package com.coolots.sso.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/coolots/sso/a/c;
 */
public interface c {
    public abstract void a(boolean p0);
    public abstract void a(boolean p0, java.lang.String p1);
}