package com.coolots.sso.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/coolots/sso/a/a;
 */
public class a {
    private static boolean a;
    private com.coolots.sso.a.f b;
    private com.coolots.sso.a.c c;
    private com.coolots.sso.a.e d;
    private com.coolots.sso.a.b e;
    private com.coolots.sso.a.g f;
    private com.coolots.sso.a.d g;

    static {
        v0 = 0;
        com.coolots.sso.a.a.a = v0; // :boolean
        return;
    }

    public a() {
        // Registers (3 total): v2 = this
        v0 = 0;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.b = v0; // com.coolots.sso.a.a.b:com.coolots.sso.a.f
        v2.c = v0; // com.coolots.sso.a.a.c:com.coolots.sso.a.c
        v2.d = v0; // com.coolots.sso.a.a.d:com.coolots.sso.a.e
        v2.e = v0; // com.coolots.sso.a.a.e:com.coolots.sso.a.b
        v2.f = v0; // com.coolots.sso.a.a.f:com.coolots.sso.a.g
        v2.g = v0; // com.coolots.sso.a.a.g:com.coolots.sso.a.d
        v0 = new java.lang.StringBuilder;
        v1 = "ChatONVAPII create() ";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v2.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        return;
    }

    static com.coolots.sso.a.c a(com.coolots.sso.a.a p0) {
        // Registers (2 total): v1 = p0 (com.coolots.sso.a.a)
        v0 = v1.c; // com.coolots.sso.a.a.c:com.coolots.sso.a.c
        return v0;
    }

    public static java.lang.String a(int p0) {
        // Registers (2 total): v1 = p0 (int)
        // switch(v1)
        v0 = 0;
        return v0;
        v0 = "STATE_INIT";
        // goto L_0004
        v0 = "STATE_CALLING";
        // goto L_0004
        v0 = "STATE_CONNECTED";
        // goto L_0004
        v0 = "STATE_DISCONNECTED";
        // goto L_0004
        v0 = "STATE_CHANGE_TO_CONFERENCE_CONNECTED";
        // goto L_0004
        v0 = "STATE_CHANGE_TO_P2P_CONNECTED";
        // goto L_0004
        v0 = "STATE_CHANGE_TO_CONFERENCE_DISCONNECTED";
        // goto L_0004
        v0 = "STATE_CHANGE_TO_P2P_DISCONNECTED";
        // goto L_0004
    }

    public static void a(android.content.Context p0, boolean p1) {
        // Registers (7 total): v5 = p0 (android.content.Context), v6 = p1 (boolean)
        com.coolots.sso.a.a.a = v6; // :boolean
        v0 = new java.lang.StringBuilder;
        v1 = "setDisplayLog: ";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v5.b(); // com.coolots.sso.a.a.b -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0020 */;
        v0 = "ChatON V is not installed";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        return;
        v0 = "content://com.coolots.chaton/set_log_display";
        _result = v5.b(v0); // com.coolots.sso.a.a.b -> int
        v0 = _result;
        v1 = 1;
        if (v0 != v1) /* goto L_002f */;
        v0 = "not allowed access";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        // goto L_001f
        v1 = 2;
        if (v0 != v1) /* goto L_0038 */;
        v0 = "not supported function";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        // goto L_001f
        v0 = "content://com.coolots.chaton/set_log_display";
        v1 = new android.content.ContentValues;
        _result = v1.<init>(); // android.content.ContentValues.<init> -> void
        _result = v5.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v2 = _result;
        _result = v0.parse(); // android.net.Uri.parse -> android.net.Uri
        v3 = _result;
        if (v6 == 0) /* goto L_0050 */;
        v0 = "1";
        v4 = 0;
        _result = v2.update(v3, v1, v0, v4); // android.content.ContentResolver.update -> int
        // goto L_001f
        v0 = "0";
        // goto L_004b
    }

    static void a(java.lang.String p0) {
        // Registers (1 total): v0 = p0 (java.lang.String)
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        return;
    }

    public static boolean a() {
        v0 = com.coolots.sso.a.a.a; // :boolean
        return v0;
    }

    public static boolean a(android.content.Context p0, java.lang.String p1) {
        // Registers (4 total): v2 = p0 (android.content.Context), v3 = p1 (java.lang.String)
        _result = v2.getPackageManager(); // android.content.Context.getPackageManager -> android.content.pm.PackageManager
        v0 = _result;
        v1 = 128;
        _result = v0.getApplicationInfo(v3, v1); // android.content.pm.PackageManager.getApplicationInfo -> android.content.pm.ApplicationInfo
        v0 = new java.lang.StringBuilder;
        _result = v3.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = "isInstalled() true";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 1;
        return v0;
        v0 = _exception;
        v0 = new java.lang.StringBuilder;
        _result = v3.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = "isInstalled() false";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 0;
        // goto L_0020
    }

    private static int b(android.content.Context p0, java.lang.String p1) {
        // Registers (6 total): v4 = p0 (android.content.Context), v5 = p1 (java.lang.String)
        v0 = "checkKey()";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = "content://com.coolots.chaton/key";
        v1 = new android.content.ContentValues;
        _result = v1.<init>(); // android.content.ContentValues.<init> -> void
        v2 = "key";
        _result = v4.getPackageName(); // android.content.Context.getPackageName -> java.lang.String
        v3 = _result;
        _result = v1.put(v2, v3); // android.content.ContentValues.put -> void
        v2 = "function";
        _result = v1.put(v2, v5); // android.content.ContentValues.put -> void
        _result = v4.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v2 = _result;
        _result = v0.parse(); // android.net.Uri.parse -> android.net.Uri
        v0 = _result;
        _result = v2.insert(v0, v1); // android.content.ContentResolver.insert -> android.net.Uri
        v0 = _result;
        if (v0 != 0) /* goto L_002a */;
        v0 = 1;
        return v0;
        _result = v0.toString(); // android.net.Uri.toString -> java.lang.String
        v1 = _result;
        v2 = "content://com.coolots.chaton/not_supported_function";
        _result = v1.equals(v2); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0038 */;
        v0 = 2;
        // goto L_0029
        _result = v0.toString(); // android.net.Uri.toString -> java.lang.String
        v0 = _result;
        v1 = "content://com.coolots.chaton/no_account";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0046 */;
        v0 = 3;
        // goto L_0029
        v0 = 0;
        // goto L_0029
    }

    static com.coolots.sso.a.f b(com.coolots.sso.a.a p0) {
        // Registers (2 total): v1 = p0 (com.coolots.sso.a.a)
        v0 = v1.b; // com.coolots.sso.a.a.b:com.coolots.sso.a.f
        return v0;
    }

    public static java.lang.String b(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = "";
        // switch(v1)
        return v0;
        v0 = "RET_CHATONV_SUCCESS";
        // goto L_0005
        v0 = "RET_CHATONV_FAIL";
        // goto L_0005
        v0 = "RET_CHATONV_NOT_INSTALLED";
        // goto L_0005
        v0 = "RET_CHATONV_ID_EMPTY";
        // goto L_0005
        v0 = "RET_CHATONV_UNEXPECTED_ERROR";
        // goto L_0005
        v0 = "RET_CHATONV_NOT_ALLOWED_ACCESS";
        // goto L_0005
        v0 = "RET_CHATONV_NATIONAL_CODE_EMPTY";
        // goto L_0005
        v0 = "RET_CHATONV_GUID_EMPTY";
        // goto L_0005
        v0 = "RET_CHATONV_CALLER_NAME_EMPTY";
        // goto L_0005
        v0 = "RET_CHATONV_CHATON_NUMBER_EMPTY";
        // goto L_0005
        v0 = "RET_CHATONV_CHATON_UID_EMPTY";
        // goto L_0005
        v0 = "RET_CHATONV_IMEI_EMPTY";
        // goto L_0005
        v0 = "RET_CHATONV_BIRTHDAY_EMPTY";
        // goto L_0005
        v0 = "RET_CHATONV_NOT_SUPPORTED_FUNCTION";
        // goto L_0005
        v0 = "RET_CHATONV_NO_ACCOUNT";
        // goto L_0005
    }

    private static void b(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = com.coolots.sso.a.a.a; // :boolean
        if (v0 == 0) /* goto L_0009 */;
        v0 = "ChatONVAPII(1.0.0.1)";
        _result = v0.i(v1); // android.util.Log.i -> int
        return;
    }

    public static boolean b(android.content.Context p0) {
        // Registers (3 total): v2 = p0 (android.content.Context)
        v0 = 1;
        v1 = "com.coolots.chaton";
        _result = v2.a(v1); // com.coolots.sso.a.a.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_000a */;
        return v0;
        v1 = "com.coolots.chatonforcanada";
        _result = v2.a(v1); // com.coolots.sso.a.a.a -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0009 */;
        v0 = 0;
        // goto L_0009
    }

    static com.coolots.sso.a.b c(com.coolots.sso.a.a p0) {
        // Registers (2 total): v1 = p0 (com.coolots.sso.a.a)
        v0 = v1.e; // com.coolots.sso.a.a.e:com.coolots.sso.a.b
        return v0;
    }

    private static void c(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = com.coolots.sso.a.a.a; // :boolean
        if (v0 == 0) /* goto L_0009 */;
        v0 = "ChatONVAPII(1.0.0.1)";
        _result = v0.e(v1); // android.util.Log.e -> int
        return;
    }

    static com.coolots.sso.a.e d(com.coolots.sso.a.a p0) {
        // Registers (2 total): v1 = p0 (com.coolots.sso.a.a)
        v0 = v1.d; // com.coolots.sso.a.a.d:com.coolots.sso.a.e
        return v0;
    }

    static com.coolots.sso.a.d e(com.coolots.sso.a.a p0) {
        // Registers (2 total): v1 = p0 (com.coolots.sso.a.a)
        v0 = v1.g; // com.coolots.sso.a.a.g:com.coolots.sso.a.d
        return v0;
    }

    static com.coolots.sso.a.g f(com.coolots.sso.a.a p0) {
        // Registers (2 total): v1 = p0 (com.coolots.sso.a.a)
        v0 = v1.f; // com.coolots.sso.a.a.f:com.coolots.sso.a.g
        return v0;
    }

    private void p(android.content.Context p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Context)
        v2 = 0;
        v0 = v3.c; // com.coolots.sso.a.a.c:com.coolots.sso.a.c
        if (v0 == 0) /* goto L_0025 */;
        v0 = new java.lang.StringBuilder;
        v1 = "clearAccountListener: mListener :";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v3.c; // com.coolots.sso.a.a.c:com.coolots.sso.a.c
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " => removed";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v3.c = v2; // com.coolots.sso.a.a.c:com.coolots.sso.a.c
        v0 = v3.b; // com.coolots.sso.a.a.b:com.coolots.sso.a.f
        if (v0 == 0) /* goto L_004e */;
        v0 = new java.lang.StringBuilder;
        v1 = "clearAccountListener: mReceiver :";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v3.b; // com.coolots.sso.a.a.b:com.coolots.sso.a.f
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " => removed";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = v3.b; // com.coolots.sso.a.a.b:com.coolots.sso.a.f
        _result = v4.unregisterReceiver(v0); // android.content.Context.unregisterReceiver -> void
        v3.b = v2; // com.coolots.sso.a.a.b:com.coolots.sso.a.f
        return;
    }

    private void q(android.content.Context p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Context)
        v2 = 0;
        v0 = v3.e; // com.coolots.sso.a.a.e:com.coolots.sso.a.b
        if (v0 == 0) /* goto L_0025 */;
        v0 = new java.lang.StringBuilder;
        v1 = "clearCallListener: mCallListener :";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v3.e; // com.coolots.sso.a.a.e:com.coolots.sso.a.b
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " => removed";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v3.e = v2; // com.coolots.sso.a.a.e:com.coolots.sso.a.b
        v0 = v3.d; // com.coolots.sso.a.a.d:com.coolots.sso.a.e
        if (v0 == 0) /* goto L_004e */;
        v0 = new java.lang.StringBuilder;
        v1 = "clearCallListener: mCallReceiver :";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v3.d; // com.coolots.sso.a.a.d:com.coolots.sso.a.e
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " => removed";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = v3.d; // com.coolots.sso.a.a.d:com.coolots.sso.a.e
        _result = v4.unregisterReceiver(v0); // android.content.Context.unregisterReceiver -> void
        v3.d = v2; // com.coolots.sso.a.a.d:com.coolots.sso.a.e
        return;
    }

    private void r(android.content.Context p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Context)
        v2 = 0;
        v0 = v3.g; // com.coolots.sso.a.a.g:com.coolots.sso.a.d
        if (v0 == 0) /* goto L_0025 */;
        v0 = new java.lang.StringBuilder;
        v1 = "clearUpdateListener: mUpdateListener :";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v3.g; // com.coolots.sso.a.a.g:com.coolots.sso.a.d
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " => removed";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v3.g = v2; // com.coolots.sso.a.a.g:com.coolots.sso.a.d
        v0 = v3.f; // com.coolots.sso.a.a.f:com.coolots.sso.a.g
        if (v0 == 0) /* goto L_004e */;
        v0 = new java.lang.StringBuilder;
        v1 = "clearUpdateListener: mUpdateReceiver :";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v3.f; // com.coolots.sso.a.a.f:com.coolots.sso.a.g
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " => removed";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = v3.f; // com.coolots.sso.a.a.f:com.coolots.sso.a.g
        _result = v4.unregisterReceiver(v0); // android.content.Context.unregisterReceiver -> void
        v3.f = v2; // com.coolots.sso.a.a.f:com.coolots.sso.a.g
        return;
    }

    public int a(android.content.Context p0, java.lang.String p1, java.lang.String p2, java.lang.String p3, java.lang.String p4, java.lang.String p5, java.lang.String p6, java.lang.String p7, java.lang.String p8) {
        // Registers (16 total): v6 = this, v7 = p0 (android.content.Context), v8 = p1 (java.lang.String), v9 = p2 (java.lang.String), v10 = p3 (java.lang.String), v11 = p4 (java.lang.String), v12 = p5 (java.lang.String), v13 = p6 (java.lang.String), v14 = p7 (java.lang.String), v15 = p8 (java.lang.String)
        v0 = "createAccount() call start";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v7.b(); // com.coolots.sso.a.a.b -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0012 */;
        v0 = "ChatON V is not installed";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 2;
        return v0;
        v0 = "content://com.coolots.chaton/create_account";
        _result = v7.b(v0); // com.coolots.sso.a.a.b -> int
        v0 = _result;
        v1 = 1;
        if (v0 != v1) /* goto L_0022 */;
        v0 = "not allowed access";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 5;
        // goto L_0011
        v1 = 2;
        if (v0 != v1) /* goto L_002d */;
        v0 = "not supported function";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 13;
        // goto L_0011
        v1 = 3;
        if (v0 != v1) /* goto L_0035 */;
        v0 = "no account";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        if (v9 == 0) /* goto L_003d */;
        _result = v9.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0044 */;
        v0 = "samsungAccount is empty";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 3;
        // goto L_0011
        if (v10 == 0) /* goto L_004c */;
        _result = v10.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0053 */;
        v0 = "nationalCode is empty";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 6;
        // goto L_0011
        if (v11 == 0) /* goto L_005b */;
        _result = v11.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0062 */;
        v0 = "GUID is empty";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 7;
        // goto L_0011
        if (v12 == 0) /* goto L_006a */;
        _result = v12.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0072 */;
        v0 = "callerName is empty";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 8;
        // goto L_0011
        if (v8 == 0) /* goto L_007a */;
        _result = v8.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0082 */;
        v0 = "chatonID is empty";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 9;
        // goto L_0011
        if (v13 == 0) /* goto L_008a */;
        _result = v13.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0092 */;
        v0 = "IMEI is empty";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 11;
        // goto L_0011
        if (v14 == 0) /* goto L_009a */;
        _result = v14.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00a3 */;
        v0 = "chatONUID is empty";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 10;
        // goto L_0011
        if (v15 == 0) /* goto L_00ab */;
        _result = v15.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00b0 */;
        v0 = "birthday is empty";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v1 = "content://com.coolots.chaton/create_account";
        v0 = 8;
        v4 = new java.lang.String[][size=v0];
        v0 = 0;
        _result = v9.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v2 = _result;
        v4[v0] = v2;
        v0 = 1;
        _result = v10.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v2 = _result;
        v4[v0] = v2;
        v0 = 2;
        _result = v12.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v2 = _result;
        v4[v0] = v2;
        v0 = 3;
        _result = v11.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v2 = _result;
        v4[v0] = v2;
        v0 = 4;
        _result = v8.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v2 = _result;
        v4[v0] = v2;
        v0 = 5;
        _result = v13.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v2 = _result;
        v4[v0] = v2;
        v0 = 6;
        _result = v14.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v2 = _result;
        v4[v0] = v2;
        v0 = 7;
        _result = v15.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v2 = _result;
        v4[v0] = v2;
        _result = v7.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        _result = v1.parse(); // android.net.Uri.parse -> android.net.Uri
        v1 = _result;
        v2 = 0;
        v3 = 0;
        v5 = 0;
        _result = v0.query(v0..v5); // android.content.ContentResolver.query -> android.database.Cursor
        v0 = _result;
        if (v0 == 0) /* goto L_0102 */;
        _result = android.database.Cursor.close(v0); // -> void
        v0 = 0;
        // goto L_0011
    }

    public int a(android.content.Context p0, boolean p1, java.lang.String p2, java.lang.String p3, java.lang.String p4) {
        // Registers (14 total): v8 = this, v9 = p0 (android.content.Context), v10 = p1 (boolean), v11 = p2 (java.lang.String), v12 = p3 (java.lang.String), v13 = p4 (java.lang.String)
        v7 = 1;
        v6 = 0;
        v2 = 0;
        v3 = 3;
        v1 = 2;
        v0 = "outgoingCall() call start";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v9.b(); // com.coolots.sso.a.a.b -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        v0 = "ChatON V is not installed";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = v1;
        return v0;
        v0 = "content://com.coolots.chaton/outgoingcall";
        _result = v9.b(v0); // com.coolots.sso.a.a.b -> int
        v0 = _result;
        if (v0 != v7) /* goto L_0026 */;
        v0 = "not allowed access";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 5;
        // goto L_0016
        if (v0 != v1) /* goto L_0030 */;
        v0 = "not supported function";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 13;
        // goto L_0016
        if (v0 != v3) /* goto L_003a */;
        v0 = "no account";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 14;
        // goto L_0016
        if (v11 == 0) /* goto L_0042 */;
        _result = v11.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0049 */;
        v0 = "chatonID is empty";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = v3;
        // goto L_0016
        v5 = "content://com.coolots.chaton/outgoingcall";
        v0 = 4;
        v4 = new java.lang.String[][size=v0];
        if (v10 == 0) /* goto L_007f */;
        v0 = "1";
        _result = v0.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v0 = _result;
        v4[v6] = v0;
        _result = v12.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v0 = _result;
        v4[v7] = v0;
        _result = v11.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v0 = _result;
        v4[v1] = v0;
        _result = v13.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v0 = _result;
        v4[v3] = v0;
        _result = v9.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        _result = v5.parse(); // android.net.Uri.parse -> android.net.Uri
        v1 = _result;
        v3 = v2;
        v5 = v2;
        _result = v0.query(v0..v5); // android.content.ContentResolver.query -> android.database.Cursor
        v0 = _result;
        if (v0 == 0) /* goto L_007d */;
        _result = android.database.Cursor.close(v0); // -> void
        v0 = v6;
        // goto L_0016
        v0 = "0";
        // goto L_0052
    }

    public int a(android.content.Context p0, boolean p1, java.lang.String[] p2, java.lang.String p3, java.lang.String p4, java.lang.String p5) {
        // Registers (15 total): v8 = this, v9 = p0 (android.content.Context), v10 = p1 (boolean), v11 = p2 (java.lang.String[]), v12 = p3 (java.lang.String), v13 = p4 (java.lang.String), v14 = p5 (java.lang.String)
        v7 = 1;
        v2 = 0;
        v3 = 3;
        v1 = 2;
        v6 = 0;
        v0 = "outgoingConferenceCall() call start";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v9.b(); // com.coolots.sso.a.a.b -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        v0 = "ChatON V is not installed";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = v1;
        return v0;
        v0 = "content://com.coolots.chaton/outgoingconferencecall";
        _result = v9.b(v0); // com.coolots.sso.a.a.b -> int
        v0 = _result;
        if (v0 != v7) /* goto L_0026 */;
        v0 = "not allowed access";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 5;
        // goto L_0016
        if (v0 != v1) /* goto L_0030 */;
        v0 = "not supported function";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 13;
        // goto L_0016
        if (v0 != v3) /* goto L_003a */;
        v0 = "no account";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 14;
        // goto L_0016
        if (v11 == 0) /* goto L_003f */;
        v0 = v11.length;
        if (v0 != 0) /* goto L_0046 */;
        v0 = "samsungAccount is empty";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = v3;
        // goto L_0016
        v5 = "content://com.coolots.chaton/outgoingconferencecall";
        v0 = v11.length;
        v0 = binOpLit8_0xd8(v0, 5);
        v4 = new java.lang.String[][size=v0];
        if (v10 == 0) /* goto L_008b */;
        v0 = "1";
        _result = v0.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v0 = _result;
        v4[v6] = v0;
        _result = v12.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v0 = _result;
        v4[v7] = v0;
        _result = v13.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v0 = _result;
        v4[v1] = v0;
        _result = v14.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v0 = _result;
        v4[v3] = v0;
        v0 = 4;
        v1 = v11.length;
        _result = v1.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v1 = _result;
        v4[v0] = v1;
        v0 = 5;
        v1 = v11.length;
        _result = v11.arraycopy(v6, v4, v0, v1); // java.lang.System.arraycopy -> void
        _result = v9.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        _result = v5.parse(); // android.net.Uri.parse -> android.net.Uri
        v1 = _result;
        v3 = v2;
        v5 = v2;
        _result = v0.query(v0..v5); // android.content.ContentResolver.query -> android.database.Cursor
        v0 = _result;
        if (v0 == 0) /* goto L_0089 */;
        _result = android.database.Cursor.close(v0); // -> void
        v0 = v6;
        // goto L_0016
        v0 = "0";
        // goto L_0051
    }

    public void a(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        v0 = "dispose()";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v1.p(v2); // com.coolots.sso.a.a.p -> void
        _result = v1.q(v2); // com.coolots.sso.a.a.q -> void
        _result = v1.r(v2); // com.coolots.sso.a.a.r -> void
        return;
    }

    public void a(android.content.Context p0, com.coolots.sso.a.b p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.content.Context), v6 = p1 (com.coolots.sso.a.b)
        v3 = 0;
        if (v6 != 0) /* goto L_001d */;
        v0 = new java.lang.StringBuilder;
        v1 = "setCallListener: clear ";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v4.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v4.q(v5); // com.coolots.sso.a.a.q -> void
        return;
        _result = v4.q(v5); // com.coolots.sso.a.a.q -> void
        v4.e = v6; // com.coolots.sso.a.a.e:com.coolots.sso.a.b
        v0 = new com.coolots.sso.a.e;
        _result = v0.<init>(v4, v3); // com.coolots.sso.a.e.<init> -> void
        v4.d = v0; // com.coolots.sso.a.a.d:com.coolots.sso.a.e
        v0 = new java.lang.StringBuilder;
        v1 = "setCallListener: set ";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v4.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = new java.lang.StringBuilder;
        v1 = "setCallListener: mCallListener ";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v4.e; // com.coolots.sso.a.a.e:com.coolots.sso.a.b
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = new java.lang.StringBuilder;
        v1 = "setCallListener: mCallReceiver ";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v4.d; // com.coolots.sso.a.a.d:com.coolots.sso.a.e
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = new android.content.IntentFilter;
        _result = v0.<init>(); // android.content.IntentFilter.<init> -> void
        v1 = "com.coolots.chaton.version.CONFERENCE_MEMBER_CHANGED";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        v1 = "com.coolots.chaton.account.CALL_STATE_CHANGE_INFO";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        v1 = v4.d; // com.coolots.sso.a.a.d:com.coolots.sso.a.e
        v2 = "com.coolots.permission.COOLOTS";
        _result = v5.registerReceiver(v1, v0, v2, v3); // android.content.Context.registerReceiver -> android.content.Intent
        // goto L_001c
    }

    public void a(android.content.Context p0, com.coolots.sso.a.c p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.content.Context), v6 = p1 (com.coolots.sso.a.c)
        v3 = 0;
        if (v6 != 0) /* goto L_001d */;
        v0 = new java.lang.StringBuilder;
        v1 = "setListener: clear ";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v4.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v4.p(v5); // com.coolots.sso.a.a.p -> void
        return;
        _result = v4.p(v5); // com.coolots.sso.a.a.p -> void
        v4.c = v6; // com.coolots.sso.a.a.c:com.coolots.sso.a.c
        v0 = new com.coolots.sso.a.f;
        _result = v0.<init>(v4, v3); // com.coolots.sso.a.f.<init> -> void
        v4.b = v0; // com.coolots.sso.a.a.b:com.coolots.sso.a.f
        v0 = new java.lang.StringBuilder;
        v1 = "setListener: set :";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v4.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = new java.lang.StringBuilder;
        v1 = "setListener: mListener :";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v4.c; // com.coolots.sso.a.a.c:com.coolots.sso.a.c
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = new java.lang.StringBuilder;
        v1 = "setListener: mReceiver :";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v4.b; // com.coolots.sso.a.a.b:com.coolots.sso.a.f
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = new android.content.IntentFilter;
        _result = v0.<init>(); // android.content.IntentFilter.<init> -> void
        v1 = "com.coolots.chaton.account.ACCOUNT_RESULTINFO";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        v1 = "com.coolots.chaton.account.REMOVE_ACCOUNT_RESULTINFO";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        v1 = v4.b; // com.coolots.sso.a.a.b:com.coolots.sso.a.f
        v2 = "com.coolots.permission.COOLOTS";
        _result = v5.registerReceiver(v1, v0, v2, v3); // android.content.Context.registerReceiver -> android.content.Intent
        // goto L_001c
    }

    public void a(android.content.Context p0, com.coolots.sso.a.d p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.content.Context), v6 = p1 (com.coolots.sso.a.d)
        v3 = 0;
        if (v6 != 0) /* goto L_001d */;
        v0 = new java.lang.StringBuilder;
        v1 = "setUpdateListener: clear ";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v4.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v4.r(v5); // com.coolots.sso.a.a.r -> void
        return;
        _result = v4.r(v5); // com.coolots.sso.a.a.r -> void
        v4.g = v6; // com.coolots.sso.a.a.g:com.coolots.sso.a.d
        v0 = new com.coolots.sso.a.g;
        _result = v0.<init>(v4, v3); // com.coolots.sso.a.g.<init> -> void
        v4.f = v0; // com.coolots.sso.a.a.f:com.coolots.sso.a.g
        v0 = new java.lang.StringBuilder;
        v1 = "setUpdateListener: set ";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v4.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = new java.lang.StringBuilder;
        v1 = "setUpdateListener: mUpdateListener ";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v4.g; // com.coolots.sso.a.a.g:com.coolots.sso.a.d
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = new java.lang.StringBuilder;
        v1 = "setUpdateListener: mUpdateReceiver ";
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v4.f; // com.coolots.sso.a.a.f:com.coolots.sso.a.g
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = new android.content.IntentFilter;
        _result = v0.<init>(); // android.content.IntentFilter.<init> -> void
        v1 = "com.coolots.chaton.version.UPGRADE_NEW_APK_INFO";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        v1 = v4.f; // com.coolots.sso.a.a.f:com.coolots.sso.a.g
        v2 = "com.coolots.permission.COOLOTS";
        _result = v5.registerReceiver(v1, v0, v2, v3); // android.content.Context.registerReceiver -> android.content.Intent
        // goto L_001c
    }

    public int b(android.content.Context p0, boolean p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.content.Context), v7 = p1 (boolean)
        v0 = 0;
        v1 = "getMaxConferenceMemberCnt()";
        _result = v1.b(); // com.coolots.sso.a.a.b -> void
        _result = v6.b(); // com.coolots.sso.a.a.b -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0012 */;
        v1 = "ChatON V is not installed";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        return v0;
        v1 = "content://com.coolots.chaton/maxconferencecallnum";
        _result = v6.b(v1); // com.coolots.sso.a.a.b -> int
        v1 = _result;
        v2 = 1;
        if (v1 != v2) /* goto L_0021 */;
        v1 = "not allowed access";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0011
        v2 = 2;
        if (v1 != v2) /* goto L_002a */;
        v1 = "not supported function";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0011
        v2 = 3;
        if (v1 != v2) /* goto L_0033 */;
        v1 = "no account";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0011
        v0 = "content://com.coolots.chaton/maxconferencecallnum";
        v1 = new android.content.ContentValues;
        _result = v1.<init>(); // android.content.ContentValues.<init> -> void
        _result = v6.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v2 = _result;
        _result = v0.parse(); // android.net.Uri.parse -> android.net.Uri
        v3 = _result;
        if (v7 == 0) /* goto L_004c */;
        v0 = "1";
        v4 = 0;
        _result = v2.update(v3, v1, v0, v4); // android.content.ContentResolver.update -> int
        v0 = _result;
        // goto L_0011
        v0 = "0";
        // goto L_0046
    }

    public int c(android.content.Context p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.content.Context)
        v0 = 2;
        v2 = 0;
        v1 = "removeAccountInDevice() call start";
        _result = v1.b(); // com.coolots.sso.a.a.b -> void
        _result = v7.b(); // com.coolots.sso.a.a.b -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        v1 = "ChatON V is not installed";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        return v0;
        v1 = "content://com.coolots.chaton/remove_account";
        _result = v7.b(v1); // com.coolots.sso.a.a.b -> int
        v1 = _result;
        v3 = 1;
        if (v1 != v3) /* goto L_0023 */;
        v0 = "not allowed access";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 5;
        // goto L_0012
        if (v1 != v0) /* goto L_002d */;
        v0 = "not supported function";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 13;
        // goto L_0012
        v1 = "content://com.coolots.chaton/remove_account";
        _result = v7.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        _result = v1.parse(); // android.net.Uri.parse -> android.net.Uri
        v1 = _result;
        v3 = v2;
        v4 = v2;
        v5 = v2;
        _result = v0.query(v0..v5); // android.content.ContentResolver.query -> android.database.Cursor
        v0 = _result;
        if (v0 == 0) /* goto L_0043 */;
        _result = android.database.Cursor.close(v0); // -> void
        v0 = 0;
        // goto L_0012
    }

    public boolean d(android.content.Context p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.content.Context)
        v1 = 1;
        v0 = 0;
        v2 = "isReadyToCall() call start";
        _result = v2.b(); // com.coolots.sso.a.a.b -> void
        _result = v5.b(); // com.coolots.sso.a.a.b -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0013 */;
        v1 = "ChatON V is not installed";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        return v0;
        v2 = "content://com.coolots.chaton/account";
        _result = v5.b(v2); // com.coolots.sso.a.a.b -> int
        v2 = _result;
        if (v2 != v1) /* goto L_0021 */;
        v1 = "not allowed access";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v3 = 2;
        if (v2 != v3) /* goto L_002a */;
        v1 = "not supported function";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v3 = 3;
        if (v2 != v3) /* goto L_0033 */;
        v1 = "no account";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v0 = v1;
        // goto L_0012
    }

    public android.content.Intent e(android.content.Context p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Context)
        v0 = "getIntentSettingActivity()";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v2.d(v3); // com.coolots.sso.a.a.d -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0016 */;
        v0 = new android.content.Intent;
        _result = v0.<init>(); // android.content.Intent.<init> -> void
        v1 = "com.coolots.chaton.USER_SETTING_SUBPAGE_CALL_SETTINGS";
        _result = v0.setAction(v1); // android.content.Intent.setAction -> android.content.Intent
        return v0;
        v0 = "getIntentSettingActivity() return null";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 0;
        // goto L_0015
    }

    public android.content.Intent f(android.content.Context p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Context)
        v0 = "getIntentAboutChatONVActivity()";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v2.d(v3); // com.coolots.sso.a.a.d -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0016 */;
        v0 = new android.content.Intent;
        _result = v0.<init>(); // android.content.Intent.<init> -> void
        v1 = "com.coolots.chaton.USER_SETTING_SUBPAGE_ABOUNT_CHATON_CALL";
        _result = v0.setAction(v1); // android.content.Intent.setAction -> android.content.Intent
        return v0;
        v0 = "getIntentAboutChatONVActivity() return null";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 0;
        // goto L_0015
    }

    public android.content.Intent g(android.content.Context p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Context)
        v0 = "getIntentDataUsageActivity()";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v2.d(v3); // com.coolots.sso.a.a.d -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0016 */;
        v0 = new android.content.Intent;
        _result = v0.<init>(); // android.content.Intent.<init> -> void
        v1 = "com.coolots.chaton.USER_SETTING_SUBPAGE_DATA_USGAE";
        _result = v0.setAction(v1); // android.content.Intent.setAction -> android.content.Intent
        return v0;
        v0 = "getIntentDataUsageActivity() return null";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        v0 = 0;
        // goto L_0015
    }

    public boolean h(android.content.Context p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.content.Context)
        v1 = 1;
        v0 = 0;
        v2 = "showCallActivity() call start";
        _result = v2.b(); // com.coolots.sso.a.a.b -> void
        _result = v8.b(); // com.coolots.sso.a.a.b -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0013 */;
        v1 = "ChatON V is not installed";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        return v0;
        v2 = "content://com.coolots.chaton/remotecallactivity";
        _result = v8.b(v2); // com.coolots.sso.a.a.b -> int
        v2 = _result;
        if (v2 != v1) /* goto L_0021 */;
        v1 = "not allowed access";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v3 = 2;
        if (v2 != v3) /* goto L_002a */;
        v1 = "not supported function";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v3 = 3;
        if (v2 != v3) /* goto L_0033 */;
        v1 = "no account";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v2 = "content://com.coolots.chaton/remotecallactivity";
        v3 = new android.content.ContentValues;
        _result = v3.<init>(); // android.content.ContentValues.<init> -> void
        _result = v8.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v4 = _result;
        _result = v2.parse(); // android.net.Uri.parse -> android.net.Uri
        v2 = _result;
        v5 = "0";
        v6 = 0;
        _result = v4.update(v2, v3, v5, v6); // android.content.ContentResolver.update -> int
        v2 = _result;
        if (v2 != v1) /* goto L_0012 */;
        v0 = v1;
        // goto L_0012
    }

    public boolean i(android.content.Context p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.content.Context)
        v1 = 1;
        v0 = 0;
        v2 = "endCallActivity() call start";
        _result = v2.b(); // com.coolots.sso.a.a.b -> void
        _result = v8.b(); // com.coolots.sso.a.a.b -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0013 */;
        v1 = "ChatON V is not installed";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        return v0;
        v2 = "content://com.coolots.chaton/remotecallactivity";
        _result = v8.b(v2); // com.coolots.sso.a.a.b -> int
        v2 = _result;
        if (v2 != v1) /* goto L_0021 */;
        v1 = "not allowed access";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v3 = 2;
        if (v2 != v3) /* goto L_002a */;
        v1 = "not supported function";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v3 = 3;
        if (v2 != v3) /* goto L_0033 */;
        v1 = "no account";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v2 = "content://com.coolots.chaton/remotecallactivity";
        v3 = new android.content.ContentValues;
        _result = v3.<init>(); // android.content.ContentValues.<init> -> void
        _result = v8.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v4 = _result;
        _result = v2.parse(); // android.net.Uri.parse -> android.net.Uri
        v2 = _result;
        v5 = "1";
        v6 = 0;
        _result = v4.update(v2, v3, v5, v6); // android.content.ContentResolver.update -> int
        v2 = _result;
        if (v2 != v1) /* goto L_0012 */;
        v0 = v1;
        // goto L_0012
    }

    public int j(android.content.Context p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Context)
        v0 = -1;
        v1 = "getCallDuration() call start";
        _result = v1.b(); // com.coolots.sso.a.a.b -> void
        _result = v4.b(); // com.coolots.sso.a.a.b -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0012 */;
        v1 = "ChatON V is not installed";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        return v0;
        v1 = "content://com.coolots.chaton/callduration";
        _result = v4.b(v1); // com.coolots.sso.a.a.b -> int
        v1 = _result;
        v2 = 1;
        if (v1 != v2) /* goto L_0021 */;
        v1 = "not allowed access";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0011
        v2 = 2;
        if (v1 != v2) /* goto L_002a */;
        v1 = "not supported function";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0011
        v2 = 3;
        if (v1 != v2) /* goto L_0033 */;
        v1 = "no account";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0011
        v1 = "content://com.coolots.chaton/callduration";
        _result = v4.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v2 = _result;
        _result = v1.parse(); // android.net.Uri.parse -> android.net.Uri
        v1 = _result;
        _result = v2.getType(v1); // android.content.ContentResolver.getType -> java.lang.String
        v1 = _result;
        if (v1 == 0) /* goto L_0011 */;
        _result = v1.parseInt(); // java.lang.Integer.parseInt -> int
        v0 = _result;
        // goto L_0011
    }

    public boolean k(android.content.Context p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.content.Context)
        v1 = 1;
        v0 = 0;
        v2 = "isCalling() call start";
        _result = v2.b(); // com.coolots.sso.a.a.b -> void
        _result = v5.b(); // com.coolots.sso.a.a.b -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0013 */;
        v1 = "ChatON V is not installed";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        return v0;
        v2 = "content://com.coolots.chaton/iscalling";
        _result = v5.b(v2); // com.coolots.sso.a.a.b -> int
        v2 = _result;
        if (v2 != v1) /* goto L_0021 */;
        v1 = "not allowed access";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v3 = 2;
        if (v2 != v3) /* goto L_002a */;
        v1 = "not supported function";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v3 = 3;
        if (v2 != v3) /* goto L_0033 */;
        v1 = "no account";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v2 = "content://com.coolots.chaton/iscalling";
        _result = v5.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v3 = _result;
        _result = v2.parse(); // android.net.Uri.parse -> android.net.Uri
        v2 = _result;
        _result = v3.getType(v2); // android.content.ContentResolver.getType -> java.lang.String
        v2 = _result;
        if (v2 == 0) /* goto L_0012 */;
        v0 = v1;
        // goto L_0012
    }

    public int l(android.content.Context p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.content.Context)
        v1 = 3;
        v0 = 0;
        v2 = "getCallStateDuringCall() call start";
        _result = v2.b(); // com.coolots.sso.a.a.b -> void
        _result = v5.b(); // com.coolots.sso.a.a.b -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0013 */;
        v1 = "ChatON V is not installed";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        return v0;
        v2 = "content://com.coolots.chaton/callstate";
        _result = v5.b(v2); // com.coolots.sso.a.a.b -> int
        v2 = _result;
        v3 = 1;
        if (v2 != v3) /* goto L_0022 */;
        v1 = "not allowed access";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v3 = 2;
        if (v2 != v3) /* goto L_002b */;
        v1 = "not supported function";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        if (v2 != v1) /* goto L_0033 */;
        v1 = "no account";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v0 = "content://com.coolots.chaton/callstate";
        _result = v5.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v2 = _result;
        _result = v0.parse(); // android.net.Uri.parse -> android.net.Uri
        v0 = _result;
        _result = v2.getType(v0); // android.content.ContentResolver.getType -> java.lang.String
        v0 = _result;
        if (v0 != 0) /* goto L_0045 */;
        v0 = v1;
        // goto L_0012
        _result = v0.parseInt(); // java.lang.Integer.parseInt -> int
        v0 = _result;
        // goto L_0012
    }

    public int m(android.content.Context p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.content.Context)
        v3 = 0;
        v0 = 0;
        v1 = "getCallType() call start";
        _result = v1.b(); // com.coolots.sso.a.a.b -> void
        _result = v5.b(); // com.coolots.sso.a.a.b -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        v1 = "ChatON V is not installed";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        return v0;
        v1 = "content://com.coolots.chaton/get_call_type";
        _result = v5.b(v1); // com.coolots.sso.a.a.b -> int
        v1 = _result;
        v2 = 1;
        if (v1 != v2) /* goto L_0022 */;
        v1 = "not allowed access";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v2 = 2;
        if (v1 != v2) /* goto L_002b */;
        v1 = "not supported function";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v2 = 3;
        if (v1 != v2) /* goto L_0034 */;
        v1 = "no account";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        // goto L_0012
        v0 = "content://com.coolots.chaton/get_call_type";
        v1 = new android.content.ContentValues;
        _result = v1.<init>(); // android.content.ContentValues.<init> -> void
        _result = v5.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v2 = _result;
        _result = v0.parse(); // android.net.Uri.parse -> android.net.Uri
        v0 = _result;
        _result = v2.update(v0, v1, v3, v3); // android.content.ContentResolver.update -> int
        v0 = _result;
        // goto L_0012
    }

    public java.util.ArrayList n(android.content.Context p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.content.Context)
        v1 = 0;
        v0 = "getCallMember() call start";
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v6.b(); // com.coolots.sso.a.a.b -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0013 */;
        v0 = "ChatON V is not installed";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = v1;
        return v0;
        v0 = "content://com.coolots.chaton/get_call_member";
        _result = v6.b(v0); // com.coolots.sso.a.a.b -> int
        v0 = _result;
        v2 = 1;
        if (v0 != v2) /* goto L_0023 */;
        v0 = "not allowed access";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = v1;
        // goto L_0012
        v2 = 2;
        if (v0 != v2) /* goto L_002d */;
        v0 = "not supported function";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = v1;
        // goto L_0012
        v2 = 3;
        if (v0 != v2) /* goto L_0037 */;
        v0 = "no account";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = v1;
        // goto L_0012
        v0 = "content://com.coolots.chaton/get_call_member";
        _result = v6.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v3 = _result;
        v2 = new java.util.ArrayList;
        _result = v2.<init>(); // java.util.ArrayList.<init> -> void
        _result = v0.parse(); // android.net.Uri.parse -> android.net.Uri
        v0 = _result;
        _result = v3.getType(v0); // android.content.ContentResolver.getType -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0052 */;
        _result = v0.length(); // java.lang.String.length -> int
        v3 = _result;
        if (v3 != 0) /* goto L_0054 */;
        v0 = v1;
        // goto L_0012
        v3 = ":";
        _result = v0.split(v3); // java.lang.String.split -> java.lang.String[]
        v3 = _result;
        v0 = 0;
        v4 = v3.length;
        if (v0 < v4) /* goto L_0078 */;
        v0 = new java.lang.StringBuilder;
        v3 = "call member: ";
        _result = v0.<init>(v3); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.b(); // com.coolots.sso.a.a.b -> void
        _result = v2.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0080 */;
        v0 = v1;
        // goto L_0012
        v4 = v3[v0];
        _result = v2.add(v4); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_005b
        v0 = v2;
        // goto L_0012
    }

    public int o(android.content.Context p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Context)
        v0 = 2;
        v1 = "getLatestApkVersion() call start";
        _result = v1.b(); // com.coolots.sso.a.a.b -> void
        _result = v4.b(); // com.coolots.sso.a.a.b -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0012 */;
        v1 = "ChatON V is not installed";
        _result = v1.c(); // com.coolots.sso.a.a.c -> void
        return v0;
        v1 = "content://com.coolots.chaton/get_latest_version";
        _result = v4.b(v1); // com.coolots.sso.a.a.b -> int
        v1 = _result;
        v2 = 1;
        if (v1 != v2) /* goto L_0022 */;
        v0 = "not allowed access";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 5;
        // goto L_0011
        if (v1 != v0) /* goto L_002c */;
        v0 = "not supported function";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 13;
        // goto L_0011
        v0 = 3;
        if (v1 != v0) /* goto L_0037 */;
        v0 = "no account";
        _result = v0.c(); // com.coolots.sso.a.a.c -> void
        v0 = 14;
        // goto L_0011
        v0 = "content://com.coolots.chaton/get_latest_version";
        _result = v4.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v1 = _result;
        _result = v0.parse(); // android.net.Uri.parse -> android.net.Uri
        v0 = _result;
        _result = v1.getType(v0); // android.content.ContentResolver.getType -> java.lang.String
        v0 = 0;
        // goto L_0011
    }

}