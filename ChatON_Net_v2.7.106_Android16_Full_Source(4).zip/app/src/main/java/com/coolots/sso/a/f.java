package com.coolots.sso.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/coolots/sso/a/f;
 */
class f extends android.content.BroadcastReceiver {
    final com.coolots.sso.a.a a;

    private f(com.coolots.sso.a.a p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.coolots.sso.a.a)
        v0.a = v1; // com.coolots.sso.a.f.a:com.coolots.sso.a.a
        _result = v0.<init>(); // android.content.BroadcastReceiver.<init> -> void
        return;
    }

    f(com.coolots.sso.a.a p0, com.coolots.sso.a.f p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.coolots.sso.a.a), v2 = p1 (com.coolots.sso.a.f)
        _result = v0.<init>(v1); // com.coolots.sso.a.f.<init> -> void
        return;
    }

    public void onReceive(android.content.Context p0, android.content.Intent p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.content.Context), v6 = p1 (android.content.Intent)
        v3 = 0;
        _result = v6.getAction(); // android.content.Intent.getAction -> java.lang.String
        v0 = _result;
        if (v0 != 0) /* goto L_0008 */;
        return;
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIIReceiver() action: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIIReceiver() this: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        _result = v4.toString(); // java.lang.Object.toString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIIReceiver() mListener: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        v2 = v4.a; // com.coolots.sso.a.f.a:com.coolots.sso.a.a
        _result = v2.a(); // com.coolots.sso.a.a.a -> com.coolots.sso.a.c
        v2 = _result;
        _result = v2.toString(); // java.lang.Object.toString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIIReceiver() mReceiver: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        v2 = v4.a; // com.coolots.sso.a.f.a:com.coolots.sso.a.a
        _result = v2.b(); // com.coolots.sso.a.a.b -> com.coolots.sso.a.f
        v2 = _result;
        _result = v2.toString(); // java.lang.Object.toString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = "com.coolots.chaton.account.ACCOUNT_RESULTINFO";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_00b8 */;
        v0 = "result";
        _result = v6.hasExtra(v0); // android.content.Intent.hasExtra -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0007 */;
        v0 = "BR_ACCOUNT_RESULT_INFO";
        _result = v0.a(); // com.coolots.sso.a.a.a -> void
        v0 = v4.a; // com.coolots.sso.a.f.a:com.coolots.sso.a.a
        _result = v0.a(); // com.coolots.sso.a.a.a -> com.coolots.sso.a.c
        v0 = _result;
        if (v0 == 0) /* goto L_0007 */;
        v0 = "result";
        _result = v6.getBooleanExtra(v0, v3); // android.content.Intent.getBooleanExtra -> boolean
        v0 = _result;
        v1 = "account_fail_string";
        _result = v6.getStringExtra(v1); // android.content.Intent.getStringExtra -> java.lang.String
        v1 = _result;
        v2 = new java.lang.StringBuilder;
        v3 = "result: ";
        _result = v2.<init>(v3); // java.lang.StringBuilder.<init> -> void
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ", result string: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v2.a(); // com.coolots.sso.a.a.a -> void
        v2 = v4.a; // com.coolots.sso.a.f.a:com.coolots.sso.a.a
        _result = v2.a(); // com.coolots.sso.a.a.a -> com.coolots.sso.a.c
        v2 = _result;
        _result = com.coolots.sso.a.c.a(v2, v0, v1); // -> void
        // goto L_0007
        v1 = "com.coolots.chaton.account.REMOVE_ACCOUNT_RESULTINFO";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0007 */;
        v0 = "result";
        _result = v6.hasExtra(v0); // android.content.Intent.hasExtra -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0007 */;
        v0 = "BR_REMOVE_ACCOUNT_RESULT_INFO";
        _result = v0.a(); // com.coolots.sso.a.a.a -> void
        v0 = v4.a; // com.coolots.sso.a.f.a:com.coolots.sso.a.a
        _result = v0.a(); // com.coolots.sso.a.a.a -> com.coolots.sso.a.c
        v0 = _result;
        if (v0 == 0) /* goto L_0007 */;
        v0 = v4.a; // com.coolots.sso.a.f.a:com.coolots.sso.a.a
        _result = v0.a(); // com.coolots.sso.a.a.a -> com.coolots.sso.a.c
        v0 = _result;
        v1 = "result";
        _result = v6.getBooleanExtra(v1, v3); // android.content.Intent.getBooleanExtra -> boolean
        v1 = _result;
        _result = com.coolots.sso.a.c.a(v0, v1); // -> void
        // goto L_0007
    }

}