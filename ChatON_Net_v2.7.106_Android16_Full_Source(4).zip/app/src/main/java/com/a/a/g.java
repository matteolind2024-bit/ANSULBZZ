package com.a.a;

/**
 * Original SourceFile: FbDialog.java
 * Descriptor: Lcom/a/a/g;
 */
public class g extends android.app.Dialog {
    static final float[] a;
    static final float[] b;
    static final android.widget.FrameLayout$LayoutParams c;
    private java.lang.String d;
    private com.a.a.e e;
    private com.sec.chaton.b.b f;
    private android.webkit.WebView g;
    private android.widget.LinearLayout h;
    private android.widget.TextView i;

    static {
        v2 = 2;
        v1 = -1;
        v0 = new float[][size=v2];
        com.a.a.g.a = v0; // :float[]
        v0 = new float[][size=v2];
        com.a.a.g.b = v0; // :float[]
        v0 = new android.widget.FrameLayout$LayoutParams;
        _result = v0.<init>(v1, v1); // android.widget.FrameLayout$LayoutParams.<init> -> void
        com.a.a.g.c = v0; // :android.widget.FrameLayout$LayoutParams
        return;
    }

    public g(android.content.Context p0, java.lang.String p1, com.a.a.e p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (java.lang.String), v4 = p2 (com.a.a.e)
        v0 = com.sec.chaton.R.style.MainCustomTheme_Dialog; // 0x7f0e0023
        _result = v1.<init>(v2, v0); // android.app.Dialog.<init> -> void
        v1.d = v3; // com.a.a.g.d:java.lang.String
        v1.e = v4; // com.a.a.g.e:com.a.a.e
        return;
    }

    static com.a.a.e a(com.a.a.g p0) {
        // Registers (2 total): v1 = p0 (com.a.a.g)
        v0 = v1.e; // com.a.a.g.e:com.a.a.e
        return v0;
    }

    private void a() {
        // Registers (7 total): v6 = this
        v5 = 6;
        v4 = 0;
        v3 = 4;
        v0 = 1;
        _result = v6.requestWindowFeature(v0); // com.a.a.g.requestWindowFeature -> boolean
        _result = v6.getContext(); // com.a.a.g.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        v1 = com.sec.chaton.R.drawable.facebook_icon; // 0x7f02043e
        _result = v0.getDrawable(v1); // android.content.res.Resources.getDrawable -> android.graphics.drawable.Drawable
        v0 = _result;
        v1 = new android.widget.TextView;
        _result = v6.getContext(); // com.a.a.g.getContext -> android.content.Context
        v2 = _result;
        _result = v1.<init>(v2); // android.widget.TextView.<init> -> void
        v6.i = v1; // com.a.a.g.i:android.widget.TextView
        v1 = v6.i; // com.a.a.g.i:android.widget.TextView
        v2 = com.sec.chaton.R.string.tellfriends_via_facebook; // 0x7f0c035b
        _result = v1.setText(v2); // android.widget.TextView.setText -> void
        v1 = v6.i; // com.a.a.g.i:android.widget.TextView
        v2 = -1;
        _result = v1.setTextColor(v2); // android.widget.TextView.setTextColor -> void
        v1 = v6.i; // com.a.a.g.i:android.widget.TextView
        v2 = android.graphics.Typeface.DEFAULT_BOLD; // :android.graphics.Typeface
        _result = v1.setTypeface(v2); // android.widget.TextView.setTypeface -> void
        v1 = v6.i; // com.a.a.g.i:android.widget.TextView
        v2 = -9599820; // 0xff6d84b4
        _result = v1.setBackgroundColor(v2); // android.widget.TextView.setBackgroundColor -> void
        v1 = v6.i; // com.a.a.g.i:android.widget.TextView
        _result = v1.setPadding(v5, v3, v3, v3); // android.widget.TextView.setPadding -> void
        v1 = v6.i; // com.a.a.g.i:android.widget.TextView
        _result = v1.setCompoundDrawablePadding(v5); // android.widget.TextView.setCompoundDrawablePadding -> void
        v1 = v6.i; // com.a.a.g.i:android.widget.TextView
        _result = v1.setCompoundDrawablesWithIntrinsicBounds(v0, v4, v4, v4); // android.widget.TextView.setCompoundDrawablesWithIntrinsicBounds -> void
        v0 = v6.h; // com.a.a.g.h:android.widget.LinearLayout
        v1 = v6.i; // com.a.a.g.i:android.widget.TextView
        _result = v0.addView(v1); // android.widget.LinearLayout.addView -> void
        return;
    }

    static com.sec.chaton.b.b b(com.a.a.g p0) {
        // Registers (2 total): v1 = p0 (com.a.a.g)
        v0 = v1.f; // com.a.a.g.f:com.sec.chaton.b.b
        return v0;
    }

    private void b() {
        // Registers (5 total): v4 = this
        v3 = 1;
        v2 = 0;
        v0 = new android.webkit.WebView;
        _result = v4.getContext(); // com.a.a.g.getContext -> android.content.Context
        v1 = _result;
        _result = v0.<init>(v1); // android.webkit.WebView.<init> -> void
        v4.g = v0; // com.a.a.g.g:android.webkit.WebView
        v0 = v4.g; // com.a.a.g.g:android.webkit.WebView
        _result = v0.getSettings(); // android.webkit.WebView.getSettings -> android.webkit.WebSettings
        v0 = _result;
        _result = v0.setSavePassword(v2); // android.webkit.WebSettings.setSavePassword -> void
        v0 = v4.g; // com.a.a.g.g:android.webkit.WebView
        _result = v0.setVerticalScrollbarOverlay(v3); // android.webkit.WebView.setVerticalScrollbarOverlay -> void
        v0 = v4.g; // com.a.a.g.g:android.webkit.WebView
        _result = v0.setHorizontalScrollBarEnabled(v2); // android.webkit.WebView.setHorizontalScrollBarEnabled -> void
        v0 = v4.g; // com.a.a.g.g:android.webkit.WebView
        v1 = new com.a.a.k;
        v2 = 0;
        _result = v1.<init>(v4, v2); // com.a.a.k.<init> -> void
        _result = v0.setWebViewClient(v1); // android.webkit.WebView.setWebViewClient -> void
        v0 = v4.g; // com.a.a.g.g:android.webkit.WebView
        _result = v0.getSettings(); // android.webkit.WebView.getSettings -> android.webkit.WebSettings
        v0 = _result;
        _result = v0.setJavaScriptEnabled(v3); // android.webkit.WebSettings.setJavaScriptEnabled -> void
        v0 = v4.g; // com.a.a.g.g:android.webkit.WebView
        v1 = v4.d; // com.a.a.g.d:java.lang.String
        _result = v0.loadUrl(v1); // android.webkit.WebView.loadUrl -> void
        v0 = v4.g; // com.a.a.g.g:android.webkit.WebView
        v1 = com.a.a.g.c; // :android.widget.FrameLayout$LayoutParams
        _result = v0.setLayoutParams(v1); // android.webkit.WebView.setLayoutParams -> void
        v0 = v4.g; // com.a.a.g.g:android.webkit.WebView
        _result = v0.getSettings(); // android.webkit.WebView.getSettings -> android.webkit.WebSettings
        v0 = _result;
        _result = v0.getUserAgentString(); // android.webkit.WebSettings.getUserAgentString -> java.lang.String
        v0 = v4.h; // com.a.a.g.h:android.widget.LinearLayout
        v1 = v4.g; // com.a.a.g.g:android.webkit.WebView
        _result = v0.addView(v1); // android.widget.LinearLayout.addView -> void
        return;
    }

    static android.webkit.WebView c(com.a.a.g p0) {
        // Registers (2 total): v1 = p0 (com.a.a.g)
        v0 = v1.g; // com.a.a.g.g:android.webkit.WebView
        return v0;
    }

    static android.widget.TextView d(com.a.a.g p0) {
        // Registers (2 total): v1 = p0 (com.a.a.g)
        v0 = v1.i; // com.a.a.g.i:android.widget.TextView
        return v0;
    }

    public void dismiss() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.a.a.g.g:android.webkit.WebView
        if (v0 == 0) /* goto L_000e */;
        v0 = v1.g; // com.a.a.g.g:android.webkit.WebView
        _result = v0.stopLoading(); // android.webkit.WebView.stopLoading -> void
        v0 = v1.g; // com.a.a.g.g:android.webkit.WebView
        _result = v0.destroy(); // android.webkit.WebView.destroy -> void
        v0 = v1.f; // com.a.a.g.f:com.sec.chaton.b.b
        _result = v0.isShowing(); // com.sec.chaton.b.b.isShowing -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001b */;
        v0 = v1.f; // com.a.a.g.f:com.sec.chaton.b.b
        _result = v0.dismiss(); // com.sec.chaton.b.b.dismiss -> void
        _result = v1.dismiss(); // android.app.Dialog.dismiss -> void
        return;
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (11 total): v9 = this, v10 = p0 (android.os.Bundle)
        v6 = 0;
        v8 = 0x3f000000;
        v7 = 1;
        _result = v9.onCreate(v10); // android.app.Dialog.onCreate -> void
        v0 = new com.a.a.h;
        _result = v0.<init>(v9); // com.a.a.h.<init> -> void
        _result = v9.setOnCancelListener(v0); // com.a.a.g.setOnCancelListener -> void
        v0 = new com.sec.chaton.widget.e;
        _result = v9.getContext(); // com.a.a.g.getContext -> android.content.Context
        v1 = _result;
        _result = v0.<init>(v1); // com.sec.chaton.widget.e.<init> -> void
        v9.f = v0; // com.a.a.g.f:com.sec.chaton.b.b
        v0 = v9.f; // com.a.a.g.f:com.sec.chaton.b.b
        _result = v0.requestWindowFeature(v7); // com.sec.chaton.b.b.requestWindowFeature -> boolean
        v0 = v9.f; // com.a.a.g.f:com.sec.chaton.b.b
        _result = v9.getContext(); // com.a.a.g.getContext -> android.content.Context
        v1 = _result;
        v2 = com.sec.chaton.R.string.dialog_connecting_server; // 0x7f0c0025
        _result = v1.getString(v2); // android.content.Context.getString -> java.lang.String
        v1 = _result;
        _result = v0.setMessage(v1); // com.sec.chaton.b.b.setMessage -> void
        v0 = v9.f; // com.a.a.g.f:com.sec.chaton.b.b
        _result = v0.setCanceledOnTouchOutside(v6); // com.sec.chaton.b.b.setCanceledOnTouchOutside -> void
        v0 = v9.f; // com.a.a.g.f:com.sec.chaton.b.b
        v1 = new com.a.a.i;
        _result = v1.<init>(v9); // com.a.a.i.<init> -> void
        _result = v0.setOnCancelListener(v1); // com.sec.chaton.b.b.setOnCancelListener -> void
        v0 = new com.a.a.j;
        _result = v9.getContext(); // com.a.a.g.getContext -> android.content.Context
        v1 = _result;
        _result = v0.<init>(v1, v9); // com.a.a.j.<init> -> void
        v9.h = v0; // com.a.a.g.h:android.widget.LinearLayout
        v0 = v9.h; // com.a.a.g.h:android.widget.LinearLayout
        _result = v0.setOrientation(v7); // android.widget.LinearLayout.setOrientation -> void
        _result = v9.a(); // com.a.a.g.a -> void
        _result = v9.b(); // com.a.a.g.b -> void
        _result = v9.getWindow(); // com.a.a.g.getWindow -> android.view.Window
        v0 = _result;
        _result = v0.getWindowManager(); // android.view.Window.getWindowManager -> android.view.WindowManager
        v0 = _result;
        _result = android.view.WindowManager.getDefaultDisplay(v0); // -> android.view.Display
        v1 = _result;
        _result = v9.getContext(); // com.a.a.g.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v0 = _result;
        v2 = v0.density; // android.util.DisplayMetrics.density:float
        _result = v9.getContext(); // com.a.a.g.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getConfiguration(); // android.content.res.Resources.getConfiguration -> android.content.res.Configuration
        v0 = _result;
        v0 = v0.orientation; // android.content.res.Configuration.orientation:int
        v3 = 2;
        if (v0 != v3) /* goto L_00a1 */;
        v0 = com.a.a.g.a; // :float[]
        v3 = v9.h; // com.a.a.g.h:android.widget.LinearLayout
        v4 = new android.widget.LinearLayout$LayoutParams;
        _result = v1.getWidth(); // android.view.Display.getWidth -> int
        v5 = _result;
        v6 = v0[v6];
        v6 = binOp2addr_0xc8(v6, v2);
        v6 = binOp2addr_0xc6(v6, v8);
        v6 = unaryOp_0x87(v6);
        v5 = binOp2addr_0xb1(v5, v6);
        _result = v1.getHeight(); // android.view.Display.getHeight -> int
        v1 = _result;
        v0 = v0[v7];
        v0 = binOp2addr_0xc8(v0, v2);
        v0 = binOp2addr_0xc6(v0, v8);
        v0 = unaryOp_0x87(v0);
        v0 = binOp_0x91(v1, v0);
        _result = v4.<init>(v5, v0); // android.widget.LinearLayout$LayoutParams.<init> -> void
        _result = v9.addContentView(v3, v4); // com.a.a.g.addContentView -> void
        return;
        v0 = com.a.a.g.b; // :float[]
        // goto L_0081
    }

}