package com.a.a;

/**
 * Original SourceFile: FacebookError.java
 * Descriptor: Lcom/a/a/f;
 */
public class f extends java.lang.Throwable {
    private int a;
    private java.lang.String b;

    public f(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        _result = v1.<init>(v2); // java.lang.Throwable.<init> -> void
        v0 = 0;
        v1.a = v0; // com.a.a.f.a:int
        return;
    }

    public f(java.lang.String p0, java.lang.String p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.String), v4 = p2 (int)
        _result = v1.<init>(v2); // java.lang.Throwable.<init> -> void
        v0 = 0;
        v1.a = v0; // com.a.a.f.a:int
        v1.b = v3; // com.a.a.f.b:java.lang.String
        v1.a = v4; // com.a.a.f.a:int
        return;
    }

}