package com.a.a;

/**
 * Original SourceFile: FbDialog.java
 * Descriptor: Lcom/a/a/k;
 */
class k extends android.webkit.WebViewClient {
    final com.a.a.g a;

    private k(com.a.a.g p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.a.a.g)
        v0.a = v1; // com.a.a.k.a:com.a.a.g
        _result = v0.<init>(); // android.webkit.WebViewClient.<init> -> void
        return;
    }

    k(com.a.a.g p0, com.a.a.h p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.a.a.g), v2 = p1 (com.a.a.h)
        _result = v0.<init>(v1); // com.a.a.k.<init> -> void
        return;
    }

    public void onPageFinished(android.webkit.WebView p0, java.lang.String p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.webkit.WebView), v5 = p1 (java.lang.String)
        _result = v3.onPageFinished(v4, v5); // android.webkit.WebViewClient.onPageFinished -> void
        v0 = v3.a; // com.a.a.k.a:com.a.a.g
        _result = v0.c(); // com.a.a.g.c -> android.webkit.WebView
        v0 = _result;
        _result = v0.getTitle(); // android.webkit.WebView.getTitle -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_001e */;
        _result = v0.length(); // java.lang.String.length -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_001e */;
        v1 = v3.a; // com.a.a.k.a:com.a.a.g
        _result = v1.d(); // com.a.a.g.d -> android.widget.TextView
        v1 = _result;
        _result = v1.setText(v0); // android.widget.TextView.setText -> void
        v0 = "onPageFinished() 	- mSpinner.dismiss()";
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        v0 = v3.a; // com.a.a.k.a:com.a.a.g
        _result = v0.b(); // com.a.a.g.b -> com.sec.chaton.b.b
        v0 = _result;
        _result = v0.dismiss(); // com.sec.chaton.b.b.dismiss -> void
        return;
        v0 = _exception;
        v1 = "onPageFinished() 	- Spinner warning";
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v2.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v2 = _result;
        _result = v1.d(v2); // com.sec.chaton.util.p.d -> void
        _result = v0.printStackTrace(); // java.lang.Exception.printStackTrace -> void
        // goto L_0034
    }

    public void onPageStarted(android.webkit.WebView p0, java.lang.String p1, android.graphics.Bitmap p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.webkit.WebView), v5 = p1 (java.lang.String), v6 = p2 (android.graphics.Bitmap)
        _result = v3.onPageStarted(v4, v5, v6); // android.webkit.WebViewClient.onPageStarted -> void
        v0 = "onPageStarted() 	- mSpinner.show()";
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        v0 = v3.a; // com.a.a.k.a:com.a.a.g
        _result = v0.b(); // com.a.a.g.b -> com.sec.chaton.b.b
        v0 = _result;
        _result = v0.show(); // com.sec.chaton.b.b.show -> void
        return;
        v0 = _exception;
        v1 = "onPageStarted() 	- Spinner warning.";
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v2.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v2 = _result;
        _result = v1.d(v2); // com.sec.chaton.util.p.d -> void
        _result = v0.printStackTrace(); // java.lang.Exception.printStackTrace -> void
        // goto L_0019
    }

    public void onReceivedError(android.webkit.WebView p0, int p1, java.lang.String p2, java.lang.String p3) {
        // Registers (7 total): v2 = this, v3 = p0 (android.webkit.WebView), v4 = p1 (int), v5 = p2 (java.lang.String), v6 = p3 (java.lang.String)
        _result = v2.onReceivedError(v3, v4, v5, v6); // android.webkit.WebViewClient.onReceivedError -> void
        v0 = v2.a; // com.a.a.k.a:com.a.a.g
        _result = v0.a(); // com.a.a.g.a -> com.a.a.e
        v0 = _result;
        v1 = new com.a.a.a;
        _result = v1.<init>(v5, v4, v6); // com.a.a.a.<init> -> void
        _result = com.a.a.e.a(v0, v1); // -> void
        v0 = v2.a; // com.a.a.k.a:com.a.a.g
        _result = v0.dismiss(); // com.a.a.g.dismiss -> void
        return;
    }

    public boolean shouldOverrideUrlLoading(android.webkit.WebView p0, java.lang.String p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.webkit.WebView), v7 = p1 (java.lang.String)
        v0 = 1;
        v1 = "fbconnect://success";
        _result = v7.startsWith(v1); // java.lang.String.startsWith -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0055 */;
        _result = v7.b(); // com.a.a.m.b -> android.os.Bundle
        v2 = _result;
        v1 = "error";
        _result = v2.getString(v1); // android.os.Bundle.getString -> java.lang.String
        v1 = _result;
        if (v1 != 0) /* goto L_001b */;
        v1 = "error_type";
        _result = v2.getString(v1); // android.os.Bundle.getString -> java.lang.String
        v1 = _result;
        if (v1 != 0) /* goto L_002c */;
        v1 = v5.a; // com.a.a.k.a:com.a.a.g
        _result = v1.a(); // com.a.a.g.a -> com.a.a.e
        v1 = _result;
        _result = com.a.a.e.a(v1, v2); // -> void
        v1 = v5.a; // com.a.a.k.a:com.a.a.g
        _result = v1.dismiss(); // com.a.a.g.dismiss -> void
        return v0;
        v2 = "access_denied";
        _result = v2.equals(v1); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_003c */;
        v2 = "OAuthAccessDeniedException";
        _result = v2.equals(v1); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0046 */;
        v1 = v5.a; // com.a.a.k.a:com.a.a.g
        _result = v1.a(); // com.a.a.g.a -> com.a.a.e
        v1 = _result;
        _result = com.a.a.e.a(v1); // -> void
        // goto L_0026
        v2 = v5.a; // com.a.a.k.a:com.a.a.g
        _result = v2.a(); // com.a.a.g.a -> com.a.a.e
        v2 = _result;
        v3 = new com.a.a.f;
        _result = v3.<init>(v1); // com.a.a.f.<init> -> void
        _result = com.a.a.e.a(v2, v3); // -> void
        // goto L_0026
        v1 = "fbconnect://cancel";
        _result = v7.startsWith(v1); // java.lang.String.startsWith -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_006c */;
        v1 = v5.a; // com.a.a.k.a:com.a.a.g
        _result = v1.a(); // com.a.a.g.a -> com.a.a.e
        v1 = _result;
        _result = com.a.a.e.a(v1); // -> void
        v1 = v5.a; // com.a.a.k.a:com.a.a.g
        _result = v1.dismiss(); // com.a.a.g.dismiss -> void
        // goto L_002b
        v1 = "touch";
        _result = v7.contains(v1); // java.lang.String.contains -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0076 */;
        v0 = 0;
        // goto L_002b
        v1 = v5.a; // com.a.a.k.a:com.a.a.g
        _result = v1.getContext(); // com.a.a.g.getContext -> android.content.Context
        v1 = _result;
        v2 = new android.content.Intent;
        v3 = "android.intent.action.VIEW";
        _result = v7.parse(); // android.net.Uri.parse -> android.net.Uri
        v4 = _result;
        _result = v2.<init>(v3, v4); // android.content.Intent.<init> -> void
        _result = v1.startActivity(v2); // android.content.Context.startActivity -> void
        // goto L_002b
    }

}