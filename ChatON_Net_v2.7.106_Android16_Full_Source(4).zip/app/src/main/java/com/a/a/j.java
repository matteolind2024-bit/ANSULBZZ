package com.a.a;

/**
 * Original SourceFile: FbDialog.java
 * Descriptor: Lcom/a/a/j;
 */
class j extends android.widget.LinearLayout {
    private android.app.Dialog a;

    public j(android.content.Context p0, android.app.Dialog p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.content.Context), v2 = p1 (android.app.Dialog)
        _result = v0.<init>(v1); // android.widget.LinearLayout.<init> -> void
        v0.a = v2; // com.a.a.j.a:android.app.Dialog
        return;
    }

    protected void onConfigurationChanged(android.content.res.Configuration p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.content.res.Configuration)
        v6 = 0x3f000000;
        _result = v7.onConfigurationChanged(v8); // android.widget.LinearLayout.onConfigurationChanged -> void
        v0 = v7.a; // com.a.a.j.a:android.app.Dialog
        _result = v0.getWindow(); // android.app.Dialog.getWindow -> android.view.Window
        v0 = _result;
        _result = v0.getWindowManager(); // android.view.Window.getWindowManager -> android.view.WindowManager
        v0 = _result;
        _result = android.view.WindowManager.getDefaultDisplay(v0); // -> android.view.Display
        v1 = _result;
        _result = v7.getContext(); // com.a.a.j.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v0 = _result;
        v2 = v0.density; // android.util.DisplayMetrics.density:float
        v0 = v8.orientation; // android.content.res.Configuration.orientation:int
        v3 = 2;
        if (v0 != v3) /* goto L_0048 */;
        v0 = com.a.a.g.a; // :float[]
        v3 = new android.widget.FrameLayout$LayoutParams;
        _result = v1.getWidth(); // android.view.Display.getWidth -> int
        v4 = _result;
        v5 = 0;
        v5 = v0[v5];
        v5 = binOp2addr_0xc8(v5, v2);
        v5 = binOp2addr_0xc6(v5, v6);
        v5 = unaryOp_0x87(v5);
        v4 = binOp2addr_0xb1(v4, v5);
        _result = v1.getHeight(); // android.view.Display.getHeight -> int
        v1 = _result;
        v5 = 1;
        v0 = v0[v5];
        v0 = binOp2addr_0xc8(v0, v2);
        v0 = binOp2addr_0xc6(v0, v6);
        v0 = unaryOp_0x87(v0);
        v0 = binOp_0x91(v1, v0);
        _result = v3.<init>(v4, v0); // android.widget.FrameLayout$LayoutParams.<init> -> void
        _result = v7.setLayoutParams(v3); // com.a.a.j.setLayoutParams -> void
        return;
        v0 = com.a.a.g.b; // :float[]
        // goto L_0028
    }

}