package com.a.a;

/**
 * Original SourceFile: SessionStore.java
 * Descriptor: Lcom/a/a/l;
 */
public class l {
    public static void a(android.content.Context p0) {
        // Registers (3 total): v2 = p0 (android.content.Context)
        v0 = "facebook-session";
        v1 = 0;
        _result = v2.getSharedPreferences(v0, v1); // android.content.Context.getSharedPreferences -> android.content.SharedPreferences
        v0 = _result;
        _result = android.content.SharedPreferences.edit(v0); // -> android.content.SharedPreferences$Editor
        v0 = _result;
        _result = android.content.SharedPreferences$Editor.clear(v0); // -> android.content.SharedPreferences$Editor
        _result = android.content.SharedPreferences$Editor.commit(v0); // -> boolean
        return;
    }

    public static boolean a(android.content.Context p0, java.lang.String p1) {
        // Registers (4 total): v2 = p0 (android.content.Context), v3 = p1 (java.lang.String)
        v0 = "facebook-session";
        v1 = 0;
        _result = v2.getSharedPreferences(v0, v1); // android.content.Context.getSharedPreferences -> android.content.SharedPreferences
        v0 = _result;
        _result = android.content.SharedPreferences.edit(v0); // -> android.content.SharedPreferences$Editor
        v0 = _result;
        v1 = "user_name";
        _result = android.content.SharedPreferences$Editor.putString(v0, v1, v3); // -> android.content.SharedPreferences$Editor
        _result = android.content.SharedPreferences$Editor.commit(v0); // -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean a(com.a.a.b p0, android.content.Context p1) {
        // Registers (6 total): v4 = p0 (com.a.a.b), v5 = p1 (android.content.Context)
        v0 = "facebook-session";
        v1 = 0;
        _result = v5.getSharedPreferences(v0, v1); // android.content.Context.getSharedPreferences -> android.content.SharedPreferences
        v0 = _result;
        _result = android.content.SharedPreferences.edit(v0); // -> android.content.SharedPreferences$Editor
        v0 = _result;
        v1 = "access_token";
        _result = v4.b(); // com.a.a.b.b -> java.lang.String
        v2 = _result;
        _result = android.content.SharedPreferences$Editor.putString(v0, v1, v2); // -> android.content.SharedPreferences$Editor
        v1 = "expires_in";
        _result = v4.c(); // com.a.a.b.c -> long
        v2 = _result;
        _result = android.content.SharedPreferences$Editor.putLong(v0, v1, v2, v3); // -> android.content.SharedPreferences$Editor
        _result = android.content.SharedPreferences$Editor.commit(v0); // -> boolean
        v0 = _result;
        return v0;
    }

    public static java.lang.String b(android.content.Context p0) {
        // Registers (4 total): v3 = p0 (android.content.Context)
        v0 = "facebook-session";
        v1 = 0;
        _result = v3.getSharedPreferences(v0, v1); // android.content.Context.getSharedPreferences -> android.content.SharedPreferences
        v0 = _result;
        v1 = "user_name";
        v2 = 0;
        _result = android.content.SharedPreferences.getString(v0, v1, v2); // -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static boolean b(android.content.Context p0, java.lang.String p1) {
        // Registers (4 total): v2 = p0 (android.content.Context), v3 = p1 (java.lang.String)
        v0 = "facebook-session";
        v1 = 0;
        _result = v2.getSharedPreferences(v0, v1); // android.content.Context.getSharedPreferences -> android.content.SharedPreferences
        v0 = _result;
        _result = android.content.SharedPreferences.edit(v0); // -> android.content.SharedPreferences$Editor
        v0 = _result;
        v1 = "user_email";
        _result = android.content.SharedPreferences$Editor.putString(v0, v1, v3); // -> android.content.SharedPreferences$Editor
        _result = android.content.SharedPreferences$Editor.commit(v0); // -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean b(com.a.a.b p0, android.content.Context p1) {
        // Registers (6 total): v4 = p0 (com.a.a.b), v5 = p1 (android.content.Context)
        v0 = "facebook-session";
        v1 = 0;
        _result = v5.getSharedPreferences(v0, v1); // android.content.Context.getSharedPreferences -> android.content.SharedPreferences
        v0 = _result;
        v1 = "access_token";
        v2 = 0;
        _result = android.content.SharedPreferences.getString(v0, v1, v2); // -> java.lang.String
        v1 = _result;
        _result = v4.a(v1); // com.a.a.b.a -> void
        v1 = "expires_in";
        v2 = 0L;
        _result = android.content.SharedPreferences.getLong(v0, v1, v2, v3); // -> long
        v0 = _result;
        _result = v4.a(v0, v1); // com.a.a.b.a -> void
        _result = v4.a(); // com.a.a.b.a -> boolean
        v0 = _result;
        return v0;
    }

    public static java.lang.String c(android.content.Context p0) {
        // Registers (4 total): v3 = p0 (android.content.Context)
        v0 = "facebook-session";
        v1 = 0;
        _result = v3.getSharedPreferences(v0, v1); // android.content.Context.getSharedPreferences -> android.content.SharedPreferences
        v0 = _result;
        v1 = "user_email";
        v2 = 0;
        _result = android.content.SharedPreferences.getString(v0, v1, v2); // -> java.lang.String
        v0 = _result;
        return v0;
    }

}