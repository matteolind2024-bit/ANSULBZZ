package com.a.a;

/**
 * Original SourceFile: Facebook.java
 * Descriptor: Lcom/a/a/b;
 */
public class b {
    protected static java.lang.String a;
    protected static java.lang.String b;
    protected static java.lang.String c;
    private java.lang.String d;
    private long e;
    private java.lang.String f;
    private android.app.Activity g;
    private java.lang.String[] h;
    private int i;
    private com.a.a.e j;
    private android.support.v4.app.Fragment k;

    static {
        v0 = "https://m.facebook.com/dialog/";
        com.a.a.b.a = v0; // :java.lang.String
        v0 = "https://graph.facebook.com/";
        com.a.a.b.b = v0; // :java.lang.String
        v0 = "https://api.facebook.com/restserver.php";
        com.a.a.b.c = v0; // :java.lang.String
        return;
    }

    public b(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v2.d = v0; // com.a.a.b.d:java.lang.String
        v0 = 0L;
        v2.e = v0; // com.a.a.b.e:long
        if (v3 != 0) /* goto L_0014 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "You must specify your application ID when instantiating a Facebook object. See README for details.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v2.f = v3; // com.a.a.b.f:java.lang.String
        return;
    }

    static com.a.a.e a(com.a.a.b p0) {
        // Registers (2 total): v1 = p0 (com.a.a.b)
        v0 = v1.j; // com.a.a.b.j:com.a.a.e
        return v0;
    }

    private void a(android.app.Activity p0, java.lang.String[] p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.app.Activity), v5 = p1 (java.lang.String[])
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        v1 = v5.length;
        if (v1 <= 0) /* goto L_0013 */;
        v1 = "scope";
        v2 = ",";
        _result = v2.join(v5); // android.text.TextUtils.join -> java.lang.String
        v2 = _result;
        _result = v0.putString(v1, v2); // android.os.Bundle.putString -> void
        _result = v4.createInstance(); // android.webkit.CookieSyncManager.createInstance -> android.webkit.CookieSyncManager
        v1 = "oauth";
        v2 = new com.a.a.d;
        _result = v2.<init>(v3); // com.a.a.d.<init> -> void
        _result = v3.a(v4, v1, v0, v2); // com.a.a.b.a -> void
        return;
    }

    static void a(com.a.a.b p0, android.app.Activity p1, java.lang.String[] p2) {
        // Registers (3 total): v0 = p0 (com.a.a.b), v1 = p1 (android.app.Activity), v2 = p2 (java.lang.String[])
        _result = v0.a(v1, v2); // com.a.a.b.a -> void
        return;
    }

    private boolean a(android.app.Activity p0, android.content.Intent p1) {
        // Registers (9 total): v6 = this, v7 = p0 (android.app.Activity), v8 = p1 (android.content.Intent)
        v0 = 0;
        _result = v7.getPackageManager(); // android.app.Activity.getPackageManager -> android.content.pm.PackageManager
        v1 = _result;
        _result = v1.resolveActivity(v8, v0); // android.content.pm.PackageManager.resolveActivity -> android.content.pm.ResolveInfo
        v1 = _result;
        if (v1 != 0) /* goto L_000c */;
        return v0;
        v1 = v1.activityInfo; // android.content.pm.ResolveInfo.activityInfo:android.content.pm.ActivityInfo
        v1 = v1.packageName; // android.content.pm.ActivityInfo.packageName:java.lang.String
        _result = v7.getPackageManager(); // android.app.Activity.getPackageManager -> android.content.pm.PackageManager
        v2 = _result;
        v3 = 64;
        _result = v2.getPackageInfo(v1, v3); // android.content.pm.PackageManager.getPackageInfo -> android.content.pm.PackageInfo
        v1 = _result;
        v2 = v1.signatures; // android.content.pm.PackageInfo.signatures:android.content.pm.Signature[]
        v3 = v2.length;
        v1 = v0;
        if (v1 >= v3) /* goto L_000b */;
        v4 = v2[v1];
        _result = v4.toCharsString(); // android.content.pm.Signature.toCharsString -> java.lang.String
        v4 = _result;
        v5 = "30820268308201d102044a9c4610300d06092a864886f70d0101040500307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e3020170d3039303833313231353231365a180f32303530303932353231353231365a307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e30819f300d06092a864886f70d010101050003818d0030818902818100c207d51df8eb8c97d93ba0c8c1002c928fab00dc1b42fca5e66e99cc3023ed2d214d822bc59e8e35ddcf5f44c7ae8ade50d7e0c434f500e6c131f4a2834f987fc46406115de2018ebbb0d5a3c261bd97581ccfef76afc7135a6d59e8855ecd7eacc8f8737e794c60a761c536b72b11fac8e603f5da1a2d54aa103b8a13c0dbc10203010001300d06092a864886f70d0101040500038181005ee9be8bcbb250648d3b741290a82a1c9dc2e76a0af2f2228f1d9f9c4007529c446a70175c5a900d5141812866db46be6559e2141616483998211f4a673149fb2232a10d247663b26a9031e15f84bc1c74d141ff98a02d76f85b2c8ab2571b6469b232d8e768a7f7ca04f7abe4a775615916c07940656b58717457b42bd928a2";
        _result = v4.equals(v5); // java.lang.String.equals -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_0030 */;
        v0 = 1;
        // goto L_000b
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_001e
        v1 = _exception;
        // goto L_000b
    }

    private boolean a(android.app.Activity p0, java.lang.String p1, java.lang.String[] p2, int p3) {
        // Registers (10 total): v5 = this, v6 = p0 (android.app.Activity), v7 = p1 (java.lang.String), v8 = p2 (java.lang.String[]), v9 = p3 (int)
        v1 = 0;
        v0 = 1;
        v2 = new android.content.Intent;
        _result = v2.<init>(); // android.content.Intent.<init> -> void
        v3 = "com.facebook.katana";
        v4 = "com.facebook.katana.ProxyAuth";
        _result = v2.setClassName(v3, v4); // android.content.Intent.setClassName -> android.content.Intent
        v3 = "client_id";
        _result = v2.putExtra(v3, v7); // android.content.Intent.putExtra -> android.content.Intent
        v3 = v8.length;
        if (v3 <= 0) /* goto L_0021 */;
        v3 = "scope";
        v4 = ",";
        _result = v4.join(v8); // android.text.TextUtils.join -> java.lang.String
        v4 = _result;
        _result = v2.putExtra(v3, v4); // android.content.Intent.putExtra -> android.content.Intent
        _result = v5.a(v6, v2); // com.a.a.b.a -> boolean
        v3 = _result;
        if (v3 != 0) /* goto L_0028 */;
        return v1;
        v5.g = v6; // com.a.a.b.g:android.app.Activity
        v5.h = v8; // com.a.a.b.h:java.lang.String[]
        v5.i = v9; // com.a.a.b.i:int
        v3 = v5.k; // com.a.a.b.k:android.support.v4.app.Fragment
        if (v3 == 0) /* goto L_0039 */;
        v3 = v5.k; // com.a.a.b.k:android.support.v4.app.Fragment
        _result = v3.startActivityForResult(v2, v9); // android.support.v4.app.Fragment.startActivityForResult -> void
        v1 = v0;
        // goto L_0027
        _result = v6.startActivityForResult(v2, v9); // android.app.Activity.startActivityForResult -> void
        // goto L_0037
        v0 = _exception;
        v0 = v1;
        // goto L_0037
    }

    public java.lang.String a(android.content.Context p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Context)
        _result = v4.a(); // com.a.a.m.a -> void
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        v1 = "method";
        v2 = "auth.expireSession";
        _result = v0.putString(v1, v2); // android.os.Bundle.putString -> void
        _result = v3.a(v0); // com.a.a.b.a -> java.lang.String
        v0 = _result;
        v1 = 0;
        _result = v3.a(v1); // com.a.a.b.a -> void
        v1 = 0L;
        _result = v3.a(v1, v2); // com.a.a.b.a -> void
        return v0;
    }

    public java.lang.String a(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        v0 = "method";
        _result = v3.containsKey(v0); // android.os.Bundle.containsKey -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0010 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "API method must be specified. (parameters must contain key \"method\" and value). See http://developers.facebook.com/docs/reference/rest/";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = 0;
        v1 = "GET";
        _result = v2.a(v0, v3, v1); // com.a.a.b.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String a(java.lang.String p0, android.os.Bundle p1, java.lang.String p2) {
        // Registers (6 total): v2 = this, v3 = p0 (java.lang.String), v4 = p1 (android.os.Bundle), v5 = p2 (java.lang.String)
        v0 = "format";
        v1 = "json";
        _result = v4.putString(v0, v1); // android.os.Bundle.putString -> void
        _result = v2.a(); // com.a.a.b.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0016 */;
        v0 = "access_token";
        _result = v2.b(); // com.a.a.b.b -> java.lang.String
        v1 = _result;
        _result = v4.putString(v0, v1); // android.os.Bundle.putString -> void
        if (v3 == 0) /* goto L_0030 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = com.a.a.b.b; // :java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.a(v5, v4); // com.a.a.m.a -> java.lang.String
        v0 = _result;
        return v0;
        v0 = com.a.a.b.c; // :java.lang.String
        // goto L_002b
    }

    public void a(int p0, int p1, android.content.Intent p2) {
        // Registers (9 total): v5 = this, v6 = p0 (int), v7 = p1 (int), v8 = p2 (android.content.Intent)
        v4 = -1;
        v0 = v5.i; // com.a.a.b.i:int
        if (v6 != v0) /* goto L_0035 */;
        if (v7 != v4) /* goto L_00d1 */;
        v0 = "error";
        _result = v8.getStringExtra(v0); // android.content.Intent.getStringExtra -> java.lang.String
        v0 = _result;
        if (v0 != 0) /* goto L_0015 */;
        v0 = "error_type";
        _result = v8.getStringExtra(v0); // android.content.Intent.getStringExtra -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0076 */;
        v1 = "service_disabled";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0027 */;
        v1 = "AndroidAuthKillSwitchException";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0036 */;
        v0 = "Facebook-authorize";
        v1 = "Hosted auth currently disabled. Retrying dialog auth...";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v5.g; // com.a.a.b.g:android.app.Activity
        v1 = v5.h; // com.a.a.b.h:java.lang.String[]
        _result = v5.a(v0, v1); // com.a.a.b.a -> void
        return;
        v1 = "access_denied";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0046 */;
        v1 = "OAuthAccessDeniedException";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0053 */;
        v0 = "Facebook-authorize";
        v1 = "Login canceled by user.";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v5.j; // com.a.a.b.j:com.a.a.e
        _result = com.a.a.e.a(v0); // -> void
        // goto L_0035
        v1 = "Facebook-authorize";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Login failed: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.d(v2); // android.util.Log.d -> int
        v1 = v5.j; // com.a.a.b.j:com.a.a.e
        v2 = new com.a.a.f;
        _result = v2.<init>(v0); // com.a.a.f.<init> -> void
        _result = com.a.a.e.a(v1, v2); // -> void
        // goto L_0035
        v0 = "access_token";
        _result = v8.getStringExtra(v0); // android.content.Intent.getStringExtra -> java.lang.String
        v0 = _result;
        _result = v5.a(v0); // com.a.a.b.a -> void
        v0 = "expires_in";
        _result = v8.getStringExtra(v0); // android.content.Intent.getStringExtra -> java.lang.String
        v0 = _result;
        _result = v5.b(v0); // com.a.a.b.b -> void
        _result = v5.a(); // com.a.a.b.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00c3 */;
        v0 = "Facebook-authorize";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Login Success! access_token=";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v5.b(); // com.a.a.b.b -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " expires=";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v5.c(); // com.a.a.b.c -> long
        v2 = _result;
        _result = v1.append(v2, v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v5.j; // com.a.a.b.j:com.a.a.e
        _result = v8.getExtras(); // android.content.Intent.getExtras -> android.os.Bundle
        v1 = _result;
        _result = com.a.a.e.a(v0, v1); // -> void
        // goto L_0035
        v0 = v5.j; // com.a.a.b.j:com.a.a.e
        v1 = new com.a.a.f;
        v2 = "Failed to receive access token.";
        _result = v1.<init>(v2); // com.a.a.f.<init> -> void
        _result = com.a.a.e.a(v0, v1); // -> void
        // goto L_0035
        if (v7 != 0) /* goto L_0035 */;
        if (v8 == 0) /* goto L_0111 */;
        v0 = "Facebook-authorize";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Login failed: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "error";
        _result = v8.getStringExtra(v2); // android.content.Intent.getStringExtra -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v5.j; // com.a.a.b.j:com.a.a.e
        v1 = new com.a.a.a;
        v2 = "error";
        _result = v8.getStringExtra(v2); // android.content.Intent.getStringExtra -> java.lang.String
        v2 = _result;
        v3 = "error_code";
        _result = v8.getIntExtra(v3, v4); // android.content.Intent.getIntExtra -> int
        v3 = _result;
        v4 = "failing_url";
        _result = v8.getStringExtra(v4); // android.content.Intent.getStringExtra -> java.lang.String
        v4 = _result;
        _result = v1.<init>(v2, v3, v4); // com.a.a.a.<init> -> void
        _result = com.a.a.e.a(v0, v1); // -> void
        // goto L_0035
        v0 = "Facebook-authorize";
        v1 = "Login canceled by user.";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v5.j; // com.a.a.b.j:com.a.a.e
        _result = com.a.a.e.a(v0); // -> void
        // goto L_0035
    }

    public void a(long p0) {
        // Registers (3 total): v0 = this, v1 = p0 (long)
        v0.e = v1; // com.a.a.b.e:long
        return;
    }

    public void a(android.app.Activity p0, java.lang.String[] p1, int p2, com.a.a.e p3) {
        // Registers (6 total): v1 = this, v2 = p0 (android.app.Activity), v3 = p1 (java.lang.String[]), v4 = p2 (int), v5 = p3 (com.a.a.e)
        v0 = 0;
        v1.j = v5; // com.a.a.b.j:com.a.a.e
        if (v4 < 0) /* goto L_000b */;
        v0 = v1.f; // com.a.a.b.f:java.lang.String
        _result = v1.a(v2, v0, v3, v4); // com.a.a.b.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0015 */;
        v0 = new com.a.a.c;
        _result = v0.<init>(v1, v2, v3); // com.a.a.c.<init> -> void
        _result = v2.runOnUiThread(v0); // android.app.Activity.runOnUiThread -> void
        return;
    }

    public void a(android.app.Activity p0, java.lang.String[] p1, com.a.a.e p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.app.Activity), v3 = p1 (java.lang.String[]), v4 = p2 (com.a.a.e)
        v0 = 32665;
        _result = v1.a(v2, v3, v0, v4); // com.a.a.b.a -> void
        return;
    }

    public void a(android.content.Context p0, java.lang.String p1, android.os.Bundle p2, com.a.a.e p3) {
        // Registers (8 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (java.lang.String), v6 = p2 (android.os.Bundle), v7 = p3 (com.a.a.e)
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = com.a.a.b.a; // :java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = "display";
        v2 = "touch";
        _result = v6.putString(v1, v2); // android.os.Bundle.putString -> void
        v1 = "redirect_uri";
        v2 = "fbconnect://success";
        _result = v6.putString(v1, v2); // android.os.Bundle.putString -> void
        v1 = "oauth";
        _result = v1.equals(v5); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0071 */;
        v1 = "type";
        v2 = "user_agent";
        _result = v6.putString(v1, v2); // android.os.Bundle.putString -> void
        v1 = "client_id";
        v2 = v3.f; // com.a.a.b.f:java.lang.String
        _result = v6.putString(v1, v2); // android.os.Bundle.putString -> void
        _result = v3.a(); // com.a.a.b.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0046 */;
        v1 = "access_token";
        _result = v3.b(); // com.a.a.b.b -> java.lang.String
        v2 = _result;
        _result = v6.putString(v1, v2); // android.os.Bundle.putString -> void
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "?";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v6.a(); // com.a.a.m.a -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = "android.permission.INTERNET";
        _result = v4.checkCallingOrSelfPermission(v1); // android.content.Context.checkCallingOrSelfPermission -> int
        v1 = _result;
        if (v1 == 0) /* goto L_0079 */;
        v0 = "Error";
        v1 = "Application requires permission to access the Internet";
        _result = v4.a(v0, v1); // com.a.a.m.a -> void
        return;
        v1 = "app_id";
        v2 = v3.f; // com.a.a.b.f:java.lang.String
        _result = v6.putString(v1, v2); // android.os.Bundle.putString -> void
        // goto L_0037
        v1 = new com.a.a.g;
        _result = v1.<init>(v4, v0, v7); // com.a.a.g.<init> -> void
        _result = v1.show(); // com.a.a.g.show -> void
        // goto L_0070
    }

    public void a(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.d = v1; // com.a.a.b.d:java.lang.String
        return;
    }

    public boolean a() {
        // Registers (5 total): v4 = this
        _result = v4.b(); // com.a.a.b.b -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_001e */;
        _result = v4.c(); // com.a.a.b.c -> long
        v0 = _result;
        v2 = 0L;
        v0 = cmp(v0, v2);
        if (v0 == 0) /* goto L_001c */;
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v0 = _result;
        _result = v4.c(); // com.a.a.b.c -> long
        v2 = _result;
        v0 = cmp(v0, v2);
        if (v0 >= 0) /* goto L_001e */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_001d
    }

    public java.lang.String b() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.a.a.b.d:java.lang.String
        return v0;
    }

    public void b(java.lang.String p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.String)
        if (v5 == 0) /* goto L_0019 */;
        v0 = "0";
        _result = v5.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0019 */;
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v0 = _result;
        _result = v5.parseInt(); // java.lang.Integer.parseInt -> int
        v2 = _result;
        v2 = binOpLit16_0xd2(v2, 1000);
        v2 = unaryOp_0x81(v2);
        v0 = binOp2addr_0xbb(v0, v2);
        _result = v4.a(v0, v1); // com.a.a.b.a -> void
        return;
    }

    public long c() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.a.a.b.e:long
        return v0;
    }

}