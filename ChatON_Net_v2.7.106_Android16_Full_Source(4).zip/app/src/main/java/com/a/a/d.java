package com.a.a;

/**
 * Original SourceFile: Facebook.java
 * Descriptor: Lcom/a/a/d;
 */
class d implements com.a.a.e {
    final com.a.a.b a;

    d(com.a.a.b p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.a.a.b)
        v0.a = v1; // com.a.a.d.a:com.a.a.b
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void a() {
        // Registers (3 total): v2 = this
        v0 = "Facebook-authorize";
        v1 = "Login canceled";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v2.a; // com.a.a.d.a:com.a.a.b
        _result = v0.a(); // com.a.a.b.a -> com.a.a.e
        v0 = _result;
        _result = com.a.a.e.a(v0); // -> void
        return;
    }

    public void a(android.os.Bundle p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.os.Bundle)
        _result = this.getInstance(); // android.webkit.CookieSyncManager.getInstance -> android.webkit.CookieSyncManager
        v0 = _result;
        _result = v0.sync(); // android.webkit.CookieSyncManager.sync -> void
        v0 = v4.a; // com.a.a.d.a:com.a.a.b
        v1 = "access_token";
        _result = v5.getString(v1); // android.os.Bundle.getString -> java.lang.String
        v1 = _result;
        _result = v0.a(v1); // com.a.a.b.a -> void
        v0 = v4.a; // com.a.a.d.a:com.a.a.b
        v1 = "expires_in";
        _result = v5.getString(v1); // android.os.Bundle.getString -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.a.a.b.b -> void
        v0 = v4.a; // com.a.a.d.a:com.a.a.b
        _result = v0.a(); // com.a.a.b.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_005d */;
        v0 = "Facebook-authorize";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Login Success! access_token=";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.a; // com.a.a.d.a:com.a.a.b
        _result = v2.b(); // com.a.a.b.b -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " expires=";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.a; // com.a.a.d.a:com.a.a.b
        _result = v2.c(); // com.a.a.b.c -> long
        v2 = _result;
        _result = v1.append(v2, v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v4.a; // com.a.a.d.a:com.a.a.b
        _result = v0.a(); // com.a.a.b.a -> com.a.a.e
        v0 = _result;
        _result = com.a.a.e.a(v0, v5); // -> void
        return;
        v0 = v4.a; // com.a.a.d.a:com.a.a.b
        _result = v0.a(); // com.a.a.b.a -> com.a.a.e
        v0 = _result;
        v1 = new com.a.a.f;
        v2 = "Failed to receive access token.";
        _result = v1.<init>(v2); // com.a.a.f.<init> -> void
        _result = com.a.a.e.a(v0, v1); // -> void
        // goto L_005c
    }

    public void a(com.a.a.a p0) {
        // Registers (5 total): v3 = this, v4 = p0 (com.a.a.a)
        v0 = "Facebook-authorize";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Login failed: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v3.a; // com.a.a.d.a:com.a.a.b
        _result = v0.a(); // com.a.a.b.a -> com.a.a.e
        v0 = _result;
        _result = com.a.a.e.a(v0, v4); // -> void
        return;
    }

    public void a(com.a.a.f p0) {
        // Registers (5 total): v3 = this, v4 = p0 (com.a.a.f)
        v0 = "Facebook-authorize";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Login failed: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v3.a; // com.a.a.d.a:com.a.a.b
        _result = v0.a(); // com.a.a.b.a -> com.a.a.e
        v0 = _result;
        _result = com.a.a.e.a(v0, v4); // -> void
        return;
    }

}