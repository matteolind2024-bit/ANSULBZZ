package com.a.a;

/**
 * Original SourceFile: Util.java
 * Descriptor: Lcom/a/a/m;
 */
public final class m {
    public static android.os.Bundle a(java.lang.String p0) {
        // Registers (9 total): v8 = p0 (java.lang.String)
        v7 = 1;
        v0 = 0;
        v1 = new android.os.Bundle;
        _result = v1.<init>(); // android.os.Bundle.<init> -> void
        if (v8 == 0) /* goto L_004a */;
        v2 = "&";
        _result = v8.split(v2); // java.lang.String.split -> java.lang.String[]
        v2 = _result;
        v3 = v2.length;
        if (v0 >= v3) /* goto L_004a */;
        v4 = v2[v0];
        v5 = "=";
        _result = v4.split(v5); // java.lang.String.split -> java.lang.String[]
        v4 = _result;
        v5 = v4.length;
        v6 = 2;
        if (v5 != v6) /* goto L_0036 */;
        v5 = 0;
        v5 = v4[v5];
        v6 = "UTF-8";
        _result = v5.decode(v6); // java.net.URLDecoder.decode -> java.lang.String
        v5 = _result;
        v6 = 1;
        v4 = v4[v6];
        v6 = "UTF-8";
        _result = v4.decode(v6); // java.net.URLDecoder.decode -> java.lang.String
        v4 = _result;
        _result = v1.putString(v5, v4); // android.os.Bundle.putString -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0010
        v5 = v4.length;
        if (v5 != v7) /* goto L_0033 */;
        v5 = 0;
        v4 = v4[v5];
        v5 = "UTF-8";
        _result = v4.decode(v5); // java.net.URLDecoder.decode -> java.lang.String
        v4 = _result;
        v5 = "";
        _result = v1.putString(v4, v5); // android.os.Bundle.putString -> void
        // goto L_0033
        v4 = _exception;
        // goto L_0033
        return v1;
    }

    public static java.lang.String a(android.os.Bundle p0) {
        // Registers (7 total): v6 = p0 (android.os.Bundle)
        if (v6 != 0) /* goto L_0005 */;
        v0 = "";
        return v0;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v0 = 1;
        _result = v6.keySet(); // android.os.Bundle.keySet -> java.util.Set
        v1 = _result;
        _result = java.util.Set.iterator(v1); // -> java.util.Iterator
        v3 = _result;
        v1 = v0;
        _result = java.util.Iterator.hasNext(v3); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0050 */;
        _result = java.util.Iterator.next(v3); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        if (v1 == 0) /* goto L_004a */;
        v1 = 0;
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.encode(); // java.net.URLEncoder.encode -> java.lang.String
        v5 = _result;
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = "=";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v6.getString(v0); // android.os.Bundle.getString -> java.lang.String
        v0 = _result;
        _result = v0.encode(); // java.net.URLEncoder.encode -> java.lang.String
        v0 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0014
        v4 = "&";
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0023
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0004
    }

    public static java.lang.String a(android.os.Bundle p0, java.lang.String p1) {
        // Registers (7 total): v5 = p0 (android.os.Bundle), v6 = p1 (java.lang.String)
        if (v5 != 0) /* goto L_0005 */;
        v0 = "";
        return v0;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v5.keySet(); // android.os.Bundle.keySet -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0065 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        _result = v5.getByteArray(v0); // android.os.Bundle.getByteArray -> byte[]
        v3 = _result;
        if (v3 != 0) /* goto L_0012 */;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "Content-Disposition: form-data; name=\"";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = "\"\r\n\r\n";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v5.getString(v0); // android.os.Bundle.getString -> java.lang.String
        v0 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "\r\n--";
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v3 = "\r\n";
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0012
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0004
    }

    private static java.lang.String a(java.io.InputStream p0) {
        // Registers (5 total): v4 = p0 (java.io.InputStream)
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = new java.io.BufferedReader;
        v0 = new java.io.InputStreamReader;
        _result = v0.<init>(v4); // java.io.InputStreamReader.<init> -> void
        v3 = 1000;
        _result = v2.<init>(v0, v3); // java.io.BufferedReader.<init> -> void
        _result = v2.readLine(); // java.io.BufferedReader.readLine -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_001f */;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v2.readLine(); // java.io.BufferedReader.readLine -> java.lang.String
        v0 = _result;
        // goto L_0015
        _result = v4.close(); // java.io.InputStream.close -> void
        _result = v2.close(); // java.io.BufferedReader.close -> void
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String a(java.lang.String p0, java.lang.String p1, android.os.Bundle p2) {
        // Registers (12 total): v9 = p0 (java.lang.String), v10 = p1 (java.lang.String), v11 = p2 (android.os.Bundle)
        v7 = 1;
        v2 = "3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f";
        v3 = "\r\n";
        v0 = "GET";
        _result = v0.equals(v10); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0028 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "?";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v11.a(); // com.a.a.m.a -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v9 = _result;
        v0 = "Facebook-Util";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v4 = " URL: ";
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = new java.net.URL;
        _result = v0.<init>(v9); // java.net.URL.<init> -> void
        _result = v0.openConnection(); // java.net.URL.openConnection -> java.net.URLConnection
        v0 = _result;
        v0 = (java.net.HttpURLConnection) v0;
        v1 = "User-Agent";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = this.getProperties(); // java.lang.System.getProperties -> java.util.Properties
        v5 = _result;
        v6 = "http.agent";
        _result = v5.getProperty(v6); // java.util.Properties.getProperty -> java.lang.String
        v5 = _result;
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = " FacebookAndroidSDK";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v0.setRequestProperty(v1, v4); // java.net.HttpURLConnection.setRequestProperty -> void
        v1 = "GET";
        _result = v1.equals(v10); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_01d1 */;
        v4 = new android.os.Bundle;
        _result = v4.<init>(); // android.os.Bundle.<init> -> void
        _result = v11.keySet(); // android.os.Bundle.keySet -> java.util.Set
        v1 = _result;
        _result = java.util.Set.iterator(v1); // -> java.util.Iterator
        v5 = _result;
        _result = java.util.Iterator.hasNext(v5); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_00a0 */;
        _result = java.util.Iterator.next(v5); // -> java.lang.Object
        v1 = _result;
        v1 = (java.lang.String) v1;
        _result = v11.getByteArray(v1); // android.os.Bundle.getByteArray -> byte[]
        v6 = _result;
        if (v6 == 0) /* goto L_0086 */;
        _result = v11.getByteArray(v1); // android.os.Bundle.getByteArray -> byte[]
        v6 = _result;
        _result = v4.putByteArray(v1, v6); // android.os.Bundle.putByteArray -> void
        // goto L_0086
        v1 = "method";
        _result = v11.containsKey(v1); // android.os.Bundle.containsKey -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_00ad */;
        v1 = "method";
        _result = v11.putString(v1, v10); // android.os.Bundle.putString -> void
        v1 = "access_token";
        _result = v11.containsKey(v1); // android.os.Bundle.containsKey -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_00c4 */;
        v1 = "access_token";
        _result = v11.getString(v1); // android.os.Bundle.getString -> java.lang.String
        v1 = _result;
        _result = v1.decode(); // java.net.URLDecoder.decode -> java.lang.String
        v1 = _result;
        v5 = "access_token";
        _result = v11.putString(v5, v1); // android.os.Bundle.putString -> void
        v1 = "POST";
        _result = v0.setRequestMethod(v1); // java.net.HttpURLConnection.setRequestMethod -> void
        v1 = "Content-Type";
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "multipart/form-data;boundary=";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v5 = _result;
        _result = v0.setRequestProperty(v1, v5); // java.net.HttpURLConnection.setRequestProperty -> void
        _result = v0.setDoOutput(v7); // java.net.HttpURLConnection.setDoOutput -> void
        _result = v0.setDoInput(v7); // java.net.HttpURLConnection.setDoInput -> void
        v1 = "Connection";
        v5 = "Keep-Alive";
        _result = v0.setRequestProperty(v1, v5); // java.net.HttpURLConnection.setRequestProperty -> void
        _result = v0.connect(); // java.net.HttpURLConnection.connect -> void
        v5 = new java.io.BufferedOutputStream;
        _result = v0.getOutputStream(); // java.net.HttpURLConnection.getOutputStream -> java.io.OutputStream
        v1 = _result;
        _result = v5.<init>(v1); // java.io.BufferedOutputStream.<init> -> void
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "--";
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.getBytes(); // java.lang.String.getBytes -> byte[]
        v1 = _result;
        _result = v5.write(v1); // java.io.OutputStream.write -> void
        _result = v11.a(v2); // com.a.a.m.a -> java.lang.String
        v1 = _result;
        _result = v1.getBytes(); // java.lang.String.getBytes -> byte[]
        v1 = _result;
        _result = v5.write(v1); // java.io.OutputStream.write -> void
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v6 = "--";
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.getBytes(); // java.lang.String.getBytes -> byte[]
        v1 = _result;
        _result = v5.write(v1); // java.io.OutputStream.write -> void
        _result = v4.isEmpty(); // android.os.Bundle.isEmpty -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_01cb */;
        _result = v4.keySet(); // android.os.Bundle.keySet -> java.util.Set
        v1 = _result;
        _result = java.util.Set.iterator(v1); // -> java.util.Iterator
        v6 = _result;
        _result = java.util.Iterator.hasNext(v6); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_01cb */;
        _result = java.util.Iterator.next(v6); // -> java.lang.Object
        v1 = _result;
        v1 = (java.lang.String) v1;
        v7 = new java.lang.StringBuilder;
        _result = v7.<init>(); // java.lang.StringBuilder.<init> -> void
        v8 = "Content-Disposition: form-data; filename=\"";
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        v8 = "\"";
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v7 = _result;
        _result = v7.getBytes(); // java.lang.String.getBytes -> byte[]
        v7 = _result;
        _result = v5.write(v7); // java.io.OutputStream.write -> void
        v7 = new java.lang.StringBuilder;
        _result = v7.<init>(); // java.lang.StringBuilder.<init> -> void
        v8 = "Content-Type: content/unknown";
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v7 = _result;
        _result = v7.getBytes(); // java.lang.String.getBytes -> byte[]
        v7 = _result;
        _result = v5.write(v7); // java.io.OutputStream.write -> void
        _result = v4.getByteArray(v1); // android.os.Bundle.getByteArray -> byte[]
        v1 = _result;
        _result = v5.write(v1); // java.io.OutputStream.write -> void
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v7 = "--";
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.getBytes(); // java.lang.String.getBytes -> byte[]
        v1 = _result;
        _result = v5.write(v1); // java.io.OutputStream.write -> void
        // goto L_0153
        _result = v5.flush(); // java.io.OutputStream.flush -> void
        _result = v5.close(); // java.io.OutputStream.close -> void
        v1 = "";
        _result = v0.getInputStream(); // java.net.HttpURLConnection.getInputStream -> java.io.InputStream
        v1 = _result;
        _result = v1.a(); // com.a.a.m.a -> java.lang.String
        v0 = _result;
        return v0;
        v1 = _exception;
        _result = v0.getErrorStream(); // java.net.HttpURLConnection.getErrorStream -> java.io.InputStream
        v0 = _result;
        _result = v0.a(); // com.a.a.m.a -> java.lang.String
        v0 = _result;
        // goto L_01db
    }

    public static void a(android.content.Context p0) {
        // Registers (2 total): v1 = p0 (android.content.Context)
        _result = v1.createInstance(); // android.webkit.CookieSyncManager.createInstance -> android.webkit.CookieSyncManager
        _result = this.getInstance(); // android.webkit.CookieManager.getInstance -> android.webkit.CookieManager
        v0 = _result;
        _result = v0.removeAllCookie(); // android.webkit.CookieManager.removeAllCookie -> void
        return;
    }

    public static void a(android.content.Context p0, java.lang.String p1, java.lang.String p2) {
        // Registers (4 total): v1 = p0 (android.content.Context), v2 = p1 (java.lang.String), v3 = p2 (java.lang.String)
        v0 = new com.sec.widget.a;
        _result = v0.<init>(v1); // com.sec.widget.a.<init> -> void
        _result = v0.setTitle(v2); // com.sec.widget.a.setTitle -> android.app.AlertDialog$Builder
        _result = v0.setMessage(v3); // com.sec.widget.a.setMessage -> android.app.AlertDialog$Builder
        _result = v0.create(); // com.sec.widget.a.create -> android.app.AlertDialog
        v0 = _result;
        _result = v0.show(); // android.app.AlertDialog.show -> void
        return;
    }

    public static android.os.Bundle b(java.lang.String p0) {
        // Registers (3 total): v2 = p0 (java.lang.String)
        v0 = "fbconnect";
        v1 = "http";
        _result = v2.replace(v0, v1); // java.lang.String.replace -> java.lang.String
        v0 = _result;
        v1 = new java.net.URL;
        _result = v1.<init>(v0); // java.net.URL.<init> -> void
        _result = v1.getQuery(); // java.net.URL.getQuery -> java.lang.String
        v0 = _result;
        _result = v0.a(); // com.a.a.m.a -> android.os.Bundle
        v0 = _result;
        _result = v1.getRef(); // java.net.URL.getRef -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.a.a.m.a -> android.os.Bundle
        v1 = _result;
        _result = v0.putAll(v1); // android.os.Bundle.putAll -> void
        return v0;
        v0 = _exception;
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        // goto L_0020
    }

    public static org.json.JSONObject c(java.lang.String p0) {
        // Registers (6 total): v5 = p0 (java.lang.String)
        v0 = "false";
        _result = v0.equals(v5); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0010 */;
        v0 = new com.a.a.f;
        v1 = "request failed";
        _result = v0.<init>(v1); // com.a.a.f.<init> -> void
        throw v0;
        v0 = "true";
        _result = v0.equals(v5); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001a */;
        v5 = "{value : true}";
        v0 = new org.json.JSONObject;
        _result = v0.<init>(v5); // org.json.JSONObject.<init> -> void
        v1 = "error";
        _result = v0.has(v1); // org.json.JSONObject.has -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0040 */;
        v1 = "error";
        _result = v0.getJSONObject(v1); // org.json.JSONObject.getJSONObject -> org.json.JSONObject
        v0 = _result;
        v1 = new com.a.a.f;
        v2 = "message";
        _result = v0.getString(v2); // org.json.JSONObject.getString -> java.lang.String
        v2 = _result;
        v3 = "type";
        _result = v0.getString(v3); // org.json.JSONObject.getString -> java.lang.String
        v0 = _result;
        v3 = 0;
        _result = v1.<init>(v2, v0, v3); // com.a.a.f.<init> -> void
        throw v1;
        v1 = "error_code";
        _result = v0.has(v1); // org.json.JSONObject.has -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0068 */;
        v1 = "error_msg";
        _result = v0.has(v1); // org.json.JSONObject.has -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0068 */;
        v1 = new com.a.a.f;
        v2 = "error_msg";
        _result = v0.getString(v2); // org.json.JSONObject.getString -> java.lang.String
        v2 = _result;
        v3 = "";
        v4 = "error_code";
        _result = v0.getString(v4); // org.json.JSONObject.getString -> java.lang.String
        v0 = _result;
        _result = v0.parseInt(); // java.lang.Integer.parseInt -> int
        v0 = _result;
        _result = v1.<init>(v2, v3, v0); // com.a.a.f.<init> -> void
        throw v1;
        v1 = "error_code";
        _result = v0.has(v1); // org.json.JSONObject.has -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0084 */;
        v1 = new com.a.a.f;
        v2 = "request failed";
        v3 = "";
        v4 = "error_code";
        _result = v0.getString(v4); // org.json.JSONObject.getString -> java.lang.String
        v0 = _result;
        _result = v0.parseInt(); // java.lang.Integer.parseInt -> int
        v0 = _result;
        _result = v1.<init>(v2, v3, v0); // com.a.a.f.<init> -> void
        throw v1;
        v1 = "error_msg";
        _result = v0.has(v1); // org.json.JSONObject.has -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0098 */;
        v1 = new com.a.a.f;
        v2 = "error_msg";
        _result = v0.getString(v2); // org.json.JSONObject.getString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // com.a.a.f.<init> -> void
        throw v1;
        v1 = "error_reason";
        _result = v0.has(v1); // org.json.JSONObject.has -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_00ac */;
        v1 = new com.a.a.f;
        v2 = "error_reason";
        _result = v0.getString(v2); // org.json.JSONObject.getString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // com.a.a.f.<init> -> void
        throw v1;
        return v0;
    }

}