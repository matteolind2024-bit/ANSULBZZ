package com.a.a;

/**
 * Original SourceFile: FbDialog.java
 * Descriptor: Lcom/a/a/i;
 */
class i implements android.content.DialogInterface$OnCancelListener {
    final com.a.a.g a;

    i(com.a.a.g p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.a.a.g)
        v0.a = v1; // com.a.a.i.a:com.a.a.g
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onCancel(android.content.DialogInterface p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.DialogInterface)
        v0 = v1.a; // com.a.a.i.a:com.a.a.g
        _result = v0.a(); // com.a.a.g.a -> com.a.a.e
        v0 = _result;
        _result = com.a.a.e.a(v0); // -> void
        v0 = v1.a; // com.a.a.i.a:com.a.a.g
        _result = v0.dismiss(); // com.a.a.g.dismiss -> void
        return;
    }

}