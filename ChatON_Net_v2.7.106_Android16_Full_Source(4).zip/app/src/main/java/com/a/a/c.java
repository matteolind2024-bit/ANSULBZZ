package com.a.a;

/**
 * Original SourceFile: Facebook.java
 * Descriptor: Lcom/a/a/c;
 */
class c implements java.lang.Runnable {
    final android.app.Activity a;
    final java.lang.String[] b;
    final com.a.a.b c;

    c(com.a.a.b p0, android.app.Activity p1, java.lang.String[] p2) {
        // Registers (4 total): v0 = this, v1 = p0 (com.a.a.b), v2 = p1 (android.app.Activity), v3 = p2 (java.lang.String[])
        v0.c = v1; // com.a.a.c.c:com.a.a.b
        v0.a = v2; // com.a.a.c.a:android.app.Activity
        v0.b = v3; // com.a.a.c.b:java.lang.String[]
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (4 total): v3 = this
        v0 = v3.c; // com.a.a.c.c:com.a.a.b
        v1 = v3.a; // com.a.a.c.a:android.app.Activity
        v2 = v3.b; // com.a.a.c.b:java.lang.String[]
        _result = v0.a(v1, v2); // com.a.a.b.a -> void
        return;
    }

}