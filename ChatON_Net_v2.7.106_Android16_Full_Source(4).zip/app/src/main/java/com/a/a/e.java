package com.a.a;

/**
 * Original SourceFile: Facebook.java
 * Descriptor: Lcom/a/a/e;
 */
public interface e {
    public abstract void a();
    public abstract void a(android.os.Bundle p0);
    public abstract void a(com.a.a.a p0);
    public abstract void a(com.a.a.f p0);
}