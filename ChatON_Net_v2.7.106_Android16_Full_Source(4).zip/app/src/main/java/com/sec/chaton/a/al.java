package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/al;
 */
public final class al extends com.google.protobuf.GeneratedMessageLite implements com.sec.chaton.a.an {
    private static final com.sec.chaton.a.al a;
    private int b;
    private long c;
    private java.lang.Object d;
    private com.sec.chaton.a.ds e;
    private long f;
    private com.sec.chaton.a.dd g;
    private byte h;
    private int i;

    static {
        v0 = new com.sec.chaton.a.al;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.chaton.a.al.<init> -> void
        com.sec.chaton.a.al.a = v0; // :com.sec.chaton.a.al
        v0 = com.sec.chaton.a.al.a; // :com.sec.chaton.a.al
        _result = v0.p(); // com.sec.chaton.a.al.p -> void
        return;
    }

    private al(com.sec.chaton.a.am p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.am)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.h = v0; // com.sec.chaton.a.al.h:byte
        v1.i = v0; // com.sec.chaton.a.al.i:int
        return;
    }

    al(com.sec.chaton.a.am p0, com.sec.chaton.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.chaton.a.am), v2 = p1 (com.sec.chaton.a.b)
        _result = v0.<init>(v1); // com.sec.chaton.a.al.<init> -> void
        return;
    }

    private al(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.h = v0; // com.sec.chaton.a.al.h:byte
        v1.i = v0; // com.sec.chaton.a.al.i:int
        return;
    }

    static int a(com.sec.chaton.a.al p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.al), v1 = p1 (int)
        v0.b = v1; // com.sec.chaton.a.al.b:int
        return v1;
    }

    static long a(com.sec.chaton.a.al p0, long p1) {
        // Registers (3 total): v0 = p0 (com.sec.chaton.a.al), v1 = p1 (long)
        v0.c = v1; // com.sec.chaton.a.al.c:long
        return v1;
    }

    public static com.sec.chaton.a.al a() {
        v0 = com.sec.chaton.a.al.a; // :com.sec.chaton.a.al
        return v0;
    }

    public static com.sec.chaton.a.al a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.chaton.a.al.newBuilder -> com.sec.chaton.a.am
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.chaton.a.am.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.chaton.a.am) v0;
        _result = v0.a(); // com.sec.chaton.a.am.a -> com.sec.chaton.a.al
        v0 = _result;
        return v0;
    }

    public static com.sec.chaton.a.am a(com.sec.chaton.a.al p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.al)
        _result = this.newBuilder(); // com.sec.chaton.a.al.newBuilder -> com.sec.chaton.a.am
        v0 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.am.a -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    static com.sec.chaton.a.dd a(com.sec.chaton.a.al p0, com.sec.chaton.a.dd p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.al), v1 = p1 (com.sec.chaton.a.dd)
        v0.g = v1; // com.sec.chaton.a.al.g:com.sec.chaton.a.dd
        return v1;
    }

    static com.sec.chaton.a.ds a(com.sec.chaton.a.al p0, com.sec.chaton.a.ds p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.al), v1 = p1 (com.sec.chaton.a.ds)
        v0.e = v1; // com.sec.chaton.a.al.e:com.sec.chaton.a.ds
        return v1;
    }

    static java.lang.Object a(com.sec.chaton.a.al p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.al), v1 = p1 (java.lang.Object)
        v0.d = v1; // com.sec.chaton.a.al.d:java.lang.Object
        return v1;
    }

    static long b(com.sec.chaton.a.al p0, long p1) {
        // Registers (3 total): v0 = p0 (com.sec.chaton.a.al), v1 = p1 (long)
        v0.f = v1; // com.sec.chaton.a.al.f:long
        return v1;
    }

    public static com.sec.chaton.a.am newBuilder() {
        _result = this.j(); // com.sec.chaton.a.am.j -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    private com.google.protobuf.ByteString o() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.chaton.a.al.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.d = v0; // com.sec.chaton.a.al.d:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void p() {
        // Registers (4 total): v3 = this
        v1 = 0L;
        v3.c = v1; // com.sec.chaton.a.al.c:long
        v0 = "";
        v3.d = v0; // com.sec.chaton.a.al.d:java.lang.Object
        _result = this.a(); // com.sec.chaton.a.ds.a -> com.sec.chaton.a.ds
        v0 = _result;
        v3.e = v0; // com.sec.chaton.a.al.e:com.sec.chaton.a.ds
        v3.f = v1; // com.sec.chaton.a.al.f:long
        _result = this.a(); // com.sec.chaton.a.dd.a -> com.sec.chaton.a.dd
        v0 = _result;
        v3.g = v0; // com.sec.chaton.a.al.g:com.sec.chaton.a.dd
        return;
    }

    public com.sec.chaton.a.al b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.chaton.a.al.a; // :com.sec.chaton.a.al
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.chaton.a.al.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public long d() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.sec.chaton.a.al.c:long
        return v0;
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.al.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public java.lang.String f() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.chaton.a.al.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.d = v1; // com.sec.chaton.a.al.d:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean g() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.al.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.al.b -> com.sec.chaton.a.al
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (7 total): v6 = this
        v5 = 4;
        v4 = 2;
        v3 = 1;
        v0 = v6.i; // com.sec.chaton.a.al.i:int
        v1 = -1;
        if (v0 == v1) /* goto L_0009 */;
        return v0;
        v0 = 0;
        v1 = v6.b; // com.sec.chaton.a.al.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v3) /* goto L_0017 */;
        v1 = v6.c; // com.sec.chaton.a.al.c:long
        _result = v3.computeInt64Size(v1, v2); // com.google.protobuf.CodedOutputStream.computeInt64Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.chaton.a.al.b:int
        v1 = binOpLit8_0xdd(v1, 2);
        if (v1 != v4) /* goto L_0026 */;
        _result = v6.o(); // com.sec.chaton.a.al.o -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v4.computeBytesSize(v1); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.chaton.a.al.b:int
        v1 = binOpLit8_0xdd(v1, 4);
        if (v1 != v5) /* goto L_0034 */;
        v1 = 3;
        v2 = v6.e; // com.sec.chaton.a.al.e:com.sec.chaton.a.ds
        _result = v1.computeMessageSize(v2); // com.google.protobuf.CodedOutputStream.computeMessageSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.chaton.a.al.b:int
        v1 = binOpLit8_0xdd(v1, 8);
        v2 = 8;
        if (v1 != v2) /* goto L_0043 */;
        v1 = v6.f; // com.sec.chaton.a.al.f:long
        _result = v5.computeInt64Size(v1, v2); // com.google.protobuf.CodedOutputStream.computeInt64Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.chaton.a.al.b:int
        v1 = binOpLit8_0xdd(v1, 16);
        v2 = 16;
        if (v1 != v2) /* goto L_0053 */;
        v1 = 5;
        v2 = v6.g; // com.sec.chaton.a.al.g:com.sec.chaton.a.dd
        _result = v1.computeMessageSize(v2); // com.google.protobuf.CodedOutputStream.computeMessageSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v6.i = v0; // com.sec.chaton.a.al.i:int
        // goto L_0008
    }

    public com.sec.chaton.a.ds h() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.sec.chaton.a.al.e:com.sec.chaton.a.ds
        return v0;
    }

    public boolean i() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.al.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.h; // com.sec.chaton.a.al.h:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.h = v0; // com.sec.chaton.a.al.h:byte
        // goto L_0008
    }

    public long j() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // com.sec.chaton.a.al.f:long
        return v0;
    }

    public boolean k() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.al.b:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public com.sec.chaton.a.dd l() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.sec.chaton.a.al.g:com.sec.chaton.a.dd
        return v0;
    }

    public com.sec.chaton.a.am m() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.chaton.a.al.newBuilder -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.am n() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.al.a -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.m(); // com.sec.chaton.a.al.m -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.n(); // com.sec.chaton.a.al.n -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (7 total): v5 = this, v6 = p0 (com.google.protobuf.CodedOutputStream)
        v4 = 4;
        v3 = 2;
        v2 = 1;
        _result = v5.getSerializedSize(); // com.sec.chaton.a.al.getSerializedSize -> int
        v0 = v5.b; // com.sec.chaton.a.al.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v2) /* goto L_0011 */;
        v0 = v5.c; // com.sec.chaton.a.al.c:long
        _result = v6.writeInt64(v2, v0, v1); // com.google.protobuf.CodedOutputStream.writeInt64 -> void
        v0 = v5.b; // com.sec.chaton.a.al.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v3) /* goto L_001e */;
        _result = v5.o(); // com.sec.chaton.a.al.o -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v6.writeBytes(v3, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v5.b; // com.sec.chaton.a.al.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        if (v0 != v4) /* goto L_002a */;
        v0 = 3;
        v1 = v5.e; // com.sec.chaton.a.al.e:com.sec.chaton.a.ds
        _result = v6.writeMessage(v0, v1); // com.google.protobuf.CodedOutputStream.writeMessage -> void
        v0 = v5.b; // com.sec.chaton.a.al.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 != v1) /* goto L_0037 */;
        v0 = v5.f; // com.sec.chaton.a.al.f:long
        _result = v6.writeInt64(v4, v0, v1); // com.google.protobuf.CodedOutputStream.writeInt64 -> void
        v0 = v5.b; // com.sec.chaton.a.al.b:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_0045 */;
        v0 = 5;
        v1 = v5.g; // com.sec.chaton.a.al.g:com.sec.chaton.a.dd
        _result = v6.writeMessage(v0, v1); // com.google.protobuf.CodedOutputStream.writeMessage -> void
        return;
    }

}