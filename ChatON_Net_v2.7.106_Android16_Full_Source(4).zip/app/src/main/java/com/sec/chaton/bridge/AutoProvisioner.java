package com.sec.chaton.bridge;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import com.sec.chaton.util.r;
import com.sec.chaton.util.s;

/**
 * ============================================================================
 * AutoProvisioner — Complete Registration & Samsung Account Bypass (v2.7.106)
 * ============================================================================
 * Populates ChatON v2.7.106's preference store (com.sec.chaton.util.r / s)
 * so that HomeActivity.d() and TabActivity.j() immediately recognize the
 * device as a registered ChatON node (@benjamin@chaton.live) and open
 * the classic TouchWiz Nature UX 3D interface directly.
 */
public final class AutoProvisioner {
    private static final String TAG = "ChatON27_AutoProv";

    public static final String LOCAL_UID       = "b7e6d5c4-a3b2-4109-8f7e-6d5c4b3a2109";
    public static final String LOCAL_CHATON_ID = "@benjamin@chaton.live";
    public static final String LOCAL_MSISDN    = "+989120001337";
    public static final String LOCAL_PUSH_NAME = "Benjamin Arthur Carter";
    public static final String LOCAL_IMEI      = "CHATON27NODE01337";
    public static final String LOCAL_AES_HEX   = "308b4ba610cf3f1eeac517d98a534932cc70c28f0da6036b2e7091ccf80f42dd";

    private AutoProvisioner() {}

    public static synchronized void ensureProvisioned(Context context) {
        try {
            s pref = r.a();
            if (pref != null) {
                pref.b("uid", LOCAL_UID);
                pref.b("chaton_id", LOCAL_CHATON_ID);
                pref.b("msisdn", LOCAL_MSISDN);
                pref.b("Push Name", LOCAL_PUSH_NAME);
                pref.b("imei", LOCAL_IMEI);
                pref.b("key", LOCAL_AES_HEX);
                pref.b("country_ISO", "IR");
                pref.b("country_name", "Iran");
                pref.b("country_code", "98");
                pref.b("account_country_code", "IR");
                pref.b("update_disclaimer_status", "DONE");
                pref.b("UpdateIsCritical", Boolean.FALSE);
                pref.b("back_deregi_fail", Boolean.FALSE);
                pref.b("back_chatonv_deregi_fail", Boolean.FALSE);
                pref.b("primary_message_addrss", "127.0.0.1");
                pref.b("primary_message_port", Integer.valueOf(5223));
                pref.b("secondary_message_addrss", "127.0.0.1");
                pref.b("secondary_message_port", Integer.valueOf(5223));
                pref.b("primary_contact_addrss", "127.0.0.1");
                pref.b("primary_contact_port", Integer.valueOf(443));
                pref.b("primary_file_addrss", "127.0.0.1");
                pref.b("primary_file_port", Integer.valueOf(443));
                pref.b("primary_translation_address", "127.0.0.1");
            }
            if (context != null) {
                SharedPreferences sp = context.getSharedPreferences("ChatON", Context.MODE_PRIVATE);
                sp.edit()
                        .putString("uid", LOCAL_UID)
                        .putString("chaton_id", LOCAL_CHATON_ID)
                        .putString("msisdn", LOCAL_MSISDN)
                        .putString("Push Name", LOCAL_PUSH_NAME)
                        .putString("imei", LOCAL_IMEI)
                        .putString("key", LOCAL_AES_HEX)
                        .putString("country_ISO", "IR")
                        .putString("update_disclaimer_status", "DONE")
                        .putBoolean("UpdateIsCritical", false)
                        .apply();
            }
            Log.i(TAG, "Auto-provisioned ChatON v2.7.106 identity: " + LOCAL_CHATON_ID);
        } catch (Throwable t) {
            Log.e(TAG, "AutoProvisioner error: " + t.getMessage(), t);
        }
    }
}
