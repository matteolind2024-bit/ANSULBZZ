package com.sec.chaton.base;

/**
 * Original SourceFile: BaseMultiPaneActivity.java
 * Descriptor: Lcom/sec/chaton/base/BaseMultiPaneActivity;
 */
public class BaseMultiPaneActivity extends com.sec.chaton.base.BaseActivity {
    public BaseMultiPaneActivity() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // com.sec.chaton.base.BaseActivity.<init> -> void
        return;
    }

    private void a(android.support.v4.app.FragmentManager p0, com.sec.chaton.base.a p1, android.content.Intent p2) {
        // Registers (8 total): v4 = this, v5 = p0 (android.support.v4.app.FragmentManager), v6 = p1 (com.sec.chaton.base.a), v7 = p2 (android.content.Intent)
        _result = v7.b(); // com.sec.chaton.base.BaseMultiPaneActivity.b -> android.os.Bundle
        v1 = _result;
        _result = v6.a(); // com.sec.chaton.base.a.a -> java.lang.Class
        v0 = _result;
        _result = v0.newInstance(); // java.lang.Class.newInstance -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        _result = v0.setArguments(v1); // android.support.v4.app.Fragment.setArguments -> void
        _result = v5.beginTransaction(); // android.support.v4.app.FragmentManager.beginTransaction -> android.support.v4.app.FragmentTransaction
        v1 = _result;
        _result = v6.c(); // com.sec.chaton.base.a.c -> int
        v2 = _result;
        _result = v6.b(); // com.sec.chaton.base.a.b -> java.lang.String
        v3 = _result;
        _result = v1.replace(v2, v0, v3); // android.support.v4.app.FragmentTransaction.replace -> android.support.v4.app.FragmentTransaction
        _result = v4.a(v5, v1, v0); // com.sec.chaton.base.BaseMultiPaneActivity.a -> void
        _result = v1.commit(); // android.support.v4.app.FragmentTransaction.commit -> int
        return;
        v0 = _exception;
        v0 = "Error creating new Fragmnet";
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.util.p.a -> void
        // goto L_0026
        v0 = _exception;
        v0 = "Error creating new Fragmnet";
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.util.p.a -> void
        // goto L_0026
    }

    protected com.sec.chaton.base.a a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = 0;
        return v0;
    }

    public void a(android.content.Intent p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Intent)
        _result = v3.getComponent(); // android.content.Intent.getComponent -> android.content.ComponentName
        v0 = _result;
        _result = v0.getClassName(); // android.content.ComponentName.getClassName -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0020 */;
        _result = v3.getComponent(); // android.content.Intent.getComponent -> android.content.ComponentName
        v0 = _result;
        _result = v0.getClassName(); // android.content.ComponentName.getClassName -> java.lang.String
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.base.BaseMultiPaneActivity.a -> com.sec.chaton.base.a
        v0 = _result;
        if (v0 == 0) /* goto L_004c */;
        _result = v2.getSupportFragmentManager(); // com.sec.chaton.base.BaseMultiPaneActivity.getSupportFragmentManager -> android.support.v4.app.FragmentManager
        v1 = _result;
        _result = v2.a(v1, v0, v3); // com.sec.chaton.base.BaseMultiPaneActivity.a -> void
        return;
        _result = v2.getPackageManager(); // com.sec.chaton.base.BaseMultiPaneActivity.getPackageManager -> android.content.pm.PackageManager
        v0 = _result;
        v1 = 0x00010000;
        _result = v0.queryIntentActivities(v3, v1); // android.content.pm.PackageManager.queryIntentActivities -> java.util.List
        v0 = _result;
        _result = java.util.List.iterator(v0); // -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_004c */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (android.content.pm.ResolveInfo) v0;
        v0 = v0.activityInfo; // android.content.pm.ResolveInfo.activityInfo:android.content.pm.ActivityInfo
        v0 = v0.name; // android.content.pm.ActivityInfo.name:java.lang.String
        _result = v2.a(v0); // com.sec.chaton.base.BaseMultiPaneActivity.a -> com.sec.chaton.base.a
        v0 = _result;
        if (v0 == 0) /* goto L_002e */;
        _result = v2.getSupportFragmentManager(); // com.sec.chaton.base.BaseMultiPaneActivity.getSupportFragmentManager -> android.support.v4.app.FragmentManager
        v1 = _result;
        _result = v2.a(v1, v0, v3); // com.sec.chaton.base.BaseMultiPaneActivity.a -> void
        // goto L_001f
        _result = v2.a(v3); // com.sec.chaton.base.BaseActivity.a -> void
        // goto L_001f
    }

    protected void a(android.support.v4.app.FragmentManager p0, android.support.v4.app.FragmentTransaction p1, android.support.v4.app.Fragment p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.support.v4.app.FragmentManager), v2 = p1 (android.support.v4.app.FragmentTransaction), v3 = p2 (android.support.v4.app.Fragment)
        return;
    }

}