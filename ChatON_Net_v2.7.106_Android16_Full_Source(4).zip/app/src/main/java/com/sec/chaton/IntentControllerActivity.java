package com.sec.chaton;

/**
 * Original SourceFile: IntentControllerActivity.java
 * Descriptor: Lcom/sec/chaton/IntentControllerActivity;
 */
public class IntentControllerActivity extends com.sec.chaton.base.BaseActivity {
    public static java.lang.Boolean a;

    static {
        v0 = 0;
        _result = v0.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v0 = _result;
        com.sec.chaton.IntentControllerActivity.a = v0; // :java.lang.Boolean
        return;
    }

    public IntentControllerActivity() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // com.sec.chaton.base.BaseActivity.<init> -> void
        return;
    }

    public static android.content.Intent a(android.content.Context p0) {
        // Registers (2 total): v1 = p0 (android.content.Context)
        v0 = 0;
        _result = v1.a(v0); // com.sec.chaton.IntentControllerActivity.a -> android.content.Intent
        v0 = _result;
        return v0;
    }

    public static android.content.Intent a(android.content.Context p0, boolean p1) {
        // Registers (4 total): v2 = p0 (android.content.Context), v3 = p1 (boolean)
        v0 = new android.content.Intent;
        v1 = com.sec.chaton.IntentControllerActivity.class;
        _result = v0.<init>(v2, v1); // android.content.Intent.<init> -> void
        v1 = "skipSplash";
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        return v0;
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v2 = 0;
        _result = v3.onCreate(v4); // com.sec.chaton.base.BaseActivity.onCreate -> void
        v0 = com.sec.chaton.IntentControllerActivity.a; // :java.lang.Boolean
        _result = v0.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0016 */;
        _result = v3.isTaskRoot(); // com.sec.chaton.IntentControllerActivity.isTaskRoot -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0016 */;
        _result = v3.finish(); // com.sec.chaton.IntentControllerActivity.finish -> void
        return;
        _result = v2.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v0 = _result;
        com.sec.chaton.IntentControllerActivity.a = v0; // :java.lang.Boolean
        _result = v3.getIntent(); // com.sec.chaton.IntentControllerActivity.getIntent -> android.content.Intent
        v0 = _result;
        v1 = 0x00100000;
        _result = v0.a(v1); // com.sec.common.b.j.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0048 */;
        _result = v3.a(); // com.sec.chaton.HomeActivity.a -> android.content.Intent
        v0 = _result;
        v1 = "android.intent.action.MAIN";
        _result = v0.setAction(v1); // android.content.Intent.setAction -> android.content.Intent
        v1 = "android.intent.category.LAUNCHER";
        _result = v0.addCategory(v1); // android.content.Intent.addCategory -> android.content.Intent
        _result = v3.isTaskRoot(); // com.sec.chaton.IntentControllerActivity.isTaskRoot -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0041 */;
        v1 = 0x10200000;
        _result = v0.setFlags(v1); // android.content.Intent.setFlags -> android.content.Intent
        _result = v3.startActivity(v0); // com.sec.chaton.IntentControllerActivity.startActivity -> void
        _result = v3.finish(); // com.sec.chaton.IntentControllerActivity.finish -> void
        // goto L_0015
        v1 = "skipSplash";
        _result = v0.getBooleanExtra(v1, v2); // android.content.Intent.getBooleanExtra -> boolean
        v1 = _result;
        _result = v3.a(v0, v1); // com.sec.chaton.HomeActivity.a -> android.content.Intent
        v0 = _result;
        _result = v3.startActivity(v0); // com.sec.chaton.IntentControllerActivity.startActivity -> void
        // goto L_0044
    }

}