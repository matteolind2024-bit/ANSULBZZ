package com.sec.chaton;

/**
 * Original SourceFile: ChatONVDialog.java
 * Descriptor: Lcom/sec/chaton/ChatONVDialog;
 */
public class ChatONVDialog extends android.app.Activity {
    private android.widget.Button a;
    private android.widget.Button b;
    private android.widget.CheckBox c;
    private android.widget.LinearLayout d;

    public ChatONVDialog() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.app.Activity.<init> -> void
        return;
    }

    static android.widget.CheckBox a(com.sec.chaton.ChatONVDialog p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.ChatONVDialog)
        v0 = v1.c; // com.sec.chaton.ChatONVDialog.c:android.widget.CheckBox
        return v0;
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.os.Bundle)
        v3 = 0;
        _result = v4.onCreate(v5); // android.app.Activity.onCreate -> void
        v0 = 1;
        _result = v4.requestWindowFeature(v0); // com.sec.chaton.ChatONVDialog.requestWindowFeature -> boolean
        v0 = com.sec.chaton.R.layout.chaton_coolots_dialog; // 0x7f030054
        _result = v4.setContentView(v0); // com.sec.chaton.ChatONVDialog.setContentView -> void
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_0017 */;
        _result = v4.setFinishOnTouchOutside(v3); // com.sec.chaton.ChatONVDialog.setFinishOnTouchOutside -> void
        _result = v4.getWindow(); // com.sec.chaton.ChatONVDialog.getWindow -> android.view.Window
        v0 = _result;
        v1 = -1;
        v2 = -2;
        _result = v0.setLayout(v1, v2); // android.view.Window.setLayout -> void
        v0 = com.sec.chaton.R.id.chaton_download_ok; // 0x7f08022b
        _result = v4.findViewById(v0); // com.sec.chaton.ChatONVDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v4.a = v0; // com.sec.chaton.ChatONVDialog.a:android.widget.Button
        v0 = com.sec.chaton.R.id.chaton_download_cancel; // 0x7f08022c
        _result = v4.findViewById(v0); // com.sec.chaton.ChatONVDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v4.b = v0; // com.sec.chaton.ChatONVDialog.b:android.widget.Button
        v0 = com.sec.chaton.R.id.data_packet_chekcbox; // 0x7f08022a
        _result = v4.findViewById(v0); // com.sec.chaton.ChatONVDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.CheckBox) v0;
        v4.c = v0; // com.sec.chaton.ChatONVDialog.c:android.widget.CheckBox
        v0 = com.sec.chaton.R.id.linear_packet_chekcbox; // 0x7f080229
        _result = v4.findViewById(v0); // com.sec.chaton.ChatONVDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.LinearLayout) v0;
        v4.d = v0; // com.sec.chaton.ChatONVDialog.d:android.widget.LinearLayout
        v0 = v4.d; // com.sec.chaton.ChatONVDialog.d:android.widget.LinearLayout
        v1 = new com.sec.chaton.m;
        _result = v1.<init>(v4); // com.sec.chaton.m.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.LinearLayout.setOnClickListener -> void
        v0 = v4.c; // com.sec.chaton.ChatONVDialog.c:android.widget.CheckBox
        _result = v0.setClickable(v3); // android.widget.CheckBox.setClickable -> void
        return;
    }

}