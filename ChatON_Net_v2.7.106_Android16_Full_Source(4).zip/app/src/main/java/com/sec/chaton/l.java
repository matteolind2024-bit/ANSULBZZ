package com.sec.chaton;

/**
 * Original SourceFile: ApplicationInitializeTask.java
 * Descriptor: Lcom/sec/chaton/l;
 */
public interface l {
    public abstract void a();
}