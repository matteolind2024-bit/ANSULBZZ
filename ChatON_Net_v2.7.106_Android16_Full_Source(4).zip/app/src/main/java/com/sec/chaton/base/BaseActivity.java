package com.sec.chaton.base;

/**
 * Original SourceFile: BaseActivity.java
 * Descriptor: Lcom/sec/chaton/base/BaseActivity;
 */
public class BaseActivity extends android.support.v4.app.FragmentActivity {
    private static final java.lang.String a;
    final com.sec.chaton.util.a f;

    static {
        v0 = com.sec.chaton.base.BaseActivity.class;
        _result = v0.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v0 = _result;
        com.sec.chaton.base.BaseActivity.a = v0; // :java.lang.String
        return;
    }

    public BaseActivity() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // android.support.v4.app.FragmentActivity.<init> -> void
        _result = v1.a(); // com.sec.chaton.util.a.a -> com.sec.chaton.util.a
        v0 = _result;
        v1.f = v0; // com.sec.chaton.base.BaseActivity.f:com.sec.chaton.util.a
        return;
    }

    public static void a(android.support.v4.app.Fragment p0, boolean p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.app.Fragment), v1 = p1 (boolean)
        _result = v0.setHasOptionsMenu(v1); // android.support.v4.app.Fragment.setHasOptionsMenu -> void
        return;
    }

    public static android.os.Bundle b(android.content.Intent p0) {
        // Registers (3 total): v2 = p0 (android.content.Intent)
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        if (v2 != 0) /* goto L_0008 */;
        return v0;
        _result = v2.getExtras(); // android.content.Intent.getExtras -> android.os.Bundle
        v1 = _result;
        if (v1 == 0) /* goto L_0007 */;
        _result = v0.putAll(v1); // android.os.Bundle.putAll -> void
        // goto L_0007
    }

    public static void b(android.support.v4.app.Fragment p0, boolean p1) {
        // Registers (3 total): v1 = p0 (android.support.v4.app.Fragment), v2 = p1 (boolean)
        _result = this.e(); // com.sec.chaton.global.GlobalApplication.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0009 */;
        _result = v1.setHasOptionsMenu(v2); // android.support.v4.app.Fragment.setHasOptionsMenu -> void
        return;
    }

    public void a(android.content.Intent p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.content.Intent)
        _result = v0.startActivity(v1); // com.sec.chaton.base.BaseActivity.startActivity -> void
        return;
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.a(); // com.sec.chaton.util.bz.a -> void
        _result = v2.onCreate(v3); // android.support.v4.app.FragmentActivity.onCreate -> void
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_005c */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ".onCreate() ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "isTaskRoot: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.isTaskRoot(); // com.sec.chaton.base.BaseActivity.isTaskRoot -> boolean
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", savedInstanceStatue: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.base.BaseActivity.a; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        return;
    }

    public boolean onCreateOptionsMenu(android.view.Menu p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.Menu)
        v0 = v1.f; // com.sec.chaton.base.BaseActivity.f:com.sec.chaton.util.a
        _result = v0.a(v2); // com.sec.chaton.util.a.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000e */;
        _result = v1.onCreateOptionsMenu(v2); // android.support.v4.app.FragmentActivity.onCreateOptionsMenu -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0010 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000f
    }

    protected void onDestroy() {
        // Registers (3 total): v2 = this
        _result = v2.onDestroy(); // android.support.v4.app.FragmentActivity.onDestroy -> void
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_0041 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ".onDestroy() ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.base.BaseActivity.a; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        return;
    }

    protected void onNewIntent(android.content.Intent p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.content.Intent)
        _result = v5.onNewIntent(v6); // android.support.v4.app.FragmentActivity.onNewIntent -> void
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_0082 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ".onNewIntent() ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v5.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v5.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.base.BaseActivity.a; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v6.getExtras(); // android.content.Intent.getExtras -> android.os.Bundle
        v1 = _result;
        if (v1 == 0) /* goto L_0082 */;
        _result = v1.keySet(); // android.os.Bundle.keySet -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0082 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = " > ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ": ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v1.get(v0); // android.os.Bundle.get -> java.lang.Object
        v0 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v3 = com.sec.chaton.base.BaseActivity.a; // :java.lang.String
        _result = v0.b(v3); // com.sec.chaton.util.p.b -> void
        // goto L_004f
        return;
    }

    public boolean onOptionsItemSelected(android.view.MenuItem p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.MenuItem)
        v0 = v1.f; // com.sec.chaton.base.BaseActivity.f:com.sec.chaton.util.a
        _result = v0.a(v2); // com.sec.chaton.util.a.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000e */;
        _result = v1.onOptionsItemSelected(v2); // android.support.v4.app.FragmentActivity.onOptionsItemSelected -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0010 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000f
    }

    protected void onPause() {
        // Registers (3 total): v2 = this
        _result = v2.onPause(); // android.support.v4.app.FragmentActivity.onPause -> void
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_0041 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ".onPause() ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.base.BaseActivity.a; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        return;
    }

    protected void onPostCreate(android.os.Bundle p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Bundle)
        _result = v1.onPostCreate(v2); // android.support.v4.app.FragmentActivity.onPostCreate -> void
        v0 = v1.f; // com.sec.chaton.base.BaseActivity.f:com.sec.chaton.util.a
        _result = v0.a(v2); // com.sec.chaton.util.a.a -> void
        return;
    }

    protected void onResume() {
        // Registers (3 total): v2 = this
        _result = v2.onResume(); // android.support.v4.app.FragmentActivity.onResume -> void
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_0041 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ".onResume() ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.base.BaseActivity.a; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        return;
    }

    protected void onSaveInstanceState(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onSaveInstanceState(v3); // android.support.v4.app.FragmentActivity.onSaveInstanceState -> void
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_0039 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ".onSaveInstanceState() ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.base.BaseActivity.a; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        return;
    }

    protected void onStop() {
        // Registers (3 total): v2 = this
        _result = v2.onStop(); // android.support.v4.app.FragmentActivity.onStop -> void
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_0041 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ".onStop() ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.base.BaseActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.base.BaseActivity.a; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        return;
    }

    protected void onUserLeaveHint() {
        // Registers (3 total): v2 = this
        v0 = "onUserLeaveHint";
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v2.getApplicationContext(); // com.sec.chaton.base.BaseActivity.getApplicationContext -> android.content.Context
        v0 = _result;
        _result = v0.b(); // com.sec.chaton.util.j.b -> void
        return;
    }

}