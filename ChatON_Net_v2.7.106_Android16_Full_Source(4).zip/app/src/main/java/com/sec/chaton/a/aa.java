package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/aa;
 */
public final class aa extends com.google.protobuf.GeneratedMessageLite implements com.sec.chaton.a.ac {
    private static final com.sec.chaton.a.aa a;
    private int b;
    private long c;
    private java.lang.Object d;
    private java.lang.Object e;
    private java.util.List f;
    private byte g;
    private int h;

    static {
        v0 = new com.sec.chaton.a.aa;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.chaton.a.aa.<init> -> void
        com.sec.chaton.a.aa.a = v0; // :com.sec.chaton.a.aa
        v0 = com.sec.chaton.a.aa.a; // :com.sec.chaton.a.aa
        _result = v0.m(); // com.sec.chaton.a.aa.m -> void
        return;
    }

    private aa(com.sec.chaton.a.ab p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.ab)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.g = v0; // com.sec.chaton.a.aa.g:byte
        v1.h = v0; // com.sec.chaton.a.aa.h:int
        return;
    }

    aa(com.sec.chaton.a.ab p0, com.sec.chaton.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.chaton.a.ab), v2 = p1 (com.sec.chaton.a.b)
        _result = v0.<init>(v1); // com.sec.chaton.a.aa.<init> -> void
        return;
    }

    private aa(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.g = v0; // com.sec.chaton.a.aa.g:byte
        v1.h = v0; // com.sec.chaton.a.aa.h:int
        return;
    }

    static int a(com.sec.chaton.a.aa p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.aa), v1 = p1 (int)
        v0.b = v1; // com.sec.chaton.a.aa.b:int
        return v1;
    }

    static long a(com.sec.chaton.a.aa p0, long p1) {
        // Registers (3 total): v0 = p0 (com.sec.chaton.a.aa), v1 = p1 (long)
        v0.c = v1; // com.sec.chaton.a.aa.c:long
        return v1;
    }

    public static com.sec.chaton.a.aa a() {
        v0 = com.sec.chaton.a.aa.a; // :com.sec.chaton.a.aa
        return v0;
    }

    public static com.sec.chaton.a.aa a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.chaton.a.aa.newBuilder -> com.sec.chaton.a.ab
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.chaton.a.ab.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.chaton.a.ab) v0;
        _result = v0.a(); // com.sec.chaton.a.ab.a -> com.sec.chaton.a.aa
        v0 = _result;
        return v0;
    }

    public static com.sec.chaton.a.ab a(com.sec.chaton.a.aa p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.aa)
        _result = this.newBuilder(); // com.sec.chaton.a.aa.newBuilder -> com.sec.chaton.a.ab
        v0 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.ab.a -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    static java.lang.Object a(com.sec.chaton.a.aa p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.aa), v1 = p1 (java.lang.Object)
        v0.d = v1; // com.sec.chaton.a.aa.d:java.lang.Object
        return v1;
    }

    static java.util.List a(com.sec.chaton.a.aa p0, java.util.List p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.aa), v1 = p1 (java.util.List)
        v0.f = v1; // com.sec.chaton.a.aa.f:java.util.List
        return v1;
    }

    static java.lang.Object b(com.sec.chaton.a.aa p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.aa), v1 = p1 (java.lang.Object)
        v0.e = v1; // com.sec.chaton.a.aa.e:java.lang.Object
        return v1;
    }

    static java.util.List b(com.sec.chaton.a.aa p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.aa)
        v0 = v1.f; // com.sec.chaton.a.aa.f:java.util.List
        return v0;
    }

    private com.google.protobuf.ByteString k() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.chaton.a.aa.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.d = v0; // com.sec.chaton.a.aa.d:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString l() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.chaton.a.aa.e:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.e = v0; // com.sec.chaton.a.aa.e:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void m() {
        // Registers (3 total): v2 = this
        v0 = 0L;
        v2.c = v0; // com.sec.chaton.a.aa.c:long
        v0 = "";
        v2.d = v0; // com.sec.chaton.a.aa.d:java.lang.Object
        v0 = "";
        v2.e = v0; // com.sec.chaton.a.aa.e:java.lang.Object
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        v2.f = v0; // com.sec.chaton.a.aa.f:java.util.List
        return;
    }

    public static com.sec.chaton.a.ab newBuilder() {
        _result = this.f(); // com.sec.chaton.a.ab.f -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.aa b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.chaton.a.aa.a; // :com.sec.chaton.a.aa
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.chaton.a.aa.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public long d() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.sec.chaton.a.aa.c:long
        return v0;
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.aa.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public java.lang.String f() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.chaton.a.aa.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.d = v1; // com.sec.chaton.a.aa.d:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean g() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.aa.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.aa.b -> com.sec.chaton.a.aa
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (8 total): v7 = this
        v6 = 4;
        v5 = 2;
        v4 = 1;
        v1 = 0;
        v2 = v7.h; // com.sec.chaton.a.aa.h:int
        v0 = -1;
        if (v2 == v0) /* goto L_000a */;
        return v2;
        v0 = v7.b; // com.sec.chaton.a.aa.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v4) /* goto L_0053 */;
        v2 = v7.c; // com.sec.chaton.a.aa.c:long
        _result = v4.computeInt64Size(v2, v3); // com.google.protobuf.CodedOutputStream.computeInt64Size -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v2 = v7.b; // com.sec.chaton.a.aa.b:int
        v2 = binOpLit8_0xdd(v2, 2);
        if (v2 != v5) /* goto L_0026 */;
        _result = v7.k(); // com.sec.chaton.a.aa.k -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v5.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v2 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = v7.b; // com.sec.chaton.a.aa.b:int
        v2 = binOpLit8_0xdd(v2, 4);
        if (v2 != v6) /* goto L_0036 */;
        v2 = 3;
        _result = v7.l(); // com.sec.chaton.a.aa.l -> com.google.protobuf.ByteString
        v3 = _result;
        _result = v2.computeBytesSize(v3); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v2 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = v0;
        v0 = v7.f; // com.sec.chaton.a.aa.f:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0050 */;
        v0 = v7.f; // com.sec.chaton.a.aa.f:java.util.List
        _result = java.util.List.get(v0, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        _result = v6.computeMessageSize(v0); // com.google.protobuf.CodedOutputStream.computeMessageSize -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v1 = binOpLit8_0xd8(v1, 1);
        v2 = v0;
        // goto L_0037
        v7.h = v2; // com.sec.chaton.a.aa.h:int
        // goto L_0009
        v0 = v1;
        // goto L_0017
    }

    public java.lang.String h() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.chaton.a.aa.e:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.e = v1; // com.sec.chaton.a.aa.e:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public com.sec.chaton.a.ab i() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.chaton.a.aa.newBuilder -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.g; // com.sec.chaton.a.aa.g:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.g = v0; // com.sec.chaton.a.aa.g:byte
        // goto L_0008
    }

    public com.sec.chaton.a.ab j() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.aa.a -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.i(); // com.sec.chaton.a.aa.i -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.j(); // com.sec.chaton.a.aa.j -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (7 total): v5 = this, v6 = p0 (com.google.protobuf.CodedOutputStream)
        v4 = 4;
        v3 = 2;
        v2 = 1;
        _result = v5.getSerializedSize(); // com.sec.chaton.a.aa.getSerializedSize -> int
        v0 = v5.b; // com.sec.chaton.a.aa.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v2) /* goto L_0011 */;
        v0 = v5.c; // com.sec.chaton.a.aa.c:long
        _result = v6.writeInt64(v2, v0, v1); // com.google.protobuf.CodedOutputStream.writeInt64 -> void
        v0 = v5.b; // com.sec.chaton.a.aa.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v3) /* goto L_001e */;
        _result = v5.k(); // com.sec.chaton.a.aa.k -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v6.writeBytes(v3, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v5.b; // com.sec.chaton.a.aa.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        if (v0 != v4) /* goto L_002c */;
        v0 = 3;
        _result = v5.l(); // com.sec.chaton.a.aa.l -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v6.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = 0;
        v1 = v0;
        v0 = v5.f; // com.sec.chaton.a.aa.f:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0045 */;
        v0 = v5.f; // com.sec.chaton.a.aa.f:java.util.List
        _result = java.util.List.get(v0, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        _result = v6.writeMessage(v4, v0); // com.google.protobuf.CodedOutputStream.writeMessage -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_002e
        return;
    }

}