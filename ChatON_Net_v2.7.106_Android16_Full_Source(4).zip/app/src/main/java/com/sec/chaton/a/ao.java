package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/ao;
 */
public final class ao extends com.google.protobuf.GeneratedMessageLite implements com.sec.chaton.a.aq {
    private static final com.sec.chaton.a.ao a;
    private int b;
    private long c;
    private com.sec.chaton.a.cp d;
    private com.sec.chaton.a.ar e;
    private java.lang.Object f;
    private java.lang.Object g;
    private com.google.protobuf.LazyStringList h;
    private java.lang.Object i;
    private java.lang.Object j;
    private java.lang.Object k;
    private java.lang.Object l;
    private long m;
    private byte n;
    private int o;

    static {
        v0 = new com.sec.chaton.a.ao;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.chaton.a.ao.<init> -> void
        com.sec.chaton.a.ao.a = v0; // :com.sec.chaton.a.ao
        v0 = com.sec.chaton.a.ao.a; // :com.sec.chaton.a.ao
        _result = v0.F(); // com.sec.chaton.a.ao.F -> void
        return;
    }

    private ao(com.sec.chaton.a.ap p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.ap)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.n = v0; // com.sec.chaton.a.ao.n:byte
        v1.o = v0; // com.sec.chaton.a.ao.o:int
        return;
    }

    ao(com.sec.chaton.a.ap p0, com.sec.chaton.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.chaton.a.ap), v2 = p1 (com.sec.chaton.a.b)
        _result = v0.<init>(v1); // com.sec.chaton.a.ao.<init> -> void
        return;
    }

    private ao(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.n = v0; // com.sec.chaton.a.ao.n:byte
        v1.o = v0; // com.sec.chaton.a.ao.o:int
        return;
    }

    private com.google.protobuf.ByteString A() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.sec.chaton.a.ao.g:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.g = v0; // com.sec.chaton.a.ao.g:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString B() {
        // Registers (3 total): v2 = this
        v0 = v2.i; // com.sec.chaton.a.ao.i:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.i = v0; // com.sec.chaton.a.ao.i:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString C() {
        // Registers (3 total): v2 = this
        v0 = v2.j; // com.sec.chaton.a.ao.j:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.j = v0; // com.sec.chaton.a.ao.j:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString D() {
        // Registers (3 total): v2 = this
        v0 = v2.k; // com.sec.chaton.a.ao.k:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.k = v0; // com.sec.chaton.a.ao.k:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString E() {
        // Registers (3 total): v2 = this
        v0 = v2.l; // com.sec.chaton.a.ao.l:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.l = v0; // com.sec.chaton.a.ao.l:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void F() {
        // Registers (4 total): v3 = this
        v1 = 0L;
        v3.c = v1; // com.sec.chaton.a.ao.c:long
        v0 = com.sec.chaton.a.cp.a; // :com.sec.chaton.a.cp
        v3.d = v0; // com.sec.chaton.a.ao.d:com.sec.chaton.a.cp
        v0 = com.sec.chaton.a.ar.a; // :com.sec.chaton.a.ar
        v3.e = v0; // com.sec.chaton.a.ao.e:com.sec.chaton.a.ar
        v0 = "";
        v3.f = v0; // com.sec.chaton.a.ao.f:java.lang.Object
        v0 = "";
        v3.g = v0; // com.sec.chaton.a.ao.g:java.lang.Object
        v0 = com.google.protobuf.LazyStringArrayList.EMPTY; // :com.google.protobuf.LazyStringList
        v3.h = v0; // com.sec.chaton.a.ao.h:com.google.protobuf.LazyStringList
        v0 = "";
        v3.i = v0; // com.sec.chaton.a.ao.i:java.lang.Object
        v0 = "";
        v3.j = v0; // com.sec.chaton.a.ao.j:java.lang.Object
        v0 = "";
        v3.k = v0; // com.sec.chaton.a.ao.k:java.lang.Object
        v0 = "";
        v3.l = v0; // com.sec.chaton.a.ao.l:java.lang.Object
        v3.m = v1; // com.sec.chaton.a.ao.m:long
        return;
    }

    static int a(com.sec.chaton.a.ao p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (int)
        v0.b = v1; // com.sec.chaton.a.ao.b:int
        return v1;
    }

    static long a(com.sec.chaton.a.ao p0, long p1) {
        // Registers (3 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (long)
        v0.c = v1; // com.sec.chaton.a.ao.c:long
        return v1;
    }

    static com.google.protobuf.LazyStringList a(com.sec.chaton.a.ao p0, com.google.protobuf.LazyStringList p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (com.google.protobuf.LazyStringList)
        v0.h = v1; // com.sec.chaton.a.ao.h:com.google.protobuf.LazyStringList
        return v1;
    }

    public static com.sec.chaton.a.ao a() {
        v0 = com.sec.chaton.a.ao.a; // :com.sec.chaton.a.ao
        return v0;
    }

    public static com.sec.chaton.a.ao a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.chaton.a.ao.newBuilder -> com.sec.chaton.a.ap
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.chaton.a.ap.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.chaton.a.ap) v0;
        _result = v0.a(); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ao
        v0 = _result;
        return v0;
    }

    public static com.sec.chaton.a.ap a(com.sec.chaton.a.ao p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.ao)
        _result = this.newBuilder(); // com.sec.chaton.a.ao.newBuilder -> com.sec.chaton.a.ap
        v0 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    static com.sec.chaton.a.ar a(com.sec.chaton.a.ao p0, com.sec.chaton.a.ar p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (com.sec.chaton.a.ar)
        v0.e = v1; // com.sec.chaton.a.ao.e:com.sec.chaton.a.ar
        return v1;
    }

    static com.sec.chaton.a.cp a(com.sec.chaton.a.ao p0, com.sec.chaton.a.cp p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (com.sec.chaton.a.cp)
        v0.d = v1; // com.sec.chaton.a.ao.d:com.sec.chaton.a.cp
        return v1;
    }

    static java.lang.Object a(com.sec.chaton.a.ao p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (java.lang.Object)
        v0.f = v1; // com.sec.chaton.a.ao.f:java.lang.Object
        return v1;
    }

    static long b(com.sec.chaton.a.ao p0, long p1) {
        // Registers (3 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (long)
        v0.m = v1; // com.sec.chaton.a.ao.m:long
        return v1;
    }

    static com.google.protobuf.LazyStringList b(com.sec.chaton.a.ao p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.ao)
        v0 = v1.h; // com.sec.chaton.a.ao.h:com.google.protobuf.LazyStringList
        return v0;
    }

    static java.lang.Object b(com.sec.chaton.a.ao p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (java.lang.Object)
        v0.g = v1; // com.sec.chaton.a.ao.g:java.lang.Object
        return v1;
    }

    static java.lang.Object c(com.sec.chaton.a.ao p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (java.lang.Object)
        v0.i = v1; // com.sec.chaton.a.ao.i:java.lang.Object
        return v1;
    }

    static java.lang.Object d(com.sec.chaton.a.ao p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (java.lang.Object)
        v0.j = v1; // com.sec.chaton.a.ao.j:java.lang.Object
        return v1;
    }

    static java.lang.Object e(com.sec.chaton.a.ao p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (java.lang.Object)
        v0.k = v1; // com.sec.chaton.a.ao.k:java.lang.Object
        return v1;
    }

    static java.lang.Object f(com.sec.chaton.a.ao p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ao), v1 = p1 (java.lang.Object)
        v0.l = v1; // com.sec.chaton.a.ao.l:java.lang.Object
        return v1;
    }

    public static com.sec.chaton.a.ap newBuilder() {
        _result = this.n(); // com.sec.chaton.a.ap.n -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    private com.google.protobuf.ByteString z() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // com.sec.chaton.a.ao.f:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.f = v0; // com.sec.chaton.a.ao.f:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    public com.sec.chaton.a.ao b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.chaton.a.ao.a; // :com.sec.chaton.a.ao
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.chaton.a.ao.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public long d() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.sec.chaton.a.ao.c:long
        return v0;
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.sec.chaton.a.cp f() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.sec.chaton.a.ao.d:com.sec.chaton.a.cp
        return v0;
    }

    public boolean g() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ao.b -> com.sec.chaton.a.ao
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (9 total): v8 = this
        v7 = 8;
        v6 = 4;
        v5 = 2;
        v4 = 1;
        v1 = 0;
        v0 = v8.o; // com.sec.chaton.a.ao.o:int
        v2 = -1;
        if (v0 == v2) /* goto L_000c */;
        return v0;
        v0 = v8.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v4) /* goto L_00de */;
        v2 = v8.c; // com.sec.chaton.a.ao.c:long
        _result = v4.computeInt64Size(v2, v3); // com.google.protobuf.CodedOutputStream.computeInt64Size -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v2 = v8.b; // com.sec.chaton.a.ao.b:int
        v2 = binOpLit8_0xdd(v2, 2);
        if (v2 != v5) /* goto L_002a */;
        v2 = v8.d; // com.sec.chaton.a.ao.d:com.sec.chaton.a.cp
        _result = v2.getNumber(); // com.sec.chaton.a.cp.getNumber -> int
        v2 = _result;
        _result = v5.computeEnumSize(v2); // com.google.protobuf.CodedOutputStream.computeEnumSize -> int
        v2 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = v8.b; // com.sec.chaton.a.ao.b:int
        v2 = binOpLit8_0xdd(v2, 4);
        if (v2 != v6) /* goto L_003c */;
        v2 = 3;
        v3 = v8.e; // com.sec.chaton.a.ao.e:com.sec.chaton.a.ar
        _result = v3.getNumber(); // com.sec.chaton.a.ar.getNumber -> int
        v3 = _result;
        _result = v2.computeEnumSize(v3); // com.google.protobuf.CodedOutputStream.computeEnumSize -> int
        v2 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = v8.b; // com.sec.chaton.a.ao.b:int
        v2 = binOpLit8_0xdd(v2, 8);
        if (v2 != v7) /* goto L_004b */;
        _result = v8.z(); // com.sec.chaton.a.ao.z -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v6.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v2 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = v8.b; // com.sec.chaton.a.ao.b:int
        v2 = binOpLit8_0xdd(v2, 16);
        v3 = 16;
        if (v2 != v3) /* goto L_005d */;
        v2 = 5;
        _result = v8.A(); // com.sec.chaton.a.ao.A -> com.google.protobuf.ByteString
        v3 = _result;
        _result = v2.computeBytesSize(v3); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v2 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = v1;
        v3 = v8.h; // com.sec.chaton.a.ao.h:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.size(v3); // -> int
        v3 = _result;
        if (v1 >= v3) /* goto L_0074 */;
        v3 = v8.h; // com.sec.chaton.a.ao.h:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.getByteString(v3, v1); // -> com.google.protobuf.ByteString
        v3 = _result;
        _result = v3.computeBytesSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeBytesSizeNoTag -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_005e
        v0 = binOp2addr_0xb0(v0, v2);
        _result = v8.m(); // com.sec.chaton.a.ao.m -> java.util.List
        v1 = _result;
        _result = java.util.List.size(v1); // -> int
        v1 = _result;
        v1 = binOpLit8_0xda(v1, 1);
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v8.b; // com.sec.chaton.a.ao.b:int
        v1 = binOpLit8_0xdd(v1, 32);
        v2 = 32;
        if (v1 != v2) /* goto L_0092 */;
        v1 = 7;
        _result = v8.B(); // com.sec.chaton.a.ao.B -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v8.b; // com.sec.chaton.a.ao.b:int
        v1 = binOpLit8_0xdd(v1, 64);
        v2 = 64;
        if (v1 != v2) /* goto L_00a3 */;
        _result = v8.C(); // com.sec.chaton.a.ao.C -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v7.computeBytesSize(v1); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v8.b; // com.sec.chaton.a.ao.b:int
        v1 = binOpLit16_0xd5(v1, 128);
        v2 = 128;
        if (v1 != v2) /* goto L_00b6 */;
        v1 = 9;
        _result = v8.D(); // com.sec.chaton.a.ao.D -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v8.b; // com.sec.chaton.a.ao.b:int
        v1 = binOpLit16_0xd5(v1, 256);
        v2 = 256;
        if (v1 != v2) /* goto L_00c9 */;
        v1 = 10;
        _result = v8.E(); // com.sec.chaton.a.ao.E -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v8.b; // com.sec.chaton.a.ao.b:int
        v1 = binOpLit16_0xd5(v1, 512);
        v2 = 512;
        if (v1 != v2) /* goto L_00da */;
        v1 = 11;
        v2 = v8.m; // com.sec.chaton.a.ao.m:long
        _result = v1.computeInt64Size(v2, v3); // com.google.protobuf.CodedOutputStream.computeInt64Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v8.o = v0; // com.sec.chaton.a.ao.o:int
        // goto L_000b
        v0 = v1;
        // goto L_0019
    }

    public com.sec.chaton.a.ar h() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.sec.chaton.a.ao.e:com.sec.chaton.a.ar
        return v0;
    }

    public boolean i() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.n; // com.sec.chaton.a.ao.n:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.n = v0; // com.sec.chaton.a.ao.n:byte
        // goto L_0008
    }

    public java.lang.String j() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // com.sec.chaton.a.ao.f:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.f = v1; // com.sec.chaton.a.ao.f:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean k() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.lang.String l() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.sec.chaton.a.ao.g:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.g = v1; // com.sec.chaton.a.ao.g:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public java.util.List m() {
        // Registers (2 total): v1 = this
        v0 = v1.h; // com.sec.chaton.a.ao.h:com.google.protobuf.LazyStringList
        return v0;
    }

    public boolean n() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 32);
        v1 = 32;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.x(); // com.sec.chaton.a.ao.x -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public java.lang.String o() {
        // Registers (3 total): v2 = this
        v0 = v2.i; // com.sec.chaton.a.ao.i:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.i = v1; // com.sec.chaton.a.ao.i:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean p() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 64);
        v1 = 64;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.lang.String q() {
        // Registers (3 total): v2 = this
        v0 = v2.j; // com.sec.chaton.a.ao.j:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.j = v1; // com.sec.chaton.a.ao.j:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean r() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit16_0xd5(v0, 128);
        v1 = 128;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.lang.String s() {
        // Registers (3 total): v2 = this
        v0 = v2.k; // com.sec.chaton.a.ao.k:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.k = v1; // com.sec.chaton.a.ao.k:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean t() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit16_0xd5(v0, 256);
        v1 = 256;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.y(); // com.sec.chaton.a.ao.y -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public java.lang.String u() {
        // Registers (3 total): v2 = this
        v0 = v2.l; // com.sec.chaton.a.ao.l:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.l = v1; // com.sec.chaton.a.ao.l:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean v() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit16_0xd5(v0, 512);
        v1 = 512;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public long w() {
        // Registers (3 total): v2 = this
        v0 = v2.m; // com.sec.chaton.a.ao.m:long
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (8 total): v6 = this, v7 = p0 (com.google.protobuf.CodedOutputStream)
        v5 = 8;
        v4 = 4;
        v3 = 2;
        v2 = 1;
        _result = v6.getSerializedSize(); // com.sec.chaton.a.ao.getSerializedSize -> int
        v0 = v6.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v2) /* goto L_0013 */;
        v0 = v6.c; // com.sec.chaton.a.ao.c:long
        _result = v7.writeInt64(v2, v0, v1); // com.google.protobuf.CodedOutputStream.writeInt64 -> void
        v0 = v6.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v3) /* goto L_0022 */;
        v0 = v6.d; // com.sec.chaton.a.ao.d:com.sec.chaton.a.cp
        _result = v0.getNumber(); // com.sec.chaton.a.cp.getNumber -> int
        v0 = _result;
        _result = v7.writeEnum(v3, v0); // com.google.protobuf.CodedOutputStream.writeEnum -> void
        v0 = v6.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        if (v0 != v4) /* goto L_0032 */;
        v0 = 3;
        v1 = v6.e; // com.sec.chaton.a.ao.e:com.sec.chaton.a.ar
        _result = v1.getNumber(); // com.sec.chaton.a.ar.getNumber -> int
        v1 = _result;
        _result = v7.writeEnum(v0, v1); // com.google.protobuf.CodedOutputStream.writeEnum -> void
        v0 = v6.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        if (v0 != v5) /* goto L_003f */;
        _result = v6.z(); // com.sec.chaton.a.ao.z -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v7.writeBytes(v4, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v6.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_004f */;
        v0 = 5;
        _result = v6.A(); // com.sec.chaton.a.ao.A -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v7.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = 0;
        v1 = v6.h; // com.sec.chaton.a.ao.h:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.size(v1); // -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_0065 */;
        v1 = 6;
        v2 = v6.h; // com.sec.chaton.a.ao.h:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.getByteString(v2, v0); // -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v7.writeBytes(v1, v2); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0050
        v0 = v6.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 32);
        v1 = 32;
        if (v0 != v1) /* goto L_0075 */;
        v0 = 7;
        _result = v6.B(); // com.sec.chaton.a.ao.B -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v7.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v6.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit8_0xdd(v0, 64);
        v1 = 64;
        if (v0 != v1) /* goto L_0084 */;
        _result = v6.C(); // com.sec.chaton.a.ao.C -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v7.writeBytes(v5, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v6.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit16_0xd5(v0, 128);
        v1 = 128;
        if (v0 != v1) /* goto L_0095 */;
        v0 = 9;
        _result = v6.D(); // com.sec.chaton.a.ao.D -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v7.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v6.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit16_0xd5(v0, 256);
        v1 = 256;
        if (v0 != v1) /* goto L_00a6 */;
        v0 = 10;
        _result = v6.E(); // com.sec.chaton.a.ao.E -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v7.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v6.b; // com.sec.chaton.a.ao.b:int
        v0 = binOpLit16_0xd5(v0, 512);
        v1 = 512;
        if (v0 != v1) /* goto L_00b5 */;
        v0 = 11;
        v1 = v6.m; // com.sec.chaton.a.ao.m:long
        _result = v7.writeInt64(v0, v1, v2); // com.google.protobuf.CodedOutputStream.writeInt64 -> void
        return;
    }

    public com.sec.chaton.a.ap x() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.chaton.a.ao.newBuilder -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ap y() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.ao.a -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

}