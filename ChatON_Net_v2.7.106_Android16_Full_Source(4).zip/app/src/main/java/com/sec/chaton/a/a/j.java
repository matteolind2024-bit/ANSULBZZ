package com.sec.chaton.a.a;

/**
 * Original SourceFile: UserProfileEntry.java
 * Descriptor: Lcom/sec/chaton/a/a/j;
 */
public class j {
    private java.lang.String a;
    private java.lang.String b;
    private java.lang.String c;
    private java.lang.String d;
    private java.lang.String e;

    public j() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.lang.String a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // com.sec.chaton.a.a.j.a:java.lang.String
        return v0;
    }

    public void a(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.a = v1; // com.sec.chaton.a.a.j.a:java.lang.String
        return;
    }

    public java.lang.String b() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // com.sec.chaton.a.a.j.b:java.lang.String
        return v0;
    }

    public void b(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.b = v1; // com.sec.chaton.a.a.j.b:java.lang.String
        return;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.sec.chaton.a.a.j.c:java.lang.String
        return v0;
    }

    public void c(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.c = v1; // com.sec.chaton.a.a.j.c:java.lang.String
        return;
    }

    public java.lang.String d() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.sec.chaton.a.a.j.d:java.lang.String
        return v0;
    }

    public java.lang.String e() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.sec.chaton.a.a.j.e:java.lang.String
        return v0;
    }

}