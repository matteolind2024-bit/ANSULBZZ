package com.sec.chaton.a.a;

/**
 * Original SourceFile: DeliveryChatResultEntry.java
 * Descriptor: Lcom/sec/chaton/a/a/c;
 */
public class c {
    protected boolean a;
    protected com.sec.chaton.a.a.i b;
    protected int c;
    protected java.lang.String d;
    protected boolean e;
    protected int f;
    protected java.lang.String g;
    protected java.lang.String h;
    protected com.sec.chaton.e.s i;
    protected java.util.ArrayList j;

    public c() {
        // Registers (3 total): v2 = this
        v1 = 0;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.a = v1; // com.sec.chaton.a.a.c.a:boolean
        v0 = com.sec.chaton.a.a.i.a; // :com.sec.chaton.a.a.i
        v2.b = v0; // com.sec.chaton.a.a.c.b:com.sec.chaton.a.a.i
        v0 = 1000;
        v2.c = v0; // com.sec.chaton.a.a.c.c:int
        v0 = "";
        v2.d = v0; // com.sec.chaton.a.a.c.d:java.lang.String
        v2.e = v1; // com.sec.chaton.a.a.c.e:boolean
        v2.f = v1; // com.sec.chaton.a.a.c.f:int
        v0 = 0;
        v2.j = v0; // com.sec.chaton.a.a.c.j:java.util.ArrayList
        return;
    }

    public com.sec.chaton.a.a.b a() {
        // Registers (2 total): v1 = this
        v0 = new com.sec.chaton.a.a.b;
        _result = v0.<init>(v1); // com.sec.chaton.a.a.b.<init> -> void
        return v0;
    }

    public com.sec.chaton.a.a.c a(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.f = v1; // com.sec.chaton.a.a.c.f:int
        return v0;
    }

    public com.sec.chaton.a.a.c a(com.sec.chaton.a.a.i p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.sec.chaton.a.a.i)
        v0.b = v1; // com.sec.chaton.a.a.c.b:com.sec.chaton.a.a.i
        return v0;
    }

    public com.sec.chaton.a.a.c a(com.sec.chaton.e.s p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.sec.chaton.e.s)
        v0.i = v1; // com.sec.chaton.a.a.c.i:com.sec.chaton.e.s
        return v0;
    }

    public com.sec.chaton.a.a.c a(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.d = v1; // com.sec.chaton.a.a.c.d:java.lang.String
        return v0;
    }

    public com.sec.chaton.a.a.c a(java.util.List p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.List)
        v0 = new java.util.ArrayList;
        _result = v0.<init>(v2); // java.util.ArrayList.<init> -> void
        v1.j = v0; // com.sec.chaton.a.a.c.j:java.util.ArrayList
        return v1;
    }

    public com.sec.chaton.a.a.c a(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        v0.a = v1; // com.sec.chaton.a.a.c.a:boolean
        return v0;
    }

    public com.sec.chaton.a.a.c b(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.h = v1; // com.sec.chaton.a.a.c.h:java.lang.String
        return v0;
    }

    public com.sec.chaton.a.a.c b(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        v0.e = v1; // com.sec.chaton.a.a.c.e:boolean
        return v0;
    }

    public com.sec.chaton.a.a.c c(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.g = v1; // com.sec.chaton.a.a.c.g:java.lang.String
        return v0;
    }

}