package com.sec.chaton.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/chaton/a/ai;
 */
public interface ai extends com.google.protobuf.MessageLiteOrBuilder {
}