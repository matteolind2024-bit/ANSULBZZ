package com.sec.chaton.a.a;

/**
 * Original SourceFile: DeliveryChatResultEntry.java
 * Descriptor: Lcom/sec/chaton/a/a/b;
 */
public class b extends com.sec.chaton.a.a.f {
    private java.lang.String d;
    private boolean e;
    private int f;
    private java.util.ArrayList g;
    private java.lang.String h;
    private java.lang.String i;
    private com.sec.chaton.e.s j;

    protected b(com.sec.chaton.a.a.c p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.chaton.a.a.c)
        v0 = v3.a; // com.sec.chaton.a.a.c.a:boolean
        v1 = v3.b; // com.sec.chaton.a.a.c.b:com.sec.chaton.a.a.i
        _result = v2.<init>(v0, v1); // com.sec.chaton.a.a.f.<init> -> void
        v0 = v3.d; // com.sec.chaton.a.a.c.d:java.lang.String
        v2.d = v0; // com.sec.chaton.a.a.b.d:java.lang.String
        v0 = v3.e; // com.sec.chaton.a.a.c.e:boolean
        v2.e = v0; // com.sec.chaton.a.a.b.e:boolean
        v0 = v3.f; // com.sec.chaton.a.a.c.f:int
        v2.f = v0; // com.sec.chaton.a.a.b.f:int
        v0 = v3.g; // com.sec.chaton.a.a.c.g:java.lang.String
        v2.i = v0; // com.sec.chaton.a.a.b.i:java.lang.String
        v0 = v3.h; // com.sec.chaton.a.a.c.h:java.lang.String
        v2.h = v0; // com.sec.chaton.a.a.b.h:java.lang.String
        v0 = v3.i; // com.sec.chaton.a.a.c.i:com.sec.chaton.e.s
        v2.j = v0; // com.sec.chaton.a.a.b.j:com.sec.chaton.e.s
        v0 = new java.util.ArrayList;
        v1 = v3.j; // com.sec.chaton.a.a.c.j:java.util.ArrayList
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v2.g = v0; // com.sec.chaton.a.a.b.g:java.util.ArrayList
        return;
    }

    public boolean a() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.sec.chaton.a.a.b.e:boolean
        return v0;
    }

    public int b() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // com.sec.chaton.a.a.b.f:int
        return v0;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        v0 = v1.h; // com.sec.chaton.a.a.b.h:java.lang.String
        return v0;
    }

    public java.lang.String d() {
        // Registers (2 total): v1 = this
        v0 = v1.i; // com.sec.chaton.a.a.b.i:java.lang.String
        return v0;
    }

    public com.sec.chaton.e.s e() {
        // Registers (2 total): v1 = this
        v0 = v1.j; // com.sec.chaton.a.a.b.j:com.sec.chaton.e.s
        return v0;
    }

    public java.lang.String[] f() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.sec.chaton.a.a.b.g:java.util.ArrayList
        v1 = 0;
        v1 = new java.lang.String[][size=v1];
        _result = v0.toArray(v1); // java.util.ArrayList.toArray -> java.lang.Object[]
        v0 = _result;
        v0 = (java.lang.String[]) v0;
        return v0;
    }

}