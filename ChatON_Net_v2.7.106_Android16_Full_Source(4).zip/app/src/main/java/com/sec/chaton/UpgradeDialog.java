package com.sec.chaton;

/**
 * Original SourceFile: UpgradeDialog.java
 * Descriptor: Lcom/sec/chaton/UpgradeDialog;
 */
public class UpgradeDialog extends com.sec.chaton.base.BaseActivity {
    private final java.lang.String a;
    private android.support.v4.content.LocalBroadcastManager b;
    private android.content.BroadcastReceiver c;
    private android.content.Context d;
    private com.sec.chaton.b.b e;
    private boolean g;
    private android.widget.LinearLayout h;
    private android.widget.LinearLayout i;
    private android.widget.LinearLayout j;
    private android.widget.LinearLayout k;
    private android.widget.TextView l;
    private android.widget.TextView m;
    private android.widget.Button n;
    private android.widget.Button o;
    private boolean p;
    private boolean q;
    private boolean r;
    private int s;

    public UpgradeDialog() {
        // Registers (3 total): v2 = this
        v1 = 0;
        _result = v2.<init>(); // com.sec.chaton.base.BaseActivity.<init> -> void
        v0 = "UpgradeDialog";
        v2.a = v0; // com.sec.chaton.UpgradeDialog.a:java.lang.String
        v2.e = v1; // com.sec.chaton.UpgradeDialog.e:com.sec.chaton.b.b
        v0 = 0;
        v2.g = v0; // com.sec.chaton.UpgradeDialog.g:boolean
        v2.l = v1; // com.sec.chaton.UpgradeDialog.l:android.widget.TextView
        return;
    }

    private void a() {
        // Registers (4 total): v3 = this
        v0 = "showPasswordLockActivity";
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v3.getApplicationContext(); // com.sec.chaton.UpgradeDialog.getApplicationContext -> android.content.Context
        v0 = _result;
        _result = v0.c(); // com.sec.chaton.util.j.c -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0028 */;
        v1 = new android.content.Intent;
        v2 = com.sec.chaton.settings.ActivityPasswordLockSet.class;
        _result = v1.<init>(v0, v2); // android.content.Intent.<init> -> void
        v0 = "MODE";
        v2 = "HOME";
        _result = v1.putExtra(v0, v2); // android.content.Intent.putExtra -> android.content.Intent
        _result = v3.startActivity(v1); // com.sec.chaton.UpgradeDialog.startActivity -> void
        return;
    }

    static boolean a(com.sec.chaton.UpgradeDialog p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.UpgradeDialog)
        v0 = v1.q; // com.sec.chaton.UpgradeDialog.q:boolean
        return v0;
    }

    static int b(com.sec.chaton.UpgradeDialog p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.UpgradeDialog)
        v0 = v1.s; // com.sec.chaton.UpgradeDialog.s:int
        return v0;
    }

    private void b() {
        // Registers (5 total): v4 = this
        v3 = 8;
        v2 = 0;
        _result = this.b(); // com.sec.chaton.util.bp.b -> boolean
        v0 = _result;
        v4.q = v0; // com.sec.chaton.UpgradeDialog.q:boolean
        _result = this.a(); // com.sec.chaton.util.bp.a -> boolean
        v0 = _result;
        v4.p = v0; // com.sec.chaton.UpgradeDialog.p:boolean
        v0 = v4.k; // com.sec.chaton.UpgradeDialog.k:android.widget.LinearLayout
        _result = v0.setVisibility(v2); // android.widget.LinearLayout.setVisibility -> void
        v0 = v4.o; // com.sec.chaton.UpgradeDialog.o:android.widget.Button
        _result = v0.setVisibility(v2); // android.widget.Button.setVisibility -> void
        v0 = v4.s; // com.sec.chaton.UpgradeDialog.s:int
        v1 = com.sec.chaton.settings.AboutFragment.e; // :int
        if (v0 != v1) /* goto L_004a */;
        v0 = v4.j; // com.sec.chaton.UpgradeDialog.j:android.widget.LinearLayout
        _result = v0.setVisibility(v3); // android.widget.LinearLayout.setVisibility -> void
        v0 = v4.n; // com.sec.chaton.UpgradeDialog.n:android.widget.Button
        _result = v0.setVisibility(v2); // android.widget.Button.setVisibility -> void
        v0 = v4.n; // com.sec.chaton.UpgradeDialog.n:android.widget.Button
        v1 = new com.sec.chaton.br;
        _result = v1.<init>(v4); // com.sec.chaton.br.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v4.r; // com.sec.chaton.UpgradeDialog.r:boolean
        if (v0 == 0) /* goto L_00a6 */;
        v0 = v4.l; // com.sec.chaton.UpgradeDialog.l:android.widget.TextView
        v1 = com.sec.chaton.R.string.upgrade_dialog_critical_message; // 0x7f0c0179
        _result = v0.setText(v1); // android.widget.TextView.setText -> void
        v0 = v4.o; // com.sec.chaton.UpgradeDialog.o:android.widget.Button
        v1 = new com.sec.chaton.bv;
        _result = v1.<init>(v4); // com.sec.chaton.bv.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        return;
        v0 = v4.q; // com.sec.chaton.UpgradeDialog.q:boolean
        if (v0 == 0) /* goto L_0091 */;
        v0 = v4.p; // com.sec.chaton.UpgradeDialog.p:boolean
        if (v0 == 0) /* goto L_0091 */;
        v0 = v4.j; // com.sec.chaton.UpgradeDialog.j:android.widget.LinearLayout
        _result = v0.setVisibility(v2); // android.widget.LinearLayout.setVisibility -> void
        v0 = v4.n; // com.sec.chaton.UpgradeDialog.n:android.widget.Button
        _result = v0.setVisibility(v3); // android.widget.Button.setVisibility -> void
        v0 = com.sec.chaton.R.id.dialog_btn_apps; // 0x7f080716
        _result = v4.findViewById(v0); // com.sec.chaton.UpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.LinearLayout) v0;
        v4.h = v0; // com.sec.chaton.UpgradeDialog.h:android.widget.LinearLayout
        v0 = v4.h; // com.sec.chaton.UpgradeDialog.h:android.widget.LinearLayout
        _result = v0.setVisibility(v2); // android.widget.LinearLayout.setVisibility -> void
        v0 = v4.h; // com.sec.chaton.UpgradeDialog.h:android.widget.LinearLayout
        v1 = new com.sec.chaton.bs;
        _result = v1.<init>(v4); // com.sec.chaton.bs.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.LinearLayout.setOnClickListener -> void
        v0 = com.sec.chaton.R.id.dialog_btn_google; // 0x7f080717
        _result = v4.findViewById(v0); // com.sec.chaton.UpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.LinearLayout) v0;
        v4.i = v0; // com.sec.chaton.UpgradeDialog.i:android.widget.LinearLayout
        v0 = v4.i; // com.sec.chaton.UpgradeDialog.i:android.widget.LinearLayout
        _result = v0.setVisibility(v2); // android.widget.LinearLayout.setVisibility -> void
        v0 = v4.i; // com.sec.chaton.UpgradeDialog.i:android.widget.LinearLayout
        v1 = new com.sec.chaton.bt;
        _result = v1.<init>(v4); // com.sec.chaton.bt.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.LinearLayout.setOnClickListener -> void
        // goto L_0033
        v0 = v4.j; // com.sec.chaton.UpgradeDialog.j:android.widget.LinearLayout
        _result = v0.setVisibility(v3); // android.widget.LinearLayout.setVisibility -> void
        v0 = v4.n; // com.sec.chaton.UpgradeDialog.n:android.widget.Button
        _result = v0.setVisibility(v2); // android.widget.Button.setVisibility -> void
        v0 = v4.n; // com.sec.chaton.UpgradeDialog.n:android.widget.Button
        v1 = new com.sec.chaton.bu;
        _result = v1.<init>(v4); // com.sec.chaton.bu.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        // goto L_0033
        v0 = v4.l; // com.sec.chaton.UpgradeDialog.l:android.widget.TextView
        v1 = com.sec.chaton.R.string.upgrade_dialog_basic_message; // 0x7f0c0178
        _result = v0.setText(v1); // android.widget.TextView.setText -> void
        v0 = v4.o; // com.sec.chaton.UpgradeDialog.o:android.widget.Button
        v1 = new com.sec.chaton.bw;
        _result = v1.<init>(v4); // com.sec.chaton.bw.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        // goto L_0049
    }

    static boolean c(com.sec.chaton.UpgradeDialog p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.UpgradeDialog)
        v0 = v1.p; // com.sec.chaton.UpgradeDialog.p:boolean
        return v0;
    }

    static android.content.Context d(com.sec.chaton.UpgradeDialog p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.UpgradeDialog)
        v0 = v1.d; // com.sec.chaton.UpgradeDialog.d:android.content.Context
        return v0;
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (10 total): v8 = this, v9 = p0 (android.os.Bundle)
        v7 = com.sec.chaton.R.id.dialog_btn_yes_ics; // 0x7f080705
        v6 = com.sec.chaton.R.id.dialog_btn_yes; // 0x7f080703
        v5 = 11;
        v4 = 8;
        v3 = 0;
        _result = v8.onCreate(v9); // com.sec.chaton.base.BaseActivity.onCreate -> void
        v0 = 1;
        _result = v8.requestWindowFeature(v0); // com.sec.chaton.UpgradeDialog.requestWindowFeature -> boolean
        v0 = com.sec.chaton.R.layout.upgrade_dialog; // 0x7f03018f
        _result = v8.setContentView(v0); // com.sec.chaton.UpgradeDialog.setContentView -> void
        _result = v8.getWindow(); // com.sec.chaton.UpgradeDialog.getWindow -> android.view.Window
        v0 = _result;
        v1 = 17170445; // 0x0106000d
        _result = v0.setBackgroundDrawableResource(v1); // android.view.Window.setBackgroundDrawableResource -> void
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        if (v0 < v5) /* goto L_0029 */;
        _result = v8.setFinishOnTouchOutside(v3); // com.sec.chaton.UpgradeDialog.setFinishOnTouchOutside -> void
        v8.d = v8; // com.sec.chaton.UpgradeDialog.d:android.content.Context
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v0 = _result;
        _result = v0.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v0 = _result;
        v8.b = v0; // com.sec.chaton.UpgradeDialog.b:android.support.v4.content.LocalBroadcastManager
        v0 = new com.sec.chaton.bq;
        _result = v0.<init>(v8); // com.sec.chaton.bq.<init> -> void
        v8.c = v0; // com.sec.chaton.UpgradeDialog.c:android.content.BroadcastReceiver
        v0 = new android.content.IntentFilter;
        _result = v0.<init>(); // android.content.IntentFilter.<init> -> void
        v1 = "com.sec.chaton.ACTION_DISMISS";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        v1 = v8.b; // com.sec.chaton.UpgradeDialog.b:android.support.v4.content.LocalBroadcastManager
        v2 = v8.c; // com.sec.chaton.UpgradeDialog.c:android.content.BroadcastReceiver
        _result = com.sec.chaton.bridge.Android16Compat.registerReceiverSafe(v1, v2, v0); // android.support.v4.content.LocalBroadcastManager.registerReceiver -> void
        v0 = com.sec.chaton.R.id.dialog_message; // 0x7f080702
        _result = v8.findViewById(v0); // com.sec.chaton.UpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TextView) v0;
        v8.l = v0; // com.sec.chaton.UpgradeDialog.l:android.widget.TextView
        v0 = com.sec.chaton.R.id.dialog_title; // 0x7f080701
        _result = v8.findViewById(v0); // com.sec.chaton.UpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TextView) v0;
        v8.m = v0; // com.sec.chaton.UpgradeDialog.m:android.widget.TextView
        v0 = com.sec.chaton.R.id.layout_center; // 0x7f08007f
        _result = v8.findViewById(v0); // com.sec.chaton.UpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.LinearLayout) v0;
        v8.j = v0; // com.sec.chaton.UpgradeDialog.j:android.widget.LinearLayout
        v0 = com.sec.chaton.R.id.layout_bottom_ok_cancel; // 0x7f080718
        _result = v8.findViewById(v0); // com.sec.chaton.UpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.LinearLayout) v0;
        v8.k = v0; // com.sec.chaton.UpgradeDialog.k:android.widget.LinearLayout
        v0 = v8.k; // com.sec.chaton.UpgradeDialog.k:android.widget.LinearLayout
        v1 = com.sec.chaton.R.id.dialog_btn_no; // 0x7f080704
        _result = v0.findViewById(v1); // android.widget.LinearLayout.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v8.o = v0; // com.sec.chaton.UpgradeDialog.o:android.widget.Button
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        if (v0 >= v5) /* goto L_00c8 */;
        _result = v8.findViewById(v6); // com.sec.chaton.UpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v8.n = v0; // com.sec.chaton.UpgradeDialog.n:android.widget.Button
        v0 = v8.n; // com.sec.chaton.UpgradeDialog.n:android.widget.Button
        _result = v0.setVisibility(v3); // android.widget.Button.setVisibility -> void
        _result = v8.findViewById(v7); // com.sec.chaton.UpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        _result = v0.setVisibility(v4); // android.view.View.setVisibility -> void
        _result = v8.getIntent(); // com.sec.chaton.UpgradeDialog.getIntent -> android.content.Intent
        v0 = _result;
        v1 = "isCritical";
        _result = v0.getBooleanExtra(v1, v3); // android.content.Intent.getBooleanExtra -> boolean
        v0 = _result;
        v8.r = v0; // com.sec.chaton.UpgradeDialog.r:boolean
        _result = v8.getIntent(); // com.sec.chaton.UpgradeDialog.getIntent -> android.content.Intent
        v0 = _result;
        v1 = "which_service";
        _result = v0.getIntExtra(v1, v3); // android.content.Intent.getIntExtra -> int
        v0 = _result;
        v8.s = v0; // com.sec.chaton.UpgradeDialog.s:int
        v0 = v8.s; // com.sec.chaton.UpgradeDialog.s:int
        v1 = com.sec.chaton.settings.AboutFragment.d; // :int
        if (v0 != v1) /* goto L_00dd */;
        v0 = v8.m; // com.sec.chaton.UpgradeDialog.m:android.widget.TextView
        v1 = com.sec.chaton.R.string.chaton_voice_video_chat; // 0x7f0c0574
        _result = v0.setText(v1); // android.widget.TextView.setText -> void
        _result = v8.b(); // com.sec.chaton.UpgradeDialog.b -> void
        return;
        _result = v8.findViewById(v7); // com.sec.chaton.UpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v8.n = v0; // com.sec.chaton.UpgradeDialog.n:android.widget.Button
        v0 = v8.n; // com.sec.chaton.UpgradeDialog.n:android.widget.Button
        _result = v0.setVisibility(v3); // android.widget.Button.setVisibility -> void
        _result = v8.findViewById(v6); // com.sec.chaton.UpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        _result = v0.setVisibility(v4); // android.view.View.setVisibility -> void
        // goto L_009e
        v0 = v8.s; // com.sec.chaton.UpgradeDialog.s:int
        v1 = com.sec.chaton.settings.AboutFragment.e; // :int
        if (v0 != v1) /* goto L_00c4 */;
        v0 = v8.m; // com.sec.chaton.UpgradeDialog.m:android.widget.TextView
        v1 = com.sec.chaton.R.string.registration_samsung_push_service; // 0x7f0c0479
        _result = v0.setText(v1); // android.widget.TextView.setText -> void
        // goto L_00c4
    }

    protected void onDestroy() {
        // Registers (3 total): v2 = this
        _result = v2.onDestroy(); // com.sec.chaton.base.BaseActivity.onDestroy -> void
        v0 = "check_upgrade_do_not_show";
        v1 = v2.g; // com.sec.chaton.UpgradeDialog.g:boolean
        _result = v1.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.util.r.a -> void
        v0 = v2.b; // com.sec.chaton.UpgradeDialog.b:android.support.v4.content.LocalBroadcastManager
        v1 = v2.c; // com.sec.chaton.UpgradeDialog.c:android.content.BroadcastReceiver
        _result = v0.unregisterReceiver(v1); // android.support.v4.content.LocalBroadcastManager.unregisterReceiver -> void
        v0 = v2.d; // com.sec.chaton.UpgradeDialog.d:android.content.Context
        if (v0 == 0) /* goto L_002a */;
        v0 = v2.e; // com.sec.chaton.UpgradeDialog.e:com.sec.chaton.b.b
        if (v0 == 0) /* goto L_002a */;
        v0 = v2.e; // com.sec.chaton.UpgradeDialog.e:com.sec.chaton.b.b
        _result = v0.isShowing(); // com.sec.chaton.b.b.isShowing -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002a */;
        v0 = v2.e; // com.sec.chaton.UpgradeDialog.e:com.sec.chaton.b.b
        _result = v0.dismiss(); // com.sec.chaton.b.b.dismiss -> void
        return;
    }

    public boolean onKeyDown(int p0, android.view.KeyEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (android.view.KeyEvent)
        v0 = 4;
        if (v2 != v0) /* goto L_0005 */;
        v0 = 1;
        return v0;
        _result = v1.onKeyDown(v2, v3); // com.sec.chaton.base.BaseActivity.onKeyDown -> boolean
        v0 = _result;
        // goto L_0004
    }

    protected void onResume() {
        // Registers (1 total): v0 = this
        _result = v0.onResume(); // com.sec.chaton.base.BaseActivity.onResume -> void
        _result = v0.a(); // com.sec.chaton.UpgradeDialog.a -> void
        return;
    }

}