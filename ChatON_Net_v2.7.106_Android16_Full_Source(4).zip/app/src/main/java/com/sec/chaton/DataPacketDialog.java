package com.sec.chaton;

/**
 * Original SourceFile: DataPacketDialog.java
 * Descriptor: Lcom/sec/chaton/DataPacketDialog;
 */
public class DataPacketDialog extends android.app.Activity {
    private android.widget.Button a;
    private android.widget.CheckBox b;
    private android.widget.LinearLayout c;

    public DataPacketDialog() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.app.Activity.<init> -> void
        return;
    }

    static android.widget.CheckBox a(com.sec.chaton.DataPacketDialog p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.DataPacketDialog)
        v0 = v1.b; // com.sec.chaton.DataPacketDialog.b:android.widget.CheckBox
        return v0;
    }

    private void a() {
        // Registers (4 total): v3 = this
        v0 = "showPasswordLockActivity";
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v3.getApplicationContext(); // com.sec.chaton.DataPacketDialog.getApplicationContext -> android.content.Context
        v0 = _result;
        _result = v0.c(); // com.sec.chaton.util.j.c -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0028 */;
        v1 = new android.content.Intent;
        v2 = com.sec.chaton.settings.ActivityPasswordLockSet.class;
        _result = v1.<init>(v0, v2); // android.content.Intent.<init> -> void
        v0 = "MODE";
        v2 = "HOME";
        _result = v1.putExtra(v0, v2); // android.content.Intent.putExtra -> android.content.Intent
        _result = v3.startActivity(v1); // com.sec.chaton.DataPacketDialog.startActivity -> void
        return;
    }

    public void onConfigurationChanged(android.content.res.Configuration p0) {
        // Registers (10 total): v8 = this, v9 = p0 (android.content.res.Configuration)
        v7 = 0x3f000000;
        _result = v8.onConfigurationChanged(v9); // android.app.Activity.onConfigurationChanged -> void
        v0 = com.sec.chaton.R.id.attentionDialog; // 0x7f0800f0
        _result = v8.findViewById(v0); // com.sec.chaton.DataPacketDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.LinearLayout) v0;
        _result = v0.getLayoutParams(); // android.widget.LinearLayout.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v1 = _result;
        v2 = new android.widget.FrameLayout$LayoutParams;
        _result = v2.<init>(v1); // android.widget.FrameLayout$LayoutParams.<init> -> void
        v1 = 0;
        v3 = 0x40a00000;
        _result = v3.a(); // com.sec.chaton.util.ad.a -> float
        v3 = _result;
        v3 = unaryOp_0x87(v3);
        _result = v8.getApplicationContext(); // com.sec.chaton.DataPacketDialog.getApplicationContext -> android.content.Context
        v4 = _result;
        _result = v4.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v4 = _result;
        _result = v4.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v4 = _result;
        v4 = v4.density; // android.util.DisplayMetrics.density:float
        v5 = v9.orientation; // android.content.res.Configuration.orientation:int
        v6 = 2;
        if (v5 != v6) /* goto L_0044 */;
        v1 = 0x43b40000;
        v1 = binOp2addr_0xc8(v1, v4);
        v1 = binOp2addr_0xc6(v1, v7);
        v1 = unaryOp_0x87(v1);
        v2.width = v1; // android.widget.FrameLayout$LayoutParams.width:int
        _result = v2.setMargins(v3, v3, v3, v3); // android.widget.FrameLayout$LayoutParams.setMargins -> void
        v1 = 17;
        v2.gravity = v1; // android.widget.FrameLayout$LayoutParams.gravity:int
        _result = v0.setLayoutParams(v2); // android.widget.LinearLayout.setLayoutParams -> void
        return;
        v5 = v9.orientation; // android.content.res.Configuration.orientation:int
        v6 = 1;
        if (v5 != v6) /* goto L_0037 */;
        v1 = 0x43a00000;
        v1 = binOp2addr_0xc8(v1, v4);
        v1 = binOp2addr_0xc6(v1, v7);
        v1 = unaryOp_0x87(v1);
        // goto L_0037
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (12 total): v10 = this, v11 = p0 (android.os.Bundle)
        v9 = 0x3f000000;
        v8 = 1;
        v2 = 0;
        _result = v10.onCreate(v11); // android.app.Activity.onCreate -> void
        _result = v10.requestWindowFeature(v8); // com.sec.chaton.DataPacketDialog.requestWindowFeature -> boolean
        v0 = com.sec.chaton.R.layout.data_packet_dialog; // 0x7f03005c
        _result = v10.setContentView(v0); // com.sec.chaton.DataPacketDialog.setContentView -> void
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_0019 */;
        _result = v10.setFinishOnTouchOutside(v2); // com.sec.chaton.DataPacketDialog.setFinishOnTouchOutside -> void
        _result = v10.getWindow(); // com.sec.chaton.DataPacketDialog.getWindow -> android.view.Window
        v0 = _result;
        v1 = -1;
        v3 = -2;
        _result = v0.setLayout(v1, v3); // android.view.Window.setLayout -> void
        v0 = com.sec.chaton.R.id.attentionDialog; // 0x7f0800f0
        _result = v10.findViewById(v0); // com.sec.chaton.DataPacketDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.LinearLayout) v0;
        _result = v0.getLayoutParams(); // android.widget.LinearLayout.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v1 = _result;
        v3 = new android.widget.FrameLayout$LayoutParams;
        _result = v3.<init>(v1); // android.widget.FrameLayout$LayoutParams.<init> -> void
        _result = v10.getResources(); // com.sec.chaton.DataPacketDialog.getResources -> android.content.res.Resources
        v1 = _result;
        _result = v1.getConfiguration(); // android.content.res.Resources.getConfiguration -> android.content.res.Configuration
        v1 = _result;
        v4 = 0x40a00000;
        _result = v4.a(); // com.sec.chaton.util.ad.a -> float
        v4 = _result;
        v4 = unaryOp_0x87(v4);
        _result = v10.getApplicationContext(); // com.sec.chaton.DataPacketDialog.getApplicationContext -> android.content.Context
        v5 = _result;
        _result = v5.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v5 = _result;
        _result = v5.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v5 = _result;
        v5 = v5.density; // android.util.DisplayMetrics.density:float
        v6 = v1.orientation; // android.content.res.Configuration.orientation:int
        v7 = 2;
        if (v6 != v7) /* goto L_00a7 */;
        v1 = 0x43b40000;
        v1 = binOp2addr_0xc8(v1, v5);
        v1 = binOp2addr_0xc6(v1, v9);
        v1 = unaryOp_0x87(v1);
        v3.width = v1; // android.widget.FrameLayout$LayoutParams.width:int
        _result = v3.setMargins(v4, v4, v4, v4); // android.widget.FrameLayout$LayoutParams.setMargins -> void
        v1 = 17;
        v3.gravity = v1; // android.widget.FrameLayout$LayoutParams.gravity:int
        _result = v0.setLayoutParams(v3); // android.widget.LinearLayout.setLayoutParams -> void
        v0 = com.sec.chaton.R.id.data_packet_ok; // 0x7f080242
        _result = v10.findViewById(v0); // com.sec.chaton.DataPacketDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v10.a = v0; // com.sec.chaton.DataPacketDialog.a:android.widget.Button
        v0 = com.sec.chaton.R.id.data_packet_chekcbox; // 0x7f08022a
        _result = v10.findViewById(v0); // com.sec.chaton.DataPacketDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.CheckBox) v0;
        v10.b = v0; // com.sec.chaton.DataPacketDialog.b:android.widget.CheckBox
        v0 = com.sec.chaton.R.id.linear_packet_chekcbox; // 0x7f080229
        _result = v10.findViewById(v0); // com.sec.chaton.DataPacketDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.LinearLayout) v0;
        v10.c = v0; // com.sec.chaton.DataPacketDialog.c:android.widget.LinearLayout
        v0 = v10.c; // com.sec.chaton.DataPacketDialog.c:android.widget.LinearLayout
        v1 = new com.sec.chaton.n;
        _result = v1.<init>(v10); // com.sec.chaton.n.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.LinearLayout.setOnClickListener -> void
        v0 = v10.c; // com.sec.chaton.DataPacketDialog.c:android.widget.LinearLayout
        _result = v0.setFocusable(v8); // android.widget.LinearLayout.setFocusable -> void
        v0 = v10.b; // com.sec.chaton.DataPacketDialog.b:android.widget.CheckBox
        _result = v0.setClickable(v2); // android.widget.CheckBox.setClickable -> void
        v0 = v10.a; // com.sec.chaton.DataPacketDialog.a:android.widget.Button
        v1 = new com.sec.chaton.o;
        _result = v1.<init>(v10); // com.sec.chaton.o.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        return;
        v1 = v1.orientation; // android.content.res.Configuration.orientation:int
        if (v1 != v8) /* goto L_00b1 */;
        v1 = 0x43a00000;
        v1 = binOp2addr_0xc8(v1, v5);
        v1 = binOp2addr_0xc6(v1, v9);
        v1 = unaryOp_0x87(v1);
        // goto L_005b
        v1 = v2;
        // goto L_005b
    }

    protected void onResume() {
        // Registers (1 total): v0 = this
        _result = v0.onResume(); // android.app.Activity.onResume -> void
        _result = v0.a(); // com.sec.chaton.DataPacketDialog.a -> void
        return;
    }

    protected void onUserLeaveHint() {
        // Registers (3 total): v2 = this
        v0 = "onUserLeaveHint";
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v2.getApplicationContext(); // com.sec.chaton.DataPacketDialog.getApplicationContext -> android.content.Context
        v0 = _result;
        _result = v0.b(); // com.sec.chaton.util.j.b -> void
        return;
    }

}