package com.sec.chaton.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/chaton/a/ac;
 */
public interface ac extends com.google.protobuf.MessageLiteOrBuilder {
}