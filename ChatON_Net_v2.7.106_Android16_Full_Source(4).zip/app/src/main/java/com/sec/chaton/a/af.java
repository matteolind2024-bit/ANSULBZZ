package com.sec.chaton.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/chaton/a/af;
 */
public interface af extends com.google.protobuf.MessageLiteOrBuilder {
}