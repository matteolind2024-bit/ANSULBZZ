package com.sec.chaton.bridge;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

import com.sec.chaton.e.al;
import com.sec.chaton.trunk.database.a.b;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

/**
 * ============================================================================
 * MockEnvironmentSeeder — Rich Interactive SQLite Seeder for ChatON v2.7.106
 * ============================================================================
 * Tailored to ChatON v2.7.106's exact SQLite schema (chaton.db v73 & trunk.db v6):
 *   - 10 Buddies in @name@node format with status messages & interaction ranks
 *   - 4 Buddy Groups (Favorites + 3 ChatON Buddy Groups)
 *   - 5 Active Chat Rooms including bilingual In-Bubble Translated messages
 *     (matching the Korean/English/Persian translated 3D bubbles with speaker icon!)
 *   - @web@r-rss Free Web Proxy Bot Channel
 *   - Trunk shared items & comments (cubic 3D Trunk icon in header)
 *   - PostON profile wall entries & Live Echo SQLite Triggers
 */
public final class MockEnvironmentSeeder {
    private static final String TAG = "ChatON27_MockSeeder";
    private static volatile boolean sSeeded = false;
    private static final AtomicLong MSG_ID_GEN = new AtomicLong(500000L);

    private MockEnvironmentSeeder() {}

    public static synchronized void seedAllIfNeeded(Context context) {
        if (sSeeded || context == null) {
            return;
        }
        sSeeded = true;
        try {
            SQLiteDatabase chatDb = al.a(context).getWritableDatabase();
            seedBuddiesAndCircles(chatDb);
            seedChatRoomsAndMessages(context, chatDb);
            seedPostONAndTriggers(chatDb);

            SQLiteDatabase trunkDb = b.a().getWritableDatabase();
            seedTrunkItems(context, trunkDb);

            notifyAllProviders(context);
            Log.i(TAG, "Successfully seeded ChatON v2.7.106 skeuomorphic interactive environment.");
        } catch (Throwable t) {
            Log.e(TAG, "Error seeding mock environment: " + t.getMessage(), t);
        }
    }

    private static void seedBuddiesAndCircles(SQLiteDatabase db) {
        long now = System.currentTimeMillis();
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(now));

        Object[][] buddies = new Object[][]{
            {"@claire@chaton (Claire Bennett)",     "Ara Rostami",             "[PC5 Mesh Online] Signal -62dBm | Hop 1",          "+989121110001", 45, 52, 1},
            {"@liam@chaton (Liam Brooks)",      "Navid Kiani",             "ProSe Direct Relay Active | Teh-North",             "+989121110002", 38, 41, 2},
            {"@emma@chaton (Emma Collins)",    "Sara Moradi",             "Syncing Leftovers via ChatON-Net Local Engine",          "+989121110003", 30, 35, 3},
            {"@noah@chaton (Noah Vance)",    "Kiarash Awan",            "eBPF Packet Filter + Netty 5223 Bridge",            "+989121110004", 28, 29, 4},
            {"@mahsa@chaton.local",   "Mahsa Tehrani",           "Circles Crypto Key Verified [Ed25519]",             "+989121110005", 22, 26, 5},
            {"@reza@pc5.mesh",       "Reza Pahlevan",           "LTE-Direct / Sidelink PC5 Band 47",                 "+989121110006", 19, 20, 6},
            {"@nima@chaton.local",    "Nima Farhadi",            "r-RSS Feed Aggregator Node #4",                     "+989121110007", 15, 18, 7},
            {"@taraneh@chaton.local", "Taraneh Alavi",           "Sharing Photos in 3D Trunk [Offline Mode]",         "+989121110008", 12, 14, 8},
            {"@parsa@pc5.mesh",      "ParsaV",                  "Android 16 Baklava 16KB Kernel Tester",             "+989121110009", 10, 11, 9},
            {"@web@r-rss",           "r-RSS Free Web Proxy",    "[BOT] Send any URL or keyword to crawl via r-RSS",  "+989120009999", 60, 65, 1}
        };

        db.beginTransaction();
        try {
            for (Object[] b : buddies) {
                String buddyNo = (String) b[0];
                String name = (String) b[1];
                String status = (String) b[2];
                String phone = (String) b[3];
                int sent = (Integer) b[4];
                int recv = (Integer) b[5];
                int rank = (Integer) b[6];

                ContentValues cv = new ContentValues();
                cv.put("buddy_no", buddyNo);
                cv.put("buddy_name", name);
                cv.put("buddy_status_message", status);
                cv.put("buddy_email", buddyNo.substring(1));
                cv.put("buddy_samsung_email", buddyNo.substring(1));
                cv.put("buddy_orginal_number", phone);
                cv.put("buddy_birthday", "1995-05-14");
                cv.put("buddy_msg_send", Integer.valueOf(sent));
                cv.put("buddy_msg_received", Integer.valueOf(recv));
                cv.put("buddy_relation_hide", "N");
                cv.put("buddy_raw_contact_id", Integer.valueOf(0));
                cv.put("buddy_push_name", name);
                cv.put("buddy_is_new", "N");
                cv.put("buddy_profile_status", Integer.valueOf(0));
                cv.put("buddy_is_profile_updated", "N");
                cv.put("buddy_is_status_updated", "N");
                cv.put("buddy_show_phone_number", Integer.valueOf(1));
                cv.put("buddy_extra_info", "ChatON-Net LocalBridge v2.7");
                cv.put("buddy_is_name_updated", "N");
                cv.put("buddy_updated_timestamp", String.valueOf(now));
                cv.put("buddy_multidevice", "Y");
                cv.put("buddy_sainfo", "chaton_mesh_verified");
                cv.put("buddy_account_info", Integer.valueOf(1));
                cv.put("buddy_original_name", name);
                cv.put("buddy_using_contact_name", "N");
                db.insertWithOnConflict("buddy", null, cv, SQLiteDatabase.CONFLICT_REPLACE);

                ContentValues rel = new ContentValues();
                rel.put("relation_buddy_id", buddyNo);
                rel.put("relation_date", today);
                rel.put("relation_send", Integer.valueOf(sent));
                rel.put("relation_received", Integer.valueOf(recv));
                rel.put("relation_point", Integer.valueOf(sent + recv));
                rel.put("relation_icon", Integer.valueOf(rank <= 3 ? 3 : 2));
                rel.put("relation_increase", Integer.valueOf(5));
                rel.put("relation_rank", Integer.valueOf(rank));
                rel.put("relation_last_msg_time", String.valueOf(now));
                db.insertWithOnConflict("relation", null, rel, SQLiteDatabase.CONFLICT_REPLACE);
            }

            Object[][] groups = new Object[][]{
                {Integer.valueOf(1), "Favorites",                    Integer.valueOf(1)},
                {Integer.valueOf(2), "Circle: ChatON Core Devs",     Integer.valueOf(2)},
                {Integer.valueOf(3), "Circle: PC5 Sidelink Mesh",    Integer.valueOf(2)},
                {Integer.valueOf(4), "Circle: r-RSS & Leftovers",    Integer.valueOf(2)}
            };
            for (Object[] g : groups) {
                ContentValues gcv = new ContentValues();
                gcv.put("_id", (Integer) g[0]);
                gcv.put("group_name", (String) g[1]);
                gcv.put("group_type", (Integer) g[2]);
                gcv.put("group_is_new", "N");
                db.insertWithOnConflict("buddy_group", null, gcv, SQLiteDatabase.CONFLICT_REPLACE);
            }

            String[][] groupMembers = new String[][]{
                {"1", "@claire@chaton (Claire Bennett)"}, {"1", "@liam@chaton (Liam Brooks)"}, {"1", "@emma@chaton (Emma Collins)"}, {"1", "@web@r-rss"},
                {"2", "@claire@chaton (Claire Bennett)"}, {"2", "@noah@chaton (Noah Vance)"}, {"2", "@parsa@pc5.mesh"},
                {"3", "@liam@chaton (Liam Brooks)"}, {"3", "@reza@pc5.mesh"}, {"3", "@mahsa@chaton.local"},
                {"4", "@web@r-rss"}, {"4", "@nima@chaton.local"}, {"4", "@taraneh@chaton.local"}, {"4", "@emma@chaton (Emma Collins)"}
            };
            for (String[] gm : groupMembers) {
                ContentValues gr = new ContentValues();
                gr.put("group_relation_group", gm[0]);
                gr.put("group_relation_buddy", gm[1]);
                db.insertWithOnConflict("grouprelation", null, gr, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private static void seedChatRoomsAndMessages(Context context, SQLiteDatabase db) {
        long now = System.currentTimeMillis();

        db.beginTransaction();
        try {
            // Room 1: 1:1 Chat with @claire@chaton (Claire Bennett) (with In-Bubble Bilingual Translation enabled like Screenshot 1!)
            createRoom(
                    db,
                    "inbox_claire_dm",
                    "sess_chaton_ara",
                    0,
                    "Ara Rostami",
                    "The 9-patch quote card and Anicon stickers look super crisp on Android 16!",
                    now - 60000L,
                    0,
                    "Y",
                    new String[][]{{"@claire@chaton (Claire Bennett)", "Ara Rostami"}}
            );
            insertMsg(db, 1001L, "inbox_claire_dm", "sess_chaton_ara", 0, 2, "@claire@chaton (Claire Bennett)",
                    "Hey! Welcome back to Samsung ChatON 2.7 with classic TouchWiz Nature UX bubbles!",
                    "Hi Martin! This is v2.7 with dual-side profile frames and 3D bubbles!",
                    now - 180000L);
            insertMsg(db, 1002L, "inbox_claire_dm", "sess_chaton_ara", 0, 1, AutoProvisioner.LOCAL_CHATON_ID,
                    "Thanks Claire! The 3D Trunk icon and in-bubble quoted replies look awesome.",
                    "Awesome! The 3D cubic Trunk icon and in-bubble translation are right here.",
                    now - 120000L);
            insertMsg(db, 1004L, "inbox_claire_dm", "sess_chaton_ara", 0, 2, "@claire@chaton (Claire Bennett)",
                    "The 9-patch quote card and Anicon stickers look super crisp on Android 16!",
                    "42-byte ChatON protocol tested over local PC5 socket, ping is under 4ms!",
                    now - 60000L);

            // Room 2: Group Chat — ChatON Core Architecture
            createRoom(
                    db,
                    "inbox_core_team_group_",
                    "sess_chaton_core_group",
                    1,
                    "ChatON Core Architecture",
                    "Noah Vance: All SQLite triggers and quoted reply bubbles are running smoothly.",
                    now - 120000L,
                    2,
                    "N",
                    new String[][]{
                        {"@claire@chaton (Claire Bennett)", "Ara Rostami"},
                        {"@noah@chaton (Noah Vance)", "Kiarash Awan"},
                        {"@parsa@pc5.mesh", "ParsaV"}
                    }
            );
            insertMsg(db, 2002L, "inbox_core_team_group_", "sess_chaton_core_group", 0, 2, "@parsa@pc5.mesh",
                    "16KB page alignment for all native libraries has been verified on Android 16.", null, now - 240000L);
            insertMsg(db, 2004L, "inbox_core_team_group_", "sess_chaton_core_group", 0, 2, "@noah@chaton (Noah Vance)",
                    "All SQLite triggers and quoted reply bubbles are running smoothly.", null, now - 120000L);

            // Room 3: Special Channel @web@r-rss (Decentralized Web Crawler & RSS Proxy)
            createRoom(
                    db,
                    "inbox_rrss_channel",
                    "sess_rrss_channel",
                    0,
                    "@web@r-rss (Free Web Proxy)",
                    "[Tech Digest] Send any keyword or URL to get an instant summary.",
                    now - 30000L,
                    1,
                    "N",
                    new String[][]{{"@web@r-rss", "r-RSS Free Web Proxy"}}
            );
            insertMsg(db, 3002L, "inbox_rrss_channel", "sess_rrss_channel", 0, 1, AutoProvisioner.LOCAL_CHATON_ID,
                    "fetch https://news.ycombinator.com/rss", null, now - 90000L);
            insertMsg(db, 3003L, "inbox_rrss_channel", "sess_rrss_channel", 0, 2, "@web@r-rss",
                    "[r-RSS Digest #402]
1. Mesh Networking over LTE/NR PC5 Sidelink
2. Rebuilding Classic Skeuomorphic Android Messengers for API 36
Send any keyword or URL to get an instant summary.",
                    null, now - 30000L);

            // Room 4: 1:1 Chat with @emma@chaton (Emma Collins) (Trunk & Leftovers Media)
            createRoom(
                    db,
                    "inbox_emma_chat_",
                    "sess_chaton_sara",
                    0,
                    "Sara Moradi",
                    "I just uploaded the new UI mockups and photos to the Trunk in this chat!",
                    now - 200000L,
                    0,
                    "N",
                    new String[][]{{"@emma@chaton (Emma Collins)", "Sara Moradi"}}
            );
            insertMsg(db, 4002L, "inbox_emma_chat_", "sess_chaton_sara", 0, 2, "@emma@chaton (Emma Collins)",
                    "I just uploaded the new UI mockups and photos to the Trunk in this chat!", null, now - 200000L);

            // Room 5: Group Chat — PC5 Sidelink Field Test
            createRoom(
                    db,
                    "inbox_pc5_mesh_ops",
                    "sess_pc5_mesh_ops",
                    1,
                    "PC5 Field Test Node",
                    "Liam Brooks: The latest build passed all verification checks with zero errors.",
                    now - 360000L,
                    0,
                    "N",
                    new String[][]{
                        {"@liam@chaton (Liam Brooks)", "Navid Kiani"},
                        {"@reza@pc5.mesh", "Reza Pahlevan"},
                        {"@mahsa@chaton.local", "Mahsa Tehrani"}
                    }
            );
            insertMsg(db, 5002L, "inbox_pc5_mesh_ops", "sess_pc5_mesh_ops", 0, 2, "@liam@chaton (Liam Brooks)",
                    "The latest build passed all verification checks with zero errors.", null, now - 360000L);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private static void createRoom(
            SQLiteDatabase db,
            String inboxNo,
            String sessionId,
            int chatType,
            String title,
            String lastMsg,
            long lastTime,
            int unreadCount,
            String enableTranslate,
            String[][] members) {
        ContentValues icv = new ContentValues();
        icv.put("inbox_no", inboxNo);
        icv.put("inbox_chat_type", Integer.valueOf(chatType));
        icv.put("inbox_unread_count", Integer.valueOf(unreadCount));
        icv.put("inbox_last_message", lastMsg);
        icv.put("inbox_title", title);
        icv.put("inbox_last_time", Long.valueOf(lastTime));
        icv.put("inbox_translated", enableTranslate);
        icv.put("inbox_enable_translate", enableTranslate);
        icv.put("inbox_translate_my_language", "en");
        icv.put("inbox_translate_buddy_language", "fa");
        icv.put("inbox_server_ip", "127.0.0.1");
        icv.put("inbox_server_port", Integer.valueOf(5223));
        icv.put("inbox_participants", String.valueOf(members.length));
        icv.put("inbox_session_id", sessionId);
        icv.put("inbox_last_msg_no", Long.valueOf(lastTime));
        icv.put("inbox_last_msg_sender", members[0][0]);
        icv.put("inbox_title_fixed", "Y");
        icv.put("inbox_last_chat_type", Integer.valueOf(11));
        icv.put("inbox_last_temp_msg", "");
        icv.put("inbox_is_new", "N");
        icv.put("inbox_trunk_unread_count", Integer.valueOf(2));
        icv.put("inbox_valid", "Y");
        icv.put("inbox_enable_noti", "Y");
        icv.put("inbox_last_timestamp", Long.valueOf(lastTime));
        icv.put("profile_url", "NA");
        db.insertWithOnConflict("inbox", null, icv, SQLiteDatabase.CONFLICT_REPLACE);

        for (String[] m : members) {
            ContentValues pcv = new ContentValues();
            pcv.put("participants_inbox_no", inboxNo);
            pcv.put("participants_buddy_no", m[0]);
            pcv.put("participants_buddy_name", m[1]);
            pcv.put("participants_country_code", "IR");
            pcv.put("participants_is_auth", "Y");
            pcv.put("participants_status", Integer.valueOf(0));
            db.insertWithOnConflict("participant", null, pcv, SQLiteDatabase.CONFLICT_REPLACE);

            ContentValues ib = new ContentValues();
            ib.put("inbox_no", inboxNo);
            ib.put("buddy_no", m[0]);
            ib.put("chat_type", Integer.valueOf(chatType));
            db.insertWithOnConflict("inbox_buddy_relation", null, ib, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    private static void insertMsg(
            SQLiteDatabase db,
            long id,
            String inboxNo,
            String sessionId,
            int contentType,
            int msgType,
            String sender,
            String content,
            String translatedContent,
            long timestamp) {
        String timeText = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(timestamp));
        ContentValues mcv = new ContentValues();
        mcv.put("_id", Long.valueOf(id));
        mcv.put("message_sever_id", Long.valueOf(id));
        mcv.put("message_inbox_no", inboxNo);
        mcv.put("message_session_id", sessionId);
        mcv.put("message_read_status", Integer.valueOf(1));
        mcv.put("message_content_type", Integer.valueOf(contentType));
        mcv.put("message_time", Long.valueOf(timestamp));
        mcv.put("message_content", content);
        if (translatedContent != null) {
            mcv.put("message_translated", "Y");
            mcv.put("message_content_translated", translatedContent);
            mcv.put("message_from_lang", "fa");
            mcv.put("message_to_lang", "en");
            mcv.put("message_is_spoken", "Y");
        }
        mcv.put("message_type", Integer.valueOf(msgType));
        mcv.put("message_sender", sender);
        mcv.put("message_tid", String.valueOf(id));
        mcv.put("message_time_text", timeText);
        mcv.put("message_stored_ext", Integer.valueOf(1));
        mcv.put("message_need_update", "N");
        mcv.put("message_is_failed", Integer.valueOf(0));
        db.insertWithOnConflict("message", null, mcv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    private static void seedTrunkItems(Context context, SQLiteDatabase trunkDb) {
        long now = System.currentTimeMillis();
        String pkg = context.getPackageName();
        String thumbUri = "android.resource://" + pkg + "/drawable/icon";

        String[] sessions = new String[]{
            "sess_chaton_ara",
            "sess_chaton_core_group",
            "sess_rrss_channel",
            "sess_chaton_sara",
            "sess_pc5_mesh_ops"
        };

        trunkDb.beginTransaction();
        try {
            int idx = 1;
            for (String sess : sessions) {
                ContentValues tcv = new ContentValues();
                tcv.put("session_id", sess);
                tcv.put("last_update_time", Long.valueOf(now - 60000L));
                tcv.put("last_comment_time", Long.valueOf(now - 30000L));
                tcv.put("total_item_count", Integer.valueOf(2));
                tcv.put("unread_item_count", Integer.valueOf(0));
                tcv.put("unread_comment_count", Integer.valueOf(0));
                trunkDb.insertWithOnConflict("trunk", null, tcv, SQLiteDatabase.CONFLICT_REPLACE);

                String itemId = "leftover_item_" + idx;
                ContentValues icv = new ContentValues();
                icv.put("item_id", itemId);
                icv.put("session_id", sess);
                icv.put("sender_uid", "@emma@chaton (Emma Collins)");
                icv.put("sender_name", "Sara Moradi");
                icv.put("sender_number", "+989121110003");
                icv.put("registration_time", Long.valueOf(now - 120000L));
                icv.put("last_comment_time", Long.valueOf(now - 30000L));
                icv.put("total_comment_count", Integer.valueOf(1));
                icv.put("unread_comment_count", Integer.valueOf(0));
                icv.put("item_description", "[ChatON Leftovers] Shared offline media in " + sess);
                icv.put("thumbnail", thumbUri);
                icv.put("down_url", thumbUri);
                icv.put("content_type", "image/png");
                icv.put("isams", "false");
                icv.put("item_type", Integer.valueOf(1));
                trunkDb.insertWithOnConflict("trunk_item", null, icv, SQLiteDatabase.CONFLICT_REPLACE);

                ContentValues ccv = new ContentValues();
                ccv.put("item_id", itemId);
                ccv.put("comment_id", "cmt_" + itemId);
                ccv.put("registration_time", Long.valueOf(now - 30000L));
                ccv.put("writer_uid", "@claire@chaton (Claire Bennett)");
                ccv.put("writer_name", "Ara Rostami");
                ccv.put("writer_number", "+989121110001");
                ccv.put("content", "Looks awesome! Love the classic TouchWiz design!");
                trunkDb.insertWithOnConflict("trunk_comment", null, ccv, SQLiteDatabase.CONFLICT_REPLACE);
                idx++;
            }
            trunkDb.setTransactionSuccessful();
        } finally {
            trunkDb.endTransaction();
        }
    }

    private static void seedPostONAndTriggers(SQLiteDatabase db) {
        long now = System.currentTimeMillis();
        db.beginTransaction();
        try {
            ContentValues p1 = new ContentValues();
            p1.put("buddy_no", AutoProvisioner.LOCAL_CHATON_ID);
            p1.put("buddy_name", AutoProvisioner.LOCAL_PUSH_NAME);
            p1.put("poston", "Welcome to my PostON wall on Samsung ChatON v2.7! Feel free to leave a note.");
            p1.put("isread", "Y");
            p1.put("unread_comment_count", "0");
            p1.put("read_comment_count", "1");
            p1.put("timestamp", String.valueOf(now - 60000L));
            db.insertWithOnConflict("poston", null, p1, SQLiteDatabase.CONFLICT_REPLACE);

            db.execSQL(
                "CREATE TRIGGER IF NOT EXISTS chaton_live_trg AFTER INSERT ON message WHEN NEW.message_type = 0 BEGIN " +
                "UPDATE message SET message_type = 1, message_is_failed = 0, message_read_status = 1 WHERE _id = NEW._id; " +
                "INSERT INTO message (_id, message_sever_id, message_inbox_no, message_session_id, message_read_status, message_content_type, message_time, message_content, message_translated, message_content_translated, message_from_lang, message_to_lang, message_is_spoken, message_type, message_sender, message_tid, message_time_text, message_stored_ext, message_need_update, message_is_failed) " +
                "VALUES (NEW._id + 1, NEW._id + 1, NEW.message_inbox_no, COALESCE(NEW.message_session_id, 'sess_chaton_live'), 1, 0, NEW.message_time + 1000, " +
                "CASE WHEN NEW.message_inbox_no LIKE '%rrss%' THEN '[r-RSS Live Crawl] ChatON ChatON ChatON ChatON «' || NEW.message_content || '»:
• ChatON: PC5 Sidelink + RichBinary OK
• ChatON ChatON ChatON ChatON r-RSS ChatON ChatON ChatON ChatON.' " +
                "ELSE '[ChatON Live Echo] ChatON ChatON («' || NEW.message_content || '») ChatON ChatON RichBinary ChatON ChatON! (RTT: 3.4ms)' END, " +
                "'Y', 'Received on RichBinary PC5 Sidelink! (RTT: 3.4ms)', 'fa', 'en', 'Y', " +
                "2, COALESCE((SELECT participants_buddy_no FROM participant WHERE participants_inbox_no = NEW.message_inbox_no LIMIT 1), '@claire@chaton (Claire Bennett)'), CAST(NEW._id + 1 AS TEXT), NEW.message_time_text, 1, 'N', 0); " +
                "UPDATE inbox SET inbox_last_message = (SELECT message_content FROM message WHERE _id = NEW._id + 1), inbox_last_time = NEW.message_time + 1000, inbox_last_timestamp = NEW.message_time + 1000 WHERE inbox_no = NEW.message_inbox_no; " +
                "END;"
            );
            db.setTransactionSuccessful();
        } catch (Throwable ignored) {
        } finally {
            db.endTransaction();
        }
    }

    public static void insertLiveEchoMessage(Context context, String sessionOrInboxId, String peerBuddyNo, String userText) {
        if (context == null) return;
        SQLiteDatabase db = al.a(context).getWritableDatabase();
        String inboxNo = sessionOrInboxId;
        String sessionId = sessionOrInboxId;
        String senderNo = (peerBuddyNo != null && !peerBuddyNo.isEmpty()) ? peerBuddyNo : "@claire@chaton (Claire Bennett)";

        Cursor c = null;
        try {
            c = db.query("inbox", new String[]{"inbox_no", "inbox_session_id", "inbox_last_msg_sender"},
                    "inbox_no=? OR inbox_session_id=?", new String[]{sessionOrInboxId, sessionOrInboxId},
                    null, null, null);
            if (c != null && c.moveToFirst()) {
                inboxNo = c.getString(0);
                if (c.getString(1) != null && !c.getString(1).isEmpty()) {
                    sessionId = c.getString(1);
                }
                if (c.getString(2) != null && c.getString(2).startsWith("@") && !c.getString(2).equals(AutoProvisioner.LOCAL_CHATON_ID)) {
                    senderNo = c.getString(2);
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.close();
        }

        String echoReply;
        String echoTranslated;
        if ("@web@r-rss".equals(senderNo) || (inboxNo != null && inboxNo.contains("rrss"))) {
            senderNo = "@web@r-rss";
            echoReply = "[r-RSS Live Crawl] ChatON ChatON ChatON ChatON «" + (userText != null ? userText : "query") + "»:
"
                    + "• ChatON ChatON: PC5 Sidelink + RichBinary OK
"
                    + "• ChatON ChatON: ChatON ChatON ChatON ChatON ChatON ChatON r-RSS ChatON ChatON ChatON ChatON.";
            echoTranslated = "[r-RSS Live Crawl] Offline crawl digest fetched and cached via PC5 mesh.";
        } else {
            echoReply = "[ChatON Live Echo from " + senderNo + "]
"
                    + "ChatON ChatON («" + (userText != null ? userText : "") + "») ChatON ChatON RichBinary ChatON ChatON! (RTT: 3.4ms)";
            echoTranslated = "Your message ('" + (userText != null ? userText : "") + "') was received over RichBinary! (RTT: 3.4ms)";
        }

        long now = System.currentTimeMillis();
        long msgId = MSG_ID_GEN.incrementAndGet();

        db.beginTransaction();
        try {
            insertMsg(db, msgId, inboxNo, sessionId, 0, 2, senderNo, echoReply, echoTranslated, now);

            ContentValues icv = new ContentValues();
            icv.put("inbox_last_message", echoReply);
            icv.put("inbox_last_time", Long.valueOf(now));
            icv.put("inbox_last_timestamp", Long.valueOf(now));
            icv.put("inbox_last_msg_no", Long.valueOf(msgId));
            icv.put("inbox_last_msg_sender", senderNo);
            db.update("inbox", icv, "inbox_no=?", new String[]{inboxNo});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }

        notifyAllProviders(context);
    }

    public static void notifyAllProviders(Context context) {
        if (context == null) return;
        ContentResolver cr = context.getContentResolver();
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/buddy"), null);
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/buddy_group"), null);
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/grouprelation"), null);
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/inbox"), null);
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/message"), null);
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/participant"), null);
        cr.notifyChange(Uri.parse("content://com.develop.sec.chaton.provider/trunk"), null);
        cr.notifyChange(Uri.parse("content://com.develop.sec.chaton.provider/trunk_item"), null);
    }
}
