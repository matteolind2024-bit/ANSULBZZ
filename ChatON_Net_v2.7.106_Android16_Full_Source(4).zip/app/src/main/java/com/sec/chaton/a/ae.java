package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/ae;
 */
public final class ae extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.chaton.a.af {
    private int a;
    private com.sec.chaton.a.ar b;
    private java.lang.Object c;
    private com.google.protobuf.LazyStringList d;
    private long e;

    private ae() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = com.sec.chaton.a.ar.a; // :com.sec.chaton.a.ar
        v1.b = v0; // com.sec.chaton.a.ae.b:com.sec.chaton.a.ar
        v0 = "";
        v1.c = v0; // com.sec.chaton.a.ae.c:java.lang.Object
        v0 = com.google.protobuf.LazyStringArrayList.EMPTY; // :com.google.protobuf.LazyStringList
        v1.d = v0; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        _result = v1.g(); // com.sec.chaton.a.ae.g -> void
        return;
    }

    static com.sec.chaton.a.ae f() {
        _result = this.h(); // com.sec.chaton.a.ae.h -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.chaton.a.ae h() {
        v0 = new com.sec.chaton.a.ae;
        _result = v0.<init>(); // com.sec.chaton.a.ae.<init> -> void
        return v0;
    }

    private void i() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 == v1) /* goto L_0016 */;
        v0 = new com.google.protobuf.LazyStringArrayList;
        v1 = v2.d; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        _result = v0.<init>(v1); // com.google.protobuf.LazyStringArrayList.<init> -> void
        v2.d = v0; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        v0 = v2.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v2.a = v0; // com.sec.chaton.a.ae.a:int
        return;
    }

    public com.sec.chaton.a.ae a() {
        // Registers (3 total): v2 = this
        _result = v2.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = com.sec.chaton.a.ar.a; // :com.sec.chaton.a.ar
        v2.b = v0; // com.sec.chaton.a.ae.b:com.sec.chaton.a.ar
        v0 = v2.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v2.a = v0; // com.sec.chaton.a.ae.a:int
        v0 = "";
        v2.c = v0; // com.sec.chaton.a.ae.c:java.lang.Object
        v0 = v2.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v2.a = v0; // com.sec.chaton.a.ae.a:int
        v0 = com.google.protobuf.LazyStringArrayList.EMPTY; // :com.google.protobuf.LazyStringList
        v2.d = v0; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        v0 = v2.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v2.a = v0; // com.sec.chaton.a.ae.a:int
        v0 = 0L;
        v2.e = v0; // com.sec.chaton.a.ae.e:long
        v0 = v2.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -9);
        v2.a = v0; // com.sec.chaton.a.ae.a:int
        return v2;
    }

    public com.sec.chaton.a.ae a(long p0) {
        // Registers (4 total): v1 = this, v2 = p0 (long)
        v0 = v1.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v1.a = v0; // com.sec.chaton.a.ae.a:int
        v1.e = v2; // com.sec.chaton.a.ae.e:long
        return v1;
    }

    public com.sec.chaton.a.ae a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.CodedInputStream), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v2.parseUnknownField(v3, v4, v0); // com.sec.chaton.a.ae.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v2;
        _result = v3.readEnum(); // com.google.protobuf.CodedInputStream.readEnum -> int
        v0 = _result;
        _result = v0.a(); // com.sec.chaton.a.ar.a -> com.sec.chaton.a.ar
        v0 = _result;
        if (v0 == 0) /* goto L_0000 */;
        v1 = v2.a; // com.sec.chaton.a.ae.a:int
        v1 = binOpLit8_0xde(v1, 1);
        v2.a = v1; // com.sec.chaton.a.ae.a:int
        v2.b = v0; // com.sec.chaton.a.ae.b:com.sec.chaton.a.ar
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v2.a = v0; // com.sec.chaton.a.ae.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.c = v0; // com.sec.chaton.a.ae.c:java.lang.Object
        // goto L_0000
        _result = v2.i(); // com.sec.chaton.a.ae.i -> void
        v0 = v2.d; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v1 = _result;
        _result = com.google.protobuf.LazyStringList.add(v0, v1); // -> void
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v2.a = v0; // com.sec.chaton.a.ae.a:int
        _result = v3.readInt64(); // com.google.protobuf.CodedInputStream.readInt64 -> long
        v0 = _result;
        v2.e = v0; // com.sec.chaton.a.ae.e:long
        // goto L_0000
    }

    public com.sec.chaton.a.ae a(com.sec.chaton.a.ad p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.chaton.a.ad)
        _result = this.a(); // com.sec.chaton.a.ad.a -> com.sec.chaton.a.ad
        v0 = _result;
        if (v3 != v0) /* goto L_0007 */;
        return v2;
        _result = v3.c(); // com.sec.chaton.a.ad.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v3.d(); // com.sec.chaton.a.ad.d -> com.sec.chaton.a.ar
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.ae.a -> com.sec.chaton.a.ae
        _result = v3.e(); // com.sec.chaton.a.ad.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v3.f(); // com.sec.chaton.a.ad.f -> java.lang.String
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.ae.a -> com.sec.chaton.a.ae
        _result = v3.b(); // com.sec.chaton.a.ad.b -> com.google.protobuf.LazyStringList
        v0 = _result;
        _result = com.google.protobuf.LazyStringList.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_003f */;
        v0 = v2.d; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_004d */;
        _result = v3.b(); // com.sec.chaton.a.ad.b -> com.google.protobuf.LazyStringList
        v0 = _result;
        v2.d = v0; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        v0 = v2.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v2.a = v0; // com.sec.chaton.a.ae.a:int
        _result = v3.h(); // com.sec.chaton.a.ad.h -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0006 */;
        _result = v3.i(); // com.sec.chaton.a.ad.i -> long
        v0 = _result;
        _result = v2.a(v0, v1); // com.sec.chaton.a.ae.a -> com.sec.chaton.a.ae
        // goto L_0006
        _result = v2.i(); // com.sec.chaton.a.ae.i -> void
        v0 = v2.d; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        _result = v3.b(); // com.sec.chaton.a.ad.b -> com.google.protobuf.LazyStringList
        v1 = _result;
        _result = com.google.protobuf.LazyStringList.addAll(v0, v1); // -> boolean
        // goto L_003f
    }

    public com.sec.chaton.a.ae a(com.sec.chaton.a.ar p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.ar)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.chaton.a.ae.a:int
        v1.b = v2; // com.sec.chaton.a.ae.b:com.sec.chaton.a.ar
        return v1;
    }

    public com.sec.chaton.a.ae a(java.lang.Iterable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Iterable)
        _result = v1.i(); // com.sec.chaton.a.ae.i -> void
        v0 = v1.d; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        _result = v2.addAll(v0); // com.google.protobuf.GeneratedMessageLite$Builder.addAll -> void
        return v1;
    }

    public com.sec.chaton.a.ae a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.chaton.a.ae.a:int
        v1.c = v2; // com.sec.chaton.a.ae.c:java.lang.Object
        return v1;
    }

    public com.sec.chaton.a.ae b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.chaton.a.ae.h -> com.sec.chaton.a.ae
        v0 = _result;
        _result = v2.e(); // com.sec.chaton.a.ae.e -> com.sec.chaton.a.ad
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.ae.a -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.chaton.a.ae.d -> com.sec.chaton.a.ad
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.chaton.a.ae.e -> com.sec.chaton.a.ad
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ad c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.chaton.a.ad.a -> com.sec.chaton.a.ad
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.ae.a -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.ae.a -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ae.b -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ae.b -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ae.b -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ae.b -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ad d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.chaton.a.ae.e -> com.sec.chaton.a.ad
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.chaton.a.ad.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.chaton.a.ae.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.chaton.a.ad e() {
        // Registers (6 total): v5 = this
        v0 = 1;
        v2 = new com.sec.chaton.a.ad;
        v1 = 0;
        _result = v2.<init>(v5, v1); // com.sec.chaton.a.ad.<init> -> void
        v3 = v5.a; // com.sec.chaton.a.ae.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_004b */;
        v1 = v5.b; // com.sec.chaton.a.ae.b:com.sec.chaton.a.ar
        _result = v2.a(v1); // com.sec.chaton.a.ad.a -> com.sec.chaton.a.ar
        v1 = binOpLit8_0xdd(v3, 2);
        v4 = 2;
        if (v1 != v4) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v5.c; // com.sec.chaton.a.ae.c:java.lang.Object
        _result = v2.a(v1); // com.sec.chaton.a.ad.a -> java.lang.Object
        v1 = v5.a; // com.sec.chaton.a.ae.a:int
        v1 = binOpLit8_0xdd(v1, 4);
        v4 = 4;
        if (v1 != v4) /* goto L_0035 */;
        v1 = new com.google.protobuf.UnmodifiableLazyStringList;
        v4 = v5.d; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        _result = v1.<init>(v4); // com.google.protobuf.UnmodifiableLazyStringList.<init> -> void
        v5.d = v1; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        v1 = v5.a; // com.sec.chaton.a.ae.a:int
        v1 = binOpLit8_0xdd(v1, -5);
        v5.a = v1; // com.sec.chaton.a.ae.a:int
        v1 = v5.d; // com.sec.chaton.a.ae.d:com.google.protobuf.LazyStringList
        _result = v2.a(v1); // com.sec.chaton.a.ad.a -> com.google.protobuf.LazyStringList
        v1 = binOpLit8_0xdd(v3, 8);
        v3 = 8;
        if (v1 != v3) /* goto L_0042 */;
        v0 = binOpLit8_0xde(v0, 4);
        v3 = v5.e; // com.sec.chaton.a.ae.e:long
        _result = v2.a(v3, v4); // com.sec.chaton.a.ad.a -> long
        _result = v2.a(v0); // com.sec.chaton.a.ad.a -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.ae.c -> com.sec.chaton.a.ad
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.ae.c -> com.sec.chaton.a.ad
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.ae.a -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.chaton.a.ad) v2;
        _result = v1.a(v2); // com.sec.chaton.a.ae.a -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.ae.a -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

}