package com.sec.chaton;

/**
 * Original SourceFile: DataPacketDialog2.java
 * Descriptor: Lcom/sec/chaton/DataPacketDialog2;
 */
public class DataPacketDialog2 extends android.support.v4.app.DialogFragment {
    public static final java.lang.String a;
    private android.widget.Button b;
    private android.widget.CheckBox c;

    static {
        v0 = com.sec.chaton.DataPacketDialog2.class;
        _result = v0.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v0 = _result;
        com.sec.chaton.DataPacketDialog2.a = v0; // :java.lang.String
        return;
    }

    public DataPacketDialog2() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.app.DialogFragment.<init> -> void
        return;
    }

    static android.widget.CheckBox a(com.sec.chaton.DataPacketDialog2 p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.DataPacketDialog2)
        v0 = v1.c; // com.sec.chaton.DataPacketDialog2.c:android.widget.CheckBox
        return v0;
    }

    public void onCreate(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onCreate(v3); // android.support.v4.app.DialogFragment.onCreate -> void
        v0 = 2;
        v1 = 0;
        _result = v2.setStyle(v0, v1); // com.sec.chaton.DataPacketDialog2.setStyle -> void
        return;
    }

    public android.view.View onCreateView(android.view.LayoutInflater p0, android.view.ViewGroup p1, android.os.Bundle p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.view.LayoutInflater), v5 = p1 (android.view.ViewGroup), v6 = p2 (android.os.Bundle)
        v1 = 0;
        _result = v3.getDialog(); // com.sec.chaton.DataPacketDialog2.getDialog -> android.app.Dialog
        v0 = _result;
        _result = v0.setCanceledOnTouchOutside(v1); // android.app.Dialog.setCanceledOnTouchOutside -> void
        v0 = com.sec.chaton.R.layout.data_packet_dialog; // 0x7f03005c
        _result = v4.inflate(v0, v5, v1); // android.view.LayoutInflater.inflate -> android.view.View
        v1 = _result;
        v0 = com.sec.chaton.R.id.data_packet_ok; // 0x7f080242
        _result = v1.findViewById(v0); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v3.b = v0; // com.sec.chaton.DataPacketDialog2.b:android.widget.Button
        v0 = com.sec.chaton.R.id.data_packet_chekcbox; // 0x7f08022a
        _result = v1.findViewById(v0); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.CheckBox) v0;
        v3.c = v0; // com.sec.chaton.DataPacketDialog2.c:android.widget.CheckBox
        v0 = v3.b; // com.sec.chaton.DataPacketDialog2.b:android.widget.Button
        v2 = new com.sec.chaton.p;
        _result = v2.<init>(v3); // com.sec.chaton.p.<init> -> void
        _result = v0.setOnClickListener(v2); // android.widget.Button.setOnClickListener -> void
        return v1;
    }

}