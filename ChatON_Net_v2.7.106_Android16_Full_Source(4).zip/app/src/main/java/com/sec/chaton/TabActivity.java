package com.sec.chaton;

/**
 * Original SourceFile: TabActivity.java
 * Descriptor: Lcom/sec/chaton/TabActivity;
 */
public class TabActivity extends com.sec.chaton.base.BaseMultiPaneActivity {
    public static final java.lang.String a;
    private static final java.lang.String g;
    private static final int j;
    private com.sec.chaton.util.bb A;
    private com.sec.chaton.util.bb B;
    private com.sec.chaton.util.bb C;
    private com.sec.chaton.util.bb D;
    private com.sec.chaton.util.bb E;
    private com.sec.chaton.util.bb F;
    private android.os.Handler G;
     java.lang.Runnable b;
     android.os.Handler c;
     android.os.Handler d;
    public android.os.Handler e;
    private final int h;
    private final int i;
    private com.sec.chaton.s k;
    private android.view.View l;
    private boolean m;
    private android.app.AlertDialog n;
    private android.content.BroadcastReceiver o;
    private android.content.BroadcastReceiver p;
    private com.sec.chaton.util.ay q;
    private com.sec.chaton.util.bb r;
    private com.sec.chaton.util.bb s;
    private com.sec.chaton.util.bb t;
    private com.sec.chaton.util.bb u;
    private com.sec.chaton.util.bb v;
    private com.sec.chaton.util.bb w;
    private com.sec.chaton.util.bb x;
    private com.sec.chaton.util.bb y;
    private com.sec.chaton.util.bb z;

    static {
        v0 = com.sec.chaton.TabActivity.class;
        _result = v0.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v0 = _result;
        com.sec.chaton.TabActivity.g = v0; // :java.lang.String
        v0 = 0x24010000;
        com.sec.chaton.TabActivity.j = v0; // :int
        v0 = "baseIntent";
        com.sec.chaton.TabActivity.a = v0; // :java.lang.String
        return;
    }

    public TabActivity() {
        // Registers (3 total): v2 = this
        _result = v2.<init>(); // com.sec.chaton.base.BaseMultiPaneActivity.<init> -> void
        v0 = 1;
        v2.h = v0; // com.sec.chaton.TabActivity.h:int
        v0 = 2;
        v2.i = v0; // com.sec.chaton.TabActivity.i:int
        v0 = new com.sec.chaton.bk;
        _result = v0.<init>(v2); // com.sec.chaton.bk.<init> -> void
        v2.r = v0; // com.sec.chaton.TabActivity.r:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.bl;
        _result = v0.<init>(v2); // com.sec.chaton.bl.<init> -> void
        v2.s = v0; // com.sec.chaton.TabActivity.s:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.bm;
        _result = v0.<init>(v2); // com.sec.chaton.bm.<init> -> void
        v2.t = v0; // com.sec.chaton.TabActivity.t:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.bn;
        _result = v0.<init>(v2); // com.sec.chaton.bn.<init> -> void
        v2.u = v0; // com.sec.chaton.TabActivity.u:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.bp;
        _result = v0.<init>(v2); // com.sec.chaton.bp.<init> -> void
        v2.v = v0; // com.sec.chaton.TabActivity.v:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.aq;
        _result = v0.<init>(v2); // com.sec.chaton.aq.<init> -> void
        v2.w = v0; // com.sec.chaton.TabActivity.w:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.ar;
        _result = v0.<init>(v2); // com.sec.chaton.ar.<init> -> void
        v2.x = v0; // com.sec.chaton.TabActivity.x:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.as;
        _result = v0.<init>(v2); // com.sec.chaton.as.<init> -> void
        v2.y = v0; // com.sec.chaton.TabActivity.y:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.at;
        _result = v0.<init>(v2); // com.sec.chaton.at.<init> -> void
        v2.z = v0; // com.sec.chaton.TabActivity.z:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.au;
        _result = v0.<init>(v2); // com.sec.chaton.au.<init> -> void
        v2.A = v0; // com.sec.chaton.TabActivity.A:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.av;
        _result = v0.<init>(v2); // com.sec.chaton.av.<init> -> void
        v2.B = v0; // com.sec.chaton.TabActivity.B:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.aw;
        _result = v0.<init>(v2); // com.sec.chaton.aw.<init> -> void
        v2.C = v0; // com.sec.chaton.TabActivity.C:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.ax;
        _result = v0.<init>(v2); // com.sec.chaton.ax.<init> -> void
        v2.D = v0; // com.sec.chaton.TabActivity.D:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.ay;
        _result = v0.<init>(v2); // com.sec.chaton.ay.<init> -> void
        v2.E = v0; // com.sec.chaton.TabActivity.E:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.az;
        _result = v0.<init>(v2); // com.sec.chaton.az.<init> -> void
        v2.F = v0; // com.sec.chaton.TabActivity.F:com.sec.chaton.util.bb
        v0 = new com.sec.chaton.ba;
        _result = v0.<init>(v2); // com.sec.chaton.ba.<init> -> void
        v2.b = v0; // com.sec.chaton.TabActivity.b:java.lang.Runnable
        v0 = new com.sec.chaton.be;
        _result = this.getMainLooper(); // android.os.Looper.getMainLooper -> android.os.Looper
        v1 = _result;
        _result = v0.<init>(v2, v1); // com.sec.chaton.be.<init> -> void
        v2.c = v0; // com.sec.chaton.TabActivity.c:android.os.Handler
        v0 = new com.sec.chaton.bf;
        _result = this.getMainLooper(); // android.os.Looper.getMainLooper -> android.os.Looper
        v1 = _result;
        _result = v0.<init>(v2, v1); // com.sec.chaton.bf.<init> -> void
        v2.d = v0; // com.sec.chaton.TabActivity.d:android.os.Handler
        v0 = new com.sec.chaton.bg;
        _result = v0.<init>(v2); // com.sec.chaton.bg.<init> -> void
        v2.e = v0; // com.sec.chaton.TabActivity.e:android.os.Handler
        v0 = new com.sec.chaton.bh;
        _result = v0.<init>(v2); // com.sec.chaton.bh.<init> -> void
        v2.G = v0; // com.sec.chaton.TabActivity.G:android.os.Handler
        return;
    }

    static android.content.BroadcastReceiver a(com.sec.chaton.TabActivity p0, android.content.BroadcastReceiver p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.TabActivity), v1 = p1 (android.content.BroadcastReceiver)
        v0.o = v1; // com.sec.chaton.TabActivity.o:android.content.BroadcastReceiver
        return v1;
    }

    public static android.content.Intent a(android.content.Context p0) {
        // Registers (3 total): v2 = p0 (android.content.Context)
        v0 = new android.content.Intent;
        v1 = com.sec.chaton.TabActivity.class;
        _result = v0.<init>(v2, v1); // android.content.Intent.<init> -> void
        v1 = com.sec.chaton.TabActivity.j; // :int
        _result = v0.setFlags(v1); // android.content.Intent.setFlags -> android.content.Intent
        return v0;
    }

    public static android.content.Intent a(android.content.Context p0, android.content.Intent p1) {
        // Registers (4 total): v2 = p0 (android.content.Context), v3 = p1 (android.content.Intent)
        _result = v2.a(); // com.sec.chaton.TabActivity.a -> android.content.Intent
        v0 = _result;
        v1 = com.sec.chaton.TabActivity.a; // :java.lang.String
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        return v0;
    }

    public static android.content.Intent a(android.content.Context p0, boolean p1) {
        // Registers (5 total): v3 = p0 (android.content.Context), v4 = p1 (boolean)
        v2 = 1;
        _result = v3.a(); // com.sec.chaton.TabActivity.a -> android.content.Intent
        v0 = _result;
        if (v4 != v2) /* goto L_000d */;
        v1 = "callChatList";
        _result = v0.putExtra(v1, v2); // android.content.Intent.putExtra -> android.content.Intent
        return v0;
        v1 = "callChatList";
        v2 = 0;
        _result = v0.putExtra(v1, v2); // android.content.Intent.putExtra -> android.content.Intent
        // goto L_000c
    }

    static com.sec.chaton.util.bb a(com.sec.chaton.TabActivity p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.TabActivity)
        v0 = v1.v; // com.sec.chaton.TabActivity.v:com.sec.chaton.util.bb
        return v0;
    }

    static void a(com.sec.chaton.TabActivity p0, java.lang.String p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.TabActivity), v1 = p1 (java.lang.String)
        _result = v0.b(v1); // com.sec.chaton.TabActivity.b -> void
        return;
    }

    static boolean a(com.sec.chaton.TabActivity p0, boolean p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.TabActivity), v1 = p1 (boolean)
        v0.m = v1; // com.sec.chaton.TabActivity.m:boolean
        return v1;
    }

    static com.sec.chaton.util.ay b(com.sec.chaton.TabActivity p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.TabActivity)
        v0 = v1.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        return v0;
    }

    private void b(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        _result = this.u(); // com.sec.chaton.util.ac.u -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_002e */;
        v0 = "showDisclaimer";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        v0 = "update_disclaimer_status";
        v1 = "RUN";
        _result = v0.a(v1); // com.sec.chaton.util.r.a -> void
        v0 = "disclaimer_ID";
        _result = v0.a(v3); // com.sec.chaton.util.r.a -> void
        v0 = new android.content.Intent;
        v1 = com.sec.chaton.registration.ActivityDisclaimer.class;
        _result = v0.<init>(v2, v1); // android.content.Intent.<init> -> void
        v1 = "disclaimerUID";
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        v1 = 0x04000000;
        _result = v0.setFlags(v1); // android.content.Intent.setFlags -> android.content.Intent
        v1 = 1;
        _result = v2.startActivityForResult(v0, v1); // com.sec.chaton.TabActivity.startActivityForResult -> void
        return;
    }

    static android.os.Handler c(com.sec.chaton.TabActivity p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.TabActivity)
        v0 = v1.G; // com.sec.chaton.TabActivity.G:android.os.Handler
        return v0;
    }

    static java.lang.String c() {
        v0 = com.sec.chaton.TabActivity.g; // :java.lang.String
        return v0;
    }

    private void c(android.content.Intent p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Intent)
        v2 = 0x04000000;
        _result = v4.a(v3); // com.sec.chaton.r.a -> com.sec.chaton.s
        v0 = _result;
        v3.k = v0; // com.sec.chaton.TabActivity.k:com.sec.chaton.s
        v1 = com.sec.chaton.bi.a; // :int[]
        _result = v0.ordinal(); // com.sec.chaton.s.ordinal -> int
        v0 = _result;
        v0 = v1[v0];
        // switch(v0)
        return;
        _result = v3.d(v4); // com.sec.chaton.TabActivity.d -> void
        // goto L_0013
        _result = v3.e(v4); // com.sec.chaton.TabActivity.e -> void
        // goto L_0013
        v0 = new android.content.Intent;
        v1 = com.sec.chaton.buddy.dialog.ChatONVInstallDialog.class;
        _result = v0.<init>(v3, v1); // android.content.Intent.<init> -> void
        _result = v3.startActivity(v0); // com.sec.chaton.TabActivity.startActivity -> void
        // goto L_0013
        v0 = com.sec.chaton.buddy.AddBuddyActivity.class;
        _result = v4.setClass(v3, v0); // android.content.Intent.setClass -> android.content.Intent
        _result = v4.setFlags(v2); // android.content.Intent.setFlags -> android.content.Intent
        _result = v3.startActivity(v4); // com.sec.chaton.TabActivity.startActivity -> void
        // goto L_0013
        v0 = com.sec.chaton.buddy.BuddyProfileActivity.class;
        _result = v4.setClass(v3, v0); // android.content.Intent.setClass -> android.content.Intent
        _result = v4.setFlags(v2); // android.content.Intent.setFlags -> android.content.Intent
        _result = v3.startActivity(v4); // com.sec.chaton.TabActivity.startActivity -> void
        // goto L_0013
    }

    private java.lang.String d() {
        // Registers (3 total): v2 = this
        v0 = "";
        _result = v2.getIntent(); // com.sec.chaton.TabActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v1.getAction(); // android.content.Intent.getAction -> java.lang.String
        v1 = _result;
        if (v1 == 0) /* goto L_0059 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Intent Action: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.TabActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v1.getAction(); // android.content.Intent.getAction -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.TabActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v1.getCategories(); // android.content.Intent.getCategories -> java.util.Set
        v1 = _result;
        if (v1 == 0) /* goto L_006d */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Intent Category: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getIntent(); // com.sec.chaton.TabActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v1.getCategories(); // android.content.Intent.getCategories -> java.util.Set
        v1 = _result;
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Intent Action: Null";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_002b
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Intent Category: Null";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0058
    }

    private void d(android.content.Intent p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.content.Intent)
        v3 = 0;
        v0 = "callChatList";
        _result = v5.getBooleanExtra(v0, v3); // android.content.Intent.getBooleanExtra -> boolean
        v0 = _result;
        v1 = com.sec.chaton.util.p.c; // :boolean
        if (v1 == 0) /* goto L_0023 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Shortcut or Notification: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        v2 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v1.c(v2); // com.sec.chaton.util.p.c -> void
        if (v0 == 0) /* goto L_0038 */;
        v0 = "callChatList";
        _result = v5.putExtra(v0, v3); // android.content.Intent.putExtra -> android.content.Intent
        v0 = com.sec.chaton.chat.ChatActivity.class;
        _result = v5.setClass(v4, v0); // android.content.Intent.setClass -> android.content.Intent
        v0 = 0x04000000;
        _result = v5.setFlags(v0); // android.content.Intent.setFlags -> android.content.Intent
        _result = v4.startActivity(v5); // com.sec.chaton.TabActivity.startActivity -> void
        return;
        v0 = "chatType";
        v1 = -1;
        _result = v5.getIntExtra(v0, v1); // android.content.Intent.getIntExtra -> int
        v0 = _result;
        _result = v0.a(); // com.sec.chaton.e.n.a -> com.sec.chaton.e.n
        v0 = _result;
        v1 = com.sec.chaton.e.n.e; // :com.sec.chaton.e.n
        if (v0 != v1) /* goto L_0037 */;
        _result = v4.a(); // com.sec.chaton.chat.notification.a.a -> com.sec.chaton.chat.notification.a
        v0 = _result;
        _result = v0.b(); // com.sec.chaton.chat.notification.a.b -> void
        v0 = new com.sec.widget.a;
        _result = v0.<init>(v4); // com.sec.widget.a.<init> -> void
        v1 = com.sec.chaton.R.string.app_name; // 0x7f0c0018
        _result = v0.setTitle(v1); // com.sec.widget.a.setTitle -> android.app.AlertDialog$Builder
        v0 = _result;
        v1 = "Content";
        _result = v5.getStringExtra(v1); // android.content.Intent.getStringExtra -> java.lang.String
        v1 = _result;
        _result = v0.setMessage(v1); // android.app.AlertDialog$Builder.setMessage -> android.app.AlertDialog$Builder
        v0 = _result;
        v1 = com.sec.chaton.R.drawable.popup_chaton_logo_2; // 0x7f02067e
        _result = v0.setIcon(v1); // android.app.AlertDialog$Builder.setIcon -> android.app.AlertDialog$Builder
        v0 = _result;
        v1 = com.sec.chaton.R.string.dialog_ok; // 0x7f0c006b
        v2 = new com.sec.chaton.bd;
        _result = v2.<init>(v4); // com.sec.chaton.bd.<init> -> void
        _result = v0.setPositiveButton(v1, v2); // android.app.AlertDialog$Builder.setPositiveButton -> android.app.AlertDialog$Builder
        v0 = _result;
        _result = v0.create(); // android.app.AlertDialog$Builder.create -> android.app.AlertDialog
        v0 = _result;
        _result = v0.show(); // android.app.AlertDialog.show -> void
        // goto L_0037
    }

    static void d(com.sec.chaton.TabActivity p0) {
        // Registers (1 total): v0 = p0 (com.sec.chaton.TabActivity)
        _result = v0.e(); // com.sec.chaton.TabActivity.e -> void
        return;
    }

    static android.content.BroadcastReceiver e(com.sec.chaton.TabActivity p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.TabActivity)
        v0 = v1.o; // com.sec.chaton.TabActivity.o:android.content.BroadcastReceiver
        return v0;
    }

    private void e() {
        // Registers (6 total): v5 = this
        v4 = 0;
        v0 = new java.text.SimpleDateFormat;
        v1 = "yyyy-MM-dd";
        _result = v0.<init>(v1); // java.text.SimpleDateFormat.<init> -> void
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v1 = _result;
        _result = v1.valueOf(v2); // java.lang.Long.valueOf -> java.lang.Long
        v1 = _result;
        _result = v0.format(v1); // java.text.SimpleDateFormat.format -> java.lang.String
        v0 = _result;
        v1 = new com.sec.chaton.e.a.t;
        _result = v1.<init>(); // com.sec.chaton.e.a.t.<init> -> void
        v2 = -1;
        v3 = new com.sec.chaton.e.b.s;
        _result = v3.<init>(v4, v0, v4); // com.sec.chaton.e.b.s.<init> -> void
        _result = v1.a(v2, v3); // com.sec.chaton.e.a.t.a -> void
        return;
    }

    private void e(android.content.Intent p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Intent)
        v2 = 0;
        v0 = com.sec.chaton.util.p.c; // :boolean
        if (v0 == 0) /* goto L_0023 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "Shortcut or Notification: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "callChatList";
        _result = v4.getBooleanExtra(v1, v2); // android.content.Intent.getBooleanExtra -> boolean
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        v0 = "callForward";
        _result = v4.getBooleanExtra(v0, v2); // android.content.Intent.getBooleanExtra -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003d */;
        v0 = "callForward";
        _result = v4.putExtra(v0, v2); // android.content.Intent.putExtra -> android.content.Intent
        v0 = com.sec.chaton.forward.ChatForwardActivity.class;
        _result = v4.setClass(v3, v0); // android.content.Intent.setClass -> android.content.Intent
        v0 = 0x04000000;
        _result = v4.setFlags(v0); // android.content.Intent.setFlags -> android.content.Intent
        _result = v3.startActivity(v4); // com.sec.chaton.TabActivity.startActivity -> void
        return;
    }

    private void f() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "[LIFE] initView, isTaskRoot: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.isTaskRoot(); // com.sec.chaton.TabActivity.isTaskRoot -> boolean
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Task ID: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getTaskId(); // com.sec.chaton.TabActivity.getTaskId -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Memory Address:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.d(); // com.sec.chaton.TabActivity.d -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        v0 = com.sec.chaton.R.layout.activity_home; // 0x7f030004
        _result = v2.setContentView(v0); // com.sec.chaton.TabActivity.setContentView -> void
        _result = this.a(); // com.sec.chaton.ExitAppDialogActivity.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0052 */;
        v0 = new android.content.Intent;
        v1 = com.sec.chaton.ExitAppDialogActivity.class;
        _result = v0.<init>(v2, v1); // android.content.Intent.<init> -> void
        _result = v2.startActivity(v0); // com.sec.chaton.TabActivity.startActivity -> void
        return;
    }

    static void f(com.sec.chaton.TabActivity p0) {
        // Registers (1 total): v0 = p0 (com.sec.chaton.TabActivity)
        _result = v0.p(); // com.sec.chaton.TabActivity.p -> void
        return;
    }

    static java.lang.String g(com.sec.chaton.TabActivity p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.TabActivity)
        _result = v1.o(); // com.sec.chaton.TabActivity.o -> java.lang.String
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (9 total): v8 = this
        v3 = 60000L;
        v6 = 86400000L;
        v0 = new com.sec.chaton.util.ay;
        _result = v0.<init>(); // com.sec.chaton.util.ay.<init> -> void
        v8.q = v0; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "get_chaton_crypto_key";
        v2 = v8.D; // com.sec.chaton.TabActivity.D:com.sec.chaton.util.bb
        v5 = "last_sync_time_get_chaton_crypto_key";
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "local_calculation";
        v2 = v8.r; // com.sec.chaton.TabActivity.r:com.sec.chaton.util.bb
        v5 = "last_sync_time_on_start";
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "get_push_status";
        v2 = v8.u; // com.sec.chaton.TabActivity.u:com.sec.chaton.util.bb
        v5 = "last_sync_time_get_push_status";
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "version_notice";
        v2 = v8.x; // com.sec.chaton.TabActivity.x:com.sec.chaton.util.bb
        v3 = 21600000L;
        v5 = "last_sync_time_get_version_notice";
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = "com.sec.spp.push";
        _result = v0.b(); // com.sec.chaton.util.bp.b -> int
        v0 = _result;
        v1 = 21;
        if (v0 >= v1) /* goto L_00c2 */;
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "spp_update_check";
        v2 = v8.y; // com.sec.chaton.TabActivity.y:com.sec.chaton.util.bb
        v3 = 259200000L;
        v5 = "last_sync_time_get_spp_update_check";
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "chatonv_update_check";
        v2 = v8.z; // com.sec.chaton.TabActivity.z:com.sec.chaton.util.bb
        v5 = "last_chatonv_upgrade_check";
        v3 = v6;
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = "Added mChatonVUpgradeCheckTask to polling scheduler";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "notification";
        v2 = v8.w; // com.sec.chaton.TabActivity.w:com.sec.chaton.util.bb
        v3 = 1800000L;
        v5 = "last_sync_time_notification";
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "get_all_buddies";
        v2 = v8.s; // com.sec.chaton.TabActivity.s:com.sec.chaton.util.bb
        v3 = 10800000L;
        v5 = "last_sync_time_get_all_buddies";
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "recommendee_sync";
        v2 = v8.A; // com.sec.chaton.TabActivity.A:com.sec.chaton.util.bb
        v5 = "last_recommendee_sync_time";
        v3 = v6;
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "interaction_sync";
        v2 = v8.B; // com.sec.chaton.TabActivity.B:com.sec.chaton.util.bb
        v5 = "last_Interaction_sync_time";
        v3 = v6;
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "contactDB_reset";
        v2 = v8.C; // com.sec.chaton.TabActivity.C:com.sec.chaton.util.bb
        v5 = "last_contact_reset_time";
        v3 = v6;
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "chatonv_available";
        v2 = v8.F; // com.sec.chaton.TabActivity.F:com.sec.chaton.util.bb
        v5 = "last_chatonv_available_time";
        v3 = v6;
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        v0 = v8.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        v1 = "set_compatibility";
        v2 = v8.E; // com.sec.chaton.TabActivity.E:com.sec.chaton.util.bb
        v3 = 900000L;
        v5 = "last_compatibility_time";
        _result = v0.a(v0..v5); // com.sec.chaton.util.ay.a -> void
        return;
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_00cd */;
        v0 = "don't need to add poliing scheduler for SPP";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v8.i(); // com.sec.chaton.TabActivity.i -> void
        // goto L_0054
    }

    private void h() {
        // Registers (4 total): v3 = this
        v0 = v3.o; // com.sec.chaton.TabActivity.o:android.content.BroadcastReceiver
        if (v0 != 0) /* goto L_0022 */;
        v0 = new android.content.IntentFilter;
        _result = v0.<init>(); // android.content.IntentFilter.<init> -> void
        v1 = "com.sec.chaton.ACTION_EXIT_APP";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        v1 = new com.sec.chaton.bb;
        _result = v1.<init>(v3); // com.sec.chaton.bb.<init> -> void
        v3.o = v1; // com.sec.chaton.TabActivity.o:android.content.BroadcastReceiver
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v1 = _result;
        _result = v1.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v1 = _result;
        v2 = v3.o; // com.sec.chaton.TabActivity.o:android.content.BroadcastReceiver
        _result = com.sec.chaton.bridge.Android16Compat.registerReceiverSafe(v1, v2, v0); // android.support.v4.content.LocalBroadcastManager.registerReceiver -> void
        return;
    }

    private void i() {
        // Registers (3 total): v2 = this
        v0 = v2.p; // com.sec.chaton.TabActivity.p:android.content.BroadcastReceiver
        if (v0 != 0) /* goto L_001a */;
        v0 = new android.content.IntentFilter;
        _result = v0.<init>(); // android.content.IntentFilter.<init> -> void
        v1 = "action_noti_spp_update";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        v1 = new com.sec.chaton.bc;
        _result = v1.<init>(v2); // com.sec.chaton.bc.<init> -> void
        v2.p = v1; // com.sec.chaton.TabActivity.p:android.content.BroadcastReceiver
        v1 = v2.p; // com.sec.chaton.TabActivity.p:android.content.BroadcastReceiver
        _result = com.sec.chaton.bridge.Android16Compat.registerReceiverSafe(v2, v1, v0); // com.sec.chaton.TabActivity.registerReceiver -> android.content.Intent
        return;
    }

    private boolean j() {
        // Registers (3 total): v2 = this
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "uid";
        _result = v0.b(v1); // com.sec.chaton.util.s.b -> boolean
        v0 = _result;
        return v0;
    }

    private boolean k() {
        // Registers (4 total): v3 = this
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "UpdateIsCritical";
        v2 = 0;
        _result = v2.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v2 = _result;
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.Boolean
        v0 = _result;
        _result = v0.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        return v0;
    }

    private boolean l() {
        // Registers (4 total): v3 = this
        _result = v3.getIntent(); // com.sec.chaton.TabActivity.getIntent -> android.content.Intent
        v0 = _result;
        v1 = "callRestart";
        v2 = 0;
        _result = v0.getBooleanExtra(v1, v2); // android.content.Intent.getBooleanExtra -> boolean
        v0 = _result;
        return v0;
    }

    private java.lang.String m() {
        // Registers (4 total): v3 = this
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "disclaimer_UID";
        v2 = "";
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    private boolean n() {
        // Registers (5 total): v4 = this
        v3 = 0x00100000;
        v0 = 0;
        _result = v4.getIntent(); // com.sec.chaton.TabActivity.getIntent -> android.content.Intent
        v1 = _result;
        v2 = "finish";
        _result = v1.getBooleanExtra(v2, v0); // android.content.Intent.getBooleanExtra -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0017 */;
        _result = v1.getFlags(); // android.content.Intent.getFlags -> int
        v1 = _result;
        v1 = binOp2addr_0xb5(v1, v3);
        if (v1 == v3) /* goto L_0017 */;
        v0 = 1;
        return v0;
    }

    private java.lang.String o() {
        // Registers (4 total): v3 = this
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "update_disclaimer_status";
        v2 = "";
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    private void p() {
        // Registers (4 total): v3 = this
        v0 = new android.content.Intent;
        v1 = "com.sec.chaton.ACTION_DISMISS";
        _result = v0.<init>(v1); // android.content.Intent.<init> -> void
        _result = v3.getApplicationContext(); // com.sec.chaton.TabActivity.getApplicationContext -> android.content.Context
        v1 = _result;
        _result = v1.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v1 = _result;
        _result = v1.sendBroadcast(v0); // android.support.v4.content.LocalBroadcastManager.sendBroadcast -> boolean
        _result = v3.getApplicationContext(); // com.sec.chaton.TabActivity.getApplicationContext -> android.content.Context
        v0 = _result;
        _result = v0.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v0 = _result;
        v1 = new android.content.Intent;
        v2 = "more_tab_badge_update";
        _result = v1.<init>(v2); // android.content.Intent.<init> -> void
        _result = v0.sendBroadcast(v1); // android.support.v4.content.LocalBroadcastManager.sendBroadcast -> boolean
        return;
    }

    private void q() {
        // Registers (4 total): v3 = this
        v0 = "showPasswordLockActivity";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v3.getApplicationContext(); // com.sec.chaton.TabActivity.getApplicationContext -> android.content.Context
        v0 = _result;
        _result = v0.c(); // com.sec.chaton.util.j.c -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0027 */;
        v1 = new android.content.Intent;
        v2 = com.sec.chaton.settings.ActivityPasswordLockSet.class;
        _result = v1.<init>(v0, v2); // android.content.Intent.<init> -> void
        v0 = "MODE";
        v2 = "HOME";
        _result = v1.putExtra(v0, v2); // android.content.Intent.putExtra -> android.content.Intent
        v0 = 0x04000000;
        _result = v1.setFlags(v0); // android.content.Intent.setFlags -> android.content.Intent
        _result = v3.startActivity(v1); // com.sec.chaton.TabActivity.startActivity -> void
        return;
    }

    private void r() {
        // Registers (1 total): v0 = this
        return;
    }

    protected com.sec.chaton.base.a a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = com.sec.chaton.R.id.fragment_container; // 0x7f08000b
        _result = v1.findViewById(v0); // com.sec.chaton.TabActivity.findViewById -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0009 */;
        _result = v1.a(v2); // com.sec.chaton.base.BaseMultiPaneActivity.a -> com.sec.chaton.base.a
        v0 = _result;
        return v0;
    }

    public void a() {
        // Registers (4 total): v3 = this
        v0 = new com.sec.widget.a;
        _result = v0.<init>(v3); // com.sec.widget.a.<init> -> void
        _result = v3.getResources(); // com.sec.chaton.TabActivity.getResources -> android.content.res.Resources
        v1 = _result;
        v2 = com.sec.chaton.R.string.backup; // 0x7f0c034d
        _result = v1.getString(v2); // android.content.res.Resources.getString -> java.lang.String
        v1 = _result;
        _result = v0.setTitle(v1); // com.sec.widget.a.setTitle -> android.app.AlertDialog$Builder
        v0 = _result;
        _result = v3.getResources(); // com.sec.chaton.TabActivity.getResources -> android.content.res.Resources
        v1 = _result;
        v2 = com.sec.chaton.R.string.auto_backup_setting; // 0x7f0c0552
        _result = v1.getString(v2); // android.content.res.Resources.getString -> java.lang.String
        v1 = _result;
        _result = v0.setMessage(v1); // android.app.AlertDialog$Builder.setMessage -> android.app.AlertDialog$Builder
        v0 = _result;
        _result = v3.getResources(); // com.sec.chaton.TabActivity.getResources -> android.content.res.Resources
        v1 = _result;
        v2 = com.sec.chaton.R.string.dialog_ok; // 0x7f0c006b
        _result = v1.getString(v2); // android.content.res.Resources.getString -> java.lang.String
        v1 = _result;
        v2 = new com.sec.chaton.ap;
        _result = v2.<init>(v3); // com.sec.chaton.ap.<init> -> void
        _result = v0.setPositiveButton(v1, v2); // android.app.AlertDialog$Builder.setPositiveButton -> android.app.AlertDialog$Builder
        v0 = _result;
        _result = v3.getResources(); // com.sec.chaton.TabActivity.getResources -> android.content.res.Resources
        v1 = _result;
        v2 = com.sec.chaton.R.string.dialog_cancel; // 0x7f0c006d
        _result = v1.getString(v2); // android.content.res.Resources.getString -> java.lang.String
        v1 = _result;
        v2 = 0;
        _result = v0.setNegativeButton(v1, v2); // android.app.AlertDialog$Builder.setNegativeButton -> android.app.AlertDialog$Builder
        v0 = _result;
        _result = v0.show(); // android.app.AlertDialog$Builder.show -> android.app.AlertDialog
        return;
    }

    public java.lang.String b(android.content.Context p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Context)
        v0 = "activity";
        _result = v4.getSystemService(v0); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.app.ActivityManager) v0;
        v1 = 1;
        _result = v0.getRunningTasks(v1); // android.app.ActivityManager.getRunningTasks -> java.util.List
        v0 = _result;
        v1 = 0;
        _result = java.util.List.get(v0, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (android.app.ActivityManager$RunningTaskInfo) v0;
        v0 = v0.topActivity; // android.app.ActivityManager$RunningTaskInfo.topActivity:android.content.ComponentName
        _result = v0.getClassName(); // android.content.ComponentName.getClassName -> java.lang.String
        v0 = _result;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "getClassName : ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        v2 = "HomeActivity";
        _result = v1.b(v2); // com.sec.chaton.util.p.b -> void
        return v0;
    }

    void b() {
        // Registers (4 total): v3 = this
        v0 = "layout_inflater";
        _result = v3.getSystemService(v0); // com.sec.chaton.TabActivity.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        v2 = com.sec.chaton.R.layout.layout_text_checkbox_for_dialog; // 0x7f03012b
        v1 = com.sec.chaton.R.id.linearLayoutCheckBox; // 0x7f0805dd
        _result = v3.findViewById(v1); // com.sec.chaton.TabActivity.findViewById -> android.view.View
        v1 = _result;
        v1 = (android.view.ViewGroup) v1;
        _result = v0.inflate(v2, v1); // android.view.LayoutInflater.inflate -> android.view.View
        v0 = _result;
        v3.l = v0; // com.sec.chaton.TabActivity.l:android.view.View
        v0 = v3.l; // com.sec.chaton.TabActivity.l:android.view.View
        v1 = com.sec.chaton.R.id.data_packet_chekcbox; // 0x7f08022a
        _result = v0.findViewById(v1); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.CheckBox) v0;
        v1 = new com.sec.chaton.bj;
        _result = v1.<init>(v3); // com.sec.chaton.bj.<init> -> void
        _result = v0.setOnCheckedChangeListener(v1); // android.widget.CheckBox.setOnCheckedChangeListener -> void
        return;
    }

    public boolean dispatchKeyEvent(android.view.KeyEvent p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.view.KeyEvent)
        _result = v4.getSupportFragmentManager(); // com.sec.chaton.TabActivity.getSupportFragmentManager -> android.support.v4.app.FragmentManager
        v0 = _result;
        v1 = com.sec.chaton.R.id.fragment_tab; // 0x7f080007
        _result = v0.findFragmentById(v1); // android.support.v4.app.FragmentManager.findFragmentById -> android.support.v4.app.Fragment
        v0 = _result;
        v0 = (com.sec.chaton.HomeTabFragment) v0;
        _result = v4.getSupportFragmentManager(); // com.sec.chaton.TabActivity.getSupportFragmentManager -> android.support.v4.app.FragmentManager
        v1 = _result;
        v2 = com.sec.chaton.R.id.fragment_buddy; // 0x7f080002
        _result = v1.findFragmentById(v2); // android.support.v4.app.FragmentManager.findFragmentById -> android.support.v4.app.Fragment
        v1 = _result;
        v1 = (com.sec.chaton.buddy.BuddyFragment) v1;
        v2 = com.sec.chaton.util.p.b; // :boolean
        if (v2 == 0) /* goto L_003a */;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "dispatchKeyEvent : KeyCode = ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v5.getKeyCode(); // android.view.KeyEvent.getKeyCode -> int
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        v3 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v2.b(v3); // com.sec.chaton.util.p.b -> void
        _result = v5.getKeyCode(); // android.view.KeyEvent.getKeyCode -> int
        v2 = _result;
        v3 = 84;
        if (v2 != v3) /* goto L_0071 */;
        if (v0 == 0) /* goto L_006f */;
        if (v1 == 0) /* goto L_006f */;
        v2 = com.sec.chaton.util.p.b; // :boolean
        if (v2 == 0) /* goto L_0066 */;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "dispatchKeyEvent : Current Tab ID = ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v0.a(); // com.sec.chaton.HomeTabFragment.a -> int
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        v3 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v2.b(v3); // com.sec.chaton.util.p.b -> void
        _result = v0.a(); // com.sec.chaton.HomeTabFragment.a -> int
        v0 = _result;
        if (v0 != 0) /* goto L_006f */;
        _result = v1.i(); // com.sec.chaton.buddy.BuddyFragment.i -> void
        v0 = 1;
        return v0;
        _result = v4.dispatchKeyEvent(v5); // com.sec.chaton.base.BaseMultiPaneActivity.dispatchKeyEvent -> boolean
        v0 = _result;
        // goto L_0070
    }

    public void onActivityResult(int p0, int p1, android.content.Intent p2) {
        // Registers (7 total): v3 = this, v4 = p0 (int), v5 = p1 (int), v6 = p2 (android.content.Intent)
        v0 = -1;
        v2 = 0;
        _result = v3.onActivityResult(v4, v5, v6); // com.sec.chaton.base.BaseMultiPaneActivity.onActivityResult -> void
        // switch(v4)
        return;
        if (v5 != v0) /* goto L_001a */;
        v0 = "update_disclaimer_status";
        v1 = "DONE";
        _result = v0.a(v1); // com.sec.chaton.util.r.a -> void
        v0 = "Success in accpet disclaimer";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        // goto L_0008
        v0 = 2;
        if (v5 != v0) /* goto L_0008 */;
        v0 = "update_disclaimer_status";
        v1 = "DONE";
        _result = v0.a(v1); // com.sec.chaton.util.r.a -> void
        // goto L_0008
        if (v5 != v0) /* goto L_0039 */;
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v0 = _result;
        _result = v0.a(v2); // com.sec.chaton.localbackup.noti.a.a -> void
        v0 = "setting_backup_enable";
        v1 = 1;
        _result = v1.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.util.r.a -> void
        // goto L_0008
        if (v5 != 0) /* goto L_0008 */;
        v0 = "auto_backup_on";
        _result = v2.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.util.r.a -> void
        // goto L_0008
        if (v5 != v0) /* goto L_0072 */;
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_0052 */;
        v0 = "Success in Contact sync after registration";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        v0 = "local_backup_feature";
        _result = v0.a(); // com.sec.chaton.global.a.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0008 */;
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "auto_backup_on";
        _result = v2.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v2 = _result;
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.Boolean
        v0 = _result;
        _result = v0.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0008 */;
        _result = v3.a(); // com.sec.chaton.TabActivity.a -> void
        // goto L_0008
        v0 = 3;
        if (v5 != v0) /* goto L_00a1 */;
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_0080 */;
        v0 = "Skip in Contact sync after registration";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        v0 = "local_backup_feature";
        _result = v0.a(); // com.sec.chaton.global.a.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0008 */;
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "auto_backup_on";
        _result = v2.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v2 = _result;
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.Boolean
        v0 = _result;
        _result = v0.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0008 */;
        _result = v3.a(); // com.sec.chaton.TabActivity.a -> void
        // goto L_0008
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_00ac */;
        v0 = "Cancel in Contact sync after registration";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v3.finish(); // com.sec.chaton.TabActivity.finish -> void
        // goto L_0008
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.os.Bundle)
        v6 = com.sec.chaton.R.layout.activity_home; // 0x7f030004
        v5 = 1;
        v4 = 0;
        _result = v7.onCreate(v8); // com.sec.chaton.base.BaseMultiPaneActivity.onCreate -> void
        _result = v7.getIntent(); // com.sec.chaton.TabActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = this.d(); // com.sec.chaton.util.bx.d -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_002f */;
        v0 = com.sec.chaton.util.p.d; // :boolean
        if (v0 == 0) /* goto L_001d */;
        v0 = "There isn't enough memory for executing ChatON.";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.d(v1); // com.sec.chaton.util.p.d -> void
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v0 = _result;
        v1 = com.sec.chaton.R.string.popup_not_enough_memory; // 0x7f0c0343
        _result = v0.makeText(v1, v4); // android.widget.Toast.makeText -> android.widget.Toast
        v0 = _result;
        _result = v0.show(); // android.widget.Toast.show -> void
        _result = v7.finish(); // com.sec.chaton.TabActivity.finish -> void
        return;
        _result = v7.n(); // com.sec.chaton.TabActivity.n -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0044 */;
        v0 = com.sec.chaton.util.p.c; // :boolean
        if (v0 == 0) /* goto L_0040 */;
        v0 = "HomeActivity is requested finish.";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        _result = v7.finish(); // com.sec.chaton.TabActivity.finish -> void
        // goto L_002e
        v0 = com.sec.chaton.c.a.f; // :boolean
        if (v0 == 0) /* goto L_007a */;
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_0053 */;
        v0 = "Welcome, First Time after update ChatON.";
        v2 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v2); // com.sec.chaton.util.p.b -> void
        _result = v7.r(); // com.sec.chaton.TabActivity.r -> void
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v2 = "Setting Sync TimeInMillis";
        v3 = "0";
        _result = v0.b(v2, v3); // com.sec.chaton.util.s.b -> void
        _result = this.v(); // com.sec.chaton.util.ac.v -> void
        v0 = "chaton_version";
        v2 = com.sec.chaton.c.a.b; // :java.lang.String
        _result = v0.a(v2); // com.sec.chaton.util.r.a -> void
        com.sec.chaton.c.a.f = v4; // :boolean
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v2 = "buddy_get_all_buddy_mode_instance";
        _result = v5.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v3 = _result;
        _result = v0.b(v2, v3); // com.sec.chaton.util.s.b -> void
        _result = v7.k(); // com.sec.chaton.TabActivity.k -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_009d */;
        _result = v7.setContentView(v6); // com.sec.chaton.TabActivity.setContentView -> void
        v0 = "wifi_80_port";
        _result = v0.a(); // com.sec.chaton.global.a.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002e */;
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "wifi_port";
        _result = this.d(); // com.sec.chaton.util.at.d -> int
        v2 = _result;
        _result = v2.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v0.b(v1, v2); // com.sec.chaton.util.s.b -> void
        // goto L_002e
        _result = v7.o(); // com.sec.chaton.TabActivity.o -> java.lang.String
        v0 = _result;
        v2 = "RUN";
        _result = v0.equals(v2); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00ad */;
        _result = v7.setContentView(v6); // com.sec.chaton.TabActivity.setContentView -> void
        // goto L_0083
        _result = v7.j(); // com.sec.chaton.TabActivity.j -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_00bf */;
        _result = v7.finish(); // com.sec.chaton.TabActivity.finish -> void
        _result = v7.a(); // com.sec.chaton.HomeActivity.a -> android.content.Intent
        v0 = _result;
        _result = v7.startActivity(v0); // com.sec.chaton.TabActivity.startActivity -> void
        // goto L_002e
        _result = v7.b(); // com.sec.chaton.TabActivity.b -> void
        _result = v7.h(); // com.sec.chaton.TabActivity.h -> void
        _result = v7.g(); // com.sec.chaton.TabActivity.g -> void
        if (v8 != 0) /* goto L_00d8 */;
        v0 = com.sec.chaton.TabActivity.a; // :java.lang.String
        _result = v1.getParcelableExtra(v0); // android.content.Intent.getParcelableExtra -> android.os.Parcelable
        v0 = _result;
        v0 = (android.content.Intent) v0;
        if (v0 != 0) /* goto L_00d5 */;
        v0 = v1;
        _result = v7.c(v0); // com.sec.chaton.TabActivity.c -> void
        if (v8 != 0) /* goto L_00f8 */;
        v0 = "extra_from_chaton";
        _result = v1.getBooleanExtra(v0, v4); // android.content.Intent.getBooleanExtra -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_00f8 */;
        v0 = v7.k; // com.sec.chaton.TabActivity.k:com.sec.chaton.s
        v1 = com.sec.chaton.s.c; // :com.sec.chaton.s
        if (v0 != v1) /* goto L_00f8 */;
        _result = this.c(); // com.sec.chaton.event.f.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00f8 */;
        v0 = new android.content.Intent;
        v1 = com.sec.chaton.event.EventDialog.class;
        _result = v0.<init>(v7, v1); // android.content.Intent.<init> -> void
        _result = v7.startActivity(v0); // com.sec.chaton.TabActivity.startActivity -> void
        _result = v7.f(); // com.sec.chaton.TabActivity.f -> void
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "first_time_after_regi";
        _result = v4.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v2 = _result;
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.Boolean
        v0 = _result;
        _result = v0.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        if (v0 != v5) /* goto L_0137 */;
        v0 = "local_backup_feature";
        _result = v0.a(); // com.sec.chaton.global.a.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_012e */;
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "auto_backup_on";
        _result = v4.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v2 = _result;
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.Boolean
        v0 = _result;
        _result = v0.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_012e */;
        _result = v7.a(); // com.sec.chaton.TabActivity.a -> void
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "first_time_after_regi";
        _result = v0.a(v1); // com.sec.chaton.util.s.a -> void
        com.sec.chaton.global.GlobalApplication.k = v5; // :boolean
        v0 = "onCreate : set setShowPasswordLock value";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v7.getIntent(); // com.sec.chaton.TabActivity.getIntent -> android.content.Intent
        v0 = _result;
        v1 = "extra_from_chaton";
        _result = v0.getBooleanExtra(v1, v4); // android.content.Intent.getBooleanExtra -> boolean
        v0 = _result;
        if (v0 != v5) /* goto L_0151 */;
        _result = v4.a(); // com.sec.chaton.util.j.a -> void
        // goto L_0083
        if (v8 == 0) /* goto L_016d */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "savedInstanceState";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        // goto L_0083
        _result = v5.a(); // com.sec.chaton.util.j.a -> void
        // goto L_0083
    }

    protected void onDestroy() {
        // Registers (4 total): v3 = this
        v2 = 0;
        _result = v3.onDestroy(); // com.sec.chaton.base.BaseMultiPaneActivity.onDestroy -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "[LIFE] onDestroy, isTaskRoot: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.isTaskRoot(); // com.sec.chaton.TabActivity.isTaskRoot -> boolean
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Task ID: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.getTaskId(); // com.sec.chaton.TabActivity.getTaskId -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Memory Address:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.d(); // com.sec.chaton.TabActivity.d -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        v0 = v3.o; // com.sec.chaton.TabActivity.o:android.content.BroadcastReceiver
        if (v0 == 0) /* goto L_0053 */;
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v0 = _result;
        _result = v0.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v0 = _result;
        v1 = v3.o; // com.sec.chaton.TabActivity.o:android.content.BroadcastReceiver
        _result = v0.unregisterReceiver(v1); // android.support.v4.content.LocalBroadcastManager.unregisterReceiver -> void
        v3.o = v2; // com.sec.chaton.TabActivity.o:android.content.BroadcastReceiver
        v0 = v3.p; // com.sec.chaton.TabActivity.p:android.content.BroadcastReceiver
        if (v0 == 0) /* goto L_005e */;
        v0 = v3.p; // com.sec.chaton.TabActivity.p:android.content.BroadcastReceiver
        _result = v3.unregisterReceiver(v0); // com.sec.chaton.TabActivity.unregisterReceiver -> void
        v3.p = v2; // com.sec.chaton.TabActivity.p:android.content.BroadcastReceiver
        v0 = v3.n; // com.sec.chaton.TabActivity.n:android.app.AlertDialog
        if (v0 == 0) /* goto L_006f */;
        v0 = v3.n; // com.sec.chaton.TabActivity.n:android.app.AlertDialog
        _result = v0.isShowing(); // android.app.AlertDialog.isShowing -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_006f */;
        v0 = v3.n; // com.sec.chaton.TabActivity.n:android.app.AlertDialog
        _result = v0.dismiss(); // android.app.AlertDialog.dismiss -> void
        return;
    }

    public void onNewIntent(android.content.Intent p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Intent)
        _result = v2.onNewIntent(v3); // com.sec.chaton.base.BaseMultiPaneActivity.onNewIntent -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "[LIFE] onNewIntent, isTaskRoot: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.isTaskRoot(); // com.sec.chaton.TabActivity.isTaskRoot -> boolean
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Task ID: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getTaskId(); // com.sec.chaton.TabActivity.getTaskId -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Memory Address:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.d(); // com.sec.chaton.TabActivity.d -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        _result = v2.setIntent(v3); // com.sec.chaton.TabActivity.setIntent -> void
        _result = v2.n(); // com.sec.chaton.TabActivity.n -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_004c */;
        _result = v2.finish(); // com.sec.chaton.TabActivity.finish -> void
        return;
        _result = v2.l(); // com.sec.chaton.TabActivity.l -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_005d */;
        _result = v2.finish(); // com.sec.chaton.TabActivity.finish -> void
        _result = v2.a(); // com.sec.chaton.TabActivity.a -> android.content.Intent
        v0 = _result;
        _result = v2.startActivity(v0); // com.sec.chaton.TabActivity.startActivity -> void
        // goto L_004b
        v0 = com.sec.chaton.TabActivity.a; // :java.lang.String
        _result = v3.getParcelableExtra(v0); // android.content.Intent.getParcelableExtra -> android.os.Parcelable
        v0 = _result;
        v0 = (android.content.Intent) v0;
        if (v0 != 0) /* goto L_0075 */;
        _result = v2.c(v3); // com.sec.chaton.TabActivity.c -> void
        _result = this.b(); // com.sec.chaton.util.j.b -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_004b */;
        v0 = 1;
        _result = v0.a(); // com.sec.chaton.util.j.a -> void
        // goto L_004b
        v3 = v0;
        // goto L_0067
    }

    protected void onPause() {
        // Registers (3 total): v2 = this
        _result = v2.onPause(); // com.sec.chaton.base.BaseMultiPaneActivity.onPause -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "[LIFE] onPause, isTaskRoot: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.isTaskRoot(); // com.sec.chaton.TabActivity.isTaskRoot -> boolean
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Task ID: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getTaskId(); // com.sec.chaton.TabActivity.getTaskId -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Memory Address:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.d(); // com.sec.chaton.TabActivity.d -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        return;
    }

    protected void onResume() {
        // Registers (4 total): v3 = this
        _result = v3.onResume(); // com.sec.chaton.base.BaseMultiPaneActivity.onResume -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "[LIFE] onResume, isTaskRoot: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.isTaskRoot(); // com.sec.chaton.TabActivity.isTaskRoot -> boolean
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Task ID: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.getTaskId(); // com.sec.chaton.TabActivity.getTaskId -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Memory Address:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.d(); // com.sec.chaton.TabActivity.d -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        _result = this.d(); // com.sec.chaton.util.bx.d -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0063 */;
        v0 = com.sec.chaton.util.p.d; // :boolean
        if (v0 == 0) /* goto L_0050 */;
        v0 = "There isn't enough memory for executing ChatON.";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.d(v1); // com.sec.chaton.util.p.d -> void
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v0 = _result;
        v1 = com.sec.chaton.R.string.popup_not_enough_memory; // 0x7f0c0343
        v2 = 0;
        _result = v0.makeText(v1, v2); // android.widget.Toast.makeText -> android.widget.Toast
        v0 = _result;
        _result = v0.show(); // android.widget.Toast.show -> void
        _result = v3.finish(); // com.sec.chaton.TabActivity.finish -> void
        return;
        _result = v3.q(); // com.sec.chaton.TabActivity.q -> void
        // goto L_0062
    }

    protected void onStart() {
        // Registers (4 total): v3 = this
        v2 = 1;
        _result = v3.onStart(); // com.sec.chaton.base.BaseMultiPaneActivity.onStart -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "[LIFE] onStart, isTaskRoot: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.isTaskRoot(); // com.sec.chaton.TabActivity.isTaskRoot -> boolean
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Task ID: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.getTaskId(); // com.sec.chaton.TabActivity.getTaskId -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Memory Address:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.d(); // com.sec.chaton.TabActivity.d -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        _result = v3.k(); // com.sec.chaton.TabActivity.k -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0065 */;
        v0 = new android.content.Intent;
        v1 = com.sec.chaton.UpgradeDialog.class;
        _result = v0.<init>(v3, v1); // android.content.Intent.<init> -> void
        v1 = "isCritical";
        _result = v0.putExtra(v1, v2); // android.content.Intent.putExtra -> android.content.Intent
        v1 = "isFromHome";
        _result = v0.putExtra(v1, v2); // android.content.Intent.putExtra -> android.content.Intent
        _result = v3.startActivity(v0); // com.sec.chaton.TabActivity.startActivity -> void
        v0 = new com.sec.chaton.d.az;
        v1 = v3.c; // com.sec.chaton.TabActivity.c:android.os.Handler
        _result = v0.<init>(v1); // com.sec.chaton.d.az.<init> -> void
        _result = v0.b(); // com.sec.chaton.d.az.b -> com.sec.chaton.d.a.cj
        return;
        _result = v3.o(); // com.sec.chaton.TabActivity.o -> java.lang.String
        v0 = _result;
        v1 = "RUN";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0079 */;
        _result = v3.m(); // com.sec.chaton.TabActivity.m -> java.lang.String
        v0 = _result;
        _result = v3.b(v0); // com.sec.chaton.TabActivity.b -> void
        // goto L_0064
        v0 = v3.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        if (v0 == 0) /* goto L_0064 */;
        v0 = v3.q; // com.sec.chaton.TabActivity.q:com.sec.chaton.util.ay
        _result = v0.a(); // com.sec.chaton.util.ay.a -> void
        // goto L_0064
    }

    protected void onStop() {
        // Registers (3 total): v2 = this
        _result = v2.onStop(); // com.sec.chaton.base.BaseMultiPaneActivity.onStop -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "[LIFE] onStop, isTaskRoot: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.isTaskRoot(); // com.sec.chaton.TabActivity.isTaskRoot -> boolean
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Task ID: ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getTaskId(); // com.sec.chaton.TabActivity.getTaskId -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", Memory Address:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.d(); // com.sec.chaton.TabActivity.d -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        return;
    }

    protected void onUserLeaveHint() {
        // Registers (3 total): v2 = this
        v0 = "onUserLeaveHint";
        v1 = com.sec.chaton.TabActivity.g; // :java.lang.String
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v2.getApplicationContext(); // com.sec.chaton.TabActivity.getApplicationContext -> android.content.Context
        v0 = _result;
        _result = v0.b(); // com.sec.chaton.util.j.b -> void
        return;
    }

}