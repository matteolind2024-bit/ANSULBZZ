package com.sec.chaton;

/**
 * Original SourceFile: HomeTabFragment.java
 * Descriptor: Lcom/sec/chaton/ac;
 */
public interface ac {
    public abstract void a();
    public abstract void b();
}