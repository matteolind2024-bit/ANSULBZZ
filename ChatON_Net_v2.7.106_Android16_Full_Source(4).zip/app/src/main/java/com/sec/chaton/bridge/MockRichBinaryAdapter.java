package com.sec.chaton.bridge;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.sec.chaton.a.a.d;
import com.sec.chaton.d.a.a;
import com.sec.chaton.global.GlobalApplication;
import com.sec.chaton.i.aa;
import com.sec.chaton.i.ae;
import com.sec.chaton.i.af;
import com.sec.chaton.i.n;

import java.util.concurrent.atomic.AtomicLong;

/**
 * ============================================================================
 * MockRichBinaryAdapter — Local Zero-Latency Implementation for ChatON v2.7.106
 * ============================================================================
 */
public final class MockRichBinaryAdapter implements RichBinaryBridge {
    private static final String TAG = "ChatON27_MockBridge";
    private static final MockRichBinaryAdapter INSTANCE = new MockRichBinaryAdapter();
    private static final AtomicLong SERVER_MSG_SEQ = new AtomicLong(900000000L);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public static MockRichBinaryAdapter getInstance() {
        return INSTANCE;
    }

    private MockRichBinaryAdapter() {}

    @Override
    public void initialize(Context context) {
        AutoProvisioner.ensureProvisioned(context);
        MockEnvironmentSeeder.seedAllIfNeeded(context);
    }

    @Override
    public void dispatchTcpEnvelope(aa tcpContext, final ae requestEnvelope) {
        if (requestEnvelope == null) {
            return;
        }
        final int reqType = requestEnvelope.b();
        final long reqMsgId = requestEnvelope.d();
        Log.i(TAG, "Intercepted v2.7.106 TCP Envelope: type=" + reqType + ", msgId=" + reqMsgId);

        final int replyType = reqType + 1;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    af envBuilder = new af();
                    envBuilder.a(AutoProvisioner.LOCAL_UID);
                    envBuilder.a(replyType);
                    ae replyEnvelope = envBuilder.b();
                    requestEnvelope.a(requestEnvelope, replyEnvelope);
                } catch (Throwable t) {
                    Log.w(TAG, "Local TCP callback handled via SQLite Live Echo trigger: " + t.getMessage());
                }
            }
        });
    }

    @Override
    public d dispatchHttpRequest(a httpTask) {
        try {
            d result = new d(null);
            result.a(n.a); // HttpResultCode.SUCCESS
            result.c(200); // HTTP 200 OK
            return result;
        } catch (Throwable t) {
            Log.w(TAG, "dispatchHttpRequest stub error: " + t.getMessage());
            return null;
        }
    }

    @Override
    public long sendHangoutMessage(
            final Context context,
            final String inboxNo,
            final String sessionId,
            final int chatType,
            final int contentType,
            final String messageText,
            final String[] receivers,
            final long clientMsgId) {
        final String peer = (receivers != null && receivers.length > 0) ? receivers[0] : "@claire@chaton (Claire Bennett)";
        scheduleLiveEchoReply(sessionId != null ? sessionId : inboxNo, peer, messageText, clientMsgId);
        return SERVER_MSG_SEQ.incrementAndGet();
    }

    public void scheduleLiveEchoReply(
            final String sessionOrInboxId,
            final String peerBuddyNo,
            final String userText,
            final long clientMsgId) {
        final Context ctx = GlobalApplication.b();
        if (ctx == null) return;

        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    ContentResolver cr = ctx.getContentResolver();
                    ContentValues ackValues = new ContentValues();
                    ackValues.put("message_type", Integer.valueOf(1));
                    ackValues.put("message_is_failed", Integer.valueOf(0));
                    ackValues.put("message_sever_id", Long.valueOf(SERVER_MSG_SEQ.incrementAndGet()));
                    if (clientMsgId > 0) {
                        cr.update(
                                Uri.parse("content://com.sec.chaton.provider/message"),
                                ackValues,
                                "_id=?",
                                new String[]{String.valueOf(clientMsgId)}
                        );
                    }
                    cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/message"), null);
                    cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/inbox"), null);
                } catch (Throwable t) {
                    Log.w(TAG, "Error updating outgoing message ACK: " + t.getMessage());
                }
            }
        });

        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    MockEnvironmentSeeder.insertLiveEchoMessage(ctx, sessionOrInboxId, peerBuddyNo, userText);
                } catch (Throwable t) {
                    Log.w(TAG, "Error inserting Live Echo message: " + t.getMessage());
                }
            }
        }, 1000L);
    }

    @Override
    public void syncCirclesAndPresence(Context context) {
        MockEnvironmentSeeder.seedAllIfNeeded(context);
    }

    @Override
    public void syncTrunkLeftovers(Context context, String sessionId) {
        MockEnvironmentSeeder.seedAllIfNeeded(context);
    }
}
