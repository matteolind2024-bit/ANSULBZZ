package com.sec.chaton.a.a;

/**
 * Original SourceFile: ResultEntry.java
 * Descriptor: Lcom/sec/chaton/a/a/h;
 */
public class h {
    public boolean a;
    public com.sec.chaton.a.a.i b;
    public java.lang.String c;

    public h(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // com.sec.chaton.a.a.h.a:boolean
        return;
    }

    public h(boolean p0, com.sec.chaton.a.a.i p1) {
        // Registers (3 total): v0 = this, v1 = p0 (boolean), v2 = p1 (com.sec.chaton.a.a.i)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // com.sec.chaton.a.a.h.a:boolean
        v0.b = v2; // com.sec.chaton.a.a.h.b:com.sec.chaton.a.a.i
        return;
    }

    public h(boolean p0, java.lang.String p1) {
        // Registers (3 total): v0 = this, v1 = p0 (boolean), v2 = p1 (java.lang.String)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // com.sec.chaton.a.a.h.a:boolean
        v0.c = v2; // com.sec.chaton.a.a.h.c:java.lang.String
        return;
    }

}