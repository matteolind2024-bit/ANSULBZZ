package com.sec.chaton.a.a;

/**
 * Original SourceFile: MessageResultEntry.java
 * Descriptor: Lcom/sec/chaton/a/a/g;
 */
public final enum g {
    public static final com.sec.chaton.a.a.g a;
    public static final com.sec.chaton.a.a.g b;
    public static final com.sec.chaton.a.a.g c;
    public static final com.sec.chaton.a.a.g d;
    public static final com.sec.chaton.a.a.g e;
    public static final com.sec.chaton.a.a.g f;
    public static final com.sec.chaton.a.a.g g;
    public static final com.sec.chaton.a.a.g h;
    public static final com.sec.chaton.a.a.g i;
    public static final com.sec.chaton.a.a.g j;
    public static final com.sec.chaton.a.a.g k;
    public static final com.sec.chaton.a.a.g l;
    public static final com.sec.chaton.a.a.g m;
    public static final com.sec.chaton.a.a.g n;
    private static final com.sec.chaton.a.a.g[] o;

    static {
        v7 = 4;
        v6 = 3;
        v5 = 2;
        v4 = 1;
        v3 = 0;
        v0 = new com.sec.chaton.a.a.g;
        v1 = "SUCCESS_RECEIVER_ERROR";
        _result = v0.<init>(v1, v3); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.a = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "RETRY";
        _result = v0.<init>(v1, v4); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.b = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "CHANGE_SERVER";
        _result = v0.<init>(v1, v5); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.c = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "FAIL";
        _result = v0.<init>(v1, v6); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.d = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "REGARD_SUCCEESS";
        _result = v0.<init>(v1, v7); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.e = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "NEED_HANDLE";
        v2 = 5;
        _result = v0.<init>(v1, v2); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.f = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "BLOCK_RECEIVER";
        v2 = 6;
        _result = v0.<init>(v1, v2); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.g = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "INVALID_USER";
        v2 = 7;
        _result = v0.<init>(v1, v2); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.h = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "END_APP";
        v2 = 8;
        _result = v0.<init>(v1, v2); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.i = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "RESTART_APP";
        v2 = 9;
        _result = v0.<init>(v1, v2); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.j = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "SESSION_USER_NOT_EXIST";
        v2 = 10;
        _result = v0.<init>(v1, v2); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.k = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "RESET_BY_WEB";
        v2 = 11;
        _result = v0.<init>(v1, v2); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.l = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "NON_WEB_USER_DETECTED";
        v2 = 12;
        _result = v0.<init>(v1, v2); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.m = v0; // :com.sec.chaton.a.a.g
        v0 = new com.sec.chaton.a.a.g;
        v1 = "SESSION_DEACTIVATED";
        v2 = 13;
        _result = v0.<init>(v1, v2); // com.sec.chaton.a.a.g.<init> -> void
        com.sec.chaton.a.a.g.n = v0; // :com.sec.chaton.a.a.g
        v0 = 14;
        v0 = new com.sec.chaton.a.a.g[][size=v0];
        v1 = com.sec.chaton.a.a.g.a; // :com.sec.chaton.a.a.g
        v0[v3] = v1;
        v1 = com.sec.chaton.a.a.g.b; // :com.sec.chaton.a.a.g
        v0[v4] = v1;
        v1 = com.sec.chaton.a.a.g.c; // :com.sec.chaton.a.a.g
        v0[v5] = v1;
        v1 = com.sec.chaton.a.a.g.d; // :com.sec.chaton.a.a.g
        v0[v6] = v1;
        v1 = com.sec.chaton.a.a.g.e; // :com.sec.chaton.a.a.g
        v0[v7] = v1;
        v1 = 5;
        v2 = com.sec.chaton.a.a.g.f; // :com.sec.chaton.a.a.g
        v0[v1] = v2;
        v1 = 6;
        v2 = com.sec.chaton.a.a.g.g; // :com.sec.chaton.a.a.g
        v0[v1] = v2;
        v1 = 7;
        v2 = com.sec.chaton.a.a.g.h; // :com.sec.chaton.a.a.g
        v0[v1] = v2;
        v1 = 8;
        v2 = com.sec.chaton.a.a.g.i; // :com.sec.chaton.a.a.g
        v0[v1] = v2;
        v1 = 9;
        v2 = com.sec.chaton.a.a.g.j; // :com.sec.chaton.a.a.g
        v0[v1] = v2;
        v1 = 10;
        v2 = com.sec.chaton.a.a.g.k; // :com.sec.chaton.a.a.g
        v0[v1] = v2;
        v1 = 11;
        v2 = com.sec.chaton.a.a.g.l; // :com.sec.chaton.a.a.g
        v0[v1] = v2;
        v1 = 12;
        v2 = com.sec.chaton.a.a.g.m; // :com.sec.chaton.a.a.g
        v0[v1] = v2;
        v1 = 13;
        v2 = com.sec.chaton.a.a.g.n; // :com.sec.chaton.a.a.g
        v0[v1] = v2;
        com.sec.chaton.a.a.g.o = v0; // :com.sec.chaton.a.a.g[]
        return;
    }

    private g(java.lang.String p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        return;
    }

    public static com.sec.chaton.a.a.g valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = com.sec.chaton.a.a.g.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (com.sec.chaton.a.a.g) v0;
        return v0;
    }

    public static com.sec.chaton.a.a.g[] values() {
        v0 = com.sec.chaton.a.a.g.o; // :com.sec.chaton.a.a.g[]
        _result = v0.clone(); // com.sec.chaton.a.a.g[].clone -> java.lang.Object
        v0 = _result;
        v0 = (com.sec.chaton.a.a.g[]) v0;
        return v0;
    }

}