package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/ap;
 */
public final class ap extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.chaton.a.aq {
    private int a;
    private long b;
    private com.sec.chaton.a.cp c;
    private com.sec.chaton.a.ar d;
    private java.lang.Object e;
    private java.lang.Object f;
    private com.google.protobuf.LazyStringList g;
    private java.lang.Object h;
    private java.lang.Object i;
    private java.lang.Object j;
    private java.lang.Object k;
    private long l;

    private ap() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = com.sec.chaton.a.cp.a; // :com.sec.chaton.a.cp
        v1.c = v0; // com.sec.chaton.a.ap.c:com.sec.chaton.a.cp
        v0 = com.sec.chaton.a.ar.a; // :com.sec.chaton.a.ar
        v1.d = v0; // com.sec.chaton.a.ap.d:com.sec.chaton.a.ar
        v0 = "";
        v1.e = v0; // com.sec.chaton.a.ap.e:java.lang.Object
        v0 = "";
        v1.f = v0; // com.sec.chaton.a.ap.f:java.lang.Object
        v0 = com.google.protobuf.LazyStringArrayList.EMPTY; // :com.google.protobuf.LazyStringList
        v1.g = v0; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        v0 = "";
        v1.h = v0; // com.sec.chaton.a.ap.h:java.lang.Object
        v0 = "";
        v1.i = v0; // com.sec.chaton.a.ap.i:java.lang.Object
        v0 = "";
        v1.j = v0; // com.sec.chaton.a.ap.j:java.lang.Object
        v0 = "";
        v1.k = v0; // com.sec.chaton.a.ap.k:java.lang.Object
        _result = v1.o(); // com.sec.chaton.a.ap.o -> void
        return;
    }

    static com.sec.chaton.a.ao a(com.sec.chaton.a.ap p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.ap)
        _result = v1.q(); // com.sec.chaton.a.ap.q -> com.sec.chaton.a.ao
        v0 = _result;
        return v0;
    }

    static com.sec.chaton.a.ap n() {
        _result = this.p(); // com.sec.chaton.a.ap.p -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    private void o() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.chaton.a.ap p() {
        v0 = new com.sec.chaton.a.ap;
        _result = v0.<init>(); // com.sec.chaton.a.ap.<init> -> void
        return v0;
    }

    private com.sec.chaton.a.ao q() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.chaton.a.ap.e -> com.sec.chaton.a.ao
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.chaton.a.ao.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.chaton.a.ap.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    private void r() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xdd(v0, 32);
        v1 = 32;
        if (v0 == v1) /* goto L_0017 */;
        v0 = new com.google.protobuf.LazyStringArrayList;
        v1 = v2.g; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        _result = v0.<init>(v1); // com.google.protobuf.LazyStringArrayList.<init> -> void
        v2.g = v0; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        v0 = v2.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xde(v0, 32);
        v2.a = v0; // com.sec.chaton.a.ap.a:int
        return;
    }

    public com.sec.chaton.a.ap a() {
        // Registers (4 total): v3 = this
        v1 = 0L;
        _result = v3.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v3.b = v1; // com.sec.chaton.a.ap.b:long
        v0 = v3.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v3.a = v0; // com.sec.chaton.a.ap.a:int
        v0 = com.sec.chaton.a.cp.a; // :com.sec.chaton.a.cp
        v3.c = v0; // com.sec.chaton.a.ap.c:com.sec.chaton.a.cp
        v0 = v3.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v3.a = v0; // com.sec.chaton.a.ap.a:int
        v0 = com.sec.chaton.a.ar.a; // :com.sec.chaton.a.ar
        v3.d = v0; // com.sec.chaton.a.ap.d:com.sec.chaton.a.ar
        v0 = v3.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v3.a = v0; // com.sec.chaton.a.ap.a:int
        v0 = "";
        v3.e = v0; // com.sec.chaton.a.ap.e:java.lang.Object
        v0 = v3.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xdd(v0, -9);
        v3.a = v0; // com.sec.chaton.a.ap.a:int
        v0 = "";
        v3.f = v0; // com.sec.chaton.a.ap.f:java.lang.Object
        v0 = v3.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xdd(v0, -17);
        v3.a = v0; // com.sec.chaton.a.ap.a:int
        v0 = com.google.protobuf.LazyStringArrayList.EMPTY; // :com.google.protobuf.LazyStringList
        v3.g = v0; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        v0 = v3.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xdd(v0, -33);
        v3.a = v0; // com.sec.chaton.a.ap.a:int
        v0 = "";
        v3.h = v0; // com.sec.chaton.a.ap.h:java.lang.Object
        v0 = v3.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xdd(v0, -65);
        v3.a = v0; // com.sec.chaton.a.ap.a:int
        v0 = "";
        v3.i = v0; // com.sec.chaton.a.ap.i:java.lang.Object
        v0 = v3.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd5(v0, -129);
        v3.a = v0; // com.sec.chaton.a.ap.a:int
        v0 = "";
        v3.j = v0; // com.sec.chaton.a.ap.j:java.lang.Object
        v0 = v3.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd5(v0, -257);
        v3.a = v0; // com.sec.chaton.a.ap.a:int
        v0 = "";
        v3.k = v0; // com.sec.chaton.a.ap.k:java.lang.Object
        v0 = v3.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd5(v0, -513);
        v3.a = v0; // com.sec.chaton.a.ap.a:int
        v3.l = v1; // com.sec.chaton.a.ap.l:long
        v0 = v3.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd5(v0, -1025);
        v3.a = v0; // com.sec.chaton.a.ap.a:int
        return v3;
    }

    public com.sec.chaton.a.ap a(long p0) {
        // Registers (4 total): v1 = this, v2 = p0 (long)
        v0 = v1.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.chaton.a.ap.a:int
        v1.b = v2; // com.sec.chaton.a.ap.b:long
        return v1;
    }

    public com.sec.chaton.a.ap a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.CodedInputStream), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v2.parseUnknownField(v3, v4, v0); // com.sec.chaton.a.ap.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v2;
        v0 = v2.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v2.a = v0; // com.sec.chaton.a.ap.a:int
        _result = v3.readInt64(); // com.google.protobuf.CodedInputStream.readInt64 -> long
        v0 = _result;
        v2.b = v0; // com.sec.chaton.a.ap.b:long
        // goto L_0000
        _result = v3.readEnum(); // com.google.protobuf.CodedInputStream.readEnum -> int
        v0 = _result;
        _result = v0.a(); // com.sec.chaton.a.cp.a -> com.sec.chaton.a.cp
        v0 = _result;
        if (v0 == 0) /* goto L_0000 */;
        v1 = v2.a; // com.sec.chaton.a.ap.a:int
        v1 = binOpLit8_0xde(v1, 2);
        v2.a = v1; // com.sec.chaton.a.ap.a:int
        v2.c = v0; // com.sec.chaton.a.ap.c:com.sec.chaton.a.cp
        // goto L_0000
        _result = v3.readEnum(); // com.google.protobuf.CodedInputStream.readEnum -> int
        v0 = _result;
        _result = v0.a(); // com.sec.chaton.a.ar.a -> com.sec.chaton.a.ar
        v0 = _result;
        if (v0 == 0) /* goto L_0000 */;
        v1 = v2.a; // com.sec.chaton.a.ap.a:int
        v1 = binOpLit8_0xde(v1, 4);
        v2.a = v1; // com.sec.chaton.a.ap.a:int
        v2.d = v0; // com.sec.chaton.a.ap.d:com.sec.chaton.a.ar
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v2.a = v0; // com.sec.chaton.a.ap.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.e = v0; // com.sec.chaton.a.ap.e:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xde(v0, 16);
        v2.a = v0; // com.sec.chaton.a.ap.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.f = v0; // com.sec.chaton.a.ap.f:java.lang.Object
        // goto L_0000
        _result = v2.r(); // com.sec.chaton.a.ap.r -> void
        v0 = v2.g; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v1 = _result;
        _result = com.google.protobuf.LazyStringList.add(v0, v1); // -> void
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xde(v0, 64);
        v2.a = v0; // com.sec.chaton.a.ap.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.h = v0; // com.sec.chaton.a.ap.h:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd6(v0, 128);
        v2.a = v0; // com.sec.chaton.a.ap.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.i = v0; // com.sec.chaton.a.ap.i:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd6(v0, 256);
        v2.a = v0; // com.sec.chaton.a.ap.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.j = v0; // com.sec.chaton.a.ap.j:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd6(v0, 512);
        v2.a = v0; // com.sec.chaton.a.ap.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.k = v0; // com.sec.chaton.a.ap.k:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd6(v0, 1024);
        v2.a = v0; // com.sec.chaton.a.ap.a:int
        _result = v3.readInt64(); // com.google.protobuf.CodedInputStream.readInt64 -> long
        v0 = _result;
        v2.l = v0; // com.sec.chaton.a.ap.l:long
        // goto L_0000
    }

    public com.sec.chaton.a.ap a(com.sec.chaton.a.ao p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.chaton.a.ao)
        _result = this.a(); // com.sec.chaton.a.ao.a -> com.sec.chaton.a.ao
        v0 = _result;
        if (v3 != v0) /* goto L_0007 */;
        return v2;
        _result = v3.c(); // com.sec.chaton.a.ao.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v3.d(); // com.sec.chaton.a.ao.d -> long
        v0 = _result;
        _result = v2.a(v0, v1); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ap
        _result = v3.e(); // com.sec.chaton.a.ao.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v3.f(); // com.sec.chaton.a.ao.f -> com.sec.chaton.a.cp
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ap
        _result = v3.g(); // com.sec.chaton.a.ao.g -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002e */;
        _result = v3.h(); // com.sec.chaton.a.ao.h -> com.sec.chaton.a.ar
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ap
        _result = v3.i(); // com.sec.chaton.a.ao.i -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003b */;
        _result = v3.j(); // com.sec.chaton.a.ao.j -> java.lang.String
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ap
        _result = v3.k(); // com.sec.chaton.a.ao.k -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0048 */;
        _result = v3.l(); // com.sec.chaton.a.ao.l -> java.lang.String
        v0 = _result;
        _result = v2.b(v0); // com.sec.chaton.a.ap.b -> com.sec.chaton.a.ap
        _result = v3.b(); // com.sec.chaton.a.ao.b -> com.google.protobuf.LazyStringList
        v0 = _result;
        _result = com.google.protobuf.LazyStringList.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0066 */;
        v0 = v2.g; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00a9 */;
        _result = v3.b(); // com.sec.chaton.a.ao.b -> com.google.protobuf.LazyStringList
        v0 = _result;
        v2.g = v0; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        v0 = v2.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xdd(v0, -33);
        v2.a = v0; // com.sec.chaton.a.ap.a:int
        _result = v3.n(); // com.sec.chaton.a.ao.n -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0073 */;
        _result = v3.o(); // com.sec.chaton.a.ao.o -> java.lang.String
        v0 = _result;
        _result = v2.d(v0); // com.sec.chaton.a.ap.d -> com.sec.chaton.a.ap
        _result = v3.p(); // com.sec.chaton.a.ao.p -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0080 */;
        _result = v3.q(); // com.sec.chaton.a.ao.q -> java.lang.String
        v0 = _result;
        _result = v2.e(v0); // com.sec.chaton.a.ap.e -> com.sec.chaton.a.ap
        _result = v3.r(); // com.sec.chaton.a.ao.r -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_008d */;
        _result = v3.s(); // com.sec.chaton.a.ao.s -> java.lang.String
        v0 = _result;
        _result = v2.f(v0); // com.sec.chaton.a.ap.f -> com.sec.chaton.a.ap
        _result = v3.t(); // com.sec.chaton.a.ao.t -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_009a */;
        _result = v3.u(); // com.sec.chaton.a.ao.u -> java.lang.String
        v0 = _result;
        _result = v2.g(v0); // com.sec.chaton.a.ap.g -> com.sec.chaton.a.ap
        _result = v3.v(); // com.sec.chaton.a.ao.v -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0006 */;
        _result = v3.w(); // com.sec.chaton.a.ao.w -> long
        v0 = _result;
        _result = v2.b(v0, v1); // com.sec.chaton.a.ap.b -> com.sec.chaton.a.ap
        // goto L_0006
        _result = v2.r(); // com.sec.chaton.a.ap.r -> void
        v0 = v2.g; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        _result = v3.b(); // com.sec.chaton.a.ao.b -> com.google.protobuf.LazyStringList
        v1 = _result;
        _result = com.google.protobuf.LazyStringList.addAll(v0, v1); // -> boolean
        // goto L_0066
    }

    public com.sec.chaton.a.ap a(com.sec.chaton.a.ar p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.ar)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.chaton.a.ap.a:int
        v1.d = v2; // com.sec.chaton.a.ap.d:com.sec.chaton.a.ar
        return v1;
    }

    public com.sec.chaton.a.ap a(com.sec.chaton.a.cp p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.cp)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.chaton.a.ap.a:int
        v1.c = v2; // com.sec.chaton.a.ap.c:com.sec.chaton.a.cp
        return v1;
    }

    public com.sec.chaton.a.ap a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v1.a = v0; // com.sec.chaton.a.ap.a:int
        v1.e = v2; // com.sec.chaton.a.ap.e:java.lang.Object
        return v1;
    }

    public com.sec.chaton.a.ap b() {
        // Registers (3 total): v2 = this
        _result = this.p(); // com.sec.chaton.a.ap.p -> com.sec.chaton.a.ap
        v0 = _result;
        _result = v2.e(); // com.sec.chaton.a.ap.e -> com.sec.chaton.a.ao
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ap b(long p0) {
        // Registers (4 total): v1 = this, v2 = p0 (long)
        v0 = v1.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd6(v0, 1024);
        v1.a = v0; // com.sec.chaton.a.ap.a:int
        v1.l = v2; // com.sec.chaton.a.ap.l:long
        return v1;
    }

    public com.sec.chaton.a.ap b(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xde(v0, 16);
        v1.a = v0; // com.sec.chaton.a.ap.a:int
        v1.f = v2; // com.sec.chaton.a.ap.f:java.lang.Object
        return v1;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.chaton.a.ap.d -> com.sec.chaton.a.ao
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.chaton.a.ap.e -> com.sec.chaton.a.ao
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ao c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.chaton.a.ao.a -> com.sec.chaton.a.ao
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ap c(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        _result = v1.r(); // com.sec.chaton.a.ap.r -> void
        v0 = v1.g; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.add(v0, v2); // -> boolean
        return v1;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ap.b -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ap.b -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ap.b -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ap.b -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ao d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.chaton.a.ap.e -> com.sec.chaton.a.ao
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.chaton.a.ao.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.chaton.a.ap.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.chaton.a.ap d(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit8_0xde(v0, 64);
        v1.a = v0; // com.sec.chaton.a.ap.a:int
        v1.h = v2; // com.sec.chaton.a.ap.h:java.lang.Object
        return v1;
    }

    public com.sec.chaton.a.ao e() {
        // Registers (7 total): v6 = this
        v0 = 1;
        v2 = new com.sec.chaton.a.ao;
        v1 = 0;
        _result = v2.<init>(v6, v1); // com.sec.chaton.a.ao.<init> -> void
        v3 = v6.a; // com.sec.chaton.a.ap.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_00a6 */;
        v4 = v6.b; // com.sec.chaton.a.ap.b:long
        _result = v2.a(v4, v5); // com.sec.chaton.a.ao.a -> long
        v1 = binOpLit8_0xdd(v3, 2);
        v4 = 2;
        if (v1 != v4) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v6.c; // com.sec.chaton.a.ap.c:com.sec.chaton.a.cp
        _result = v2.a(v1); // com.sec.chaton.a.ao.a -> com.sec.chaton.a.cp
        v1 = binOpLit8_0xdd(v3, 4);
        v4 = 4;
        if (v1 != v4) /* goto L_0026 */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = v6.d; // com.sec.chaton.a.ap.d:com.sec.chaton.a.ar
        _result = v2.a(v1); // com.sec.chaton.a.ao.a -> com.sec.chaton.a.ar
        v1 = binOpLit8_0xdd(v3, 8);
        v4 = 8;
        if (v1 != v4) /* goto L_0033 */;
        v0 = binOpLit8_0xde(v0, 8);
        v1 = v6.e; // com.sec.chaton.a.ap.e:java.lang.Object
        _result = v2.a(v1); // com.sec.chaton.a.ao.a -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 16);
        v4 = 16;
        if (v1 != v4) /* goto L_0040 */;
        v0 = binOpLit8_0xde(v0, 16);
        v1 = v6.f; // com.sec.chaton.a.ap.f:java.lang.Object
        _result = v2.b(v1); // com.sec.chaton.a.ao.b -> java.lang.Object
        v1 = v6.a; // com.sec.chaton.a.ap.a:int
        v1 = binOpLit8_0xdd(v1, 32);
        v4 = 32;
        if (v1 != v4) /* goto L_005c */;
        v1 = new com.google.protobuf.UnmodifiableLazyStringList;
        v4 = v6.g; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        _result = v1.<init>(v4); // com.google.protobuf.UnmodifiableLazyStringList.<init> -> void
        v6.g = v1; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        v1 = v6.a; // com.sec.chaton.a.ap.a:int
        v1 = binOpLit8_0xdd(v1, -33);
        v6.a = v1; // com.sec.chaton.a.ap.a:int
        v1 = v6.g; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        _result = v2.a(v1); // com.sec.chaton.a.ao.a -> com.google.protobuf.LazyStringList
        v1 = binOpLit8_0xdd(v3, 64);
        v4 = 64;
        if (v1 != v4) /* goto L_0069 */;
        v0 = binOpLit8_0xde(v0, 32);
        v1 = v6.h; // com.sec.chaton.a.ap.h:java.lang.Object
        _result = v2.c(v1); // com.sec.chaton.a.ao.c -> java.lang.Object
        v1 = binOpLit16_0xd5(v3, 128);
        v4 = 128;
        if (v1 != v4) /* goto L_0076 */;
        v0 = binOpLit8_0xde(v0, 64);
        v1 = v6.i; // com.sec.chaton.a.ap.i:java.lang.Object
        _result = v2.d(v1); // com.sec.chaton.a.ao.d -> java.lang.Object
        v1 = binOpLit16_0xd5(v3, 256);
        v4 = 256;
        if (v1 != v4) /* goto L_0083 */;
        v0 = binOpLit16_0xd6(v0, 128);
        v1 = v6.j; // com.sec.chaton.a.ap.j:java.lang.Object
        _result = v2.e(v1); // com.sec.chaton.a.ao.e -> java.lang.Object
        v1 = binOpLit16_0xd5(v3, 512);
        v4 = 512;
        if (v1 != v4) /* goto L_0090 */;
        v0 = binOpLit16_0xd6(v0, 256);
        v1 = v6.k; // com.sec.chaton.a.ap.k:java.lang.Object
        _result = v2.f(v1); // com.sec.chaton.a.ao.f -> java.lang.Object
        v1 = binOpLit16_0xd5(v3, 1024);
        v3 = 1024;
        if (v1 != v3) /* goto L_009d */;
        v0 = binOpLit16_0xd6(v0, 512);
        v3 = v6.l; // com.sec.chaton.a.ap.l:long
        _result = v2.b(v3, v4); // com.sec.chaton.a.ao.b -> long
        _result = v2.a(v0); // com.sec.chaton.a.ao.a -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.sec.chaton.a.ap e(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd6(v0, 128);
        v1.a = v0; // com.sec.chaton.a.ap.a:int
        v1.i = v2; // com.sec.chaton.a.ap.i:java.lang.Object
        return v1;
    }

    public long f() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ap.b:long
        return v0;
    }

    public com.sec.chaton.a.ap f(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd6(v0, 256);
        v1.a = v0; // com.sec.chaton.a.ap.a:int
        v1.j = v2; // com.sec.chaton.a.ap.j:java.lang.Object
        return v1;
    }

    public com.sec.chaton.a.ap g(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ap.a:int
        v0 = binOpLit16_0xd6(v0, 512);
        v1.a = v0; // com.sec.chaton.a.ap.a:int
        v1.k = v2; // com.sec.chaton.a.ap.k:java.lang.Object
        return v1;
    }

    public com.sec.chaton.a.cp g() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.sec.chaton.a.ap.c:com.sec.chaton.a.cp
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.ap.c -> com.sec.chaton.a.ao
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.ap.c -> com.sec.chaton.a.ao
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ar h() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.sec.chaton.a.ap.d:com.sec.chaton.a.ar
        return v0;
    }

    public java.lang.String i() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.chaton.a.ap.e:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 != 0) /* goto L_000f */;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v0 = _result;
        v2.e = v0; // com.sec.chaton.a.ap.e:java.lang.Object
        return v0;
        v0 = (java.lang.String) v0;
        // goto L_000e
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public java.lang.String j() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // com.sec.chaton.a.ap.f:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 != 0) /* goto L_000f */;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v0 = _result;
        v2.f = v0; // com.sec.chaton.a.ap.f:java.lang.Object
        return v0;
        v0 = (java.lang.String) v0;
        // goto L_000e
    }

    public java.util.List k() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.sec.chaton.a.ap.g:com.google.protobuf.LazyStringList
        _result = v0.unmodifiableList(); // java.util.Collections.unmodifiableList -> java.util.List
        v0 = _result;
        return v0;
    }

    public java.lang.String l() {
        // Registers (3 total): v2 = this
        v0 = v2.j; // com.sec.chaton.a.ap.j:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 != 0) /* goto L_000f */;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v0 = _result;
        v2.j = v0; // com.sec.chaton.a.ap.j:java.lang.Object
        return v0;
        v0 = (java.lang.String) v0;
        // goto L_000e
    }

    public long m() {
        // Registers (3 total): v2 = this
        v0 = v2.l; // com.sec.chaton.a.ap.l:long
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.chaton.a.ao) v2;
        _result = v1.a(v2); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.ap.a -> com.sec.chaton.a.ap
        v0 = _result;
        return v0;
    }

}