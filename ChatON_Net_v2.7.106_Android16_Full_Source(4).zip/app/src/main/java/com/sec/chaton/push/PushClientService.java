package com.sec.chaton.push;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

/**
 * ============================================================================
 * PushClientService — Safe Idle Stub Service for Android 16 (API 36)
 * ============================================================================
 */
public class PushClientService extends Service {
    private static final String TAG = "ChatON27_PushStub";

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "PushClientService initialized in local ChatON-Net LocalBridge stub mode (idle).");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
