package com.sec.chaton.a.a;

/**
 * Original SourceFile: ResultEntry.java
 * Descriptor: Lcom/sec/chaton/a/a/i;
 */
public final enum i {
    public static final com.sec.chaton.a.a.i a;
    public static final com.sec.chaton.a.a.i b;
    public static final com.sec.chaton.a.a.i c;
    public static final com.sec.chaton.a.a.i d;
    private static final com.sec.chaton.a.a.i[] e;

    static {
        v5 = 3;
        v4 = 2;
        v3 = 1;
        v2 = 0;
        v0 = new com.sec.chaton.a.a.i;
        v1 = "SUCCESS";
        _result = v0.<init>(v1, v2); // com.sec.chaton.a.a.i.<init> -> void
        com.sec.chaton.a.a.i.a = v0; // :com.sec.chaton.a.a.i
        v0 = new com.sec.chaton.a.a.i;
        v1 = "SUCCESS_UPLOAD_ONLY";
        _result = v0.<init>(v1, v3); // com.sec.chaton.a.a.i.<init> -> void
        com.sec.chaton.a.a.i.b = v0; // :com.sec.chaton.a.a.i
        v0 = new com.sec.chaton.a.a.i;
        v1 = "FAIL";
        _result = v0.<init>(v1, v4); // com.sec.chaton.a.a.i.<init> -> void
        com.sec.chaton.a.a.i.c = v0; // :com.sec.chaton.a.a.i
        v0 = new com.sec.chaton.a.a.i;
        v1 = "NETWORKFAIL";
        _result = v0.<init>(v1, v5); // com.sec.chaton.a.a.i.<init> -> void
        com.sec.chaton.a.a.i.d = v0; // :com.sec.chaton.a.a.i
        v0 = 4;
        v0 = new com.sec.chaton.a.a.i[][size=v0];
        v1 = com.sec.chaton.a.a.i.a; // :com.sec.chaton.a.a.i
        v0[v2] = v1;
        v1 = com.sec.chaton.a.a.i.b; // :com.sec.chaton.a.a.i
        v0[v3] = v1;
        v1 = com.sec.chaton.a.a.i.c; // :com.sec.chaton.a.a.i
        v0[v4] = v1;
        v1 = com.sec.chaton.a.a.i.d; // :com.sec.chaton.a.a.i
        v0[v5] = v1;
        com.sec.chaton.a.a.i.e = v0; // :com.sec.chaton.a.a.i[]
        return;
    }

    private i(java.lang.String p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        return;
    }

    public static com.sec.chaton.a.a.i valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = com.sec.chaton.a.a.i.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (com.sec.chaton.a.a.i) v0;
        return v0;
    }

    public static com.sec.chaton.a.a.i[] values() {
        v0 = com.sec.chaton.a.a.i.e; // :com.sec.chaton.a.a.i[]
        _result = v0.clone(); // com.sec.chaton.a.a.i[].clone -> java.lang.Object
        v0 = _result;
        v0 = (com.sec.chaton.a.a.i[]) v0;
        return v0;
    }

}