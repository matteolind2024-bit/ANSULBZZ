package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/ag;
 */
public final class ag extends com.google.protobuf.GeneratedMessageLite implements com.sec.chaton.a.ai {
    private static final com.sec.chaton.a.ag a;
    private int b;
    private com.sec.chaton.a.aj c;
    private java.lang.Object d;
    private java.lang.Object e;
    private byte f;
    private int g;

    static {
        v0 = new com.sec.chaton.a.ag;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.chaton.a.ag.<init> -> void
        com.sec.chaton.a.ag.a = v0; // :com.sec.chaton.a.ag
        v0 = com.sec.chaton.a.ag.a; // :com.sec.chaton.a.ag
        _result = v0.m(); // com.sec.chaton.a.ag.m -> void
        return;
    }

    private ag(com.sec.chaton.a.ah p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.ah)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.f = v0; // com.sec.chaton.a.ag.f:byte
        v1.g = v0; // com.sec.chaton.a.ag.g:int
        return;
    }

    ag(com.sec.chaton.a.ah p0, com.sec.chaton.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.chaton.a.ah), v2 = p1 (com.sec.chaton.a.b)
        _result = v0.<init>(v1); // com.sec.chaton.a.ag.<init> -> void
        return;
    }

    private ag(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.f = v0; // com.sec.chaton.a.ag.f:byte
        v1.g = v0; // com.sec.chaton.a.ag.g:int
        return;
    }

    static int a(com.sec.chaton.a.ag p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ag), v1 = p1 (int)
        v0.b = v1; // com.sec.chaton.a.ag.b:int
        return v1;
    }

    public static com.sec.chaton.a.ag a() {
        v0 = com.sec.chaton.a.ag.a; // :com.sec.chaton.a.ag
        return v0;
    }

    public static com.sec.chaton.a.ah a(com.sec.chaton.a.ag p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.ag)
        _result = this.newBuilder(); // com.sec.chaton.a.ag.newBuilder -> com.sec.chaton.a.ah
        v0 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.ah.a -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    static com.sec.chaton.a.aj a(com.sec.chaton.a.ag p0, com.sec.chaton.a.aj p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ag), v1 = p1 (com.sec.chaton.a.aj)
        v0.c = v1; // com.sec.chaton.a.ag.c:com.sec.chaton.a.aj
        return v1;
    }

    static java.lang.Object a(com.sec.chaton.a.ag p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ag), v1 = p1 (java.lang.Object)
        v0.d = v1; // com.sec.chaton.a.ag.d:java.lang.Object
        return v1;
    }

    static java.lang.Object b(com.sec.chaton.a.ag p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ag), v1 = p1 (java.lang.Object)
        v0.e = v1; // com.sec.chaton.a.ag.e:java.lang.Object
        return v1;
    }

    private com.google.protobuf.ByteString k() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.chaton.a.ag.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.d = v0; // com.sec.chaton.a.ag.d:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString l() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.chaton.a.ag.e:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.e = v0; // com.sec.chaton.a.ag.e:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void m() {
        // Registers (2 total): v1 = this
        v0 = com.sec.chaton.a.aj.a; // :com.sec.chaton.a.aj
        v1.c = v0; // com.sec.chaton.a.ag.c:com.sec.chaton.a.aj
        v0 = "";
        v1.d = v0; // com.sec.chaton.a.ag.d:java.lang.Object
        v0 = "";
        v1.e = v0; // com.sec.chaton.a.ag.e:java.lang.Object
        return;
    }

    public static com.sec.chaton.a.ah newBuilder() {
        _result = this.f(); // com.sec.chaton.a.ah.f -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ag b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.chaton.a.ag.a; // :com.sec.chaton.a.ag
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.chaton.a.ag.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public com.sec.chaton.a.aj d() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.sec.chaton.a.ag.c:com.sec.chaton.a.aj
        return v0;
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ag.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public java.lang.String f() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.chaton.a.ag.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.d = v1; // com.sec.chaton.a.ag.d:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean g() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ag.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ag.b -> com.sec.chaton.a.ag
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (5 total): v4 = this
        v3 = 2;
        v2 = 1;
        v0 = v4.g; // com.sec.chaton.a.ag.g:int
        v1 = -1;
        if (v0 == v1) /* goto L_0008 */;
        return v0;
        v0 = 0;
        v1 = v4.b; // com.sec.chaton.a.ag.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v2) /* goto L_001a */;
        v1 = v4.c; // com.sec.chaton.a.ag.c:com.sec.chaton.a.aj
        _result = v1.getNumber(); // com.sec.chaton.a.aj.getNumber -> int
        v1 = _result;
        _result = v2.computeEnumSize(v1); // com.google.protobuf.CodedOutputStream.computeEnumSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v4.b; // com.sec.chaton.a.ag.b:int
        v1 = binOpLit8_0xdd(v1, 2);
        if (v1 != v3) /* goto L_0029 */;
        _result = v4.k(); // com.sec.chaton.a.ag.k -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v3.computeBytesSize(v1); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v4.b; // com.sec.chaton.a.ag.b:int
        v1 = binOpLit8_0xdd(v1, 4);
        v2 = 4;
        if (v1 != v2) /* goto L_003a */;
        v1 = 3;
        _result = v4.l(); // com.sec.chaton.a.ag.l -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v4.g = v0; // com.sec.chaton.a.ag.g:int
        // goto L_0007
    }

    public java.lang.String h() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.chaton.a.ag.e:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.e = v1; // com.sec.chaton.a.ag.e:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public com.sec.chaton.a.ah i() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.chaton.a.ag.newBuilder -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.f; // com.sec.chaton.a.ag.f:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.f = v0; // com.sec.chaton.a.ag.f:byte
        // goto L_0008
    }

    public com.sec.chaton.a.ah j() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.ag.a -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.i(); // com.sec.chaton.a.ag.i -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.j(); // com.sec.chaton.a.ag.j -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (5 total): v3 = this, v4 = p0 (com.google.protobuf.CodedOutputStream)
        v2 = 2;
        v1 = 1;
        _result = v3.getSerializedSize(); // com.sec.chaton.a.ag.getSerializedSize -> int
        v0 = v3.b; // com.sec.chaton.a.ag.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v1) /* goto L_0014 */;
        v0 = v3.c; // com.sec.chaton.a.ag.c:com.sec.chaton.a.aj
        _result = v0.getNumber(); // com.sec.chaton.a.aj.getNumber -> int
        v0 = _result;
        _result = v4.writeEnum(v1, v0); // com.google.protobuf.CodedOutputStream.writeEnum -> void
        v0 = v3.b; // com.sec.chaton.a.ag.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v2) /* goto L_0021 */;
        _result = v3.k(); // com.sec.chaton.a.ag.k -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v4.writeBytes(v2, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v3.b; // com.sec.chaton.a.ag.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0030 */;
        v0 = 3;
        _result = v3.l(); // com.sec.chaton.a.ag.l -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v4.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        return;
    }

}