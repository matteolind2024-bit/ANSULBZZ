package com.sec.chaton;

/**
 * Original SourceFile: HomeTabFragment.java
 * Descriptor: Lcom/sec/chaton/HomeTabFragment;
 */
public class HomeTabFragment extends android.support.v4.app.Fragment implements android.widget.TabHost$OnTabChangeListener {
     com.sec.chaton.e.a.s a;
    private android.widget.TabHost b;
    private android.widget.TabWidget c;
    private java.util.HashMap d;
    private java.lang.String e;
    private java.lang.String f;
    private int g;
    private int h;
    private com.sec.chaton.e.a.r i;
    private boolean j;
    private boolean k;
    private boolean l;
    private boolean m;
    private boolean n;
    private android.database.ContentObserver o;
    private android.database.ContentObserver p;
    private android.database.ContentObserver q;
    private android.content.BroadcastReceiver r;
    private android.content.BroadcastReceiver s;

    public HomeTabFragment() {
        // Registers (3 total): v2 = this
        _result = v2.<init>(); // android.support.v4.app.Fragment.<init> -> void
        v0 = new com.sec.chaton.w;
        _result = v0.<init>(v2); // com.sec.chaton.w.<init> -> void
        v2.a = v0; // com.sec.chaton.HomeTabFragment.a:com.sec.chaton.e.a.s
        v0 = new com.sec.chaton.x;
        v1 = new android.os.Handler;
        _result = v1.<init>(); // android.os.Handler.<init> -> void
        _result = v0.<init>(v2, v1); // com.sec.chaton.x.<init> -> void
        v2.o = v0; // com.sec.chaton.HomeTabFragment.o:android.database.ContentObserver
        v0 = new com.sec.chaton.y;
        v1 = new android.os.Handler;
        _result = v1.<init>(); // android.os.Handler.<init> -> void
        _result = v0.<init>(v2, v1); // com.sec.chaton.y.<init> -> void
        v2.p = v0; // com.sec.chaton.HomeTabFragment.p:android.database.ContentObserver
        v0 = new com.sec.chaton.z;
        v1 = new android.os.Handler;
        _result = v1.<init>(); // android.os.Handler.<init> -> void
        _result = v0.<init>(v2, v1); // com.sec.chaton.z.<init> -> void
        v2.q = v0; // com.sec.chaton.HomeTabFragment.q:android.database.ContentObserver
        v0 = new com.sec.chaton.aa;
        _result = v0.<init>(v2); // com.sec.chaton.aa.<init> -> void
        v2.r = v0; // com.sec.chaton.HomeTabFragment.r:android.content.BroadcastReceiver
        v0 = new com.sec.chaton.ab;
        _result = v0.<init>(v2); // com.sec.chaton.ab.<init> -> void
        v2.s = v0; // com.sec.chaton.HomeTabFragment.s:android.content.BroadcastReceiver
        return;
    }

    static int a(com.sec.chaton.HomeTabFragment p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.HomeTabFragment), v1 = p1 (int)
        v0.g = v1; // com.sec.chaton.HomeTabFragment.g:int
        return v1;
    }

    private void a(android.database.Cursor p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.database.Cursor)
        _result = this.a(); // com.sec.chaton.e.b.e.a -> com.sec.chaton.e.b.e
        v0 = _result;
        _result = v0.c(); // com.sec.chaton.e.b.e.c -> android.os.Message
        v0 = _result;
        v0.obj = v3; // android.os.Message.obj:java.lang.Object
        _result = this.a(); // com.sec.chaton.e.b.e.a -> com.sec.chaton.e.b.e
        v1 = _result;
        _result = v1.b(); // com.sec.chaton.e.b.e.b -> android.os.Handler
        v1 = _result;
        _result = v1.sendMessage(v0); // android.os.Handler.sendMessage -> boolean
        return;
    }

    public static void a(android.support.v4.app.Fragment p0, android.widget.TabHost p1, android.widget.TabWidget p2, java.util.HashMap p3, int p4, int p5, java.lang.String p6, android.support.v4.app.Fragment p7) {
        // Registers (11 total): v3 = p0 (android.support.v4.app.Fragment), v4 = p1 (android.widget.TabHost), v5 = p2 (android.widget.TabWidget), v6 = p3 (java.util.HashMap), v7 = p4 (int), v8 = p5 (int), v9 = p6 (java.lang.String), v10 = p7 (android.support.v4.app.Fragment)
        v2 = -1;
        v0 = new android.widget.FrameLayout;
        _result = v3.getActivity(); // android.support.v4.app.Fragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v0.<init>(v1); // android.widget.FrameLayout.<init> -> void
        _result = v0.setId(v7); // android.widget.FrameLayout.setId -> void
        v1 = new android.view.ViewGroup$LayoutParams;
        _result = v1.<init>(v2, v2); // android.view.ViewGroup$LayoutParams.<init> -> void
        _result = v0.setLayoutParams(v1); // android.widget.FrameLayout.setLayoutParams -> void
        _result = v4.getTabContentView(); // android.widget.TabHost.getTabContentView -> android.widget.FrameLayout
        v1 = _result;
        _result = v1.addView(v0); // android.view.ViewGroup.addView -> void
        _result = v3.getActivity(); // android.support.v4.app.Fragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getLayoutInflater(); // android.support.v4.app.FragmentActivity.getLayoutInflater -> android.view.LayoutInflater
        v0 = _result;
        v1 = 0;
        _result = v0.inflate(v8, v5, v1); // android.view.LayoutInflater.inflate -> android.view.View
        v0 = _result;
        v0 = (android.view.ViewGroup) v0;
        _result = v0.setTag(v9); // android.view.ViewGroup.setTag -> void
        if (v10 == 0) /* goto L_0059 */;
        _result = v3.getFragmentManager(); // android.support.v4.app.Fragment.getFragmentManager -> android.support.v4.app.FragmentManager
        v1 = _result;
        _result = v1.beginTransaction(); // android.support.v4.app.FragmentManager.beginTransaction -> android.support.v4.app.FragmentTransaction
        v1 = _result;
        _result = v1.add(v7, v10, v9); // android.support.v4.app.FragmentTransaction.add -> android.support.v4.app.FragmentTransaction
        v1 = _result;
        _result = v1.commit(); // android.support.v4.app.FragmentTransaction.commit -> int
        v1 = v10;
        v2 = (v1 instanceof com.sec.chaton.ac);
        if (v2 == 0) /* goto L_0049 */;
        v1 = (com.sec.chaton.ac) v1;
        _result = v6.put(v9, v1); // java.util.HashMap.put -> java.lang.Object
        _result = v4.newTabSpec(v9); // android.widget.TabHost.newTabSpec -> android.widget.TabHost$TabSpec
        v1 = _result;
        _result = v1.setIndicator(v0); // android.widget.TabHost$TabSpec.setIndicator -> android.widget.TabHost$TabSpec
        v0 = _result;
        _result = v0.setContent(v7); // android.widget.TabHost$TabSpec.setContent -> android.widget.TabHost$TabSpec
        v0 = _result;
        _result = v4.addTab(v0); // android.widget.TabHost.addTab -> void
        return;
        _result = v3.getFragmentManager(); // android.support.v4.app.Fragment.getFragmentManager -> android.support.v4.app.FragmentManager
        v1 = _result;
        _result = v1.findFragmentByTag(v9); // android.support.v4.app.FragmentManager.findFragmentByTag -> android.support.v4.app.Fragment
        v1 = _result;
        // goto L_0040
    }

    static void a(android.widget.TabWidget p0, java.lang.String p1, int p2) {
        // Registers (3 total): v0 = p0 (android.widget.TabWidget), v1 = p1 (java.lang.String), v2 = p2 (int)
        _result = v0.b(v1, v2); // com.sec.chaton.HomeTabFragment.b -> void
        return;
    }

    static void a(com.sec.chaton.HomeTabFragment p0, android.database.Cursor p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.HomeTabFragment), v1 = p1 (android.database.Cursor)
        _result = v0.a(v1); // com.sec.chaton.HomeTabFragment.a -> void
        return;
    }

    static boolean a(com.sec.chaton.HomeTabFragment p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.HomeTabFragment)
        v0 = v1.n; // com.sec.chaton.HomeTabFragment.n:boolean
        return v0;
    }

    static boolean a(com.sec.chaton.HomeTabFragment p0, boolean p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.HomeTabFragment), v1 = p1 (boolean)
        v0.j = v1; // com.sec.chaton.HomeTabFragment.j:boolean
        return v1;
    }

    static int b(com.sec.chaton.HomeTabFragment p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.HomeTabFragment), v1 = p1 (int)
        v0.h = v1; // com.sec.chaton.HomeTabFragment.h:int
        return v1;
    }

    static android.widget.TabWidget b(com.sec.chaton.HomeTabFragment p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.HomeTabFragment)
        v0 = v1.c; // com.sec.chaton.HomeTabFragment.c:android.widget.TabWidget
        return v0;
    }

    private void b() {
        // Registers (6 total): v5 = this
        v4 = 0;
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "new_post_on_count";
        _result = v4.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.Integer
        v0 = _result;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v1 = _result;
        v0 = v5.c; // com.sec.chaton.HomeTabFragment.c:android.widget.TabWidget
        v2 = "My page";
        _result = v0.findViewWithTag(v2); // android.widget.TabWidget.findViewWithTag -> android.view.View
        v0 = _result;
        if (v0 != 0) /* goto L_001e */;
        return;
        v2 = com.sec.chaton.R.id.tab_badge; // 0x7f08070e
        _result = v0.findViewById(v2); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TextView) v0;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "My page totalNumBadge : ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        _result = v3.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v3 = _result;
        _result = v2.e(v3); // com.sec.chaton.util.p.e -> void
        if (v1 <= 0) /* goto L_0051 */;
        _result = v0.setVisibility(v4); // android.widget.TextView.setVisibility -> void
        _result = v0.a(v1); // com.sec.chaton.util.cb.a -> void
        _result = v0.invalidate(); // android.widget.TextView.invalidate -> void
        // goto L_001d
        v1 = 8;
        _result = v0.setVisibility(v1); // android.widget.TextView.setVisibility -> void
        // goto L_004d
    }

    private static void b(android.widget.TabWidget p0, java.lang.String p1, int p2) {
        // Registers (7 total): v4 = p0 (android.widget.TabWidget), v5 = p1 (java.lang.String), v6 = p2 (int)
        v3 = 0;
        _result = v4.findViewWithTag(v5); // android.widget.TabWidget.findViewWithTag -> android.view.View
        v0 = _result;
        v1 = com.sec.chaton.R.id.tab_badge; // 0x7f08070e
        _result = v0.findViewById(v1); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TextView) v0;
        if (v6 <= 0) /* goto L_008d */;
        _result = v0.setVisibility(v3); // android.widget.TextView.setVisibility -> void
        v1 = 100;
        if (v6 < v1) /* goto L_0064 */;
        v1 = com.sec.chaton.R.string.chat_max_unread; // 0x7f0c0090
        _result = v0.setText(v1); // android.widget.TextView.setText -> void
        _result = v0.getResources(); // android.widget.TextView.getResources -> android.content.res.Resources
        v1 = _result;
        v2 = com.sec.chaton.R.dimen.text_size_10; // 0x7f0b0070
        _result = v1.getDimension(v2); // android.content.res.Resources.getDimension -> float
        v1 = _result;
        _result = v0.setTextSize(v3, v1); // android.widget.TextView.setTextSize -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "badgeType : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", count : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = "HomeTabFragment";
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        v0 = "Buddies";
        if (v5 != v0) /* goto L_0063 */;
        v0 = new android.content.Intent;
        v1 = "buddy_tab_badge_update";
        _result = v0.<init>(v1); // android.content.Intent.<init> -> void
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v1 = _result;
        _result = v1.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v1 = _result;
        _result = v1.sendBroadcast(v0); // android.support.v4.content.LocalBroadcastManager.sendBroadcast -> boolean
        return;
        _result = v6.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v1 = _result;
        _result = v0.setText(v1); // android.widget.TextView.setText -> void
        v1 = 10;
        if (v6 < v1) /* goto L_007e */;
        _result = v0.getResources(); // android.widget.TextView.getResources -> android.content.res.Resources
        v1 = _result;
        v2 = com.sec.chaton.R.dimen.text_size_12; // 0x7f0b0071
        _result = v1.getDimension(v2); // android.content.res.Resources.getDimension -> float
        v1 = _result;
        _result = v0.setTextSize(v3, v1); // android.widget.TextView.setTextSize -> void
        // goto L_002b
        _result = v0.getResources(); // android.widget.TextView.getResources -> android.content.res.Resources
        v1 = _result;
        v2 = com.sec.chaton.R.dimen.text_size_13; // 0x7f0b0072
        _result = v1.getDimension(v2); // android.content.res.Resources.getDimension -> float
        v1 = _result;
        _result = v0.setTextSize(v3, v1); // android.widget.TextView.setTextSize -> void
        // goto L_002b
        v1 = 8;
        _result = v0.setVisibility(v1); // android.widget.TextView.setVisibility -> void
        // goto L_0063
    }

    static boolean b(com.sec.chaton.HomeTabFragment p0, boolean p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.HomeTabFragment), v1 = p1 (boolean)
        v0.k = v1; // com.sec.chaton.HomeTabFragment.k:boolean
        return v1;
    }

    static int c(com.sec.chaton.HomeTabFragment p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.HomeTabFragment)
        v0 = v1.g; // com.sec.chaton.HomeTabFragment.g:int
        return v0;
    }

    private void c() {
        // Registers (4 total): v3 = this
        _result = this.e(); // com.sec.chaton.MoreFragment.e -> int
        v1 = _result;
        v0 = v3.c; // com.sec.chaton.HomeTabFragment.c:android.widget.TabWidget
        v2 = "More";
        _result = v0.findViewWithTag(v2); // android.widget.TabWidget.findViewWithTag -> android.view.View
        v0 = _result;
        if (v0 != 0) /* goto L_000f */;
        return;
        v2 = com.sec.chaton.R.id.tab_badge; // 0x7f08070e
        _result = v0.findViewById(v2); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TextView) v0;
        if (v1 <= 0) /* goto L_0025 */;
        v2 = 0;
        _result = v0.setVisibility(v2); // android.widget.TextView.setVisibility -> void
        _result = v0.a(v1); // com.sec.chaton.util.cb.a -> void
        _result = v0.invalidate(); // android.widget.TextView.invalidate -> void
        // goto L_000e
        v1 = 8;
        _result = v0.setVisibility(v1); // android.widget.TextView.setVisibility -> void
        // goto L_0021
    }

    static boolean c(com.sec.chaton.HomeTabFragment p0, boolean p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.HomeTabFragment), v1 = p1 (boolean)
        v0.l = v1; // com.sec.chaton.HomeTabFragment.l:boolean
        return v1;
    }

    static int d(com.sec.chaton.HomeTabFragment p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.HomeTabFragment)
        v0 = v1.h; // com.sec.chaton.HomeTabFragment.h:int
        return v0;
    }

    private void d() {
        // Registers (10 total): v9 = this
        v8 = 0;
        v2 = 0;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "badge need : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v9.j; // com.sec.chaton.HomeTabFragment.j:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = "HomeTabFragment";
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        v0 = v9.j; // com.sec.chaton.HomeTabFragment.j:boolean
        if (v0 == 0) /* goto L_005b */;
        v9.j = v8; // com.sec.chaton.HomeTabFragment.j:boolean
        v0 = v9.k; // com.sec.chaton.HomeTabFragment.k:boolean
        if (v0 == 0) /* goto L_0035 */;
        v9.k = v8; // com.sec.chaton.HomeTabFragment.k:boolean
        v0 = v9.i; // com.sec.chaton.HomeTabFragment.i:com.sec.chaton.e.a.r
        v1 = 2;
        v3 = com.sec.chaton.e.m.a; // :android.net.Uri
        v5 = "inbox_unread_count > 0";
        v4 = v2;
        v6 = v2;
        v7 = v2;
        _result = v0.startQuery(v0..v7); // com.sec.chaton.e.a.r.startQuery -> void
        v0 = v9.l; // com.sec.chaton.HomeTabFragment.l:boolean
        if (v0 == 0) /* goto L_0048 */;
        v9.l = v8; // com.sec.chaton.HomeTabFragment.l:boolean
        v0 = v9.i; // com.sec.chaton.HomeTabFragment.i:com.sec.chaton.e.a.r
        v1 = 1;
        v3 = com.sec.chaton.e.f.a; // :android.net.Uri
        v5 = "buddy_is_new='Y'";
        v4 = v2;
        v6 = v2;
        v7 = v2;
        _result = v0.startQuery(v0..v7); // com.sec.chaton.e.a.r.startQuery -> void
        v0 = v9.m; // com.sec.chaton.HomeTabFragment.m:boolean
        if (v0 == 0) /* goto L_005b */;
        v9.m = v8; // com.sec.chaton.HomeTabFragment.m:boolean
        v0 = v9.i; // com.sec.chaton.HomeTabFragment.i:com.sec.chaton.e.a.r
        v1 = 3;
        v3 = com.sec.chaton.e.z.a; // :android.net.Uri
        v5 = "isNew='Y'";
        v4 = v2;
        v6 = v2;
        v7 = v2;
        _result = v0.startQuery(v0..v7); // com.sec.chaton.e.a.r.startQuery -> void
        return;
    }

    static boolean d(com.sec.chaton.HomeTabFragment p0, boolean p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.HomeTabFragment), v1 = p1 (boolean)
        v0.m = v1; // com.sec.chaton.HomeTabFragment.m:boolean
        return v1;
    }

    static com.sec.chaton.e.a.r e(com.sec.chaton.HomeTabFragment p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.HomeTabFragment)
        v0 = v1.i; // com.sec.chaton.HomeTabFragment.i:com.sec.chaton.e.a.r
        return v0;
    }

    static void f(com.sec.chaton.HomeTabFragment p0) {
        // Registers (1 total): v0 = p0 (com.sec.chaton.HomeTabFragment)
        _result = v0.b(); // com.sec.chaton.HomeTabFragment.b -> void
        return;
    }

    static void g(com.sec.chaton.HomeTabFragment p0) {
        // Registers (1 total): v0 = p0 (com.sec.chaton.HomeTabFragment)
        _result = v0.c(); // com.sec.chaton.HomeTabFragment.c -> void
        return;
    }

    public int a() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        if (v0 == 0) /* goto L_000b */;
        v0 = v1.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        _result = v0.getCurrentTab(); // android.widget.TabHost.getCurrentTab -> int
        v0 = _result;
        return v0;
        v0 = -1;
        // goto L_000a
    }

    public void onActivityCreated(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onActivityCreated(v3); // android.support.v4.app.Fragment.onActivityCreated -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onActivityCrated, MemoryAddress : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        if (v3 == 0) /* goto L_0033 */;
        v0 = "current_position";
        _result = v3.containsKey(v0); // android.os.Bundle.containsKey -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0033 */;
        v0 = "current_position";
        _result = v3.getString(v0); // android.os.Bundle.getString -> java.lang.String
        v0 = _result;
        v2.f = v0; // com.sec.chaton.HomeTabFragment.f:java.lang.String
        return;
    }

    public void onAttach(android.app.Activity p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.app.Activity)
        _result = v2.onAttach(v3); // android.support.v4.app.Fragment.onAttach -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onAttach, MemoryAddress : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        return;
    }

    public void onCreate(android.os.Bundle p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.os.Bundle)
        v3 = 1;
        _result = v4.onCreate(v5); // android.support.v4.app.Fragment.onCreate -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onCreate, MemoryAddress : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        v0 = new com.sec.chaton.e.a.r;
        _result = v4.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v1.getContentResolver(); // android.support.v4.app.FragmentActivity.getContentResolver -> android.content.ContentResolver
        v1 = _result;
        v2 = v4.a; // com.sec.chaton.HomeTabFragment.a:com.sec.chaton.e.a.s
        _result = v0.<init>(v1, v2); // com.sec.chaton.e.a.r.<init> -> void
        v4.i = v0; // com.sec.chaton.HomeTabFragment.i:com.sec.chaton.e.a.r
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        v4.d = v0; // com.sec.chaton.HomeTabFragment.d:java.util.HashMap
        _result = v4.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getContentResolver(); // android.support.v4.app.FragmentActivity.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        v1 = com.sec.chaton.e.m.a; // :android.net.Uri
        v2 = v4.q; // com.sec.chaton.HomeTabFragment.q:android.database.ContentObserver
        _result = v0.registerContentObserver(v1, v3, v2); // android.content.ContentResolver.registerContentObserver -> void
        _result = v4.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getContentResolver(); // android.support.v4.app.FragmentActivity.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        v1 = com.sec.chaton.e.f.a; // :android.net.Uri
        v2 = v4.o; // com.sec.chaton.HomeTabFragment.o:android.database.ContentObserver
        _result = v0.registerContentObserver(v1, v3, v2); // android.content.ContentResolver.registerContentObserver -> void
        _result = v4.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getContentResolver(); // android.support.v4.app.FragmentActivity.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        v1 = com.sec.chaton.e.z.a; // :android.net.Uri
        v2 = v4.p; // com.sec.chaton.HomeTabFragment.p:android.database.ContentObserver
        _result = v0.registerContentObserver(v1, v3, v2); // android.content.ContentResolver.registerContentObserver -> void
        v0 = "onCreate : regist Observer";
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        return;
    }

    public android.view.View onCreateView(android.view.LayoutInflater p0, android.view.ViewGroup p1, android.os.Bundle p2) {
        // Registers (15 total): v11 = this, v12 = p0 (android.view.LayoutInflater), v13 = p1 (android.view.ViewGroup), v14 = p2 (android.os.Bundle)
        v8 = 0;
        v10 = 1;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onCreateView, MemoryAddress : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v11); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v11.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        v0 = com.sec.chaton.R.layout.layout_fragment_tab; // 0x7f0300b7
        v1 = 0;
        _result = v12.inflate(v0, v13, v1); // android.view.LayoutInflater.inflate -> android.view.View
        v9 = _result;
        v0 = 16908306; // 0x01020012
        _result = v9.findViewById(v0); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TabHost) v0;
        v11.b = v0; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        v0 = 16908307; // 0x01020013
        _result = v9.findViewById(v0); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TabWidget) v0;
        v11.c = v0; // com.sec.chaton.HomeTabFragment.c:android.widget.TabWidget
        v0 = v11.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        _result = v0.setup(); // android.widget.TabHost.setup -> void
        v0 = v11.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        _result = v0.setOnTabChangedListener(v11); // android.widget.TabHost.setOnTabChangedListener -> void
        v1 = v11.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        v2 = v11.c; // com.sec.chaton.HomeTabFragment.c:android.widget.TabWidget
        v3 = v11.d; // com.sec.chaton.HomeTabFragment.d:java.util.HashMap
        v4 = com.sec.chaton.R.id.fragment_buddy; // 0x7f080002
        v5 = com.sec.chaton.R.layout.tab_indicator_badge_buddy; // 0x7f030186
        v6 = "Buddies";
        if (v14 != 0) /* goto L_00c2 */;
        v7 = new com.sec.chaton.buddy.BuddyFragment;
        _result = v7.<init>(); // com.sec.chaton.buddy.BuddyFragment.<init> -> void
        v0 = v11;
        _result = v0.a(v0..v7); // com.sec.chaton.HomeTabFragment.a -> void
        v1 = v11.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        v2 = v11.c; // com.sec.chaton.HomeTabFragment.c:android.widget.TabWidget
        v3 = v11.d; // com.sec.chaton.HomeTabFragment.d:java.util.HashMap
        v4 = com.sec.chaton.R.id.fragment_msg_box; // 0x7f080003
        v5 = com.sec.chaton.R.layout.tab_indicator_badge_chat; // 0x7f030187
        v6 = "Chat";
        if (v14 != 0) /* goto L_00c4 */;
        v7 = new com.sec.chaton.msgbox.MsgboxFragment;
        _result = v7.<init>(); // com.sec.chaton.msgbox.MsgboxFragment.<init> -> void
        v0 = v11;
        _result = v0.a(v0..v7); // com.sec.chaton.HomeTabFragment.a -> void
        v1 = v11.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        v2 = v11.c; // com.sec.chaton.HomeTabFragment.c:android.widget.TabWidget
        v3 = v11.d; // com.sec.chaton.HomeTabFragment.d:java.util.HashMap
        v4 = com.sec.chaton.R.id.fragment_user_profile; // 0x7f080004
        v5 = com.sec.chaton.R.layout.tab_indicator_badge_mypage; // 0x7f030189
        v6 = "My page";
        if (v14 != 0) /* goto L_00c6 */;
        v7 = new com.sec.chaton.userprofile.MyPageFragment;
        _result = v7.<init>(); // com.sec.chaton.userprofile.MyPageFragment.<init> -> void
        v0 = v11;
        _result = v0.a(v0..v7); // com.sec.chaton.HomeTabFragment.a -> void
        v1 = v11.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        v2 = v11.c; // com.sec.chaton.HomeTabFragment.c:android.widget.TabWidget
        v3 = v11.d; // com.sec.chaton.HomeTabFragment.d:java.util.HashMap
        v4 = com.sec.chaton.R.id.fragment_more_tab; // 0x7f080006
        v5 = com.sec.chaton.R.layout.tab_indicator_badge_more; // 0x7f030188
        v6 = "More";
        if (v14 != 0) /* goto L_00c8 */;
        v7 = new com.sec.chaton.MoreFragment;
        _result = v7.<init>(); // com.sec.chaton.MoreFragment.<init> -> void
        v0 = v11;
        _result = v0.a(v0..v7); // com.sec.chaton.HomeTabFragment.a -> void
        v11.j = v10; // com.sec.chaton.HomeTabFragment.j:boolean
        v11.k = v10; // com.sec.chaton.HomeTabFragment.k:boolean
        v11.l = v10; // com.sec.chaton.HomeTabFragment.l:boolean
        v11.m = v10; // com.sec.chaton.HomeTabFragment.m:boolean
        v0 = "onCreateView : need set true";
        _result = v11.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        return v9;
        v7 = v8;
        // goto L_005d
        v7 = v8;
        // goto L_0076
        v7 = v8;
        // goto L_008f
        v7 = v8;
        // goto L_00a8
    }

    public void onDestroy() {
        // Registers (3 total): v2 = this
        _result = v2.onDestroy(); // android.support.v4.app.Fragment.onDestroy -> void
        _result = v2.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getContentResolver(); // android.support.v4.app.FragmentActivity.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        v1 = v2.q; // com.sec.chaton.HomeTabFragment.q:android.database.ContentObserver
        _result = v0.unregisterContentObserver(v1); // android.content.ContentResolver.unregisterContentObserver -> void
        _result = v2.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getContentResolver(); // android.support.v4.app.FragmentActivity.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        v1 = v2.o; // com.sec.chaton.HomeTabFragment.o:android.database.ContentObserver
        _result = v0.unregisterContentObserver(v1); // android.content.ContentResolver.unregisterContentObserver -> void
        _result = v2.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getContentResolver(); // android.support.v4.app.FragmentActivity.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        v1 = v2.p; // com.sec.chaton.HomeTabFragment.p:android.database.ContentObserver
        _result = v0.unregisterContentObserver(v1); // android.content.ContentResolver.unregisterContentObserver -> void
        v0 = "onDestroy : unregist observer";
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        return;
    }

    public void onPause() {
        // Registers (3 total): v2 = this
        _result = v2.onPause(); // android.support.v4.app.Fragment.onPause -> void
        v0 = 1;
        v2.n = v0; // com.sec.chaton.HomeTabFragment.n:boolean
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onPause, MemoryAddress : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        _result = v2.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v0 = _result;
        v1 = v2.r; // com.sec.chaton.HomeTabFragment.r:android.content.BroadcastReceiver
        _result = v0.unregisterReceiver(v1); // android.support.v4.content.LocalBroadcastManager.unregisterReceiver -> void
        _result = v2.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v0 = _result;
        v1 = v2.s; // com.sec.chaton.HomeTabFragment.s:android.content.BroadcastReceiver
        _result = v0.unregisterReceiver(v1); // android.support.v4.content.LocalBroadcastManager.unregisterReceiver -> void
        v0 = "preTab_position";
        v1 = v2.e; // com.sec.chaton.HomeTabFragment.e:java.lang.String
        _result = v0.a(v1); // com.sec.chaton.util.r.a -> void
        return;
    }

    public void onResume() {
        // Registers (4 total): v3 = this
        _result = v3.onResume(); // android.support.v4.app.Fragment.onResume -> void
        v0 = 0;
        v3.n = v0; // com.sec.chaton.HomeTabFragment.n:boolean
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onResume, MemoryAddress : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        v0 = v3.f; // com.sec.chaton.HomeTabFragment.f:java.lang.String
        _result = v0.isEmpty(); // android.text.TextUtils.isEmpty -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0036 */;
        v0 = v3.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        v1 = v3.f; // com.sec.chaton.HomeTabFragment.f:java.lang.String
        _result = v0.setCurrentTabByTag(v1); // android.widget.TabHost.setCurrentTabByTag -> void
        v0 = 0;
        v3.f = v0; // com.sec.chaton.HomeTabFragment.f:java.lang.String
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "preTab_position";
        v2 = "";
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.String
        v0 = _result;
        _result = v0.isEmpty(); // android.text.TextUtils.isEmpty -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_004d */;
        v1 = v3.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        _result = v1.setCurrentTabByTag(v0); // android.widget.TabHost.setCurrentTabByTag -> void
        _result = v3.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getIntent(); // android.support.v4.app.FragmentActivity.getIntent -> android.content.Intent
        v0 = _result;
        if (v0 == 0) /* goto L_0090 */;
        v1 = com.sec.chaton.TabActivity.a; // :java.lang.String
        _result = v0.getParcelableExtra(v1); // android.content.Intent.getParcelableExtra -> android.os.Parcelable
        v0 = _result;
        v0 = (android.content.Intent) v0;
        if (v0 == 0) /* goto L_0090 */;
        _result = v0.getExtras(); // android.content.Intent.getExtras -> android.os.Bundle
        v1 = _result;
        if (v1 == 0) /* goto L_00c8 */;
        v2 = "callChatTab";
        _result = v1.containsKey(v2); // android.os.Bundle.containsKey -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_00c8 */;
        v2 = "callChatTab";
        _result = v1.getBoolean(v2); // android.os.Bundle.getBoolean -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_00c8 */;
        v1 = "callChatTab";
        _result = v0.removeExtra(v1); // android.content.Intent.removeExtra -> void
        _result = v3.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v1.getIntent(); // android.support.v4.app.FragmentActivity.getIntent -> android.content.Intent
        v1 = _result;
        v2 = com.sec.chaton.TabActivity.a; // :java.lang.String
        _result = v1.putExtra(v2, v0); // android.content.Intent.putExtra -> android.content.Intent
        v0 = v3.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        v1 = "Chat";
        _result = v0.setCurrentTabByTag(v1); // android.widget.TabHost.setCurrentTabByTag -> void
        _result = v3.d(); // com.sec.chaton.HomeTabFragment.d -> void
        _result = v3.b(); // com.sec.chaton.HomeTabFragment.b -> void
        v0 = new android.content.IntentFilter;
        _result = v0.<init>(); // android.content.IntentFilter.<init> -> void
        v1 = "mypage_badge_update";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        _result = v3.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v1.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v1 = _result;
        v2 = v3.r; // com.sec.chaton.HomeTabFragment.r:android.content.BroadcastReceiver
        _result = com.sec.chaton.bridge.Android16Compat.registerReceiverSafe(v1, v2, v0); // android.support.v4.content.LocalBroadcastManager.registerReceiver -> void
        _result = v3.c(); // com.sec.chaton.HomeTabFragment.c -> void
        v0 = new android.content.IntentFilter;
        _result = v0.<init>(); // android.content.IntentFilter.<init> -> void
        v1 = "more_tab_badge_update";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        _result = v3.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v1.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v1 = _result;
        v2 = v3.s; // com.sec.chaton.HomeTabFragment.s:android.content.BroadcastReceiver
        _result = com.sec.chaton.bridge.Android16Compat.registerReceiverSafe(v1, v2, v0); // android.support.v4.content.LocalBroadcastManager.registerReceiver -> void
        return;
        _result = this.c(); // com.sec.chaton.settings.PhoneSettingFragment2.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0090 */;
        v0 = v3.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        v1 = "More";
        _result = v0.setCurrentTabByTag(v1); // android.widget.TabHost.setCurrentTabByTag -> void
        // goto L_0090
    }

    public void onSaveInstanceState(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onSaveInstanceState(v3); // android.support.v4.app.Fragment.onSaveInstanceState -> void
        v0 = "current_position";
        v1 = v2.b; // com.sec.chaton.HomeTabFragment.b:android.widget.TabHost
        _result = v1.getCurrentTabTag(); // android.widget.TabHost.getCurrentTabTag -> java.lang.String
        v1 = _result;
        _result = v3.putString(v0, v1); // android.os.Bundle.putString -> void
        return;
    }

    public void onTabChanged(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = v2.e; // com.sec.chaton.HomeTabFragment.e:java.lang.String
        if (v0 == 0) /* goto L_001b */;
        v0 = v2.d; // com.sec.chaton.HomeTabFragment.d:java.util.HashMap
        v1 = v2.e; // com.sec.chaton.HomeTabFragment.e:java.lang.String
        _result = v0.containsKey(v1); // java.util.HashMap.containsKey -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001b */;
        v0 = v2.d; // com.sec.chaton.HomeTabFragment.d:java.util.HashMap
        v1 = v2.e; // com.sec.chaton.HomeTabFragment.e:java.lang.String
        _result = v0.get(v1); // java.util.HashMap.get -> java.lang.Object
        v0 = _result;
        v0 = (com.sec.chaton.ac) v0;
        _result = com.sec.chaton.ac.b(v0); // -> void
        _result = v2.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        if (v0 == 0) /* goto L_0028 */;
        _result = v2.getActivity(); // com.sec.chaton.HomeTabFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.closeOptionsMenu(); // android.support.v4.app.FragmentActivity.closeOptionsMenu -> void
        v0 = v2.d; // com.sec.chaton.HomeTabFragment.d:java.util.HashMap
        _result = v0.containsKey(v3); // java.util.HashMap.containsKey -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003b */;
        v0 = v2.d; // com.sec.chaton.HomeTabFragment.d:java.util.HashMap
        _result = v0.get(v3); // java.util.HashMap.get -> java.lang.Object
        v0 = _result;
        v0 = (com.sec.chaton.ac) v0;
        _result = com.sec.chaton.ac.a(v0); // -> void
        v2.e = v3; // com.sec.chaton.HomeTabFragment.e:java.lang.String
        return;
    }

}