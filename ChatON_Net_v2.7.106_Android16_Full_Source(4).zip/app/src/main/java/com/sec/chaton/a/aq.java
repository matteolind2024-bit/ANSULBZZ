package com.sec.chaton.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/chaton/a/aq;
 */
public interface aq extends com.google.protobuf.MessageLiteOrBuilder {
}