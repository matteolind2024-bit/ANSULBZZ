package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/a;
 */
public final class a {
}