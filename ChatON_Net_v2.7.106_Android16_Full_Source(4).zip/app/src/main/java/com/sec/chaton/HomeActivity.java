package com.sec.chaton;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.sec.chaton.base.BaseActivity;
import com.sec.chaton.bridge.AutoProvisioner;
import com.sec.chaton.bridge.MockEnvironmentSeeder;

/**
 * ============================================================================
 * HomeActivity — Auto-Provisioned Direct Entry into TabActivity (v2.7.106)
 * ============================================================================
 */
public class HomeActivity extends BaseActivity implements l {
    private static final String a = HomeActivity.class.getSimpleName();

    public static Intent a(Context context) {
        return a(context, false);
    }

    public static Intent a(Context context, boolean skipSplash) {
        Intent intent = new Intent(context, HomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        intent.putExtra("skipSplash", skipSplash);
        return intent;
    }

    public static Intent a(Context context, Intent intent, boolean skipSplash) {
        intent.setClass(context, HomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        intent.putExtra("skipSplash", skipSplash);
        return intent;
    }

    @Override
    public void a() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AutoProvisioner.ensureProvisioned(this);
        MockEnvironmentSeeder.seedAllIfNeeded(this);

        Intent baseIntent = getIntent();
        if (baseIntent != null && baseIntent.getBooleanExtra("finish", false)) {
            finish();
            return;
        }

        Intent tabIntent = TabActivity.a(this, baseIntent != null ? baseIntent : new Intent());
        startActivity(tabIntent);
        finish();
    }
}
