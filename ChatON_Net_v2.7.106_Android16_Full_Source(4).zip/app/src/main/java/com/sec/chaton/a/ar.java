package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/ar;
 */
public final enum ar implements com.google.protobuf.Internal$EnumLite {
    public static final com.sec.chaton.a.ar a;
    public static final com.sec.chaton.a.ar b;
    public static final com.sec.chaton.a.ar c;
    private static com.google.protobuf.Internal$EnumLiteMap d;
    private static final com.sec.chaton.a.ar[] f;
    private final int e;

    static {
        v4 = 2;
        v3 = 1;
        v2 = 0;
        v0 = new com.sec.chaton.a.ar;
        v1 = "SINGLE";
        _result = v0.<init>(v1, v2, v2, v2); // com.sec.chaton.a.ar.<init> -> void
        com.sec.chaton.a.ar.a = v0; // :com.sec.chaton.a.ar
        v0 = new com.sec.chaton.a.ar;
        v1 = "GROUP";
        _result = v0.<init>(v1, v3, v3, v3); // com.sec.chaton.a.ar.<init> -> void
        com.sec.chaton.a.ar.b = v0; // :com.sec.chaton.a.ar
        v0 = new com.sec.chaton.a.ar;
        v1 = "BROADCAST";
        _result = v0.<init>(v1, v4, v4, v4); // com.sec.chaton.a.ar.<init> -> void
        com.sec.chaton.a.ar.c = v0; // :com.sec.chaton.a.ar
        v0 = 3;
        v0 = new com.sec.chaton.a.ar[][size=v0];
        v1 = com.sec.chaton.a.ar.a; // :com.sec.chaton.a.ar
        v0[v2] = v1;
        v1 = com.sec.chaton.a.ar.b; // :com.sec.chaton.a.ar
        v0[v3] = v1;
        v1 = com.sec.chaton.a.ar.c; // :com.sec.chaton.a.ar
        v0[v4] = v1;
        com.sec.chaton.a.ar.f = v0; // :com.sec.chaton.a.ar[]
        v0 = new com.sec.chaton.a.as;
        _result = v0.<init>(); // com.sec.chaton.a.as.<init> -> void
        com.sec.chaton.a.ar.d = v0; // :com.google.protobuf.Internal$EnumLiteMap
        return;
    }

    private ar(java.lang.String p0, int p1, int p2, int p3) {
        // Registers (5 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int), v3 = p2 (int), v4 = p3 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        v0.e = v4; // com.sec.chaton.a.ar.e:int
        return;
    }

    public static com.sec.chaton.a.ar a(int p0) {
        // Registers (2 total): v1 = p0 (int)
        // switch(v1)
        v0 = 0;
        return v0;
        v0 = com.sec.chaton.a.ar.a; // :com.sec.chaton.a.ar
        // goto L_0004
        v0 = com.sec.chaton.a.ar.b; // :com.sec.chaton.a.ar
        // goto L_0004
        v0 = com.sec.chaton.a.ar.c; // :com.sec.chaton.a.ar
        // goto L_0004
    }

    public static com.sec.chaton.a.ar valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = com.sec.chaton.a.ar.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (com.sec.chaton.a.ar) v0;
        return v0;
    }

    public static com.sec.chaton.a.ar[] values() {
        v0 = com.sec.chaton.a.ar.f; // :com.sec.chaton.a.ar[]
        _result = v0.clone(); // com.sec.chaton.a.ar[].clone -> java.lang.Object
        v0 = _result;
        v0 = (com.sec.chaton.a.ar[]) v0;
        return v0;
    }

    public final int getNumber() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.sec.chaton.a.ar.e:int
        return v0;
    }

}