package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/aw;
 */
public final class aw extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.chaton.a.ax {
    private int a;
    private java.lang.Object b;
    private com.sec.chaton.a.ar c;
    private java.util.List d;
    private java.lang.Object e;
    private boolean f;
    private java.lang.Object g;

    private aw() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = "";
        v1.b = v0; // com.sec.chaton.a.aw.b:java.lang.Object
        v0 = com.sec.chaton.a.ar.a; // :com.sec.chaton.a.ar
        v1.c = v0; // com.sec.chaton.a.aw.c:com.sec.chaton.a.ar
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        v1.d = v0; // com.sec.chaton.a.aw.d:java.util.List
        v0 = "";
        v1.e = v0; // com.sec.chaton.a.aw.e:java.lang.Object
        v0 = "";
        v1.g = v0; // com.sec.chaton.a.aw.g:java.lang.Object
        _result = v1.g(); // com.sec.chaton.a.aw.g -> void
        return;
    }

    static com.sec.chaton.a.av a(com.sec.chaton.a.aw p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.aw)
        _result = v1.i(); // com.sec.chaton.a.aw.i -> com.sec.chaton.a.av
        v0 = _result;
        return v0;
    }

    static com.sec.chaton.a.aw f() {
        _result = this.h(); // com.sec.chaton.a.aw.h -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.chaton.a.aw h() {
        v0 = new com.sec.chaton.a.aw;
        _result = v0.<init>(); // com.sec.chaton.a.aw.<init> -> void
        return v0;
    }

    private com.sec.chaton.a.av i() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.chaton.a.aw.e -> com.sec.chaton.a.av
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.chaton.a.av.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.chaton.a.aw.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    private void j() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 == v1) /* goto L_0016 */;
        v0 = new java.util.ArrayList;
        v1 = v2.d; // com.sec.chaton.a.aw.d:java.util.List
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v2.d = v0; // com.sec.chaton.a.aw.d:java.util.List
        v0 = v2.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v2.a = v0; // com.sec.chaton.a.aw.a:int
        return;
    }

    public com.sec.chaton.a.aw a() {
        // Registers (2 total): v1 = this
        _result = v1.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = "";
        v1.b = v0; // com.sec.chaton.a.aw.b:java.lang.Object
        v0 = v1.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v1.a = v0; // com.sec.chaton.a.aw.a:int
        v0 = com.sec.chaton.a.ar.a; // :com.sec.chaton.a.ar
        v1.c = v0; // com.sec.chaton.a.aw.c:com.sec.chaton.a.ar
        v0 = v1.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v1.a = v0; // com.sec.chaton.a.aw.a:int
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        v1.d = v0; // com.sec.chaton.a.aw.d:java.util.List
        v0 = v1.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v1.a = v0; // com.sec.chaton.a.aw.a:int
        v0 = "";
        v1.e = v0; // com.sec.chaton.a.aw.e:java.lang.Object
        v0 = v1.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xdd(v0, -9);
        v1.a = v0; // com.sec.chaton.a.aw.a:int
        v0 = 0;
        v1.f = v0; // com.sec.chaton.a.aw.f:boolean
        v0 = v1.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xdd(v0, -17);
        v1.a = v0; // com.sec.chaton.a.aw.a:int
        v0 = "";
        v1.g = v0; // com.sec.chaton.a.aw.g:java.lang.Object
        v0 = v1.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xdd(v0, -33);
        v1.a = v0; // com.sec.chaton.a.aw.a:int
        return v1;
    }

    public com.sec.chaton.a.aw a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.CodedInputStream), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v2.parseUnknownField(v3, v4, v0); // com.sec.chaton.a.aw.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v2;
        v0 = v2.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v2.a = v0; // com.sec.chaton.a.aw.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.b = v0; // com.sec.chaton.a.aw.b:java.lang.Object
        // goto L_0000
        _result = v3.readEnum(); // com.google.protobuf.CodedInputStream.readEnum -> int
        v0 = _result;
        _result = v0.a(); // com.sec.chaton.a.ar.a -> com.sec.chaton.a.ar
        v0 = _result;
        if (v0 == 0) /* goto L_0000 */;
        v1 = v2.a; // com.sec.chaton.a.aw.a:int
        v1 = binOpLit8_0xde(v1, 2);
        v2.a = v1; // com.sec.chaton.a.aw.a:int
        v2.c = v0; // com.sec.chaton.a.aw.c:com.sec.chaton.a.ar
        // goto L_0000
        _result = this.newBuilder(); // com.sec.chaton.a.bu.newBuilder -> com.sec.chaton.a.bv
        v0 = _result;
        _result = v3.readMessage(v0, v4); // com.google.protobuf.CodedInputStream.readMessage -> void
        _result = v0.e(); // com.sec.chaton.a.bv.e -> com.sec.chaton.a.bu
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.aw
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v2.a = v0; // com.sec.chaton.a.aw.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.e = v0; // com.sec.chaton.a.aw.e:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xde(v0, 16);
        v2.a = v0; // com.sec.chaton.a.aw.a:int
        _result = v3.readBool(); // com.google.protobuf.CodedInputStream.readBool -> boolean
        v0 = _result;
        v2.f = v0; // com.sec.chaton.a.aw.f:boolean
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xde(v0, 32);
        v2.a = v0; // com.sec.chaton.a.aw.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.g = v0; // com.sec.chaton.a.aw.g:java.lang.Object
        // goto L_0000
    }

    public com.sec.chaton.a.aw a(com.sec.chaton.a.ar p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.ar)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.chaton.a.aw.a:int
        v1.c = v2; // com.sec.chaton.a.aw.c:com.sec.chaton.a.ar
        return v1;
    }

    public com.sec.chaton.a.aw a(com.sec.chaton.a.av p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.chaton.a.av)
        _result = this.a(); // com.sec.chaton.a.av.a -> com.sec.chaton.a.av
        v0 = _result;
        if (v3 != v0) /* goto L_0007 */;
        return v2;
        _result = v3.c(); // com.sec.chaton.a.av.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v3.d(); // com.sec.chaton.a.av.d -> java.lang.String
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.aw
        _result = v3.e(); // com.sec.chaton.a.av.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v3.f(); // com.sec.chaton.a.av.f -> com.sec.chaton.a.ar
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.aw
        _result = v3.b(); // com.sec.chaton.a.av.b -> java.util.List
        v0 = _result;
        _result = java.util.List.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_003f */;
        v0 = v2.d; // com.sec.chaton.a.aw.d:java.util.List
        _result = java.util.List.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0067 */;
        _result = v3.b(); // com.sec.chaton.a.av.b -> java.util.List
        v0 = _result;
        v2.d = v0; // com.sec.chaton.a.aw.d:java.util.List
        v0 = v2.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v2.a = v0; // com.sec.chaton.a.aw.a:int
        _result = v3.i(); // com.sec.chaton.a.av.i -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_004c */;
        _result = v3.j(); // com.sec.chaton.a.av.j -> java.lang.String
        v0 = _result;
        _result = v2.b(v0); // com.sec.chaton.a.aw.b -> com.sec.chaton.a.aw
        _result = v3.k(); // com.sec.chaton.a.av.k -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0059 */;
        _result = v3.l(); // com.sec.chaton.a.av.l -> boolean
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.aw
        _result = v3.m(); // com.sec.chaton.a.av.m -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0006 */;
        _result = v3.n(); // com.sec.chaton.a.av.n -> java.lang.String
        v0 = _result;
        _result = v2.c(v0); // com.sec.chaton.a.aw.c -> com.sec.chaton.a.aw
        // goto L_0006
        _result = v2.j(); // com.sec.chaton.a.aw.j -> void
        v0 = v2.d; // com.sec.chaton.a.aw.d:java.util.List
        _result = v3.b(); // com.sec.chaton.a.av.b -> java.util.List
        v1 = _result;
        _result = java.util.List.addAll(v0, v1); // -> boolean
        // goto L_003f
    }

    public com.sec.chaton.a.aw a(com.sec.chaton.a.bu p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.bu)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        _result = v1.j(); // com.sec.chaton.a.aw.j -> void
        v0 = v1.d; // com.sec.chaton.a.aw.d:java.util.List
        _result = java.util.List.add(v0, v2); // -> boolean
        return v1;
    }

    public com.sec.chaton.a.aw a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.chaton.a.aw.a:int
        v1.b = v2; // com.sec.chaton.a.aw.b:java.lang.Object
        return v1;
    }

    public com.sec.chaton.a.aw a(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xde(v0, 16);
        v1.a = v0; // com.sec.chaton.a.aw.a:int
        v1.f = v2; // com.sec.chaton.a.aw.f:boolean
        return v1;
    }

    public com.sec.chaton.a.aw b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.chaton.a.aw.h -> com.sec.chaton.a.aw
        v0 = _result;
        _result = v2.e(); // com.sec.chaton.a.aw.e -> com.sec.chaton.a.av
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.aw b(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v1.a = v0; // com.sec.chaton.a.aw.a:int
        v1.e = v2; // com.sec.chaton.a.aw.e:java.lang.Object
        return v1;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.chaton.a.aw.d -> com.sec.chaton.a.av
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.chaton.a.aw.e -> com.sec.chaton.a.av
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.av c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.chaton.a.av.a -> com.sec.chaton.a.av
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.aw c(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.aw.a:int
        v0 = binOpLit8_0xde(v0, 32);
        v1.a = v0; // com.sec.chaton.a.aw.a:int
        v1.g = v2; // com.sec.chaton.a.aw.g:java.lang.Object
        return v1;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.aw.b -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.aw.b -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.aw.b -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.aw.b -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.av d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.chaton.a.aw.e -> com.sec.chaton.a.av
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.chaton.a.av.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.chaton.a.aw.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.chaton.a.av e() {
        // Registers (6 total): v5 = this
        v0 = 1;
        v2 = new com.sec.chaton.a.av;
        v1 = 0;
        _result = v2.<init>(v5, v1); // com.sec.chaton.a.av.<init> -> void
        v3 = v5.a; // com.sec.chaton.a.aw.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_0064 */;
        v1 = v5.b; // com.sec.chaton.a.aw.b:java.lang.Object
        _result = v2.a(v1); // com.sec.chaton.a.av.a -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 2);
        v4 = 2;
        if (v1 != v4) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v5.c; // com.sec.chaton.a.aw.c:com.sec.chaton.a.ar
        _result = v2.a(v1); // com.sec.chaton.a.av.a -> com.sec.chaton.a.ar
        v1 = v5.a; // com.sec.chaton.a.aw.a:int
        v1 = binOpLit8_0xdd(v1, 4);
        v4 = 4;
        if (v1 != v4) /* goto L_0034 */;
        v1 = v5.d; // com.sec.chaton.a.aw.d:java.util.List
        _result = v1.unmodifiableList(); // java.util.Collections.unmodifiableList -> java.util.List
        v1 = _result;
        v5.d = v1; // com.sec.chaton.a.aw.d:java.util.List
        v1 = v5.a; // com.sec.chaton.a.aw.a:int
        v1 = binOpLit8_0xdd(v1, -5);
        v5.a = v1; // com.sec.chaton.a.aw.a:int
        v1 = v5.d; // com.sec.chaton.a.aw.d:java.util.List
        _result = v2.a(v1); // com.sec.chaton.a.av.a -> java.util.List
        v1 = binOpLit8_0xdd(v3, 8);
        v4 = 8;
        if (v1 != v4) /* goto L_0041 */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = v5.e; // com.sec.chaton.a.aw.e:java.lang.Object
        _result = v2.b(v1); // com.sec.chaton.a.av.b -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 16);
        v4 = 16;
        if (v1 != v4) /* goto L_004e */;
        v0 = binOpLit8_0xde(v0, 8);
        v1 = v5.f; // com.sec.chaton.a.aw.f:boolean
        _result = v2.a(v1); // com.sec.chaton.a.av.a -> boolean
        v1 = binOpLit8_0xdd(v3, 32);
        v3 = 32;
        if (v1 != v3) /* goto L_005b */;
        v0 = binOpLit8_0xde(v0, 16);
        v1 = v5.g; // com.sec.chaton.a.aw.g:java.lang.Object
        _result = v2.c(v1); // com.sec.chaton.a.av.c -> java.lang.Object
        _result = v2.a(v0); // com.sec.chaton.a.av.a -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.aw.c -> com.sec.chaton.a.av
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.aw.c -> com.sec.chaton.a.av
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.chaton.a.av) v2;
        _result = v1.a(v2); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

}