package com.sec.chaton;

/**
 * Original SourceFile: ExitAppDialogActivity.java
 * Descriptor: Lcom/sec/chaton/ExitAppDialogActivity;
 */
public class ExitAppDialogActivity extends android.app.Activity {
    private int a;
    private com.coolots.sso.a.a b;

    public ExitAppDialogActivity() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.app.Activity.<init> -> void
        return;
    }

    static int a(com.sec.chaton.ExitAppDialogActivity p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.ExitAppDialogActivity)
        v0 = v1.a; // com.sec.chaton.ExitAppDialogActivity.a:int
        return v0;
    }

    public static void a(int p0) {
        // Registers (3 total): v2 = p0 (int)
        v0 = "exit_app_done";
        v1 = 1;
        _result = v1.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.util.r.a -> void
        v0 = new android.content.Intent;
        v1 = "com.sec.chaton.ACTION_EXIT_APP";
        _result = v0.<init>(v1); // android.content.Intent.<init> -> void
        v1 = "reason";
        _result = v0.putExtra(v1, v2); // android.content.Intent.putExtra -> android.content.Intent
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v1 = _result;
        _result = v1.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v1 = _result;
        _result = v1.sendBroadcast(v0); // android.support.v4.content.LocalBroadcastManager.sendBroadcast -> boolean
        return;
    }

    public static boolean a() {
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "exit_app_done";
        v2 = 0;
        _result = v2.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v2 = _result;
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.Boolean
        v0 = _result;
        _result = v0.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        return v0;
    }

    public static void b() {
        v2 = 0;
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "uid";
        _result = v0.b(v1); // com.sec.chaton.util.s.b -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v0 = "Exit App. Unauthorized.";
        _result = v0.a(v2); // com.sec.chaton.util.p.a -> void
        v0 = 0;
        _result = v0.a(); // com.sec.chaton.ExitAppDialogActivity.a -> void
        return;
        v0 = com.sec.chaton.util.p.b; // :boolean
        if (v0 == 0) /* goto L_0016 */;
        v0 = "it was already deleted";
        _result = v0.b(v2); // com.sec.chaton.util.p.b -> void
        // goto L_0016
    }

    private void c() {
        // Registers (4 total): v3 = this
        v2 = com.sec.chaton.R.id.exit_error_content; // 0x7f08024c
        v0 = "ExitAppDialogActivity initView";
        v1 = 0;
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        v0 = 16908313; // 0x01020019
        _result = v3.findViewById(v0); // com.sec.chaton.ExitAppDialogActivity.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v1 = new com.sec.chaton.q;
        _result = v1.<init>(v3); // com.sec.chaton.q.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = 1;
        v1 = v3.a; // com.sec.chaton.ExitAppDialogActivity.a:int
        if (v0 != v1) /* goto L_002c */;
        _result = v3.findViewById(v2); // com.sec.chaton.ExitAppDialogActivity.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TextView) v0;
        v1 = com.sec.chaton.R.string.popup_not_enough_memory; // 0x7f0c0343
        _result = v0.setText(v1); // android.widget.TextView.setText -> void
        return;
        v0 = 2;
        v1 = v3.a; // com.sec.chaton.ExitAppDialogActivity.a:int
        if (v0 != v1) /* goto L_002b */;
        _result = v3.findViewById(v2); // com.sec.chaton.ExitAppDialogActivity.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TextView) v0;
        v1 = com.sec.chaton.R.string.registration_popup_reset_device; // 0x7f0c0579
        _result = v0.setText(v1); // android.widget.TextView.setText -> void
        // goto L_002b
    }

    public void onBackPressed() {
        // Registers (1 total): v0 = this
        return;
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v2 = 0;
        _result = v3.onCreate(v4); // android.app.Activity.onCreate -> void
        v0 = 1;
        _result = v3.requestWindowFeature(v0); // com.sec.chaton.ExitAppDialogActivity.requestWindowFeature -> boolean
        v0 = com.sec.chaton.R.layout.exit_app_dialog; // 0x7f030064
        _result = v3.setContentView(v0); // com.sec.chaton.ExitAppDialogActivity.setContentView -> void
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_0017 */;
        _result = v3.setFinishOnTouchOutside(v2); // com.sec.chaton.ExitAppDialogActivity.setFinishOnTouchOutside -> void
        _result = v3.getIntent(); // com.sec.chaton.ExitAppDialogActivity.getIntent -> android.content.Intent
        v0 = _result;
        v1 = "reason";
        _result = v0.getIntExtra(v1, v2); // android.content.Intent.getIntExtra -> int
        v0 = _result;
        v3.a = v0; // com.sec.chaton.ExitAppDialogActivity.a:int
        _result = v3.c(); // com.sec.chaton.ExitAppDialogActivity.c -> void
        _result = v3.a(); // com.sec.chaton.util.bp.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_004d */;
        v0 = new com.coolots.sso.a.a;
        _result = v0.<init>(); // com.coolots.sso.a.a.<init> -> void
        v3.b = v0; // com.sec.chaton.ExitAppDialogActivity.b:com.coolots.sso.a.a
        v0 = v3.b; // com.sec.chaton.ExitAppDialogActivity.b:com.coolots.sso.a.a
        _result = v0.d(v3); // com.coolots.sso.a.a.d -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_004d */;
        v0 = v3.b; // com.sec.chaton.ExitAppDialogActivity.b:com.coolots.sso.a.a
        _result = v0.c(v3); // com.coolots.sso.a.a.c -> int
        v0 = "onCreate:mChatonV.removeAccountInDevice()";
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        return;
    }

    protected void onNewIntent(android.content.Intent p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Intent)
        v1 = 0;
        _result = v2.onNewIntent(v3); // android.app.Activity.onNewIntent -> void
        _result = v2.setIntent(v3); // com.sec.chaton.ExitAppDialogActivity.setIntent -> void
        if (v3 == 0) /* goto L_0015 */;
        v0 = "reason";
        _result = v3.getIntExtra(v0, v1); // android.content.Intent.getIntExtra -> int
        v0 = _result;
        v2.a = v0; // com.sec.chaton.ExitAppDialogActivity.a:int
        _result = v2.c(); // com.sec.chaton.ExitAppDialogActivity.c -> void
        return;
        v2.a = v1; // com.sec.chaton.ExitAppDialogActivity.a:int
        // goto L_0011
    }

    protected void onUserLeaveHint() {
        // Registers (3 total): v2 = this
        v0 = "onUserLeaveHint";
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        return;
    }

}