package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/ad;
 */
public final class ad extends com.google.protobuf.GeneratedMessageLite implements com.sec.chaton.a.af {
    private static final com.sec.chaton.a.ad a;
    private int b;
    private com.sec.chaton.a.ar c;
    private java.lang.Object d;
    private com.google.protobuf.LazyStringList e;
    private long f;
    private byte g;
    private int h;

    static {
        v0 = new com.sec.chaton.a.ad;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.chaton.a.ad.<init> -> void
        com.sec.chaton.a.ad.a = v0; // :com.sec.chaton.a.ad
        v0 = com.sec.chaton.a.ad.a; // :com.sec.chaton.a.ad
        _result = v0.m(); // com.sec.chaton.a.ad.m -> void
        return;
    }

    private ad(com.sec.chaton.a.ae p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.ae)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.g = v0; // com.sec.chaton.a.ad.g:byte
        v1.h = v0; // com.sec.chaton.a.ad.h:int
        return;
    }

    ad(com.sec.chaton.a.ae p0, com.sec.chaton.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.chaton.a.ae), v2 = p1 (com.sec.chaton.a.b)
        _result = v0.<init>(v1); // com.sec.chaton.a.ad.<init> -> void
        return;
    }

    private ad(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.g = v0; // com.sec.chaton.a.ad.g:byte
        v1.h = v0; // com.sec.chaton.a.ad.h:int
        return;
    }

    static int a(com.sec.chaton.a.ad p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ad), v1 = p1 (int)
        v0.b = v1; // com.sec.chaton.a.ad.b:int
        return v1;
    }

    static long a(com.sec.chaton.a.ad p0, long p1) {
        // Registers (3 total): v0 = p0 (com.sec.chaton.a.ad), v1 = p1 (long)
        v0.f = v1; // com.sec.chaton.a.ad.f:long
        return v1;
    }

    static com.google.protobuf.LazyStringList a(com.sec.chaton.a.ad p0, com.google.protobuf.LazyStringList p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ad), v1 = p1 (com.google.protobuf.LazyStringList)
        v0.e = v1; // com.sec.chaton.a.ad.e:com.google.protobuf.LazyStringList
        return v1;
    }

    public static com.sec.chaton.a.ad a() {
        v0 = com.sec.chaton.a.ad.a; // :com.sec.chaton.a.ad
        return v0;
    }

    public static com.sec.chaton.a.ae a(com.sec.chaton.a.ad p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.ad)
        _result = this.newBuilder(); // com.sec.chaton.a.ad.newBuilder -> com.sec.chaton.a.ae
        v0 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.ae.a -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    static com.sec.chaton.a.ar a(com.sec.chaton.a.ad p0, com.sec.chaton.a.ar p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ad), v1 = p1 (com.sec.chaton.a.ar)
        v0.c = v1; // com.sec.chaton.a.ad.c:com.sec.chaton.a.ar
        return v1;
    }

    static java.lang.Object a(com.sec.chaton.a.ad p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.ad), v1 = p1 (java.lang.Object)
        v0.d = v1; // com.sec.chaton.a.ad.d:java.lang.Object
        return v1;
    }

    static com.google.protobuf.LazyStringList b(com.sec.chaton.a.ad p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.ad)
        v0 = v1.e; // com.sec.chaton.a.ad.e:com.google.protobuf.LazyStringList
        return v0;
    }

    private com.google.protobuf.ByteString l() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.chaton.a.ad.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.d = v0; // com.sec.chaton.a.ad.d:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void m() {
        // Registers (3 total): v2 = this
        v0 = com.sec.chaton.a.ar.a; // :com.sec.chaton.a.ar
        v2.c = v0; // com.sec.chaton.a.ad.c:com.sec.chaton.a.ar
        v0 = "";
        v2.d = v0; // com.sec.chaton.a.ad.d:java.lang.Object
        v0 = com.google.protobuf.LazyStringArrayList.EMPTY; // :com.google.protobuf.LazyStringList
        v2.e = v0; // com.sec.chaton.a.ad.e:com.google.protobuf.LazyStringList
        v0 = 0L;
        v2.f = v0; // com.sec.chaton.a.ad.f:long
        return;
    }

    public static com.sec.chaton.a.ae newBuilder() {
        _result = this.f(); // com.sec.chaton.a.ae.f -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ad b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.chaton.a.ad.a; // :com.sec.chaton.a.ad
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.chaton.a.ad.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public com.sec.chaton.a.ar d() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.sec.chaton.a.ad.c:com.sec.chaton.a.ar
        return v0;
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public java.lang.String f() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.chaton.a.ad.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.d = v1; // com.sec.chaton.a.ad.d:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public java.util.List g() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.sec.chaton.a.ad.e:com.google.protobuf.LazyStringList
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ad.b -> com.sec.chaton.a.ad
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (7 total): v6 = this
        v5 = 4;
        v4 = 2;
        v3 = 1;
        v1 = 0;
        v0 = v6.h; // com.sec.chaton.a.ad.h:int
        v2 = -1;
        if (v0 == v2) /* goto L_000a */;
        return v0;
        v0 = v6.b; // com.sec.chaton.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v3) /* goto L_005d */;
        v0 = v6.c; // com.sec.chaton.a.ad.c:com.sec.chaton.a.ar
        _result = v0.getNumber(); // com.sec.chaton.a.ar.getNumber -> int
        v0 = _result;
        _result = v3.computeEnumSize(v0); // com.google.protobuf.CodedOutputStream.computeEnumSize -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v2 = v6.b; // com.sec.chaton.a.ad.b:int
        v2 = binOpLit8_0xdd(v2, 2);
        if (v2 != v4) /* goto L_002a */;
        _result = v6.l(); // com.sec.chaton.a.ad.l -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v4.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v2 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = v1;
        v3 = v6.e; // com.sec.chaton.a.ad.e:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.size(v3); // -> int
        v3 = _result;
        if (v1 >= v3) /* goto L_0041 */;
        v3 = v6.e; // com.sec.chaton.a.ad.e:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.getByteString(v3, v1); // -> com.google.protobuf.ByteString
        v3 = _result;
        _result = v3.computeBytesSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeBytesSizeNoTag -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_002b
        v0 = binOp2addr_0xb0(v0, v2);
        _result = v6.g(); // com.sec.chaton.a.ad.g -> java.util.List
        v1 = _result;
        _result = java.util.List.size(v1); // -> int
        v1 = _result;
        v1 = binOpLit8_0xda(v1, 1);
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.chaton.a.ad.b:int
        v1 = binOpLit8_0xdd(v1, 4);
        if (v1 != v5) /* goto L_005a */;
        v1 = v6.f; // com.sec.chaton.a.ad.f:long
        _result = v5.computeInt64Size(v1, v2); // com.google.protobuf.CodedOutputStream.computeInt64Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v6.h = v0; // com.sec.chaton.a.ad.h:int
        // goto L_0009
        v0 = v1;
        // goto L_001b
    }

    public boolean h() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public long i() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // com.sec.chaton.a.ad.f:long
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.g; // com.sec.chaton.a.ad.g:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.g = v0; // com.sec.chaton.a.ad.g:byte
        // goto L_0008
    }

    public com.sec.chaton.a.ae j() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.chaton.a.ad.newBuilder -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ae k() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.ad.a -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.j(); // com.sec.chaton.a.ad.j -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.k(); // com.sec.chaton.a.ad.k -> com.sec.chaton.a.ae
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (6 total): v4 = this, v5 = p0 (com.google.protobuf.CodedOutputStream)
        v3 = 4;
        v2 = 2;
        v1 = 1;
        _result = v4.getSerializedSize(); // com.sec.chaton.a.ad.getSerializedSize -> int
        v0 = v4.b; // com.sec.chaton.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v1) /* goto L_0015 */;
        v0 = v4.c; // com.sec.chaton.a.ad.c:com.sec.chaton.a.ar
        _result = v0.getNumber(); // com.sec.chaton.a.ar.getNumber -> int
        v0 = _result;
        _result = v5.writeEnum(v1, v0); // com.google.protobuf.CodedOutputStream.writeEnum -> void
        v0 = v4.b; // com.sec.chaton.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v2) /* goto L_0022 */;
        _result = v4.l(); // com.sec.chaton.a.ad.l -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v5.writeBytes(v2, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = 0;
        v1 = v4.e; // com.sec.chaton.a.ad.e:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.size(v1); // -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_0038 */;
        v1 = 3;
        v2 = v4.e; // com.sec.chaton.a.ad.e:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.getByteString(v2, v0); // -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v5.writeBytes(v1, v2); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0023
        v0 = v4.b; // com.sec.chaton.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        if (v0 != v3) /* goto L_0043 */;
        v0 = v4.f; // com.sec.chaton.a.ad.f:long
        _result = v5.writeInt64(v3, v0, v1); // com.google.protobuf.CodedOutputStream.writeInt64 -> void
        return;
    }

}