package com.sec.chaton.a.a;

/**
 * Original SourceFile: HttpEntry.java
 * Descriptor: Lcom/sec/chaton/a/a/d;
 */
public class d {
    private boolean a;
    private com.sec.chaton.i.n b;
    private com.sec.chaton.i.h c;
    private int d;
    private java.lang.String e;
    private java.lang.Object f;
    private java.lang.Object g;
    private int h;
    private java.lang.String i;
    private org.apache.http.HttpResponse j;

    public d(com.sec.chaton.i.h p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.chaton.i.h)
        v1 = 0;
        v0 = 0;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.a = v0; // com.sec.chaton.a.a.d.a:boolean
        v2.d = v0; // com.sec.chaton.a.a.d.d:int
        v0 = "";
        v2.e = v0; // com.sec.chaton.a.a.d.e:java.lang.String
        v2.f = v1; // com.sec.chaton.a.a.d.f:java.lang.Object
        v2.g = v1; // com.sec.chaton.a.a.d.g:java.lang.Object
        v2.c = v3; // com.sec.chaton.a.a.d.c:com.sec.chaton.i.h
        return;
    }

    public void a(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.d = v1; // com.sec.chaton.a.a.d.d:int
        return;
    }

    public void a(com.sec.chaton.i.n p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.sec.chaton.i.n)
        v0.b = v1; // com.sec.chaton.a.a.d.b:com.sec.chaton.i.n
        return;
    }

    public void a(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        v0.f = v1; // com.sec.chaton.a.a.d.f:java.lang.Object
        return;
    }

    public void a(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.e = v1; // com.sec.chaton.a.a.d.e:java.lang.String
        return;
    }

    public void a(org.apache.http.HttpResponse p0) {
        // Registers (2 total): v0 = this, v1 = p0 (org.apache.http.HttpResponse)
        v0.j = v1; // com.sec.chaton.a.a.d.j:org.apache.http.HttpResponse
        return;
    }

    public void a(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        v0.a = v1; // com.sec.chaton.a.a.d.a:boolean
        return;
    }

    public boolean a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // com.sec.chaton.a.a.d.a:boolean
        return v0;
    }

    public com.sec.chaton.i.n b() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // com.sec.chaton.a.a.d.b:com.sec.chaton.i.n
        return v0;
    }

    public void b(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.h = v1; // com.sec.chaton.a.a.d.h:int
        return;
    }

    public void b(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        v0.g = v1; // com.sec.chaton.a.a.d.g:java.lang.Object
        return;
    }

    public void b(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.i = v1; // com.sec.chaton.a.a.d.i:java.lang.String
        return;
    }

    public com.sec.chaton.i.h c() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.sec.chaton.a.a.d.c:com.sec.chaton.i.h
        return v0;
    }

    public org.apache.http.Header[] c(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.j; // com.sec.chaton.a.a.d.j:org.apache.http.HttpResponse
        if (v0 != 0) /* goto L_0006 */;
        v0 = 0;
        return v0;
        v0 = v1.j; // com.sec.chaton.a.a.d.j:org.apache.http.HttpResponse
        _result = org.apache.http.HttpResponse.getHeaders(v0, v2); // -> org.apache.http.Header[]
        v0 = _result;
        // goto L_0005
    }

    public java.lang.Object d() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // com.sec.chaton.a.a.d.f:java.lang.Object
        return v0;
    }

    public java.lang.Object e() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.sec.chaton.a.a.d.g:java.lang.Object
        return v0;
    }

    public int f() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.sec.chaton.a.a.d.d:int
        return v0;
    }

    public java.lang.String g() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.sec.chaton.a.a.d.e:java.lang.String
        return v0;
    }

    public int h() {
        // Registers (2 total): v1 = this
        v0 = v1.h; // com.sec.chaton.a.a.d.h:int
        return v0;
    }

    public java.lang.String i() {
        // Registers (2 total): v1 = this
        v0 = v1.i; // com.sec.chaton.a.a.d.i:java.lang.String
        return v0;
    }

}