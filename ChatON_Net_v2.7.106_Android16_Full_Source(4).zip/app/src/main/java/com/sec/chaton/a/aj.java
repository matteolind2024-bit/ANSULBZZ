package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/aj;
 */
public final enum aj implements com.google.protobuf.Internal$EnumLite {
    public static final com.sec.chaton.a.aj a;
    public static final com.sec.chaton.a.aj b;
    private static com.google.protobuf.Internal$EnumLiteMap c;
    private static final com.sec.chaton.a.aj[] e;
    private final int d;

    static {
        v3 = 1;
        v2 = 0;
        v0 = new com.sec.chaton.a.aj;
        v1 = "ENTER";
        _result = v0.<init>(v1, v2, v2, v2); // com.sec.chaton.a.aj.<init> -> void
        com.sec.chaton.a.aj.a = v0; // :com.sec.chaton.a.aj
        v0 = new com.sec.chaton.a.aj;
        v1 = "LEAVE";
        _result = v0.<init>(v1, v3, v3, v3); // com.sec.chaton.a.aj.<init> -> void
        com.sec.chaton.a.aj.b = v0; // :com.sec.chaton.a.aj
        v0 = 2;
        v0 = new com.sec.chaton.a.aj[][size=v0];
        v1 = com.sec.chaton.a.aj.a; // :com.sec.chaton.a.aj
        v0[v2] = v1;
        v1 = com.sec.chaton.a.aj.b; // :com.sec.chaton.a.aj
        v0[v3] = v1;
        com.sec.chaton.a.aj.e = v0; // :com.sec.chaton.a.aj[]
        v0 = new com.sec.chaton.a.ak;
        _result = v0.<init>(); // com.sec.chaton.a.ak.<init> -> void
        com.sec.chaton.a.aj.c = v0; // :com.google.protobuf.Internal$EnumLiteMap
        return;
    }

    private aj(java.lang.String p0, int p1, int p2, int p3) {
        // Registers (5 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int), v3 = p2 (int), v4 = p3 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        v0.d = v4; // com.sec.chaton.a.aj.d:int
        return;
    }

    public static com.sec.chaton.a.aj a(int p0) {
        // Registers (2 total): v1 = p0 (int)
        // switch(v1)
        v0 = 0;
        return v0;
        v0 = com.sec.chaton.a.aj.a; // :com.sec.chaton.a.aj
        // goto L_0004
        v0 = com.sec.chaton.a.aj.b; // :com.sec.chaton.a.aj
        // goto L_0004
    }

    public static com.sec.chaton.a.aj valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = com.sec.chaton.a.aj.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (com.sec.chaton.a.aj) v0;
        return v0;
    }

    public static com.sec.chaton.a.aj[] values() {
        v0 = com.sec.chaton.a.aj.e; // :com.sec.chaton.a.aj[]
        _result = v0.clone(); // com.sec.chaton.a.aj[].clone -> java.lang.Object
        v0 = _result;
        v0 = (com.sec.chaton.a.aj[]) v0;
        return v0;
    }

    public final int getNumber() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.sec.chaton.a.aj.d:int
        return v0;
    }

}