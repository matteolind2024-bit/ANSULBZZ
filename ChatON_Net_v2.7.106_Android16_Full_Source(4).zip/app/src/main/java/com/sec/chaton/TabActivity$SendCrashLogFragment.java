package com.sec.chaton;

/**
 * Original SourceFile: TabActivity.java
 * Descriptor: Lcom/sec/chaton/TabActivity$SendCrashLogFragment;
 */
public class TabActivity$SendCrashLogFragment extends android.support.v4.app.Fragment {
    public static final java.lang.String a;

    static {
        v0 = com.sec.chaton.TabActivity$SendCrashLogFragment.class;
        _result = v0.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v0 = _result;
        com.sec.chaton.TabActivity$SendCrashLogFragment.a = v0; // :java.lang.String
        return;
    }

    public TabActivity$SendCrashLogFragment() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.app.Fragment.<init> -> void
        return;
    }

    public void onCreate(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onCreate(v3); // android.support.v4.app.Fragment.onCreate -> void
        v0 = new com.sec.chaton.util.q;
        _result = v0.<init>(); // com.sec.chaton.util.q.<init> -> void
        v1 = 0;
        v1 = new java.lang.Void[][size=v1];
        _result = v0.execute(v1); // com.sec.chaton.util.q.execute -> android.os.AsyncTask
        return;
    }

}