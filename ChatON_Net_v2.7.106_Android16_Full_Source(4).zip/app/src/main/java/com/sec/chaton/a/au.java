package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/au;
 */
final class au implements com.google.protobuf.Internal$EnumLiteMap {
    au() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public com.sec.chaton.a.at a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v2.a(); // com.sec.chaton.a.at.a -> com.sec.chaton.a.at
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.Internal$EnumLite findValueByNumber(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.a(v2); // com.sec.chaton.a.au.a -> com.sec.chaton.a.at
        v0 = _result;
        return v0;
    }

}