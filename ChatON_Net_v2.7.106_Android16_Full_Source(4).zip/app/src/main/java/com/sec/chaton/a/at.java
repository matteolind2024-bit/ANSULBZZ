package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/at;
 */
public final enum at implements com.google.protobuf.Internal$EnumLite {
    public static final com.sec.chaton.a.at a;
    public static final com.sec.chaton.a.at b;
    public static final com.sec.chaton.a.at c;
    public static final com.sec.chaton.a.at d;
    private static com.google.protobuf.Internal$EnumLiteMap e;
    private static final com.sec.chaton.a.at[] g;
    private final int f;

    static {
        v5 = 3;
        v4 = 2;
        v3 = 1;
        v2 = 0;
        v0 = new com.sec.chaton.a.at;
        v1 = "CONTENT_TEXT";
        _result = v0.<init>(v1, v2, v2, v2); // com.sec.chaton.a.at.<init> -> void
        com.sec.chaton.a.at.a = v0; // :com.sec.chaton.a.at
        v0 = new com.sec.chaton.a.at;
        v1 = "CONTENT_IMAGE";
        _result = v0.<init>(v1, v3, v3, v3); // com.sec.chaton.a.at.<init> -> void
        com.sec.chaton.a.at.b = v0; // :com.sec.chaton.a.at
        v0 = new com.sec.chaton.a.at;
        v1 = "CONTENT_VIDEO";
        _result = v0.<init>(v1, v4, v4, v4); // com.sec.chaton.a.at.<init> -> void
        com.sec.chaton.a.at.c = v0; // :com.sec.chaton.a.at
        v0 = new com.sec.chaton.a.at;
        v1 = "CONTENT_AUDIO";
        _result = v0.<init>(v1, v5, v5, v5); // com.sec.chaton.a.at.<init> -> void
        com.sec.chaton.a.at.d = v0; // :com.sec.chaton.a.at
        v0 = 4;
        v0 = new com.sec.chaton.a.at[][size=v0];
        v1 = com.sec.chaton.a.at.a; // :com.sec.chaton.a.at
        v0[v2] = v1;
        v1 = com.sec.chaton.a.at.b; // :com.sec.chaton.a.at
        v0[v3] = v1;
        v1 = com.sec.chaton.a.at.c; // :com.sec.chaton.a.at
        v0[v4] = v1;
        v1 = com.sec.chaton.a.at.d; // :com.sec.chaton.a.at
        v0[v5] = v1;
        com.sec.chaton.a.at.g = v0; // :com.sec.chaton.a.at[]
        v0 = new com.sec.chaton.a.au;
        _result = v0.<init>(); // com.sec.chaton.a.au.<init> -> void
        com.sec.chaton.a.at.e = v0; // :com.google.protobuf.Internal$EnumLiteMap
        return;
    }

    private at(java.lang.String p0, int p1, int p2, int p3) {
        // Registers (5 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int), v3 = p2 (int), v4 = p3 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        v0.f = v4; // com.sec.chaton.a.at.f:int
        return;
    }

    public static com.sec.chaton.a.at a(int p0) {
        // Registers (2 total): v1 = p0 (int)
        // switch(v1)
        v0 = 0;
        return v0;
        v0 = com.sec.chaton.a.at.a; // :com.sec.chaton.a.at
        // goto L_0004
        v0 = com.sec.chaton.a.at.b; // :com.sec.chaton.a.at
        // goto L_0004
        v0 = com.sec.chaton.a.at.c; // :com.sec.chaton.a.at
        // goto L_0004
        v0 = com.sec.chaton.a.at.d; // :com.sec.chaton.a.at
        // goto L_0004
    }

    public static com.sec.chaton.a.at valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = com.sec.chaton.a.at.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (com.sec.chaton.a.at) v0;
        return v0;
    }

    public static com.sec.chaton.a.at[] values() {
        v0 = com.sec.chaton.a.at.g; // :com.sec.chaton.a.at[]
        _result = v0.clone(); // com.sec.chaton.a.at[].clone -> java.lang.Object
        v0 = _result;
        v0 = (com.sec.chaton.a.at[]) v0;
        return v0;
    }

    public final int getNumber() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // com.sec.chaton.a.at.f:int
        return v0;
    }

}