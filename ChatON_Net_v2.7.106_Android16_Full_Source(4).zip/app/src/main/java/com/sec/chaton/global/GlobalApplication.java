package com.sec.chaton.global;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.PowerManager;
import android.util.DisplayMetrics;

import com.sec.chaton.TabActivity;
import com.sec.chaton.bridge.Android16Compat;
import com.sec.chaton.bridge.AutoProvisioner;
import com.sec.chaton.bridge.MockRichBinaryAdapter;
import com.sec.chaton.chat.notification.BlackScreenNotification;
import com.sec.chaton.chat.notification.ScreenOnNotification;
import com.sec.chaton.d.a.dc;
import com.sec.chaton.d.o;
import com.sec.chaton.i.ae;
import com.sec.chaton.k;
import com.sec.chaton.push.PushClientApplication;
import com.sec.chaton.push.PushClientService;
import com.sec.chaton.receiver.AlarmReceiver;
import com.sec.chaton.receiver.ScreenReceiver;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * ============================================================================
 * GlobalApplication — Android 16 (API 36) & ChatON-Net LocalBridge Entry Point (v2.7.106)
 * ============================================================================
 */
public class GlobalApplication extends PushClientApplication {
    public static String a = null;
    public static String b = null;
    public static boolean c = true;
    public static BlackScreenNotification d = null;
    public static ScreenOnNotification e = null;
    public static String f = null;
    public static boolean g = false;
    public static String h = null;
    public static k i = null;
    public static boolean k = true;
    public static boolean l = false;
    private static int m = 1080;
    private static int n = 2400;
    private static boolean o = false;
    private static GlobalApplication p = null;
    private static com.sec.chaton.util.k q = null;

    public Lock j = new ReentrantLock();

    public static Application a() {
        return p;
    }

    public static Context b() {
        return p;
    }

    public static Resources c() {
        return p.getResources();
    }

    public static com.sec.chaton.util.k d() {
        if (q == null) {
            q = new com.sec.chaton.util.k();
        }
        return q;
    }

    public static boolean e() {
        return o;
    }

    public static boolean f() {
        return true;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        p = this;

        // 1. Auto-provision local ChatON identity (@benjamin@chaton.live) & AES key
        AutoProvisioner.ensureProvisioned(this);

        // 2. Display metrics
        try {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            m = dm.widthPixels;
            n = dm.heightPixels;
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                c = pm.isScreenOn();
            }
        } catch (Throwable ignored) {}

        // 3. Safe Explicit Service start for PushClientService stub
        Intent pushIntent = new Intent(this, PushClientService.class);
        pushIntent.setAction("com.sec.chaton.push.PUSH_CLIENT_SERVICE_ACTION");
        Android16Compat.startServiceSafe(this, pushIntent);

        // 4. Safe BroadcastReceiver registrations with ContextCompat.RECEIVER_NOT_EXPORTED
        IntentFilter screenFilter = new IntentFilter();
        screenFilter.addAction(Intent.ACTION_SCREEN_ON);
        screenFilter.addAction(Intent.ACTION_SCREEN_OFF);
        Android16Compat.registerReceiverSafe(this, new ScreenReceiver(), screenFilter);

        IntentFilter alarmFilter = new IntentFilter();
        if (AlarmReceiver.a != null) alarmFilter.addAction(AlarmReceiver.a);
        if (AlarmReceiver.b != null) alarmFilter.addAction(AlarmReceiver.b);
        Android16Compat.registerReceiverSafe(this, new AlarmReceiver(), alarmFilter);

        // 5. Initialize core queues & seed local SQLite databases (chaton.db + trunk.db)
        ae.f();
        dc.a();
        o.a();
        MockRichBinaryAdapter.getInstance().initialize(this);
    }

    @Override
    public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter) {
        return Android16Compat.registerReceiverSafe(super.getBaseContext(), receiver, filter);
    }

    @Override
    public ComponentName startService(Intent service) {
        return Android16Compat.startServiceSafe(super.getBaseContext(), service);
    }
}
