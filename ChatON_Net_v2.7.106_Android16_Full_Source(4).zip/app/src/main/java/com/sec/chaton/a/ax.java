package com.sec.chaton.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/chaton/a/ax;
 */
public interface ax extends com.google.protobuf.MessageLiteOrBuilder {
}