package com.sec.chaton;

/**
 * Original SourceFile: SPPUpgradeDialog.java
 * Descriptor: Lcom/sec/chaton/SPPUpgradeDialog;
 */
public class SPPUpgradeDialog extends android.app.Activity {
    public SPPUpgradeDialog() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.app.Activity.<init> -> void
        return;
    }

    private void a() {
        // Registers (4 total): v3 = this
        v0 = "showPasswordLockActivity";
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v3.getApplicationContext(); // com.sec.chaton.SPPUpgradeDialog.getApplicationContext -> android.content.Context
        v0 = _result;
        _result = v0.c(); // com.sec.chaton.util.j.c -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0028 */;
        v1 = new android.content.Intent;
        v2 = com.sec.chaton.settings.ActivityPasswordLockSet.class;
        _result = v1.<init>(v0, v2); // android.content.Intent.<init> -> void
        v0 = "MODE";
        v2 = "HOME";
        _result = v1.putExtra(v0, v2); // android.content.Intent.putExtra -> android.content.Intent
        _result = v3.startActivity(v1); // com.sec.chaton.SPPUpgradeDialog.startActivity -> void
        return;
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.os.Bundle)
        v3 = com.sec.chaton.R.id.dialog_btn_yes; // 0x7f080703
        v2 = 11;
        v1 = 0;
        _result = v4.onCreate(v5); // android.app.Activity.onCreate -> void
        v0 = 1;
        _result = v4.requestWindowFeature(v0); // com.sec.chaton.SPPUpgradeDialog.requestWindowFeature -> boolean
        v0 = com.sec.chaton.R.layout.spp_upgrade_dialog; // 0x7f030184
        _result = v4.setContentView(v0); // com.sec.chaton.SPPUpgradeDialog.setContentView -> void
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        if (v0 < v2) /* goto L_001a */;
        _result = v4.setFinishOnTouchOutside(v1); // com.sec.chaton.SPPUpgradeDialog.setFinishOnTouchOutside -> void
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        if (v0 >= v2) /* goto L_003e */;
        _result = v4.findViewById(v3); // com.sec.chaton.SPPUpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v1 = new com.sec.chaton.an;
        _result = v1.<init>(v4); // com.sec.chaton.an.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = com.sec.chaton.R.id.dialog_btn_no; // 0x7f080704
        _result = v4.findViewById(v0); // com.sec.chaton.SPPUpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v1 = new com.sec.chaton.ao;
        _result = v1.<init>(v4); // com.sec.chaton.ao.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        return;
        v0 = com.sec.chaton.R.id.dialog_btn_yes_ics; // 0x7f080705
        _result = v4.findViewById(v0); // com.sec.chaton.SPPUpgradeDialog.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        _result = v0.setVisibility(v1); // android.widget.Button.setVisibility -> void
        _result = v4.findViewById(v3); // com.sec.chaton.SPPUpgradeDialog.findViewById -> android.view.View
        v1 = _result;
        v2 = 8;
        _result = v1.setVisibility(v2); // android.view.View.setVisibility -> void
        // goto L_0024
    }

    protected void onDestroy() {
        // Registers (1 total): v0 = this
        _result = v0.onDestroy(); // android.app.Activity.onDestroy -> void
        return;
    }

    public boolean onKeyDown(int p0, android.view.KeyEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (android.view.KeyEvent)
        v0 = 4;
        if (v2 != v0) /* goto L_0005 */;
        v0 = 1;
        return v0;
        _result = v1.onKeyDown(v2, v3); // android.app.Activity.onKeyDown -> boolean
        v0 = _result;
        // goto L_0004
    }

    protected void onResume() {
        // Registers (1 total): v0 = this
        _result = v0.onResume(); // android.app.Activity.onResume -> void
        _result = v0.a(); // com.sec.chaton.SPPUpgradeDialog.a -> void
        return;
    }

}