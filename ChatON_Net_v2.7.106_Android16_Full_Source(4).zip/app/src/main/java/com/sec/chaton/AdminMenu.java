package com.sec.chaton;

/**
 * Original SourceFile: AdminMenu.java
 * Descriptor: Lcom/sec/chaton/AdminMenu;
 */
public class AdminMenu extends com.sec.chaton.base.BaseActivity implements android.widget.TabHost$OnTabChangeListener {
    private static final java.lang.String[] b;
    private android.widget.Button A;
    private android.widget.Button B;
    private android.widget.Button C;
    private android.widget.Button D;
    private android.widget.Button E;
    private android.content.Context F;
    private android.app.ProgressDialog G;
    private boolean H;
    private android.widget.TabHost I;
    private android.widget.EditText J;
    private android.widget.EditText K;
    private boolean L;
    private int M;
    private android.widget.EditText N;
    private java.util.ArrayList O;
    private com.sec.chaton.d.o P;
    private int Q;
    private int R;
    private android.os.Handler S;
    private android.view.View$OnClickListener T;
    final android.os.Handler a;
    private android.widget.EditText c;
    private android.widget.EditText d;
    private android.widget.EditText e;
    private android.widget.EditText g;
    private android.widget.Button h;
    private android.widget.Button i;
    private android.widget.Button j;
    private android.widget.Button k;
    private android.widget.TextView l;
    private android.widget.Button m;
    private android.widget.Button n;
    private android.widget.Button o;
    private android.widget.Button p;
    private android.widget.Button q;
    private android.widget.Button r;
    private android.widget.Button s;
    private android.widget.Button t;
    private android.widget.Button u;
    private android.widget.Button v;
    private android.widget.Button w;
    private android.widget.Button x;
    private android.widget.Button y;
    private android.widget.Button z;

    static {
        v0 = 1;
        v0 = new java.lang.String[][size=v0];
        v1 = 0;
        v2 = "chatondev@samsung.com";
        v0[v1] = v2;
        com.sec.chaton.AdminMenu.b = v0; // :java.lang.String[]
        return;
    }

    public AdminMenu() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.sec.chaton.base.BaseActivity.<init> -> void
        v0 = 0;
        v1.G = v0; // com.sec.chaton.AdminMenu.G:android.app.ProgressDialog
        v0 = 0;
        v1.H = v0; // com.sec.chaton.AdminMenu.H:boolean
        v0 = new com.sec.chaton.b;
        _result = v0.<init>(v1); // com.sec.chaton.b.<init> -> void
        v1.T = v0; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        v0 = new com.sec.chaton.c;
        _result = v0.<init>(v1); // com.sec.chaton.c.<init> -> void
        v1.a = v0; // com.sec.chaton.AdminMenu.a:android.os.Handler
        return;
    }

    static com.sec.chaton.d.o A(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.P; // com.sec.chaton.AdminMenu.P:com.sec.chaton.d.o
        return v0;
    }

    static int B(com.sec.chaton.AdminMenu p0) {
        // Registers (3 total): v2 = p0 (com.sec.chaton.AdminMenu)
        v0 = v2.Q; // com.sec.chaton.AdminMenu.Q:int
        v1 = binOpLit8_0xd8(v0, 1);
        v2.Q = v1; // com.sec.chaton.AdminMenu.Q:int
        return v0;
    }

    static int C(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.R; // com.sec.chaton.AdminMenu.R:int
        return v0;
    }

    static int a(com.sec.chaton.AdminMenu p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.AdminMenu), v1 = p1 (int)
        v0.Q = v1; // com.sec.chaton.AdminMenu.Q:int
        return v1;
    }

    static android.app.ProgressDialog a(com.sec.chaton.AdminMenu p0, android.app.ProgressDialog p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.AdminMenu), v1 = p1 (android.app.ProgressDialog)
        v0.G = v1; // com.sec.chaton.AdminMenu.G:android.app.ProgressDialog
        return v1;
    }

    static android.widget.Button a(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.u; // com.sec.chaton.AdminMenu.u:android.widget.Button
        return v0;
    }

    public static void a() {
        v1 = 0;
        v0 = "TEST";
        v2 = "copyPreferenceToSdcard start";
        _result = v0.i(v2); // android.util.Log.i -> int
        v2 = new java.io.File;
        v0 = "data/data/com.sec.chaton/shared_prefs/";
        v3 = "ChatON.xml";
        _result = v2.<init>(v0, v3); // java.io.File.<init> -> void
        v0 = new java.io.FileInputStream;
        _result = v0.<init>(v2); // java.io.FileInputStream.<init> -> void
        v2 = new java.io.FileOutputStream;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = this.getExternalStorageDirectory(); // android.os.Environment.getExternalStorageDirectory -> java.io.File
        v4 = _result;
        _result = v4.getAbsolutePath(); // java.io.File.getAbsolutePath -> java.lang.String
        v4 = _result;
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = "/chaton.xml";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v2.<init>(v3); // java.io.FileOutputStream.<init> -> void
        v1 = v2;
        v2 = 1;
        v2 = new byte[][size=v2];
        _result = v0.read(v2); // java.io.InputStream.read -> int
        v3 = _result;
        if (v3 <= 0) /* goto L_0048 */;
        _result = v1.write(v2); // java.io.OutputStream.write -> void
        // goto L_003a
        v2 = _exception;
        _result = v2.printStackTrace(); // java.io.IOException.printStackTrace -> void
        _result = v1.flush(); // java.io.OutputStream.flush -> void
        _result = v1.close(); // java.io.OutputStream.close -> void
        _result = v0.close(); // java.io.InputStream.close -> void
        v0 = "TEST";
        v1 = "copyPreferenceToSdcard end";
        _result = v0.i(v1); // android.util.Log.i -> int
        return;
        v0 = _exception;
        _result = v0.printStackTrace(); // java.io.FileNotFoundException.printStackTrace -> void
        v0 = v1;
        // goto L_0016
        v2 = _exception;
        _result = v2.printStackTrace(); // java.io.FileNotFoundException.printStackTrace -> void
        // goto L_0037
        v2 = _exception;
        _result = v2.printStackTrace(); // java.io.IOException.printStackTrace -> void
        // goto L_004b
        v1 = _exception;
        _result = v1.printStackTrace(); // java.io.IOException.printStackTrace -> void
        // goto L_004e
        v0 = _exception;
        _result = v0.printStackTrace(); // java.io.IOException.printStackTrace -> void
        // goto L_0051
    }

    static boolean a(com.sec.chaton.AdminMenu p0, boolean p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.AdminMenu), v1 = p1 (boolean)
        v0.H = v1; // com.sec.chaton.AdminMenu.H:boolean
        return v1;
    }

    static int b(com.sec.chaton.AdminMenu p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.AdminMenu), v1 = p1 (int)
        v0.R = v1; // com.sec.chaton.AdminMenu.R:int
        return v1;
    }

    static java.util.ArrayList b(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.O; // com.sec.chaton.AdminMenu.O:java.util.ArrayList
        return v0;
    }

    public static void b() {
        v0 = "TEST";
        v1 = "copyAutoResendTraceToSdcard start";
        _result = v0.i(v1); // android.util.Log.i -> int
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v0 = _result;
        _result = v0.a(); // com.sec.chaton.msgsend.q.a -> java.io.File
        v0 = _result;
        _result = v0.exists(); // java.io.File.exists -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_001e */;
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v1 = _result;
        v2 = "try to copy to sdcard, but not exist. make empty trace file now";
        _result = v1.a(v2); // com.sec.chaton.msgsend.q.a -> void
        v1 = new java.io.FileInputStream;
        _result = v1.<init>(v0); // java.io.FileInputStream.<init> -> void
        v0 = new java.io.FileOutputStream;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = this.getExternalStorageDirectory(); // android.os.Environment.getExternalStorageDirectory -> java.io.File
        v3 = _result;
        _result = v3.getAbsolutePath(); // java.io.File.getAbsolutePath -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = "/";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = this.f(); // com.sec.chaton.msgsend.q.f -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v0.<init>(v2); // java.io.FileOutputStream.<init> -> void
        v2 = 1024;
        v2 = new byte[][size=v2];
        _result = v1.read(v2); // java.io.InputStream.read -> int
        v3 = _result;
        if (v3 <= 0) /* goto L_0066 */;
        v4 = 0;
        _result = v0.write(v2, v4, v3); // java.io.OutputStream.write -> void
        // goto L_004f
        v0 = _exception;
        _result = v0.printStackTrace(); // java.io.FileNotFoundException.printStackTrace -> void
        v0 = "TEST";
        v1 = "copyAutoResendTraceToSdcard end";
        _result = v0.i(v1); // android.util.Log.i -> int
        return;
        _result = v0.flush(); // java.io.OutputStream.flush -> void
        _result = v0.close(); // java.io.OutputStream.close -> void
        _result = v1.close(); // java.io.InputStream.close -> void
        // goto L_005e
        v0 = _exception;
        // goto L_005e
    }

    static int c(com.sec.chaton.AdminMenu p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.AdminMenu), v1 = p1 (int)
        v0.M = v1; // com.sec.chaton.AdminMenu.M:int
        return v1;
    }

    static void c(com.sec.chaton.AdminMenu p0) {
        // Registers (1 total): v0 = p0 (com.sec.chaton.AdminMenu)
        _result = v0.f(); // com.sec.chaton.AdminMenu.f -> void
        return;
    }

    static java.lang.String[] c() {
        v0 = com.sec.chaton.AdminMenu.b; // :java.lang.String[]
        return v0;
    }

    private void d() {
        // Registers (6 total): v5 = this
        v4 = 0;
        v1 = new com.sec.common.widget.b;
        v0 = v5.F; // com.sec.chaton.AdminMenu.F:android.content.Context
        _result = v1.<init>(v0); // com.sec.common.widget.b.<init> -> void
        v0 = "DB File SendEmail";
        _result = v1.setTitle(v0); // com.sec.common.widget.b.setTitle -> void
        v0 = v5.F; // com.sec.chaton.AdminMenu.F:android.content.Context
        v2 = "layout_inflater";
        _result = v0.getSystemService(v2); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        v2 = com.sec.chaton.R.layout.admin_menu_db_sendmail; // 0x7f030007
        v3 = 0;
        _result = v0.inflate(v2, v3); // android.view.LayoutInflater.inflate -> android.view.View
        v0 = _result;
        _result = v1.setView(v0); // com.sec.common.widget.b.setView -> void
        v2 = com.sec.chaton.R.id.admin_menu_db_send_mail; // 0x7f08001c
        _result = v0.findViewById(v2); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.EditText) v0;
        v5.N = v0; // com.sec.chaton.AdminMenu.N:android.widget.EditText
        v0 = -1;
        _result = v5.getResources(); // com.sec.chaton.AdminMenu.getResources -> android.content.res.Resources
        v2 = _result;
        v3 = com.sec.chaton.R.string.dialog_ok; // 0x7f0c006b
        _result = v2.getString(v3); // android.content.res.Resources.getString -> java.lang.String
        v2 = _result;
        v3 = new com.sec.chaton.d;
        _result = v3.<init>(v5); // com.sec.chaton.d.<init> -> void
        _result = v1.setButton(v0, v2, v3); // com.sec.common.widget.b.setButton -> void
        v0 = -2;
        _result = v5.getResources(); // com.sec.chaton.AdminMenu.getResources -> android.content.res.Resources
        v2 = _result;
        v3 = com.sec.chaton.R.string.dialog_cancel; // 0x7f0c006d
        _result = v2.getString(v3); // android.content.res.Resources.getString -> java.lang.String
        v2 = _result;
        v3 = new com.sec.chaton.e;
        _result = v3.<init>(v5); // com.sec.chaton.e.<init> -> void
        _result = v1.setButton(v0, v2, v3); // com.sec.common.widget.b.setButton -> void
        _result = v1.setCancelable(v4); // com.sec.common.widget.b.setCancelable -> void
        _result = v1.setCanceledOnTouchOutside(v4); // com.sec.common.widget.b.setCanceledOnTouchOutside -> void
        _result = v1.show(); // com.sec.common.widget.b.show -> void
        return;
    }

    static void d(com.sec.chaton.AdminMenu p0) {
        // Registers (1 total): v0 = p0 (com.sec.chaton.AdminMenu)
        _result = v0.h(); // com.sec.chaton.AdminMenu.h -> void
        return;
    }

    static android.content.Context e(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.F; // com.sec.chaton.AdminMenu.F:android.content.Context
        return v0;
    }

    private void e() {
        // Registers (6 total): v5 = this
        v4 = 0;
        v1 = new com.sec.common.widget.b;
        v0 = v5.F; // com.sec.chaton.AdminMenu.F:android.content.Context
        _result = v1.<init>(v0); // com.sec.common.widget.b.<init> -> void
        v0 = "Enter Password";
        _result = v1.setTitle(v0); // com.sec.common.widget.b.setTitle -> void
        v0 = v5.F; // com.sec.chaton.AdminMenu.F:android.content.Context
        v2 = "layout_inflater";
        _result = v0.getSystemService(v2); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        v2 = com.sec.chaton.R.layout.admin_menu_password; // 0x7f030008
        v3 = 0;
        _result = v0.inflate(v2, v3); // android.view.LayoutInflater.inflate -> android.view.View
        v2 = _result;
        _result = v1.setView(v2); // com.sec.common.widget.b.setView -> void
        v0 = com.sec.chaton.R.id.admin_id_input; // 0x7f08001d
        _result = v2.findViewById(v0); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.EditText) v0;
        v5.J = v0; // com.sec.chaton.AdminMenu.J:android.widget.EditText
        v0 = com.sec.chaton.R.id.admin_pass_input; // 0x7f08001e
        _result = v2.findViewById(v0); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.EditText) v0;
        v5.K = v0; // com.sec.chaton.AdminMenu.K:android.widget.EditText
        v0 = -1;
        _result = v5.getResources(); // com.sec.chaton.AdminMenu.getResources -> android.content.res.Resources
        v2 = _result;
        v3 = com.sec.chaton.R.string.dialog_ok; // 0x7f0c006b
        _result = v2.getString(v3); // android.content.res.Resources.getString -> java.lang.String
        v2 = _result;
        v3 = new com.sec.chaton.f;
        _result = v3.<init>(v5); // com.sec.chaton.f.<init> -> void
        _result = v1.setButton(v0, v2, v3); // com.sec.common.widget.b.setButton -> void
        v0 = -2;
        _result = v5.getResources(); // com.sec.chaton.AdminMenu.getResources -> android.content.res.Resources
        v2 = _result;
        v3 = com.sec.chaton.R.string.dialog_cancel; // 0x7f0c006d
        _result = v2.getString(v3); // android.content.res.Resources.getString -> java.lang.String
        v2 = _result;
        v3 = new com.sec.chaton.g;
        _result = v3.<init>(v5); // com.sec.chaton.g.<init> -> void
        _result = v1.setButton(v0, v2, v3); // com.sec.common.widget.b.setButton -> void
        _result = v1.setCancelable(v4); // com.sec.common.widget.b.setCancelable -> void
        _result = v1.setCanceledOnTouchOutside(v4); // com.sec.common.widget.b.setCanceledOnTouchOutside -> void
        _result = v1.show(); // com.sec.common.widget.b.show -> void
        return;
    }

    static android.app.ProgressDialog f(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.G; // com.sec.chaton.AdminMenu.G:android.app.ProgressDialog
        return v0;
    }

    private void f() {
        // Registers (7 total): v6 = this
        v1 = 199;
        v2 = "827799990";
        v0 = 0;
        if (v0 >= v1) /* goto L_006e */;
        v3 = 10;
        if (v0 >= v3) /* goto L_002e */;
        v3 = v6.O; // com.sec.chaton.AdminMenu.O:java.util.ArrayList
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = "00";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v0.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v5 = _result;
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v3.add(v4); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0005
        v3 = 100;
        if (v0 >= v3) /* goto L_0053 */;
        v3 = v6.O; // com.sec.chaton.AdminMenu.O:java.util.ArrayList
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = "0";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v0.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v5 = _result;
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v3.add(v4); // java.util.ArrayList.add -> boolean
        // goto L_002b
        v3 = v6.O; // com.sec.chaton.AdminMenu.O:java.util.ArrayList
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v0.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v5 = _result;
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v3.add(v4); // java.util.ArrayList.add -> boolean
        // goto L_002b
        return;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    static void g(com.sec.chaton.AdminMenu p0) {
        // Registers (1 total): v0 = p0 (com.sec.chaton.AdminMenu)
        _result = v0.i(); // com.sec.chaton.AdminMenu.i -> void
        return;
    }

    static int h(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.M; // com.sec.chaton.AdminMenu.M:int
        return v0;
    }

    private void h() {
        // Registers (2 total): v1 = this
        v0 = new com.sec.chaton.h;
        _result = v0.<init>(v1); // com.sec.chaton.h.<init> -> void
        v1.S = v0; // com.sec.chaton.AdminMenu.S:android.os.Handler
        return;
    }

    static android.widget.Button i(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.q; // com.sec.chaton.AdminMenu.q:android.widget.Button
        return v0;
    }

    private void i() {
        // Registers (4 total): v3 = this
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v0 = _result;
        _result = v0.a(); // com.sec.chaton.util.RTLogCollector.a -> com.sec.chaton.util.RTLogCollector
        v0 = _result;
        _result = v0.c(); // com.sec.chaton.util.RTLogCollector.c -> boolean
        v1 = _result;
        v2 = v3.o; // com.sec.chaton.AdminMenu.o:android.widget.Button
        if (v1 != 0) /* goto L_001a */;
        v0 = 1;
        _result = v2.setEnabled(v0); // android.widget.Button.setEnabled -> void
        v0 = v3.p; // com.sec.chaton.AdminMenu.p:android.widget.Button
        _result = v0.setEnabled(v1); // android.widget.Button.setEnabled -> void
        return;
        v0 = 0;
        // goto L_0011
    }

    static android.widget.TextView j(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.l; // com.sec.chaton.AdminMenu.l:android.widget.TextView
        return v0;
    }

    static android.widget.EditText k(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.c; // com.sec.chaton.AdminMenu.c:android.widget.EditText
        return v0;
    }

    static android.widget.EditText l(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.d; // com.sec.chaton.AdminMenu.d:android.widget.EditText
        return v0;
    }

    static android.widget.EditText m(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.e; // com.sec.chaton.AdminMenu.e:android.widget.EditText
        return v0;
    }

    static android.widget.EditText n(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.g; // com.sec.chaton.AdminMenu.g:android.widget.EditText
        return v0;
    }

    static android.widget.Button o(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.w; // com.sec.chaton.AdminMenu.w:android.widget.Button
        return v0;
    }

    static android.widget.Button p(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.x; // com.sec.chaton.AdminMenu.x:android.widget.Button
        return v0;
    }

    static android.widget.Button q(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.y; // com.sec.chaton.AdminMenu.y:android.widget.Button
        return v0;
    }

    static android.widget.Button r(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.z; // com.sec.chaton.AdminMenu.z:android.widget.Button
        return v0;
    }

    static android.widget.Button s(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.A; // com.sec.chaton.AdminMenu.A:android.widget.Button
        return v0;
    }

    static void t(com.sec.chaton.AdminMenu p0) {
        // Registers (1 total): v0 = p0 (com.sec.chaton.AdminMenu)
        _result = v0.d(); // com.sec.chaton.AdminMenu.d -> void
        return;
    }

    static android.widget.EditText u(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.N; // com.sec.chaton.AdminMenu.N:android.widget.EditText
        return v0;
    }

    static android.widget.EditText v(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.J; // com.sec.chaton.AdminMenu.J:android.widget.EditText
        return v0;
    }

    static android.widget.EditText w(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.K; // com.sec.chaton.AdminMenu.K:android.widget.EditText
        return v0;
    }

    static android.widget.TabHost x(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        return v0;
    }

    static int y(com.sec.chaton.AdminMenu p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.AdminMenu)
        v0 = v1.Q; // com.sec.chaton.AdminMenu.Q:int
        return v0;
    }

    static void z(com.sec.chaton.AdminMenu p0) {
        // Registers (1 total): v0 = p0 (com.sec.chaton.AdminMenu)
        _result = v0.g(); // com.sec.chaton.AdminMenu.g -> void
        return;
    }

    public boolean a(java.lang.String p0, java.lang.String p1) {
        // Registers (7 total): v4 = this, v5 = p0 (java.lang.String), v6 = p1 (java.lang.String)
        v0 = 0;
        v1 = "MD5";
        _result = v1.getInstance(); // java.security.MessageDigest.getInstance -> java.security.MessageDigest
        v1 = _result;
        _result = v5.getBytes(); // java.lang.String.getBytes -> byte[]
        v2 = _result;
        _result = v1.update(v2); // java.security.MessageDigest.update -> void
        v2 = new java.math.BigInteger;
        v3 = 1;
        _result = v1.digest(); // java.security.MessageDigest.digest -> byte[]
        v1 = _result;
        _result = v2.<init>(v3, v1); // java.math.BigInteger.<init> -> void
        v1 = 16;
        _result = v2.toString(v1); // java.math.BigInteger.toString -> java.lang.String
        v0 = _result;
        _result = v6.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        return v0;
        v1 = _exception;
        _result = v1.printStackTrace(); // java.security.NoSuchAlgorithmException.printStackTrace -> void
        // goto L_001e
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.os.Bundle)
        v5 = 1;
        v2 = 0;
        _result = v6.onCreate(v7); // com.sec.chaton.base.BaseActivity.onCreate -> void
        v6.F = v6; // com.sec.chaton.AdminMenu.F:android.content.Context
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v6.O = v0; // com.sec.chaton.AdminMenu.O:java.util.ArrayList
        v0 = com.sec.chaton.R.layout.admin_tab_menu; // 0x7f030009
        _result = v6.setContentView(v0); // com.sec.chaton.AdminMenu.setContentView -> void
        v0 = com.sec.chaton.R.id.admin_tab_menu; // 0x7f080020
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TabHost) v0;
        v6.I = v0; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        v0 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        _result = v0.setup(); // android.widget.TabHost.setup -> void
        v0 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        v1 = "Tab1";
        _result = v0.newTabSpec(v1); // android.widget.TabHost.newTabSpec -> android.widget.TabHost$TabSpec
        v0 = _result;
        v1 = "GENERAL";
        _result = v0.setIndicator(v1); // android.widget.TabHost$TabSpec.setIndicator -> android.widget.TabHost$TabSpec
        v1 = com.sec.chaton.R.id.tab_general; // 0x7f080021
        _result = v0.setContent(v1); // android.widget.TabHost$TabSpec.setContent -> android.widget.TabHost$TabSpec
        v1 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        _result = v1.addTab(v0); // android.widget.TabHost.addTab -> void
        v0 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        v1 = "Tab2";
        _result = v0.newTabSpec(v1); // android.widget.TabHost.newTabSpec -> android.widget.TabHost$TabSpec
        v0 = _result;
        v1 = "SQE";
        _result = v0.setIndicator(v1); // android.widget.TabHost$TabSpec.setIndicator -> android.widget.TabHost$TabSpec
        v1 = com.sec.chaton.R.id.tab_sqe; // 0x7f080027
        _result = v0.setContent(v1); // android.widget.TabHost$TabSpec.setContent -> android.widget.TabHost$TabSpec
        v1 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        _result = v1.addTab(v0); // android.widget.TabHost.addTab -> void
        v0 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        v1 = "Tab3";
        _result = v0.newTabSpec(v1); // android.widget.TabHost.newTabSpec -> android.widget.TabHost$TabSpec
        v0 = _result;
        v1 = "DEV";
        _result = v0.setIndicator(v1); // android.widget.TabHost$TabSpec.setIndicator -> android.widget.TabHost$TabSpec
        v1 = com.sec.chaton.R.id.tab_dev; // 0x7f080029
        _result = v0.setContent(v1); // android.widget.TabHost$TabSpec.setContent -> android.widget.TabHost$TabSpec
        v1 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        _result = v1.addTab(v0); // android.widget.TabHost.addTab -> void
        _result = v6.getIntent(); // com.sec.chaton.AdminMenu.getIntent -> android.content.Intent
        v0 = _result;
        _result = v0.getExtras(); // android.content.Intent.getExtras -> android.os.Bundle
        v3 = _result;
        v0 = com.sec.chaton.R.id.timeOut; // 0x7f08002e
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.EditText) v0;
        v6.c = v0; // com.sec.chaton.AdminMenu.c:android.widget.EditText
        v0 = v6.c; // com.sec.chaton.AdminMenu.c:android.widget.EditText
        v1 = "0";
        _result = v0.setText(v1); // android.widget.EditText.setText -> void
        v0 = com.sec.chaton.R.id.replyTimeOut; // 0x7f080030
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.EditText) v0;
        v6.d = v0; // com.sec.chaton.AdminMenu.d:android.widget.EditText
        v0 = v6.d; // com.sec.chaton.AdminMenu.d:android.widget.EditText
        v1 = "0";
        _result = v0.setText(v1); // android.widget.EditText.setText -> void
        v0 = com.sec.chaton.R.id.chatTimeOut; // 0x7f080032
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.EditText) v0;
        v6.e = v0; // com.sec.chaton.AdminMenu.e:android.widget.EditText
        v0 = v6.e; // com.sec.chaton.AdminMenu.e:android.widget.EditText
        v1 = "0";
        _result = v0.setText(v1); // android.widget.EditText.setText -> void
        v0 = com.sec.chaton.R.id.initChatTimeOut; // 0x7f080034
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.EditText) v0;
        v6.g = v0; // com.sec.chaton.AdminMenu.g:android.widget.EditText
        v0 = v6.g; // com.sec.chaton.AdminMenu.g:android.widget.EditText
        v1 = "0";
        _result = v0.setText(v1); // android.widget.EditText.setText -> void
        v0 = com.sec.chaton.R.id.timeOutValueSet; // 0x7f080035
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.h = v0; // com.sec.chaton.AdminMenu.h:android.widget.Button
        v0 = v6.h; // com.sec.chaton.AdminMenu.h:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = com.sec.chaton.R.id.timeOutValueReset; // 0x7f080036
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.i = v0; // com.sec.chaton.AdminMenu.i:android.widget.Button
        v0 = v6.i; // com.sec.chaton.AdminMenu.i:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = com.sec.chaton.R.id.applyhanzitopinyin; // 0x7f080037
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.j = v0; // com.sec.chaton.AdminMenu.j:android.widget.Button
        v0 = v6.j; // com.sec.chaton.AdminMenu.j:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = com.sec.chaton.R.id.resethanzitopinyin; // 0x7f080038
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.k = v0; // com.sec.chaton.AdminMenu.k:android.widget.Button
        v0 = v6.k; // com.sec.chaton.AdminMenu.k:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = com.sec.chaton.R.id.mccCode; // 0x7f08002c
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TextView) v0;
        v6.l = v0; // com.sec.chaton.AdminMenu.l:android.widget.TextView
        v0 = v6.l; // com.sec.chaton.AdminMenu.l:android.widget.TextView
        _result = this.f(); // com.sec.chaton.util.ac.f -> java.lang.String
        v1 = _result;
        _result = v0.setText(v1); // android.widget.TextView.setText -> void
        v0 = com.sec.chaton.R.id.btn_make_dummy_groupchatroom100; // 0x7f080039
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.m = v0; // com.sec.chaton.AdminMenu.m:android.widget.Button
        v0 = com.sec.chaton.R.id.btn_make_dummy_groupchatroom200; // 0x7f08003a
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.n = v0; // com.sec.chaton.AdminMenu.n:android.widget.Button
        v0 = v6.m; // com.sec.chaton.AdminMenu.m:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.n; // com.sec.chaton.AdminMenu.n:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = com.sec.chaton.R.id.btn_start_log_collector; // 0x7f080024
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.o = v0; // com.sec.chaton.AdminMenu.o:android.widget.Button
        v0 = com.sec.chaton.R.id.btn_stop_log_collector; // 0x7f080025
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.p = v0; // com.sec.chaton.AdminMenu.p:android.widget.Button
        v0 = v6.o; // com.sec.chaton.AdminMenu.o:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.p; // com.sec.chaton.AdminMenu.p:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        _result = v6.i(); // com.sec.chaton.AdminMenu.i -> void
        v0 = com.sec.chaton.R.id.btn_autoresend_turn_on_off; // 0x7f080026
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.z = v0; // com.sec.chaton.AdminMenu.z:android.widget.Button
        v0 = com.sec.chaton.R.id.btn_autoresend_enable_notification; // 0x7f08003b
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.A = v0; // com.sec.chaton.AdminMenu.A:android.widget.Button
        v0 = com.sec.chaton.R.id.btn_autoresend_dump_log_current; // 0x7f08003c
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.B = v0; // com.sec.chaton.AdminMenu.B:android.widget.Button
        v0 = com.sec.chaton.R.id.btn_autoresend_do_send; // 0x7f08003e
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.C = v0; // com.sec.chaton.AdminMenu.C:android.widget.Button
        v0 = com.sec.chaton.R.id.btn_autoresend_loaddb; // 0x7f08003d
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.D = v0; // com.sec.chaton.AdminMenu.D:android.widget.Button
        v0 = com.sec.chaton.R.id.btn_autoresend_clearmsg; // 0x7f08003f
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.E = v0; // com.sec.chaton.AdminMenu.E:android.widget.Button
        v0 = v6.z; // com.sec.chaton.AdminMenu.z:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.A; // com.sec.chaton.AdminMenu.A:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.B; // com.sec.chaton.AdminMenu.B:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.C; // com.sec.chaton.AdminMenu.C:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.D; // com.sec.chaton.AdminMenu.D:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.E; // com.sec.chaton.AdminMenu.E:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        _result = this.b(); // com.sec.chaton.msgsend.q.b -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_02f6 */;
        v0 = v6.z; // com.sec.chaton.AdminMenu.z:android.widget.Button
        v1 = "A-Resend:ENABLED";
        _result = v0.setText(v1); // android.widget.Button.setText -> void
        _result = this.g(); // com.sec.chaton.msgsend.q.g -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_02ff */;
        v0 = v6.A; // com.sec.chaton.AdminMenu.A:android.widget.Button
        v1 = "A-Resend:Noti enabled";
        _result = v0.setText(v1); // android.widget.Button.setText -> void
        v0 = com.sec.chaton.R.id.btn_random_imei; // 0x7f080040
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.r = v0; // com.sec.chaton.AdminMenu.r:android.widget.Button
        v0 = com.sec.chaton.R.id.btn_change_GLD; // 0x7f080041
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.s = v0; // com.sec.chaton.AdminMenu.s:android.widget.Button
        v0 = com.sec.chaton.R.id.btn_skip; // 0x7f080042
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.t = v0; // com.sec.chaton.AdminMenu.t:android.widget.Button
        v0 = com.sec.chaton.R.id.chaton_upgrade; // 0x7f080043
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.w = v0; // com.sec.chaton.AdminMenu.w:android.widget.Button
        v0 = com.sec.chaton.R.id.chaton_notice; // 0x7f080044
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.x = v0; // com.sec.chaton.AdminMenu.x:android.widget.Button
        v0 = com.sec.chaton.R.id.chaton_disclaimer; // 0x7f080045
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.y = v0; // com.sec.chaton.AdminMenu.y:android.widget.Button
        v0 = v6.r; // com.sec.chaton.AdminMenu.r:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.s; // com.sec.chaton.AdminMenu.s:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.t; // com.sec.chaton.AdminMenu.t:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.w; // com.sec.chaton.AdminMenu.w:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.x; // com.sec.chaton.AdminMenu.x:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.y; // com.sec.chaton.AdminMenu.y:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = com.sec.chaton.R.id.btn_push_status; // 0x7f080023
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.u = v0; // com.sec.chaton.AdminMenu.u:android.widget.Button
        v0 = v6.u; // com.sec.chaton.AdminMenu.u:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        _result = this.a(); // com.sec.chaton.d.am.a -> com.sec.chaton.d.a
        v0 = _result;
        v1 = new com.sec.chaton.a;
        _result = this.getMainLooper(); // android.os.Looper.getMainLooper -> android.os.Looper
        v4 = _result;
        _result = v1.<init>(v6, v4); // com.sec.chaton.a.<init> -> void
        _result = v0.c(v1); // com.sec.chaton.d.a.c -> void
        v0 = com.sec.chaton.R.id.btn_log_on_off; // 0x7f080022
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.q = v0; // com.sec.chaton.AdminMenu.q:android.widget.Button
        v0 = v6.q; // com.sec.chaton.AdminMenu.q:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        _result = this.b(); // com.sec.chaton.util.p.b -> int
        v0 = _result;
        v6.M = v0; // com.sec.chaton.AdminMenu.M:int
        _result = v5.a(); // com.sec.chaton.util.p.a -> void
        v0 = v6.M; // com.sec.chaton.AdminMenu.M:int
        if (v0 <= 0) /* goto L_0308 */;
        v0 = v6.q; // com.sec.chaton.AdminMenu.q:android.widget.Button
        v1 = "Log Off";
        _result = v0.setText(v1); // android.widget.Button.setText -> void
        v0 = v6.L; // com.sec.chaton.AdminMenu.L:boolean
        if (v0 != v5) /* goto L_02ab */;
        v0 = v6.s; // com.sec.chaton.AdminMenu.s:android.widget.Button
        _result = v0.setEnabled(v2); // android.widget.Button.setEnabled -> void
        v0 = v6.r; // com.sec.chaton.AdminMenu.r:android.widget.Button
        _result = v0.setEnabled(v2); // android.widget.Button.setEnabled -> void
        v0 = com.sec.chaton.R.id.dump_database; // 0x7f080028
        _result = v6.findViewById(v0); // com.sec.chaton.AdminMenu.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.Button) v0;
        v6.v = v0; // com.sec.chaton.AdminMenu.v:android.widget.Button
        v0 = v6.v; // com.sec.chaton.AdminMenu.v:android.widget.Button
        v1 = v6.T; // com.sec.chaton.AdminMenu.T:android.view.View$OnClickListener
        _result = v0.setOnClickListener(v1); // android.widget.Button.setOnClickListener -> void
        v0 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        v1 = 8;
        _result = v0.setVisibility(v1); // android.widget.TabHost.setVisibility -> void
        v0 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        _result = v0.setOnTabChangedListener(v6); // android.widget.TabHost.setOnTabChangedListener -> void
        v1 = v2;
        v0 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        _result = v0.getTabWidget(); // android.widget.TabHost.getTabWidget -> android.widget.TabWidget
        v0 = _result;
        _result = v0.getChildCount(); // android.widget.TabWidget.getChildCount -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0310 */;
        v0 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        _result = v0.getTabWidget(); // android.widget.TabHost.getTabWidget -> android.widget.TabWidget
        v0 = _result;
        _result = v0.getChildAt(v1); // android.widget.TabWidget.getChildAt -> android.view.View
        v0 = _result;
        v4 = 16908310; // 0x01020016
        _result = v0.findViewById(v4); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.TextView) v0;
        v4 = "#ffffff";
        _result = v4.parseColor(); // android.graphics.Color.parseColor -> int
        v4 = _result;
        _result = v0.setTextColor(v4); // android.widget.TextView.setTextColor -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_02ca
        v0 = v6.z; // com.sec.chaton.AdminMenu.z:android.widget.Button
        v1 = "A-Resend:DISABLED";
        _result = v0.setText(v1); // android.widget.Button.setText -> void
        // goto L_01dc
        v0 = v6.A; // com.sec.chaton.AdminMenu.A:android.widget.Button
        v1 = "A-Resend:Noti disabled";
        _result = v0.setText(v1); // android.widget.Button.setText -> void
        // goto L_01e9
        v0 = v6.q; // com.sec.chaton.AdminMenu.q:android.widget.Button
        v1 = "Log On";
        _result = v0.setText(v1); // android.widget.Button.setText -> void
        // goto L_029d
        if (v3 == 0) /* goto L_032c */;
        v0 = "mapping_mode";
        _result = v3.getBoolean(v0, v2); // android.os.Bundle.getBoolean -> boolean
        v0 = _result;
        v6.L = v0; // com.sec.chaton.AdminMenu.L:boolean
        v0 = "general_tab";
        _result = v3.getBoolean(v0, v5); // android.os.Bundle.getBoolean -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0328 */;
        v0 = v6.I; // com.sec.chaton.AdminMenu.I:android.widget.TabHost
        _result = v0.setVisibility(v2); // android.widget.TabHost.setVisibility -> void
        return;
        _result = v6.e(); // com.sec.chaton.AdminMenu.e -> void
        // goto L_0327
        _result = v6.e(); // com.sec.chaton.AdminMenu.e -> void
        // goto L_0327
    }

    public void onTabChanged(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        return;
    }

}