package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/ah;
 */
public final class ah extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.chaton.a.ai {
    private int a;
    private com.sec.chaton.a.aj b;
    private java.lang.Object c;
    private java.lang.Object d;

    private ah() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = com.sec.chaton.a.aj.a; // :com.sec.chaton.a.aj
        v1.b = v0; // com.sec.chaton.a.ah.b:com.sec.chaton.a.aj
        v0 = "";
        v1.c = v0; // com.sec.chaton.a.ah.c:java.lang.Object
        v0 = "";
        v1.d = v0; // com.sec.chaton.a.ah.d:java.lang.Object
        _result = v1.g(); // com.sec.chaton.a.ah.g -> void
        return;
    }

    static com.sec.chaton.a.ah f() {
        _result = this.h(); // com.sec.chaton.a.ah.h -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.chaton.a.ah h() {
        v0 = new com.sec.chaton.a.ah;
        _result = v0.<init>(); // com.sec.chaton.a.ah.<init> -> void
        return v0;
    }

    public com.sec.chaton.a.ah a() {
        // Registers (2 total): v1 = this
        _result = v1.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = com.sec.chaton.a.aj.a; // :com.sec.chaton.a.aj
        v1.b = v0; // com.sec.chaton.a.ah.b:com.sec.chaton.a.aj
        v0 = v1.a; // com.sec.chaton.a.ah.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v1.a = v0; // com.sec.chaton.a.ah.a:int
        v0 = "";
        v1.c = v0; // com.sec.chaton.a.ah.c:java.lang.Object
        v0 = v1.a; // com.sec.chaton.a.ah.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v1.a = v0; // com.sec.chaton.a.ah.a:int
        v0 = "";
        v1.d = v0; // com.sec.chaton.a.ah.d:java.lang.Object
        v0 = v1.a; // com.sec.chaton.a.ah.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v1.a = v0; // com.sec.chaton.a.ah.a:int
        return v1;
    }

    public com.sec.chaton.a.ah a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.CodedInputStream), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v2.parseUnknownField(v3, v4, v0); // com.sec.chaton.a.ah.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v2;
        _result = v3.readEnum(); // com.google.protobuf.CodedInputStream.readEnum -> int
        v0 = _result;
        _result = v0.a(); // com.sec.chaton.a.aj.a -> com.sec.chaton.a.aj
        v0 = _result;
        if (v0 == 0) /* goto L_0000 */;
        v1 = v2.a; // com.sec.chaton.a.ah.a:int
        v1 = binOpLit8_0xde(v1, 1);
        v2.a = v1; // com.sec.chaton.a.ah.a:int
        v2.b = v0; // com.sec.chaton.a.ah.b:com.sec.chaton.a.aj
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ah.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v2.a = v0; // com.sec.chaton.a.ah.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.c = v0; // com.sec.chaton.a.ah.c:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ah.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v2.a = v0; // com.sec.chaton.a.ah.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.d = v0; // com.sec.chaton.a.ah.d:java.lang.Object
        // goto L_0000
    }

    public com.sec.chaton.a.ah a(com.sec.chaton.a.ag p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.ag)
        _result = this.a(); // com.sec.chaton.a.ag.a -> com.sec.chaton.a.ag
        v0 = _result;
        if (v2 != v0) /* goto L_0007 */;
        return v1;
        _result = v2.c(); // com.sec.chaton.a.ag.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v2.d(); // com.sec.chaton.a.ag.d -> com.sec.chaton.a.aj
        v0 = _result;
        _result = v1.a(v0); // com.sec.chaton.a.ah.a -> com.sec.chaton.a.ah
        _result = v2.e(); // com.sec.chaton.a.ag.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v2.f(); // com.sec.chaton.a.ag.f -> java.lang.String
        v0 = _result;
        _result = v1.a(v0); // com.sec.chaton.a.ah.a -> com.sec.chaton.a.ah
        _result = v2.g(); // com.sec.chaton.a.ag.g -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0006 */;
        _result = v2.h(); // com.sec.chaton.a.ag.h -> java.lang.String
        v0 = _result;
        _result = v1.b(v0); // com.sec.chaton.a.ah.b -> com.sec.chaton.a.ah
        // goto L_0006
    }

    public com.sec.chaton.a.ah a(com.sec.chaton.a.aj p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.aj)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ah.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.chaton.a.ah.a:int
        v1.b = v2; // com.sec.chaton.a.ah.b:com.sec.chaton.a.aj
        return v1;
    }

    public com.sec.chaton.a.ah a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ah.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.chaton.a.ah.a:int
        v1.c = v2; // com.sec.chaton.a.ah.c:java.lang.Object
        return v1;
    }

    public com.sec.chaton.a.ah b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.chaton.a.ah.h -> com.sec.chaton.a.ah
        v0 = _result;
        _result = v2.e(); // com.sec.chaton.a.ah.e -> com.sec.chaton.a.ag
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.ah.a -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ah b(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ah.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.chaton.a.ah.a:int
        v1.d = v2; // com.sec.chaton.a.ah.d:java.lang.Object
        return v1;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.chaton.a.ah.d -> com.sec.chaton.a.ag
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.chaton.a.ah.e -> com.sec.chaton.a.ag
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ag c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.chaton.a.ag.a -> com.sec.chaton.a.ag
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.ah.a -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.ah.a -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ah.b -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ah.b -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ah.b -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ah.b -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ag d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.chaton.a.ah.e -> com.sec.chaton.a.ag
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.chaton.a.ag.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.chaton.a.ah.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.chaton.a.ag e() {
        // Registers (6 total): v5 = this
        v0 = 1;
        v2 = new com.sec.chaton.a.ag;
        v1 = 0;
        _result = v2.<init>(v5, v1); // com.sec.chaton.a.ag.<init> -> void
        v3 = v5.a; // com.sec.chaton.a.ah.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_002f */;
        v1 = v5.b; // com.sec.chaton.a.ah.b:com.sec.chaton.a.aj
        _result = v2.a(v1); // com.sec.chaton.a.ag.a -> com.sec.chaton.a.aj
        v1 = binOpLit8_0xdd(v3, 2);
        v4 = 2;
        if (v1 != v4) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v5.c; // com.sec.chaton.a.ah.c:java.lang.Object
        _result = v2.a(v1); // com.sec.chaton.a.ag.a -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 4);
        v3 = 4;
        if (v1 != v3) /* goto L_0026 */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = v5.d; // com.sec.chaton.a.ah.d:java.lang.Object
        _result = v2.b(v1); // com.sec.chaton.a.ag.b -> java.lang.Object
        _result = v2.a(v0); // com.sec.chaton.a.ag.a -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.ah.c -> com.sec.chaton.a.ag
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.ah.c -> com.sec.chaton.a.ag
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.ah.a -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.chaton.a.ag) v2;
        _result = v1.a(v2); // com.sec.chaton.a.ah.a -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.ah.a -> com.sec.chaton.a.ah
        v0 = _result;
        return v0;
    }

}