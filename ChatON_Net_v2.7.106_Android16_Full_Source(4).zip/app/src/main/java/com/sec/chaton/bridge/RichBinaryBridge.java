package com.sec.chaton.bridge;

import android.content.Context;
import com.sec.chaton.a.a.d;
import com.sec.chaton.d.a.a;
import com.sec.chaton.i.aa;
import com.sec.chaton.i.ae;

/**
 * ============================================================================
 * RichBinaryBridge — Unified Contract for ChatON-Net Local Engine (ChatON v2.7.106)
 * ============================================================================
 * Connects ChatON v2.7.106's classic skeuomorphic UI (dual-side 3D profile
 * avatars, 3D orange header, cubic Trunk, and in-bubble bilingual translation)
 * to ChatON-Net Local Engine (PC5 / ProSe offline radio & r-RSS crawler):
 *   - ChatON Chats       <--> ChatON Messaging (com.sec.chaton.i.aa / ae)
 *   - ChatON Buddies     <--> ChatON Buddy Groups  (com.sec.chaton.e.al)
 *   - ChatON Trunk       <--> ChatON Trunk Media (com.sec.chaton.trunk.database.a.b)
 *   - @web@r-rss Channel <--> ChatON r-RSS Decentralized Web Crawler
 */
public interface RichBinaryBridge {

    void initialize(Context context);

    /** Intercepts Netty TCP Protobuf envelopes in com.sec.chaton.i.v (TcpClient). */
    void dispatchTcpEnvelope(aa tcpContext, ae requestEnvelope);

    /** Intercepts HTTP REST tasks in com.sec.chaton.d.a.a (AbstractHttpTask2). */
    d dispatchHttpRequest(a httpTask);

    /** Sends a Hangout message and triggers the 1-second Live Echo reply in Mock mode. */
    long sendHangoutMessage(
            Context context,
            String inboxNo,
            String sessionId,
            int chatType,
            int contentType,
            String messageText,
            String[] receivers,
            long clientMsgId
    );

    void syncCirclesAndPresence(Context context);

    void syncTrunkLeftovers(Context context, String sessionId);
}
