package com.sec.chaton;

/**
 * Original SourceFile: SelectCountry.java
 * Descriptor: Lcom/sec/chaton/SelectCountry$RegisteFragment;
 */
public class SelectCountry$RegisteFragment extends android.support.v4.app.Fragment {
    final int a;
    final int b;
    private java.util.Map c;
    private java.lang.CharSequence[] d;
    private java.lang.CharSequence[] e;
    private java.lang.String f;
    private com.sec.chaton.b.b g;
    private android.content.Context h;

    public SelectCountry$RegisteFragment() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // android.support.v4.app.Fragment.<init> -> void
        v0 = 16;
        v1.a = v0; // com.sec.chaton.SelectCountry$RegisteFragment.a:int
        v0 = 0;
        v1.b = v0; // com.sec.chaton.SelectCountry$RegisteFragment.b:int
        v0 = 0;
        v1.g = v0; // com.sec.chaton.SelectCountry$RegisteFragment.g:com.sec.chaton.b.b
        return;
    }

    public void onActivityResult(int p0, int p1, android.content.Intent p2) {
        // Registers (8 total): v4 = this, v5 = p0 (int), v6 = p1 (int), v7 = p2 (android.content.Intent)
        v3 = -1;
        // switch(v5)
        return;
        if (v6 != v3) /* goto L_0076 */;
        _result = v7.getExtras(); // android.content.Intent.getExtras -> android.os.Bundle
        v0 = _result;
        v1 = "PARAMS_COUNTRY_NAME";
        _result = v0.getString(v1); // android.os.Bundle.getString -> java.lang.String
        v0 = _result;
        v4.f = v0; // com.sec.chaton.SelectCountry$RegisteFragment.f:java.lang.String
        v0 = v4.f; // com.sec.chaton.SelectCountry$RegisteFragment.f:java.lang.String
        if (v0 == 0) /* goto L_0068 */;
        v0 = v4.c; // com.sec.chaton.SelectCountry$RegisteFragment.c:java.util.Map
        v1 = v4.f; // com.sec.chaton.SelectCountry$RegisteFragment.f:java.lang.String
        _result = java.util.Map.get(v0, v1); // -> java.lang.Object
        v0 = _result;
        _result = v0.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v0 = _result;
        v1 = "country_letter";
        v2 = v4.f; // com.sec.chaton.SelectCountry$RegisteFragment.f:java.lang.String
        _result = v1.a(v2); // com.sec.chaton.util.r.a -> void
        v1 = "country_name";
        _result = v1.a(v0); // com.sec.chaton.util.r.a -> void
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "[ACS] mCountryLetter: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.f; // com.sec.chaton.SelectCountry$RegisteFragment.f:java.lang.String
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " selectedCountryName: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v4.getActivity(); // com.sec.chaton.SelectCountry$RegisteFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.setResult(v3); // android.support.v4.app.FragmentActivity.setResult -> void
        _result = v4.getActivity(); // com.sec.chaton.SelectCountry$RegisteFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.finish(); // android.support.v4.app.FragmentActivity.finish -> void
        // goto L_0004
        v0 = "selectedCountryName is null";
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        // goto L_0060
        if (v6 != 0) /* goto L_0089 */;
        _result = v4.getActivity(); // com.sec.chaton.SelectCountry$RegisteFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        v1 = 0;
        _result = v0.setResult(v1); // android.support.v4.app.FragmentActivity.setResult -> void
        _result = v4.getActivity(); // com.sec.chaton.SelectCountry$RegisteFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.finish(); // android.support.v4.app.FragmentActivity.finish -> void
        // goto L_0004
        _result = v4.getActivity(); // com.sec.chaton.SelectCountry$RegisteFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.finish(); // android.support.v4.app.FragmentActivity.finish -> void
        // goto L_0004
    }

    public void onCreate(android.os.Bundle p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.os.Bundle)
        v1 = 0;
        _result = v5.onCreate(v6); // android.support.v4.app.Fragment.onCreate -> void
        _result = v5.getActivity(); // com.sec.chaton.SelectCountry$RegisteFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        v5.h = v0; // com.sec.chaton.SelectCountry$RegisteFragment.h:android.content.Context
        v0 = "onCreate..............";
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v2.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v2 = _result;
        _result = v0.b(v2); // com.sec.chaton.util.p.b -> void
        v0 = new com.sec.chaton.widget.e;
        _result = v5.getActivity(); // com.sec.chaton.SelectCountry$RegisteFragment.getActivity -> android.support.v4.app.FragmentActivity
        v2 = _result;
        _result = v0.<init>(v2); // com.sec.chaton.widget.e.<init> -> void
        v5.g = v0; // com.sec.chaton.SelectCountry$RegisteFragment.g:com.sec.chaton.b.b
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        v5.c = v0; // com.sec.chaton.SelectCountry$RegisteFragment.c:java.util.Map
        _result = v5.getResources(); // com.sec.chaton.SelectCountry$RegisteFragment.getResources -> android.content.res.Resources
        v0 = _result;
        v2 = 0x7f070000; /* @array/country */
        _result = v0.getTextArray(v2); // android.content.res.Resources.getTextArray -> java.lang.CharSequence[]
        v0 = _result;
        v5.d = v0; // com.sec.chaton.SelectCountry$RegisteFragment.d:java.lang.CharSequence[]
        _result = v5.getResources(); // com.sec.chaton.SelectCountry$RegisteFragment.getResources -> android.content.res.Resources
        v0 = _result;
        v2 = com.sec.chaton.R.array.ISO_country_code_Letter2; // 0x7f070002
        _result = v0.getTextArray(v2); // android.content.res.Resources.getTextArray -> java.lang.CharSequence[]
        v0 = _result;
        v5.e = v0; // com.sec.chaton.SelectCountry$RegisteFragment.e:java.lang.CharSequence[]
        v0 = v1;
        v2 = v5.d; // com.sec.chaton.SelectCountry$RegisteFragment.d:java.lang.CharSequence[]
        v2 = v2.length;
        if (v0 >= v2) /* goto L_0058 */;
        v2 = v5.c; // com.sec.chaton.SelectCountry$RegisteFragment.c:java.util.Map
        v3 = v5.e; // com.sec.chaton.SelectCountry$RegisteFragment.e:java.lang.CharSequence[]
        v3 = v3[v0];
        v4 = v5.d; // com.sec.chaton.SelectCountry$RegisteFragment.d:java.lang.CharSequence[]
        v4 = v4[v0];
        _result = java.util.Map.put(v2, v3, v4); // -> java.lang.Object
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0043
        v0 = new android.content.Intent;
        _result = v5.getActivity(); // com.sec.chaton.SelectCountry$RegisteFragment.getActivity -> android.support.v4.app.FragmentActivity
        v2 = _result;
        v3 = com.sec.chaton.registration.CountryActivity.class;
        _result = v0.<init>(v2, v3); // android.content.Intent.<init> -> void
        v2 = "mode";
        _result = v0.putExtra(v2, v1); // android.content.Intent.putExtra -> android.content.Intent
        v1 = 0x04000000;
        _result = v0.setFlags(v1); // android.content.Intent.setFlags -> android.content.Intent
        v1 = 16;
        _result = v5.startActivityForResult(v0, v1); // com.sec.chaton.SelectCountry$RegisteFragment.startActivityForResult -> void
        return;
    }

}