package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/am;
 */
public final class am extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.chaton.a.an {
    private int a;
    private long b;
    private java.lang.Object c;
    private com.sec.chaton.a.ds d;
    private long e;
    private com.sec.chaton.a.dd f;

    private am() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = "";
        v1.c = v0; // com.sec.chaton.a.am.c:java.lang.Object
        _result = this.a(); // com.sec.chaton.a.ds.a -> com.sec.chaton.a.ds
        v0 = _result;
        v1.d = v0; // com.sec.chaton.a.am.d:com.sec.chaton.a.ds
        _result = this.a(); // com.sec.chaton.a.dd.a -> com.sec.chaton.a.dd
        v0 = _result;
        v1.f = v0; // com.sec.chaton.a.am.f:com.sec.chaton.a.dd
        _result = v1.k(); // com.sec.chaton.a.am.k -> void
        return;
    }

    static com.sec.chaton.a.al a(com.sec.chaton.a.am p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.am)
        _result = v1.m(); // com.sec.chaton.a.am.m -> com.sec.chaton.a.al
        v0 = _result;
        return v0;
    }

    static com.sec.chaton.a.am j() {
        _result = this.l(); // com.sec.chaton.a.am.l -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    private void k() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.chaton.a.am l() {
        v0 = new com.sec.chaton.a.am;
        _result = v0.<init>(); // com.sec.chaton.a.am.<init> -> void
        return v0;
    }

    private com.sec.chaton.a.al m() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.chaton.a.am.e -> com.sec.chaton.a.al
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.chaton.a.al.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.chaton.a.am.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.chaton.a.am a() {
        // Registers (4 total): v3 = this
        v1 = 0L;
        _result = v3.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v3.b = v1; // com.sec.chaton.a.am.b:long
        v0 = v3.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v3.a = v0; // com.sec.chaton.a.am.a:int
        v0 = "";
        v3.c = v0; // com.sec.chaton.a.am.c:java.lang.Object
        v0 = v3.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v3.a = v0; // com.sec.chaton.a.am.a:int
        _result = this.a(); // com.sec.chaton.a.ds.a -> com.sec.chaton.a.ds
        v0 = _result;
        v3.d = v0; // com.sec.chaton.a.am.d:com.sec.chaton.a.ds
        v0 = v3.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v3.a = v0; // com.sec.chaton.a.am.a:int
        v3.e = v1; // com.sec.chaton.a.am.e:long
        v0 = v3.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xdd(v0, -9);
        v3.a = v0; // com.sec.chaton.a.am.a:int
        _result = this.a(); // com.sec.chaton.a.dd.a -> com.sec.chaton.a.dd
        v0 = _result;
        v3.f = v0; // com.sec.chaton.a.am.f:com.sec.chaton.a.dd
        v0 = v3.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xdd(v0, -17);
        v3.a = v0; // com.sec.chaton.a.am.a:int
        return v3;
    }

    public com.sec.chaton.a.am a(long p0) {
        // Registers (4 total): v1 = this, v2 = p0 (long)
        v0 = v1.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.chaton.a.am.a:int
        v1.b = v2; // com.sec.chaton.a.am.b:long
        return v1;
    }

    public com.sec.chaton.a.am a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.CodedInputStream), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v2.parseUnknownField(v3, v4, v0); // com.sec.chaton.a.am.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v2;
        v0 = v2.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v2.a = v0; // com.sec.chaton.a.am.a:int
        _result = v3.readInt64(); // com.google.protobuf.CodedInputStream.readInt64 -> long
        v0 = _result;
        v2.b = v0; // com.sec.chaton.a.am.b:long
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v2.a = v0; // com.sec.chaton.a.am.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.c = v0; // com.sec.chaton.a.am.c:java.lang.Object
        // goto L_0000
        _result = this.newBuilder(); // com.sec.chaton.a.ds.newBuilder -> com.sec.chaton.a.dt
        v0 = _result;
        _result = v2.f(); // com.sec.chaton.a.am.f -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0039 */;
        _result = v2.g(); // com.sec.chaton.a.am.g -> com.sec.chaton.a.ds
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.dt.a -> com.sec.chaton.a.dt
        _result = v3.readMessage(v0, v4); // com.google.protobuf.CodedInputStream.readMessage -> void
        _result = v0.e(); // com.sec.chaton.a.dt.e -> com.sec.chaton.a.ds
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.am.a -> com.sec.chaton.a.am
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v2.a = v0; // com.sec.chaton.a.am.a:int
        _result = v3.readInt64(); // com.google.protobuf.CodedInputStream.readInt64 -> long
        v0 = _result;
        v2.e = v0; // com.sec.chaton.a.am.e:long
        // goto L_0000
        _result = this.newBuilder(); // com.sec.chaton.a.dd.newBuilder -> com.sec.chaton.a.de
        v0 = _result;
        _result = v2.h(); // com.sec.chaton.a.am.h -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0062 */;
        _result = v2.i(); // com.sec.chaton.a.am.i -> com.sec.chaton.a.dd
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.de.a -> com.sec.chaton.a.de
        _result = v3.readMessage(v0, v4); // com.google.protobuf.CodedInputStream.readMessage -> void
        _result = v0.e(); // com.sec.chaton.a.de.e -> com.sec.chaton.a.dd
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.am.a -> com.sec.chaton.a.am
        // goto L_0000
    }

    public com.sec.chaton.a.am a(com.sec.chaton.a.al p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.chaton.a.al)
        _result = this.a(); // com.sec.chaton.a.al.a -> com.sec.chaton.a.al
        v0 = _result;
        if (v3 != v0) /* goto L_0007 */;
        return v2;
        _result = v3.c(); // com.sec.chaton.a.al.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v3.d(); // com.sec.chaton.a.al.d -> long
        v0 = _result;
        _result = v2.a(v0, v1); // com.sec.chaton.a.am.a -> com.sec.chaton.a.am
        _result = v3.e(); // com.sec.chaton.a.al.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v3.f(); // com.sec.chaton.a.al.f -> java.lang.String
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.am.a -> com.sec.chaton.a.am
        _result = v3.g(); // com.sec.chaton.a.al.g -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002e */;
        _result = v3.h(); // com.sec.chaton.a.al.h -> com.sec.chaton.a.ds
        v0 = _result;
        _result = v2.b(v0); // com.sec.chaton.a.am.b -> com.sec.chaton.a.am
        _result = v3.i(); // com.sec.chaton.a.al.i -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003b */;
        _result = v3.j(); // com.sec.chaton.a.al.j -> long
        v0 = _result;
        _result = v2.b(v0, v1); // com.sec.chaton.a.am.b -> com.sec.chaton.a.am
        _result = v3.k(); // com.sec.chaton.a.al.k -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0006 */;
        _result = v3.l(); // com.sec.chaton.a.al.l -> com.sec.chaton.a.dd
        v0 = _result;
        _result = v2.b(v0); // com.sec.chaton.a.am.b -> com.sec.chaton.a.am
        // goto L_0006
    }

    public com.sec.chaton.a.am a(com.sec.chaton.a.dd p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.dd)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v1.f = v2; // com.sec.chaton.a.am.f:com.sec.chaton.a.dd
        v0 = v1.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xde(v0, 16);
        v1.a = v0; // com.sec.chaton.a.am.a:int
        return v1;
    }

    public com.sec.chaton.a.am a(com.sec.chaton.a.ds p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.ds)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v1.d = v2; // com.sec.chaton.a.am.d:com.sec.chaton.a.ds
        v0 = v1.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.chaton.a.am.a:int
        return v1;
    }

    public com.sec.chaton.a.am a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.chaton.a.am.a:int
        v1.c = v2; // com.sec.chaton.a.am.c:java.lang.Object
        return v1;
    }

    public com.sec.chaton.a.am b() {
        // Registers (3 total): v2 = this
        _result = this.l(); // com.sec.chaton.a.am.l -> com.sec.chaton.a.am
        v0 = _result;
        _result = v2.e(); // com.sec.chaton.a.am.e -> com.sec.chaton.a.al
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.am.a -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.am b(long p0) {
        // Registers (4 total): v1 = this, v2 = p0 (long)
        v0 = v1.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v1.a = v0; // com.sec.chaton.a.am.a:int
        v1.e = v2; // com.sec.chaton.a.am.e:long
        return v1;
    }

    public com.sec.chaton.a.am b(com.sec.chaton.a.dd p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.chaton.a.dd)
        v0 = v2.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_0027 */;
        v0 = v2.f; // com.sec.chaton.a.am.f:com.sec.chaton.a.dd
        _result = this.a(); // com.sec.chaton.a.dd.a -> com.sec.chaton.a.dd
        v1 = _result;
        if (v0 == v1) /* goto L_0027 */;
        v0 = v2.f; // com.sec.chaton.a.am.f:com.sec.chaton.a.dd
        _result = v0.a(); // com.sec.chaton.a.dd.a -> com.sec.chaton.a.de
        v0 = _result;
        _result = v0.a(v3); // com.sec.chaton.a.de.a -> com.sec.chaton.a.de
        v0 = _result;
        _result = v0.e(); // com.sec.chaton.a.de.e -> com.sec.chaton.a.dd
        v0 = _result;
        v2.f = v0; // com.sec.chaton.a.am.f:com.sec.chaton.a.dd
        v0 = v2.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xde(v0, 16);
        v2.a = v0; // com.sec.chaton.a.am.a:int
        return v2;
        v2.f = v3; // com.sec.chaton.a.am.f:com.sec.chaton.a.dd
        // goto L_0020
    }

    public com.sec.chaton.a.am b(com.sec.chaton.a.ds p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.chaton.a.ds)
        v0 = v2.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0026 */;
        v0 = v2.d; // com.sec.chaton.a.am.d:com.sec.chaton.a.ds
        _result = this.a(); // com.sec.chaton.a.ds.a -> com.sec.chaton.a.ds
        v1 = _result;
        if (v0 == v1) /* goto L_0026 */;
        v0 = v2.d; // com.sec.chaton.a.am.d:com.sec.chaton.a.ds
        _result = v0.a(); // com.sec.chaton.a.ds.a -> com.sec.chaton.a.dt
        v0 = _result;
        _result = v0.a(v3); // com.sec.chaton.a.dt.a -> com.sec.chaton.a.dt
        v0 = _result;
        _result = v0.e(); // com.sec.chaton.a.dt.e -> com.sec.chaton.a.ds
        v0 = _result;
        v2.d = v0; // com.sec.chaton.a.am.d:com.sec.chaton.a.ds
        v0 = v2.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v2.a = v0; // com.sec.chaton.a.am.a:int
        return v2;
        v2.d = v3; // com.sec.chaton.a.am.d:com.sec.chaton.a.ds
        // goto L_001f
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.chaton.a.am.d -> com.sec.chaton.a.al
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.chaton.a.am.e -> com.sec.chaton.a.al
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.al c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.chaton.a.al.a -> com.sec.chaton.a.al
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.am.a -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.am.a -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.am.b -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.am.b -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.am.b -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.am.b -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.al d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.chaton.a.am.e -> com.sec.chaton.a.al
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.chaton.a.al.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.chaton.a.am.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.chaton.a.al e() {
        // Registers (7 total): v6 = this
        v0 = 1;
        v2 = new com.sec.chaton.a.al;
        v1 = 0;
        _result = v2.<init>(v6, v1); // com.sec.chaton.a.al.<init> -> void
        v3 = v6.a; // com.sec.chaton.a.am.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_0049 */;
        v4 = v6.b; // com.sec.chaton.a.am.b:long
        _result = v2.a(v4, v5); // com.sec.chaton.a.al.a -> long
        v1 = binOpLit8_0xdd(v3, 2);
        v4 = 2;
        if (v1 != v4) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v6.c; // com.sec.chaton.a.am.c:java.lang.Object
        _result = v2.a(v1); // com.sec.chaton.a.al.a -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 4);
        v4 = 4;
        if (v1 != v4) /* goto L_0026 */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = v6.d; // com.sec.chaton.a.am.d:com.sec.chaton.a.ds
        _result = v2.a(v1); // com.sec.chaton.a.al.a -> com.sec.chaton.a.ds
        v1 = binOpLit8_0xdd(v3, 8);
        v4 = 8;
        if (v1 != v4) /* goto L_0033 */;
        v0 = binOpLit8_0xde(v0, 8);
        v4 = v6.e; // com.sec.chaton.a.am.e:long
        _result = v2.b(v4, v5); // com.sec.chaton.a.al.b -> long
        v1 = binOpLit8_0xdd(v3, 16);
        v3 = 16;
        if (v1 != v3) /* goto L_0040 */;
        v0 = binOpLit8_0xde(v0, 16);
        v1 = v6.f; // com.sec.chaton.a.am.f:com.sec.chaton.a.dd
        _result = v2.a(v1); // com.sec.chaton.a.al.a -> com.sec.chaton.a.dd
        _result = v2.a(v0); // com.sec.chaton.a.al.a -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public boolean f() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.sec.chaton.a.ds g() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.sec.chaton.a.am.d:com.sec.chaton.a.ds
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.am.c -> com.sec.chaton.a.al
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.am.c -> com.sec.chaton.a.al
        v0 = _result;
        return v0;
    }

    public boolean h() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // com.sec.chaton.a.am.a:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public com.sec.chaton.a.dd i() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // com.sec.chaton.a.am.f:com.sec.chaton.a.dd
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.am.a -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.chaton.a.al) v2;
        _result = v1.a(v2); // com.sec.chaton.a.am.a -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.am.a -> com.sec.chaton.a.am
        v0 = _result;
        return v0;
    }

}