package com.sec.chaton.bridge;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.Log;
import androidx.core.content.ContextCompat;
import com.sec.chaton.push.PushClientService;
import java.util.Locale;

/**
 * ============================================================================
 * Android 16 (API 36 - Baklava) Runtime & Manifest Compatibility Layer
 * ============================================================================
 * Built for Samsung ChatON v2.7.106 (TouchWiz Nature UX Skeuomorphic Edition):
 *   1. Enforces ContextCompat.RECEIVER_NOT_EXPORTED on all dynamic BroadcastReceivers.
 *   2. Converts implicit startService intents (e.g. PUSH_CLIENT_SERVICE_ACTION)
 *      into explicit component intents & catches background start exceptions.
 *   3. Provides standard TelephonyManager / Locale ISO resolution without
 *      blacklisted CountryDetector or privileged IMEI/IMSI calls.
 */
public final class Android16Compat {
    private static final String TAG = "ChatON27_A16Compat";

    private Android16Compat() {}

    public static Intent registerReceiverSafe(Context context, BroadcastReceiver receiver, IntentFilter filter) {
        if (context == null || receiver == null || filter == null) {
            return null;
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                return ContextCompat.registerReceiver(
                        context,
                        receiver,
                        filter,
                        ContextCompat.RECEIVER_NOT_EXPORTED
                );
            } else {
                return context.registerReceiver(receiver, filter);
            }
        } catch (SecurityException | IllegalArgumentException e) {
            Log.w(TAG, "Suppressed registerReceiver exception on API " + Build.VERSION.SDK_INT + ": " + e.getMessage());
            return null;
        }
    }

    public static ComponentName startServiceSafe(Context context, Intent intent) {
        if (context == null || intent == null) {
            return null;
        }
        try {
            if (intent.getComponent() == null && intent.getPackage() == null) {
                String action = intent.getAction();
                if ("com.sec.chaton.push.PUSH_CLIENT_SERVICE_ACTION".equals(action)) {
                    intent.setClass(context, PushClientService.class);
                } else {
                    intent.setPackage(context.getPackageName());
                }
            }
            return context.startService(intent);
        } catch (IllegalStateException | SecurityException | IllegalArgumentException e) {
            Log.w(TAG, "Intercepted startService on API " + Build.VERSION.SDK_INT + " (" + intent + "): " + e.getMessage());
            return null;
        }
    }

    public static String resolveCountryIso(Context context) {
        try {
            if (context != null) {
                TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                if (tm != null) {
                    String netIso = tm.getNetworkCountryIso();
                    if (netIso != null && !netIso.isEmpty()) {
                        return netIso.toUpperCase(Locale.US);
                    }
                    String simIso = tm.getSimCountryIso();
                    if (simIso != null && !simIso.isEmpty()) {
                        return simIso.toUpperCase(Locale.US);
                    }
                }
            }
        } catch (Exception ignored) {}
        String fallback = Locale.getDefault().getCountry();
        return (fallback != null && !fallback.isEmpty()) ? fallback.toUpperCase(Locale.US) : "IR";
    }
}
