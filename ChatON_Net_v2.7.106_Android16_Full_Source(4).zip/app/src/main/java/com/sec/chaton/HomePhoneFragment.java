package com.sec.chaton;

/**
 * Original SourceFile: HomePhoneFragment.java
 * Descriptor: Lcom/sec/chaton/HomePhoneFragment;
 */
public class HomePhoneFragment extends android.support.v4.app.Fragment {
    public HomePhoneFragment() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.app.Fragment.<init> -> void
        return;
    }

    public void onCreate(android.os.Bundle p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.Bundle)
        _result = v0.onCreate(v1); // android.support.v4.app.Fragment.onCreate -> void
        return;
    }

    public android.view.View onCreateView(android.view.LayoutInflater p0, android.view.ViewGroup p1, android.os.Bundle p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.LayoutInflater), v4 = p1 (android.view.ViewGroup), v5 = p2 (android.os.Bundle)
        v0 = com.sec.chaton.R.layout.activity_home_phone; // 0x7f030005
        v1 = 0;
        _result = v3.inflate(v0, v4, v1); // android.view.LayoutInflater.inflate -> android.view.View
        v0 = _result;
        return v0;
    }

}