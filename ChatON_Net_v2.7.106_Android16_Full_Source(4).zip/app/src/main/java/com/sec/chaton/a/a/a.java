package com.sec.chaton.a.a;

/**
 * Original SourceFile: BuddyEntry.java
 * Descriptor: Lcom/sec/chaton/a/a/a;
 */
public class a {
    private java.lang.String a;
    private java.lang.String b;
    private java.lang.String c;

    public a(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.a = v3; // com.sec.chaton.a.a.a.a:java.lang.String
        _result = this.c(); // com.sec.chaton.global.GlobalApplication.c -> android.content.res.Resources
        v0 = _result;
        v1 = com.sec.chaton.R.string.unknown; // 0x7f0c012d
        _result = v0.getString(v1); // android.content.res.Resources.getString -> java.lang.String
        v0 = _result;
        v2.b = v0; // com.sec.chaton.a.a.a.b:java.lang.String
        return;
    }

    public a(java.lang.String p0, java.lang.String p1, java.lang.String p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (java.lang.String), v3 = p2 (java.lang.String)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // com.sec.chaton.a.a.a.a:java.lang.String
        v0.b = v2; // com.sec.chaton.a.a.a.b:java.lang.String
        v0.c = v3; // com.sec.chaton.a.a.a.c:java.lang.String
        return;
    }

    public java.lang.String a() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // com.sec.chaton.a.a.a.b:java.lang.String
        return v0;
    }

    public void a(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.b = v1; // com.sec.chaton.a.a.a.b:java.lang.String
        return;
    }

    public void b(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.c = v1; // com.sec.chaton.a.a.a.c:java.lang.String
        return;
    }

}