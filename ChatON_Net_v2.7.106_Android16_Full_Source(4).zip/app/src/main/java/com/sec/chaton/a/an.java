package com.sec.chaton.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/chaton/a/an;
 */
public interface an extends com.google.protobuf.MessageLiteOrBuilder {
}