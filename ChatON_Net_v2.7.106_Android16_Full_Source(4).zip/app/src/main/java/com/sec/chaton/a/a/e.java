package com.sec.chaton.a.a;

/**
 * Original SourceFile: ImageRequestResult.java
 * Descriptor: Lcom/sec/chaton/a/a/e;
 */
public class e {
     android.graphics.Bitmap a;
     com.sec.chaton.util.am b;

    public e(android.graphics.Bitmap p0, com.sec.chaton.util.am p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.graphics.Bitmap), v2 = p1 (com.sec.chaton.util.am)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // com.sec.chaton.a.a.e.a:android.graphics.Bitmap
        v0.b = v2; // com.sec.chaton.a.a.e.b:com.sec.chaton.util.am
        return;
    }

    public android.graphics.Bitmap a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // com.sec.chaton.a.a.e.a:android.graphics.Bitmap
        return v0;
    }

    public void a(android.graphics.Bitmap p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.graphics.Bitmap)
        v0.a = v1; // com.sec.chaton.a.a.e.a:android.graphics.Bitmap
        return;
    }

    public com.sec.chaton.util.am b() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // com.sec.chaton.a.a.e.b:com.sec.chaton.util.am
        return v0;
    }

}