package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/ab;
 */
public final class ab extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.chaton.a.ac {
    private int a;
    private long b;
    private java.lang.Object c;
    private java.lang.Object d;
    private java.util.List e;

    private ab() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = "";
        v1.c = v0; // com.sec.chaton.a.ab.c:java.lang.Object
        v0 = "";
        v1.d = v0; // com.sec.chaton.a.ab.d:java.lang.Object
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        v1.e = v0; // com.sec.chaton.a.ab.e:java.util.List
        _result = v1.g(); // com.sec.chaton.a.ab.g -> void
        return;
    }

    static com.sec.chaton.a.aa a(com.sec.chaton.a.ab p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.ab)
        _result = v1.i(); // com.sec.chaton.a.ab.i -> com.sec.chaton.a.aa
        v0 = _result;
        return v0;
    }

    static com.sec.chaton.a.ab f() {
        _result = this.h(); // com.sec.chaton.a.ab.h -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.chaton.a.ab h() {
        v0 = new com.sec.chaton.a.ab;
        _result = v0.<init>(); // com.sec.chaton.a.ab.<init> -> void
        return v0;
    }

    private com.sec.chaton.a.aa i() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.chaton.a.ab.e -> com.sec.chaton.a.aa
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.chaton.a.aa.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.chaton.a.ab.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    private void j() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 == v1) /* goto L_0017 */;
        v0 = new java.util.ArrayList;
        v1 = v2.e; // com.sec.chaton.a.ab.e:java.util.List
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v2.e = v0; // com.sec.chaton.a.ab.e:java.util.List
        v0 = v2.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v2.a = v0; // com.sec.chaton.a.ab.a:int
        return;
    }

    public com.sec.chaton.a.ab a() {
        // Registers (3 total): v2 = this
        _result = v2.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = 0L;
        v2.b = v0; // com.sec.chaton.a.ab.b:long
        v0 = v2.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v2.a = v0; // com.sec.chaton.a.ab.a:int
        v0 = "";
        v2.c = v0; // com.sec.chaton.a.ab.c:java.lang.Object
        v0 = v2.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v2.a = v0; // com.sec.chaton.a.ab.a:int
        v0 = "";
        v2.d = v0; // com.sec.chaton.a.ab.d:java.lang.Object
        v0 = v2.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v2.a = v0; // com.sec.chaton.a.ab.a:int
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        v2.e = v0; // com.sec.chaton.a.ab.e:java.util.List
        v0 = v2.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xdd(v0, -9);
        v2.a = v0; // com.sec.chaton.a.ab.a:int
        return v2;
    }

    public com.sec.chaton.a.ab a(long p0) {
        // Registers (4 total): v1 = this, v2 = p0 (long)
        v0 = v1.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.chaton.a.ab.a:int
        v1.b = v2; // com.sec.chaton.a.ab.b:long
        return v1;
    }

    public com.sec.chaton.a.ab a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.CodedInputStream), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v2.parseUnknownField(v3, v4, v0); // com.sec.chaton.a.ab.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v2;
        v0 = v2.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v2.a = v0; // com.sec.chaton.a.ab.a:int
        _result = v3.readInt64(); // com.google.protobuf.CodedInputStream.readInt64 -> long
        v0 = _result;
        v2.b = v0; // com.sec.chaton.a.ab.b:long
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v2.a = v0; // com.sec.chaton.a.ab.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.c = v0; // com.sec.chaton.a.ab.c:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v2.a = v0; // com.sec.chaton.a.ab.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.d = v0; // com.sec.chaton.a.ab.d:java.lang.Object
        // goto L_0000
        _result = this.newBuilder(); // com.sec.chaton.a.ad.newBuilder -> com.sec.chaton.a.ae
        v0 = _result;
        _result = v3.readMessage(v0, v4); // com.google.protobuf.CodedInputStream.readMessage -> void
        _result = v0.e(); // com.sec.chaton.a.ae.e -> com.sec.chaton.a.ad
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.ab.a -> com.sec.chaton.a.ab
        // goto L_0000
    }

    public com.sec.chaton.a.ab a(com.sec.chaton.a.aa p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.chaton.a.aa)
        _result = this.a(); // com.sec.chaton.a.aa.a -> com.sec.chaton.a.aa
        v0 = _result;
        if (v3 != v0) /* goto L_0007 */;
        return v2;
        _result = v3.c(); // com.sec.chaton.a.aa.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v3.d(); // com.sec.chaton.a.aa.d -> long
        v0 = _result;
        _result = v2.a(v0, v1); // com.sec.chaton.a.ab.a -> com.sec.chaton.a.ab
        _result = v3.e(); // com.sec.chaton.a.aa.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v3.f(); // com.sec.chaton.a.aa.f -> java.lang.String
        v0 = _result;
        _result = v2.a(v0); // com.sec.chaton.a.ab.a -> com.sec.chaton.a.ab
        _result = v3.g(); // com.sec.chaton.a.aa.g -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002e */;
        _result = v3.h(); // com.sec.chaton.a.aa.h -> java.lang.String
        v0 = _result;
        _result = v2.b(v0); // com.sec.chaton.a.ab.b -> com.sec.chaton.a.ab
        _result = v3.b(); // com.sec.chaton.a.aa.b -> java.util.List
        v0 = _result;
        _result = java.util.List.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0006 */;
        v0 = v2.e; // com.sec.chaton.a.ab.e:java.util.List
        _result = java.util.List.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_004d */;
        _result = v3.b(); // com.sec.chaton.a.aa.b -> java.util.List
        v0 = _result;
        v2.e = v0; // com.sec.chaton.a.ab.e:java.util.List
        v0 = v2.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xdd(v0, -9);
        v2.a = v0; // com.sec.chaton.a.ab.a:int
        // goto L_0006
        _result = v2.j(); // com.sec.chaton.a.ab.j -> void
        v0 = v2.e; // com.sec.chaton.a.ab.e:java.util.List
        _result = v3.b(); // com.sec.chaton.a.aa.b -> java.util.List
        v1 = _result;
        _result = java.util.List.addAll(v0, v1); // -> boolean
        // goto L_0006
    }

    public com.sec.chaton.a.ab a(com.sec.chaton.a.ad p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.ad)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        _result = v1.j(); // com.sec.chaton.a.ab.j -> void
        v0 = v1.e; // com.sec.chaton.a.ab.e:java.util.List
        _result = java.util.List.add(v0, v2); // -> boolean
        return v1;
    }

    public com.sec.chaton.a.ab a(java.lang.Iterable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Iterable)
        _result = v1.j(); // com.sec.chaton.a.ab.j -> void
        v0 = v1.e; // com.sec.chaton.a.ab.e:java.util.List
        _result = v2.addAll(v0); // com.google.protobuf.GeneratedMessageLite$Builder.addAll -> void
        return v1;
    }

    public com.sec.chaton.a.ab a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.chaton.a.ab.a:int
        v1.c = v2; // com.sec.chaton.a.ab.c:java.lang.Object
        return v1;
    }

    public com.sec.chaton.a.ab b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.chaton.a.ab.h -> com.sec.chaton.a.ab
        v0 = _result;
        _result = v2.e(); // com.sec.chaton.a.ab.e -> com.sec.chaton.a.aa
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.ab.a -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.ab b(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.chaton.a.ab.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.chaton.a.ab.a:int
        v1.d = v2; // com.sec.chaton.a.ab.d:java.lang.Object
        return v1;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.chaton.a.ab.d -> com.sec.chaton.a.aa
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.chaton.a.ab.e -> com.sec.chaton.a.aa
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.aa c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.chaton.a.aa.a -> com.sec.chaton.a.aa
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.ab.a -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.ab.a -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ab.b -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ab.b -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ab.b -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.ab.b -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.aa d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.chaton.a.ab.e -> com.sec.chaton.a.aa
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.chaton.a.aa.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.chaton.a.ab.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.chaton.a.aa e() {
        // Registers (7 total): v6 = this
        v0 = 1;
        v2 = new com.sec.chaton.a.aa;
        v1 = 0;
        _result = v2.<init>(v6, v1); // com.sec.chaton.a.aa.<init> -> void
        v3 = v6.a; // com.sec.chaton.a.ab.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_004a */;
        v4 = v6.b; // com.sec.chaton.a.ab.b:long
        _result = v2.a(v4, v5); // com.sec.chaton.a.aa.a -> long
        v1 = binOpLit8_0xdd(v3, 2);
        v4 = 2;
        if (v1 != v4) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v6.c; // com.sec.chaton.a.ab.c:java.lang.Object
        _result = v2.a(v1); // com.sec.chaton.a.aa.a -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 4);
        v3 = 4;
        if (v1 != v3) /* goto L_0026 */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = v6.d; // com.sec.chaton.a.ab.d:java.lang.Object
        _result = v2.b(v1); // com.sec.chaton.a.aa.b -> java.lang.Object
        v1 = v6.a; // com.sec.chaton.a.ab.a:int
        v1 = binOpLit8_0xdd(v1, 8);
        v3 = 8;
        if (v1 != v3) /* goto L_0041 */;
        v1 = v6.e; // com.sec.chaton.a.ab.e:java.util.List
        _result = v1.unmodifiableList(); // java.util.Collections.unmodifiableList -> java.util.List
        v1 = _result;
        v6.e = v1; // com.sec.chaton.a.ab.e:java.util.List
        v1 = v6.a; // com.sec.chaton.a.ab.a:int
        v1 = binOpLit8_0xdd(v1, -9);
        v6.a = v1; // com.sec.chaton.a.ab.a:int
        v1 = v6.e; // com.sec.chaton.a.ab.e:java.util.List
        _result = v2.a(v1); // com.sec.chaton.a.aa.a -> java.util.List
        _result = v2.a(v0); // com.sec.chaton.a.aa.a -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.ab.c -> com.sec.chaton.a.aa
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.chaton.a.ab.c -> com.sec.chaton.a.aa
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.ab.a -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.chaton.a.aa) v2;
        _result = v1.a(v2); // com.sec.chaton.a.ab.a -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.chaton.a.ab.a -> com.sec.chaton.a.ab
        v0 = _result;
        return v0;
    }

}