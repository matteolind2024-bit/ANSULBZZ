package com.sec.chaton;

/**
 * Original SourceFile: SelectCountry.java
 * Descriptor: Lcom/sec/chaton/SelectCountry;
 */
public class SelectCountry extends com.sec.chaton.base.BaseSinglePaneActivity {
    public SelectCountry() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // com.sec.chaton.base.BaseSinglePaneActivity.<init> -> void
        return;
    }

    protected android.support.v4.app.Fragment a() {
        // Registers (2 total): v1 = this
        v0 = new com.sec.chaton.SelectCountry$RegisteFragment;
        _result = v0.<init>(); // com.sec.chaton.SelectCountry$RegisteFragment.<init> -> void
        return v0;
    }

    public void onWindowFocusChanged(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        _result = v0.onWindowFocusChanged(v1); // com.sec.chaton.base.BaseSinglePaneActivity.onWindowFocusChanged -> void
        return;
    }

}