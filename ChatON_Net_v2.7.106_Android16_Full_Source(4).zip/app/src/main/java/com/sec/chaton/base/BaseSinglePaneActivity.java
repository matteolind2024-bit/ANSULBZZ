package com.sec.chaton.base;

/**
 * Original SourceFile: BaseSinglePaneActivity.java
 * Descriptor: Lcom/sec/chaton/base/BaseSinglePaneActivity;
 */
public abstract class BaseSinglePaneActivity extends com.sec.chaton.base.BaseActivity {
    private android.support.v4.app.Fragment a;

    public BaseSinglePaneActivity() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // com.sec.chaton.base.BaseActivity.<init> -> void
        return;
    }

    private void c() {
        // Registers (4 total): v3 = this
        v0 = "showPasswordLockActivity";
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // com.sec.chaton.util.p.b -> void
        _result = v3.getApplicationContext(); // com.sec.chaton.base.BaseSinglePaneActivity.getApplicationContext -> android.content.Context
        v0 = _result;
        _result = v0.c(); // com.sec.chaton.util.j.c -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0028 */;
        v1 = new android.content.Intent;
        v2 = com.sec.chaton.settings.ActivityPasswordLockSet.class;
        _result = v1.<init>(v0, v2); // android.content.Intent.<init> -> void
        v0 = "MODE";
        v2 = "HOME";
        _result = v1.putExtra(v0, v2); // android.content.Intent.putExtra -> android.content.Intent
        _result = v3.startActivity(v1); // com.sec.chaton.base.BaseSinglePaneActivity.startActivity -> void
        return;
    }

    protected abstract android.support.v4.app.Fragment a();
    protected android.support.v4.app.Fragment b() {
        // Registers (3 total): v2 = this
        _result = v2.getSupportFragmentManager(); // com.sec.chaton.base.BaseSinglePaneActivity.getSupportFragmentManager -> android.support.v4.app.FragmentManager
        v0 = _result;
        v1 = "com.sec.chaton:single_pane_fragment";
        _result = v0.findFragmentByTag(v1); // android.support.v4.app.FragmentManager.findFragmentByTag -> android.support.v4.app.Fragment
        v0 = _result;
        return v0;
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.os.Bundle)
        _result = v4.onCreate(v5); // com.sec.chaton.base.BaseActivity.onCreate -> void
        v0 = com.sec.chaton.R.layout.base_singlepane; // 0x7f03002f
        _result = v4.setContentView(v0); // com.sec.chaton.base.BaseSinglePaneActivity.setContentView -> void
        if (v5 != 0) /* goto L_0034 */;
        _result = v4.a(); // com.sec.chaton.base.BaseSinglePaneActivity.a -> android.support.v4.app.Fragment
        v0 = _result;
        v4.a = v0; // com.sec.chaton.base.BaseSinglePaneActivity.a:android.support.v4.app.Fragment
        v0 = v4.a; // com.sec.chaton.base.BaseSinglePaneActivity.a:android.support.v4.app.Fragment
        _result = v4.getIntent(); // com.sec.chaton.base.BaseSinglePaneActivity.getIntent -> android.content.Intent
        v1 = _result;
        _result = v1.b(); // com.sec.chaton.base.BaseSinglePaneActivity.b -> android.os.Bundle
        v1 = _result;
        _result = v0.setArguments(v1); // android.support.v4.app.Fragment.setArguments -> void
        _result = v4.getSupportFragmentManager(); // com.sec.chaton.base.BaseSinglePaneActivity.getSupportFragmentManager -> android.support.v4.app.FragmentManager
        v0 = _result;
        _result = v0.beginTransaction(); // android.support.v4.app.FragmentManager.beginTransaction -> android.support.v4.app.FragmentTransaction
        v0 = _result;
        v1 = com.sec.chaton.R.id.fragment_controller; // 0x7f08000c
        v2 = v4.a; // com.sec.chaton.base.BaseSinglePaneActivity.a:android.support.v4.app.Fragment
        v3 = "com.sec.chaton:single_pane_fragment";
        _result = v0.add(v1, v2, v3); // android.support.v4.app.FragmentTransaction.add -> android.support.v4.app.FragmentTransaction
        v0 = _result;
        _result = v0.commit(); // android.support.v4.app.FragmentTransaction.commit -> int
        return;
    }

    protected void onResume() {
        // Registers (1 total): v0 = this
        _result = v0.onResume(); // com.sec.chaton.base.BaseActivity.onResume -> void
        _result = v0.c(); // com.sec.chaton.base.BaseSinglePaneActivity.c -> void
        return;
    }

}