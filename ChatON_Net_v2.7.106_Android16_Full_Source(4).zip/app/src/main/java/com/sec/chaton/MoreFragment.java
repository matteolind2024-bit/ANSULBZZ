package com.sec.chaton;

/**
 * Original SourceFile: MoreFragment.java
 * Descriptor: Lcom/sec/chaton/MoreFragment;
 */
public class MoreFragment extends android.support.v4.app.Fragment implements com.sec.chaton.ac {
    public static final java.lang.String a;
    static java.util.ArrayList b;
    public static com.coolots.sso.a.a c;
    public static com.coolots.sso.a.d d;
     android.widget.AdapterView$OnItemClickListener e;
    private boolean f;
    private android.view.View g;
    private android.widget.LinearLayout h;
    private android.widget.ImageView i;
    private android.widget.GridView j;
    private com.sec.chaton.aj k;
    private com.sec.chaton.event.e l;
    private android.content.BroadcastReceiver m;
    private android.content.BroadcastReceiver n;
    private android.os.Handler o;

    static {
        v0 = com.sec.chaton.MoreFragment.class;
        _result = v0.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v0 = _result;
        com.sec.chaton.MoreFragment.a = v0; // :java.lang.String
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        com.sec.chaton.MoreFragment.b = v0; // :java.util.ArrayList
        v0 = 0;
        com.sec.chaton.MoreFragment.c = v0; // :com.coolots.sso.a.a
        v0 = new com.sec.chaton.ad;
        _result = v0.<init>(); // com.sec.chaton.ad.<init> -> void
        com.sec.chaton.MoreFragment.d = v0; // :com.coolots.sso.a.d
        return;
    }

    public MoreFragment() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // android.support.v4.app.Fragment.<init> -> void
        v0 = 1;
        v1.f = v0; // com.sec.chaton.MoreFragment.f:boolean
        v0 = new com.sec.chaton.ae;
        _result = v0.<init>(v1); // com.sec.chaton.ae.<init> -> void
        v1.m = v0; // com.sec.chaton.MoreFragment.m:android.content.BroadcastReceiver
        v0 = new com.sec.chaton.af;
        _result = v0.<init>(v1); // com.sec.chaton.af.<init> -> void
        v1.e = v0; // com.sec.chaton.MoreFragment.e:android.widget.AdapterView$OnItemClickListener
        v0 = new com.sec.chaton.ah;
        _result = v0.<init>(v1); // com.sec.chaton.ah.<init> -> void
        v1.n = v0; // com.sec.chaton.MoreFragment.n:android.content.BroadcastReceiver
        v0 = new com.sec.chaton.ai;
        _result = v0.<init>(v1); // com.sec.chaton.ai.<init> -> void
        v1.o = v0; // com.sec.chaton.MoreFragment.o:android.os.Handler
        return;
    }

    public static int a(int p0) {
        // Registers (6 total): v5 = p0 (int)
        v1 = 1;
        v2 = 0;
        v0 = com.sec.chaton.MoreFragment.b; // :java.util.ArrayList
        _result = v0.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (com.sec.chaton.ak) v0;
        v0 = v0.a; // com.sec.chaton.ak.a:java.lang.Integer
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        // switch(v0)
        v0 = v2;
        return v0;
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v3 = "UpdateIsCritical";
        _result = v0.b(v3); // com.sec.chaton.util.s.b -> boolean
        v0 = _result;
        if (v0 != v1) /* goto L_0059 */;
        v0 = v1;
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v1 = _result;
        _result = v1.a(); // com.sec.chaton.util.bp.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0042 */;
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v1 = _result;
        v3 = "chatonVUpdateStatus";
        _result = v2.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v4 = _result;
        _result = v1.a(v3, v4); // com.sec.chaton.util.s.a -> java.lang.Integer
        v1 = _result;
        _result = v1.intValue(); // java.lang.Integer.intValue -> int
        v1 = _result;
        if (v1 == 0) /* goto L_0042 */;
        v0 = binOpLit8_0xd8(v0, 1);
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v1 = _result;
        v3 = "sppIsUpdate";
        _result = v2.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v2 = _result;
        _result = v1.a(v3, v2); // com.sec.chaton.util.s.a -> java.lang.Boolean
        v1 = _result;
        _result = v1.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0014 */;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0014
        v0 = v2;
        // goto L_0022
        _result = this.a(); // com.sec.chaton.settings.downloads.ax.a -> int
        v0 = _result;
        // goto L_0014
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "notice";
        _result = v2.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.Integer
        v0 = _result;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        // goto L_0014
        _result = this.m(); // com.sec.chaton.event.f.m -> int
        v0 = _result;
        // goto L_0014
    }

    static void a(com.sec.chaton.MoreFragment p0) {
        // Registers (1 total): v0 = p0 (com.sec.chaton.MoreFragment)
        _result = v0.g(); // com.sec.chaton.MoreFragment.g -> void
        return;
    }

    static com.sec.chaton.aj b(com.sec.chaton.MoreFragment p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.MoreFragment)
        v0 = v1.k; // com.sec.chaton.MoreFragment.k:com.sec.chaton.aj
        return v0;
    }

    static com.sec.chaton.event.e c(com.sec.chaton.MoreFragment p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.MoreFragment)
        v0 = v1.l; // com.sec.chaton.MoreFragment.l:com.sec.chaton.event.e
        return v0;
    }

    public static void c() {
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v0 = _result;
        _result = v0.a(); // com.sec.chaton.util.bp.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000b */;
        return;
        v0 = com.sec.chaton.MoreFragment.c; // :com.coolots.sso.a.a
        if (v0 == 0) /* goto L_0018 */;
        v0 = com.sec.chaton.MoreFragment.c; // :com.coolots.sso.a.a
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v1 = _result;
        _result = v0.a(v1); // com.coolots.sso.a.a.a -> void
        v0 = new com.coolots.sso.a.a;
        _result = v0.<init>(); // com.coolots.sso.a.a.<init> -> void
        com.sec.chaton.MoreFragment.c = v0; // :com.coolots.sso.a.a
        v0 = com.sec.chaton.MoreFragment.c; // :com.coolots.sso.a.a
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v1 = _result;
        v2 = com.sec.chaton.MoreFragment.d; // :com.coolots.sso.a.d
        _result = v0.a(v1, v2); // com.coolots.sso.a.a.a -> void
        v0 = com.sec.chaton.MoreFragment.c; // :com.coolots.sso.a.a
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v1 = _result;
        _result = v0.o(v1); // com.coolots.sso.a.a.o -> int
        // goto L_000a
    }

    static void d(com.sec.chaton.MoreFragment p0) {
        // Registers (1 total): v0 = p0 (com.sec.chaton.MoreFragment)
        _result = v0.f(); // com.sec.chaton.MoreFragment.f -> void
        return;
    }

    public static int e() {
        v0 = 0;
        v1 = v0;
        v2 = com.sec.chaton.MoreFragment.b; // :java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        if (v0 >= v2) /* goto L_0012 */;
        _result = v0.a(); // com.sec.chaton.MoreFragment.a -> int
        v2 = _result;
        v1 = binOp2addr_0xb0(v1, v2);
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0002
        return v1;
    }

    private void f() {
        // Registers (4 total): v3 = this
        v0 = com.sec.chaton.MoreFragment.b; // :java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        v0 = com.sec.chaton.MoreFragment.b; // :java.util.ArrayList
        v1 = new com.sec.chaton.ak;
        v2 = com.sec.chaton.R.layout.more_item_setting; // 0x7f03015b
        _result = v2.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v1.<init>(v3, v2); // com.sec.chaton.ak.<init> -> void
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        v0 = com.sec.chaton.MoreFragment.b; // :java.util.ArrayList
        v1 = new com.sec.chaton.ak;
        v2 = com.sec.chaton.R.layout.more_item_download; // 0x7f030158
        _result = v2.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v1.<init>(v3, v2); // com.sec.chaton.ak.<init> -> void
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        v0 = com.sec.chaton.MoreFragment.b; // :java.util.ArrayList
        v1 = new com.sec.chaton.ak;
        v2 = com.sec.chaton.R.layout.more_item_chatonlive; // 0x7f030156
        _result = v2.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v1.<init>(v3, v2); // com.sec.chaton.ak.<init> -> void
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        v0 = com.sec.chaton.MoreFragment.b; // :java.util.ArrayList
        v1 = new com.sec.chaton.ak;
        v2 = com.sec.chaton.R.layout.more_item_support; // 0x7f03015c
        _result = v2.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v1.<init>(v3, v2); // com.sec.chaton.ak.<init> -> void
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        _result = this.f(); // com.sec.chaton.event.f.f -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0060 */;
        v0 = com.sec.chaton.MoreFragment.b; // :java.util.ArrayList
        v1 = new com.sec.chaton.ak;
        v2 = com.sec.chaton.R.layout.more_item_events; // 0x7f030159
        _result = v2.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v1.<init>(v3, v2); // com.sec.chaton.ak.<init> -> void
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        return;
    }

    private void g() {
        // Registers (5 total): v4 = this
        v2 = 0;
        v1 = v2;
        v0 = com.sec.chaton.MoreFragment.b; // :java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_002c */;
        _result = v1.a(); // com.sec.chaton.MoreFragment.a -> int
        v3 = _result;
        v0 = com.sec.chaton.MoreFragment.b; // :java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (com.sec.chaton.ak) v0;
        v0 = v0.b; // com.sec.chaton.ak.b:android.widget.TextView
        if (v0 == 0) /* goto L_0022 */;
        if (v3 <= 0) /* goto L_0026 */;
        _result = v0.setVisibility(v2); // android.widget.TextView.setVisibility -> void
        _result = v0.a(v3); // com.sec.chaton.util.cb.a -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0002
        v3 = 8;
        _result = v0.setVisibility(v3); // android.widget.TextView.setVisibility -> void
        // goto L_0022
        _result = v4.getView(); // com.sec.chaton.MoreFragment.getView -> android.view.View
        v0 = _result;
        _result = v0.invalidate(); // android.view.View.invalidate -> void
        return;
        v0 = _exception;
        v1 = com.sec.chaton.MoreFragment.a; // :java.lang.String
        _result = v0.a(v1); // com.sec.chaton.util.p.a -> void
        // goto L_0033
    }

    public void a() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v2.f = v0; // com.sec.chaton.MoreFragment.f:boolean
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onTabSelected() / isShow : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.f; // com.sec.chaton.MoreFragment.f:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.MoreFragment.a; // :java.lang.String
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        return;
    }

    public void b() {
        // Registers (3 total): v2 = this
        v0 = 0;
        v2.f = v0; // com.sec.chaton.MoreFragment.f:boolean
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onTabUnSelected() / isShow : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.f; // com.sec.chaton.MoreFragment.f:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.MoreFragment.a; // :java.lang.String
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        return;
    }

    public void d() {
        // Registers (4 total): v3 = this
        // monitor-enter(v3)
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "new_event_count";
        v2 = 0;
        _result = v2.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v0.a(v1, v2); // com.sec.chaton.util.s.a -> java.lang.Integer
        v0 = _result;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_001b */;
        v0 = v3.l; // com.sec.chaton.MoreFragment.l:com.sec.chaton.event.e
        _result = v0.a(); // com.sec.chaton.event.e.a -> com.sec.chaton.event.g
        // monitor-exit(v3)
        return;
        v0 = _exception;
        // monitor-exit(v3)
        throw v0;
    }

    public void onActivityCreated(android.os.Bundle p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.Bundle)
        _result = v0.onActivityCreated(v1); // android.support.v4.app.Fragment.onActivityCreated -> void
        return;
    }

    public void onConfigurationChanged(android.content.res.Configuration p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.res.Configuration)
        _result = v2.onConfigurationChanged(v3); // android.support.v4.app.Fragment.onConfigurationChanged -> void
        v0 = v3.orientation; // android.content.res.Configuration.orientation:int
        v1 = 2;
        if (v0 != v1) /* goto L_0010 */;
        v0 = v2.h; // com.sec.chaton.MoreFragment.h:android.widget.LinearLayout
        v1 = 8;
        _result = v0.setVisibility(v1); // android.widget.LinearLayout.setVisibility -> void
        return;
        v0 = v2.h; // com.sec.chaton.MoreFragment.h:android.widget.LinearLayout
        v1 = 0;
        _result = v0.setVisibility(v1); // android.widget.LinearLayout.setVisibility -> void
        // goto L_000f
    }

    public void onCreate(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        _result = v3.onCreate(v4); // android.support.v4.app.Fragment.onCreate -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onCreate() / isShow : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.f; // com.sec.chaton.MoreFragment.f:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.MoreFragment.a; // :java.lang.String
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        v0 = new com.sec.chaton.event.e;
        _result = v3.getActivity(); // com.sec.chaton.MoreFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        v2 = v3.o; // com.sec.chaton.MoreFragment.o:android.os.Handler
        _result = v0.<init>(v1, v2); // com.sec.chaton.event.e.<init> -> void
        v3.l = v0; // com.sec.chaton.MoreFragment.l:com.sec.chaton.event.e
        _result = v3.f(); // com.sec.chaton.MoreFragment.f -> void
        return;
    }

    public android.view.View onCreateView(android.view.LayoutInflater p0, android.view.ViewGroup p1, android.os.Bundle p2) {
        // Registers (9 total): v5 = this, v6 = p0 (android.view.LayoutInflater), v7 = p1 (android.view.ViewGroup), v8 = p2 (android.os.Bundle)
        v4 = 0;
        v0 = com.sec.chaton.R.layout.layout_more_menu; // 0x7f0300cd
        _result = v6.inflate(v0, v7, v4); // android.view.LayoutInflater.inflate -> android.view.View
        v0 = _result;
        v5.g = v0; // com.sec.chaton.MoreFragment.g:android.view.View
        v0 = v5.g; // com.sec.chaton.MoreFragment.g:android.view.View
        v1 = com.sec.chaton.R.id.layout_more_menu_logo; // 0x7f080455
        _result = v0.findViewById(v1); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.LinearLayout) v0;
        v5.h = v0; // com.sec.chaton.MoreFragment.h:android.widget.LinearLayout
        v0 = v5.g; // com.sec.chaton.MoreFragment.g:android.view.View
        v1 = com.sec.chaton.R.id.more_menu_logo; // 0x7f080456
        _result = v0.findViewById(v1); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.ImageView) v0;
        v5.i = v0; // com.sec.chaton.MoreFragment.i:android.widget.ImageView
        v0 = 1;
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v1 = _result;
        v2 = "Theme";
        _result = v4.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v3 = _result;
        _result = v1.a(v2, v3); // com.sec.chaton.util.s.a -> java.lang.Integer
        v1 = _result;
        _result = v1.intValue(); // java.lang.Integer.intValue -> int
        v1 = _result;
        if (v0 != v1) /* goto L_0044 */;
        v0 = v5.i; // com.sec.chaton.MoreFragment.i:android.widget.ImageView
        _result = v0.getBackground(); // android.widget.ImageView.getBackground -> android.graphics.drawable.Drawable
        v0 = _result;
        v1 = 95;
        _result = v0.setAlpha(v1); // android.graphics.drawable.Drawable.setAlpha -> void
        v0 = v5.g; // com.sec.chaton.MoreFragment.g:android.view.View
        v1 = com.sec.chaton.R.id.MoreMenu; // 0x7f080454
        _result = v0.findViewById(v1); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.GridView) v0;
        v5.j = v0; // com.sec.chaton.MoreFragment.j:android.widget.GridView
        v0 = new com.sec.chaton.aj;
        _result = this.b(); // com.sec.chaton.global.GlobalApplication.b -> android.content.Context
        v1 = _result;
        _result = v0.<init>(v5, v1); // com.sec.chaton.aj.<init> -> void
        v5.k = v0; // com.sec.chaton.MoreFragment.k:com.sec.chaton.aj
        v0 = v5.j; // com.sec.chaton.MoreFragment.j:android.widget.GridView
        v1 = v5.k; // com.sec.chaton.MoreFragment.k:com.sec.chaton.aj
        _result = v0.setAdapter(v1); // android.widget.GridView.setAdapter -> void
        v0 = v5.j; // com.sec.chaton.MoreFragment.j:android.widget.GridView
        v1 = v5.e; // com.sec.chaton.MoreFragment.e:android.widget.AdapterView$OnItemClickListener
        _result = v0.setOnItemClickListener(v1); // android.widget.GridView.setOnItemClickListener -> void
        _result = v5.getResources(); // com.sec.chaton.MoreFragment.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getConfiguration(); // android.content.res.Resources.getConfiguration -> android.content.res.Configuration
        v0 = _result;
        v0 = v0.orientation; // android.content.res.Configuration.orientation:int
        v1 = 2;
        if (v0 != v1) /* goto L_0081 */;
        v0 = v5.h; // com.sec.chaton.MoreFragment.h:android.widget.LinearLayout
        v1 = 8;
        _result = v0.setVisibility(v1); // android.widget.LinearLayout.setVisibility -> void
        v0 = v5.g; // com.sec.chaton.MoreFragment.g:android.view.View
        return v0;
        v0 = v5.h; // com.sec.chaton.MoreFragment.h:android.widget.LinearLayout
        _result = v0.setVisibility(v4); // android.widget.LinearLayout.setVisibility -> void
        // goto L_007e
    }

    public void onDestroy() {
        // Registers (3 total): v2 = this
        _result = v2.onDestroy(); // android.support.v4.app.Fragment.onDestroy -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onDestroy() / isShow : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.f; // com.sec.chaton.MoreFragment.f:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.MoreFragment.a; // :java.lang.String
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        return;
    }

    public void onPause() {
        // Registers (3 total): v2 = this
        _result = v2.onPause(); // android.support.v4.app.Fragment.onPause -> void
        v0 = 0;
        v2.f = v0; // com.sec.chaton.MoreFragment.f:boolean
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onPause() / isShow : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.f; // com.sec.chaton.MoreFragment.f:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.MoreFragment.a; // :java.lang.String
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        _result = v2.getActivity(); // com.sec.chaton.MoreFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v0 = _result;
        v1 = v2.m; // com.sec.chaton.MoreFragment.m:android.content.BroadcastReceiver
        _result = v0.unregisterReceiver(v1); // android.support.v4.content.LocalBroadcastManager.unregisterReceiver -> void
        _result = v2.getActivity(); // com.sec.chaton.MoreFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v0 = _result;
        v1 = v2.n; // com.sec.chaton.MoreFragment.n:android.content.BroadcastReceiver
        _result = v0.unregisterReceiver(v1); // android.support.v4.content.LocalBroadcastManager.unregisterReceiver -> void
        return;
    }

    public void onResume() {
        // Registers (4 total): v3 = this
        _result = v3.onResume(); // android.support.v4.app.Fragment.onResume -> void
        v0 = 1;
        v3.f = v0; // com.sec.chaton.MoreFragment.f:boolean
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onResume() / isShow : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.f; // com.sec.chaton.MoreFragment.f:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.MoreFragment.a; // :java.lang.String
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        _result = v3.f(); // com.sec.chaton.MoreFragment.f -> void
        v0 = v3.k; // com.sec.chaton.MoreFragment.k:com.sec.chaton.aj
        _result = v0.notifyDataSetChanged(); // com.sec.chaton.aj.notifyDataSetChanged -> void
        _result = v3.d(); // com.sec.chaton.MoreFragment.d -> void
        v0 = new android.content.IntentFilter;
        _result = v0.<init>(); // android.content.IntentFilter.<init> -> void
        v1 = "more_tab_badge_update";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        _result = v3.getActivity(); // com.sec.chaton.MoreFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v1.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v1 = _result;
        v2 = v3.n; // com.sec.chaton.MoreFragment.n:android.content.BroadcastReceiver
        _result = com.sec.chaton.bridge.Android16Compat.registerReceiverSafe(v1, v2, v0); // android.support.v4.content.LocalBroadcastManager.registerReceiver -> void
        v0 = new android.content.IntentFilter;
        _result = v0.<init>(); // android.content.IntentFilter.<init> -> void
        v1 = "more_event_update";
        _result = v0.addAction(v1); // android.content.IntentFilter.addAction -> void
        _result = v3.getActivity(); // com.sec.chaton.MoreFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v1.getInstance(); // android.support.v4.content.LocalBroadcastManager.getInstance -> android.support.v4.content.LocalBroadcastManager
        v1 = _result;
        v2 = v3.m; // com.sec.chaton.MoreFragment.m:android.content.BroadcastReceiver
        _result = com.sec.chaton.bridge.Android16Compat.registerReceiverSafe(v1, v2, v0); // android.support.v4.content.LocalBroadcastManager.registerReceiver -> void
        _result = this.c(); // com.sec.chaton.settings.PhoneSettingFragment2.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0075 */;
        v0 = new android.content.Intent;
        _result = v3.getActivity(); // com.sec.chaton.MoreFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        v2 = com.sec.chaton.settings.SettingContainerActivity.class;
        _result = v0.<init>(v1, v2); // android.content.Intent.<init> -> void
        v1 = "contentId";
        v2 = com.sec.chaton.R.string.menu_inbox_setting; // 0x7f0c005a
        _result = v0.putExtra(v1, v2); // android.content.Intent.putExtra -> android.content.Intent
        _result = v3.startActivity(v0); // com.sec.chaton.MoreFragment.startActivity -> void
        return;
    }

    public void onStart() {
        // Registers (3 total): v2 = this
        _result = v2.onStart(); // android.support.v4.app.Fragment.onStart -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "onStart() / isShow : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.f; // com.sec.chaton.MoreFragment.f:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = com.sec.chaton.MoreFragment.a; // :java.lang.String
        _result = v0.e(v1); // com.sec.chaton.util.p.e -> void
        return;
    }

}