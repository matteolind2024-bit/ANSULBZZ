package com.sec.chaton.a.a;

/**
 * Original SourceFile: MessageResultEntry.java
 * Descriptor: Lcom/sec/chaton/a/a/f;
 */
public class f extends com.sec.chaton.a.a.h {
    private int d;
    private long e;

    public f(boolean p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (boolean), v4 = p1 (int)
        _result = v2.<init>(v3); // com.sec.chaton.a.a.h.<init> -> void
        v2.d = v4; // com.sec.chaton.a.a.f.d:int
        v0 = com.sec.chaton.a.a.i.a; // :com.sec.chaton.a.a.i
        v2.b = v0; // com.sec.chaton.a.a.f.b:com.sec.chaton.a.a.i
        v0 = -1L;
        v2.e = v0; // com.sec.chaton.a.a.f.e:long
        return;
    }

    public f(boolean p0, int p1, long p2) {
        // Registers (6 total): v1 = this, v2 = p0 (boolean), v3 = p1 (int), v4 = p2 (long)
        _result = v1.<init>(v2); // com.sec.chaton.a.a.h.<init> -> void
        v1.d = v3; // com.sec.chaton.a.a.f.d:int
        v0 = com.sec.chaton.a.a.i.a; // :com.sec.chaton.a.a.i
        v1.b = v0; // com.sec.chaton.a.a.f.b:com.sec.chaton.a.a.i
        v1.e = v4; // com.sec.chaton.a.a.f.e:long
        return;
    }

    public f(boolean p0, int p1, java.lang.String p2) {
        // Registers (6 total): v2 = this, v3 = p0 (boolean), v4 = p1 (int), v5 = p2 (java.lang.String)
        _result = v2.<init>(v3, v5); // com.sec.chaton.a.a.h.<init> -> void
        v2.d = v4; // com.sec.chaton.a.a.f.d:int
        v0 = com.sec.chaton.a.a.i.a; // :com.sec.chaton.a.a.i
        v2.b = v0; // com.sec.chaton.a.a.f.b:com.sec.chaton.a.a.i
        v0 = -1L;
        v2.e = v0; // com.sec.chaton.a.a.f.e:long
        return;
    }

    public f(boolean p0, int p1, java.lang.String p2, long p3) {
        // Registers (7 total): v1 = this, v2 = p0 (boolean), v3 = p1 (int), v4 = p2 (java.lang.String), v5 = p3 (long)
        _result = v1.<init>(v2, v4); // com.sec.chaton.a.a.h.<init> -> void
        v1.d = v3; // com.sec.chaton.a.a.f.d:int
        v0 = com.sec.chaton.a.a.i.a; // :com.sec.chaton.a.a.i
        v1.b = v0; // com.sec.chaton.a.a.f.b:com.sec.chaton.a.a.i
        v1.e = v5; // com.sec.chaton.a.a.f.e:long
        return;
    }

    public f(boolean p0, com.sec.chaton.a.a.i p1) {
        // Registers (5 total): v2 = this, v3 = p0 (boolean), v4 = p1 (com.sec.chaton.a.a.i)
        _result = v2.<init>(v3, v4); // com.sec.chaton.a.a.h.<init> -> void
        v0 = -1;
        v2.d = v0; // com.sec.chaton.a.a.f.d:int
        v0 = -1L;
        v2.e = v0; // com.sec.chaton.a.a.f.e:long
        return;
    }

    public int g() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.sec.chaton.a.a.f.d:int
        return v0;
    }

    public long h() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.chaton.a.a.f.e:long
        return v0;
    }

}