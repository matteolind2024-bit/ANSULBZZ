package com.sec.chaton.a;

/**
 * Original SourceFile: SSMGPB.java
 * Descriptor: Lcom/sec/chaton/a/av;
 */
public final class av extends com.google.protobuf.GeneratedMessageLite implements com.sec.chaton.a.ax {
    private static final com.sec.chaton.a.av a;
    private int b;
    private java.lang.Object c;
    private com.sec.chaton.a.ar d;
    private java.util.List e;
    private java.lang.Object f;
    private boolean g;
    private java.lang.Object h;
    private byte i;
    private int j;

    static {
        v0 = new com.sec.chaton.a.av;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.chaton.a.av.<init> -> void
        com.sec.chaton.a.av.a = v0; // :com.sec.chaton.a.av
        v0 = com.sec.chaton.a.av.a; // :com.sec.chaton.a.av
        _result = v0.t(); // com.sec.chaton.a.av.t -> void
        return;
    }

    private av(com.sec.chaton.a.aw p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.chaton.a.aw)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.i = v0; // com.sec.chaton.a.av.i:byte
        v1.j = v0; // com.sec.chaton.a.av.j:int
        return;
    }

    av(com.sec.chaton.a.aw p0, com.sec.chaton.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.chaton.a.aw), v2 = p1 (com.sec.chaton.a.b)
        _result = v0.<init>(v1); // com.sec.chaton.a.av.<init> -> void
        return;
    }

    private av(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.i = v0; // com.sec.chaton.a.av.i:byte
        v1.j = v0; // com.sec.chaton.a.av.j:int
        return;
    }

    static int a(com.sec.chaton.a.av p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.av), v1 = p1 (int)
        v0.b = v1; // com.sec.chaton.a.av.b:int
        return v1;
    }

    static com.sec.chaton.a.ar a(com.sec.chaton.a.av p0, com.sec.chaton.a.ar p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.av), v1 = p1 (com.sec.chaton.a.ar)
        v0.d = v1; // com.sec.chaton.a.av.d:com.sec.chaton.a.ar
        return v1;
    }

    public static com.sec.chaton.a.av a() {
        v0 = com.sec.chaton.a.av.a; // :com.sec.chaton.a.av
        return v0;
    }

    public static com.sec.chaton.a.av a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.chaton.a.av.newBuilder -> com.sec.chaton.a.aw
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.chaton.a.aw.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.chaton.a.aw) v0;
        _result = v0.a(); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.av
        v0 = _result;
        return v0;
    }

    public static com.sec.chaton.a.aw a(com.sec.chaton.a.av p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.av)
        _result = this.newBuilder(); // com.sec.chaton.a.av.newBuilder -> com.sec.chaton.a.aw
        v0 = _result;
        _result = v0.a(v1); // com.sec.chaton.a.aw.a -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    static java.lang.Object a(com.sec.chaton.a.av p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.av), v1 = p1 (java.lang.Object)
        v0.c = v1; // com.sec.chaton.a.av.c:java.lang.Object
        return v1;
    }

    static java.util.List a(com.sec.chaton.a.av p0, java.util.List p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.av), v1 = p1 (java.util.List)
        v0.e = v1; // com.sec.chaton.a.av.e:java.util.List
        return v1;
    }

    static boolean a(com.sec.chaton.a.av p0, boolean p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.av), v1 = p1 (boolean)
        v0.g = v1; // com.sec.chaton.a.av.g:boolean
        return v1;
    }

    static java.lang.Object b(com.sec.chaton.a.av p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.av), v1 = p1 (java.lang.Object)
        v0.f = v1; // com.sec.chaton.a.av.f:java.lang.Object
        return v1;
    }

    static java.util.List b(com.sec.chaton.a.av p0) {
        // Registers (2 total): v1 = p0 (com.sec.chaton.a.av)
        v0 = v1.e; // com.sec.chaton.a.av.e:java.util.List
        return v0;
    }

    static java.lang.Object c(com.sec.chaton.a.av p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.chaton.a.av), v1 = p1 (java.lang.Object)
        v0.h = v1; // com.sec.chaton.a.av.h:java.lang.Object
        return v1;
    }

    public static com.sec.chaton.a.aw newBuilder() {
        _result = this.f(); // com.sec.chaton.a.aw.f -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    private com.google.protobuf.ByteString q() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.sec.chaton.a.av.c:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.c = v0; // com.sec.chaton.a.av.c:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString r() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // com.sec.chaton.a.av.f:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.f = v0; // com.sec.chaton.a.av.f:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString s() {
        // Registers (3 total): v2 = this
        v0 = v2.h; // com.sec.chaton.a.av.h:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.h = v0; // com.sec.chaton.a.av.h:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void t() {
        // Registers (2 total): v1 = this
        v0 = "";
        v1.c = v0; // com.sec.chaton.a.av.c:java.lang.Object
        v0 = com.sec.chaton.a.ar.a; // :com.sec.chaton.a.ar
        v1.d = v0; // com.sec.chaton.a.av.d:com.sec.chaton.a.ar
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        v1.e = v0; // com.sec.chaton.a.av.e:java.util.List
        v0 = "";
        v1.f = v0; // com.sec.chaton.a.av.f:java.lang.Object
        v0 = 0;
        v1.g = v0; // com.sec.chaton.a.av.g:boolean
        v0 = "";
        v1.h = v0; // com.sec.chaton.a.av.h:java.lang.Object
        return;
    }

    public com.sec.chaton.a.bu a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.e; // com.sec.chaton.a.av.e:java.util.List
        _result = java.util.List.get(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (com.sec.chaton.a.bu) v0;
        return v0;
    }

    public com.sec.chaton.a.av b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.chaton.a.av.a; // :com.sec.chaton.a.av
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.chaton.a.av.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public java.lang.String d() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.sec.chaton.a.av.c:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.c = v1; // com.sec.chaton.a.av.c:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.sec.chaton.a.ar f() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.sec.chaton.a.av.d:com.sec.chaton.a.ar
        return v0;
    }

    public java.util.List g() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.sec.chaton.a.av.e:java.util.List
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.chaton.a.av.b -> com.sec.chaton.a.av
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (7 total): v6 = this
        v5 = 4;
        v4 = 2;
        v3 = 1;
        v1 = 0;
        v2 = v6.j; // com.sec.chaton.a.av.j:int
        v0 = -1;
        if (v2 == v0) /* goto L_000a */;
        return v2;
        v0 = v6.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v3) /* goto L_0079 */;
        _result = v6.q(); // com.sec.chaton.a.av.q -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v3.computeBytesSize(v0); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v2 = v6.b; // com.sec.chaton.a.av.b:int
        v2 = binOpLit8_0xdd(v2, 2);
        if (v2 != v4) /* goto L_002a */;
        v2 = v6.d; // com.sec.chaton.a.av.d:com.sec.chaton.a.ar
        _result = v2.getNumber(); // com.sec.chaton.a.ar.getNumber -> int
        v2 = _result;
        _result = v4.computeEnumSize(v2); // com.google.protobuf.CodedOutputStream.computeEnumSize -> int
        v2 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = v0;
        v0 = v6.e; // com.sec.chaton.a.av.e:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0045 */;
        v3 = 3;
        v0 = v6.e; // com.sec.chaton.a.av.e:java.util.List
        _result = java.util.List.get(v0, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        _result = v3.computeMessageSize(v0); // com.google.protobuf.CodedOutputStream.computeMessageSize -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v1 = binOpLit8_0xd8(v1, 1);
        v2 = v0;
        // goto L_002b
        v0 = v6.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        if (v0 != v5) /* goto L_0054 */;
        _result = v6.r(); // com.sec.chaton.a.av.r -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v5.computeBytesSize(v0); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v0 = _result;
        v2 = binOp2addr_0xb0(v2, v0);
        v0 = v6.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 != v1) /* goto L_0064 */;
        v0 = 5;
        v1 = v6.g; // com.sec.chaton.a.av.g:boolean
        _result = v0.computeBoolSize(v1); // com.google.protobuf.CodedOutputStream.computeBoolSize -> int
        v0 = _result;
        v2 = binOp2addr_0xb0(v2, v0);
        v0 = v6.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_0076 */;
        v0 = 6;
        _result = v6.s(); // com.sec.chaton.a.av.s -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v0.computeBytesSize(v1); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v0 = _result;
        v2 = binOp2addr_0xb0(v2, v0);
        v6.j = v2; // com.sec.chaton.a.av.j:int
        // goto L_0009
        v0 = v1;
        // goto L_0019
    }

    public int h() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.sec.chaton.a.av.e:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        return v0;
    }

    public boolean i() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.i; // com.sec.chaton.a.av.i:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.i = v0; // com.sec.chaton.a.av.i:byte
        // goto L_0008
    }

    public java.lang.String j() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // com.sec.chaton.a.av.f:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.f = v1; // com.sec.chaton.a.av.f:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean k() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public boolean l() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.sec.chaton.a.av.g:boolean
        return v0;
    }

    public boolean m() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.lang.String n() {
        // Registers (3 total): v2 = this
        v0 = v2.h; // com.sec.chaton.a.av.h:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.h = v1; // com.sec.chaton.a.av.h:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.o(); // com.sec.chaton.a.av.o -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.aw o() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.chaton.a.av.newBuilder -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public com.sec.chaton.a.aw p() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.chaton.a.av.a -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.p(); // com.sec.chaton.a.av.p -> com.sec.chaton.a.aw
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (6 total): v4 = this, v5 = p0 (com.google.protobuf.CodedOutputStream)
        v3 = 4;
        v2 = 2;
        v1 = 1;
        _result = v4.getSerializedSize(); // com.sec.chaton.a.av.getSerializedSize -> int
        v0 = v4.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v1) /* goto L_0013 */;
        _result = v4.q(); // com.sec.chaton.a.av.q -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v5.writeBytes(v1, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v4.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v2) /* goto L_0022 */;
        v0 = v4.d; // com.sec.chaton.a.av.d:com.sec.chaton.a.ar
        _result = v0.getNumber(); // com.sec.chaton.a.ar.getNumber -> int
        v0 = _result;
        _result = v5.writeEnum(v2, v0); // com.google.protobuf.CodedOutputStream.writeEnum -> void
        v0 = 0;
        v1 = v0;
        v0 = v4.e; // com.sec.chaton.a.av.e:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_003c */;
        v2 = 3;
        v0 = v4.e; // com.sec.chaton.a.av.e:java.util.List
        _result = java.util.List.get(v0, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        _result = v5.writeMessage(v2, v0); // com.google.protobuf.CodedOutputStream.writeMessage -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0024
        v0 = v4.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        if (v0 != v3) /* goto L_0049 */;
        _result = v4.r(); // com.sec.chaton.a.av.r -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v5.writeBytes(v3, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v4.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 != v1) /* goto L_0057 */;
        v0 = 5;
        v1 = v4.g; // com.sec.chaton.a.av.g:boolean
        _result = v5.writeBool(v0, v1); // com.google.protobuf.CodedOutputStream.writeBool -> void
        v0 = v4.b; // com.sec.chaton.a.av.b:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_0067 */;
        v0 = 6;
        _result = v4.s(); // com.sec.chaton.a.av.s -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v5.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        return;
    }

}