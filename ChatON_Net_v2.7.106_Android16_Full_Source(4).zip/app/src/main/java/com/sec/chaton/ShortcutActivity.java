package com.sec.chaton;

/**
 * Original SourceFile: ShortcutActivity.java
 * Descriptor: Lcom/sec/chaton/ShortcutActivity;
 */
public class ShortcutActivity extends com.sec.chaton.base.BaseActivity {
    public ShortcutActivity() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // com.sec.chaton.base.BaseActivity.<init> -> void
        return;
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (13 total): v11 = this, v12 = p0 (android.os.Bundle)
        v6 = com.sec.chaton.R.string.shortcut_buddy_notfound; // 0x7f0c00d7
        v2 = 0;
        v10 = 1;
        v9 = 0;
        _result = v11.onCreate(v12); // com.sec.chaton.base.BaseActivity.onCreate -> void
        _result = this.a(); // com.sec.chaton.util.r.a -> com.sec.chaton.util.s
        v0 = _result;
        v1 = "uid";
        _result = v0.b(v1); // com.sec.chaton.util.s.b -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_01b2 */;
        _result = v11.getIntent(); // com.sec.chaton.ShortcutActivity.getIntent -> android.content.Intent
        v0 = _result;
        _result = v0.getAction(); // android.content.Intent.getAction -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_00b3 */;
        _result = v11.getIntent(); // com.sec.chaton.ShortcutActivity.getIntent -> android.content.Intent
        v0 = _result;
        _result = v0.getAction(); // android.content.Intent.getAction -> java.lang.String
        v0 = _result;
        v1 = "android.intent.action.VIEW";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00b3 */;
        _result = v11.getIntent(); // com.sec.chaton.ShortcutActivity.getIntent -> android.content.Intent
        v0 = _result;
        _result = v0.getData(); // android.content.Intent.getData -> android.net.Uri
        v0 = _result;
        if (v0 == 0) /* goto L_00b3 */;
        v0 = "Shocrcut from contact";
        _result = v11.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.c(v1); // com.sec.chaton.util.p.c -> void
        _result = v11.getIntent(); // com.sec.chaton.ShortcutActivity.getIntent -> android.content.Intent
        v0 = _result;
        _result = v0.getData(); // android.content.Intent.getData -> android.net.Uri
        v1 = _result;
        _result = v11.getContentResolver(); // com.sec.chaton.ShortcutActivity.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        v3 = v2;
        v4 = v2;
        v5 = v2;
        _result = v0.query(v0..v5); // android.content.ContentResolver.query -> android.database.Cursor
        v0 = _result;
        _result = android.database.Cursor.moveToFirst(v0); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0094 */;
        v1 = "data1";
        _result = android.database.Cursor.getColumnIndex(v0, v1); // -> int
        v1 = _result;
        _result = android.database.Cursor.getString(v0, v1); // -> java.lang.String
        v1 = _result;
        v2 = new android.content.Intent;
        _result = v11.getApplicationContext(); // com.sec.chaton.ShortcutActivity.getApplicationContext -> android.content.Context
        v3 = _result;
        _result = v3.a(v10); // com.sec.chaton.TabActivity.a -> android.content.Intent
        v3 = _result;
        _result = v2.<init>(v3); // android.content.Intent.<init> -> void
        v3 = "inboxNO";
        _result = v2.putExtra(v3, v1); // android.content.Intent.putExtra -> android.content.Intent
        v3 = "chatType";
        v4 = com.sec.chaton.e.n.b; // :com.sec.chaton.e.n
        _result = v4.a(); // com.sec.chaton.e.n.a -> int
        v4 = _result;
        _result = v2.putExtra(v3, v4); // android.content.Intent.putExtra -> android.content.Intent
        v3 = "contact";
        _result = v2.putExtra(v3, v10); // android.content.Intent.putExtra -> android.content.Intent
        v3 = "receivers";
        v4 = new java.lang.String[][size=v10];
        v4[v9] = v1;
        _result = v2.putExtra(v3, v4); // android.content.Intent.putExtra -> android.content.Intent
        _result = android.database.Cursor.close(v0); // -> void
        if (v2 == 0) /* goto L_00a0 */;
        _result = v11.startActivity(v2); // com.sec.chaton.ShortcutActivity.startActivity -> void
        _result = v11.finish(); // com.sec.chaton.ShortcutActivity.finish -> void
        return;
        _result = v11.getResources(); // com.sec.chaton.ShortcutActivity.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getString(v6); // android.content.res.Resources.getString -> java.lang.String
        v0 = _result;
        _result = v11.a(v0, v9); // com.sec.widget.ar.a -> android.widget.Toast
        v0 = _result;
        _result = v0.show(); // android.widget.Toast.show -> void
        _result = v11.finish(); // com.sec.chaton.ShortcutActivity.finish -> void
        // goto L_009f
        _result = v11.getIntent(); // com.sec.chaton.ShortcutActivity.getIntent -> android.content.Intent
        v0 = _result;
        _result = v0.getExtras(); // android.content.Intent.getExtras -> android.os.Bundle
        v0 = _result;
        if (v0 == 0) /* goto L_019e */;
        v1 = "Shocrcut from homescreen";
        _result = v11.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        _result = v3.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v3 = _result;
        _result = v1.c(v3); // com.sec.chaton.util.p.c -> void
        v1 = "inboxNO";
        _result = v0.getString(v1); // android.os.Bundle.getString -> java.lang.String
        v1 = _result;
        v3 = "chatType";
        _result = v0.getInt(v3); // android.os.Bundle.getInt -> int
        v0 = _result;
        v3 = com.sec.chaton.e.n.b; // :com.sec.chaton.e.n
        _result = v3.a(); // com.sec.chaton.e.n.a -> int
        v3 = _result;
        if (v0 != v3) /* goto L_0155 */;
        _result = v11.getContentResolver(); // com.sec.chaton.ShortcutActivity.getContentResolver -> android.content.ContentResolver
        v3 = _result;
        v4 = com.sec.chaton.e.f.a; // :android.net.Uri
        v5 = new java.lang.String[][size=v10];
        v6 = "buddy_no";
        v5[v9] = v6;
        v6 = "buddy_no=?";
        v7 = new java.lang.String[][size=v10];
        v7[v9] = v1;
        v8 = v2;
        _result = v3.query(v3..v8); // android.content.ContentResolver.query -> android.database.Cursor
        v2 = _result;
        if (v2 == 0) /* goto L_00fd */;
        _result = android.database.Cursor.getCount(v2); // -> int
        v3 = _result;
        if (v3 != 0) /* goto L_0119 */;
        _result = v11.getResources(); // com.sec.chaton.ShortcutActivity.getResources -> android.content.res.Resources
        v0 = _result;
        v1 = com.sec.chaton.R.string.shortcut_buddy_notfound; // 0x7f0c00d7
        _result = v0.getString(v1); // android.content.res.Resources.getString -> java.lang.String
        v0 = _result;
        v1 = 0;
        _result = v11.a(v0, v1); // com.sec.widget.ar.a -> android.widget.Toast
        v0 = _result;
        _result = v0.show(); // android.widget.Toast.show -> void
        _result = v11.finish(); // com.sec.chaton.ShortcutActivity.finish -> void
        if (v2 == 0) /* goto L_009f */;
        _result = android.database.Cursor.close(v2); // -> void
        // goto L_009f
        if (v2 == 0) /* goto L_011e */;
        _result = android.database.Cursor.close(v2); // -> void
        v2 = new android.content.Intent;
        _result = v11.getApplicationContext(); // com.sec.chaton.ShortcutActivity.getApplicationContext -> android.content.Context
        v3 = _result;
        _result = v3.a(v10); // com.sec.chaton.TabActivity.a -> android.content.Intent
        v3 = _result;
        _result = v2.<init>(v3); // android.content.Intent.<init> -> void
        v3 = com.sec.chaton.e.n.b; // :com.sec.chaton.e.n
        _result = v3.a(); // com.sec.chaton.e.n.a -> int
        v3 = _result;
        if (v0 != v3) /* goto L_013c */;
        v3 = new java.lang.String[][size=v10];
        v3[v9] = v1;
        v4 = "receivers";
        _result = v2.putExtra(v4, v3); // android.content.Intent.putExtra -> android.content.Intent
        v3 = "inboxNO";
        _result = v2.putExtra(v3, v1); // android.content.Intent.putExtra -> android.content.Intent
        v1 = "chatType";
        _result = v2.putExtra(v1, v0); // android.content.Intent.putExtra -> android.content.Intent
        _result = v11.startActivity(v2); // com.sec.chaton.ShortcutActivity.startActivity -> void
        _result = v11.finish(); // com.sec.chaton.ShortcutActivity.finish -> void
        // goto L_009f
        v0 = _exception;
        if (v2 == 0) /* goto L_0154 */;
        _result = android.database.Cursor.close(v2); // -> void
        throw v0;
        _result = v11.getContentResolver(); // com.sec.chaton.ShortcutActivity.getContentResolver -> android.content.ContentResolver
        v3 = _result;
        v4 = com.sec.chaton.e.m.a; // :android.net.Uri
        v5 = new java.lang.String[][size=v10];
        v6 = "inbox_no";
        v5[v9] = v6;
        v6 = "inbox_no=?";
        v7 = new java.lang.String[][size=v10];
        v7[v9] = v1;
        v8 = v2;
        _result = v3.query(v3..v8); // android.content.ContentResolver.query -> android.database.Cursor
        v2 = _result;
        if (v2 == 0) /* goto L_0174 */;
        _result = android.database.Cursor.getCount(v2); // -> int
        v3 = _result;
        if (v3 != 0) /* goto L_0191 */;
        _result = v11.getResources(); // com.sec.chaton.ShortcutActivity.getResources -> android.content.res.Resources
        v0 = _result;
        v1 = com.sec.chaton.R.string.shortcut_buddy_notfound; // 0x7f0c00d7
        _result = v0.getString(v1); // android.content.res.Resources.getString -> java.lang.String
        v0 = _result;
        v1 = 0;
        _result = v11.a(v0, v1); // com.sec.widget.ar.a -> android.widget.Toast
        v0 = _result;
        _result = v0.show(); // android.widget.Toast.show -> void
        _result = v11.finish(); // com.sec.chaton.ShortcutActivity.finish -> void
        if (v2 == 0) /* goto L_009f */;
        _result = android.database.Cursor.close(v2); // -> void
        // goto L_009f
        if (v2 == 0) /* goto L_011e */;
        _result = android.database.Cursor.close(v2); // -> void
        // goto L_011e
        v0 = _exception;
        if (v2 == 0) /* goto L_019d */;
        _result = android.database.Cursor.close(v2); // -> void
        throw v0;
        _result = v11.getResources(); // com.sec.chaton.ShortcutActivity.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getString(v6); // android.content.res.Resources.getString -> java.lang.String
        v0 = _result;
        _result = v11.a(v0, v9); // com.sec.widget.ar.a -> android.widget.Toast
        v0 = _result;
        _result = v0.show(); // android.widget.Toast.show -> void
        _result = v11.finish(); // com.sec.chaton.ShortcutActivity.finish -> void
        // goto L_009f
        v0 = new android.content.Intent;
        v1 = com.sec.chaton.TabActivity.class;
        _result = v0.<init>(v11, v1); // android.content.Intent.<init> -> void
        _result = v11.startActivity(v0); // com.sec.chaton.ShortcutActivity.startActivity -> void
        _result = v11.finish(); // com.sec.chaton.ShortcutActivity.finish -> void
        // goto L_009f
    }

}