package com.sec.amsoma.structure;

/**
 * Original SourceFile: AMS_OPTION.java
 * Descriptor: Lcom/sec/amsoma/structure/AMS_OPTION;
 */
public class AMS_OPTION {
     boolean m_bBGROrder;
    public byte m_cSimplificationBufSize;
    public byte m_cTurnPageEffect;
    public int m_eSamplingOption;
    public int m_eSmoothingOption;
    public float m_fGenerationCurvature;
    public float m_fSimplificationTolerance;
    public int m_nGenerationAddPointGap;
    public int m_nGenerationExceptMaxLength;
    public int m_nGenerationExceptMinLength;
    public int m_nImageBPP;
    public int m_nMaxPageNum;

    public AMS_OPTION() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void Init() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v0 = 3;
        v2.m_nMaxPageNum = v0; // com.sec.amsoma.structure.AMS_OPTION.m_nMaxPageNum:int
        v0 = 24;
        v2.m_nImageBPP = v0; // com.sec.amsoma.structure.AMS_OPTION.m_nImageBPP:int
        v2.m_bBGROrder = v1; // com.sec.amsoma.structure.AMS_OPTION.m_bBGROrder:boolean
        v0 = 6;
        v2.m_cSimplificationBufSize = v0; // com.sec.amsoma.structure.AMS_OPTION.m_cSimplificationBufSize:byte
        v0 = 0x40000000;
        v2.m_fSimplificationTolerance = v0; // com.sec.amsoma.structure.AMS_OPTION.m_fSimplificationTolerance:float
        v2.m_eSmoothingOption = v1; // com.sec.amsoma.structure.AMS_OPTION.m_eSmoothingOption:int
        v0 = 2;
        v2.m_eSamplingOption = v0; // com.sec.amsoma.structure.AMS_OPTION.m_eSamplingOption:int
        v0 = 7;
        v2.m_nGenerationExceptMinLength = v0; // com.sec.amsoma.structure.AMS_OPTION.m_nGenerationExceptMinLength:int
        v0 = 60;
        v2.m_nGenerationExceptMaxLength = v0; // com.sec.amsoma.structure.AMS_OPTION.m_nGenerationExceptMaxLength:int
        v0 = 5;
        v2.m_nGenerationAddPointGap = v0; // com.sec.amsoma.structure.AMS_OPTION.m_nGenerationAddPointGap:int
        v0 = 0x40400000;
        v2.m_fGenerationCurvature = v0; // com.sec.amsoma.structure.AMS_OPTION.m_fGenerationCurvature:float
        v0 = 1;
        v2.m_cTurnPageEffect = v0; // com.sec.amsoma.structure.AMS_OPTION.m_cTurnPageEffect:byte
        return;
    }

    public int getM_eSamplingOption() {
        // Registers (2 total): v1 = this
        v0 = v1.m_eSamplingOption; // com.sec.amsoma.structure.AMS_OPTION.m_eSamplingOption:int
        return v0;
    }

    public int getM_eSmoothingOption() {
        // Registers (2 total): v1 = this
        v0 = v1.m_eSmoothingOption; // com.sec.amsoma.structure.AMS_OPTION.m_eSmoothingOption:int
        return v0;
    }

    public float getM_fGenerationCurvature() {
        // Registers (2 total): v1 = this
        v0 = v1.m_fGenerationCurvature; // com.sec.amsoma.structure.AMS_OPTION.m_fGenerationCurvature:float
        return v0;
    }

    public float getM_fSimplificationTolerance() {
        // Registers (2 total): v1 = this
        v0 = v1.m_fSimplificationTolerance; // com.sec.amsoma.structure.AMS_OPTION.m_fSimplificationTolerance:float
        return v0;
    }

    public int getM_nGenerationAddPointGap() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nGenerationAddPointGap; // com.sec.amsoma.structure.AMS_OPTION.m_nGenerationAddPointGap:int
        return v0;
    }

    public int getM_nGenerationExceptMaxLength() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nGenerationExceptMaxLength; // com.sec.amsoma.structure.AMS_OPTION.m_nGenerationExceptMaxLength:int
        return v0;
    }

    public int getM_nGenerationExceptMinLength() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nGenerationExceptMinLength; // com.sec.amsoma.structure.AMS_OPTION.m_nGenerationExceptMinLength:int
        return v0;
    }

    public int getM_nImageBPP() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nImageBPP; // com.sec.amsoma.structure.AMS_OPTION.m_nImageBPP:int
        return v0;
    }

    public int getM_nMaxPageNum() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nMaxPageNum; // com.sec.amsoma.structure.AMS_OPTION.m_nMaxPageNum:int
        return v0;
    }

    public boolean isM_bBGROrder() {
        // Registers (2 total): v1 = this
        v0 = v1.m_bBGROrder; // com.sec.amsoma.structure.AMS_OPTION.m_bBGROrder:boolean
        return v0;
    }

    public void setM_bBGROrder(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        v0.m_bBGROrder = v1; // com.sec.amsoma.structure.AMS_OPTION.m_bBGROrder:boolean
        return;
    }

    public void setM_eSamplingOption(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_eSamplingOption = v1; // com.sec.amsoma.structure.AMS_OPTION.m_eSamplingOption:int
        return;
    }

    public void setM_eSmoothingOption(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_eSmoothingOption = v1; // com.sec.amsoma.structure.AMS_OPTION.m_eSmoothingOption:int
        return;
    }

    public void setM_fGenerationCurvature(float p0) {
        // Registers (2 total): v0 = this, v1 = p0 (float)
        v0.m_fGenerationCurvature = v1; // com.sec.amsoma.structure.AMS_OPTION.m_fGenerationCurvature:float
        return;
    }

    public void setM_fSimplificationTolerance(float p0) {
        // Registers (2 total): v0 = this, v1 = p0 (float)
        v0.m_fSimplificationTolerance = v1; // com.sec.amsoma.structure.AMS_OPTION.m_fSimplificationTolerance:float
        return;
    }

    public void setM_nGenerationAddPointGap(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nGenerationAddPointGap = v1; // com.sec.amsoma.structure.AMS_OPTION.m_nGenerationAddPointGap:int
        return;
    }

    public void setM_nGenerationExceptMaxLength(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nGenerationExceptMaxLength = v1; // com.sec.amsoma.structure.AMS_OPTION.m_nGenerationExceptMaxLength:int
        return;
    }

    public void setM_nGenerationExceptMinLength(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nGenerationExceptMinLength = v1; // com.sec.amsoma.structure.AMS_OPTION.m_nGenerationExceptMinLength:int
        return;
    }

    public void setM_nImageBPP(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nImageBPP = v1; // com.sec.amsoma.structure.AMS_OPTION.m_nImageBPP:int
        return;
    }

    public void setM_nMaxPageNum(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nMaxPageNum = v1; // com.sec.amsoma.structure.AMS_OPTION.m_nMaxPageNum:int
        return;
    }

}