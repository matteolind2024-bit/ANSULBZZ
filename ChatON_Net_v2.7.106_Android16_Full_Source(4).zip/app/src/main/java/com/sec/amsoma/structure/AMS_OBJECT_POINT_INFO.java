package com.sec.amsoma.structure;

/**
 * Original SourceFile: AMS_OBJECT_POINT_INFO.java
 * Descriptor: Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;
 */
public class AMS_OBJECT_POINT_INFO {
     boolean m_bPressureFlag;
     int m_nPointNum;
     int m_nSimpleNum;
     char[] m_pcSimpleFlag;
     short[] m_pnAMSPointPressure;
     short[] m_pnAMSPointX;
     short[] m_pnAMSPointY;

    public AMS_OBJECT_POINT_INFO() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean getM_bPressureFlag() {
        // Registers (2 total): v1 = this
        v0 = v1.m_bPressureFlag; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_bPressureFlag:boolean
        return v0;
    }

    public int getM_nPointNum() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nPointNum; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_nPointNum:int
        return v0;
    }

    public int getM_nSimpleNum() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nSimpleNum; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_nSimpleNum:int
        return v0;
    }

    public char getM_pcSimpleFlag(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.m_pcSimpleFlag; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pcSimpleFlag:char[]
        v0 = v0.length;
        if (v2 >= v0) /* goto L_000a */;
        v0 = v1.m_pcSimpleFlag; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pcSimpleFlag:char[]
        v0 = v0[v2];
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public char[] getM_pcSimpleFlag() {
        // Registers (2 total): v1 = this
        v0 = v1.m_pcSimpleFlag; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pcSimpleFlag:char[]
        return v0;
    }

    public short getM_pnAMSPointPressure(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.m_pnAMSPointPressure; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointPressure:short[]
        v0 = v0.length;
        if (v2 >= v0) /* goto L_000a */;
        v0 = v1.m_pnAMSPointPressure; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointPressure:short[]
        v0 = v0[v2];
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public short[] getM_pnAMSPointPressure() {
        // Registers (2 total): v1 = this
        v0 = v1.m_pnAMSPointPressure; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointPressure:short[]
        return v0;
    }

    public short getM_pnAMSPointX(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.m_pnAMSPointX; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointX:short[]
        v0 = v0.length;
        if (v2 >= v0) /* goto L_000a */;
        v0 = v1.m_pnAMSPointX; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointX:short[]
        v0 = v0[v2];
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public short[] getM_pnAMSPointX() {
        // Registers (2 total): v1 = this
        v0 = v1.m_pnAMSPointX; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointX:short[]
        return v0;
    }

    public short getM_pnAMSPointY(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.m_pnAMSPointY; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointY:short[]
        v0 = v0.length;
        if (v2 >= v0) /* goto L_000a */;
        v0 = v1.m_pnAMSPointY; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointY:short[]
        v0 = v0[v2];
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public short[] getM_pnAMSPointY() {
        // Registers (2 total): v1 = this
        v0 = v1.m_pnAMSPointY; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointY:short[]
        return v0;
    }

    public void setM_bPressureFlag(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        v0.m_bPressureFlag = v1; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_bPressureFlag:boolean
        return;
    }

    public void setM_nPointNum(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nPointNum = v1; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_nPointNum:int
        return;
    }

    public void setM_nSimpleNum(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nSimpleNum = v1; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_nSimpleNum:int
        return;
    }

    public void setM_pcSimpleFlag(char[] p0) {
        // Registers (2 total): v0 = this, v1 = p0 (char[])
        v0.m_pcSimpleFlag = v1; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pcSimpleFlag:char[]
        return;
    }

    public void setM_pnAMSPointPressure(short[] p0) {
        // Registers (2 total): v0 = this, v1 = p0 (short[])
        v0.m_pnAMSPointPressure = v1; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointPressure:short[]
        return;
    }

    public void setM_pnAMSPointX(short[] p0) {
        // Registers (2 total): v0 = this, v1 = p0 (short[])
        v0.m_pnAMSPointX = v1; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointX:short[]
        return;
    }

    public void setM_pnAMSPointY(short[] p0) {
        // Registers (2 total): v0 = this, v1 = p0 (short[])
        v0.m_pnAMSPointY = v1; // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.m_pnAMSPointY:short[]
        return;
    }

}