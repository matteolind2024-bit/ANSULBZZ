package com.sec.amsoma.structure;

/**
 * Original SourceFile: AMS_OBJECT_TEXT_INFO.java
 * Descriptor: Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;
 */
public class AMS_OBJECT_TEXT_INFO {
     int m_nFontFaceLength;
     int m_nTextLength;
     java.lang.String m_strFontFaceName;
     java.lang.String m_strText;

    public AMS_OBJECT_TEXT_INFO() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public char[] getM_cFontFaceName() {
        // Registers (2 total): v1 = this
        v0 = v1.m_strFontFaceName; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_strFontFaceName:java.lang.String
        _result = v0.length(); // java.lang.String.length -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, 1);
        v0 = new char[][size=v0];
        v0 = v1.m_strFontFaceName; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_strFontFaceName:java.lang.String
        _result = v0.toCharArray(); // java.lang.String.toCharArray -> char[]
        v0 = _result;
        return v0;
    }

    public char[] getM_cText() {
        // Registers (2 total): v1 = this
        v0 = v1.m_strText; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_strText:java.lang.String
        _result = v0.length(); // java.lang.String.length -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, 1);
        v0 = new char[][size=v0];
        v0 = v1.m_strText; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_strText:java.lang.String
        _result = v0.toCharArray(); // java.lang.String.toCharArray -> char[]
        v0 = _result;
        return v0;
    }

    public int getM_nFontFaceLength() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nFontFaceLength; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_nFontFaceLength:int
        return v0;
    }

    public int getM_nTextLength() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nTextLength; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_nTextLength:int
        return v0;
    }

    public java.lang.String getM_strFontFaceName() {
        // Registers (2 total): v1 = this
        v0 = v1.m_strFontFaceName; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_strFontFaceName:java.lang.String
        return v0;
    }

    public java.lang.String getM_strText() {
        // Registers (2 total): v1 = this
        v0 = v1.m_strText; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_strText:java.lang.String
        return v0;
    }

    public void setM_nFontFaceLength(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nFontFaceLength = v1; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_nFontFaceLength:int
        return;
    }

    public void setM_nTextLength(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nTextLength = v1; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_nTextLength:int
        return;
    }

    public void setM_strFontFaceName(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.m_strFontFaceName = v1; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_strFontFaceName:java.lang.String
        return;
    }

    public void setM_strText(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.m_strText = v1; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_strText:java.lang.String
        return;
    }

}