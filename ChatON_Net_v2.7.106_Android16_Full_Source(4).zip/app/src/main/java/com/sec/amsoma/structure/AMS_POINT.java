package com.sec.amsoma.structure;

/**
 * Original SourceFile: AMS_POINT.java
 * Descriptor: Lcom/sec/amsoma/structure/AMS_POINT;
 */
public class AMS_POINT {
     short x;
     short y;

    public AMS_POINT() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public short getX() {
        // Registers (2 total): v1 = this
        v0 = v1.x; // com.sec.amsoma.structure.AMS_POINT.x:short
        return v0;
    }

    public short getY() {
        // Registers (2 total): v1 = this
        v0 = v1.y; // com.sec.amsoma.structure.AMS_POINT.y:short
        return v0;
    }

    public void setX(short p0) {
        // Registers (2 total): v0 = this, v1 = p0 (short)
        v0.x = v1; // com.sec.amsoma.structure.AMS_POINT.x:short
        return;
    }

    public void setY(short p0) {
        // Registers (2 total): v0 = this, v1 = p0 (short)
        v0.y = v1; // com.sec.amsoma.structure.AMS_POINT.y:short
        return;
    }

}