package com.sec.amsoma;

/**
 * Original SourceFile: AMSLibs.java
 * Descriptor: Lcom/sec/amsoma/AMSLibs;
 */
public class AMSLibs {
    public static final byte DEF_VIP_AMSLIB_BK_COLOR;
    public static final byte DEF_VIP_AMSLIB_BK_INDEX_IMAGE;
    public static final byte DEF_VIP_AMSLIB_BK_PATTERN;
    public static final byte DEF_VIP_AMSLIB_BK_RAW_IMAGE;
    public static final byte DEF_VIP_AMSLIB_BK_SCREEN_BUF;
    public static final int DEF_VIP_AMS_ANIMATION_TURN_PAGE_EFFECT_BRIGHT_VAR;
    public static final int DEF_VIP_AMS_ANIMATION_TURN_PAGE_EFFECT_SIDE_CURL;
    public static final int DEF_VIP_AMS_ANIMATION_TURN_PAGE_EFFECT_SLIDE_MOVE;
    public static final int DEF_VIP_AMS_ANIMATION_TURN_PAGE_NONE;
    public static final int ENUM_VIP_AMS_AUDIO_BG_INDEX;
    public static final int ENUM_VIP_AMS_AUDIO_BG_MP3;
    public static final int ENUM_VIP_AMS_AUDIO_BG_VOICE;
    public static final int ENUM_VIP_AMS_AUDIO_NONE;
    public static final byte ENUM_VIP_AMS_CB_ERROR_DISK_FULL;
    public static final byte ENUM_VIP_AMS_CB_ERROR_DRAW;
    public static final byte ENUM_VIP_AMS_CB_ERROR_FILE_OPEN;
    public static final byte ENUM_VIP_AMS_CB_ERROR_FILE_READ;
    public static final byte ENUM_VIP_AMS_CB_ERROR_FILE_WRITE;
    public static final byte ENUM_VIP_AMS_CB_ERROR_INVALID_LIB_VERSION;
    public static final byte ENUM_VIP_AMS_CB_ERROR_JPEG_DECODING;
    public static final byte ENUM_VIP_AMS_CB_ERROR_JPEG_ENCODING;
    public static final byte ENUM_VIP_AMS_CB_ERROR_LIMITED_LIB_VERSION;
    public static final byte ENUM_VIP_AMS_CB_ERROR_MEMORY_ALLOC;
    public static final byte ENUM_VIP_AMS_DIAGRAMSTYLE_CIRCLE;
    public static final byte ENUM_VIP_AMS_DIAGRAMSTYLE_CIRCLE_FILL;
    public static final byte ENUM_VIP_AMS_DIAGRAMSTYLE_LINE;
    public static final byte ENUM_VIP_AMS_DIAGRAMSTYLE_RECT;
    public static final byte ENUM_VIP_AMS_DIAGRAMSTYLE_RECT_FILL;
    public static final byte ENUM_VIP_AMS_DIAGRAMSTYLE_TRI;
    public static final byte ENUM_VIP_AMS_DIAGRAMSTYLE_TRI_FILL;
    public static final byte ENUM_VIP_AMS_DIAGRAM_OBJECT_NUM_FULL;
    public static final byte ENUM_VIP_AMS_ERROR_CONVERT_IMAGEBUFFER;
    public static final byte ENUM_VIP_AMS_ERROR_DATA_FULL;
    public static final byte ENUM_VIP_AMS_ERROR_DECODE_BUFFER;
    public static final byte ENUM_VIP_AMS_ERROR_DECODE_DATA;
    public static final byte ENUM_VIP_AMS_ERROR_DECODE_EXIF;
    public static final byte ENUM_VIP_AMS_ERROR_DECODE_HEADER;
    public static final byte ENUM_VIP_AMS_ERROR_DECODE_IMAGE;
    public static final byte ENUM_VIP_AMS_ERROR_DRAW;
    public static final byte ENUM_VIP_AMS_ERROR_ENCODE_DATA;
    public static final byte ENUM_VIP_AMS_ERROR_ENCODE_IMAGE;
    public static final byte ENUM_VIP_AMS_ERROR_INVALID_APP_VERSION;
    public static final byte ENUM_VIP_AMS_ERROR_INVALID_CLIP;
    public static final byte ENUM_VIP_AMS_ERROR_INVALID_DRAWING_DATA;
    public static final byte ENUM_VIP_AMS_ERROR_INVALID_FILEFORMAT;
    public static final byte ENUM_VIP_AMS_ERROR_INVALID_FILEINFO;
    public static final byte ENUM_VIP_AMS_ERROR_INVALID_HEADER;
    public static final byte ENUM_VIP_AMS_ERROR_INVALID_IMAGE_SIZE;
    public static final byte ENUM_VIP_AMS_ERROR_INVALID_INSTANCE;
    public static final byte ENUM_VIP_AMS_ERROR_INVALID_OBJECT_DATA;
    public static final byte ENUM_VIP_AMS_ERROR_INVALID_OBJECT_STYLE;
    public static final byte ENUM_VIP_AMS_ERROR_INVALID_PAGE;
    public static final byte ENUM_VIP_AMS_ERROR_LOAD_JPEGTORAW;
    public static final byte ENUM_VIP_AMS_ERROR_NO;
    public static final byte ENUM_VIP_AMS_ERROR_NOMORE_PLAY_OBJECT;
    public static final byte ENUM_VIP_AMS_ERROR_NOT_READY;
    public static final byte ENUM_VIP_AMS_ERROR_OBJECT_ALLOC;
    public static final byte ENUM_VIP_AMS_ERROR_OBJECT_IMAGE_NUM_FULL;
    public static final byte ENUM_VIP_AMS_ERROR_OBJECT_PROPERTY_SETTING;
    public static final byte ENUM_VIP_AMS_ERROR_OBJECT_START_SETTING;
    public static final byte ENUM_VIP_AMS_ERROR_POINT_FULL;
    public static final byte ENUM_VIP_AMS_ERROR_SAVE_FLASH;
    public static final byte ENUM_VIP_AMS_ERROR_STRING_LENGTH;
    public static final byte ENUM_VIP_AMS_ERROR_TURN_PAGE;
    public static final byte ENUM_VIP_AMS_ERROR_UNDEFINED;
    public static final byte ENUM_VIP_AMS_ERROR_UNDO_REDO;
    public static final byte ENUM_VIP_AMS_ERROR_USERIMAGE_ID_FULL;
    public static final byte ENUM_VIP_AMS_ERROR_USERIMAGE_TRANSMIT_FULL;
    public static final byte ENUM_VIP_AMS_ERROR_ZOOM_INVALID_NEXTREGION;
    public static final byte ENUM_VIP_AMS_PENSTYLE_CRAYON;
    public static final byte ENUM_VIP_AMS_PENSTYLE_DOTLINE;
    public static final byte ENUM_VIP_AMS_PENSTYLE_PENCIL;
    public static final byte ENUM_VIP_AMS_PENSTYLE_SHINY;
    public static final byte ENUM_VIP_AMS_PENSTYLE_TRANSPARENT;
    public static final byte ENUM_VIP_AMS_PEN_OBJECT_NUM_FULL;
    public static final int ENUM_VIP_AMS_SAVE_THUMBNAIL_IMAGE_SIZE;
    public static final byte ENUM_VIP_AMS_SAVE_USER_STAMPSIZE;
    public static final byte ENUM_VIP_AMS_STAMPSIZE_NORMAL;
    public static final byte ENUM_VIP_AMS_STAMPSIZE_SMALL;
    public static final byte ENUM_VIP_AMS_STAMPSIZE_UNDEFINED;
    public static final byte ENUM_VIP_AMS_STAMPSTYLE_ANIMATION;
    public static final byte ENUM_VIP_AMS_STAMPSTYLE_BASIC;
    public static final byte ENUM_VIP_AMS_STAMPSTYLE_USER;
    public static final byte ENUM_VIP_AMS_STAMPSTYLE_USER_CIRCLE;
    public static final byte ENUM_VIP_AMS_STAMPSTYLE_USER_HEART;
    public static final byte ENUM_VIP_AMS_STAMPSTYLE_USER_RECT;
    public static final byte ENUM_VIP_AMS_STAMPSTYLE_USER_STAR;
    public static final byte ENUM_VIP_AMS_STAMP_OBJECT_NUM_FULL;
    public static final byte ENUM_VIP_AMS_TEXTSIZE_LARGE;
    public static final byte ENUM_VIP_AMS_TEXTSIZE_NORMAL;
    public static final byte ENUM_VIP_AMS_TEXTSIZE_SMALL;
    public static final byte ENUM_VIP_AMS_TEXT_OBJECT_NUM_FULL;
    public static final byte ENUM_VIP_AMS_TYPE_DIAGRAM;
    public static final byte ENUM_VIP_AMS_TYPE_PEN;
    public static final byte ENUM_VIP_AMS_TYPE_STAMP;
    public static final byte ENUM_VIP_AMS_TYPE_TEXT;
    public static final byte ENUM_VIP_AMS_TYPE_UNDEFINED;
    public static final int ENUM_VIP_AMS_UNDO_REDO_DRAW_ALL;
    public static final int ENUM_VIP_AMS_UNDO_REDO_ERROR;
    public static final int ENUM_VIP_AMS_UNDO_REDO_UPDATE;
    public static final byte ENUM_VIP_AMS_WQVGA_DRAW_BASIC_STAMPSIZE;
    public static final byte ENUM_VIP_AMS_WQVGA_DRAW_USER_STAMPSIZE_LARGE;
    public static final byte ENUM_VIP_AMS_WQVGA_DRAW_USER_STAMPSIZE_SMALL;
    public static final int ENUM_VIP_AMS_WQVGA_SAVE_USER_STAMPIMAGE_SIZE;
    public static final byte ENUM_VIP_AMS_WVGA_DRAW_BASIC_STAMPSIZE;
    public static final byte ENUM_VIP_AMS_WVGA_DRAW_USER_STAMPSIZE_LARGE;
    public static final byte ENUM_VIP_AMS_WVGA_DRAW_USER_STAMPSIZE_SMALL;
    public static int g_nCurObjectImageBPP;
    public static int g_nCurObjectImageHeight;
    public static int g_nCurObjectImageWidth;
    public static int g_nCurrentBackgroundBPP;
    public static int g_nCurrentBackgroundHeight;
    public static int g_nCurrentBackgroundWidth;
    public static int g_nNumTotalObject;
    public static int g_nNumTotalPenPoint;
    public static int g_nTextHeight;
    public static int g_nTextWidth;
    public com.sec.amsoma.structure.AMS_UI_DATA UIData;

    static {
        v0 = "AMSWiFiLibs-1.0.5";
        _result = v0.loadLibrary(); // java.lang.System.loadLibrary -> void
        return;
        v0 = _exception;
        v1 = java.lang.System.err; // :java.io.PrintStream
        _result = v1.println(v0); // java.io.PrintStream.println -> void
        // goto L_0005
    }

    public AMSLibs() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new com.sec.amsoma.structure.AMS_UI_DATA;
        _result = v0.<init>(); // com.sec.amsoma.structure.AMS_UI_DATA.<init> -> void
        v1.UIData = v0; // com.sec.amsoma.AMSLibs.UIData:com.sec.amsoma.structure.AMS_UI_DATA
        return;
    }

    public static java.nio.IntBuffer makeBuffer(int[] p0, int p1, int p2) {
        // Registers (4 total): v1 = p0 (int[]), v2 = p1 (int), v3 = p2 (int)
        v0 = binOp_0x92(v2, v3);
        _result = v0.allocate(); // java.nio.IntBuffer.allocate -> java.nio.IntBuffer
        v0 = _result;
        _result = v0.put(v1); // java.nio.IntBuffer.put -> java.nio.IntBuffer
        _result = v0.rewind(); // java.nio.IntBuffer.rewind -> java.nio.Buffer
        return v0;
    }

    public void Callback_deleteTempFile(byte[] p0) {
        // Registers (4 total): v2 = this, v3 = p0 (byte[])
        v0 = new java.lang.String;
        _result = v0.<init>(v3); // java.lang.String.<init> -> void
        v1 = new java.io.File;
        _result = v1.<init>(v0); // java.io.File.<init> -> void
        _result = v1.isFile(); // java.io.File.isFile -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0013 */;
        _result = v1.delete(); // java.io.File.delete -> boolean
        if (v1 == 0) /* goto L_0015 */;
        return;
    }

    public int Callback_loadImageFileToRawImage(byte[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (byte[])
        v0 = new java.lang.String;
        _result = v0.<init>(v2); // java.lang.String.<init> -> void
        _result = v1.loadImageFileToRawImage(v0); // com.sec.amsoma.AMSLibs.loadImageFileToRawImage -> int
        v0 = _result;
        return v0;
    }

    public int Callback_loadImageStreamToRawImage(byte[] p0, byte[] p1, int p2) {
        // Registers (7 total): v3 = this, v4 = p0 (byte[]), v5 = p1 (byte[]), v6 = p2 (int)
        _result = v3.Callback_deleteTempFile(v4); // com.sec.amsoma.AMSLibs.Callback_deleteTempFile -> void
        v1 = 0;
        v2 = new java.io.File;
        v0 = new java.lang.String;
        _result = v0.<init>(v4); // java.lang.String.<init> -> void
        _result = v2.<init>(v0); // java.io.File.<init> -> void
        v0 = new java.io.FileOutputStream;
        _result = v0.<init>(v2); // java.io.FileOutputStream.<init> -> void
        if (v0 != 0) /* goto L_0018 */;
        v0 = 43;
        return v0;
        v1 = 0;
        _result = v0.write(v5, v1, v6); // java.io.FileOutputStream.write -> void
        if (v0 == 0) /* goto L_0021 */;
        _result = v0.close(); // java.io.FileOutputStream.close -> void
        v0 = new java.lang.String;
        _result = v0.<init>(v4); // java.lang.String.<init> -> void
        _result = v3.loadImageFileToRawImage(v0); // com.sec.amsoma.AMSLibs.loadImageFileToRawImage -> int
        v0 = _result;
        // goto L_0017
        v0 = _exception;
        v0 = v1;
        v1 = "IOException";
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v2.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v2 = _result;
        _result = v1.a(v2); // com.sec.chaton.util.p.a -> void
        // goto L_001c
        v0 = _exception;
        v0 = "IOException";
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v1 = _result;
        _result = v0.a(v1); // com.sec.chaton.util.p.a -> void
        // goto L_0021
        v1 = _exception;
        // goto L_002d
    }

    public int Callback_saveRawImageToImageFile(byte[] p0, int[] p1, int p2, int p3, int p4, int p5, int p6) {
        // Registers (16 total): v8 = this, v9 = p0 (byte[]), v10 = p1 (int[]), v11 = p2 (int), v12 = p3 (int), v13 = p4 (int), v14 = p5 (int), v15 = p6 (int)
        if (v10 != 0) /* goto L_0005 */;
        v0 = 41;
        return v0;
        _result = v8.Callback_deleteTempFile(v9); // com.sec.amsoma.AMSLibs.Callback_deleteTempFile -> void
        v0 = android.graphics.Bitmap$Config.ARGB_8888; // :android.graphics.Bitmap$Config
        _result = v11.createBitmap(v12, v0); // android.graphics.Bitmap.createBitmap -> android.graphics.Bitmap
        v0 = _result;
        v2 = 0;
        v4 = 0;
        v5 = 0;
        v1 = v10;
        v3 = v11;
        v6 = v11;
        v7 = v12;
        _result = v0.setPixels(v0..v7); // android.graphics.Bitmap.setPixels -> void
        v3 = new java.io.File;
        v1 = new java.lang.String;
        _result = v1.<init>(v9); // java.lang.String.<init> -> void
        _result = v3.<init>(v1); // java.io.File.<init> -> void
        v2 = 0;
        v1 = new java.io.FileOutputStream;
        _result = v1.<init>(v3); // java.io.FileOutputStream.<init> -> void
        if (v1 != 0) /* goto L_0036 */;
        v0 = 41;
        if (v1 == 0) /* goto L_0004 */;
        _result = v1.close(); // java.io.FileOutputStream.close -> void
        // goto L_0004
        v0 = _exception;
        v0 = 41;
        // goto L_0004
        if (v15 != 0) /* goto L_004a */;
        v2 = android.graphics.Bitmap$CompressFormat.JPEG; // :android.graphics.Bitmap$CompressFormat
        _result = v0.compress(v2, v14, v1); // android.graphics.Bitmap.compress -> boolean
        _result = v0.recycle(); // android.graphics.Bitmap.recycle -> void
        _result = this.gc(); // java.lang.System.gc -> void
        if (v1 == 0) /* goto L_0048 */;
        _result = v1.close(); // java.io.FileOutputStream.close -> void
        v0 = 0;
        // goto L_0004
        v2 = 1;
        if (v15 != v2) /* goto L_0063 */;
        v2 = android.graphics.Bitmap$CompressFormat.PNG; // :android.graphics.Bitmap$CompressFormat
        _result = v0.compress(v2, v14, v1); // android.graphics.Bitmap.compress -> boolean
        // goto L_003d
        v0 = _exception;
        _result = v0.printStackTrace(); // java.io.FileNotFoundException.printStackTrace -> void
        v0 = 41;
        if (v1 == 0) /* goto L_0004 */;
        _result = v1.close(); // java.io.FileOutputStream.close -> void
        // goto L_0004
        v0 = _exception;
        v0 = 41;
        // goto L_0004
        v2 = android.graphics.Bitmap$CompressFormat.JPEG; // :android.graphics.Bitmap$CompressFormat
        _result = v0.compress(v2, v14, v1); // android.graphics.Bitmap.compress -> boolean
        // goto L_003d
        v0 = _exception;
        if (v1 == 0) /* goto L_006f */;
        _result = v1.close(); // java.io.FileOutputStream.close -> void
        throw v0;
        v0 = _exception;
        v0 = 41;
        // goto L_0004
        v0 = _exception;
        v0 = 41;
        // goto L_0004
        v0 = _exception;
        v1 = v2;
        // goto L_006a
        v0 = _exception;
        v1 = v2;
        // goto L_0054
    }

    public int Callback_saveRawImageToJPEGFileWithLimitSize(byte[] p0, int[] p1, int p2, int p3, int p4, int p5, int p6) {
        // Registers (18 total): v10 = this, v11 = p0 (byte[]), v12 = p1 (int[]), v13 = p2 (int), v14 = p3 (int), v15 = p4 (int), v16 = p5 (int), v17 = p6 (int)
        v1 = 0;
        _result = v10.Callback_deleteTempFile(v11); // com.sec.amsoma.AMSLibs.Callback_deleteTempFile -> void
        v9 = v1;
        v7 = v16;
        v8 = 0;
        v1 = v10;
        v2 = v11;
        v3 = v12;
        v4 = v13;
        v5 = v14;
        v6 = v15;
        _result = v1.Callback_saveRawImageToImageFile(v1..v8); // com.sec.amsoma.AMSLibs.Callback_saveRawImageToImageFile -> int
        v1 = _result;
        if (v1 == 0) /* goto L_0015 */;
        return v1;
        v1 = new java.io.File;
        v2 = new java.lang.String;
        _result = v2.<init>(v11); // java.lang.String.<init> -> void
        _result = v1.<init>(v2); // java.io.File.<init> -> void
        v2 = new java.io.FileInputStream;
        _result = v2.<init>(v1); // java.io.FileInputStream.<init> -> void
        if (v2 == 0) /* goto L_0029 */;
        _result = v2.close(); // java.io.FileInputStream.close -> void
        if (v1 == 0) /* goto L_0066 */;
        _result = v1.length(); // java.io.File.length -> long
        v1 = _result;
        v1 = unaryOp_0x84(v1);
        v0 = v17;
        if (v1 >= v0) /* goto L_003d */;
        v2 = 0;
        v3 = 43;
        if (v2 == v3) /* goto L_003b */;
        if (v1 != 0) /* goto L_0062 */;
        v1 = v2;
        // goto L_0014
        _result = v10.Callback_deleteTempFile(v11); // com.sec.amsoma.AMSLibs.Callback_deleteTempFile -> void
        v2 = 30;
        if (v7 > v2) /* goto L_004c */;
        v7 = binOpLit8_0xd8(v7, -5);
        v2 = 5;
        if (v7 >= v2) /* goto L_004f */;
        v2 = 43;
        // goto L_0035
        v7 = binOpLit8_0xd8(v7, -10);
        // goto L_0046
        v9 = v1;
        // goto L_0007
        v1 = _exception;
        v1 = v9;
        v2 = "IOException";
        _result = v10.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        _result = v3.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v3 = _result;
        _result = v2.a(v3); // com.sec.chaton.util.p.a -> void
        v9 = v1;
        // goto L_0007
        v1 = v2;
        // goto L_0014
        v2 = _exception;
        // goto L_0053
        v1 = v9;
        // goto L_0030
    }

    public boolean Callback_writeData(byte[] p0, int p1, byte[] p2) {
        // Registers (11 total): v7 = this, v8 = p0 (byte[]), v9 = p1 (int), v10 = p2 (byte[])
        v0 = 0;
        if (v8 == 0) /* goto L_0005 */;
        if (v10 != 0) /* goto L_0006 */;
        return v0;
        v3 = 0;
        v1 = new java.lang.String;
        _result = v1.<init>(v8); // java.lang.String.<init> -> void
        v2 = new java.io.RandomAccessFile;
        v4 = "rw";
        _result = v2.<init>(v1, v4); // java.io.RandomAccessFile.<init> -> void
        if (v2 != 0) /* goto L_0020 */;
        if (v2 == 0) /* goto L_0005 */;
        _result = v2.close(); // java.io.RandomAccessFile.close -> void
        // goto L_0005
        v1 = _exception;
        _result = v1.printStackTrace(); // java.io.IOException.printStackTrace -> void
        // goto L_0005
        if (v9 < 0) /* goto L_0032 */;
        v3 = unaryOp_0x81(v9);
        _result = v2.length(); // java.io.RandomAccessFile.length -> long
        v5 = _result;
        v1 = cmp(v3, v5);
        if (v1 >= 0) /* goto L_0032 */;
        v3 = unaryOp_0x81(v9);
        _result = v2.seek(v3, v4); // java.io.RandomAccessFile.seek -> void
        _result = v2.write(v10); // java.io.RandomAccessFile.write -> void
        if (v2 == 0) /* goto L_0037 */;
        _result = v2.close(); // java.io.RandomAccessFile.close -> void
        v0 = 1;
        // goto L_0005
        v0 = _exception;
        _result = v0.printStackTrace(); // java.io.IOException.printStackTrace -> void
        // goto L_0037
        v1 = _exception;
        v2 = v3;
        _result = v1.printStackTrace(); // java.io.IOException.printStackTrace -> void
        if (v2 == 0) /* goto L_0005 */;
        _result = v2.close(); // java.io.RandomAccessFile.close -> void
        // goto L_0005
        v1 = _exception;
        _result = v1.printStackTrace(); // java.io.IOException.printStackTrace -> void
        // goto L_0005
        v0 = _exception;
        if (v3 == 0) /* goto L_0054 */;
        _result = v3.close(); // java.io.RandomAccessFile.close -> void
        throw v0;
        v1 = _exception;
        _result = v1.printStackTrace(); // java.io.IOException.printStackTrace -> void
        // goto L_0054
        v0 = _exception;
        v3 = v2;
        // goto L_004f
        v1 = _exception;
        // goto L_0040
    }

    public int Convert565(int p0, int p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (int), v5 = p2 (int)
        v0 = binOpLit8_0xda(v3, 31);
        v0 = binOpLit8_0xd8(v0, 127);
        v0 = binOpLit16_0xd3(v0, 255);
        v0 = binOpLit8_0xe0(v0, 11);
        v1 = binOpLit8_0xda(v4, 63);
        v1 = binOpLit8_0xd8(v1, 127);
        v1 = binOpLit16_0xd3(v1, 255);
        v1 = binOpLit8_0xe0(v1, 5);
        v0 = binOp2addr_0xb6(v0, v1);
        v1 = binOpLit8_0xda(v5, 31);
        v1 = binOpLit8_0xd8(v1, 127);
        v1 = binOpLit16_0xd3(v1, 255);
        v0 = binOp2addr_0xb6(v0, v1);
        return v0;
    }

    public void GetAnimationObjectInfo(int p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (int), v2 = p1 (int)
        com.sec.amsoma.AMSLibs.g_nNumTotalPenPoint = v1; // :int
        com.sec.amsoma.AMSLibs.g_nNumTotalObject = v2; // :int
        return;
    }

    public int GetBValue(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = binOpLit8_0xe1(v2, 0);
        v0 = binOpLit16_0xd5(v0, 255);
        return v0;
    }

    public void GetCurObjectImageBufInfo(int p0, int p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (int), v2 = p1 (int), v3 = p2 (int)
        com.sec.amsoma.AMSLibs.g_nCurObjectImageWidth = v1; // :int
        com.sec.amsoma.AMSLibs.g_nCurObjectImageHeight = v2; // :int
        com.sec.amsoma.AMSLibs.g_nCurObjectImageBPP = v3; // :int
        return;
    }

    public void GetCurrentBackgroundBufInfo(int p0, int p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (int), v2 = p1 (int), v3 = p2 (int)
        com.sec.amsoma.AMSLibs.g_nCurrentBackgroundWidth = v1; // :int
        com.sec.amsoma.AMSLibs.g_nCurrentBackgroundHeight = v2; // :int
        com.sec.amsoma.AMSLibs.g_nCurrentBackgroundBPP = v3; // :int
        return;
    }

    public int GetGValue(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = binOpLit8_0xe1(v2, 8);
        v0 = binOpLit16_0xd5(v0, 255);
        return v0;
    }

    public int GetRValue(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = binOpLit8_0xe1(v2, 16);
        v0 = binOpLit16_0xd5(v0, 255);
        return v0;
    }

    public boolean NewEncoding(int p0, com.sec.amsoma.structure.AMS_UI_DATA p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (com.sec.amsoma.structure.AMS_UI_DATA)
        v2.UIData = v4; // com.sec.amsoma.AMSLibs.UIData:com.sec.amsoma.structure.AMS_UI_DATA
        v0 = new com.sec.amsoma.structure.AMS_OBJECT_DATA;
        _result = v0.<init>(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.<init> -> void
        v1 = v2.UIData; // com.sec.amsoma.AMSLibs.UIData:com.sec.amsoma.structure.AMS_UI_DATA
        v1 = v1.m_cObjectSize; // com.sec.amsoma.structure.AMS_UI_DATA.m_cObjectSize:byte
        _result = v0.setM_cSize(v1); // com.sec.amsoma.structure.AMS_OBJECT_DATA.setM_cSize -> void
        v1 = v2.UIData; // com.sec.amsoma.AMSLibs.UIData:com.sec.amsoma.structure.AMS_UI_DATA
        v1 = v1.m_cObjectStyle; // com.sec.amsoma.structure.AMS_UI_DATA.m_cObjectStyle:byte
        _result = v0.setM_cStyle(v1); // com.sec.amsoma.structure.AMS_OBJECT_DATA.setM_cStyle -> void
        v1 = v2.UIData; // com.sec.amsoma.AMSLibs.UIData:com.sec.amsoma.structure.AMS_UI_DATA
        v1 = v1.m_rgbPen; // com.sec.amsoma.structure.AMS_UI_DATA.m_rgbPen:int
        _result = v2.GetRValue(v1); // com.sec.amsoma.AMSLibs.GetRValue -> int
        v1 = _result;
        _result = v0.setM_nColorR(v1); // com.sec.amsoma.structure.AMS_OBJECT_DATA.setM_nColorR -> void
        v1 = v2.UIData; // com.sec.amsoma.AMSLibs.UIData:com.sec.amsoma.structure.AMS_UI_DATA
        v1 = v1.m_rgbPen; // com.sec.amsoma.structure.AMS_UI_DATA.m_rgbPen:int
        _result = v2.GetGValue(v1); // com.sec.amsoma.AMSLibs.GetGValue -> int
        v1 = _result;
        _result = v0.setM_nColorG(v1); // com.sec.amsoma.structure.AMS_OBJECT_DATA.setM_nColorG -> void
        v1 = v2.UIData; // com.sec.amsoma.AMSLibs.UIData:com.sec.amsoma.structure.AMS_UI_DATA
        v1 = v1.m_rgbPen; // com.sec.amsoma.structure.AMS_UI_DATA.m_rgbPen:int
        _result = v2.GetBValue(v1); // com.sec.amsoma.AMSLibs.GetBValue -> int
        v1 = _result;
        _result = v0.setM_nColorB(v1); // com.sec.amsoma.structure.AMS_OBJECT_DATA.setM_nColorB -> void
        v1 = v2.UIData; // com.sec.amsoma.AMSLibs.UIData:com.sec.amsoma.structure.AMS_UI_DATA
        v1 = v1.m_rectRegion; // com.sec.amsoma.structure.AMS_UI_DATA.m_rectRegion:com.sec.amsoma.structure.AMS_RECT
        _result = v2.VipAMS_TotalNewEncoding(v3, v1, v0); // com.sec.amsoma.AMSLibs.VipAMS_TotalNewEncoding -> boolean
        v0 = _result;
        return v0;
    }

    public native boolean VipAMS_AddFrame(int p0);
    public native boolean VipAMS_AddObjectImage(int p0, byte p1, int[] p2, int p3, int p4, int p5, short p6);
    public native boolean VipAMS_AnimationEnd(int p0);
    public native boolean VipAMS_AnimationNext(int p0);
    public native boolean VipAMS_AnimationStart(int p0);
    public native boolean VipAMS_Blur(int[] p0, int p1, int p2, int p3);
    public native boolean VipAMS_Bright(int[] p0, int p1, int p2);
    public native boolean VipAMS_CancelSelect(int p0);
    public native boolean VipAMS_ChangeSelectDiagram(int p0, com.sec.amsoma.structure.AMS_SELECT_OBJECT p1, com.sec.amsoma.structure.AMS_RECT p2, byte p3);
    public native boolean VipAMS_ChangeSelectStamp(int p0, com.sec.amsoma.structure.AMS_SELECT_OBJECT p1, com.sec.amsoma.structure.AMS_RECT p2, int p3, int p4);
    public native boolean VipAMS_ChangeSelectText(int p0, com.sec.amsoma.structure.AMS_SELECT_OBJECT p1, com.sec.amsoma.structure.AMS_RECT p2, byte p3, char[] p4, short p5, char[] p6, short p7);
    public native boolean VipAMS_ClearEncoding(int p0);
    public native void VipAMS_Close(int p0);
    public native boolean VipAMS_Dark(int[] p0, int p1, int p2);
    public native boolean VipAMS_DeleteSelectObject(int p0, com.sec.amsoma.structure.AMS_SELECT_OBJECT p1);
    public native boolean VipAMS_EncodeNewDiagram(int p0, com.sec.amsoma.structure.AMS_RECT p1, byte p2);
    public native int VipAMS_EncodeNewMultiImage(int p0, com.sec.amsoma.structure.AMS_RECT p1, byte p2, byte p3);
    public native boolean VipAMS_EncodeNewStamp(int p0, com.sec.amsoma.structure.AMS_RECT p1, byte p2, byte p3, byte p4, int[] p5, int p6, int p7, int p8);
    public native boolean VipAMS_EncodeNewText(int p0, com.sec.amsoma.structure.AMS_RECT p1, byte p2, char[] p3, short p4, char[] p5, short p6);
    public native boolean VipAMS_EncodePointData(int p0, short p1, short p2, short p3);
    public native boolean VipAMS_EncodeStrokeEnd(int p0);
    public native boolean VipAMS_EncodeStrokeStart(int p0);
    public native boolean VipAMS_GetAnimationInfo(int p0);
    public native byte[] VipAMS_GetBGAudioFile(int p0);
    public native int VipAMS_GetBGAudioStyle(int p0);
    public native int VipAMS_GetBGMIndex(int p0);
    public native int VipAMS_GetBackgroundColorA(int p0);
    public native int VipAMS_GetBackgroundColorB(int p0);
    public native int VipAMS_GetBackgroundColorG(int p0);
    public native int VipAMS_GetBackgroundColorR(int p0);
    public native byte VipAMS_GetBackgroundIndex(int p0);
    public native int VipAMS_GetBackgroundStyle(int p0);
    public native int VipAMS_GetCodingHeight(int p0);
    public native int VipAMS_GetCodingWidth(int p0);
    public native int VipAMS_GetCurObjectColorA(int p0);
    public native int VipAMS_GetCurObjectColorB(int p0);
    public native int VipAMS_GetCurObjectColorG(int p0);
    public native int VipAMS_GetCurObjectColorR(int p0);
    public native byte VipAMS_GetCurObjectSize(int p0);
    public native byte VipAMS_GetCurObjectStyle(int p0);
    public native byte VipAMS_GetCurObjectType(int p0);
    public native int[] VipAMS_GetCurrentBackgroundBuf(int p0);
    public native int VipAMS_GetCurrentFrame(int p0);
    public native int VipAMS_GetErrorCode(int p0);
    public native void VipAMS_GetFileStreamInfo(byte[] p0, int p1);
    public native int VipAMS_GetFreeSpace(int p0);
    public native boolean VipAMS_GetImageInfo(int[] p0, int p1, int p2, int p3);
    public native int VipAMS_GetLastFrame(int p0);
    public native java.lang.String VipAMS_GetLibVersion(int p0);
    public native int VipAMS_GetNextDrawingData(int p0, int p1, com.sec.amsoma.structure.AMS_OBJECT_DATA p2);
    public native int VipAMS_GetNextUpdateObject(int p0, int p1, com.sec.amsoma.structure.AMS_OBJECT_DATA p2);
    public native int VipAMS_GetNextUpdateRegion(int p0, int p1, com.sec.amsoma.structure.AMS_RECT p2);
    public int[] VipAMS_GetObjectImageBuf(int p0, com.sec.amsoma.structure.AMS_OBJECT_DATA p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (com.sec.amsoma.structure.AMS_OBJECT_DATA)
        v0 = 0;
        _result = v1.VipAMS_GetObjectImageBuf(v2, v3, v0); // com.sec.amsoma.AMSLibs.VipAMS_GetObjectImageBuf -> int[]
        v0 = _result;
        return v0;
    }

    public native int[] VipAMS_GetObjectImageBuf(int p0, com.sec.amsoma.structure.AMS_OBJECT_DATA p1, byte p2);
    public native int VipAMS_GetObjectImageDuration(int p0, com.sec.amsoma.structure.AMS_OBJECT_DATA p1, byte p2);
    public native int VipAMS_GetObjectImageNum(int p0, com.sec.amsoma.structure.AMS_OBJECT_DATA p1);
    public native int VipAMS_GetObjectIteration(int p0, com.sec.amsoma.structure.AMS_OBJECT_DATA p1);
    public native void VipAMS_GetSelectObjectData(int p0, com.sec.amsoma.structure.AMS_OBJECT_DATA p1);
    public native int VipAMS_GetTotalObjectNum(int p0);
    public native byte VipAMS_GetTurnPageOption(int p0);
    public native boolean VipAMS_GetUIImageBuffer(int[] p0, int p1, int p2);
    public native boolean VipAMS_Gray(int[] p0, int p1, int p2);
    public native void VipAMS_Init();
    public native int VipAMS_IsAMSJPEGFile(com.sec.amsoma.structure.AMS_UI_DATA p0, com.sec.amsoma.structure.AMS_CODING_FILE_INFO[] p1);
    public native boolean VipAMS_IsAnimationEnable(int p0);
    public native boolean VipAMS_IsEditEnable(int p0);
    public native boolean VipAMS_IsEnableRedo(int p0);
    public native boolean VipAMS_IsEnableUndo(int p0);
    public native boolean VipAMS_Negative(int[] p0, int p1, int p2);
    public native int VipAMS_Open(com.sec.amsoma.structure.AMS_OPTION p0);
    public native boolean VipAMS_PencilSketch(int[] p0, int p1, int p2);
    public native int VipAMS_Redo(int p0);
    public native boolean VipAMS_RemoveFrame(int p0, byte p1);
    public native boolean VipAMS_SelectObject(int p0, int p1, int p2, com.sec.amsoma.structure.AMS_SELECT_OBJECT p3, int p4);
    public native boolean VipAMS_Sepia(int[] p0, int p1, int p2);
    public native int VipAMS_SetAMSImageBuf(int p0, int[] p1, int p2, int p3);
    public native boolean VipAMS_SetBGAudioFile(int p0, byte[] p1, int p2);
    public native boolean VipAMS_SetBGAudioStyle(int p0, int p1);
    public native boolean VipAMS_SetBGMIndex(int p0, int p1);
    public native boolean VipAMS_SetBackgroundColor(int p0, int p1, int p2, int p3);
    public native boolean VipAMS_SetBackgroundIndex(int p0, byte p1);
    public native boolean VipAMS_SetBackgroundRawImage(int p0, int[] p1, int p2, int p3, int p4);
    public native boolean VipAMS_SetCurObjectColor(int p0, int p1, int p2, int p3);
    public native boolean VipAMS_SetCurObjectSize(int p0, byte p1);
    public native boolean VipAMS_SetCurObjectStyle(int p0, byte p1);
    public native boolean VipAMS_SetCurObjectType(int p0, byte p1);
    public native boolean VipAMS_SetCurrentFrame(int p0, byte p1);
    public native boolean VipAMS_SetEditEnable(int p0, boolean p1);
    public native boolean VipAMS_SetNextFrame(int p0);
    public native boolean VipAMS_SetPrevFrame(int p0);
    public native boolean VipAMS_SetTempFilePath(byte[] p0, int p1);
    public native boolean VipAMS_SetTurnPageOption(int p0, byte p1);
    public native int VipAMS_TotalEndEncoding(int p0, com.sec.amsoma.structure.AMS_CODING_FILE_INFO[] p1);
    public native int VipAMS_TotalLoadEncodingFile(int p0, com.sec.amsoma.structure.AMS_CODING_FILE_INFO[] p1, com.sec.amsoma.structure.AMS_RECT p2);
    public native boolean VipAMS_TotalNewEncoding(int p0, com.sec.amsoma.structure.AMS_RECT p1, com.sec.amsoma.structure.AMS_OBJECT_DATA p2);
    public native int VipAMS_TotalSaveEncoding(int p0, com.sec.amsoma.structure.AMS_CODING_FILE_INFO[] p1);
    public native int VipAMS_Undo(int p0);
    public com.sec.amsoma.structure.AMS_UI_DATA getUIData() {
        // Registers (2 total): v1 = this
        v0 = v1.UIData; // com.sec.amsoma.AMSLibs.UIData:com.sec.amsoma.structure.AMS_UI_DATA
        return v0;
    }

    public int loadImageFileToRawImage(java.lang.String p0) {
        // Registers (12 total): v10 = this, v11 = p0 (java.lang.String)
        v8 = 41;
        v2 = 0;
        v0 = new android.graphics.BitmapFactory$Options;
        _result = v0.<init>(); // android.graphics.BitmapFactory$Options.<init> -> void
        v0.inDither = v2; // android.graphics.BitmapFactory$Options.inDither:boolean
        _result = v11.decodeFile(v0); // android.graphics.BitmapFactory.decodeFile -> android.graphics.Bitmap
        v0 = _result;
        _result = v0.getWidth(); // android.graphics.Bitmap.getWidth -> int
        v3 = _result;
        _result = v0.getHeight(); // android.graphics.Bitmap.getHeight -> int
        v7 = _result;
        v9 = 32;
        v1 = binOp_0x92(v3, v7);
        v1 = new int[][size=v1];
        v4 = v2;
        v5 = v2;
        v6 = v3;
        _result = v0.getPixels(v0..v7); // android.graphics.Bitmap.getPixels -> void
        _result = v0.recycle(); // android.graphics.Bitmap.recycle -> void
        if (v1 != 0) /* goto L_0030 */;
        v2 = v8;
        return v2;
        v1 = _exception;
        _result = v0.recycle(); // android.graphics.Bitmap.recycle -> void
        v2 = 45;
        // goto L_0028
        _result = v10.VipAMS_GetImageInfo(v1, v3, v7, v9); // com.sec.amsoma.AMSLibs.VipAMS_GetImageInfo -> boolean
        v0 = _result;
        _result = this.gc(); // java.lang.System.gc -> void
        if (v0 != 0) /* goto L_0028 */;
        v2 = v8;
        // goto L_0028
    }

    public void setUIData(com.sec.amsoma.structure.AMS_UI_DATA p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.sec.amsoma.structure.AMS_UI_DATA)
        v0.UIData = v1; // com.sec.amsoma.AMSLibs.UIData:com.sec.amsoma.structure.AMS_UI_DATA
        return;
    }

}