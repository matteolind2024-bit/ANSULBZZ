package com.sec.amsoma.structure;

/**
 * Original SourceFile: AMS_CODING_FILE_INFO.java
 * Descriptor: Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;
 */
public class AMS_CODING_FILE_INFO {
    public int m_eExportType;
    public int m_nCurPageIndex;
    public int m_nMessageID;
    public int m_nTotalPageNum;
    public java.lang.String m_strFileName;

    public AMS_CODING_FILE_INFO() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int getM_eExportType() {
        // Registers (2 total): v1 = this
        v0 = v1.m_eExportType; // com.sec.amsoma.structure.AMS_CODING_FILE_INFO.m_eExportType:int
        return v0;
    }

    public int getM_nCurPageIndex() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nCurPageIndex; // com.sec.amsoma.structure.AMS_CODING_FILE_INFO.m_nCurPageIndex:int
        return v0;
    }

    public int getM_nMessageID() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nMessageID; // com.sec.amsoma.structure.AMS_CODING_FILE_INFO.m_nMessageID:int
        return v0;
    }

    public int getM_nTotalPageNum() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nTotalPageNum; // com.sec.amsoma.structure.AMS_CODING_FILE_INFO.m_nTotalPageNum:int
        return v0;
    }

    public java.lang.String getM_strFileName() {
        // Registers (2 total): v1 = this
        v0 = v1.m_strFileName; // com.sec.amsoma.structure.AMS_CODING_FILE_INFO.m_strFileName:java.lang.String
        return v0;
    }

    public void setM_eExportType(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_eExportType = v1; // com.sec.amsoma.structure.AMS_CODING_FILE_INFO.m_eExportType:int
        return;
    }

    public void setM_nCurPageIndex(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nCurPageIndex = v1; // com.sec.amsoma.structure.AMS_CODING_FILE_INFO.m_nCurPageIndex:int
        return;
    }

    public void setM_nMessageID(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nMessageID = v1; // com.sec.amsoma.structure.AMS_CODING_FILE_INFO.m_nMessageID:int
        return;
    }

    public void setM_nTotalPageNum(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nTotalPageNum = v1; // com.sec.amsoma.structure.AMS_CODING_FILE_INFO.m_nTotalPageNum:int
        return;
    }

    public void setM_strFileName(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.m_strFileName = v1; // com.sec.amsoma.structure.AMS_CODING_FILE_INFO.m_strFileName:java.lang.String
        return;
    }

}