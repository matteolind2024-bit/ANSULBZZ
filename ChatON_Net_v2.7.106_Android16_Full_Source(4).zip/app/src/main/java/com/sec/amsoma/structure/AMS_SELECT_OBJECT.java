package com.sec.amsoma.structure;

/**
 * Original SourceFile: AMS_SELECT_OBJECT.java
 * Descriptor: Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;
 */
public class AMS_SELECT_OBJECT {
     int m_UserStampHeight;
     int[] m_UserStampMemory;
     int m_UserStampWidth;
     int m_nExcludedDrawingBPP;
     int m_nExcludedDrawingHeight;
     int m_nExcludedDrawingWidth;
     int m_nSelectObjectBPP;
     int[] m_pExcludedDrawingMemory;
     int m_pSelectObjectData;
     int m_pSelectObjectNode;

    public AMS_SELECT_OBJECT() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int getM_UserStampHeight() {
        // Registers (2 total): v1 = this
        v0 = v1.m_UserStampHeight; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_UserStampHeight:int
        return v0;
    }

    public int[] getM_UserStampMemory() {
        // Registers (2 total): v1 = this
        v0 = v1.m_UserStampMemory; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_UserStampMemory:int[]
        return v0;
    }

    public int getM_UserStampWidth() {
        // Registers (2 total): v1 = this
        v0 = v1.m_UserStampWidth; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_UserStampWidth:int
        return v0;
    }

    public int getM_nExcludedDrawingBPP() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nExcludedDrawingBPP; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_nExcludedDrawingBPP:int
        return v0;
    }

    public int getM_nExcludedDrawingHeight() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nExcludedDrawingHeight; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_nExcludedDrawingHeight:int
        return v0;
    }

    public int getM_nExcludedDrawingWidth() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nExcludedDrawingWidth; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_nExcludedDrawingWidth:int
        return v0;
    }

    public int getM_nSelectObjectBPP() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nSelectObjectBPP; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_nSelectObjectBPP:int
        return v0;
    }

    public int[] getM_pExcludedDrawingMemory() {
        // Registers (2 total): v1 = this
        v0 = v1.m_pExcludedDrawingMemory; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_pExcludedDrawingMemory:int[]
        return v0;
    }

    public int getM_pSelectObjectData() {
        // Registers (2 total): v1 = this
        v0 = v1.m_pSelectObjectData; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_pSelectObjectData:int
        return v0;
    }

    public int getM_pSelectObjectNode() {
        // Registers (2 total): v1 = this
        v0 = v1.m_pSelectObjectNode; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_pSelectObjectNode:int
        return v0;
    }

    public void setM_UserStampHeight(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_UserStampHeight = v1; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_UserStampHeight:int
        return;
    }

    public void setM_UserStampMemory(int[] p0, int p1, int p2) {
        // Registers (8 total): v4 = this, v5 = p0 (int[]), v6 = p1 (int), v7 = p2 (int)
        v1 = binOp_0x92(v6, v7);
        v0 = new int[][size=v1];
        v4.m_UserStampMemory = v0; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_UserStampMemory:int[]
        v0 = 0;
        if (v0 >= v1) /* goto L_0012 */;
        v2 = v4.m_UserStampMemory; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_UserStampMemory:int[]
        v3 = v5[v0];
        v2[v0] = v3;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0007
        return;
    }

    public void setM_UserStampWidth(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_UserStampWidth = v1; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_UserStampWidth:int
        return;
    }

    public void setM_nExcludedDrawingBPP(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nExcludedDrawingBPP = v1; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_nExcludedDrawingBPP:int
        return;
    }

    public void setM_nExcludedDrawingHeight(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nExcludedDrawingHeight = v1; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_nExcludedDrawingHeight:int
        return;
    }

    public void setM_nExcludedDrawingWidth(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nExcludedDrawingWidth = v1; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_nExcludedDrawingWidth:int
        return;
    }

    public void setM_nSelectObjectBPP(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nSelectObjectBPP = v1; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_nSelectObjectBPP:int
        return;
    }

    public void setM_pExcludedDrawingMemory(int[] p0, int p1, int p2) {
        // Registers (8 total): v4 = this, v5 = p0 (int[]), v6 = p1 (int), v7 = p2 (int)
        v1 = binOp_0x92(v6, v7);
        v0 = new int[][size=v1];
        v4.m_pExcludedDrawingMemory = v0; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_pExcludedDrawingMemory:int[]
        v0 = 0;
        if (v0 >= v1) /* goto L_0012 */;
        v2 = v4.m_pExcludedDrawingMemory; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_pExcludedDrawingMemory:int[]
        v3 = v5[v0];
        v2[v0] = v3;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0007
        return;
    }

    public void setM_pSelectObjectData(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_pSelectObjectData = v1; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_pSelectObjectData:int
        return;
    }

    public void setM_pSelectObjectNode(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_pSelectObjectNode = v1; // com.sec.amsoma.structure.AMS_SELECT_OBJECT.m_pSelectObjectNode:int
        return;
    }

}