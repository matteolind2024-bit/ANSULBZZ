package com.sec.amsoma.structure;

/**
 * Original SourceFile: AMS_OBJECT_DATA.java
 * Descriptor: Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;
 */
public class AMS_OBJECT_DATA {
     com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO m_TPoint;
     com.sec.amsoma.structure.AMS_RECT m_TRect;
     com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO m_TText;
     int m_bObjectInputFlag;
     int m_cAdditionalID;
     byte m_cSize;
     int m_cStyle;
     int m_eType;
     int m_nColor565;
     int m_nColorB;
     int m_nColorG;
     int m_nColorR;
     int m_nDrawingMapID;
     byte m_nIsThisSimplified;
     int m_nSpecialCodingBitSize;

    public AMS_OBJECT_DATA() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new com.sec.amsoma.structure.AMS_RECT;
        _result = v0.<init>(); // com.sec.amsoma.structure.AMS_RECT.<init> -> void
        v1.m_TRect = v0; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v0 = new com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO;
        _result = v0.<init>(); // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.<init> -> void
        v1.m_TText = v0; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TText:com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO
        v0 = new com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO;
        _result = v0.<init>(); // com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO.<init> -> void
        v1.m_TPoint = v0; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TPoint:com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO
        return;
    }

    public boolean equals(com.sec.amsoma.structure.AMS_OBJECT_DATA p0) {
        // Registers (6 total): v4 = this, v5 = p0 (com.sec.amsoma.structure.AMS_OBJECT_DATA)
        v0 = 0;
        v1 = 1;
        v2 = v4.m_eType; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_eType:int
        _result = v5.getM_eType(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_eType -> int
        v3 = _result;
        if (v2 == v3) /* goto L_000b */;
        return v0;
        v2 = v4.m_eType; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_eType:int
        // switch(v2)
        // goto L_000a
        v2 = v4.m_cSize; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_cSize:byte
        _result = v5.getM_cSize(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_cSize -> byte
        v3 = _result;
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_nColorR; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorR:int
        _result = v5.getM_nColorR(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_nColorR -> int
        v3 = _result;
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_nColorG; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorG:int
        _result = v5.getM_nColorB(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_nColorB -> int
        v3 = _result;
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_nColorB; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorB:int
        _result = v5.getM_nColorB(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_nColorB -> int
        v3 = _result;
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nLeft; // com.sec.amsoma.structure.AMS_RECT.nLeft:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nLeft; // com.sec.amsoma.structure.AMS_RECT.nLeft:short
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nRight; // com.sec.amsoma.structure.AMS_RECT.nRight:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nRight; // com.sec.amsoma.structure.AMS_RECT.nRight:short
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nTop; // com.sec.amsoma.structure.AMS_RECT.nTop:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nTop; // com.sec.amsoma.structure.AMS_RECT.nTop:short
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nBottom; // com.sec.amsoma.structure.AMS_RECT.nBottom:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nBottom; // com.sec.amsoma.structure.AMS_RECT.nBottom:short
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TText; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TText:com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO
        v2 = v2.m_strText; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_strText:java.lang.String
        v3 = v5.m_TText; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TText:com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO
        v3 = v3.m_strText; // com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO.m_strText:java.lang.String
        if (v2 != v3) /* goto L_000a */;
        v0 = v1;
        // goto L_000a
        v2 = v4.m_cStyle; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_cStyle:int
        _result = v5.getM_cStyle(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_cStyle -> int
        v3 = _result;
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_cAdditionalID; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_cAdditionalID:int
        _result = v5.getM_cAdditionalID(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_cAdditionalID -> int
        v3 = _result;
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nLeft; // com.sec.amsoma.structure.AMS_RECT.nLeft:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nLeft; // com.sec.amsoma.structure.AMS_RECT.nLeft:short
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nRight; // com.sec.amsoma.structure.AMS_RECT.nRight:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nRight; // com.sec.amsoma.structure.AMS_RECT.nRight:short
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nTop; // com.sec.amsoma.structure.AMS_RECT.nTop:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nTop; // com.sec.amsoma.structure.AMS_RECT.nTop:short
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nBottom; // com.sec.amsoma.structure.AMS_RECT.nBottom:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nBottom; // com.sec.amsoma.structure.AMS_RECT.nBottom:short
        if (v2 != v3) /* goto L_000a */;
        v0 = v1;
        // goto L_000a
        v2 = v4.m_cStyle; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_cStyle:int
        _result = v5.getM_cStyle(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_cStyle -> int
        v3 = _result;
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_cSize; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_cSize:byte
        _result = v5.getM_cSize(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_cSize -> byte
        v3 = _result;
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_nColorR; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorR:int
        _result = v5.getM_nColorR(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_nColorR -> int
        v3 = _result;
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_nColorG; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorG:int
        _result = v5.getM_nColorG(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_nColorG -> int
        v3 = _result;
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_nColorB; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorB:int
        _result = v5.getM_nColorB(); // com.sec.amsoma.structure.AMS_OBJECT_DATA.getM_nColorB -> int
        v3 = _result;
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nLeft; // com.sec.amsoma.structure.AMS_RECT.nLeft:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nLeft; // com.sec.amsoma.structure.AMS_RECT.nLeft:short
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nRight; // com.sec.amsoma.structure.AMS_RECT.nRight:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nRight; // com.sec.amsoma.structure.AMS_RECT.nRight:short
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nTop; // com.sec.amsoma.structure.AMS_RECT.nTop:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nTop; // com.sec.amsoma.structure.AMS_RECT.nTop:short
        if (v2 != v3) /* goto L_000a */;
        v2 = v4.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v2 = v2.nBottom; // com.sec.amsoma.structure.AMS_RECT.nBottom:short
        v3 = v5.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        v3 = v3.nBottom; // com.sec.amsoma.structure.AMS_RECT.nBottom:short
        if (v2 != v3) /* goto L_000a */;
        v0 = v1;
        // goto L_000a
    }

    public com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO getM_TPoint() {
        // Registers (2 total): v1 = this
        v0 = v1.m_TPoint; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TPoint:com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO
        return v0;
    }

    public com.sec.amsoma.structure.AMS_RECT getM_TRect() {
        // Registers (2 total): v1 = this
        v0 = v1.m_TRect; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        return v0;
    }

    public com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO getM_TText() {
        // Registers (2 total): v1 = this
        v0 = v1.m_TText; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TText:com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO
        return v0;
    }

    public int getM_bObjectInputFlag() {
        // Registers (2 total): v1 = this
        v0 = v1.m_bObjectInputFlag; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_bObjectInputFlag:int
        return v0;
    }

    public int getM_cAdditionalID() {
        // Registers (2 total): v1 = this
        v0 = v1.m_cAdditionalID; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_cAdditionalID:int
        return v0;
    }

    public byte getM_cSize() {
        // Registers (2 total): v1 = this
        v0 = v1.m_cSize; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_cSize:byte
        return v0;
    }

    public int getM_cStyle() {
        // Registers (2 total): v1 = this
        v0 = v1.m_cStyle; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_cStyle:int
        return v0;
    }

    public int getM_eType() {
        // Registers (2 total): v1 = this
        v0 = v1.m_eType; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_eType:int
        return v0;
    }

    public int getM_nColor565() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nColor565; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColor565:int
        return v0;
    }

    public int getM_nColorB() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nColorB; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorB:int
        return v0;
    }

    public int getM_nColorG() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nColorG; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorG:int
        return v0;
    }

    public int getM_nColorR() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nColorR; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorR:int
        return v0;
    }

    public int getM_nDrawingMapID() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nDrawingMapID; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nDrawingMapID:int
        return v0;
    }

    public byte getM_nIsThisSimplified() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nIsThisSimplified; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nIsThisSimplified:byte
        return v0;
    }

    public int getM_nSpecialCodingBitSize() {
        // Registers (2 total): v1 = this
        v0 = v1.m_nSpecialCodingBitSize; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nSpecialCodingBitSize:int
        return v0;
    }

    public void setM_TPoint(com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO)
        v0.m_TPoint = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TPoint:com.sec.amsoma.structure.AMS_OBJECT_POINT_INFO
        return;
    }

    public void setM_TRect(com.sec.amsoma.structure.AMS_RECT p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.sec.amsoma.structure.AMS_RECT)
        v0.m_TRect = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TRect:com.sec.amsoma.structure.AMS_RECT
        return;
    }

    public void setM_TText(com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO)
        v0.m_TText = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_TText:com.sec.amsoma.structure.AMS_OBJECT_TEXT_INFO
        return;
    }

    public void setM_bObjectInputFlag(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_bObjectInputFlag = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_bObjectInputFlag:int
        return;
    }

    public void setM_cAdditionalID(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_cAdditionalID = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_cAdditionalID:int
        return;
    }

    public void setM_cSize(byte p0) {
        // Registers (2 total): v0 = this, v1 = p0 (byte)
        v0.m_cSize = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_cSize:byte
        return;
    }

    public void setM_cStyle(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_cStyle = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_cStyle:int
        return;
    }

    public void setM_eType(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_eType = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_eType:int
        return;
    }

    public void setM_nColor565(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nColor565 = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColor565:int
        return;
    }

    public void setM_nColorB(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nColorB = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorB:int
        return;
    }

    public void setM_nColorG(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nColorG = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorG:int
        return;
    }

    public void setM_nColorR(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nColorR = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nColorR:int
        return;
    }

    public void setM_nDrawingMapID(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nDrawingMapID = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nDrawingMapID:int
        return;
    }

    public void setM_nIsThisSimplified(byte p0) {
        // Registers (2 total): v0 = this, v1 = p0 (byte)
        v0.m_nIsThisSimplified = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nIsThisSimplified:byte
        return;
    }

    public void setM_nSpecialCodingBitSize(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m_nSpecialCodingBitSize = v1; // com.sec.amsoma.structure.AMS_OBJECT_DATA.m_nSpecialCodingBitSize:int
        return;
    }

}