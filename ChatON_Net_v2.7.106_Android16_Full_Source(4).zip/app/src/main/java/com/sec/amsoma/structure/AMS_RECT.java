package com.sec.amsoma.structure;

/**
 * Original SourceFile: AMS_RECT.java
 * Descriptor: Lcom/sec/amsoma/structure/AMS_RECT;
 */
public class AMS_RECT {
    public short nBottom;
    public short nLeft;
    public short nRight;
    public short nTop;

    public AMS_RECT() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public short getnBottom() {
        // Registers (2 total): v1 = this
        v0 = v1.nBottom; // com.sec.amsoma.structure.AMS_RECT.nBottom:short
        return v0;
    }

    public short getnLeft() {
        // Registers (2 total): v1 = this
        v0 = v1.nLeft; // com.sec.amsoma.structure.AMS_RECT.nLeft:short
        return v0;
    }

    public short getnRight() {
        // Registers (2 total): v1 = this
        v0 = v1.nRight; // com.sec.amsoma.structure.AMS_RECT.nRight:short
        return v0;
    }

    public short getnTop() {
        // Registers (2 total): v1 = this
        v0 = v1.nTop; // com.sec.amsoma.structure.AMS_RECT.nTop:short
        return v0;
    }

    public void setnBottom(short p0) {
        // Registers (2 total): v0 = this, v1 = p0 (short)
        v0.nBottom = v1; // com.sec.amsoma.structure.AMS_RECT.nBottom:short
        return;
    }

    public void setnLeft(short p0) {
        // Registers (2 total): v0 = this, v1 = p0 (short)
        v0.nLeft = v1; // com.sec.amsoma.structure.AMS_RECT.nLeft:short
        return;
    }

    public void setnRight(short p0) {
        // Registers (2 total): v0 = this, v1 = p0 (short)
        v0.nRight = v1; // com.sec.amsoma.structure.AMS_RECT.nRight:short
        return;
    }

    public void setnTop(short p0) {
        // Registers (2 total): v0 = this, v1 = p0 (short)
        v0.nTop = v1; // com.sec.amsoma.structure.AMS_RECT.nTop:short
        return;
    }

}