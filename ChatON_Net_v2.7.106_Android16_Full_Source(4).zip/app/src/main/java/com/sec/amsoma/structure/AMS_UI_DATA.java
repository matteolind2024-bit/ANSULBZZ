package com.sec.amsoma.structure;

/**
 * Original SourceFile: AMS_UI_DATA.java
 * Descriptor: Lcom/sec/amsoma/structure/AMS_UI_DATA;
 */
public class AMS_UI_DATA {
    public android.graphics.Bitmap m_Bitmap;
    public boolean m_bStart;
    public byte m_cObjectSize;
    public byte m_cObjectStyle;
    public byte m_eObjectType;
    public com.sec.amsoma.structure.AMS_RECT m_rectRegion;
    public int m_rgbBack;
    public int m_rgbPen;

    public AMS_UI_DATA() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new com.sec.amsoma.structure.AMS_RECT;
        _result = v0.<init>(); // com.sec.amsoma.structure.AMS_RECT.<init> -> void
        v1.m_rectRegion = v0; // com.sec.amsoma.structure.AMS_UI_DATA.m_rectRegion:com.sec.amsoma.structure.AMS_RECT
        return;
    }

    public void Init() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v0 = 1;
        v2.m_eObjectType = v0; // com.sec.amsoma.structure.AMS_UI_DATA.m_eObjectType:byte
        v2.m_cObjectStyle = v1; // com.sec.amsoma.structure.AMS_UI_DATA.m_cObjectStyle:byte
        v0 = 2;
        v2.m_cObjectSize = v0; // com.sec.amsoma.structure.AMS_UI_DATA.m_cObjectSize:byte
        v0 = 65280; // 0x0000ff00
        v2.m_rgbPen = v0; // com.sec.amsoma.structure.AMS_UI_DATA.m_rgbPen:int
        v2.m_rgbBack = v1; // com.sec.amsoma.structure.AMS_UI_DATA.m_rgbBack:int
        v0 = v2.m_rectRegion; // com.sec.amsoma.structure.AMS_UI_DATA.m_rectRegion:com.sec.amsoma.structure.AMS_RECT
        _result = v0.setnLeft(v1); // com.sec.amsoma.structure.AMS_RECT.setnLeft -> void
        v0 = v2.m_rectRegion; // com.sec.amsoma.structure.AMS_UI_DATA.m_rectRegion:com.sec.amsoma.structure.AMS_RECT
        _result = v0.setnTop(v1); // com.sec.amsoma.structure.AMS_RECT.setnTop -> void
        v0 = v2.m_rectRegion; // com.sec.amsoma.structure.AMS_UI_DATA.m_rectRegion:com.sec.amsoma.structure.AMS_RECT
        _result = v0.setnRight(v1); // com.sec.amsoma.structure.AMS_RECT.setnRight -> void
        v0 = v2.m_rectRegion; // com.sec.amsoma.structure.AMS_UI_DATA.m_rectRegion:com.sec.amsoma.structure.AMS_RECT
        _result = v0.setnBottom(v1); // com.sec.amsoma.structure.AMS_RECT.setnBottom -> void
        v2.m_bStart = v1; // com.sec.amsoma.structure.AMS_UI_DATA.m_bStart:boolean
        return;
    }

    public void SetRect(short p0, short p1, short p2, short p3) {
        // Registers (6 total): v1 = this, v2 = p0 (short), v3 = p1 (short), v4 = p2 (short), v5 = p3 (short)
        v0 = v1.m_rectRegion; // com.sec.amsoma.structure.AMS_UI_DATA.m_rectRegion:com.sec.amsoma.structure.AMS_RECT
        _result = v0.setnLeft(v2); // com.sec.amsoma.structure.AMS_RECT.setnLeft -> void
        v0 = v1.m_rectRegion; // com.sec.amsoma.structure.AMS_UI_DATA.m_rectRegion:com.sec.amsoma.structure.AMS_RECT
        _result = v0.setnTop(v3); // com.sec.amsoma.structure.AMS_RECT.setnTop -> void
        v0 = v1.m_rectRegion; // com.sec.amsoma.structure.AMS_UI_DATA.m_rectRegion:com.sec.amsoma.structure.AMS_RECT
        _result = v0.setnRight(v4); // com.sec.amsoma.structure.AMS_RECT.setnRight -> void
        v0 = v1.m_rectRegion; // com.sec.amsoma.structure.AMS_UI_DATA.m_rectRegion:com.sec.amsoma.structure.AMS_RECT
        _result = v0.setnBottom(v5); // com.sec.amsoma.structure.AMS_RECT.setnBottom -> void
        return;
    }

}