package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/t;
 */
public interface t extends com.google.protobuf.MessageLiteOrBuilder {
}