package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/ao;
 */
public interface ao extends com.google.protobuf.MessageLiteOrBuilder {
}