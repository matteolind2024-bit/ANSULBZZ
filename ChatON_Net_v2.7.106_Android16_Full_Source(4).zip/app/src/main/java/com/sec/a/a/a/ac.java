package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/ac;
 */
public interface ac extends com.google.protobuf.MessageLiteOrBuilder {
}