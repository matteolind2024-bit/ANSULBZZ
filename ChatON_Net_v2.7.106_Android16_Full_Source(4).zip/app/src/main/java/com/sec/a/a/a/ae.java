package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/ae;
 */
public final class ae extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.a.a.a.af {
    private int a;
    private int b;
    private java.lang.Object c;
    private java.lang.Object d;
    private int e;
    private java.lang.Object f;
    private int g;
    private int h;
    private java.lang.Object i;

    private ae() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = "";
        v1.c = v0; // com.sec.a.a.a.ae.c:java.lang.Object
        v0 = "";
        v1.d = v0; // com.sec.a.a.a.ae.d:java.lang.Object
        v0 = "";
        v1.f = v0; // com.sec.a.a.a.ae.f:java.lang.Object
        v0 = "";
        v1.i = v0; // com.sec.a.a.a.ae.i:java.lang.Object
        _result = v1.g(); // com.sec.a.a.a.ae.g -> void
        return;
    }

    static com.sec.a.a.a.ad a(com.sec.a.a.a.ae p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.ae)
        _result = v1.i(); // com.sec.a.a.a.ae.i -> com.sec.a.a.a.ad
        v0 = _result;
        return v0;
    }

    static com.sec.a.a.a.ae f() {
        _result = this.h(); // com.sec.a.a.a.ae.h -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.a.a.a.ae h() {
        v0 = new com.sec.a.a.a.ae;
        _result = v0.<init>(); // com.sec.a.a.a.ae.<init> -> void
        return v0;
    }

    private com.sec.a.a.a.ad i() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.ae.e -> com.sec.a.a.a.ad
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.ad.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.ae.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.ae a() {
        // Registers (3 total): v2 = this
        v1 = 0;
        _result = v2.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v2.b = v1; // com.sec.a.a.a.ae.b:int
        v0 = v2.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v2.a = v0; // com.sec.a.a.a.ae.a:int
        v0 = "";
        v2.c = v0; // com.sec.a.a.a.ae.c:java.lang.Object
        v0 = v2.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v2.a = v0; // com.sec.a.a.a.ae.a:int
        v0 = "";
        v2.d = v0; // com.sec.a.a.a.ae.d:java.lang.Object
        v0 = v2.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v2.a = v0; // com.sec.a.a.a.ae.a:int
        v2.e = v1; // com.sec.a.a.a.ae.e:int
        v0 = v2.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -9);
        v2.a = v0; // com.sec.a.a.a.ae.a:int
        v0 = "";
        v2.f = v0; // com.sec.a.a.a.ae.f:java.lang.Object
        v0 = v2.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -17);
        v2.a = v0; // com.sec.a.a.a.ae.a:int
        v2.g = v1; // com.sec.a.a.a.ae.g:int
        v0 = v2.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -33);
        v2.a = v0; // com.sec.a.a.a.ae.a:int
        v2.h = v1; // com.sec.a.a.a.ae.h:int
        v0 = v2.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xdd(v0, -65);
        v2.a = v0; // com.sec.a.a.a.ae.a:int
        v0 = "";
        v2.i = v0; // com.sec.a.a.a.ae.i:java.lang.Object
        v0 = v2.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit16_0xd5(v0, -129);
        v2.a = v0; // com.sec.a.a.a.ae.a:int
        return v2;
    }

    public com.sec.a.a.a.ae a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        v1.b = v2; // com.sec.a.a.a.ae.b:int
        return v1;
    }

    public com.sec.a.a.a.ae a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v2.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v1.parseUnknownField(v2, v3, v0); // com.sec.a.a.a.ae.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v1;
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        _result = v2.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v1.b = v0; // com.sec.a.a.a.ae.b:int
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        _result = v2.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v1.c = v0; // com.sec.a.a.a.ae.c:java.lang.Object
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        _result = v2.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v1.d = v0; // com.sec.a.a.a.ae.d:java.lang.Object
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        _result = v2.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v1.e = v0; // com.sec.a.a.a.ae.e:int
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 16);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        _result = v2.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v1.f = v0; // com.sec.a.a.a.ae.f:java.lang.Object
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 32);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        _result = v2.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v1.g = v0; // com.sec.a.a.a.ae.g:int
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 64);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        _result = v2.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v1.h = v0; // com.sec.a.a.a.ae.h:int
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit16_0xd6(v0, 128);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        _result = v2.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v1.i = v0; // com.sec.a.a.a.ae.i:java.lang.Object
        // goto L_0000
    }

    public com.sec.a.a.a.ae a(com.sec.a.a.a.ad p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.ad)
        _result = this.a(); // com.sec.a.a.a.ad.a -> com.sec.a.a.a.ad
        v0 = _result;
        if (v2 != v0) /* goto L_0007 */;
        return v1;
        _result = v2.c(); // com.sec.a.a.a.ad.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v2.d(); // com.sec.a.a.a.ad.d -> int
        v0 = _result;
        _result = v1.a(v0); // com.sec.a.a.a.ae.a -> com.sec.a.a.a.ae
        _result = v2.e(); // com.sec.a.a.a.ad.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v2.f(); // com.sec.a.a.a.ad.f -> java.lang.String
        v0 = _result;
        _result = v1.a(v0); // com.sec.a.a.a.ae.a -> com.sec.a.a.a.ae
        _result = v2.g(); // com.sec.a.a.a.ad.g -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002e */;
        _result = v2.h(); // com.sec.a.a.a.ad.h -> java.lang.String
        v0 = _result;
        _result = v1.b(v0); // com.sec.a.a.a.ae.b -> com.sec.a.a.a.ae
        _result = v2.i(); // com.sec.a.a.a.ad.i -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003b */;
        _result = v2.j(); // com.sec.a.a.a.ad.j -> int
        v0 = _result;
        _result = v1.b(v0); // com.sec.a.a.a.ae.b -> com.sec.a.a.a.ae
        _result = v2.k(); // com.sec.a.a.a.ad.k -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0048 */;
        _result = v2.l(); // com.sec.a.a.a.ad.l -> java.lang.String
        v0 = _result;
        _result = v1.c(v0); // com.sec.a.a.a.ae.c -> com.sec.a.a.a.ae
        _result = v2.m(); // com.sec.a.a.a.ad.m -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0055 */;
        _result = v2.n(); // com.sec.a.a.a.ad.n -> int
        v0 = _result;
        _result = v1.c(v0); // com.sec.a.a.a.ae.c -> com.sec.a.a.a.ae
        _result = v2.o(); // com.sec.a.a.a.ad.o -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0062 */;
        _result = v2.p(); // com.sec.a.a.a.ad.p -> int
        v0 = _result;
        _result = v1.d(v0); // com.sec.a.a.a.ae.d -> com.sec.a.a.a.ae
        _result = v2.q(); // com.sec.a.a.a.ad.q -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0006 */;
        _result = v2.r(); // com.sec.a.a.a.ad.r -> java.lang.String
        v0 = _result;
        _result = v1.d(v0); // com.sec.a.a.a.ae.d -> com.sec.a.a.a.ae
        // goto L_0006
    }

    public com.sec.a.a.a.ae a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        v1.c = v2; // com.sec.a.a.a.ae.c:java.lang.Object
        return v1;
    }

    public com.sec.a.a.a.ae b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.a.a.a.ae.h -> com.sec.a.a.a.ae
        v0 = _result;
        _result = v2.e(); // com.sec.a.a.a.ae.e -> com.sec.a.a.a.ad
        v1 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.ae.a -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.ae b(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        v1.e = v2; // com.sec.a.a.a.ae.e:int
        return v1;
    }

    public com.sec.a.a.a.ae b(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        v1.d = v2; // com.sec.a.a.a.ae.d:java.lang.Object
        return v1;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.a.a.a.ae.d -> com.sec.a.a.a.ad
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.a.a.a.ae.e -> com.sec.a.a.a.ad
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.ad c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.a.a.a.ad.a -> com.sec.a.a.a.ad
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.ae c(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 32);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        v1.g = v2; // com.sec.a.a.a.ae.g:int
        return v1;
    }

    public com.sec.a.a.a.ae c(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 16);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        v1.f = v2; // com.sec.a.a.a.ae.f:java.lang.Object
        return v1;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.ae.a -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.ae.a -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.ae.b -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.ae.b -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.ae.b -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.ae.b -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.ad d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.ae.e -> com.sec.a.a.a.ad
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.ad.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.ae.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.ae d(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit8_0xde(v0, 64);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        v1.h = v2; // com.sec.a.a.a.ae.h:int
        return v1;
    }

    public com.sec.a.a.a.ae d(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.ae.a:int
        v0 = binOpLit16_0xd6(v0, 128);
        v1.a = v0; // com.sec.a.a.a.ae.a:int
        v1.i = v2; // com.sec.a.a.a.ae.i:java.lang.Object
        return v1;
    }

    public com.sec.a.a.a.ad e() {
        // Registers (6 total): v5 = this
        v0 = 1;
        v2 = new com.sec.a.a.a.ad;
        v1 = 0;
        _result = v2.<init>(v5, v1); // com.sec.a.a.a.ad.<init> -> void
        v3 = v5.a; // com.sec.a.a.a.ae.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_0070 */;
        v1 = v5.b; // com.sec.a.a.a.ae.b:int
        _result = v2.a(v1); // com.sec.a.a.a.ad.a -> int
        v1 = binOpLit8_0xdd(v3, 2);
        v4 = 2;
        if (v1 != v4) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v5.c; // com.sec.a.a.a.ae.c:java.lang.Object
        _result = v2.a(v1); // com.sec.a.a.a.ad.a -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 4);
        v4 = 4;
        if (v1 != v4) /* goto L_0026 */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = v5.d; // com.sec.a.a.a.ae.d:java.lang.Object
        _result = v2.b(v1); // com.sec.a.a.a.ad.b -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 8);
        v4 = 8;
        if (v1 != v4) /* goto L_0033 */;
        v0 = binOpLit8_0xde(v0, 8);
        v1 = v5.e; // com.sec.a.a.a.ae.e:int
        _result = v2.b(v1); // com.sec.a.a.a.ad.b -> int
        v1 = binOpLit8_0xdd(v3, 16);
        v4 = 16;
        if (v1 != v4) /* goto L_0040 */;
        v0 = binOpLit8_0xde(v0, 16);
        v1 = v5.f; // com.sec.a.a.a.ae.f:java.lang.Object
        _result = v2.c(v1); // com.sec.a.a.a.ad.c -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 32);
        v4 = 32;
        if (v1 != v4) /* goto L_004d */;
        v0 = binOpLit8_0xde(v0, 32);
        v1 = v5.g; // com.sec.a.a.a.ae.g:int
        _result = v2.c(v1); // com.sec.a.a.a.ad.c -> int
        v1 = binOpLit8_0xdd(v3, 64);
        v4 = 64;
        if (v1 != v4) /* goto L_005a */;
        v0 = binOpLit8_0xde(v0, 64);
        v1 = v5.h; // com.sec.a.a.a.ae.h:int
        _result = v2.d(v1); // com.sec.a.a.a.ad.d -> int
        v1 = binOpLit16_0xd5(v3, 128);
        v3 = 128;
        if (v1 != v3) /* goto L_0067 */;
        v0 = binOpLit16_0xd6(v0, 128);
        v1 = v5.i; // com.sec.a.a.a.ae.i:java.lang.Object
        _result = v2.d(v1); // com.sec.a.a.a.ad.d -> java.lang.Object
        _result = v2.e(v0); // com.sec.a.a.a.ad.e -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.ae.c -> com.sec.a.a.a.ad
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.ae.c -> com.sec.a.a.a.ad
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.ae.a -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.a.a.a.ad) v2;
        _result = v1.a(v2); // com.sec.a.a.a.ae.a -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.ae.a -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

}