package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/v;
 */
public final class v extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.a.a.a.w {
    private int a;
    private java.util.List b;

    private v() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        v1.b = v0; // com.sec.a.a.a.v.b:java.util.List
        _result = v1.g(); // com.sec.a.a.a.v.g -> void
        return;
    }

    static com.sec.a.a.a.u a(com.sec.a.a.a.v p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.v)
        _result = v1.i(); // com.sec.a.a.a.v.i -> com.sec.a.a.a.u
        v0 = _result;
        return v0;
    }

    static com.sec.a.a.a.v f() {
        _result = this.h(); // com.sec.a.a.a.v.h -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.a.a.a.v h() {
        v0 = new com.sec.a.a.a.v;
        _result = v0.<init>(); // com.sec.a.a.a.v.<init> -> void
        return v0;
    }

    private com.sec.a.a.a.u i() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.v.e -> com.sec.a.a.a.u
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.u.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.v.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    private void j() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // com.sec.a.a.a.v.a:int
        v0 = binOpLit8_0xdd(v0, 1);
        v1 = 1;
        if (v0 == v1) /* goto L_0016 */;
        v0 = new java.util.ArrayList;
        v1 = v2.b; // com.sec.a.a.a.v.b:java.util.List
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v2.b = v0; // com.sec.a.a.a.v.b:java.util.List
        v0 = v2.a; // com.sec.a.a.a.v.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v2.a = v0; // com.sec.a.a.a.v.a:int
        return;
    }

    public com.sec.a.a.a.v a() {
        // Registers (2 total): v1 = this
        _result = v1.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        v1.b = v0; // com.sec.a.a.a.v.b:java.util.List
        v0 = v1.a; // com.sec.a.a.a.v.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v1.a = v0; // com.sec.a.a.a.v.a:int
        return v1;
    }

    public com.sec.a.a.a.v a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v2.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v1.parseUnknownField(v2, v3, v0); // com.sec.a.a.a.v.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v1;
        _result = this.newBuilder(); // com.sec.a.a.a.r.newBuilder -> com.sec.a.a.a.s
        v0 = _result;
        _result = v2.readMessage(v0, v3); // com.google.protobuf.CodedInputStream.readMessage -> void
        _result = v0.e(); // com.sec.a.a.a.s.e -> com.sec.a.a.a.r
        v0 = _result;
        _result = v1.a(v0); // com.sec.a.a.a.v.a -> com.sec.a.a.a.v
        // goto L_0000
    }

    public com.sec.a.a.a.v a(com.sec.a.a.a.r p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.r)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        _result = v1.j(); // com.sec.a.a.a.v.j -> void
        v0 = v1.b; // com.sec.a.a.a.v.b:java.util.List
        _result = java.util.List.add(v0, v2); // -> boolean
        return v1;
    }

    public com.sec.a.a.a.v a(com.sec.a.a.a.u p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.a.a.a.u)
        _result = this.a(); // com.sec.a.a.a.u.a -> com.sec.a.a.a.u
        v0 = _result;
        if (v3 != v0) /* goto L_0007 */;
        return v2;
        _result = v3.b(); // com.sec.a.a.a.u.b -> java.util.List
        v0 = _result;
        _result = java.util.List.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0006 */;
        v0 = v2.b; // com.sec.a.a.a.v.b:java.util.List
        _result = java.util.List.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0026 */;
        _result = v3.b(); // com.sec.a.a.a.u.b -> java.util.List
        v0 = _result;
        v2.b = v0; // com.sec.a.a.a.v.b:java.util.List
        v0 = v2.a; // com.sec.a.a.a.v.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v2.a = v0; // com.sec.a.a.a.v.a:int
        // goto L_0006
        _result = v2.j(); // com.sec.a.a.a.v.j -> void
        v0 = v2.b; // com.sec.a.a.a.v.b:java.util.List
        _result = v3.b(); // com.sec.a.a.a.u.b -> java.util.List
        v1 = _result;
        _result = java.util.List.addAll(v0, v1); // -> boolean
        // goto L_0006
    }

    public com.sec.a.a.a.v b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.a.a.a.v.h -> com.sec.a.a.a.v
        v0 = _result;
        _result = v2.e(); // com.sec.a.a.a.v.e -> com.sec.a.a.a.u
        v1 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.v.a -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.a.a.a.v.d -> com.sec.a.a.a.u
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.a.a.a.v.e -> com.sec.a.a.a.u
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.u c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.a.a.a.u.a -> com.sec.a.a.a.u
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.v.a -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.v.a -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.v.b -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.v.b -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.v.b -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.v.b -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.u d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.v.e -> com.sec.a.a.a.u
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.u.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.v.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.u e() {
        // Registers (4 total): v3 = this
        v0 = new com.sec.a.a.a.u;
        v1 = 0;
        _result = v0.<init>(v3, v1); // com.sec.a.a.a.u.<init> -> void
        v1 = v3.a; // com.sec.a.a.a.v.a:int
        v1 = v3.a; // com.sec.a.a.a.v.a:int
        v1 = binOpLit8_0xdd(v1, 1);
        v2 = 1;
        if (v1 != v2) /* goto L_001d */;
        v1 = v3.b; // com.sec.a.a.a.v.b:java.util.List
        _result = v1.unmodifiableList(); // java.util.Collections.unmodifiableList -> java.util.List
        v1 = _result;
        v3.b = v1; // com.sec.a.a.a.v.b:java.util.List
        v1 = v3.a; // com.sec.a.a.a.v.a:int
        v1 = binOpLit8_0xdd(v1, -2);
        v3.a = v1; // com.sec.a.a.a.v.a:int
        v1 = v3.b; // com.sec.a.a.a.v.b:java.util.List
        _result = v0.a(v1); // com.sec.a.a.a.u.a -> java.util.List
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.v.c -> com.sec.a.a.a.u
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.v.c -> com.sec.a.a.a.u
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.v.a -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.a.a.a.u) v2;
        _result = v1.a(v2); // com.sec.a.a.a.v.a -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.v.a -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

}