package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/m;
 */
public final class m extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.a.a.a.n {
    private int a;
    private int b;
    private java.lang.Object c;

    private m() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = "";
        v1.c = v0; // com.sec.a.a.a.m.c:java.lang.Object
        _result = v1.g(); // com.sec.a.a.a.m.g -> void
        return;
    }

    static com.sec.a.a.a.l a(com.sec.a.a.a.m p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.m)
        _result = v1.i(); // com.sec.a.a.a.m.i -> com.sec.a.a.a.l
        v0 = _result;
        return v0;
    }

    static com.sec.a.a.a.m f() {
        _result = this.h(); // com.sec.a.a.a.m.h -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.a.a.a.m h() {
        v0 = new com.sec.a.a.a.m;
        _result = v0.<init>(); // com.sec.a.a.a.m.<init> -> void
        return v0;
    }

    private com.sec.a.a.a.l i() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.m.e -> com.sec.a.a.a.l
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.l.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.m.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.m a() {
        // Registers (2 total): v1 = this
        _result = v1.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = 0;
        v1.b = v0; // com.sec.a.a.a.m.b:int
        v0 = v1.a; // com.sec.a.a.a.m.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v1.a = v0; // com.sec.a.a.a.m.a:int
        v0 = "";
        v1.c = v0; // com.sec.a.a.a.m.c:java.lang.Object
        v0 = v1.a; // com.sec.a.a.a.m.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v1.a = v0; // com.sec.a.a.a.m.a:int
        return v1;
    }

    public com.sec.a.a.a.m a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.m.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.a.a.a.m.a:int
        v1.b = v2; // com.sec.a.a.a.m.b:int
        return v1;
    }

    public com.sec.a.a.a.m a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v2.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v1.parseUnknownField(v2, v3, v0); // com.sec.a.a.a.m.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v1;
        v0 = v1.a; // com.sec.a.a.a.m.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.a.a.a.m.a:int
        _result = v2.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v1.b = v0; // com.sec.a.a.a.m.b:int
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.m.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.a.a.a.m.a:int
        _result = v2.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v1.c = v0; // com.sec.a.a.a.m.c:java.lang.Object
        // goto L_0000
    }

    public com.sec.a.a.a.m a(com.sec.a.a.a.l p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.l)
        _result = this.a(); // com.sec.a.a.a.l.a -> com.sec.a.a.a.l
        v0 = _result;
        if (v2 != v0) /* goto L_0007 */;
        return v1;
        _result = v2.c(); // com.sec.a.a.a.l.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v2.d(); // com.sec.a.a.a.l.d -> int
        v0 = _result;
        _result = v1.a(v0); // com.sec.a.a.a.m.a -> com.sec.a.a.a.m
        _result = v2.e(); // com.sec.a.a.a.l.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0006 */;
        _result = v2.f(); // com.sec.a.a.a.l.f -> java.lang.String
        v0 = _result;
        _result = v1.a(v0); // com.sec.a.a.a.m.a -> com.sec.a.a.a.m
        // goto L_0006
    }

    public com.sec.a.a.a.m a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.m.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.a.a.a.m.a:int
        v1.c = v2; // com.sec.a.a.a.m.c:java.lang.Object
        return v1;
    }

    public com.sec.a.a.a.m b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.a.a.a.m.h -> com.sec.a.a.a.m
        v0 = _result;
        _result = v2.e(); // com.sec.a.a.a.m.e -> com.sec.a.a.a.l
        v1 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.m.a -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.a.a.a.m.d -> com.sec.a.a.a.l
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.a.a.a.m.e -> com.sec.a.a.a.l
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.l c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.a.a.a.l.a -> com.sec.a.a.a.l
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.m.a -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.m.a -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.m.b -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.m.b -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.m.b -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.m.b -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.l d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.m.e -> com.sec.a.a.a.l
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.l.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.m.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.l e() {
        // Registers (6 total): v5 = this
        v0 = 1;
        v2 = new com.sec.a.a.a.l;
        v1 = 0;
        _result = v2.<init>(v5, v1); // com.sec.a.a.a.l.<init> -> void
        v3 = v5.a; // com.sec.a.a.a.m.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_0023 */;
        v1 = v5.b; // com.sec.a.a.a.m.b:int
        _result = v2.a(v1); // com.sec.a.a.a.l.a -> int
        v1 = binOpLit8_0xdd(v3, 2);
        v3 = 2;
        if (v1 != v3) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v5.c; // com.sec.a.a.a.m.c:java.lang.Object
        _result = v2.a(v1); // com.sec.a.a.a.l.a -> java.lang.Object
        _result = v2.b(v0); // com.sec.a.a.a.l.b -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.m.c -> com.sec.a.a.a.l
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.m.c -> com.sec.a.a.a.l
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.m.a -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.a.a.a.l) v2;
        _result = v1.a(v2); // com.sec.a.a.a.m.a -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.m.a -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

}