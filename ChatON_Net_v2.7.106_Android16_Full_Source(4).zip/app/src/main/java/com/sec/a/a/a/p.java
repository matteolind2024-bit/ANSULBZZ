package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/p;
 */
public final class p extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.a.a.a.q {
    private int a;
    private java.lang.Object b;
    private com.google.protobuf.LazyStringList c;

    private p() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = "";
        v1.b = v0; // com.sec.a.a.a.p.b:java.lang.Object
        v0 = com.google.protobuf.LazyStringArrayList.EMPTY; // :com.google.protobuf.LazyStringList
        v1.c = v0; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        _result = v1.g(); // com.sec.a.a.a.p.g -> void
        return;
    }

    static com.sec.a.a.a.o a(com.sec.a.a.a.p p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.p)
        _result = v1.i(); // com.sec.a.a.a.p.i -> com.sec.a.a.a.o
        v0 = _result;
        return v0;
    }

    static com.sec.a.a.a.p f() {
        _result = this.h(); // com.sec.a.a.a.p.h -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.a.a.a.p h() {
        v0 = new com.sec.a.a.a.p;
        _result = v0.<init>(); // com.sec.a.a.a.p.<init> -> void
        return v0;
    }

    private com.sec.a.a.a.o i() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.p.e -> com.sec.a.a.a.o
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.o.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.p.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    private void j() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // com.sec.a.a.a.p.a:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 == v1) /* goto L_0016 */;
        v0 = new com.google.protobuf.LazyStringArrayList;
        v1 = v2.c; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        _result = v0.<init>(v1); // com.google.protobuf.LazyStringArrayList.<init> -> void
        v2.c = v0; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        v0 = v2.a; // com.sec.a.a.a.p.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v2.a = v0; // com.sec.a.a.a.p.a:int
        return;
    }

    public com.sec.a.a.a.p a() {
        // Registers (2 total): v1 = this
        _result = v1.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = "";
        v1.b = v0; // com.sec.a.a.a.p.b:java.lang.Object
        v0 = v1.a; // com.sec.a.a.a.p.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v1.a = v0; // com.sec.a.a.a.p.a:int
        v0 = com.google.protobuf.LazyStringArrayList.EMPTY; // :com.google.protobuf.LazyStringList
        v1.c = v0; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        v0 = v1.a; // com.sec.a.a.a.p.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v1.a = v0; // com.sec.a.a.a.p.a:int
        return v1;
    }

    public com.sec.a.a.a.p a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.CodedInputStream), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v2.parseUnknownField(v3, v4, v0); // com.sec.a.a.a.p.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v2;
        v0 = v2.a; // com.sec.a.a.a.p.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v2.a = v0; // com.sec.a.a.a.p.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.b = v0; // com.sec.a.a.a.p.b:java.lang.Object
        // goto L_0000
        _result = v2.j(); // com.sec.a.a.a.p.j -> void
        v0 = v2.c; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v1 = _result;
        _result = com.google.protobuf.LazyStringList.add(v0, v1); // -> void
        // goto L_0000
    }

    public com.sec.a.a.a.p a(com.sec.a.a.a.o p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.a.a.a.o)
        _result = this.a(); // com.sec.a.a.a.o.a -> com.sec.a.a.a.o
        v0 = _result;
        if (v3 != v0) /* goto L_0007 */;
        return v2;
        _result = v3.c(); // com.sec.a.a.a.o.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v3.d(); // com.sec.a.a.a.o.d -> java.lang.String
        v0 = _result;
        _result = v2.a(v0); // com.sec.a.a.a.p.a -> com.sec.a.a.a.p
        _result = v3.b(); // com.sec.a.a.a.o.b -> com.google.protobuf.LazyStringList
        v0 = _result;
        _result = com.google.protobuf.LazyStringList.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0006 */;
        v0 = v2.c; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0033 */;
        _result = v3.b(); // com.sec.a.a.a.o.b -> com.google.protobuf.LazyStringList
        v0 = _result;
        v2.c = v0; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        v0 = v2.a; // com.sec.a.a.a.p.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v2.a = v0; // com.sec.a.a.a.p.a:int
        // goto L_0006
        _result = v2.j(); // com.sec.a.a.a.p.j -> void
        v0 = v2.c; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        _result = v3.b(); // com.sec.a.a.a.o.b -> com.google.protobuf.LazyStringList
        v1 = _result;
        _result = com.google.protobuf.LazyStringList.addAll(v0, v1); // -> boolean
        // goto L_0006
    }

    public com.sec.a.a.a.p a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.p.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.a.a.a.p.a:int
        v1.b = v2; // com.sec.a.a.a.p.b:java.lang.Object
        return v1;
    }

    public com.sec.a.a.a.p b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.a.a.a.p.h -> com.sec.a.a.a.p
        v0 = _result;
        _result = v2.e(); // com.sec.a.a.a.p.e -> com.sec.a.a.a.o
        v1 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.p.a -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.p b(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        _result = v1.j(); // com.sec.a.a.a.p.j -> void
        v0 = v1.c; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.add(v0, v2); // -> boolean
        return v1;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.a.a.a.p.d -> com.sec.a.a.a.o
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.a.a.a.p.e -> com.sec.a.a.a.o
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.o c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.a.a.a.o.a -> com.sec.a.a.a.o
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.p.a -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.p.a -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.p.b -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.p.b -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.p.b -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.p.b -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.o d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.p.e -> com.sec.a.a.a.o
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.o.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.p.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.o e() {
        // Registers (5 total): v4 = this
        v0 = 1;
        v2 = new com.sec.a.a.a.o;
        v1 = 0;
        _result = v2.<init>(v4, v1); // com.sec.a.a.a.o.<init> -> void
        v3 = v4.a; // com.sec.a.a.a.p.a:int
        v1 = 0;
        v3 = binOpLit8_0xdd(v3, 1);
        if (v3 != v0) /* goto L_0032 */;
        v1 = v4.b; // com.sec.a.a.a.p.b:java.lang.Object
        _result = v2.a(v1); // com.sec.a.a.a.o.a -> java.lang.Object
        v1 = v4.a; // com.sec.a.a.a.p.a:int
        v1 = binOpLit8_0xdd(v1, 2);
        v3 = 2;
        if (v1 != v3) /* goto L_0029 */;
        v1 = new com.google.protobuf.UnmodifiableLazyStringList;
        v3 = v4.c; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        _result = v1.<init>(v3); // com.google.protobuf.UnmodifiableLazyStringList.<init> -> void
        v4.c = v1; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        v1 = v4.a; // com.sec.a.a.a.p.a:int
        v1 = binOpLit8_0xdd(v1, -3);
        v4.a = v1; // com.sec.a.a.a.p.a:int
        v1 = v4.c; // com.sec.a.a.a.p.c:com.google.protobuf.LazyStringList
        _result = v2.a(v1); // com.sec.a.a.a.o.a -> com.google.protobuf.LazyStringList
        _result = v2.a(v0); // com.sec.a.a.a.o.a -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.p.c -> com.sec.a.a.a.o
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.p.c -> com.sec.a.a.a.o
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.p.a -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.a.a.a.o) v2;
        _result = v1.a(v2); // com.sec.a.a.a.p.a -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.p.a -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

}