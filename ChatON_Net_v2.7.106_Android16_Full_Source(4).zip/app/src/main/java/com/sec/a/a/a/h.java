package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/h;
 */
public interface h extends com.google.protobuf.MessageLiteOrBuilder {
}