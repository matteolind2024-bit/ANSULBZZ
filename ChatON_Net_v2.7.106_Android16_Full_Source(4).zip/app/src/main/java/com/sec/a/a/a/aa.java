package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/aa;
 */
public final class aa extends com.google.protobuf.GeneratedMessageLite implements com.sec.a.a.a.ac {
    private static final com.sec.a.a.a.aa a;
    private int b;
    private int c;
    private long d;
    private int e;
    private byte f;
    private int g;

    static {
        v0 = new com.sec.a.a.a.aa;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.a.a.a.aa.<init> -> void
        com.sec.a.a.a.aa.a = v0; // :com.sec.a.a.a.aa
        v0 = com.sec.a.a.a.aa.a; // :com.sec.a.a.a.aa
        _result = v0.k(); // com.sec.a.a.a.aa.k -> void
        return;
    }

    private aa(com.sec.a.a.a.ab p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.ab)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.f = v0; // com.sec.a.a.a.aa.f:byte
        v1.g = v0; // com.sec.a.a.a.aa.g:int
        return;
    }

    aa(com.sec.a.a.a.ab p0, com.sec.a.a.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.a.a.a.ab), v2 = p1 (com.sec.a.a.a.b)
        _result = v0.<init>(v1); // com.sec.a.a.a.aa.<init> -> void
        return;
    }

    private aa(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.f = v0; // com.sec.a.a.a.aa.f:byte
        v1.g = v0; // com.sec.a.a.a.aa.g:int
        return;
    }

    static int a(com.sec.a.a.a.aa p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.aa), v1 = p1 (int)
        v0.c = v1; // com.sec.a.a.a.aa.c:int
        return v1;
    }

    static long a(com.sec.a.a.a.aa p0, long p1) {
        // Registers (3 total): v0 = p0 (com.sec.a.a.a.aa), v1 = p1 (long)
        v0.d = v1; // com.sec.a.a.a.aa.d:long
        return v1;
    }

    public static com.sec.a.a.a.aa a() {
        v0 = com.sec.a.a.a.aa.a; // :com.sec.a.a.a.aa
        return v0;
    }

    public static com.sec.a.a.a.aa a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.a.a.a.aa.newBuilder -> com.sec.a.a.a.ab
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.a.a.a.ab.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.a.a.a.ab) v0;
        _result = v0.a(); // com.sec.a.a.a.ab.a -> com.sec.a.a.a.aa
        v0 = _result;
        return v0;
    }

    public static com.sec.a.a.a.ab a(com.sec.a.a.a.aa p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.aa)
        _result = this.newBuilder(); // com.sec.a.a.a.aa.newBuilder -> com.sec.a.a.a.ab
        v0 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.ab.a -> com.sec.a.a.a.ab
        v0 = _result;
        return v0;
    }

    static int b(com.sec.a.a.a.aa p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.aa), v1 = p1 (int)
        v0.e = v1; // com.sec.a.a.a.aa.e:int
        return v1;
    }

    static int c(com.sec.a.a.a.aa p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.aa), v1 = p1 (int)
        v0.b = v1; // com.sec.a.a.a.aa.b:int
        return v1;
    }

    private void k() {
        // Registers (4 total): v3 = this
        v2 = 0;
        v3.c = v2; // com.sec.a.a.a.aa.c:int
        v0 = 0L;
        v3.d = v0; // com.sec.a.a.a.aa.d:long
        v3.e = v2; // com.sec.a.a.a.aa.e:int
        return;
    }

    public static com.sec.a.a.a.ab newBuilder() {
        _result = this.f(); // com.sec.a.a.a.ab.f -> com.sec.a.a.a.ab
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.aa b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.a.a.a.aa.a; // :com.sec.a.a.a.aa
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.a.a.a.aa.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public int d() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.sec.a.a.a.aa.c:int
        return v0;
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.aa.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public long f() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.a.a.a.aa.d:long
        return v0;
    }

    public boolean g() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.aa.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.aa.b -> com.sec.a.a.a.aa
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (5 total): v4 = this
        v3 = 2;
        v2 = 1;
        v0 = v4.g; // com.sec.a.a.a.aa.g:int
        v1 = -1;
        if (v0 == v1) /* goto L_0008 */;
        return v0;
        v0 = 0;
        v1 = v4.b; // com.sec.a.a.a.aa.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v2) /* goto L_0016 */;
        v1 = v4.c; // com.sec.a.a.a.aa.c:int
        _result = v2.computeInt32Size(v1); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v4.b; // com.sec.a.a.a.aa.b:int
        v1 = binOpLit8_0xdd(v1, 2);
        if (v1 != v3) /* goto L_0023 */;
        v1 = v4.d; // com.sec.a.a.a.aa.d:long
        _result = v3.computeInt64Size(v1, v2); // com.google.protobuf.CodedOutputStream.computeInt64Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v4.b; // com.sec.a.a.a.aa.b:int
        v1 = binOpLit8_0xdd(v1, 4);
        v2 = 4;
        if (v1 != v2) /* goto L_0032 */;
        v1 = 3;
        v2 = v4.e; // com.sec.a.a.a.aa.e:int
        _result = v1.computeInt32Size(v2); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v4.g = v0; // com.sec.a.a.a.aa.g:int
        // goto L_0007
    }

    public int h() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.sec.a.a.a.aa.e:int
        return v0;
    }

    public com.sec.a.a.a.ab i() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.a.a.a.aa.newBuilder -> com.sec.a.a.a.ab
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.f; // com.sec.a.a.a.aa.f:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.f = v0; // com.sec.a.a.a.aa.f:byte
        // goto L_0008
    }

    public com.sec.a.a.a.ab j() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.aa.a -> com.sec.a.a.a.ab
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.i(); // com.sec.a.a.a.aa.i -> com.sec.a.a.a.ab
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.j(); // com.sec.a.a.a.aa.j -> com.sec.a.a.a.ab
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (5 total): v3 = this, v4 = p0 (com.google.protobuf.CodedOutputStream)
        v2 = 2;
        v1 = 1;
        _result = v3.getSerializedSize(); // com.sec.a.a.a.aa.getSerializedSize -> int
        v0 = v3.b; // com.sec.a.a.a.aa.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v1) /* goto L_0010 */;
        v0 = v3.c; // com.sec.a.a.a.aa.c:int
        _result = v4.writeInt32(v1, v0); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v3.b; // com.sec.a.a.a.aa.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v2) /* goto L_001b */;
        v0 = v3.d; // com.sec.a.a.a.aa.d:long
        _result = v4.writeInt64(v2, v0, v1); // com.google.protobuf.CodedOutputStream.writeInt64 -> void
        v0 = v3.b; // com.sec.a.a.a.aa.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0028 */;
        v0 = 3;
        v1 = v3.e; // com.sec.a.a.a.aa.e:int
        _result = v4.writeInt32(v0, v1); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        return;
    }

}