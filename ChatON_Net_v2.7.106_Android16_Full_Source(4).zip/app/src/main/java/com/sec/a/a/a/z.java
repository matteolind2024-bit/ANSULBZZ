package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/z;
 */
public interface z extends com.google.protobuf.MessageLiteOrBuilder {
}