package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/l;
 */
public final class l extends com.google.protobuf.GeneratedMessageLite implements com.sec.a.a.a.n {
    private static final com.sec.a.a.a.l a;
    private int b;
    private int c;
    private java.lang.Object d;
    private byte e;
    private int f;

    static {
        v0 = new com.sec.a.a.a.l;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.a.a.a.l.<init> -> void
        com.sec.a.a.a.l.a = v0; // :com.sec.a.a.a.l
        v0 = com.sec.a.a.a.l.a; // :com.sec.a.a.a.l
        _result = v0.j(); // com.sec.a.a.a.l.j -> void
        return;
    }

    private l(com.sec.a.a.a.m p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.m)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.e = v0; // com.sec.a.a.a.l.e:byte
        v1.f = v0; // com.sec.a.a.a.l.f:int
        return;
    }

    l(com.sec.a.a.a.m p0, com.sec.a.a.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.a.a.a.m), v2 = p1 (com.sec.a.a.a.b)
        _result = v0.<init>(v1); // com.sec.a.a.a.l.<init> -> void
        return;
    }

    private l(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.e = v0; // com.sec.a.a.a.l.e:byte
        v1.f = v0; // com.sec.a.a.a.l.f:int
        return;
    }

    static int a(com.sec.a.a.a.l p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.l), v1 = p1 (int)
        v0.c = v1; // com.sec.a.a.a.l.c:int
        return v1;
    }

    public static com.sec.a.a.a.l a() {
        v0 = com.sec.a.a.a.l.a; // :com.sec.a.a.a.l
        return v0;
    }

    public static com.sec.a.a.a.l a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.a.a.a.l.newBuilder -> com.sec.a.a.a.m
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.a.a.a.m.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.a.a.a.m) v0;
        _result = v0.a(); // com.sec.a.a.a.m.a -> com.sec.a.a.a.l
        v0 = _result;
        return v0;
    }

    public static com.sec.a.a.a.m a(com.sec.a.a.a.l p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.l)
        _result = this.newBuilder(); // com.sec.a.a.a.l.newBuilder -> com.sec.a.a.a.m
        v0 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.m.a -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    static java.lang.Object a(com.sec.a.a.a.l p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.l), v1 = p1 (java.lang.Object)
        v0.d = v1; // com.sec.a.a.a.l.d:java.lang.Object
        return v1;
    }

    static int b(com.sec.a.a.a.l p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.l), v1 = p1 (int)
        v0.b = v1; // com.sec.a.a.a.l.b:int
        return v1;
    }

    private com.google.protobuf.ByteString i() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.a.a.a.l.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.d = v0; // com.sec.a.a.a.l.d:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void j() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.c = v0; // com.sec.a.a.a.l.c:int
        v0 = "";
        v1.d = v0; // com.sec.a.a.a.l.d:java.lang.Object
        return;
    }

    public static com.sec.a.a.a.m newBuilder() {
        _result = this.f(); // com.sec.a.a.a.m.f -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.l b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.a.a.a.l.a; // :com.sec.a.a.a.l
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.a.a.a.l.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public int d() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.sec.a.a.a.l.c:int
        return v0;
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.l.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public java.lang.String f() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.a.a.a.l.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.d = v1; // com.sec.a.a.a.l.d:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public com.sec.a.a.a.m g() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.a.a.a.l.newBuilder -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.l.b -> com.sec.a.a.a.l
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (5 total): v4 = this
        v3 = 2;
        v2 = 1;
        v0 = v4.f; // com.sec.a.a.a.l.f:int
        v1 = -1;
        if (v0 == v1) /* goto L_0008 */;
        return v0;
        v0 = 0;
        v1 = v4.b; // com.sec.a.a.a.l.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v2) /* goto L_0016 */;
        v1 = v4.c; // com.sec.a.a.a.l.c:int
        _result = v2.computeInt32Size(v1); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v4.b; // com.sec.a.a.a.l.b:int
        v1 = binOpLit8_0xdd(v1, 2);
        if (v1 != v3) /* goto L_0025 */;
        _result = v4.i(); // com.sec.a.a.a.l.i -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v3.computeBytesSize(v1); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v4.f = v0; // com.sec.a.a.a.l.f:int
        // goto L_0007
    }

    public com.sec.a.a.a.m h() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.l.a -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.e; // com.sec.a.a.a.l.e:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.e = v0; // com.sec.a.a.a.l.e:byte
        // goto L_0008
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.g(); // com.sec.a.a.a.l.g -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.h(); // com.sec.a.a.a.l.h -> com.sec.a.a.a.m
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (5 total): v3 = this, v4 = p0 (com.google.protobuf.CodedOutputStream)
        v2 = 2;
        v1 = 1;
        _result = v3.getSerializedSize(); // com.sec.a.a.a.l.getSerializedSize -> int
        v0 = v3.b; // com.sec.a.a.a.l.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v1) /* goto L_0010 */;
        v0 = v3.c; // com.sec.a.a.a.l.c:int
        _result = v4.writeInt32(v1, v0); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v3.b; // com.sec.a.a.a.l.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v2) /* goto L_001d */;
        _result = v3.i(); // com.sec.a.a.a.l.i -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v4.writeBytes(v2, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        return;
    }

}