package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/s;
 */
public final class s extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.a.a.a.t {
    private int a;
    private java.lang.Object b;
    private java.lang.Object c;
    private int d;
    private int e;
    private java.lang.Object f;
    private java.lang.Object g;
    private java.lang.Object h;
    private long i;
    private int j;
    private java.lang.Object k;

    private s() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = "";
        v1.b = v0; // com.sec.a.a.a.s.b:java.lang.Object
        v0 = "";
        v1.c = v0; // com.sec.a.a.a.s.c:java.lang.Object
        v0 = "";
        v1.f = v0; // com.sec.a.a.a.s.f:java.lang.Object
        v0 = "";
        v1.g = v0; // com.sec.a.a.a.s.g:java.lang.Object
        v0 = "";
        v1.h = v0; // com.sec.a.a.a.s.h:java.lang.Object
        v0 = "";
        v1.k = v0; // com.sec.a.a.a.s.k:java.lang.Object
        _result = v1.g(); // com.sec.a.a.a.s.g -> void
        return;
    }

    static com.sec.a.a.a.r a(com.sec.a.a.a.s p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.s)
        _result = v1.i(); // com.sec.a.a.a.s.i -> com.sec.a.a.a.r
        v0 = _result;
        return v0;
    }

    static com.sec.a.a.a.s f() {
        _result = this.h(); // com.sec.a.a.a.s.h -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.a.a.a.s h() {
        v0 = new com.sec.a.a.a.s;
        _result = v0.<init>(); // com.sec.a.a.a.s.<init> -> void
        return v0;
    }

    private com.sec.a.a.a.r i() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.s.e -> com.sec.a.a.a.r
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.r.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.s.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.s a() {
        // Registers (4 total): v3 = this
        v2 = 0;
        _result = v3.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = "";
        v3.b = v0; // com.sec.a.a.a.s.b:java.lang.Object
        v0 = v3.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v3.a = v0; // com.sec.a.a.a.s.a:int
        v0 = "";
        v3.c = v0; // com.sec.a.a.a.s.c:java.lang.Object
        v0 = v3.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v3.a = v0; // com.sec.a.a.a.s.a:int
        v3.d = v2; // com.sec.a.a.a.s.d:int
        v0 = v3.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v3.a = v0; // com.sec.a.a.a.s.a:int
        v3.e = v2; // com.sec.a.a.a.s.e:int
        v0 = v3.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xdd(v0, -9);
        v3.a = v0; // com.sec.a.a.a.s.a:int
        v0 = "";
        v3.f = v0; // com.sec.a.a.a.s.f:java.lang.Object
        v0 = v3.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xdd(v0, -17);
        v3.a = v0; // com.sec.a.a.a.s.a:int
        v0 = "";
        v3.g = v0; // com.sec.a.a.a.s.g:java.lang.Object
        v0 = v3.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xdd(v0, -33);
        v3.a = v0; // com.sec.a.a.a.s.a:int
        v0 = "";
        v3.h = v0; // com.sec.a.a.a.s.h:java.lang.Object
        v0 = v3.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xdd(v0, -65);
        v3.a = v0; // com.sec.a.a.a.s.a:int
        v0 = 0L;
        v3.i = v0; // com.sec.a.a.a.s.i:long
        v0 = v3.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit16_0xd5(v0, -129);
        v3.a = v0; // com.sec.a.a.a.s.a:int
        v3.j = v2; // com.sec.a.a.a.s.j:int
        v0 = v3.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit16_0xd5(v0, -257);
        v3.a = v0; // com.sec.a.a.a.s.a:int
        v0 = "";
        v3.k = v0; // com.sec.a.a.a.s.k:java.lang.Object
        v0 = v3.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit16_0xd5(v0, -513);
        v3.a = v0; // com.sec.a.a.a.s.a:int
        return v3;
    }

    public com.sec.a.a.a.s a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.a.a.a.s.a:int
        v1.d = v2; // com.sec.a.a.a.s.d:int
        return v1;
    }

    public com.sec.a.a.a.s a(long p0) {
        // Registers (4 total): v1 = this, v2 = p0 (long)
        v0 = v1.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit16_0xd6(v0, 128);
        v1.a = v0; // com.sec.a.a.a.s.a:int
        v1.i = v2; // com.sec.a.a.a.s.i:long
        return v1;
    }

    public com.sec.a.a.a.s a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.CodedInputStream), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v2.parseUnknownField(v3, v4, v0); // com.sec.a.a.a.s.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v2;
        v0 = v2.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v2.a = v0; // com.sec.a.a.a.s.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.b = v0; // com.sec.a.a.a.s.b:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v2.a = v0; // com.sec.a.a.a.s.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.c = v0; // com.sec.a.a.a.s.c:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v2.a = v0; // com.sec.a.a.a.s.a:int
        _result = v3.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v2.d = v0; // com.sec.a.a.a.s.d:int
        // goto L_0000
        v0 = v2.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v2.a = v0; // com.sec.a.a.a.s.a:int
        _result = v3.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v2.e = v0; // com.sec.a.a.a.s.e:int
        // goto L_0000
        v0 = v2.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 16);
        v2.a = v0; // com.sec.a.a.a.s.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.f = v0; // com.sec.a.a.a.s.f:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 32);
        v2.a = v0; // com.sec.a.a.a.s.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.g = v0; // com.sec.a.a.a.s.g:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 64);
        v2.a = v0; // com.sec.a.a.a.s.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.h = v0; // com.sec.a.a.a.s.h:java.lang.Object
        // goto L_0000
        v0 = v2.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit16_0xd6(v0, 128);
        v2.a = v0; // com.sec.a.a.a.s.a:int
        _result = v3.readInt64(); // com.google.protobuf.CodedInputStream.readInt64 -> long
        v0 = _result;
        v2.i = v0; // com.sec.a.a.a.s.i:long
        // goto L_0000
        v0 = v2.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit16_0xd6(v0, 256);
        v2.a = v0; // com.sec.a.a.a.s.a:int
        _result = v3.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v2.j = v0; // com.sec.a.a.a.s.j:int
        // goto L_0000
        v0 = v2.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit16_0xd6(v0, 512);
        v2.a = v0; // com.sec.a.a.a.s.a:int
        _result = v3.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v2.k = v0; // com.sec.a.a.a.s.k:java.lang.Object
        // goto L_0000
    }

    public com.sec.a.a.a.s a(com.sec.a.a.a.r p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.a.a.a.r)
        _result = this.a(); // com.sec.a.a.a.r.a -> com.sec.a.a.a.r
        v0 = _result;
        if (v3 != v0) /* goto L_0007 */;
        return v2;
        _result = v3.c(); // com.sec.a.a.a.r.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v3.d(); // com.sec.a.a.a.r.d -> java.lang.String
        v0 = _result;
        _result = v2.a(v0); // com.sec.a.a.a.s.a -> com.sec.a.a.a.s
        _result = v3.e(); // com.sec.a.a.a.r.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v3.f(); // com.sec.a.a.a.r.f -> java.lang.String
        v0 = _result;
        _result = v2.b(v0); // com.sec.a.a.a.s.b -> com.sec.a.a.a.s
        _result = v3.g(); // com.sec.a.a.a.r.g -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002e */;
        _result = v3.h(); // com.sec.a.a.a.r.h -> int
        v0 = _result;
        _result = v2.a(v0); // com.sec.a.a.a.s.a -> com.sec.a.a.a.s
        _result = v3.i(); // com.sec.a.a.a.r.i -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003b */;
        _result = v3.j(); // com.sec.a.a.a.r.j -> int
        v0 = _result;
        _result = v2.b(v0); // com.sec.a.a.a.s.b -> com.sec.a.a.a.s
        _result = v3.k(); // com.sec.a.a.a.r.k -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0048 */;
        _result = v3.l(); // com.sec.a.a.a.r.l -> java.lang.String
        v0 = _result;
        _result = v2.c(v0); // com.sec.a.a.a.s.c -> com.sec.a.a.a.s
        _result = v3.m(); // com.sec.a.a.a.r.m -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0055 */;
        _result = v3.n(); // com.sec.a.a.a.r.n -> java.lang.String
        v0 = _result;
        _result = v2.d(v0); // com.sec.a.a.a.s.d -> com.sec.a.a.a.s
        _result = v3.o(); // com.sec.a.a.a.r.o -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0062 */;
        _result = v3.p(); // com.sec.a.a.a.r.p -> java.lang.String
        v0 = _result;
        _result = v2.e(v0); // com.sec.a.a.a.s.e -> com.sec.a.a.a.s
        _result = v3.q(); // com.sec.a.a.a.r.q -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_006f */;
        _result = v3.r(); // com.sec.a.a.a.r.r -> long
        v0 = _result;
        _result = v2.a(v0, v1); // com.sec.a.a.a.s.a -> com.sec.a.a.a.s
        _result = v3.s(); // com.sec.a.a.a.r.s -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_007c */;
        _result = v3.t(); // com.sec.a.a.a.r.t -> int
        v0 = _result;
        _result = v2.c(v0); // com.sec.a.a.a.s.c -> com.sec.a.a.a.s
        _result = v3.u(); // com.sec.a.a.a.r.u -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0006 */;
        _result = v3.v(); // com.sec.a.a.a.r.v -> java.lang.String
        v0 = _result;
        _result = v2.f(v0); // com.sec.a.a.a.s.f -> com.sec.a.a.a.s
        // goto L_0006
    }

    public com.sec.a.a.a.s a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.a.a.a.s.a:int
        v1.b = v2; // com.sec.a.a.a.s.b:java.lang.Object
        return v1;
    }

    public com.sec.a.a.a.s b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.a.a.a.s.h -> com.sec.a.a.a.s
        v0 = _result;
        _result = v2.e(); // com.sec.a.a.a.s.e -> com.sec.a.a.a.r
        v1 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.s.a -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.s b(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v1.a = v0; // com.sec.a.a.a.s.a:int
        v1.e = v2; // com.sec.a.a.a.s.e:int
        return v1;
    }

    public com.sec.a.a.a.s b(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.a.a.a.s.a:int
        v1.c = v2; // com.sec.a.a.a.s.c:java.lang.Object
        return v1;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.a.a.a.s.d -> com.sec.a.a.a.r
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.a.a.a.s.e -> com.sec.a.a.a.r
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.r c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.a.a.a.r.a -> com.sec.a.a.a.r
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.s c(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit16_0xd6(v0, 256);
        v1.a = v0; // com.sec.a.a.a.s.a:int
        v1.j = v2; // com.sec.a.a.a.s.j:int
        return v1;
    }

    public com.sec.a.a.a.s c(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 16);
        v1.a = v0; // com.sec.a.a.a.s.a:int
        v1.f = v2; // com.sec.a.a.a.s.f:java.lang.Object
        return v1;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.s.a -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.s.a -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.s.b -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.s.b -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.s.b -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.s.b -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.r d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.s.e -> com.sec.a.a.a.r
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.r.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.s.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.s d(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 32);
        v1.a = v0; // com.sec.a.a.a.s.a:int
        v1.g = v2; // com.sec.a.a.a.s.g:java.lang.Object
        return v1;
    }

    public com.sec.a.a.a.r e() {
        // Registers (7 total): v6 = this
        v0 = 1;
        v2 = new com.sec.a.a.a.r;
        v1 = 0;
        _result = v2.<init>(v6, v1); // com.sec.a.a.a.r.<init> -> void
        v3 = v6.a; // com.sec.a.a.a.s.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_008a */;
        v1 = v6.b; // com.sec.a.a.a.s.b:java.lang.Object
        _result = v2.a(v1); // com.sec.a.a.a.r.a -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 2);
        v4 = 2;
        if (v1 != v4) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v6.c; // com.sec.a.a.a.s.c:java.lang.Object
        _result = v2.b(v1); // com.sec.a.a.a.r.b -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 4);
        v4 = 4;
        if (v1 != v4) /* goto L_0026 */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = v6.d; // com.sec.a.a.a.s.d:int
        _result = v2.a(v1); // com.sec.a.a.a.r.a -> int
        v1 = binOpLit8_0xdd(v3, 8);
        v4 = 8;
        if (v1 != v4) /* goto L_0033 */;
        v0 = binOpLit8_0xde(v0, 8);
        v1 = v6.e; // com.sec.a.a.a.s.e:int
        _result = v2.b(v1); // com.sec.a.a.a.r.b -> int
        v1 = binOpLit8_0xdd(v3, 16);
        v4 = 16;
        if (v1 != v4) /* goto L_0040 */;
        v0 = binOpLit8_0xde(v0, 16);
        v1 = v6.f; // com.sec.a.a.a.s.f:java.lang.Object
        _result = v2.c(v1); // com.sec.a.a.a.r.c -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 32);
        v4 = 32;
        if (v1 != v4) /* goto L_004d */;
        v0 = binOpLit8_0xde(v0, 32);
        v1 = v6.g; // com.sec.a.a.a.s.g:java.lang.Object
        _result = v2.d(v1); // com.sec.a.a.a.r.d -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 64);
        v4 = 64;
        if (v1 != v4) /* goto L_005a */;
        v0 = binOpLit8_0xde(v0, 64);
        v1 = v6.h; // com.sec.a.a.a.s.h:java.lang.Object
        _result = v2.e(v1); // com.sec.a.a.a.r.e -> java.lang.Object
        v1 = binOpLit16_0xd5(v3, 128);
        v4 = 128;
        if (v1 != v4) /* goto L_0067 */;
        v0 = binOpLit16_0xd6(v0, 128);
        v4 = v6.i; // com.sec.a.a.a.s.i:long
        _result = v2.a(v4, v5); // com.sec.a.a.a.r.a -> long
        v1 = binOpLit16_0xd5(v3, 256);
        v4 = 256;
        if (v1 != v4) /* goto L_0074 */;
        v0 = binOpLit16_0xd6(v0, 256);
        v1 = v6.j; // com.sec.a.a.a.s.j:int
        _result = v2.c(v1); // com.sec.a.a.a.r.c -> int
        v1 = binOpLit16_0xd5(v3, 512);
        v3 = 512;
        if (v1 != v3) /* goto L_0081 */;
        v0 = binOpLit16_0xd6(v0, 512);
        v1 = v6.k; // com.sec.a.a.a.s.k:java.lang.Object
        _result = v2.f(v1); // com.sec.a.a.a.r.f -> java.lang.Object
        _result = v2.d(v0); // com.sec.a.a.a.r.d -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.sec.a.a.a.s e(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit8_0xde(v0, 64);
        v1.a = v0; // com.sec.a.a.a.s.a:int
        v1.h = v2; // com.sec.a.a.a.s.h:java.lang.Object
        return v1;
    }

    public com.sec.a.a.a.s f(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.s.a:int
        v0 = binOpLit16_0xd6(v0, 512);
        v1.a = v0; // com.sec.a.a.a.s.a:int
        v1.k = v2; // com.sec.a.a.a.s.k:java.lang.Object
        return v1;
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.s.c -> com.sec.a.a.a.r
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.s.c -> com.sec.a.a.a.r
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.s.a -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.a.a.a.r) v2;
        _result = v1.a(v2); // com.sec.a.a.a.s.a -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.s.a -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

}