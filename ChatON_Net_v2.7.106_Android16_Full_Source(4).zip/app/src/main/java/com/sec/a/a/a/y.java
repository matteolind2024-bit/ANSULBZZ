package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/y;
 */
public final class y extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.a.a.a.z {
    private int a;
    private int b;
    private long c;
    private int d;

    private y() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        _result = v0.g(); // com.sec.a.a.a.y.g -> void
        return;
    }

    static com.sec.a.a.a.x a(com.sec.a.a.a.y p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.y)
        _result = v1.i(); // com.sec.a.a.a.y.i -> com.sec.a.a.a.x
        v0 = _result;
        return v0;
    }

    static com.sec.a.a.a.y f() {
        _result = this.h(); // com.sec.a.a.a.y.h -> com.sec.a.a.a.y
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.a.a.a.y h() {
        v0 = new com.sec.a.a.a.y;
        _result = v0.<init>(); // com.sec.a.a.a.y.<init> -> void
        return v0;
    }

    private com.sec.a.a.a.x i() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.y.e -> com.sec.a.a.a.x
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.x.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.y.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.y a() {
        // Registers (4 total): v3 = this
        v2 = 0;
        _result = v3.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v3.b = v2; // com.sec.a.a.a.y.b:int
        v0 = v3.a; // com.sec.a.a.a.y.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v3.a = v0; // com.sec.a.a.a.y.a:int
        v0 = 0L;
        v3.c = v0; // com.sec.a.a.a.y.c:long
        v0 = v3.a; // com.sec.a.a.a.y.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v3.a = v0; // com.sec.a.a.a.y.a:int
        v3.d = v2; // com.sec.a.a.a.y.d:int
        v0 = v3.a; // com.sec.a.a.a.y.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v3.a = v0; // com.sec.a.a.a.y.a:int
        return v3;
    }

    public com.sec.a.a.a.y a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.y.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.a.a.a.y.a:int
        v1.b = v2; // com.sec.a.a.a.y.b:int
        return v1;
    }

    public com.sec.a.a.a.y a(long p0) {
        // Registers (4 total): v1 = this, v2 = p0 (long)
        v0 = v1.a; // com.sec.a.a.a.y.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.a.a.a.y.a:int
        v1.c = v2; // com.sec.a.a.a.y.c:long
        return v1;
    }

    public com.sec.a.a.a.y a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.CodedInputStream), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v2.parseUnknownField(v3, v4, v0); // com.sec.a.a.a.y.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v2;
        v0 = v2.a; // com.sec.a.a.a.y.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v2.a = v0; // com.sec.a.a.a.y.a:int
        _result = v3.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v2.b = v0; // com.sec.a.a.a.y.b:int
        // goto L_0000
        v0 = v2.a; // com.sec.a.a.a.y.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v2.a = v0; // com.sec.a.a.a.y.a:int
        _result = v3.readInt64(); // com.google.protobuf.CodedInputStream.readInt64 -> long
        v0 = _result;
        v2.c = v0; // com.sec.a.a.a.y.c:long
        // goto L_0000
        v0 = v2.a; // com.sec.a.a.a.y.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v2.a = v0; // com.sec.a.a.a.y.a:int
        _result = v3.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v2.d = v0; // com.sec.a.a.a.y.d:int
        // goto L_0000
    }

    public com.sec.a.a.a.y a(com.sec.a.a.a.x p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.sec.a.a.a.x)
        _result = this.a(); // com.sec.a.a.a.x.a -> com.sec.a.a.a.x
        v0 = _result;
        if (v3 != v0) /* goto L_0007 */;
        return v2;
        _result = v3.c(); // com.sec.a.a.a.x.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v3.d(); // com.sec.a.a.a.x.d -> int
        v0 = _result;
        _result = v2.a(v0); // com.sec.a.a.a.y.a -> com.sec.a.a.a.y
        _result = v3.e(); // com.sec.a.a.a.x.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v3.f(); // com.sec.a.a.a.x.f -> long
        v0 = _result;
        _result = v2.a(v0, v1); // com.sec.a.a.a.y.a -> com.sec.a.a.a.y
        _result = v3.g(); // com.sec.a.a.a.x.g -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0006 */;
        _result = v3.h(); // com.sec.a.a.a.x.h -> int
        v0 = _result;
        _result = v2.b(v0); // com.sec.a.a.a.y.b -> com.sec.a.a.a.y
        // goto L_0006
    }

    public com.sec.a.a.a.y b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.a.a.a.y.h -> com.sec.a.a.a.y
        v0 = _result;
        _result = v2.e(); // com.sec.a.a.a.y.e -> com.sec.a.a.a.x
        v1 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.y.a -> com.sec.a.a.a.y
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.y b(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.y.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.a.a.a.y.a:int
        v1.d = v2; // com.sec.a.a.a.y.d:int
        return v1;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.a.a.a.y.d -> com.sec.a.a.a.x
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.a.a.a.y.e -> com.sec.a.a.a.x
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.x c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.a.a.a.x.a -> com.sec.a.a.a.x
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.y.a -> com.sec.a.a.a.y
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.y.a -> com.sec.a.a.a.y
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.y.b -> com.sec.a.a.a.y
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.y.b -> com.sec.a.a.a.y
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.y.b -> com.sec.a.a.a.y
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.y.b -> com.sec.a.a.a.y
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.x d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.y.e -> com.sec.a.a.a.x
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.x.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.y.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.x e() {
        // Registers (7 total): v6 = this
        v0 = 1;
        v2 = new com.sec.a.a.a.x;
        v1 = 0;
        _result = v2.<init>(v6, v1); // com.sec.a.a.a.x.<init> -> void
        v3 = v6.a; // com.sec.a.a.a.y.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_002f */;
        v1 = v6.b; // com.sec.a.a.a.y.b:int
        _result = v2.a(v1); // com.sec.a.a.a.x.a -> int
        v1 = binOpLit8_0xdd(v3, 2);
        v4 = 2;
        if (v1 != v4) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v4 = v6.c; // com.sec.a.a.a.y.c:long
        _result = v2.a(v4, v5); // com.sec.a.a.a.x.a -> long
        v1 = binOpLit8_0xdd(v3, 4);
        v3 = 4;
        if (v1 != v3) /* goto L_0026 */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = v6.d; // com.sec.a.a.a.y.d:int
        _result = v2.b(v1); // com.sec.a.a.a.x.b -> int
        _result = v2.c(v0); // com.sec.a.a.a.x.c -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.y.c -> com.sec.a.a.a.x
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.y.c -> com.sec.a.a.a.x
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.y.a -> com.sec.a.a.a.y
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.a.a.a.x) v2;
        _result = v1.a(v2); // com.sec.a.a.a.y.a -> com.sec.a.a.a.y
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.y.a -> com.sec.a.a.a.y
        v0 = _result;
        return v0;
    }

}