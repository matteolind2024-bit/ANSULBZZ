package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/r;
 */
public final class r extends com.google.protobuf.GeneratedMessageLite implements com.sec.a.a.a.t {
    private static final com.sec.a.a.a.r a;
    private int b;
    private java.lang.Object c;
    private java.lang.Object d;
    private int e;
    private int f;
    private java.lang.Object g;
    private java.lang.Object h;
    private java.lang.Object i;
    private long j;
    private int k;
    private java.lang.Object l;
    private byte m;
    private int n;

    static {
        v0 = new com.sec.a.a.a.r;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.a.a.a.r.<init> -> void
        com.sec.a.a.a.r.a = v0; // :com.sec.a.a.a.r
        v0 = com.sec.a.a.a.r.a; // :com.sec.a.a.a.r
        _result = v0.E(); // com.sec.a.a.a.r.E -> void
        return;
    }

    private r(com.sec.a.a.a.s p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.s)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.m = v0; // com.sec.a.a.a.r.m:byte
        v1.n = v0; // com.sec.a.a.a.r.n:int
        return;
    }

    r(com.sec.a.a.a.s p0, com.sec.a.a.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.a.a.a.s), v2 = p1 (com.sec.a.a.a.b)
        _result = v0.<init>(v1); // com.sec.a.a.a.r.<init> -> void
        return;
    }

    private r(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.m = v0; // com.sec.a.a.a.r.m:byte
        v1.n = v0; // com.sec.a.a.a.r.n:int
        return;
    }

    private com.google.protobuf.ByteString A() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.sec.a.a.a.r.g:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.g = v0; // com.sec.a.a.a.r.g:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString B() {
        // Registers (3 total): v2 = this
        v0 = v2.h; // com.sec.a.a.a.r.h:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.h = v0; // com.sec.a.a.a.r.h:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString C() {
        // Registers (3 total): v2 = this
        v0 = v2.i; // com.sec.a.a.a.r.i:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.i = v0; // com.sec.a.a.a.r.i:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString D() {
        // Registers (3 total): v2 = this
        v0 = v2.l; // com.sec.a.a.a.r.l:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.l = v0; // com.sec.a.a.a.r.l:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void E() {
        // Registers (4 total): v3 = this
        v2 = 0;
        v0 = "";
        v3.c = v0; // com.sec.a.a.a.r.c:java.lang.Object
        v0 = "";
        v3.d = v0; // com.sec.a.a.a.r.d:java.lang.Object
        v3.e = v2; // com.sec.a.a.a.r.e:int
        v3.f = v2; // com.sec.a.a.a.r.f:int
        v0 = "";
        v3.g = v0; // com.sec.a.a.a.r.g:java.lang.Object
        v0 = "";
        v3.h = v0; // com.sec.a.a.a.r.h:java.lang.Object
        v0 = "";
        v3.i = v0; // com.sec.a.a.a.r.i:java.lang.Object
        v0 = 0L;
        v3.j = v0; // com.sec.a.a.a.r.j:long
        v3.k = v2; // com.sec.a.a.a.r.k:int
        v0 = "";
        v3.l = v0; // com.sec.a.a.a.r.l:java.lang.Object
        return;
    }

    static int a(com.sec.a.a.a.r p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.r), v1 = p1 (int)
        v0.e = v1; // com.sec.a.a.a.r.e:int
        return v1;
    }

    static long a(com.sec.a.a.a.r p0, long p1) {
        // Registers (3 total): v0 = p0 (com.sec.a.a.a.r), v1 = p1 (long)
        v0.j = v1; // com.sec.a.a.a.r.j:long
        return v1;
    }

    public static com.sec.a.a.a.r a() {
        v0 = com.sec.a.a.a.r.a; // :com.sec.a.a.a.r
        return v0;
    }

    public static com.sec.a.a.a.r a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.a.a.a.r.newBuilder -> com.sec.a.a.a.s
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.a.a.a.s.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.a.a.a.s) v0;
        _result = v0.a(); // com.sec.a.a.a.s.a -> com.sec.a.a.a.r
        v0 = _result;
        return v0;
    }

    public static com.sec.a.a.a.s a(com.sec.a.a.a.r p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.r)
        _result = this.newBuilder(); // com.sec.a.a.a.r.newBuilder -> com.sec.a.a.a.s
        v0 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.s.a -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    static java.lang.Object a(com.sec.a.a.a.r p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.r), v1 = p1 (java.lang.Object)
        v0.c = v1; // com.sec.a.a.a.r.c:java.lang.Object
        return v1;
    }

    static int b(com.sec.a.a.a.r p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.r), v1 = p1 (int)
        v0.f = v1; // com.sec.a.a.a.r.f:int
        return v1;
    }

    static java.lang.Object b(com.sec.a.a.a.r p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.r), v1 = p1 (java.lang.Object)
        v0.d = v1; // com.sec.a.a.a.r.d:java.lang.Object
        return v1;
    }

    static int c(com.sec.a.a.a.r p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.r), v1 = p1 (int)
        v0.k = v1; // com.sec.a.a.a.r.k:int
        return v1;
    }

    static java.lang.Object c(com.sec.a.a.a.r p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.r), v1 = p1 (java.lang.Object)
        v0.g = v1; // com.sec.a.a.a.r.g:java.lang.Object
        return v1;
    }

    static int d(com.sec.a.a.a.r p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.r), v1 = p1 (int)
        v0.b = v1; // com.sec.a.a.a.r.b:int
        return v1;
    }

    static java.lang.Object d(com.sec.a.a.a.r p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.r), v1 = p1 (java.lang.Object)
        v0.h = v1; // com.sec.a.a.a.r.h:java.lang.Object
        return v1;
    }

    static java.lang.Object e(com.sec.a.a.a.r p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.r), v1 = p1 (java.lang.Object)
        v0.i = v1; // com.sec.a.a.a.r.i:java.lang.Object
        return v1;
    }

    static java.lang.Object f(com.sec.a.a.a.r p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.r), v1 = p1 (java.lang.Object)
        v0.l = v1; // com.sec.a.a.a.r.l:java.lang.Object
        return v1;
    }

    public static com.sec.a.a.a.s newBuilder() {
        _result = this.f(); // com.sec.a.a.a.s.f -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    private com.google.protobuf.ByteString y() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.sec.a.a.a.r.c:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.c = v0; // com.sec.a.a.a.r.c:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString z() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.a.a.a.r.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.d = v0; // com.sec.a.a.a.r.d:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    public com.sec.a.a.a.r b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.a.a.a.r.a; // :com.sec.a.a.a.r
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.a.a.a.r.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public java.lang.String d() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.sec.a.a.a.r.c:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.c = v1; // com.sec.a.a.a.r.c:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public java.lang.String f() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.a.a.a.r.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.d = v1; // com.sec.a.a.a.r.d:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean g() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.r.b -> com.sec.a.a.a.r
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (6 total): v5 = this
        v4 = 4;
        v3 = 2;
        v2 = 1;
        v0 = v5.n; // com.sec.a.a.a.r.n:int
        v1 = -1;
        if (v0 == v1) /* goto L_0009 */;
        return v0;
        v0 = 0;
        v1 = v5.b; // com.sec.a.a.a.r.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v2) /* goto L_0019 */;
        _result = v5.y(); // com.sec.a.a.a.r.y -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v2.computeBytesSize(v1); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.r.b:int
        v1 = binOpLit8_0xdd(v1, 2);
        if (v1 != v3) /* goto L_0028 */;
        _result = v5.z(); // com.sec.a.a.a.r.z -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v3.computeBytesSize(v1); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.r.b:int
        v1 = binOpLit8_0xdd(v1, 4);
        if (v1 != v4) /* goto L_0036 */;
        v1 = 3;
        v2 = v5.e; // com.sec.a.a.a.r.e:int
        _result = v1.computeInt32Size(v2); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.r.b:int
        v1 = binOpLit8_0xdd(v1, 8);
        v2 = 8;
        if (v1 != v2) /* goto L_0045 */;
        v1 = v5.f; // com.sec.a.a.a.r.f:int
        _result = v4.computeInt32Size(v1); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.r.b:int
        v1 = binOpLit8_0xdd(v1, 16);
        v2 = 16;
        if (v1 != v2) /* goto L_0057 */;
        v1 = 5;
        _result = v5.A(); // com.sec.a.a.a.r.A -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.r.b:int
        v1 = binOpLit8_0xdd(v1, 32);
        v2 = 32;
        if (v1 != v2) /* goto L_0069 */;
        v1 = 6;
        _result = v5.B(); // com.sec.a.a.a.r.B -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.r.b:int
        v1 = binOpLit8_0xdd(v1, 64);
        v2 = 64;
        if (v1 != v2) /* goto L_007b */;
        v1 = 7;
        _result = v5.C(); // com.sec.a.a.a.r.C -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.r.b:int
        v1 = binOpLit16_0xd5(v1, 128);
        v2 = 128;
        if (v1 != v2) /* goto L_008c */;
        v1 = 11;
        v2 = v5.j; // com.sec.a.a.a.r.j:long
        _result = v1.computeInt64Size(v2, v3); // com.google.protobuf.CodedOutputStream.computeInt64Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.r.b:int
        v1 = binOpLit16_0xd5(v1, 256);
        v2 = 256;
        if (v1 != v2) /* goto L_009d */;
        v1 = 12;
        v2 = v5.k; // com.sec.a.a.a.r.k:int
        _result = v1.computeInt32Size(v2); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.r.b:int
        v1 = binOpLit16_0xd5(v1, 512);
        v2 = 512;
        if (v1 != v2) /* goto L_00b0 */;
        v1 = 13;
        _result = v5.D(); // com.sec.a.a.a.r.D -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v5.n = v0; // com.sec.a.a.a.r.n:int
        // goto L_0008
    }

    public int h() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.sec.a.a.a.r.e:int
        return v0;
    }

    public boolean i() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.m; // com.sec.a.a.a.r.m:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.m = v0; // com.sec.a.a.a.r.m:byte
        // goto L_0008
    }

    public int j() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // com.sec.a.a.a.r.f:int
        return v0;
    }

    public boolean k() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.lang.String l() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.sec.a.a.a.r.g:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.g = v1; // com.sec.a.a.a.r.g:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean m() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 32);
        v1 = 32;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.lang.String n() {
        // Registers (3 total): v2 = this
        v0 = v2.h; // com.sec.a.a.a.r.h:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.h = v1; // com.sec.a.a.a.r.h:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.w(); // com.sec.a.a.a.r.w -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    public boolean o() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 64);
        v1 = 64;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.lang.String p() {
        // Registers (3 total): v2 = this
        v0 = v2.i; // com.sec.a.a.a.r.i:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.i = v1; // com.sec.a.a.a.r.i:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean q() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit16_0xd5(v0, 128);
        v1 = 128;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public long r() {
        // Registers (3 total): v2 = this
        v0 = v2.j; // com.sec.a.a.a.r.j:long
        return v0;
    }

    public boolean s() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit16_0xd5(v0, 256);
        v1 = 256;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public int t() {
        // Registers (2 total): v1 = this
        v0 = v1.k; // com.sec.a.a.a.r.k:int
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.x(); // com.sec.a.a.a.r.x -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    public boolean u() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit16_0xd5(v0, 512);
        v1 = 512;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.lang.String v() {
        // Registers (3 total): v2 = this
        v0 = v2.l; // com.sec.a.a.a.r.l:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.l = v1; // com.sec.a.a.a.r.l:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public com.sec.a.a.a.s w() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.a.a.a.r.newBuilder -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (6 total): v4 = this, v5 = p0 (com.google.protobuf.CodedOutputStream)
        v3 = 4;
        v2 = 2;
        v1 = 1;
        _result = v4.getSerializedSize(); // com.sec.a.a.a.r.getSerializedSize -> int
        v0 = v4.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v1) /* goto L_0013 */;
        _result = v4.y(); // com.sec.a.a.a.r.y -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v5.writeBytes(v1, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v4.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v2) /* goto L_0020 */;
        _result = v4.z(); // com.sec.a.a.a.r.z -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v5.writeBytes(v2, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v4.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        if (v0 != v3) /* goto L_002c */;
        v0 = 3;
        v1 = v4.e; // com.sec.a.a.a.r.e:int
        _result = v5.writeInt32(v0, v1); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v4.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 != v1) /* goto L_0039 */;
        v0 = v4.f; // com.sec.a.a.a.r.f:int
        _result = v5.writeInt32(v3, v0); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v4.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_0049 */;
        v0 = 5;
        _result = v4.A(); // com.sec.a.a.a.r.A -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v5.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v4.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 32);
        v1 = 32;
        if (v0 != v1) /* goto L_0059 */;
        v0 = 6;
        _result = v4.B(); // com.sec.a.a.a.r.B -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v5.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v4.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit8_0xdd(v0, 64);
        v1 = 64;
        if (v0 != v1) /* goto L_0069 */;
        v0 = 7;
        _result = v4.C(); // com.sec.a.a.a.r.C -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v5.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v4.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit16_0xd5(v0, 128);
        v1 = 128;
        if (v0 != v1) /* goto L_0078 */;
        v0 = 11;
        v1 = v4.j; // com.sec.a.a.a.r.j:long
        _result = v5.writeInt64(v0, v1, v2); // com.google.protobuf.CodedOutputStream.writeInt64 -> void
        v0 = v4.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit16_0xd5(v0, 256);
        v1 = 256;
        if (v0 != v1) /* goto L_0087 */;
        v0 = 12;
        v1 = v4.k; // com.sec.a.a.a.r.k:int
        _result = v5.writeInt32(v0, v1); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v4.b; // com.sec.a.a.a.r.b:int
        v0 = binOpLit16_0xd5(v0, 512);
        v1 = 512;
        if (v0 != v1) /* goto L_0098 */;
        v0 = 13;
        _result = v4.D(); // com.sec.a.a.a.r.D -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v5.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        return;
    }

    public com.sec.a.a.a.s x() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.r.a -> com.sec.a.a.a.s
        v0 = _result;
        return v0;
    }

}