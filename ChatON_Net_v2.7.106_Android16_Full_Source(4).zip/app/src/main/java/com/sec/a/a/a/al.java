package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/al;
 */
public interface al extends com.google.protobuf.MessageLiteOrBuilder {
}