package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/k;
 */
public interface k extends com.google.protobuf.MessageLiteOrBuilder {
}