package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/ad;
 */
public final class ad extends com.google.protobuf.GeneratedMessageLite implements com.sec.a.a.a.af {
    private static final com.sec.a.a.a.ad a;
    private int b;
    private int c;
    private java.lang.Object d;
    private java.lang.Object e;
    private int f;
    private java.lang.Object g;
    private int h;
    private int i;
    private java.lang.Object j;
    private byte k;
    private int l;

    static {
        v0 = new com.sec.a.a.a.ad;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.a.a.a.ad.<init> -> void
        com.sec.a.a.a.ad.a = v0; // :com.sec.a.a.a.ad
        v0 = com.sec.a.a.a.ad.a; // :com.sec.a.a.a.ad
        _result = v0.y(); // com.sec.a.a.a.ad.y -> void
        return;
    }

    private ad(com.sec.a.a.a.ae p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.ae)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.k = v0; // com.sec.a.a.a.ad.k:byte
        v1.l = v0; // com.sec.a.a.a.ad.l:int
        return;
    }

    ad(com.sec.a.a.a.ae p0, com.sec.a.a.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.a.a.a.ae), v2 = p1 (com.sec.a.a.a.b)
        _result = v0.<init>(v1); // com.sec.a.a.a.ad.<init> -> void
        return;
    }

    private ad(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.k = v0; // com.sec.a.a.a.ad.k:byte
        v1.l = v0; // com.sec.a.a.a.ad.l:int
        return;
    }

    static int a(com.sec.a.a.a.ad p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.ad), v1 = p1 (int)
        v0.c = v1; // com.sec.a.a.a.ad.c:int
        return v1;
    }

    public static com.sec.a.a.a.ad a() {
        v0 = com.sec.a.a.a.ad.a; // :com.sec.a.a.a.ad
        return v0;
    }

    public static com.sec.a.a.a.ad a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.a.a.a.ad.newBuilder -> com.sec.a.a.a.ae
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.a.a.a.ae.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.a.a.a.ae) v0;
        _result = v0.a(); // com.sec.a.a.a.ae.a -> com.sec.a.a.a.ad
        v0 = _result;
        return v0;
    }

    public static com.sec.a.a.a.ae a(com.sec.a.a.a.ad p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.ad)
        _result = this.newBuilder(); // com.sec.a.a.a.ad.newBuilder -> com.sec.a.a.a.ae
        v0 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.ae.a -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    static java.lang.Object a(com.sec.a.a.a.ad p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.ad), v1 = p1 (java.lang.Object)
        v0.d = v1; // com.sec.a.a.a.ad.d:java.lang.Object
        return v1;
    }

    static int b(com.sec.a.a.a.ad p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.ad), v1 = p1 (int)
        v0.f = v1; // com.sec.a.a.a.ad.f:int
        return v1;
    }

    static java.lang.Object b(com.sec.a.a.a.ad p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.ad), v1 = p1 (java.lang.Object)
        v0.e = v1; // com.sec.a.a.a.ad.e:java.lang.Object
        return v1;
    }

    static int c(com.sec.a.a.a.ad p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.ad), v1 = p1 (int)
        v0.h = v1; // com.sec.a.a.a.ad.h:int
        return v1;
    }

    static java.lang.Object c(com.sec.a.a.a.ad p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.ad), v1 = p1 (java.lang.Object)
        v0.g = v1; // com.sec.a.a.a.ad.g:java.lang.Object
        return v1;
    }

    static int d(com.sec.a.a.a.ad p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.ad), v1 = p1 (int)
        v0.i = v1; // com.sec.a.a.a.ad.i:int
        return v1;
    }

    static java.lang.Object d(com.sec.a.a.a.ad p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.ad), v1 = p1 (java.lang.Object)
        v0.j = v1; // com.sec.a.a.a.ad.j:java.lang.Object
        return v1;
    }

    static int e(com.sec.a.a.a.ad p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.ad), v1 = p1 (int)
        v0.b = v1; // com.sec.a.a.a.ad.b:int
        return v1;
    }

    public static com.sec.a.a.a.ae newBuilder() {
        _result = this.f(); // com.sec.a.a.a.ae.f -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    private com.google.protobuf.ByteString u() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.a.a.a.ad.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.d = v0; // com.sec.a.a.a.ad.d:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString v() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.a.a.a.ad.e:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.e = v0; // com.sec.a.a.a.ad.e:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString w() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.sec.a.a.a.ad.g:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.g = v0; // com.sec.a.a.a.ad.g:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString x() {
        // Registers (3 total): v2 = this
        v0 = v2.j; // com.sec.a.a.a.ad.j:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.j = v0; // com.sec.a.a.a.ad.j:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void y() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v2.c = v1; // com.sec.a.a.a.ad.c:int
        v0 = "";
        v2.d = v0; // com.sec.a.a.a.ad.d:java.lang.Object
        v0 = "";
        v2.e = v0; // com.sec.a.a.a.ad.e:java.lang.Object
        v2.f = v1; // com.sec.a.a.a.ad.f:int
        v0 = "";
        v2.g = v0; // com.sec.a.a.a.ad.g:java.lang.Object
        v2.h = v1; // com.sec.a.a.a.ad.h:int
        v2.i = v1; // com.sec.a.a.a.ad.i:int
        v0 = "";
        v2.j = v0; // com.sec.a.a.a.ad.j:java.lang.Object
        return;
    }

    public com.sec.a.a.a.ad b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.a.a.a.ad.a; // :com.sec.a.a.a.ad
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.a.a.a.ad.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public int d() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.sec.a.a.a.ad.c:int
        return v0;
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public java.lang.String f() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.a.a.a.ad.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.d = v1; // com.sec.a.a.a.ad.d:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean g() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.ad.b -> com.sec.a.a.a.ad
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (7 total): v6 = this
        v5 = 8;
        v4 = 4;
        v3 = 2;
        v0 = v6.l; // com.sec.a.a.a.ad.l:int
        v1 = -1;
        if (v0 == v1) /* goto L_000a */;
        return v0;
        v0 = 0;
        v1 = v6.b; // com.sec.a.a.a.ad.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        v2 = 1;
        if (v1 != v2) /* goto L_0019 */;
        v1 = v6.c; // com.sec.a.a.a.ad.c:int
        _result = v3.computeInt32Size(v1); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.a.a.a.ad.b:int
        v1 = binOpLit8_0xdd(v1, 2);
        if (v1 != v3) /* goto L_0029 */;
        v1 = 3;
        _result = v6.u(); // com.sec.a.a.a.ad.u -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.a.a.a.ad.b:int
        v1 = binOpLit8_0xdd(v1, 4);
        if (v1 != v4) /* goto L_0038 */;
        _result = v6.v(); // com.sec.a.a.a.ad.v -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v4.computeBytesSize(v1); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.a.a.a.ad.b:int
        v1 = binOpLit8_0xdd(v1, 8);
        if (v1 != v5) /* goto L_0046 */;
        v1 = 5;
        v2 = v6.f; // com.sec.a.a.a.ad.f:int
        _result = v1.computeInt32Size(v2); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.a.a.a.ad.b:int
        v1 = binOpLit8_0xdd(v1, 16);
        v2 = 16;
        if (v1 != v2) /* goto L_0058 */;
        v1 = 6;
        _result = v6.w(); // com.sec.a.a.a.ad.w -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.a.a.a.ad.b:int
        v1 = binOpLit8_0xdd(v1, 32);
        v2 = 32;
        if (v1 != v2) /* goto L_0068 */;
        v1 = 7;
        v2 = v6.h; // com.sec.a.a.a.ad.h:int
        _result = v1.computeInt32Size(v2); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.a.a.a.ad.b:int
        v1 = binOpLit8_0xdd(v1, 64);
        v2 = 64;
        if (v1 != v2) /* goto L_0077 */;
        v1 = v6.i; // com.sec.a.a.a.ad.i:int
        _result = v5.computeInt32Size(v1); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v6.b; // com.sec.a.a.a.ad.b:int
        v1 = binOpLit16_0xd5(v1, 128);
        v2 = 128;
        if (v1 != v2) /* goto L_008a */;
        v1 = 9;
        _result = v6.x(); // com.sec.a.a.a.ad.x -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v6.l = v0; // com.sec.a.a.a.ad.l:int
        // goto L_0009
    }

    public java.lang.String h() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.a.a.a.ad.e:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.e = v1; // com.sec.a.a.a.ad.e:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean i() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.k; // com.sec.a.a.a.ad.k:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.k = v0; // com.sec.a.a.a.ad.k:byte
        // goto L_0008
    }

    public int j() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // com.sec.a.a.a.ad.f:int
        return v0;
    }

    public boolean k() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.lang.String l() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.sec.a.a.a.ad.g:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.g = v1; // com.sec.a.a.a.ad.g:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean m() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 32);
        v1 = 32;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public int n() {
        // Registers (2 total): v1 = this
        v0 = v1.h; // com.sec.a.a.a.ad.h:int
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.s(); // com.sec.a.a.a.ad.s -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public boolean o() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 64);
        v1 = 64;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public int p() {
        // Registers (2 total): v1 = this
        v0 = v1.i; // com.sec.a.a.a.ad.i:int
        return v0;
    }

    public boolean q() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit16_0xd5(v0, 128);
        v1 = 128;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.lang.String r() {
        // Registers (3 total): v2 = this
        v0 = v2.j; // com.sec.a.a.a.ad.j:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.j = v1; // com.sec.a.a.a.ad.j:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public com.sec.a.a.a.ae s() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.a.a.a.ad.newBuilder -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.ae t() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.ad.a -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.t(); // com.sec.a.a.a.ad.t -> com.sec.a.a.a.ae
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (7 total): v5 = this, v6 = p0 (com.google.protobuf.CodedOutputStream)
        v4 = 8;
        v3 = 4;
        v2 = 2;
        _result = v5.getSerializedSize(); // com.sec.a.a.a.ad.getSerializedSize -> int
        v0 = v5.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        v1 = 1;
        if (v0 != v1) /* goto L_0013 */;
        v0 = v5.c; // com.sec.a.a.a.ad.c:int
        _result = v6.writeInt32(v2, v0); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v5.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v2) /* goto L_0021 */;
        v0 = 3;
        _result = v5.u(); // com.sec.a.a.a.ad.u -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v6.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v5.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        if (v0 != v3) /* goto L_002e */;
        _result = v5.v(); // com.sec.a.a.a.ad.v -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v6.writeBytes(v3, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v5.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        if (v0 != v4) /* goto L_003a */;
        v0 = 5;
        v1 = v5.f; // com.sec.a.a.a.ad.f:int
        _result = v6.writeInt32(v0, v1); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v5.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 16);
        v1 = 16;
        if (v0 != v1) /* goto L_004a */;
        v0 = 6;
        _result = v5.w(); // com.sec.a.a.a.ad.w -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v6.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v5.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 32);
        v1 = 32;
        if (v0 != v1) /* goto L_0058 */;
        v0 = 7;
        v1 = v5.h; // com.sec.a.a.a.ad.h:int
        _result = v6.writeInt32(v0, v1); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v5.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit8_0xdd(v0, 64);
        v1 = 64;
        if (v0 != v1) /* goto L_0065 */;
        v0 = v5.i; // com.sec.a.a.a.ad.i:int
        _result = v6.writeInt32(v4, v0); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v5.b; // com.sec.a.a.a.ad.b:int
        v0 = binOpLit16_0xd5(v0, 128);
        v1 = 128;
        if (v0 != v1) /* goto L_0076 */;
        v0 = 9;
        _result = v5.x(); // com.sec.a.a.a.ad.x -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v6.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        return;
    }

}