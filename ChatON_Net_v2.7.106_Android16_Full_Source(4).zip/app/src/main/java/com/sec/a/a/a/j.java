package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/j;
 */
public final class j extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.a.a.a.k {
    private int a;
    private int b;
    private int c;
    private java.lang.Object d;

    private j() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = "";
        v1.d = v0; // com.sec.a.a.a.j.d:java.lang.Object
        _result = v1.g(); // com.sec.a.a.a.j.g -> void
        return;
    }

    static com.sec.a.a.a.i a(com.sec.a.a.a.j p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.j)
        _result = v1.i(); // com.sec.a.a.a.j.i -> com.sec.a.a.a.i
        v0 = _result;
        return v0;
    }

    static com.sec.a.a.a.j f() {
        _result = this.h(); // com.sec.a.a.a.j.h -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.a.a.a.j h() {
        v0 = new com.sec.a.a.a.j;
        _result = v0.<init>(); // com.sec.a.a.a.j.<init> -> void
        return v0;
    }

    private com.sec.a.a.a.i i() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.j.e -> com.sec.a.a.a.i
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.i.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.j.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.j a() {
        // Registers (3 total): v2 = this
        v1 = 0;
        _result = v2.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v2.b = v1; // com.sec.a.a.a.j.b:int
        v0 = v2.a; // com.sec.a.a.a.j.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v2.a = v0; // com.sec.a.a.a.j.a:int
        v2.c = v1; // com.sec.a.a.a.j.c:int
        v0 = v2.a; // com.sec.a.a.a.j.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v2.a = v0; // com.sec.a.a.a.j.a:int
        v0 = "";
        v2.d = v0; // com.sec.a.a.a.j.d:java.lang.Object
        v0 = v2.a; // com.sec.a.a.a.j.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v2.a = v0; // com.sec.a.a.a.j.a:int
        return v2;
    }

    public com.sec.a.a.a.j a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.j.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.a.a.a.j.a:int
        v1.b = v2; // com.sec.a.a.a.j.b:int
        return v1;
    }

    public com.sec.a.a.a.j a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v2.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v1.parseUnknownField(v2, v3, v0); // com.sec.a.a.a.j.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v1;
        v0 = v1.a; // com.sec.a.a.a.j.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.a.a.a.j.a:int
        _result = v2.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v1.b = v0; // com.sec.a.a.a.j.b:int
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.j.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.a.a.a.j.a:int
        _result = v2.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v1.c = v0; // com.sec.a.a.a.j.c:int
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.j.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.a.a.a.j.a:int
        _result = v2.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v1.d = v0; // com.sec.a.a.a.j.d:java.lang.Object
        // goto L_0000
    }

    public com.sec.a.a.a.j a(com.sec.a.a.a.i p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.i)
        _result = this.a(); // com.sec.a.a.a.i.a -> com.sec.a.a.a.i
        v0 = _result;
        if (v2 != v0) /* goto L_0007 */;
        return v1;
        _result = v2.c(); // com.sec.a.a.a.i.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v2.d(); // com.sec.a.a.a.i.d -> int
        v0 = _result;
        _result = v1.a(v0); // com.sec.a.a.a.j.a -> com.sec.a.a.a.j
        _result = v2.e(); // com.sec.a.a.a.i.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v2.f(); // com.sec.a.a.a.i.f -> int
        v0 = _result;
        _result = v1.b(v0); // com.sec.a.a.a.j.b -> com.sec.a.a.a.j
        _result = v2.g(); // com.sec.a.a.a.i.g -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0006 */;
        _result = v2.h(); // com.sec.a.a.a.i.h -> java.lang.String
        v0 = _result;
        _result = v1.a(v0); // com.sec.a.a.a.j.a -> com.sec.a.a.a.j
        // goto L_0006
    }

    public com.sec.a.a.a.j a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.j.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.a.a.a.j.a:int
        v1.d = v2; // com.sec.a.a.a.j.d:java.lang.Object
        return v1;
    }

    public com.sec.a.a.a.j b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.a.a.a.j.h -> com.sec.a.a.a.j
        v0 = _result;
        _result = v2.e(); // com.sec.a.a.a.j.e -> com.sec.a.a.a.i
        v1 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.j.a -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.j b(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.j.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.a.a.a.j.a:int
        v1.c = v2; // com.sec.a.a.a.j.c:int
        return v1;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.a.a.a.j.d -> com.sec.a.a.a.i
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.a.a.a.j.e -> com.sec.a.a.a.i
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.i c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.a.a.a.i.a -> com.sec.a.a.a.i
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.j.a -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.j.a -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.j.b -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.j.b -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.j.b -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.j.b -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.i d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.j.e -> com.sec.a.a.a.i
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.i.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.j.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.i e() {
        // Registers (6 total): v5 = this
        v0 = 1;
        v2 = new com.sec.a.a.a.i;
        v1 = 0;
        _result = v2.<init>(v5, v1); // com.sec.a.a.a.i.<init> -> void
        v3 = v5.a; // com.sec.a.a.a.j.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_002f */;
        v1 = v5.b; // com.sec.a.a.a.j.b:int
        _result = v2.a(v1); // com.sec.a.a.a.i.a -> int
        v1 = binOpLit8_0xdd(v3, 2);
        v4 = 2;
        if (v1 != v4) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v5.c; // com.sec.a.a.a.j.c:int
        _result = v2.b(v1); // com.sec.a.a.a.i.b -> int
        v1 = binOpLit8_0xdd(v3, 4);
        v3 = 4;
        if (v1 != v3) /* goto L_0026 */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = v5.d; // com.sec.a.a.a.j.d:java.lang.Object
        _result = v2.a(v1); // com.sec.a.a.a.i.a -> java.lang.Object
        _result = v2.c(v0); // com.sec.a.a.a.i.c -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.j.c -> com.sec.a.a.a.i
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.j.c -> com.sec.a.a.a.i
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.j.a -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.a.a.a.i) v2;
        _result = v1.a(v2); // com.sec.a.a.a.j.a -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.j.a -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

}