package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/o;
 */
public final class o extends com.google.protobuf.GeneratedMessageLite implements com.sec.a.a.a.q {
    private static final com.sec.a.a.a.o a;
    private int b;
    private java.lang.Object c;
    private com.google.protobuf.LazyStringList d;
    private byte e;
    private int f;

    static {
        v0 = new com.sec.a.a.a.o;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.a.a.a.o.<init> -> void
        com.sec.a.a.a.o.a = v0; // :com.sec.a.a.a.o
        v0 = com.sec.a.a.a.o.a; // :com.sec.a.a.a.o
        _result = v0.i(); // com.sec.a.a.a.o.i -> void
        return;
    }

    private o(com.sec.a.a.a.p p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.p)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.e = v0; // com.sec.a.a.a.o.e:byte
        v1.f = v0; // com.sec.a.a.a.o.f:int
        return;
    }

    o(com.sec.a.a.a.p p0, com.sec.a.a.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.a.a.a.p), v2 = p1 (com.sec.a.a.a.b)
        _result = v0.<init>(v1); // com.sec.a.a.a.o.<init> -> void
        return;
    }

    private o(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.e = v0; // com.sec.a.a.a.o.e:byte
        v1.f = v0; // com.sec.a.a.a.o.f:int
        return;
    }

    static int a(com.sec.a.a.a.o p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.o), v1 = p1 (int)
        v0.b = v1; // com.sec.a.a.a.o.b:int
        return v1;
    }

    static com.google.protobuf.LazyStringList a(com.sec.a.a.a.o p0, com.google.protobuf.LazyStringList p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.o), v1 = p1 (com.google.protobuf.LazyStringList)
        v0.d = v1; // com.sec.a.a.a.o.d:com.google.protobuf.LazyStringList
        return v1;
    }

    public static com.sec.a.a.a.o a() {
        v0 = com.sec.a.a.a.o.a; // :com.sec.a.a.a.o
        return v0;
    }

    public static com.sec.a.a.a.o a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.a.a.a.o.newBuilder -> com.sec.a.a.a.p
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.a.a.a.p.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.a.a.a.p) v0;
        _result = v0.a(); // com.sec.a.a.a.p.a -> com.sec.a.a.a.o
        v0 = _result;
        return v0;
    }

    public static com.sec.a.a.a.p a(com.sec.a.a.a.o p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.o)
        _result = this.newBuilder(); // com.sec.a.a.a.o.newBuilder -> com.sec.a.a.a.p
        v0 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.p.a -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    static java.lang.Object a(com.sec.a.a.a.o p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.o), v1 = p1 (java.lang.Object)
        v0.c = v1; // com.sec.a.a.a.o.c:java.lang.Object
        return v1;
    }

    static com.google.protobuf.LazyStringList b(com.sec.a.a.a.o p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.o)
        v0 = v1.d; // com.sec.a.a.a.o.d:com.google.protobuf.LazyStringList
        return v0;
    }

    private com.google.protobuf.ByteString h() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.sec.a.a.a.o.c:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.c = v0; // com.sec.a.a.a.o.c:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void i() {
        // Registers (2 total): v1 = this
        v0 = "";
        v1.c = v0; // com.sec.a.a.a.o.c:java.lang.Object
        v0 = com.google.protobuf.LazyStringArrayList.EMPTY; // :com.google.protobuf.LazyStringList
        v1.d = v0; // com.sec.a.a.a.o.d:com.google.protobuf.LazyStringList
        return;
    }

    public static com.sec.a.a.a.p newBuilder() {
        _result = this.f(); // com.sec.a.a.a.p.f -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.o b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.a.a.a.o.a; // :com.sec.a.a.a.o
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.a.a.a.o.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public java.lang.String d() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.sec.a.a.a.o.c:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.c = v1; // com.sec.a.a.a.o.c:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public java.util.List e() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.sec.a.a.a.o.d:com.google.protobuf.LazyStringList
        return v0;
    }

    public com.sec.a.a.a.p f() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.a.a.a.o.newBuilder -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.p g() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.o.a -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.o.b -> com.sec.a.a.a.o
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (5 total): v4 = this
        v3 = 1;
        v1 = 0;
        v0 = v4.f; // com.sec.a.a.a.o.f:int
        v2 = -1;
        if (v0 == v2) /* goto L_0008 */;
        return v0;
        v0 = v4.b; // com.sec.a.a.a.o.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v3) /* goto L_003d */;
        _result = v4.h(); // com.sec.a.a.a.o.h -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v3.computeBytesSize(v0); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v2 = v1;
        v3 = v4.d; // com.sec.a.a.a.o.d:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.size(v3); // -> int
        v3 = _result;
        if (v1 >= v3) /* goto L_002e */;
        v3 = v4.d; // com.sec.a.a.a.o.d:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.getByteString(v3, v1); // -> com.google.protobuf.ByteString
        v3 = _result;
        _result = v3.computeBytesSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeBytesSizeNoTag -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0018
        v0 = binOp2addr_0xb0(v0, v2);
        _result = v4.e(); // com.sec.a.a.a.o.e -> java.util.List
        v1 = _result;
        _result = java.util.List.size(v1); // -> int
        v1 = _result;
        v1 = binOpLit8_0xda(v1, 1);
        v0 = binOp2addr_0xb0(v0, v1);
        v4.f = v0; // com.sec.a.a.a.o.f:int
        // goto L_0007
        v0 = v1;
        // goto L_0017
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.e; // com.sec.a.a.a.o.e:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.e = v0; // com.sec.a.a.a.o.e:byte
        // goto L_0008
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.f(); // com.sec.a.a.a.o.f -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.g(); // com.sec.a.a.a.o.g -> com.sec.a.a.a.p
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (5 total): v3 = this, v4 = p0 (com.google.protobuf.CodedOutputStream)
        v1 = 1;
        _result = v3.getSerializedSize(); // com.sec.a.a.a.o.getSerializedSize -> int
        v0 = v3.b; // com.sec.a.a.a.o.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v1) /* goto L_0011 */;
        _result = v3.h(); // com.sec.a.a.a.o.h -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v4.writeBytes(v1, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = 0;
        v1 = v3.d; // com.sec.a.a.a.o.d:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.size(v1); // -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_0027 */;
        v1 = 2;
        v2 = v3.d; // com.sec.a.a.a.o.d:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.getByteString(v2, v0); // -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v4.writeBytes(v1, v2); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0012
        return;
    }

}