package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/an;
 */
public final class an extends com.google.protobuf.GeneratedMessageLite$Builder implements com.sec.a.a.a.ao {
    private int a;
    private int b;
    private java.lang.Object c;
    private java.lang.Object d;
    private java.lang.Object e;

    private an() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        v0 = "";
        v1.c = v0; // com.sec.a.a.a.an.c:java.lang.Object
        v0 = "";
        v1.d = v0; // com.sec.a.a.a.an.d:java.lang.Object
        v0 = "";
        v1.e = v0; // com.sec.a.a.a.an.e:java.lang.Object
        _result = v1.g(); // com.sec.a.a.a.an.g -> void
        return;
    }

    static com.sec.a.a.a.am a(com.sec.a.a.a.an p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.an)
        _result = v1.i(); // com.sec.a.a.a.an.i -> com.sec.a.a.a.am
        v0 = _result;
        return v0;
    }

    static com.sec.a.a.a.an f() {
        _result = this.h(); // com.sec.a.a.a.an.h -> com.sec.a.a.a.an
        v0 = _result;
        return v0;
    }

    private void g() {
        // Registers (1 total): v0 = this
        return;
    }

    private static com.sec.a.a.a.an h() {
        v0 = new com.sec.a.a.a.an;
        _result = v0.<init>(); // com.sec.a.a.a.an.<init> -> void
        return v0;
    }

    private com.sec.a.a.a.am i() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.an.e -> com.sec.a.a.a.am
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.am.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.an.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        _result = v0.asInvalidProtocolBufferException(); // com.google.protobuf.UninitializedMessageException.asInvalidProtocolBufferException -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.an a() {
        // Registers (2 total): v1 = this
        _result = v1.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = 0;
        v1.b = v0; // com.sec.a.a.a.an.b:int
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xdd(v0, -2);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        v0 = "";
        v1.c = v0; // com.sec.a.a.a.an.c:java.lang.Object
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xdd(v0, -3);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        v0 = "";
        v1.d = v0; // com.sec.a.a.a.an.d:java.lang.Object
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xdd(v0, -5);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        v0 = "";
        v1.e = v0; // com.sec.a.a.a.an.e:java.lang.Object
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xdd(v0, -9);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        return v1;
    }

    public com.sec.a.a.a.an a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        v1.b = v2; // com.sec.a.a.a.an.b:int
        return v1;
    }

    public com.sec.a.a.a.an a(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v2.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        // switch(v0)
        _result = v1.parseUnknownField(v2, v3, v0); // com.sec.a.a.a.an.parseUnknownField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return v1;
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xde(v0, 1);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        _result = v2.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        v1.b = v0; // com.sec.a.a.a.an.b:int
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        _result = v2.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v1.c = v0; // com.sec.a.a.a.an.c:java.lang.Object
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        _result = v2.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v1.d = v0; // com.sec.a.a.a.an.d:java.lang.Object
        // goto L_0000
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        _result = v2.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        v1.e = v0; // com.sec.a.a.a.an.e:java.lang.Object
        // goto L_0000
    }

    public com.sec.a.a.a.an a(com.sec.a.a.a.am p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.am)
        _result = this.a(); // com.sec.a.a.a.am.a -> com.sec.a.a.a.am
        v0 = _result;
        if (v2 != v0) /* goto L_0007 */;
        return v1;
        _result = v2.c(); // com.sec.a.a.a.am.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        _result = v2.d(); // com.sec.a.a.a.am.d -> int
        v0 = _result;
        _result = v1.a(v0); // com.sec.a.a.a.an.a -> com.sec.a.a.a.an
        _result = v2.e(); // com.sec.a.a.a.am.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v2.f(); // com.sec.a.a.a.am.f -> java.lang.String
        v0 = _result;
        _result = v1.a(v0); // com.sec.a.a.a.an.a -> com.sec.a.a.a.an
        _result = v2.g(); // com.sec.a.a.a.am.g -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002e */;
        _result = v2.h(); // com.sec.a.a.a.am.h -> java.lang.String
        v0 = _result;
        _result = v1.b(v0); // com.sec.a.a.a.an.b -> com.sec.a.a.a.an
        _result = v2.i(); // com.sec.a.a.a.am.i -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0006 */;
        _result = v2.j(); // com.sec.a.a.a.am.j -> java.lang.String
        v0 = _result;
        _result = v1.c(v0); // com.sec.a.a.a.an.c -> com.sec.a.a.a.an
        // goto L_0006
    }

    public com.sec.a.a.a.an a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xde(v0, 2);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        v1.c = v2; // com.sec.a.a.a.an.c:java.lang.Object
        return v1;
    }

    public com.sec.a.a.a.an b() {
        // Registers (3 total): v2 = this
        _result = this.h(); // com.sec.a.a.a.an.h -> com.sec.a.a.a.an
        v0 = _result;
        _result = v2.e(); // com.sec.a.a.a.an.e -> com.sec.a.a.a.am
        v1 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.an.a -> com.sec.a.a.a.an
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.an b(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xde(v0, 4);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        v1.d = v2; // com.sec.a.a.a.an.d:java.lang.Object
        return v1;
    }

    public com.google.protobuf.MessageLite build() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.sec.a.a.a.an.d -> com.sec.a.a.a.am
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite buildPartial() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.a.a.a.an.e -> com.sec.a.a.a.am
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.am c() {
        // Registers (2 total): v1 = this
        _result = this.a(); // com.sec.a.a.a.am.a -> com.sec.a.a.a.am
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.an c(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = v1.a; // com.sec.a.a.a.an.a:int
        v0 = binOpLit8_0xde(v0, 8);
        v1.a = v0; // com.sec.a.a.a.an.a:int
        v1.e = v2; // com.sec.a.a.a.an.e:java.lang.Object
        return v1;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.an.a -> com.sec.a.a.a.an
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.an.a -> com.sec.a.a.a.an
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.an.b -> com.sec.a.a.a.an
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.an.b -> com.sec.a.a.a.an
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.an.b -> com.sec.a.a.a.an
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.an.b -> com.sec.a.a.a.an
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.am d() {
        // Registers (3 total): v2 = this
        _result = v2.e(); // com.sec.a.a.a.an.e -> com.sec.a.a.a.am
        v0 = _result;
        _result = v0.isInitialized(); // com.sec.a.a.a.am.isInitialized -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v0.newUninitializedMessageException(); // com.sec.a.a.a.an.newUninitializedMessageException -> com.google.protobuf.UninitializedMessageException
        v0 = _result;
        throw v0;
        return v0;
    }

    public com.sec.a.a.a.am e() {
        // Registers (6 total): v5 = this
        v0 = 1;
        v2 = new com.sec.a.a.a.am;
        v1 = 0;
        _result = v2.<init>(v5, v1); // com.sec.a.a.a.am.<init> -> void
        v3 = v5.a; // com.sec.a.a.a.an.a:int
        v1 = 0;
        v4 = binOpLit8_0xdd(v3, 1);
        if (v4 != v0) /* goto L_003c */;
        v1 = v5.b; // com.sec.a.a.a.an.b:int
        _result = v2.a(v1); // com.sec.a.a.a.am.a -> int
        v1 = binOpLit8_0xdd(v3, 2);
        v4 = 2;
        if (v1 != v4) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v5.c; // com.sec.a.a.a.an.c:java.lang.Object
        _result = v2.a(v1); // com.sec.a.a.a.am.a -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 4);
        v4 = 4;
        if (v1 != v4) /* goto L_0026 */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = v5.d; // com.sec.a.a.a.an.d:java.lang.Object
        _result = v2.b(v1); // com.sec.a.a.a.am.b -> java.lang.Object
        v1 = binOpLit8_0xdd(v3, 8);
        v3 = 8;
        if (v1 != v3) /* goto L_0033 */;
        v0 = binOpLit8_0xde(v0, 8);
        v1 = v5.e; // com.sec.a.a.a.an.e:java.lang.Object
        _result = v2.c(v1); // com.sec.a.a.a.am.c -> java.lang.Object
        _result = v2.b(v0); // com.sec.a.a.a.am.b -> int
        return v2;
        v0 = v1;
        // goto L_000e
    }

    public com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.an.c -> com.sec.a.a.a.am
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // com.sec.a.a.a.an.c -> com.sec.a.a.a.am
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.an.a -> com.sec.a.a.a.an
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite)
        v2 = (com.sec.a.a.a.am) v2;
        _result = v1.a(v2); // com.sec.a.a.a.an.a -> com.sec.a.a.a.an
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.a(v2, v3); // com.sec.a.a.a.an.a -> com.sec.a.a.a.an
        v0 = _result;
        return v0;
    }

}