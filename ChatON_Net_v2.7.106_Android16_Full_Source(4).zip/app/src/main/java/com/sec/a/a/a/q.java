package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/q;
 */
public interface q extends com.google.protobuf.MessageLiteOrBuilder {
}