package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/n;
 */
public interface n extends com.google.protobuf.MessageLiteOrBuilder {
}