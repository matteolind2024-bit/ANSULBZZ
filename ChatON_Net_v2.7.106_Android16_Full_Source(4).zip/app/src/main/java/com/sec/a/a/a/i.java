package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/i;
 */
public final class i extends com.google.protobuf.GeneratedMessageLite implements com.sec.a.a.a.k {
    private static final com.sec.a.a.a.i a;
    private int b;
    private int c;
    private int d;
    private java.lang.Object e;
    private byte f;
    private int g;

    static {
        v0 = new com.sec.a.a.a.i;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.a.a.a.i.<init> -> void
        com.sec.a.a.a.i.a = v0; // :com.sec.a.a.a.i
        v0 = com.sec.a.a.a.i.a; // :com.sec.a.a.a.i
        _result = v0.l(); // com.sec.a.a.a.i.l -> void
        return;
    }

    private i(com.sec.a.a.a.j p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.j)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.f = v0; // com.sec.a.a.a.i.f:byte
        v1.g = v0; // com.sec.a.a.a.i.g:int
        return;
    }

    i(com.sec.a.a.a.j p0, com.sec.a.a.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.a.a.a.j), v2 = p1 (com.sec.a.a.a.b)
        _result = v0.<init>(v1); // com.sec.a.a.a.i.<init> -> void
        return;
    }

    private i(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.f = v0; // com.sec.a.a.a.i.f:byte
        v1.g = v0; // com.sec.a.a.a.i.g:int
        return;
    }

    static int a(com.sec.a.a.a.i p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.i), v1 = p1 (int)
        v0.c = v1; // com.sec.a.a.a.i.c:int
        return v1;
    }

    public static com.sec.a.a.a.i a() {
        v0 = com.sec.a.a.a.i.a; // :com.sec.a.a.a.i
        return v0;
    }

    public static com.sec.a.a.a.i a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.a.a.a.i.newBuilder -> com.sec.a.a.a.j
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.a.a.a.j.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.a.a.a.j) v0;
        _result = v0.a(); // com.sec.a.a.a.j.a -> com.sec.a.a.a.i
        v0 = _result;
        return v0;
    }

    public static com.sec.a.a.a.j a(com.sec.a.a.a.i p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.i)
        _result = this.newBuilder(); // com.sec.a.a.a.i.newBuilder -> com.sec.a.a.a.j
        v0 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.j.a -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    static java.lang.Object a(com.sec.a.a.a.i p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.i), v1 = p1 (java.lang.Object)
        v0.e = v1; // com.sec.a.a.a.i.e:java.lang.Object
        return v1;
    }

    static int b(com.sec.a.a.a.i p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.i), v1 = p1 (int)
        v0.d = v1; // com.sec.a.a.a.i.d:int
        return v1;
    }

    static int c(com.sec.a.a.a.i p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.i), v1 = p1 (int)
        v0.b = v1; // com.sec.a.a.a.i.b:int
        return v1;
    }

    private com.google.protobuf.ByteString k() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.a.a.a.i.e:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.e = v0; // com.sec.a.a.a.i.e:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void l() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.c = v0; // com.sec.a.a.a.i.c:int
        v1.d = v0; // com.sec.a.a.a.i.d:int
        v0 = "";
        v1.e = v0; // com.sec.a.a.a.i.e:java.lang.Object
        return;
    }

    public static com.sec.a.a.a.j newBuilder() {
        _result = this.f(); // com.sec.a.a.a.j.f -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.i b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.a.a.a.i.a; // :com.sec.a.a.a.i
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.a.a.a.i.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public int d() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.sec.a.a.a.i.c:int
        return v0;
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.i.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public int f() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.sec.a.a.a.i.d:int
        return v0;
    }

    public boolean g() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.i.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.i.b -> com.sec.a.a.a.i
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (5 total): v4 = this
        v3 = 2;
        v2 = 1;
        v0 = v4.g; // com.sec.a.a.a.i.g:int
        v1 = -1;
        if (v0 == v1) /* goto L_0008 */;
        return v0;
        v0 = 0;
        v1 = v4.b; // com.sec.a.a.a.i.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v2) /* goto L_0016 */;
        v1 = v4.c; // com.sec.a.a.a.i.c:int
        _result = v2.computeInt32Size(v1); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v4.b; // com.sec.a.a.a.i.b:int
        v1 = binOpLit8_0xdd(v1, 2);
        if (v1 != v3) /* goto L_0023 */;
        v1 = v4.d; // com.sec.a.a.a.i.d:int
        _result = v3.computeInt32Size(v1); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v4.b; // com.sec.a.a.a.i.b:int
        v1 = binOpLit8_0xdd(v1, 4);
        v2 = 4;
        if (v1 != v2) /* goto L_0034 */;
        v1 = 3;
        _result = v4.k(); // com.sec.a.a.a.i.k -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v4.g = v0; // com.sec.a.a.a.i.g:int
        // goto L_0007
    }

    public java.lang.String h() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.a.a.a.i.e:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.e = v1; // com.sec.a.a.a.i.e:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public com.sec.a.a.a.j i() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.a.a.a.i.newBuilder -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.f; // com.sec.a.a.a.i.f:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.f = v0; // com.sec.a.a.a.i.f:byte
        // goto L_0008
    }

    public com.sec.a.a.a.j j() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.i.a -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.i(); // com.sec.a.a.a.i.i -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.j(); // com.sec.a.a.a.i.j -> com.sec.a.a.a.j
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (5 total): v3 = this, v4 = p0 (com.google.protobuf.CodedOutputStream)
        v2 = 2;
        v1 = 1;
        _result = v3.getSerializedSize(); // com.sec.a.a.a.i.getSerializedSize -> int
        v0 = v3.b; // com.sec.a.a.a.i.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v1) /* goto L_0010 */;
        v0 = v3.c; // com.sec.a.a.a.i.c:int
        _result = v4.writeInt32(v1, v0); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v3.b; // com.sec.a.a.a.i.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v2) /* goto L_001b */;
        v0 = v3.d; // com.sec.a.a.a.i.d:int
        _result = v4.writeInt32(v2, v0); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v3.b; // com.sec.a.a.a.i.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_002a */;
        v0 = 3;
        _result = v3.k(); // com.sec.a.a.a.i.k -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v4.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        return;
    }

}