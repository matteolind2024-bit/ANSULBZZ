package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/u;
 */
public final class u extends com.google.protobuf.GeneratedMessageLite implements com.sec.a.a.a.w {
    private static final com.sec.a.a.a.u a;
    private java.util.List b;
    private byte c;
    private int d;

    static {
        v0 = new com.sec.a.a.a.u;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.a.a.a.u.<init> -> void
        com.sec.a.a.a.u.a = v0; // :com.sec.a.a.a.u
        v0 = com.sec.a.a.a.u.a; // :com.sec.a.a.a.u
        _result = v0.g(); // com.sec.a.a.a.u.g -> void
        return;
    }

    private u(com.sec.a.a.a.v p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.v)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.c = v0; // com.sec.a.a.a.u.c:byte
        v1.d = v0; // com.sec.a.a.a.u.d:int
        return;
    }

    u(com.sec.a.a.a.v p0, com.sec.a.a.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.a.a.a.v), v2 = p1 (com.sec.a.a.a.b)
        _result = v0.<init>(v1); // com.sec.a.a.a.u.<init> -> void
        return;
    }

    private u(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.c = v0; // com.sec.a.a.a.u.c:byte
        v1.d = v0; // com.sec.a.a.a.u.d:int
        return;
    }

    public static com.sec.a.a.a.u a() {
        v0 = com.sec.a.a.a.u.a; // :com.sec.a.a.a.u
        return v0;
    }

    public static com.sec.a.a.a.u a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.a.a.a.u.newBuilder -> com.sec.a.a.a.v
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.a.a.a.v.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.a.a.a.v) v0;
        _result = v0.a(); // com.sec.a.a.a.v.a -> com.sec.a.a.a.u
        v0 = _result;
        return v0;
    }

    public static com.sec.a.a.a.v a(com.sec.a.a.a.u p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.u)
        _result = this.newBuilder(); // com.sec.a.a.a.u.newBuilder -> com.sec.a.a.a.v
        v0 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.v.a -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    static java.util.List a(com.sec.a.a.a.u p0, java.util.List p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.u), v1 = p1 (java.util.List)
        v0.b = v1; // com.sec.a.a.a.u.b:java.util.List
        return v1;
    }

    static java.util.List b(com.sec.a.a.a.u p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.u)
        v0 = v1.b; // com.sec.a.a.a.u.b:java.util.List
        return v0;
    }

    private void g() {
        // Registers (2 total): v1 = this
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        v1.b = v0; // com.sec.a.a.a.u.b:java.util.List
        return;
    }

    public static com.sec.a.a.a.v newBuilder() {
        _result = this.f(); // com.sec.a.a.a.v.f -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.u b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.a.a.a.u.a; // :com.sec.a.a.a.u
        return v0;
    }

    public java.util.List c() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // com.sec.a.a.a.u.b:java.util.List
        return v0;
    }

    public int d() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // com.sec.a.a.a.u.b:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.v e() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.a.a.a.u.newBuilder -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.v f() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.u.a -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.u.b -> com.sec.a.a.a.u
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (5 total): v4 = this
        v0 = 0;
        v2 = v4.d; // com.sec.a.a.a.u.d:int
        v1 = -1;
        if (v2 == v1) /* goto L_0007 */;
        return v2;
        v1 = v0;
        v2 = v0;
        v0 = v4.b; // com.sec.a.a.a.u.b:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0023 */;
        v3 = 1;
        v0 = v4.b; // com.sec.a.a.a.u.b:java.util.List
        _result = java.util.List.get(v0, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        _result = v3.computeMessageSize(v0); // com.google.protobuf.CodedOutputStream.computeMessageSize -> int
        v0 = _result;
        v2 = binOp2addr_0xb0(v2, v0);
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0009
        v4.d = v2; // com.sec.a.a.a.u.d:int
        // goto L_0006
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.c; // com.sec.a.a.a.u.c:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.c = v0; // com.sec.a.a.a.u.c:byte
        // goto L_0008
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.sec.a.a.a.u.e -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.f(); // com.sec.a.a.a.u.f -> com.sec.a.a.a.v
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (5 total): v3 = this, v4 = p0 (com.google.protobuf.CodedOutputStream)
        _result = v3.getSerializedSize(); // com.sec.a.a.a.u.getSerializedSize -> int
        v0 = 0;
        v1 = v0;
        v0 = v3.b; // com.sec.a.a.a.u.b:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001d */;
        v2 = 1;
        v0 = v3.b; // com.sec.a.a.a.u.b:java.util.List
        _result = java.util.List.get(v0, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        _result = v4.writeMessage(v2, v0); // com.google.protobuf.CodedOutputStream.writeMessage -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0005
        return;
    }

}