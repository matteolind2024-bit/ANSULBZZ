package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/w;
 */
public interface w extends com.google.protobuf.MessageLiteOrBuilder {
}