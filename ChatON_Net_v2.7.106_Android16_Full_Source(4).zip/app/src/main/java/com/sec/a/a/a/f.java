package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontend.java
 * Descriptor: Lcom/sec/a/a/a/f;
 */
public final class f extends com.google.protobuf.GeneratedMessageLite implements com.sec.a.a.a.h {
    private static final com.sec.a.a.a.f a;
    private int b;
    private int c;
    private java.lang.Object d;
    private java.lang.Object e;
    private java.lang.Object f;
    private byte g;
    private int h;

    static {
        v0 = new com.sec.a.a.a.f;
        v1 = 1;
        _result = v0.<init>(v1); // com.sec.a.a.a.f.<init> -> void
        com.sec.a.a.a.f.a = v0; // :com.sec.a.a.a.f
        v0 = com.sec.a.a.a.f.a; // :com.sec.a.a.a.f
        _result = v0.p(); // com.sec.a.a.a.f.p -> void
        return;
    }

    private f(com.sec.a.a.a.g p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.sec.a.a.a.g)
        v0 = -1;
        _result = v1.<init>(v2); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.g = v0; // com.sec.a.a.a.f.g:byte
        v1.h = v0; // com.sec.a.a.a.f.h:int
        return;
    }

    f(com.sec.a.a.a.g p0, com.sec.a.a.a.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.sec.a.a.a.g), v2 = p1 (com.sec.a.a.a.b)
        _result = v0.<init>(v1); // com.sec.a.a.a.f.<init> -> void
        return;
    }

    private f(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = -1;
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        v1.g = v0; // com.sec.a.a.a.f.g:byte
        v1.h = v0; // com.sec.a.a.a.f.h:int
        return;
    }

    static int a(com.sec.a.a.a.f p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.f), v1 = p1 (int)
        v0.c = v1; // com.sec.a.a.a.f.c:int
        return v1;
    }

    public static com.sec.a.a.a.f a() {
        v0 = com.sec.a.a.a.f.a; // :com.sec.a.a.a.f
        return v0;
    }

    public static com.sec.a.a.a.f a(byte[] p0) {
        // Registers (2 total): v1 = p0 (byte[])
        _result = this.newBuilder(); // com.sec.a.a.a.f.newBuilder -> com.sec.a.a.a.g
        v0 = _result;
        _result = v0.mergeFrom(v1); // com.sec.a.a.a.g.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        v0 = (com.sec.a.a.a.g) v0;
        _result = v0.a(); // com.sec.a.a.a.g.a -> com.sec.a.a.a.f
        v0 = _result;
        return v0;
    }

    public static com.sec.a.a.a.g a(com.sec.a.a.a.f p0) {
        // Registers (2 total): v1 = p0 (com.sec.a.a.a.f)
        _result = this.newBuilder(); // com.sec.a.a.a.f.newBuilder -> com.sec.a.a.a.g
        v0 = _result;
        _result = v0.a(v1); // com.sec.a.a.a.g.a -> com.sec.a.a.a.g
        v0 = _result;
        return v0;
    }

    static java.lang.Object a(com.sec.a.a.a.f p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.f), v1 = p1 (java.lang.Object)
        v0.d = v1; // com.sec.a.a.a.f.d:java.lang.Object
        return v1;
    }

    static int b(com.sec.a.a.a.f p0, int p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.f), v1 = p1 (int)
        v0.b = v1; // com.sec.a.a.a.f.b:int
        return v1;
    }

    static java.lang.Object b(com.sec.a.a.a.f p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.f), v1 = p1 (java.lang.Object)
        v0.e = v1; // com.sec.a.a.a.f.e:java.lang.Object
        return v1;
    }

    static java.lang.Object c(com.sec.a.a.a.f p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (com.sec.a.a.a.f), v1 = p1 (java.lang.Object)
        v0.f = v1; // com.sec.a.a.a.f.f:java.lang.Object
        return v1;
    }

    private com.google.protobuf.ByteString m() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.a.a.a.f.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.d = v0; // com.sec.a.a.a.f.d:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private com.google.protobuf.ByteString n() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.a.a.a.f.e:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.e = v0; // com.sec.a.a.a.f.e:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    public static com.sec.a.a.a.g newBuilder() {
        _result = this.f(); // com.sec.a.a.a.g.f -> com.sec.a.a.a.g
        v0 = _result;
        return v0;
    }

    private com.google.protobuf.ByteString o() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // com.sec.a.a.a.f.f:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v2.f = v0; // com.sec.a.a.a.f.f:java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_000e
    }

    private void p() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.c = v0; // com.sec.a.a.a.f.c:int
        v0 = "";
        v1.d = v0; // com.sec.a.a.a.f.d:java.lang.Object
        v0 = "";
        v1.e = v0; // com.sec.a.a.a.f.e:java.lang.Object
        v0 = "";
        v1.f = v0; // com.sec.a.a.a.f.f:java.lang.Object
        return;
    }

    public com.sec.a.a.a.f b() {
        // Registers (2 total): v1 = this
        v0 = com.sec.a.a.a.f.a; // :com.sec.a.a.a.f
        return v0;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // com.sec.a.a.a.f.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v0) /* goto L_0008 */;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public int d() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.sec.a.a.a.f.c:int
        return v0;
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.f.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public java.lang.String f() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.sec.a.a.a.f.d:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.d = v1; // com.sec.a.a.a.f.d:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean g() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.f.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        v1 = 4;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.sec.a.a.a.f.b -> com.sec.a.a.a.f
        v0 = _result;
        return v0;
    }

    public int getSerializedSize() {
        // Registers (6 total): v5 = this
        v4 = 4;
        v3 = 2;
        v2 = 1;
        v0 = v5.h; // com.sec.a.a.a.f.h:int
        v1 = -1;
        if (v0 == v1) /* goto L_0009 */;
        return v0;
        v0 = 0;
        v1 = v5.b; // com.sec.a.a.a.f.b:int
        v1 = binOpLit8_0xdd(v1, 1);
        if (v1 != v2) /* goto L_0017 */;
        v1 = v5.c; // com.sec.a.a.a.f.c:int
        _result = v2.computeInt32Size(v1); // com.google.protobuf.CodedOutputStream.computeInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.f.b:int
        v1 = binOpLit8_0xdd(v1, 2);
        if (v1 != v3) /* goto L_0026 */;
        _result = v5.m(); // com.sec.a.a.a.f.m -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v3.computeBytesSize(v1); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.f.b:int
        v1 = binOpLit8_0xdd(v1, 4);
        if (v1 != v4) /* goto L_0036 */;
        v1 = 3;
        _result = v5.n(); // com.sec.a.a.a.f.n -> com.google.protobuf.ByteString
        v2 = _result;
        _result = v1.computeBytesSize(v2); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v5.b; // com.sec.a.a.a.f.b:int
        v1 = binOpLit8_0xdd(v1, 8);
        v2 = 8;
        if (v1 != v2) /* goto L_0047 */;
        _result = v5.o(); // com.sec.a.a.a.f.o -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v4.computeBytesSize(v1); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v5.h = v0; // com.sec.a.a.a.f.h:int
        // goto L_0008
    }

    public java.lang.String h() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.sec.a.a.a.f.e:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.e = v1; // com.sec.a.a.a.f.e:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public boolean i() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.sec.a.a.a.f.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public final boolean isInitialized() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.g; // com.sec.a.a.a.f.g:byte
        v2 = -1;
        if (v1 == v2) /* goto L_000b */;
        if (v1 != v0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
        v3.g = v0; // com.sec.a.a.a.f.g:byte
        // goto L_0008
    }

    public java.lang.String j() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // com.sec.a.a.a.f.f:java.lang.Object
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0009 */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v2.f = v1; // com.sec.a.a.a.f.f:java.lang.Object
        v0 = v1;
        // goto L_0008
    }

    public com.sec.a.a.a.g k() {
        // Registers (2 total): v1 = this
        _result = this.newBuilder(); // com.sec.a.a.a.f.newBuilder -> com.sec.a.a.a.g
        v0 = _result;
        return v0;
    }

    public com.sec.a.a.a.g l() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // com.sec.a.a.a.f.a -> com.sec.a.a.a.g
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder newBuilderForType() {
        // Registers (2 total): v1 = this
        _result = v1.k(); // com.sec.a.a.a.f.k -> com.sec.a.a.a.g
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder toBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.l(); // com.sec.a.a.a.f.l -> com.sec.a.a.a.g
        v0 = _result;
        return v0;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        _result = v1.writeReplace(); // com.google.protobuf.GeneratedMessageLite.writeReplace -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (6 total): v4 = this, v5 = p0 (com.google.protobuf.CodedOutputStream)
        v3 = 4;
        v2 = 2;
        v1 = 1;
        _result = v4.getSerializedSize(); // com.sec.a.a.a.f.getSerializedSize -> int
        v0 = v4.b; // com.sec.a.a.a.f.b:int
        v0 = binOpLit8_0xdd(v0, 1);
        if (v0 != v1) /* goto L_0011 */;
        v0 = v4.c; // com.sec.a.a.a.f.c:int
        _result = v5.writeInt32(v1, v0); // com.google.protobuf.CodedOutputStream.writeInt32 -> void
        v0 = v4.b; // com.sec.a.a.a.f.b:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 != v2) /* goto L_001e */;
        _result = v4.m(); // com.sec.a.a.a.f.m -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v5.writeBytes(v2, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v4.b; // com.sec.a.a.a.f.b:int
        v0 = binOpLit8_0xdd(v0, 4);
        if (v0 != v3) /* goto L_002c */;
        v0 = 3;
        _result = v4.n(); // com.sec.a.a.a.f.n -> com.google.protobuf.ByteString
        v1 = _result;
        _result = v5.writeBytes(v0, v1); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = v4.b; // com.sec.a.a.a.f.b:int
        v0 = binOpLit8_0xdd(v0, 8);
        v1 = 8;
        if (v0 != v1) /* goto L_003b */;
        _result = v4.o(); // com.sec.a.a.a.f.o -> com.google.protobuf.ByteString
        v0 = _result;
        _result = v5.writeBytes(v3, v0); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        return;
    }

}