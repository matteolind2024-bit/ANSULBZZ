package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/af;
 */
public interface af extends com.google.protobuf.MessageLiteOrBuilder {
}