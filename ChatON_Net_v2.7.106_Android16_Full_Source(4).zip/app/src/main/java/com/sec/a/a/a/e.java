package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/e;
 */
public interface e extends com.google.protobuf.MessageLiteOrBuilder {
}