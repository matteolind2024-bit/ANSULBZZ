package com.sec.a.a.a;

/**
 * Original SourceFile: MsgFrontendCommon.java
 * Descriptor: Lcom/sec/a/a/a/ap;
 */
public class ap {
    public static byte a(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v0 = (v1 instanceof com.sec.a.a.a.l);
        if (v0 == 0) /* goto L_0006 */;
        v0 = 0;
        return v0;
        v0 = (v1 instanceof com.sec.a.a.a.i);
        if (v0 == 0) /* goto L_000c */;
        v0 = 1;
        // goto L_0005
        v0 = (v1 instanceof com.sec.a.a.a.am);
        if (v0 == 0) /* goto L_0012 */;
        v0 = 2;
        // goto L_0005
        v0 = (v1 instanceof com.sec.a.a.a.aj);
        if (v0 == 0) /* goto L_0018 */;
        v0 = 3;
        // goto L_0005
        v0 = (v1 instanceof com.sec.a.a.a.f);
        if (v0 == 0) /* goto L_001e */;
        v0 = 4;
        // goto L_0005
        v0 = (v1 instanceof com.sec.a.a.a.c);
        if (v0 == 0) /* goto L_0024 */;
        v0 = 5;
        // goto L_0005
        v0 = (v1 instanceof com.sec.a.a.a.aa);
        if (v0 == 0) /* goto L_002a */;
        v0 = 6;
        // goto L_0005
        v0 = (v1 instanceof com.sec.a.a.a.x);
        if (v0 == 0) /* goto L_0030 */;
        v0 = 7;
        // goto L_0005
        v0 = (v1 instanceof com.sec.a.a.a.r);
        if (v0 == 0) /* goto L_0037 */;
        v0 = 8;
        // goto L_0005
        v0 = (v1 instanceof com.sec.a.a.a.u);
        if (v0 == 0) /* goto L_003e */;
        v0 = 9;
        // goto L_0005
        v0 = (v1 instanceof com.sec.a.a.a.o);
        if (v0 == 0) /* goto L_0045 */;
        v0 = 10;
        // goto L_0005
        v0 = (v1 instanceof com.sec.a.a.a.ag);
        if (v0 == 0) /* goto L_004c */;
        v0 = 11;
        // goto L_0005
        v0 = (v1 instanceof com.sec.a.a.a.ad);
        if (v0 == 0) /* goto L_0053 */;
        v0 = 12;
        // goto L_0005
        v0 = -1;
        // goto L_0005
    }

    public static java.lang.Object a(byte p0, byte[] p1) {
        // Registers (4 total): v2 = p0 (byte), v3 = p1 (byte[])
        v0 = 0;
        // switch(v2)
        return v0;
        _result = v3.a(); // com.sec.a.a.a.l.a -> com.sec.a.a.a.l
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.i.a -> com.sec.a.a.a.i
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.am.a -> com.sec.a.a.a.am
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.aj.a -> com.sec.a.a.a.aj
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.f.a -> com.sec.a.a.a.f
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.c.a -> com.sec.a.a.a.c
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.aa.a -> com.sec.a.a.a.aa
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.x.a -> com.sec.a.a.a.x
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.r.a -> com.sec.a.a.a.r
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.u.a -> com.sec.a.a.a.u
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.o.a -> com.sec.a.a.a.o
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.ag.a -> com.sec.a.a.a.ag
        v0 = _result;
        // goto L_0004
        _result = v3.a(); // com.sec.a.a.a.ad.a -> com.sec.a.a.a.ad
        v0 = _result;
        // goto L_0004
        v1 = _exception;
        _result = v1.printStackTrace(); // com.google.protobuf.InvalidProtocolBufferException.printStackTrace -> void
        // goto L_0004
    }

    public static java.lang.String a(byte p0) {
        // Registers (2 total): v1 = p0 (byte)
        v0 = 0;
        // switch(v1)
        return v0;
        v0 = "InitRequest";
        // goto L_0004
        v0 = "InitReply";
        // goto L_0004
        v0 = "RegistrationRequest";
        // goto L_0004
        v0 = "RegistrationReply";
        // goto L_0004
        v0 = "DeregistrationRequest";
        // goto L_0004
        v0 = "DeregistrationReply";
        // goto L_0004
        v0 = "PingRequest";
        // goto L_0004
        v0 = "PingReply";
        // goto L_0004
        v0 = "NotiElement";
        // goto L_0004
        v0 = "NotiGroup";
        // goto L_0004
        v0 = "NotiAcks";
        // goto L_0004
        v0 = "ProvisionRequest";
        // goto L_0004
        v0 = "ProvisionReply";
        // goto L_0004
    }

    public static java.lang.String b(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        _result = v1.a(); // com.sec.a.a.a.ap.a -> byte
        v0 = _result;
        _result = v0.a(); // com.sec.a.a.a.ap.a -> java.lang.String
        v0 = _result;
        return v0;
    }

}