package com.sec.a.a.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/sec/a/a/a/ai;
 */
public interface ai extends com.google.protobuf.MessageLiteOrBuilder {
}