package com.google.protobuf;

/**
 * Original SourceFile: Internal.java
 * Descriptor: Lcom/google/protobuf/Internal$EnumLiteMap;
 */
public interface Internal$EnumLiteMap {
    public abstract com.google.protobuf.Internal$EnumLite findValueByNumber(int p0);
}