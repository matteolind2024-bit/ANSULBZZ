package com.google.protobuf;

/**
 * Original SourceFile: FieldSet.java
 * Descriptor: Lcom/google/protobuf/FieldSet;
 */
final class FieldSet {
    private static final com.google.protobuf.FieldSet DEFAULT_INSTANCE;
    private final com.google.protobuf.SmallSortedMap fields;
    private boolean isImmutable;

    static {
        v0 = new com.google.protobuf.FieldSet;
        v1 = 1;
        _result = v0.<init>(v1); // com.google.protobuf.FieldSet.<init> -> void
        com.google.protobuf.FieldSet.DEFAULT_INSTANCE = v0; // :com.google.protobuf.FieldSet
        return;
    }

    private FieldSet() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 16;
        _result = v0.newFieldMap(); // com.google.protobuf.SmallSortedMap.newFieldMap -> com.google.protobuf.SmallSortedMap
        v0 = _result;
        v1.fields = v0; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        return;
    }

    private FieldSet(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        _result = v0.newFieldMap(); // com.google.protobuf.SmallSortedMap.newFieldMap -> com.google.protobuf.SmallSortedMap
        v0 = _result;
        v1.fields = v0; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v1.makeImmutable(); // com.google.protobuf.FieldSet.makeImmutable -> void
        return;
    }

    private static int computeElementSize(com.google.protobuf.WireFormat$FieldType p0, int p1, java.lang.Object p2) {
        // Registers (5 total): v2 = p0 (com.google.protobuf.WireFormat$FieldType), v3 = p1 (int), v4 = p2 (java.lang.Object)
        _result = v3.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        v1 = com.google.protobuf.WireFormat$FieldType.GROUP; // :com.google.protobuf.WireFormat$FieldType
        if (v2 != v1) /* goto L_000a */;
        v0 = binOpLit8_0xda(v0, 2);
        _result = v2.computeElementSizeNoTag(v4); // com.google.protobuf.FieldSet.computeElementSizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    private static int computeElementSizeNoTag(com.google.protobuf.WireFormat$FieldType p0, java.lang.Object p1) {
        // Registers (4 total): v2 = p0 (com.google.protobuf.WireFormat$FieldType), v3 = p1 (java.lang.Object)
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        _result = v2.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v0 = v0[v1];
        // switch(v0)
        v0 = new java.lang.RuntimeException;
        v1 = "There is no way to get here, but the compiler thinks otherwise.";
        _result = v0.<init>(v1); // java.lang.RuntimeException.<init> -> void
        throw v0;
        v3 = (java.lang.Double) v3;
        _result = v3.doubleValue(); // java.lang.Double.doubleValue -> double
        v0 = _result;
        _result = v0.computeDoubleSizeNoTag(v1); // com.google.protobuf.CodedOutputStream.computeDoubleSizeNoTag -> int
        v0 = _result;
        return v0;
        v3 = (java.lang.Float) v3;
        _result = v3.floatValue(); // java.lang.Float.floatValue -> float
        v0 = _result;
        _result = v0.computeFloatSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeFloatSizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.Long) v3;
        _result = v3.longValue(); // java.lang.Long.longValue -> long
        v0 = _result;
        _result = v0.computeInt64SizeNoTag(v1); // com.google.protobuf.CodedOutputStream.computeInt64SizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.Long) v3;
        _result = v3.longValue(); // java.lang.Long.longValue -> long
        v0 = _result;
        _result = v0.computeUInt64SizeNoTag(v1); // com.google.protobuf.CodedOutputStream.computeUInt64SizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.Integer) v3;
        _result = v3.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v0.computeInt32SizeNoTag(); // com.google.protobuf.CodedOutputStream.computeInt32SizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.Long) v3;
        _result = v3.longValue(); // java.lang.Long.longValue -> long
        v0 = _result;
        _result = v0.computeFixed64SizeNoTag(v1); // com.google.protobuf.CodedOutputStream.computeFixed64SizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.Integer) v3;
        _result = v3.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v0.computeFixed32SizeNoTag(); // com.google.protobuf.CodedOutputStream.computeFixed32SizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.Boolean) v3;
        _result = v3.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        _result = v0.computeBoolSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeBoolSizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.String) v3;
        _result = v3.computeStringSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeStringSizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (com.google.protobuf.MessageLite) v3;
        _result = v3.computeGroupSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeGroupSizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (com.google.protobuf.MessageLite) v3;
        _result = v3.computeMessageSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeMessageSizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (com.google.protobuf.ByteString) v3;
        _result = v3.computeBytesSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeBytesSizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.Integer) v3;
        _result = v3.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v0.computeUInt32SizeNoTag(); // com.google.protobuf.CodedOutputStream.computeUInt32SizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.Integer) v3;
        _result = v3.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v0.computeSFixed32SizeNoTag(); // com.google.protobuf.CodedOutputStream.computeSFixed32SizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.Long) v3;
        _result = v3.longValue(); // java.lang.Long.longValue -> long
        v0 = _result;
        _result = v0.computeSFixed64SizeNoTag(v1); // com.google.protobuf.CodedOutputStream.computeSFixed64SizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.Integer) v3;
        _result = v3.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v0.computeSInt32SizeNoTag(); // com.google.protobuf.CodedOutputStream.computeSInt32SizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (java.lang.Long) v3;
        _result = v3.longValue(); // java.lang.Long.longValue -> long
        v0 = _result;
        _result = v0.computeSInt64SizeNoTag(v1); // com.google.protobuf.CodedOutputStream.computeSInt64SizeNoTag -> int
        v0 = _result;
        // goto L_001d
        v3 = (com.google.protobuf.Internal$EnumLite) v3;
        _result = com.google.protobuf.Internal$EnumLite.getNumber(v3); // -> int
        v0 = _result;
        _result = v0.computeEnumSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeEnumSizeNoTag -> int
        v0 = _result;
        // goto L_001d
    }

    public static int computeFieldSize(com.google.protobuf.FieldSet$FieldDescriptorLite p0, java.lang.Object p1) {
        // Registers (7 total): v5 = p0 (com.google.protobuf.FieldSet$FieldDescriptorLite), v6 = p1 (java.lang.Object)
        v0 = 0;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getLiteType(v5); // -> com.google.protobuf.WireFormat$FieldType
        v1 = _result;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getNumber(v5); // -> int
        v2 = _result;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v5); // -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_004c */;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isPacked(v5); // -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0036 */;
        v6 = (java.util.List) v6;
        _result = java.util.List.iterator(v6); // -> java.util.Iterator
        v3 = _result;
        _result = java.util.Iterator.hasNext(v3); // -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_002b */;
        _result = java.util.Iterator.next(v3); // -> java.lang.Object
        v4 = _result;
        _result = v1.computeElementSizeNoTag(v4); // com.google.protobuf.FieldSet.computeElementSizeNoTag -> int
        v4 = _result;
        v0 = binOp2addr_0xb0(v0, v4);
        // goto L_001b
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v1 = _result;
        v1 = binOp2addr_0xb0(v1, v0);
        _result = v0.computeRawVarint32Size(); // com.google.protobuf.CodedOutputStream.computeRawVarint32Size -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v6 = (java.util.List) v6;
        _result = java.util.List.iterator(v6); // -> java.util.Iterator
        v3 = _result;
        _result = java.util.Iterator.hasNext(v3); // -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_0035 */;
        _result = java.util.Iterator.next(v3); // -> java.lang.Object
        v4 = _result;
        _result = v1.computeElementSize(v2, v4); // com.google.protobuf.FieldSet.computeElementSize -> int
        v4 = _result;
        v0 = binOp2addr_0xb0(v0, v4);
        // goto L_003c
        _result = v1.computeElementSize(v2, v6); // com.google.protobuf.FieldSet.computeElementSize -> int
        v0 = _result;
        // goto L_0035
    }

    public static com.google.protobuf.FieldSet emptySet() {
        v0 = com.google.protobuf.FieldSet.DEFAULT_INSTANCE; // :com.google.protobuf.FieldSet
        return v0;
    }

    private int getMessageSetSerializedSize(java.util.Map$Entry p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.util.Map$Entry)
        _result = java.util.Map$Entry.getKey(v4); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v0;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getLiteJavaType(v0); // -> com.google.protobuf.WireFormat$JavaType
        v1 = _result;
        v2 = com.google.protobuf.WireFormat$JavaType.MESSAGE; // :com.google.protobuf.WireFormat$JavaType
        if (v1 != v2) /* goto L_002f */;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v0); // -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_002f */;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isPacked(v0); // -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_002f */;
        _result = java.util.Map$Entry.getKey(v4); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v0;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getNumber(v0); // -> int
        v1 = _result;
        _result = java.util.Map$Entry.getValue(v4); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        _result = v1.computeMessageSetExtensionSize(v0); // com.google.protobuf.CodedOutputStream.computeMessageSetExtensionSize -> int
        v0 = _result;
        return v0;
        _result = java.util.Map$Entry.getValue(v4); // -> java.lang.Object
        v1 = _result;
        _result = v0.computeFieldSize(v1); // com.google.protobuf.FieldSet.computeFieldSize -> int
        v0 = _result;
        // goto L_002e
    }

    static int getWireFormatForFieldType(com.google.protobuf.WireFormat$FieldType p0, boolean p1) {
        // Registers (3 total): v1 = p0 (com.google.protobuf.WireFormat$FieldType), v2 = p1 (boolean)
        if (v2 == 0) /* goto L_0004 */;
        v0 = 2;
        return v0;
        _result = v1.getWireType(); // com.google.protobuf.WireFormat$FieldType.getWireType -> int
        v0 = _result;
        // goto L_0003
    }

    private boolean isInitialized(java.util.Map$Entry p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.util.Map$Entry)
        v1 = 0;
        _result = java.util.Map$Entry.getKey(v5); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v0;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getLiteJavaType(v0); // -> com.google.protobuf.WireFormat$JavaType
        v2 = _result;
        v3 = com.google.protobuf.WireFormat$JavaType.MESSAGE; // :com.google.protobuf.WireFormat$JavaType
        if (v2 != v3) /* goto L_0041 */;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0033 */;
        _result = java.util.Map$Entry.getValue(v5); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.List) v0;
        _result = java.util.List.iterator(v0); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0041 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        _result = com.google.protobuf.MessageLite.isInitialized(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_001f */;
        v0 = v1;
        return v0;
        _result = java.util.Map$Entry.getValue(v5); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        _result = com.google.protobuf.MessageLite.isInitialized(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0041 */;
        v0 = v1;
        // goto L_0032
        v0 = 1;
        // goto L_0032
    }

    private void mergeFromField(java.util.Map$Entry p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.util.Map$Entry)
        _result = java.util.Map$Entry.getKey(v5); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v0;
        _result = java.util.Map$Entry.getValue(v5); // -> java.lang.Object
        v1 = _result;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v0); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_002e */;
        v2 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v2.get(v0); // com.google.protobuf.SmallSortedMap.get -> java.lang.Object
        v2 = _result;
        if (v2 != 0) /* goto L_0025 */;
        v2 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        v3 = new java.util.ArrayList;
        v1 = (java.util.List) v1;
        _result = v3.<init>(v1); // java.util.ArrayList.<init> -> void
        _result = v2.put(v0, v3); // com.google.protobuf.SmallSortedMap.put -> java.lang.Object
        return;
        v0 = v2;
        v0 = (java.util.List) v0;
        v1 = (java.util.List) v1;
        _result = java.util.List.addAll(v0, v1); // -> boolean
        // goto L_0024
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getLiteJavaType(v0); // -> com.google.protobuf.WireFormat$JavaType
        v2 = _result;
        v3 = com.google.protobuf.WireFormat$JavaType.MESSAGE; // :com.google.protobuf.WireFormat$JavaType
        if (v2 != v3) /* goto L_005a */;
        v2 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v2.get(v0); // com.google.protobuf.SmallSortedMap.get -> java.lang.Object
        v2 = _result;
        if (v2 != 0) /* goto L_0044 */;
        v2 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v2.put(v0, v1); // com.google.protobuf.SmallSortedMap.put -> java.lang.Object
        // goto L_0024
        v3 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        v2 = (com.google.protobuf.MessageLite) v2;
        _result = com.google.protobuf.MessageLite.toBuilder(v2); // -> com.google.protobuf.MessageLite$Builder
        v2 = _result;
        v1 = (com.google.protobuf.MessageLite) v1;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.internalMergeFrom(v0, v2, v1); // -> com.google.protobuf.MessageLite$Builder
        v1 = _result;
        _result = com.google.protobuf.MessageLite$Builder.build(v1); // -> com.google.protobuf.MessageLite
        v1 = _result;
        _result = v3.put(v0, v1); // com.google.protobuf.SmallSortedMap.put -> java.lang.Object
        // goto L_0024
        v2 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v2.put(v0, v1); // com.google.protobuf.SmallSortedMap.put -> java.lang.Object
        // goto L_0024
    }

    public static com.google.protobuf.FieldSet newFieldSet() {
        v0 = new com.google.protobuf.FieldSet;
        _result = v0.<init>(); // com.google.protobuf.FieldSet.<init> -> void
        return v0;
    }

    public static java.lang.Object readPrimitiveField(com.google.protobuf.CodedInputStream p0, com.google.protobuf.WireFormat$FieldType p1) {
        // Registers (4 total): v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.WireFormat$FieldType)
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        _result = v3.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v0 = v0[v1];
        // switch(v0)
        v0 = new java.lang.RuntimeException;
        v1 = "There is no way to get here, but the compiler thinks otherwise.";
        _result = v0.<init>(v1); // java.lang.RuntimeException.<init> -> void
        throw v0;
        _result = v2.readDouble(); // com.google.protobuf.CodedInputStream.readDouble -> double
        v0 = _result;
        _result = v0.valueOf(v1); // java.lang.Double.valueOf -> java.lang.Double
        v0 = _result;
        return v0;
        _result = v2.readFloat(); // com.google.protobuf.CodedInputStream.readFloat -> float
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Float.valueOf -> java.lang.Float
        v0 = _result;
        // goto L_001b
        _result = v2.readInt64(); // com.google.protobuf.CodedInputStream.readInt64 -> long
        v0 = _result;
        _result = v0.valueOf(v1); // java.lang.Long.valueOf -> java.lang.Long
        v0 = _result;
        // goto L_001b
        _result = v2.readUInt64(); // com.google.protobuf.CodedInputStream.readUInt64 -> long
        v0 = _result;
        _result = v0.valueOf(v1); // java.lang.Long.valueOf -> java.lang.Long
        v0 = _result;
        // goto L_001b
        _result = v2.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v0 = _result;
        // goto L_001b
        _result = v2.readFixed64(); // com.google.protobuf.CodedInputStream.readFixed64 -> long
        v0 = _result;
        _result = v0.valueOf(v1); // java.lang.Long.valueOf -> java.lang.Long
        v0 = _result;
        // goto L_001b
        _result = v2.readFixed32(); // com.google.protobuf.CodedInputStream.readFixed32 -> int
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v0 = _result;
        // goto L_001b
        _result = v2.readBool(); // com.google.protobuf.CodedInputStream.readBool -> boolean
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v0 = _result;
        // goto L_001b
        _result = v2.readString(); // com.google.protobuf.CodedInputStream.readString -> java.lang.String
        v0 = _result;
        // goto L_001b
        _result = v2.readBytes(); // com.google.protobuf.CodedInputStream.readBytes -> com.google.protobuf.ByteString
        v0 = _result;
        // goto L_001b
        _result = v2.readUInt32(); // com.google.protobuf.CodedInputStream.readUInt32 -> int
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v0 = _result;
        // goto L_001b
        _result = v2.readSFixed32(); // com.google.protobuf.CodedInputStream.readSFixed32 -> int
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v0 = _result;
        // goto L_001b
        _result = v2.readSFixed64(); // com.google.protobuf.CodedInputStream.readSFixed64 -> long
        v0 = _result;
        _result = v0.valueOf(v1); // java.lang.Long.valueOf -> java.lang.Long
        v0 = _result;
        // goto L_001b
        _result = v2.readSInt32(); // com.google.protobuf.CodedInputStream.readSInt32 -> int
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v0 = _result;
        // goto L_001b
        _result = v2.readSInt64(); // com.google.protobuf.CodedInputStream.readSInt64 -> long
        v0 = _result;
        _result = v0.valueOf(v1); // java.lang.Long.valueOf -> java.lang.Long
        v0 = _result;
        // goto L_001b
        v0 = new java.lang.IllegalArgumentException;
        v1 = "readPrimitiveField() cannot handle nested groups.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "readPrimitiveField() cannot handle embedded messages.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "readPrimitiveField() cannot handle enums.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
    }

    private static void verifyType(com.google.protobuf.WireFormat$FieldType p0, java.lang.Object p1) {
        // Registers (5 total): v3 = p0 (com.google.protobuf.WireFormat$FieldType), v4 = p1 (java.lang.Object)
        if (v4 != 0) /* goto L_0008 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = 0;
        v1 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        _result = v3.getJavaType(); // com.google.protobuf.WireFormat$FieldType.getJavaType -> com.google.protobuf.WireFormat$JavaType
        v2 = _result;
        _result = v2.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v2 = _result;
        v1 = v1[v2];
        // switch(v1)
        if (v0 != 0) /* goto L_003d */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Wrong object type used with protocol message reflection.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = (v4 instanceof java.lang.Integer);
        // goto L_0018
        v0 = (v4 instanceof java.lang.Long);
        // goto L_0018
        v0 = (v4 instanceof java.lang.Float);
        // goto L_0018
        v0 = (v4 instanceof java.lang.Double);
        // goto L_0018
        v0 = (v4 instanceof java.lang.Boolean);
        // goto L_0018
        v0 = (v4 instanceof java.lang.String);
        // goto L_0018
        v0 = (v4 instanceof com.google.protobuf.ByteString);
        // goto L_0018
        v0 = (v4 instanceof com.google.protobuf.Internal$EnumLite);
        // goto L_0018
        v0 = (v4 instanceof com.google.protobuf.MessageLite);
        // goto L_0018
        return;
    }

    private static void writeElement(com.google.protobuf.CodedOutputStream p0, com.google.protobuf.WireFormat$FieldType p1, int p2, java.lang.Object p3) {
        // Registers (5 total): v1 = p0 (com.google.protobuf.CodedOutputStream), v2 = p1 (com.google.protobuf.WireFormat$FieldType), v3 = p2 (int), v4 = p3 (java.lang.Object)
        v0 = com.google.protobuf.WireFormat$FieldType.GROUP; // :com.google.protobuf.WireFormat$FieldType
        if (v2 != v0) /* goto L_000a */;
        v4 = (com.google.protobuf.MessageLite) v4;
        _result = v1.writeGroup(v3, v4); // com.google.protobuf.CodedOutputStream.writeGroup -> void
        return;
        v0 = 0;
        _result = v2.getWireFormatForFieldType(v0); // com.google.protobuf.FieldSet.getWireFormatForFieldType -> int
        v0 = _result;
        _result = v1.writeTag(v3, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeElementNoTag(v2, v4); // com.google.protobuf.FieldSet.writeElementNoTag -> void
        // goto L_0009
    }

    private static void writeElementNoTag(com.google.protobuf.CodedOutputStream p0, com.google.protobuf.WireFormat$FieldType p1, java.lang.Object p2) {
        // Registers (5 total): v2 = p0 (com.google.protobuf.CodedOutputStream), v3 = p1 (com.google.protobuf.WireFormat$FieldType), v4 = p2 (java.lang.Object)
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        _result = v3.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v0 = v0[v1];
        // switch(v0)
        return;
        v4 = (java.lang.Double) v4;
        _result = v4.doubleValue(); // java.lang.Double.doubleValue -> double
        v0 = _result;
        _result = v2.writeDoubleNoTag(v0, v1); // com.google.protobuf.CodedOutputStream.writeDoubleNoTag -> void
        // goto L_000b
        v4 = (java.lang.Float) v4;
        _result = v4.floatValue(); // java.lang.Float.floatValue -> float
        v0 = _result;
        _result = v2.writeFloatNoTag(v0); // com.google.protobuf.CodedOutputStream.writeFloatNoTag -> void
        // goto L_000b
        v4 = (java.lang.Long) v4;
        _result = v4.longValue(); // java.lang.Long.longValue -> long
        v0 = _result;
        _result = v2.writeInt64NoTag(v0, v1); // com.google.protobuf.CodedOutputStream.writeInt64NoTag -> void
        // goto L_000b
        v4 = (java.lang.Long) v4;
        _result = v4.longValue(); // java.lang.Long.longValue -> long
        v0 = _result;
        _result = v2.writeUInt64NoTag(v0, v1); // com.google.protobuf.CodedOutputStream.writeUInt64NoTag -> void
        // goto L_000b
        v4 = (java.lang.Integer) v4;
        _result = v4.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v2.writeInt32NoTag(v0); // com.google.protobuf.CodedOutputStream.writeInt32NoTag -> void
        // goto L_000b
        v4 = (java.lang.Long) v4;
        _result = v4.longValue(); // java.lang.Long.longValue -> long
        v0 = _result;
        _result = v2.writeFixed64NoTag(v0, v1); // com.google.protobuf.CodedOutputStream.writeFixed64NoTag -> void
        // goto L_000b
        v4 = (java.lang.Integer) v4;
        _result = v4.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v2.writeFixed32NoTag(v0); // com.google.protobuf.CodedOutputStream.writeFixed32NoTag -> void
        // goto L_000b
        v4 = (java.lang.Boolean) v4;
        _result = v4.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        _result = v2.writeBoolNoTag(v0); // com.google.protobuf.CodedOutputStream.writeBoolNoTag -> void
        // goto L_000b
        v4 = (java.lang.String) v4;
        _result = v2.writeStringNoTag(v4); // com.google.protobuf.CodedOutputStream.writeStringNoTag -> void
        // goto L_000b
        v4 = (com.google.protobuf.MessageLite) v4;
        _result = v2.writeGroupNoTag(v4); // com.google.protobuf.CodedOutputStream.writeGroupNoTag -> void
        // goto L_000b
        v4 = (com.google.protobuf.MessageLite) v4;
        _result = v2.writeMessageNoTag(v4); // com.google.protobuf.CodedOutputStream.writeMessageNoTag -> void
        // goto L_000b
        v4 = (com.google.protobuf.ByteString) v4;
        _result = v2.writeBytesNoTag(v4); // com.google.protobuf.CodedOutputStream.writeBytesNoTag -> void
        // goto L_000b
        v4 = (java.lang.Integer) v4;
        _result = v4.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v2.writeUInt32NoTag(v0); // com.google.protobuf.CodedOutputStream.writeUInt32NoTag -> void
        // goto L_000b
        v4 = (java.lang.Integer) v4;
        _result = v4.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v2.writeSFixed32NoTag(v0); // com.google.protobuf.CodedOutputStream.writeSFixed32NoTag -> void
        // goto L_000b
        v4 = (java.lang.Long) v4;
        _result = v4.longValue(); // java.lang.Long.longValue -> long
        v0 = _result;
        _result = v2.writeSFixed64NoTag(v0, v1); // com.google.protobuf.CodedOutputStream.writeSFixed64NoTag -> void
        // goto L_000b
        v4 = (java.lang.Integer) v4;
        _result = v4.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v2.writeSInt32NoTag(v0); // com.google.protobuf.CodedOutputStream.writeSInt32NoTag -> void
        // goto L_000b
        v4 = (java.lang.Long) v4;
        _result = v4.longValue(); // java.lang.Long.longValue -> long
        v0 = _result;
        _result = v2.writeSInt64NoTag(v0, v1); // com.google.protobuf.CodedOutputStream.writeSInt64NoTag -> void
        // goto L_000b
        v4 = (com.google.protobuf.Internal$EnumLite) v4;
        _result = com.google.protobuf.Internal$EnumLite.getNumber(v4); // -> int
        v0 = _result;
        _result = v2.writeEnumNoTag(v0); // com.google.protobuf.CodedOutputStream.writeEnumNoTag -> void
        // goto L_000b
    }

    public static void writeField(com.google.protobuf.FieldSet$FieldDescriptorLite p0, java.lang.Object p1, com.google.protobuf.CodedOutputStream p2) {
        // Registers (7 total): v4 = p0 (com.google.protobuf.FieldSet$FieldDescriptorLite), v5 = p1 (java.lang.Object), v6 = p2 (com.google.protobuf.CodedOutputStream)
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getLiteType(v4); // -> com.google.protobuf.WireFormat$FieldType
        v1 = _result;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getNumber(v4); // -> int
        v0 = _result;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v4); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0056 */;
        v5 = (java.util.List) v5;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isPacked(v4); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0044 */;
        v2 = 2;
        _result = v6.writeTag(v0, v2); // com.google.protobuf.CodedOutputStream.writeTag -> void
        v0 = 0;
        _result = java.util.List.iterator(v5); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_002f */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v3 = _result;
        _result = v1.computeElementSizeNoTag(v3); // com.google.protobuf.FieldSet.computeElementSizeNoTag -> int
        v3 = _result;
        v0 = binOp2addr_0xb0(v0, v3);
        // goto L_001f
        _result = v6.writeRawVarint32(v0); // com.google.protobuf.CodedOutputStream.writeRawVarint32 -> void
        _result = java.util.List.iterator(v5); // -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0059 */;
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v2 = _result;
        _result = v6.writeElementNoTag(v1, v2); // com.google.protobuf.FieldSet.writeElementNoTag -> void
        // goto L_0036
        _result = java.util.List.iterator(v5); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0059 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v3 = _result;
        _result = v6.writeElement(v1, v0, v3); // com.google.protobuf.FieldSet.writeElement -> void
        // goto L_0048
        _result = v6.writeElement(v1, v0, v5); // com.google.protobuf.FieldSet.writeElement -> void
        return;
    }

    private void writeMessageSetTo(java.util.Map$Entry p0, com.google.protobuf.CodedOutputStream p1) {
        // Registers (6 total): v3 = this, v4 = p0 (java.util.Map$Entry), v5 = p1 (com.google.protobuf.CodedOutputStream)
        _result = java.util.Map$Entry.getKey(v4); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v0;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getLiteJavaType(v0); // -> com.google.protobuf.WireFormat$JavaType
        v1 = _result;
        v2 = com.google.protobuf.WireFormat$JavaType.MESSAGE; // :com.google.protobuf.WireFormat$JavaType
        if (v1 != v2) /* goto L_002e */;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v0); // -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_002e */;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isPacked(v0); // -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_002e */;
        _result = java.util.Map$Entry.getKey(v4); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v0;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getNumber(v0); // -> int
        v1 = _result;
        _result = java.util.Map$Entry.getValue(v4); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        _result = v5.writeMessageSetExtension(v1, v0); // com.google.protobuf.CodedOutputStream.writeMessageSetExtension -> void
        return;
        _result = java.util.Map$Entry.getValue(v4); // -> java.lang.Object
        v1 = _result;
        _result = v0.writeField(v1, v5); // com.google.protobuf.FieldSet.writeField -> void
        // goto L_002d
    }

    public void addRepeatedField(com.google.protobuf.FieldSet$FieldDescriptorLite p0, java.lang.Object p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.FieldSet$FieldDescriptorLite), v4 = p1 (java.lang.Object)
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v3); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000e */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "addRepeatedField() can only be called on repeated fields.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getLiteType(v3); // -> com.google.protobuf.WireFormat$FieldType
        v0 = _result;
        _result = v0.verifyType(v4); // com.google.protobuf.FieldSet.verifyType -> void
        v0 = v2.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.get(v3); // com.google.protobuf.SmallSortedMap.get -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_002b */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1 = v2.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v1.put(v3, v0); // com.google.protobuf.SmallSortedMap.put -> java.lang.Object
        _result = java.util.List.add(v0, v4); // -> boolean
        return;
        v0 = (java.util.List) v0;
        // goto L_0027
    }

    public void clear() {
        // Registers (2 total): v1 = this
        v0 = v1.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.clear(); // com.google.protobuf.SmallSortedMap.clear -> void
        return;
    }

    public void clearField(com.google.protobuf.FieldSet$FieldDescriptorLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.FieldSet$FieldDescriptorLite)
        v0 = v1.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.remove(v2); // com.google.protobuf.SmallSortedMap.remove -> java.lang.Object
        return;
    }

    public com.google.protobuf.FieldSet clone() {
        // Registers (5 total): v4 = this
        _result = this.newFieldSet(); // com.google.protobuf.FieldSet.newFieldSet -> com.google.protobuf.FieldSet
        v2 = _result;
        v0 = 0;
        v1 = v0;
        v0 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getNumArrayEntries(); // com.google.protobuf.SmallSortedMap.getNumArrayEntries -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0025 */;
        v0 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getArrayEntryAt(v1); // com.google.protobuf.SmallSortedMap.getArrayEntryAt -> java.util.Map$Entry
        v3 = _result;
        _result = java.util.Map$Entry.getKey(v3); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v0;
        _result = java.util.Map$Entry.getValue(v3); // -> java.lang.Object
        v3 = _result;
        _result = v2.setField(v0, v3); // com.google.protobuf.FieldSet.setField -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
        v0 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getOverflowEntries(); // com.google.protobuf.SmallSortedMap.getOverflowEntries -> java.lang.Iterable
        v0 = _result;
        _result = java.lang.Iterable.iterator(v0); // -> java.util.Iterator
        v3 = _result;
        _result = java.util.Iterator.hasNext(v3); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0049 */;
        _result = java.util.Iterator.next(v3); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = java.util.Map$Entry.getKey(v0); // -> java.lang.Object
        v1 = _result;
        v1 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v1;
        _result = java.util.Map$Entry.getValue(v0); // -> java.lang.Object
        v0 = _result;
        _result = v2.setField(v1, v0); // com.google.protobuf.FieldSet.setField -> void
        // goto L_002f
        return v2;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.clone(); // com.google.protobuf.FieldSet.clone -> com.google.protobuf.FieldSet
        v0 = _result;
        return v0;
    }

    public java.util.Map getAllFields() {
        // Registers (2 total): v1 = this
        v0 = v1.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.isImmutable(); // com.google.protobuf.SmallSortedMap.isImmutable -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000b */;
        v0 = v1.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        return v0;
        v0 = v1.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.unmodifiableMap(); // java.util.Collections.unmodifiableMap -> java.util.Map
        v0 = _result;
        // goto L_000a
    }

    public java.lang.Object getField(com.google.protobuf.FieldSet$FieldDescriptorLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.FieldSet$FieldDescriptorLite)
        v0 = v1.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.get(v2); // com.google.protobuf.SmallSortedMap.get -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public int getMessageSetSerializedSize() {
        // Registers (4 total): v3 = this
        v0 = 0;
        v1 = v0;
        v2 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v2.getNumArrayEntries(); // com.google.protobuf.SmallSortedMap.getNumArrayEntries -> int
        v2 = _result;
        if (v0 >= v2) /* goto L_0018 */;
        v2 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v2.getArrayEntryAt(v0); // com.google.protobuf.SmallSortedMap.getArrayEntryAt -> java.util.Map$Entry
        v2 = _result;
        _result = v3.getMessageSetSerializedSize(v2); // com.google.protobuf.FieldSet.getMessageSetSerializedSize -> int
        v2 = _result;
        v1 = binOp2addr_0xb0(v1, v2);
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0002
        v0 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getOverflowEntries(); // com.google.protobuf.SmallSortedMap.getOverflowEntries -> java.lang.Iterable
        v0 = _result;
        _result = java.lang.Iterable.iterator(v0); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0034 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = v3.getMessageSetSerializedSize(v0); // com.google.protobuf.FieldSet.getMessageSetSerializedSize -> int
        v0 = _result;
        v1 = binOp2addr_0xb0(v1, v0);
        // goto L_0022
        return v1;
    }

    public java.lang.Object getRepeatedField(com.google.protobuf.FieldSet$FieldDescriptorLite p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.FieldSet$FieldDescriptorLite), v4 = p1 (int)
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v3); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000e */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "getRepeatedField() can only be called on repeated fields.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v2.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.get(v3); // com.google.protobuf.SmallSortedMap.get -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_001c */;
        v0 = new java.lang.IndexOutOfBoundsException;
        _result = v0.<init>(); // java.lang.IndexOutOfBoundsException.<init> -> void
        throw v0;
        v0 = (java.util.List) v0;
        _result = java.util.List.get(v0, v4); // -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public int getRepeatedFieldCount(com.google.protobuf.FieldSet$FieldDescriptorLite p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.FieldSet$FieldDescriptorLite)
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v3); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000e */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "getRepeatedField() can only be called on repeated fields.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v2.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.get(v3); // com.google.protobuf.SmallSortedMap.get -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_0018 */;
        v0 = 0;
        return v0;
        v0 = (java.util.List) v0;
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        // goto L_0017
    }

    public int getSerializedSize() {
        // Registers (5 total): v4 = this
        v0 = 0;
        v1 = v0;
        v2 = v0;
        v0 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getNumArrayEntries(); // com.google.protobuf.SmallSortedMap.getNumArrayEntries -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0024 */;
        v0 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getArrayEntryAt(v1); // com.google.protobuf.SmallSortedMap.getArrayEntryAt -> java.util.Map$Entry
        v3 = _result;
        _result = java.util.Map$Entry.getKey(v3); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v0;
        _result = java.util.Map$Entry.getValue(v3); // -> java.lang.Object
        v3 = _result;
        _result = v0.computeFieldSize(v3); // com.google.protobuf.FieldSet.computeFieldSize -> int
        v0 = _result;
        v2 = binOp2addr_0xb0(v2, v0);
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0003
        v0 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getOverflowEntries(); // com.google.protobuf.SmallSortedMap.getOverflowEntries -> java.lang.Iterable
        v0 = _result;
        _result = java.lang.Iterable.iterator(v0); // -> java.util.Iterator
        v3 = _result;
        _result = java.util.Iterator.hasNext(v3); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_004a */;
        _result = java.util.Iterator.next(v3); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = java.util.Map$Entry.getKey(v0); // -> java.lang.Object
        v1 = _result;
        v1 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v1;
        _result = java.util.Map$Entry.getValue(v0); // -> java.lang.Object
        v0 = _result;
        _result = v1.computeFieldSize(v0); // com.google.protobuf.FieldSet.computeFieldSize -> int
        v0 = _result;
        v2 = binOp2addr_0xb0(v2, v0);
        // goto L_002e
        return v2;
    }

    public boolean hasField(com.google.protobuf.FieldSet$FieldDescriptorLite p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.FieldSet$FieldDescriptorLite)
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v3); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000e */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "hasField() can only be called on non-repeated fields.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v2.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.get(v3); // com.google.protobuf.SmallSortedMap.get -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_0018 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0017
    }

    public boolean isImmutable() {
        // Registers (2 total): v1 = this
        v0 = v1.isImmutable; // com.google.protobuf.FieldSet.isImmutable:boolean
        return v0;
    }

    public boolean isInitialized() {
        // Registers (4 total): v3 = this
        v1 = 0;
        v0 = v1;
        v2 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v2.getNumArrayEntries(); // com.google.protobuf.SmallSortedMap.getNumArrayEntries -> int
        v2 = _result;
        if (v0 >= v2) /* goto L_001a */;
        v2 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v2.getArrayEntryAt(v0); // com.google.protobuf.SmallSortedMap.getArrayEntryAt -> java.util.Map$Entry
        v2 = _result;
        _result = v3.isInitialized(v2); // com.google.protobuf.FieldSet.isInitialized -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0017 */;
        return v1;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0002
        v0 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getOverflowEntries(); // com.google.protobuf.SmallSortedMap.getOverflowEntries -> java.lang.Iterable
        v0 = _result;
        _result = java.lang.Iterable.iterator(v0); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0037 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = v3.isInitialized(v0); // com.google.protobuf.FieldSet.isInitialized -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0024 */;
        // goto L_0016
        v1 = 1;
        // goto L_0016
    }

    public java.util.Iterator iterator() {
        // Registers (2 total): v1 = this
        v0 = v1.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.entrySet(); // com.google.protobuf.SmallSortedMap.entrySet -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v0 = _result;
        return v0;
    }

    public void makeImmutable() {
        // Registers (2 total): v1 = this
        v0 = v1.isImmutable; // com.google.protobuf.FieldSet.isImmutable:boolean
        if (v0 == 0) /* goto L_0005 */;
        return;
        v0 = v1.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.makeImmutable(); // com.google.protobuf.SmallSortedMap.makeImmutable -> void
        v0 = 1;
        v1.isImmutable = v0; // com.google.protobuf.FieldSet.isImmutable:boolean
        // goto L_0004
    }

    public void mergeFrom(com.google.protobuf.FieldSet p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.FieldSet)
        v0 = 0;
        v1 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v1.getNumArrayEntries(); // com.google.protobuf.SmallSortedMap.getNumArrayEntries -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_0015 */;
        v1 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v1.getArrayEntryAt(v0); // com.google.protobuf.SmallSortedMap.getArrayEntryAt -> java.util.Map$Entry
        v1 = _result;
        _result = v2.mergeFromField(v1); // com.google.protobuf.FieldSet.mergeFromField -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0001
        v0 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getOverflowEntries(); // com.google.protobuf.SmallSortedMap.getOverflowEntries -> java.lang.Iterable
        v0 = _result;
        _result = java.lang.Iterable.iterator(v0); // -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002f */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = v2.mergeFromField(v0); // com.google.protobuf.FieldSet.mergeFromField -> void
        // goto L_001f
        return;
    }

    public void setField(com.google.protobuf.FieldSet$FieldDescriptorLite p0, java.lang.Object p1) {
        // Registers (7 total): v4 = this, v5 = p0 (com.google.protobuf.FieldSet$FieldDescriptorLite), v6 = p1 (java.lang.Object)
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v5); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0039 */;
        v0 = (v6 instanceof java.util.List);
        if (v0 != 0) /* goto L_0012 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Wrong object type used with protocol message reflection.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v6 = (java.util.List) v6;
        _result = java.util.List.addAll(v0, v6); // -> boolean
        _result = java.util.List.iterator(v0); // -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0032 */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v2 = _result;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getLiteType(v5); // -> com.google.protobuf.WireFormat$FieldType
        v3 = _result;
        _result = v3.verifyType(v2); // com.google.protobuf.FieldSet.verifyType -> void
        // goto L_0020
        v6 = v0;
        v0 = v4.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.put(v5, v6); // com.google.protobuf.SmallSortedMap.put -> java.lang.Object
        return;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getLiteType(v5); // -> com.google.protobuf.WireFormat$FieldType
        v0 = _result;
        _result = v0.verifyType(v6); // com.google.protobuf.FieldSet.verifyType -> void
        // goto L_0033
    }

    public void setRepeatedField(com.google.protobuf.FieldSet$FieldDescriptorLite p0, int p1, java.lang.Object p2) {
        // Registers (6 total): v2 = this, v3 = p0 (com.google.protobuf.FieldSet$FieldDescriptorLite), v4 = p1 (int), v5 = p2 (java.lang.Object)
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v3); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000e */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "getRepeatedField() can only be called on repeated fields.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v2.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.get(v3); // com.google.protobuf.SmallSortedMap.get -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_001c */;
        v0 = new java.lang.IndexOutOfBoundsException;
        _result = v0.<init>(); // java.lang.IndexOutOfBoundsException.<init> -> void
        throw v0;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.getLiteType(v3); // -> com.google.protobuf.WireFormat$FieldType
        v1 = _result;
        _result = v1.verifyType(v5); // com.google.protobuf.FieldSet.verifyType -> void
        v0 = (java.util.List) v0;
        _result = java.util.List.set(v0, v4, v5); // -> java.lang.Object
        return;
    }

    public void writeMessageSetTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.CodedOutputStream)
        v0 = 0;
        v1 = v2.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v1.getNumArrayEntries(); // com.google.protobuf.SmallSortedMap.getNumArrayEntries -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_0015 */;
        v1 = v2.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v1.getArrayEntryAt(v0); // com.google.protobuf.SmallSortedMap.getArrayEntryAt -> java.util.Map$Entry
        v1 = _result;
        _result = v2.writeMessageSetTo(v1, v3); // com.google.protobuf.FieldSet.writeMessageSetTo -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0001
        v0 = v2.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getOverflowEntries(); // com.google.protobuf.SmallSortedMap.getOverflowEntries -> java.lang.Iterable
        v0 = _result;
        _result = java.lang.Iterable.iterator(v0); // -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002f */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = v2.writeMessageSetTo(v0, v3); // com.google.protobuf.FieldSet.writeMessageSetTo -> void
        // goto L_001f
        return;
    }

    public void writeTo(com.google.protobuf.CodedOutputStream p0) {
        // Registers (5 total): v3 = this, v4 = p0 (com.google.protobuf.CodedOutputStream)
        v0 = 0;
        v1 = v0;
        v0 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getNumArrayEntries(); // com.google.protobuf.SmallSortedMap.getNumArrayEntries -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0021 */;
        v0 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getArrayEntryAt(v1); // com.google.protobuf.SmallSortedMap.getArrayEntryAt -> java.util.Map$Entry
        v2 = _result;
        _result = java.util.Map$Entry.getKey(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v0;
        _result = java.util.Map$Entry.getValue(v2); // -> java.lang.Object
        v2 = _result;
        _result = v0.writeField(v2, v4); // com.google.protobuf.FieldSet.writeField -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0002
        v0 = v3.fields; // com.google.protobuf.FieldSet.fields:com.google.protobuf.SmallSortedMap
        _result = v0.getOverflowEntries(); // com.google.protobuf.SmallSortedMap.getOverflowEntries -> java.lang.Iterable
        v0 = _result;
        _result = java.lang.Iterable.iterator(v0); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0045 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = java.util.Map$Entry.getKey(v0); // -> java.lang.Object
        v1 = _result;
        v1 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v1;
        _result = java.util.Map$Entry.getValue(v0); // -> java.lang.Object
        v0 = _result;
        _result = v1.writeField(v0, v4); // com.google.protobuf.FieldSet.writeField -> void
        // goto L_002b
        return;
    }

}