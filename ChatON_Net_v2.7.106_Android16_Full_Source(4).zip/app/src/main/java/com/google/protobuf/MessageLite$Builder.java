package com.google.protobuf;

/**
 * Original SourceFile: MessageLite.java
 * Descriptor: Lcom/google/protobuf/MessageLite$Builder;
 */
public interface MessageLite$Builder extends com.google.protobuf.MessageLiteOrBuilder, java.lang.Cloneable {
    public abstract com.google.protobuf.MessageLite build();
    public abstract com.google.protobuf.MessageLite buildPartial();
    public abstract com.google.protobuf.MessageLite$Builder clear();
    public abstract com.google.protobuf.MessageLite$Builder clone();
    public abstract boolean mergeDelimitedFrom(java.io.InputStream p0);
    public abstract boolean mergeDelimitedFrom(java.io.InputStream p0, com.google.protobuf.ExtensionRegistryLite p1);
    public abstract com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.ByteString p0);
    public abstract com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.ByteString p0, com.google.protobuf.ExtensionRegistryLite p1);
    public abstract com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0);
    public abstract com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1);
    public abstract com.google.protobuf.MessageLite$Builder mergeFrom(java.io.InputStream p0);
    public abstract com.google.protobuf.MessageLite$Builder mergeFrom(java.io.InputStream p0, com.google.protobuf.ExtensionRegistryLite p1);
    public abstract com.google.protobuf.MessageLite$Builder mergeFrom(byte[] p0);
    public abstract com.google.protobuf.MessageLite$Builder mergeFrom(byte[] p0, int p1, int p2);
    public abstract com.google.protobuf.MessageLite$Builder mergeFrom(byte[] p0, int p1, int p2, com.google.protobuf.ExtensionRegistryLite p3);
    public abstract com.google.protobuf.MessageLite$Builder mergeFrom(byte[] p0, com.google.protobuf.ExtensionRegistryLite p1);
}