package com.google.protobuf;

/**
 * Original SourceFile: SmallSortedMap.java
 * Descriptor: Lcom/google/protobuf/SmallSortedMap$EmptySet$2;
 */
final class SmallSortedMap$EmptySet$2 implements java.lang.Iterable {
    SmallSortedMap$EmptySet$2() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.util.Iterator iterator() {
        // Registers (2 total): v1 = this
        _result = this.access$700(); // com.google.protobuf.SmallSortedMap$EmptySet.access$700 -> java.util.Iterator
        v0 = _result;
        return v0;
    }

}