package com.google.protobuf;

/**
 * Original SourceFile: CodedOutputStream.java
 * Descriptor: Lcom/google/protobuf/CodedOutputStream;
 */
public final class CodedOutputStream {
    public static final int DEFAULT_BUFFER_SIZE;
    public static final int LITTLE_ENDIAN_32_SIZE;
    public static final int LITTLE_ENDIAN_64_SIZE;
    private final byte[] buffer;
    private final int limit;
    private final java.io.OutputStream output;
    private int position;

    private CodedOutputStream(java.io.OutputStream p0, byte[] p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.io.OutputStream), v3 = p1 (byte[])
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v1.output = v2; // com.google.protobuf.CodedOutputStream.output:java.io.OutputStream
        v1.buffer = v3; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        v0 = 0;
        v1.position = v0; // com.google.protobuf.CodedOutputStream.position:int
        v0 = v3.length;
        v1.limit = v0; // com.google.protobuf.CodedOutputStream.limit:int
        return;
    }

    private CodedOutputStream(byte[] p0, int p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (byte[]), v3 = p1 (int), v4 = p2 (int)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v1.output = v0; // com.google.protobuf.CodedOutputStream.output:java.io.OutputStream
        v1.buffer = v2; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        v1.position = v3; // com.google.protobuf.CodedOutputStream.position:int
        v0 = binOp_0x90(v3, v4);
        v1.limit = v0; // com.google.protobuf.CodedOutputStream.limit:int
        return;
    }

    public static int computeBoolSize(int p0, boolean p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (boolean)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeBoolSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeBoolSizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeBoolSizeNoTag(boolean p0) {
        // Registers (2 total): v1 = p0 (boolean)
        v0 = 1;
        return v0;
    }

    public static int computeBytesSize(int p0, com.google.protobuf.ByteString p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (com.google.protobuf.ByteString)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeBytesSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeBytesSizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeBytesSizeNoTag(com.google.protobuf.ByteString p0) {
        // Registers (3 total): v2 = p0 (com.google.protobuf.ByteString)
        _result = v2.size(); // com.google.protobuf.ByteString.size -> int
        v0 = _result;
        _result = v0.computeRawVarint32Size(); // com.google.protobuf.CodedOutputStream.computeRawVarint32Size -> int
        v0 = _result;
        _result = v2.size(); // com.google.protobuf.ByteString.size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeDoubleSize(int p0, double p1) {
        // Registers (5 total): v2 = p0 (int), v3 = p1 (double)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeDoubleSizeNoTag(v4); // com.google.protobuf.CodedOutputStream.computeDoubleSizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeDoubleSizeNoTag(double p0) {
        // Registers (3 total): v1 = p0 (double)
        v0 = 8;
        return v0;
    }

    public static int computeEnumSize(int p0, int p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (int)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeEnumSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeEnumSizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeEnumSizeNoTag(int p0) {
        // Registers (2 total): v1 = p0 (int)
        _result = v1.computeInt32SizeNoTag(); // com.google.protobuf.CodedOutputStream.computeInt32SizeNoTag -> int
        v0 = _result;
        return v0;
    }

    public static int computeFixed32Size(int p0, int p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (int)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeFixed32SizeNoTag(); // com.google.protobuf.CodedOutputStream.computeFixed32SizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeFixed32SizeNoTag(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = 4;
        return v0;
    }

    public static int computeFixed64Size(int p0, long p1) {
        // Registers (5 total): v2 = p0 (int), v3 = p1 (long)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeFixed64SizeNoTag(v4); // com.google.protobuf.CodedOutputStream.computeFixed64SizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeFixed64SizeNoTag(long p0) {
        // Registers (3 total): v1 = p0 (long)
        v0 = 8;
        return v0;
    }

    public static int computeFloatSize(int p0, float p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (float)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeFloatSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeFloatSizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeFloatSizeNoTag(float p0) {
        // Registers (2 total): v1 = p0 (float)
        v0 = 4;
        return v0;
    }

    public static int computeGroupSize(int p0, com.google.protobuf.MessageLite p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (com.google.protobuf.MessageLite)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 2);
        _result = v3.computeGroupSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeGroupSizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeGroupSizeNoTag(com.google.protobuf.MessageLite p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.MessageLite)
        _result = com.google.protobuf.MessageLite.getSerializedSize(v1); // -> int
        v0 = _result;
        return v0;
    }

    public static int computeInt32Size(int p0, int p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (int)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeInt32SizeNoTag(); // com.google.protobuf.CodedOutputStream.computeInt32SizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeInt32SizeNoTag(int p0) {
        // Registers (2 total): v1 = p0 (int)
        if (v1 < 0) /* goto L_0007 */;
        _result = v1.computeRawVarint32Size(); // com.google.protobuf.CodedOutputStream.computeRawVarint32Size -> int
        v0 = _result;
        return v0;
        v0 = 10;
        // goto L_0006
    }

    public static int computeInt64Size(int p0, long p1) {
        // Registers (5 total): v2 = p0 (int), v3 = p1 (long)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeInt64SizeNoTag(v4); // com.google.protobuf.CodedOutputStream.computeInt64SizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeInt64SizeNoTag(long p0) {
        // Registers (3 total): v1 = p0 (long)
        _result = v1.computeRawVarint64Size(v2); // com.google.protobuf.CodedOutputStream.computeRawVarint64Size -> int
        v0 = _result;
        return v0;
    }

    public static int computeMessageSetExtensionSize(int p0, com.google.protobuf.MessageLite p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (com.google.protobuf.MessageLite)
        v0 = 1;
        _result = v0.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 2);
        v1 = 2;
        _result = v1.computeUInt32Size(v2); // com.google.protobuf.CodedOutputStream.computeUInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = 3;
        _result = v1.computeMessageSize(v3); // com.google.protobuf.CodedOutputStream.computeMessageSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeMessageSize(int p0, com.google.protobuf.MessageLite p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (com.google.protobuf.MessageLite)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeMessageSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeMessageSizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeMessageSizeNoTag(com.google.protobuf.MessageLite p0) {
        // Registers (3 total): v2 = p0 (com.google.protobuf.MessageLite)
        _result = com.google.protobuf.MessageLite.getSerializedSize(v2); // -> int
        v0 = _result;
        _result = v0.computeRawVarint32Size(); // com.google.protobuf.CodedOutputStream.computeRawVarint32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    static int computePreferredBufferSize(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = 4096;
        if (v1 <= v0) /* goto L_0005 */;
        v1 = v0;
        return v1;
    }

    public static int computeRawMessageSetExtensionSize(int p0, com.google.protobuf.ByteString p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (com.google.protobuf.ByteString)
        v0 = 1;
        _result = v0.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 2);
        v1 = 2;
        _result = v1.computeUInt32Size(v2); // com.google.protobuf.CodedOutputStream.computeUInt32Size -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = 3;
        _result = v1.computeBytesSize(v3); // com.google.protobuf.CodedOutputStream.computeBytesSize -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeRawVarint32Size(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = binOpLit8_0xdd(v1, -128);
        if (v0 != 0) /* goto L_0006 */;
        v0 = 1;
        return v0;
        v0 = binOpLit16_0xd5(v1, -16384);
        if (v0 != 0) /* goto L_000c */;
        v0 = 2;
        // goto L_0005
        v0 = 0xffe00000;
        v0 = binOp2addr_0xb5(v0, v1);
        if (v0 != 0) /* goto L_0013 */;
        v0 = 3;
        // goto L_0005
        v0 = 0xf0000000;
        v0 = binOp2addr_0xb5(v0, v1);
        if (v0 != 0) /* goto L_001a */;
        v0 = 4;
        // goto L_0005
        v0 = 5;
        // goto L_0005
    }

    public static int computeRawVarint64Size(long p0) {
        // Registers (6 total): v4 = p0 (long)
        v2 = 0L;
        v0 = -128L;
        v0 = binOp2addr_0xc0(v0, v4);
        v0 = cmp(v0, v2);
        if (v0 != 0) /* goto L_000b */;
        v0 = 1;
        return v0;
        v0 = -16384L;
        v0 = binOp2addr_0xc0(v0, v4);
        v0 = cmp(v0, v2);
        if (v0 != 0) /* goto L_0014 */;
        v0 = 2;
        // goto L_000a
        v0 = -2097152L;
        v0 = binOp2addr_0xc0(v0, v4);
        v0 = cmp(v0, v2);
        if (v0 != 0) /* goto L_001e */;
        v0 = 3;
        // goto L_000a
        v0 = -268435456L;
        v0 = binOp2addr_0xc0(v0, v4);
        v0 = cmp(v0, v2);
        if (v0 != 0) /* goto L_0028 */;
        v0 = 4;
        // goto L_000a
        v0 = 0xfffffff800000000L;
        v0 = binOp2addr_0xc0(v0, v4);
        v0 = cmp(v0, v2);
        if (v0 != 0) /* goto L_0034 */;
        v0 = 5;
        // goto L_000a
        v0 = 0xfffffc0000000000L;
        v0 = binOp2addr_0xc0(v0, v4);
        v0 = cmp(v0, v2);
        if (v0 != 0) /* goto L_0040 */;
        v0 = 6;
        // goto L_000a
        v0 = 0xfffe000000000000L;
        v0 = binOp2addr_0xc0(v0, v4);
        v0 = cmp(v0, v2);
        if (v0 != 0) /* goto L_0049 */;
        v0 = 7;
        // goto L_000a
        v0 = 0xff00000000000000L;
        v0 = binOp2addr_0xc0(v0, v4);
        v0 = cmp(v0, v2);
        if (v0 != 0) /* goto L_0053 */;
        v0 = 8;
        // goto L_000a
        v0 = 0x8000000000000000L;
        v0 = binOp2addr_0xc0(v0, v4);
        v0 = cmp(v0, v2);
        if (v0 != 0) /* goto L_005d */;
        v0 = 9;
        // goto L_000a
        v0 = 10;
        // goto L_000a
    }

    public static int computeSFixed32Size(int p0, int p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (int)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeSFixed32SizeNoTag(); // com.google.protobuf.CodedOutputStream.computeSFixed32SizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeSFixed32SizeNoTag(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = 4;
        return v0;
    }

    public static int computeSFixed64Size(int p0, long p1) {
        // Registers (5 total): v2 = p0 (int), v3 = p1 (long)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeSFixed64SizeNoTag(v4); // com.google.protobuf.CodedOutputStream.computeSFixed64SizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeSFixed64SizeNoTag(long p0) {
        // Registers (3 total): v1 = p0 (long)
        v0 = 8;
        return v0;
    }

    public static int computeSInt32Size(int p0, int p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (int)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeSInt32SizeNoTag(); // com.google.protobuf.CodedOutputStream.computeSInt32SizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeSInt32SizeNoTag(int p0) {
        // Registers (2 total): v1 = p0 (int)
        _result = v1.encodeZigZag32(); // com.google.protobuf.CodedOutputStream.encodeZigZag32 -> int
        v0 = _result;
        _result = v0.computeRawVarint32Size(); // com.google.protobuf.CodedOutputStream.computeRawVarint32Size -> int
        v0 = _result;
        return v0;
    }

    public static int computeSInt64Size(int p0, long p1) {
        // Registers (5 total): v2 = p0 (int), v3 = p1 (long)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeSInt64SizeNoTag(v4); // com.google.protobuf.CodedOutputStream.computeSInt64SizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeSInt64SizeNoTag(long p0) {
        // Registers (4 total): v2 = p0 (long)
        _result = v2.encodeZigZag64(v3); // com.google.protobuf.CodedOutputStream.encodeZigZag64 -> long
        v0 = _result;
        _result = v0.computeRawVarint64Size(v1); // com.google.protobuf.CodedOutputStream.computeRawVarint64Size -> int
        v0 = _result;
        return v0;
    }

    public static int computeStringSize(int p0, java.lang.String p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (java.lang.String)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeStringSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeStringSizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeStringSizeNoTag(java.lang.String p0) {
        // Registers (4 total): v3 = p0 (java.lang.String)
        v0 = "UTF-8";
        _result = v3.getBytes(v0); // java.lang.String.getBytes -> byte[]
        v0 = _result;
        v1 = v0.length;
        _result = v1.computeRawVarint32Size(); // com.google.protobuf.CodedOutputStream.computeRawVarint32Size -> int
        v1 = _result;
        v0 = v0.length;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "UTF-8 not supported.";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
    }

    public static int computeTagSize(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = 0;
        _result = v1.makeTag(v0); // com.google.protobuf.WireFormat.makeTag -> int
        v0 = _result;
        _result = v0.computeRawVarint32Size(); // com.google.protobuf.CodedOutputStream.computeRawVarint32Size -> int
        v0 = _result;
        return v0;
    }

    public static int computeUInt32Size(int p0, int p1) {
        // Registers (4 total): v2 = p0 (int), v3 = p1 (int)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeUInt32SizeNoTag(); // com.google.protobuf.CodedOutputStream.computeUInt32SizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeUInt32SizeNoTag(int p0) {
        // Registers (2 total): v1 = p0 (int)
        _result = v1.computeRawVarint32Size(); // com.google.protobuf.CodedOutputStream.computeRawVarint32Size -> int
        v0 = _result;
        return v0;
    }

    public static int computeUInt64Size(int p0, long p1) {
        // Registers (5 total): v2 = p0 (int), v3 = p1 (long)
        _result = v2.computeTagSize(); // com.google.protobuf.CodedOutputStream.computeTagSize -> int
        v0 = _result;
        _result = v3.computeUInt64SizeNoTag(v4); // com.google.protobuf.CodedOutputStream.computeUInt64SizeNoTag -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public static int computeUInt64SizeNoTag(long p0) {
        // Registers (3 total): v1 = p0 (long)
        _result = v1.computeRawVarint64Size(v2); // com.google.protobuf.CodedOutputStream.computeRawVarint64Size -> int
        v0 = _result;
        return v0;
    }

    public static int computeUnknownGroupSize(int p0, com.google.protobuf.MessageLite p1) {
        // Registers (3 total): v1 = p0 (int), v2 = p1 (com.google.protobuf.MessageLite)
        _result = v1.computeGroupSize(v2); // com.google.protobuf.CodedOutputStream.computeGroupSize -> int
        v0 = _result;
        return v0;
    }

    public static int computeUnknownGroupSizeNoTag(com.google.protobuf.MessageLite p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.MessageLite)
        _result = v1.computeGroupSizeNoTag(); // com.google.protobuf.CodedOutputStream.computeGroupSizeNoTag -> int
        v0 = _result;
        return v0;
    }

    public static int encodeZigZag32(int p0) {
        // Registers (3 total): v2 = p0 (int)
        v0 = binOpLit8_0xe0(v2, 1);
        v1 = binOpLit8_0xe1(v2, 31);
        v0 = binOp2addr_0xb7(v0, v1);
        return v0;
    }

    public static long encodeZigZag64(long p0) {
        // Registers (6 total): v4 = p0 (long)
        v0 = 1;
        v0 = binOp_0xa3(v4, v0);
        v2 = 63;
        v2 = binOp_0xa4(v4, v2);
        v0 = binOp2addr_0xc2(v0, v2);
        return v0;
    }

    public static com.google.protobuf.CodedOutputStream newInstance(java.io.OutputStream p0) {
        // Registers (2 total): v1 = p0 (java.io.OutputStream)
        v0 = 4096;
        _result = v1.newInstance(v0); // com.google.protobuf.CodedOutputStream.newInstance -> com.google.protobuf.CodedOutputStream
        v0 = _result;
        return v0;
    }

    public static com.google.protobuf.CodedOutputStream newInstance(java.io.OutputStream p0, int p1) {
        // Registers (4 total): v2 = p0 (java.io.OutputStream), v3 = p1 (int)
        v0 = new com.google.protobuf.CodedOutputStream;
        v1 = new byte[][size=v3];
        _result = v0.<init>(v2, v1); // com.google.protobuf.CodedOutputStream.<init> -> void
        return v0;
    }

    public static com.google.protobuf.CodedOutputStream newInstance(byte[] p0) {
        // Registers (3 total): v2 = p0 (byte[])
        v0 = 0;
        v1 = v2.length;
        _result = v2.newInstance(v0, v1); // com.google.protobuf.CodedOutputStream.newInstance -> com.google.protobuf.CodedOutputStream
        v0 = _result;
        return v0;
    }

    public static com.google.protobuf.CodedOutputStream newInstance(byte[] p0, int p1, int p2) {
        // Registers (4 total): v1 = p0 (byte[]), v2 = p1 (int), v3 = p2 (int)
        v0 = new com.google.protobuf.CodedOutputStream;
        _result = v0.<init>(v1, v2, v3); // com.google.protobuf.CodedOutputStream.<init> -> void
        return v0;
    }

    private void refreshBuffer() {
        // Registers (5 total): v4 = this
        v3 = 0;
        v0 = v4.output; // com.google.protobuf.CodedOutputStream.output:java.io.OutputStream
        if (v0 != 0) /* goto L_000b */;
        v0 = new com.google.protobuf.CodedOutputStream$OutOfSpaceException;
        _result = v0.<init>(); // com.google.protobuf.CodedOutputStream$OutOfSpaceException.<init> -> void
        throw v0;
        v0 = v4.output; // com.google.protobuf.CodedOutputStream.output:java.io.OutputStream
        v1 = v4.buffer; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        v2 = v4.position; // com.google.protobuf.CodedOutputStream.position:int
        _result = v0.write(v1, v3, v2); // java.io.OutputStream.write -> void
        v4.position = v3; // com.google.protobuf.CodedOutputStream.position:int
        return;
    }

    public void checkNoSpaceLeft() {
        // Registers (3 total): v2 = this
        _result = v2.spaceLeft(); // com.google.protobuf.CodedOutputStream.spaceLeft -> int
        v0 = _result;
        if (v0 == 0) /* goto L_000e */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Did not write as much data as expected.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        return;
    }

    public void flush() {
        // Registers (2 total): v1 = this
        v0 = v1.output; // com.google.protobuf.CodedOutputStream.output:java.io.OutputStream
        if (v0 == 0) /* goto L_0007 */;
        _result = v1.refreshBuffer(); // com.google.protobuf.CodedOutputStream.refreshBuffer -> void
        return;
    }

    public int spaceLeft() {
        // Registers (3 total): v2 = this
        v0 = v2.output; // com.google.protobuf.CodedOutputStream.output:java.io.OutputStream
        if (v0 != 0) /* goto L_000a */;
        v0 = v2.limit; // com.google.protobuf.CodedOutputStream.limit:int
        v1 = v2.position; // com.google.protobuf.CodedOutputStream.position:int
        v0 = binOp2addr_0xb1(v0, v1);
        return v0;
        v0 = new java.lang.UnsupportedOperationException;
        v1 = "spaceLeft() can only be called on CodedOutputStreams that are writing to a flat array.";
        _result = v0.<init>(v1); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public void writeBool(int p0, boolean p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (boolean)
        v0 = 0;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeBoolNoTag(v3); // com.google.protobuf.CodedOutputStream.writeBoolNoTag -> void
        return;
    }

    public void writeBoolNoTag(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        if (v2 == 0) /* goto L_0007 */;
        v0 = 1;
        _result = v1.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        return;
        v0 = 0;
        // goto L_0003
    }

    public void writeBytes(int p0, com.google.protobuf.ByteString p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (com.google.protobuf.ByteString)
        v0 = 2;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeBytesNoTag(v3); // com.google.protobuf.CodedOutputStream.writeBytesNoTag -> void
        return;
    }

    public void writeBytesNoTag(com.google.protobuf.ByteString p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.ByteString)
        _result = v2.size(); // com.google.protobuf.ByteString.size -> int
        v0 = _result;
        _result = v1.writeRawVarint32(v0); // com.google.protobuf.CodedOutputStream.writeRawVarint32 -> void
        _result = v1.writeRawBytes(v2); // com.google.protobuf.CodedOutputStream.writeRawBytes -> void
        return;
    }

    public void writeDouble(int p0, double p1) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (double)
        v0 = 1;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeDoubleNoTag(v3, v4); // com.google.protobuf.CodedOutputStream.writeDoubleNoTag -> void
        return;
    }

    public void writeDoubleNoTag(double p0) {
        // Registers (5 total): v2 = this, v3 = p0 (double)
        _result = v3.doubleToRawLongBits(v4); // java.lang.Double.doubleToRawLongBits -> long
        v0 = _result;
        _result = v2.writeRawLittleEndian64(v0, v1); // com.google.protobuf.CodedOutputStream.writeRawLittleEndian64 -> void
        return;
    }

    public void writeEnum(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = 0;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeEnumNoTag(v3); // com.google.protobuf.CodedOutputStream.writeEnumNoTag -> void
        return;
    }

    public void writeEnumNoTag(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        _result = v0.writeInt32NoTag(v1); // com.google.protobuf.CodedOutputStream.writeInt32NoTag -> void
        return;
    }

    public void writeFixed32(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = 5;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeFixed32NoTag(v3); // com.google.protobuf.CodedOutputStream.writeFixed32NoTag -> void
        return;
    }

    public void writeFixed32NoTag(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        _result = v0.writeRawLittleEndian32(v1); // com.google.protobuf.CodedOutputStream.writeRawLittleEndian32 -> void
        return;
    }

    public void writeFixed64(int p0, long p1) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (long)
        v0 = 1;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeFixed64NoTag(v3, v4); // com.google.protobuf.CodedOutputStream.writeFixed64NoTag -> void
        return;
    }

    public void writeFixed64NoTag(long p0) {
        // Registers (3 total): v0 = this, v1 = p0 (long)
        _result = v0.writeRawLittleEndian64(v1, v2); // com.google.protobuf.CodedOutputStream.writeRawLittleEndian64 -> void
        return;
    }

    public void writeFloat(int p0, float p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (float)
        v0 = 5;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeFloatNoTag(v3); // com.google.protobuf.CodedOutputStream.writeFloatNoTag -> void
        return;
    }

    public void writeFloatNoTag(float p0) {
        // Registers (3 total): v1 = this, v2 = p0 (float)
        _result = v2.floatToRawIntBits(); // java.lang.Float.floatToRawIntBits -> int
        v0 = _result;
        _result = v1.writeRawLittleEndian32(v0); // com.google.protobuf.CodedOutputStream.writeRawLittleEndian32 -> void
        return;
    }

    public void writeGroup(int p0, com.google.protobuf.MessageLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (com.google.protobuf.MessageLite)
        v0 = 3;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeGroupNoTag(v3); // com.google.protobuf.CodedOutputStream.writeGroupNoTag -> void
        v0 = 4;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        return;
    }

    public void writeGroupNoTag(com.google.protobuf.MessageLite p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.google.protobuf.MessageLite)
        _result = com.google.protobuf.MessageLite.writeTo(v1, v0); // -> void
        return;
    }

    public void writeInt32(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = 0;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeInt32NoTag(v3); // com.google.protobuf.CodedOutputStream.writeInt32NoTag -> void
        return;
    }

    public void writeInt32NoTag(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        if (v3 < 0) /* goto L_0006 */;
        _result = v2.writeRawVarint32(v3); // com.google.protobuf.CodedOutputStream.writeRawVarint32 -> void
        return;
        v0 = unaryOp_0x81(v3);
        _result = v2.writeRawVarint64(v0, v1); // com.google.protobuf.CodedOutputStream.writeRawVarint64 -> void
        // goto L_0005
    }

    public void writeInt64(int p0, long p1) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (long)
        v0 = 0;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeInt64NoTag(v3, v4); // com.google.protobuf.CodedOutputStream.writeInt64NoTag -> void
        return;
    }

    public void writeInt64NoTag(long p0) {
        // Registers (3 total): v0 = this, v1 = p0 (long)
        _result = v0.writeRawVarint64(v1, v2); // com.google.protobuf.CodedOutputStream.writeRawVarint64 -> void
        return;
    }

    public void writeMessage(int p0, com.google.protobuf.MessageLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (com.google.protobuf.MessageLite)
        v0 = 2;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeMessageNoTag(v3); // com.google.protobuf.CodedOutputStream.writeMessageNoTag -> void
        return;
    }

    public void writeMessageNoTag(com.google.protobuf.MessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.MessageLite)
        _result = com.google.protobuf.MessageLite.getSerializedSize(v2); // -> int
        v0 = _result;
        _result = v1.writeRawVarint32(v0); // com.google.protobuf.CodedOutputStream.writeRawVarint32 -> void
        _result = com.google.protobuf.MessageLite.writeTo(v2, v1); // -> void
        return;
    }

    public void writeMessageSetExtension(int p0, com.google.protobuf.MessageLite p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (com.google.protobuf.MessageLite)
        v2 = 3;
        v1 = 1;
        _result = v3.writeTag(v1, v2); // com.google.protobuf.CodedOutputStream.writeTag -> void
        v0 = 2;
        _result = v3.writeUInt32(v0, v4); // com.google.protobuf.CodedOutputStream.writeUInt32 -> void
        _result = v3.writeMessage(v2, v5); // com.google.protobuf.CodedOutputStream.writeMessage -> void
        v0 = 4;
        _result = v3.writeTag(v1, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        return;
    }

    public void writeRawByte(byte p0) {
        // Registers (5 total): v3 = this, v4 = p0 (byte)
        v0 = v3.position; // com.google.protobuf.CodedOutputStream.position:int
        v1 = v3.limit; // com.google.protobuf.CodedOutputStream.limit:int
        if (v0 != v1) /* goto L_0009 */;
        _result = v3.refreshBuffer(); // com.google.protobuf.CodedOutputStream.refreshBuffer -> void
        v0 = v3.buffer; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        v1 = v3.position; // com.google.protobuf.CodedOutputStream.position:int
        v2 = binOpLit8_0xd8(v1, 1);
        v3.position = v2; // com.google.protobuf.CodedOutputStream.position:int
        v0[v1] = v4;
        return;
    }

    public void writeRawByte(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = unaryOp_0x8d(v2);
        _result = v1.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        return;
    }

    public void writeRawBytes(com.google.protobuf.ByteString p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.ByteString)
        v0 = 0;
        _result = v3.size(); // com.google.protobuf.ByteString.size -> int
        v1 = _result;
        _result = v2.writeRawBytes(v3, v0, v1); // com.google.protobuf.CodedOutputStream.writeRawBytes -> void
        return;
    }

    public void writeRawBytes(com.google.protobuf.ByteString p0, int p1, int p2) {
        // Registers (12 total): v8 = this, v9 = p0 (com.google.protobuf.ByteString), v10 = p1 (int), v11 = p2 (int)
        v7 = 0;
        v0 = v8.limit; // com.google.protobuf.CodedOutputStream.limit:int
        v1 = v8.position; // com.google.protobuf.CodedOutputStream.position:int
        v0 = binOp2addr_0xb1(v0, v1);
        if (v0 < v11) /* goto L_0015 */;
        v0 = v8.buffer; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        v1 = v8.position; // com.google.protobuf.CodedOutputStream.position:int
        _result = v9.copyTo(v0, v10, v1, v11); // com.google.protobuf.ByteString.copyTo -> void
        v0 = v8.position; // com.google.protobuf.CodedOutputStream.position:int
        v0 = binOp2addr_0xb0(v0, v11);
        v8.position = v0; // com.google.protobuf.CodedOutputStream.position:int
        return;
        v0 = v8.limit; // com.google.protobuf.CodedOutputStream.limit:int
        v1 = v8.position; // com.google.protobuf.CodedOutputStream.position:int
        v0 = binOp2addr_0xb1(v0, v1);
        v1 = v8.buffer; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        v2 = v8.position; // com.google.protobuf.CodedOutputStream.position:int
        _result = v9.copyTo(v1, v10, v2, v0); // com.google.protobuf.ByteString.copyTo -> void
        v1 = binOp_0x90(v10, v0);
        v0 = binOp_0x91(v11, v0);
        v2 = v8.limit; // com.google.protobuf.CodedOutputStream.limit:int
        v8.position = v2; // com.google.protobuf.CodedOutputStream.position:int
        _result = v8.refreshBuffer(); // com.google.protobuf.CodedOutputStream.refreshBuffer -> void
        v2 = v8.limit; // com.google.protobuf.CodedOutputStream.limit:int
        if (v0 > v2) /* goto L_0038 */;
        v2 = v8.buffer; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        _result = v9.copyTo(v2, v1, v7, v0); // com.google.protobuf.ByteString.copyTo -> void
        v8.position = v0; // com.google.protobuf.CodedOutputStream.position:int
        // goto L_0014
        _result = v9.newInput(); // com.google.protobuf.ByteString.newInput -> java.io.InputStream
        v2 = _result;
        v3 = unaryOp_0x81(v1);
        v5 = unaryOp_0x81(v1);
        _result = v2.skip(v5, v6); // java.io.InputStream.skip -> long
        v5 = _result;
        v1 = cmp(v3, v5);
        if (v1 == 0) /* goto L_0056 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Skip failed? Should never happen.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v1 = v8.output; // com.google.protobuf.CodedOutputStream.output:java.io.OutputStream
        v4 = v8.buffer; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        _result = v1.write(v4, v7, v3); // java.io.OutputStream.write -> void
        v0 = binOp2addr_0xb1(v0, v3);
        if (v0 <= 0) /* goto L_0014 */;
        v1 = v8.limit; // com.google.protobuf.CodedOutputStream.limit:int
        _result = v0.min(v1); // java.lang.Math.min -> int
        v1 = _result;
        v3 = v8.buffer; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        _result = v2.read(v3, v7, v1); // java.io.InputStream.read -> int
        v3 = _result;
        if (v3 == v1) /* goto L_004e */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Read failed? Should never happen";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
    }

    public void writeRawBytes(byte[] p0) {
        // Registers (4 total): v2 = this, v3 = p0 (byte[])
        v0 = 0;
        v1 = v3.length;
        _result = v2.writeRawBytes(v3, v0, v1); // com.google.protobuf.CodedOutputStream.writeRawBytes -> void
        return;
    }

    public void writeRawBytes(byte[] p0, int p1, int p2) {
        // Registers (8 total): v4 = this, v5 = p0 (byte[]), v6 = p1 (int), v7 = p2 (int)
        v0 = v4.limit; // com.google.protobuf.CodedOutputStream.limit:int
        v1 = v4.position; // com.google.protobuf.CodedOutputStream.position:int
        v0 = binOp2addr_0xb1(v0, v1);
        if (v0 < v7) /* goto L_0014 */;
        v0 = v4.buffer; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        v1 = v4.position; // com.google.protobuf.CodedOutputStream.position:int
        _result = v5.arraycopy(v6, v0, v1, v7); // java.lang.System.arraycopy -> void
        v0 = v4.position; // com.google.protobuf.CodedOutputStream.position:int
        v0 = binOp2addr_0xb0(v0, v7);
        v4.position = v0; // com.google.protobuf.CodedOutputStream.position:int
        return;
        v0 = v4.limit; // com.google.protobuf.CodedOutputStream.limit:int
        v1 = v4.position; // com.google.protobuf.CodedOutputStream.position:int
        v0 = binOp2addr_0xb1(v0, v1);
        v1 = v4.buffer; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        v2 = v4.position; // com.google.protobuf.CodedOutputStream.position:int
        _result = v5.arraycopy(v6, v1, v2, v0); // java.lang.System.arraycopy -> void
        v1 = binOp_0x90(v6, v0);
        v0 = binOp_0x91(v7, v0);
        v2 = v4.limit; // com.google.protobuf.CodedOutputStream.limit:int
        v4.position = v2; // com.google.protobuf.CodedOutputStream.position:int
        _result = v4.refreshBuffer(); // com.google.protobuf.CodedOutputStream.refreshBuffer -> void
        v2 = v4.limit; // com.google.protobuf.CodedOutputStream.limit:int
        if (v0 > v2) /* goto L_0038 */;
        v2 = v4.buffer; // com.google.protobuf.CodedOutputStream.buffer:byte[]
        v3 = 0;
        _result = v5.arraycopy(v1, v2, v3, v0); // java.lang.System.arraycopy -> void
        v4.position = v0; // com.google.protobuf.CodedOutputStream.position:int
        // goto L_0013
        v2 = v4.output; // com.google.protobuf.CodedOutputStream.output:java.io.OutputStream
        _result = v2.write(v5, v1, v0); // java.io.OutputStream.write -> void
        // goto L_0013
    }

    public void writeRawLittleEndian32(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = binOpLit16_0xd5(v2, 255);
        _result = v1.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v0 = binOpLit8_0xe1(v2, 8);
        v0 = binOpLit16_0xd5(v0, 255);
        _result = v1.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v0 = binOpLit8_0xe1(v2, 16);
        v0 = binOpLit16_0xd5(v0, 255);
        _result = v1.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v0 = binOpLit8_0xe1(v2, 24);
        v0 = binOpLit16_0xd5(v0, 255);
        _result = v1.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        return;
    }

    public void writeRawLittleEndian64(long p0) {
        // Registers (5 total): v2 = this, v3 = p0 (long)
        v0 = unaryOp_0x84(v3);
        v0 = binOpLit16_0xd5(v0, 255);
        _result = v2.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v0 = 8;
        v0 = binOp_0xa4(v3, v0);
        v0 = unaryOp_0x84(v0);
        v0 = binOpLit16_0xd5(v0, 255);
        _result = v2.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v0 = 16;
        v0 = binOp_0xa4(v3, v0);
        v0 = unaryOp_0x84(v0);
        v0 = binOpLit16_0xd5(v0, 255);
        _result = v2.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v0 = 24;
        v0 = binOp_0xa4(v3, v0);
        v0 = unaryOp_0x84(v0);
        v0 = binOpLit16_0xd5(v0, 255);
        _result = v2.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v0 = 32;
        v0 = binOp_0xa4(v3, v0);
        v0 = unaryOp_0x84(v0);
        v0 = binOpLit16_0xd5(v0, 255);
        _result = v2.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v0 = 40;
        v0 = binOp_0xa4(v3, v0);
        v0 = unaryOp_0x84(v0);
        v0 = binOpLit16_0xd5(v0, 255);
        _result = v2.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v0 = 48;
        v0 = binOp_0xa4(v3, v0);
        v0 = unaryOp_0x84(v0);
        v0 = binOpLit16_0xd5(v0, 255);
        _result = v2.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v0 = 56;
        v0 = binOp_0xa4(v3, v0);
        v0 = unaryOp_0x84(v0);
        v0 = binOpLit16_0xd5(v0, 255);
        _result = v2.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        return;
    }

    public void writeRawMessageSetExtension(int p0, com.google.protobuf.ByteString p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (com.google.protobuf.ByteString)
        v2 = 3;
        v1 = 1;
        _result = v3.writeTag(v1, v2); // com.google.protobuf.CodedOutputStream.writeTag -> void
        v0 = 2;
        _result = v3.writeUInt32(v0, v4); // com.google.protobuf.CodedOutputStream.writeUInt32 -> void
        _result = v3.writeBytes(v2, v5); // com.google.protobuf.CodedOutputStream.writeBytes -> void
        v0 = 4;
        _result = v3.writeTag(v1, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        return;
    }

    public void writeRawVarint32(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = binOpLit8_0xdd(v2, -128);
        if (v0 != 0) /* goto L_0008 */;
        _result = v1.writeRawByte(v2); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        return;
        v0 = binOpLit8_0xdd(v2, 127);
        v0 = binOpLit16_0xd6(v0, 128);
        _result = v1.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v2 = binOpLit8_0xe2(v2, 7);
        // goto L_0000
    }

    public void writeRawVarint64(long p0) {
        // Registers (7 total): v4 = this, v5 = p0 (long)
        v0 = -128L;
        v0 = binOp2addr_0xc0(v0, v5);
        v2 = 0L;
        v0 = cmp(v0, v2);
        if (v0 != 0) /* goto L_000e */;
        v0 = unaryOp_0x84(v5);
        _result = v4.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        return;
        v0 = unaryOp_0x84(v5);
        v0 = binOpLit8_0xdd(v0, 127);
        v0 = binOpLit16_0xd6(v0, 128);
        _result = v4.writeRawByte(v0); // com.google.protobuf.CodedOutputStream.writeRawByte -> void
        v0 = 7;
        v5 = binOp2addr_0xc5(v5, v0);
        // goto L_0000
    }

    public void writeSFixed32(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = 5;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeSFixed32NoTag(v3); // com.google.protobuf.CodedOutputStream.writeSFixed32NoTag -> void
        return;
    }

    public void writeSFixed32NoTag(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        _result = v0.writeRawLittleEndian32(v1); // com.google.protobuf.CodedOutputStream.writeRawLittleEndian32 -> void
        return;
    }

    public void writeSFixed64(int p0, long p1) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (long)
        v0 = 1;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeSFixed64NoTag(v3, v4); // com.google.protobuf.CodedOutputStream.writeSFixed64NoTag -> void
        return;
    }

    public void writeSFixed64NoTag(long p0) {
        // Registers (3 total): v0 = this, v1 = p0 (long)
        _result = v0.writeRawLittleEndian64(v1, v2); // com.google.protobuf.CodedOutputStream.writeRawLittleEndian64 -> void
        return;
    }

    public void writeSInt32(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = 0;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeSInt32NoTag(v3); // com.google.protobuf.CodedOutputStream.writeSInt32NoTag -> void
        return;
    }

    public void writeSInt32NoTag(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v2.encodeZigZag32(); // com.google.protobuf.CodedOutputStream.encodeZigZag32 -> int
        v0 = _result;
        _result = v1.writeRawVarint32(v0); // com.google.protobuf.CodedOutputStream.writeRawVarint32 -> void
        return;
    }

    public void writeSInt64(int p0, long p1) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (long)
        v0 = 0;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeSInt64NoTag(v3, v4); // com.google.protobuf.CodedOutputStream.writeSInt64NoTag -> void
        return;
    }

    public void writeSInt64NoTag(long p0) {
        // Registers (5 total): v2 = this, v3 = p0 (long)
        _result = v3.encodeZigZag64(v4); // com.google.protobuf.CodedOutputStream.encodeZigZag64 -> long
        v0 = _result;
        _result = v2.writeRawVarint64(v0, v1); // com.google.protobuf.CodedOutputStream.writeRawVarint64 -> void
        return;
    }

    public void writeString(int p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (java.lang.String)
        v0 = 2;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeStringNoTag(v3); // com.google.protobuf.CodedOutputStream.writeStringNoTag -> void
        return;
    }

    public void writeStringNoTag(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = "UTF-8";
        _result = v3.getBytes(v0); // java.lang.String.getBytes -> byte[]
        v0 = _result;
        v1 = v0.length;
        _result = v2.writeRawVarint32(v1); // com.google.protobuf.CodedOutputStream.writeRawVarint32 -> void
        _result = v2.writeRawBytes(v0); // com.google.protobuf.CodedOutputStream.writeRawBytes -> void
        return;
    }

    public void writeTag(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        _result = v2.makeTag(v3); // com.google.protobuf.WireFormat.makeTag -> int
        v0 = _result;
        _result = v1.writeRawVarint32(v0); // com.google.protobuf.CodedOutputStream.writeRawVarint32 -> void
        return;
    }

    public void writeUInt32(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = 0;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeUInt32NoTag(v3); // com.google.protobuf.CodedOutputStream.writeUInt32NoTag -> void
        return;
    }

    public void writeUInt32NoTag(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        _result = v0.writeRawVarint32(v1); // com.google.protobuf.CodedOutputStream.writeRawVarint32 -> void
        return;
    }

    public void writeUInt64(int p0, long p1) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (long)
        v0 = 0;
        _result = v1.writeTag(v2, v0); // com.google.protobuf.CodedOutputStream.writeTag -> void
        _result = v1.writeUInt64NoTag(v3, v4); // com.google.protobuf.CodedOutputStream.writeUInt64NoTag -> void
        return;
    }

    public void writeUInt64NoTag(long p0) {
        // Registers (3 total): v0 = this, v1 = p0 (long)
        _result = v0.writeRawVarint64(v1, v2); // com.google.protobuf.CodedOutputStream.writeRawVarint64 -> void
        return;
    }

    public void writeUnknownGroup(int p0, com.google.protobuf.MessageLite p1) {
        // Registers (3 total): v0 = this, v1 = p0 (int), v2 = p1 (com.google.protobuf.MessageLite)
        _result = v0.writeGroup(v1, v2); // com.google.protobuf.CodedOutputStream.writeGroup -> void
        return;
    }

    public void writeUnknownGroupNoTag(com.google.protobuf.MessageLite p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.google.protobuf.MessageLite)
        _result = v0.writeGroupNoTag(v1); // com.google.protobuf.CodedOutputStream.writeGroupNoTag -> void
        return;
    }

}