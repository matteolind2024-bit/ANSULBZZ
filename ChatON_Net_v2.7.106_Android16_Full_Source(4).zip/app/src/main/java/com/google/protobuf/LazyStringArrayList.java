package com.google.protobuf;

/**
 * Original SourceFile: LazyStringArrayList.java
 * Descriptor: Lcom/google/protobuf/LazyStringArrayList;
 */
public class LazyStringArrayList extends java.util.AbstractList implements com.google.protobuf.LazyStringList, java.util.RandomAccess {
    public static final com.google.protobuf.LazyStringList EMPTY;
    private final java.util.List list;

    static {
        v0 = new com.google.protobuf.UnmodifiableLazyStringList;
        v1 = new com.google.protobuf.LazyStringArrayList;
        _result = v1.<init>(); // com.google.protobuf.LazyStringArrayList.<init> -> void
        _result = v0.<init>(v1); // com.google.protobuf.UnmodifiableLazyStringList.<init> -> void
        com.google.protobuf.LazyStringArrayList.EMPTY = v0; // :com.google.protobuf.LazyStringList
        return;
    }

    public LazyStringArrayList() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.util.AbstractList.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.list = v0; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        return;
    }

    public LazyStringArrayList(java.util.List p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.List)
        _result = v1.<init>(); // java.util.AbstractList.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(v2); // java.util.ArrayList.<init> -> void
        v1.list = v0; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        return;
    }

    private java.lang.String asString(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = (v2 instanceof java.lang.String);
        if (v0 == 0) /* goto L_0007 */;
        v2 = (java.lang.String) v2;
        return v2;
        v2 = (com.google.protobuf.ByteString) v2;
        _result = v2.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v2 = _result;
        // goto L_0006
    }

    public void add(int p0, java.lang.Object p1) {
        // Registers (3 total): v0 = this, v1 = p0 (int), v2 = p1 (java.lang.Object)
        v2 = (java.lang.String) v2;
        _result = v0.add(v1, v2); // com.google.protobuf.LazyStringArrayList.add -> void
        return;
    }

    public void add(int p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (java.lang.String)
        v0 = v1.list; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        _result = java.util.List.add(v0, v2, v3); // -> void
        v0 = v1.modCount; // com.google.protobuf.LazyStringArrayList.modCount:int
        v0 = binOpLit8_0xd8(v0, 1);
        v1.modCount = v0; // com.google.protobuf.LazyStringArrayList.modCount:int
        return;
    }

    public void add(com.google.protobuf.ByteString p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.ByteString)
        v0 = v1.list; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        _result = java.util.List.add(v0, v2); // -> boolean
        v0 = v1.modCount; // com.google.protobuf.LazyStringArrayList.modCount:int
        v0 = binOpLit8_0xd8(v0, 1);
        v1.modCount = v0; // com.google.protobuf.LazyStringArrayList.modCount:int
        return;
    }

    public boolean addAll(int p0, java.util.Collection p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (java.util.Collection)
        v0 = v2.list; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        _result = java.util.List.addAll(v0, v3, v4); // -> boolean
        v0 = _result;
        v1 = v2.modCount; // com.google.protobuf.LazyStringArrayList.modCount:int
        v1 = binOpLit8_0xd8(v1, 1);
        v2.modCount = v1; // com.google.protobuf.LazyStringArrayList.modCount:int
        return v0;
    }

    public void clear() {
        // Registers (2 total): v1 = this
        v0 = v1.list; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        _result = java.util.List.clear(v0); // -> void
        v0 = v1.modCount; // com.google.protobuf.LazyStringArrayList.modCount:int
        v0 = binOpLit8_0xd8(v0, 1);
        v1.modCount = v0; // com.google.protobuf.LazyStringArrayList.modCount:int
        return;
    }

    public java.lang.Object get(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.get(v2); // com.google.protobuf.LazyStringArrayList.get -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String get(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.list; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        _result = java.util.List.get(v0, v3); // -> java.lang.Object
        v0 = _result;
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_000d */;
        v0 = (java.lang.String) v0;
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.toStringUtf8(); // com.google.protobuf.ByteString.toStringUtf8 -> java.lang.String
        v1 = _result;
        _result = v0.isValidUtf8(); // com.google.protobuf.Internal.isValidUtf8 -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001e */;
        v0 = v2.list; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        _result = java.util.List.set(v0, v3, v1); // -> java.lang.Object
        v0 = v1;
        // goto L_000c
    }

    public com.google.protobuf.ByteString getByteString(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.list; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        _result = java.util.List.get(v0, v3); // -> java.lang.Object
        v0 = _result;
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0016 */;
        v0 = (java.lang.String) v0;
        _result = v0.copyFromUtf8(); // com.google.protobuf.ByteString.copyFromUtf8 -> com.google.protobuf.ByteString
        v0 = _result;
        v1 = v2.list; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        _result = java.util.List.set(v1, v3, v0); // -> java.lang.Object
        return v0;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_0015
    }

    public java.lang.Object remove(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.remove(v2); // com.google.protobuf.LazyStringArrayList.remove -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String remove(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.list; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        _result = java.util.List.remove(v0, v3); // -> java.lang.Object
        v0 = _result;
        v1 = v2.modCount; // com.google.protobuf.LazyStringArrayList.modCount:int
        v1 = binOpLit8_0xd8(v1, 1);
        v2.modCount = v1; // com.google.protobuf.LazyStringArrayList.modCount:int
        _result = v2.asString(v0); // com.google.protobuf.LazyStringArrayList.asString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.Object set(int p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (java.lang.Object)
        v3 = (java.lang.String) v3;
        _result = v1.set(v2, v3); // com.google.protobuf.LazyStringArrayList.set -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String set(int p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (java.lang.String)
        v0 = v1.list; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        _result = java.util.List.set(v0, v2, v3); // -> java.lang.Object
        v0 = _result;
        _result = v1.asString(v0); // com.google.protobuf.LazyStringArrayList.asString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public int size() {
        // Registers (2 total): v1 = this
        v0 = v1.list; // com.google.protobuf.LazyStringArrayList.list:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        return v0;
    }

}