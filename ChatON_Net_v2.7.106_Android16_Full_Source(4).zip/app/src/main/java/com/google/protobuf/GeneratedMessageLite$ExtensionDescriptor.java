package com.google.protobuf;

/**
 * Original SourceFile: GeneratedMessageLite.java
 * Descriptor: Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
 */
final class GeneratedMessageLite$ExtensionDescriptor implements com.google.protobuf.FieldSet$FieldDescriptorLite {
    private final com.google.protobuf.Internal$EnumLiteMap enumTypeMap;
    private final boolean isPacked;
    private final boolean isRepeated;
    private final int number;
    private final com.google.protobuf.WireFormat$FieldType type;

    private GeneratedMessageLite$ExtensionDescriptor(com.google.protobuf.Internal$EnumLiteMap p0, int p1, com.google.protobuf.WireFormat$FieldType p2, boolean p3, boolean p4) {
        // Registers (6 total): v0 = this, v1 = p0 (com.google.protobuf.Internal$EnumLiteMap), v2 = p1 (int), v3 = p2 (com.google.protobuf.WireFormat$FieldType), v4 = p3 (boolean), v5 = p4 (boolean)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.enumTypeMap = v1; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.enumTypeMap:com.google.protobuf.Internal$EnumLiteMap
        v0.number = v2; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.number:int
        v0.type = v3; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.type:com.google.protobuf.WireFormat$FieldType
        v0.isRepeated = v4; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.isRepeated:boolean
        v0.isPacked = v5; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.isPacked:boolean
        return;
    }

    GeneratedMessageLite$ExtensionDescriptor(com.google.protobuf.Internal$EnumLiteMap p0, int p1, com.google.protobuf.WireFormat$FieldType p2, boolean p3, boolean p4, com.google.protobuf.GeneratedMessageLite$1 p5) {
        // Registers (7 total): v0 = this, v1 = p0 (com.google.protobuf.Internal$EnumLiteMap), v2 = p1 (int), v3 = p2 (com.google.protobuf.WireFormat$FieldType), v4 = p3 (boolean), v5 = p4 (boolean), v6 = p5 (com.google.protobuf.GeneratedMessageLite$1)
        _result = v0.<init>(v0..v5); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.<init> -> void
        return;
    }

    static boolean access$500(com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor)
        v0 = v1.isRepeated; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.isRepeated:boolean
        return v0;
    }

    static com.google.protobuf.WireFormat$FieldType access$600(com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor)
        v0 = v1.type; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.type:com.google.protobuf.WireFormat$FieldType
        return v0;
    }

    public int compareTo(com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor)
        v0 = v2.number; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.number:int
        v1 = v3.number; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.number:int
        v0 = binOp2addr_0xb1(v0, v1);
        return v0;
    }

    public int compareTo(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v2 = (com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor) v2;
        _result = v1.compareTo(v2); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.compareTo -> int
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.Internal$EnumLiteMap getEnumType() {
        // Registers (2 total): v1 = this
        v0 = v1.enumTypeMap; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.enumTypeMap:com.google.protobuf.Internal$EnumLiteMap
        return v0;
    }

    public com.google.protobuf.WireFormat$JavaType getLiteJavaType() {
        // Registers (2 total): v1 = this
        v0 = v1.type; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.type:com.google.protobuf.WireFormat$FieldType
        _result = v0.getJavaType(); // com.google.protobuf.WireFormat$FieldType.getJavaType -> com.google.protobuf.WireFormat$JavaType
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.WireFormat$FieldType getLiteType() {
        // Registers (2 total): v1 = this
        v0 = v1.type; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.type:com.google.protobuf.WireFormat$FieldType
        return v0;
    }

    public int getNumber() {
        // Registers (2 total): v1 = this
        v0 = v1.number; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.number:int
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder internalMergeFrom(com.google.protobuf.MessageLite$Builder p0, com.google.protobuf.MessageLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.MessageLite$Builder), v3 = p1 (com.google.protobuf.MessageLite)
        v2 = (com.google.protobuf.GeneratedMessageLite$Builder) v2;
        v3 = (com.google.protobuf.GeneratedMessageLite) v3;
        _result = v2.mergeFrom(v3); // com.google.protobuf.GeneratedMessageLite$Builder.mergeFrom -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public boolean isPacked() {
        // Registers (2 total): v1 = this
        v0 = v1.isPacked; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.isPacked:boolean
        return v0;
    }

    public boolean isRepeated() {
        // Registers (2 total): v1 = this
        v0 = v1.isRepeated; // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.isRepeated:boolean
        return v0;
    }

}