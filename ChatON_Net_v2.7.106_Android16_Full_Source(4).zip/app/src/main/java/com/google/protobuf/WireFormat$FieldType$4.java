package com.google.protobuf;

/**
 * Original SourceFile: WireFormat.java
 * Descriptor: Lcom/google/protobuf/WireFormat$FieldType$4;
 */
final enum WireFormat$FieldType$4 extends com.google.protobuf.WireFormat$FieldType {
    WireFormat$FieldType$4(java.lang.String p0, int p1, com.google.protobuf.WireFormat$JavaType p2, int p3) {
        // Registers (11 total): v6 = this, v7 = p0 (java.lang.String), v8 = p1 (int), v9 = p2 (com.google.protobuf.WireFormat$JavaType), v10 = p3 (int)
        v5 = 0;
        v0 = v6;
        v1 = v7;
        v2 = v8;
        v3 = v9;
        v4 = v10;
        _result = v0.<init>(v0..v5); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        return;
    }

    public boolean isPackable() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

}