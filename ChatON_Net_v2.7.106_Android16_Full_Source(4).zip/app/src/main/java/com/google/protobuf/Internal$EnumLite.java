package com.google.protobuf;

/**
 * Original SourceFile: Internal.java
 * Descriptor: Lcom/google/protobuf/Internal$EnumLite;
 */
public interface Internal$EnumLite {
    public abstract int getNumber();
}