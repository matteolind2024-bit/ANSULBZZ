package com.google.protobuf;

/**
 * Original SourceFile: GeneratedMessageLite.java
 * Descriptor: Lcom/google/protobuf/GeneratedMessageLite$Builder;
 */
public abstract class GeneratedMessageLite$Builder extends com.google.protobuf.AbstractMessageLite$Builder {
    protected GeneratedMessageLite$Builder() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // com.google.protobuf.AbstractMessageLite$Builder.<init> -> void
        return;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (1 total): v0 = this
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.clone(); // com.google.protobuf.GeneratedMessageLite$Builder.clone -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.UnsupportedOperationException;
        v1 = "This is supposed to be overridden by subclasses.";
        _result = v0.<init>(v1); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.clone(); // com.google.protobuf.GeneratedMessageLite$Builder.clone -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.clone(); // com.google.protobuf.GeneratedMessageLite$Builder.clone -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public abstract com.google.protobuf.GeneratedMessageLite getDefaultInstanceForType();
    public com.google.protobuf.MessageLite getDefaultInstanceForType() {
        // Registers (2 total): v1 = this
        _result = v1.getDefaultInstanceForType(); // com.google.protobuf.GeneratedMessageLite$Builder.getDefaultInstanceForType -> com.google.protobuf.GeneratedMessageLite
        v0 = _result;
        return v0;
    }

    public abstract com.google.protobuf.GeneratedMessageLite$Builder mergeFrom(com.google.protobuf.GeneratedMessageLite p0);
    protected boolean parseUnknownField(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite), v4 = p2 (int)
        _result = v2.skipField(v4); // com.google.protobuf.CodedInputStream.skipField -> boolean
        v0 = _result;
        return v0;
    }

}