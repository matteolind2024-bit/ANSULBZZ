package com.google.protobuf;

/**
 * Original SourceFile: CodedOutputStream.java
 * Descriptor: Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;
 */
public class CodedOutputStream$OutOfSpaceException extends java.io.IOException {
    private static final long serialVersionUID;

    CodedOutputStream$OutOfSpaceException() {
        // Registers (2 total): v1 = this
        v0 = "CodedOutputStream was writing to a flat byte array and ran out of space.";
        _result = v1.<init>(v0); // java.io.IOException.<init> -> void
        return;
    }

}