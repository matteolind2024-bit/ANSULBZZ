package com.google.protobuf;

/**
 * Original SourceFile: GeneratedMessageLite.java
 * Descriptor: Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessageOrBuilder;
 */
public interface GeneratedMessageLite$ExtendableMessageOrBuilder extends com.google.protobuf.MessageLiteOrBuilder {
    public abstract java.lang.Object getExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0);
    public abstract java.lang.Object getExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0, int p1);
    public abstract int getExtensionCount(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0);
    public abstract boolean hasExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0);
}