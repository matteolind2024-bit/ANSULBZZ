package com.google.protobuf;

/**
 * Original SourceFile: Internal.java
 * Descriptor: Lcom/google/protobuf/Internal;
 */
public class Internal {
    public Internal() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static com.google.protobuf.ByteString bytesDefaultValue(java.lang.String p0) {
        // Registers (4 total): v3 = p0 (java.lang.String)
        v0 = "ISO-8859-1";
        _result = v3.getBytes(v0); // java.lang.String.getBytes -> byte[]
        v0 = _result;
        _result = v0.copyFrom(); // com.google.protobuf.ByteString.copyFrom -> com.google.protobuf.ByteString
        v0 = _result;
        return v0;
        v0 = _exception;
        v1 = new java.lang.IllegalStateException;
        v2 = "Java VM does not support a standard character set.";
        _result = v1.<init>(v2, v0); // java.lang.IllegalStateException.<init> -> void
        throw v1;
    }

    public static boolean isValidUtf8(com.google.protobuf.ByteString p0) {
        // Registers (11 total): v10 = p0 (com.google.protobuf.ByteString)
        v9 = 244;
        v8 = 191;
        v7 = 128;
        v2 = 0;
        _result = v10.size(); // com.google.protobuf.ByteString.size -> int
        v4 = _result;
        v0 = v2;
        if (v0 >= v4) /* goto L_0084 */;
        v1 = binOpLit8_0xd8(v0, 1);
        _result = v10.byteAt(v0); // com.google.protobuf.ByteString.byteAt -> byte
        v0 = _result;
        v5 = binOpLit16_0xd5(v0, 255);
        if (v5 >= v7) /* goto L_001a */;
        v0 = v1;
        // goto L_000c
        v0 = 194;
        if (v5 < v0) /* goto L_0020 */;
        if (v5 <= v9) /* goto L_0022 */;
        v0 = v2;
        return v0;
        if (v1 < v4) /* goto L_0026 */;
        v0 = v2;
        // goto L_0021
        v3 = binOpLit8_0xd8(v1, 1);
        _result = v10.byteAt(v1); // com.google.protobuf.ByteString.byteAt -> byte
        v0 = _result;
        v6 = binOpLit16_0xd5(v0, 255);
        if (v6 < v7) /* goto L_0032 */;
        if (v6 <= v8) /* goto L_0034 */;
        v0 = v2;
        // goto L_0021
        v0 = 223;
        if (v5 > v0) /* goto L_003a */;
        v0 = v3;
        // goto L_000c
        if (v3 < v4) /* goto L_003e */;
        v0 = v2;
        // goto L_0021
        v0 = binOpLit8_0xd8(v3, 1);
        _result = v10.byteAt(v3); // com.google.protobuf.ByteString.byteAt -> byte
        v1 = _result;
        v1 = binOpLit16_0xd5(v1, 255);
        if (v1 < v7) /* goto L_004a */;
        if (v1 <= v8) /* goto L_004c */;
        v0 = v2;
        // goto L_0021
        v1 = 239;
        if (v5 > v1) /* goto L_0062 */;
        v1 = 224;
        if (v5 != v1) /* goto L_0058 */;
        v1 = 160;
        if (v6 < v1) /* goto L_0060 */;
        v1 = 237;
        if (v5 != v1) /* goto L_000c */;
        v1 = 159;
        if (v6 <= v1) /* goto L_000c */;
        v0 = v2;
        // goto L_0021
        if (v0 < v4) /* goto L_0066 */;
        v0 = v2;
        // goto L_0021
        v1 = binOpLit8_0xd8(v0, 1);
        _result = v10.byteAt(v0); // com.google.protobuf.ByteString.byteAt -> byte
        v0 = _result;
        v0 = binOpLit16_0xd5(v0, 255);
        if (v0 < v7) /* goto L_0072 */;
        if (v0 <= v8) /* goto L_0074 */;
        v0 = v2;
        // goto L_0021
        v0 = 240;
        if (v5 != v0) /* goto L_007c */;
        v0 = 144;
        if (v6 < v0) /* goto L_0082 */;
        if (v5 != v9) /* goto L_0086 */;
        v0 = 143;
        if (v6 <= v0) /* goto L_0086 */;
        v0 = v2;
        // goto L_0021
        v0 = 1;
        // goto L_0021
        v0 = v1;
        // goto L_000c
    }

    public static java.lang.String stringDefaultValue(java.lang.String p0) {
        // Registers (4 total): v3 = p0 (java.lang.String)
        v0 = new java.lang.String;
        v1 = "ISO-8859-1";
        _result = v3.getBytes(v1); // java.lang.String.getBytes -> byte[]
        v1 = _result;
        v2 = "UTF-8";
        _result = v0.<init>(v1, v2); // java.lang.String.<init> -> void
        return v0;
        v0 = _exception;
        v1 = new java.lang.IllegalStateException;
        v2 = "Java VM does not support a standard character set.";
        _result = v1.<init>(v2, v0); // java.lang.IllegalStateException.<init> -> void
        throw v1;
    }

}