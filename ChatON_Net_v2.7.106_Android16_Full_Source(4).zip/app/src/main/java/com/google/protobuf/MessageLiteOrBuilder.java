package com.google.protobuf;

/**
 * Original SourceFile: MessageLiteOrBuilder.java
 * Descriptor: Lcom/google/protobuf/MessageLiteOrBuilder;
 */
public interface MessageLiteOrBuilder {
    public abstract com.google.protobuf.MessageLite getDefaultInstanceForType();
    public abstract boolean isInitialized();
}