package com.google.protobuf;

/**
 * Original SourceFile: GeneratedMessageLite.java
 * Descriptor: Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;
 */
public class GeneratedMessageLite$ExtendableMessage$ExtensionWriter {
    private final java.util.Iterator iter;
    private final boolean messageSetWireFormat;
    private java.util.Map$Entry next;
    final com.google.protobuf.GeneratedMessageLite$ExtendableMessage this$0;

    private GeneratedMessageLite$ExtendableMessage$ExtensionWriter(com.google.protobuf.GeneratedMessageLite$ExtendableMessage p0, boolean p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite$ExtendableMessage), v3 = p1 (boolean)
        v1.this$0 = v2; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.this$0:com.google.protobuf.GeneratedMessageLite$ExtendableMessage
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = v1.this$0; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.this$0:com.google.protobuf.GeneratedMessageLite$ExtendableMessage
        _result = v0.access$300(); // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.access$300 -> com.google.protobuf.FieldSet
        v0 = _result;
        _result = v0.iterator(); // com.google.protobuf.FieldSet.iterator -> java.util.Iterator
        v0 = _result;
        v1.iter = v0; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.iter:java.util.Iterator
        v0 = v1.iter; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.iter:java.util.Iterator
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0023 */;
        v0 = v1.iter; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.iter:java.util.Iterator
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        v1.next = v0; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.next:java.util.Map$Entry
        v1.messageSetWireFormat = v3; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.messageSetWireFormat:boolean
        return;
    }

    GeneratedMessageLite$ExtendableMessage$ExtensionWriter(com.google.protobuf.GeneratedMessageLite$ExtendableMessage p0, boolean p1, com.google.protobuf.GeneratedMessageLite$1 p2) {
        // Registers (4 total): v0 = this, v1 = p0 (com.google.protobuf.GeneratedMessageLite$ExtendableMessage), v2 = p1 (boolean), v3 = p2 (com.google.protobuf.GeneratedMessageLite$1)
        _result = v0.<init>(v1, v2); // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.<init> -> void
        return;
    }

    public void writeUntil(int p0, com.google.protobuf.CodedOutputStream p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (com.google.protobuf.CodedOutputStream)
        v0 = v3.next; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.next:java.util.Map$Entry
        if (v0 == 0) /* goto L_005c */;
        v0 = v3.next; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.next:java.util.Map$Entry
        _result = java.util.Map$Entry.getKey(v0); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor) v0;
        _result = v0.getNumber(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getNumber -> int
        v0 = _result;
        if (v0 >= v4) /* goto L_005c */;
        v0 = v3.next; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.next:java.util.Map$Entry
        _result = java.util.Map$Entry.getKey(v0); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor) v0;
        v1 = v3.messageSetWireFormat; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.messageSetWireFormat:boolean
        if (v1 == 0) /* goto L_004e */;
        _result = v0.getLiteJavaType(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getLiteJavaType -> com.google.protobuf.WireFormat$JavaType
        v1 = _result;
        v2 = com.google.protobuf.WireFormat$JavaType.MESSAGE; // :com.google.protobuf.WireFormat$JavaType
        if (v1 != v2) /* goto L_004e */;
        _result = v0.isRepeated(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.isRepeated -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_004e */;
        _result = v0.getNumber(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getNumber -> int
        v1 = _result;
        v0 = v3.next; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.next:java.util.Map$Entry
        _result = java.util.Map$Entry.getValue(v0); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        _result = v5.writeMessageSetExtension(v1, v0); // com.google.protobuf.CodedOutputStream.writeMessageSetExtension -> void
        v0 = v3.iter; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.iter:java.util.Iterator
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0058 */;
        v0 = v3.iter; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.iter:java.util.Iterator
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        v3.next = v0; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.next:java.util.Map$Entry
        // goto L_0000
        v1 = v3.next; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.next:java.util.Map$Entry
        _result = java.util.Map$Entry.getValue(v1); // -> java.lang.Object
        v1 = _result;
        _result = v0.writeField(v1, v5); // com.google.protobuf.FieldSet.writeField -> void
        // goto L_003b
        v0 = 0;
        v3.next = v0; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.next:java.util.Map$Entry
        // goto L_0000
        return;
    }

}