package com.google.protobuf;

/**
 * Original SourceFile: WireFormat.java
 * Descriptor: Lcom/google/protobuf/WireFormat$JavaType;
 */
public final enum WireFormat$JavaType {
    private static final com.google.protobuf.WireFormat$JavaType[] $VALUES;
    public static final com.google.protobuf.WireFormat$JavaType BOOLEAN;
    public static final com.google.protobuf.WireFormat$JavaType BYTE_STRING;
    public static final com.google.protobuf.WireFormat$JavaType DOUBLE;
    public static final com.google.protobuf.WireFormat$JavaType ENUM;
    public static final com.google.protobuf.WireFormat$JavaType FLOAT;
    public static final com.google.protobuf.WireFormat$JavaType INT;
    public static final com.google.protobuf.WireFormat$JavaType LONG;
    public static final com.google.protobuf.WireFormat$JavaType MESSAGE;
    public static final com.google.protobuf.WireFormat$JavaType STRING;
    private final java.lang.Object defaultDefault;

    static {
        v8 = 4;
        v7 = 3;
        v6 = 2;
        v5 = 1;
        v4 = 0;
        v0 = new com.google.protobuf.WireFormat$JavaType;
        v1 = "INT";
        _result = v4.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v0.<init>(v1, v4, v2); // com.google.protobuf.WireFormat$JavaType.<init> -> void
        com.google.protobuf.WireFormat$JavaType.INT = v0; // :com.google.protobuf.WireFormat$JavaType
        v0 = new com.google.protobuf.WireFormat$JavaType;
        v1 = "LONG";
        v2 = 0L;
        _result = v2.valueOf(v3); // java.lang.Long.valueOf -> java.lang.Long
        v2 = _result;
        _result = v0.<init>(v1, v5, v2); // com.google.protobuf.WireFormat$JavaType.<init> -> void
        com.google.protobuf.WireFormat$JavaType.LONG = v0; // :com.google.protobuf.WireFormat$JavaType
        v0 = new com.google.protobuf.WireFormat$JavaType;
        v1 = "FLOAT";
        v2 = 0;
        _result = v2.valueOf(); // java.lang.Float.valueOf -> java.lang.Float
        v2 = _result;
        _result = v0.<init>(v1, v6, v2); // com.google.protobuf.WireFormat$JavaType.<init> -> void
        com.google.protobuf.WireFormat$JavaType.FLOAT = v0; // :com.google.protobuf.WireFormat$JavaType
        v0 = new com.google.protobuf.WireFormat$JavaType;
        v1 = "DOUBLE";
        v2 = 0L;
        _result = v2.valueOf(v3); // java.lang.Double.valueOf -> java.lang.Double
        v2 = _result;
        _result = v0.<init>(v1, v7, v2); // com.google.protobuf.WireFormat$JavaType.<init> -> void
        com.google.protobuf.WireFormat$JavaType.DOUBLE = v0; // :com.google.protobuf.WireFormat$JavaType
        v0 = new com.google.protobuf.WireFormat$JavaType;
        v1 = "BOOLEAN";
        _result = v4.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v2 = _result;
        _result = v0.<init>(v1, v8, v2); // com.google.protobuf.WireFormat$JavaType.<init> -> void
        com.google.protobuf.WireFormat$JavaType.BOOLEAN = v0; // :com.google.protobuf.WireFormat$JavaType
        v0 = new com.google.protobuf.WireFormat$JavaType;
        v1 = "STRING";
        v2 = 5;
        v3 = "";
        _result = v0.<init>(v1, v2, v3); // com.google.protobuf.WireFormat$JavaType.<init> -> void
        com.google.protobuf.WireFormat$JavaType.STRING = v0; // :com.google.protobuf.WireFormat$JavaType
        v0 = new com.google.protobuf.WireFormat$JavaType;
        v1 = "BYTE_STRING";
        v2 = 6;
        v3 = com.google.protobuf.ByteString.EMPTY; // :com.google.protobuf.ByteString
        _result = v0.<init>(v1, v2, v3); // com.google.protobuf.WireFormat$JavaType.<init> -> void
        com.google.protobuf.WireFormat$JavaType.BYTE_STRING = v0; // :com.google.protobuf.WireFormat$JavaType
        v0 = new com.google.protobuf.WireFormat$JavaType;
        v1 = "ENUM";
        v2 = 7;
        v3 = 0;
        _result = v0.<init>(v1, v2, v3); // com.google.protobuf.WireFormat$JavaType.<init> -> void
        com.google.protobuf.WireFormat$JavaType.ENUM = v0; // :com.google.protobuf.WireFormat$JavaType
        v0 = new com.google.protobuf.WireFormat$JavaType;
        v1 = "MESSAGE";
        v2 = 8;
        v3 = 0;
        _result = v0.<init>(v1, v2, v3); // com.google.protobuf.WireFormat$JavaType.<init> -> void
        com.google.protobuf.WireFormat$JavaType.MESSAGE = v0; // :com.google.protobuf.WireFormat$JavaType
        v0 = 9;
        v0 = new com.google.protobuf.WireFormat$JavaType[][size=v0];
        v1 = com.google.protobuf.WireFormat$JavaType.INT; // :com.google.protobuf.WireFormat$JavaType
        v0[v4] = v1;
        v1 = com.google.protobuf.WireFormat$JavaType.LONG; // :com.google.protobuf.WireFormat$JavaType
        v0[v5] = v1;
        v1 = com.google.protobuf.WireFormat$JavaType.FLOAT; // :com.google.protobuf.WireFormat$JavaType
        v0[v6] = v1;
        v1 = com.google.protobuf.WireFormat$JavaType.DOUBLE; // :com.google.protobuf.WireFormat$JavaType
        v0[v7] = v1;
        v1 = com.google.protobuf.WireFormat$JavaType.BOOLEAN; // :com.google.protobuf.WireFormat$JavaType
        v0[v8] = v1;
        v1 = 5;
        v2 = com.google.protobuf.WireFormat$JavaType.STRING; // :com.google.protobuf.WireFormat$JavaType
        v0[v1] = v2;
        v1 = 6;
        v2 = com.google.protobuf.WireFormat$JavaType.BYTE_STRING; // :com.google.protobuf.WireFormat$JavaType
        v0[v1] = v2;
        v1 = 7;
        v2 = com.google.protobuf.WireFormat$JavaType.ENUM; // :com.google.protobuf.WireFormat$JavaType
        v0[v1] = v2;
        v1 = 8;
        v2 = com.google.protobuf.WireFormat$JavaType.MESSAGE; // :com.google.protobuf.WireFormat$JavaType
        v0[v1] = v2;
        com.google.protobuf.WireFormat$JavaType.$VALUES = v0; // :com.google.protobuf.WireFormat$JavaType[]
        return;
    }

    private WireFormat$JavaType(java.lang.String p0, int p1, java.lang.Object p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int), v3 = p2 (java.lang.Object)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        v0.defaultDefault = v3; // com.google.protobuf.WireFormat$JavaType.defaultDefault:java.lang.Object
        return;
    }

    public static com.google.protobuf.WireFormat$JavaType valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = com.google.protobuf.WireFormat$JavaType.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (com.google.protobuf.WireFormat$JavaType) v0;
        return v0;
    }

    public static com.google.protobuf.WireFormat$JavaType[] values() {
        v0 = com.google.protobuf.WireFormat$JavaType.$VALUES; // :com.google.protobuf.WireFormat$JavaType[]
        _result = v0.clone(); // com.google.protobuf.WireFormat$JavaType[].clone -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.WireFormat$JavaType[]) v0;
        return v0;
    }

    java.lang.Object getDefaultDefault() {
        // Registers (2 total): v1 = this
        v0 = v1.defaultDefault; // com.google.protobuf.WireFormat$JavaType.defaultDefault:java.lang.Object
        return v0;
    }

}