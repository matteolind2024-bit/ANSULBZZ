package com.google.protobuf;

/**
 * Original SourceFile: WireFormat.java
 * Descriptor: Lcom/google/protobuf/WireFormat$FieldType;
 */
public enum WireFormat$FieldType {
    private static final com.google.protobuf.WireFormat$FieldType[] $VALUES;
    public static final com.google.protobuf.WireFormat$FieldType BOOL;
    public static final com.google.protobuf.WireFormat$FieldType BYTES;
    public static final com.google.protobuf.WireFormat$FieldType DOUBLE;
    public static final com.google.protobuf.WireFormat$FieldType ENUM;
    public static final com.google.protobuf.WireFormat$FieldType FIXED32;
    public static final com.google.protobuf.WireFormat$FieldType FIXED64;
    public static final com.google.protobuf.WireFormat$FieldType FLOAT;
    public static final com.google.protobuf.WireFormat$FieldType GROUP;
    public static final com.google.protobuf.WireFormat$FieldType INT32;
    public static final com.google.protobuf.WireFormat$FieldType INT64;
    public static final com.google.protobuf.WireFormat$FieldType MESSAGE;
    public static final com.google.protobuf.WireFormat$FieldType SFIXED32;
    public static final com.google.protobuf.WireFormat$FieldType SFIXED64;
    public static final com.google.protobuf.WireFormat$FieldType SINT32;
    public static final com.google.protobuf.WireFormat$FieldType SINT64;
    public static final com.google.protobuf.WireFormat$FieldType STRING;
    public static final com.google.protobuf.WireFormat$FieldType UINT32;
    public static final com.google.protobuf.WireFormat$FieldType UINT64;
    private final com.google.protobuf.WireFormat$JavaType javaType;
    private final int wireType;

    static {
        v8 = 3;
        v7 = 5;
        v6 = 2;
        v5 = 1;
        v4 = 0;
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "DOUBLE";
        v2 = com.google.protobuf.WireFormat$JavaType.DOUBLE; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v4, v2, v5); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.DOUBLE = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "FLOAT";
        v2 = com.google.protobuf.WireFormat$JavaType.FLOAT; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v5, v2, v7); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.FLOAT = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "INT64";
        v2 = com.google.protobuf.WireFormat$JavaType.LONG; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v6, v2, v4); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.INT64 = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "UINT64";
        v2 = com.google.protobuf.WireFormat$JavaType.LONG; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v8, v2, v4); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.UINT64 = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "INT32";
        v2 = 4;
        v3 = com.google.protobuf.WireFormat$JavaType.INT; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v4); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.INT32 = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "FIXED64";
        v2 = com.google.protobuf.WireFormat$JavaType.LONG; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v7, v2, v5); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.FIXED64 = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "FIXED32";
        v2 = 6;
        v3 = com.google.protobuf.WireFormat$JavaType.INT; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v7); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.FIXED32 = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "BOOL";
        v2 = 7;
        v3 = com.google.protobuf.WireFormat$JavaType.BOOLEAN; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v4); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.BOOL = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType$1;
        v1 = "STRING";
        v2 = 8;
        v3 = com.google.protobuf.WireFormat$JavaType.STRING; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v6); // com.google.protobuf.WireFormat$FieldType$1.<init> -> void
        com.google.protobuf.WireFormat$FieldType.STRING = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType$2;
        v1 = "GROUP";
        v2 = 9;
        v3 = com.google.protobuf.WireFormat$JavaType.MESSAGE; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v8); // com.google.protobuf.WireFormat$FieldType$2.<init> -> void
        com.google.protobuf.WireFormat$FieldType.GROUP = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType$3;
        v1 = "MESSAGE";
        v2 = 10;
        v3 = com.google.protobuf.WireFormat$JavaType.MESSAGE; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v6); // com.google.protobuf.WireFormat$FieldType$3.<init> -> void
        com.google.protobuf.WireFormat$FieldType.MESSAGE = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType$4;
        v1 = "BYTES";
        v2 = 11;
        v3 = com.google.protobuf.WireFormat$JavaType.BYTE_STRING; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v6); // com.google.protobuf.WireFormat$FieldType$4.<init> -> void
        com.google.protobuf.WireFormat$FieldType.BYTES = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "UINT32";
        v2 = 12;
        v3 = com.google.protobuf.WireFormat$JavaType.INT; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v4); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.UINT32 = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "ENUM";
        v2 = 13;
        v3 = com.google.protobuf.WireFormat$JavaType.ENUM; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v4); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.ENUM = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "SFIXED32";
        v2 = 14;
        v3 = com.google.protobuf.WireFormat$JavaType.INT; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v7); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.SFIXED32 = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "SFIXED64";
        v2 = 15;
        v3 = com.google.protobuf.WireFormat$JavaType.LONG; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v5); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.SFIXED64 = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "SINT32";
        v2 = 16;
        v3 = com.google.protobuf.WireFormat$JavaType.INT; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v4); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.SINT32 = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = new com.google.protobuf.WireFormat$FieldType;
        v1 = "SINT64";
        v2 = 17;
        v3 = com.google.protobuf.WireFormat$JavaType.LONG; // :com.google.protobuf.WireFormat$JavaType
        _result = v0.<init>(v1, v2, v3, v4); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        com.google.protobuf.WireFormat$FieldType.SINT64 = v0; // :com.google.protobuf.WireFormat$FieldType
        v0 = 18;
        v0 = new com.google.protobuf.WireFormat$FieldType[][size=v0];
        v1 = com.google.protobuf.WireFormat$FieldType.DOUBLE; // :com.google.protobuf.WireFormat$FieldType
        v0[v4] = v1;
        v1 = com.google.protobuf.WireFormat$FieldType.FLOAT; // :com.google.protobuf.WireFormat$FieldType
        v0[v5] = v1;
        v1 = com.google.protobuf.WireFormat$FieldType.INT64; // :com.google.protobuf.WireFormat$FieldType
        v0[v6] = v1;
        v1 = com.google.protobuf.WireFormat$FieldType.UINT64; // :com.google.protobuf.WireFormat$FieldType
        v0[v8] = v1;
        v1 = 4;
        v2 = com.google.protobuf.WireFormat$FieldType.INT32; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = com.google.protobuf.WireFormat$FieldType.FIXED64; // :com.google.protobuf.WireFormat$FieldType
        v0[v7] = v1;
        v1 = 6;
        v2 = com.google.protobuf.WireFormat$FieldType.FIXED32; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = 7;
        v2 = com.google.protobuf.WireFormat$FieldType.BOOL; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = 8;
        v2 = com.google.protobuf.WireFormat$FieldType.STRING; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = 9;
        v2 = com.google.protobuf.WireFormat$FieldType.GROUP; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = 10;
        v2 = com.google.protobuf.WireFormat$FieldType.MESSAGE; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = 11;
        v2 = com.google.protobuf.WireFormat$FieldType.BYTES; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = 12;
        v2 = com.google.protobuf.WireFormat$FieldType.UINT32; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = 13;
        v2 = com.google.protobuf.WireFormat$FieldType.ENUM; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = 14;
        v2 = com.google.protobuf.WireFormat$FieldType.SFIXED32; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = 15;
        v2 = com.google.protobuf.WireFormat$FieldType.SFIXED64; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = 16;
        v2 = com.google.protobuf.WireFormat$FieldType.SINT32; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        v1 = 17;
        v2 = com.google.protobuf.WireFormat$FieldType.SINT64; // :com.google.protobuf.WireFormat$FieldType
        v0[v1] = v2;
        com.google.protobuf.WireFormat$FieldType.$VALUES = v0; // :com.google.protobuf.WireFormat$FieldType[]
        return;
    }

    private WireFormat$FieldType(java.lang.String p0, int p1, com.google.protobuf.WireFormat$JavaType p2, int p3) {
        // Registers (5 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int), v3 = p2 (com.google.protobuf.WireFormat$JavaType), v4 = p3 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        v0.javaType = v3; // com.google.protobuf.WireFormat$FieldType.javaType:com.google.protobuf.WireFormat$JavaType
        v0.wireType = v4; // com.google.protobuf.WireFormat$FieldType.wireType:int
        return;
    }

    WireFormat$FieldType(java.lang.String p0, int p1, com.google.protobuf.WireFormat$JavaType p2, int p3, com.google.protobuf.WireFormat$1 p4) {
        // Registers (6 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int), v3 = p2 (com.google.protobuf.WireFormat$JavaType), v4 = p3 (int), v5 = p4 (com.google.protobuf.WireFormat$1)
        _result = v0.<init>(v1, v2, v3, v4); // com.google.protobuf.WireFormat$FieldType.<init> -> void
        return;
    }

    public static com.google.protobuf.WireFormat$FieldType valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = com.google.protobuf.WireFormat$FieldType.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (com.google.protobuf.WireFormat$FieldType) v0;
        return v0;
    }

    public static com.google.protobuf.WireFormat$FieldType[] values() {
        v0 = com.google.protobuf.WireFormat$FieldType.$VALUES; // :com.google.protobuf.WireFormat$FieldType[]
        _result = v0.clone(); // com.google.protobuf.WireFormat$FieldType[].clone -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.WireFormat$FieldType[]) v0;
        return v0;
    }

    public com.google.protobuf.WireFormat$JavaType getJavaType() {
        // Registers (2 total): v1 = this
        v0 = v1.javaType; // com.google.protobuf.WireFormat$FieldType.javaType:com.google.protobuf.WireFormat$JavaType
        return v0;
    }

    public int getWireType() {
        // Registers (2 total): v1 = this
        v0 = v1.wireType; // com.google.protobuf.WireFormat$FieldType.wireType:int
        return v0;
    }

    public boolean isPackable() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

}