package com.google.protobuf;

/**
 * Original SourceFile: AbstractMessageLite.java
 * Descriptor: Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;
 */
final class AbstractMessageLite$Builder$LimitedInputStream extends java.io.FilterInputStream {
    private int limit;

    AbstractMessageLite$Builder$LimitedInputStream(java.io.InputStream p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.io.InputStream), v2 = p1 (int)
        _result = v0.<init>(v1); // java.io.FilterInputStream.<init> -> void
        v0.limit = v2; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        return;
    }

    public int available() {
        // Registers (3 total): v2 = this
        _result = v2.available(); // java.io.FilterInputStream.available -> int
        v0 = _result;
        v1 = v2.limit; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        _result = v0.min(v1); // java.lang.Math.min -> int
        v0 = _result;
        return v0;
    }

    public int read() {
        // Registers (3 total): v2 = this
        v0 = v2.limit; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        if (v0 > 0) /* goto L_0006 */;
        v0 = -1;
        return v0;
        _result = v2.read(); // java.io.FilterInputStream.read -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0005 */;
        v1 = v2.limit; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        v1 = binOpLit8_0xd8(v1, -1);
        v2.limit = v1; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        // goto L_0005
    }

    public int read(byte[] p0, int p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (byte[]), v4 = p1 (int), v5 = p2 (int)
        v0 = v2.limit; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        if (v0 > 0) /* goto L_0006 */;
        v0 = -1;
        return v0;
        v0 = v2.limit; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        _result = v5.min(v0); // java.lang.Math.min -> int
        v0 = _result;
        _result = v2.read(v3, v4, v0); // java.io.FilterInputStream.read -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0005 */;
        v1 = v2.limit; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        v1 = binOp2addr_0xb1(v1, v0);
        v2.limit = v1; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        // goto L_0005
    }

    public long skip(long p0) {
        // Registers (7 total): v4 = this, v5 = p0 (long)
        v0 = v4.limit; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        v0 = unaryOp_0x81(v0);
        _result = v5.min(v6, v0, v1); // java.lang.Math.min -> long
        v0 = _result;
        _result = v4.skip(v0, v1); // java.io.FilterInputStream.skip -> long
        v0 = _result;
        v2 = 0L;
        v2 = cmp(v0, v2);
        if (v2 < 0) /* goto L_0018 */;
        v2 = v4.limit; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        v2 = unaryOp_0x81(v2);
        v2 = binOp2addr_0xbc(v2, v0);
        v2 = unaryOp_0x84(v2);
        v4.limit = v2; // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.limit:int
        return v0;
    }

}