package com.google.protobuf;

/**
 * Original SourceFile: UnmodifiableLazyStringList.java
 * Descriptor: Lcom/google/protobuf/UnmodifiableLazyStringList$1;
 */
class UnmodifiableLazyStringList$1 implements java.util.ListIterator {
     java.util.ListIterator iter;
    final com.google.protobuf.UnmodifiableLazyStringList this$0;
    final int val$index;

    UnmodifiableLazyStringList$1(com.google.protobuf.UnmodifiableLazyStringList p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.UnmodifiableLazyStringList), v4 = p1 (int)
        v2.this$0 = v3; // com.google.protobuf.UnmodifiableLazyStringList$1.this$0:com.google.protobuf.UnmodifiableLazyStringList
        v2.val$index = v4; // com.google.protobuf.UnmodifiableLazyStringList$1.val$index:int
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v0 = v2.this$0; // com.google.protobuf.UnmodifiableLazyStringList$1.this$0:com.google.protobuf.UnmodifiableLazyStringList
        _result = v0.access$000(); // com.google.protobuf.UnmodifiableLazyStringList.access$000 -> com.google.protobuf.LazyStringList
        v0 = _result;
        v1 = v2.val$index; // com.google.protobuf.UnmodifiableLazyStringList$1.val$index:int
        _result = com.google.protobuf.LazyStringList.listIterator(v0, v1); // -> java.util.ListIterator
        v0 = _result;
        v2.iter = v0; // com.google.protobuf.UnmodifiableLazyStringList$1.iter:java.util.ListIterator
        return;
    }

    public void add(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        v1 = (java.lang.String) v1;
        _result = v0.add(v1); // com.google.protobuf.UnmodifiableLazyStringList$1.add -> void
        return;
    }

    public void add(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public boolean hasNext() {
        // Registers (2 total): v1 = this
        v0 = v1.iter; // com.google.protobuf.UnmodifiableLazyStringList$1.iter:java.util.ListIterator
        _result = java.util.ListIterator.hasNext(v0); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean hasPrevious() {
        // Registers (2 total): v1 = this
        v0 = v1.iter; // com.google.protobuf.UnmodifiableLazyStringList$1.iter:java.util.ListIterator
        _result = java.util.ListIterator.hasPrevious(v0); // -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.Object next() {
        // Registers (2 total): v1 = this
        _result = v1.next(); // com.google.protobuf.UnmodifiableLazyStringList$1.next -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String next() {
        // Registers (2 total): v1 = this
        v0 = v1.iter; // com.google.protobuf.UnmodifiableLazyStringList$1.iter:java.util.ListIterator
        _result = java.util.ListIterator.next(v0); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        return v0;
    }

    public int nextIndex() {
        // Registers (2 total): v1 = this
        v0 = v1.iter; // com.google.protobuf.UnmodifiableLazyStringList$1.iter:java.util.ListIterator
        _result = java.util.ListIterator.nextIndex(v0); // -> int
        v0 = _result;
        return v0;
    }

    public java.lang.Object previous() {
        // Registers (2 total): v1 = this
        _result = v1.previous(); // com.google.protobuf.UnmodifiableLazyStringList$1.previous -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String previous() {
        // Registers (2 total): v1 = this
        v0 = v1.iter; // com.google.protobuf.UnmodifiableLazyStringList$1.iter:java.util.ListIterator
        _result = java.util.ListIterator.previous(v0); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        return v0;
    }

    public int previousIndex() {
        // Registers (2 total): v1 = this
        v0 = v1.iter; // com.google.protobuf.UnmodifiableLazyStringList$1.iter:java.util.ListIterator
        _result = java.util.ListIterator.previousIndex(v0); // -> int
        v0 = _result;
        return v0;
    }

    public void remove() {
        // Registers (2 total): v1 = this
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public void set(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        v1 = (java.lang.String) v1;
        _result = v0.set(v1); // com.google.protobuf.UnmodifiableLazyStringList$1.set -> void
        return;
    }

    public void set(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

}