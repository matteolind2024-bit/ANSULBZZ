package com.google.protobuf;

/**
 * Original SourceFile: FieldSet.java
 * Descriptor: Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
 */
public interface FieldSet$FieldDescriptorLite extends java.lang.Comparable {
    public abstract com.google.protobuf.Internal$EnumLiteMap getEnumType();
    public abstract com.google.protobuf.WireFormat$JavaType getLiteJavaType();
    public abstract com.google.protobuf.WireFormat$FieldType getLiteType();
    public abstract int getNumber();
    public abstract com.google.protobuf.MessageLite$Builder internalMergeFrom(com.google.protobuf.MessageLite$Builder p0, com.google.protobuf.MessageLite p1);
    public abstract boolean isPacked();
    public abstract boolean isRepeated();
}