package com.google.protobuf;

/**
 * Original SourceFile: AbstractMessageLite.java
 * Descriptor: Lcom/google/protobuf/AbstractMessageLite$Builder;
 */
public abstract class AbstractMessageLite$Builder implements com.google.protobuf.MessageLite$Builder {
    public AbstractMessageLite$Builder() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    protected static void addAll(java.lang.Iterable p0, java.util.Collection p1) {
        // Registers (4 total): v2 = p0 (java.lang.Iterable), v3 = p1 (java.util.Collection)
        _result = java.lang.Iterable.iterator(v2); // -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0016 */;
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v1 = _result;
        if (v1 != 0) /* goto L_0004 */;
        v0 = new java.lang.NullPointerException;
        _result = v0.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = (v2 instanceof java.util.Collection);
        if (v0 == 0) /* goto L_0020 */;
        v2 = (java.util.Collection) v2;
        _result = java.util.Collection.addAll(v3, v2); // -> boolean
        return;
        _result = java.lang.Iterable.iterator(v2); // -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_001f */;
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v1 = _result;
        _result = java.util.Collection.add(v3, v1); // -> boolean
        // goto L_0024
    }

    protected static com.google.protobuf.UninitializedMessageException newUninitializedMessageException(com.google.protobuf.MessageLite p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.MessageLite)
        v0 = new com.google.protobuf.UninitializedMessageException;
        _result = v0.<init>(v1); // com.google.protobuf.UninitializedMessageException.<init> -> void
        return v0;
    }

    public abstract com.google.protobuf.AbstractMessageLite$Builder clone();
    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.clone(); // com.google.protobuf.AbstractMessageLite$Builder.clone -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.clone(); // com.google.protobuf.AbstractMessageLite$Builder.clone -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public boolean mergeDelimitedFrom(java.io.InputStream p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.io.InputStream)
        _result = this.getEmptyRegistry(); // com.google.protobuf.ExtensionRegistryLite.getEmptyRegistry -> com.google.protobuf.ExtensionRegistryLite
        v0 = _result;
        _result = v1.mergeDelimitedFrom(v2, v0); // com.google.protobuf.AbstractMessageLite$Builder.mergeDelimitedFrom -> boolean
        v0 = _result;
        return v0;
    }

    public boolean mergeDelimitedFrom(java.io.InputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.io.InputStream), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.read(); // java.io.InputStream.read -> int
        v0 = _result;
        v1 = -1;
        if (v0 != v1) /* goto L_0009 */;
        v0 = 0;
        return v0;
        _result = v0.readRawVarint32(v3); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v0 = _result;
        v1 = new com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream;
        _result = v1.<init>(v3, v0); // com.google.protobuf.AbstractMessageLite$Builder$LimitedInputStream.<init> -> void
        _result = v2.mergeFrom(v1, v4); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = 1;
        // goto L_0008
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.ByteString p0) {
        // Registers (5 total): v3 = this, v4 = p0 (com.google.protobuf.ByteString)
        _result = v4.newCodedInput(); // com.google.protobuf.ByteString.newCodedInput -> com.google.protobuf.CodedInputStream
        v0 = _result;
        _result = v3.mergeFrom(v0); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v1 = 0;
        _result = v0.checkLastTagWas(v1); // com.google.protobuf.CodedInputStream.checkLastTagWas -> void
        return v3;
        v0 = _exception;
        throw v0;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "Reading from a ByteString threw an IOException (should never happen).";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.ByteString p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (6 total): v3 = this, v4 = p0 (com.google.protobuf.ByteString), v5 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v4.newCodedInput(); // com.google.protobuf.ByteString.newCodedInput -> com.google.protobuf.CodedInputStream
        v0 = _result;
        _result = v3.mergeFrom(v0, v5); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v1 = 0;
        _result = v0.checkLastTagWas(v1); // com.google.protobuf.CodedInputStream.checkLastTagWas -> void
        return v3;
        v0 = _exception;
        throw v0;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "Reading from a ByteString threw an IOException (should never happen).";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream)
        _result = this.getEmptyRegistry(); // com.google.protobuf.ExtensionRegistryLite.getEmptyRegistry -> com.google.protobuf.ExtensionRegistryLite
        v0 = _result;
        _result = v1.mergeFrom(v2, v0); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public abstract com.google.protobuf.AbstractMessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1);
    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(java.io.InputStream p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.io.InputStream)
        _result = v3.newInstance(); // com.google.protobuf.CodedInputStream.newInstance -> com.google.protobuf.CodedInputStream
        v0 = _result;
        _result = v2.mergeFrom(v0); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v1 = 0;
        _result = v0.checkLastTagWas(v1); // com.google.protobuf.CodedInputStream.checkLastTagWas -> void
        return v2;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(java.io.InputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.io.InputStream), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.newInstance(); // com.google.protobuf.CodedInputStream.newInstance -> com.google.protobuf.CodedInputStream
        v0 = _result;
        _result = v2.mergeFrom(v0, v4); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v1 = 0;
        _result = v0.checkLastTagWas(v1); // com.google.protobuf.CodedInputStream.checkLastTagWas -> void
        return v2;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(byte[] p0) {
        // Registers (4 total): v2 = this, v3 = p0 (byte[])
        v0 = 0;
        v1 = v3.length;
        _result = v2.mergeFrom(v3, v0, v1); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(byte[] p0, int p1, int p2) {
        // Registers (7 total): v3 = this, v4 = p0 (byte[]), v5 = p1 (int), v6 = p2 (int)
        _result = v4.newInstance(v5, v6); // com.google.protobuf.CodedInputStream.newInstance -> com.google.protobuf.CodedInputStream
        v0 = _result;
        _result = v3.mergeFrom(v0); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v1 = 0;
        _result = v0.checkLastTagWas(v1); // com.google.protobuf.CodedInputStream.checkLastTagWas -> void
        return v3;
        v0 = _exception;
        throw v0;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "Reading from a byte array threw an IOException (should never happen).";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(byte[] p0, int p1, int p2, com.google.protobuf.ExtensionRegistryLite p3) {
        // Registers (8 total): v3 = this, v4 = p0 (byte[]), v5 = p1 (int), v6 = p2 (int), v7 = p3 (com.google.protobuf.ExtensionRegistryLite)
        _result = v4.newInstance(v5, v6); // com.google.protobuf.CodedInputStream.newInstance -> com.google.protobuf.CodedInputStream
        v0 = _result;
        _result = v3.mergeFrom(v0, v7); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v1 = 0;
        _result = v0.checkLastTagWas(v1); // com.google.protobuf.CodedInputStream.checkLastTagWas -> void
        return v3;
        v0 = _exception;
        throw v0;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "Reading from a byte array threw an IOException (should never happen).";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
    }

    public com.google.protobuf.AbstractMessageLite$Builder mergeFrom(byte[] p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (5 total): v2 = this, v3 = p0 (byte[]), v4 = p1 (com.google.protobuf.ExtensionRegistryLite)
        v0 = 0;
        v1 = v3.length;
        _result = v2.mergeFrom(v3, v0, v1, v4); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.ByteString p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.ByteString)
        _result = v1.mergeFrom(v2); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.ByteString p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.ByteString), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.mergeFrom(v2, v3); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream)
        _result = v1.mergeFrom(v2); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (com.google.protobuf.CodedInputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.mergeFrom(v2, v3); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(java.io.InputStream p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.io.InputStream)
        _result = v1.mergeFrom(v2); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(java.io.InputStream p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.io.InputStream), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.mergeFrom(v2, v3); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(byte[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (byte[])
        _result = v1.mergeFrom(v2); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(byte[] p0, int p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (byte[]), v3 = p1 (int), v4 = p2 (int)
        _result = v1.mergeFrom(v2, v3, v4); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(byte[] p0, int p1, int p2, com.google.protobuf.ExtensionRegistryLite p3) {
        // Registers (6 total): v1 = this, v2 = p0 (byte[]), v3 = p1 (int), v4 = p2 (int), v5 = p3 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.mergeFrom(v2, v3, v4, v5); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder mergeFrom(byte[] p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (4 total): v1 = this, v2 = p0 (byte[]), v3 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.mergeFrom(v2, v3); // com.google.protobuf.AbstractMessageLite$Builder.mergeFrom -> com.google.protobuf.AbstractMessageLite$Builder
        v0 = _result;
        return v0;
    }

}