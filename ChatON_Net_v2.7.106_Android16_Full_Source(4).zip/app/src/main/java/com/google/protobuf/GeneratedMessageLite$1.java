package com.google.protobuf;

/**
 * Original SourceFile: GeneratedMessageLite.java
 * Descriptor: Lcom/google/protobuf/GeneratedMessageLite$1;
 */
class GeneratedMessageLite$1 {
    static final int[] $SwitchMap$com$google$protobuf$WireFormat$JavaType;

    static {
        _result = this.values(); // com.google.protobuf.WireFormat$JavaType.values -> com.google.protobuf.WireFormat$JavaType[]
        v0 = _result;
        v0 = v0.length;
        v0 = new int[][size=v0];
        com.google.protobuf.GeneratedMessageLite$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType = v0; // :int[]
        v0 = com.google.protobuf.GeneratedMessageLite$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        v1 = com.google.protobuf.WireFormat$JavaType.MESSAGE; // :com.google.protobuf.WireFormat$JavaType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v1 = _result;
        v2 = 1;
        v0[v1] = v2;
        v0 = com.google.protobuf.GeneratedMessageLite$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        v1 = com.google.protobuf.WireFormat$JavaType.ENUM; // :com.google.protobuf.WireFormat$JavaType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v1 = _result;
        v2 = 2;
        v0[v1] = v2;
        return;
        v0 = _exception;
        // goto L_001f
        v0 = _exception;
        // goto L_0014
    }

}