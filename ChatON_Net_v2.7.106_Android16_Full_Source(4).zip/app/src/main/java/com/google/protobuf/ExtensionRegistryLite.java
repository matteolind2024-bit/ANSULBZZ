package com.google.protobuf;

/**
 * Original SourceFile: ExtensionRegistryLite.java
 * Descriptor: Lcom/google/protobuf/ExtensionRegistryLite;
 */
public class ExtensionRegistryLite {
    private static final com.google.protobuf.ExtensionRegistryLite EMPTY;
    private final java.util.Map extensionsByNumber;

    static {
        v0 = new com.google.protobuf.ExtensionRegistryLite;
        v1 = 1;
        _result = v0.<init>(v1); // com.google.protobuf.ExtensionRegistryLite.<init> -> void
        com.google.protobuf.ExtensionRegistryLite.EMPTY = v0; // :com.google.protobuf.ExtensionRegistryLite
        return;
    }

    ExtensionRegistryLite() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        v1.extensionsByNumber = v0; // com.google.protobuf.ExtensionRegistryLite.extensionsByNumber:java.util.Map
        return;
    }

    ExtensionRegistryLite(com.google.protobuf.ExtensionRegistryLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.ExtensionRegistryLite)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = com.google.protobuf.ExtensionRegistryLite.EMPTY; // :com.google.protobuf.ExtensionRegistryLite
        if (v2 != v0) /* goto L_000e */;
        _result = this.emptyMap(); // java.util.Collections.emptyMap -> java.util.Map
        v0 = _result;
        v1.extensionsByNumber = v0; // com.google.protobuf.ExtensionRegistryLite.extensionsByNumber:java.util.Map
        return;
        v0 = v2.extensionsByNumber; // com.google.protobuf.ExtensionRegistryLite.extensionsByNumber:java.util.Map
        _result = v0.unmodifiableMap(); // java.util.Collections.unmodifiableMap -> java.util.Map
        v0 = _result;
        v1.extensionsByNumber = v0; // com.google.protobuf.ExtensionRegistryLite.extensionsByNumber:java.util.Map
        // goto L_000d
    }

    private ExtensionRegistryLite(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        _result = this.emptyMap(); // java.util.Collections.emptyMap -> java.util.Map
        v0 = _result;
        v1.extensionsByNumber = v0; // com.google.protobuf.ExtensionRegistryLite.extensionsByNumber:java.util.Map
        return;
    }

    public static com.google.protobuf.ExtensionRegistryLite getEmptyRegistry() {
        v0 = com.google.protobuf.ExtensionRegistryLite.EMPTY; // :com.google.protobuf.ExtensionRegistryLite
        return v0;
    }

    public static com.google.protobuf.ExtensionRegistryLite newInstance() {
        v0 = new com.google.protobuf.ExtensionRegistryLite;
        _result = v0.<init>(); // com.google.protobuf.ExtensionRegistryLite.<init> -> void
        return v0;
    }

    public final void add(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (6 total): v4 = this, v5 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        v0 = v4.extensionsByNumber; // com.google.protobuf.ExtensionRegistryLite.extensionsByNumber:java.util.Map
        v1 = new com.google.protobuf.ExtensionRegistryLite$ObjectIntPair;
        _result = v5.getContainingTypeDefaultInstance(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.getContainingTypeDefaultInstance -> com.google.protobuf.MessageLite
        v2 = _result;
        _result = v5.getNumber(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.getNumber -> int
        v3 = _result;
        _result = v1.<init>(v2, v3); // com.google.protobuf.ExtensionRegistryLite$ObjectIntPair.<init> -> void
        _result = java.util.Map.put(v0, v1, v5); // -> java.lang.Object
        return;
    }

    public com.google.protobuf.GeneratedMessageLite$GeneratedExtension findLiteExtensionByNumber(com.google.protobuf.MessageLite p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.MessageLite), v4 = p1 (int)
        v0 = v2.extensionsByNumber; // com.google.protobuf.ExtensionRegistryLite.extensionsByNumber:java.util.Map
        v1 = new com.google.protobuf.ExtensionRegistryLite$ObjectIntPair;
        _result = v1.<init>(v3, v4); // com.google.protobuf.ExtensionRegistryLite$ObjectIntPair.<init> -> void
        _result = java.util.Map.get(v0, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.GeneratedMessageLite$GeneratedExtension) v0;
        return v0;
    }

    public com.google.protobuf.ExtensionRegistryLite getUnmodifiable() {
        // Registers (2 total): v1 = this
        v0 = new com.google.protobuf.ExtensionRegistryLite;
        _result = v0.<init>(v1); // com.google.protobuf.ExtensionRegistryLite.<init> -> void
        return v0;
    }

}