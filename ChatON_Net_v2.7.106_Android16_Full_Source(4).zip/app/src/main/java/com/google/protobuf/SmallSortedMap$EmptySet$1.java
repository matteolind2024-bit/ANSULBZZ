package com.google.protobuf;

/**
 * Original SourceFile: SmallSortedMap.java
 * Descriptor: Lcom/google/protobuf/SmallSortedMap$EmptySet$1;
 */
final class SmallSortedMap$EmptySet$1 implements java.util.Iterator {
    SmallSortedMap$EmptySet$1() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean hasNext() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public java.lang.Object next() {
        // Registers (2 total): v1 = this
        v0 = new java.util.NoSuchElementException;
        _result = v0.<init>(); // java.util.NoSuchElementException.<init> -> void
        throw v0;
    }

    public void remove() {
        // Registers (2 total): v1 = this
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

}