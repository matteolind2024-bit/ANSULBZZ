package com.google.protobuf;

/**
 * Original SourceFile: SmallSortedMap.java
 * Descriptor: Lcom/google/protobuf/SmallSortedMap;
 */
class SmallSortedMap extends java.util.AbstractMap {
    private java.util.List entryList;
    private boolean isImmutable;
    private volatile com.google.protobuf.SmallSortedMap$EntrySet lazyEntrySet;
    private final int maxArraySize;
    private java.util.Map overflowEntries;

    private SmallSortedMap(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.<init>(); // java.util.AbstractMap.<init> -> void
        v1.maxArraySize = v2; // com.google.protobuf.SmallSortedMap.maxArraySize:int
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        v1.entryList = v0; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = this.emptyMap(); // java.util.Collections.emptyMap -> java.util.Map
        v0 = _result;
        v1.overflowEntries = v0; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        return;
    }

    SmallSortedMap(int p0, com.google.protobuf.SmallSortedMap$1 p1) {
        // Registers (3 total): v0 = this, v1 = p0 (int), v2 = p1 (com.google.protobuf.SmallSortedMap$1)
        _result = v0.<init>(v1); // com.google.protobuf.SmallSortedMap.<init> -> void
        return;
    }

    static void access$200(com.google.protobuf.SmallSortedMap p0) {
        // Registers (1 total): v0 = p0 (com.google.protobuf.SmallSortedMap)
        _result = v0.checkMutable(); // com.google.protobuf.SmallSortedMap.checkMutable -> void
        return;
    }

    static java.util.List access$400(com.google.protobuf.SmallSortedMap p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.SmallSortedMap)
        v0 = v1.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        return v0;
    }

    static java.lang.Object access$500(com.google.protobuf.SmallSortedMap p0, int p1) {
        // Registers (3 total): v1 = p0 (com.google.protobuf.SmallSortedMap), v2 = p1 (int)
        _result = v1.removeArrayEntryAt(v2); // com.google.protobuf.SmallSortedMap.removeArrayEntryAt -> java.lang.Object
        v0 = _result;
        return v0;
    }

    static java.util.Map access$600(com.google.protobuf.SmallSortedMap p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.SmallSortedMap)
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        return v0;
    }

    private int binarySearchInArray(java.lang.Comparable p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.Comparable)
        v2 = 0;
        v0 = v5.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        v1 = binOpLit8_0xd8(v0, -1);
        if (v1 < 0) /* goto L_0025 */;
        v0 = v5.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.get(v0, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.SmallSortedMap$Entry) v0;
        _result = v0.getKey(); // com.google.protobuf.SmallSortedMap$Entry.getKey -> java.lang.Comparable
        v0 = _result;
        _result = java.lang.Comparable.compareTo(v6, v0); // -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0021 */;
        v0 = binOpLit8_0xd8(v1, 2);
        v0 = unaryOp_0x7b(v0);
        return v0;
        if (v0 != 0) /* goto L_0025 */;
        v0 = v1;
        // goto L_0020
        if (v2 > v1) /* goto L_004d */;
        v0 = binOp_0x90(v2, v1);
        v3 = binOpLit8_0xdb(v0, 2);
        v0 = v5.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.get(v0, v3); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.SmallSortedMap$Entry) v0;
        _result = v0.getKey(); // com.google.protobuf.SmallSortedMap$Entry.getKey -> java.lang.Comparable
        v0 = _result;
        _result = java.lang.Comparable.compareTo(v6, v0); // -> int
        v0 = _result;
        if (v0 >= 0) /* goto L_0043 */;
        v0 = binOpLit8_0xd8(v3, -1);
        v1 = v2;
        v2 = v1;
        v1 = v0;
        // goto L_0025
        if (v0 <= 0) /* goto L_004b */;
        v0 = binOpLit8_0xd8(v3, 1);
        v4 = v1;
        v1 = v0;
        v0 = v4;
        // goto L_0040
        v0 = v3;
        // goto L_0020
        v0 = binOpLit8_0xd8(v2, 1);
        v0 = unaryOp_0x7b(v0);
        // goto L_0020
    }

    private void checkMutable() {
        // Registers (2 total): v1 = this
        v0 = v1.isImmutable; // com.google.protobuf.SmallSortedMap.isImmutable:boolean
        if (v0 == 0) /* goto L_000a */;
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
        return;
    }

    private void ensureEntryArrayMutable() {
        // Registers (3 total): v2 = this
        _result = v2.checkMutable(); // com.google.protobuf.SmallSortedMap.checkMutable -> void
        v0 = v2.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001a */;
        v0 = v2.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        v0 = (v0 instanceof java.util.ArrayList);
        if (v0 != 0) /* goto L_001a */;
        v0 = new java.util.ArrayList;
        v1 = v2.maxArraySize; // com.google.protobuf.SmallSortedMap.maxArraySize:int
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v2.entryList = v0; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        return;
    }

    private java.util.SortedMap getOverflowEntriesMutable() {
        // Registers (2 total): v1 = this
        _result = v1.checkMutable(); // com.google.protobuf.SmallSortedMap.checkMutable -> void
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0018 */;
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        v0 = (v0 instanceof java.util.TreeMap);
        if (v0 != 0) /* goto L_0018 */;
        v0 = new java.util.TreeMap;
        _result = v0.<init>(); // java.util.TreeMap.<init> -> void
        v1.overflowEntries = v0; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        v0 = (java.util.SortedMap) v0;
        return v0;
    }

    static com.google.protobuf.SmallSortedMap newFieldMap(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = new com.google.protobuf.SmallSortedMap$1;
        _result = v0.<init>(v1); // com.google.protobuf.SmallSortedMap$1.<init> -> void
        return v0;
    }

    static com.google.protobuf.SmallSortedMap newInstanceForTest(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = new com.google.protobuf.SmallSortedMap;
        _result = v0.<init>(v1); // com.google.protobuf.SmallSortedMap.<init> -> void
        return v0;
    }

    private java.lang.Object removeArrayEntryAt(int p0) {
        // Registers (7 total): v5 = this, v6 = p0 (int)
        _result = v5.checkMutable(); // com.google.protobuf.SmallSortedMap.checkMutable -> void
        v0 = v5.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.remove(v0, v6); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.SmallSortedMap$Entry) v0;
        _result = v0.getValue(); // com.google.protobuf.SmallSortedMap$Entry.getValue -> java.lang.Object
        v1 = _result;
        v0 = v5.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0036 */;
        _result = v5.getOverflowEntriesMutable(); // com.google.protobuf.SmallSortedMap.getOverflowEntriesMutable -> java.util.SortedMap
        v0 = _result;
        _result = java.util.SortedMap.entrySet(v0); // -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v2 = _result;
        v3 = v5.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        v4 = new com.google.protobuf.SmallSortedMap$Entry;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = v4.<init>(v5, v0); // com.google.protobuf.SmallSortedMap$Entry.<init> -> void
        _result = java.util.List.add(v3, v4); // -> boolean
        _result = java.util.Iterator.remove(v2); // -> void
        return v1;
    }

    public void clear() {
        // Registers (2 total): v1 = this
        _result = v1.checkMutable(); // com.google.protobuf.SmallSortedMap.checkMutable -> void
        v0 = v1.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0010 */;
        v0 = v1.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.clear(v0); // -> void
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_001d */;
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.clear(v0); // -> void
        return;
    }

    public boolean containsKey(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v2 = (java.lang.Comparable) v2;
        _result = v1.binarySearchInArray(v2); // com.google.protobuf.SmallSortedMap.binarySearchInArray -> int
        v0 = _result;
        if (v0 >= 0) /* goto L_0010 */;
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.containsKey(v0, v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0012 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0011
    }

    public java.util.Set entrySet() {
        // Registers (3 total): v2 = this
        v0 = v2.lazyEntrySet; // com.google.protobuf.SmallSortedMap.lazyEntrySet:com.google.protobuf.SmallSortedMap$EntrySet
        if (v0 != 0) /* goto L_000c */;
        v0 = new com.google.protobuf.SmallSortedMap$EntrySet;
        v1 = 0;
        _result = v0.<init>(v2, v1); // com.google.protobuf.SmallSortedMap$EntrySet.<init> -> void
        v2.lazyEntrySet = v0; // com.google.protobuf.SmallSortedMap.lazyEntrySet:com.google.protobuf.SmallSortedMap$EntrySet
        v0 = v2.lazyEntrySet; // com.google.protobuf.SmallSortedMap.lazyEntrySet:com.google.protobuf.SmallSortedMap$EntrySet
        return v0;
    }

    public java.lang.Object get(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v3 = (java.lang.Comparable) v3;
        _result = v2.binarySearchInArray(v3); // com.google.protobuf.SmallSortedMap.binarySearchInArray -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0015 */;
        v1 = v2.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.get(v1, v0); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.SmallSortedMap$Entry) v0;
        _result = v0.getValue(); // com.google.protobuf.SmallSortedMap$Entry.getValue -> java.lang.Object
        v0 = _result;
        return v0;
        v0 = v2.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.get(v0, v3); // -> java.lang.Object
        v0 = _result;
        // goto L_0014
    }

    public java.util.Map$Entry getArrayEntryAt(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.get(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        return v0;
    }

    public int getNumArrayEntries() {
        // Registers (2 total): v1 = this
        v0 = v1.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        return v0;
    }

    public int getNumOverflowEntries() {
        // Registers (2 total): v1 = this
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.size(v0); // -> int
        v0 = _result;
        return v0;
    }

    public java.lang.Iterable getOverflowEntries() {
        // Registers (2 total): v1 = this
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000d */;
        _result = this.iterable(); // com.google.protobuf.SmallSortedMap$EmptySet.iterable -> java.lang.Iterable
        v0 = _result;
        return v0;
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.entrySet(v0); // -> java.util.Set
        v0 = _result;
        // goto L_000c
    }

    public boolean isImmutable() {
        // Registers (2 total): v1 = this
        v0 = v1.isImmutable; // com.google.protobuf.SmallSortedMap.isImmutable:boolean
        return v0;
    }

    public void makeImmutable() {
        // Registers (2 total): v1 = this
        v0 = v1.isImmutable; // com.google.protobuf.SmallSortedMap.isImmutable:boolean
        if (v0 != 0) /* goto L_0015 */;
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0016 */;
        _result = this.emptyMap(); // java.util.Collections.emptyMap -> java.util.Map
        v0 = _result;
        v1.overflowEntries = v0; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        v0 = 1;
        v1.isImmutable = v0; // com.google.protobuf.SmallSortedMap.isImmutable:boolean
        return;
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = v0.unmodifiableMap(); // java.util.Collections.unmodifiableMap -> java.util.Map
        v0 = _result;
        // goto L_0010
    }

    public java.lang.Object put(java.lang.Comparable p0, java.lang.Object p1) {
        // Registers (7 total): v4 = this, v5 = p0 (java.lang.Comparable), v6 = p1 (java.lang.Object)
        _result = v4.checkMutable(); // com.google.protobuf.SmallSortedMap.checkMutable -> void
        _result = v4.binarySearchInArray(v5); // com.google.protobuf.SmallSortedMap.binarySearchInArray -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0016 */;
        v1 = v4.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.get(v1, v0); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.SmallSortedMap$Entry) v0;
        _result = v0.setValue(v6); // com.google.protobuf.SmallSortedMap$Entry.setValue -> java.lang.Object
        v0 = _result;
        return v0;
        _result = v4.ensureEntryArrayMutable(); // com.google.protobuf.SmallSortedMap.ensureEntryArrayMutable -> void
        v0 = binOpLit8_0xd8(v0, 1);
        v1 = unaryOp_0x7b(v0);
        v0 = v4.maxArraySize; // com.google.protobuf.SmallSortedMap.maxArraySize:int
        if (v1 < v0) /* goto L_0029 */;
        _result = v4.getOverflowEntriesMutable(); // com.google.protobuf.SmallSortedMap.getOverflowEntriesMutable -> java.util.SortedMap
        v0 = _result;
        _result = java.util.SortedMap.put(v0, v5, v6); // -> java.lang.Object
        v0 = _result;
        // goto L_0015
        v0 = v4.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        v2 = v4.maxArraySize; // com.google.protobuf.SmallSortedMap.maxArraySize:int
        if (v0 != v2) /* goto L_004e */;
        v0 = v4.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        v2 = v4.maxArraySize; // com.google.protobuf.SmallSortedMap.maxArraySize:int
        v2 = binOpLit8_0xd8(v2, -1);
        _result = java.util.List.remove(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.SmallSortedMap$Entry) v0;
        _result = v4.getOverflowEntriesMutable(); // com.google.protobuf.SmallSortedMap.getOverflowEntriesMutable -> java.util.SortedMap
        v2 = _result;
        _result = v0.getKey(); // com.google.protobuf.SmallSortedMap$Entry.getKey -> java.lang.Comparable
        v3 = _result;
        _result = v0.getValue(); // com.google.protobuf.SmallSortedMap$Entry.getValue -> java.lang.Object
        v0 = _result;
        _result = java.util.SortedMap.put(v2, v3, v0); // -> java.lang.Object
        v0 = v4.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        v2 = new com.google.protobuf.SmallSortedMap$Entry;
        _result = v2.<init>(v4, v5, v6); // com.google.protobuf.SmallSortedMap$Entry.<init> -> void
        _result = java.util.List.add(v0, v1, v2); // -> void
        v0 = 0;
        // goto L_0015
    }

    public java.lang.Object put(java.lang.Object p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (java.lang.Object)
        v2 = (java.lang.Comparable) v2;
        _result = v1.put(v2, v3); // com.google.protobuf.SmallSortedMap.put -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object remove(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v1.checkMutable(); // com.google.protobuf.SmallSortedMap.checkMutable -> void
        v2 = (java.lang.Comparable) v2;
        _result = v1.binarySearchInArray(v2); // com.google.protobuf.SmallSortedMap.binarySearchInArray -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0010 */;
        _result = v1.removeArrayEntryAt(v0); // com.google.protobuf.SmallSortedMap.removeArrayEntryAt -> java.lang.Object
        v0 = _result;
        return v0;
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.isEmpty(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001a */;
        v0 = 0;
        // goto L_000f
        v0 = v1.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.remove(v0, v2); // -> java.lang.Object
        v0 = _result;
        // goto L_000f
    }

    public int size() {
        // Registers (3 total): v2 = this
        v0 = v2.entryList; // com.google.protobuf.SmallSortedMap.entryList:java.util.List
        _result = java.util.List.size(v0); // -> int
        v0 = _result;
        v1 = v2.overflowEntries; // com.google.protobuf.SmallSortedMap.overflowEntries:java.util.Map
        _result = java.util.Map.size(v1); // -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

}