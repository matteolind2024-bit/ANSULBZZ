package com.google.protobuf;

/**
 * Original SourceFile: InvalidProtocolBufferException.java
 * Descriptor: Lcom/google/protobuf/InvalidProtocolBufferException;
 */
public class InvalidProtocolBufferException extends java.io.IOException {
    private static final long serialVersionUID;

    public InvalidProtocolBufferException(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        _result = v0.<init>(v1); // java.io.IOException.<init> -> void
        return;
    }

    static com.google.protobuf.InvalidProtocolBufferException invalidEndTag() {
        v0 = new com.google.protobuf.InvalidProtocolBufferException;
        v1 = "Protocol message end-group tag did not match expected tag.";
        _result = v0.<init>(v1); // com.google.protobuf.InvalidProtocolBufferException.<init> -> void
        return v0;
    }

    static com.google.protobuf.InvalidProtocolBufferException invalidTag() {
        v0 = new com.google.protobuf.InvalidProtocolBufferException;
        v1 = "Protocol message contained an invalid tag (zero).";
        _result = v0.<init>(v1); // com.google.protobuf.InvalidProtocolBufferException.<init> -> void
        return v0;
    }

    static com.google.protobuf.InvalidProtocolBufferException invalidWireType() {
        v0 = new com.google.protobuf.InvalidProtocolBufferException;
        v1 = "Protocol message tag had invalid wire type.";
        _result = v0.<init>(v1); // com.google.protobuf.InvalidProtocolBufferException.<init> -> void
        return v0;
    }

    static com.google.protobuf.InvalidProtocolBufferException malformedVarint() {
        v0 = new com.google.protobuf.InvalidProtocolBufferException;
        v1 = "CodedInputStream encountered a malformed varint.";
        _result = v0.<init>(v1); // com.google.protobuf.InvalidProtocolBufferException.<init> -> void
        return v0;
    }

    static com.google.protobuf.InvalidProtocolBufferException negativeSize() {
        v0 = new com.google.protobuf.InvalidProtocolBufferException;
        v1 = "CodedInputStream encountered an embedded string or message which claimed to have negative size.";
        _result = v0.<init>(v1); // com.google.protobuf.InvalidProtocolBufferException.<init> -> void
        return v0;
    }

    static com.google.protobuf.InvalidProtocolBufferException recursionLimitExceeded() {
        v0 = new com.google.protobuf.InvalidProtocolBufferException;
        v1 = "Protocol message had too many levels of nesting.  May be malicious.  Use CodedInputStream.setRecursionLimit() to increase the depth limit.";
        _result = v0.<init>(v1); // com.google.protobuf.InvalidProtocolBufferException.<init> -> void
        return v0;
    }

    static com.google.protobuf.InvalidProtocolBufferException sizeLimitExceeded() {
        v0 = new com.google.protobuf.InvalidProtocolBufferException;
        v1 = "Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.";
        _result = v0.<init>(v1); // com.google.protobuf.InvalidProtocolBufferException.<init> -> void
        return v0;
    }

    static com.google.protobuf.InvalidProtocolBufferException truncatedMessage() {
        v0 = new com.google.protobuf.InvalidProtocolBufferException;
        v1 = "While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either than the input has been truncated or that an embedded message misreported its own length.";
        _result = v0.<init>(v1); // com.google.protobuf.InvalidProtocolBufferException.<init> -> void
        return v0;
    }

}