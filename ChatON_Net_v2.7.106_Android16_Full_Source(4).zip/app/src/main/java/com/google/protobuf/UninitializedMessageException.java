package com.google.protobuf;

/**
 * Original SourceFile: UninitializedMessageException.java
 * Descriptor: Lcom/google/protobuf/UninitializedMessageException;
 */
public class UninitializedMessageException extends java.lang.RuntimeException {
    private static final long serialVersionUID;
    private final java.util.List missingFields;

    public UninitializedMessageException(com.google.protobuf.MessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.MessageLite)
        v0 = "Message was missing required fields.  (Lite runtime could not determine which fields were missing).";
        _result = v1.<init>(v0); // java.lang.RuntimeException.<init> -> void
        v0 = 0;
        v1.missingFields = v0; // com.google.protobuf.UninitializedMessageException.missingFields:java.util.List
        return;
    }

    public UninitializedMessageException(java.util.List p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.List)
        _result = v2.buildDescription(); // com.google.protobuf.UninitializedMessageException.buildDescription -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.RuntimeException.<init> -> void
        v1.missingFields = v2; // com.google.protobuf.UninitializedMessageException.missingFields:java.util.List
        return;
    }

    private static java.lang.String buildDescription(java.util.List p0) {
        // Registers (6 total): v5 = p0 (java.util.List)
        v2 = new java.lang.StringBuilder;
        v0 = "Message missing required fields: ";
        _result = v2.<init>(v0); // java.lang.StringBuilder.<init> -> void
        v0 = 1;
        _result = java.util.List.iterator(v5); // -> java.util.Iterator
        v3 = _result;
        v1 = v0;
        _result = java.util.Iterator.hasNext(v3); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0026 */;
        _result = java.util.Iterator.next(v3); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        if (v1 == 0) /* goto L_0020 */;
        v1 = 0;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_000d
        v4 = ", ";
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_001c
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.InvalidProtocolBufferException asInvalidProtocolBufferException() {
        // Registers (3 total): v2 = this
        v0 = new com.google.protobuf.InvalidProtocolBufferException;
        _result = v2.getMessage(); // com.google.protobuf.UninitializedMessageException.getMessage -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // com.google.protobuf.InvalidProtocolBufferException.<init> -> void
        return v0;
    }

    public java.util.List getMissingFields() {
        // Registers (2 total): v1 = this
        v0 = v1.missingFields; // com.google.protobuf.UninitializedMessageException.missingFields:java.util.List
        _result = v0.unmodifiableList(); // java.util.Collections.unmodifiableList -> java.util.List
        v0 = _result;
        return v0;
    }

}