package com.google.protobuf;

/**
 * Original SourceFile: CodedInputStream.java
 * Descriptor: Lcom/google/protobuf/CodedInputStream;
 */
public final class CodedInputStream {
    private static final int BUFFER_SIZE;
    private static final int DEFAULT_RECURSION_LIMIT;
    private static final int DEFAULT_SIZE_LIMIT;
    private final byte[] buffer;
    private int bufferPos;
    private int bufferSize;
    private int bufferSizeAfterLimit;
    private int currentLimit;
    private final java.io.InputStream input;
    private int lastTag;
    private int recursionDepth;
    private int recursionLimit;
    private int sizeLimit;
    private int totalBytesRetired;

    private CodedInputStream(java.io.InputStream p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.io.InputStream)
        v1 = 0;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v0 = 2147483647; // 0x7fffffff
        v2.currentLimit = v0; // com.google.protobuf.CodedInputStream.currentLimit:int
        v0 = 64;
        v2.recursionLimit = v0; // com.google.protobuf.CodedInputStream.recursionLimit:int
        v0 = 0x04000000;
        v2.sizeLimit = v0; // com.google.protobuf.CodedInputStream.sizeLimit:int
        v0 = 4096;
        v0 = new byte[][size=v0];
        v2.buffer = v0; // com.google.protobuf.CodedInputStream.buffer:byte[]
        v2.bufferSize = v1; // com.google.protobuf.CodedInputStream.bufferSize:int
        v2.bufferPos = v1; // com.google.protobuf.CodedInputStream.bufferPos:int
        v2.totalBytesRetired = v1; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v2.input = v3; // com.google.protobuf.CodedInputStream.input:java.io.InputStream
        return;
    }

    private CodedInputStream(byte[] p0, int p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (byte[]), v3 = p1 (int), v4 = p2 (int)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 2147483647; // 0x7fffffff
        v1.currentLimit = v0; // com.google.protobuf.CodedInputStream.currentLimit:int
        v0 = 64;
        v1.recursionLimit = v0; // com.google.protobuf.CodedInputStream.recursionLimit:int
        v0 = 0x04000000;
        v1.sizeLimit = v0; // com.google.protobuf.CodedInputStream.sizeLimit:int
        v1.buffer = v2; // com.google.protobuf.CodedInputStream.buffer:byte[]
        v0 = binOp_0x90(v3, v4);
        v1.bufferSize = v0; // com.google.protobuf.CodedInputStream.bufferSize:int
        v1.bufferPos = v3; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = unaryOp_0x7b(v3);
        v1.totalBytesRetired = v0; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v0 = 0;
        v1.input = v0; // com.google.protobuf.CodedInputStream.input:java.io.InputStream
        return;
    }

    public static int decodeZigZag32(int p0) {
        // Registers (3 total): v2 = p0 (int)
        v0 = binOpLit8_0xe2(v2, 1);
        v1 = binOpLit8_0xdd(v2, 1);
        v1 = unaryOp_0x7b(v1);
        v0 = binOp2addr_0xb7(v0, v1);
        return v0;
    }

    public static long decodeZigZag64(long p0) {
        // Registers (6 total): v4 = p0 (long)
        v0 = 1;
        v0 = binOp_0xa5(v4, v0);
        v2 = 1L;
        v2 = binOp2addr_0xc0(v2, v4);
        v2 = unaryOp_0x7d(v2);
        v0 = binOp2addr_0xc2(v0, v2);
        return v0;
    }

    public static com.google.protobuf.CodedInputStream newInstance(java.io.InputStream p0) {
        // Registers (2 total): v1 = p0 (java.io.InputStream)
        v0 = new com.google.protobuf.CodedInputStream;
        _result = v0.<init>(v1); // com.google.protobuf.CodedInputStream.<init> -> void
        return v0;
    }

    public static com.google.protobuf.CodedInputStream newInstance(byte[] p0) {
        // Registers (3 total): v2 = p0 (byte[])
        v0 = 0;
        v1 = v2.length;
        _result = v2.newInstance(v0, v1); // com.google.protobuf.CodedInputStream.newInstance -> com.google.protobuf.CodedInputStream
        v0 = _result;
        return v0;
    }

    public static com.google.protobuf.CodedInputStream newInstance(byte[] p0, int p1, int p2) {
        // Registers (5 total): v2 = p0 (byte[]), v3 = p1 (int), v4 = p2 (int)
        v0 = new com.google.protobuf.CodedInputStream;
        _result = v0.<init>(v2, v3, v4); // com.google.protobuf.CodedInputStream.<init> -> void
        _result = v0.pushLimit(v4); // com.google.protobuf.CodedInputStream.pushLimit -> int
        return v0;
        v0 = _exception;
        v1 = new java.lang.IllegalArgumentException;
        _result = v1.<init>(v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v1;
    }

    public static int readRawVarint32(int p0, java.io.InputStream p1) {
        // Registers (6 total): v4 = p0 (int), v5 = p1 (java.io.InputStream)
        v3 = -1;
        v0 = binOpLit16_0xd5(v4, 128);
        if (v0 != 0) /* goto L_0006 */;
        return v4;
        v4 = binOpLit8_0xdd(v4, 127);
        v0 = 7;
        v1 = 32;
        if (v0 >= v1) /* goto L_0025 */;
        _result = v5.read(); // java.io.InputStream.read -> int
        v1 = _result;
        if (v1 != v3) /* goto L_0018 */;
        _result = this.truncatedMessage(); // com.google.protobuf.InvalidProtocolBufferException.truncatedMessage -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v2 = binOpLit8_0xdd(v1, 127);
        v2 = binOp2addr_0xb8(v2, v0);
        v4 = binOp2addr_0xb6(v4, v2);
        v1 = binOpLit16_0xd5(v1, 128);
        if (v1 == 0) /* goto L_0005 */;
        v0 = binOpLit8_0xd8(v0, 7);
        // goto L_0009
        v0 = binOpLit8_0xd8(v0, 7);
        v1 = 64;
        if (v0 >= v1) /* goto L_0039 */;
        _result = v5.read(); // java.io.InputStream.read -> int
        v1 = _result;
        if (v1 != v3) /* goto L_0034 */;
        _result = this.truncatedMessage(); // com.google.protobuf.InvalidProtocolBufferException.truncatedMessage -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v1 = binOpLit16_0xd5(v1, 128);
        if (v1 != 0) /* goto L_0023 */;
        // goto L_0005
        _result = this.malformedVarint(); // com.google.protobuf.InvalidProtocolBufferException.malformedVarint -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
    }

    static int readRawVarint32(java.io.InputStream p0) {
        // Registers (3 total): v2 = p0 (java.io.InputStream)
        _result = v2.read(); // java.io.InputStream.read -> int
        v0 = _result;
        v1 = -1;
        if (v0 != v1) /* goto L_000c */;
        _result = this.truncatedMessage(); // com.google.protobuf.InvalidProtocolBufferException.truncatedMessage -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        _result = v0.readRawVarint32(v2); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v0 = _result;
        return v0;
    }

    private void recomputeBufferSizeAfterLimit() {
        // Registers (3 total): v2 = this
        v0 = v2.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v1 = v2.bufferSizeAfterLimit; // com.google.protobuf.CodedInputStream.bufferSizeAfterLimit:int
        v0 = binOp2addr_0xb0(v0, v1);
        v2.bufferSize = v0; // com.google.protobuf.CodedInputStream.bufferSize:int
        v0 = v2.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v1 = v2.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v2.currentLimit; // com.google.protobuf.CodedInputStream.currentLimit:int
        if (v0 <= v1) /* goto L_001d */;
        v1 = v2.currentLimit; // com.google.protobuf.CodedInputStream.currentLimit:int
        v0 = binOp2addr_0xb1(v0, v1);
        v2.bufferSizeAfterLimit = v0; // com.google.protobuf.CodedInputStream.bufferSizeAfterLimit:int
        v0 = v2.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v1 = v2.bufferSizeAfterLimit; // com.google.protobuf.CodedInputStream.bufferSizeAfterLimit:int
        v0 = binOp2addr_0xb1(v0, v1);
        v2.bufferSize = v0; // com.google.protobuf.CodedInputStream.bufferSize:int
        return;
        v0 = 0;
        v2.bufferSizeAfterLimit = v0; // com.google.protobuf.CodedInputStream.bufferSizeAfterLimit:int
        // goto L_001c
    }

    private boolean refillBuffer(boolean p0) {
        // Registers (6 total): v4 = this, v5 = p0 (boolean)
        v1 = -1;
        v2 = 0;
        v0 = v4.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v3 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        if (v0 >= v3) /* goto L_0010 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "refillBuffer() called when buffer wasn't empty.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v4.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v3 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v0 = binOp2addr_0xb0(v0, v3);
        v3 = v4.currentLimit; // com.google.protobuf.CodedInputStream.currentLimit:int
        if (v0 != v3) /* goto L_0022 */;
        if (v5 == 0) /* goto L_0020 */;
        _result = this.truncatedMessage(); // com.google.protobuf.InvalidProtocolBufferException.truncatedMessage -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v0 = v2;
        return v0;
        v0 = v4.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v3 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v0 = binOp2addr_0xb0(v0, v3);
        v4.totalBytesRetired = v0; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v4.bufferPos = v2; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = v4.input; // com.google.protobuf.CodedInputStream.input:java.io.InputStream
        if (v0 != 0) /* goto L_005b */;
        v0 = v1;
        v4.bufferSize = v0; // com.google.protobuf.CodedInputStream.bufferSize:int
        v0 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        if (v0 == 0) /* goto L_003a */;
        v0 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        if (v0 >= v1) /* goto L_0064 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "InputStream#read(byte[]) returned invalid result: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "\nThe InputStream implementation is buggy.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v4.input; // com.google.protobuf.CodedInputStream.input:java.io.InputStream
        v3 = v4.buffer; // com.google.protobuf.CodedInputStream.buffer:byte[]
        _result = v0.read(v3); // java.io.InputStream.read -> int
        v0 = _result;
        // goto L_0030
        v0 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        if (v0 != v1) /* goto L_0073 */;
        v4.bufferSize = v2; // com.google.protobuf.CodedInputStream.bufferSize:int
        if (v5 == 0) /* goto L_0071 */;
        _result = this.truncatedMessage(); // com.google.protobuf.InvalidProtocolBufferException.truncatedMessage -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v0 = v2;
        // goto L_0021
        _result = v4.recomputeBufferSizeAfterLimit(); // com.google.protobuf.CodedInputStream.recomputeBufferSizeAfterLimit -> void
        v0 = v4.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v1 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v4.bufferSizeAfterLimit; // com.google.protobuf.CodedInputStream.bufferSizeAfterLimit:int
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v4.sizeLimit; // com.google.protobuf.CodedInputStream.sizeLimit:int
        if (v0 > v1) /* goto L_0084 */;
        if (v0 >= 0) /* goto L_0089 */;
        _result = this.sizeLimitExceeded(); // com.google.protobuf.InvalidProtocolBufferException.sizeLimitExceeded -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v0 = 1;
        // goto L_0021
    }

    public void checkLastTagWas(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.lastTag; // com.google.protobuf.CodedInputStream.lastTag:int
        if (v0 == v2) /* goto L_0009 */;
        _result = this.invalidEndTag(); // com.google.protobuf.InvalidProtocolBufferException.invalidEndTag -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        return;
    }

    public int getBytesUntilLimit() {
        // Registers (3 total): v2 = this
        v0 = v2.currentLimit; // com.google.protobuf.CodedInputStream.currentLimit:int
        v1 = 2147483647; // 0x7fffffff
        if (v0 != v1) /* goto L_0009 */;
        v0 = -1;
        return v0;
        v0 = v2.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v1 = v2.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v2.currentLimit; // com.google.protobuf.CodedInputStream.currentLimit:int
        v0 = binOp_0x91(v1, v0);
        // goto L_0008
    }

    public int getTotalBytesRead() {
        // Registers (3 total): v2 = this
        v0 = v2.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v1 = v2.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public boolean isAtEnd() {
        // Registers (4 total): v3 = this
        v0 = 0;
        v1 = v3.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v2 = v3.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        if (v1 != v2) /* goto L_000e */;
        _result = v3.refillBuffer(v0); // com.google.protobuf.CodedInputStream.refillBuffer -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000e */;
        v0 = 1;
        return v0;
    }

    public void popLimit(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.currentLimit = v1; // com.google.protobuf.CodedInputStream.currentLimit:int
        _result = v0.recomputeBufferSizeAfterLimit(); // com.google.protobuf.CodedInputStream.recomputeBufferSizeAfterLimit -> void
        return;
    }

    public int pushLimit(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        if (v3 >= 0) /* goto L_0007 */;
        _result = this.negativeSize(); // com.google.protobuf.InvalidProtocolBufferException.negativeSize -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v0 = v2.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v1 = v2.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = binOp2addr_0xb0(v0, v3);
        v1 = v2.currentLimit; // com.google.protobuf.CodedInputStream.currentLimit:int
        if (v0 <= v1) /* goto L_0016 */;
        _result = this.truncatedMessage(); // com.google.protobuf.InvalidProtocolBufferException.truncatedMessage -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v2.currentLimit = v0; // com.google.protobuf.CodedInputStream.currentLimit:int
        _result = v2.recomputeBufferSizeAfterLimit(); // com.google.protobuf.CodedInputStream.recomputeBufferSizeAfterLimit -> void
        return v1;
    }

    public boolean readBool() {
        // Registers (2 total): v1 = this
        _result = v1.readRawVarint32(); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0008 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public com.google.protobuf.ByteString readBytes() {
        // Registers (4 total): v3 = this
        _result = v3.readRawVarint32(); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v1 = _result;
        if (v1 != 0) /* goto L_0009 */;
        v0 = com.google.protobuf.ByteString.EMPTY; // :com.google.protobuf.ByteString
        return v0;
        v0 = v3.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v2 = v3.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb1(v0, v2);
        if (v1 > v0) /* goto L_0020 */;
        if (v1 <= 0) /* goto L_0020 */;
        v0 = v3.buffer; // com.google.protobuf.CodedInputStream.buffer:byte[]
        v2 = v3.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        _result = v0.copyFrom(v2, v1); // com.google.protobuf.ByteString.copyFrom -> com.google.protobuf.ByteString
        v0 = _result;
        v2 = v3.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v1 = binOp2addr_0xb0(v1, v2);
        v3.bufferPos = v1; // com.google.protobuf.CodedInputStream.bufferPos:int
        // goto L_0008
        _result = v3.readRawBytes(v1); // com.google.protobuf.CodedInputStream.readRawBytes -> byte[]
        v0 = _result;
        _result = v0.copyFrom(); // com.google.protobuf.ByteString.copyFrom -> com.google.protobuf.ByteString
        v0 = _result;
        // goto L_0008
    }

    public double readDouble() {
        // Registers (3 total): v2 = this
        _result = v2.readRawLittleEndian64(); // com.google.protobuf.CodedInputStream.readRawLittleEndian64 -> long
        v0 = _result;
        _result = v0.longBitsToDouble(v1); // java.lang.Double.longBitsToDouble -> double
        v0 = _result;
        return v0;
    }

    public int readEnum() {
        // Registers (2 total): v1 = this
        _result = v1.readRawVarint32(); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v0 = _result;
        return v0;
    }

    public int readFixed32() {
        // Registers (2 total): v1 = this
        _result = v1.readRawLittleEndian32(); // com.google.protobuf.CodedInputStream.readRawLittleEndian32 -> int
        v0 = _result;
        return v0;
    }

    public long readFixed64() {
        // Registers (3 total): v2 = this
        _result = v2.readRawLittleEndian64(); // com.google.protobuf.CodedInputStream.readRawLittleEndian64 -> long
        v0 = _result;
        return v0;
    }

    public float readFloat() {
        // Registers (2 total): v1 = this
        _result = v1.readRawLittleEndian32(); // com.google.protobuf.CodedInputStream.readRawLittleEndian32 -> int
        v0 = _result;
        _result = v0.intBitsToFloat(); // java.lang.Float.intBitsToFloat -> float
        v0 = _result;
        return v0;
    }

    public void readGroup(int p0, com.google.protobuf.MessageLite$Builder p1, com.google.protobuf.ExtensionRegistryLite p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (com.google.protobuf.MessageLite$Builder), v5 = p2 (com.google.protobuf.ExtensionRegistryLite)
        v0 = v2.recursionDepth; // com.google.protobuf.CodedInputStream.recursionDepth:int
        v1 = v2.recursionLimit; // com.google.protobuf.CodedInputStream.recursionLimit:int
        if (v0 < v1) /* goto L_000b */;
        _result = this.recursionLimitExceeded(); // com.google.protobuf.InvalidProtocolBufferException.recursionLimitExceeded -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v0 = v2.recursionDepth; // com.google.protobuf.CodedInputStream.recursionDepth:int
        v0 = binOpLit8_0xd8(v0, 1);
        v2.recursionDepth = v0; // com.google.protobuf.CodedInputStream.recursionDepth:int
        _result = com.google.protobuf.MessageLite$Builder.mergeFrom(v4, v2, v5); // -> com.google.protobuf.MessageLite$Builder
        v0 = 4;
        _result = v3.makeTag(v0); // com.google.protobuf.WireFormat.makeTag -> int
        v0 = _result;
        _result = v2.checkLastTagWas(v0); // com.google.protobuf.CodedInputStream.checkLastTagWas -> void
        v0 = v2.recursionDepth; // com.google.protobuf.CodedInputStream.recursionDepth:int
        v0 = binOpLit8_0xd8(v0, -1);
        v2.recursionDepth = v0; // com.google.protobuf.CodedInputStream.recursionDepth:int
        return;
    }

    public int readInt32() {
        // Registers (2 total): v1 = this
        _result = v1.readRawVarint32(); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v0 = _result;
        return v0;
    }

    public long readInt64() {
        // Registers (3 total): v2 = this
        _result = v2.readRawVarint64(); // com.google.protobuf.CodedInputStream.readRawVarint64 -> long
        v0 = _result;
        return v0;
    }

    public void readMessage(com.google.protobuf.MessageLite$Builder p0, com.google.protobuf.ExtensionRegistryLite p1) {
        // Registers (6 total): v3 = this, v4 = p0 (com.google.protobuf.MessageLite$Builder), v5 = p1 (com.google.protobuf.ExtensionRegistryLite)
        _result = v3.readRawVarint32(); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v0 = _result;
        v1 = v3.recursionDepth; // com.google.protobuf.CodedInputStream.recursionDepth:int
        v2 = v3.recursionLimit; // com.google.protobuf.CodedInputStream.recursionLimit:int
        if (v1 < v2) /* goto L_000f */;
        _result = this.recursionLimitExceeded(); // com.google.protobuf.InvalidProtocolBufferException.recursionLimitExceeded -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        _result = v3.pushLimit(v0); // com.google.protobuf.CodedInputStream.pushLimit -> int
        v0 = _result;
        v1 = v3.recursionDepth; // com.google.protobuf.CodedInputStream.recursionDepth:int
        v1 = binOpLit8_0xd8(v1, 1);
        v3.recursionDepth = v1; // com.google.protobuf.CodedInputStream.recursionDepth:int
        _result = com.google.protobuf.MessageLite$Builder.mergeFrom(v4, v3, v5); // -> com.google.protobuf.MessageLite$Builder
        v1 = 0;
        _result = v3.checkLastTagWas(v1); // com.google.protobuf.CodedInputStream.checkLastTagWas -> void
        v1 = v3.recursionDepth; // com.google.protobuf.CodedInputStream.recursionDepth:int
        v1 = binOpLit8_0xd8(v1, -1);
        v3.recursionDepth = v1; // com.google.protobuf.CodedInputStream.recursionDepth:int
        _result = v3.popLimit(v0); // com.google.protobuf.CodedInputStream.popLimit -> void
        return;
    }

    public byte readRawByte() {
        // Registers (4 total): v3 = this
        v0 = v3.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v1 = v3.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        if (v0 != v1) /* goto L_000a */;
        v0 = 1;
        _result = v3.refillBuffer(v0); // com.google.protobuf.CodedInputStream.refillBuffer -> boolean
        v0 = v3.buffer; // com.google.protobuf.CodedInputStream.buffer:byte[]
        v1 = v3.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v2 = binOpLit8_0xd8(v1, 1);
        v3.bufferPos = v2; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = v0[v1];
        return v0;
    }

    public byte[] readRawBytes(int p0) {
        // Registers (13 total): v11 = this, v12 = p0 (int)
        v10 = 4096;
        v5 = 1;
        v3 = -1;
        v1 = 0;
        if (v12 >= 0) /* goto L_000c */;
        _result = this.negativeSize(); // com.google.protobuf.InvalidProtocolBufferException.negativeSize -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v0 = v11.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v2 = v11.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb0(v0, v2);
        v0 = binOp2addr_0xb0(v0, v12);
        v2 = v11.currentLimit; // com.google.protobuf.CodedInputStream.currentLimit:int
        if (v0 <= v2) /* goto L_0026 */;
        v0 = v11.currentLimit; // com.google.protobuf.CodedInputStream.currentLimit:int
        v1 = v11.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v0 = binOp2addr_0xb1(v0, v1);
        v1 = v11.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb1(v0, v1);
        _result = v11.skipRawBytes(v0); // com.google.protobuf.CodedInputStream.skipRawBytes -> void
        _result = this.truncatedMessage(); // com.google.protobuf.InvalidProtocolBufferException.truncatedMessage -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v0 = v11.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v2 = v11.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb1(v0, v2);
        if (v12 > v0) /* goto L_003c */;
        v0 = new byte[][size=v12];
        v2 = v11.buffer; // com.google.protobuf.CodedInputStream.buffer:byte[]
        v3 = v11.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        _result = v2.arraycopy(v3, v0, v1, v12); // java.lang.System.arraycopy -> void
        v1 = v11.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v1 = binOp2addr_0xb0(v1, v12);
        v11.bufferPos = v1; // com.google.protobuf.CodedInputStream.bufferPos:int
        return v0;
        if (v12 >= v10) /* goto L_0078 */;
        v2 = new byte[][size=v12];
        v0 = v11.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v3 = v11.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb1(v0, v3);
        v3 = v11.buffer; // com.google.protobuf.CodedInputStream.buffer:byte[]
        v4 = v11.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        _result = v3.arraycopy(v4, v2, v1, v0); // java.lang.System.arraycopy -> void
        v3 = v11.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v11.bufferPos = v3; // com.google.protobuf.CodedInputStream.bufferPos:int
        _result = v11.refillBuffer(v5); // com.google.protobuf.CodedInputStream.refillBuffer -> boolean
        v3 = binOp_0x91(v12, v0);
        v4 = v11.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        if (v3 <= v4) /* goto L_006b */;
        v3 = v11.buffer; // com.google.protobuf.CodedInputStream.buffer:byte[]
        v4 = v11.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        _result = v3.arraycopy(v1, v2, v0, v4); // java.lang.System.arraycopy -> void
        v3 = v11.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v0 = binOp2addr_0xb0(v0, v3);
        v3 = v11.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v11.bufferPos = v3; // com.google.protobuf.CodedInputStream.bufferPos:int
        _result = v11.refillBuffer(v5); // com.google.protobuf.CodedInputStream.refillBuffer -> boolean
        // goto L_0053
        v3 = v11.buffer; // com.google.protobuf.CodedInputStream.buffer:byte[]
        v4 = binOp_0x91(v12, v0);
        _result = v3.arraycopy(v1, v2, v0, v4); // java.lang.System.arraycopy -> void
        v0 = binOp_0x91(v12, v0);
        v11.bufferPos = v0; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = v2;
        // goto L_003b
        v5 = v11.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v6 = v11.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v0 = v11.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v2 = v11.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v0 = binOp2addr_0xb0(v0, v2);
        v11.totalBytesRetired = v0; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v11.bufferPos = v1; // com.google.protobuf.CodedInputStream.bufferPos:int
        v11.bufferSize = v1; // com.google.protobuf.CodedInputStream.bufferSize:int
        v0 = binOp_0x91(v6, v5);
        v0 = binOp_0x91(v12, v0);
        v7 = new java.util.ArrayList;
        _result = v7.<init>(); // java.util.ArrayList.<init> -> void
        v4 = v0;
        if (v4 <= 0) /* goto L_00c1 */;
        _result = v4.min(v10); // java.lang.Math.min -> int
        v0 = _result;
        v8 = new byte[][size=v0];
        v0 = v1;
        v2 = v8.length;
        if (v0 >= v2) /* goto L_00b9 */;
        v2 = v11.input; // com.google.protobuf.CodedInputStream.input:java.io.InputStream
        if (v2 != 0) /* goto L_00a9 */;
        v2 = v3;
        if (v2 != v3) /* goto L_00b2 */;
        _result = this.truncatedMessage(); // com.google.protobuf.InvalidProtocolBufferException.truncatedMessage -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v2 = v11.input; // com.google.protobuf.CodedInputStream.input:java.io.InputStream
        v9 = v8.length;
        v9 = binOp2addr_0xb1(v9, v0);
        _result = v2.read(v8, v0, v9); // java.io.InputStream.read -> int
        v2 = _result;
        // goto L_00a2
        v9 = v11.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v9 = binOp2addr_0xb0(v9, v2);
        v11.totalBytesRetired = v9; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v0 = binOp2addr_0xb0(v0, v2);
        // goto L_009a
        v0 = v8.length;
        v0 = binOp_0x91(v4, v0);
        _result = java.util.List.add(v7, v8); // -> boolean
        v4 = v0;
        // goto L_0091
        v3 = new byte[][size=v12];
        v0 = binOp_0x91(v6, v5);
        v2 = v11.buffer; // com.google.protobuf.CodedInputStream.buffer:byte[]
        _result = v2.arraycopy(v5, v3, v1, v0); // java.lang.System.arraycopy -> void
        _result = java.util.List.iterator(v7); // -> java.util.Iterator
        v4 = _result;
        v2 = v0;
        _result = java.util.Iterator.hasNext(v4); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00e3 */;
        _result = java.util.Iterator.next(v4); // -> java.lang.Object
        v0 = _result;
        v0 = (byte[]) v0;
        v5 = v0.length;
        _result = v0.arraycopy(v1, v3, v2, v5); // java.lang.System.arraycopy -> void
        v0 = v0.length;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = v0;
        // goto L_00cf
        v0 = v3;
        // goto L_003b
    }

    public int readRawLittleEndian32() {
        // Registers (5 total): v4 = this
        _result = v4.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v0 = _result;
        _result = v4.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v1 = _result;
        _result = v4.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v2 = _result;
        _result = v4.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v3 = _result;
        v0 = binOpLit16_0xd5(v0, 255);
        v1 = binOpLit16_0xd5(v1, 255);
        v1 = binOpLit8_0xe0(v1, 8);
        v0 = binOp2addr_0xb6(v0, v1);
        v1 = binOpLit16_0xd5(v2, 255);
        v1 = binOpLit8_0xe0(v1, 16);
        v0 = binOp2addr_0xb6(v0, v1);
        v1 = binOpLit16_0xd5(v3, 255);
        v1 = binOpLit8_0xe0(v1, 24);
        v0 = binOp2addr_0xb6(v0, v1);
        return v0;
    }

    public long readRawLittleEndian64() {
        // Registers (14 total): v13 = this
        v11 = 255L;
        _result = v13.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v0 = _result;
        _result = v13.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v1 = _result;
        _result = v13.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v2 = _result;
        _result = v13.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v3 = _result;
        _result = v13.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v4 = _result;
        _result = v13.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v5 = _result;
        _result = v13.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v6 = _result;
        _result = v13.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v7 = _result;
        v8 = unaryOp_0x81(v0);
        v8 = binOp2addr_0xc0(v8, v11);
        v0 = unaryOp_0x81(v1);
        v0 = binOp2addr_0xc0(v0, v11);
        v10 = 8;
        v0 = binOp2addr_0xc3(v0, v10);
        v0 = binOp2addr_0xc1(v0, v8);
        v8 = unaryOp_0x81(v2);
        v8 = binOp2addr_0xc0(v8, v11);
        v2 = 16;
        v8 = binOp2addr_0xc3(v8, v2);
        v0 = binOp2addr_0xc1(v0, v8);
        v2 = unaryOp_0x81(v3);
        v2 = binOp2addr_0xc0(v2, v11);
        v8 = 24;
        v2 = binOp2addr_0xc3(v2, v8);
        v0 = binOp2addr_0xc1(v0, v2);
        v2 = unaryOp_0x81(v4);
        v2 = binOp2addr_0xc0(v2, v11);
        v4 = 32;
        v2 = binOp2addr_0xc3(v2, v4);
        v0 = binOp2addr_0xc1(v0, v2);
        v2 = unaryOp_0x81(v5);
        v2 = binOp2addr_0xc0(v2, v11);
        v4 = 40;
        v2 = binOp2addr_0xc3(v2, v4);
        v0 = binOp2addr_0xc1(v0, v2);
        v2 = unaryOp_0x81(v6);
        v2 = binOp2addr_0xc0(v2, v11);
        v4 = 48;
        v2 = binOp2addr_0xc3(v2, v4);
        v0 = binOp2addr_0xc1(v0, v2);
        v2 = unaryOp_0x81(v7);
        v2 = binOp2addr_0xc0(v2, v11);
        v4 = 56;
        v2 = binOp2addr_0xc3(v2, v4);
        v0 = binOp2addr_0xc1(v0, v2);
        return v0;
    }

    public int readRawVarint32() {
        // Registers (4 total): v3 = this
        _result = v3.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v0 = _result;
        if (v0 < 0) /* goto L_0007 */;
        return v0;
        v0 = binOpLit8_0xdd(v0, 127);
        _result = v3.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v1 = _result;
        if (v1 < 0) /* goto L_0013 */;
        v1 = binOpLit8_0xe0(v1, 7);
        v0 = binOp2addr_0xb6(v0, v1);
        // goto L_0006
        v1 = binOpLit8_0xdd(v1, 127);
        v1 = binOpLit8_0xe0(v1, 7);
        v0 = binOp2addr_0xb6(v0, v1);
        _result = v3.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v1 = _result;
        if (v1 < 0) /* goto L_0022 */;
        v1 = binOpLit8_0xe0(v1, 14);
        v0 = binOp2addr_0xb6(v0, v1);
        // goto L_0006
        v1 = binOpLit8_0xdd(v1, 127);
        v1 = binOpLit8_0xe0(v1, 14);
        v0 = binOp2addr_0xb6(v0, v1);
        _result = v3.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v1 = _result;
        if (v1 < 0) /* goto L_0031 */;
        v1 = binOpLit8_0xe0(v1, 21);
        v0 = binOp2addr_0xb6(v0, v1);
        // goto L_0006
        v1 = binOpLit8_0xdd(v1, 127);
        v1 = binOpLit8_0xe0(v1, 21);
        v0 = binOp2addr_0xb6(v0, v1);
        _result = v3.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v1 = _result;
        v2 = binOpLit8_0xe0(v1, 28);
        v0 = binOp2addr_0xb6(v0, v2);
        if (v1 >= 0) /* goto L_0006 */;
        v1 = 0;
        v2 = 5;
        if (v1 >= v2) /* goto L_004c */;
        _result = v3.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v2 = _result;
        if (v2 >= 0) /* goto L_0006 */;
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0040
        _result = this.malformedVarint(); // com.google.protobuf.InvalidProtocolBufferException.malformedVarint -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
    }

    public long readRawVarint64() {
        // Registers (7 total): v6 = this
        v2 = 0;
        v0 = 0L;
        v3 = 64;
        if (v2 >= v3) /* goto L_0018 */;
        _result = v6.readRawByte(); // com.google.protobuf.CodedInputStream.readRawByte -> byte
        v3 = _result;
        v4 = binOpLit8_0xdd(v3, 127);
        v4 = unaryOp_0x81(v4);
        v4 = binOp2addr_0xc3(v4, v2);
        v0 = binOp2addr_0xc1(v0, v4);
        v3 = binOpLit16_0xd5(v3, 128);
        if (v3 != 0) /* goto L_0015 */;
        return v0;
        v2 = binOpLit8_0xd8(v2, 7);
        // goto L_0003
        _result = this.malformedVarint(); // com.google.protobuf.InvalidProtocolBufferException.malformedVarint -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
    }

    public int readSFixed32() {
        // Registers (2 total): v1 = this
        _result = v1.readRawLittleEndian32(); // com.google.protobuf.CodedInputStream.readRawLittleEndian32 -> int
        v0 = _result;
        return v0;
    }

    public long readSFixed64() {
        // Registers (3 total): v2 = this
        _result = v2.readRawLittleEndian64(); // com.google.protobuf.CodedInputStream.readRawLittleEndian64 -> long
        v0 = _result;
        return v0;
    }

    public int readSInt32() {
        // Registers (2 total): v1 = this
        _result = v1.readRawVarint32(); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v0 = _result;
        _result = v0.decodeZigZag32(); // com.google.protobuf.CodedInputStream.decodeZigZag32 -> int
        v0 = _result;
        return v0;
    }

    public long readSInt64() {
        // Registers (3 total): v2 = this
        _result = v2.readRawVarint64(); // com.google.protobuf.CodedInputStream.readRawVarint64 -> long
        v0 = _result;
        _result = v0.decodeZigZag64(v1); // com.google.protobuf.CodedInputStream.decodeZigZag64 -> long
        v0 = _result;
        return v0;
    }

    public java.lang.String readString() {
        // Registers (6 total): v5 = this
        _result = v5.readRawVarint32(); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v1 = _result;
        v0 = v5.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v2 = v5.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb1(v0, v2);
        if (v1 > v0) /* goto L_001e */;
        if (v1 <= 0) /* goto L_001e */;
        v0 = new java.lang.String;
        v2 = v5.buffer; // com.google.protobuf.CodedInputStream.buffer:byte[]
        v3 = v5.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v4 = "UTF-8";
        _result = v0.<init>(v2, v3, v1, v4); // java.lang.String.<init> -> void
        v2 = v5.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v1 = binOp2addr_0xb0(v1, v2);
        v5.bufferPos = v1; // com.google.protobuf.CodedInputStream.bufferPos:int
        return v0;
        v0 = new java.lang.String;
        _result = v5.readRawBytes(v1); // com.google.protobuf.CodedInputStream.readRawBytes -> byte[]
        v1 = _result;
        v2 = "UTF-8";
        _result = v0.<init>(v1, v2); // java.lang.String.<init> -> void
        // goto L_001d
    }

    public int readTag() {
        // Registers (3 total): v2 = this
        v0 = 0;
        _result = v2.isAtEnd(); // com.google.protobuf.CodedInputStream.isAtEnd -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_000a */;
        v2.lastTag = v0; // com.google.protobuf.CodedInputStream.lastTag:int
        return v0;
        _result = v2.readRawVarint32(); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v0 = _result;
        v2.lastTag = v0; // com.google.protobuf.CodedInputStream.lastTag:int
        v0 = v2.lastTag; // com.google.protobuf.CodedInputStream.lastTag:int
        _result = v0.getTagFieldNumber(); // com.google.protobuf.WireFormat.getTagFieldNumber -> int
        v0 = _result;
        if (v0 != 0) /* goto L_001d */;
        _result = this.invalidTag(); // com.google.protobuf.InvalidProtocolBufferException.invalidTag -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v0 = v2.lastTag; // com.google.protobuf.CodedInputStream.lastTag:int
        // goto L_0009
    }

    public int readUInt32() {
        // Registers (2 total): v1 = this
        _result = v1.readRawVarint32(); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v0 = _result;
        return v0;
    }

    public long readUInt64() {
        // Registers (3 total): v2 = this
        _result = v2.readRawVarint64(); // com.google.protobuf.CodedInputStream.readRawVarint64 -> long
        v0 = _result;
        return v0;
    }

    public void readUnknownGroup(int p0, com.google.protobuf.MessageLite$Builder p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (com.google.protobuf.MessageLite$Builder)
        v0 = 0;
        _result = v1.readGroup(v2, v3, v0); // com.google.protobuf.CodedInputStream.readGroup -> void
        return;
    }

    public void resetSizeCounter() {
        // Registers (2 total): v1 = this
        v0 = v1.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = unaryOp_0x7b(v0);
        v1.totalBytesRetired = v0; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        return;
    }

    public int setRecursionLimit(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        if (v4 >= 0) /* goto L_001b */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Recursion limit cannot be negative: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v3.recursionLimit; // com.google.protobuf.CodedInputStream.recursionLimit:int
        v3.recursionLimit = v4; // com.google.protobuf.CodedInputStream.recursionLimit:int
        return v0;
    }

    public int setSizeLimit(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        if (v4 >= 0) /* goto L_001b */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Size limit cannot be negative: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v3.sizeLimit; // com.google.protobuf.CodedInputStream.sizeLimit:int
        v3.sizeLimit = v4; // com.google.protobuf.CodedInputStream.sizeLimit:int
        return v0;
    }

    public boolean skipField(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = 1;
        _result = v4.getTagWireType(); // com.google.protobuf.WireFormat.getTagWireType -> int
        v1 = _result;
        // switch(v1)
        _result = this.invalidWireType(); // com.google.protobuf.InvalidProtocolBufferException.invalidWireType -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        _result = v3.readInt32(); // com.google.protobuf.CodedInputStream.readInt32 -> int
        return v0;
        _result = v3.readRawLittleEndian64(); // com.google.protobuf.CodedInputStream.readRawLittleEndian64 -> long
        // goto L_0010
        _result = v3.readRawVarint32(); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v1 = _result;
        _result = v3.skipRawBytes(v1); // com.google.protobuf.CodedInputStream.skipRawBytes -> void
        // goto L_0010
        _result = v3.skipMessage(); // com.google.protobuf.CodedInputStream.skipMessage -> void
        _result = v4.getTagFieldNumber(); // com.google.protobuf.WireFormat.getTagFieldNumber -> int
        v1 = _result;
        v2 = 4;
        _result = v1.makeTag(v2); // com.google.protobuf.WireFormat.makeTag -> int
        v1 = _result;
        _result = v3.checkLastTagWas(v1); // com.google.protobuf.CodedInputStream.checkLastTagWas -> void
        // goto L_0010
        v0 = 0;
        // goto L_0010
        _result = v3.readRawLittleEndian32(); // com.google.protobuf.CodedInputStream.readRawLittleEndian32 -> int
        // goto L_0010
    }

    public void skipMessage() {
        // Registers (2 total): v1 = this
        _result = v1.readTag(); // com.google.protobuf.CodedInputStream.readTag -> int
        v0 = _result;
        if (v0 == 0) /* goto L_000c */;
        _result = v1.skipField(v0); // com.google.protobuf.CodedInputStream.skipField -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0000 */;
        return;
    }

    public void skipRawBytes(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        v3 = 1;
        if (v5 >= 0) /* goto L_0008 */;
        _result = this.negativeSize(); // com.google.protobuf.InvalidProtocolBufferException.negativeSize -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v0 = v4.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v1 = v4.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = binOp2addr_0xb0(v0, v5);
        v1 = v4.currentLimit; // com.google.protobuf.CodedInputStream.currentLimit:int
        if (v0 <= v1) /* goto L_0022 */;
        v0 = v4.currentLimit; // com.google.protobuf.CodedInputStream.currentLimit:int
        v1 = v4.totalBytesRetired; // com.google.protobuf.CodedInputStream.totalBytesRetired:int
        v0 = binOp2addr_0xb1(v0, v1);
        v1 = v4.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb1(v0, v1);
        _result = v4.skipRawBytes(v0); // com.google.protobuf.CodedInputStream.skipRawBytes -> void
        _result = this.truncatedMessage(); // com.google.protobuf.InvalidProtocolBufferException.truncatedMessage -> com.google.protobuf.InvalidProtocolBufferException
        v0 = _result;
        throw v0;
        v0 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v1 = v4.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb1(v0, v1);
        if (v5 > v0) /* goto L_002f */;
        v0 = v4.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb0(v0, v5);
        v4.bufferPos = v0; // com.google.protobuf.CodedInputStream.bufferPos:int
        return;
        v0 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v1 = v4.bufferPos; // com.google.protobuf.CodedInputStream.bufferPos:int
        v0 = binOp2addr_0xb1(v0, v1);
        v1 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v4.bufferPos = v1; // com.google.protobuf.CodedInputStream.bufferPos:int
        _result = v4.refillBuffer(v3); // com.google.protobuf.CodedInputStream.refillBuffer -> boolean
        v1 = binOp_0x91(v5, v0);
        v2 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        if (v1 <= v2) /* goto L_004c */;
        v1 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v4.bufferSize; // com.google.protobuf.CodedInputStream.bufferSize:int
        v4.bufferPos = v1; // com.google.protobuf.CodedInputStream.bufferPos:int
        _result = v4.refillBuffer(v3); // com.google.protobuf.CodedInputStream.refillBuffer -> boolean
        // goto L_003b
        v0 = binOp_0x91(v5, v0);
        v4.bufferPos = v0; // com.google.protobuf.CodedInputStream.bufferPos:int
        // goto L_002e
    }

}