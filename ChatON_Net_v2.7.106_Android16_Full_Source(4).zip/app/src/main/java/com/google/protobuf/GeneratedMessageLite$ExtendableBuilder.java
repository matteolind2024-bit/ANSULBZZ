package com.google.protobuf;

/**
 * Original SourceFile: GeneratedMessageLite.java
 * Descriptor: Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
 */
public abstract class GeneratedMessageLite$ExtendableBuilder extends com.google.protobuf.GeneratedMessageLite$Builder implements com.google.protobuf.GeneratedMessageLite$ExtendableMessageOrBuilder {
    private com.google.protobuf.FieldSet extensions;
    private boolean extensionsIsMutable;

    protected GeneratedMessageLite$ExtendableBuilder() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite$Builder.<init> -> void
        _result = this.emptySet(); // com.google.protobuf.FieldSet.emptySet -> com.google.protobuf.FieldSet
        v0 = _result;
        v1.extensions = v0; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        return;
    }

    static com.google.protobuf.FieldSet access$000(com.google.protobuf.GeneratedMessageLite$ExtendableBuilder p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.GeneratedMessageLite$ExtendableBuilder)
        _result = v1.buildExtensions(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.buildExtensions -> com.google.protobuf.FieldSet
        v0 = _result;
        return v0;
    }

    private com.google.protobuf.FieldSet buildExtensions() {
        // Registers (2 total): v1 = this
        v0 = v1.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v0.makeImmutable(); // com.google.protobuf.FieldSet.makeImmutable -> void
        v0 = 0;
        v1.extensionsIsMutable = v0; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensionsIsMutable:boolean
        v0 = v1.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        return v0;
    }

    private void ensureExtensionsIsMutable() {
        // Registers (2 total): v1 = this
        v0 = v1.extensionsIsMutable; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensionsIsMutable:boolean
        if (v0 != 0) /* goto L_000f */;
        v0 = v1.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v0.clone(); // com.google.protobuf.FieldSet.clone -> com.google.protobuf.FieldSet
        v0 = _result;
        v1.extensions = v0; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        v0 = 1;
        v1.extensionsIsMutable = v0; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensionsIsMutable:boolean
        return;
    }

    private void verifyExtensionContainingType(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        _result = v3.getContainingTypeDefaultInstance(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.getContainingTypeDefaultInstance -> com.google.protobuf.MessageLite
        v0 = _result;
        _result = v2.getDefaultInstanceForType(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.getDefaultInstanceForType -> com.google.protobuf.GeneratedMessageLite
        v1 = _result;
        if (v0 == v1) /* goto L_0012 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "This extension is for a different message type.  Please make sure that you are not suppressing any generics type warnings.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        return;
    }

    public final com.google.protobuf.GeneratedMessageLite$ExtendableBuilder addExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0, java.lang.Object p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension), v4 = p1 (java.lang.Object)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.verifyExtensionContainingType -> void
        _result = v2.ensureExtensionsIsMutable(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.ensureExtensionsIsMutable -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.addRepeatedField(v1, v4); // com.google.protobuf.FieldSet.addRepeatedField -> void
        return v2;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.clear(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.clear -> com.google.protobuf.GeneratedMessageLite$ExtendableBuilder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$ExtendableBuilder clear() {
        // Registers (2 total): v1 = this
        v0 = v1.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v0.clear(); // com.google.protobuf.FieldSet.clear -> void
        v0 = 0;
        v1.extensionsIsMutable = v0; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensionsIsMutable:boolean
        _result = v1.clear(); // com.google.protobuf.GeneratedMessageLite$Builder.clear -> com.google.protobuf.GeneratedMessageLite$Builder
        v0 = _result;
        v0 = (com.google.protobuf.GeneratedMessageLite$ExtendableBuilder) v0;
        return v0;
    }

    public com.google.protobuf.MessageLite$Builder clear() {
        // Registers (2 total): v1 = this
        _result = v1.clear(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.clear -> com.google.protobuf.GeneratedMessageLite$ExtendableBuilder
        v0 = _result;
        return v0;
    }

    public final com.google.protobuf.GeneratedMessageLite$ExtendableBuilder clearExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.verifyExtensionContainingType -> void
        _result = v2.ensureExtensionsIsMutable(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.ensureExtensionsIsMutable -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.clearField(v1); // com.google.protobuf.FieldSet.clearField -> void
        return v2;
    }

    public com.google.protobuf.AbstractMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.clone(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.clone -> com.google.protobuf.GeneratedMessageLite$ExtendableBuilder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.clone(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.clone -> com.google.protobuf.GeneratedMessageLite$ExtendableBuilder
        v0 = _result;
        return v0;
    }

    public com.google.protobuf.GeneratedMessageLite$ExtendableBuilder clone() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.UnsupportedOperationException;
        v1 = "This is supposed to be overridden by subclasses.";
        _result = v0.<init>(v1); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public com.google.protobuf.MessageLite$Builder clone() {
        // Registers (2 total): v1 = this
        _result = v1.clone(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.clone -> com.google.protobuf.GeneratedMessageLite$ExtendableBuilder
        v0 = _result;
        return v0;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.clone(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.clone -> com.google.protobuf.GeneratedMessageLite$ExtendableBuilder
        v0 = _result;
        return v0;
    }

    protected boolean extensionsAreInitialized() {
        // Registers (2 total): v1 = this
        v0 = v1.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v0.isInitialized(); // com.google.protobuf.FieldSet.isInitialized -> boolean
        v0 = _result;
        return v0;
    }

    public final java.lang.Object getExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.verifyExtensionContainingType -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.getField(v1); // com.google.protobuf.FieldSet.getField -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_0013 */;
        _result = v3.access$200(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$200 -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public final java.lang.Object getExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension), v4 = p1 (int)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.verifyExtensionContainingType -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.getRepeatedField(v1, v4); // com.google.protobuf.FieldSet.getRepeatedField -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public final int getExtensionCount(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.verifyExtensionContainingType -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.getRepeatedFieldCount(v1); // com.google.protobuf.FieldSet.getRepeatedFieldCount -> int
        v0 = _result;
        return v0;
    }

    public final boolean hasExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.verifyExtensionContainingType -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.hasField(v1); // com.google.protobuf.FieldSet.hasField -> boolean
        v0 = _result;
        return v0;
    }

    protected final void mergeExtensionFields(com.google.protobuf.GeneratedMessageLite$ExtendableMessage p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$ExtendableMessage)
        _result = v2.ensureExtensionsIsMutable(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.ensureExtensionsIsMutable -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$300(); // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.access$300 -> com.google.protobuf.FieldSet
        v1 = _result;
        _result = v0.mergeFrom(v1); // com.google.protobuf.FieldSet.mergeFrom -> void
        return;
    }

    protected boolean parseUnknownField(com.google.protobuf.CodedInputStream p0, com.google.protobuf.ExtensionRegistryLite p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (com.google.protobuf.CodedInputStream), v8 = p1 (com.google.protobuf.ExtensionRegistryLite), v9 = p2 (int)
        v0 = 0;
        v1 = 1;
        _result = v9.getTagWireType(); // com.google.protobuf.WireFormat.getTagWireType -> int
        v2 = _result;
        _result = v9.getTagFieldNumber(); // com.google.protobuf.WireFormat.getTagFieldNumber -> int
        v3 = _result;
        _result = v6.getDefaultInstanceForType(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.getDefaultInstanceForType -> com.google.protobuf.GeneratedMessageLite
        v4 = _result;
        _result = v8.findLiteExtensionByNumber(v4, v3); // com.google.protobuf.ExtensionRegistryLite.findLiteExtensionByNumber -> com.google.protobuf.GeneratedMessageLite$GeneratedExtension
        v3 = _result;
        if (v3 != 0) /* goto L_001c */;
        v2 = v1;
        if (v2 == 0) /* goto L_0057 */;
        _result = v7.skipField(v9); // com.google.protobuf.CodedInputStream.skipField -> boolean
        v0 = _result;
        return v0;
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v4 = _result;
        _result = v4.getLiteType(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getLiteType -> com.google.protobuf.WireFormat$FieldType
        v4 = _result;
        _result = v4.getWireFormatForFieldType(v0); // com.google.protobuf.FieldSet.getWireFormatForFieldType -> int
        v4 = _result;
        if (v2 != v4) /* goto L_002c */;
        v2 = v0;
        // goto L_0015
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v4 = _result;
        _result = v4.access$500(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.access$500 -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_0055 */;
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v4 = _result;
        _result = v4.access$600(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.access$600 -> com.google.protobuf.WireFormat$FieldType
        v4 = _result;
        _result = v4.isPackable(); // com.google.protobuf.WireFormat$FieldType.isPackable -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_0055 */;
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v4 = _result;
        _result = v4.getLiteType(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getLiteType -> com.google.protobuf.WireFormat$FieldType
        v4 = _result;
        _result = v4.getWireFormatForFieldType(v1); // com.google.protobuf.FieldSet.getWireFormatForFieldType -> int
        v4 = _result;
        if (v2 != v4) /* goto L_0055 */;
        v2 = v0;
        v0 = v1;
        // goto L_0015
        v2 = v1;
        // goto L_0015
        if (v0 == 0) /* goto L_00b9 */;
        _result = v7.readRawVarint32(); // com.google.protobuf.CodedInputStream.readRawVarint32 -> int
        v0 = _result;
        _result = v7.pushLimit(v0); // com.google.protobuf.CodedInputStream.pushLimit -> int
        v0 = _result;
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v2 = _result;
        _result = v2.getLiteType(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getLiteType -> com.google.protobuf.WireFormat$FieldType
        v2 = _result;
        v4 = com.google.protobuf.WireFormat$FieldType.ENUM; // :com.google.protobuf.WireFormat$FieldType
        if (v2 != v4) /* goto L_0094 */;
        _result = v7.getBytesUntilLimit(); // com.google.protobuf.CodedInputStream.getBytesUntilLimit -> int
        v2 = _result;
        if (v2 <= 0) /* goto L_00b3 */;
        _result = v7.readEnum(); // com.google.protobuf.CodedInputStream.readEnum -> int
        v2 = _result;
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v4 = _result;
        _result = v4.getEnumType(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getEnumType -> com.google.protobuf.Internal$EnumLiteMap
        v4 = _result;
        _result = com.google.protobuf.Internal$EnumLiteMap.findValueByNumber(v4, v2); // -> com.google.protobuf.Internal$EnumLite
        v2 = _result;
        if (v2 != 0) /* goto L_0087 */;
        v0 = v1;
        // goto L_001b
        _result = v6.ensureExtensionsIsMutable(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.ensureExtensionsIsMutable -> void
        v4 = v6.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v5 = _result;
        _result = v4.addRepeatedField(v5, v2); // com.google.protobuf.FieldSet.addRepeatedField -> void
        // goto L_006d
        _result = v7.getBytesUntilLimit(); // com.google.protobuf.CodedInputStream.getBytesUntilLimit -> int
        v2 = _result;
        if (v2 <= 0) /* goto L_00b3 */;
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v2 = _result;
        _result = v2.getLiteType(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getLiteType -> com.google.protobuf.WireFormat$FieldType
        v2 = _result;
        _result = v7.readPrimitiveField(v2); // com.google.protobuf.FieldSet.readPrimitiveField -> java.lang.Object
        v2 = _result;
        _result = v6.ensureExtensionsIsMutable(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.ensureExtensionsIsMutable -> void
        v4 = v6.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v5 = _result;
        _result = v4.addRepeatedField(v5, v2); // com.google.protobuf.FieldSet.addRepeatedField -> void
        // goto L_0094
        _result = v7.popLimit(v0); // com.google.protobuf.CodedInputStream.popLimit -> void
        v0 = v1;
        // goto L_001b
        v0 = com.google.protobuf.GeneratedMessageLite$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v2 = _result;
        _result = v2.getLiteJavaType(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getLiteJavaType -> com.google.protobuf.WireFormat$JavaType
        v2 = _result;
        _result = v2.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v2 = _result;
        v0 = v0[v2];
        // switch(v0)
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v0 = _result;
        _result = v0.getLiteType(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getLiteType -> com.google.protobuf.WireFormat$FieldType
        v0 = _result;
        _result = v7.readPrimitiveField(v0); // com.google.protobuf.FieldSet.readPrimitiveField -> java.lang.Object
        v0 = _result;
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v2 = _result;
        _result = v2.isRepeated(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.isRepeated -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0147 */;
        _result = v6.ensureExtensionsIsMutable(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.ensureExtensionsIsMutable -> void
        v2 = v6.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v3 = _result;
        _result = v2.addRepeatedField(v3, v0); // com.google.protobuf.FieldSet.addRepeatedField -> void
        // goto L_00b6
        v2 = 0;
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v0 = _result;
        _result = v0.isRepeated(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.isRepeated -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0155 */;
        v0 = v6.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v4 = _result;
        _result = v0.getField(v4); // com.google.protobuf.FieldSet.getField -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite) v0;
        if (v0 == 0) /* goto L_0155 */;
        _result = com.google.protobuf.MessageLite.toBuilder(v0); // -> com.google.protobuf.MessageLite$Builder
        v0 = _result;
        if (v0 != 0) /* goto L_0116 */;
        _result = v3.access$700(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$700 -> com.google.protobuf.MessageLite
        v0 = _result;
        _result = com.google.protobuf.MessageLite.newBuilderForType(v0); // -> com.google.protobuf.MessageLite$Builder
        v0 = _result;
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v2 = _result;
        _result = v2.getLiteType(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getLiteType -> com.google.protobuf.WireFormat$FieldType
        v2 = _result;
        v4 = com.google.protobuf.WireFormat$FieldType.GROUP; // :com.google.protobuf.WireFormat$FieldType
        if (v2 != v4) /* goto L_012e */;
        _result = v3.getNumber(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.getNumber -> int
        v2 = _result;
        _result = v7.readGroup(v2, v0, v8); // com.google.protobuf.CodedInputStream.readGroup -> void
        _result = com.google.protobuf.MessageLite$Builder.build(v0); // -> com.google.protobuf.MessageLite
        v0 = _result;
        // goto L_00d8
        _result = v7.readMessage(v0, v8); // com.google.protobuf.CodedInputStream.readMessage -> void
        // goto L_0129
        _result = v7.readEnum(); // com.google.protobuf.CodedInputStream.readEnum -> int
        v0 = _result;
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v2 = _result;
        _result = v2.getEnumType(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getEnumType -> com.google.protobuf.Internal$EnumLiteMap
        v2 = _result;
        _result = com.google.protobuf.Internal$EnumLiteMap.findValueByNumber(v2, v0); // -> com.google.protobuf.Internal$EnumLite
        v0 = _result;
        if (v0 != 0) /* goto L_00d8 */;
        v0 = v1;
        // goto L_001b
        _result = v6.ensureExtensionsIsMutable(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.ensureExtensionsIsMutable -> void
        v2 = v6.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v3 = _result;
        _result = v2.setField(v3, v0); // com.google.protobuf.FieldSet.setField -> void
        // goto L_00b6
        v0 = v2;
        // goto L_010c
    }

    public final com.google.protobuf.GeneratedMessageLite$ExtendableBuilder setExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0, int p1, java.lang.Object p2) {
        // Registers (6 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension), v4 = p1 (int), v5 = p2 (java.lang.Object)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.verifyExtensionContainingType -> void
        _result = v2.ensureExtensionsIsMutable(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.ensureExtensionsIsMutable -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.setRepeatedField(v1, v4, v5); // com.google.protobuf.FieldSet.setRepeatedField -> void
        return v2;
    }

    public final com.google.protobuf.GeneratedMessageLite$ExtendableBuilder setExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0, java.lang.Object p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension), v4 = p1 (java.lang.Object)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.verifyExtensionContainingType -> void
        _result = v2.ensureExtensionsIsMutable(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.ensureExtensionsIsMutable -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.setField(v1, v4); // com.google.protobuf.FieldSet.setField -> void
        return v2;
    }

}