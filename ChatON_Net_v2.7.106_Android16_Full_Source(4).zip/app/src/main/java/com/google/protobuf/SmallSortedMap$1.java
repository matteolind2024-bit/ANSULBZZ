package com.google.protobuf;

/**
 * Original SourceFile: SmallSortedMap.java
 * Descriptor: Lcom/google/protobuf/SmallSortedMap$1;
 */
final class SmallSortedMap$1 extends com.google.protobuf.SmallSortedMap {
    SmallSortedMap$1(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        _result = v1.<init>(v2, v0); // com.google.protobuf.SmallSortedMap.<init> -> void
        return;
    }

    public void makeImmutable() {
        // Registers (4 total): v3 = this
        _result = v3.isImmutable(); // com.google.protobuf.SmallSortedMap$1.isImmutable -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_005d */;
        v0 = 0;
        v1 = v0;
        _result = v3.getNumArrayEntries(); // com.google.protobuf.SmallSortedMap$1.getNumArrayEntries -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_002f */;
        _result = v3.getArrayEntryAt(v1); // com.google.protobuf.SmallSortedMap$1.getArrayEntryAt -> java.util.Map$Entry
        v2 = _result;
        _result = java.util.Map$Entry.getKey(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v0;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002b */;
        _result = java.util.Map$Entry.getValue(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.List) v0;
        _result = v0.unmodifiableList(); // java.util.Collections.unmodifiableList -> java.util.List
        v0 = _result;
        _result = java.util.Map$Entry.setValue(v2, v0); // -> java.lang.Object
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0008
        _result = v3.getOverflowEntries(); // com.google.protobuf.SmallSortedMap$1.getOverflowEntries -> java.lang.Iterable
        v0 = _result;
        _result = java.lang.Iterable.iterator(v0); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_005d */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = java.util.Map$Entry.getKey(v0); // -> java.lang.Object
        v1 = _result;
        v1 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v1;
        _result = com.google.protobuf.FieldSet$FieldDescriptorLite.isRepeated(v1); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0037 */;
        _result = java.util.Map$Entry.getValue(v0); // -> java.lang.Object
        v1 = _result;
        v1 = (java.util.List) v1;
        _result = v1.unmodifiableList(); // java.util.Collections.unmodifiableList -> java.util.List
        v1 = _result;
        _result = java.util.Map$Entry.setValue(v0, v1); // -> java.lang.Object
        // goto L_0037
        _result = v3.makeImmutable(); // com.google.protobuf.SmallSortedMap.makeImmutable -> void
        return;
    }

    public java.lang.Object put(java.lang.Object p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (java.lang.Object)
        v2 = (com.google.protobuf.FieldSet$FieldDescriptorLite) v2;
        _result = v1.put(v2, v3); // com.google.protobuf.SmallSortedMap.put -> java.lang.Object
        v0 = _result;
        return v0;
    }

}