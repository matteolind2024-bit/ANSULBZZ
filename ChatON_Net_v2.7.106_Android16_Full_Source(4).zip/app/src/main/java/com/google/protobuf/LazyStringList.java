package com.google.protobuf;

/**
 * Original SourceFile: LazyStringList.java
 * Descriptor: Lcom/google/protobuf/LazyStringList;
 */
public interface LazyStringList extends java.util.List {
    public abstract void add(com.google.protobuf.ByteString p0);
    public abstract com.google.protobuf.ByteString getByteString(int p0);
}