package com.google.protobuf;

/**
 * Original SourceFile: SmallSortedMap.java
 * Descriptor: Lcom/google/protobuf/SmallSortedMap$EntryIterator;
 */
class SmallSortedMap$EntryIterator implements java.util.Iterator {
    private java.util.Iterator lazyOverflowIterator;
    private boolean nextCalledBeforeRemove;
    private int pos;
    final com.google.protobuf.SmallSortedMap this$0;

    private SmallSortedMap$EntryIterator(com.google.protobuf.SmallSortedMap p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.SmallSortedMap)
        v1.this$0 = v2; // com.google.protobuf.SmallSortedMap$EntryIterator.this$0:com.google.protobuf.SmallSortedMap
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = -1;
        v1.pos = v0; // com.google.protobuf.SmallSortedMap$EntryIterator.pos:int
        return;
    }

    SmallSortedMap$EntryIterator(com.google.protobuf.SmallSortedMap p0, com.google.protobuf.SmallSortedMap$1 p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.google.protobuf.SmallSortedMap), v2 = p1 (com.google.protobuf.SmallSortedMap$1)
        _result = v0.<init>(v1); // com.google.protobuf.SmallSortedMap$EntryIterator.<init> -> void
        return;
    }

    private java.util.Iterator getOverflowIterator() {
        // Registers (2 total): v1 = this
        v0 = v1.lazyOverflowIterator; // com.google.protobuf.SmallSortedMap$EntryIterator.lazyOverflowIterator:java.util.Iterator
        if (v0 != 0) /* goto L_0014 */;
        v0 = v1.this$0; // com.google.protobuf.SmallSortedMap$EntryIterator.this$0:com.google.protobuf.SmallSortedMap
        _result = v0.access$600(); // com.google.protobuf.SmallSortedMap.access$600 -> java.util.Map
        v0 = _result;
        _result = java.util.Map.entrySet(v0); // -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v0 = _result;
        v1.lazyOverflowIterator = v0; // com.google.protobuf.SmallSortedMap$EntryIterator.lazyOverflowIterator:java.util.Iterator
        v0 = v1.lazyOverflowIterator; // com.google.protobuf.SmallSortedMap$EntryIterator.lazyOverflowIterator:java.util.Iterator
        return v0;
    }

    public boolean hasNext() {
        // Registers (3 total): v2 = this
        v0 = v2.pos; // com.google.protobuf.SmallSortedMap$EntryIterator.pos:int
        v0 = binOpLit8_0xd8(v0, 1);
        v1 = v2.this$0; // com.google.protobuf.SmallSortedMap$EntryIterator.this$0:com.google.protobuf.SmallSortedMap
        _result = v1.access$400(); // com.google.protobuf.SmallSortedMap.access$400 -> java.util.List
        v1 = _result;
        _result = java.util.List.size(v1); // -> int
        v1 = _result;
        if (v0 < v1) /* goto L_001a */;
        _result = v2.getOverflowIterator(); // com.google.protobuf.SmallSortedMap$EntryIterator.getOverflowIterator -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_001b
    }

    public java.lang.Object next() {
        // Registers (2 total): v1 = this
        _result = v1.next(); // com.google.protobuf.SmallSortedMap$EntryIterator.next -> java.util.Map$Entry
        v0 = _result;
        return v0;
    }

    public java.util.Map$Entry next() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v2.nextCalledBeforeRemove = v0; // com.google.protobuf.SmallSortedMap$EntryIterator.nextCalledBeforeRemove:boolean
        v0 = v2.pos; // com.google.protobuf.SmallSortedMap$EntryIterator.pos:int
        v0 = binOpLit8_0xd8(v0, 1);
        v2.pos = v0; // com.google.protobuf.SmallSortedMap$EntryIterator.pos:int
        v1 = v2.this$0; // com.google.protobuf.SmallSortedMap$EntryIterator.this$0:com.google.protobuf.SmallSortedMap
        _result = v1.access$400(); // com.google.protobuf.SmallSortedMap.access$400 -> java.util.List
        v1 = _result;
        _result = java.util.List.size(v1); // -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_0024 */;
        v0 = v2.this$0; // com.google.protobuf.SmallSortedMap$EntryIterator.this$0:com.google.protobuf.SmallSortedMap
        _result = v0.access$400(); // com.google.protobuf.SmallSortedMap.access$400 -> java.util.List
        v0 = _result;
        v1 = v2.pos; // com.google.protobuf.SmallSortedMap$EntryIterator.pos:int
        _result = java.util.List.get(v0, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        return v0;
        _result = v2.getOverflowIterator(); // com.google.protobuf.SmallSortedMap$EntryIterator.getOverflowIterator -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        // goto L_0023
    }

    public void remove() {
        // Registers (4 total): v3 = this
        v0 = v3.nextCalledBeforeRemove; // com.google.protobuf.SmallSortedMap$EntryIterator.nextCalledBeforeRemove:boolean
        if (v0 != 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "remove() was called before next()";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = 0;
        v3.nextCalledBeforeRemove = v0; // com.google.protobuf.SmallSortedMap$EntryIterator.nextCalledBeforeRemove:boolean
        v0 = v3.this$0; // com.google.protobuf.SmallSortedMap$EntryIterator.this$0:com.google.protobuf.SmallSortedMap
        _result = v0.access$200(); // com.google.protobuf.SmallSortedMap.access$200 -> void
        v0 = v3.pos; // com.google.protobuf.SmallSortedMap$EntryIterator.pos:int
        v1 = v3.this$0; // com.google.protobuf.SmallSortedMap$EntryIterator.this$0:com.google.protobuf.SmallSortedMap
        _result = v1.access$400(); // com.google.protobuf.SmallSortedMap.access$400 -> java.util.List
        v1 = _result;
        _result = java.util.List.size(v1); // -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_002e */;
        v0 = v3.this$0; // com.google.protobuf.SmallSortedMap$EntryIterator.this$0:com.google.protobuf.SmallSortedMap
        v1 = v3.pos; // com.google.protobuf.SmallSortedMap$EntryIterator.pos:int
        v2 = binOpLit8_0xd8(v1, -1);
        v3.pos = v2; // com.google.protobuf.SmallSortedMap$EntryIterator.pos:int
        _result = v0.access$500(v1); // com.google.protobuf.SmallSortedMap.access$500 -> java.lang.Object
        return;
        _result = v3.getOverflowIterator(); // com.google.protobuf.SmallSortedMap$EntryIterator.getOverflowIterator -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.remove(v0); // -> void
        // goto L_002d
    }

}