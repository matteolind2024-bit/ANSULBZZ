package com.google.protobuf;

/**
 * Original SourceFile: GeneratedMessageLite.java
 * Descriptor: Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;
 */
public final class GeneratedMessageLite$GeneratedExtension {
    private final com.google.protobuf.MessageLite containingTypeDefaultInstance;
    private final java.lang.Object defaultValue;
    private final com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor descriptor;
    private final com.google.protobuf.MessageLite messageDefaultInstance;

    private GeneratedMessageLite$GeneratedExtension(com.google.protobuf.MessageLite p0, java.lang.Object p1, com.google.protobuf.MessageLite p2, com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor p3) {
        // Registers (7 total): v2 = this, v3 = p0 (com.google.protobuf.MessageLite), v4 = p1 (java.lang.Object), v5 = p2 (com.google.protobuf.MessageLite), v6 = p3 (com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor)
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        if (v3 != 0) /* goto L_000d */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Null containingTypeDefaultInstance";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = v6.getLiteType(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getLiteType -> com.google.protobuf.WireFormat$FieldType
        v0 = _result;
        v1 = com.google.protobuf.WireFormat$FieldType.MESSAGE; // :com.google.protobuf.WireFormat$FieldType
        if (v0 != v1) /* goto L_001f */;
        if (v5 != 0) /* goto L_001f */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Null messageDefaultInstance";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v2.containingTypeDefaultInstance = v3; // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.containingTypeDefaultInstance:com.google.protobuf.MessageLite
        v2.defaultValue = v4; // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.defaultValue:java.lang.Object
        v2.messageDefaultInstance = v5; // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.messageDefaultInstance:com.google.protobuf.MessageLite
        v2.descriptor = v6; // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.descriptor:com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        return;
    }

    GeneratedMessageLite$GeneratedExtension(com.google.protobuf.MessageLite p0, java.lang.Object p1, com.google.protobuf.MessageLite p2, com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor p3, com.google.protobuf.GeneratedMessageLite$1 p4) {
        // Registers (6 total): v0 = this, v1 = p0 (com.google.protobuf.MessageLite), v2 = p1 (java.lang.Object), v3 = p2 (com.google.protobuf.MessageLite), v4 = p3 (com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor), v5 = p4 (com.google.protobuf.GeneratedMessageLite$1)
        _result = v0.<init>(v1, v2, v3, v4); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.<init> -> void
        return;
    }

    static com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor access$100(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        v0 = v1.descriptor; // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.descriptor:com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        return v0;
    }

    static java.lang.Object access$200(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        v0 = v1.defaultValue; // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.defaultValue:java.lang.Object
        return v0;
    }

    static com.google.protobuf.MessageLite access$700(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        v0 = v1.messageDefaultInstance; // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.messageDefaultInstance:com.google.protobuf.MessageLite
        return v0;
    }

    public com.google.protobuf.MessageLite getContainingTypeDefaultInstance() {
        // Registers (2 total): v1 = this
        v0 = v1.containingTypeDefaultInstance; // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.containingTypeDefaultInstance:com.google.protobuf.MessageLite
        return v0;
    }

    public com.google.protobuf.MessageLite getMessageDefaultInstance() {
        // Registers (2 total): v1 = this
        v0 = v1.messageDefaultInstance; // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.messageDefaultInstance:com.google.protobuf.MessageLite
        return v0;
    }

    public int getNumber() {
        // Registers (2 total): v1 = this
        v0 = v1.descriptor; // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.descriptor:com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        _result = v0.getNumber(); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.getNumber -> int
        v0 = _result;
        return v0;
    }

}