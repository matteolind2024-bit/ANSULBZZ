package com.google.protobuf;

/**
 * Original SourceFile: GeneratedMessageLite.java
 * Descriptor: Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;
 */
public abstract class GeneratedMessageLite$ExtendableMessage extends com.google.protobuf.GeneratedMessageLite implements com.google.protobuf.GeneratedMessageLite$ExtendableMessageOrBuilder {
    private final com.google.protobuf.FieldSet extensions;

    protected GeneratedMessageLite$ExtendableMessage() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        _result = this.newFieldSet(); // com.google.protobuf.FieldSet.newFieldSet -> com.google.protobuf.FieldSet
        v0 = _result;
        v1.extensions = v0; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.extensions:com.google.protobuf.FieldSet
        return;
    }

    protected GeneratedMessageLite$ExtendableMessage(com.google.protobuf.GeneratedMessageLite$ExtendableBuilder p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.GeneratedMessageLite$ExtendableBuilder)
        _result = v1.<init>(); // com.google.protobuf.GeneratedMessageLite.<init> -> void
        _result = v2.access$000(); // com.google.protobuf.GeneratedMessageLite$ExtendableBuilder.access$000 -> com.google.protobuf.FieldSet
        v0 = _result;
        v1.extensions = v0; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.extensions:com.google.protobuf.FieldSet
        return;
    }

    static com.google.protobuf.FieldSet access$300(com.google.protobuf.GeneratedMessageLite$ExtendableMessage p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.GeneratedMessageLite$ExtendableMessage)
        v0 = v1.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.extensions:com.google.protobuf.FieldSet
        return v0;
    }

    private void verifyExtensionContainingType(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        _result = v3.getContainingTypeDefaultInstance(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.getContainingTypeDefaultInstance -> com.google.protobuf.MessageLite
        v0 = _result;
        _result = v2.getDefaultInstanceForType(); // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.getDefaultInstanceForType -> com.google.protobuf.MessageLite
        v1 = _result;
        if (v0 == v1) /* goto L_0012 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "This extension is for a different message type.  Please make sure that you are not suppressing any generics type warnings.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        return;
    }

    protected boolean extensionsAreInitialized() {
        // Registers (2 total): v1 = this
        v0 = v1.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.extensions:com.google.protobuf.FieldSet
        _result = v0.isInitialized(); // com.google.protobuf.FieldSet.isInitialized -> boolean
        v0 = _result;
        return v0;
    }

    protected int extensionsSerializedSize() {
        // Registers (2 total): v1 = this
        v0 = v1.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.extensions:com.google.protobuf.FieldSet
        _result = v0.getSerializedSize(); // com.google.protobuf.FieldSet.getSerializedSize -> int
        v0 = _result;
        return v0;
    }

    protected int extensionsSerializedSizeAsMessageSet() {
        // Registers (2 total): v1 = this
        v0 = v1.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.extensions:com.google.protobuf.FieldSet
        _result = v0.getMessageSetSerializedSize(); // com.google.protobuf.FieldSet.getMessageSetSerializedSize -> int
        v0 = _result;
        return v0;
    }

    public final java.lang.Object getExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.verifyExtensionContainingType -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.getField(v1); // com.google.protobuf.FieldSet.getField -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_0013 */;
        _result = v3.access$200(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$200 -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public final java.lang.Object getExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension), v4 = p1 (int)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.verifyExtensionContainingType -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.getRepeatedField(v1, v4); // com.google.protobuf.FieldSet.getRepeatedField -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public final int getExtensionCount(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.verifyExtensionContainingType -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.getRepeatedFieldCount(v1); // com.google.protobuf.FieldSet.getRepeatedFieldCount -> int
        v0 = _result;
        return v0;
    }

    public final boolean hasExtension(com.google.protobuf.GeneratedMessageLite$GeneratedExtension p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.GeneratedMessageLite$GeneratedExtension)
        _result = v2.verifyExtensionContainingType(v3); // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.verifyExtensionContainingType -> void
        v0 = v2.extensions; // com.google.protobuf.GeneratedMessageLite$ExtendableMessage.extensions:com.google.protobuf.FieldSet
        _result = v3.access$100(); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.access$100 -> com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor
        v1 = _result;
        _result = v0.hasField(v1); // com.google.protobuf.FieldSet.hasField -> boolean
        v0 = _result;
        return v0;
    }

    protected com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter newExtensionWriter() {
        // Registers (4 total): v3 = this
        v0 = new com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter;
        v1 = 0;
        v2 = 0;
        _result = v0.<init>(v3, v1, v2); // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.<init> -> void
        return v0;
    }

    protected com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter newMessageSetExtensionWriter() {
        // Registers (4 total): v3 = this
        v0 = new com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter;
        v1 = 1;
        v2 = 0;
        _result = v0.<init>(v3, v1, v2); // com.google.protobuf.GeneratedMessageLite$ExtendableMessage$ExtensionWriter.<init> -> void
        return v0;
    }

}