package com.google.protobuf;

/**
 * Original SourceFile: WireFormat.java
 * Descriptor: Lcom/google/protobuf/WireFormat;
 */
public final class WireFormat {
    static final int MESSAGE_SET_ITEM;
    static final int MESSAGE_SET_ITEM_END_TAG;
    static final int MESSAGE_SET_ITEM_TAG;
    static final int MESSAGE_SET_MESSAGE;
    static final int MESSAGE_SET_MESSAGE_TAG;
    static final int MESSAGE_SET_TYPE_ID;
    static final int MESSAGE_SET_TYPE_ID_TAG;
    static final int TAG_TYPE_BITS;
    static final int TAG_TYPE_MASK;
    public static final int WIRETYPE_END_GROUP;
    public static final int WIRETYPE_FIXED32;
    public static final int WIRETYPE_FIXED64;
    public static final int WIRETYPE_LENGTH_DELIMITED;
    public static final int WIRETYPE_START_GROUP;
    public static final int WIRETYPE_VARINT;

    static {
        v3 = 3;
        v2 = 2;
        v1 = 1;
        _result = v1.makeTag(v3); // com.google.protobuf.WireFormat.makeTag -> int
        v0 = _result;
        com.google.protobuf.WireFormat.MESSAGE_SET_ITEM_TAG = v0; // :int
        v0 = 4;
        _result = v1.makeTag(v0); // com.google.protobuf.WireFormat.makeTag -> int
        v0 = _result;
        com.google.protobuf.WireFormat.MESSAGE_SET_ITEM_END_TAG = v0; // :int
        v0 = 0;
        _result = v2.makeTag(v0); // com.google.protobuf.WireFormat.makeTag -> int
        v0 = _result;
        com.google.protobuf.WireFormat.MESSAGE_SET_TYPE_ID_TAG = v0; // :int
        _result = v3.makeTag(v2); // com.google.protobuf.WireFormat.makeTag -> int
        v0 = _result;
        com.google.protobuf.WireFormat.MESSAGE_SET_MESSAGE_TAG = v0; // :int
        return;
    }

    private WireFormat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static int getTagFieldNumber(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = binOpLit8_0xe2(v1, 3);
        return v0;
    }

    static int getTagWireType(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = binOpLit8_0xdd(v1, 7);
        return v0;
    }

    static int makeTag(int p0, int p1) {
        // Registers (3 total): v1 = p0 (int), v2 = p1 (int)
        v0 = binOpLit8_0xe0(v1, 3);
        v0 = binOp2addr_0xb6(v0, v2);
        return v0;
    }

}