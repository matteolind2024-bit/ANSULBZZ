package com.google.protobuf;

/**
 * Original SourceFile: GeneratedMessageLite.java
 * Descriptor: Lcom/google/protobuf/GeneratedMessageLite$SerializedForm;
 */
final class GeneratedMessageLite$SerializedForm implements java.io.Serializable {
    private static final long serialVersionUID;
    private byte[] asBytes;
    private java.lang.String messageClassName;

    GeneratedMessageLite$SerializedForm(com.google.protobuf.MessageLite p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.MessageLite)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getName(); // java.lang.Class.getName -> java.lang.String
        v0 = _result;
        v1.messageClassName = v0; // com.google.protobuf.GeneratedMessageLite$SerializedForm.messageClassName:java.lang.String
        _result = com.google.protobuf.MessageLite.toByteArray(v2); // -> byte[]
        v0 = _result;
        v1.asBytes = v0; // com.google.protobuf.GeneratedMessageLite$SerializedForm.asBytes:byte[]
        return;
    }

    protected java.lang.Object readResolve() {
        // Registers (4 total): v3 = this
        v0 = v3.messageClassName; // com.google.protobuf.GeneratedMessageLite$SerializedForm.messageClassName:java.lang.String
        _result = v0.forName(); // java.lang.Class.forName -> java.lang.Class
        v0 = _result;
        v1 = "newBuilder";
        v2 = 0;
        v2 = new java.lang.Class[][size=v2];
        _result = v0.getMethod(v1, v2); // java.lang.Class.getMethod -> java.lang.reflect.Method
        v0 = _result;
        v1 = 0;
        v2 = 0;
        v2 = new java.lang.Object[][size=v2];
        _result = v0.invoke(v1, v2); // java.lang.reflect.Method.invoke -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.MessageLite$Builder) v0;
        v1 = v3.asBytes; // com.google.protobuf.GeneratedMessageLite$SerializedForm.asBytes:byte[]
        _result = com.google.protobuf.MessageLite$Builder.mergeFrom(v0, v1); // -> com.google.protobuf.MessageLite$Builder
        _result = com.google.protobuf.MessageLite$Builder.buildPartial(v0); // -> com.google.protobuf.MessageLite
        v0 = _result;
        return v0;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "Unable to find proto buffer class";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "Unable to find newBuilder method";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "Unable to call newBuilder method";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "Error calling newBuilder";
        _result = v0.getCause(); // java.lang.reflect.InvocationTargetException.getCause -> java.lang.Throwable
        v0 = _result;
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "Unable to understand proto buffer";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
    }

}