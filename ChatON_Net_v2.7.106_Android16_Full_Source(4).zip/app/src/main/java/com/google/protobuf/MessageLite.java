package com.google.protobuf;

/**
 * Original SourceFile: MessageLite.java
 * Descriptor: Lcom/google/protobuf/MessageLite;
 */
public interface MessageLite extends com.google.protobuf.MessageLiteOrBuilder {
    public abstract int getSerializedSize();
    public abstract com.google.protobuf.MessageLite$Builder newBuilderForType();
    public abstract com.google.protobuf.MessageLite$Builder toBuilder();
    public abstract byte[] toByteArray();
    public abstract com.google.protobuf.ByteString toByteString();
    public abstract void writeDelimitedTo(java.io.OutputStream p0);
    public abstract void writeTo(com.google.protobuf.CodedOutputStream p0);
    public abstract void writeTo(java.io.OutputStream p0);
}