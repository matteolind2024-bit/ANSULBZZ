package com.google.protobuf;

/**
 * Original SourceFile: WireFormat.java
 * Descriptor: Lcom/google/protobuf/WireFormat$1;
 */
class WireFormat$1 {
}