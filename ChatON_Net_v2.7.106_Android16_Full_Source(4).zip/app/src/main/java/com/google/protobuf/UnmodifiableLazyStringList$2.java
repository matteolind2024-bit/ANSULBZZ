package com.google.protobuf;

/**
 * Original SourceFile: UnmodifiableLazyStringList.java
 * Descriptor: Lcom/google/protobuf/UnmodifiableLazyStringList$2;
 */
class UnmodifiableLazyStringList$2 implements java.util.Iterator {
     java.util.Iterator iter;
    final com.google.protobuf.UnmodifiableLazyStringList this$0;

    UnmodifiableLazyStringList$2(com.google.protobuf.UnmodifiableLazyStringList p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.UnmodifiableLazyStringList)
        v1.this$0 = v2; // com.google.protobuf.UnmodifiableLazyStringList$2.this$0:com.google.protobuf.UnmodifiableLazyStringList
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = v1.this$0; // com.google.protobuf.UnmodifiableLazyStringList$2.this$0:com.google.protobuf.UnmodifiableLazyStringList
        _result = v0.access$000(); // com.google.protobuf.UnmodifiableLazyStringList.access$000 -> com.google.protobuf.LazyStringList
        v0 = _result;
        _result = com.google.protobuf.LazyStringList.iterator(v0); // -> java.util.Iterator
        v0 = _result;
        v1.iter = v0; // com.google.protobuf.UnmodifiableLazyStringList$2.iter:java.util.Iterator
        return;
    }

    public boolean hasNext() {
        // Registers (2 total): v1 = this
        v0 = v1.iter; // com.google.protobuf.UnmodifiableLazyStringList$2.iter:java.util.Iterator
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.Object next() {
        // Registers (2 total): v1 = this
        _result = v1.next(); // com.google.protobuf.UnmodifiableLazyStringList$2.next -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String next() {
        // Registers (2 total): v1 = this
        v0 = v1.iter; // com.google.protobuf.UnmodifiableLazyStringList$2.iter:java.util.Iterator
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        return v0;
    }

    public void remove() {
        // Registers (2 total): v1 = this
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

}