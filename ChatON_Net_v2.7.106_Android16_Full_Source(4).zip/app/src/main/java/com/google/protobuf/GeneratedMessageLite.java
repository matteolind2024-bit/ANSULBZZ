package com.google.protobuf;

/**
 * Original SourceFile: GeneratedMessageLite.java
 * Descriptor: Lcom/google/protobuf/GeneratedMessageLite;
 */
public abstract class GeneratedMessageLite extends com.google.protobuf.AbstractMessageLite implements java.io.Serializable {
    private static final long serialVersionUID;

    protected GeneratedMessageLite() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // com.google.protobuf.AbstractMessageLite.<init> -> void
        return;
    }

    protected GeneratedMessageLite(com.google.protobuf.GeneratedMessageLite$Builder p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.google.protobuf.GeneratedMessageLite$Builder)
        _result = v0.<init>(); // com.google.protobuf.AbstractMessageLite.<init> -> void
        return;
    }

    public static com.google.protobuf.GeneratedMessageLite$GeneratedExtension newRepeatedGeneratedExtension(com.google.protobuf.MessageLite p0, com.google.protobuf.MessageLite p1, com.google.protobuf.Internal$EnumLiteMap p2, int p3, com.google.protobuf.WireFormat$FieldType p4, boolean p5) {
        // Registers (15 total): v9 = p0 (com.google.protobuf.MessageLite), v10 = p1 (com.google.protobuf.MessageLite), v11 = p2 (com.google.protobuf.Internal$EnumLiteMap), v12 = p3 (int), v13 = p4 (com.google.protobuf.WireFormat$FieldType), v14 = p5 (boolean)
        v6 = 0;
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v7 = _result;
        v8 = new com.google.protobuf.GeneratedMessageLite$GeneratedExtension;
        v0 = new com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor;
        v4 = 1;
        v1 = v11;
        v2 = v12;
        v3 = v13;
        v5 = v14;
        _result = v0.<init>(v0..v6); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.<init> -> void
        v1 = v8;
        v2 = v9;
        v3 = v7;
        v4 = v10;
        v5 = v0;
        _result = v1.<init>(v1..v6); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.<init> -> void
        return v8;
    }

    public static com.google.protobuf.GeneratedMessageLite$GeneratedExtension newSingularGeneratedExtension(com.google.protobuf.MessageLite p0, java.lang.Object p1, com.google.protobuf.MessageLite p2, com.google.protobuf.Internal$EnumLiteMap p3, int p4, com.google.protobuf.WireFormat$FieldType p5) {
        // Registers (14 total): v8 = p0 (com.google.protobuf.MessageLite), v9 = p1 (java.lang.Object), v10 = p2 (com.google.protobuf.MessageLite), v11 = p3 (com.google.protobuf.Internal$EnumLiteMap), v12 = p4 (int), v13 = p5 (com.google.protobuf.WireFormat$FieldType)
        v6 = 0;
        v4 = 0;
        v7 = new com.google.protobuf.GeneratedMessageLite$GeneratedExtension;
        v0 = new com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor;
        v1 = v11;
        v2 = v12;
        v3 = v13;
        v5 = v4;
        _result = v0.<init>(v0..v6); // com.google.protobuf.GeneratedMessageLite$ExtensionDescriptor.<init> -> void
        v1 = v7;
        v2 = v8;
        v3 = v9;
        v4 = v10;
        v5 = v0;
        _result = v1.<init>(v1..v6); // com.google.protobuf.GeneratedMessageLite$GeneratedExtension.<init> -> void
        return v7;
    }

    protected java.lang.Object writeReplace() {
        // Registers (2 total): v1 = this
        v0 = new com.google.protobuf.GeneratedMessageLite$SerializedForm;
        _result = v0.<init>(v1); // com.google.protobuf.GeneratedMessageLite$SerializedForm.<init> -> void
        return v0;
    }

}