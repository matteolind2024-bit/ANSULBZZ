package com.google.protobuf;

/**
 * Original SourceFile: FieldSet.java
 * Descriptor: Lcom/google/protobuf/FieldSet$1;
 */
class FieldSet$1 {
    static final int[] $SwitchMap$com$google$protobuf$WireFormat$FieldType;
    static final int[] $SwitchMap$com$google$protobuf$WireFormat$JavaType;

    static {
        _result = this.values(); // com.google.protobuf.WireFormat$FieldType.values -> com.google.protobuf.WireFormat$FieldType[]
        v0 = _result;
        v0 = v0.length;
        v0 = new int[][size=v0];
        com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType = v0; // :int[]
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.DOUBLE; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 1;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.FLOAT; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 2;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.INT64; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 3;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.UINT64; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 4;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.INT32; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 5;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.FIXED64; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 6;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.FIXED32; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 7;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.BOOL; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 8;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.STRING; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 9;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.BYTES; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 10;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.UINT32; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 11;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.SFIXED32; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 12;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.SFIXED64; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 13;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.SINT32; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 14;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.SINT64; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 15;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.GROUP; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 16;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.MESSAGE; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 17;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$FieldType; // :int[]
        v1 = com.google.protobuf.WireFormat$FieldType.ENUM; // :com.google.protobuf.WireFormat$FieldType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$FieldType.ordinal -> int
        v1 = _result;
        v2 = 18;
        v0[v1] = v2;
        _result = this.values(); // com.google.protobuf.WireFormat$JavaType.values -> com.google.protobuf.WireFormat$JavaType[]
        v0 = _result;
        v0 = v0.length;
        v0 = new int[][size=v0];
        com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType = v0; // :int[]
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        v1 = com.google.protobuf.WireFormat$JavaType.INT; // :com.google.protobuf.WireFormat$JavaType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v1 = _result;
        v2 = 1;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        v1 = com.google.protobuf.WireFormat$JavaType.LONG; // :com.google.protobuf.WireFormat$JavaType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v1 = _result;
        v2 = 2;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        v1 = com.google.protobuf.WireFormat$JavaType.FLOAT; // :com.google.protobuf.WireFormat$JavaType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v1 = _result;
        v2 = 3;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        v1 = com.google.protobuf.WireFormat$JavaType.DOUBLE; // :com.google.protobuf.WireFormat$JavaType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v1 = _result;
        v2 = 4;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        v1 = com.google.protobuf.WireFormat$JavaType.BOOLEAN; // :com.google.protobuf.WireFormat$JavaType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v1 = _result;
        v2 = 5;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        v1 = com.google.protobuf.WireFormat$JavaType.STRING; // :com.google.protobuf.WireFormat$JavaType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v1 = _result;
        v2 = 6;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        v1 = com.google.protobuf.WireFormat$JavaType.BYTE_STRING; // :com.google.protobuf.WireFormat$JavaType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v1 = _result;
        v2 = 7;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        v1 = com.google.protobuf.WireFormat$JavaType.ENUM; // :com.google.protobuf.WireFormat$JavaType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v1 = _result;
        v2 = 8;
        v0[v1] = v2;
        v0 = com.google.protobuf.FieldSet$1.$SwitchMap$com$google$protobuf$WireFormat$JavaType; // :int[]
        v1 = com.google.protobuf.WireFormat$JavaType.MESSAGE; // :com.google.protobuf.WireFormat$JavaType
        _result = v1.ordinal(); // com.google.protobuf.WireFormat$JavaType.ordinal -> int
        v1 = _result;
        v2 = 9;
        v0[v1] = v2;
        return;
        v0 = _exception;
        // goto L_0148
        v0 = _exception;
        // goto L_013c
        v0 = _exception;
        // goto L_0130
        v0 = _exception;
        // goto L_0125
        v0 = _exception;
        // goto L_011a
        v0 = _exception;
        // goto L_010f
        v0 = _exception;
        // goto L_0104
        v0 = _exception;
        // goto L_00f9
        v0 = _exception;
        // goto L_00ee
        v0 = _exception;
        // goto L_00da
        v0 = _exception;
        // goto L_00ce
        v0 = _exception;
        // goto L_00c2
        v0 = _exception;
        // goto L_00b6
        v0 = _exception;
        // goto L_00aa
        v0 = _exception;
        // goto L_009e
        v0 = _exception;
        // goto L_0092
        v0 = _exception;
        // goto L_0086
        v0 = _exception;
        // goto L_007a
        v0 = _exception;
        // goto L_006e
        v0 = _exception;
        // goto L_0062
        v0 = _exception;
        // goto L_0056
        v0 = _exception;
        // goto L_004b
        v0 = _exception;
        // goto L_0040
        v0 = _exception;
        // goto L_0035
        v0 = _exception;
        // goto L_002a
        v0 = _exception;
        // goto L_001f
        v0 = _exception;
        // goto L_0014
    }

}