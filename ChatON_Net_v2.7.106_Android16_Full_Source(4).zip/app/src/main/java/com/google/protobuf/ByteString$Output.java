package com.google.protobuf;

/**
 * Original SourceFile: ByteString.java
 * Descriptor: Lcom/google/protobuf/ByteString$Output;
 */
public final class ByteString$Output extends java.io.FilterOutputStream {
    private final java.io.ByteArrayOutputStream bout;

    private ByteString$Output(java.io.ByteArrayOutputStream p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.io.ByteArrayOutputStream)
        _result = v0.<init>(v1); // java.io.FilterOutputStream.<init> -> void
        v0.bout = v1; // com.google.protobuf.ByteString$Output.bout:java.io.ByteArrayOutputStream
        return;
    }

    ByteString$Output(java.io.ByteArrayOutputStream p0, com.google.protobuf.ByteString$1 p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.io.ByteArrayOutputStream), v2 = p1 (com.google.protobuf.ByteString$1)
        _result = v0.<init>(v1); // com.google.protobuf.ByteString$Output.<init> -> void
        return;
    }

    public com.google.protobuf.ByteString toByteString() {
        // Registers (4 total): v3 = this
        v0 = v3.bout; // com.google.protobuf.ByteString$Output.bout:java.io.ByteArrayOutputStream
        _result = v0.toByteArray(); // java.io.ByteArrayOutputStream.toByteArray -> byte[]
        v0 = _result;
        v1 = new com.google.protobuf.ByteString;
        v2 = 0;
        _result = v1.<init>(v0, v2); // com.google.protobuf.ByteString.<init> -> void
        return v1;
    }

}