package com.google.protobuf;

/**
 * Original SourceFile: SmallSortedMap.java
 * Descriptor: Lcom/google/protobuf/SmallSortedMap$EntrySet;
 */
class SmallSortedMap$EntrySet extends java.util.AbstractSet {
    final com.google.protobuf.SmallSortedMap this$0;

    private SmallSortedMap$EntrySet(com.google.protobuf.SmallSortedMap p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.google.protobuf.SmallSortedMap)
        v0.this$0 = v1; // com.google.protobuf.SmallSortedMap$EntrySet.this$0:com.google.protobuf.SmallSortedMap
        _result = v0.<init>(); // java.util.AbstractSet.<init> -> void
        return;
    }

    SmallSortedMap$EntrySet(com.google.protobuf.SmallSortedMap p0, com.google.protobuf.SmallSortedMap$1 p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.google.protobuf.SmallSortedMap), v2 = p1 (com.google.protobuf.SmallSortedMap$1)
        _result = v0.<init>(v1); // com.google.protobuf.SmallSortedMap$EntrySet.<init> -> void
        return;
    }

    public boolean add(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v2 = (java.util.Map$Entry) v2;
        _result = v1.add(v2); // com.google.protobuf.SmallSortedMap$EntrySet.add -> boolean
        v0 = _result;
        return v0;
    }

    public boolean add(java.util.Map$Entry p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.util.Map$Entry)
        _result = v3.contains(v4); // com.google.protobuf.SmallSortedMap$EntrySet.contains -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        v1 = v3.this$0; // com.google.protobuf.SmallSortedMap$EntrySet.this$0:com.google.protobuf.SmallSortedMap
        _result = java.util.Map$Entry.getKey(v4); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Comparable) v0;
        _result = java.util.Map$Entry.getValue(v4); // -> java.lang.Object
        v2 = _result;
        _result = v1.put(v0, v2); // com.google.protobuf.SmallSortedMap.put -> java.lang.Object
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0016
    }

    public void clear() {
        // Registers (2 total): v1 = this
        v0 = v1.this$0; // com.google.protobuf.SmallSortedMap$EntrySet.this$0:com.google.protobuf.SmallSortedMap
        _result = v0.clear(); // com.google.protobuf.SmallSortedMap.clear -> void
        return;
    }

    public boolean contains(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v3 = (java.util.Map$Entry) v3;
        v0 = v2.this$0; // com.google.protobuf.SmallSortedMap$EntrySet.this$0:com.google.protobuf.SmallSortedMap
        _result = java.util.Map$Entry.getKey(v3); // -> java.lang.Object
        v1 = _result;
        _result = v0.get(v1); // com.google.protobuf.SmallSortedMap.get -> java.lang.Object
        v0 = _result;
        _result = java.util.Map$Entry.getValue(v3); // -> java.lang.Object
        v1 = _result;
        if (v0 == v1) /* goto L_001a */;
        if (v0 == 0) /* goto L_001c */;
        _result = v0.equals(v1); // java.lang.Object.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_001b
    }

    public java.util.Iterator iterator() {
        // Registers (4 total): v3 = this
        v0 = new com.google.protobuf.SmallSortedMap$EntryIterator;
        v1 = v3.this$0; // com.google.protobuf.SmallSortedMap$EntrySet.this$0:com.google.protobuf.SmallSortedMap
        v2 = 0;
        _result = v0.<init>(v1, v2); // com.google.protobuf.SmallSortedMap$EntryIterator.<init> -> void
        return v0;
    }

    public boolean remove(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v3 = (java.util.Map$Entry) v3;
        _result = v2.contains(v3); // com.google.protobuf.SmallSortedMap$EntrySet.contains -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0013 */;
        v0 = v2.this$0; // com.google.protobuf.SmallSortedMap$EntrySet.this$0:com.google.protobuf.SmallSortedMap
        _result = java.util.Map$Entry.getKey(v3); // -> java.lang.Object
        v1 = _result;
        _result = v0.remove(v1); // com.google.protobuf.SmallSortedMap.remove -> java.lang.Object
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0012
    }

    public int size() {
        // Registers (2 total): v1 = this
        v0 = v1.this$0; // com.google.protobuf.SmallSortedMap$EntrySet.this$0:com.google.protobuf.SmallSortedMap
        _result = v0.size(); // com.google.protobuf.SmallSortedMap.size -> int
        v0 = _result;
        return v0;
    }

}