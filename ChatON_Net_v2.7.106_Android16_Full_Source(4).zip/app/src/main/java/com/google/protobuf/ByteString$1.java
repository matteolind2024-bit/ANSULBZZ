package com.google.protobuf;

/**
 * Original SourceFile: ByteString.java
 * Descriptor: Lcom/google/protobuf/ByteString$1;
 */
class ByteString$1 {
}