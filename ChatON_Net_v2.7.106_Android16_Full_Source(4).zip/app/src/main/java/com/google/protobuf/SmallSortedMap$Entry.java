package com.google.protobuf;

/**
 * Original SourceFile: SmallSortedMap.java
 * Descriptor: Lcom/google/protobuf/SmallSortedMap$Entry;
 */
class SmallSortedMap$Entry implements java.lang.Comparable, java.util.Map$Entry {
    private final java.lang.Comparable key;
    final com.google.protobuf.SmallSortedMap this$0;
    private java.lang.Object value;

    SmallSortedMap$Entry(com.google.protobuf.SmallSortedMap p0, java.lang.Comparable p1, java.lang.Object p2) {
        // Registers (4 total): v0 = this, v1 = p0 (com.google.protobuf.SmallSortedMap), v2 = p1 (java.lang.Comparable), v3 = p2 (java.lang.Object)
        v0.this$0 = v1; // com.google.protobuf.SmallSortedMap$Entry.this$0:com.google.protobuf.SmallSortedMap
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.key = v2; // com.google.protobuf.SmallSortedMap$Entry.key:java.lang.Comparable
        v0.value = v3; // com.google.protobuf.SmallSortedMap$Entry.value:java.lang.Object
        return;
    }

    SmallSortedMap$Entry(com.google.protobuf.SmallSortedMap p0, java.util.Map$Entry p1) {
        // Registers (5 total): v2 = this, v3 = p0 (com.google.protobuf.SmallSortedMap), v4 = p1 (java.util.Map$Entry)
        _result = java.util.Map$Entry.getKey(v4); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Comparable) v0;
        _result = java.util.Map$Entry.getValue(v4); // -> java.lang.Object
        v1 = _result;
        _result = v2.<init>(v3, v0, v1); // com.google.protobuf.SmallSortedMap$Entry.<init> -> void
        return;
    }

    private boolean equals(java.lang.Object p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (java.lang.Object)
        if (v2 != 0) /* goto L_0008 */;
        if (v3 != 0) /* goto L_0006 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0005
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v0 = _result;
        // goto L_0005
    }

    public int compareTo(com.google.protobuf.SmallSortedMap$Entry p0) {
        // Registers (4 total): v2 = this, v3 = p0 (com.google.protobuf.SmallSortedMap$Entry)
        _result = v2.getKey(); // com.google.protobuf.SmallSortedMap$Entry.getKey -> java.lang.Comparable
        v0 = _result;
        _result = v3.getKey(); // com.google.protobuf.SmallSortedMap$Entry.getKey -> java.lang.Comparable
        v1 = _result;
        _result = java.lang.Comparable.compareTo(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int compareTo(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v2 = (com.google.protobuf.SmallSortedMap$Entry) v2;
        _result = v1.compareTo(v2); // com.google.protobuf.SmallSortedMap$Entry.compareTo -> int
        v0 = _result;
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v5 != v4) /* goto L_0005 */;
        return v0;
        v2 = (v5 instanceof java.util.Map$Entry);
        if (v2 != 0) /* goto L_000b */;
        v0 = v1;
        // goto L_0004
        v5 = (java.util.Map$Entry) v5;
        v2 = v4.key; // com.google.protobuf.SmallSortedMap$Entry.key:java.lang.Comparable
        _result = java.util.Map$Entry.getKey(v5); // -> java.lang.Object
        v3 = _result;
        _result = v4.equals(v2, v3); // com.google.protobuf.SmallSortedMap$Entry.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0025 */;
        v2 = v4.value; // com.google.protobuf.SmallSortedMap$Entry.value:java.lang.Object
        _result = java.util.Map$Entry.getValue(v5); // -> java.lang.Object
        v3 = _result;
        _result = v4.equals(v2, v3); // com.google.protobuf.SmallSortedMap$Entry.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public java.lang.Comparable getKey() {
        // Registers (2 total): v1 = this
        v0 = v1.key; // com.google.protobuf.SmallSortedMap$Entry.key:java.lang.Comparable
        return v0;
    }

    public java.lang.Object getKey() {
        // Registers (2 total): v1 = this
        _result = v1.getKey(); // com.google.protobuf.SmallSortedMap$Entry.getKey -> java.lang.Comparable
        v0 = _result;
        return v0;
    }

    public java.lang.Object getValue() {
        // Registers (2 total): v1 = this
        v0 = v1.value; // com.google.protobuf.SmallSortedMap$Entry.value:java.lang.Object
        return v0;
    }

    public int hashCode() {
        // Registers (4 total): v3 = this
        v1 = 0;
        v0 = v3.key; // com.google.protobuf.SmallSortedMap$Entry.key:java.lang.Comparable
        if (v0 != 0) /* goto L_000c */;
        v0 = v1;
        v2 = v3.value; // com.google.protobuf.SmallSortedMap$Entry.value:java.lang.Object
        if (v2 != 0) /* goto L_0013 */;
        v0 = binOp2addr_0xb7(v0, v1);
        return v0;
        v0 = v3.key; // com.google.protobuf.SmallSortedMap$Entry.key:java.lang.Comparable
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        // goto L_0006
        v1 = v3.value; // com.google.protobuf.SmallSortedMap$Entry.value:java.lang.Object
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        // goto L_000a
    }

    public java.lang.Object setValue(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = v1.this$0; // com.google.protobuf.SmallSortedMap$Entry.this$0:com.google.protobuf.SmallSortedMap
        _result = v0.access$200(); // com.google.protobuf.SmallSortedMap.access$200 -> void
        v0 = v1.value; // com.google.protobuf.SmallSortedMap$Entry.value:java.lang.Object
        v1.value = v2; // com.google.protobuf.SmallSortedMap$Entry.value:java.lang.Object
        return v0;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = v2.key; // com.google.protobuf.SmallSortedMap$Entry.key:java.lang.Comparable
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.value; // com.google.protobuf.SmallSortedMap$Entry.value:java.lang.Object
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}