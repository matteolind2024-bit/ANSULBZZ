package com.google.protobuf;

/**
 * Original SourceFile: ExtensionRegistryLite.java
 * Descriptor: Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;
 */
final class ExtensionRegistryLite$ObjectIntPair {
    private final int number;
    private final java.lang.Object object;

    ExtensionRegistryLite$ObjectIntPair(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.object = v1; // com.google.protobuf.ExtensionRegistryLite$ObjectIntPair.object:java.lang.Object
        v0.number = v2; // com.google.protobuf.ExtensionRegistryLite$ObjectIntPair.number:int
        return;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.Object)
        v0 = 0;
        v1 = (v4 instanceof com.google.protobuf.ExtensionRegistryLite$ObjectIntPair);
        if (v1 != 0) /* goto L_0006 */;
        return v0;
        v4 = (com.google.protobuf.ExtensionRegistryLite$ObjectIntPair) v4;
        v1 = v3.object; // com.google.protobuf.ExtensionRegistryLite$ObjectIntPair.object:java.lang.Object
        v2 = v4.object; // com.google.protobuf.ExtensionRegistryLite$ObjectIntPair.object:java.lang.Object
        if (v1 != v2) /* goto L_0005 */;
        v1 = v3.number; // com.google.protobuf.ExtensionRegistryLite$ObjectIntPair.number:int
        v2 = v4.number; // com.google.protobuf.ExtensionRegistryLite$ObjectIntPair.number:int
        if (v1 != v2) /* goto L_0005 */;
        v0 = 1;
        // goto L_0005
    }

    public int hashCode() {
        // Registers (3 total): v2 = this
        v0 = v2.object; // com.google.protobuf.ExtensionRegistryLite$ObjectIntPair.object:java.lang.Object
        _result = v0.identityHashCode(); // java.lang.System.identityHashCode -> int
        v0 = _result;
        v1 = 65535; // 0x0000ffff
        v0 = binOp2addr_0xb2(v0, v1);
        v1 = v2.number; // com.google.protobuf.ExtensionRegistryLite$ObjectIntPair.number:int
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

}