package com.google.protobuf;

/**
 * Original SourceFile: ByteString.java
 * Descriptor: Lcom/google/protobuf/ByteString;
 */
public final class ByteString {
    public static final com.google.protobuf.ByteString EMPTY;
    private final byte[] bytes;
    private volatile int hash;

    static {
        v0 = new com.google.protobuf.ByteString;
        v1 = 0;
        v1 = new byte[][size=v1];
        _result = v0.<init>(v1); // com.google.protobuf.ByteString.<init> -> void
        com.google.protobuf.ByteString.EMPTY = v0; // :com.google.protobuf.ByteString
        return;
    }

    private ByteString(byte[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (byte[])
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v1.hash = v0; // com.google.protobuf.ByteString.hash:int
        v1.bytes = v2; // com.google.protobuf.ByteString.bytes:byte[]
        return;
    }

    ByteString(byte[] p0, com.google.protobuf.ByteString$1 p1) {
        // Registers (3 total): v0 = this, v1 = p0 (byte[]), v2 = p1 (com.google.protobuf.ByteString$1)
        _result = v0.<init>(v1); // com.google.protobuf.ByteString.<init> -> void
        return;
    }

    public static com.google.protobuf.ByteString copyFrom(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        v0 = new com.google.protobuf.ByteString;
        _result = v2.getBytes(v3); // java.lang.String.getBytes -> byte[]
        v1 = _result;
        _result = v0.<init>(v1); // com.google.protobuf.ByteString.<init> -> void
        return v0;
    }

    public static com.google.protobuf.ByteString copyFrom(java.nio.ByteBuffer p0) {
        // Registers (2 total): v1 = p0 (java.nio.ByteBuffer)
        _result = v1.remaining(); // java.nio.ByteBuffer.remaining -> int
        v0 = _result;
        _result = v1.copyFrom(v0); // com.google.protobuf.ByteString.copyFrom -> com.google.protobuf.ByteString
        v0 = _result;
        return v0;
    }

    public static com.google.protobuf.ByteString copyFrom(java.nio.ByteBuffer p0, int p1) {
        // Registers (4 total): v2 = p0 (java.nio.ByteBuffer), v3 = p1 (int)
        v0 = new byte[][size=v3];
        _result = v2.get(v0); // java.nio.ByteBuffer.get -> java.nio.ByteBuffer
        v1 = new com.google.protobuf.ByteString;
        _result = v1.<init>(v0); // com.google.protobuf.ByteString.<init> -> void
        return v1;
    }

    public static com.google.protobuf.ByteString copyFrom(java.util.List p0) {
        // Registers (8 total): v7 = p0 (java.util.List)
        v2 = 0;
        _result = java.util.List.size(v7); // -> int
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v0 = com.google.protobuf.ByteString.EMPTY; // :com.google.protobuf.ByteString
        return v0;
        _result = java.util.List.size(v7); // -> int
        v0 = _result;
        v1 = 1;
        if (v0 != v1) /* goto L_0018 */;
        _result = java.util.List.get(v7, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.ByteString) v0;
        // goto L_0009
        _result = java.util.List.iterator(v7); // -> java.util.Iterator
        v3 = _result;
        v1 = v2;
        _result = java.util.Iterator.hasNext(v3); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0030 */;
        _result = java.util.Iterator.next(v3); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.ByteString) v0;
        _result = v0.size(); // com.google.protobuf.ByteString.size -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v0;
        // goto L_001d
        v3 = new byte[][size=v1];
        _result = java.util.List.iterator(v7); // -> java.util.Iterator
        v4 = _result;
        v1 = v2;
        _result = java.util.Iterator.hasNext(v4); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0053 */;
        _result = java.util.Iterator.next(v4); // -> java.lang.Object
        v0 = _result;
        v0 = (com.google.protobuf.ByteString) v0;
        v5 = v0.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        _result = v0.size(); // com.google.protobuf.ByteString.size -> int
        v6 = _result;
        _result = v5.arraycopy(v2, v3, v1, v6); // java.lang.System.arraycopy -> void
        _result = v0.size(); // com.google.protobuf.ByteString.size -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v0;
        // goto L_0037
        v0 = new com.google.protobuf.ByteString;
        _result = v0.<init>(v3); // com.google.protobuf.ByteString.<init> -> void
        // goto L_0009
    }

    public static com.google.protobuf.ByteString copyFrom(byte[] p0) {
        // Registers (3 total): v2 = p0 (byte[])
        v0 = 0;
        v1 = v2.length;
        _result = v2.copyFrom(v0, v1); // com.google.protobuf.ByteString.copyFrom -> com.google.protobuf.ByteString
        v0 = _result;
        return v0;
    }

    public static com.google.protobuf.ByteString copyFrom(byte[] p0, int p1, int p2) {
        // Registers (5 total): v2 = p0 (byte[]), v3 = p1 (int), v4 = p2 (int)
        v0 = new byte[][size=v4];
        v1 = 0;
        _result = v2.arraycopy(v3, v0, v1, v4); // java.lang.System.arraycopy -> void
        v1 = new com.google.protobuf.ByteString;
        _result = v1.<init>(v0); // com.google.protobuf.ByteString.<init> -> void
        return v1;
    }

    public static com.google.protobuf.ByteString copyFromUtf8(java.lang.String p0) {
        // Registers (4 total): v3 = p0 (java.lang.String)
        v0 = new com.google.protobuf.ByteString;
        v1 = "UTF-8";
        _result = v3.getBytes(v1); // java.lang.String.getBytes -> byte[]
        v1 = _result;
        _result = v0.<init>(v1); // com.google.protobuf.ByteString.<init> -> void
        return v0;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "UTF-8 not supported?";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
    }

    static com.google.protobuf.ByteString$CodedBuilder newCodedBuilder(int p0) {
        // Registers (3 total): v2 = p0 (int)
        v0 = new com.google.protobuf.ByteString$CodedBuilder;
        v1 = 0;
        _result = v0.<init>(v2, v1); // com.google.protobuf.ByteString$CodedBuilder.<init> -> void
        return v0;
    }

    public static com.google.protobuf.ByteString$Output newOutput() {
        v0 = 32;
        _result = v0.newOutput(); // com.google.protobuf.ByteString.newOutput -> com.google.protobuf.ByteString$Output
        v0 = _result;
        return v0;
    }

    public static com.google.protobuf.ByteString$Output newOutput(int p0) {
        // Registers (4 total): v3 = p0 (int)
        v0 = new com.google.protobuf.ByteString$Output;
        v1 = new java.io.ByteArrayOutputStream;
        _result = v1.<init>(v3); // java.io.ByteArrayOutputStream.<init> -> void
        v2 = 0;
        _result = v0.<init>(v1, v2); // com.google.protobuf.ByteString$Output.<init> -> void
        return v0;
    }

    public java.nio.ByteBuffer asReadOnlyByteBuffer() {
        // Registers (2 total): v1 = this
        v0 = v1.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        _result = v0.wrap(); // java.nio.ByteBuffer.wrap -> java.nio.ByteBuffer
        v0 = _result;
        _result = v0.asReadOnlyBuffer(); // java.nio.ByteBuffer.asReadOnlyBuffer -> java.nio.ByteBuffer
        v0 = _result;
        return v0;
    }

    public byte byteAt(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v0 = v0[v2];
        return v0;
    }

    public void copyTo(java.nio.ByteBuffer p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.nio.ByteBuffer)
        v0 = v3.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v1 = 0;
        v2 = v3.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v2 = v2.length;
        _result = v4.put(v0, v1, v2); // java.nio.ByteBuffer.put -> java.nio.ByteBuffer
        return;
    }

    public void copyTo(byte[] p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (byte[]), v5 = p1 (int)
        v0 = v3.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v1 = 0;
        v2 = v3.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v2 = v2.length;
        _result = v0.arraycopy(v1, v4, v5, v2); // java.lang.System.arraycopy -> void
        return;
    }

    public void copyTo(byte[] p0, int p1, int p2, int p3) {
        // Registers (6 total): v1 = this, v2 = p0 (byte[]), v3 = p1 (int), v4 = p2 (int), v5 = p3 (int)
        v0 = v1.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        _result = v0.arraycopy(v3, v2, v4, v5); // java.lang.System.arraycopy -> void
        return;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (10 total): v8 = this, v9 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v9 != v8) /* goto L_0005 */;
        return v0;
        v2 = (v9 instanceof com.google.protobuf.ByteString);
        if (v2 != 0) /* goto L_000b */;
        v0 = v1;
        // goto L_0004
        v9 = (com.google.protobuf.ByteString) v9;
        v2 = v8.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v3 = v2.length;
        v2 = v9.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v2 = v2.length;
        if (v3 == v2) /* goto L_0017 */;
        v0 = v1;
        // goto L_0004
        v4 = v8.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v5 = v9.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v2 = v1;
        if (v2 >= v3) /* goto L_0004 */;
        v6 = v4[v2];
        v7 = v5[v2];
        if (v6 == v7) /* goto L_0026 */;
        v0 = v1;
        // goto L_0004
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_001c
    }

    public int hashCode() {
        // Registers (6 total): v5 = this
        v0 = v5.hash; // com.google.protobuf.ByteString.hash:int
        if (v0 != 0) /* goto L_001d */;
        v4 = v5.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v0 = v5.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v2 = v0.length;
        v0 = 0;
        v1 = v0;
        v0 = v2;
        if (v1 >= v2) /* goto L_0018 */;
        v0 = binOpLit8_0xda(v0, 31);
        v3 = v4[v1];
        v3 = binOp2addr_0xb0(v3, v0);
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        v0 = v3;
        // goto L_000c
        if (v0 != 0) /* goto L_001b */;
        v0 = 1;
        v5.hash = v0; // com.google.protobuf.ByteString.hash:int
        return v0;
    }

    public boolean isEmpty() {
        // Registers (2 total): v1 = this
        v0 = v1.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v0 = v0.length;
        if (v0 != 0) /* goto L_0007 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0006
    }

    public com.google.protobuf.CodedInputStream newCodedInput() {
        // Registers (2 total): v1 = this
        v0 = v1.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        _result = v0.newInstance(); // com.google.protobuf.CodedInputStream.newInstance -> com.google.protobuf.CodedInputStream
        v0 = _result;
        return v0;
    }

    public java.io.InputStream newInput() {
        // Registers (3 total): v2 = this
        v0 = new java.io.ByteArrayInputStream;
        v1 = v2.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        _result = v0.<init>(v1); // java.io.ByteArrayInputStream.<init> -> void
        return v0;
    }

    public int size() {
        // Registers (2 total): v1 = this
        v0 = v1.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v0 = v0.length;
        return v0;
    }

    public byte[] toByteArray() {
        // Registers (5 total): v4 = this
        v3 = 0;
        v0 = v4.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v0 = v0.length;
        v1 = new byte[][size=v0];
        v2 = v4.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        _result = v2.arraycopy(v3, v1, v3, v0); // java.lang.System.arraycopy -> void
        return v1;
    }

    public java.lang.String toString(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = new java.lang.String;
        v1 = v2.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        _result = v0.<init>(v1, v3); // java.lang.String.<init> -> void
        return v0;
    }

    public java.lang.String toStringUtf8() {
        // Registers (4 total): v3 = this
        v0 = new java.lang.String;
        v1 = v3.bytes; // com.google.protobuf.ByteString.bytes:byte[]
        v2 = "UTF-8";
        _result = v0.<init>(v1, v2); // java.lang.String.<init> -> void
        return v0;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "UTF-8 not supported?";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
    }

}