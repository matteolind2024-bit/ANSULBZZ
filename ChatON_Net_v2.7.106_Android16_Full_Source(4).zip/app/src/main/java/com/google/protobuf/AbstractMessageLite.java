package com.google.protobuf;

/**
 * Original SourceFile: AbstractMessageLite.java
 * Descriptor: Lcom/google/protobuf/AbstractMessageLite;
 */
public abstract class AbstractMessageLite implements com.google.protobuf.MessageLite {
    public AbstractMessageLite() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public byte[] toByteArray() {
        // Registers (4 total): v3 = this
        _result = v3.getSerializedSize(); // com.google.protobuf.AbstractMessageLite.getSerializedSize -> int
        v0 = _result;
        v0 = new byte[][size=v0];
        _result = v0.newInstance(); // com.google.protobuf.CodedOutputStream.newInstance -> com.google.protobuf.CodedOutputStream
        v1 = _result;
        _result = v3.writeTo(v1); // com.google.protobuf.AbstractMessageLite.writeTo -> void
        _result = v1.checkNoSpaceLeft(); // com.google.protobuf.CodedOutputStream.checkNoSpaceLeft -> void
        return v0;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "Serializing to a byte array threw an IOException (should never happen).";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
    }

    public com.google.protobuf.ByteString toByteString() {
        // Registers (4 total): v3 = this
        _result = v3.getSerializedSize(); // com.google.protobuf.AbstractMessageLite.getSerializedSize -> int
        v0 = _result;
        _result = v0.newCodedBuilder(); // com.google.protobuf.ByteString.newCodedBuilder -> com.google.protobuf.ByteString$CodedBuilder
        v0 = _result;
        _result = v0.getCodedOutput(); // com.google.protobuf.ByteString$CodedBuilder.getCodedOutput -> com.google.protobuf.CodedOutputStream
        v1 = _result;
        _result = v3.writeTo(v1); // com.google.protobuf.AbstractMessageLite.writeTo -> void
        _result = v0.build(); // com.google.protobuf.ByteString$CodedBuilder.build -> com.google.protobuf.ByteString
        v0 = _result;
        return v0;
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "Serializing to a ByteString threw an IOException (should never happen).";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
    }

    public void writeDelimitedTo(java.io.OutputStream p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.io.OutputStream)
        _result = v2.getSerializedSize(); // com.google.protobuf.AbstractMessageLite.getSerializedSize -> int
        v0 = _result;
        _result = v0.computeRawVarint32Size(); // com.google.protobuf.CodedOutputStream.computeRawVarint32Size -> int
        v1 = _result;
        v1 = binOp2addr_0xb0(v1, v0);
        _result = v1.computePreferredBufferSize(); // com.google.protobuf.CodedOutputStream.computePreferredBufferSize -> int
        v1 = _result;
        _result = v3.newInstance(v1); // com.google.protobuf.CodedOutputStream.newInstance -> com.google.protobuf.CodedOutputStream
        v1 = _result;
        _result = v1.writeRawVarint32(v0); // com.google.protobuf.CodedOutputStream.writeRawVarint32 -> void
        _result = v2.writeTo(v1); // com.google.protobuf.AbstractMessageLite.writeTo -> void
        _result = v1.flush(); // com.google.protobuf.CodedOutputStream.flush -> void
        return;
    }

    public void writeTo(java.io.OutputStream p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.io.OutputStream)
        _result = v1.getSerializedSize(); // com.google.protobuf.AbstractMessageLite.getSerializedSize -> int
        v0 = _result;
        _result = v0.computePreferredBufferSize(); // com.google.protobuf.CodedOutputStream.computePreferredBufferSize -> int
        v0 = _result;
        _result = v2.newInstance(v0); // com.google.protobuf.CodedOutputStream.newInstance -> com.google.protobuf.CodedOutputStream
        v0 = _result;
        _result = v1.writeTo(v0); // com.google.protobuf.AbstractMessageLite.writeTo -> void
        _result = v0.flush(); // com.google.protobuf.CodedOutputStream.flush -> void
        return;
    }

}