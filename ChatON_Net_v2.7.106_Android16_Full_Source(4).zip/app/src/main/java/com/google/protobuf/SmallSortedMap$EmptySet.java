package com.google.protobuf;

/**
 * Original SourceFile: SmallSortedMap.java
 * Descriptor: Lcom/google/protobuf/SmallSortedMap$EmptySet;
 */
class SmallSortedMap$EmptySet {
    private static final java.lang.Iterable ITERABLE;
    private static final java.util.Iterator ITERATOR;

    static {
        v0 = new com.google.protobuf.SmallSortedMap$EmptySet$1;
        _result = v0.<init>(); // com.google.protobuf.SmallSortedMap$EmptySet$1.<init> -> void
        com.google.protobuf.SmallSortedMap$EmptySet.ITERATOR = v0; // :java.util.Iterator
        v0 = new com.google.protobuf.SmallSortedMap$EmptySet$2;
        _result = v0.<init>(); // com.google.protobuf.SmallSortedMap$EmptySet$2.<init> -> void
        com.google.protobuf.SmallSortedMap$EmptySet.ITERABLE = v0; // :java.lang.Iterable
        return;
    }

    private SmallSortedMap$EmptySet() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    static java.util.Iterator access$700() {
        v0 = com.google.protobuf.SmallSortedMap$EmptySet.ITERATOR; // :java.util.Iterator
        return v0;
    }

    static java.lang.Iterable iterable() {
        v0 = com.google.protobuf.SmallSortedMap$EmptySet.ITERABLE; // :java.lang.Iterable
        return v0;
    }

}