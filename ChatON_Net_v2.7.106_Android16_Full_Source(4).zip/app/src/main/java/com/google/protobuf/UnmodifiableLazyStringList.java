package com.google.protobuf;

/**
 * Original SourceFile: UnmodifiableLazyStringList.java
 * Descriptor: Lcom/google/protobuf/UnmodifiableLazyStringList;
 */
public class UnmodifiableLazyStringList extends java.util.AbstractList implements com.google.protobuf.LazyStringList, java.util.RandomAccess {
    private final com.google.protobuf.LazyStringList list;

    public UnmodifiableLazyStringList(com.google.protobuf.LazyStringList p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.google.protobuf.LazyStringList)
        _result = v0.<init>(); // java.util.AbstractList.<init> -> void
        v0.list = v1; // com.google.protobuf.UnmodifiableLazyStringList.list:com.google.protobuf.LazyStringList
        return;
    }

    static com.google.protobuf.LazyStringList access$000(com.google.protobuf.UnmodifiableLazyStringList p0) {
        // Registers (2 total): v1 = p0 (com.google.protobuf.UnmodifiableLazyStringList)
        v0 = v1.list; // com.google.protobuf.UnmodifiableLazyStringList.list:com.google.protobuf.LazyStringList
        return v0;
    }

    public void add(com.google.protobuf.ByteString p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.google.protobuf.ByteString)
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public java.lang.Object get(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.get(v2); // com.google.protobuf.UnmodifiableLazyStringList.get -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String get(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.list; // com.google.protobuf.UnmodifiableLazyStringList.list:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.get(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        return v0;
    }

    public com.google.protobuf.ByteString getByteString(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.list; // com.google.protobuf.UnmodifiableLazyStringList.list:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.getByteString(v0, v2); // -> com.google.protobuf.ByteString
        v0 = _result;
        return v0;
    }

    public java.util.Iterator iterator() {
        // Registers (2 total): v1 = this
        v0 = new com.google.protobuf.UnmodifiableLazyStringList$2;
        _result = v0.<init>(v1); // com.google.protobuf.UnmodifiableLazyStringList$2.<init> -> void
        return v0;
    }

    public java.util.ListIterator listIterator(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = new com.google.protobuf.UnmodifiableLazyStringList$1;
        _result = v0.<init>(v1, v2); // com.google.protobuf.UnmodifiableLazyStringList$1.<init> -> void
        return v0;
    }

    public int size() {
        // Registers (2 total): v1 = this
        v0 = v1.list; // com.google.protobuf.UnmodifiableLazyStringList.list:com.google.protobuf.LazyStringList
        _result = com.google.protobuf.LazyStringList.size(v0); // -> int
        v0 = _result;
        return v0;
    }

}