package com.google.protobuf;

/**
 * Original SourceFile: ByteString.java
 * Descriptor: Lcom/google/protobuf/ByteString$CodedBuilder;
 */
final class ByteString$CodedBuilder {
    private final byte[] buffer;
    private final com.google.protobuf.CodedOutputStream output;

    private ByteString$CodedBuilder(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new byte[][size=v2];
        v1.buffer = v0; // com.google.protobuf.ByteString$CodedBuilder.buffer:byte[]
        v0 = v1.buffer; // com.google.protobuf.ByteString$CodedBuilder.buffer:byte[]
        _result = v0.newInstance(); // com.google.protobuf.CodedOutputStream.newInstance -> com.google.protobuf.CodedOutputStream
        v0 = _result;
        v1.output = v0; // com.google.protobuf.ByteString$CodedBuilder.output:com.google.protobuf.CodedOutputStream
        return;
    }

    ByteString$CodedBuilder(int p0, com.google.protobuf.ByteString$1 p1) {
        // Registers (3 total): v0 = this, v1 = p0 (int), v2 = p1 (com.google.protobuf.ByteString$1)
        _result = v0.<init>(v1); // com.google.protobuf.ByteString$CodedBuilder.<init> -> void
        return;
    }

    public com.google.protobuf.ByteString build() {
        // Registers (4 total): v3 = this
        v0 = v3.output; // com.google.protobuf.ByteString$CodedBuilder.output:com.google.protobuf.CodedOutputStream
        _result = v0.checkNoSpaceLeft(); // com.google.protobuf.CodedOutputStream.checkNoSpaceLeft -> void
        v0 = new com.google.protobuf.ByteString;
        v1 = v3.buffer; // com.google.protobuf.ByteString$CodedBuilder.buffer:byte[]
        v2 = 0;
        _result = v0.<init>(v1, v2); // com.google.protobuf.ByteString.<init> -> void
        return v0;
    }

    public com.google.protobuf.CodedOutputStream getCodedOutput() {
        // Registers (2 total): v1 = this
        v0 = v1.output; // com.google.protobuf.ByteString$CodedBuilder.output:com.google.protobuf.CodedOutputStream
        return v0;
    }

}