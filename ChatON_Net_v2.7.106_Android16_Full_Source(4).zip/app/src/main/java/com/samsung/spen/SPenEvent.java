package com.samsung.spen;

/**
 * Original SourceFile: SPenEvent.java
 * Descriptor: Lcom/samsung/spen/SPenEvent;
 */
public class SPenEvent {
    public static final int BUTTON_ERASER;
    public static final int BUTTON_NONE;
    public static final int BUTTON_SIDE;
    private static final int META_BUTTON_ERASER;
    private static final int META_BUTTON_SIDE;
    private static final int META_PEN_ON;
    private int mMetaState;
    private final android.view.MotionEvent mMotionEvent;
    private int mPressedButtons;

    SPenEvent(android.view.MotionEvent p0, boolean p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MotionEvent), v3 = p1 (boolean)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v1.mPressedButtons = v0; // com.samsung.spen.SPenEvent.mPressedButtons:int
        v1.mMotionEvent = v2; // com.samsung.spen.SPenEvent.mMotionEvent:android.view.MotionEvent
        v0 = com.samsung.spen.DeviceModel.IS_SUPPORTED_DEVICE; // :boolean
        if (v0 != 0) /* goto L_000e */;
        if (v3 != 0) /* goto L_0017 */;
        _result = v2.getMetaState(); // android.view.MotionEvent.getMetaState -> int
        v0 = _result;
        v1.mMetaState = v0; // com.samsung.spen.SPenEvent.mMetaState:int
        _result = v1.setPressedButtons(); // com.samsung.spen.SPenEvent.setPressedButtons -> void
        return;
    }

    private void setPressedButtons() {
        // Registers (2 total): v1 = this
        v0 = v1.mMetaState; // com.samsung.spen.SPenEvent.mMetaState:int
        v0 = binOpLit16_0xd5(v0, 1024);
        if (v0 == 0) /* goto L_000c */;
        v0 = v1.mPressedButtons; // com.samsung.spen.SPenEvent.mPressedButtons:int
        v0 = binOpLit8_0xd8(v0, 1);
        v1.mPressedButtons = v0; // com.samsung.spen.SPenEvent.mPressedButtons:int
        v0 = v1.mMetaState; // com.samsung.spen.SPenEvent.mMetaState:int
        v0 = binOpLit16_0xd5(v0, 2048);
        if (v0 == 0) /* goto L_0018 */;
        v0 = v1.mPressedButtons; // com.samsung.spen.SPenEvent.mPressedButtons:int
        v0 = binOpLit8_0xd8(v0, 2);
        v1.mPressedButtons = v0; // com.samsung.spen.SPenEvent.mPressedButtons:int
        return;
    }

    public int getPressedButtons() {
        // Registers (2 total): v1 = this
        v0 = v1.mPressedButtons; // com.samsung.spen.SPenEvent.mPressedButtons:int
        return v0;
    }

    public float getPressure() {
        // Registers (2 total): v1 = this
        v0 = v1.mMotionEvent; // com.samsung.spen.SPenEvent.mMotionEvent:android.view.MotionEvent
        _result = v0.getPressure(); // android.view.MotionEvent.getPressure -> float
        v0 = _result;
        return v0;
    }

    public float getX() {
        // Registers (2 total): v1 = this
        v0 = v1.mMotionEvent; // com.samsung.spen.SPenEvent.mMotionEvent:android.view.MotionEvent
        _result = v0.getX(); // android.view.MotionEvent.getX -> float
        v0 = _result;
        return v0;
    }

    public float getY() {
        // Registers (2 total): v1 = this
        v0 = v1.mMotionEvent; // com.samsung.spen.SPenEvent.mMotionEvent:android.view.MotionEvent
        _result = v0.getY(); // android.view.MotionEvent.getY -> float
        v0 = _result;
        return v0;
    }

    public boolean isPen() {
        // Registers (2 total): v1 = this
        v0 = v1.mMetaState; // com.samsung.spen.SPenEvent.mMetaState:int
        v0 = binOpLit16_0xd5(v0, 512);
        if (v0 == 0) /* goto L_0008 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public boolean isPressedButton(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mPressedButtons; // com.samsung.spen.SPenEvent.mPressedButtons:int
        v0 = binOp2addr_0xb5(v0, v2);
        if (v0 == 0) /* goto L_0007 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0006
    }

}