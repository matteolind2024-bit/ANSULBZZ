package com.samsung.spen;

/**
 * Original SourceFile: SPenLibrary.java
 * Descriptor: Lcom/samsung/spen/SPenLibrary;
 */
public class SPenLibrary {
    static final boolean REQUIRE_SUPPORTED_DEVICE;
    public static final com.samsung.spen.SPenLibraryVersion VERSION;

    static {
        v0 = new com.samsung.spen.SPenLibraryVersion;
        v1 = 0;
        v2 = 5;
        v3 = 1;
        _result = v0.<init>(v1, v2, v3); // com.samsung.spen.SPenLibraryVersion.<init> -> void
        com.samsung.spen.SPenLibrary.VERSION = v0; // :com.samsung.spen.SPenLibraryVersion
        return;
    }

    public SPenLibrary() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static com.samsung.spen.SPenEvent getEvent(android.view.MotionEvent p0) {
        // Registers (3 total): v2 = p0 (android.view.MotionEvent)
        if (v2 != 0) /* goto L_000a */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Event can't be null.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = new com.samsung.spen.SPenEvent;
        v1 = 0;
        _result = v0.<init>(v2, v1); // com.samsung.spen.SPenEvent.<init> -> void
        return v0;
    }

    public static java.lang.String[] getSupportedModels() {
        v0 = com.samsung.spen.DeviceModel.SUPPORTED_MODELS; // :java.lang.String[]
        return v0;
    }

    public static boolean isSupportedDevice() {
        v0 = com.samsung.spen.DeviceModel.IS_SUPPORTED_DEVICE; // :boolean
        return v0;
    }

}