package com.samsung.spen;

/**
 * Original SourceFile: package-info.java
 * Descriptor: Lcom/samsung/spen/package-info;
 */
interface package-info {
}