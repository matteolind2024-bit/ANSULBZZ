package com.samsung.spen;

/**
 * Original SourceFile: DeviceModel.java
 * Descriptor: Lcom/samsung/spen/DeviceModel;
 */
class DeviceModel {
    static final java.lang.String DEVICE_MODEL;
    static final boolean IS_SUPPORTED_DEVICE;
    static final java.lang.String[] SUPPORTED_MODELS;

    static {
        v0 = android.os.Build.PRODUCT; // :java.lang.String
        com.samsung.spen.DeviceModel.DEVICE_MODEL = v0; // :java.lang.String
        v0 = 3;
        v0 = new java.lang.String[][size=v0];
        v1 = 0;
        v2 = "GT-I9220";
        v0[v1] = v2;
        v1 = 1;
        v2 = "GT-I9221";
        v0[v1] = v2;
        v1 = 2;
        v2 = "GT-N7000";
        v0[v1] = v2;
        com.samsung.spen.DeviceModel.SUPPORTED_MODELS = v0; // :java.lang.String[]
        _result = this.checkForSupportedDevice(); // com.samsung.spen.DeviceModel.checkForSupportedDevice -> boolean
        v0 = _result;
        com.samsung.spen.DeviceModel.IS_SUPPORTED_DEVICE = v0; // :boolean
        return;
    }

    DeviceModel() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    private static boolean checkForSupportedDevice() {
        v0 = 0;
        v1 = "SPen";
        v2 = "Checking for supported device.";
        _result = v1.d(v2); // android.util.Log.d -> int
        v2 = com.samsung.spen.DeviceModel.SUPPORTED_MODELS; // :java.lang.String[]
        v3 = v2.length;
        v1 = v0;
        if (v1 < v3) /* goto L_002b */;
        v1 = "SPen";
        v2 = new java.lang.StringBuilder;
        v3 = "Device '";
        _result = v2.<init>(v3); // java.lang.StringBuilder.<init> -> void
        v3 = com.samsung.spen.DeviceModel.DEVICE_MODEL; // :java.lang.String
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = "' is not supported.";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.d(v2); // android.util.Log.d -> int
        return v0;
        v4 = v2[v1];
        v5 = com.samsung.spen.DeviceModel.DEVICE_MODEL; // :java.lang.String
        _result = v4.equalsIgnoreCase(v5); // java.lang.String.equalsIgnoreCase -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_0053 */;
        v0 = "SPen";
        v1 = new java.lang.StringBuilder;
        v2 = "Device '";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        v2 = com.samsung.spen.DeviceModel.DEVICE_MODEL; // :java.lang.String
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "' is supported.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = 1;
        // goto L_002a
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_000c
    }

}