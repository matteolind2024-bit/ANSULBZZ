package com.samsung.spen;

/**
 * Original SourceFile: SPenLibraryVersion.java
 * Descriptor: Lcom/samsung/spen/SPenLibraryVersion;
 */
public class SPenLibraryVersion {
    public final int BUILD;
    public final int MAJOR;
    public final int MINOR;
    public final java.lang.String RELEASE;

    SPenLibraryVersion(int p0, int p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (int), v5 = p2 (int)
        v1 = 46;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.MAJOR = v3; // com.samsung.spen.SPenLibraryVersion.MAJOR:int
        v2.MINOR = v4; // com.samsung.spen.SPenLibraryVersion.MINOR:int
        v2.BUILD = v5; // com.samsung.spen.SPenLibraryVersion.BUILD:int
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v2.RELEASE = v0; // com.samsung.spen.SPenLibraryVersion.RELEASE:java.lang.String
        return;
    }

}