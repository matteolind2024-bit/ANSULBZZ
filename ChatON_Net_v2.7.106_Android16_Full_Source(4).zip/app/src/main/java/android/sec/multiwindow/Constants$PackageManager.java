package android.sec.multiwindow;

/**
 * Original SourceFile: Constants.java
 * Descriptor: Landroid/sec/multiwindow/Constants$PackageManager;
 */
public class Constants$PackageManager {
    public static java.lang.String FEATURE_MULTIWINDOW;
    static java.lang.String[] FIELD_NAMES;

    static {
        v0 = 0;
        v1 = 1;
        v1 = new java.lang.String[][size=v1];
        v2 = "FEATURE_MULTIWINDOW";
        v1[v0] = v2;
        android.sec.multiwindow.Constants$PackageManager.FIELD_NAMES = v1; // :java.lang.String[]
        v1 = android.sec.multiwindow.Constants$PackageManager.FIELD_NAMES; // :java.lang.String[]
        v1 = v1.length;
        if (v0 >= v1) /* goto L_002d */;
        v2 = android.content.pm.PackageManager.class;
        v3 = android.sec.multiwindow.Constants$PackageManager.FIELD_NAMES; // :java.lang.String[]
        v3 = v3[v0];
        _result = v2.getDeclaredField(v3); // java.lang.Class.getDeclaredField -> java.lang.reflect.Field
        v2 = _result;
        v3 = android.sec.multiwindow.Constants$PackageManager.class;
        v4 = android.sec.multiwindow.Constants$PackageManager.FIELD_NAMES; // :java.lang.String[]
        v4 = v4[v0];
        _result = v3.getField(v4); // java.lang.Class.getField -> java.lang.reflect.Field
        v3 = _result;
        _result = v2.get(v2); // java.lang.reflect.Field.get -> java.lang.Object
        v2 = _result;
        _result = v3.set(v3, v2); // java.lang.reflect.Field.set -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_000d
        return;
        v2 = _exception;
        // goto L_002a
        v2 = _exception;
        // goto L_002a
        v2 = _exception;
        // goto L_002a
    }

    public Constants$PackageManager() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}