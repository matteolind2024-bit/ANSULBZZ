package android.sec.multiwindow;

/**
 * Original SourceFile: MWOnDragListener.java
 * Descriptor: Landroid/sec/multiwindow/MWOnDragListener;
 */
public abstract class MWOnDragListener implements android.view.View$OnDragListener {
    public static final java.lang.String TAG;

    public MWOnDragListener() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean onDrag(android.view.View p0, android.view.DragEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.view.DragEvent)
        v0 = 1;
        _result = v4.getAction(); // android.view.DragEvent.getAction -> int
        v1 = _result;
        // switch(v1)
        v0 = "MWOnDragListener";
        v1 = "Unknown action type received by OnDragListener.";
        _result = v0.w(v1); // android.util.Log.w -> int
        v0 = 0;
        return v0;
        _result = v2.onDrop(v4); // android.sec.multiwindow.MWOnDragListener.onDrop -> void
        _result = v3.invalidate(); // android.view.View.invalidate -> void
        // goto L_0010
        _result = v3.invalidate(); // android.view.View.invalidate -> void
        // goto L_0010
    }

    public abstract void onDrop(android.view.DragEvent p0);
}