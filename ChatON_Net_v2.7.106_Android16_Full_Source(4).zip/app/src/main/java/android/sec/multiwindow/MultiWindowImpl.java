package android.sec.multiwindow;

/**
 * Original SourceFile: MultiWindowImpl.java
 * Descriptor: Landroid/sec/multiwindow/MultiWindowImpl;
 */
public class MultiWindowImpl {
    protected android.content.Context mContext;
    private java.util.HashMap mMethodMap;

    public MultiWindowImpl(android.content.Context p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.content.Context)
        v6 = 0;
        v5 = 1;
        v4 = 0;
        _result = v7.<init>(); // java.lang.Object.<init> -> void
        v7.mContext = v8; // android.sec.multiwindow.MultiWindowImpl.mContext:android.content.Context
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        v7.mMethodMap = v0; // android.sec.multiwindow.MultiWindowImpl.mMethodMap:java.util.HashMap
        v0 = "android.view.WindowManagerPolicy$WindowModeHelper";
        _result = v7.findClass(v0); // android.sec.multiwindow.MultiWindowImpl.findClass -> java.lang.Class
        v0 = _result;
        v1 = "mode";
        v2 = new java.lang.Class[][size=v5];
        v3 = java.lang.Integer.TYPE; // :java.lang.Class
        v2[v4] = v3;
        _result = v7.putMethod(v0, v6, v1, v2); // android.sec.multiwindow.MultiWindowImpl.putMethod -> void
        v1 = "option";
        v2 = new java.lang.Class[][size=v5];
        v3 = java.lang.Integer.TYPE; // :java.lang.Class
        v2[v4] = v3;
        _result = v7.putMethod(v0, v6, v1, v2); // android.sec.multiwindow.MultiWindowImpl.putMethod -> void
        return;
    }

    protected java.lang.Class findClass(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        _result = v2.forName(); // java.lang.Class.forName -> java.lang.Class
        v0 = _result;
        return v0;
        v0 = _exception;
        v0 = 0;
        // goto L_0004
    }

    protected java.lang.Object invoke(java.lang.String p0, java.lang.Object[] p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.String), v4 = p1 (java.lang.Object[])
        v0 = v2.mMethodMap; // android.sec.multiwindow.MultiWindowImpl.mMethodMap:java.util.HashMap
        _result = v0.get(v3); // java.util.HashMap.get -> java.lang.Object
        v0 = _result;
        v0 = (android.util.Pair) v0;
        v1 = v0.second; // android.util.Pair.second:java.lang.Object
        v1 = (java.lang.reflect.Method) v1;
        v0 = v0.first; // android.util.Pair.first:java.lang.Object
        _result = v1.invoke(v0, v4); // java.lang.reflect.Method.invoke -> java.lang.Object
        v0 = _result;
        return v0;
        v0 = _exception;
        _result = v0.printStackTrace(); // java.lang.Exception.printStackTrace -> void
        v0 = 0;
        // goto L_0012
    }

    protected int mode(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        v0 = "mode";
        v1 = 1;
        v1 = new java.lang.Object[][size=v1];
        v2 = 0;
        _result = v5.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v3 = _result;
        v1[v2] = v3;
        _result = v4.invoke(v0, v1); // android.sec.multiwindow.MultiWindowImpl.invoke -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Integer) v0;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        return v0;
    }

    protected int option(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        v0 = "option";
        v1 = 1;
        v1 = new java.lang.Object[][size=v1];
        v2 = 0;
        _result = v5.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v3 = _result;
        v1[v2] = v3;
        _result = v4.invoke(v0, v1); // android.sec.multiwindow.MultiWindowImpl.invoke -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Integer) v0;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        return v0;
    }

    protected void putMethod(java.lang.Class p0, java.lang.Object p1, java.lang.String p2, java.lang.Class[] p3) {
        // Registers (8 total): v3 = this, v4 = p0 (java.lang.Class), v5 = p1 (java.lang.Object), v6 = p2 (java.lang.String), v7 = p3 (java.lang.Class[])
        _result = v4.getMethod(v6, v7); // java.lang.Class.getMethod -> java.lang.reflect.Method
        v0 = _result;
        v1 = v3.mMethodMap; // android.sec.multiwindow.MultiWindowImpl.mMethodMap:java.util.HashMap
        v2 = new android.util.Pair;
        _result = v2.<init>(v5, v0); // android.util.Pair.<init> -> void
        _result = v1.put(v6, v2); // java.util.HashMap.put -> java.lang.Object
        return;
        v0 = _exception;
        // goto L_000e
    }

}