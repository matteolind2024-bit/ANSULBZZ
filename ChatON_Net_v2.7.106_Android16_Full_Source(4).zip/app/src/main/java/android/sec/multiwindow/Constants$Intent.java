package android.sec.multiwindow;

/**
 * Original SourceFile: Constants.java
 * Descriptor: Landroid/sec/multiwindow/Constants$Intent;
 */
public class Constants$Intent {
    public static java.lang.String ACTION_ARRANGE_WINDOWS;
    public static java.lang.String CATEGORY_MULTIWINDOW_LAUNCHER;
    public static java.lang.String EXTRA_ARRANGE_MODE;
    public static java.lang.String EXTRA_WINDOW_ARRANGED_SIZE;
    public static java.lang.String EXTRA_WINDOW_DEFAULT_SIZE;
    public static java.lang.String EXTRA_WINDOW_LAST_SIZE;
    public static java.lang.String EXTRA_WINDOW_MINIMIZED_SIZE;
    public static java.lang.String EXTRA_WINDOW_MINIMIZED_SLOT;
    public static java.lang.String EXTRA_WINDOW_MINIMUM_SIZE;
    public static java.lang.String EXTRA_WINDOW_MODE;
    public static java.lang.String EXTRA_WINDOW_OUT_OF_ARRANGE;
    public static java.lang.String EXTRA_WINDOW_POSITION;
    static java.lang.String[] FIELD_NAMES;
    public static java.lang.String METADATA_MULTIWINDOW_DEF_HEIGHT;
    public static java.lang.String METADATA_MULTIWINDOW_DEF_WIDTH;
    public static java.lang.String METADATA_MULTIWINDOW_MIN_HEIGHT;
    public static java.lang.String METADATA_MULTIWINDOW_MIN_WIDTH;
    public static java.lang.String METADATA_MULTIWINDOW_STYLE;
    public static java.lang.String METADATA_SUPPORT_MULTIWINDOW;

    static {
        v0 = 0;
        v1 = 18;
        v1 = new java.lang.String[][size=v1];
        v2 = "EXTRA_WINDOW_MODE";
        v1[v0] = v2;
        v2 = 1;
        v3 = "EXTRA_WINDOW_POSITION";
        v1[v2] = v3;
        v2 = 2;
        v3 = "EXTRA_WINDOW_MINIMUM_SIZE";
        v1[v2] = v3;
        v2 = 3;
        v3 = "EXTRA_WINDOW_MINIMIZED_SIZE";
        v1[v2] = v3;
        v2 = 4;
        v3 = "EXTRA_WINDOW_MINIMIZED_SLOT";
        v1[v2] = v3;
        v2 = 5;
        v3 = "EXTRA_WINDOW_DEFAULT_SIZE";
        v1[v2] = v3;
        v2 = 6;
        v3 = "EXTRA_WINDOW_LAST_SIZE";
        v1[v2] = v3;
        v2 = 7;
        v3 = "EXTRA_WINDOW_ARRANGED_SIZE";
        v1[v2] = v3;
        v2 = 8;
        v3 = "EXTRA_WINDOW_OUT_OF_ARRANGE";
        v1[v2] = v3;
        v2 = 9;
        v3 = "CATEGORY_MULTIWINDOW_LAUNCHER";
        v1[v2] = v3;
        v2 = 10;
        v3 = "METADATA_SUPPORT_MULTIWINDOW";
        v1[v2] = v3;
        v2 = 11;
        v3 = "METADATA_MULTIWINDOW_STYLE";
        v1[v2] = v3;
        v2 = 12;
        v3 = "METADATA_MULTIWINDOW_MIN_WIDTH";
        v1[v2] = v3;
        v2 = 13;
        v3 = "METADATA_MULTIWINDOW_MIN_HEIGHT";
        v1[v2] = v3;
        v2 = 14;
        v3 = "METADATA_MULTIWINDOW_DEF_WIDTH";
        v1[v2] = v3;
        v2 = 15;
        v3 = "METADATA_MULTIWINDOW_DEF_HEIGHT";
        v1[v2] = v3;
        v2 = 16;
        v3 = "ACTION_ARRANGE_WINDOWS";
        v1[v2] = v3;
        v2 = 17;
        v3 = "EXTRA_ARRANGE_MODE";
        v1[v2] = v3;
        android.sec.multiwindow.Constants$Intent.FIELD_NAMES = v1; // :java.lang.String[]
        v1 = android.sec.multiwindow.Constants$Intent.FIELD_NAMES; // :java.lang.String[]
        v1 = v1.length;
        if (v0 >= v1) /* goto L_008d */;
        v2 = android.content.Intent.class;
        v3 = android.sec.multiwindow.Constants$Intent.FIELD_NAMES; // :java.lang.String[]
        v3 = v3[v0];
        _result = v2.getDeclaredField(v3); // java.lang.Class.getDeclaredField -> java.lang.reflect.Field
        v2 = _result;
        v3 = android.sec.multiwindow.Constants$Intent.class;
        v4 = android.sec.multiwindow.Constants$Intent.FIELD_NAMES; // :java.lang.String[]
        v4 = v4[v0];
        _result = v3.getField(v4); // java.lang.Class.getField -> java.lang.reflect.Field
        v3 = _result;
        _result = v2.get(v2); // java.lang.reflect.Field.get -> java.lang.Object
        v2 = _result;
        _result = v3.set(v3, v2); // java.lang.reflect.Field.set -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_006d
        return;
        v2 = _exception;
        // goto L_008a
        v2 = _exception;
        // goto L_008a
        v2 = _exception;
        // goto L_008a
    }

    public Constants$Intent() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}