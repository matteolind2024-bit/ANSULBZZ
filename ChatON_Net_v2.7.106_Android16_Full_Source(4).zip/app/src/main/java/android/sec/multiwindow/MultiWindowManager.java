package android.sec.multiwindow;

/**
 * Original SourceFile: MultiWindowManager.java
 * Descriptor: Landroid/sec/multiwindow/MultiWindowManager;
 */
public class MultiWindowManager extends android.sec.multiwindow.MultiWindowImpl implements android.sec.multiwindow.IMultiWindowManager {
    public static final int ARRANGE_MODE_CASCADE;
    public static final int ARRANGE_MODE_SPLIT;
    public static final int FLAG_STYLE_FREE;
    public static final int FLAG_STYLE_MINIMIZE;
    public static final int FLAG_STYLE_PINUP;
    public static final int FLAG_STYLE_POPUP;
    private static final int MAX_RUNNING_TASK;
    public static final java.lang.String TAG;
    private static android.sec.multiwindow.MultiWindowManager mSelf;
    private static boolean sIsMultiWindowEnabled;
    private static boolean sQueried;

    static {
        v1 = 0;
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_FREESTYLE; // :int
        android.sec.multiwindow.MultiWindowManager.FLAG_STYLE_FREE = v0; // :int
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_PINUP; // :int
        android.sec.multiwindow.MultiWindowManager.FLAG_STYLE_PINUP = v0; // :int
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_MINIMIZED; // :int
        android.sec.multiwindow.MultiWindowManager.FLAG_STYLE_MINIMIZE = v0; // :int
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_NO_DECORATION; // :int
        android.sec.multiwindow.MultiWindowManager.FLAG_STYLE_POPUP = v0; // :int
        v0 = android.sec.multiwindow.Constants$Configuration.ARRANGE_SPLITED; // :int
        android.sec.multiwindow.MultiWindowManager.ARRANGE_MODE_SPLIT = v0; // :int
        v0 = android.sec.multiwindow.Constants$Configuration.ARRANGE_CASCADE; // :int
        android.sec.multiwindow.MultiWindowManager.ARRANGE_MODE_CASCADE = v0; // :int
        v0 = 0;
        android.sec.multiwindow.MultiWindowManager.mSelf = v0; // :android.sec.multiwindow.MultiWindowManager
        android.sec.multiwindow.MultiWindowManager.sQueried = v1; // :boolean
        android.sec.multiwindow.MultiWindowManager.sIsMultiWindowEnabled = v1; // :boolean
        return;
    }

    public MultiWindowManager(android.content.Context p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.content.Context)
        _result = v4.<init>(v5); // android.sec.multiwindow.MultiWindowImpl.<init> -> void
        v0 = "activity";
        _result = v5.getSystemService(v0); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.app.ActivityManager) v0;
        _result = v0.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        v3 = "getFrontActivityPosition";
        v1 = 0;
        v1 = (java.lang.Class[]) v1;
        _result = v4.putMethod(v2, v0, v3, v1); // android.sec.multiwindow.MultiWindowManager.putMethod -> void
        return;
    }

    public MultiWindowManager(android.content.Context p0, android.os.Handler p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.content.Context), v2 = p1 (android.os.Handler)
        _result = v0.<init>(v1); // android.sec.multiwindow.MultiWindowManager.<init> -> void
        return;
    }

    public static android.sec.multiwindow.IMultiWindowManager getInstance(android.content.Context p0) {
        // Registers (2 total): v1 = p0 (android.content.Context)
        v0 = 0;
        return v0;
    }

    private java.util.List getMultiWindowInfos(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public static android.sec.multiwindow.MultiWindowManager getSelf(android.content.Context p0) {
        // Registers (2 total): v1 = p0 (android.content.Context)
        v0 = android.sec.multiwindow.MultiWindowManager.mSelf; // :android.sec.multiwindow.MultiWindowManager
        if (v0 != 0) /* goto L_000b */;
        v0 = new android.sec.multiwindow.MultiWindowManager;
        _result = v0.<init>(v1); // android.sec.multiwindow.MultiWindowManager.<init> -> void
        android.sec.multiwindow.MultiWindowManager.mSelf = v0; // :android.sec.multiwindow.MultiWindowManager
        v0 = android.sec.multiwindow.MultiWindowManager.mSelf; // :android.sec.multiwindow.MultiWindowManager
        return v0;
    }

    public static android.sec.multiwindow.IMultiWindowService getService() {
        v0 = 0;
        return v0;
    }

    public static boolean isMultiWindowServiceEnabled(android.content.Context p0) {
        // Registers (3 total): v2 = p0 (android.content.Context)
        v0 = android.sec.multiwindow.MultiWindowManager.sQueried; // :boolean
        if (v0 != 0) /* goto L_0015 */;
        v0 = 1;
        android.sec.multiwindow.MultiWindowManager.sQueried = v0; // :boolean
        _result = v2.getPackageManager(); // android.content.Context.getPackageManager -> android.content.pm.PackageManager
        v0 = _result;
        if (v0 == 0) /* goto L_0015 */;
        v1 = android.sec.multiwindow.Constants$PackageManager.FEATURE_MULTIWINDOW; // :java.lang.String
        _result = v0.hasSystemFeature(v1); // android.content.pm.PackageManager.hasSystemFeature -> boolean
        v0 = _result;
        android.sec.multiwindow.MultiWindowManager.sIsMultiWindowEnabled = v0; // :boolean
        v0 = android.sec.multiwindow.MultiWindowManager.sIsMultiWindowEnabled; // :boolean
        return v0;
    }

    public void arrange(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = new android.content.Intent;
        v1 = android.sec.multiwindow.Constants$Intent.ACTION_ARRANGE_WINDOWS; // :java.lang.String
        _result = v0.<init>(v1); // android.content.Intent.<init> -> void
        v1 = android.sec.multiwindow.Constants$Intent.EXTRA_ARRANGE_MODE; // :java.lang.String
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        v1 = v2.mContext; // android.sec.multiwindow.MultiWindowManager.mContext:android.content.Context
        _result = v1.sendBroadcast(v0); // android.content.Context.sendBroadcast -> void
        return;
    }

    public void arrangeCascade() {
        // Registers (2 total): v1 = this
        v0 = android.sec.multiwindow.Constants$Configuration.ARRANGE_CASCADE; // :int
        _result = v1.arrange(v0); // android.sec.multiwindow.MultiWindowManager.arrange -> void
        return;
    }

    public void arrangeSplit() {
        // Registers (2 total): v1 = this
        v0 = android.sec.multiwindow.Constants$Configuration.ARRANGE_SPLITED; // :int
        _result = v1.arrange(v0); // android.sec.multiwindow.MultiWindowManager.arrange -> void
        return;
    }

    public boolean arrangeTemplate(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public boolean arrangeWindows(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public android.graphics.Bitmap capture(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean exchangeSplitScreens() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public boolean finishAllWindow() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public boolean finishAppPid(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public android.graphics.Rect getFrontActivityPosition() {
        // Registers (3 total): v2 = this
        v0 = "getFrontActivityPosition";
        v1 = 0;
        v1 = new java.lang.Object[][size=v1];
        _result = v2.invoke(v0, v1); // android.sec.multiwindow.MultiWindowManager.invoke -> java.lang.Object
        v0 = _result;
        v0 = (android.graphics.Rect) v0;
        return v0;
    }

    public boolean getMultiLayout() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public java.util.List getMultiWindowInfos() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public java.util.List getMultiWindowList() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public java.util.List getMultiWindowList(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public java.util.List getMultiWindowListOwnerList() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public android.sec.multiwindow.MultiWindowType getMultiWindowMode() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public android.content.ComponentName getPinupWindow() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public java.util.List getPinupWindowList() {
        // Registers (2 total): v1 = this
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        return v0;
    }

    public java.util.List getRegisteredList() {
        // Registers (5 total): v4 = this
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        v0 = new android.content.Intent;
        v2 = "android.intent.action.MAIN";
        _result = v0.<init>(v2); // android.content.Intent.<init> -> void
        v2 = android.sec.multiwindow.Constants$Intent.CATEGORY_MULTIWINDOW_LAUNCHER; // :java.lang.String
        _result = v0.addCategory(v2); // android.content.Intent.addCategory -> android.content.Intent
        v2 = v4.mContext; // android.sec.multiwindow.MultiWindowManager.mContext:android.content.Context
        _result = v2.getPackageManager(); // android.content.Context.getPackageManager -> android.content.pm.PackageManager
        v2 = _result;
        v3 = 128;
        _result = v2.queryIntentActivities(v0, v3); // android.content.pm.PackageManager.queryIntentActivities -> java.util.List
        v0 = _result;
        _result = java.util.List.iterator(v0); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0035 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (android.content.pm.ResolveInfo) v0;
        if (v0 == 0) /* goto L_0021 */;
        v0 = v0.activityInfo; // android.content.pm.ResolveInfo.activityInfo:android.content.pm.ActivityInfo
        _result = java.util.List.add(v1, v0); // -> boolean
        // goto L_0021
        return v1;
    }

    public android.content.ComponentName getResumedWindow() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public java.util.List getRunningList(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.mContext; // android.sec.multiwindow.MultiWindowManager.mContext:android.content.Context
        v1 = "activity";
        _result = v0.getSystemService(v1); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.app.ActivityManager) v0;
        v1 = 1000;
        v2 = 0;
        _result = v0.getRunningTasks(v1, v4, v2); // android.app.ActivityManager.getRunningTasks -> java.util.List
        v0 = _result;
        return v0;
    }

    public java.util.List getRunningWindowList() {
        // Registers (2 total): v1 = this
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        return v0;
    }

    public java.util.List getSplitList() {
        // Registers (2 total): v1 = this
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        return v0;
    }

    public java.util.List getVisibleWindowList() {
        // Registers (2 total): v1 = this
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        return v0;
    }

    public android.sec.multiwindow.IMultiWindow getWindowInstance(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public android.sec.multiwindow.IMultiWindow getWindowInstance(android.content.Intent p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Intent)
        v0 = 0;
        return v0;
    }

    public boolean isMultiWindow(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean isMultiWindow(android.content.ComponentName p0, android.content.ComponentName p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.ComponentName), v3 = p1 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean isPermissionOff() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public boolean isPinup(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean isPinup(android.content.ComponentName p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.ComponentName), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

    public boolean isRunning(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean isVisible(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public android.content.Intent makeIntent(int p0, android.graphics.Rect p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (android.graphics.Rect)
        v0 = new android.content.Intent;
        _result = v0.<init>(); // android.content.Intent.<init> -> void
        v1 = android.sec.multiwindow.Constants$Intent.EXTRA_WINDOW_MODE; // :java.lang.String
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        if (v4 == 0) /* goto L_0011 */;
        v1 = android.sec.multiwindow.Constants$Intent.EXTRA_WINDOW_POSITION; // :java.lang.String
        _result = v0.putExtra(v1, v4); // android.content.Intent.putExtra -> android.content.Intent
        return v0;
    }

    public void minimizeAll() {
        // Registers (2 total): v1 = this
        v0 = android.sec.multiwindow.Constants$Configuration.ARRANGE_MINIMIZED_ALL; // :int
        _result = v1.arrange(v0); // android.sec.multiwindow.MultiWindowManager.arrange -> void
        return;
    }

    public boolean notifyFinished(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 0;
        return v0;
    }

    public boolean notifyForceFinished(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean notifySIP(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 1;
        return v0;
    }

    public boolean notifyStarted(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 0;
        return v0;
    }

    public boolean orientationChangeRestore(android.content.ComponentName p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.ComponentName), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

    public boolean postResume(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 0;
        return v0;
    }

    public android.sec.multiwindow.IMultiWindow registerMultiWindow(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public android.sec.multiwindow.IMultiWindow registerMultiWindow(android.content.ComponentName p0, int p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.ComponentName), v3 = p1 (int), v4 = p2 (int)
        v0 = 0;
        return v0;
    }

    public android.sec.multiwindow.IMultiWindow registerMultiWindow(android.content.ComponentName p0, int p1, int p2, boolean p3) {
        // Registers (6 total): v1 = this, v2 = p0 (android.content.ComponentName), v3 = p1 (int), v4 = p2 (int), v5 = p3 (boolean)
        v0 = 0;
        return v0;
    }

    public android.sec.multiwindow.IMultiWindow registerMultiWindow(android.content.ComponentName p0, java.util.List p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.ComponentName), v3 = p1 (java.util.List)
        v0 = 0;
        return v0;
    }

    public boolean registerMultiWindowPair(android.content.ComponentName p0, android.content.ComponentName p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.ComponentName), v3 = p1 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean removeMultiWindow(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean removeMultiWindowOwnerItem(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean removeMultiWindowPair(android.content.ComponentName p0, android.content.ComponentName p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.ComponentName), v3 = p1 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public void restoreAll() {
        // Registers (2 total): v1 = this
        v0 = android.sec.multiwindow.Constants$Configuration.ARRANGE_RESTORED_ALL; // :int
        _result = v1.arrange(v0); // android.sec.multiwindow.MultiWindowManager.arrange -> void
        return;
    }

    public android.graphics.Bitmap screenShot(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean sendCreateAction(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 0;
        return v0;
    }

    public boolean sendDestroyAction(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 0;
        return v0;
    }

    public boolean sendFinishAction(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 0;
        return v0;
    }

    public boolean sendPauseAction(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 0;
        return v0;
    }

    public boolean sendResumeAction(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 0;
        return v0;
    }

    public boolean sendStartAction(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 0;
        return v0;
    }

    public boolean setMultiLayout(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = 1;
        return v0;
    }

    public boolean setMultiWindowMode(android.sec.multiwindow.MultiWindowType p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.sec.multiwindow.MultiWindowType)
        v0 = 0;
        return v0;
    }

    public void setPreferenceValue(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        return;
    }

    public void showSwitchWindowGuideDialog(android.content.Context p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.content.Context)
        return;
    }

    public boolean startLauncher() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public boolean startLauncher(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean startLauncher(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        v0 = 0;
        return v0;
    }

    public boolean startLauncher(android.content.Context p0, android.content.ComponentName p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean startSplitScreens(android.content.ComponentName p0, android.content.ComponentName p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.ComponentName), v3 = p1 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean startSplitScreens(android.content.ComponentName p0, android.content.Intent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.ComponentName), v3 = p1 (android.content.Intent)
        v0 = 0;
        return v0;
    }

    public boolean startSplitScreens(android.content.Intent p0, android.content.ComponentName p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Intent), v3 = p1 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean startSplitScreensForLauncher(android.content.ComponentName p0, android.content.ComponentName p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.ComponentName), v3 = p1 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean unRegisterMultiWindow(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

}