package android.support.v4.widget;

/**
 * Original SourceFile: CursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/CursorAdapter$1;
 */
class CursorAdapter$1 {
}