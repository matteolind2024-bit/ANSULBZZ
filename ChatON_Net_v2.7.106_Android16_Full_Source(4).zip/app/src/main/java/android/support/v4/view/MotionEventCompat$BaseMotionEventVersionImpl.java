package android.support.v4.view;

/**
 * Original SourceFile: MotionEventCompat.java
 * Descriptor: Landroid/support/v4/view/MotionEventCompat$BaseMotionEventVersionImpl;
 */
class MotionEventCompat$BaseMotionEventVersionImpl implements android.support.v4.view.MotionEventCompat$MotionEventVersionImpl {
    MotionEventCompat$BaseMotionEventVersionImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int findPointerIndex(android.view.MotionEvent p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MotionEvent), v3 = p1 (int)
        if (v3 != 0) /* goto L_0004 */;
        v0 = 0;
        return v0;
        v0 = -1;
        // goto L_0003
    }

    public int getPointerId(android.view.MotionEvent p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.MotionEvent), v4 = p1 (int)
        if (v4 != 0) /* goto L_0004 */;
        v0 = 0;
        return v0;
        v0 = new java.lang.IndexOutOfBoundsException;
        v1 = "Pre-Eclair does not support multiple pointers";
        _result = v0.<init>(v1); // java.lang.IndexOutOfBoundsException.<init> -> void
        throw v0;
    }

    public float getX(android.view.MotionEvent p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.MotionEvent), v4 = p1 (int)
        if (v4 != 0) /* goto L_0007 */;
        _result = v3.getX(); // android.view.MotionEvent.getX -> float
        v0 = _result;
        return v0;
        v0 = new java.lang.IndexOutOfBoundsException;
        v1 = "Pre-Eclair does not support multiple pointers";
        _result = v0.<init>(v1); // java.lang.IndexOutOfBoundsException.<init> -> void
        throw v0;
    }

    public float getY(android.view.MotionEvent p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.MotionEvent), v4 = p1 (int)
        if (v4 != 0) /* goto L_0007 */;
        _result = v3.getY(); // android.view.MotionEvent.getY -> float
        v0 = _result;
        return v0;
        v0 = new java.lang.IndexOutOfBoundsException;
        v1 = "Pre-Eclair does not support multiple pointers";
        _result = v0.<init>(v1); // java.lang.IndexOutOfBoundsException.<init> -> void
        throw v0;
    }

}