package android.support.v4.content;

/**
 * Original SourceFile: Loader.java
 * Descriptor: Landroid/support/v4/content/Loader$OnLoadCompleteListener;
 */
public interface Loader$OnLoadCompleteListener {
    public abstract void onLoadComplete(android.support.v4.content.Loader p0, java.lang.Object p1);
}