package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/FragmentManagerImpl$4;
 */
class FragmentManagerImpl$4 implements java.lang.Runnable {
    final android.support.v4.app.FragmentManagerImpl this$0;
    final int val$flags;
    final int val$id;

    FragmentManagerImpl$4(android.support.v4.app.FragmentManagerImpl p0, int p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.support.v4.app.FragmentManagerImpl), v2 = p1 (int), v3 = p2 (int)
        v0.this$0 = v1; // android.support.v4.app.FragmentManagerImpl$4.this$0:android.support.v4.app.FragmentManagerImpl
        v0.val$id = v2; // android.support.v4.app.FragmentManagerImpl$4.val$id:int
        v0.val$flags = v3; // android.support.v4.app.FragmentManagerImpl$4.val$flags:int
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (6 total): v5 = this
        v0 = v5.this$0; // android.support.v4.app.FragmentManagerImpl$4.this$0:android.support.v4.app.FragmentManagerImpl
        v1 = v5.this$0; // android.support.v4.app.FragmentManagerImpl$4.this$0:android.support.v4.app.FragmentManagerImpl
        v1 = v1.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = v1.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v2 = 0;
        v3 = v5.val$id; // android.support.v4.app.FragmentManagerImpl$4.val$id:int
        v4 = v5.val$flags; // android.support.v4.app.FragmentManagerImpl$4.val$flags:int
        _result = v0.popBackStackState(v1, v2, v3, v4); // android.support.v4.app.FragmentManagerImpl.popBackStackState -> boolean
        return;
    }

}