package android.support.v4.content;

/**
 * Original SourceFile: Loader.java
 * Descriptor: Landroid/support/v4/content/Loader;
 */
public class Loader {
     boolean mAbandoned;
     boolean mContentChanged;
     android.content.Context mContext;
     int mId;
     android.support.v4.content.Loader$OnLoadCompleteListener mListener;
     boolean mReset;
     boolean mStarted;

    public Loader(android.content.Context p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Context)
        v1 = 0;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.mStarted = v1; // android.support.v4.content.Loader.mStarted:boolean
        v2.mAbandoned = v1; // android.support.v4.content.Loader.mAbandoned:boolean
        v0 = 1;
        v2.mReset = v0; // android.support.v4.content.Loader.mReset:boolean
        v2.mContentChanged = v1; // android.support.v4.content.Loader.mContentChanged:boolean
        _result = v3.getApplicationContext(); // android.content.Context.getApplicationContext -> android.content.Context
        v0 = _result;
        v2.mContext = v0; // android.support.v4.content.Loader.mContext:android.content.Context
        return;
    }

    public void abandon() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mAbandoned = v0; // android.support.v4.content.Loader.mAbandoned:boolean
        _result = v1.onAbandon(); // android.support.v4.content.Loader.onAbandon -> void
        return;
    }

    public java.lang.String dataToString(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v0 = new java.lang.StringBuilder;
        v1 = 64;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v3.buildShortClassTag(v0); // android.support.v4.util.DebugUtils.buildShortClassTag -> void
        v1 = "}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void deliverResult(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = v1.mListener; // android.support.v4.content.Loader.mListener:android.support.v4.content.Loader$OnLoadCompleteListener
        if (v0 == 0) /* goto L_0009 */;
        v0 = v1.mListener; // android.support.v4.content.Loader.mListener:android.support.v4.content.Loader$OnLoadCompleteListener
        _result = android.support.v4.content.Loader$OnLoadCompleteListener.onLoadComplete(v0, v1, v2); // -> void
        return;
    }

    public void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.io.FileDescriptor), v4 = p2 (java.io.PrintWriter), v5 = p3 (java.lang.String[])
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mId=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mId; // android.support.v4.content.Loader.mId:int
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mListener=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mListener; // android.support.v4.content.Loader.mListener:android.support.v4.content.Loader$OnLoadCompleteListener
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mStarted=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mStarted; // android.support.v4.content.Loader.mStarted:boolean
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mContentChanged=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mContentChanged; // android.support.v4.content.Loader.mContentChanged:boolean
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mAbandoned=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mAbandoned; // android.support.v4.content.Loader.mAbandoned:boolean
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mReset=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mReset; // android.support.v4.content.Loader.mReset:boolean
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        return;
    }

    public void forceLoad() {
        // Registers (1 total): v0 = this
        _result = v0.onForceLoad(); // android.support.v4.content.Loader.onForceLoad -> void
        return;
    }

    public android.content.Context getContext() {
        // Registers (2 total): v1 = this
        v0 = v1.mContext; // android.support.v4.content.Loader.mContext:android.content.Context
        return v0;
    }

    public int getId() {
        // Registers (2 total): v1 = this
        v0 = v1.mId; // android.support.v4.content.Loader.mId:int
        return v0;
    }

    public boolean isAbandoned() {
        // Registers (2 total): v1 = this
        v0 = v1.mAbandoned; // android.support.v4.content.Loader.mAbandoned:boolean
        return v0;
    }

    public boolean isReset() {
        // Registers (2 total): v1 = this
        v0 = v1.mReset; // android.support.v4.content.Loader.mReset:boolean
        return v0;
    }

    public boolean isStarted() {
        // Registers (2 total): v1 = this
        v0 = v1.mStarted; // android.support.v4.content.Loader.mStarted:boolean
        return v0;
    }

    protected void onAbandon() {
        // Registers (1 total): v0 = this
        return;
    }

    public void onContentChanged() {
        // Registers (2 total): v1 = this
        v0 = v1.mStarted; // android.support.v4.content.Loader.mStarted:boolean
        if (v0 == 0) /* goto L_0008 */;
        _result = v1.forceLoad(); // android.support.v4.content.Loader.forceLoad -> void
        return;
        v0 = 1;
        v1.mContentChanged = v0; // android.support.v4.content.Loader.mContentChanged:boolean
        // goto L_0007
    }

    protected void onForceLoad() {
        // Registers (1 total): v0 = this
        return;
    }

    protected void onReset() {
        // Registers (1 total): v0 = this
        return;
    }

    protected void onStartLoading() {
        // Registers (1 total): v0 = this
        return;
    }

    protected void onStopLoading() {
        // Registers (1 total): v0 = this
        return;
    }

    public void registerListener(int p0, android.support.v4.content.Loader$OnLoadCompleteListener p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (android.support.v4.content.Loader$OnLoadCompleteListener)
        v0 = v2.mListener; // android.support.v4.content.Loader.mListener:android.support.v4.content.Loader$OnLoadCompleteListener
        if (v0 == 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "There is already a listener registered";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v2.mListener = v4; // android.support.v4.content.Loader.mListener:android.support.v4.content.Loader$OnLoadCompleteListener
        v2.mId = v3; // android.support.v4.content.Loader.mId:int
        return;
    }

    public void reset() {
        // Registers (3 total): v2 = this
        v1 = 0;
        _result = v2.onReset(); // android.support.v4.content.Loader.onReset -> void
        v0 = 1;
        v2.mReset = v0; // android.support.v4.content.Loader.mReset:boolean
        v2.mStarted = v1; // android.support.v4.content.Loader.mStarted:boolean
        v2.mAbandoned = v1; // android.support.v4.content.Loader.mAbandoned:boolean
        v2.mContentChanged = v1; // android.support.v4.content.Loader.mContentChanged:boolean
        return;
    }

    public final void startLoading() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v0 = 1;
        v2.mStarted = v0; // android.support.v4.content.Loader.mStarted:boolean
        v2.mReset = v1; // android.support.v4.content.Loader.mReset:boolean
        v2.mAbandoned = v1; // android.support.v4.content.Loader.mAbandoned:boolean
        _result = v2.onStartLoading(); // android.support.v4.content.Loader.onStartLoading -> void
        return;
    }

    public void stopLoading() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.mStarted = v0; // android.support.v4.content.Loader.mStarted:boolean
        _result = v1.onStopLoading(); // android.support.v4.content.Loader.onStopLoading -> void
        return;
    }

    public boolean takeContentChanged() {
        // Registers (3 total): v2 = this
        v0 = v2.mContentChanged; // android.support.v4.content.Loader.mContentChanged:boolean
        v1 = 0;
        v2.mContentChanged = v1; // android.support.v4.content.Loader.mContentChanged:boolean
        return v0;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 64;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v2.buildShortClassTag(v0); // android.support.v4.util.DebugUtils.buildShortClassTag -> void
        v1 = " id=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mId; // android.support.v4.content.Loader.mId:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = "}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void unregisterListener(android.support.v4.content.Loader$OnLoadCompleteListener p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.content.Loader$OnLoadCompleteListener)
        v0 = v2.mListener; // android.support.v4.content.Loader.mListener:android.support.v4.content.Loader$OnLoadCompleteListener
        if (v0 != 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "No listener register";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v2.mListener; // android.support.v4.content.Loader.mListener:android.support.v4.content.Loader$OnLoadCompleteListener
        if (v0 == v3) /* goto L_0018 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Attempting to unregister the wrong listener";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = 0;
        v2.mListener = v0; // android.support.v4.content.Loader.mListener:android.support.v4.content.Loader$OnLoadCompleteListener
        return;
    }

}