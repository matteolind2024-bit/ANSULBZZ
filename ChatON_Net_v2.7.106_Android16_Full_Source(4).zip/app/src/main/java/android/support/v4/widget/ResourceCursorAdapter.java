package android.support.v4.widget;

/**
 * Original SourceFile: ResourceCursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/ResourceCursorAdapter;
 */
public abstract class ResourceCursorAdapter extends android.support.v4.widget.CursorAdapter {
    private int mDropDownLayout;
    private android.view.LayoutInflater mInflater;
    private int mLayout;

    public ResourceCursorAdapter(android.content.Context p0, int p1, android.database.Cursor p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (int), v4 = p2 (android.database.Cursor)
        _result = v1.<init>(v2, v4); // android.support.v4.widget.CursorAdapter.<init> -> void
        v1.mDropDownLayout = v3; // android.support.v4.widget.ResourceCursorAdapter.mDropDownLayout:int
        v1.mLayout = v3; // android.support.v4.widget.ResourceCursorAdapter.mLayout:int
        v0 = "layout_inflater";
        _result = v2.getSystemService(v0); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        v1.mInflater = v0; // android.support.v4.widget.ResourceCursorAdapter.mInflater:android.view.LayoutInflater
        return;
    }

    public ResourceCursorAdapter(android.content.Context p0, int p1, android.database.Cursor p2, int p3) {
        // Registers (6 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (int), v4 = p2 (android.database.Cursor), v5 = p3 (int)
        _result = v1.<init>(v2, v4, v5); // android.support.v4.widget.CursorAdapter.<init> -> void
        v1.mDropDownLayout = v3; // android.support.v4.widget.ResourceCursorAdapter.mDropDownLayout:int
        v1.mLayout = v3; // android.support.v4.widget.ResourceCursorAdapter.mLayout:int
        v0 = "layout_inflater";
        _result = v2.getSystemService(v0); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        v1.mInflater = v0; // android.support.v4.widget.ResourceCursorAdapter.mInflater:android.view.LayoutInflater
        return;
    }

    public ResourceCursorAdapter(android.content.Context p0, int p1, android.database.Cursor p2, boolean p3) {
        // Registers (6 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (int), v4 = p2 (android.database.Cursor), v5 = p3 (boolean)
        _result = v1.<init>(v2, v4, v5); // android.support.v4.widget.CursorAdapter.<init> -> void
        v1.mDropDownLayout = v3; // android.support.v4.widget.ResourceCursorAdapter.mDropDownLayout:int
        v1.mLayout = v3; // android.support.v4.widget.ResourceCursorAdapter.mLayout:int
        v0 = "layout_inflater";
        _result = v2.getSystemService(v0); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        v1.mInflater = v0; // android.support.v4.widget.ResourceCursorAdapter.mInflater:android.view.LayoutInflater
        return;
    }

    public android.view.View newDropDownView(android.content.Context p0, android.database.Cursor p1, android.view.ViewGroup p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.database.Cursor), v6 = p2 (android.view.ViewGroup)
        v0 = v3.mInflater; // android.support.v4.widget.ResourceCursorAdapter.mInflater:android.view.LayoutInflater
        v1 = v3.mDropDownLayout; // android.support.v4.widget.ResourceCursorAdapter.mDropDownLayout:int
        v2 = 0;
        _result = v0.inflate(v1, v6, v2); // android.view.LayoutInflater.inflate -> android.view.View
        v0 = _result;
        return v0;
    }

    public android.view.View newView(android.content.Context p0, android.database.Cursor p1, android.view.ViewGroup p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.database.Cursor), v6 = p2 (android.view.ViewGroup)
        v0 = v3.mInflater; // android.support.v4.widget.ResourceCursorAdapter.mInflater:android.view.LayoutInflater
        v1 = v3.mLayout; // android.support.v4.widget.ResourceCursorAdapter.mLayout:int
        v2 = 0;
        _result = v0.inflate(v1, v6, v2); // android.view.LayoutInflater.inflate -> android.view.View
        v0 = _result;
        return v0;
    }

    public void setDropDownViewResource(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.mDropDownLayout = v1; // android.support.v4.widget.ResourceCursorAdapter.mDropDownLayout:int
        return;
    }

    public void setViewResource(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.mLayout = v1; // android.support.v4.widget.ResourceCursorAdapter.mLayout:int
        return;
    }

}