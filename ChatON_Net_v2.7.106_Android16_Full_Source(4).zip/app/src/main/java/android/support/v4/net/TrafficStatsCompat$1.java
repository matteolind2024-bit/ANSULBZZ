package android.support.v4.net;

/**
 * Original SourceFile: TrafficStatsCompat.java
 * Descriptor: Landroid/support/v4/net/TrafficStatsCompat$1;
 */
class TrafficStatsCompat$1 {
}