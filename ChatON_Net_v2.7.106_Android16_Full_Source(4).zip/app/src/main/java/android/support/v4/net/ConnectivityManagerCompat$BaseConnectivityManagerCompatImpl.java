package android.support.v4.net;

/**
 * Original SourceFile: ConnectivityManagerCompat.java
 * Descriptor: Landroid/support/v4/net/ConnectivityManagerCompat$BaseConnectivityManagerCompatImpl;
 */
class ConnectivityManagerCompat$BaseConnectivityManagerCompatImpl implements android.support.v4.net.ConnectivityManagerCompat$ConnectivityManagerCompatImpl {
    ConnectivityManagerCompat$BaseConnectivityManagerCompatImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean isActiveNetworkMetered(android.net.ConnectivityManager p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.net.ConnectivityManager)
        v0 = 1;
        _result = v3.getActiveNetworkInfo(); // android.net.ConnectivityManager.getActiveNetworkInfo -> android.net.NetworkInfo
        v1 = _result;
        if (v1 != 0) /* goto L_0008 */;
        return v0;
        _result = v1.getType(); // android.net.NetworkInfo.getType -> int
        v1 = _result;
        // switch(v1)
        // goto L_0007
        v0 = 0;
        // goto L_0007
    }

}