package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/ModernAsyncTask$Status;
 */
public final enum ModernAsyncTask$Status {
    private static final android.support.v4.content.ModernAsyncTask$Status[] $VALUES;
    public static final android.support.v4.content.ModernAsyncTask$Status FINISHED;
    public static final android.support.v4.content.ModernAsyncTask$Status PENDING;
    public static final android.support.v4.content.ModernAsyncTask$Status RUNNING;

    static {
        v4 = 2;
        v3 = 1;
        v2 = 0;
        v0 = new android.support.v4.content.ModernAsyncTask$Status;
        v1 = "PENDING";
        _result = v0.<init>(v1, v2); // android.support.v4.content.ModernAsyncTask$Status.<init> -> void
        android.support.v4.content.ModernAsyncTask$Status.PENDING = v0; // :android.support.v4.content.ModernAsyncTask$Status
        v0 = new android.support.v4.content.ModernAsyncTask$Status;
        v1 = "RUNNING";
        _result = v0.<init>(v1, v3); // android.support.v4.content.ModernAsyncTask$Status.<init> -> void
        android.support.v4.content.ModernAsyncTask$Status.RUNNING = v0; // :android.support.v4.content.ModernAsyncTask$Status
        v0 = new android.support.v4.content.ModernAsyncTask$Status;
        v1 = "FINISHED";
        _result = v0.<init>(v1, v4); // android.support.v4.content.ModernAsyncTask$Status.<init> -> void
        android.support.v4.content.ModernAsyncTask$Status.FINISHED = v0; // :android.support.v4.content.ModernAsyncTask$Status
        v0 = 3;
        v0 = new android.support.v4.content.ModernAsyncTask$Status[][size=v0];
        v1 = android.support.v4.content.ModernAsyncTask$Status.PENDING; // :android.support.v4.content.ModernAsyncTask$Status
        v0[v2] = v1;
        v1 = android.support.v4.content.ModernAsyncTask$Status.RUNNING; // :android.support.v4.content.ModernAsyncTask$Status
        v0[v3] = v1;
        v1 = android.support.v4.content.ModernAsyncTask$Status.FINISHED; // :android.support.v4.content.ModernAsyncTask$Status
        v0[v4] = v1;
        android.support.v4.content.ModernAsyncTask$Status.$VALUES = v0; // :android.support.v4.content.ModernAsyncTask$Status[]
        return;
    }

    private ModernAsyncTask$Status(java.lang.String p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        return;
    }

    public static android.support.v4.content.ModernAsyncTask$Status valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = android.support.v4.content.ModernAsyncTask$Status.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (android.support.v4.content.ModernAsyncTask$Status) v0;
        return v0;
    }

    public static android.support.v4.content.ModernAsyncTask$Status[] values() {
        v0 = android.support.v4.content.ModernAsyncTask$Status.$VALUES; // :android.support.v4.content.ModernAsyncTask$Status[]
        _result = v0.clone(); // android.support.v4.content.ModernAsyncTask$Status[].clone -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.content.ModernAsyncTask$Status[]) v0;
        return v0;
    }

}