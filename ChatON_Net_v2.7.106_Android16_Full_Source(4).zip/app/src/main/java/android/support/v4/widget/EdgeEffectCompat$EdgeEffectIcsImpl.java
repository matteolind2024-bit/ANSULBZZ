package android.support.v4.widget;

/**
 * Original SourceFile: EdgeEffectCompat.java
 * Descriptor: Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectIcsImpl;
 */
class EdgeEffectCompat$EdgeEffectIcsImpl implements android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl {
    EdgeEffectCompat$EdgeEffectIcsImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean draw(java.lang.Object p0, android.graphics.Canvas p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.graphics.Canvas)
        _result = v2.draw(v3); // android.support.v4.widget.EdgeEffectCompatIcs.draw -> boolean
        v0 = _result;
        return v0;
    }

    public void finish(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v1.finish(); // android.support.v4.widget.EdgeEffectCompatIcs.finish -> void
        return;
    }

    public boolean isFinished(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isFinished(); // android.support.v4.widget.EdgeEffectCompatIcs.isFinished -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.Object newEdgeEffect(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        _result = v2.newEdgeEffect(); // android.support.v4.widget.EdgeEffectCompatIcs.newEdgeEffect -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public boolean onAbsorb(java.lang.Object p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (int)
        _result = v2.onAbsorb(v3); // android.support.v4.widget.EdgeEffectCompatIcs.onAbsorb -> boolean
        v0 = _result;
        return v0;
    }

    public boolean onPull(java.lang.Object p0, float p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (float)
        _result = v2.onPull(v3); // android.support.v4.widget.EdgeEffectCompatIcs.onPull -> boolean
        v0 = _result;
        return v0;
    }

    public boolean onRelease(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.onRelease(); // android.support.v4.widget.EdgeEffectCompatIcs.onRelease -> boolean
        v0 = _result;
        return v0;
    }

    public void setSize(java.lang.Object p0, int p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int), v3 = p2 (int)
        _result = v1.setSize(v2, v3); // android.support.v4.widget.EdgeEffectCompatIcs.setSize -> void
        return;
    }

}