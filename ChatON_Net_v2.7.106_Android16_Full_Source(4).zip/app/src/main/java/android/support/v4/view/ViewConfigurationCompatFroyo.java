package android.support.v4.view;

/**
 * Original SourceFile: ViewConfigurationCompatFroyo.java
 * Descriptor: Landroid/support/v4/view/ViewConfigurationCompatFroyo;
 */
class ViewConfigurationCompatFroyo {
    ViewConfigurationCompatFroyo() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static int getScaledPagingTouchSlop(android.view.ViewConfiguration p0) {
        // Registers (2 total): v1 = p0 (android.view.ViewConfiguration)
        _result = v1.getScaledPagingTouchSlop(); // android.view.ViewConfiguration.getScaledPagingTouchSlop -> int
        v0 = _result;
        return v0;
    }

}