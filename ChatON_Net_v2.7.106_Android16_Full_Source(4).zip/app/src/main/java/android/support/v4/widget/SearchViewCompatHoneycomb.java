package android.support.v4.widget;

/**
 * Original SourceFile: SearchViewCompatHoneycomb.java
 * Descriptor: Landroid/support/v4/widget/SearchViewCompatHoneycomb;
 */
class SearchViewCompatHoneycomb {
    SearchViewCompatHoneycomb() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static java.lang.Object newOnQueryTextListener(android.support.v4.widget.SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.widget.SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge)
        v0 = new android.support.v4.widget.SearchViewCompatHoneycomb$1;
        _result = v0.<init>(v1); // android.support.v4.widget.SearchViewCompatHoneycomb$1.<init> -> void
        return v0;
    }

    public static android.view.View newSearchView(android.content.Context p0) {
        // Registers (2 total): v1 = p0 (android.content.Context)
        v0 = new android.widget.SearchView;
        _result = v0.<init>(v1); // android.widget.SearchView.<init> -> void
        return v0;
    }

    public static void setOnQueryTextListener(java.lang.Object p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (java.lang.Object)
        v0 = (android.widget.SearchView) v0;
        v1 = (android.widget.SearchView$OnQueryTextListener) v1;
        _result = v0.setOnQueryTextListener(v1); // android.widget.SearchView.setOnQueryTextListener -> void
        return;
    }

}