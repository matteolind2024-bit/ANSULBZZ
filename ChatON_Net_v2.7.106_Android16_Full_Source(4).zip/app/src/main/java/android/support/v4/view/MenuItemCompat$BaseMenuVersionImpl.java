package android.support.v4.view;

/**
 * Original SourceFile: MenuItemCompat.java
 * Descriptor: Landroid/support/v4/view/MenuItemCompat$BaseMenuVersionImpl;
 */
class MenuItemCompat$BaseMenuVersionImpl implements android.support.v4.view.MenuItemCompat$MenuVersionImpl {
    MenuItemCompat$BaseMenuVersionImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.view.MenuItem setActionView(android.view.MenuItem p0, android.view.View p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.MenuItem), v2 = p1 (android.view.View)
        return v1;
    }

    public boolean setShowAsAction(android.view.MenuItem p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MenuItem), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

}