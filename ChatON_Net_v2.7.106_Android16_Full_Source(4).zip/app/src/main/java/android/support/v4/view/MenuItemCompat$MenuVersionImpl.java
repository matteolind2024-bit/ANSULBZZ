package android.support.v4.view;

/**
 * Original SourceFile: MenuItemCompat.java
 * Descriptor: Landroid/support/v4/view/MenuItemCompat$MenuVersionImpl;
 */
interface MenuItemCompat$MenuVersionImpl {
    public abstract android.view.MenuItem setActionView(android.view.MenuItem p0, android.view.View p1);
    public abstract boolean setShowAsAction(android.view.MenuItem p0, int p1);
}