package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/FragmentManager$BackStackEntry;
 */
public interface FragmentManager$BackStackEntry {
    public abstract java.lang.CharSequence getBreadCrumbShortTitle();
    public abstract int getBreadCrumbShortTitleRes();
    public abstract java.lang.CharSequence getBreadCrumbTitle();
    public abstract int getBreadCrumbTitleRes();
    public abstract int getId();
    public abstract java.lang.String getName();
}