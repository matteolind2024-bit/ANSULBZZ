package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
 */
interface ViewCompat$ViewCompatImpl {
    public abstract boolean canScrollHorizontally(android.view.View p0, int p1);
    public abstract boolean canScrollVertically(android.view.View p0, int p1);
    public abstract android.support.v4.view.accessibility.AccessibilityNodeProviderCompat getAccessibilityNodeProvider(android.view.View p0);
    public abstract int getImportantForAccessibility(android.view.View p0);
    public abstract int getOverScrollMode(android.view.View p0);
    public abstract boolean hasTransientState(android.view.View p0);
    public abstract void onInitializeAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1);
    public abstract void onInitializeAccessibilityNodeInfo(android.view.View p0, android.support.v4.view.accessibility.AccessibilityNodeInfoCompat p1);
    public abstract void onPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1);
    public abstract void postInvalidateOnAnimation(android.view.View p0);
    public abstract void postInvalidateOnAnimation(android.view.View p0, int p1, int p2, int p3, int p4);
    public abstract void postOnAnimation(android.view.View p0, java.lang.Runnable p1);
    public abstract void postOnAnimationDelayed(android.view.View p0, java.lang.Runnable p1, long p2);
    public abstract void setAccessibilityDelegate(android.view.View p0, android.support.v4.view.AccessibilityDelegateCompat p1);
    public abstract void setHasTransientState(android.view.View p0, boolean p1);
    public abstract void setImportantForAccessibility(android.view.View p0, int p1);
    public abstract void setOverScrollMode(android.view.View p0, int p1);
}