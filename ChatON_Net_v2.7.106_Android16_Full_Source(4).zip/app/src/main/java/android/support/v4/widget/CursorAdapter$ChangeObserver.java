package android.support.v4.widget;

/**
 * Original SourceFile: CursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/CursorAdapter$ChangeObserver;
 */
class CursorAdapter$ChangeObserver extends android.database.ContentObserver {
    final android.support.v4.widget.CursorAdapter this$0;

    public CursorAdapter$ChangeObserver(android.support.v4.widget.CursorAdapter p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.widget.CursorAdapter)
        v1.this$0 = v2; // android.support.v4.widget.CursorAdapter$ChangeObserver.this$0:android.support.v4.widget.CursorAdapter
        v0 = new android.os.Handler;
        _result = v0.<init>(); // android.os.Handler.<init> -> void
        _result = v1.<init>(v0); // android.database.ContentObserver.<init> -> void
        return;
    }

    public boolean deliverSelfNotifications() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public void onChange(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.this$0; // android.support.v4.widget.CursorAdapter$ChangeObserver.this$0:android.support.v4.widget.CursorAdapter
        _result = v0.onContentChanged(); // android.support.v4.widget.CursorAdapter.onContentChanged -> void
        return;
    }

}