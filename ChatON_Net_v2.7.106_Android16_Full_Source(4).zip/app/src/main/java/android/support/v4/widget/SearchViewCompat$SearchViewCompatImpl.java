package android.support.v4.widget;

/**
 * Original SourceFile: SearchViewCompat.java
 * Descriptor: Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;
 */
interface SearchViewCompat$SearchViewCompatImpl {
    public abstract java.lang.Object newOnQueryTextListener(android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat p0);
    public abstract android.view.View newSearchView(android.content.Context p0);
    public abstract void setOnQueryTextListener(java.lang.Object p0, java.lang.Object p1);
}