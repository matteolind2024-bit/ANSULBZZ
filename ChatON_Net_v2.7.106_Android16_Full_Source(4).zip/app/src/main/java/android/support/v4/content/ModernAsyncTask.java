package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/ModernAsyncTask;
 */
abstract class ModernAsyncTask {
    private static final int CORE_POOL_SIZE;
    private static final int KEEP_ALIVE;
    private static final java.lang.String LOG_TAG;
    private static final int MAXIMUM_POOL_SIZE;
    private static final int MESSAGE_POST_PROGRESS;
    private static final int MESSAGE_POST_RESULT;
    public static final java.util.concurrent.Executor THREAD_POOL_EXECUTOR;
    private static volatile java.util.concurrent.Executor sDefaultExecutor;
    private static final android.support.v4.content.ModernAsyncTask$InternalHandler sHandler;
    private static final java.util.concurrent.BlockingQueue sPoolWorkQueue;
    private static final java.util.concurrent.ThreadFactory sThreadFactory;
    private final java.util.concurrent.FutureTask mFuture;
    private volatile android.support.v4.content.ModernAsyncTask$Status mStatus;
    private final java.util.concurrent.atomic.AtomicBoolean mTaskInvoked;
    private final android.support.v4.content.ModernAsyncTask$WorkerRunnable mWorker;

    static {
        v0 = new android.support.v4.content.ModernAsyncTask$1;
        _result = v0.<init>(); // android.support.v4.content.ModernAsyncTask$1.<init> -> void
        android.support.v4.content.ModernAsyncTask.sThreadFactory = v0; // :java.util.concurrent.ThreadFactory
        v0 = new java.util.concurrent.LinkedBlockingQueue;
        v1 = 10;
        _result = v0.<init>(v1); // java.util.concurrent.LinkedBlockingQueue.<init> -> void
        android.support.v4.content.ModernAsyncTask.sPoolWorkQueue = v0; // :java.util.concurrent.BlockingQueue
        v0 = new java.util.concurrent.ThreadPoolExecutor;
        v1 = 5;
        v2 = 128;
        v3 = 1L;
        v5 = java.util.concurrent.TimeUnit.SECONDS; // :java.util.concurrent.TimeUnit
        v6 = android.support.v4.content.ModernAsyncTask.sPoolWorkQueue; // :java.util.concurrent.BlockingQueue
        v7 = android.support.v4.content.ModernAsyncTask.sThreadFactory; // :java.util.concurrent.ThreadFactory
        _result = v0.<init>(v0..v7); // java.util.concurrent.ThreadPoolExecutor.<init> -> void
        android.support.v4.content.ModernAsyncTask.THREAD_POOL_EXECUTOR = v0; // :java.util.concurrent.Executor
        v0 = new android.support.v4.content.ModernAsyncTask$InternalHandler;
        v1 = 0;
        _result = v0.<init>(v1); // android.support.v4.content.ModernAsyncTask$InternalHandler.<init> -> void
        android.support.v4.content.ModernAsyncTask.sHandler = v0; // :android.support.v4.content.ModernAsyncTask$InternalHandler
        v0 = android.support.v4.content.ModernAsyncTask.THREAD_POOL_EXECUTOR; // :java.util.concurrent.Executor
        android.support.v4.content.ModernAsyncTask.sDefaultExecutor = v0; // :java.util.concurrent.Executor
        return;
    }

    public ModernAsyncTask() {
        // Registers (3 total): v2 = this
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v0 = android.support.v4.content.ModernAsyncTask$Status.PENDING; // :android.support.v4.content.ModernAsyncTask$Status
        v2.mStatus = v0; // android.support.v4.content.ModernAsyncTask.mStatus:android.support.v4.content.ModernAsyncTask$Status
        v0 = new java.util.concurrent.atomic.AtomicBoolean;
        _result = v0.<init>(); // java.util.concurrent.atomic.AtomicBoolean.<init> -> void
        v2.mTaskInvoked = v0; // android.support.v4.content.ModernAsyncTask.mTaskInvoked:java.util.concurrent.atomic.AtomicBoolean
        v0 = new android.support.v4.content.ModernAsyncTask$2;
        _result = v0.<init>(v2); // android.support.v4.content.ModernAsyncTask$2.<init> -> void
        v2.mWorker = v0; // android.support.v4.content.ModernAsyncTask.mWorker:android.support.v4.content.ModernAsyncTask$WorkerRunnable
        v0 = new android.support.v4.content.ModernAsyncTask$3;
        v1 = v2.mWorker; // android.support.v4.content.ModernAsyncTask.mWorker:android.support.v4.content.ModernAsyncTask$WorkerRunnable
        _result = v0.<init>(v2, v1); // android.support.v4.content.ModernAsyncTask$3.<init> -> void
        v2.mFuture = v0; // android.support.v4.content.ModernAsyncTask.mFuture:java.util.concurrent.FutureTask
        return;
    }

    static java.util.concurrent.atomic.AtomicBoolean access$200(android.support.v4.content.ModernAsyncTask p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.content.ModernAsyncTask)
        v0 = v1.mTaskInvoked; // android.support.v4.content.ModernAsyncTask.mTaskInvoked:java.util.concurrent.atomic.AtomicBoolean
        return v0;
    }

    static java.lang.Object access$300(android.support.v4.content.ModernAsyncTask p0, java.lang.Object p1) {
        // Registers (3 total): v1 = p0 (android.support.v4.content.ModernAsyncTask), v2 = p1 (java.lang.Object)
        _result = v1.postResult(v2); // android.support.v4.content.ModernAsyncTask.postResult -> java.lang.Object
        v0 = _result;
        return v0;
    }

    static void access$400(android.support.v4.content.ModernAsyncTask p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.content.ModernAsyncTask), v1 = p1 (java.lang.Object)
        _result = v0.postResultIfNotInvoked(v1); // android.support.v4.content.ModernAsyncTask.postResultIfNotInvoked -> void
        return;
    }

    static void access$500(android.support.v4.content.ModernAsyncTask p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.content.ModernAsyncTask), v1 = p1 (java.lang.Object)
        _result = v0.finish(v1); // android.support.v4.content.ModernAsyncTask.finish -> void
        return;
    }

    public static void execute(java.lang.Runnable p0) {
        // Registers (2 total): v1 = p0 (java.lang.Runnable)
        v0 = android.support.v4.content.ModernAsyncTask.sDefaultExecutor; // :java.util.concurrent.Executor
        _result = java.util.concurrent.Executor.execute(v0, v1); // -> void
        return;
    }

    private void finish(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v1.isCancelled(); // android.support.v4.content.ModernAsyncTask.isCancelled -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000e */;
        _result = v1.onCancelled(v2); // android.support.v4.content.ModernAsyncTask.onCancelled -> void
        v0 = android.support.v4.content.ModernAsyncTask$Status.FINISHED; // :android.support.v4.content.ModernAsyncTask$Status
        v1.mStatus = v0; // android.support.v4.content.ModernAsyncTask.mStatus:android.support.v4.content.ModernAsyncTask$Status
        return;
        _result = v1.onPostExecute(v2); // android.support.v4.content.ModernAsyncTask.onPostExecute -> void
        // goto L_0009
    }

    public static void init() {
        v0 = android.support.v4.content.ModernAsyncTask.sHandler; // :android.support.v4.content.ModernAsyncTask$InternalHandler
        _result = v0.getLooper(); // android.support.v4.content.ModernAsyncTask$InternalHandler.getLooper -> android.os.Looper
        return;
    }

    private java.lang.Object postResult(java.lang.Object p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.Object)
        v4 = 1;
        v0 = android.support.v4.content.ModernAsyncTask.sHandler; // :android.support.v4.content.ModernAsyncTask$InternalHandler
        v1 = new android.support.v4.content.ModernAsyncTask$AsyncTaskResult;
        v2 = new java.lang.Object[][size=v4];
        v3 = 0;
        v2[v3] = v6;
        _result = v1.<init>(v5, v2); // android.support.v4.content.ModernAsyncTask$AsyncTaskResult.<init> -> void
        _result = v0.obtainMessage(v4, v1); // android.support.v4.content.ModernAsyncTask$InternalHandler.obtainMessage -> android.os.Message
        v0 = _result;
        _result = v0.sendToTarget(); // android.os.Message.sendToTarget -> void
        return v6;
    }

    private void postResultIfNotInvoked(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = v1.mTaskInvoked; // android.support.v4.content.ModernAsyncTask.mTaskInvoked:java.util.concurrent.atomic.AtomicBoolean
        _result = v0.get(); // java.util.concurrent.atomic.AtomicBoolean.get -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000b */;
        _result = v1.postResult(v2); // android.support.v4.content.ModernAsyncTask.postResult -> java.lang.Object
        return;
    }

    public static void setDefaultExecutor(java.util.concurrent.Executor p0) {
        // Registers (1 total): v0 = p0 (java.util.concurrent.Executor)
        android.support.v4.content.ModernAsyncTask.sDefaultExecutor = v0; // :java.util.concurrent.Executor
        return;
    }

    public final boolean cancel(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.mFuture; // android.support.v4.content.ModernAsyncTask.mFuture:java.util.concurrent.FutureTask
        _result = v0.cancel(v2); // java.util.concurrent.FutureTask.cancel -> boolean
        v0 = _result;
        return v0;
    }

    protected abstract java.lang.Object doInBackground(java.lang.Object[] p0);
    public final android.support.v4.content.ModernAsyncTask execute(java.lang.Object[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object[])
        v0 = android.support.v4.content.ModernAsyncTask.sDefaultExecutor; // :java.util.concurrent.Executor
        _result = v1.executeOnExecutor(v0, v2); // android.support.v4.content.ModernAsyncTask.executeOnExecutor -> android.support.v4.content.ModernAsyncTask
        v0 = _result;
        return v0;
    }

    public final android.support.v4.content.ModernAsyncTask executeOnExecutor(java.util.concurrent.Executor p0, java.lang.Object[] p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.util.concurrent.Executor), v4 = p1 (java.lang.Object[])
        v0 = v2.mStatus; // android.support.v4.content.ModernAsyncTask.mStatus:android.support.v4.content.ModernAsyncTask$Status
        v1 = android.support.v4.content.ModernAsyncTask$Status.PENDING; // :android.support.v4.content.ModernAsyncTask$Status
        if (v0 == v1) /* goto L_0013 */;
        v0 = android.support.v4.content.ModernAsyncTask$4.$SwitchMap$android$support$v4$content$ModernAsyncTask$Status; // :int[]
        v1 = v2.mStatus; // android.support.v4.content.ModernAsyncTask.mStatus:android.support.v4.content.ModernAsyncTask$Status
        _result = v1.ordinal(); // android.support.v4.content.ModernAsyncTask$Status.ordinal -> int
        v1 = _result;
        v0 = v0[v1];
        // switch(v0)
        v0 = android.support.v4.content.ModernAsyncTask$Status.RUNNING; // :android.support.v4.content.ModernAsyncTask$Status
        v2.mStatus = v0; // android.support.v4.content.ModernAsyncTask.mStatus:android.support.v4.content.ModernAsyncTask$Status
        _result = v2.onPreExecute(); // android.support.v4.content.ModernAsyncTask.onPreExecute -> void
        v0 = v2.mWorker; // android.support.v4.content.ModernAsyncTask.mWorker:android.support.v4.content.ModernAsyncTask$WorkerRunnable
        v0.mParams = v4; // android.support.v4.content.ModernAsyncTask$WorkerRunnable.mParams:java.lang.Object[]
        v0 = v2.mFuture; // android.support.v4.content.ModernAsyncTask.mFuture:java.util.concurrent.FutureTask
        _result = java.util.concurrent.Executor.execute(v3, v0); // -> void
        return v2;
        v0 = new java.lang.IllegalStateException;
        v1 = "Cannot execute task: the task is already running.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = new java.lang.IllegalStateException;
        v1 = "Cannot execute task: the task has already been executed (a task can be executed only once)";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
    }

    public final java.lang.Object get() {
        // Registers (2 total): v1 = this
        v0 = v1.mFuture; // android.support.v4.content.ModernAsyncTask.mFuture:java.util.concurrent.FutureTask
        _result = v0.get(); // java.util.concurrent.FutureTask.get -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public final java.lang.Object get(long p0, java.util.concurrent.TimeUnit p1) {
        // Registers (5 total): v1 = this, v2 = p0 (long), v4 = p1 (java.util.concurrent.TimeUnit)
        v0 = v1.mFuture; // android.support.v4.content.ModernAsyncTask.mFuture:java.util.concurrent.FutureTask
        _result = v0.get(v2, v3, v4); // java.util.concurrent.FutureTask.get -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public final android.support.v4.content.ModernAsyncTask$Status getStatus() {
        // Registers (2 total): v1 = this
        v0 = v1.mStatus; // android.support.v4.content.ModernAsyncTask.mStatus:android.support.v4.content.ModernAsyncTask$Status
        return v0;
    }

    public final boolean isCancelled() {
        // Registers (2 total): v1 = this
        v0 = v1.mFuture; // android.support.v4.content.ModernAsyncTask.mFuture:java.util.concurrent.FutureTask
        _result = v0.isCancelled(); // java.util.concurrent.FutureTask.isCancelled -> boolean
        v0 = _result;
        return v0;
    }

    protected void onCancelled() {
        // Registers (1 total): v0 = this
        return;
    }

    protected void onCancelled(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v0.onCancelled(); // android.support.v4.content.ModernAsyncTask.onCancelled -> void
        return;
    }

    protected void onPostExecute(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        return;
    }

    protected void onPreExecute() {
        // Registers (1 total): v0 = this
        return;
    }

    protected void onProgressUpdate(java.lang.Object[] p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object[])
        return;
    }

    protected final void publishProgress(java.lang.Object[] p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.Object[])
        _result = v3.isCancelled(); // android.support.v4.content.ModernAsyncTask.isCancelled -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0015 */;
        v0 = android.support.v4.content.ModernAsyncTask.sHandler; // :android.support.v4.content.ModernAsyncTask$InternalHandler
        v1 = 2;
        v2 = new android.support.v4.content.ModernAsyncTask$AsyncTaskResult;
        _result = v2.<init>(v3, v4); // android.support.v4.content.ModernAsyncTask$AsyncTaskResult.<init> -> void
        _result = v0.obtainMessage(v1, v2); // android.support.v4.content.ModernAsyncTask$InternalHandler.obtainMessage -> android.os.Message
        v0 = _result;
        _result = v0.sendToTarget(); // android.os.Message.sendToTarget -> void
        return;
    }

}