package android.support.v4.net;

/**
 * Original SourceFile: TrafficStatsCompat.java
 * Descriptor: Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;
 */
class TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags {
    public int statsTag;

    private TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = -1;
        v1.statsTag = v0; // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags.statsTag:int
        return;
    }

    TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags(android.support.v4.net.TrafficStatsCompat$1 p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.net.TrafficStatsCompat$1)
        _result = v0.<init>(); // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags.<init> -> void
        return;
    }

}