package android.support.v4.view;

/**
 * Original SourceFile: MotionEventCompat.java
 * Descriptor: Landroid/support/v4/view/MotionEventCompat;
 */
public class MotionEventCompat {
    public static final int ACTION_HOVER_ENTER;
    public static final int ACTION_HOVER_EXIT;
    public static final int ACTION_HOVER_MOVE;
    public static final int ACTION_MASK;
    public static final int ACTION_POINTER_DOWN;
    public static final int ACTION_POINTER_INDEX_MASK;
    public static final int ACTION_POINTER_INDEX_SHIFT;
    public static final int ACTION_POINTER_UP;
    public static final int ACTION_SCROLL;
    static final android.support.v4.view.MotionEventCompat$MotionEventVersionImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 5;
        if (v0 < v1) /* goto L_000d */;
        v0 = new android.support.v4.view.MotionEventCompat$EclairMotionEventVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.MotionEventCompat$EclairMotionEventVersionImpl.<init> -> void
        android.support.v4.view.MotionEventCompat.IMPL = v0; // :android.support.v4.view.MotionEventCompat$MotionEventVersionImpl
        return;
        v0 = new android.support.v4.view.MotionEventCompat$BaseMotionEventVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.MotionEventCompat$BaseMotionEventVersionImpl.<init> -> void
        android.support.v4.view.MotionEventCompat.IMPL = v0; // :android.support.v4.view.MotionEventCompat$MotionEventVersionImpl
        // goto L_000c
    }

    public MotionEventCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static int findPointerIndex(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        v0 = android.support.v4.view.MotionEventCompat.IMPL; // :android.support.v4.view.MotionEventCompat$MotionEventVersionImpl
        _result = android.support.v4.view.MotionEventCompat$MotionEventVersionImpl.findPointerIndex(v0, v1, v2); // -> int
        v0 = _result;
        return v0;
    }

    public static int getActionIndex(android.view.MotionEvent p0) {
        // Registers (3 total): v2 = p0 (android.view.MotionEvent)
        _result = v2.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        v1 = 65280; // 0x0000ff00
        v0 = binOp2addr_0xb5(v0, v1);
        v0 = binOpLit8_0xe1(v0, 8);
        return v0;
    }

    public static int getActionMasked(android.view.MotionEvent p0) {
        // Registers (2 total): v1 = p0 (android.view.MotionEvent)
        _result = v1.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        v0 = binOpLit16_0xd5(v0, 255);
        return v0;
    }

    public static int getPointerId(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        v0 = android.support.v4.view.MotionEventCompat.IMPL; // :android.support.v4.view.MotionEventCompat$MotionEventVersionImpl
        _result = android.support.v4.view.MotionEventCompat$MotionEventVersionImpl.getPointerId(v0, v1, v2); // -> int
        v0 = _result;
        return v0;
    }

    public static float getX(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        v0 = android.support.v4.view.MotionEventCompat.IMPL; // :android.support.v4.view.MotionEventCompat$MotionEventVersionImpl
        _result = android.support.v4.view.MotionEventCompat$MotionEventVersionImpl.getX(v0, v1, v2); // -> float
        v0 = _result;
        return v0;
    }

    public static float getY(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        v0 = android.support.v4.view.MotionEventCompat.IMPL; // :android.support.v4.view.MotionEventCompat$MotionEventVersionImpl
        _result = android.support.v4.view.MotionEventCompat$MotionEventVersionImpl.getY(v0, v1, v2); // -> float
        v0 = _result;
        return v0;
    }

}