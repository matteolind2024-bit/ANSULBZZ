package android.support.v4.view;

/**
 * Original SourceFile: MotionEventCompat.java
 * Descriptor: Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;
 */
interface MotionEventCompat$MotionEventVersionImpl {
    public abstract int findPointerIndex(android.view.MotionEvent p0, int p1);
    public abstract int getPointerId(android.view.MotionEvent p0, int p1);
    public abstract float getX(android.view.MotionEvent p0, int p1);
    public abstract float getY(android.view.MotionEvent p0, int p1);
}