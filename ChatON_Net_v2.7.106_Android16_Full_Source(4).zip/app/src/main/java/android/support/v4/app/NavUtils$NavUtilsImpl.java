package android.support.v4.app;

/**
 * Original SourceFile: NavUtils.java
 * Descriptor: Landroid/support/v4/app/NavUtils$NavUtilsImpl;
 */
interface NavUtils$NavUtilsImpl {
    public abstract android.content.Intent getParentActivityIntent(android.app.Activity p0);
    public abstract java.lang.String getParentActivityName(android.content.Context p0, android.content.pm.ActivityInfo p1);
    public abstract void navigateUpTo(android.app.Activity p0, android.content.Intent p1);
    public abstract boolean shouldUpRecreateTask(android.app.Activity p0, android.content.Intent p1);
}