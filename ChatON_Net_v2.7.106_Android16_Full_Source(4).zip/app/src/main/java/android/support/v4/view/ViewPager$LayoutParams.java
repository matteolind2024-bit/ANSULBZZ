package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$LayoutParams;
 */
public class ViewPager$LayoutParams extends android.view.ViewGroup$LayoutParams {
    public int gravity;
    public boolean isDecor;
    public boolean needsMeasure;
    public float widthFactor;

    public ViewPager$LayoutParams() {
        // Registers (2 total): v1 = this
        v0 = -1;
        _result = v1.<init>(v0, v0); // android.view.ViewGroup$LayoutParams.<init> -> void
        v0 = 0;
        v1.widthFactor = v0; // android.support.v4.view.ViewPager$LayoutParams.widthFactor:float
        return;
    }

    public ViewPager$LayoutParams(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.util.AttributeSet)
        _result = v3.<init>(v4, v5); // android.view.ViewGroup$LayoutParams.<init> -> void
        v0 = 0;
        v3.widthFactor = v0; // android.support.v4.view.ViewPager$LayoutParams.widthFactor:float
        _result = this.access$300(); // android.support.v4.view.ViewPager.access$300 -> int[]
        v0 = _result;
        _result = v4.obtainStyledAttributes(v5, v0); // android.content.Context.obtainStyledAttributes -> android.content.res.TypedArray
        v0 = _result;
        v1 = 0;
        v2 = 48;
        _result = v0.getInteger(v1, v2); // android.content.res.TypedArray.getInteger -> int
        v1 = _result;
        v3.gravity = v1; // android.support.v4.view.ViewPager$LayoutParams.gravity:int
        _result = v0.recycle(); // android.content.res.TypedArray.recycle -> void
        return;
    }

}