package android.support.v4.app;

/**
 * Original SourceFile: Fragment.java
 * Descriptor: Landroid/support/v4/app/Fragment$SavedState;
 */
public class Fragment$SavedState implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
    final android.os.Bundle mState;

    static {
        v0 = new android.support.v4.app.Fragment$SavedState$1;
        _result = v0.<init>(); // android.support.v4.app.Fragment$SavedState$1.<init> -> void
        android.support.v4.app.Fragment$SavedState.CREATOR = v0; // :android.os.Parcelable$Creator
        return;
    }

    Fragment$SavedState(android.os.Bundle p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.Bundle)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.mState = v1; // android.support.v4.app.Fragment$SavedState.mState:android.os.Bundle
        return;
    }

    Fragment$SavedState(android.os.Parcel p0, java.lang.ClassLoader p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (java.lang.ClassLoader)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        _result = v2.readBundle(); // android.os.Parcel.readBundle -> android.os.Bundle
        v0 = _result;
        v1.mState = v0; // android.support.v4.app.Fragment$SavedState.mState:android.os.Bundle
        if (v3 == 0) /* goto L_0014 */;
        v0 = v1.mState; // android.support.v4.app.Fragment$SavedState.mState:android.os.Bundle
        if (v0 == 0) /* goto L_0014 */;
        v0 = v1.mState; // android.support.v4.app.Fragment$SavedState.mState:android.os.Bundle
        _result = v0.setClassLoader(v3); // android.os.Bundle.setClassLoader -> void
        return;
    }

    public int describeContents() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (int)
        v0 = v1.mState; // android.support.v4.app.Fragment$SavedState.mState:android.os.Bundle
        _result = v2.writeBundle(v0); // android.os.Parcel.writeBundle -> void
        return;
    }

}