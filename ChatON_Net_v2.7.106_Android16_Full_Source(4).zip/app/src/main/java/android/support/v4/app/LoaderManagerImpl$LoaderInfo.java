package android.support.v4.app;

/**
 * Original SourceFile: LoaderManager.java
 * Descriptor: Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
 */
final class LoaderManagerImpl$LoaderInfo implements android.support.v4.content.Loader$OnLoadCompleteListener {
    final android.os.Bundle mArgs;
     android.support.v4.app.LoaderManager$LoaderCallbacks mCallbacks;
     java.lang.Object mData;
     boolean mDeliveredData;
     boolean mDestroyed;
     boolean mHaveData;
    final int mId;
     boolean mListenerRegistered;
     android.support.v4.content.Loader mLoader;
     android.support.v4.app.LoaderManagerImpl$LoaderInfo mPendingLoader;
     boolean mReportNextStart;
     boolean mRetaining;
     boolean mRetainingStarted;
     boolean mStarted;
    final android.support.v4.app.LoaderManagerImpl this$0;

    public LoaderManagerImpl$LoaderInfo(android.support.v4.app.LoaderManagerImpl p0, int p1, android.os.Bundle p2, android.support.v4.app.LoaderManager$LoaderCallbacks p3) {
        // Registers (5 total): v0 = this, v1 = p0 (android.support.v4.app.LoaderManagerImpl), v2 = p1 (int), v3 = p2 (android.os.Bundle), v4 = p3 (android.support.v4.app.LoaderManager$LoaderCallbacks)
        v0.this$0 = v1; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.mId = v2; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mId:int
        v0.mArgs = v3; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mArgs:android.os.Bundle
        v0.mCallbacks = v4; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mCallbacks:android.support.v4.app.LoaderManager$LoaderCallbacks
        return;
    }

    void callOnLoadFinished(android.support.v4.content.Loader p0, java.lang.Object p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.support.v4.content.Loader), v6 = p1 (java.lang.Object)
        v0 = v4.mCallbacks; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mCallbacks:android.support.v4.app.LoaderManager$LoaderCallbacks
        if (v0 == 0) /* goto L_005e */;
        v0 = 0;
        v1 = v4.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v1 = v1.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v1 == 0) /* goto L_006f */;
        v0 = v4.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v0 = v0.mNoTransactionsBecause; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        v1 = v4.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v1 = v1.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v2 = "onLoadFinished";
        v1.mNoTransactionsBecause = v2; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        v1 = v0;
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0048 */;
        v0 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  onLoadFinished in ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v5.dataToString(v6); // android.support.v4.content.Loader.dataToString -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v0.v(v2); // android.util.Log.v -> int
        v0 = v4.mCallbacks; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mCallbacks:android.support.v4.app.LoaderManager$LoaderCallbacks
        _result = android.support.v4.app.LoaderManager$LoaderCallbacks.onLoadFinished(v0, v5, v6); // -> void
        v0 = v4.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_005b */;
        v0 = v4.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v0.mNoTransactionsBecause = v1; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        v0 = 1;
        v4.mDeliveredData = v0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mDeliveredData:boolean
        return;
        v0 = _exception;
        v2 = v4.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v2 = v2.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v2 == 0) /* goto L_006e */;
        v2 = v4.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v2 = v2.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v2 = v2.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v2.mNoTransactionsBecause = v1; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        throw v0;
        v1 = v0;
        // goto L_001e
    }

    void destroy() {
        // Registers (6 total): v5 = this
        v2 = 0;
        v4 = 0;
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001e */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Destroying: ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = 1;
        v5.mDestroyed = v0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mDestroyed:boolean
        v0 = v5.mDeliveredData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mDeliveredData:boolean
        v5.mDeliveredData = v4; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mDeliveredData:boolean
        v1 = v5.mCallbacks; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mCallbacks:android.support.v4.app.LoaderManager$LoaderCallbacks
        if (v1 == 0) /* goto L_007d */;
        v1 = v5.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        if (v1 == 0) /* goto L_007d */;
        v1 = v5.mHaveData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mHaveData:boolean
        if (v1 == 0) /* goto L_007d */;
        if (v0 == 0) /* goto L_007d */;
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_004f */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Reseting: ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_00b1 */;
        v0 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v0 = v0.mNoTransactionsBecause; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        v1 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v1 = v1.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v3 = "onLoaderReset";
        v1.mNoTransactionsBecause = v3; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        v1 = v0;
        v0 = v5.mCallbacks; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mCallbacks:android.support.v4.app.LoaderManager$LoaderCallbacks
        v3 = v5.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = android.support.v4.app.LoaderManager$LoaderCallbacks.onLoaderReset(v0, v3); // -> void
        v0 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_007d */;
        v0 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v0.mNoTransactionsBecause = v1; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        v5.mCallbacks = v2; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mCallbacks:android.support.v4.app.LoaderManager$LoaderCallbacks
        v5.mData = v2; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mData:java.lang.Object
        v5.mHaveData = v4; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mHaveData:boolean
        v0 = v5.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        if (v0 == 0) /* goto L_0097 */;
        v0 = v5.mListenerRegistered; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mListenerRegistered:boolean
        if (v0 == 0) /* goto L_0092 */;
        v5.mListenerRegistered = v4; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mListenerRegistered:boolean
        v0 = v5.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v0.unregisterListener(v5); // android.support.v4.content.Loader.unregisterListener -> void
        v0 = v5.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v0.reset(); // android.support.v4.content.Loader.reset -> void
        v0 = v5.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        if (v0 == 0) /* goto L_00a0 */;
        v0 = v5.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        _result = v0.destroy(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.destroy -> void
        return;
        v0 = _exception;
        v2 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v2 = v2.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v2 == 0) /* goto L_00b0 */;
        v2 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v2 = v2.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v2 = v2.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v2.mNoTransactionsBecause = v1; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        throw v0;
        v1 = v2;
        // goto L_0068
    }

    public void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (8 total): v3 = this, v4 = p0 (java.lang.String), v5 = p1 (java.io.FileDescriptor), v6 = p2 (java.io.PrintWriter), v7 = p3 (java.lang.String[])
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mId=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mId; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mId:int
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mArgs=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mArgs; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mArgs:android.os.Bundle
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mCallbacks=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mCallbacks; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mCallbacks:android.support.v4.app.LoaderManager$LoaderCallbacks
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mLoader=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        if (v0 == 0) /* goto L_004d */;
        v0 = v3.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "  ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.dump(v1, v5, v6, v7); // android.support.v4.content.Loader.dump -> void
        v0 = v3.mHaveData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mHaveData:boolean
        if (v0 != 0) /* goto L_0055 */;
        v0 = v3.mDeliveredData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mDeliveredData:boolean
        if (v0 == 0) /* goto L_0079 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mHaveData=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mHaveData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mHaveData:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = "  mDeliveredData=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mDeliveredData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mDeliveredData:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mData=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mData:java.lang.Object
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mStarted=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mReportNextStart=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mReportNextStart; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mReportNextStart:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mDestroyed=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mDestroyed; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mDestroyed:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mRetaining=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mRetaining; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mRetaining:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mRetainingStarted=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mRetainingStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mRetainingStarted:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mListenerRegistered=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mListenerRegistered; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mListenerRegistered:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        if (v0 == 0) /* goto L_00e9 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "Pending Loader ";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = ":";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "  ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.dump(v1, v5, v6, v7); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.dump -> void
        return;
    }

    void finishRetain() {
        // Registers (4 total): v3 = this
        v0 = v3.mRetaining; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mRetaining:boolean
        if (v0 == 0) /* goto L_0030 */;
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0020 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "  Finished Retaining: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = 0;
        v3.mRetaining = v0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mRetaining:boolean
        v0 = v3.mStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        v1 = v3.mRetainingStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mRetainingStarted:boolean
        if (v0 == v1) /* goto L_0030 */;
        v0 = v3.mStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        if (v0 != 0) /* goto L_0030 */;
        _result = v3.stop(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.stop -> void
        v0 = v3.mStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        if (v0 == 0) /* goto L_0043 */;
        v0 = v3.mHaveData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mHaveData:boolean
        if (v0 == 0) /* goto L_0043 */;
        v0 = v3.mReportNextStart; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mReportNextStart:boolean
        if (v0 != 0) /* goto L_0043 */;
        v0 = v3.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        v1 = v3.mData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mData:java.lang.Object
        _result = v3.callOnLoadFinished(v0, v1); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.callOnLoadFinished -> void
        return;
    }

    public void onLoadComplete(android.support.v4.content.Loader p0, java.lang.Object p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.support.v4.content.Loader), v7 = p1 (java.lang.Object)
        v4 = 0;
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001d */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "onLoadComplete: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v5.mDestroyed; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mDestroyed:boolean
        if (v0 == 0) /* goto L_002d */;
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_002c */;
        v0 = "LoaderManager";
        v1 = "  Ignoring load complete -- destroyed";
        _result = v0.v(v1); // android.util.Log.v -> int
        return;
        v0 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        v1 = v5.mId; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mId:int
        _result = v0.get(v1); // android.support.v4.util.SparseArrayCompat.get -> java.lang.Object
        v0 = _result;
        if (v0 == v5) /* goto L_0045 */;
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_002c */;
        v0 = "LoaderManager";
        v1 = "  Ignoring load complete -- not active";
        _result = v0.v(v1); // android.util.Log.v -> int
        // goto L_002c
        v0 = v5.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        if (v0 == 0) /* goto L_0079 */;
        v1 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_0065 */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Switching to pending loader: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v5.mPendingLoader = v4; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        v1 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v1 = v1.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        v2 = v5.mId; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mId:int
        _result = v1.put(v2, v4); // android.support.v4.util.SparseArrayCompat.put -> void
        _result = v5.destroy(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.destroy -> void
        v1 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        _result = v1.installLoader(v0); // android.support.v4.app.LoaderManagerImpl.installLoader -> void
        // goto L_002c
        v0 = v5.mData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mData:java.lang.Object
        if (v0 != v7) /* goto L_0081 */;
        v0 = v5.mHaveData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mHaveData:boolean
        if (v0 != 0) /* goto L_008d */;
        v5.mData = v7; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mData:java.lang.Object
        v0 = 1;
        v5.mHaveData = v0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mHaveData:boolean
        v0 = v5.mStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        if (v0 == 0) /* goto L_008d */;
        _result = v5.callOnLoadFinished(v6, v7); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.callOnLoadFinished -> void
        v0 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        v1 = v5.mId; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mId:int
        _result = v0.get(v1); // android.support.v4.util.SparseArrayCompat.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        if (v0 == 0) /* goto L_00ac */;
        if (v0 == v5) /* goto L_00ac */;
        v1 = 0;
        v0.mDeliveredData = v1; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mDeliveredData:boolean
        _result = v0.destroy(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.destroy -> void
        v0 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        v1 = v5.mId; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mId:int
        _result = v0.remove(v1); // android.support.v4.util.SparseArrayCompat.remove -> void
        v0 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_002c */;
        v0 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        _result = v0.hasRunningLoaders(); // android.support.v4.app.LoaderManagerImpl.hasRunningLoaders -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_002c */;
        v0 = v5.this$0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.this$0:android.support.v4.app.LoaderManagerImpl
        v0 = v0.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.startPendingDeferredFragments(); // android.support.v4.app.FragmentManagerImpl.startPendingDeferredFragments -> void
        // goto L_002c
    }

    void reportStart() {
        // Registers (3 total): v2 = this
        v0 = v2.mStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        if (v0 == 0) /* goto L_0016 */;
        v0 = v2.mReportNextStart; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mReportNextStart:boolean
        if (v0 == 0) /* goto L_0016 */;
        v0 = 0;
        v2.mReportNextStart = v0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mReportNextStart:boolean
        v0 = v2.mHaveData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mHaveData:boolean
        if (v0 == 0) /* goto L_0016 */;
        v0 = v2.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        v1 = v2.mData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mData:java.lang.Object
        _result = v2.callOnLoadFinished(v0, v1); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.callOnLoadFinished -> void
        return;
    }

    void retain() {
        // Registers (4 total): v3 = this
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001c */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "  Retaining: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = 1;
        v3.mRetaining = v0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mRetaining:boolean
        v0 = v3.mStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        v3.mRetainingStarted = v0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mRetainingStarted:boolean
        v0 = 0;
        v3.mStarted = v0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        v0 = 0;
        v3.mCallbacks = v0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mCallbacks:android.support.v4.app.LoaderManager$LoaderCallbacks
        return;
    }

    void start() {
        // Registers (5 total): v4 = this
        v3 = 1;
        v0 = v4.mRetaining; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mRetaining:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = v4.mRetainingStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mRetainingStarted:boolean
        if (v0 == 0) /* goto L_000c */;
        v4.mStarted = v3; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        return;
        v0 = v4.mStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        if (v0 != 0) /* goto L_000b */;
        v4.mStarted = v3; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_002e */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "  Starting: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        if (v0 != 0) /* goto L_0042 */;
        v0 = v4.mCallbacks; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mCallbacks:android.support.v4.app.LoaderManager$LoaderCallbacks
        if (v0 == 0) /* goto L_0042 */;
        v0 = v4.mCallbacks; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mCallbacks:android.support.v4.app.LoaderManager$LoaderCallbacks
        v1 = v4.mId; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mId:int
        v2 = v4.mArgs; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mArgs:android.os.Bundle
        _result = android.support.v4.app.LoaderManager$LoaderCallbacks.onCreateLoader(v0, v1, v2); // -> android.support.v4.content.Loader
        v0 = _result;
        v4.mLoader = v0; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        v0 = v4.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        if (v0 == 0) /* goto L_000b */;
        v0 = v4.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v0.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.isMemberClass(); // java.lang.Class.isMemberClass -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_007d */;
        v0 = v4.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v0.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getModifiers(); // java.lang.Class.getModifiers -> int
        v0 = _result;
        _result = v0.isStatic(); // java.lang.reflect.Modifier.isStatic -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_007d */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Object returned from onCreateLoader must not be a non-static inner member class: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v4.mListenerRegistered; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mListenerRegistered:boolean
        if (v0 != 0) /* goto L_008a */;
        v0 = v4.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        v1 = v4.mId; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mId:int
        _result = v0.registerListener(v1, v4); // android.support.v4.content.Loader.registerListener -> void
        v4.mListenerRegistered = v3; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mListenerRegistered:boolean
        v0 = v4.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v0.startLoading(); // android.support.v4.content.Loader.startLoading -> void
        // goto L_000b
    }

    void stop() {
        // Registers (5 total): v4 = this
        v3 = 0;
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001d */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "  Stopping: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v4.mStarted = v3; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        v0 = v4.mRetaining; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mRetaining:boolean
        if (v0 != 0) /* goto L_0037 */;
        v0 = v4.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        if (v0 == 0) /* goto L_0037 */;
        v0 = v4.mListenerRegistered; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mListenerRegistered:boolean
        if (v0 == 0) /* goto L_0037 */;
        v4.mListenerRegistered = v3; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mListenerRegistered:boolean
        v0 = v4.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v0.unregisterListener(v4); // android.support.v4.content.Loader.unregisterListener -> void
        v0 = v4.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v0.stopLoading(); // android.support.v4.content.Loader.stopLoading -> void
        return;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 64;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = "LoaderInfo{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v2.identityHashCode(); // java.lang.System.identityHashCode -> int
        v1 = _result;
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = " #";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mId; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mId:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = " : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v1.buildShortClassTag(v0); // android.support.v4.util.DebugUtils.buildShortClassTag -> void
        v1 = "}}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}