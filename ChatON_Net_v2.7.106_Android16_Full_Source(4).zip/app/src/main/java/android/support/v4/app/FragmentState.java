package android.support.v4.app;

/**
 * Original SourceFile: Fragment.java
 * Descriptor: Landroid/support/v4/app/FragmentState;
 */
final class FragmentState implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
    final android.os.Bundle mArguments;
    final java.lang.String mClassName;
    final int mContainerId;
    final boolean mDetached;
    final int mFragmentId;
    final boolean mFromLayout;
    final int mIndex;
     android.support.v4.app.Fragment mInstance;
    final boolean mRetainInstance;
     android.os.Bundle mSavedFragmentState;
    final java.lang.String mTag;

    static {
        v0 = new android.support.v4.app.FragmentState$1;
        _result = v0.<init>(); // android.support.v4.app.FragmentState$1.<init> -> void
        android.support.v4.app.FragmentState.CREATOR = v0; // :android.os.Parcelable$Creator
        return;
    }

    public FragmentState(android.os.Parcel p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Parcel)
        v1 = 1;
        v2 = 0;
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        _result = v4.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        v3.mClassName = v0; // android.support.v4.app.FragmentState.mClassName:java.lang.String
        _result = v4.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v3.mIndex = v0; // android.support.v4.app.FragmentState.mIndex:int
        _result = v4.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 == 0) /* goto L_004a */;
        v0 = v1;
        v3.mFromLayout = v0; // android.support.v4.app.FragmentState.mFromLayout:boolean
        _result = v4.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v3.mFragmentId = v0; // android.support.v4.app.FragmentState.mFragmentId:int
        _result = v4.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v3.mContainerId = v0; // android.support.v4.app.FragmentState.mContainerId:int
        _result = v4.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        v3.mTag = v0; // android.support.v4.app.FragmentState.mTag:java.lang.String
        _result = v4.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 == 0) /* goto L_004c */;
        v0 = v1;
        v3.mRetainInstance = v0; // android.support.v4.app.FragmentState.mRetainInstance:boolean
        _result = v4.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 == 0) /* goto L_004e */;
        v3.mDetached = v1; // android.support.v4.app.FragmentState.mDetached:boolean
        _result = v4.readBundle(); // android.os.Parcel.readBundle -> android.os.Bundle
        v0 = _result;
        v3.mArguments = v0; // android.support.v4.app.FragmentState.mArguments:android.os.Bundle
        _result = v4.readBundle(); // android.os.Parcel.readBundle -> android.os.Bundle
        v0 = _result;
        v3.mSavedFragmentState = v0; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        return;
        v0 = v2;
        // goto L_0018
        v0 = v2;
        // goto L_0033
        v1 = v2;
        // goto L_003b
    }

    public FragmentState(android.support.v4.app.Fragment p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.Fragment)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getName(); // java.lang.Class.getName -> java.lang.String
        v0 = _result;
        v1.mClassName = v0; // android.support.v4.app.FragmentState.mClassName:java.lang.String
        v0 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v1.mIndex = v0; // android.support.v4.app.FragmentState.mIndex:int
        v0 = v2.mFromLayout; // android.support.v4.app.Fragment.mFromLayout:boolean
        v1.mFromLayout = v0; // android.support.v4.app.FragmentState.mFromLayout:boolean
        v0 = v2.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        v1.mFragmentId = v0; // android.support.v4.app.FragmentState.mFragmentId:int
        v0 = v2.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        v1.mContainerId = v0; // android.support.v4.app.FragmentState.mContainerId:int
        v0 = v2.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        v1.mTag = v0; // android.support.v4.app.FragmentState.mTag:java.lang.String
        v0 = v2.mRetainInstance; // android.support.v4.app.Fragment.mRetainInstance:boolean
        v1.mRetainInstance = v0; // android.support.v4.app.FragmentState.mRetainInstance:boolean
        v0 = v2.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        v1.mDetached = v0; // android.support.v4.app.FragmentState.mDetached:boolean
        v0 = v2.mArguments; // android.support.v4.app.Fragment.mArguments:android.os.Bundle
        v1.mArguments = v0; // android.support.v4.app.FragmentState.mArguments:android.os.Bundle
        return;
    }

    public int describeContents() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public android.support.v4.app.Fragment instantiate(android.support.v4.app.FragmentActivity p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.support.v4.app.FragmentActivity)
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0007 */;
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        return v0;
        v0 = v3.mArguments; // android.support.v4.app.FragmentState.mArguments:android.os.Bundle
        if (v0 == 0) /* goto L_0014 */;
        v0 = v3.mArguments; // android.support.v4.app.FragmentState.mArguments:android.os.Bundle
        _result = v4.getClassLoader(); // android.support.v4.app.FragmentActivity.getClassLoader -> java.lang.ClassLoader
        v1 = _result;
        _result = v0.setClassLoader(v1); // android.os.Bundle.setClassLoader -> void
        v0 = v3.mClassName; // android.support.v4.app.FragmentState.mClassName:java.lang.String
        v1 = v3.mArguments; // android.support.v4.app.FragmentState.mArguments:android.os.Bundle
        _result = v4.instantiate(v0, v1); // android.support.v4.app.Fragment.instantiate -> android.support.v4.app.Fragment
        v0 = _result;
        v3.mInstance = v0; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v0 = v3.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        if (v0 == 0) /* goto L_0031 */;
        v0 = v3.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        _result = v4.getClassLoader(); // android.support.v4.app.FragmentActivity.getClassLoader -> java.lang.ClassLoader
        v1 = _result;
        _result = v0.setClassLoader(v1); // android.os.Bundle.setClassLoader -> void
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v1 = v3.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v0.mSavedFragmentState = v1; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v1 = v3.mIndex; // android.support.v4.app.FragmentState.mIndex:int
        _result = v0.setIndex(v1); // android.support.v4.app.Fragment.setIndex -> void
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v1 = v3.mFromLayout; // android.support.v4.app.FragmentState.mFromLayout:boolean
        v0.mFromLayout = v1; // android.support.v4.app.Fragment.mFromLayout:boolean
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v1 = 1;
        v0.mRestored = v1; // android.support.v4.app.Fragment.mRestored:boolean
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v1 = v3.mFragmentId; // android.support.v4.app.FragmentState.mFragmentId:int
        v0.mFragmentId = v1; // android.support.v4.app.Fragment.mFragmentId:int
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v1 = v3.mContainerId; // android.support.v4.app.FragmentState.mContainerId:int
        v0.mContainerId = v1; // android.support.v4.app.Fragment.mContainerId:int
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v1 = v3.mTag; // android.support.v4.app.FragmentState.mTag:java.lang.String
        v0.mTag = v1; // android.support.v4.app.Fragment.mTag:java.lang.String
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v1 = v3.mRetainInstance; // android.support.v4.app.FragmentState.mRetainInstance:boolean
        v0.mRetainInstance = v1; // android.support.v4.app.Fragment.mRetainInstance:boolean
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v1 = v3.mDetached; // android.support.v4.app.FragmentState.mDetached:boolean
        v0.mDetached = v1; // android.support.v4.app.Fragment.mDetached:boolean
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v1 = v4.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v0.mFragmentManager = v1; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.FragmentManagerImpl
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0085 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Instantiated fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v3.mInstance; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        // goto L_0006
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.os.Parcel), v5 = p1 (int)
        v1 = 1;
        v2 = 0;
        v0 = v3.mClassName; // android.support.v4.app.FragmentState.mClassName:java.lang.String
        _result = v4.writeString(v0); // android.os.Parcel.writeString -> void
        v0 = v3.mIndex; // android.support.v4.app.FragmentState.mIndex:int
        _result = v4.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v3.mFromLayout; // android.support.v4.app.FragmentState.mFromLayout:boolean
        if (v0 == 0) /* goto L_003d */;
        v0 = v1;
        _result = v4.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v3.mFragmentId; // android.support.v4.app.FragmentState.mFragmentId:int
        _result = v4.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v3.mContainerId; // android.support.v4.app.FragmentState.mContainerId:int
        _result = v4.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v3.mTag; // android.support.v4.app.FragmentState.mTag:java.lang.String
        _result = v4.writeString(v0); // android.os.Parcel.writeString -> void
        v0 = v3.mRetainInstance; // android.support.v4.app.FragmentState.mRetainInstance:boolean
        if (v0 == 0) /* goto L_003f */;
        v0 = v1;
        _result = v4.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v3.mDetached; // android.support.v4.app.FragmentState.mDetached:boolean
        if (v0 == 0) /* goto L_0041 */;
        _result = v4.writeInt(v1); // android.os.Parcel.writeInt -> void
        v0 = v3.mArguments; // android.support.v4.app.FragmentState.mArguments:android.os.Bundle
        _result = v4.writeBundle(v0); // android.os.Parcel.writeBundle -> void
        v0 = v3.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        _result = v4.writeBundle(v0); // android.os.Parcel.writeBundle -> void
        return;
        v0 = v2;
        // goto L_0011
        v0 = v2;
        // goto L_0028
        v1 = v2;
        // goto L_002f
    }

}