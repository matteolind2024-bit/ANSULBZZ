package android.support.v4.app;

/**
 * Original SourceFile: ShareCompatICS.java
 * Descriptor: Landroid/support/v4/app/ShareCompatICS;
 */
class ShareCompatICS {
    private static final java.lang.String HISTORY_FILENAME_PREFIX;

    ShareCompatICS() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void configureMenuItem(android.view.MenuItem p0, android.app.Activity p1, android.content.Intent p2) {
        // Registers (6 total): v3 = p0 (android.view.MenuItem), v4 = p1 (android.app.Activity), v5 = p2 (android.content.Intent)
        _result = android.view.MenuItem.getActionProvider(v3); // -> android.view.ActionProvider
        v0 = _result;
        v1 = (v0 instanceof android.widget.ShareActionProvider);
        if (v1 != 0) /* goto L_0032 */;
        v0 = new android.widget.ShareActionProvider;
        _result = v0.<init>(v4); // android.widget.ShareActionProvider.<init> -> void
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = ".sharecompat_";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v2.getName(); // java.lang.Class.getName -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.setShareHistoryFileName(v1); // android.widget.ShareActionProvider.setShareHistoryFileName -> void
        _result = v0.setShareIntent(v5); // android.widget.ShareActionProvider.setShareIntent -> void
        _result = android.view.MenuItem.setActionProvider(v3, v0); // -> android.view.MenuItem
        return;
        v0 = (android.widget.ShareActionProvider) v0;
        // goto L_000d
    }

}