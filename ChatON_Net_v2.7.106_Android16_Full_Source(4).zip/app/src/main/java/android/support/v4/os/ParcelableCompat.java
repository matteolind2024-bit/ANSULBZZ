package android.support.v4.os;

/**
 * Original SourceFile: ParcelableCompat.java
 * Descriptor: Landroid/support/v4/os/ParcelableCompat;
 */
public class ParcelableCompat {
    public ParcelableCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static android.os.Parcelable$Creator newCreator(android.support.v4.os.ParcelableCompatCreatorCallbacks p0) {
        // Registers (3 total): v2 = p0 (android.support.v4.os.ParcelableCompatCreatorCallbacks)
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 13;
        if (v0 < v1) /* goto L_0009 */;
        _result = v2.instantiate(); // android.support.v4.os.ParcelableCompatCreatorHoneycombMR2Stub.instantiate -> android.os.Parcelable$Creator
        v0 = new android.support.v4.os.ParcelableCompat$CompatCreator;
        _result = v0.<init>(v2); // android.support.v4.os.ParcelableCompat$CompatCreator.<init> -> void
        return v0;
    }

}