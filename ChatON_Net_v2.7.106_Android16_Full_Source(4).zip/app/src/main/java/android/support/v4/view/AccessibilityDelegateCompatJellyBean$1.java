package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompatJellyBean.java
 * Descriptor: Landroid/support/v4/view/AccessibilityDelegateCompatJellyBean$1;
 */
final class AccessibilityDelegateCompatJellyBean$1 extends android.view.View$AccessibilityDelegate {
    final android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean val$bridge;

    AccessibilityDelegateCompatJellyBean$1(android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean)
        v0.val$bridge = v1; // android.support.v4.view.AccessibilityDelegateCompatJellyBean$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean
        _result = v0.<init>(); // android.view.View$AccessibilityDelegate.<init> -> void
        return;
    }

    public boolean dispatchPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatJellyBean$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean
        _result = android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean.dispatchPopulateAccessibilityEvent(v0, v2, v3); // -> boolean
        v0 = _result;
        return v0;
    }

    public android.view.accessibility.AccessibilityNodeProvider getAccessibilityNodeProvider(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatJellyBean$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean
        _result = android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean.getAccessibilityNodeProvider(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (android.view.accessibility.AccessibilityNodeProvider) v0;
        return v0;
    }

    public void onInitializeAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatJellyBean$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean
        _result = android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean.onInitializeAccessibilityEvent(v0, v2, v3); // -> void
        return;
    }

    public void onInitializeAccessibilityNodeInfo(android.view.View p0, android.view.accessibility.AccessibilityNodeInfo p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityNodeInfo)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatJellyBean$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean
        _result = android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean.onInitializeAccessibilityNodeInfo(v0, v2, v3); // -> void
        return;
    }

    public void onPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatJellyBean$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean
        _result = android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean.onPopulateAccessibilityEvent(v0, v2, v3); // -> void
        return;
    }

    public boolean onRequestSendAccessibilityEvent(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (android.view.View), v4 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatJellyBean$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean
        _result = android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean.onRequestSendAccessibilityEvent(v0, v2, v3, v4); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean performAccessibilityAction(android.view.View p0, int p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int), v4 = p2 (android.os.Bundle)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatJellyBean$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean
        _result = android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean.performAccessibilityAction(v0, v2, v3, v4); // -> boolean
        v0 = _result;
        return v0;
    }

    public void sendAccessibilityEvent(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatJellyBean$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean
        _result = android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean.sendAccessibilityEvent(v0, v2, v3); // -> void
        return;
    }

    public void sendAccessibilityEventUnchecked(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatJellyBean$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean
        _result = android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean.sendAccessibilityEventUnchecked(v0, v2, v3); // -> void
        return;
    }

}