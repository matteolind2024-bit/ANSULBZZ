package android.support.v4.view;

/**
 * Original SourceFile: ViewConfigurationCompat.java
 * Descriptor: Landroid/support/v4/view/ViewConfigurationCompat;
 */
public class ViewConfigurationCompat {
    static final android.support.v4.view.ViewConfigurationCompat$ViewConfigurationVersionImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.ViewConfigurationCompat$FroyoViewConfigurationVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.ViewConfigurationCompat$FroyoViewConfigurationVersionImpl.<init> -> void
        android.support.v4.view.ViewConfigurationCompat.IMPL = v0; // :android.support.v4.view.ViewConfigurationCompat$ViewConfigurationVersionImpl
        return;
        v0 = new android.support.v4.view.ViewConfigurationCompat$BaseViewConfigurationVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.ViewConfigurationCompat$BaseViewConfigurationVersionImpl.<init> -> void
        android.support.v4.view.ViewConfigurationCompat.IMPL = v0; // :android.support.v4.view.ViewConfigurationCompat$ViewConfigurationVersionImpl
        // goto L_000d
    }

    public ViewConfigurationCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static int getScaledPagingTouchSlop(android.view.ViewConfiguration p0) {
        // Registers (2 total): v1 = p0 (android.view.ViewConfiguration)
        v0 = android.support.v4.view.ViewConfigurationCompat.IMPL; // :android.support.v4.view.ViewConfigurationCompat$ViewConfigurationVersionImpl
        _result = android.support.v4.view.ViewConfigurationCompat$ViewConfigurationVersionImpl.getScaledPagingTouchSlop(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

}