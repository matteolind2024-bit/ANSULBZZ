package android.support.v4.app;

/**
 * Original SourceFile: FragmentActivity.java
 * Descriptor: Landroid/support/v4/app/FragmentActivity$1;
 */
class FragmentActivity$1 extends android.os.Handler {
    final android.support.v4.app.FragmentActivity this$0;

    FragmentActivity$1(android.support.v4.app.FragmentActivity p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.FragmentActivity)
        v0.this$0 = v1; // android.support.v4.app.FragmentActivity$1.this$0:android.support.v4.app.FragmentActivity
        _result = v0.<init>(); // android.os.Handler.<init> -> void
        return;
    }

    public void handleMessage(android.os.Message p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Message)
        v0 = v3.what; // android.os.Message.what:int
        // switch(v0)
        _result = v2.handleMessage(v3); // android.os.Handler.handleMessage -> void
        return;
        v0 = v2.this$0; // android.support.v4.app.FragmentActivity$1.this$0:android.support.v4.app.FragmentActivity
        v0 = v0.mStopped; // android.support.v4.app.FragmentActivity.mStopped:boolean
        if (v0 == 0) /* goto L_0008 */;
        v0 = v2.this$0; // android.support.v4.app.FragmentActivity$1.this$0:android.support.v4.app.FragmentActivity
        v1 = 0;
        _result = v0.doReallyStop(v1); // android.support.v4.app.FragmentActivity.doReallyStop -> void
        // goto L_0008
        v0 = v2.this$0; // android.support.v4.app.FragmentActivity$1.this$0:android.support.v4.app.FragmentActivity
        _result = v0.onResumeFragments(); // android.support.v4.app.FragmentActivity.onResumeFragments -> void
        v0 = v2.this$0; // android.support.v4.app.FragmentActivity$1.this$0:android.support.v4.app.FragmentActivity
        v0 = v0.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.execPendingActions(); // android.support.v4.app.FragmentManagerImpl.execPendingActions -> boolean
        // goto L_0008
    }

}