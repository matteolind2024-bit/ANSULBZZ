package android.support.v4.app;

/**
 * Original SourceFile: ActivityCompat.java
 * Descriptor: Landroid/support/v4/app/ActivityCompat;
 */
public class ActivityCompat extends android.support.v4.content.ContextCompat {
    public ActivityCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.content.ContextCompat.<init> -> void
        return;
    }

    public static boolean invalidateOptionsMenu(android.app.Activity p0) {
        // Registers (3 total): v2 = p0 (android.app.Activity)
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000b */;
        _result = v2.invalidateOptionsMenu(); // android.support.v4.app.ActivityCompatHoneycomb.invalidateOptionsMenu -> void
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000a
    }

}