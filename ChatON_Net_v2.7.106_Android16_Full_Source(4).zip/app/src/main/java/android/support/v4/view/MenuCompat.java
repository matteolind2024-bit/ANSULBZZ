package android.support.v4.view;

/**
 * Original SourceFile: MenuCompat.java
 * Descriptor: Landroid/support/v4/view/MenuCompat;
 */
public class MenuCompat {
    static final android.support.v4.view.MenuCompat$MenuVersionImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.MenuCompat$HoneycombMenuVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.MenuCompat$HoneycombMenuVersionImpl.<init> -> void
        android.support.v4.view.MenuCompat.IMPL = v0; // :android.support.v4.view.MenuCompat$MenuVersionImpl
        return;
        v0 = new android.support.v4.view.MenuCompat$BaseMenuVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.MenuCompat$BaseMenuVersionImpl.<init> -> void
        android.support.v4.view.MenuCompat.IMPL = v0; // :android.support.v4.view.MenuCompat$MenuVersionImpl
        // goto L_000d
    }

    public MenuCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean setShowAsAction(android.view.MenuItem p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MenuItem), v2 = p1 (int)
        v0 = android.support.v4.view.MenuCompat.IMPL; // :android.support.v4.view.MenuCompat$MenuVersionImpl
        _result = android.support.v4.view.MenuCompat$MenuVersionImpl.setShowAsAction(v0, v1, v2); // -> boolean
        v0 = _result;
        return v0;
    }

}