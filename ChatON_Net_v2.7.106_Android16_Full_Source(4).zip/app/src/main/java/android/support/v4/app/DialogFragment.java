package android.support.v4.app;

/**
 * Original SourceFile: DialogFragment.java
 * Descriptor: Landroid/support/v4/app/DialogFragment;
 */
public class DialogFragment extends android.support.v4.app.Fragment implements android.content.DialogInterface$OnCancelListener, android.content.DialogInterface$OnDismissListener {
    private static final java.lang.String SAVED_BACK_STACK_ID;
    private static final java.lang.String SAVED_CANCELABLE;
    private static final java.lang.String SAVED_DIALOG_STATE_TAG;
    private static final java.lang.String SAVED_SHOWS_DIALOG;
    private static final java.lang.String SAVED_STYLE;
    private static final java.lang.String SAVED_THEME;
    public static final int STYLE_NORMAL;
    public static final int STYLE_NO_FRAME;
    public static final int STYLE_NO_INPUT;
    public static final int STYLE_NO_TITLE;
     int mBackStackId;
     boolean mCancelable;
     android.app.Dialog mDialog;
     boolean mDismissed;
     boolean mShownByMe;
     boolean mShowsDialog;
     int mStyle;
     int mTheme;
     boolean mViewDestroyed;

    public DialogFragment() {
        // Registers (3 total): v2 = this
        v1 = 1;
        v0 = 0;
        _result = v2.<init>(); // android.support.v4.app.Fragment.<init> -> void
        v2.mStyle = v0; // android.support.v4.app.DialogFragment.mStyle:int
        v2.mTheme = v0; // android.support.v4.app.DialogFragment.mTheme:int
        v2.mCancelable = v1; // android.support.v4.app.DialogFragment.mCancelable:boolean
        v2.mShowsDialog = v1; // android.support.v4.app.DialogFragment.mShowsDialog:boolean
        v0 = -1;
        v2.mBackStackId = v0; // android.support.v4.app.DialogFragment.mBackStackId:int
        return;
    }

    public void dismiss() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.dismissInternal(v0); // android.support.v4.app.DialogFragment.dismissInternal -> void
        return;
    }

    public void dismissAllowingStateLoss() {
        // Registers (2 total): v1 = this
        v0 = 1;
        _result = v1.dismissInternal(v0); // android.support.v4.app.DialogFragment.dismissInternal -> void
        return;
    }

    void dismissInternal(boolean p0) {
        // Registers (5 total): v3 = this, v4 = p0 (boolean)
        v2 = 1;
        v0 = v3.mDismissed; // android.support.v4.app.DialogFragment.mDismissed:boolean
        if (v0 == 0) /* goto L_0006 */;
        return;
        v3.mDismissed = v2; // android.support.v4.app.DialogFragment.mDismissed:boolean
        v0 = 0;
        v3.mShownByMe = v0; // android.support.v4.app.DialogFragment.mShownByMe:boolean
        v0 = v3.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        if (v0 == 0) /* goto L_0017 */;
        v0 = v3.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v0.dismiss(); // android.app.Dialog.dismiss -> void
        v0 = 0;
        v3.mDialog = v0; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        v3.mViewDestroyed = v2; // android.support.v4.app.DialogFragment.mViewDestroyed:boolean
        v0 = v3.mBackStackId; // android.support.v4.app.DialogFragment.mBackStackId:int
        if (v0 < 0) /* goto L_002a */;
        _result = v3.getFragmentManager(); // android.support.v4.app.DialogFragment.getFragmentManager -> android.support.v4.app.FragmentManager
        v0 = _result;
        v1 = v3.mBackStackId; // android.support.v4.app.DialogFragment.mBackStackId:int
        _result = v0.popBackStack(v1, v2); // android.support.v4.app.FragmentManager.popBackStack -> void
        v0 = -1;
        v3.mBackStackId = v0; // android.support.v4.app.DialogFragment.mBackStackId:int
        // goto L_0005
        _result = v3.getFragmentManager(); // android.support.v4.app.DialogFragment.getFragmentManager -> android.support.v4.app.FragmentManager
        v0 = _result;
        _result = v0.beginTransaction(); // android.support.v4.app.FragmentManager.beginTransaction -> android.support.v4.app.FragmentTransaction
        v0 = _result;
        _result = v0.remove(v3); // android.support.v4.app.FragmentTransaction.remove -> android.support.v4.app.FragmentTransaction
        if (v4 == 0) /* goto L_003b */;
        _result = v0.commitAllowingStateLoss(); // android.support.v4.app.FragmentTransaction.commitAllowingStateLoss -> int
        // goto L_0005
        _result = v0.commit(); // android.support.v4.app.FragmentTransaction.commit -> int
        // goto L_0005
    }

    public android.app.Dialog getDialog() {
        // Registers (2 total): v1 = this
        v0 = v1.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        return v0;
    }

    public android.view.LayoutInflater getLayoutInflater(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        v0 = v2.mShowsDialog; // android.support.v4.app.DialogFragment.mShowsDialog:boolean
        if (v0 != 0) /* goto L_0009 */;
        _result = v2.getLayoutInflater(v3); // android.support.v4.app.Fragment.getLayoutInflater -> android.view.LayoutInflater
        v0 = _result;
        return v0;
        _result = v2.onCreateDialog(v3); // android.support.v4.app.DialogFragment.onCreateDialog -> android.app.Dialog
        v0 = _result;
        v2.mDialog = v0; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        v0 = v2.mStyle; // android.support.v4.app.DialogFragment.mStyle:int
        // switch(v0)
        v0 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        if (v0 == 0) /* goto L_0039 */;
        v0 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v0.getContext(); // android.app.Dialog.getContext -> android.content.Context
        v0 = _result;
        v1 = "layout_inflater";
        _result = v0.getSystemService(v1); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        // goto L_0008
        v0 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v0.getWindow(); // android.app.Dialog.getWindow -> android.view.Window
        v0 = _result;
        v1 = 24;
        _result = v0.addFlags(v1); // android.view.Window.addFlags -> void
        v0 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        v1 = 1;
        _result = v0.requestWindowFeature(v1); // android.app.Dialog.requestWindowFeature -> boolean
        // goto L_0014
        v0 = v2.mActivity; // android.support.v4.app.DialogFragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = "layout_inflater";
        _result = v0.getSystemService(v1); // android.support.v4.app.FragmentActivity.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        // goto L_0008
    }

    public boolean getShowsDialog() {
        // Registers (2 total): v1 = this
        v0 = v1.mShowsDialog; // android.support.v4.app.DialogFragment.mShowsDialog:boolean
        return v0;
    }

    public int getTheme() {
        // Registers (2 total): v1 = this
        v0 = v1.mTheme; // android.support.v4.app.DialogFragment.mTheme:int
        return v0;
    }

    public boolean isCancelable() {
        // Registers (2 total): v1 = this
        v0 = v1.mCancelable; // android.support.v4.app.DialogFragment.mCancelable:boolean
        return v0;
    }

    public void onActivityCreated(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onActivityCreated(v3); // android.support.v4.app.Fragment.onActivityCreated -> void
        v0 = v2.mShowsDialog; // android.support.v4.app.DialogFragment.mShowsDialog:boolean
        if (v0 != 0) /* goto L_0008 */;
        return;
        _result = v2.getView(); // android.support.v4.app.DialogFragment.getView -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        _result = v0.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v1 = _result;
        if (v1 == 0) /* goto L_001c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "DialogFragment can not be attached to a container view";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v1 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v1.setContentView(v0); // android.app.Dialog.setContentView -> void
        v0 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v2.getActivity(); // android.support.v4.app.DialogFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v0.setOwnerActivity(v1); // android.app.Dialog.setOwnerActivity -> void
        v0 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        v1 = v2.mCancelable; // android.support.v4.app.DialogFragment.mCancelable:boolean
        _result = v0.setCancelable(v1); // android.app.Dialog.setCancelable -> void
        v0 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v0.setOnCancelListener(v2); // android.app.Dialog.setOnCancelListener -> void
        v0 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v0.setOnDismissListener(v2); // android.app.Dialog.setOnDismissListener -> void
        if (v3 == 0) /* goto L_0007 */;
        v0 = "android:savedDialogState";
        _result = v3.getBundle(v0); // android.os.Bundle.getBundle -> android.os.Bundle
        v0 = _result;
        if (v0 == 0) /* goto L_0007 */;
        v1 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v1.onRestoreInstanceState(v0); // android.app.Dialog.onRestoreInstanceState -> void
        // goto L_0007
    }

    public void onAttach(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        _result = v1.onAttach(v2); // android.support.v4.app.Fragment.onAttach -> void
        v0 = v1.mShownByMe; // android.support.v4.app.DialogFragment.mShownByMe:boolean
        if (v0 != 0) /* goto L_000a */;
        v0 = 0;
        v1.mDismissed = v0; // android.support.v4.app.DialogFragment.mDismissed:boolean
        return;
    }

    public void onCancel(android.content.DialogInterface p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.content.DialogInterface)
        return;
    }

    public void onCreate(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v1 = 1;
        v2 = 0;
        _result = v3.onCreate(v4); // android.support.v4.app.Fragment.onCreate -> void
        v0 = v3.mContainerId; // android.support.v4.app.DialogFragment.mContainerId:int
        if (v0 != 0) /* goto L_003a */;
        v0 = v1;
        v3.mShowsDialog = v0; // android.support.v4.app.DialogFragment.mShowsDialog:boolean
        if (v4 == 0) /* goto L_0039 */;
        v0 = "android:style";
        _result = v4.getInt(v0, v2); // android.os.Bundle.getInt -> int
        v0 = _result;
        v3.mStyle = v0; // android.support.v4.app.DialogFragment.mStyle:int
        v0 = "android:theme";
        _result = v4.getInt(v0, v2); // android.os.Bundle.getInt -> int
        v0 = _result;
        v3.mTheme = v0; // android.support.v4.app.DialogFragment.mTheme:int
        v0 = "android:cancelable";
        _result = v4.getBoolean(v0, v1); // android.os.Bundle.getBoolean -> boolean
        v0 = _result;
        v3.mCancelable = v0; // android.support.v4.app.DialogFragment.mCancelable:boolean
        v0 = "android:showsDialog";
        v1 = v3.mShowsDialog; // android.support.v4.app.DialogFragment.mShowsDialog:boolean
        _result = v4.getBoolean(v0, v1); // android.os.Bundle.getBoolean -> boolean
        v0 = _result;
        v3.mShowsDialog = v0; // android.support.v4.app.DialogFragment.mShowsDialog:boolean
        v0 = "android:backStackId";
        v1 = -1;
        _result = v4.getInt(v0, v1); // android.os.Bundle.getInt -> int
        v0 = _result;
        v3.mBackStackId = v0; // android.support.v4.app.DialogFragment.mBackStackId:int
        return;
        v0 = v2;
        // goto L_000a
    }

    public android.app.Dialog onCreateDialog(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v0 = new android.app.Dialog;
        _result = v3.getActivity(); // android.support.v4.app.DialogFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v3.getTheme(); // android.support.v4.app.DialogFragment.getTheme -> int
        v2 = _result;
        _result = v0.<init>(v1, v2); // android.app.Dialog.<init> -> void
        return v0;
    }

    public void onDestroyView() {
        // Registers (2 total): v1 = this
        _result = v1.onDestroyView(); // android.support.v4.app.Fragment.onDestroyView -> void
        v0 = v1.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        if (v0 == 0) /* goto L_0012 */;
        v0 = 1;
        v1.mViewDestroyed = v0; // android.support.v4.app.DialogFragment.mViewDestroyed:boolean
        v0 = v1.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v0.dismiss(); // android.app.Dialog.dismiss -> void
        v0 = 0;
        v1.mDialog = v0; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        return;
    }

    public void onDetach() {
        // Registers (2 total): v1 = this
        _result = v1.onDetach(); // android.support.v4.app.Fragment.onDetach -> void
        v0 = v1.mShownByMe; // android.support.v4.app.DialogFragment.mShownByMe:boolean
        if (v0 != 0) /* goto L_000e */;
        v0 = v1.mDismissed; // android.support.v4.app.DialogFragment.mDismissed:boolean
        if (v0 != 0) /* goto L_000e */;
        v0 = 1;
        v1.mDismissed = v0; // android.support.v4.app.DialogFragment.mDismissed:boolean
        return;
    }

    public void onDismiss(android.content.DialogInterface p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.DialogInterface)
        v0 = v1.mViewDestroyed; // android.support.v4.app.DialogFragment.mViewDestroyed:boolean
        if (v0 != 0) /* goto L_0008 */;
        v0 = 1;
        _result = v1.dismissInternal(v0); // android.support.v4.app.DialogFragment.dismissInternal -> void
        return;
    }

    public void onSaveInstanceState(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onSaveInstanceState(v3); // android.support.v4.app.Fragment.onSaveInstanceState -> void
        v0 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        if (v0 == 0) /* goto L_0014 */;
        v0 = v2.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v0.onSaveInstanceState(); // android.app.Dialog.onSaveInstanceState -> android.os.Bundle
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        v1 = "android:savedDialogState";
        _result = v3.putBundle(v1, v0); // android.os.Bundle.putBundle -> void
        v0 = v2.mStyle; // android.support.v4.app.DialogFragment.mStyle:int
        if (v0 == 0) /* goto L_001f */;
        v0 = "android:style";
        v1 = v2.mStyle; // android.support.v4.app.DialogFragment.mStyle:int
        _result = v3.putInt(v0, v1); // android.os.Bundle.putInt -> void
        v0 = v2.mTheme; // android.support.v4.app.DialogFragment.mTheme:int
        if (v0 == 0) /* goto L_002a */;
        v0 = "android:theme";
        v1 = v2.mTheme; // android.support.v4.app.DialogFragment.mTheme:int
        _result = v3.putInt(v0, v1); // android.os.Bundle.putInt -> void
        v0 = v2.mCancelable; // android.support.v4.app.DialogFragment.mCancelable:boolean
        if (v0 != 0) /* goto L_0035 */;
        v0 = "android:cancelable";
        v1 = v2.mCancelable; // android.support.v4.app.DialogFragment.mCancelable:boolean
        _result = v3.putBoolean(v0, v1); // android.os.Bundle.putBoolean -> void
        v0 = v2.mShowsDialog; // android.support.v4.app.DialogFragment.mShowsDialog:boolean
        if (v0 != 0) /* goto L_0040 */;
        v0 = "android:showsDialog";
        v1 = v2.mShowsDialog; // android.support.v4.app.DialogFragment.mShowsDialog:boolean
        _result = v3.putBoolean(v0, v1); // android.os.Bundle.putBoolean -> void
        v0 = v2.mBackStackId; // android.support.v4.app.DialogFragment.mBackStackId:int
        v1 = -1;
        if (v0 == v1) /* goto L_004c */;
        v0 = "android:backStackId";
        v1 = v2.mBackStackId; // android.support.v4.app.DialogFragment.mBackStackId:int
        _result = v3.putInt(v0, v1); // android.os.Bundle.putInt -> void
        return;
    }

    public void onStart() {
        // Registers (2 total): v1 = this
        _result = v1.onStart(); // android.support.v4.app.Fragment.onStart -> void
        v0 = v1.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        if (v0 == 0) /* goto L_000f */;
        v0 = 0;
        v1.mViewDestroyed = v0; // android.support.v4.app.DialogFragment.mViewDestroyed:boolean
        v0 = v1.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v0.show(); // android.app.Dialog.show -> void
        return;
    }

    public void onStop() {
        // Registers (2 total): v1 = this
        _result = v1.onStop(); // android.support.v4.app.Fragment.onStop -> void
        v0 = v1.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        if (v0 == 0) /* goto L_000c */;
        v0 = v1.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v0.hide(); // android.app.Dialog.hide -> void
        return;
    }

    public void setCancelable(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v1.mCancelable = v2; // android.support.v4.app.DialogFragment.mCancelable:boolean
        v0 = v1.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        if (v0 == 0) /* goto L_000b */;
        v0 = v1.mDialog; // android.support.v4.app.DialogFragment.mDialog:android.app.Dialog
        _result = v0.setCancelable(v2); // android.app.Dialog.setCancelable -> void
        return;
    }

    public void setShowsDialog(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        v0.mShowsDialog = v1; // android.support.v4.app.DialogFragment.mShowsDialog:boolean
        return;
    }

    public void setStyle(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v2.mStyle = v3; // android.support.v4.app.DialogFragment.mStyle:int
        v0 = v2.mStyle; // android.support.v4.app.DialogFragment.mStyle:int
        v1 = 2;
        if (v0 == v1) /* goto L_000c */;
        v0 = v2.mStyle; // android.support.v4.app.DialogFragment.mStyle:int
        v1 = 3;
        if (v0 != v1) /* goto L_0011 */;
        v0 = 16973913; // 0x01030059
        v2.mTheme = v0; // android.support.v4.app.DialogFragment.mTheme:int
        if (v4 == 0) /* goto L_0015 */;
        v2.mTheme = v4; // android.support.v4.app.DialogFragment.mTheme:int
        return;
    }

    public int show(android.support.v4.app.FragmentTransaction p0, java.lang.String p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.support.v4.app.FragmentTransaction), v4 = p1 (java.lang.String)
        v1 = 0;
        v2.mDismissed = v1; // android.support.v4.app.DialogFragment.mDismissed:boolean
        v0 = 1;
        v2.mShownByMe = v0; // android.support.v4.app.DialogFragment.mShownByMe:boolean
        _result = v3.add(v2, v4); // android.support.v4.app.FragmentTransaction.add -> android.support.v4.app.FragmentTransaction
        v2.mViewDestroyed = v1; // android.support.v4.app.DialogFragment.mViewDestroyed:boolean
        _result = v3.commit(); // android.support.v4.app.FragmentTransaction.commit -> int
        v0 = _result;
        v2.mBackStackId = v0; // android.support.v4.app.DialogFragment.mBackStackId:int
        v0 = v2.mBackStackId; // android.support.v4.app.DialogFragment.mBackStackId:int
        return v0;
    }

    public void show(android.support.v4.app.FragmentManager p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.support.v4.app.FragmentManager), v3 = p1 (java.lang.String)
        v0 = 0;
        v1.mDismissed = v0; // android.support.v4.app.DialogFragment.mDismissed:boolean
        v0 = 1;
        v1.mShownByMe = v0; // android.support.v4.app.DialogFragment.mShownByMe:boolean
        _result = v2.beginTransaction(); // android.support.v4.app.FragmentManager.beginTransaction -> android.support.v4.app.FragmentTransaction
        v0 = _result;
        _result = v0.add(v1, v3); // android.support.v4.app.FragmentTransaction.add -> android.support.v4.app.FragmentTransaction
        _result = v0.commit(); // android.support.v4.app.FragmentTransaction.commit -> int
        return;
    }

}