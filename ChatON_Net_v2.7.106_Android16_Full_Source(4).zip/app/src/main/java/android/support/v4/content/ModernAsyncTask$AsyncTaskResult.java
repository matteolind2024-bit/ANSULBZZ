package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;
 */
class ModernAsyncTask$AsyncTaskResult {
    final java.lang.Object[] mData;
    final android.support.v4.content.ModernAsyncTask mTask;

    ModernAsyncTask$AsyncTaskResult(android.support.v4.content.ModernAsyncTask p0, java.lang.Object[] p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.content.ModernAsyncTask), v2 = p1 (java.lang.Object[])
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.mTask = v1; // android.support.v4.content.ModernAsyncTask$AsyncTaskResult.mTask:android.support.v4.content.ModernAsyncTask
        v0.mData = v2; // android.support.v4.content.ModernAsyncTask$AsyncTaskResult.mData:java.lang.Object[]
        return;
    }

}