package android.support.v4.net;

/**
 * Original SourceFile: ConnectivityManagerCompat.java
 * Descriptor: Landroid/support/v4/net/ConnectivityManagerCompat;
 */
public class ConnectivityManagerCompat {
    private static final android.support.v4.net.ConnectivityManagerCompat$ConnectivityManagerCompatImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.net.ConnectivityManagerCompat$JellyBeanConnectivityManagerCompatImpl;
        _result = v0.<init>(); // android.support.v4.net.ConnectivityManagerCompat$JellyBeanConnectivityManagerCompatImpl.<init> -> void
        android.support.v4.net.ConnectivityManagerCompat.IMPL = v0; // :android.support.v4.net.ConnectivityManagerCompat$ConnectivityManagerCompatImpl
        return;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 13;
        if (v0 < v1) /* goto L_001c */;
        v0 = new android.support.v4.net.ConnectivityManagerCompat$HoneycombMR2ConnectivityManagerCompatImpl;
        _result = v0.<init>(); // android.support.v4.net.ConnectivityManagerCompat$HoneycombMR2ConnectivityManagerCompatImpl.<init> -> void
        android.support.v4.net.ConnectivityManagerCompat.IMPL = v0; // :android.support.v4.net.ConnectivityManagerCompat$ConnectivityManagerCompatImpl
        // goto L_000d
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 8;
        if (v0 < v1) /* goto L_002a */;
        v0 = new android.support.v4.net.ConnectivityManagerCompat$GingerbreadConnectivityManagerCompatImpl;
        _result = v0.<init>(); // android.support.v4.net.ConnectivityManagerCompat$GingerbreadConnectivityManagerCompatImpl.<init> -> void
        android.support.v4.net.ConnectivityManagerCompat.IMPL = v0; // :android.support.v4.net.ConnectivityManagerCompat$ConnectivityManagerCompatImpl
        // goto L_000d
        v0 = new android.support.v4.net.ConnectivityManagerCompat$BaseConnectivityManagerCompatImpl;
        _result = v0.<init>(); // android.support.v4.net.ConnectivityManagerCompat$BaseConnectivityManagerCompatImpl.<init> -> void
        android.support.v4.net.ConnectivityManagerCompat.IMPL = v0; // :android.support.v4.net.ConnectivityManagerCompat$ConnectivityManagerCompatImpl
        // goto L_000d
    }

    public ConnectivityManagerCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean isActiveNetworkMetered(android.net.ConnectivityManager p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.net.ConnectivityManager)
        v0 = android.support.v4.net.ConnectivityManagerCompat.IMPL; // :android.support.v4.net.ConnectivityManagerCompat$ConnectivityManagerCompatImpl
        _result = android.support.v4.net.ConnectivityManagerCompat$ConnectivityManagerCompatImpl.isActiveNetworkMetered(v0, v2); // -> boolean
        v0 = _result;
        return v0;
    }

}