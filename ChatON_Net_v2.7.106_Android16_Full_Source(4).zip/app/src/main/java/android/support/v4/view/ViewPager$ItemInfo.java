package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$ItemInfo;
 */
class ViewPager$ItemInfo {
     java.lang.Object object;
     float offset;
     int position;
     boolean scrolling;
     float widthFactor;

    ViewPager$ItemInfo() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}