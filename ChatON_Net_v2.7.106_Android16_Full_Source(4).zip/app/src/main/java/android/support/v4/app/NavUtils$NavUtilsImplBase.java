package android.support.v4.app;

/**
 * Original SourceFile: NavUtils.java
 * Descriptor: Landroid/support/v4/app/NavUtils$NavUtilsImplBase;
 */
class NavUtils$NavUtilsImplBase implements android.support.v4.app.NavUtils$NavUtilsImpl {
    NavUtils$NavUtilsImplBase() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.content.Intent getParentActivityIntent(android.app.Activity p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.app.Activity)
        _result = v3.getParentActivityName(); // android.support.v4.app.NavUtils.getParentActivityName -> java.lang.String
        v0 = _result;
        if (v0 != 0) /* goto L_0008 */;
        v0 = 0;
        return v0;
        v1 = new android.content.Intent;
        _result = v1.<init>(); // android.content.Intent.<init> -> void
        _result = v1.setClassName(v3, v0); // android.content.Intent.setClassName -> android.content.Intent
        v0 = _result;
        // goto L_0007
    }

    public java.lang.String getParentActivityName(android.content.Context p0, android.content.pm.ActivityInfo p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.content.pm.ActivityInfo)
        v1 = 0;
        v0 = v5.metaData; // android.content.pm.ActivityInfo.metaData:android.os.Bundle
        if (v0 != 0) /* goto L_0007 */;
        v0 = v1;
        return v0;
        v0 = v5.metaData; // android.content.pm.ActivityInfo.metaData:android.os.Bundle
        v2 = "android.support.PARENT_ACTIVITY";
        _result = v0.getString(v2); // android.os.Bundle.getString -> java.lang.String
        v0 = _result;
        if (v0 != 0) /* goto L_0013 */;
        v0 = v1;
        // goto L_0006
        v1 = 0;
        _result = v0.charAt(v1); // java.lang.String.charAt -> char
        v1 = _result;
        v2 = 46;
        if (v1 != v2) /* goto L_0006 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v4.getPackageName(); // android.content.Context.getPackageName -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0006
    }

    public void navigateUpTo(android.app.Activity p0, android.content.Intent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.app.Activity), v3 = p1 (android.content.Intent)
        v0 = 0x04000000;
        _result = v3.addFlags(v0); // android.content.Intent.addFlags -> android.content.Intent
        _result = v2.startActivity(v3); // android.app.Activity.startActivity -> void
        _result = v2.finish(); // android.app.Activity.finish -> void
        return;
    }

    public boolean shouldUpRecreateTask(android.app.Activity p0, android.content.Intent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.app.Activity), v4 = p1 (android.content.Intent)
        _result = v3.getIntent(); // android.app.Activity.getIntent -> android.content.Intent
        v0 = _result;
        _result = v0.getAction(); // android.content.Intent.getAction -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        v1 = "android.intent.action.MAIN";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0014 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0013
    }

}