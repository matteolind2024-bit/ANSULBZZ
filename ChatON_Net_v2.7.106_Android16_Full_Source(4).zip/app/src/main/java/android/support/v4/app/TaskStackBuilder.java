package android.support.v4.app;

/**
 * Original SourceFile: TaskStackBuilder.java
 * Descriptor: Landroid/support/v4/app/TaskStackBuilder;
 */
public class TaskStackBuilder implements java.lang.Iterable {
    private static final android.support.v4.app.TaskStackBuilder$TaskStackBuilderImpl IMPL;
    private static final java.lang.String TAG;
    private final java.util.ArrayList mIntents;
    private final android.content.Context mSourceContext;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.app.TaskStackBuilder$TaskStackBuilderImplHoneycomb;
        _result = v0.<init>(); // android.support.v4.app.TaskStackBuilder$TaskStackBuilderImplHoneycomb.<init> -> void
        android.support.v4.app.TaskStackBuilder.IMPL = v0; // :android.support.v4.app.TaskStackBuilder$TaskStackBuilderImpl
        return;
        v0 = new android.support.v4.app.TaskStackBuilder$TaskStackBuilderImplBase;
        _result = v0.<init>(); // android.support.v4.app.TaskStackBuilder$TaskStackBuilderImplBase.<init> -> void
        android.support.v4.app.TaskStackBuilder.IMPL = v0; // :android.support.v4.app.TaskStackBuilder$TaskStackBuilderImpl
        // goto L_000d
    }

    private TaskStackBuilder(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.mIntents = v0; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        v1.mSourceContext = v2; // android.support.v4.app.TaskStackBuilder.mSourceContext:android.content.Context
        return;
    }

    public static android.support.v4.app.TaskStackBuilder create(android.content.Context p0) {
        // Registers (2 total): v1 = p0 (android.content.Context)
        v0 = new android.support.v4.app.TaskStackBuilder;
        _result = v0.<init>(v1); // android.support.v4.app.TaskStackBuilder.<init> -> void
        return v0;
    }

    public static android.support.v4.app.TaskStackBuilder from(android.content.Context p0) {
        // Registers (2 total): v1 = p0 (android.content.Context)
        _result = v1.create(); // android.support.v4.app.TaskStackBuilder.create -> android.support.v4.app.TaskStackBuilder
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.TaskStackBuilder addNextIntent(android.content.Intent p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Intent)
        v0 = v1.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        return v1;
    }

    public android.support.v4.app.TaskStackBuilder addParentStack(android.app.Activity p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.app.Activity)
        v0 = v3.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        _result = v4.getParentActivityIntent(); // android.support.v4.app.NavUtils.getParentActivityIntent -> android.content.Intent
        v0 = _result;
        if (v0 == 0) /* goto L_0028 */;
        v2 = v3.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v2.add(v1, v0); // java.util.ArrayList.add -> void
        _result = v0.getComponent(); // android.content.Intent.getComponent -> android.content.ComponentName
        v0 = _result;
        _result = v4.getParentActivityIntent(v0); // android.support.v4.app.NavUtils.getParentActivityIntent -> android.content.Intent
        v0 = _result;
        // goto L_000a
        v0 = _exception;
        v1 = "TaskStackBuilder";
        v2 = "Bad ComponentName while traversing activity parent metadata";
        _result = v1.e(v2); // android.util.Log.e -> int
        v1 = new java.lang.IllegalArgumentException;
        _result = v1.<init>(v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v1;
        return v3;
    }

    public android.support.v4.app.TaskStackBuilder addParentStack(java.lang.Class p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.Class)
        v0 = v3.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v0 = v3.mSourceContext; // android.support.v4.app.TaskStackBuilder.mSourceContext:android.content.Context
        _result = v0.getParentActivityIntent(v4); // android.support.v4.app.NavUtils.getParentActivityIntent -> android.content.Intent
        v0 = _result;
        if (v0 == 0) /* goto L_002c */;
        v2 = v3.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v2.add(v1, v0); // java.util.ArrayList.add -> void
        v2 = v3.mSourceContext; // android.support.v4.app.TaskStackBuilder.mSourceContext:android.content.Context
        _result = v0.getComponent(); // android.content.Intent.getComponent -> android.content.ComponentName
        v0 = _result;
        _result = v2.getParentActivityIntent(v0); // android.support.v4.app.NavUtils.getParentActivityIntent -> android.content.Intent
        v0 = _result;
        // goto L_000c
        v0 = _exception;
        v1 = "TaskStackBuilder";
        v2 = "Bad ComponentName while traversing activity parent metadata";
        _result = v1.e(v2); // android.util.Log.e -> int
        v1 = new java.lang.IllegalArgumentException;
        _result = v1.<init>(v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v1;
        return v3;
    }

    public android.content.Intent editIntentAt(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.content.Intent) v0;
        return v0;
    }

    public android.content.Intent getIntent(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.editIntentAt(v2); // android.support.v4.app.TaskStackBuilder.editIntentAt -> android.content.Intent
        v0 = _result;
        return v0;
    }

    public int getIntentCount() {
        // Registers (2 total): v1 = this
        v0 = v1.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        return v0;
    }

    public android.content.Intent[] getIntents() {
        // Registers (3 total): v2 = this
        v0 = v2.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        v1 = v2.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = new android.content.Intent[][size=v1];
        _result = v0.toArray(v1); // java.util.ArrayList.toArray -> java.lang.Object[]
        v0 = _result;
        v0 = (android.content.Intent[]) v0;
        return v0;
    }

    public android.app.PendingIntent getPendingIntent(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = 0;
        _result = v1.getPendingIntent(v2, v3, v0); // android.support.v4.app.TaskStackBuilder.getPendingIntent -> android.app.PendingIntent
        v0 = _result;
        return v0;
    }

    public android.app.PendingIntent getPendingIntent(int p0, int p1, android.os.Bundle p2) {
        // Registers (10 total): v6 = this, v7 = p0 (int), v8 = p1 (int), v9 = p2 (android.os.Bundle)
        v0 = v6.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v0.isEmpty(); // java.util.ArrayList.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0010 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "No intents added to TaskStackBuilder; cannot getPendingIntent";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v6.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        v1 = v6.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = new android.content.Intent[][size=v1];
        _result = v0.toArray(v1); // java.util.ArrayList.toArray -> java.lang.Object[]
        v2 = _result;
        v2 = (android.content.Intent[]) v2;
        v0 = 0;
        v0 = v2[v0];
        v1 = 268484608; // 0x1000c000
        _result = v0.addFlags(v1); // android.content.Intent.addFlags -> android.content.Intent
        v0 = android.support.v4.app.TaskStackBuilder.IMPL; // :android.support.v4.app.TaskStackBuilder$TaskStackBuilderImpl
        v1 = v6.mSourceContext; // android.support.v4.app.TaskStackBuilder.mSourceContext:android.content.Context
        v3 = v7;
        v4 = v8;
        v5 = v9;
        _result = android.support.v4.app.TaskStackBuilder$TaskStackBuilderImpl.getPendingIntent(v0..v5); // -> android.app.PendingIntent
        v0 = _result;
        return v0;
    }

    public java.util.Iterator iterator() {
        // Registers (2 total): v1 = this
        v0 = v1.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v0.iterator(); // java.util.ArrayList.iterator -> java.util.Iterator
        v0 = _result;
        return v0;
    }

    public void startActivities() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.startActivities(v0); // android.support.v4.app.TaskStackBuilder.startActivities -> void
        return;
    }

    public void startActivities(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v0 = v3.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v0.isEmpty(); // java.util.ArrayList.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0010 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "No intents added to TaskStackBuilder; cannot startActivities";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        v1 = v3.mIntents; // android.support.v4.app.TaskStackBuilder.mIntents:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = new android.content.Intent[][size=v1];
        _result = v0.toArray(v1); // java.util.ArrayList.toArray -> java.lang.Object[]
        v0 = _result;
        v0 = (android.content.Intent[]) v0;
        v1 = 0;
        v1 = v0[v1];
        v2 = 268484608; // 0x1000c000
        _result = v1.addFlags(v2); // android.content.Intent.addFlags -> android.content.Intent
        v1 = v3.mSourceContext; // android.support.v4.app.TaskStackBuilder.mSourceContext:android.content.Context
        _result = v1.startActivities(v0, v4); // android.support.v4.content.ContextCompat.startActivities -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0040 */;
        v1 = v0.length;
        v1 = binOpLit8_0xd8(v1, -1);
        v0 = v0[v1];
        v1 = 0x10000000;
        _result = v0.addFlags(v1); // android.content.Intent.addFlags -> android.content.Intent
        v1 = v3.mSourceContext; // android.support.v4.app.TaskStackBuilder.mSourceContext:android.content.Context
        _result = v1.startActivity(v0); // android.content.Context.startActivity -> void
        return;
    }

}