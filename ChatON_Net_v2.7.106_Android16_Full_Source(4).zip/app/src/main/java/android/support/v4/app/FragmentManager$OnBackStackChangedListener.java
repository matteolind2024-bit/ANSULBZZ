package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/FragmentManager$OnBackStackChangedListener;
 */
public interface FragmentManager$OnBackStackChangedListener {
    public abstract void onBackStackChanged();
}