package android.support.v4.app;

/**
 * Original SourceFile: ShareCompat.java
 * Descriptor: Landroid/support/v4/app/ShareCompat$ShareCompatImplJB;
 */
class ShareCompat$ShareCompatImplJB extends android.support.v4.app.ShareCompat$ShareCompatImplICS {
    ShareCompat$ShareCompatImplJB() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.app.ShareCompat$ShareCompatImplICS.<init> -> void
        return;
    }

    public java.lang.String escapeHtml(java.lang.CharSequence p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.CharSequence)
        _result = v2.escapeHtml(); // android.support.v4.app.ShareCompatJB.escapeHtml -> java.lang.String
        v0 = _result;
        return v0;
    }

    boolean shouldAddChooserIntent(android.view.MenuItem p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.MenuItem)
        v0 = 0;
        return v0;
    }

}