package android.support.v4.widget;

/**
 * Original SourceFile: SearchViewCompat.java
 * Descriptor: Landroid/support/v4/widget/SearchViewCompat;
 */
public class SearchViewCompat {
    private static final android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl;
        _result = v0.<init>(); // android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl.<init> -> void
        android.support.v4.widget.SearchViewCompat.IMPL = v0; // :android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl
        return;
        v0 = new android.support.v4.widget.SearchViewCompat$SearchViewCompatStubImpl;
        _result = v0.<init>(); // android.support.v4.widget.SearchViewCompat$SearchViewCompatStubImpl.<init> -> void
        android.support.v4.widget.SearchViewCompat.IMPL = v0; // :android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl
        // goto L_000d
    }

    private SearchViewCompat(android.content.Context p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.content.Context)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    static android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl access$000() {
        v0 = android.support.v4.widget.SearchViewCompat.IMPL; // :android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl
        return v0;
    }

    public static android.view.View newSearchView(android.content.Context p0) {
        // Registers (2 total): v1 = p0 (android.content.Context)
        v0 = android.support.v4.widget.SearchViewCompat.IMPL; // :android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl
        _result = android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl.newSearchView(v0, v1); // -> android.view.View
        v0 = _result;
        return v0;
    }

    public static void setOnQueryTextListener(android.view.View p0, android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat p1) {
        // Registers (4 total): v2 = p0 (android.view.View), v3 = p1 (android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat)
        v0 = android.support.v4.widget.SearchViewCompat.IMPL; // :android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl
        v1 = v3.mListener; // android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat.mListener:java.lang.Object
        _result = android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl.setOnQueryTextListener(v0, v2, v1); // -> void
        return;
    }

}