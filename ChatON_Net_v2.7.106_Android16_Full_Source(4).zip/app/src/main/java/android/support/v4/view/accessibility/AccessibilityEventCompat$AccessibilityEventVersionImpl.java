package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityEventCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl;
 */
interface AccessibilityEventCompat$AccessibilityEventVersionImpl {
    public abstract void appendRecord(android.view.accessibility.AccessibilityEvent p0, java.lang.Object p1);
    public abstract java.lang.Object getRecord(android.view.accessibility.AccessibilityEvent p0, int p1);
    public abstract int getRecordCount(android.view.accessibility.AccessibilityEvent p0);
}