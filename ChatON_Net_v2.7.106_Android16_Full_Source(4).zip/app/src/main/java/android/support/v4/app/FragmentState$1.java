package android.support.v4.app;

/**
 * Original SourceFile: Fragment.java
 * Descriptor: Landroid/support/v4/app/FragmentState$1;
 */
final class FragmentState$1 implements android.os.Parcelable$Creator {
    FragmentState$1() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.support.v4.app.FragmentState createFromParcel(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        v0 = new android.support.v4.app.FragmentState;
        _result = v0.<init>(v2); // android.support.v4.app.FragmentState.<init> -> void
        return v0;
    }

    public java.lang.Object createFromParcel(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        _result = v1.createFromParcel(v2); // android.support.v4.app.FragmentState$1.createFromParcel -> android.support.v4.app.FragmentState
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.FragmentState[] newArray(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = new android.support.v4.app.FragmentState[][size=v2];
        return v0;
    }

    public java.lang.Object[] newArray(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.newArray(v2); // android.support.v4.app.FragmentState$1.newArray -> android.support.v4.app.FragmentState[]
        v0 = _result;
        return v0;
    }

}