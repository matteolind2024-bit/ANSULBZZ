package android.support.v4.content;

/**
 * Original SourceFile: AsyncTaskLoader.java
 * Descriptor: Landroid/support/v4/content/AsyncTaskLoader;
 */
public abstract class AsyncTaskLoader extends android.support.v4.content.Loader {
    static final boolean DEBUG;
    static final java.lang.String TAG;
    volatile android.support.v4.content.AsyncTaskLoader$LoadTask mCancellingTask;
     android.os.Handler mHandler;
     long mLastLoadCompleteTime;
    volatile android.support.v4.content.AsyncTaskLoader$LoadTask mTask;
     long mUpdateThrottle;

    public AsyncTaskLoader(android.content.Context p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Context)
        _result = v2.<init>(v3); // android.support.v4.content.Loader.<init> -> void
        v0 = -10000L;
        v2.mLastLoadCompleteTime = v0; // android.support.v4.content.AsyncTaskLoader.mLastLoadCompleteTime:long
        return;
    }

    public boolean cancelLoad() {
        // Registers (5 total): v4 = this
        v3 = 0;
        v0 = 0;
        v1 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        if (v1 == 0) /* goto L_001d */;
        v1 = v4.mCancellingTask; // android.support.v4.content.AsyncTaskLoader.mCancellingTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        if (v1 == 0) /* goto L_001e */;
        v1 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v1 = v1.waiting; // android.support.v4.content.AsyncTaskLoader$LoadTask.waiting:boolean
        if (v1 == 0) /* goto L_001b */;
        v1 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v1.waiting = v0; // android.support.v4.content.AsyncTaskLoader$LoadTask.waiting:boolean
        v1 = v4.mHandler; // android.support.v4.content.AsyncTaskLoader.mHandler:android.os.Handler
        v2 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        _result = v1.removeCallbacks(v2); // android.os.Handler.removeCallbacks -> void
        v4.mTask = v3; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        return v0;
        v1 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v1 = v1.waiting; // android.support.v4.content.AsyncTaskLoader$LoadTask.waiting:boolean
        if (v1 == 0) /* goto L_0032 */;
        v1 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v1.waiting = v0; // android.support.v4.content.AsyncTaskLoader$LoadTask.waiting:boolean
        v1 = v4.mHandler; // android.support.v4.content.AsyncTaskLoader.mHandler:android.os.Handler
        v2 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        _result = v1.removeCallbacks(v2); // android.os.Handler.removeCallbacks -> void
        v4.mTask = v3; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        // goto L_001d
        v1 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        _result = v1.cancel(v0); // android.support.v4.content.AsyncTaskLoader$LoadTask.cancel -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003e */;
        v1 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v4.mCancellingTask = v1; // android.support.v4.content.AsyncTaskLoader.mCancellingTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v4.mTask = v3; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        // goto L_001d
    }

    void dispatchOnCancelled(android.support.v4.content.AsyncTaskLoader$LoadTask p0, java.lang.Object p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.support.v4.content.AsyncTaskLoader$LoadTask), v4 = p1 (java.lang.Object)
        _result = v2.onCanceled(v4); // android.support.v4.content.AsyncTaskLoader.onCanceled -> void
        v0 = v2.mCancellingTask; // android.support.v4.content.AsyncTaskLoader.mCancellingTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        if (v0 != v3) /* goto L_0013 */;
        _result = this.uptimeMillis(); // android.os.SystemClock.uptimeMillis -> long
        v0 = _result;
        v2.mLastLoadCompleteTime = v0; // android.support.v4.content.AsyncTaskLoader.mLastLoadCompleteTime:long
        v0 = 0;
        v2.mCancellingTask = v0; // android.support.v4.content.AsyncTaskLoader.mCancellingTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        _result = v2.executePendingTask(); // android.support.v4.content.AsyncTaskLoader.executePendingTask -> void
        return;
    }

    void dispatchOnLoadComplete(android.support.v4.content.AsyncTaskLoader$LoadTask p0, java.lang.Object p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.support.v4.content.AsyncTaskLoader$LoadTask), v4 = p1 (java.lang.Object)
        v0 = v2.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        if (v0 == v3) /* goto L_0008 */;
        _result = v2.dispatchOnCancelled(v3, v4); // android.support.v4.content.AsyncTaskLoader.dispatchOnCancelled -> void
        return;
        _result = v2.isAbandoned(); // android.support.v4.content.AsyncTaskLoader.isAbandoned -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0012 */;
        _result = v2.onCanceled(v4); // android.support.v4.content.AsyncTaskLoader.onCanceled -> void
        // goto L_0007
        _result = this.uptimeMillis(); // android.os.SystemClock.uptimeMillis -> long
        v0 = _result;
        v2.mLastLoadCompleteTime = v0; // android.support.v4.content.AsyncTaskLoader.mLastLoadCompleteTime:long
        v0 = 0;
        v2.mTask = v0; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        _result = v2.deliverResult(v4); // android.support.v4.content.AsyncTaskLoader.deliverResult -> void
        // goto L_0007
    }

    public void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (9 total): v4 = this, v5 = p0 (java.lang.String), v6 = p1 (java.io.FileDescriptor), v7 = p2 (java.io.PrintWriter), v8 = p3 (java.lang.String[])
        _result = v4.dump(v5, v6, v7, v8); // android.support.v4.content.Loader.dump -> void
        v0 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        if (v0 == 0) /* goto L_0020 */;
        _result = v7.print(v5); // java.io.PrintWriter.print -> void
        v0 = "mTask=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = " waiting=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v0 = v0.waiting; // android.support.v4.content.AsyncTaskLoader$LoadTask.waiting:boolean
        _result = v7.println(v0); // java.io.PrintWriter.println -> void
        v0 = v4.mCancellingTask; // android.support.v4.content.AsyncTaskLoader.mCancellingTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        if (v0 == 0) /* goto L_003d */;
        _result = v7.print(v5); // java.io.PrintWriter.print -> void
        v0 = "mCancellingTask=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.mCancellingTask; // android.support.v4.content.AsyncTaskLoader.mCancellingTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = " waiting=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.mCancellingTask; // android.support.v4.content.AsyncTaskLoader.mCancellingTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v0 = v0.waiting; // android.support.v4.content.AsyncTaskLoader$LoadTask.waiting:boolean
        _result = v7.println(v0); // java.io.PrintWriter.println -> void
        v0 = v4.mUpdateThrottle; // android.support.v4.content.AsyncTaskLoader.mUpdateThrottle:long
        v2 = 0L;
        v0 = cmp(v0, v2);
        if (v0 == 0) /* goto L_0063 */;
        _result = v7.print(v5); // java.io.PrintWriter.print -> void
        v0 = "mUpdateThrottle=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.mUpdateThrottle; // android.support.v4.content.AsyncTaskLoader.mUpdateThrottle:long
        _result = v0.formatDuration(v1, v7); // android.support.v4.util.TimeUtils.formatDuration -> void
        v0 = " mLastLoadCompleteTime=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.mLastLoadCompleteTime; // android.support.v4.content.AsyncTaskLoader.mLastLoadCompleteTime:long
        _result = this.uptimeMillis(); // android.os.SystemClock.uptimeMillis -> long
        v2 = _result;
        _result = v0.formatDuration(v1, v2, v3, v7); // android.support.v4.util.TimeUtils.formatDuration -> void
        _result = v7.println(); // java.io.PrintWriter.println -> void
        return;
    }

    void executePendingTask() {
        // Registers (7 total): v6 = this
        v0 = v6.mCancellingTask; // android.support.v4.content.AsyncTaskLoader.mCancellingTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        if (v0 != 0) /* goto L_0040 */;
        v0 = v6.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        if (v0 == 0) /* goto L_0040 */;
        v0 = v6.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v0 = v0.waiting; // android.support.v4.content.AsyncTaskLoader$LoadTask.waiting:boolean
        if (v0 == 0) /* goto L_001a */;
        v0 = v6.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v1 = 0;
        v0.waiting = v1; // android.support.v4.content.AsyncTaskLoader$LoadTask.waiting:boolean
        v0 = v6.mHandler; // android.support.v4.content.AsyncTaskLoader.mHandler:android.os.Handler
        v1 = v6.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        _result = v0.removeCallbacks(v1); // android.os.Handler.removeCallbacks -> void
        v0 = v6.mUpdateThrottle; // android.support.v4.content.AsyncTaskLoader.mUpdateThrottle:long
        v2 = 0L;
        v0 = cmp(v0, v2);
        if (v0 <= 0) /* goto L_0041 */;
        _result = this.uptimeMillis(); // android.os.SystemClock.uptimeMillis -> long
        v0 = _result;
        v2 = v6.mLastLoadCompleteTime; // android.support.v4.content.AsyncTaskLoader.mLastLoadCompleteTime:long
        v4 = v6.mUpdateThrottle; // android.support.v4.content.AsyncTaskLoader.mUpdateThrottle:long
        v2 = binOp2addr_0xbb(v2, v4);
        v0 = cmp(v0, v2);
        if (v0 >= 0) /* goto L_0041 */;
        v0 = v6.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v1 = 1;
        v0.waiting = v1; // android.support.v4.content.AsyncTaskLoader$LoadTask.waiting:boolean
        v0 = v6.mHandler; // android.support.v4.content.AsyncTaskLoader.mHandler:android.os.Handler
        v1 = v6.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v2 = v6.mLastLoadCompleteTime; // android.support.v4.content.AsyncTaskLoader.mLastLoadCompleteTime:long
        v4 = v6.mUpdateThrottle; // android.support.v4.content.AsyncTaskLoader.mUpdateThrottle:long
        v2 = binOp2addr_0xbb(v2, v4);
        _result = v0.postAtTime(v1, v2, v3); // android.os.Handler.postAtTime -> boolean
        return;
        v1 = v6.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        v2 = android.support.v4.content.ModernAsyncTask.THREAD_POOL_EXECUTOR; // :java.util.concurrent.Executor
        v0 = 0;
        v0 = (java.lang.Void[]) v0;
        _result = v1.executeOnExecutor(v2, v0); // android.support.v4.content.AsyncTaskLoader$LoadTask.executeOnExecutor -> android.support.v4.content.ModernAsyncTask
        // goto L_0040
    }

    public abstract java.lang.Object loadInBackground();
    public void onCanceled(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        return;
    }

    protected void onForceLoad() {
        // Registers (2 total): v1 = this
        _result = v1.onForceLoad(); // android.support.v4.content.Loader.onForceLoad -> void
        _result = v1.cancelLoad(); // android.support.v4.content.AsyncTaskLoader.cancelLoad -> boolean
        v0 = new android.support.v4.content.AsyncTaskLoader$LoadTask;
        _result = v0.<init>(v1); // android.support.v4.content.AsyncTaskLoader$LoadTask.<init> -> void
        v1.mTask = v0; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        _result = v1.executePendingTask(); // android.support.v4.content.AsyncTaskLoader.executePendingTask -> void
        return;
    }

    protected java.lang.Object onLoadInBackground() {
        // Registers (2 total): v1 = this
        _result = v1.loadInBackground(); // android.support.v4.content.AsyncTaskLoader.loadInBackground -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void setUpdateThrottle(long p0) {
        // Registers (5 total): v2 = this, v3 = p0 (long)
        v2.mUpdateThrottle = v3; // android.support.v4.content.AsyncTaskLoader.mUpdateThrottle:long
        v0 = 0L;
        v0 = cmp(v3, v0);
        if (v0 == 0) /* goto L_000f */;
        v0 = new android.os.Handler;
        _result = v0.<init>(); // android.os.Handler.<init> -> void
        v2.mHandler = v0; // android.support.v4.content.AsyncTaskLoader.mHandler:android.os.Handler
        return;
    }

    public void waitForLoader() {
        // Registers (2 total): v1 = this
        v0 = v1.mTask; // android.support.v4.content.AsyncTaskLoader.mTask:android.support.v4.content.AsyncTaskLoader$LoadTask
        if (v0 == 0) /* goto L_000b */;
        _result = v0.access$000(); // android.support.v4.content.AsyncTaskLoader$LoadTask.access$000 -> java.util.concurrent.CountDownLatch
        v0 = _result;
        _result = v0.await(); // java.util.concurrent.CountDownLatch.await -> void
        return;
        v0 = _exception;
        // goto L_000b
    }

}