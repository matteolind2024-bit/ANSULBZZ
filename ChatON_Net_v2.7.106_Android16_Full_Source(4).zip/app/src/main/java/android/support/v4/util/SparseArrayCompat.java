package android.support.v4.util;

/**
 * Original SourceFile: SparseArrayCompat.java
 * Descriptor: Landroid/support/v4/util/SparseArrayCompat;
 */
public class SparseArrayCompat {
    private static final java.lang.Object DELETED;
    private boolean mGarbage;
    private int[] mKeys;
    private int mSize;
    private java.lang.Object[] mValues;

    static {
        v0 = new java.lang.Object;
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        android.support.v4.util.SparseArrayCompat.DELETED = v0; // :java.lang.Object
        return;
    }

    public SparseArrayCompat() {
        // Registers (2 total): v1 = this
        v0 = 10;
        _result = v1.<init>(v0); // android.support.v4.util.SparseArrayCompat.<init> -> void
        return;
    }

    public SparseArrayCompat(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v2 = 0;
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v3.mGarbage = v2; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        _result = v4.idealIntArraySize(); // android.support.v4.util.SparseArrayCompat.idealIntArraySize -> int
        v0 = _result;
        v1 = new int[][size=v0];
        v3.mKeys = v1; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v0 = new java.lang.Object[][size=v0];
        v3.mValues = v0; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v3.mSize = v2; // android.support.v4.util.SparseArrayCompat.mSize:int
        return;
    }

    private static int binarySearch(int[] p0, int p1, int p2, int p3) {
        // Registers (8 total): v4 = p0 (int[]), v5 = p1 (int), v6 = p2 (int), v7 = p3 (int)
        v2 = binOp_0x90(v5, v6);
        v0 = binOpLit8_0xd8(v5, -1);
        v1 = v0;
        v0 = v2;
        v2 = binOp_0x91(v0, v1);
        v3 = 1;
        if (v2 <= v3) /* goto L_0017 */;
        v2 = binOp_0x90(v0, v1);
        v2 = binOpLit8_0xdb(v2, 2);
        v3 = v4[v2];
        if (v3 >= v7) /* goto L_0015 */;
        v1 = v2;
        // goto L_0006
        v0 = v2;
        // goto L_0006
        v1 = binOp_0x90(v5, v6);
        if (v0 != v1) /* goto L_0020 */;
        v0 = binOp_0x90(v5, v6);
        v0 = binOpLit8_0xdf(v0, -1);
        return v0;
        v1 = v4[v0];
        if (v1 == v7) /* goto L_001f */;
        v0 = binOpLit8_0xdf(v0, -1);
        // goto L_001f
    }

    private void gc() {
        // Registers (9 total): v8 = this
        v2 = 0;
        v3 = v8.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v4 = v8.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v5 = v8.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1 = v2;
        v0 = v2;
        if (v1 >= v3) /* goto L_001e */;
        v6 = v5[v1];
        v7 = android.support.v4.util.SparseArrayCompat.DELETED; // :java.lang.Object
        if (v6 == v7) /* goto L_001b */;
        if (v1 == v0) /* goto L_0019 */;
        v7 = v4[v1];
        v4[v0] = v7;
        v5[v0] = v6;
        v0 = binOpLit8_0xd8(v0, 1);
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0009
        v8.mGarbage = v2; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        v8.mSize = v0; // android.support.v4.util.SparseArrayCompat.mSize:int
        return;
    }

    static int idealByteArraySize(int p0) {
        // Registers (4 total): v3 = p0 (int)
        v2 = 1;
        v0 = 4;
        v1 = 32;
        if (v0 >= v1) /* goto L_0010 */;
        v1 = binOp_0x98(v2, v0);
        v1 = binOpLit8_0xd8(v1, -12);
        if (v3 > v1) /* goto L_0011 */;
        v0 = binOp_0x98(v2, v0);
        v3 = binOpLit8_0xd8(v0, -12);
        return v3;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0002
    }

    static int idealIntArraySize(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = binOpLit8_0xda(v1, 4);
        _result = v0.idealByteArraySize(); // android.support.v4.util.SparseArrayCompat.idealByteArraySize -> int
        v0 = _result;
        v0 = binOpLit8_0xdb(v0, 4);
        return v0;
    }

    public void append(int p0, java.lang.Object p1) {
        // Registers (9 total): v6 = this, v7 = p0 (int), v8 = p1 (java.lang.Object)
        v5 = 0;
        v0 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        if (v0 == 0) /* goto L_0013 */;
        v0 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v1 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v1 = binOpLit8_0xd8(v1, -1);
        v0 = v0[v1];
        if (v7 > v0) /* goto L_0013 */;
        _result = v6.put(v7, v8); // android.support.v4.util.SparseArrayCompat.put -> void
        return;
        v0 = v6.mGarbage; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        if (v0 == 0) /* goto L_0021 */;
        v0 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v1 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v1 = v1.length;
        if (v0 < v1) /* goto L_0021 */;
        _result = v6.gc(); // android.support.v4.util.SparseArrayCompat.gc -> void
        v0 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v1 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v1 = v1.length;
        if (v0 < v1) /* goto L_0046 */;
        v1 = binOpLit8_0xd8(v0, 1);
        _result = v1.idealIntArraySize(); // android.support.v4.util.SparseArrayCompat.idealIntArraySize -> int
        v1 = _result;
        v2 = new int[][size=v1];
        v1 = new java.lang.Object[][size=v1];
        v3 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v4 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v4 = v4.length;
        _result = v3.arraycopy(v5, v2, v5, v4); // java.lang.System.arraycopy -> void
        v3 = v6.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v4 = v6.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v4 = v4.length;
        _result = v3.arraycopy(v5, v1, v5, v4); // java.lang.System.arraycopy -> void
        v6.mKeys = v2; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v6.mValues = v1; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v1[v0] = v7;
        v1 = v6.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1[v0] = v8;
        v0 = binOpLit8_0xd8(v0, 1);
        v6.mSize = v0; // android.support.v4.util.SparseArrayCompat.mSize:int
        // goto L_0012
    }

    public void clear() {
        // Registers (6 total): v5 = this
        v1 = 0;
        v2 = v5.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v3 = v5.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v0 = v1;
        if (v0 >= v2) /* goto L_000e */;
        v4 = 0;
        v3[v0] = v4;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0006
        v5.mSize = v1; // android.support.v4.util.SparseArrayCompat.mSize:int
        v5.mGarbage = v1; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        return;
    }

    public void delete(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v1 = 0;
        v2 = v3.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        _result = v0.binarySearch(v1, v2, v4); // android.support.v4.util.SparseArrayCompat.binarySearch -> int
        v0 = _result;
        if (v0 < 0) /* goto L_001c */;
        v1 = v3.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1 = v1[v0];
        v2 = android.support.v4.util.SparseArrayCompat.DELETED; // :java.lang.Object
        if (v1 == v2) /* goto L_001c */;
        v1 = v3.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v2 = android.support.v4.util.SparseArrayCompat.DELETED; // :java.lang.Object
        v1[v0] = v2;
        v0 = 1;
        v3.mGarbage = v0; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        return;
    }

    public java.lang.Object get(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        _result = v1.get(v2, v0); // android.support.v4.util.SparseArrayCompat.get -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object get(int p0, java.lang.Object p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (java.lang.Object)
        v0 = v3.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v1 = 0;
        v2 = v3.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        _result = v0.binarySearch(v1, v2, v4); // android.support.v4.util.SparseArrayCompat.binarySearch -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0013 */;
        v1 = v3.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1 = v1[v0];
        v2 = android.support.v4.util.SparseArrayCompat.DELETED; // :java.lang.Object
        if (v1 != v2) /* goto L_0014 */;
        return v5;
        v1 = v3.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v5 = v1[v0];
        // goto L_0013
    }

    public int indexOfKey(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.mGarbage; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v3.gc(); // android.support.v4.util.SparseArrayCompat.gc -> void
        v0 = v3.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v1 = 0;
        v2 = v3.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        _result = v0.binarySearch(v1, v2, v4); // android.support.v4.util.SparseArrayCompat.binarySearch -> int
        v0 = _result;
        return v0;
    }

    public int indexOfValue(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v0 = v2.mGarbage; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v2.gc(); // android.support.v4.util.SparseArrayCompat.gc -> void
        v0 = 0;
        v1 = v2.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        if (v0 >= v1) /* goto L_0016 */;
        v1 = v2.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1 = v1[v0];
        if (v1 != v3) /* goto L_0013 */;
        return v0;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0008
        v0 = -1;
        // goto L_0012
    }

    public int keyAt(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mGarbage; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v1.gc(); // android.support.v4.util.SparseArrayCompat.gc -> void
        v0 = v1.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v0 = v0[v2];
        return v0;
    }

    public void put(int p0, java.lang.Object p1) {
        // Registers (9 total): v6 = this, v7 = p0 (int), v8 = p1 (java.lang.Object)
        v5 = 0;
        v0 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v1 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        _result = v0.binarySearch(v5, v1, v7); // android.support.v4.util.SparseArrayCompat.binarySearch -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0010 */;
        v1 = v6.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1[v0] = v8;
        return;
        v0 = binOpLit8_0xdf(v0, -1);
        v1 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        if (v0 >= v1) /* goto L_0027 */;
        v1 = v6.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1 = v1[v0];
        v2 = android.support.v4.util.SparseArrayCompat.DELETED; // :java.lang.Object
        if (v1 != v2) /* goto L_0027 */;
        v1 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v1[v0] = v7;
        v1 = v6.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1[v0] = v8;
        // goto L_000f
        v1 = v6.mGarbage; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        if (v1 == 0) /* goto L_003f */;
        v1 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v2 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v2 = v2.length;
        if (v1 < v2) /* goto L_003f */;
        _result = v6.gc(); // android.support.v4.util.SparseArrayCompat.gc -> void
        v0 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v1 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        _result = v0.binarySearch(v5, v1, v7); // android.support.v4.util.SparseArrayCompat.binarySearch -> int
        v0 = _result;
        v0 = binOpLit8_0xdf(v0, -1);
        v1 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v2 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v2 = v2.length;
        if (v1 < v2) /* goto L_0066 */;
        v1 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v1.idealIntArraySize(); // android.support.v4.util.SparseArrayCompat.idealIntArraySize -> int
        v1 = _result;
        v2 = new int[][size=v1];
        v1 = new java.lang.Object[][size=v1];
        v3 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v4 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v4 = v4.length;
        _result = v3.arraycopy(v5, v2, v5, v4); // java.lang.System.arraycopy -> void
        v3 = v6.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v4 = v6.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v4 = v4.length;
        _result = v3.arraycopy(v5, v1, v5, v4); // java.lang.System.arraycopy -> void
        v6.mKeys = v2; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v6.mValues = v1; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v1 = binOp2addr_0xb1(v1, v0);
        if (v1 == 0) /* goto L_0083 */;
        v1 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v2 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v3 = binOpLit8_0xd8(v0, 1);
        v4 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v4 = binOp2addr_0xb1(v4, v0);
        _result = v1.arraycopy(v0, v2, v3, v4); // java.lang.System.arraycopy -> void
        v1 = v6.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v2 = v6.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v3 = binOpLit8_0xd8(v0, 1);
        v4 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v4 = binOp2addr_0xb1(v4, v0);
        _result = v1.arraycopy(v0, v2, v3, v4); // java.lang.System.arraycopy -> void
        v1 = v6.mKeys; // android.support.v4.util.SparseArrayCompat.mKeys:int[]
        v1[v0] = v7;
        v1 = v6.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1[v0] = v8;
        v0 = v6.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v0 = binOpLit8_0xd8(v0, 1);
        v6.mSize = v0; // android.support.v4.util.SparseArrayCompat.mSize:int
        // goto L_000f
    }

    public void remove(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        _result = v0.delete(v1); // android.support.v4.util.SparseArrayCompat.delete -> void
        return;
    }

    public void removeAt(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v0 = v0[v3];
        v1 = android.support.v4.util.SparseArrayCompat.DELETED; // :java.lang.Object
        if (v0 == v1) /* goto L_0011 */;
        v0 = v2.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v1 = android.support.v4.util.SparseArrayCompat.DELETED; // :java.lang.Object
        v0[v3] = v1;
        v0 = 1;
        v2.mGarbage = v0; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        return;
    }

    public void removeAtRange(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v0 = v2.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        v1 = binOp_0x90(v3, v4);
        _result = v0.min(v1); // java.lang.Math.min -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_0010 */;
        _result = v2.removeAt(v3); // android.support.v4.util.SparseArrayCompat.removeAt -> void
        v3 = binOpLit8_0xd8(v3, 1);
        // goto L_0008
        return;
    }

    public void setValueAt(int p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (java.lang.Object)
        v0 = v1.mGarbage; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v1.gc(); // android.support.v4.util.SparseArrayCompat.gc -> void
        v0 = v1.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v0[v2] = v3;
        return;
    }

    public int size() {
        // Registers (2 total): v1 = this
        v0 = v1.mGarbage; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v1.gc(); // android.support.v4.util.SparseArrayCompat.gc -> void
        v0 = v1.mSize; // android.support.v4.util.SparseArrayCompat.mSize:int
        return v0;
    }

    public java.lang.Object valueAt(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mGarbage; // android.support.v4.util.SparseArrayCompat.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v1.gc(); // android.support.v4.util.SparseArrayCompat.gc -> void
        v0 = v1.mValues; // android.support.v4.util.SparseArrayCompat.mValues:java.lang.Object[]
        v0 = v0[v2];
        return v0;
    }

}