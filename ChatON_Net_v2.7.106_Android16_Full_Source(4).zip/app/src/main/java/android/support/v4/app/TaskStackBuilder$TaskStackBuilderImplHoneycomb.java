package android.support.v4.app;

/**
 * Original SourceFile: TaskStackBuilder.java
 * Descriptor: Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImplHoneycomb;
 */
class TaskStackBuilder$TaskStackBuilderImplHoneycomb implements android.support.v4.app.TaskStackBuilder$TaskStackBuilderImpl {
    TaskStackBuilder$TaskStackBuilderImplHoneycomb() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.app.PendingIntent getPendingIntent(android.content.Context p0, android.content.Intent[] p1, int p2, int p3, android.os.Bundle p4) {
        // Registers (8 total): v2 = this, v3 = p0 (android.content.Context), v4 = p1 (android.content.Intent[]), v5 = p2 (int), v6 = p3 (int), v7 = p4 (android.os.Bundle)
        v0 = 0;
        v0 = v4[v0];
        v1 = 268468224; // 0x10008000
        _result = v0.addFlags(v1); // android.content.Intent.addFlags -> android.content.Intent
        _result = v3.getActivitiesPendingIntent(v5, v4, v6); // android.support.v4.app.TaskStackBuilderHoneycomb.getActivitiesPendingIntent -> android.app.PendingIntent
        v0 = _result;
        return v0;
    }

}