package android.support.v4.net;

/**
 * Original SourceFile: ConnectivityManagerCompat.java
 * Descriptor: Landroid/support/v4/net/ConnectivityManagerCompat$ConnectivityManagerCompatImpl;
 */
interface ConnectivityManagerCompat$ConnectivityManagerCompatImpl {
    public abstract boolean isActiveNetworkMetered(android.net.ConnectivityManager p0);
}