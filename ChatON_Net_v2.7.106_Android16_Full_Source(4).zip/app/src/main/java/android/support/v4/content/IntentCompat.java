package android.support.v4.content;

/**
 * Original SourceFile: IntentCompat.java
 * Descriptor: Landroid/support/v4/content/IntentCompat;
 */
public class IntentCompat {
    public static final java.lang.String ACTION_EXTERNAL_APPLICATIONS_AVAILABLE;
    public static final java.lang.String ACTION_EXTERNAL_APPLICATIONS_UNAVAILABLE;
    public static final java.lang.String EXTRA_CHANGED_PACKAGE_LIST;
    public static final java.lang.String EXTRA_CHANGED_UID_LIST;
    public static final java.lang.String EXTRA_HTML_TEXT;
    public static final int FLAG_ACTIVITY_CLEAR_TASK;
    public static final int FLAG_ACTIVITY_TASK_ON_HOME;

    private IntentCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}