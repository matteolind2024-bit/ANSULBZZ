package android.support.v4.widget;

/**
 * Original SourceFile: ScrollerCompat.java
 * Descriptor: Landroid/support/v4/widget/ScrollerCompat;
 */
class ScrollerCompat {
     android.widget.Scroller mScroller;

    ScrollerCompat(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new android.widget.Scroller;
        _result = v0.<init>(v2); // android.widget.Scroller.<init> -> void
        v1.mScroller = v0; // android.support.v4.widget.ScrollerCompat.mScroller:android.widget.Scroller
        return;
    }

    public static android.support.v4.widget.ScrollerCompat from(android.content.Context p0) {
        // Registers (3 total): v2 = p0 (android.content.Context)
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_000c */;
        v0 = new android.support.v4.widget.ScrollerCompat$ScrollerCompatImplIcs;
        _result = v0.<init>(v2); // android.support.v4.widget.ScrollerCompat$ScrollerCompatImplIcs.<init> -> void
        return v0;
        v0 = new android.support.v4.widget.ScrollerCompat;
        _result = v0.<init>(v2); // android.support.v4.widget.ScrollerCompat.<init> -> void
        // goto L_000b
    }

    public void abortAnimation() {
        // Registers (2 total): v1 = this
        v0 = v1.mScroller; // android.support.v4.widget.ScrollerCompat.mScroller:android.widget.Scroller
        _result = v0.abortAnimation(); // android.widget.Scroller.abortAnimation -> void
        return;
    }

    public boolean computeScrollOffset() {
        // Registers (2 total): v1 = this
        v0 = v1.mScroller; // android.support.v4.widget.ScrollerCompat.mScroller:android.widget.Scroller
        _result = v0.computeScrollOffset(); // android.widget.Scroller.computeScrollOffset -> boolean
        v0 = _result;
        return v0;
    }

    public void fling(int p0, int p1, int p2, int p3, int p4, int p5, int p6, int p7) {
        // Registers (18 total): v9 = this, v10 = p0 (int), v11 = p1 (int), v12 = p2 (int), v13 = p3 (int), v14 = p4 (int), v15 = p5 (int), v16 = p6 (int), v17 = p7 (int)
        v0 = v9.mScroller; // android.support.v4.widget.ScrollerCompat.mScroller:android.widget.Scroller
        v1 = v10;
        v2 = v11;
        v3 = v12;
        v4 = v13;
        v5 = v14;
        v6 = v15;
        v7 = v16;
        v8 = v17;
        _result = v0.fling(v0..v8); // android.widget.Scroller.fling -> void
        return;
    }

    public float getCurrVelocity() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public int getCurrX() {
        // Registers (2 total): v1 = this
        v0 = v1.mScroller; // android.support.v4.widget.ScrollerCompat.mScroller:android.widget.Scroller
        _result = v0.getCurrX(); // android.widget.Scroller.getCurrX -> int
        v0 = _result;
        return v0;
    }

    public int getCurrY() {
        // Registers (2 total): v1 = this
        v0 = v1.mScroller; // android.support.v4.widget.ScrollerCompat.mScroller:android.widget.Scroller
        _result = v0.getCurrY(); // android.widget.Scroller.getCurrY -> int
        v0 = _result;
        return v0;
    }

    public int getDuration() {
        // Registers (2 total): v1 = this
        v0 = v1.mScroller; // android.support.v4.widget.ScrollerCompat.mScroller:android.widget.Scroller
        _result = v0.getDuration(); // android.widget.Scroller.getDuration -> int
        v0 = _result;
        return v0;
    }

    public boolean isFinished() {
        // Registers (2 total): v1 = this
        v0 = v1.mScroller; // android.support.v4.widget.ScrollerCompat.mScroller:android.widget.Scroller
        _result = v0.isFinished(); // android.widget.Scroller.isFinished -> boolean
        v0 = _result;
        return v0;
    }

    public void startScroll(int p0, int p1, int p2, int p3) {
        // Registers (6 total): v1 = this, v2 = p0 (int), v3 = p1 (int), v4 = p2 (int), v5 = p3 (int)
        v0 = v1.mScroller; // android.support.v4.widget.ScrollerCompat.mScroller:android.widget.Scroller
        _result = v0.startScroll(v2, v3, v4, v5); // android.widget.Scroller.startScroll -> void
        return;
    }

    public void startScroll(int p0, int p1, int p2, int p3, int p4) {
        // Registers (12 total): v6 = this, v7 = p0 (int), v8 = p1 (int), v9 = p2 (int), v10 = p3 (int), v11 = p4 (int)
        v0 = v6.mScroller; // android.support.v4.widget.ScrollerCompat.mScroller:android.widget.Scroller
        v1 = v7;
        v2 = v8;
        v3 = v9;
        v4 = v10;
        v5 = v11;
        _result = v0.startScroll(v0..v5); // android.widget.Scroller.startScroll -> void
        return;
    }

}