package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$SavedState;
 */
public class ViewPager$SavedState extends android.view.View$BaseSavedState {
    public static final android.os.Parcelable$Creator CREATOR;
     android.os.Parcelable adapterState;
     java.lang.ClassLoader loader;
     int position;

    static {
        v0 = new android.support.v4.view.ViewPager$SavedState$1;
        _result = v0.<init>(); // android.support.v4.view.ViewPager$SavedState$1.<init> -> void
        _result = v0.newCreator(); // android.support.v4.os.ParcelableCompat.newCreator -> android.os.Parcelable$Creator
        v0 = _result;
        android.support.v4.view.ViewPager$SavedState.CREATOR = v0; // :android.os.Parcelable$Creator
        return;
    }

    ViewPager$SavedState(android.os.Parcel p0, java.lang.ClassLoader p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (java.lang.ClassLoader)
        _result = v1.<init>(v2); // android.view.View$BaseSavedState.<init> -> void
        if (v3 != 0) /* goto L_000d */;
        _result = v1.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getClassLoader(); // java.lang.Class.getClassLoader -> java.lang.ClassLoader
        v3 = _result;
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.position = v0; // android.support.v4.view.ViewPager$SavedState.position:int
        _result = v2.readParcelable(v3); // android.os.Parcel.readParcelable -> android.os.Parcelable
        v0 = _result;
        v1.adapterState = v0; // android.support.v4.view.ViewPager$SavedState.adapterState:android.os.Parcelable
        v1.loader = v3; // android.support.v4.view.ViewPager$SavedState.loader:java.lang.ClassLoader
        return;
    }

    public ViewPager$SavedState(android.os.Parcelable p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.Parcelable)
        _result = v0.<init>(v1); // android.view.View$BaseSavedState.<init> -> void
        return;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "FragmentPager.SavedState{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.identityHashCode(); // java.lang.System.identityHashCode -> int
        v1 = _result;
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " position=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.position; // android.support.v4.view.ViewPager$SavedState.position:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (int)
        _result = v1.writeToParcel(v2, v3); // android.view.View$BaseSavedState.writeToParcel -> void
        v0 = v1.position; // android.support.v4.view.ViewPager$SavedState.position:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v1.adapterState; // android.support.v4.view.ViewPager$SavedState.adapterState:android.os.Parcelable
        _result = v2.writeParcelable(v0, v3); // android.os.Parcel.writeParcelable -> void
        return;
    }

}