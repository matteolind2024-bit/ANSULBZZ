package android.support.v4.view;

/**
 * Original SourceFile: ViewCompatGingerbread.java
 * Descriptor: Landroid/support/v4/view/ViewCompatGingerbread;
 */
class ViewCompatGingerbread {
    ViewCompatGingerbread() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static int getOverScrollMode(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        _result = v1.getOverScrollMode(); // android.view.View.getOverScrollMode -> int
        v0 = _result;
        return v0;
    }

    public static void setOverScrollMode(android.view.View p0, int p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (int)
        _result = v0.setOverScrollMode(v1); // android.view.View.setOverScrollMode -> void
        return;
    }

}