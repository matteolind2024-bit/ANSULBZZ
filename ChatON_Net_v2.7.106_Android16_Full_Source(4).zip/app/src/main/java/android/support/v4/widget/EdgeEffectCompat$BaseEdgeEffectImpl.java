package android.support.v4.widget;

/**
 * Original SourceFile: EdgeEffectCompat.java
 * Descriptor: Landroid/support/v4/widget/EdgeEffectCompat$BaseEdgeEffectImpl;
 */
class EdgeEffectCompat$BaseEdgeEffectImpl implements android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl {
    EdgeEffectCompat$BaseEdgeEffectImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean draw(java.lang.Object p0, android.graphics.Canvas p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.graphics.Canvas)
        v0 = 0;
        return v0;
    }

    public void finish(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        return;
    }

    public boolean isFinished(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 1;
        return v0;
    }

    public java.lang.Object newEdgeEffect(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        v0 = 0;
        return v0;
    }

    public boolean onAbsorb(java.lang.Object p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

    public boolean onPull(java.lang.Object p0, float p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (float)
        v0 = 0;
        return v0;
    }

    public boolean onRelease(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public void setSize(java.lang.Object p0, int p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int), v3 = p2 (int)
        return;
    }

}