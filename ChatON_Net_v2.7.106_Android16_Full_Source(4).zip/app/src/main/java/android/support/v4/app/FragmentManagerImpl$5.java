package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/FragmentManagerImpl$5;
 */
class FragmentManagerImpl$5 implements android.view.animation.Animation$AnimationListener {
    final android.support.v4.app.FragmentManagerImpl this$0;
    final android.support.v4.app.Fragment val$fragment;

    FragmentManagerImpl$5(android.support.v4.app.FragmentManagerImpl p0, android.support.v4.app.Fragment p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.app.FragmentManagerImpl), v2 = p1 (android.support.v4.app.Fragment)
        v0.this$0 = v1; // android.support.v4.app.FragmentManagerImpl$5.this$0:android.support.v4.app.FragmentManagerImpl
        v0.val$fragment = v2; // android.support.v4.app.FragmentManagerImpl$5.val$fragment:android.support.v4.app.Fragment
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onAnimationEnd(android.view.animation.Animation p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.view.animation.Animation)
        v3 = 0;
        v0 = v6.val$fragment; // android.support.v4.app.FragmentManagerImpl$5.val$fragment:android.support.v4.app.Fragment
        v0 = v0.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        if (v0 == 0) /* goto L_0019 */;
        v0 = v6.val$fragment; // android.support.v4.app.FragmentManagerImpl$5.val$fragment:android.support.v4.app.Fragment
        v1 = 0;
        v0.mAnimatingAway = v1; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        v0 = v6.this$0; // android.support.v4.app.FragmentManagerImpl$5.this$0:android.support.v4.app.FragmentManagerImpl
        v1 = v6.val$fragment; // android.support.v4.app.FragmentManagerImpl$5.val$fragment:android.support.v4.app.Fragment
        v2 = v6.val$fragment; // android.support.v4.app.FragmentManagerImpl$5.val$fragment:android.support.v4.app.Fragment
        v2 = v2.mStateAfterAnimating; // android.support.v4.app.Fragment.mStateAfterAnimating:int
        v4 = v3;
        v5 = v3;
        _result = v0.moveToState(v0..v5); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    public void onAnimationRepeat(android.view.animation.Animation p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.animation.Animation)
        return;
    }

    public void onAnimationStart(android.view.animation.Animation p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.animation.Animation)
        return;
    }

}