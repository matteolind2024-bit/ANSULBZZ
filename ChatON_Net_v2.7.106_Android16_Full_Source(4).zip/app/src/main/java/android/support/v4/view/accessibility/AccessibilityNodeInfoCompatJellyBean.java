package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityNodeInfoCompatJellyBean.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;
 */
class AccessibilityNodeInfoCompatJellyBean {
    AccessibilityNodeInfoCompatJellyBean() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void addChild(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (int)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.addChild(v1, v2); // android.view.accessibility.AccessibilityNodeInfo.addChild -> void
        return;
    }

    public static java.lang.Object findFocus(java.lang.Object p0, int p1) {
        // Registers (3 total): v1 = p0 (java.lang.Object), v2 = p1 (int)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.findFocus(v2); // android.view.accessibility.AccessibilityNodeInfo.findFocus -> android.view.accessibility.AccessibilityNodeInfo
        v0 = _result;
        return v0;
    }

    public static java.lang.Object focusSearch(java.lang.Object p0, int p1) {
        // Registers (3 total): v1 = p0 (java.lang.Object), v2 = p1 (int)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.focusSearch(v2); // android.view.accessibility.AccessibilityNodeInfo.focusSearch -> android.view.accessibility.AccessibilityNodeInfo
        v0 = _result;
        return v0;
    }

    public static int getMovementGranularities(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getMovementGranularities(); // android.view.accessibility.AccessibilityNodeInfo.getMovementGranularities -> int
        v0 = _result;
        return v0;
    }

    public static boolean isAccessibilityFocused(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isAccessibilityFocused(); // android.view.accessibility.AccessibilityNodeInfo.isAccessibilityFocused -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isVisibleToUser(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isVisibleToUser(); // android.view.accessibility.AccessibilityNodeInfo.isVisibleToUser -> boolean
        v0 = _result;
        return v0;
    }

    public static java.lang.Object obtain(android.view.View p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (int)
        _result = v1.obtain(v2); // android.view.accessibility.AccessibilityNodeInfo.obtain -> android.view.accessibility.AccessibilityNodeInfo
        v0 = _result;
        return v0;
    }

    public static boolean performAction(java.lang.Object p0, int p1, android.os.Bundle p2) {
        // Registers (4 total): v1 = p0 (java.lang.Object), v2 = p1 (int), v3 = p2 (android.os.Bundle)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.performAction(v2, v3); // android.view.accessibility.AccessibilityNodeInfo.performAction -> boolean
        v0 = _result;
        return v0;
    }

    public static void setAccesibilityFocused(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setAccessibilityFocused(v1); // android.view.accessibility.AccessibilityNodeInfo.setAccessibilityFocused -> void
        return;
    }

    public static void setMovementGranularities(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setMovementGranularities(v1); // android.view.accessibility.AccessibilityNodeInfo.setMovementGranularities -> void
        return;
    }

    public static void setParent(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (int)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setParent(v1, v2); // android.view.accessibility.AccessibilityNodeInfo.setParent -> void
        return;
    }

    public static void setSource(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (int)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setSource(v1, v2); // android.view.accessibility.AccessibilityNodeInfo.setSource -> void
        return;
    }

    public static void setVisibleToUser(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setVisibleToUser(v1); // android.view.accessibility.AccessibilityNodeInfo.setVisibleToUser -> void
        return;
    }

}