package android.support.v4.app;

/**
 * Original SourceFile: NavUtils.java
 * Descriptor: Landroid/support/v4/app/NavUtils$NavUtilsImplJB;
 */
class NavUtils$NavUtilsImplJB extends android.support.v4.app.NavUtils$NavUtilsImplBase {
    NavUtils$NavUtilsImplJB() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.app.NavUtils$NavUtilsImplBase.<init> -> void
        return;
    }

    public android.content.Intent getParentActivityIntent(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        _result = v2.getParentActivityIntent(); // android.support.v4.app.NavUtilsJB.getParentActivityIntent -> android.content.Intent
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        _result = v1.getParentActivityIntent(v2); // android.support.v4.app.NavUtils$NavUtilsImplBase.getParentActivityIntent -> android.content.Intent
        v0 = _result;
        return v0;
    }

    public java.lang.String getParentActivityName(android.content.Context p0, android.content.pm.ActivityInfo p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.content.pm.ActivityInfo)
        _result = v3.getParentActivityName(); // android.support.v4.app.NavUtilsJB.getParentActivityName -> java.lang.String
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        _result = v1.getParentActivityName(v2, v3); // android.support.v4.app.NavUtils$NavUtilsImplBase.getParentActivityName -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void navigateUpTo(android.app.Activity p0, android.content.Intent p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.app.Activity), v2 = p1 (android.content.Intent)
        _result = v1.navigateUpTo(v2); // android.support.v4.app.NavUtilsJB.navigateUpTo -> void
        return;
    }

    public boolean shouldUpRecreateTask(android.app.Activity p0, android.content.Intent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.app.Activity), v3 = p1 (android.content.Intent)
        _result = v2.shouldUpRecreateTask(v3); // android.support.v4.app.NavUtilsJB.shouldUpRecreateTask -> boolean
        v0 = _result;
        return v0;
    }

}