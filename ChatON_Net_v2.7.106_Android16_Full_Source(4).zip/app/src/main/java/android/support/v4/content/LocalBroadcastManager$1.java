package android.support.v4.content;

/**
 * Original SourceFile: LocalBroadcastManager.java
 * Descriptor: Landroid/support/v4/content/LocalBroadcastManager$1;
 */
class LocalBroadcastManager$1 extends android.os.Handler {
    final android.support.v4.content.LocalBroadcastManager this$0;

    LocalBroadcastManager$1(android.support.v4.content.LocalBroadcastManager p0, android.os.Looper p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.content.LocalBroadcastManager), v2 = p1 (android.os.Looper)
        v0.this$0 = v1; // android.support.v4.content.LocalBroadcastManager$1.this$0:android.support.v4.content.LocalBroadcastManager
        _result = v0.<init>(v2); // android.os.Handler.<init> -> void
        return;
    }

    public void handleMessage(android.os.Message p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Message)
        v0 = v2.what; // android.os.Message.what:int
        // switch(v0)
        _result = v1.handleMessage(v2); // android.os.Handler.handleMessage -> void
        return;
        v0 = v1.this$0; // android.support.v4.content.LocalBroadcastManager$1.this$0:android.support.v4.content.LocalBroadcastManager
        _result = v0.access$000(); // android.support.v4.content.LocalBroadcastManager.access$000 -> void
        // goto L_0008
    }

}