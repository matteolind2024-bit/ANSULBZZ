package android.support.v4.widget;

/**
 * Original SourceFile: SearchViewCompat.java
 * Descriptor: Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatStubImpl;
 */
class SearchViewCompat$SearchViewCompatStubImpl implements android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl {
    SearchViewCompat$SearchViewCompatStubImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.lang.Object newOnQueryTextListener(android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat)
        v0 = 0;
        return v0;
    }

    public android.view.View newSearchView(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        v0 = 0;
        return v0;
    }

    public void setOnQueryTextListener(java.lang.Object p0, java.lang.Object p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.Object)
        return;
    }

}