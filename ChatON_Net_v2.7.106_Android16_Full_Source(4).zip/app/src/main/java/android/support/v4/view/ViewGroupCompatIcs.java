package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompatIcs.java
 * Descriptor: Landroid/support/v4/view/ViewGroupCompatIcs;
 */
class ViewGroupCompatIcs {
    ViewGroupCompatIcs() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean onRequestSendAccessibilityEvent(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v1 = p0 (android.view.ViewGroup), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        _result = v1.onRequestSendAccessibilityEvent(v2, v3); // android.view.ViewGroup.onRequestSendAccessibilityEvent -> boolean
        v0 = _result;
        return v0;
    }

}