package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/FragmentManagerImpl$2;
 */
class FragmentManagerImpl$2 implements java.lang.Runnable {
    final android.support.v4.app.FragmentManagerImpl this$0;

    FragmentManagerImpl$2(android.support.v4.app.FragmentManagerImpl p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.FragmentManagerImpl)
        v0.this$0 = v1; // android.support.v4.app.FragmentManagerImpl$2.this$0:android.support.v4.app.FragmentManagerImpl
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (6 total): v5 = this
        v0 = v5.this$0; // android.support.v4.app.FragmentManagerImpl$2.this$0:android.support.v4.app.FragmentManagerImpl
        v1 = v5.this$0; // android.support.v4.app.FragmentManagerImpl$2.this$0:android.support.v4.app.FragmentManagerImpl
        v1 = v1.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = v1.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v2 = 0;
        v3 = -1;
        v4 = 0;
        _result = v0.popBackStackState(v1, v2, v3, v4); // android.support.v4.app.FragmentManagerImpl.popBackStackState -> boolean
        return;
    }

}