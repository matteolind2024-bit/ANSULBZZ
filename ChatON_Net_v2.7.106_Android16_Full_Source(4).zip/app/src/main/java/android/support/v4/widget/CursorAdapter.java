package android.support.v4.widget;

/**
 * Original SourceFile: CursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/CursorAdapter;
 */
public abstract class CursorAdapter extends android.widget.BaseAdapter implements android.support.v4.widget.CursorFilter$CursorFilterClient, android.widget.Filterable {
    public static final int FLAG_AUTO_REQUERY;
    public static final int FLAG_REGISTER_CONTENT_OBSERVER;
    protected boolean mAutoRequery;
    protected android.support.v4.widget.CursorAdapter$ChangeObserver mChangeObserver;
    protected android.content.Context mContext;
    protected android.database.Cursor mCursor;
    protected android.support.v4.widget.CursorFilter mCursorFilter;
    protected android.database.DataSetObserver mDataSetObserver;
    protected boolean mDataValid;
    protected android.widget.FilterQueryProvider mFilterQueryProvider;
    protected int mRowIDColumn;

    public CursorAdapter(android.content.Context p0, android.database.Cursor p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.database.Cursor)
        _result = v1.<init>(); // android.widget.BaseAdapter.<init> -> void
        v0 = 1;
        _result = v1.init(v2, v3, v0); // android.support.v4.widget.CursorAdapter.init -> void
        return;
    }

    public CursorAdapter(android.content.Context p0, android.database.Cursor p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.content.Context), v2 = p1 (android.database.Cursor), v3 = p2 (int)
        _result = v0.<init>(); // android.widget.BaseAdapter.<init> -> void
        _result = v0.init(v1, v2, v3); // android.support.v4.widget.CursorAdapter.init -> void
        return;
    }

    public CursorAdapter(android.content.Context p0, android.database.Cursor p1, boolean p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.database.Cursor), v4 = p2 (boolean)
        _result = v1.<init>(); // android.widget.BaseAdapter.<init> -> void
        if (v4 == 0) /* goto L_000a */;
        v0 = 1;
        _result = v1.init(v2, v3, v0); // android.support.v4.widget.CursorAdapter.init -> void
        return;
        v0 = 2;
        // goto L_0006
    }

    public abstract void bindView(android.view.View p0, android.content.Context p1, android.database.Cursor p2);
    public void changeCursor(android.database.Cursor p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.database.Cursor)
        _result = v1.swapCursor(v2); // android.support.v4.widget.CursorAdapter.swapCursor -> android.database.Cursor
        v0 = _result;
        if (v0 == 0) /* goto L_0009 */;
        _result = android.database.Cursor.close(v0); // -> void
        return;
    }

    public java.lang.CharSequence convertToString(android.database.Cursor p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.database.Cursor)
        if (v2 != 0) /* goto L_0005 */;
        v0 = "";
        return v0;
        _result = v2.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        // goto L_0004
    }

    public int getCount() {
        // Registers (2 total): v1 = this
        v0 = v1.mDataValid; // android.support.v4.widget.CursorAdapter.mDataValid:boolean
        if (v0 == 0) /* goto L_000f */;
        v0 = v1.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        if (v0 == 0) /* goto L_000f */;
        v0 = v1.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        _result = android.database.Cursor.getCount(v0); // -> int
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_000e
    }

    public android.database.Cursor getCursor() {
        // Registers (2 total): v1 = this
        v0 = v1.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        return v0;
    }

    public android.view.View getDropDownView(int p0, android.view.View p1, android.view.ViewGroup p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (android.view.View), v5 = p2 (android.view.ViewGroup)
        v0 = v2.mDataValid; // android.support.v4.widget.CursorAdapter.mDataValid:boolean
        if (v0 == 0) /* goto L_001b */;
        v0 = v2.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        _result = android.database.Cursor.moveToPosition(v0, v3); // -> boolean
        if (v4 != 0) /* goto L_0013 */;
        v0 = v2.mContext; // android.support.v4.widget.CursorAdapter.mContext:android.content.Context
        v1 = v2.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        _result = v2.newDropDownView(v0, v1, v5); // android.support.v4.widget.CursorAdapter.newDropDownView -> android.view.View
        v4 = _result;
        v0 = v2.mContext; // android.support.v4.widget.CursorAdapter.mContext:android.content.Context
        v1 = v2.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        _result = v2.bindView(v4, v0, v1); // android.support.v4.widget.CursorAdapter.bindView -> void
        return v4;
        v4 = 0;
        // goto L_001a
    }

    public android.widget.Filter getFilter() {
        // Registers (2 total): v1 = this
        v0 = v1.mCursorFilter; // android.support.v4.widget.CursorAdapter.mCursorFilter:android.support.v4.widget.CursorFilter
        if (v0 != 0) /* goto L_000b */;
        v0 = new android.support.v4.widget.CursorFilter;
        _result = v0.<init>(v1); // android.support.v4.widget.CursorFilter.<init> -> void
        v1.mCursorFilter = v0; // android.support.v4.widget.CursorAdapter.mCursorFilter:android.support.v4.widget.CursorFilter
        v0 = v1.mCursorFilter; // android.support.v4.widget.CursorAdapter.mCursorFilter:android.support.v4.widget.CursorFilter
        return v0;
    }

    public android.widget.FilterQueryProvider getFilterQueryProvider() {
        // Registers (2 total): v1 = this
        v0 = v1.mFilterQueryProvider; // android.support.v4.widget.CursorAdapter.mFilterQueryProvider:android.widget.FilterQueryProvider
        return v0;
    }

    public java.lang.Object getItem(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mDataValid; // android.support.v4.widget.CursorAdapter.mDataValid:boolean
        if (v0 == 0) /* goto L_0010 */;
        v0 = v1.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        if (v0 == 0) /* goto L_0010 */;
        v0 = v1.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        _result = android.database.Cursor.moveToPosition(v0, v2); // -> boolean
        v0 = v1.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        return v0;
        v0 = 0;
        // goto L_000f
    }

    public long getItemId(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = 0L;
        v2 = v3.mDataValid; // android.support.v4.widget.CursorAdapter.mDataValid:boolean
        if (v2 == 0) /* goto L_001a */;
        v2 = v3.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        if (v2 == 0) /* goto L_001a */;
        v2 = v3.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        _result = android.database.Cursor.moveToPosition(v2, v4); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_001a */;
        v0 = v3.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        v1 = v3.mRowIDColumn; // android.support.v4.widget.CursorAdapter.mRowIDColumn:int
        _result = android.database.Cursor.getLong(v0, v1); // -> long
        v0 = _result;
        return v0;
    }

    public android.view.View getView(int p0, android.view.View p1, android.view.ViewGroup p2) {
        // Registers (7 total): v3 = this, v4 = p0 (int), v5 = p1 (android.view.View), v6 = p2 (android.view.ViewGroup)
        v0 = v3.mDataValid; // android.support.v4.widget.CursorAdapter.mDataValid:boolean
        if (v0 != 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "this should only be called when the cursor is valid";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        _result = android.database.Cursor.moveToPosition(v0, v4); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_002d */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "couldn't move cursor to position ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        if (v5 != 0) /* goto L_0037 */;
        v0 = v3.mContext; // android.support.v4.widget.CursorAdapter.mContext:android.content.Context
        v1 = v3.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        _result = v3.newView(v0, v1, v6); // android.support.v4.widget.CursorAdapter.newView -> android.view.View
        v5 = _result;
        v0 = v3.mContext; // android.support.v4.widget.CursorAdapter.mContext:android.content.Context
        v1 = v3.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        _result = v3.bindView(v5, v0, v1); // android.support.v4.widget.CursorAdapter.bindView -> void
        return v5;
    }

    public boolean hasStableIds() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    void init(android.content.Context p0, android.database.Cursor p1, int p2) {
        // Registers (8 total): v4 = this, v5 = p0 (android.content.Context), v6 = p1 (android.database.Cursor), v7 = p2 (int)
        v1 = 0;
        v3 = 0;
        v0 = 1;
        v2 = binOpLit8_0xdd(v7, 1);
        if (v2 != v0) /* goto L_0045 */;
        v7 = binOpLit8_0xde(v7, 2);
        v4.mAutoRequery = v0; // android.support.v4.widget.CursorAdapter.mAutoRequery:boolean
        if (v6 == 0) /* goto L_0048 */;
        v4.mCursor = v6; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        v4.mDataValid = v0; // android.support.v4.widget.CursorAdapter.mDataValid:boolean
        v4.mContext = v5; // android.support.v4.widget.CursorAdapter.mContext:android.content.Context
        if (v0 == 0) /* goto L_004a */;
        v1 = "_id";
        _result = android.database.Cursor.getColumnIndexOrThrow(v6, v1); // -> int
        v1 = _result;
        v4.mRowIDColumn = v1; // android.support.v4.widget.CursorAdapter.mRowIDColumn:int
        v1 = binOpLit8_0xdd(v7, 2);
        v2 = 2;
        if (v1 != v2) /* goto L_004c */;
        v1 = new android.support.v4.widget.CursorAdapter$ChangeObserver;
        _result = v1.<init>(v4); // android.support.v4.widget.CursorAdapter$ChangeObserver.<init> -> void
        v4.mChangeObserver = v1; // android.support.v4.widget.CursorAdapter.mChangeObserver:android.support.v4.widget.CursorAdapter$ChangeObserver
        v1 = new android.support.v4.widget.CursorAdapter$MyDataSetObserver;
        _result = v1.<init>(v4, v3); // android.support.v4.widget.CursorAdapter$MyDataSetObserver.<init> -> void
        v4.mDataSetObserver = v1; // android.support.v4.widget.CursorAdapter.mDataSetObserver:android.database.DataSetObserver
        if (v0 == 0) /* goto L_0044 */;
        v0 = v4.mChangeObserver; // android.support.v4.widget.CursorAdapter.mChangeObserver:android.support.v4.widget.CursorAdapter$ChangeObserver
        if (v0 == 0) /* goto L_003b */;
        v0 = v4.mChangeObserver; // android.support.v4.widget.CursorAdapter.mChangeObserver:android.support.v4.widget.CursorAdapter$ChangeObserver
        _result = android.database.Cursor.registerContentObserver(v6, v0); // -> void
        v0 = v4.mDataSetObserver; // android.support.v4.widget.CursorAdapter.mDataSetObserver:android.database.DataSetObserver
        if (v0 == 0) /* goto L_0044 */;
        v0 = v4.mDataSetObserver; // android.support.v4.widget.CursorAdapter.mDataSetObserver:android.database.DataSetObserver
        _result = android.database.Cursor.registerDataSetObserver(v6, v0); // -> void
        return;
        v4.mAutoRequery = v1; // android.support.v4.widget.CursorAdapter.mAutoRequery:boolean
        // goto L_000b
        v0 = v1;
        // goto L_000d
        v1 = -1;
        // goto L_001b
        v4.mChangeObserver = v3; // android.support.v4.widget.CursorAdapter.mChangeObserver:android.support.v4.widget.CursorAdapter$ChangeObserver
        v4.mDataSetObserver = v3; // android.support.v4.widget.CursorAdapter.mDataSetObserver:android.database.DataSetObserver
        // goto L_0030
    }

    protected void init(android.content.Context p0, android.database.Cursor p1, boolean p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.database.Cursor), v4 = p2 (boolean)
        if (v4 == 0) /* goto L_0007 */;
        v0 = 1;
        _result = v1.init(v2, v3, v0); // android.support.v4.widget.CursorAdapter.init -> void
        return;
        v0 = 2;
        // goto L_0003
    }

    public android.view.View newDropDownView(android.content.Context p0, android.database.Cursor p1, android.view.ViewGroup p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.database.Cursor), v4 = p2 (android.view.ViewGroup)
        _result = v1.newView(v2, v3, v4); // android.support.v4.widget.CursorAdapter.newView -> android.view.View
        v0 = _result;
        return v0;
    }

    public abstract android.view.View newView(android.content.Context p0, android.database.Cursor p1, android.view.ViewGroup p2);
    protected void onContentChanged() {
        // Registers (2 total): v1 = this
        v0 = v1.mAutoRequery; // android.support.v4.widget.CursorAdapter.mAutoRequery:boolean
        if (v0 == 0) /* goto L_0018 */;
        v0 = v1.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        if (v0 == 0) /* goto L_0018 */;
        v0 = v1.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        _result = android.database.Cursor.isClosed(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0018 */;
        v0 = v1.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        _result = android.database.Cursor.requery(v0); // -> boolean
        v0 = _result;
        v1.mDataValid = v0; // android.support.v4.widget.CursorAdapter.mDataValid:boolean
        return;
    }

    public android.database.Cursor runQueryOnBackgroundThread(java.lang.CharSequence p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.CharSequence)
        v0 = v1.mFilterQueryProvider; // android.support.v4.widget.CursorAdapter.mFilterQueryProvider:android.widget.FilterQueryProvider
        if (v0 == 0) /* goto L_000b */;
        v0 = v1.mFilterQueryProvider; // android.support.v4.widget.CursorAdapter.mFilterQueryProvider:android.widget.FilterQueryProvider
        _result = android.widget.FilterQueryProvider.runQuery(v0, v2); // -> android.database.Cursor
        v0 = _result;
        return v0;
        v0 = v1.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        // goto L_000a
    }

    public void setFilterQueryProvider(android.widget.FilterQueryProvider p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.widget.FilterQueryProvider)
        v0.mFilterQueryProvider = v1; // android.support.v4.widget.CursorAdapter.mFilterQueryProvider:android.widget.FilterQueryProvider
        return;
    }

    public android.database.Cursor swapCursor(android.database.Cursor p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.database.Cursor)
        v0 = v2.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        if (v3 != v0) /* goto L_0006 */;
        v0 = 0;
        return v0;
        v0 = v2.mCursor; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        if (v0 == 0) /* goto L_001c */;
        v1 = v2.mChangeObserver; // android.support.v4.widget.CursorAdapter.mChangeObserver:android.support.v4.widget.CursorAdapter$ChangeObserver
        if (v1 == 0) /* goto L_0013 */;
        v1 = v2.mChangeObserver; // android.support.v4.widget.CursorAdapter.mChangeObserver:android.support.v4.widget.CursorAdapter$ChangeObserver
        _result = android.database.Cursor.unregisterContentObserver(v0, v1); // -> void
        v1 = v2.mDataSetObserver; // android.support.v4.widget.CursorAdapter.mDataSetObserver:android.database.DataSetObserver
        if (v1 == 0) /* goto L_001c */;
        v1 = v2.mDataSetObserver; // android.support.v4.widget.CursorAdapter.mDataSetObserver:android.database.DataSetObserver
        _result = android.database.Cursor.unregisterDataSetObserver(v0, v1); // -> void
        v2.mCursor = v3; // android.support.v4.widget.CursorAdapter.mCursor:android.database.Cursor
        if (v3 == 0) /* goto L_0041 */;
        v1 = v2.mChangeObserver; // android.support.v4.widget.CursorAdapter.mChangeObserver:android.support.v4.widget.CursorAdapter$ChangeObserver
        if (v1 == 0) /* goto L_0029 */;
        v1 = v2.mChangeObserver; // android.support.v4.widget.CursorAdapter.mChangeObserver:android.support.v4.widget.CursorAdapter$ChangeObserver
        _result = android.database.Cursor.registerContentObserver(v3, v1); // -> void
        v1 = v2.mDataSetObserver; // android.support.v4.widget.CursorAdapter.mDataSetObserver:android.database.DataSetObserver
        if (v1 == 0) /* goto L_0032 */;
        v1 = v2.mDataSetObserver; // android.support.v4.widget.CursorAdapter.mDataSetObserver:android.database.DataSetObserver
        _result = android.database.Cursor.registerDataSetObserver(v3, v1); // -> void
        v1 = "_id";
        _result = android.database.Cursor.getColumnIndexOrThrow(v3, v1); // -> int
        v1 = _result;
        v2.mRowIDColumn = v1; // android.support.v4.widget.CursorAdapter.mRowIDColumn:int
        v1 = 1;
        v2.mDataValid = v1; // android.support.v4.widget.CursorAdapter.mDataValid:boolean
        _result = v2.notifyDataSetChanged(); // android.support.v4.widget.CursorAdapter.notifyDataSetChanged -> void
        // goto L_0005
        v1 = -1;
        v2.mRowIDColumn = v1; // android.support.v4.widget.CursorAdapter.mRowIDColumn:int
        v1 = 0;
        v2.mDataValid = v1; // android.support.v4.widget.CursorAdapter.mDataValid:boolean
        _result = v2.notifyDataSetInvalidated(); // android.support.v4.widget.CursorAdapter.notifyDataSetInvalidated -> void
        // goto L_0005
    }

}