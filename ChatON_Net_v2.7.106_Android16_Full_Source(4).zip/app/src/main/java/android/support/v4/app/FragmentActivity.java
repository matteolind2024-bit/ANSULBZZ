package android.support.v4.app;

/**
 * Original SourceFile: FragmentActivity.java
 * Descriptor: Landroid/support/v4/app/FragmentActivity;
 */
public class FragmentActivity extends android.app.Activity {
    private static final java.lang.String FRAGMENTS_TAG;
    private static final int HONEYCOMB;
    static final int MSG_REALLY_STOPPED;
    static final int MSG_RESUME_PENDING;
    private static final java.lang.String TAG;
     android.support.v4.util.SparseArrayCompat mAllLoaderManagers;
     boolean mCheckedForLoaderManager;
     boolean mCreated;
    final android.support.v4.app.FragmentManagerImpl mFragments;
    final android.os.Handler mHandler;
     android.support.v4.app.LoaderManagerImpl mLoaderManager;
     boolean mLoadersStarted;
     boolean mOptionsMenuInvalidated;
     boolean mReallyStopped;
     boolean mResumed;
     boolean mRetaining;
     boolean mStopped;

    public FragmentActivity() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // android.app.Activity.<init> -> void
        v0 = new android.support.v4.app.FragmentActivity$1;
        _result = v0.<init>(v1); // android.support.v4.app.FragmentActivity$1.<init> -> void
        v1.mHandler = v0; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v0 = new android.support.v4.app.FragmentManagerImpl;
        _result = v0.<init>(); // android.support.v4.app.FragmentManagerImpl.<init> -> void
        v1.mFragments = v0; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        return;
    }

    void doReallyStop(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v1 = 1;
        v0 = v2.mReallyStopped; // android.support.v4.app.FragmentActivity.mReallyStopped:boolean
        if (v0 != 0) /* goto L_0011 */;
        v2.mReallyStopped = v1; // android.support.v4.app.FragmentActivity.mReallyStopped:boolean
        v2.mRetaining = v3; // android.support.v4.app.FragmentActivity.mRetaining:boolean
        v0 = v2.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        _result = v0.removeMessages(v1); // android.os.Handler.removeMessages -> void
        _result = v2.onReallyStop(); // android.support.v4.app.FragmentActivity.onReallyStop -> void
        return;
    }

    public void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (8 total): v3 = this, v4 = p0 (java.lang.String), v5 = p1 (java.io.FileDescriptor), v6 = p2 (java.io.PrintWriter), v7 = p3 (java.lang.String[])
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_0006 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "Local FragmentActivity ";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        _result = v3.identityHashCode(); // java.lang.System.identityHashCode -> int
        v0 = _result;
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " State:";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "  ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v1 = "mCreated=";
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = v3.mCreated; // android.support.v4.app.FragmentActivity.mCreated:boolean
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = "mResumed=";
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = v3.mResumed; // android.support.v4.app.FragmentActivity.mResumed:boolean
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = " mStopped=";
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = v3.mStopped; // android.support.v4.app.FragmentActivity.mStopped:boolean
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = " mReallyStopped=";
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = v3.mReallyStopped; // android.support.v4.app.FragmentActivity.mReallyStopped:boolean
        _result = v6.println(v1); // java.io.PrintWriter.println -> void
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = "mLoadersStarted=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mLoadersStarted; // android.support.v4.app.FragmentActivity.mLoadersStarted:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_009f */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "Loader Manager ";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.identityHashCode(); // java.lang.System.identityHashCode -> int
        v0 = _result;
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = ":";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "  ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.dump(v1, v5, v6, v7); // android.support.v4.app.LoaderManagerImpl.dump -> void
        v0 = v3.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dump(v4, v5, v6, v7); // android.support.v4.app.FragmentManagerImpl.dump -> void
        return;
    }

    public java.lang.Object getLastCustomNonConfigurationInstance() {
        // Registers (2 total): v1 = this
        _result = v1.getLastNonConfigurationInstance(); // android.support.v4.app.FragmentActivity.getLastNonConfigurationInstance -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.FragmentActivity$NonConfigurationInstances) v0;
        if (v0 == 0) /* goto L_000b */;
        v0 = v0.custom; // android.support.v4.app.FragmentActivity$NonConfigurationInstances.custom:java.lang.Object
        return v0;
        v0 = 0;
        // goto L_000a
    }

    android.support.v4.app.LoaderManagerImpl getLoaderManager(int p0, boolean p1, boolean p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (boolean), v5 = p2 (boolean)
        v0 = v2.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        if (v0 != 0) /* goto L_000b */;
        v0 = new android.support.v4.util.SparseArrayCompat;
        _result = v0.<init>(); // android.support.v4.util.SparseArrayCompat.<init> -> void
        v2.mAllLoaderManagers = v0; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        v0 = v2.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        _result = v0.get(v3); // android.support.v4.util.SparseArrayCompat.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl) v0;
        if (v0 != 0) /* goto L_0022 */;
        if (v5 == 0) /* goto L_0021 */;
        v0 = new android.support.v4.app.LoaderManagerImpl;
        _result = v0.<init>(v2, v4); // android.support.v4.app.LoaderManagerImpl.<init> -> void
        v1 = v2.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        _result = v1.put(v3, v0); // android.support.v4.util.SparseArrayCompat.put -> void
        return v0;
        _result = v0.updateActivity(v2); // android.support.v4.app.LoaderManagerImpl.updateActivity -> void
        // goto L_0021
    }

    public android.support.v4.app.FragmentManager getSupportFragmentManager() {
        // Registers (2 total): v1 = this
        v0 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        return v0;
    }

    public android.support.v4.app.LoaderManager getSupportLoaderManager() {
        // Registers (4 total): v3 = this
        v2 = 1;
        v0 = v3.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_0008 */;
        v0 = v3.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        return v0;
        v3.mCheckedForLoaderManager = v2; // android.support.v4.app.FragmentActivity.mCheckedForLoaderManager:boolean
        v0 = -1;
        v1 = v3.mLoadersStarted; // android.support.v4.app.FragmentActivity.mLoadersStarted:boolean
        _result = v3.getLoaderManager(v0, v1, v2); // android.support.v4.app.FragmentActivity.getLoaderManager -> android.support.v4.app.LoaderManagerImpl
        v0 = _result;
        v3.mLoaderManager = v0; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        v0 = v3.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        // goto L_0007
    }

    void invalidateSupportFragmentIndex(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        if (v0 == 0) /* goto L_001a */;
        v0 = v2.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        _result = v0.get(v3); // android.support.v4.util.SparseArrayCompat.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl) v0;
        if (v0 == 0) /* goto L_001a */;
        v1 = v0.mRetaining; // android.support.v4.app.LoaderManagerImpl.mRetaining:boolean
        if (v1 != 0) /* goto L_001a */;
        _result = v0.doDestroy(); // android.support.v4.app.LoaderManagerImpl.doDestroy -> void
        v0 = v2.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        _result = v0.remove(v3); // android.support.v4.util.SparseArrayCompat.remove -> void
        return;
    }

    protected void onActivityResult(int p0, int p1, android.content.Intent p2) {
        // Registers (7 total): v3 = this, v4 = p0 (int), v5 = p1 (int), v6 = p2 (android.content.Intent)
        v0 = binOpLit8_0xe1(v4, 16);
        if (v0 == 0) /* goto L_0066 */;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v3.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v1 = v1.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        if (v1 == 0) /* goto L_0018 */;
        if (v0 < 0) /* goto L_0018 */;
        v1 = v3.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v1 = v1.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v0 < v1) /* goto L_0035 */;
        v0 = "FragmentActivity";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Activity result fragment index out of range: 0x";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v4.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.w(v1); // android.util.Log.w -> int
        return;
        v1 = v3.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v1 = v1.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v1.get(v0); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 != 0) /* goto L_005e */;
        v0 = "FragmentActivity";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Activity result no fragment exists for index: 0x";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v4.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.w(v1); // android.util.Log.w -> int
        // goto L_0034
        v1 = 65535; // 0x0000ffff
        v1 = binOp2addr_0xb5(v1, v4);
        _result = v0.onActivityResult(v1, v5, v6); // android.support.v4.app.Fragment.onActivityResult -> void
        // goto L_0034
        _result = v3.onActivityResult(v4, v5, v6); // android.app.Activity.onActivityResult -> void
        // goto L_0034
    }

    public void onAttachFragment(android.support.v4.app.Fragment p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.Fragment)
        return;
    }

    public void onBackPressed() {
        // Registers (2 total): v1 = this
        v0 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.popBackStackImmediate(); // android.support.v4.app.FragmentManagerImpl.popBackStackImmediate -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000b */;
        _result = v1.finish(); // android.support.v4.app.FragmentActivity.finish -> void
        return;
    }

    public void onConfigurationChanged(android.content.res.Configuration p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.res.Configuration)
        _result = v1.onConfigurationChanged(v2); // android.app.Activity.onConfigurationChanged -> void
        v0 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchConfigurationChanged(v2); // android.support.v4.app.FragmentManagerImpl.dispatchConfigurationChanged -> void
        return;
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v0 = v3.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.attachActivity(v3); // android.support.v4.app.FragmentManagerImpl.attachActivity -> void
        _result = v3.getLayoutInflater(); // android.support.v4.app.FragmentActivity.getLayoutInflater -> android.view.LayoutInflater
        v0 = _result;
        _result = v0.getFactory(); // android.view.LayoutInflater.getFactory -> android.view.LayoutInflater$Factory
        v0 = _result;
        if (v0 != 0) /* goto L_0016 */;
        _result = v3.getLayoutInflater(); // android.support.v4.app.FragmentActivity.getLayoutInflater -> android.view.LayoutInflater
        v0 = _result;
        _result = v0.setFactory(v3); // android.view.LayoutInflater.setFactory -> void
        _result = v3.onCreate(v4); // android.app.Activity.onCreate -> void
        _result = v3.getLastNonConfigurationInstance(); // android.support.v4.app.FragmentActivity.getLastNonConfigurationInstance -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.FragmentActivity$NonConfigurationInstances) v0;
        if (v0 == 0) /* goto L_0025 */;
        v1 = v0.loaders; // android.support.v4.app.FragmentActivity$NonConfigurationInstances.loaders:android.support.v4.util.SparseArrayCompat
        v3.mAllLoaderManagers = v1; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        if (v4 == 0) /* goto L_0036 */;
        v1 = "android:support:fragments";
        _result = v4.getParcelable(v1); // android.os.Bundle.getParcelable -> android.os.Parcelable
        v1 = _result;
        v2 = v3.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        if (v0 == 0) /* goto L_003c */;
        v0 = v0.fragments; // android.support.v4.app.FragmentActivity$NonConfigurationInstances.fragments:java.util.ArrayList
        _result = v2.restoreAllState(v1, v0); // android.support.v4.app.FragmentManagerImpl.restoreAllState -> void
        v0 = v3.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchCreate(); // android.support.v4.app.FragmentManagerImpl.dispatchCreate -> void
        return;
        v0 = 0;
        // goto L_0033
    }

    public boolean onCreatePanelMenu(int p0, android.view.Menu p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (android.view.Menu)
        if (v4 != 0) /* goto L_001a */;
        _result = v3.onCreatePanelMenu(v4, v5); // android.app.Activity.onCreatePanelMenu -> boolean
        v0 = _result;
        v1 = v3.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v3.getMenuInflater(); // android.support.v4.app.FragmentActivity.getMenuInflater -> android.view.MenuInflater
        v2 = _result;
        _result = v1.dispatchCreateOptionsMenu(v5, v2); // android.support.v4.app.FragmentManagerImpl.dispatchCreateOptionsMenu -> boolean
        v1 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        v1 = android.os.Build$VERSION.SDK_INT; // :int
        v2 = 11;
        if (v1 < v2) /* goto L_0018 */;
        return v0;
        v0 = 1;
        // goto L_0017
        _result = v3.onCreatePanelMenu(v4, v5); // android.app.Activity.onCreatePanelMenu -> boolean
        v0 = _result;
        // goto L_0017
    }

    public android.view.View onCreateView(java.lang.String p0, android.content.Context p1, android.util.AttributeSet p2) {
        // Registers (13 total): v9 = this, v10 = p0 (java.lang.String), v11 = p1 (android.content.Context), v12 = p2 (android.util.AttributeSet)
        v3 = 0;
        v1 = 0;
        v8 = 1;
        v6 = -1;
        v0 = "fragment";
        _result = v0.equals(v10); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0011 */;
        _result = v9.onCreateView(v10, v11, v12); // android.app.Activity.onCreateView -> android.view.View
        v0 = _result;
        return v0;
        v0 = "class";
        _result = android.util.AttributeSet.getAttributeValue(v12, v1, v0); // -> java.lang.String
        v0 = _result;
        v2 = android.support.v4.app.FragmentActivity$FragmentTag.Fragment; // :int[]
        _result = v11.obtainStyledAttributes(v12, v2); // android.content.Context.obtainStyledAttributes -> android.content.res.TypedArray
        v4 = _result;
        if (v0 != 0) /* goto L_0023 */;
        _result = v4.getString(v3); // android.content.res.TypedArray.getString -> java.lang.String
        v0 = _result;
        _result = v4.getResourceId(v8, v6); // android.content.res.TypedArray.getResourceId -> int
        v2 = _result;
        v5 = 2;
        _result = v4.getString(v5); // android.content.res.TypedArray.getString -> java.lang.String
        v5 = _result;
        _result = v4.recycle(); // android.content.res.TypedArray.recycle -> void
        if (v1 == 0) /* goto L_0035 */;
        _result = v1.getId(); // android.view.View.getId -> int
        v3 = _result;
        if (v3 != v6) /* goto L_005c */;
        if (v2 != v6) /* goto L_005c */;
        if (v5 != 0) /* goto L_005c */;
        v1 = new java.lang.IllegalArgumentException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = android.util.AttributeSet.getPositionDescription(v12); // -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": Must specify unique android:id, android:tag, or have a parent with an id for ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v1;
        if (v2 == v6) /* goto L_0064 */;
        v1 = v9.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v1.findFragmentById(v2); // android.support.v4.app.FragmentManagerImpl.findFragmentById -> android.support.v4.app.Fragment
        v1 = _result;
        if (v1 != 0) /* goto L_006e */;
        if (v5 == 0) /* goto L_006e */;
        v1 = v9.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v1.findFragmentByTag(v5); // android.support.v4.app.FragmentManagerImpl.findFragmentByTag -> android.support.v4.app.Fragment
        v1 = _result;
        if (v1 != 0) /* goto L_0078 */;
        if (v3 == v6) /* goto L_0078 */;
        v1 = v9.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v1.findFragmentById(v3); // android.support.v4.app.FragmentManagerImpl.findFragmentById -> android.support.v4.app.Fragment
        v1 = _result;
        v4 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v4 == 0) /* goto L_00ac */;
        v4 = "FragmentActivity";
        v6 = new java.lang.StringBuilder;
        _result = v6.<init>(); // java.lang.StringBuilder.<init> -> void
        v7 = "onCreateView: id=0x";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v2.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v7 = _result;
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v7 = " fname=";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v7 = " existing=";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v6 = _result;
        _result = v4.v(v6); // android.util.Log.v -> int
        if (v1 != 0) /* goto L_00f3 */;
        _result = v9.instantiate(v0); // android.support.v4.app.Fragment.instantiate -> android.support.v4.app.Fragment
        v4 = _result;
        v4.mFromLayout = v8; // android.support.v4.app.Fragment.mFromLayout:boolean
        if (v2 == 0) /* goto L_00f1 */;
        v1 = v2;
        v4.mFragmentId = v1; // android.support.v4.app.Fragment.mFragmentId:int
        v4.mContainerId = v3; // android.support.v4.app.Fragment.mContainerId:int
        v4.mTag = v5; // android.support.v4.app.Fragment.mTag:java.lang.String
        v4.mInLayout = v8; // android.support.v4.app.Fragment.mInLayout:boolean
        v1 = v9.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v4.mFragmentManager = v1; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.FragmentManagerImpl
        v1 = v4.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v4.onInflate(v9, v12, v1); // android.support.v4.app.Fragment.onInflate -> void
        v1 = v9.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v1.addFragment(v4, v8); // android.support.v4.app.FragmentManagerImpl.addFragment -> void
        v1 = v4;
        v3 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v3 != 0) /* goto L_014f */;
        v1 = new java.lang.IllegalStateException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Fragment ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = " did not create a view.";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.IllegalStateException.<init> -> void
        throw v1;
        v1 = v3;
        // goto L_00b7
        v4 = v1.mInLayout; // android.support.v4.app.Fragment.mInLayout:boolean
        if (v4 == 0) /* goto L_013e */;
        v1 = new java.lang.IllegalArgumentException;
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = android.util.AttributeSet.getPositionDescription(v12); // -> java.lang.String
        v6 = _result;
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v6 = ": Duplicate id 0x";
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v2.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v2 = _result;
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v4 = ", tag ";
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v4 = ", or parent id 0x";
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v3.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " with another fragment for ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v1;
        v1.mInLayout = v8; // android.support.v4.app.Fragment.mInLayout:boolean
        v3 = v1.mRetaining; // android.support.v4.app.Fragment.mRetaining:boolean
        if (v3 != 0) /* goto L_0149 */;
        v3 = v1.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v1.onInflate(v9, v12, v3); // android.support.v4.app.Fragment.onInflate -> void
        v3 = v9.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v3.moveToState(v1); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        // goto L_00ce
        if (v2 == 0) /* goto L_0156 */;
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.setId(v2); // android.view.View.setId -> void
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.getTag(); // android.view.View.getTag -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_0163 */;
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.setTag(v5); // android.view.View.setTag -> void
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        // goto L_0010
    }

    protected void onDestroy() {
        // Registers (2 total): v1 = this
        _result = v1.onDestroy(); // android.app.Activity.onDestroy -> void
        v0 = 0;
        _result = v1.doReallyStop(v0); // android.support.v4.app.FragmentActivity.doReallyStop -> void
        v0 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchDestroy(); // android.support.v4.app.FragmentManagerImpl.dispatchDestroy -> void
        v0 = v1.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_0015 */;
        v0 = v1.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.doDestroy(); // android.support.v4.app.LoaderManagerImpl.doDestroy -> void
        return;
    }

    public boolean onKeyDown(int p0, android.view.KeyEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (android.view.KeyEvent)
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 5;
        if (v0 >= v1) /* goto L_0013 */;
        v0 = 4;
        if (v3 != v0) /* goto L_0013 */;
        _result = v4.getRepeatCount(); // android.view.KeyEvent.getRepeatCount -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0013 */;
        _result = v2.onBackPressed(); // android.support.v4.app.FragmentActivity.onBackPressed -> void
        v0 = 1;
        return v0;
        _result = v2.onKeyDown(v3, v4); // android.app.Activity.onKeyDown -> boolean
        v0 = _result;
        // goto L_0012
    }

    public void onLowMemory() {
        // Registers (2 total): v1 = this
        _result = v1.onLowMemory(); // android.app.Activity.onLowMemory -> void
        v0 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchLowMemory(); // android.support.v4.app.FragmentManagerImpl.dispatchLowMemory -> void
        return;
    }

    public boolean onMenuItemSelected(int p0, android.view.MenuItem p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (android.view.MenuItem)
        _result = v1.onMenuItemSelected(v2, v3); // android.app.Activity.onMenuItemSelected -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0008 */;
        v0 = 1;
        return v0;
        // switch(v2)
        v0 = 0;
        // goto L_0007
        v0 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchOptionsItemSelected(v3); // android.support.v4.app.FragmentManagerImpl.dispatchOptionsItemSelected -> boolean
        v0 = _result;
        // goto L_0007
        v0 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchContextItemSelected(v3); // android.support.v4.app.FragmentManagerImpl.dispatchContextItemSelected -> boolean
        v0 = _result;
        // goto L_0007
    }

    public void onPanelClosed(int p0, android.view.Menu p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (android.view.Menu)
        // switch(v2)
        _result = v1.onPanelClosed(v2, v3); // android.app.Activity.onPanelClosed -> void
        return;
        v0 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchOptionsMenuClosed(v3); // android.support.v4.app.FragmentManagerImpl.dispatchOptionsMenuClosed -> void
        // goto L_0003
    }

    protected void onPause() {
        // Registers (3 total): v2 = this
        v1 = 2;
        _result = v2.onPause(); // android.app.Activity.onPause -> void
        v0 = 0;
        v2.mResumed = v0; // android.support.v4.app.FragmentActivity.mResumed:boolean
        v0 = v2.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        _result = v0.hasMessages(v1); // android.os.Handler.hasMessages -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v0 = v2.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        _result = v0.removeMessages(v1); // android.os.Handler.removeMessages -> void
        _result = v2.onResumeFragments(); // android.support.v4.app.FragmentActivity.onResumeFragments -> void
        v0 = v2.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchPause(); // android.support.v4.app.FragmentManagerImpl.dispatchPause -> void
        return;
    }

    protected void onPostResume() {
        // Registers (3 total): v2 = this
        _result = v2.onPostResume(); // android.app.Activity.onPostResume -> void
        v0 = v2.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v1 = 2;
        _result = v0.removeMessages(v1); // android.os.Handler.removeMessages -> void
        _result = v2.onResumeFragments(); // android.support.v4.app.FragmentActivity.onResumeFragments -> void
        v0 = v2.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.execPendingActions(); // android.support.v4.app.FragmentManagerImpl.execPendingActions -> boolean
        return;
    }

    public boolean onPreparePanel(int p0, android.view.View p1, android.view.Menu p2) {
        // Registers (7 total): v3 = this, v4 = p0 (int), v5 = p1 (android.view.View), v6 = p2 (android.view.Menu)
        v0 = 0;
        if (v4 != 0) /* goto L_0026 */;
        if (v6 == 0) /* goto L_0026 */;
        v1 = v3.mOptionsMenuInvalidated; // android.support.v4.app.FragmentActivity.mOptionsMenuInvalidated:boolean
        if (v1 == 0) /* goto L_0011 */;
        v3.mOptionsMenuInvalidated = v0; // android.support.v4.app.FragmentActivity.mOptionsMenuInvalidated:boolean
        _result = android.view.Menu.clear(v6); // -> void
        _result = v3.onCreatePanelMenu(v4, v6); // android.support.v4.app.FragmentActivity.onCreatePanelMenu -> boolean
        _result = v3.onPreparePanel(v4, v5, v6); // android.app.Activity.onPreparePanel -> boolean
        v1 = _result;
        v2 = v3.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v2.dispatchPrepareOptionsMenu(v6); // android.support.v4.app.FragmentManagerImpl.dispatchPrepareOptionsMenu -> boolean
        v2 = _result;
        v1 = binOp2addr_0xb6(v1, v2);
        if (v1 == 0) /* goto L_0025 */;
        _result = android.view.Menu.hasVisibleItems(v6); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0025 */;
        v0 = 1;
        return v0;
        _result = v3.onPreparePanel(v4, v5, v6); // android.app.Activity.onPreparePanel -> boolean
        v0 = _result;
        // goto L_0025
    }

    void onReallyStop() {
        // Registers (2 total): v1 = this
        v0 = v1.mLoadersStarted; // android.support.v4.app.FragmentActivity.mLoadersStarted:boolean
        if (v0 == 0) /* goto L_0014 */;
        v0 = 0;
        v1.mLoadersStarted = v0; // android.support.v4.app.FragmentActivity.mLoadersStarted:boolean
        v0 = v1.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_0014 */;
        v0 = v1.mRetaining; // android.support.v4.app.FragmentActivity.mRetaining:boolean
        if (v0 != 0) /* goto L_001a */;
        v0 = v1.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.doStop(); // android.support.v4.app.LoaderManagerImpl.doStop -> void
        v0 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchReallyStop(); // android.support.v4.app.FragmentManagerImpl.dispatchReallyStop -> void
        return;
        v0 = v1.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.doRetain(); // android.support.v4.app.LoaderManagerImpl.doRetain -> void
        // goto L_0014
    }

    protected void onResume() {
        // Registers (3 total): v2 = this
        _result = v2.onResume(); // android.app.Activity.onResume -> void
        v0 = v2.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v1 = 2;
        _result = v0.sendEmptyMessage(v1); // android.os.Handler.sendEmptyMessage -> boolean
        v0 = 1;
        v2.mResumed = v0; // android.support.v4.app.FragmentActivity.mResumed:boolean
        v0 = v2.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.execPendingActions(); // android.support.v4.app.FragmentManagerImpl.execPendingActions -> boolean
        return;
    }

    protected void onResumeFragments() {
        // Registers (2 total): v1 = this
        v0 = v1.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchResume(); // android.support.v4.app.FragmentManagerImpl.dispatchResume -> void
        return;
    }

    public java.lang.Object onRetainCustomNonConfigurationInstance() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public final java.lang.Object onRetainNonConfigurationInstance() {
        // Registers (9 total): v8 = this
        v1 = 1;
        v3 = 0;
        v0 = v8.mStopped; // android.support.v4.app.FragmentActivity.mStopped:boolean
        if (v0 == 0) /* goto L_0009 */;
        _result = v8.doReallyStop(v1); // android.support.v4.app.FragmentActivity.doReallyStop -> void
        _result = v8.onRetainCustomNonConfigurationInstance(); // android.support.v4.app.FragmentActivity.onRetainCustomNonConfigurationInstance -> java.lang.Object
        v5 = _result;
        v0 = v8.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.retainNonConfig(); // android.support.v4.app.FragmentManagerImpl.retainNonConfig -> java.util.ArrayList
        v6 = _result;
        v2 = 0;
        v0 = v8.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        if (v0 == 0) /* goto L_003f */;
        v0 = v8.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v4 = v0;
        if (v4 < 0) /* goto L_003f */;
        v0 = v8.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v4); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl) v0;
        v7 = v0.mRetaining; // android.support.v4.app.LoaderManagerImpl.mRetaining:boolean
        if (v7 == 0) /* goto L_0035 */;
        v0 = v1;
        v2 = binOpLit8_0xd8(v4, -1);
        v4 = v2;
        v2 = v0;
        // goto L_0021
        _result = v0.doDestroy(); // android.support.v4.app.LoaderManagerImpl.doDestroy -> void
        v0 = v8.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        _result = v0.removeAt(v4); // android.support.v4.util.SparseArrayCompat.removeAt -> void
        v0 = v2;
        // goto L_0030
        if (v6 != 0) /* goto L_0047 */;
        if (v2 != 0) /* goto L_0047 */;
        if (v5 != 0) /* goto L_0047 */;
        v0 = v3;
        return v0;
        v0 = new android.support.v4.app.FragmentActivity$NonConfigurationInstances;
        _result = v0.<init>(); // android.support.v4.app.FragmentActivity$NonConfigurationInstances.<init> -> void
        v0.activity = v3; // android.support.v4.app.FragmentActivity$NonConfigurationInstances.activity:java.lang.Object
        v0.custom = v5; // android.support.v4.app.FragmentActivity$NonConfigurationInstances.custom:java.lang.Object
        v0.children = v3; // android.support.v4.app.FragmentActivity$NonConfigurationInstances.children:java.util.HashMap
        v0.fragments = v6; // android.support.v4.app.FragmentActivity$NonConfigurationInstances.fragments:java.util.ArrayList
        v1 = v8.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        v0.loaders = v1; // android.support.v4.app.FragmentActivity$NonConfigurationInstances.loaders:android.support.v4.util.SparseArrayCompat
        // goto L_0046
    }

    protected void onSaveInstanceState(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onSaveInstanceState(v3); // android.app.Activity.onSaveInstanceState -> void
        v0 = v2.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.saveAllState(); // android.support.v4.app.FragmentManagerImpl.saveAllState -> android.os.Parcelable
        v0 = _result;
        if (v0 == 0) /* goto L_0010 */;
        v1 = "android:support:fragments";
        _result = v3.putParcelable(v1, v0); // android.os.Bundle.putParcelable -> void
        return;
    }

    protected void onStart() {
        // Registers (5 total): v4 = this
        v3 = 0;
        v2 = 1;
        _result = v4.onStart(); // android.app.Activity.onStart -> void
        v4.mStopped = v3; // android.support.v4.app.FragmentActivity.mStopped:boolean
        v4.mReallyStopped = v3; // android.support.v4.app.FragmentActivity.mReallyStopped:boolean
        v0 = v4.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        _result = v0.removeMessages(v2); // android.os.Handler.removeMessages -> void
        v0 = v4.mCreated; // android.support.v4.app.FragmentActivity.mCreated:boolean
        if (v0 != 0) /* goto L_0019 */;
        v4.mCreated = v2; // android.support.v4.app.FragmentActivity.mCreated:boolean
        v0 = v4.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchActivityCreated(); // android.support.v4.app.FragmentManagerImpl.dispatchActivityCreated -> void
        v0 = v4.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.noteStateNotSaved(); // android.support.v4.app.FragmentManagerImpl.noteStateNotSaved -> void
        v0 = v4.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.execPendingActions(); // android.support.v4.app.FragmentManagerImpl.execPendingActions -> boolean
        v0 = v4.mLoadersStarted; // android.support.v4.app.FragmentActivity.mLoadersStarted:boolean
        if (v0 != 0) /* goto L_0034 */;
        v4.mLoadersStarted = v2; // android.support.v4.app.FragmentActivity.mLoadersStarted:boolean
        v0 = v4.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_005a */;
        v0 = v4.mLoaderManager; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.doStart(); // android.support.v4.app.LoaderManagerImpl.doStart -> void
        v4.mCheckedForLoaderManager = v2; // android.support.v4.app.FragmentActivity.mCheckedForLoaderManager:boolean
        v0 = v4.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchStart(); // android.support.v4.app.FragmentManagerImpl.dispatchStart -> void
        v0 = v4.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        if (v0 == 0) /* goto L_0068 */;
        v0 = v4.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0068 */;
        v0 = v4.mAllLoaderManagers; // android.support.v4.app.FragmentActivity.mAllLoaderManagers:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl) v0;
        _result = v0.finishRetain(); // android.support.v4.app.LoaderManagerImpl.finishRetain -> void
        _result = v0.doReportStart(); // android.support.v4.app.LoaderManagerImpl.doReportStart -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0046
        v0 = v4.mCheckedForLoaderManager; // android.support.v4.app.FragmentActivity.mCheckedForLoaderManager:boolean
        if (v0 != 0) /* goto L_0032 */;
        v0 = -1;
        v1 = v4.mLoadersStarted; // android.support.v4.app.FragmentActivity.mLoadersStarted:boolean
        _result = v4.getLoaderManager(v0, v1, v3); // android.support.v4.app.FragmentActivity.getLoaderManager -> android.support.v4.app.LoaderManagerImpl
        v0 = _result;
        v4.mLoaderManager = v0; // android.support.v4.app.FragmentActivity.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        // goto L_0032
        return;
    }

    protected void onStop() {
        // Registers (3 total): v2 = this
        v1 = 1;
        _result = v2.onStop(); // android.app.Activity.onStop -> void
        v2.mStopped = v1; // android.support.v4.app.FragmentActivity.mStopped:boolean
        v0 = v2.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        _result = v0.sendEmptyMessage(v1); // android.os.Handler.sendEmptyMessage -> boolean
        v0 = v2.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.dispatchStop(); // android.support.v4.app.FragmentManagerImpl.dispatchStop -> void
        return;
    }

    public void startActivityForResult(android.content.Intent p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.content.Intent), v4 = p1 (int)
        v0 = -1;
        if (v4 == v0) /* goto L_0010 */;
        v0 = 0xffff0000;
        v0 = binOp2addr_0xb5(v0, v4);
        if (v0 == 0) /* goto L_0010 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Can only use lower 16 bits for requestCode";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = v2.startActivityForResult(v3, v4); // android.app.Activity.startActivityForResult -> void
        return;
    }

    public void startActivityFromFragment(android.support.v4.app.Fragment p0, android.content.Intent p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment), v4 = p1 (android.content.Intent), v5 = p2 (int)
        v0 = -1;
        if (v5 != v0) /* goto L_0007 */;
        _result = v2.startActivityForResult(v4, v0); // android.app.Activity.startActivityForResult -> void
        return;
        v0 = 0xffff0000;
        v0 = binOp2addr_0xb5(v0, v5);
        if (v0 == 0) /* goto L_0014 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Can only use lower 16 bits for requestCode";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v3.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v0 = binOpLit8_0xd8(v0, 1);
        v0 = binOpLit8_0xe0(v0, 16);
        v1 = 65535; // 0x0000ffff
        v1 = binOp2addr_0xb5(v1, v5);
        v0 = binOp2addr_0xb0(v0, v1);
        _result = v2.startActivityForResult(v4, v0); // android.app.Activity.startActivityForResult -> void
        // goto L_0006
    }

    public void supportInvalidateOptionsMenu() {
        // Registers (3 total): v2 = this
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000a */;
        _result = v2.invalidateOptionsMenu(); // android.support.v4.app.ActivityCompatHoneycomb.invalidateOptionsMenu -> void
        return;
        v0 = 1;
        v2.mOptionsMenuInvalidated = v0; // android.support.v4.app.FragmentActivity.mOptionsMenuInvalidated:boolean
        // goto L_0009
    }

}