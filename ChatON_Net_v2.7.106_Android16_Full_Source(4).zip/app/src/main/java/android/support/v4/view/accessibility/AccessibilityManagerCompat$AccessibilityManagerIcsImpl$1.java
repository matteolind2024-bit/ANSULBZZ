package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityManagerCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1;
 */
class AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1 implements android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge {
    final android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerIcsImpl this$0;
    final android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat val$listener;

    AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1(android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerIcsImpl p0, android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerIcsImpl), v2 = p1 (android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat)
        v0.this$0 = v1; // android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1.this$0:android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerIcsImpl
        v0.val$listener = v2; // android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1.val$listener:android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onAccessibilityStateChanged(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.val$listener; // android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1.val$listener:android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat
        _result = v0.onAccessibilityStateChanged(v2); // android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat.onAccessibilityStateChanged -> void
        return;
    }

}