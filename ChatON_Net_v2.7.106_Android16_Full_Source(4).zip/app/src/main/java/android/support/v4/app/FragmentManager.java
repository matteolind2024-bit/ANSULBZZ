package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/FragmentManager;
 */
public abstract class FragmentManager {
    public static final int POP_BACK_STACK_INCLUSIVE;

    public FragmentManager() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void enableDebugLogging(boolean p0) {
        // Registers (1 total): v0 = p0 (boolean)
        android.support.v4.app.FragmentManagerImpl.DEBUG = v0; // :boolean
        return;
    }

    public abstract void addOnBackStackChangedListener(android.support.v4.app.FragmentManager$OnBackStackChangedListener p0);
    public abstract android.support.v4.app.FragmentTransaction beginTransaction();
    public abstract void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3);
    public abstract boolean executePendingTransactions();
    public abstract android.support.v4.app.Fragment findFragmentById(int p0);
    public abstract android.support.v4.app.Fragment findFragmentByTag(java.lang.String p0);
    public abstract android.support.v4.app.FragmentManager$BackStackEntry getBackStackEntryAt(int p0);
    public abstract int getBackStackEntryCount();
    public abstract android.support.v4.app.Fragment getFragment(android.os.Bundle p0, java.lang.String p1);
    public android.support.v4.app.FragmentTransaction openTransaction() {
        // Registers (2 total): v1 = this
        _result = v1.beginTransaction(); // android.support.v4.app.FragmentManager.beginTransaction -> android.support.v4.app.FragmentTransaction
        v0 = _result;
        return v0;
    }

    public abstract void popBackStack();
    public abstract void popBackStack(int p0, int p1);
    public abstract void popBackStack(java.lang.String p0, int p1);
    public abstract boolean popBackStackImmediate();
    public abstract boolean popBackStackImmediate(int p0, int p1);
    public abstract boolean popBackStackImmediate(java.lang.String p0, int p1);
    public abstract void putFragment(android.os.Bundle p0, java.lang.String p1, android.support.v4.app.Fragment p2);
    public abstract void removeOnBackStackChangedListener(android.support.v4.app.FragmentManager$OnBackStackChangedListener p0);
    public abstract android.support.v4.app.Fragment$SavedState saveFragmentInstanceState(android.support.v4.app.Fragment p0);
}