package android.support.v4.util;

/**
 * Original SourceFile: LongSparseArray.java
 * Descriptor: Landroid/support/v4/util/LongSparseArray;
 */
public class LongSparseArray implements java.lang.Cloneable {
    private static final java.lang.Object DELETED;
    private boolean mGarbage;
    private long[] mKeys;
    private int mSize;
    private java.lang.Object[] mValues;

    static {
        v0 = new java.lang.Object;
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        android.support.v4.util.LongSparseArray.DELETED = v0; // :java.lang.Object
        return;
    }

    public LongSparseArray() {
        // Registers (2 total): v1 = this
        v0 = 10;
        _result = v1.<init>(v0); // android.support.v4.util.LongSparseArray.<init> -> void
        return;
    }

    public LongSparseArray(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v2 = 0;
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v3.mGarbage = v2; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        _result = v4.idealLongArraySize(); // android.support.v4.util.LongSparseArray.idealLongArraySize -> int
        v0 = _result;
        v1 = new long[][size=v0];
        v3.mKeys = v1; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v0 = new java.lang.Object[][size=v0];
        v3.mValues = v0; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v3.mSize = v2; // android.support.v4.util.LongSparseArray.mSize:int
        return;
    }

    private static int binarySearch(long[] p0, int p1, int p2, long p3) {
        // Registers (10 total): v5 = p0 (long[]), v6 = p1 (int), v7 = p2 (int), v8 = p3 (long)
        v2 = binOp_0x90(v6, v7);
        v0 = binOpLit8_0xd8(v6, -1);
        v1 = v0;
        v0 = v2;
        v2 = binOp_0x91(v0, v1);
        v3 = 1;
        if (v2 <= v3) /* goto L_0019 */;
        v2 = binOp_0x90(v0, v1);
        v2 = binOpLit8_0xdb(v2, 2);
        v3 = v5[v2];
        v3 = cmp(v3, v8);
        if (v3 >= 0) /* goto L_0017 */;
        v1 = v2;
        // goto L_0006
        v0 = v2;
        // goto L_0006
        v1 = binOp_0x90(v6, v7);
        if (v0 != v1) /* goto L_0022 */;
        v0 = binOp_0x90(v6, v7);
        v0 = binOpLit8_0xdf(v0, -1);
        return v0;
        v1 = v5[v0];
        v1 = cmp(v1, v8);
        if (v1 == 0) /* goto L_0021 */;
        v0 = binOpLit8_0xdf(v0, -1);
        // goto L_0021
    }

    private void gc() {
        // Registers (10 total): v9 = this
        v2 = 0;
        v3 = v9.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v4 = v9.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v5 = v9.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1 = v2;
        v0 = v2;
        if (v1 >= v3) /* goto L_0021 */;
        v6 = v5[v1];
        v7 = android.support.v4.util.LongSparseArray.DELETED; // :java.lang.Object
        if (v6 == v7) /* goto L_001e */;
        if (v1 == v0) /* goto L_001c */;
        v7 = v4[v1];
        v4[v0] = v7;
        v5[v0] = v6;
        v6 = 0;
        v5[v1] = v6;
        v0 = binOpLit8_0xd8(v0, 1);
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0009
        v9.mGarbage = v2; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        v9.mSize = v0; // android.support.v4.util.LongSparseArray.mSize:int
        return;
    }

    public static int idealByteArraySize(int p0) {
        // Registers (4 total): v3 = p0 (int)
        v2 = 1;
        v0 = 4;
        v1 = 32;
        if (v0 >= v1) /* goto L_0010 */;
        v1 = binOp_0x98(v2, v0);
        v1 = binOpLit8_0xd8(v1, -12);
        if (v3 > v1) /* goto L_0011 */;
        v0 = binOp_0x98(v2, v0);
        v3 = binOpLit8_0xd8(v0, -12);
        return v3;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0002
    }

    public static int idealLongArraySize(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = binOpLit8_0xda(v1, 8);
        _result = v0.idealByteArraySize(); // android.support.v4.util.LongSparseArray.idealByteArraySize -> int
        v0 = _result;
        v0 = binOpLit8_0xdb(v0, 8);
        return v0;
    }

    public void append(long p0, java.lang.Object p1) {
        // Registers (10 total): v6 = this, v7 = p0 (long), v9 = p1 (java.lang.Object)
        v5 = 0;
        v0 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        if (v0 == 0) /* goto L_0015 */;
        v0 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v1 = binOpLit8_0xd8(v1, -1);
        v0 = v0[v1];
        v0 = cmp(v7, v0);
        if (v0 > 0) /* goto L_0015 */;
        _result = v6.put(v7, v8, v9); // android.support.v4.util.LongSparseArray.put -> void
        return;
        v0 = v6.mGarbage; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        if (v0 == 0) /* goto L_0023 */;
        v0 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v1 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1 = v1.length;
        if (v0 < v1) /* goto L_0023 */;
        _result = v6.gc(); // android.support.v4.util.LongSparseArray.gc -> void
        v0 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v1 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1 = v1.length;
        if (v0 < v1) /* goto L_0048 */;
        v1 = binOpLit8_0xd8(v0, 1);
        _result = v1.idealLongArraySize(); // android.support.v4.util.LongSparseArray.idealLongArraySize -> int
        v1 = _result;
        v2 = new long[][size=v1];
        v1 = new java.lang.Object[][size=v1];
        v3 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v4 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v4 = v4.length;
        _result = v3.arraycopy(v5, v2, v5, v4); // java.lang.System.arraycopy -> void
        v3 = v6.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v4 = v6.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v4 = v4.length;
        _result = v3.arraycopy(v5, v1, v5, v4); // java.lang.System.arraycopy -> void
        v6.mKeys = v2; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v6.mValues = v1; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1[v0] = v7;
        v1 = v6.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1[v0] = v9;
        v0 = binOpLit8_0xd8(v0, 1);
        v6.mSize = v0; // android.support.v4.util.LongSparseArray.mSize:int
        // goto L_0014
    }

    public void clear() {
        // Registers (6 total): v5 = this
        v1 = 0;
        v2 = v5.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v3 = v5.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v0 = v1;
        if (v0 >= v2) /* goto L_000e */;
        v4 = 0;
        v3[v0] = v4;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0006
        v5.mSize = v1; // android.support.v4.util.LongSparseArray.mSize:int
        v5.mGarbage = v1; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        return;
    }

    public android.support.v4.util.LongSparseArray clone() {
        // Registers (3 total): v2 = this
        v1 = 0;
        _result = v2.clone(); // java.lang.Object.clone -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.util.LongSparseArray) v0;
        v1 = v2.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        _result = v1.clone(); // long[].clone -> java.lang.Object
        v1 = _result;
        v1 = (long[]) v1;
        v0.mKeys = v1; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1 = v2.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        _result = v1.clone(); // java.lang.Object[].clone -> java.lang.Object
        v1 = _result;
        v1 = (java.lang.Object[]) v1;
        v0.mValues = v1; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        return v0;
        v0 = _exception;
        v0 = v1;
        // goto L_001b
        v1 = _exception;
        // goto L_001b
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.clone(); // android.support.v4.util.LongSparseArray.clone -> android.support.v4.util.LongSparseArray
        v0 = _result;
        return v0;
    }

    public void delete(long p0) {
        // Registers (6 total): v3 = this, v4 = p0 (long)
        v0 = v3.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1 = 0;
        v2 = v3.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        _result = v0.binarySearch(v1, v2, v4, v5); // android.support.v4.util.LongSparseArray.binarySearch -> int
        v0 = _result;
        if (v0 < 0) /* goto L_001c */;
        v1 = v3.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1 = v1[v0];
        v2 = android.support.v4.util.LongSparseArray.DELETED; // :java.lang.Object
        if (v1 == v2) /* goto L_001c */;
        v1 = v3.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v2 = android.support.v4.util.LongSparseArray.DELETED; // :java.lang.Object
        v1[v0] = v2;
        v0 = 1;
        v3.mGarbage = v0; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        return;
    }

    public java.lang.Object get(long p0) {
        // Registers (4 total): v1 = this, v2 = p0 (long)
        v0 = 0;
        _result = v1.get(v2, v3, v0); // android.support.v4.util.LongSparseArray.get -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object get(long p0, java.lang.Object p1) {
        // Registers (7 total): v3 = this, v4 = p0 (long), v6 = p1 (java.lang.Object)
        v0 = v3.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1 = 0;
        v2 = v3.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        _result = v0.binarySearch(v1, v2, v4, v5); // android.support.v4.util.LongSparseArray.binarySearch -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0013 */;
        v1 = v3.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1 = v1[v0];
        v2 = android.support.v4.util.LongSparseArray.DELETED; // :java.lang.Object
        if (v1 != v2) /* goto L_0014 */;
        return v6;
        v1 = v3.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v6 = v1[v0];
        // goto L_0013
    }

    public int indexOfKey(long p0) {
        // Registers (6 total): v3 = this, v4 = p0 (long)
        v0 = v3.mGarbage; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v3.gc(); // android.support.v4.util.LongSparseArray.gc -> void
        v0 = v3.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1 = 0;
        v2 = v3.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        _result = v0.binarySearch(v1, v2, v4, v5); // android.support.v4.util.LongSparseArray.binarySearch -> int
        v0 = _result;
        return v0;
    }

    public int indexOfValue(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v0 = v2.mGarbage; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v2.gc(); // android.support.v4.util.LongSparseArray.gc -> void
        v0 = 0;
        v1 = v2.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        if (v0 >= v1) /* goto L_0016 */;
        v1 = v2.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1 = v1[v0];
        if (v1 != v3) /* goto L_0013 */;
        return v0;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0008
        v0 = -1;
        // goto L_0012
    }

    public long keyAt(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.mGarbage; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v2.gc(); // android.support.v4.util.LongSparseArray.gc -> void
        v0 = v2.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v0 = v0[v3];
        return v0;
    }

    public void put(long p0, java.lang.Object p1) {
        // Registers (10 total): v6 = this, v7 = p0 (long), v9 = p1 (java.lang.Object)
        v5 = 0;
        v0 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        _result = v0.binarySearch(v5, v1, v7, v8); // android.support.v4.util.LongSparseArray.binarySearch -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0010 */;
        v1 = v6.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1[v0] = v9;
        return;
        v0 = binOpLit8_0xdf(v0, -1);
        v1 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        if (v0 >= v1) /* goto L_0027 */;
        v1 = v6.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1 = v1[v0];
        v2 = android.support.v4.util.LongSparseArray.DELETED; // :java.lang.Object
        if (v1 != v2) /* goto L_0027 */;
        v1 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1[v0] = v7;
        v1 = v6.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1[v0] = v9;
        // goto L_000f
        v1 = v6.mGarbage; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        if (v1 == 0) /* goto L_003f */;
        v1 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v2 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v2 = v2.length;
        if (v1 < v2) /* goto L_003f */;
        _result = v6.gc(); // android.support.v4.util.LongSparseArray.gc -> void
        v0 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        _result = v0.binarySearch(v5, v1, v7, v8); // android.support.v4.util.LongSparseArray.binarySearch -> int
        v0 = _result;
        v0 = binOpLit8_0xdf(v0, -1);
        v1 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v2 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v2 = v2.length;
        if (v1 < v2) /* goto L_0066 */;
        v1 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v1.idealLongArraySize(); // android.support.v4.util.LongSparseArray.idealLongArraySize -> int
        v1 = _result;
        v2 = new long[][size=v1];
        v1 = new java.lang.Object[][size=v1];
        v3 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v4 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v4 = v4.length;
        _result = v3.arraycopy(v5, v2, v5, v4); // java.lang.System.arraycopy -> void
        v3 = v6.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v4 = v6.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v4 = v4.length;
        _result = v3.arraycopy(v5, v1, v5, v4); // java.lang.System.arraycopy -> void
        v6.mKeys = v2; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v6.mValues = v1; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v1 = binOp2addr_0xb1(v1, v0);
        if (v1 == 0) /* goto L_0083 */;
        v1 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v2 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v3 = binOpLit8_0xd8(v0, 1);
        v4 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v4 = binOp2addr_0xb1(v4, v0);
        _result = v1.arraycopy(v0, v2, v3, v4); // java.lang.System.arraycopy -> void
        v1 = v6.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v2 = v6.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v3 = binOpLit8_0xd8(v0, 1);
        v4 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v4 = binOp2addr_0xb1(v4, v0);
        _result = v1.arraycopy(v0, v2, v3, v4); // java.lang.System.arraycopy -> void
        v1 = v6.mKeys; // android.support.v4.util.LongSparseArray.mKeys:long[]
        v1[v0] = v7;
        v1 = v6.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1[v0] = v9;
        v0 = v6.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        v0 = binOpLit8_0xd8(v0, 1);
        v6.mSize = v0; // android.support.v4.util.LongSparseArray.mSize:int
        // goto L_000f
    }

    public void remove(long p0) {
        // Registers (3 total): v0 = this, v1 = p0 (long)
        _result = v0.delete(v1, v2); // android.support.v4.util.LongSparseArray.delete -> void
        return;
    }

    public void removeAt(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v0 = v0[v3];
        v1 = android.support.v4.util.LongSparseArray.DELETED; // :java.lang.Object
        if (v0 == v1) /* goto L_0011 */;
        v0 = v2.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v1 = android.support.v4.util.LongSparseArray.DELETED; // :java.lang.Object
        v0[v3] = v1;
        v0 = 1;
        v2.mGarbage = v0; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        return;
    }

    public void setValueAt(int p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (java.lang.Object)
        v0 = v1.mGarbage; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v1.gc(); // android.support.v4.util.LongSparseArray.gc -> void
        v0 = v1.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v0[v2] = v3;
        return;
    }

    public int size() {
        // Registers (2 total): v1 = this
        v0 = v1.mGarbage; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v1.gc(); // android.support.v4.util.LongSparseArray.gc -> void
        v0 = v1.mSize; // android.support.v4.util.LongSparseArray.mSize:int
        return v0;
    }

    public java.lang.Object valueAt(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mGarbage; // android.support.v4.util.LongSparseArray.mGarbage:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v1.gc(); // android.support.v4.util.LongSparseArray.gc -> void
        v0 = v1.mValues; // android.support.v4.util.LongSparseArray.mValues:java.lang.Object[]
        v0 = v0[v2];
        return v0;
    }

}