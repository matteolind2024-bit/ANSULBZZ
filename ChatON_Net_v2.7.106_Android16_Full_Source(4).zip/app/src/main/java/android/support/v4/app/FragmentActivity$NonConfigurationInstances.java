package android.support.v4.app;

/**
 * Original SourceFile: FragmentActivity.java
 * Descriptor: Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;
 */
final class FragmentActivity$NonConfigurationInstances {
     java.lang.Object activity;
     java.util.HashMap children;
     java.lang.Object custom;
     java.util.ArrayList fragments;
     android.support.v4.util.SparseArrayCompat loaders;

    FragmentActivity$NonConfigurationInstances() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}