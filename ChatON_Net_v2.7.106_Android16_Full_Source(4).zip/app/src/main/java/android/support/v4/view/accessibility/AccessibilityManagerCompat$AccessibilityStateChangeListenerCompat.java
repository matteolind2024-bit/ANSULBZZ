package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityManagerCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;
 */
public abstract class AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat {
    final java.lang.Object mListener;

    public AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        _result = this.access$000(); // android.support.v4.view.accessibility.AccessibilityManagerCompat.access$000 -> android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl
        v0 = _result;
        _result = android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl.newAccessiblityStateChangeListener(v0, v1); // -> java.lang.Object
        v0 = _result;
        v1.mListener = v0; // android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat.mListener:java.lang.Object
        return;
    }

    public abstract void onAccessibilityStateChanged(boolean p0);
}