package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$1;
 */
final class ViewPager$1 implements java.util.Comparator {
    ViewPager$1() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int compare(android.support.v4.view.ViewPager$ItemInfo p0, android.support.v4.view.ViewPager$ItemInfo p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.support.v4.view.ViewPager$ItemInfo), v4 = p1 (android.support.v4.view.ViewPager$ItemInfo)
        v0 = v3.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v1 = v4.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v0 = binOp2addr_0xb1(v0, v1);
        return v0;
    }

    public int compare(java.lang.Object p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (java.lang.Object)
        v2 = (android.support.v4.view.ViewPager$ItemInfo) v2;
        v3 = (android.support.v4.view.ViewPager$ItemInfo) v3;
        _result = v1.compare(v2, v3); // android.support.v4.view.ViewPager$1.compare -> int
        v0 = _result;
        return v0;
    }

}