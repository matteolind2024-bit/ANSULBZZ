package android.support.v4.accessibilityservice;

/**
 * Original SourceFile: AccessibilityServiceInfoCompat.java
 * Descriptor: Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl;
 */
class AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl implements android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl {
    AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean getCanRetrieveWindowContent(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        v0 = 0;
        return v0;
    }

    public java.lang.String getDescription(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        v0 = 0;
        return v0;
    }

    public java.lang.String getId(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        v0 = 0;
        return v0;
    }

    public android.content.pm.ResolveInfo getResolveInfo(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        v0 = 0;
        return v0;
    }

    public java.lang.String getSettingsActivityName(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        v0 = 0;
        return v0;
    }

}