package android.support.v4.content;

/**
 * Original SourceFile: LocalBroadcastManager.java
 * Descriptor: Landroid/support/v4/content/LocalBroadcastManager$BroadcastRecord;
 */
class LocalBroadcastManager$BroadcastRecord {
    final android.content.Intent intent;
    final java.util.ArrayList receivers;

    LocalBroadcastManager$BroadcastRecord(android.content.Intent p0, java.util.ArrayList p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.content.Intent), v2 = p1 (java.util.ArrayList)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.intent = v1; // android.support.v4.content.LocalBroadcastManager$BroadcastRecord.intent:android.content.Intent
        v0.receivers = v2; // android.support.v4.content.LocalBroadcastManager$BroadcastRecord.receivers:java.util.ArrayList
        return;
    }

}