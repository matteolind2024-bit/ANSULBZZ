package android.support.v4.content.pm;

/**
 * Original SourceFile: ActivityInfoCompat.java
 * Descriptor: Landroid/support/v4/content/pm/ActivityInfoCompat;
 */
public class ActivityInfoCompat {
    public static final int CONFIG_UI_MODE;

    private ActivityInfoCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}