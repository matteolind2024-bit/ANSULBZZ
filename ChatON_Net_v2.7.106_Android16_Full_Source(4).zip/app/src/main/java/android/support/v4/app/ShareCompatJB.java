package android.support.v4.app;

/**
 * Original SourceFile: ShareCompatJB.java
 * Descriptor: Landroid/support/v4/app/ShareCompatJB;
 */
class ShareCompatJB {
    ShareCompatJB() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static java.lang.String escapeHtml(java.lang.CharSequence p0) {
        // Registers (2 total): v1 = p0 (java.lang.CharSequence)
        _result = v1.escapeHtml(); // android.text.Html.escapeHtml -> java.lang.String
        v0 = _result;
        return v0;
    }

}