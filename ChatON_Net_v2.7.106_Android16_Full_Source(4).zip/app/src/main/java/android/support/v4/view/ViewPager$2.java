package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$2;
 */
final class ViewPager$2 implements android.view.animation.Interpolator {
    ViewPager$2() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public float getInterpolation(float p0) {
        // Registers (5 total): v3 = this, v4 = p0 (float)
        v2 = 0x3f800000;
        v0 = binOp_0xa7(v4, v2);
        v1 = binOp_0xa8(v0, v0);
        v1 = binOp2addr_0xc8(v1, v0);
        v1 = binOp2addr_0xc8(v1, v0);
        v0 = binOp2addr_0xc8(v0, v1);
        v0 = binOp2addr_0xc6(v0, v2);
        return v0;
    }

}