package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityEventCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventIcsImpl;
 */
class AccessibilityEventCompat$AccessibilityEventIcsImpl extends android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventStubImpl {
    AccessibilityEventCompat$AccessibilityEventIcsImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventStubImpl.<init> -> void
        return;
    }

    public void appendRecord(android.view.accessibility.AccessibilityEvent p0, java.lang.Object p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.accessibility.AccessibilityEvent), v2 = p1 (java.lang.Object)
        _result = v1.appendRecord(v2); // android.support.v4.view.accessibility.AccessibilityEventCompatIcs.appendRecord -> void
        return;
    }

    public java.lang.Object getRecord(android.view.accessibility.AccessibilityEvent p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityEvent), v3 = p1 (int)
        _result = v2.getRecord(v3); // android.support.v4.view.accessibility.AccessibilityEventCompatIcs.getRecord -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public int getRecordCount(android.view.accessibility.AccessibilityEvent p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityEvent)
        _result = v2.getRecordCount(); // android.support.v4.view.accessibility.AccessibilityEventCompatIcs.getRecordCount -> int
        v0 = _result;
        return v0;
    }

}