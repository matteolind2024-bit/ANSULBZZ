package android.support.v4.app;

/**
 * Original SourceFile: FragmentPagerAdapter.java
 * Descriptor: Landroid/support/v4/app/FragmentPagerAdapter;
 */
public abstract class FragmentPagerAdapter extends android.support.v4.view.PagerAdapter {
    private static final boolean DEBUG;
    private static final java.lang.String TAG;
    private android.support.v4.app.FragmentTransaction mCurTransaction;
    private android.support.v4.app.Fragment mCurrentPrimaryItem;
    private final android.support.v4.app.FragmentManager mFragmentManager;

    public FragmentPagerAdapter(android.support.v4.app.FragmentManager p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.FragmentManager)
        v0 = 0;
        _result = v1.<init>(); // android.support.v4.view.PagerAdapter.<init> -> void
        v1.mCurTransaction = v0; // android.support.v4.app.FragmentPagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        v1.mCurrentPrimaryItem = v0; // android.support.v4.app.FragmentPagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        v1.mFragmentManager = v2; // android.support.v4.app.FragmentPagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        return;
    }

    private static java.lang.String makeFragmentName(int p0, long p1) {
        // Registers (5 total): v2 = p0 (int), v3 = p1 (long)
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "android:switcher:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ":";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3, v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void destroyItem(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (int), v4 = p2 (java.lang.Object)
        v0 = v1.mCurTransaction; // android.support.v4.app.FragmentPagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        if (v0 != 0) /* goto L_000c */;
        v0 = v1.mFragmentManager; // android.support.v4.app.FragmentPagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        _result = v0.beginTransaction(); // android.support.v4.app.FragmentManager.beginTransaction -> android.support.v4.app.FragmentTransaction
        v0 = _result;
        v1.mCurTransaction = v0; // android.support.v4.app.FragmentPagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        v0 = v1.mCurTransaction; // android.support.v4.app.FragmentPagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        v4 = (android.support.v4.app.Fragment) v4;
        _result = v0.detach(v4); // android.support.v4.app.FragmentTransaction.detach -> android.support.v4.app.FragmentTransaction
        return;
    }

    public void finishUpdate(android.view.ViewGroup p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup)
        v0 = v1.mCurTransaction; // android.support.v4.app.FragmentPagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        if (v0 == 0) /* goto L_0011 */;
        v0 = v1.mCurTransaction; // android.support.v4.app.FragmentPagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        _result = v0.commitAllowingStateLoss(); // android.support.v4.app.FragmentTransaction.commitAllowingStateLoss -> int
        v0 = 0;
        v1.mCurTransaction = v0; // android.support.v4.app.FragmentPagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        v0 = v1.mFragmentManager; // android.support.v4.app.FragmentPagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        _result = v0.executePendingTransactions(); // android.support.v4.app.FragmentManager.executePendingTransactions -> boolean
        return;
    }

    public abstract android.support.v4.app.Fragment getItem(int p0);
    public long getItemId(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = unaryOp_0x81(v3);
        return v0;
    }

    public java.lang.Object instantiateItem(android.view.ViewGroup p0, int p1) {
        // Registers (10 total): v7 = this, v8 = p0 (android.view.ViewGroup), v9 = p1 (int)
        v6 = 0;
        v0 = v7.mCurTransaction; // android.support.v4.app.FragmentPagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        if (v0 != 0) /* goto L_000d */;
        v0 = v7.mFragmentManager; // android.support.v4.app.FragmentPagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        _result = v0.beginTransaction(); // android.support.v4.app.FragmentManager.beginTransaction -> android.support.v4.app.FragmentTransaction
        v0 = _result;
        v7.mCurTransaction = v0; // android.support.v4.app.FragmentPagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        _result = v7.getItemId(v9); // android.support.v4.app.FragmentPagerAdapter.getItemId -> long
        v1 = _result;
        _result = v8.getId(); // android.view.ViewGroup.getId -> int
        v0 = _result;
        _result = v0.makeFragmentName(v1, v2); // android.support.v4.app.FragmentPagerAdapter.makeFragmentName -> java.lang.String
        v0 = _result;
        v3 = v7.mFragmentManager; // android.support.v4.app.FragmentPagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        _result = v3.findFragmentByTag(v0); // android.support.v4.app.FragmentManager.findFragmentByTag -> android.support.v4.app.Fragment
        v0 = _result;
        if (v0 == 0) /* goto L_0031 */;
        v1 = v7.mCurTransaction; // android.support.v4.app.FragmentPagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        _result = v1.attach(v0); // android.support.v4.app.FragmentTransaction.attach -> android.support.v4.app.FragmentTransaction
        v1 = v7.mCurrentPrimaryItem; // android.support.v4.app.FragmentPagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        if (v0 == v1) /* goto L_0030 */;
        _result = v0.setMenuVisibility(v6); // android.support.v4.app.Fragment.setMenuVisibility -> void
        _result = v0.setUserVisibleHint(v6); // android.support.v4.app.Fragment.setUserVisibleHint -> void
        return v0;
        _result = v7.getItem(v9); // android.support.v4.app.FragmentPagerAdapter.getItem -> android.support.v4.app.Fragment
        v0 = _result;
        v3 = v7.mCurTransaction; // android.support.v4.app.FragmentPagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        _result = v8.getId(); // android.view.ViewGroup.getId -> int
        v4 = _result;
        _result = v8.getId(); // android.view.ViewGroup.getId -> int
        v5 = _result;
        _result = v5.makeFragmentName(v1, v2); // android.support.v4.app.FragmentPagerAdapter.makeFragmentName -> java.lang.String
        v1 = _result;
        _result = v3.add(v4, v0, v1); // android.support.v4.app.FragmentTransaction.add -> android.support.v4.app.FragmentTransaction
        // goto L_0026
    }

    public boolean isViewFromObject(android.view.View p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (java.lang.Object)
        v3 = (android.support.v4.app.Fragment) v3;
        _result = v3.getView(); // android.support.v4.app.Fragment.getView -> android.view.View
        v0 = _result;
        if (v0 != v2) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public void restoreState(android.os.Parcelable p0, java.lang.ClassLoader p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.os.Parcelable), v2 = p1 (java.lang.ClassLoader)
        return;
    }

    public android.os.Parcelable saveState() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public void setPrimaryItem(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.view.ViewGroup), v5 = p1 (int), v6 = p2 (java.lang.Object)
        v2 = 1;
        v1 = 0;
        v6 = (android.support.v4.app.Fragment) v6;
        v0 = v3.mCurrentPrimaryItem; // android.support.v4.app.FragmentPagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        if (v6 == v0) /* goto L_0020 */;
        v0 = v3.mCurrentPrimaryItem; // android.support.v4.app.FragmentPagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0016 */;
        v0 = v3.mCurrentPrimaryItem; // android.support.v4.app.FragmentPagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        _result = v0.setMenuVisibility(v1); // android.support.v4.app.Fragment.setMenuVisibility -> void
        v0 = v3.mCurrentPrimaryItem; // android.support.v4.app.FragmentPagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        _result = v0.setUserVisibleHint(v1); // android.support.v4.app.Fragment.setUserVisibleHint -> void
        if (v6 == 0) /* goto L_001e */;
        _result = v6.setMenuVisibility(v2); // android.support.v4.app.Fragment.setMenuVisibility -> void
        _result = v6.setUserVisibleHint(v2); // android.support.v4.app.Fragment.setUserVisibleHint -> void
        v3.mCurrentPrimaryItem = v6; // android.support.v4.app.FragmentPagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        return;
    }

    public void startUpdate(android.view.ViewGroup p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.ViewGroup)
        return;
    }

}