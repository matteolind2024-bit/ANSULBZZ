package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/ViewCompat;
 */
public class ViewCompat {
    private static final long FAKE_FRAME_TIME;
    static final android.support.v4.view.ViewCompat$ViewCompatImpl IMPL;
    public static final int IMPORTANT_FOR_ACCESSIBILITY_AUTO;
    public static final int IMPORTANT_FOR_ACCESSIBILITY_NO;
    public static final int IMPORTANT_FOR_ACCESSIBILITY_YES;
    public static final int OVER_SCROLL_ALWAYS;
    public static final int OVER_SCROLL_IF_CONTENT_SCROLLS;
    public static final int OVER_SCROLL_NEVER;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 >= v1) /* goto L_0010 */;
        v1 = android.os.Build$VERSION.CODENAME; // :java.lang.String
        v2 = "JellyBean";
        _result = v1.equals(v2); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0018 */;
        v0 = new android.support.v4.view.ViewCompat$JBViewCompatImpl;
        _result = v0.<init>(); // android.support.v4.view.ViewCompat$JBViewCompatImpl.<init> -> void
        android.support.v4.view.ViewCompat.IMPL = v0; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        return;
        v1 = 14;
        if (v0 < v1) /* goto L_0024 */;
        v0 = new android.support.v4.view.ViewCompat$ICSViewCompatImpl;
        _result = v0.<init>(); // android.support.v4.view.ViewCompat$ICSViewCompatImpl.<init> -> void
        android.support.v4.view.ViewCompat.IMPL = v0; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        // goto L_0017
        v1 = 11;
        if (v0 < v1) /* goto L_0030 */;
        v0 = new android.support.v4.view.ViewCompat$HCViewCompatImpl;
        _result = v0.<init>(); // android.support.v4.view.ViewCompat$HCViewCompatImpl.<init> -> void
        android.support.v4.view.ViewCompat.IMPL = v0; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        // goto L_0017
        v1 = 9;
        if (v0 < v1) /* goto L_003c */;
        v0 = new android.support.v4.view.ViewCompat$GBViewCompatImpl;
        _result = v0.<init>(); // android.support.v4.view.ViewCompat$GBViewCompatImpl.<init> -> void
        android.support.v4.view.ViewCompat.IMPL = v0; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        // goto L_0017
        v0 = new android.support.v4.view.ViewCompat$BaseViewCompatImpl;
        _result = v0.<init>(); // android.support.v4.view.ViewCompat$BaseViewCompatImpl.<init> -> void
        android.support.v4.view.ViewCompat.IMPL = v0; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        // goto L_0017
    }

    public ViewCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean canScrollHorizontally(android.view.View p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (int)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.canScrollHorizontally(v0, v1, v2); // -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean canScrollVertically(android.view.View p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (int)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.canScrollVertically(v0, v1, v2); // -> boolean
        v0 = _result;
        return v0;
    }

    public static android.support.v4.view.accessibility.AccessibilityNodeProviderCompat getAccessibilityNodeProvider(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.getAccessibilityNodeProvider(v0, v1); // -> android.support.v4.view.accessibility.AccessibilityNodeProviderCompat
        v0 = _result;
        return v0;
    }

    public static int getImportantForAccessibility(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.getImportantForAccessibility(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public static int getOverScrollMode(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.getOverScrollMode(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public static boolean hasTransientState(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.hasTransientState(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public static void onInitializeAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.onInitializeAccessibilityEvent(v0, v1, v2); // -> void
        return;
    }

    public static void onInitializeAccessibilityNodeInfo(android.view.View p0, android.support.v4.view.accessibility.AccessibilityNodeInfoCompat p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (android.support.v4.view.accessibility.AccessibilityNodeInfoCompat)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.onInitializeAccessibilityNodeInfo(v0, v1, v2); // -> void
        return;
    }

    public static void onPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.onPopulateAccessibilityEvent(v0, v1, v2); // -> void
        return;
    }

    public static void postInvalidateOnAnimation(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.postInvalidateOnAnimation(v0, v1); // -> void
        return;
    }

    public static void postInvalidateOnAnimation(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (11 total): v6 = p0 (android.view.View), v7 = p1 (int), v8 = p2 (int), v9 = p3 (int), v10 = p4 (int)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        v1 = v6;
        v2 = v7;
        v3 = v8;
        v4 = v9;
        v5 = v10;
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.postInvalidateOnAnimation(v0..v5); // -> void
        return;
    }

    public static void postOnAnimation(android.view.View p0, java.lang.Runnable p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (java.lang.Runnable)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.postOnAnimation(v0, v1, v2); // -> void
        return;
    }

    public static void postOnAnimationDelayed(android.view.View p0, java.lang.Runnable p1, long p2) {
        // Registers (5 total): v1 = p0 (android.view.View), v2 = p1 (java.lang.Runnable), v3 = p2 (long)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.postOnAnimationDelayed(v0, v1, v2, v3, v4); // -> void
        return;
    }

    public static void setAccessibilityDelegate(android.view.View p0, android.support.v4.view.AccessibilityDelegateCompat p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (android.support.v4.view.AccessibilityDelegateCompat)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.setAccessibilityDelegate(v0, v1, v2); // -> void
        return;
    }

    public static void setHasTransientState(android.view.View p0, boolean p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (boolean)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.setHasTransientState(v0, v1, v2); // -> void
        return;
    }

    public static void setImportantForAccessibility(android.view.View p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (int)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.setImportantForAccessibility(v0, v1, v2); // -> void
        return;
    }

    public static void setOverScrollMode(android.view.View p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (int)
        v0 = android.support.v4.view.ViewCompat.IMPL; // :android.support.v4.view.ViewCompat$ViewCompatImpl
        _result = android.support.v4.view.ViewCompat$ViewCompatImpl.setOverScrollMode(v0, v1, v2); // -> void
        return;
    }

}