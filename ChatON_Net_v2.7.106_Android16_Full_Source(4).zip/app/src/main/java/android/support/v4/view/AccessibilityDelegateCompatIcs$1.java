package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompatIcs.java
 * Descriptor: Landroid/support/v4/view/AccessibilityDelegateCompatIcs$1;
 */
final class AccessibilityDelegateCompatIcs$1 extends android.view.View$AccessibilityDelegate {
    final android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge val$bridge;

    AccessibilityDelegateCompatIcs$1(android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge)
        v0.val$bridge = v1; // android.support.v4.view.AccessibilityDelegateCompatIcs$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge
        _result = v0.<init>(); // android.view.View$AccessibilityDelegate.<init> -> void
        return;
    }

    public boolean dispatchPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatIcs$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge
        _result = android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge.dispatchPopulateAccessibilityEvent(v0, v2, v3); // -> boolean
        v0 = _result;
        return v0;
    }

    public void onInitializeAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatIcs$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge
        _result = android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge.onInitializeAccessibilityEvent(v0, v2, v3); // -> void
        return;
    }

    public void onInitializeAccessibilityNodeInfo(android.view.View p0, android.view.accessibility.AccessibilityNodeInfo p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityNodeInfo)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatIcs$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge
        _result = android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge.onInitializeAccessibilityNodeInfo(v0, v2, v3); // -> void
        return;
    }

    public void onPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatIcs$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge
        _result = android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge.onPopulateAccessibilityEvent(v0, v2, v3); // -> void
        return;
    }

    public boolean onRequestSendAccessibilityEvent(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (android.view.View), v4 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatIcs$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge
        _result = android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge.onRequestSendAccessibilityEvent(v0, v2, v3, v4); // -> boolean
        v0 = _result;
        return v0;
    }

    public void sendAccessibilityEvent(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatIcs$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge
        _result = android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge.sendAccessibilityEvent(v0, v2, v3); // -> void
        return;
    }

    public void sendAccessibilityEventUnchecked(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$bridge; // android.support.v4.view.AccessibilityDelegateCompatIcs$1.val$bridge:android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge
        _result = android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge.sendAccessibilityEventUnchecked(v0, v2, v3); // -> void
        return;
    }

}