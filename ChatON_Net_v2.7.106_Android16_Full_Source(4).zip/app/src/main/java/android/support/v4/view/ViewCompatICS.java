package android.support.v4.view;

/**
 * Original SourceFile: ViewCompatICS.java
 * Descriptor: Landroid/support/v4/view/ViewCompatICS;
 */
class ViewCompatICS {
    ViewCompatICS() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean canScrollHorizontally(android.view.View p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (int)
        _result = v1.canScrollHorizontally(v2); // android.view.View.canScrollHorizontally -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean canScrollVertically(android.view.View p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (int)
        _result = v1.canScrollVertically(v2); // android.view.View.canScrollVertically -> boolean
        v0 = _result;
        return v0;
    }

    public static void onInitializeAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (android.view.accessibility.AccessibilityEvent)
        _result = v0.onInitializeAccessibilityEvent(v1); // android.view.View.onInitializeAccessibilityEvent -> void
        return;
    }

    public static void onInitializeAccessibilityNodeInfo(android.view.View p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v0.onInitializeAccessibilityNodeInfo(v1); // android.view.View.onInitializeAccessibilityNodeInfo -> void
        return;
    }

    public static void onPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (android.view.accessibility.AccessibilityEvent)
        _result = v0.onPopulateAccessibilityEvent(v1); // android.view.View.onPopulateAccessibilityEvent -> void
        return;
    }

    public static void setAccessibilityDelegate(android.view.View p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (java.lang.Object)
        v1 = (android.view.View$AccessibilityDelegate) v1;
        _result = v0.setAccessibilityDelegate(v1); // android.view.View.setAccessibilityDelegate -> void
        return;
    }

}