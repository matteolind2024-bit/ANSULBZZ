package android.support.v4.database;

/**
 * Original SourceFile: DatabaseUtilsCompat.java
 * Descriptor: Landroid/support/v4/database/DatabaseUtilsCompat;
 */
public class DatabaseUtilsCompat {
    private DatabaseUtilsCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static java.lang.String[] appendSelectionArgs(java.lang.String[] p0, java.lang.String[] p1) {
        // Registers (6 total): v4 = p0 (java.lang.String[]), v5 = p1 (java.lang.String[])
        v3 = 0;
        if (v4 == 0) /* goto L_0006 */;
        v0 = v4.length;
        if (v0 != 0) /* goto L_0007 */;
        return v5;
        v0 = v4.length;
        v1 = v5.length;
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = new java.lang.String[][size=v0];
        v1 = v4.length;
        _result = v4.arraycopy(v3, v0, v3, v1); // java.lang.System.arraycopy -> void
        v1 = v4.length;
        v2 = v5.length;
        _result = v5.arraycopy(v3, v0, v1, v2); // java.lang.System.arraycopy -> void
        v5 = v0;
        // goto L_0006
    }

    public static java.lang.String concatenateWhere(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        _result = v2.isEmpty(); // android.text.TextUtils.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0007 */;
        return v3;
        _result = v3.isEmpty(); // android.text.TextUtils.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000f */;
        v3 = v2;
        // goto L_0006
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "(";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ") AND (";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ")";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        // goto L_0006
    }

}