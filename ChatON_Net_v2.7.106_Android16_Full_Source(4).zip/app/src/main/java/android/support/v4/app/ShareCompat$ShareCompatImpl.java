package android.support.v4.app;

/**
 * Original SourceFile: ShareCompat.java
 * Descriptor: Landroid/support/v4/app/ShareCompat$ShareCompatImpl;
 */
interface ShareCompat$ShareCompatImpl {
    public abstract void configureMenuItem(android.view.MenuItem p0, android.support.v4.app.ShareCompat$IntentBuilder p1);
    public abstract java.lang.String escapeHtml(java.lang.CharSequence p0);
}