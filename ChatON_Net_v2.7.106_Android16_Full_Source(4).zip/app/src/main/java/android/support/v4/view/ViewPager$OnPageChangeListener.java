package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$OnPageChangeListener;
 */
public interface ViewPager$OnPageChangeListener {
    public abstract void onPageScrollStateChanged(int p0);
    public abstract void onPageScrolled(int p0, float p1, int p2);
    public abstract void onPageSelected(int p0);
}