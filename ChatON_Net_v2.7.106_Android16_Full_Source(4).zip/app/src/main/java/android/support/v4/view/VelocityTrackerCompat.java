package android.support.v4.view;

/**
 * Original SourceFile: VelocityTrackerCompat.java
 * Descriptor: Landroid/support/v4/view/VelocityTrackerCompat;
 */
public class VelocityTrackerCompat {
    static final android.support.v4.view.VelocityTrackerCompat$VelocityTrackerVersionImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.VelocityTrackerCompat$HoneycombVelocityTrackerVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.VelocityTrackerCompat$HoneycombVelocityTrackerVersionImpl.<init> -> void
        android.support.v4.view.VelocityTrackerCompat.IMPL = v0; // :android.support.v4.view.VelocityTrackerCompat$VelocityTrackerVersionImpl
        return;
        v0 = new android.support.v4.view.VelocityTrackerCompat$BaseVelocityTrackerVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.VelocityTrackerCompat$BaseVelocityTrackerVersionImpl.<init> -> void
        android.support.v4.view.VelocityTrackerCompat.IMPL = v0; // :android.support.v4.view.VelocityTrackerCompat$VelocityTrackerVersionImpl
        // goto L_000d
    }

    public VelocityTrackerCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static float getXVelocity(android.view.VelocityTracker p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.VelocityTracker), v2 = p1 (int)
        v0 = android.support.v4.view.VelocityTrackerCompat.IMPL; // :android.support.v4.view.VelocityTrackerCompat$VelocityTrackerVersionImpl
        _result = android.support.v4.view.VelocityTrackerCompat$VelocityTrackerVersionImpl.getXVelocity(v0, v1, v2); // -> float
        v0 = _result;
        return v0;
    }

    public static float getYVelocity(android.view.VelocityTracker p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.VelocityTracker), v2 = p1 (int)
        v0 = android.support.v4.view.VelocityTrackerCompat.IMPL; // :android.support.v4.view.VelocityTrackerCompat$VelocityTrackerVersionImpl
        _result = android.support.v4.view.VelocityTrackerCompat$VelocityTrackerVersionImpl.getYVelocity(v0, v1, v2); // -> float
        v0 = _result;
        return v0;
    }

}