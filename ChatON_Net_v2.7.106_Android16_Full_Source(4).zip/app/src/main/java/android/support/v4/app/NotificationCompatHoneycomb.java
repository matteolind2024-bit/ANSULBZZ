package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompatHoneycomb.java
 * Descriptor: Landroid/support/v4/app/NotificationCompatHoneycomb;
 */
class NotificationCompatHoneycomb {
    NotificationCompatHoneycomb() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    static android.app.Notification add(android.content.Context p0, android.app.Notification p1, java.lang.CharSequence p2, java.lang.CharSequence p3, java.lang.CharSequence p4, android.widget.RemoteViews p5, int p6, android.app.PendingIntent p7, android.app.PendingIntent p8, android.graphics.Bitmap p9) {
        // Registers (16 total): v6 = p0 (android.content.Context), v7 = p1 (android.app.Notification), v8 = p2 (java.lang.CharSequence), v9 = p3 (java.lang.CharSequence), v10 = p4 (java.lang.CharSequence), v11 = p5 (android.widget.RemoteViews), v12 = p6 (int), v13 = p7 (android.app.PendingIntent), v14 = p8 (android.app.PendingIntent), v15 = p9 (android.graphics.Bitmap)
        v1 = 1;
        v2 = 0;
        v0 = new android.app.Notification$Builder;
        _result = v0.<init>(v6); // android.app.Notification$Builder.<init> -> void
        v3 = v7.when; // android.app.Notification.when:long
        _result = v0.setWhen(v3, v4); // android.app.Notification$Builder.setWhen -> android.app.Notification$Builder
        v0 = _result;
        v3 = v7.icon; // android.app.Notification.icon:int
        v4 = v7.iconLevel; // android.app.Notification.iconLevel:int
        _result = v0.setSmallIcon(v3, v4); // android.app.Notification$Builder.setSmallIcon -> android.app.Notification$Builder
        v0 = _result;
        v3 = v7.contentView; // android.app.Notification.contentView:android.widget.RemoteViews
        _result = v0.setContent(v3); // android.app.Notification$Builder.setContent -> android.app.Notification$Builder
        v0 = _result;
        v3 = v7.tickerText; // android.app.Notification.tickerText:java.lang.CharSequence
        _result = v0.setTicker(v3, v11); // android.app.Notification$Builder.setTicker -> android.app.Notification$Builder
        v0 = _result;
        v3 = v7.sound; // android.app.Notification.sound:android.net.Uri
        v4 = v7.audioStreamType; // android.app.Notification.audioStreamType:int
        _result = v0.setSound(v3, v4); // android.app.Notification$Builder.setSound -> android.app.Notification$Builder
        v0 = _result;
        v3 = v7.vibrate; // android.app.Notification.vibrate:long[]
        _result = v0.setVibrate(v3); // android.app.Notification$Builder.setVibrate -> android.app.Notification$Builder
        v0 = _result;
        v3 = v7.ledARGB; // android.app.Notification.ledARGB:int
        v4 = v7.ledOnMS; // android.app.Notification.ledOnMS:int
        v5 = v7.ledOffMS; // android.app.Notification.ledOffMS:int
        _result = v0.setLights(v3, v4, v5); // android.app.Notification$Builder.setLights -> android.app.Notification$Builder
        v3 = _result;
        v0 = v7.flags; // android.app.Notification.flags:int
        v0 = binOpLit8_0xdd(v0, 2);
        if (v0 == 0) /* goto L_008d */;
        v0 = v1;
        _result = v3.setOngoing(v0); // android.app.Notification$Builder.setOngoing -> android.app.Notification$Builder
        v3 = _result;
        v0 = v7.flags; // android.app.Notification.flags:int
        v0 = binOpLit8_0xdd(v0, 8);
        if (v0 == 0) /* goto L_008f */;
        v0 = v1;
        _result = v3.setOnlyAlertOnce(v0); // android.app.Notification$Builder.setOnlyAlertOnce -> android.app.Notification$Builder
        v3 = _result;
        v0 = v7.flags; // android.app.Notification.flags:int
        v0 = binOpLit8_0xdd(v0, 16);
        if (v0 == 0) /* goto L_0091 */;
        v0 = v1;
        _result = v3.setAutoCancel(v0); // android.app.Notification$Builder.setAutoCancel -> android.app.Notification$Builder
        v0 = _result;
        v3 = v7.defaults; // android.app.Notification.defaults:int
        _result = v0.setDefaults(v3); // android.app.Notification$Builder.setDefaults -> android.app.Notification$Builder
        v0 = _result;
        _result = v0.setContentTitle(v8); // android.app.Notification$Builder.setContentTitle -> android.app.Notification$Builder
        v0 = _result;
        _result = v0.setContentText(v9); // android.app.Notification$Builder.setContentText -> android.app.Notification$Builder
        v0 = _result;
        _result = v0.setContentInfo(v10); // android.app.Notification$Builder.setContentInfo -> android.app.Notification$Builder
        v0 = _result;
        _result = v0.setContentIntent(v13); // android.app.Notification$Builder.setContentIntent -> android.app.Notification$Builder
        v0 = _result;
        v3 = v7.deleteIntent; // android.app.Notification.deleteIntent:android.app.PendingIntent
        _result = v0.setDeleteIntent(v3); // android.app.Notification$Builder.setDeleteIntent -> android.app.Notification$Builder
        v0 = _result;
        v3 = v7.flags; // android.app.Notification.flags:int
        v3 = binOpLit16_0xd5(v3, 128);
        if (v3 == 0) /* goto L_0093 */;
        _result = v0.setFullScreenIntent(v14, v1); // android.app.Notification$Builder.setFullScreenIntent -> android.app.Notification$Builder
        v0 = _result;
        _result = v0.setLargeIcon(v15); // android.app.Notification$Builder.setLargeIcon -> android.app.Notification$Builder
        v0 = _result;
        _result = v0.setNumber(v12); // android.app.Notification$Builder.setNumber -> android.app.Notification$Builder
        v0 = _result;
        _result = v0.getNotification(); // android.app.Notification$Builder.getNotification -> android.app.Notification
        v0 = _result;
        return v0;
        v0 = v2;
        // goto L_0040
        v0 = v2;
        // goto L_004b
        v0 = v2;
        // goto L_0056
        v1 = v2;
        // goto L_007c
    }

}