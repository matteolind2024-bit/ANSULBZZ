package android.support.v4.app;

/**
 * Original SourceFile: ShareCompat.java
 * Descriptor: Landroid/support/v4/app/ShareCompat$IntentBuilder;
 */
public class ShareCompat$IntentBuilder {
    private android.app.Activity mActivity;
    private java.util.ArrayList mBccAddresses;
    private java.util.ArrayList mCcAddresses;
    private java.lang.CharSequence mChooserTitle;
    private android.content.Intent mIntent;
    private java.util.ArrayList mStreams;
    private java.util.ArrayList mToAddresses;

    private ShareCompat$IntentBuilder(android.app.Activity p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.app.Activity)
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v3.mActivity = v4; // android.support.v4.app.ShareCompat$IntentBuilder.mActivity:android.app.Activity
        v0 = new android.content.Intent;
        _result = v0.<init>(); // android.content.Intent.<init> -> void
        v1 = "android.intent.action.SEND";
        _result = v0.setAction(v1); // android.content.Intent.setAction -> android.content.Intent
        v0 = _result;
        v3.mIntent = v0; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v0 = v3.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.support.v4.app.EXTRA_CALLING_PACKAGE";
        _result = v4.getPackageName(); // android.app.Activity.getPackageName -> java.lang.String
        v2 = _result;
        _result = v0.putExtra(v1, v2); // android.content.Intent.putExtra -> android.content.Intent
        v0 = v3.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.support.v4.app.EXTRA_CALLING_ACTIVITY";
        _result = v4.getComponentName(); // android.app.Activity.getComponentName -> android.content.ComponentName
        v2 = _result;
        _result = v0.putExtra(v1, v2); // android.content.Intent.putExtra -> android.content.Intent
        v0 = v3.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = 0x00080000;
        _result = v0.addFlags(v1); // android.content.Intent.addFlags -> android.content.Intent
        return;
    }

    private void combineArrayExtra(java.lang.String p0, java.util.ArrayList p1) {
        // Registers (8 total): v5 = this, v6 = p0 (java.lang.String), v7 = p1 (java.util.ArrayList)
        v1 = 0;
        v0 = v5.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        _result = v0.getStringArrayExtra(v6); // android.content.Intent.getStringArrayExtra -> java.lang.String[]
        v2 = _result;
        if (v2 == 0) /* goto L_0023 */;
        v0 = v2.length;
        _result = v7.size(); // java.util.ArrayList.size -> int
        v3 = _result;
        v3 = binOp2addr_0xb0(v3, v0);
        v3 = new java.lang.String[][size=v3];
        _result = v7.toArray(v3); // java.util.ArrayList.toArray -> java.lang.Object[]
        if (v2 == 0) /* goto L_001d */;
        _result = v7.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        _result = v2.arraycopy(v1, v3, v4, v0); // java.lang.System.arraycopy -> void
        v0 = v5.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        _result = v0.putExtra(v6, v3); // android.content.Intent.putExtra -> android.content.Intent
        return;
        v0 = v1;
        // goto L_000a
    }

    private void combineArrayExtra(java.lang.String p0, java.lang.String[] p1) {
        // Registers (8 total): v5 = this, v6 = p0 (java.lang.String), v7 = p1 (java.lang.String[])
        v1 = 0;
        _result = v5.getIntent(); // android.support.v4.app.ShareCompat$IntentBuilder.getIntent -> android.content.Intent
        v2 = _result;
        _result = v2.getStringArrayExtra(v6); // android.content.Intent.getStringArrayExtra -> java.lang.String[]
        v3 = _result;
        if (v3 == 0) /* goto L_001d */;
        v0 = v3.length;
        v4 = v7.length;
        v4 = binOp2addr_0xb0(v4, v0);
        v4 = new java.lang.String[][size=v4];
        if (v3 == 0) /* goto L_0015 */;
        _result = v3.arraycopy(v1, v4, v1, v0); // java.lang.System.arraycopy -> void
        v3 = v7.length;
        _result = v7.arraycopy(v1, v4, v0, v3); // java.lang.System.arraycopy -> void
        _result = v2.putExtra(v6, v4); // android.content.Intent.putExtra -> android.content.Intent
        return;
        v0 = v1;
        // goto L_000c
    }

    public static android.support.v4.app.ShareCompat$IntentBuilder from(android.app.Activity p0) {
        // Registers (2 total): v1 = p0 (android.app.Activity)
        v0 = new android.support.v4.app.ShareCompat$IntentBuilder;
        _result = v0.<init>(v1); // android.support.v4.app.ShareCompat$IntentBuilder.<init> -> void
        return v0;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder addEmailBcc(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.mBccAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mBccAddresses:java.util.ArrayList
        if (v0 != 0) /* goto L_000b */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.mBccAddresses = v0; // android.support.v4.app.ShareCompat$IntentBuilder.mBccAddresses:java.util.ArrayList
        v0 = v1.mBccAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mBccAddresses:java.util.ArrayList
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        return v1;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder addEmailBcc(java.lang.String[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String[])
        v0 = "android.intent.extra.BCC";
        _result = v1.combineArrayExtra(v0, v2); // android.support.v4.app.ShareCompat$IntentBuilder.combineArrayExtra -> void
        return v1;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder addEmailCc(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.mCcAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mCcAddresses:java.util.ArrayList
        if (v0 != 0) /* goto L_000b */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.mCcAddresses = v0; // android.support.v4.app.ShareCompat$IntentBuilder.mCcAddresses:java.util.ArrayList
        v0 = v1.mCcAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mCcAddresses:java.util.ArrayList
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        return v1;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder addEmailCc(java.lang.String[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String[])
        v0 = "android.intent.extra.CC";
        _result = v1.combineArrayExtra(v0, v2); // android.support.v4.app.ShareCompat$IntentBuilder.combineArrayExtra -> void
        return v1;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder addEmailTo(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.mToAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mToAddresses:java.util.ArrayList
        if (v0 != 0) /* goto L_000b */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.mToAddresses = v0; // android.support.v4.app.ShareCompat$IntentBuilder.mToAddresses:java.util.ArrayList
        v0 = v1.mToAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mToAddresses:java.util.ArrayList
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        return v1;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder addEmailTo(java.lang.String[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String[])
        v0 = "android.intent.extra.EMAIL";
        _result = v1.combineArrayExtra(v0, v2); // android.support.v4.app.ShareCompat$IntentBuilder.combineArrayExtra -> void
        return v1;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder addStream(android.net.Uri p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.net.Uri)
        v0 = v3.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.extra.STREAM";
        _result = v0.getParcelableExtra(v1); // android.content.Intent.getParcelableExtra -> android.os.Parcelable
        v0 = _result;
        v0 = (android.net.Uri) v0;
        if (v0 != 0) /* goto L_0011 */;
        _result = v3.setStream(v4); // android.support.v4.app.ShareCompat$IntentBuilder.setStream -> android.support.v4.app.ShareCompat$IntentBuilder
        v3 = _result;
        return v3;
        v1 = v3.mStreams; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        if (v1 != 0) /* goto L_001c */;
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        v3.mStreams = v1; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        if (v0 == 0) /* goto L_002a */;
        v1 = v3.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v2 = "android.intent.extra.STREAM";
        _result = v1.removeExtra(v2); // android.content.Intent.removeExtra -> void
        v1 = v3.mStreams; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        _result = v1.add(v0); // java.util.ArrayList.add -> boolean
        v0 = v3.mStreams; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        _result = v0.add(v4); // java.util.ArrayList.add -> boolean
        // goto L_0010
    }

    public android.content.Intent createChooserIntent() {
        // Registers (3 total): v2 = this
        _result = v2.getIntent(); // android.support.v4.app.ShareCompat$IntentBuilder.getIntent -> android.content.Intent
        v0 = _result;
        v1 = v2.mChooserTitle; // android.support.v4.app.ShareCompat$IntentBuilder.mChooserTitle:java.lang.CharSequence
        _result = v0.createChooser(v1); // android.content.Intent.createChooser -> android.content.Intent
        v0 = _result;
        return v0;
    }

    android.app.Activity getActivity() {
        // Registers (2 total): v1 = this
        v0 = v1.mActivity; // android.support.v4.app.ShareCompat$IntentBuilder.mActivity:android.app.Activity
        return v0;
    }

    public android.content.Intent getIntent() {
        // Registers (8 total): v7 = this
        v0 = 1;
        v2 = 0;
        v6 = 0;
        v1 = v7.mToAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mToAddresses:java.util.ArrayList
        if (v1 == 0) /* goto L_0010 */;
        v1 = "android.intent.extra.EMAIL";
        v3 = v7.mToAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mToAddresses:java.util.ArrayList
        _result = v7.combineArrayExtra(v1, v3); // android.support.v4.app.ShareCompat$IntentBuilder.combineArrayExtra -> void
        v7.mToAddresses = v6; // android.support.v4.app.ShareCompat$IntentBuilder.mToAddresses:java.util.ArrayList
        v1 = v7.mCcAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mCcAddresses:java.util.ArrayList
        if (v1 == 0) /* goto L_001d */;
        v1 = "android.intent.extra.CC";
        v3 = v7.mCcAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mCcAddresses:java.util.ArrayList
        _result = v7.combineArrayExtra(v1, v3); // android.support.v4.app.ShareCompat$IntentBuilder.combineArrayExtra -> void
        v7.mCcAddresses = v6; // android.support.v4.app.ShareCompat$IntentBuilder.mCcAddresses:java.util.ArrayList
        v1 = v7.mBccAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mBccAddresses:java.util.ArrayList
        if (v1 == 0) /* goto L_002a */;
        v1 = "android.intent.extra.BCC";
        v3 = v7.mBccAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mBccAddresses:java.util.ArrayList
        _result = v7.combineArrayExtra(v1, v3); // android.support.v4.app.ShareCompat$IntentBuilder.combineArrayExtra -> void
        v7.mBccAddresses = v6; // android.support.v4.app.ShareCompat$IntentBuilder.mBccAddresses:java.util.ArrayList
        v1 = v7.mStreams; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        if (v1 == 0) /* goto L_008e */;
        v1 = v7.mStreams; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v1 <= v0) /* goto L_008e */;
        v1 = v0;
        v0 = v7.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        _result = v0.getAction(); // android.content.Intent.getAction -> java.lang.String
        v0 = _result;
        v3 = "android.intent.action.SEND_MULTIPLE";
        _result = v0.equals(v3); // java.lang.String.equals -> boolean
        v3 = _result;
        if (v1 != 0) /* goto L_006b */;
        if (v3 == 0) /* goto L_006b */;
        v0 = v7.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v4 = "android.intent.action.SEND";
        _result = v0.setAction(v4); // android.content.Intent.setAction -> android.content.Intent
        v0 = v7.mStreams; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        if (v0 == 0) /* goto L_0090 */;
        v0 = v7.mStreams; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        _result = v0.isEmpty(); // java.util.ArrayList.isEmpty -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0090 */;
        v4 = v7.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v5 = "android.intent.extra.STREAM";
        v0 = v7.mStreams; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.os.Parcelable) v0;
        _result = v4.putExtra(v5, v0); // android.content.Intent.putExtra -> android.content.Intent
        v7.mStreams = v6; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        if (v1 == 0) /* goto L_008b */;
        if (v3 != 0) /* goto L_008b */;
        v0 = v7.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.action.SEND_MULTIPLE";
        _result = v0.setAction(v1); // android.content.Intent.setAction -> android.content.Intent
        v0 = v7.mStreams; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        if (v0 == 0) /* goto L_0098 */;
        v0 = v7.mStreams; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        _result = v0.isEmpty(); // java.util.ArrayList.isEmpty -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0098 */;
        v0 = v7.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.extra.STREAM";
        v2 = v7.mStreams; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        _result = v0.putParcelableArrayListExtra(v1, v2); // android.content.Intent.putParcelableArrayListExtra -> android.content.Intent
        v0 = v7.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        return v0;
        v1 = v2;
        // goto L_0037
        v0 = v7.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v2 = "android.intent.extra.STREAM";
        _result = v0.removeExtra(v2); // android.content.Intent.removeExtra -> void
        // goto L_0069
        v0 = v7.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.extra.STREAM";
        _result = v0.removeExtra(v1); // android.content.Intent.removeExtra -> void
        // goto L_008b
    }

    public android.support.v4.app.ShareCompat$IntentBuilder setChooserTitle(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mActivity; // android.support.v4.app.ShareCompat$IntentBuilder.mActivity:android.app.Activity
        _result = v0.getText(v2); // android.app.Activity.getText -> java.lang.CharSequence
        v0 = _result;
        _result = v1.setChooserTitle(v0); // android.support.v4.app.ShareCompat$IntentBuilder.setChooserTitle -> android.support.v4.app.ShareCompat$IntentBuilder
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder setChooserTitle(java.lang.CharSequence p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.CharSequence)
        v0.mChooserTitle = v1; // android.support.v4.app.ShareCompat$IntentBuilder.mChooserTitle:java.lang.CharSequence
        return v0;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder setEmailBcc(java.lang.String[] p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String[])
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.extra.BCC";
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        return v2;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder setEmailCc(java.lang.String[] p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String[])
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.extra.CC";
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        return v2;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder setEmailTo(java.lang.String[] p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String[])
        v0 = v2.mToAddresses; // android.support.v4.app.ShareCompat$IntentBuilder.mToAddresses:java.util.ArrayList
        if (v0 == 0) /* goto L_0007 */;
        v0 = 0;
        v2.mToAddresses = v0; // android.support.v4.app.ShareCompat$IntentBuilder.mToAddresses:java.util.ArrayList
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.extra.EMAIL";
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        return v2;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder setHtmlText(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.extra.HTML_TEXT";
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.extra.TEXT";
        _result = v0.hasExtra(v1); // android.content.Intent.hasExtra -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0018 */;
        _result = v3.fromHtml(); // android.text.Html.fromHtml -> android.text.Spanned
        v0 = _result;
        _result = v2.setText(v0); // android.support.v4.app.ShareCompat$IntentBuilder.setText -> android.support.v4.app.ShareCompat$IntentBuilder
        return v2;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder setStream(android.net.Uri p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.net.Uri)
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        _result = v0.getAction(); // android.content.Intent.getAction -> java.lang.String
        v0 = _result;
        v1 = "android.intent.action.SEND";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0015 */;
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.action.SEND";
        _result = v0.setAction(v1); // android.content.Intent.setAction -> android.content.Intent
        v0 = 0;
        v2.mStreams = v0; // android.support.v4.app.ShareCompat$IntentBuilder.mStreams:java.util.ArrayList
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.extra.STREAM";
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        return v2;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder setSubject(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.extra.SUBJECT";
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        return v2;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder setText(java.lang.CharSequence p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.CharSequence)
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        v1 = "android.intent.extra.TEXT";
        _result = v0.putExtra(v1, v3); // android.content.Intent.putExtra -> android.content.Intent
        return v2;
    }

    public android.support.v4.app.ShareCompat$IntentBuilder setType(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.mIntent; // android.support.v4.app.ShareCompat$IntentBuilder.mIntent:android.content.Intent
        _result = v0.setType(v2); // android.content.Intent.setType -> android.content.Intent
        return v1;
    }

    public void startChooser() {
        // Registers (3 total): v2 = this
        v0 = v2.mActivity; // android.support.v4.app.ShareCompat$IntentBuilder.mActivity:android.app.Activity
        _result = v2.createChooserIntent(); // android.support.v4.app.ShareCompat$IntentBuilder.createChooserIntent -> android.content.Intent
        v1 = _result;
        _result = v0.startActivity(v1); // android.app.Activity.startActivity -> void
        return;
    }

}