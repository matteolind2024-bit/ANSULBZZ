package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/ViewCompat$HCViewCompatImpl;
 */
class ViewCompat$HCViewCompatImpl extends android.support.v4.view.ViewCompat$GBViewCompatImpl {
    ViewCompat$HCViewCompatImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.ViewCompat$GBViewCompatImpl.<init> -> void
        return;
    }

    long getFrameTime() {
        // Registers (3 total): v2 = this
        _result = this.getFrameTime(); // android.support.v4.view.ViewCompatHC.getFrameTime -> long
        v0 = _result;
        return v0;
    }

}