package android.support.v4.content;

/**
 * Original SourceFile: LocalBroadcastManager.java
 * Descriptor: Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;
 */
class LocalBroadcastManager$ReceiverRecord {
     boolean broadcasting;
    final android.content.IntentFilter filter;
    final android.content.BroadcastReceiver receiver;

    LocalBroadcastManager$ReceiverRecord(android.content.IntentFilter p0, android.content.BroadcastReceiver p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.content.IntentFilter), v2 = p1 (android.content.BroadcastReceiver)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.filter = v1; // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.filter:android.content.IntentFilter
        v0.receiver = v2; // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.receiver:android.content.BroadcastReceiver
        return;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 128;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = "Receiver{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.receiver; // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.receiver:android.content.BroadcastReceiver
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = " filter=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.filter; // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.filter:android.content.IntentFilter
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = "}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}