package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityRecordCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordJellyBeanImpl;
 */
class AccessibilityRecordCompat$AccessibilityRecordJellyBeanImpl extends android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordIcsMr1Impl {
    AccessibilityRecordCompat$AccessibilityRecordJellyBeanImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordIcsMr1Impl.<init> -> void
        return;
    }

    public void setSource(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (int)
        _result = v1.setSource(v2, v3); // android.support.v4.view.accessibility.AccessibilityRecordCompatJellyBean.setSource -> void
        return;
    }

}