package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager;
 */
public class ViewPager extends android.view.ViewGroup {
    private static final int CLOSE_ENOUGH;
    private static final java.util.Comparator COMPARATOR;
    private static final boolean DEBUG;
    private static final int DEFAULT_GUTTER_SIZE;
    private static final int DEFAULT_OFFSCREEN_PAGES;
    private static final int INVALID_POINTER;
    private static final int[] LAYOUT_ATTRS;
    private static final int MAX_SETTLE_DURATION;
    private static final int MIN_DISTANCE_FOR_FLING;
    public static final int SCROLL_STATE_DRAGGING;
    public static final int SCROLL_STATE_IDLE;
    public static final int SCROLL_STATE_SETTLING;
    private static final java.lang.String TAG;
    private static final boolean USE_CACHE;
    private static final android.view.animation.Interpolator sInterpolator;
    private int mActivePointerId;
    private android.support.v4.view.PagerAdapter mAdapter;
    private android.support.v4.view.ViewPager$OnAdapterChangeListener mAdapterChangeListener;
    private int mBottomPageBounds;
    private boolean mCalledSuper;
    private int mChildHeightMeasureSpec;
    private int mChildWidthMeasureSpec;
    private int mCloseEnough;
    private int mCurItem;
    private int mDecorChildCount;
    private int mDefaultGutterSize;
    private long mFakeDragBeginTime;
    private boolean mFakeDragging;
    private boolean mFirstLayout;
    private float mFirstOffset;
    private int mFlingDistance;
    private int mGutterSize;
    private boolean mIgnoreGutter;
    private boolean mInLayout;
    private float mInitialMotionX;
    private android.support.v4.view.ViewPager$OnPageChangeListener mInternalPageChangeListener;
    private boolean mIsBeingDragged;
    private boolean mIsUnableToDrag;
    private final java.util.ArrayList mItems;
    private float mLastMotionX;
    private float mLastMotionY;
    private float mLastOffset;
    private android.support.v4.widget.EdgeEffectCompat mLeftEdge;
    private android.graphics.drawable.Drawable mMarginDrawable;
    private int mMaximumVelocity;
    private int mMinimumVelocity;
    private boolean mNeedCalculatePageOffsets;
    private android.support.v4.view.ViewPager$PagerObserver mObserver;
    private int mOffscreenPageLimit;
    private android.support.v4.view.ViewPager$OnPageChangeListener mOnPageChangeListener;
    private int mPageMargin;
    private boolean mPopulatePending;
    private android.os.Parcelable mRestoredAdapterState;
    private java.lang.ClassLoader mRestoredClassLoader;
    private int mRestoredCurItem;
    private android.support.v4.widget.EdgeEffectCompat mRightEdge;
    private int mScrollState;
    private android.widget.Scroller mScroller;
    private boolean mScrollingCacheEnabled;
    private final android.support.v4.view.ViewPager$ItemInfo mTempItem;
    private final android.graphics.Rect mTempRect;
    private int mTopPageBounds;
    private int mTouchSlop;
    private android.view.VelocityTracker mVelocityTracker;

    static {
        v0 = 1;
        v0 = new int[][size=v0];
        v1 = 0;
        v2 = 16842931; // 0x010100b3
        v0[v1] = v2;
        android.support.v4.view.ViewPager.LAYOUT_ATTRS = v0; // :int[]
        v0 = new android.support.v4.view.ViewPager$1;
        _result = v0.<init>(); // android.support.v4.view.ViewPager$1.<init> -> void
        android.support.v4.view.ViewPager.COMPARATOR = v0; // :java.util.Comparator
        v0 = new android.support.v4.view.ViewPager$2;
        _result = v0.<init>(); // android.support.v4.view.ViewPager$2.<init> -> void
        android.support.v4.view.ViewPager.sInterpolator = v0; // :android.view.animation.Interpolator
        return;
    }

    public ViewPager(android.content.Context p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.content.Context)
        v4 = 0;
        v3 = 1;
        v2 = 0;
        v1 = -1;
        _result = v5.<init>(v6); // android.view.ViewGroup.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v5.mItems = v0; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        v0 = new android.support.v4.view.ViewPager$ItemInfo;
        _result = v0.<init>(); // android.support.v4.view.ViewPager$ItemInfo.<init> -> void
        v5.mTempItem = v0; // android.support.v4.view.ViewPager.mTempItem:android.support.v4.view.ViewPager$ItemInfo
        v0 = new android.graphics.Rect;
        _result = v0.<init>(); // android.graphics.Rect.<init> -> void
        v5.mTempRect = v0; // android.support.v4.view.ViewPager.mTempRect:android.graphics.Rect
        v5.mRestoredCurItem = v1; // android.support.v4.view.ViewPager.mRestoredCurItem:int
        v5.mRestoredAdapterState = v4; // android.support.v4.view.ViewPager.mRestoredAdapterState:android.os.Parcelable
        v5.mRestoredClassLoader = v4; // android.support.v4.view.ViewPager.mRestoredClassLoader:java.lang.ClassLoader
        v0 = -8388609; // 0xff7fffff
        v5.mFirstOffset = v0; // android.support.v4.view.ViewPager.mFirstOffset:float
        v0 = 2139095039; // 0x7f7fffff
        v5.mLastOffset = v0; // android.support.v4.view.ViewPager.mLastOffset:float
        v5.mOffscreenPageLimit = v3; // android.support.v4.view.ViewPager.mOffscreenPageLimit:int
        v5.mActivePointerId = v1; // android.support.v4.view.ViewPager.mActivePointerId:int
        v5.mFirstLayout = v3; // android.support.v4.view.ViewPager.mFirstLayout:boolean
        v5.mNeedCalculatePageOffsets = v2; // android.support.v4.view.ViewPager.mNeedCalculatePageOffsets:boolean
        v5.mScrollState = v2; // android.support.v4.view.ViewPager.mScrollState:int
        _result = v5.initViewPager(); // android.support.v4.view.ViewPager.initViewPager -> void
        return;
    }

    public ViewPager(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.content.Context), v7 = p1 (android.util.AttributeSet)
        v4 = 0;
        v3 = 1;
        v2 = 0;
        v1 = -1;
        _result = v5.<init>(v6, v7); // android.view.ViewGroup.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v5.mItems = v0; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        v0 = new android.support.v4.view.ViewPager$ItemInfo;
        _result = v0.<init>(); // android.support.v4.view.ViewPager$ItemInfo.<init> -> void
        v5.mTempItem = v0; // android.support.v4.view.ViewPager.mTempItem:android.support.v4.view.ViewPager$ItemInfo
        v0 = new android.graphics.Rect;
        _result = v0.<init>(); // android.graphics.Rect.<init> -> void
        v5.mTempRect = v0; // android.support.v4.view.ViewPager.mTempRect:android.graphics.Rect
        v5.mRestoredCurItem = v1; // android.support.v4.view.ViewPager.mRestoredCurItem:int
        v5.mRestoredAdapterState = v4; // android.support.v4.view.ViewPager.mRestoredAdapterState:android.os.Parcelable
        v5.mRestoredClassLoader = v4; // android.support.v4.view.ViewPager.mRestoredClassLoader:java.lang.ClassLoader
        v0 = -8388609; // 0xff7fffff
        v5.mFirstOffset = v0; // android.support.v4.view.ViewPager.mFirstOffset:float
        v0 = 2139095039; // 0x7f7fffff
        v5.mLastOffset = v0; // android.support.v4.view.ViewPager.mLastOffset:float
        v5.mOffscreenPageLimit = v3; // android.support.v4.view.ViewPager.mOffscreenPageLimit:int
        v5.mActivePointerId = v1; // android.support.v4.view.ViewPager.mActivePointerId:int
        v5.mFirstLayout = v3; // android.support.v4.view.ViewPager.mFirstLayout:boolean
        v5.mNeedCalculatePageOffsets = v2; // android.support.v4.view.ViewPager.mNeedCalculatePageOffsets:boolean
        v5.mScrollState = v2; // android.support.v4.view.ViewPager.mScrollState:int
        _result = v5.initViewPager(); // android.support.v4.view.ViewPager.initViewPager -> void
        return;
    }

    static android.support.v4.view.PagerAdapter access$100(android.support.v4.view.ViewPager p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.view.ViewPager)
        v0 = v1.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        return v0;
    }

    static int access$200(android.support.v4.view.ViewPager p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.view.ViewPager)
        v0 = v1.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        return v0;
    }

    static int[] access$300() {
        v0 = android.support.v4.view.ViewPager.LAYOUT_ATTRS; // :int[]
        return v0;
    }

    private void calculatePageOffsets(android.support.v4.view.ViewPager$ItemInfo p0, int p1, android.support.v4.view.ViewPager$ItemInfo p2) {
        // Registers (15 total): v11 = this, v12 = p0 (android.support.v4.view.ViewPager$ItemInfo), v13 = p1 (int), v14 = p2 (android.support.v4.view.ViewPager$ItemInfo)
        v4 = 0;
        v10 = 0x3f800000;
        v0 = v11.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v0.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v7 = _result;
        _result = v11.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0055 */;
        v1 = v11.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        v1 = unaryOp_0x82(v1);
        v0 = unaryOp_0x82(v0);
        v0 = binOp_0xa9(v1, v0);
        v6 = v0;
        if (v14 == 0) /* goto L_00b7 */;
        v0 = v14.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v1 = v12.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v0 >= v1) /* goto L_0070 */;
        v1 = v14.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v2 = v14.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v1 = binOp2addr_0xc6(v1, v2);
        v3 = binOp_0xa6(v1, v6);
        v2 = binOpLit8_0xd8(v0, 1);
        v1 = v4;
        v0 = v12.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v2 > v0) /* goto L_00b7 */;
        v0 = v11.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_00b7 */;
        v0 = v11.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v5 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v2 <= v5) /* goto L_0058 */;
        v5 = v11.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v5.size(); // java.util.ArrayList.size -> int
        v5 = _result;
        v5 = binOpLit8_0xd8(v5, -1);
        if (v1 >= v5) /* goto L_0058 */;
        v1 = binOpLit8_0xd8(v1, 1);
        v0 = v11.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        // goto L_003c
        v0 = 0;
        v6 = v0;
        // goto L_0016
        v5 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v2 >= v5) /* goto L_0067 */;
        v5 = v11.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v5.getPageWidth(v2); // android.support.v4.view.PagerAdapter.getPageWidth -> float
        v5 = _result;
        v5 = binOp2addr_0xc6(v5, v6);
        v3 = binOp2addr_0xc6(v3, v5);
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_0058
        v0.offset = v3; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v0 = v0.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v0 = binOp2addr_0xc6(v0, v6);
        v3 = binOp2addr_0xc6(v3, v0);
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_0028
        v1 = v12.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v0 <= v1) /* goto L_00b7 */;
        v1 = v11.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        v3 = v14.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v2 = binOpLit8_0xd8(v0, -1);
        v0 = v12.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v2 < v0) /* goto L_00b7 */;
        if (v1 < 0) /* goto L_00b7 */;
        v0 = v11.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v5 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v2 >= v5) /* goto L_009f */;
        if (v1 <= 0) /* goto L_009f */;
        v1 = binOpLit8_0xd8(v1, -1);
        v0 = v11.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        // goto L_008e
        v5 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v2 <= v5) /* goto L_00ae */;
        v5 = v11.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v5.getPageWidth(v2); // android.support.v4.view.PagerAdapter.getPageWidth -> float
        v5 = _result;
        v5 = binOp2addr_0xc6(v5, v6);
        v3 = binOp2addr_0xc7(v3, v5);
        v2 = binOpLit8_0xd8(v2, -1);
        // goto L_009f
        v5 = v0.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v5 = binOp2addr_0xc6(v5, v6);
        v3 = binOp2addr_0xc7(v3, v5);
        v0.offset = v3; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v2 = binOpLit8_0xd8(v2, -1);
        // goto L_0080
        v0 = v11.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v8 = _result;
        v2 = v12.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v0 = v12.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v1 = binOpLit8_0xd8(v0, -1);
        v0 = v12.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v0 != 0) /* goto L_00f9 */;
        v0 = v12.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v11.mFirstOffset = v0; // android.support.v4.view.ViewPager.mFirstOffset:float
        v0 = v12.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v3 = binOpLit8_0xd8(v7, -1);
        if (v0 != v3) /* goto L_00fd */;
        v0 = v12.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v3 = v12.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v0 = binOp2addr_0xc6(v0, v3);
        v0 = binOp2addr_0xc7(v0, v10);
        v11.mLastOffset = v0; // android.support.v4.view.ViewPager.mLastOffset:float
        v0 = binOpLit8_0xd8(v13, -1);
        v5 = v0;
        if (v5 < 0) /* goto L_0114 */;
        v0 = v11.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v3 = v2;
        v2 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v1 <= v2) /* goto L_0101 */;
        v9 = v11.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v2 = binOpLit8_0xd8(v1, -1);
        _result = v9.getPageWidth(v1); // android.support.v4.view.PagerAdapter.getPageWidth -> float
        v1 = _result;
        v1 = binOp2addr_0xc6(v1, v6);
        v1 = binOp_0xa7(v3, v1);
        v3 = v1;
        v1 = v2;
        // goto L_00e7
        v0 = -8388609; // 0xff7fffff
        // goto L_00c9
        v0 = 2139095039; // 0x7f7fffff
        // goto L_00d7
        v2 = v0.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v2 = binOp2addr_0xc6(v2, v6);
        v2 = binOp_0xa7(v3, v2);
        v0.offset = v2; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v0 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v0 != 0) /* goto L_010e */;
        v11.mFirstOffset = v2; // android.support.v4.view.ViewPager.mFirstOffset:float
        v0 = binOpLit8_0xd8(v5, -1);
        v1 = binOpLit8_0xd8(v1, -1);
        v5 = v0;
        // goto L_00dc
        v0 = v12.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v1 = v12.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v0 = binOp2addr_0xc6(v0, v1);
        v2 = binOp_0xa6(v0, v6);
        v0 = v12.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v1 = binOpLit8_0xd8(v0, 1);
        v0 = binOpLit8_0xd8(v13, 1);
        v5 = v0;
        if (v5 >= v8) /* goto L_0157 */;
        v0 = v11.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v3 = v2;
        v2 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v1 >= v2) /* goto L_013e */;
        v9 = v11.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v2 = binOpLit8_0xd8(v1, 1);
        _result = v9.getPageWidth(v1); // android.support.v4.view.PagerAdapter.getPageWidth -> float
        v1 = _result;
        v1 = binOp2addr_0xc6(v1, v6);
        v1 = binOp2addr_0xc6(v1, v3);
        v3 = v1;
        v1 = v2;
        // goto L_012d
        v2 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v9 = binOpLit8_0xd8(v7, -1);
        if (v2 != v9) /* goto L_014a */;
        v2 = v0.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v2 = binOp2addr_0xc6(v2, v3);
        v2 = binOp2addr_0xc7(v2, v10);
        v11.mLastOffset = v2; // android.support.v4.view.ViewPager.mLastOffset:float
        v0.offset = v3; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v0 = v0.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v0 = binOp2addr_0xc6(v0, v6);
        v2 = binOp_0xa6(v3, v0);
        v0 = binOpLit8_0xd8(v5, 1);
        v1 = binOpLit8_0xd8(v1, 1);
        v5 = v0;
        // goto L_0122
        v11.mNeedCalculatePageOffsets = v4; // android.support.v4.view.ViewPager.mNeedCalculatePageOffsets:boolean
        return;
    }

    private void completeScroll() {
        // Registers (8 total): v7 = this
        v4 = 1;
        v2 = 0;
        v0 = v7.mScrollState; // android.support.v4.view.ViewPager.mScrollState:int
        v1 = 2;
        if (v0 != v1) /* goto L_004f */;
        v0 = v4;
        if (v0 == 0) /* goto L_0030 */;
        _result = v7.setScrollingCacheEnabled(v2); // android.support.v4.view.ViewPager.setScrollingCacheEnabled -> void
        v1 = v7.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v1.abortAnimation(); // android.widget.Scroller.abortAnimation -> void
        _result = v7.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v1 = _result;
        _result = v7.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v3 = _result;
        v5 = v7.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v5.getCurrX(); // android.widget.Scroller.getCurrX -> int
        v5 = _result;
        v6 = v7.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v6.getCurrY(); // android.widget.Scroller.getCurrY -> int
        v6 = _result;
        if (v1 != v5) /* goto L_002a */;
        if (v3 == v6) /* goto L_002d */;
        _result = v7.scrollTo(v5, v6); // android.support.v4.view.ViewPager.scrollTo -> void
        _result = v7.setScrollState(v2); // android.support.v4.view.ViewPager.setScrollState -> void
        v7.mPopulatePending = v2; // android.support.v4.view.ViewPager.mPopulatePending:boolean
        v1 = v2;
        v3 = v0;
        v0 = v7.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0051 */;
        v0 = v7.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v5 = v0.scrolling; // android.support.v4.view.ViewPager$ItemInfo.scrolling:boolean
        if (v5 == 0) /* goto L_004b */;
        v0.scrolling = v2; // android.support.v4.view.ViewPager$ItemInfo.scrolling:boolean
        v3 = v4;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0034
        v0 = v2;
        // goto L_0008
        if (v3 == 0) /* goto L_0056 */;
        _result = v7.populate(); // android.support.v4.view.ViewPager.populate -> void
        return;
    }

    private int determineTargetPage(int p0, float p1, int p2, int p3) {
        // Registers (8 total): v3 = this, v4 = p0 (int), v5 = p1 (float), v6 = p2 (int), v7 = p3 (int)
        _result = v7.abs(); // java.lang.Math.abs -> int
        v0 = _result;
        v1 = v3.mFlingDistance; // android.support.v4.view.ViewPager.mFlingDistance:int
        if (v0 <= v1) /* goto L_0043 */;
        _result = v6.abs(); // java.lang.Math.abs -> int
        v0 = _result;
        v1 = v3.mMinimumVelocity; // android.support.v4.view.ViewPager.mMinimumVelocity:int
        if (v0 <= v1) /* goto L_0043 */;
        if (v6 <= 0) /* goto L_0040 */;
        v0 = v3.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_003f */;
        v0 = v3.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        v1 = 0;
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v1 = v3.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        v2 = v3.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        v2 = binOpLit8_0xd8(v2, -1);
        _result = v1.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.view.ViewPager$ItemInfo) v1;
        v0 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v1 = v1.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        _result = v4.min(v1); // java.lang.Math.min -> int
        v1 = _result;
        _result = v0.max(v1); // java.lang.Math.max -> int
        v4 = _result;
        return v4;
        v4 = binOpLit8_0xd8(v4, 1);
        // goto L_0012
        v0 = unaryOp_0x82(v4);
        v0 = binOp2addr_0xc6(v0, v5);
        v1 = 0x3f000000;
        v0 = binOp2addr_0xc6(v0, v1);
        v4 = unaryOp_0x87(v0);
        // goto L_0012
    }

    private void endDrag() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.mIsBeingDragged = v0; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        v1.mIsUnableToDrag = v0; // android.support.v4.view.ViewPager.mIsUnableToDrag:boolean
        v0 = v1.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        if (v0 == 0) /* goto L_0011 */;
        v0 = v1.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        _result = v0.recycle(); // android.view.VelocityTracker.recycle -> void
        v0 = 0;
        v1.mVelocityTracker = v0; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        return;
    }

    private android.graphics.Rect getChildRectInPagerCoordinates(android.graphics.Rect p0, android.view.View p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.graphics.Rect), v6 = p1 (android.view.View)
        v0 = 0;
        if (v5 != 0) /* goto L_005e */;
        v1 = new android.graphics.Rect;
        _result = v1.<init>(); // android.graphics.Rect.<init> -> void
        if (v6 != 0) /* goto L_000f */;
        _result = v1.set(v0, v0, v0, v0); // android.graphics.Rect.set -> void
        v0 = v1;
        return v0;
        _result = v6.getLeft(); // android.view.View.getLeft -> int
        v0 = _result;
        v1.left = v0; // android.graphics.Rect.left:int
        _result = v6.getRight(); // android.view.View.getRight -> int
        v0 = _result;
        v1.right = v0; // android.graphics.Rect.right:int
        _result = v6.getTop(); // android.view.View.getTop -> int
        v0 = _result;
        v1.top = v0; // android.graphics.Rect.top:int
        _result = v6.getBottom(); // android.view.View.getBottom -> int
        v0 = _result;
        v1.bottom = v0; // android.graphics.Rect.bottom:int
        _result = v6.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v0 = _result;
        v2 = (v0 instanceof android.view.ViewGroup);
        if (v2 == 0) /* goto L_005c */;
        if (v0 == v4) /* goto L_005c */;
        v0 = (android.view.ViewGroup) v0;
        v2 = v1.left; // android.graphics.Rect.left:int
        _result = v0.getLeft(); // android.view.ViewGroup.getLeft -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v1.left = v2; // android.graphics.Rect.left:int
        v2 = v1.right; // android.graphics.Rect.right:int
        _result = v0.getRight(); // android.view.ViewGroup.getRight -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v1.right = v2; // android.graphics.Rect.right:int
        v2 = v1.top; // android.graphics.Rect.top:int
        _result = v0.getTop(); // android.view.ViewGroup.getTop -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v1.top = v2; // android.graphics.Rect.top:int
        v2 = v1.bottom; // android.graphics.Rect.bottom:int
        _result = v0.getBottom(); // android.view.ViewGroup.getBottom -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v1.bottom = v2; // android.graphics.Rect.bottom:int
        _result = v0.getParent(); // android.view.ViewGroup.getParent -> android.view.ViewParent
        v0 = _result;
        // goto L_002b
        v0 = v1;
        // goto L_000e
        v1 = v5;
        // goto L_0008
    }

    private android.support.v4.view.ViewPager$ItemInfo infoForCurrentScrollPosition() {
        // Registers (14 total): v13 = this
        v3 = 0;
        v2 = 0;
        _result = v13.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_006e */;
        _result = v13.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v0 = _result;
        v0 = unaryOp_0x82(v0);
        v4 = unaryOp_0x82(v1);
        v0 = binOp2addr_0xc9(v0, v4);
        v9 = v0;
        if (v1 <= 0) /* goto L_0070 */;
        v0 = v13.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        v0 = unaryOp_0x82(v0);
        v1 = unaryOp_0x82(v1);
        v0 = binOp2addr_0xc9(v0, v1);
        v1 = v0;
        v5 = -1;
        v4 = 1;
        v0 = 0;
        v6 = v2;
        v7 = v2;
        v8 = v5;
        v2 = v3;
        v5 = v4;
        v4 = v0;
        v0 = v13.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v2 >= v0) /* goto L_006d */;
        v0 = v13.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        if (v5 != 0) /* goto L_007f */;
        v10 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v11 = binOpLit8_0xd8(v8, 1);
        if (v10 == v11) /* goto L_007f */;
        v0 = v13.mTempItem; // android.support.v4.view.ViewPager.mTempItem:android.support.v4.view.ViewPager$ItemInfo
        v6 = binOp2addr_0xc6(v6, v7);
        v6 = binOp2addr_0xc6(v6, v1);
        v0.offset = v6; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v6 = binOpLit8_0xd8(v8, 1);
        v0.position = v6; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v6 = v13.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v7 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        _result = v6.getPageWidth(v7); // android.support.v4.view.PagerAdapter.getPageWidth -> float
        v6 = _result;
        v0.widthFactor = v6; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v2 = binOpLit8_0xd8(v2, -1);
        v12 = v0;
        v0 = v2;
        v2 = v12;
        v6 = v2.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v7 = v2.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v7 = binOp2addr_0xc6(v7, v6);
        v7 = binOp2addr_0xc6(v7, v1);
        if (v5 != 0) /* goto L_005e */;
        v5 = cmp(v9, v6);
        if (v5 < 0) /* goto L_006d */;
        v4 = cmp(v9, v7);
        if (v4 < 0) /* goto L_006c */;
        v4 = v13.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v4.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        v4 = binOpLit8_0xd8(v4, -1);
        if (v0 != v4) /* goto L_0072 */;
        v4 = v2;
        return v4;
        v9 = v2;
        // goto L_0010
        v1 = v2;
        // goto L_0018
        v5 = v2.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v4 = v2.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v0 = binOpLit8_0xd8(v0, 1);
        v7 = v6;
        v8 = v5;
        v5 = v3;
        v6 = v4;
        v4 = v2;
        v2 = v0;
        // goto L_0021
        v12 = v0;
        v0 = v2;
        v2 = v12;
        // goto L_0052
    }

    private boolean isGutterDrag(float p0, float p1) {
        // Registers (6 total): v3 = this, v4 = p0 (float), v5 = p1 (float)
        v2 = 0;
        v0 = v3.mGutterSize; // android.support.v4.view.ViewPager.mGutterSize:int
        v0 = unaryOp_0x82(v0);
        v0 = cmp(v4, v0);
        if (v0 >= 0) /* goto L_000c */;
        v0 = cmp(v5, v2);
        if (v0 > 0) /* goto L_001c */;
        _result = v3.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v0 = _result;
        v1 = v3.mGutterSize; // android.support.v4.view.ViewPager.mGutterSize:int
        v0 = binOp2addr_0xb1(v0, v1);
        v0 = unaryOp_0x82(v0);
        v0 = cmp(v4, v0);
        if (v0 <= 0) /* goto L_001e */;
        v0 = cmp(v5, v2);
        if (v0 >= 0) /* goto L_001e */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_001d
    }

    private void onSecondaryPointerUp(android.view.MotionEvent p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.MotionEvent)
        _result = v4.getActionIndex(); // android.support.v4.view.MotionEventCompat.getActionIndex -> int
        v0 = _result;
        _result = v4.getPointerId(v0); // android.support.v4.view.MotionEventCompat.getPointerId -> int
        v1 = _result;
        v2 = v3.mActivePointerId; // android.support.v4.view.ViewPager.mActivePointerId:int
        if (v1 != v2) /* goto L_0024 */;
        if (v0 != 0) /* goto L_0025 */;
        v0 = 1;
        _result = v4.getX(v0); // android.support.v4.view.MotionEventCompat.getX -> float
        v1 = _result;
        v3.mLastMotionX = v1; // android.support.v4.view.ViewPager.mLastMotionX:float
        _result = v4.getPointerId(v0); // android.support.v4.view.MotionEventCompat.getPointerId -> int
        v0 = _result;
        v3.mActivePointerId = v0; // android.support.v4.view.ViewPager.mActivePointerId:int
        v0 = v3.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        if (v0 == 0) /* goto L_0024 */;
        v0 = v3.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        _result = v0.clear(); // android.view.VelocityTracker.clear -> void
        return;
        v0 = 0;
        // goto L_000f
    }

    private boolean pageScrolled(int p0) {
        // Registers (9 total): v7 = this, v8 = p0 (int)
        v0 = 0;
        v1 = v7.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v1 != 0) /* goto L_001b */;
        v7.mCalledSuper = v0; // android.support.v4.view.ViewPager.mCalledSuper:boolean
        v1 = 0;
        _result = v7.onPageScrolled(v0, v1, v0); // android.support.v4.view.ViewPager.onPageScrolled -> void
        v1 = v7.mCalledSuper; // android.support.v4.view.ViewPager.mCalledSuper:boolean
        if (v1 != 0) /* goto L_004e */;
        v0 = new java.lang.IllegalStateException;
        v1 = "onPageScrolled did not call superclass implementation";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        _result = v7.infoForCurrentScrollPosition(); // android.support.v4.view.ViewPager.infoForCurrentScrollPosition -> android.support.v4.view.ViewPager$ItemInfo
        v1 = _result;
        _result = v7.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v2 = _result;
        v3 = v7.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        v3 = binOp2addr_0xb0(v3, v2);
        v4 = v7.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        v4 = unaryOp_0x82(v4);
        v5 = unaryOp_0x82(v2);
        v4 = binOp2addr_0xc9(v4, v5);
        v5 = v1.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v6 = unaryOp_0x82(v8);
        v2 = unaryOp_0x82(v2);
        v2 = binOp_0xa9(v6, v2);
        v6 = v1.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v2 = binOp2addr_0xc7(v2, v6);
        v1 = v1.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v1 = binOp2addr_0xc6(v1, v4);
        v1 = binOp_0xa9(v2, v1);
        v2 = unaryOp_0x82(v3);
        v2 = binOp2addr_0xc8(v2, v1);
        v2 = unaryOp_0x87(v2);
        v7.mCalledSuper = v0; // android.support.v4.view.ViewPager.mCalledSuper:boolean
        _result = v7.onPageScrolled(v5, v1, v2); // android.support.v4.view.ViewPager.onPageScrolled -> void
        v0 = v7.mCalledSuper; // android.support.v4.view.ViewPager.mCalledSuper:boolean
        if (v0 != 0) /* goto L_004d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "onPageScrolled did not call superclass implementation";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = 1;
        return v0;
    }

    private boolean performDrag(float p0) {
        // Registers (12 total): v10 = this, v11 = p0 (float)
        v3 = 1;
        v2 = 0;
        v0 = v10.mLastMotionX; // android.support.v4.view.ViewPager.mLastMotionX:float
        v0 = binOp2addr_0xc7(v0, v11);
        v10.mLastMotionX = v11; // android.support.v4.view.ViewPager.mLastMotionX:float
        _result = v10.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v1 = _result;
        v1 = unaryOp_0x82(v1);
        v5 = binOp_0xa6(v1, v0);
        _result = v10.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v7 = _result;
        v0 = unaryOp_0x82(v7);
        v1 = v10.mFirstOffset; // android.support.v4.view.ViewPager.mFirstOffset:float
        v4 = binOp_0xa8(v0, v1);
        v0 = unaryOp_0x82(v7);
        v1 = v10.mLastOffset; // android.support.v4.view.ViewPager.mLastOffset:float
        v6 = binOp_0xa8(v0, v1);
        v0 = v10.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v1 = v10.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        v8 = v10.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v8.size(); // java.util.ArrayList.size -> int
        v8 = _result;
        v8 = binOpLit8_0xd8(v8, -1);
        _result = v1.get(v8); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.view.ViewPager$ItemInfo) v1;
        v8 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v8 == 0) /* goto L_0093 */;
        v0 = v0.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v4 = unaryOp_0x82(v7);
        v0 = binOp2addr_0xc8(v0, v4);
        v4 = v0;
        v0 = v2;
        v8 = v1.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v9 = v10.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v9.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v9 = _result;
        v9 = binOpLit8_0xd8(v9, -1);
        if (v8 == v9) /* goto L_0091 */;
        v1 = v1.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v3 = unaryOp_0x82(v7);
        v1 = binOp2addr_0xc8(v1, v3);
        v3 = v2;
        v6 = cmp(v5, v4);
        if (v6 >= 0) /* goto L_0079 */;
        if (v0 == 0) /* goto L_0063 */;
        v0 = binOp_0xa7(v4, v5);
        v1 = v10.mLeftEdge; // android.support.v4.view.ViewPager.mLeftEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v0.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v2 = unaryOp_0x82(v7);
        v0 = binOp2addr_0xc9(v0, v2);
        _result = v1.onPull(v0); // android.support.v4.widget.EdgeEffectCompat.onPull -> boolean
        v2 = _result;
        v0 = v10.mLastMotionX; // android.support.v4.view.ViewPager.mLastMotionX:float
        v1 = unaryOp_0x87(v4);
        v1 = unaryOp_0x82(v1);
        v1 = binOp_0xa7(v4, v1);
        v0 = binOp2addr_0xc6(v0, v1);
        v10.mLastMotionX = v0; // android.support.v4.view.ViewPager.mLastMotionX:float
        v0 = unaryOp_0x87(v4);
        _result = v10.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v1 = _result;
        _result = v10.scrollTo(v0, v1); // android.support.v4.view.ViewPager.scrollTo -> void
        v0 = unaryOp_0x87(v4);
        _result = v10.pageScrolled(v0); // android.support.v4.view.ViewPager.pageScrolled -> boolean
        return v2;
        v0 = cmp(v5, v1);
        if (v0 <= 0) /* goto L_008f */;
        if (v3 == 0) /* goto L_008d */;
        v0 = binOp_0xa7(v5, v1);
        v2 = v10.mRightEdge; // android.support.v4.view.ViewPager.mRightEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v0.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v3 = unaryOp_0x82(v7);
        v0 = binOp2addr_0xc9(v0, v3);
        _result = v2.onPull(v0); // android.support.v4.widget.EdgeEffectCompat.onPull -> boolean
        v2 = _result;
        v4 = v1;
        // goto L_0063
        v4 = v5;
        // goto L_0063
        v1 = v6;
        // goto L_004f
        v0 = v3;
        // goto L_003e
    }

    private void recomputeScrollPosition(int p0, int p1, int p2, int p3) {
        // Registers (11 total): v6 = this, v7 = p0 (int), v8 = p1 (int), v9 = p2 (int), v10 = p3 (int)
        v2 = 0;
        if (v8 <= 0) /* goto L_0049 */;
        v0 = v6.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.isEmpty(); // java.util.ArrayList.isEmpty -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0049 */;
        v0 = binOp_0x90(v7, v9);
        v1 = binOp_0x90(v8, v10);
        _result = v6.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v3 = _result;
        v3 = unaryOp_0x82(v3);
        v1 = unaryOp_0x82(v1);
        v1 = binOp_0xa9(v3, v1);
        v0 = unaryOp_0x82(v0);
        v0 = binOp2addr_0xc8(v0, v1);
        v1 = unaryOp_0x87(v0);
        _result = v6.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v0 = _result;
        _result = v6.scrollTo(v1, v0); // android.support.v4.view.ViewPager.scrollTo -> void
        v0 = v6.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v0.isFinished(); // android.widget.Scroller.isFinished -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0048 */;
        v0 = v6.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v0.getDuration(); // android.widget.Scroller.getDuration -> int
        v0 = _result;
        v3 = v6.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v3.timePassed(); // android.widget.Scroller.timePassed -> int
        v3 = _result;
        v5 = binOp_0x91(v0, v3);
        v0 = v6.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        _result = v6.infoForPosition(v0); // android.support.v4.view.ViewPager.infoForPosition -> android.support.v4.view.ViewPager$ItemInfo
        v3 = _result;
        v0 = v6.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        v3 = v3.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v4 = unaryOp_0x82(v7);
        v3 = binOp2addr_0xc8(v3, v4);
        v3 = unaryOp_0x87(v3);
        v4 = v2;
        _result = v0.startScroll(v0..v5); // android.widget.Scroller.startScroll -> void
        return;
        v0 = v6.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        _result = v6.infoForPosition(v0); // android.support.v4.view.ViewPager.infoForPosition -> android.support.v4.view.ViewPager$ItemInfo
        v0 = _result;
        if (v0 == 0) /* goto L_006d */;
        v0 = v0.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v1 = v6.mLastOffset; // android.support.v4.view.ViewPager.mLastOffset:float
        _result = v0.min(v1); // java.lang.Math.min -> float
        v0 = _result;
        v1 = unaryOp_0x82(v7);
        v0 = binOp2addr_0xc8(v0, v1);
        v0 = unaryOp_0x87(v0);
        _result = v6.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v1 = _result;
        if (v0 == v1) /* goto L_0048 */;
        _result = v6.completeScroll(); // android.support.v4.view.ViewPager.completeScroll -> void
        _result = v6.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v1 = _result;
        _result = v6.scrollTo(v0, v1); // android.support.v4.view.ViewPager.scrollTo -> void
        // goto L_0048
        v0 = 0;
        // goto L_0059
    }

    private void removeNonDecorViews() {
        // Registers (3 total): v2 = this
        v0 = 0;
        v1 = v0;
        _result = v2.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001f */;
        _result = v2.getChildAt(v1); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v0 = _result;
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        v0 = v0.isDecor; // android.support.v4.view.ViewPager$LayoutParams.isDecor:boolean
        if (v0 != 0) /* goto L_001b */;
        _result = v2.removeViewAt(v1); // android.support.v4.view.ViewPager.removeViewAt -> void
        v1 = binOpLit8_0xd8(v1, -1);
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0002
        return;
    }

    private void setScrollState(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mScrollState; // android.support.v4.view.ViewPager.mScrollState:int
        if (v0 != v2) /* goto L_0005 */;
        return;
        v1.mScrollState = v2; // android.support.v4.view.ViewPager.mScrollState:int
        v0 = v1.mOnPageChangeListener; // android.support.v4.view.ViewPager.mOnPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        if (v0 == 0) /* goto L_0004 */;
        v0 = v1.mOnPageChangeListener; // android.support.v4.view.ViewPager.mOnPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        _result = android.support.v4.view.ViewPager$OnPageChangeListener.onPageScrollStateChanged(v0, v2); // -> void
        // goto L_0004
    }

    private void setScrollingCacheEnabled(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.mScrollingCacheEnabled; // android.support.v4.view.ViewPager.mScrollingCacheEnabled:boolean
        if (v0 == v2) /* goto L_0006 */;
        v1.mScrollingCacheEnabled = v2; // android.support.v4.view.ViewPager.mScrollingCacheEnabled:boolean
        return;
    }

    public void addFocusables(java.util.ArrayList p0, int p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (java.util.ArrayList), v8 = p1 (int), v9 = p2 (int)
        _result = v7.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        _result = v6.getDescendantFocusability(); // android.support.v4.view.ViewPager.getDescendantFocusability -> int
        v2 = _result;
        v0 = 0x00060000;
        if (v2 == v0) /* goto L_002f */;
        v0 = 0;
        _result = v6.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v3 = _result;
        if (v0 >= v3) /* goto L_002f */;
        _result = v6.getChildAt(v0); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v3 = _result;
        _result = v3.getVisibility(); // android.view.View.getVisibility -> int
        v4 = _result;
        if (v4 != 0) /* goto L_002c */;
        _result = v6.infoForChild(v3); // android.support.v4.view.ViewPager.infoForChild -> android.support.v4.view.ViewPager$ItemInfo
        v4 = _result;
        if (v4 == 0) /* goto L_002c */;
        v4 = v4.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v5 = v6.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v4 != v5) /* goto L_002c */;
        _result = v3.addFocusables(v7, v8, v9); // android.view.View.addFocusables -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_000d
        v0 = 0x00040000;
        if (v2 != v0) /* goto L_0039 */;
        _result = v7.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 != v0) /* goto L_003f */;
        _result = v6.isFocusable(); // android.support.v4.view.ViewPager.isFocusable -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0040 */;
        return;
        v0 = binOpLit8_0xdd(v9, 1);
        v1 = 1;
        if (v0 != v1) /* goto L_0051 */;
        _result = v6.isInTouchMode(); // android.support.v4.view.ViewPager.isInTouchMode -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0051 */;
        _result = v6.isFocusableInTouchMode(); // android.support.v4.view.ViewPager.isFocusableInTouchMode -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003f */;
        if (v7 == 0) /* goto L_003f */;
        _result = v7.add(v6); // java.util.ArrayList.add -> boolean
        // goto L_003f
    }

    android.support.v4.view.ViewPager$ItemInfo addNewItem(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v0 = new android.support.v4.view.ViewPager$ItemInfo;
        _result = v0.<init>(); // android.support.v4.view.ViewPager$ItemInfo.<init> -> void
        v0.position = v3; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v1 = v2.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v1.instantiateItem(v2, v3); // android.support.v4.view.PagerAdapter.instantiateItem -> java.lang.Object
        v1 = _result;
        v0.object = v1; // android.support.v4.view.ViewPager$ItemInfo.object:java.lang.Object
        v1 = v2.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v1.getPageWidth(v3); // android.support.v4.view.PagerAdapter.getPageWidth -> float
        v1 = _result;
        v0.widthFactor = v1; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        if (v4 < 0) /* goto L_0021 */;
        v1 = v2.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v4 < v1) /* goto L_0027 */;
        v1 = v2.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v1.add(v0); // java.util.ArrayList.add -> boolean
        return v0;
        v1 = v2.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v1.add(v4, v0); // java.util.ArrayList.add -> void
        // goto L_0026
    }

    public void addTouchables(java.util.ArrayList p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.util.ArrayList)
        v0 = 0;
        _result = v4.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_0023 */;
        _result = v4.getChildAt(v0); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v1 = _result;
        _result = v1.getVisibility(); // android.view.View.getVisibility -> int
        v2 = _result;
        if (v2 != 0) /* goto L_0020 */;
        _result = v4.infoForChild(v1); // android.support.v4.view.ViewPager.infoForChild -> android.support.v4.view.ViewPager$ItemInfo
        v2 = _result;
        if (v2 == 0) /* goto L_0020 */;
        v2 = v2.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v3 = v4.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v2 != v3) /* goto L_0020 */;
        _result = v1.addTouchables(v5); // android.view.View.addTouchables -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0001
        return;
    }

    public void addView(android.view.View p0, int p1, android.view.ViewGroup$LayoutParams p2) {
        // Registers (8 total): v4 = this, v5 = p0 (android.view.View), v6 = p1 (int), v7 = p2 (android.view.ViewGroup$LayoutParams)
        _result = v4.checkLayoutParams(v7); // android.support.v4.view.ViewPager.checkLayoutParams -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0031 */;
        _result = v4.generateLayoutParams(v7); // android.support.v4.view.ViewPager.generateLayoutParams -> android.view.ViewGroup$LayoutParams
        v1 = _result;
        v0 = v1;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        v2 = v0.isDecor; // android.support.v4.view.ViewPager$LayoutParams.isDecor:boolean
        v3 = (v5 instanceof android.support.v4.view.ViewPager$Decor);
        v2 = binOp2addr_0xb6(v2, v3);
        v0.isDecor = v2; // android.support.v4.view.ViewPager$LayoutParams.isDecor:boolean
        v2 = v4.mInLayout; // android.support.v4.view.ViewPager.mInLayout:boolean
        if (v2 == 0) /* goto L_002d */;
        if (v0 == 0) /* goto L_0026 */;
        v2 = v0.isDecor; // android.support.v4.view.ViewPager$LayoutParams.isDecor:boolean
        if (v2 == 0) /* goto L_0026 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Cannot add pager decor view during layout";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v2 = 1;
        v0.needsMeasure = v2; // android.support.v4.view.ViewPager$LayoutParams.needsMeasure:boolean
        _result = v4.addViewInLayout(v5, v6, v1); // android.support.v4.view.ViewPager.addViewInLayout -> boolean
        return;
        _result = v4.addView(v5, v6, v1); // android.view.ViewGroup.addView -> void
        // goto L_002c
        v1 = v7;
        // goto L_000a
    }

    public boolean arrowScroll(int p0) {
        // Registers (7 total): v5 = this, v6 = p0 (int)
        v4 = 66;
        v3 = 17;
        _result = v5.findFocus(); // android.support.v4.view.ViewPager.findFocus -> android.view.View
        v0 = _result;
        if (v0 != v5) /* goto L_000b */;
        v0 = 0;
        v1 = 0;
        _result = this.getInstance(); // android.view.FocusFinder.getInstance -> android.view.FocusFinder
        v2 = _result;
        _result = v2.findNextFocus(v5, v0, v6); // android.view.FocusFinder.findNextFocus -> android.view.View
        v2 = _result;
        if (v2 == 0) /* goto L_0061 */;
        if (v2 == v0) /* goto L_0061 */;
        if (v6 != v3) /* goto L_0041 */;
        v1 = v5.mTempRect; // android.support.v4.view.ViewPager.mTempRect:android.graphics.Rect
        _result = v5.getChildRectInPagerCoordinates(v1, v2); // android.support.v4.view.ViewPager.getChildRectInPagerCoordinates -> android.graphics.Rect
        v1 = _result;
        v1 = v1.left; // android.graphics.Rect.left:int
        v3 = v5.mTempRect; // android.support.v4.view.ViewPager.mTempRect:android.graphics.Rect
        _result = v5.getChildRectInPagerCoordinates(v3, v0); // android.support.v4.view.ViewPager.getChildRectInPagerCoordinates -> android.graphics.Rect
        v3 = _result;
        v3 = v3.left; // android.graphics.Rect.left:int
        if (v0 == 0) /* goto L_003c */;
        if (v1 < v3) /* goto L_003c */;
        _result = v5.pageLeft(); // android.support.v4.view.ViewPager.pageLeft -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003b */;
        _result = v6.getContantForFocusDirection(); // android.view.SoundEffectConstants.getContantForFocusDirection -> int
        v1 = _result;
        _result = v5.playSoundEffect(v1); // android.support.v4.view.ViewPager.playSoundEffect -> void
        return v0;
        _result = v2.requestFocus(); // android.view.View.requestFocus -> boolean
        v0 = _result;
        // goto L_0032
        if (v6 != v4) /* goto L_0075 */;
        v1 = v5.mTempRect; // android.support.v4.view.ViewPager.mTempRect:android.graphics.Rect
        _result = v5.getChildRectInPagerCoordinates(v1, v2); // android.support.v4.view.ViewPager.getChildRectInPagerCoordinates -> android.graphics.Rect
        v1 = _result;
        v1 = v1.left; // android.graphics.Rect.left:int
        v3 = v5.mTempRect; // android.support.v4.view.ViewPager.mTempRect:android.graphics.Rect
        _result = v5.getChildRectInPagerCoordinates(v3, v0); // android.support.v4.view.ViewPager.getChildRectInPagerCoordinates -> android.graphics.Rect
        v3 = _result;
        v3 = v3.left; // android.graphics.Rect.left:int
        if (v0 == 0) /* goto L_005c */;
        if (v1 > v3) /* goto L_005c */;
        _result = v5.pageRight(); // android.support.v4.view.ViewPager.pageRight -> boolean
        v0 = _result;
        // goto L_0032
        _result = v2.requestFocus(); // android.view.View.requestFocus -> boolean
        v0 = _result;
        // goto L_0032
        if (v6 == v3) /* goto L_0066 */;
        v0 = 1;
        if (v6 != v0) /* goto L_006b */;
        _result = v5.pageLeft(); // android.support.v4.view.ViewPager.pageLeft -> boolean
        v0 = _result;
        // goto L_0032
        if (v6 == v4) /* goto L_0070 */;
        v0 = 2;
        if (v6 != v0) /* goto L_0075 */;
        _result = v5.pageRight(); // android.support.v4.view.ViewPager.pageRight -> boolean
        v0 = _result;
        // goto L_0032
        v0 = v1;
        // goto L_0032
    }

    public boolean beginFakeDrag() {
        // Registers (10 total): v9 = this
        v8 = 1;
        v4 = 0;
        v5 = 0;
        v0 = v9.mIsBeingDragged; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        if (v0 == 0) /* goto L_0008 */;
        return v4;
        v9.mFakeDragging = v8; // android.support.v4.view.ViewPager.mFakeDragging:boolean
        _result = v9.setScrollState(v8); // android.support.v4.view.ViewPager.setScrollState -> void
        v9.mLastMotionX = v5; // android.support.v4.view.ViewPager.mLastMotionX:float
        v9.mInitialMotionX = v5; // android.support.v4.view.ViewPager.mInitialMotionX:float
        v0 = v9.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        if (v0 != 0) /* goto L_0032 */;
        _result = this.obtain(); // android.view.VelocityTracker.obtain -> android.view.VelocityTracker
        v0 = _result;
        v9.mVelocityTracker = v0; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        _result = this.uptimeMillis(); // android.os.SystemClock.uptimeMillis -> long
        v0 = _result;
        v2 = v0;
        v6 = v5;
        v7 = v4;
        _result = v0.obtain(v0..v7); // android.view.MotionEvent.obtain -> android.view.MotionEvent
        v2 = _result;
        v3 = v9.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        _result = v3.addMovement(v2); // android.view.VelocityTracker.addMovement -> void
        _result = v2.recycle(); // android.view.MotionEvent.recycle -> void
        v9.mFakeDragBeginTime = v0; // android.support.v4.view.ViewPager.mFakeDragBeginTime:long
        v4 = v8;
        // goto L_0007
        v0 = v9.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        _result = v0.clear(); // android.view.VelocityTracker.clear -> void
        // goto L_001b
    }

    protected boolean canScroll(android.view.View p0, boolean p1, int p2, int p3, int p4) {
        // Registers (16 total): v10 = this, v11 = p0 (android.view.View), v12 = p1 (boolean), v13 = p2 (int), v14 = p3 (int), v15 = p4 (int)
        v2 = 1;
        v0 = (v11 instanceof android.view.ViewGroup);
        if (v0 == 0) /* goto L_005a */;
        v6 = v11;
        v6 = (android.view.ViewGroup) v6;
        _result = v11.getScrollX(); // android.view.View.getScrollX -> int
        v8 = _result;
        _result = v11.getScrollY(); // android.view.View.getScrollY -> int
        v9 = _result;
        _result = v6.getChildCount(); // android.view.ViewGroup.getChildCount -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v7 = v0;
        if (v7 < 0) /* goto L_005a */;
        _result = v6.getChildAt(v7); // android.view.ViewGroup.getChildAt -> android.view.View
        v1 = _result;
        v0 = binOp_0x90(v14, v8);
        _result = v1.getLeft(); // android.view.View.getLeft -> int
        v3 = _result;
        if (v0 < v3) /* goto L_0056 */;
        v0 = binOp_0x90(v14, v8);
        _result = v1.getRight(); // android.view.View.getRight -> int
        v3 = _result;
        if (v0 >= v3) /* goto L_0056 */;
        v0 = binOp_0x90(v15, v9);
        _result = v1.getTop(); // android.view.View.getTop -> int
        v3 = _result;
        if (v0 < v3) /* goto L_0056 */;
        v0 = binOp_0x90(v15, v9);
        _result = v1.getBottom(); // android.view.View.getBottom -> int
        v3 = _result;
        if (v0 >= v3) /* goto L_0056 */;
        v0 = binOp_0x90(v14, v8);
        _result = v1.getLeft(); // android.view.View.getLeft -> int
        v3 = _result;
        v4 = binOp_0x91(v0, v3);
        v0 = binOp_0x90(v15, v9);
        _result = v1.getTop(); // android.view.View.getTop -> int
        v3 = _result;
        v5 = binOp_0x91(v0, v3);
        v0 = v10;
        v3 = v13;
        _result = v0.canScroll(v0..v5); // android.support.v4.view.ViewPager.canScroll -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0056 */;
        return v2;
        v0 = binOpLit8_0xd8(v7, -1);
        v7 = v0;
        // goto L_0017
        if (v12 == 0) /* goto L_0063 */;
        v0 = unaryOp_0x7b(v13);
        _result = v11.canScrollHorizontally(v0); // android.support.v4.view.ViewCompat.canScrollHorizontally -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0055 */;
        v2 = 0;
        // goto L_0055
    }

    protected boolean checkLayoutParams(android.view.ViewGroup$LayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$LayoutParams)
        v0 = (v2 instanceof android.support.v4.view.ViewPager$LayoutParams);
        if (v0 == 0) /* goto L_000c */;
        _result = v1.checkLayoutParams(v2); // android.view.ViewGroup.checkLayoutParams -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000b
    }

    public void computeScroll() {
        // Registers (5 total): v4 = this
        v0 = v4.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v0.isFinished(); // android.widget.Scroller.isFinished -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_003e */;
        v0 = v4.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v0.computeScrollOffset(); // android.widget.Scroller.computeScrollOffset -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003e */;
        _result = v4.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v0 = _result;
        _result = v4.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v1 = _result;
        v2 = v4.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v2.getCurrX(); // android.widget.Scroller.getCurrX -> int
        v2 = _result;
        v3 = v4.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v3.getCurrY(); // android.widget.Scroller.getCurrY -> int
        v3 = _result;
        if (v0 != v2) /* goto L_0028 */;
        if (v1 == v3) /* goto L_003a */;
        _result = v4.scrollTo(v2, v3); // android.support.v4.view.ViewPager.scrollTo -> void
        _result = v4.pageScrolled(v2); // android.support.v4.view.ViewPager.pageScrolled -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_003a */;
        v0 = v4.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v0.abortAnimation(); // android.widget.Scroller.abortAnimation -> void
        v0 = 0;
        _result = v4.scrollTo(v0, v3); // android.support.v4.view.ViewPager.scrollTo -> void
        _result = v4.postInvalidateOnAnimation(); // android.support.v4.view.ViewCompat.postInvalidateOnAnimation -> void
        return;
        _result = v4.completeScroll(); // android.support.v4.view.ViewPager.completeScroll -> void
        // goto L_003d
    }

    void dataSetChanged() {
        // Registers (10 total): v9 = this
        v1 = 1;
        v2 = 0;
        v0 = v9.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v3 = v9.mOffscreenPageLimit; // android.support.v4.view.ViewPager.mOffscreenPageLimit:int
        v3 = binOpLit8_0xda(v3, 2);
        v3 = binOpLit8_0xd8(v3, 1);
        if (v0 >= v3) /* goto L_004b */;
        v0 = v9.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v3 = v9.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v3.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v3 = _result;
        if (v0 >= v3) /* goto L_004b */;
        v0 = v1;
        v3 = v9.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v4 = v2;
        v5 = v3;
        v6 = v0;
        v3 = v2;
        v0 = v9.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_0097 */;
        v0 = v9.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v7 = v9.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v8 = v0.object; // android.support.v4.view.ViewPager$ItemInfo.object:java.lang.Object
        _result = v7.getItemPosition(v8); // android.support.v4.view.PagerAdapter.getItemPosition -> int
        v7 = _result;
        v8 = -1;
        if (v7 != v8) /* goto L_004d */;
        v0 = v3;
        v3 = v4;
        v4 = v5;
        v5 = v6;
        v0 = binOpLit8_0xd8(v0, 1);
        v6 = v5;
        v5 = v4;
        v4 = v3;
        v3 = v0;
        // goto L_0025
        v0 = v2;
        // goto L_001f
        v8 = -2;
        if (v7 != v8) /* goto L_0085 */;
        v6 = v9.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v6.remove(v3); // java.util.ArrayList.remove -> java.lang.Object
        v3 = binOpLit8_0xd8(v3, -1);
        if (v4 != 0) /* goto L_005f */;
        v4 = v9.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v4.startUpdate(v9); // android.support.v4.view.PagerAdapter.startUpdate -> void
        v4 = v1;
        v6 = v9.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v7 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v8 = v0.object; // android.support.v4.view.ViewPager$ItemInfo.object:java.lang.Object
        _result = v6.destroyItem(v9, v7, v8); // android.support.v4.view.PagerAdapter.destroyItem -> void
        v6 = v9.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v0 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v6 != v0) /* goto L_00d0 */;
        v0 = v9.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v5 = v9.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v5.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v5 = _result;
        v5 = binOpLit8_0xd8(v5, -1);
        _result = v0.min(v5); // java.lang.Math.min -> int
        v0 = _result;
        _result = v2.max(v0); // java.lang.Math.max -> int
        v5 = _result;
        v0 = v3;
        v3 = v4;
        v4 = v5;
        v5 = v1;
        // goto L_0044
        v8 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v8 == v7) /* goto L_00ca */;
        v6 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v8 = v9.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v6 != v8) /* goto L_0090 */;
        v5 = v7;
        v0.position = v7; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v0 = v3;
        v3 = v4;
        v4 = v5;
        v5 = v1;
        // goto L_0044
        if (v4 == 0) /* goto L_009e */;
        v0 = v9.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v0.finishUpdate(v9); // android.support.v4.view.PagerAdapter.finishUpdate -> void
        v0 = v9.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        v3 = android.support.v4.view.ViewPager.COMPARATOR; // :java.util.Comparator
        _result = v0.sort(v3); // java.util.Collections.sort -> void
        if (v6 == 0) /* goto L_00c9 */;
        _result = v9.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v4 = _result;
        v3 = v2;
        if (v3 >= v4) /* goto L_00c3 */;
        _result = v9.getChildAt(v3); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v0 = _result;
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        v6 = v0.isDecor; // android.support.v4.view.ViewPager$LayoutParams.isDecor:boolean
        if (v6 != 0) /* goto L_00bf */;
        v6 = 0;
        v0.widthFactor = v6; // android.support.v4.view.ViewPager$LayoutParams.widthFactor:float
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_00ac
        _result = v9.setCurrentItemInternal(v5, v2, v1); // android.support.v4.view.ViewPager.setCurrentItemInternal -> void
        _result = v9.requestLayout(); // android.support.v4.view.ViewPager.requestLayout -> void
        return;
        v0 = v3;
        v3 = v4;
        v4 = v5;
        v5 = v6;
        // goto L_0044
        v0 = v3;
        v3 = v4;
        v4 = v5;
        v5 = v1;
        // goto L_0044
    }

    public boolean dispatchKeyEvent(android.view.KeyEvent p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.KeyEvent)
        _result = v1.dispatchKeyEvent(v2); // android.view.ViewGroup.dispatchKeyEvent -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000c */;
        _result = v1.executeKeyEvent(v2); // android.support.v4.view.ViewPager.executeKeyEvent -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000e */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000d
    }

    public boolean dispatchPopulateAccessibilityEvent(android.view.accessibility.AccessibilityEvent p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.view.accessibility.AccessibilityEvent)
        v0 = 0;
        _result = v6.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v2 = _result;
        v1 = v0;
        if (v1 >= v2) /* goto L_0025 */;
        _result = v6.getChildAt(v1); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v3 = _result;
        _result = v3.getVisibility(); // android.view.View.getVisibility -> int
        v4 = _result;
        if (v4 != 0) /* goto L_0026 */;
        _result = v6.infoForChild(v3); // android.support.v4.view.ViewPager.infoForChild -> android.support.v4.view.ViewPager$ItemInfo
        v4 = _result;
        if (v4 == 0) /* goto L_0026 */;
        v4 = v4.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v5 = v6.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v4 != v5) /* goto L_0026 */;
        _result = v3.dispatchPopulateAccessibilityEvent(v7); // android.view.View.dispatchPopulateAccessibilityEvent -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0026 */;
        v0 = 1;
        return v0;
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0006
    }

    float distanceInfluenceForSnapDuration(float p0) {
        // Registers (6 total): v4 = this, v5 = p0 (float)
        v0 = 0x3f000000;
        v0 = binOp_0xa7(v5, v0);
        v0 = unaryOp_0x89(v0);
        v2 = 0x3fde28c7460698c7L;
        v0 = binOp2addr_0xcd(v0, v2);
        v0 = unaryOp_0x8c(v0);
        v0 = unaryOp_0x89(v0);
        _result = v0.sin(v1); // java.lang.Math.sin -> double
        v0 = _result;
        v0 = unaryOp_0x8c(v0);
        return v0;
    }

    public void draw(android.graphics.Canvas p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.graphics.Canvas)
        v2 = 1;
        _result = v7.draw(v8); // android.view.ViewGroup.draw -> void
        v0 = 0;
        _result = v7.getOverScrollMode(); // android.support.v4.view.ViewCompat.getOverScrollMode -> int
        v1 = _result;
        if (v1 == 0) /* goto L_0019 */;
        if (v1 != v2) /* goto L_00a2 */;
        v1 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        if (v1 == 0) /* goto L_00a2 */;
        v1 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v1.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v1 = _result;
        if (v1 <= v2) /* goto L_00a2 */;
        v1 = v7.mLeftEdge; // android.support.v4.view.ViewPager.mLeftEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v1.isFinished(); // android.support.v4.widget.EdgeEffectCompat.isFinished -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0059 */;
        _result = v8.save(); // android.graphics.Canvas.save -> int
        v1 = _result;
        _result = v7.getHeight(); // android.support.v4.view.ViewPager.getHeight -> int
        v2 = _result;
        _result = v7.getPaddingTop(); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v3 = _result;
        v2 = binOp2addr_0xb1(v2, v3);
        _result = v7.getPaddingBottom(); // android.support.v4.view.ViewPager.getPaddingBottom -> int
        v3 = _result;
        v2 = binOp2addr_0xb1(v2, v3);
        _result = v7.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v3 = _result;
        v4 = 0x43870000;
        _result = v8.rotate(v4); // android.graphics.Canvas.rotate -> void
        v4 = unaryOp_0x7b(v2);
        _result = v7.getPaddingTop(); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v5 = _result;
        v4 = binOp2addr_0xb0(v4, v5);
        v4 = unaryOp_0x82(v4);
        v5 = v7.mFirstOffset; // android.support.v4.view.ViewPager.mFirstOffset:float
        v6 = unaryOp_0x82(v3);
        v5 = binOp2addr_0xc8(v5, v6);
        _result = v8.translate(v4, v5); // android.graphics.Canvas.translate -> void
        v4 = v7.mLeftEdge; // android.support.v4.view.ViewPager.mLeftEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v4.setSize(v2, v3); // android.support.v4.widget.EdgeEffectCompat.setSize -> void
        v2 = v7.mLeftEdge; // android.support.v4.view.ViewPager.mLeftEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v2.draw(v8); // android.support.v4.widget.EdgeEffectCompat.draw -> boolean
        v2 = _result;
        v0 = binOp2addr_0xb6(v0, v2);
        _result = v8.restoreToCount(v1); // android.graphics.Canvas.restoreToCount -> void
        v1 = v7.mRightEdge; // android.support.v4.view.ViewPager.mRightEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v1.isFinished(); // android.support.v4.widget.EdgeEffectCompat.isFinished -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_009c */;
        _result = v8.save(); // android.graphics.Canvas.save -> int
        v1 = _result;
        _result = v7.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v2 = _result;
        _result = v7.getHeight(); // android.support.v4.view.ViewPager.getHeight -> int
        v3 = _result;
        _result = v7.getPaddingTop(); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v4 = _result;
        v3 = binOp2addr_0xb1(v3, v4);
        _result = v7.getPaddingBottom(); // android.support.v4.view.ViewPager.getPaddingBottom -> int
        v4 = _result;
        v3 = binOp2addr_0xb1(v3, v4);
        v4 = 0x42b40000;
        _result = v8.rotate(v4); // android.graphics.Canvas.rotate -> void
        _result = v7.getPaddingTop(); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v4 = _result;
        v4 = unaryOp_0x7b(v4);
        v4 = unaryOp_0x82(v4);
        v5 = v7.mLastOffset; // android.support.v4.view.ViewPager.mLastOffset:float
        v6 = 0x3f800000;
        v5 = binOp2addr_0xc6(v5, v6);
        v5 = unaryOp_0x7f(v5);
        v6 = unaryOp_0x82(v2);
        v5 = binOp2addr_0xc8(v5, v6);
        _result = v8.translate(v4, v5); // android.graphics.Canvas.translate -> void
        v4 = v7.mRightEdge; // android.support.v4.view.ViewPager.mRightEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v4.setSize(v3, v2); // android.support.v4.widget.EdgeEffectCompat.setSize -> void
        v2 = v7.mRightEdge; // android.support.v4.view.ViewPager.mRightEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v2.draw(v8); // android.support.v4.widget.EdgeEffectCompat.draw -> boolean
        v2 = _result;
        v0 = binOp2addr_0xb6(v0, v2);
        _result = v8.restoreToCount(v1); // android.graphics.Canvas.restoreToCount -> void
        if (v0 == 0) /* goto L_00a1 */;
        _result = v7.postInvalidateOnAnimation(); // android.support.v4.view.ViewCompat.postInvalidateOnAnimation -> void
        return;
        v1 = v7.mLeftEdge; // android.support.v4.view.ViewPager.mLeftEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v1.finish(); // android.support.v4.widget.EdgeEffectCompat.finish -> void
        v1 = v7.mRightEdge; // android.support.v4.view.ViewPager.mRightEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v1.finish(); // android.support.v4.widget.EdgeEffectCompat.finish -> void
        // goto L_009c
    }

    protected void drawableStateChanged() {
        // Registers (3 total): v2 = this
        _result = v2.drawableStateChanged(); // android.view.ViewGroup.drawableStateChanged -> void
        v0 = v2.mMarginDrawable; // android.support.v4.view.ViewPager.mMarginDrawable:android.graphics.drawable.Drawable
        if (v0 == 0) /* goto L_0014 */;
        _result = v0.isStateful(); // android.graphics.drawable.Drawable.isStateful -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0014 */;
        _result = v2.getDrawableState(); // android.support.v4.view.ViewPager.getDrawableState -> int[]
        v1 = _result;
        _result = v0.setState(v1); // android.graphics.drawable.Drawable.setState -> boolean
        return;
    }

    public void endFakeDrag() {
        // Registers (7 total): v6 = this
        v5 = 1;
        v0 = v6.mFakeDragging; // android.support.v4.view.ViewPager.mFakeDragging:boolean
        if (v0 != 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "No fake drag in progress. Call beginFakeDrag first.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v6.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        v1 = 1000;
        v2 = v6.mMaximumVelocity; // android.support.v4.view.ViewPager.mMaximumVelocity:int
        v2 = unaryOp_0x82(v2);
        _result = v0.computeCurrentVelocity(v1, v2); // android.view.VelocityTracker.computeCurrentVelocity -> void
        v1 = v6.mActivePointerId; // android.support.v4.view.ViewPager.mActivePointerId:int
        _result = v0.getXVelocity(v1); // android.support.v4.view.VelocityTrackerCompat.getXVelocity -> float
        v0 = _result;
        v0 = unaryOp_0x87(v0);
        v6.mPopulatePending = v5; // android.support.v4.view.ViewPager.mPopulatePending:boolean
        _result = v6.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v1 = _result;
        _result = v6.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v2 = _result;
        _result = v6.infoForCurrentScrollPosition(); // android.support.v4.view.ViewPager.infoForCurrentScrollPosition -> android.support.v4.view.ViewPager$ItemInfo
        v3 = _result;
        v4 = v3.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v2 = unaryOp_0x82(v2);
        v1 = unaryOp_0x82(v1);
        v1 = binOp_0xa9(v2, v1);
        v2 = v3.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v1 = binOp2addr_0xc7(v1, v2);
        v2 = v3.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v1 = binOp2addr_0xc9(v1, v2);
        v2 = v6.mLastMotionX; // android.support.v4.view.ViewPager.mLastMotionX:float
        v3 = v6.mInitialMotionX; // android.support.v4.view.ViewPager.mInitialMotionX:float
        v2 = binOp2addr_0xc7(v2, v3);
        v2 = unaryOp_0x87(v2);
        _result = v6.determineTargetPage(v4, v1, v0, v2); // android.support.v4.view.ViewPager.determineTargetPage -> int
        v1 = _result;
        _result = v6.setCurrentItemInternal(v1, v5, v5, v0); // android.support.v4.view.ViewPager.setCurrentItemInternal -> void
        _result = v6.endDrag(); // android.support.v4.view.ViewPager.endDrag -> void
        v0 = 0;
        v6.mFakeDragging = v0; // android.support.v4.view.ViewPager.mFakeDragging:boolean
        return;
    }

    public boolean executeKeyEvent(android.view.KeyEvent p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.view.KeyEvent)
        v3 = 1;
        v0 = 0;
        _result = v5.getAction(); // android.view.KeyEvent.getAction -> int
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v5.getKeyCode(); // android.view.KeyEvent.getKeyCode -> int
        v1 = _result;
        // switch(v1)
        return v0;
        v0 = 17;
        _result = v4.arrowScroll(v0); // android.support.v4.view.ViewPager.arrowScroll -> boolean
        v0 = _result;
        // goto L_000f
        v0 = 66;
        _result = v4.arrowScroll(v0); // android.support.v4.view.ViewPager.arrowScroll -> boolean
        v0 = _result;
        // goto L_000f
        v1 = android.os.Build$VERSION.SDK_INT; // :int
        v2 = 11;
        if (v1 < v2) /* goto L_000f */;
        _result = v5.hasNoModifiers(); // android.support.v4.view.KeyEventCompat.hasNoModifiers -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0030 */;
        v0 = 2;
        _result = v4.arrowScroll(v0); // android.support.v4.view.ViewPager.arrowScroll -> boolean
        v0 = _result;
        // goto L_000f
        _result = v5.hasModifiers(v3); // android.support.v4.view.KeyEventCompat.hasModifiers -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_000f */;
        _result = v4.arrowScroll(v3); // android.support.v4.view.ViewPager.arrowScroll -> boolean
        v0 = _result;
        // goto L_000f
    }

    public void fakeDragBy(float p0) {
        // Registers (10 total): v8 = this, v9 = p0 (float)
        v7 = 0;
        v0 = v8.mFakeDragging; // android.support.v4.view.ViewPager.mFakeDragging:boolean
        if (v0 != 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "No fake drag in progress. Call beginFakeDrag first.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v8.mLastMotionX; // android.support.v4.view.ViewPager.mLastMotionX:float
        v0 = binOp2addr_0xc6(v0, v9);
        v8.mLastMotionX = v0; // android.support.v4.view.ViewPager.mLastMotionX:float
        _result = v8.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v0 = _result;
        v0 = unaryOp_0x82(v0);
        v3 = binOp_0xa7(v0, v9);
        _result = v8.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v5 = _result;
        v0 = unaryOp_0x82(v5);
        v1 = v8.mFirstOffset; // android.support.v4.view.ViewPager.mFirstOffset:float
        v2 = binOp_0xa8(v0, v1);
        v0 = unaryOp_0x82(v5);
        v1 = v8.mLastOffset; // android.support.v4.view.ViewPager.mLastOffset:float
        v4 = binOp_0xa8(v0, v1);
        v0 = v8.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v7); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v1 = v8.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        v6 = v8.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v6.size(); // java.util.ArrayList.size -> int
        v6 = _result;
        v6 = binOpLit8_0xd8(v6, -1);
        _result = v1.get(v6); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.view.ViewPager$ItemInfo) v1;
        v6 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v6 == 0) /* goto L_0091 */;
        v0 = v0.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v2 = unaryOp_0x82(v5);
        v0 = binOp2addr_0xc8(v0, v2);
        v2 = v1.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v6 = v8.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v6.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v6 = _result;
        v6 = binOpLit8_0xd8(v6, -1);
        if (v2 == v6) /* goto L_008f */;
        v1 = v1.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v2 = unaryOp_0x82(v5);
        v1 = binOp2addr_0xc8(v1, v2);
        v2 = cmp(v3, v0);
        if (v2 >= 0) /* goto L_0087 */;
        v1 = v8.mLastMotionX; // android.support.v4.view.ViewPager.mLastMotionX:float
        v2 = unaryOp_0x87(v0);
        v2 = unaryOp_0x82(v2);
        v2 = binOp_0xa7(v0, v2);
        v1 = binOp2addr_0xc6(v1, v2);
        v8.mLastMotionX = v1; // android.support.v4.view.ViewPager.mLastMotionX:float
        v1 = unaryOp_0x87(v0);
        _result = v8.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v2 = _result;
        _result = v8.scrollTo(v1, v2); // android.support.v4.view.ViewPager.scrollTo -> void
        v0 = unaryOp_0x87(v0);
        _result = v8.pageScrolled(v0); // android.support.v4.view.ViewPager.pageScrolled -> boolean
        _result = this.uptimeMillis(); // android.os.SystemClock.uptimeMillis -> long
        v2 = _result;
        v0 = v8.mFakeDragBeginTime; // android.support.v4.view.ViewPager.mFakeDragBeginTime:long
        v4 = 2;
        v5 = v8.mLastMotionX; // android.support.v4.view.ViewPager.mLastMotionX:float
        v6 = 0;
        _result = v0.obtain(v0..v7); // android.view.MotionEvent.obtain -> android.view.MotionEvent
        v0 = _result;
        v1 = v8.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        _result = v1.addMovement(v0); // android.view.VelocityTracker.addMovement -> void
        _result = v0.recycle(); // android.view.MotionEvent.recycle -> void
        return;
        v0 = cmp(v3, v1);
        if (v0 <= 0) /* goto L_008d */;
        v0 = v1;
        // goto L_005b
        v0 = v3;
        // goto L_005b
        v1 = v4;
        // goto L_0057
        v0 = v2;
        // goto L_0047
    }

    protected android.view.ViewGroup$LayoutParams generateDefaultLayoutParams() {
        // Registers (2 total): v1 = this
        v0 = new android.support.v4.view.ViewPager$LayoutParams;
        _result = v0.<init>(); // android.support.v4.view.ViewPager$LayoutParams.<init> -> void
        return v0;
    }

    public android.view.ViewGroup$LayoutParams generateLayoutParams(android.util.AttributeSet p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.util.AttributeSet)
        v0 = new android.support.v4.view.ViewPager$LayoutParams;
        _result = v2.getContext(); // android.support.v4.view.ViewPager.getContext -> android.content.Context
        v1 = _result;
        _result = v0.<init>(v1, v3); // android.support.v4.view.ViewPager$LayoutParams.<init> -> void
        return v0;
    }

    protected android.view.ViewGroup$LayoutParams generateLayoutParams(android.view.ViewGroup$LayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$LayoutParams)
        _result = v1.generateDefaultLayoutParams(); // android.support.v4.view.ViewPager.generateDefaultLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        return v0;
    }

    public android.support.v4.view.PagerAdapter getAdapter() {
        // Registers (2 total): v1 = this
        v0 = v1.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        return v0;
    }

    public int getCurrentItem() {
        // Registers (2 total): v1 = this
        v0 = v1.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        return v0;
    }

    public int getOffscreenPageLimit() {
        // Registers (2 total): v1 = this
        v0 = v1.mOffscreenPageLimit; // android.support.v4.view.ViewPager.mOffscreenPageLimit:int
        return v0;
    }

    public int getPageMargin() {
        // Registers (2 total): v1 = this
        v0 = v1.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        return v0;
    }

    android.support.v4.view.ViewPager$ItemInfo infoForAnyChild(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        _result = v3.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v0 = _result;
        if (v0 == v2) /* goto L_0012 */;
        if (v0 == 0) /* goto L_000c */;
        v1 = (v0 instanceof android.view.View);
        if (v1 != 0) /* goto L_000e */;
        v0 = 0;
        return v0;
        v0 = (android.view.View) v0;
        v3 = v0;
        // goto L_0000
        _result = v2.infoForChild(v3); // android.support.v4.view.ViewPager.infoForChild -> android.support.v4.view.ViewPager$ItemInfo
        v0 = _result;
        // goto L_000d
    }

    android.support.v4.view.ViewPager$ItemInfo infoForChild(android.view.View p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.view.View)
        v0 = 0;
        v1 = v0;
        v0 = v4.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0021 */;
        v0 = v4.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v2 = v4.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v3 = v0.object; // android.support.v4.view.ViewPager$ItemInfo.object:java.lang.Object
        _result = v2.isViewFromObject(v5, v3); // android.support.v4.view.PagerAdapter.isViewFromObject -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_001d */;
        return v0;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0002
        v0 = 0;
        // goto L_001c
    }

    android.support.v4.view.ViewPager$ItemInfo infoForPosition(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = 0;
        v1 = v0;
        v0 = v3.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001b */;
        v0 = v3.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v2 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v2 != v4) /* goto L_0017 */;
        return v0;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0002
        v0 = 0;
        // goto L_0016
    }

    void initViewPager() {
        // Registers (5 total): v4 = this
        v3 = 1;
        v0 = 0;
        _result = v4.setWillNotDraw(v0); // android.support.v4.view.ViewPager.setWillNotDraw -> void
        v0 = 0x00040000;
        _result = v4.setDescendantFocusability(v0); // android.support.v4.view.ViewPager.setDescendantFocusability -> void
        _result = v4.setFocusable(v3); // android.support.v4.view.ViewPager.setFocusable -> void
        _result = v4.getContext(); // android.support.v4.view.ViewPager.getContext -> android.content.Context
        v0 = _result;
        v1 = new android.widget.Scroller;
        v2 = android.support.v4.view.ViewPager.sInterpolator; // :android.view.animation.Interpolator
        _result = v1.<init>(v0, v2); // android.widget.Scroller.<init> -> void
        v4.mScroller = v1; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v0.get(); // android.view.ViewConfiguration.get -> android.view.ViewConfiguration
        v1 = _result;
        _result = v1.getScaledPagingTouchSlop(); // android.support.v4.view.ViewConfigurationCompat.getScaledPagingTouchSlop -> int
        v2 = _result;
        v4.mTouchSlop = v2; // android.support.v4.view.ViewPager.mTouchSlop:int
        _result = v1.getScaledMinimumFlingVelocity(); // android.view.ViewConfiguration.getScaledMinimumFlingVelocity -> int
        v2 = _result;
        v4.mMinimumVelocity = v2; // android.support.v4.view.ViewPager.mMinimumVelocity:int
        _result = v1.getScaledMaximumFlingVelocity(); // android.view.ViewConfiguration.getScaledMaximumFlingVelocity -> int
        v1 = _result;
        v4.mMaximumVelocity = v1; // android.support.v4.view.ViewPager.mMaximumVelocity:int
        v1 = new android.support.v4.widget.EdgeEffectCompat;
        _result = v1.<init>(v0); // android.support.v4.widget.EdgeEffectCompat.<init> -> void
        v4.mLeftEdge = v1; // android.support.v4.view.ViewPager.mLeftEdge:android.support.v4.widget.EdgeEffectCompat
        v1 = new android.support.v4.widget.EdgeEffectCompat;
        _result = v1.<init>(v0); // android.support.v4.widget.EdgeEffectCompat.<init> -> void
        v4.mRightEdge = v1; // android.support.v4.view.ViewPager.mRightEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v0.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v0 = _result;
        v0 = v0.density; // android.util.DisplayMetrics.density:float
        v1 = 0x41c80000;
        v1 = binOp2addr_0xc8(v1, v0);
        v1 = unaryOp_0x87(v1);
        v4.mFlingDistance = v1; // android.support.v4.view.ViewPager.mFlingDistance:int
        v1 = 0x40000000;
        v1 = binOp2addr_0xc8(v1, v0);
        v1 = unaryOp_0x87(v1);
        v4.mCloseEnough = v1; // android.support.v4.view.ViewPager.mCloseEnough:int
        v1 = 0x41800000;
        v0 = binOp2addr_0xc8(v0, v1);
        v0 = unaryOp_0x87(v0);
        v4.mDefaultGutterSize = v0; // android.support.v4.view.ViewPager.mDefaultGutterSize:int
        v0 = new android.support.v4.view.ViewPager$MyAccessibilityDelegate;
        _result = v0.<init>(v4); // android.support.v4.view.ViewPager$MyAccessibilityDelegate.<init> -> void
        _result = v4.setAccessibilityDelegate(v0); // android.support.v4.view.ViewCompat.setAccessibilityDelegate -> void
        _result = v4.getImportantForAccessibility(); // android.support.v4.view.ViewCompat.getImportantForAccessibility -> int
        v0 = _result;
        if (v0 != 0) /* goto L_006b */;
        _result = v4.setImportantForAccessibility(v3); // android.support.v4.view.ViewCompat.setImportantForAccessibility -> void
        return;
    }

    public boolean isFakeDragging() {
        // Registers (2 total): v1 = this
        v0 = v1.mFakeDragging; // android.support.v4.view.ViewPager.mFakeDragging:boolean
        return v0;
    }

    protected void onAttachedToWindow() {
        // Registers (2 total): v1 = this
        _result = v1.onAttachedToWindow(); // android.view.ViewGroup.onAttachedToWindow -> void
        v0 = 1;
        v1.mFirstLayout = v0; // android.support.v4.view.ViewPager.mFirstLayout:boolean
        return;
    }

    protected void onDraw(android.graphics.Canvas p0) {
        // Registers (18 total): v16 = this, v17 = p0 (android.graphics.Canvas)
        _result = v16.onDraw(v16..v17); // android.view.ViewGroup.onDraw -> void
        v0 = v16;
        v1 = v0.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        if (v1 <= 0) /* goto L_00b2 */;
        v0 = v16;
        v1 = v0.mMarginDrawable; // android.support.v4.view.ViewPager.mMarginDrawable:android.graphics.drawable.Drawable
        if (v1 == 0) /* goto L_00b2 */;
        v0 = v16;
        v1 = v0.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_00b2 */;
        v0 = v16;
        v1 = v0.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        if (v1 == 0) /* goto L_00b2 */;
        _result = v16.getScrollX(v16..v16); // android.support.v4.view.ViewPager.getScrollX -> int
        v6 = _result;
        _result = v16.getWidth(v16..v16); // android.support.v4.view.ViewPager.getWidth -> int
        v7 = _result;
        v0 = v16;
        v1 = v0.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        v1 = unaryOp_0x82(v1);
        v2 = unaryOp_0x82(v7);
        v8 = binOp_0xa9(v1, v2);
        v5 = 0;
        v0 = v16;
        v1 = v0.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        v2 = 0;
        _result = v1.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.view.ViewPager$ItemInfo) v1;
        v4 = v1.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v0 = v16;
        v2 = v0.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v9 = _result;
        v3 = v1.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v0 = v16;
        v2 = v0.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        v10 = binOpLit8_0xd8(v9, -1);
        _result = v2.get(v10); // java.util.ArrayList.get -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.view.ViewPager$ItemInfo) v2;
        v10 = v2.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v2 = v5;
        v5 = v3;
        if (v5 >= v10) /* goto L_00b2 */;
        v3 = v1.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v5 <= v3) /* goto L_006c */;
        if (v2 >= v9) /* goto L_006c */;
        v0 = v16;
        v1 = v0.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        v2 = binOpLit8_0xd8(v2, 1);
        _result = v1.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.view.ViewPager$ItemInfo) v1;
        // goto L_0059
        v3 = v1.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v5 != v3) /* goto L_00b3 */;
        v3 = v1.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v4 = v1.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v3 = binOp2addr_0xc6(v3, v4);
        v4 = unaryOp_0x82(v7);
        v3 = binOp2addr_0xc8(v3, v4);
        v4 = v1.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v11 = v1.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v4 = binOp2addr_0xc6(v4, v11);
        v4 = binOp2addr_0xc6(v4, v8);
        v0 = v16;
        v11 = v0.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        v11 = unaryOp_0x82(v11);
        v11 = binOp2addr_0xc6(v11, v3);
        v12 = unaryOp_0x82(v6);
        v11 = cmp(v11, v12);
        if (v11 <= 0) /* goto L_00ab */;
        v0 = v16;
        v11 = v0.mMarginDrawable; // android.support.v4.view.ViewPager.mMarginDrawable:android.graphics.drawable.Drawable
        v12 = unaryOp_0x87(v3);
        v0 = v16;
        v13 = v0.mTopPageBounds; // android.support.v4.view.ViewPager.mTopPageBounds:int
        v0 = v16;
        v14 = v0.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        v14 = unaryOp_0x82(v14);
        v14 = binOp2addr_0xc6(v14, v3);
        v15 = 0x3f000000;
        v14 = binOp2addr_0xc6(v14, v15);
        v14 = unaryOp_0x87(v14);
        v0 = v16;
        v15 = v0.mBottomPageBounds; // android.support.v4.view.ViewPager.mBottomPageBounds:int
        _result = v11.setBounds(v12, v13, v14, v15); // android.graphics.drawable.Drawable.setBounds -> void
        v0 = v16;
        v11 = v0.mMarginDrawable; // android.support.v4.view.ViewPager.mMarginDrawable:android.graphics.drawable.Drawable
        v0 = v17;
        _result = v11.draw(v0); // android.graphics.drawable.Drawable.draw -> void
        v11 = binOp_0x90(v6, v7);
        v11 = unaryOp_0x82(v11);
        v3 = cmp(v3, v11);
        if (v3 <= 0) /* goto L_00c2 */;
        return;
        v0 = v16;
        v3 = v0.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v3.getPageWidth(v5); // android.support.v4.view.PagerAdapter.getPageWidth -> float
        v11 = _result;
        v3 = binOp_0xa6(v4, v11);
        v12 = unaryOp_0x82(v7);
        v3 = binOp2addr_0xc8(v3, v12);
        v11 = binOp2addr_0xc6(v11, v8);
        v4 = binOp2addr_0xc6(v4, v11);
        // goto L_007d
        v3 = binOpLit8_0xd8(v5, 1);
        v5 = v3;
        // goto L_0057
    }

    public boolean onInterceptTouchEvent(android.view.MotionEvent p0) {
        // Registers (15 total): v13 = this, v14 = p0 (android.view.MotionEvent)
        v3 = -1;
        v12 = 0;
        v6 = 1;
        v2 = 0;
        _result = v14.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        v0 = binOpLit16_0xd5(v0, 255);
        v1 = 3;
        if (v0 == v1) /* goto L_000f */;
        if (v0 != v6) /* goto L_0022 */;
        v13.mIsBeingDragged = v2; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        v13.mIsUnableToDrag = v2; // android.support.v4.view.ViewPager.mIsUnableToDrag:boolean
        v13.mActivePointerId = v3; // android.support.v4.view.ViewPager.mActivePointerId:int
        v0 = v13.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        if (v0 == 0) /* goto L_0021 */;
        v0 = v13.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        _result = v0.recycle(); // android.view.VelocityTracker.recycle -> void
        v0 = 0;
        v13.mVelocityTracker = v0; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        return v2;
        if (v0 == 0) /* goto L_002e */;
        v1 = v13.mIsBeingDragged; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        if (v1 == 0) /* goto L_002a */;
        v2 = v6;
        // goto L_0021
        v1 = v13.mIsUnableToDrag; // android.support.v4.view.ViewPager.mIsUnableToDrag:boolean
        if (v1 != 0) /* goto L_0021 */;
        // switch(v0)
        v0 = v13.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        if (v0 != 0) /* goto L_003b */;
        _result = this.obtain(); // android.view.VelocityTracker.obtain -> android.view.VelocityTracker
        v0 = _result;
        v13.mVelocityTracker = v0; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        v0 = v13.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        _result = v0.addMovement(v14); // android.view.VelocityTracker.addMovement -> void
        v2 = v13.mIsBeingDragged; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        // goto L_0021
        v0 = v13.mActivePointerId; // android.support.v4.view.ViewPager.mActivePointerId:int
        if (v0 == v3) /* goto L_0031 */;
        _result = v14.findPointerIndex(v0); // android.support.v4.view.MotionEventCompat.findPointerIndex -> int
        v0 = _result;
        _result = v14.getX(v0); // android.support.v4.view.MotionEventCompat.getX -> float
        v7 = _result;
        v1 = v13.mLastMotionX; // android.support.v4.view.ViewPager.mLastMotionX:float
        v8 = binOp_0xa7(v7, v1);
        _result = v8.abs(); // java.lang.Math.abs -> float
        v9 = _result;
        _result = v14.getY(v0); // android.support.v4.view.MotionEventCompat.getY -> float
        v10 = _result;
        v0 = v13.mLastMotionY; // android.support.v4.view.ViewPager.mLastMotionY:float
        v0 = binOp_0xa7(v10, v0);
        _result = v0.abs(); // java.lang.Math.abs -> float
        v11 = _result;
        v0 = cmp(v8, v12);
        if (v0 == 0) /* goto L_0083 */;
        v0 = v13.mLastMotionX; // android.support.v4.view.ViewPager.mLastMotionX:float
        _result = v13.isGutterDrag(v0, v8); // android.support.v4.view.ViewPager.isGutterDrag -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0083 */;
        v3 = unaryOp_0x87(v8);
        v4 = unaryOp_0x87(v7);
        v5 = unaryOp_0x87(v10);
        v0 = v13;
        v1 = v13;
        _result = v0.canScroll(v0..v5); // android.support.v4.view.ViewPager.canScroll -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0083 */;
        v13.mLastMotionX = v7; // android.support.v4.view.ViewPager.mLastMotionX:float
        v13.mInitialMotionX = v7; // android.support.v4.view.ViewPager.mInitialMotionX:float
        v13.mLastMotionY = v10; // android.support.v4.view.ViewPager.mLastMotionY:float
        v13.mIsUnableToDrag = v6; // android.support.v4.view.ViewPager.mIsUnableToDrag:boolean
        // goto L_0021
        v0 = v13.mTouchSlop; // android.support.v4.view.ViewPager.mTouchSlop:int
        v0 = unaryOp_0x82(v0);
        v0 = cmp(v9, v0);
        if (v0 <= 0) /* goto L_00b7 */;
        v0 = cmp(v9, v11);
        if (v0 <= 0) /* goto L_00b7 */;
        v13.mIsBeingDragged = v6; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        _result = v13.setScrollState(v6); // android.support.v4.view.ViewPager.setScrollState -> void
        v0 = cmp(v8, v12);
        if (v0 <= 0) /* goto L_00b0 */;
        v0 = v13.mInitialMotionX; // android.support.v4.view.ViewPager.mInitialMotionX:float
        v1 = v13.mTouchSlop; // android.support.v4.view.ViewPager.mTouchSlop:int
        v1 = unaryOp_0x82(v1);
        v0 = binOp2addr_0xc6(v0, v1);
        v13.mLastMotionX = v0; // android.support.v4.view.ViewPager.mLastMotionX:float
        _result = v13.setScrollingCacheEnabled(v6); // android.support.v4.view.ViewPager.setScrollingCacheEnabled -> void
        v0 = v13.mIsBeingDragged; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        if (v0 == 0) /* goto L_0031 */;
        _result = v13.performDrag(v7); // android.support.v4.view.ViewPager.performDrag -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0031 */;
        _result = v13.postInvalidateOnAnimation(); // android.support.v4.view.ViewCompat.postInvalidateOnAnimation -> void
        // goto L_0031
        v0 = v13.mInitialMotionX; // android.support.v4.view.ViewPager.mInitialMotionX:float
        v1 = v13.mTouchSlop; // android.support.v4.view.ViewPager.mTouchSlop:int
        v1 = unaryOp_0x82(v1);
        v0 = binOp2addr_0xc7(v0, v1);
        // goto L_009d
        v0 = v13.mTouchSlop; // android.support.v4.view.ViewPager.mTouchSlop:int
        v0 = unaryOp_0x82(v0);
        v0 = cmp(v11, v0);
        if (v0 <= 0) /* goto L_00a2 */;
        v13.mIsUnableToDrag = v6; // android.support.v4.view.ViewPager.mIsUnableToDrag:boolean
        // goto L_00a2
        _result = v14.getX(); // android.view.MotionEvent.getX -> float
        v0 = _result;
        v13.mInitialMotionX = v0; // android.support.v4.view.ViewPager.mInitialMotionX:float
        v13.mLastMotionX = v0; // android.support.v4.view.ViewPager.mLastMotionX:float
        _result = v14.getY(); // android.view.MotionEvent.getY -> float
        v0 = _result;
        v13.mLastMotionY = v0; // android.support.v4.view.ViewPager.mLastMotionY:float
        _result = v14.getPointerId(v2); // android.support.v4.view.MotionEventCompat.getPointerId -> int
        v0 = _result;
        v13.mActivePointerId = v0; // android.support.v4.view.ViewPager.mActivePointerId:int
        v13.mIsUnableToDrag = v2; // android.support.v4.view.ViewPager.mIsUnableToDrag:boolean
        v0 = v13.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v0.computeScrollOffset(); // android.widget.Scroller.computeScrollOffset -> boolean
        v0 = v13.mScrollState; // android.support.v4.view.ViewPager.mScrollState:int
        v1 = 2;
        if (v0 != v1) /* goto L_0107 */;
        v0 = v13.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v0.getFinalX(); // android.widget.Scroller.getFinalX -> int
        v0 = _result;
        v1 = v13.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v1.getCurrX(); // android.widget.Scroller.getCurrX -> int
        v1 = _result;
        v0 = binOp2addr_0xb1(v0, v1);
        _result = v0.abs(); // java.lang.Math.abs -> int
        v0 = _result;
        v1 = v13.mCloseEnough; // android.support.v4.view.ViewPager.mCloseEnough:int
        if (v0 <= v1) /* goto L_0107 */;
        v0 = v13.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v0.abortAnimation(); // android.widget.Scroller.abortAnimation -> void
        v13.mPopulatePending = v2; // android.support.v4.view.ViewPager.mPopulatePending:boolean
        _result = v13.populate(); // android.support.v4.view.ViewPager.populate -> void
        v13.mIsBeingDragged = v6; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        _result = v13.setScrollState(v6); // android.support.v4.view.ViewPager.setScrollState -> void
        // goto L_0031
        _result = v13.completeScroll(); // android.support.v4.view.ViewPager.completeScroll -> void
        v13.mIsBeingDragged = v2; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        // goto L_0031
        _result = v13.onSecondaryPointerUp(v14); // android.support.v4.view.ViewPager.onSecondaryPointerUp -> void
        // goto L_0031
    }

    protected void onLayout(boolean p0, int p1, int p2, int p3, int p4) {
        // Registers (23 total): v17 = this, v18 = p0 (boolean), v19 = p1 (int), v20 = p2 (int), v21 = p3 (int), v22 = p4 (int)
        v1 = 1;
        v0 = v17;
        v0.mInLayout = v1; // android.support.v4.view.ViewPager.mInLayout:boolean
        _result = v17.populate(v17..v17); // android.support.v4.view.ViewPager.populate -> void
        v1 = 0;
        v0 = v17;
        v0.mInLayout = v1; // android.support.v4.view.ViewPager.mInLayout:boolean
        _result = v17.getChildCount(v17..v17); // android.support.v4.view.ViewPager.getChildCount -> int
        v9 = _result;
        v10 = binOp_0x91(v21, v19);
        v11 = binOp_0x91(v22, v20);
        _result = v17.getPaddingLeft(v17..v17); // android.support.v4.view.ViewPager.getPaddingLeft -> int
        v6 = _result;
        _result = v17.getPaddingTop(v17..v17); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v2 = _result;
        _result = v17.getPaddingRight(v17..v17); // android.support.v4.view.ViewPager.getPaddingRight -> int
        v5 = _result;
        _result = v17.getPaddingBottom(v17..v17); // android.support.v4.view.ViewPager.getPaddingBottom -> int
        v3 = _result;
        _result = v17.getScrollX(v17..v17); // android.support.v4.view.ViewPager.getScrollX -> int
        v12 = _result;
        v4 = 0;
        v1 = 0;
        v8 = v1;
        if (v8 >= v9) /* goto L_00cb */;
        v0 = v17;
        _result = v0.getChildAt(v8); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v13 = _result;
        _result = v13.getVisibility(); // android.view.View.getVisibility -> int
        v1 = _result;
        v7 = 8;
        if (v1 == v7) /* goto L_013b */;
        _result = v13.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v1 = _result;
        v1 = (android.support.v4.view.ViewPager$LayoutParams) v1;
        v7 = v1.isDecor; // android.support.v4.view.ViewPager$LayoutParams.isDecor:boolean
        if (v7 == 0) /* goto L_013b */;
        v7 = v1.gravity; // android.support.v4.view.ViewPager$LayoutParams.gravity:int
        v7 = binOpLit8_0xdd(v7, 7);
        v1 = v1.gravity; // android.support.v4.view.ViewPager$LayoutParams.gravity:int
        v14 = binOpLit8_0xdd(v1, 112);
        // switch(v7)
        v7 = v6;
        // switch(v14)
        v1 = v2;
        v16 = v3;
        v3 = v2;
        v2 = v16;
        v7 = binOp2addr_0xb0(v7, v12);
        _result = v13.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v14 = _result;
        v14 = binOp2addr_0xb0(v14, v7);
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v15 = _result;
        v15 = binOp2addr_0xb0(v15, v1);
        _result = v13.layout(v7, v1, v14, v15); // android.view.View.layout -> void
        v1 = binOpLit8_0xd8(v4, 1);
        v4 = v3;
        v3 = v2;
        v2 = v5;
        v5 = v6;
        v6 = binOpLit8_0xd8(v8, 1);
        v8 = v6;
        v6 = v5;
        v5 = v2;
        v2 = v4;
        v4 = v1;
        // goto L_002c
        _result = v13.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v1 = _result;
        v1 = binOp2addr_0xb0(v1, v6);
        v7 = v6;
        v6 = v1;
        // goto L_0052
        _result = v13.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v1 = _result;
        v1 = binOp_0x91(v10, v1);
        v1 = binOpLit8_0xdb(v1, 2);
        _result = v1.max(v6); // java.lang.Math.max -> int
        v1 = _result;
        v7 = v1;
        // goto L_0052
        v1 = binOp_0x91(v10, v5);
        _result = v13.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v7 = _result;
        v1 = binOp2addr_0xb1(v1, v7);
        _result = v13.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v7 = _result;
        v5 = binOp2addr_0xb0(v5, v7);
        v7 = v1;
        // goto L_0052
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v1 = _result;
        v1 = binOp2addr_0xb0(v1, v2);
        v16 = v2;
        v2 = v3;
        v3 = v1;
        v1 = v16;
        // goto L_005b
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v1 = _result;
        v1 = binOp_0x91(v11, v1);
        v1 = binOpLit8_0xdb(v1, 2);
        _result = v1.max(v2); // java.lang.Math.max -> int
        v1 = _result;
        v16 = v3;
        v3 = v2;
        v2 = v16;
        // goto L_005b
        v1 = binOp_0x91(v11, v3);
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v14 = _result;
        v1 = binOp2addr_0xb1(v1, v14);
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v14 = _result;
        v3 = binOp2addr_0xb0(v3, v14);
        v16 = v3;
        v3 = v2;
        v2 = v16;
        // goto L_005b
        v1 = 0;
        v7 = v1;
        if (v7 >= v9) /* goto L_0127 */;
        v0 = v17;
        _result = v0.getChildAt(v7); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v8 = _result;
        _result = v8.getVisibility(); // android.view.View.getVisibility -> int
        v1 = _result;
        v12 = 8;
        if (v1 == v12) /* goto L_0123 */;
        _result = v8.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v1 = _result;
        v1 = (android.support.v4.view.ViewPager$LayoutParams) v1;
        v12 = v1.isDecor; // android.support.v4.view.ViewPager$LayoutParams.isDecor:boolean
        if (v12 != 0) /* goto L_0123 */;
        v0 = v17;
        _result = v0.infoForChild(v8); // android.support.v4.view.ViewPager.infoForChild -> android.support.v4.view.ViewPager$ItemInfo
        v12 = _result;
        if (v12 == 0) /* goto L_0123 */;
        v13 = unaryOp_0x82(v10);
        v12 = v12.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v12 = binOp2addr_0xc8(v12, v13);
        v12 = unaryOp_0x87(v12);
        v12 = binOp2addr_0xb0(v12, v6);
        v13 = v1.needsMeasure; // android.support.v4.view.ViewPager$LayoutParams.needsMeasure:boolean
        if (v13 == 0) /* goto L_0116 */;
        v13 = 0;
        v1.needsMeasure = v13; // android.support.v4.view.ViewPager$LayoutParams.needsMeasure:boolean
        v13 = binOp_0x91(v10, v6);
        v13 = binOp2addr_0xb1(v13, v5);
        v13 = unaryOp_0x82(v13);
        v1 = v1.widthFactor; // android.support.v4.view.ViewPager$LayoutParams.widthFactor:float
        v1 = binOp2addr_0xc8(v1, v13);
        v1 = unaryOp_0x87(v1);
        v13 = 0x40000000;
        _result = v1.makeMeasureSpec(v13); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v1 = _result;
        v13 = binOp_0x91(v11, v2);
        v13 = binOp2addr_0xb1(v13, v3);
        v14 = 0x40000000;
        _result = v13.makeMeasureSpec(v14); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v13 = _result;
        _result = v8.measure(v1, v13); // android.view.View.measure -> void
        _result = v8.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v1 = _result;
        v1 = binOp2addr_0xb0(v1, v12);
        _result = v8.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v13 = _result;
        v13 = binOp2addr_0xb0(v13, v2);
        _result = v8.layout(v12, v2, v1, v13); // android.view.View.layout -> void
        v1 = binOpLit8_0xd8(v7, 1);
        v7 = v1;
        // goto L_00cd
        v0 = v17;
        v0.mTopPageBounds = v2; // android.support.v4.view.ViewPager.mTopPageBounds:int
        v1 = binOp_0x91(v11, v3);
        v0 = v17;
        v0.mBottomPageBounds = v1; // android.support.v4.view.ViewPager.mBottomPageBounds:int
        v0 = v17;
        v0.mDecorChildCount = v4; // android.support.v4.view.ViewPager.mDecorChildCount:int
        v1 = 0;
        v0 = v17;
        v0.mFirstLayout = v1; // android.support.v4.view.ViewPager.mFirstLayout:boolean
        return;
        v1 = v4;
        v4 = v2;
        v2 = v5;
        v5 = v6;
        // goto L_006f
    }

    protected void onMeasure(int p0, int p1) {
        // Registers (16 total): v13 = this, v14 = p0 (int), v15 = p1 (int)
        v0 = 0;
        _result = v0.getDefaultSize(v14); // android.support.v4.view.ViewPager.getDefaultSize -> int
        v0 = _result;
        v1 = 0;
        _result = v1.getDefaultSize(v15); // android.support.v4.view.ViewPager.getDefaultSize -> int
        v1 = _result;
        _result = v13.setMeasuredDimension(v0, v1); // android.support.v4.view.ViewPager.setMeasuredDimension -> void
        _result = v13.getMeasuredWidth(); // android.support.v4.view.ViewPager.getMeasuredWidth -> int
        v0 = _result;
        v1 = binOpLit8_0xdb(v0, 10);
        v2 = v13.mDefaultGutterSize; // android.support.v4.view.ViewPager.mDefaultGutterSize:int
        _result = v1.min(v2); // java.lang.Math.min -> int
        v1 = _result;
        v13.mGutterSize = v1; // android.support.v4.view.ViewPager.mGutterSize:int
        _result = v13.getPaddingLeft(); // android.support.v4.view.ViewPager.getPaddingLeft -> int
        v1 = _result;
        v0 = binOp2addr_0xb1(v0, v1);
        _result = v13.getPaddingRight(); // android.support.v4.view.ViewPager.getPaddingRight -> int
        v1 = _result;
        v3 = binOp_0x91(v0, v1);
        _result = v13.getMeasuredHeight(); // android.support.v4.view.ViewPager.getMeasuredHeight -> int
        v0 = _result;
        _result = v13.getPaddingTop(); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v1 = _result;
        v0 = binOp2addr_0xb1(v0, v1);
        _result = v13.getPaddingBottom(); // android.support.v4.view.ViewPager.getPaddingBottom -> int
        v1 = _result;
        v5 = binOp_0x91(v0, v1);
        _result = v13.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v9 = _result;
        v0 = 0;
        v8 = v0;
        if (v8 >= v9) /* goto L_00bc */;
        _result = v13.getChildAt(v8); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v10 = _result;
        _result = v10.getVisibility(); // android.view.View.getVisibility -> int
        v0 = _result;
        v1 = 8;
        if (v0 == v1) /* goto L_00a5 */;
        _result = v10.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        if (v0 == 0) /* goto L_00a5 */;
        v1 = v0.isDecor; // android.support.v4.view.ViewPager$LayoutParams.isDecor:boolean
        if (v1 == 0) /* goto L_00a5 */;
        v1 = v0.gravity; // android.support.v4.view.ViewPager$LayoutParams.gravity:int
        v6 = binOpLit8_0xdd(v1, 7);
        v1 = v0.gravity; // android.support.v4.view.ViewPager$LayoutParams.gravity:int
        v4 = binOpLit8_0xdd(v1, 112);
        v2 = 0x80000000;
        v1 = 0x80000000;
        v7 = 48;
        if (v4 == v7) /* goto L_0069 */;
        v7 = 80;
        if (v4 != v7) /* goto L_00a9 */;
        v4 = 1;
        v7 = v4;
        v4 = 3;
        if (v6 == v4) /* goto L_0071 */;
        v4 = 5;
        if (v6 != v4) /* goto L_00ac */;
        v4 = 1;
        v6 = v4;
        if (v7 == 0) /* goto L_00af */;
        v2 = 0x40000000;
        v4 = v0.width; // android.support.v4.view.ViewPager$LayoutParams.width:int
        v11 = -2;
        if (v4 == v11) /* goto L_010f */;
        v4 = 0x40000000;
        v2 = v0.width; // android.support.v4.view.ViewPager$LayoutParams.width:int
        v11 = -1;
        if (v2 == v11) /* goto L_010c */;
        v2 = v0.width; // android.support.v4.view.ViewPager$LayoutParams.width:int
        v11 = v0.height; // android.support.v4.view.ViewPager$LayoutParams.height:int
        v12 = -2;
        if (v11 == v12) /* goto L_010a */;
        v1 = 0x40000000;
        v11 = v0.height; // android.support.v4.view.ViewPager$LayoutParams.height:int
        v12 = -1;
        if (v11 == v12) /* goto L_010a */;
        v0 = v0.height; // android.support.v4.view.ViewPager$LayoutParams.height:int
        _result = v2.makeMeasureSpec(v4); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v2 = _result;
        _result = v0.makeMeasureSpec(v1); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        _result = v10.measure(v2, v0); // android.view.View.measure -> void
        if (v7 == 0) /* goto L_00b4 */;
        _result = v10.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v0 = _result;
        v5 = binOp2addr_0xb1(v5, v0);
        v0 = binOpLit8_0xd8(v8, 1);
        v8 = v0;
        // goto L_003b
        v4 = 0;
        v7 = v4;
        // goto L_006b
        v4 = 0;
        v6 = v4;
        // goto L_0073
        if (v6 == 0) /* goto L_0077 */;
        v1 = 0x40000000;
        // goto L_0077
        if (v6 == 0) /* goto L_00a5 */;
        _result = v10.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v0 = _result;
        v3 = binOp2addr_0xb1(v3, v0);
        // goto L_00a5
        v0 = 0x40000000;
        _result = v3.makeMeasureSpec(v0); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        v13.mChildWidthMeasureSpec = v0; // android.support.v4.view.ViewPager.mChildWidthMeasureSpec:int
        v0 = 0x40000000;
        _result = v5.makeMeasureSpec(v0); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        v13.mChildHeightMeasureSpec = v0; // android.support.v4.view.ViewPager.mChildHeightMeasureSpec:int
        v0 = 1;
        v13.mInLayout = v0; // android.support.v4.view.ViewPager.mInLayout:boolean
        _result = v13.populate(); // android.support.v4.view.ViewPager.populate -> void
        v0 = 0;
        v13.mInLayout = v0; // android.support.v4.view.ViewPager.mInLayout:boolean
        _result = v13.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v2 = _result;
        v0 = 0;
        v1 = v0;
        if (v1 >= v2) /* goto L_0109 */;
        _result = v13.getChildAt(v1); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v4 = _result;
        _result = v4.getVisibility(); // android.view.View.getVisibility -> int
        v0 = _result;
        v5 = 8;
        if (v0 == v5) /* goto L_0105 */;
        _result = v4.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        if (v0 == 0) /* goto L_00f5 */;
        v5 = v0.isDecor; // android.support.v4.view.ViewPager$LayoutParams.isDecor:boolean
        if (v5 != 0) /* goto L_0105 */;
        v5 = unaryOp_0x82(v3);
        v0 = v0.widthFactor; // android.support.v4.view.ViewPager$LayoutParams.widthFactor:float
        v0 = binOp2addr_0xc8(v0, v5);
        v0 = unaryOp_0x87(v0);
        v5 = 0x40000000;
        _result = v0.makeMeasureSpec(v5); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        v5 = v13.mChildHeightMeasureSpec; // android.support.v4.view.ViewPager.mChildHeightMeasureSpec:int
        _result = v4.measure(v0, v5); // android.view.View.measure -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_00db
        return;
        v0 = v5;
        // goto L_0093
        v2 = v3;
        // goto L_0085
        v4 = v2;
        v2 = v3;
        // goto L_0085
    }

    protected void onPageScrolled(int p0, float p1, int p2) {
        // Registers (14 total): v10 = this, v11 = p0 (int), v12 = p1 (float), v13 = p2 (int)
        v0 = v10.mDecorChildCount; // android.support.v4.view.ViewPager.mDecorChildCount:int
        if (v0 <= 0) /* goto L_0075 */;
        _result = v10.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v4 = _result;
        _result = v10.getPaddingLeft(); // android.support.v4.view.ViewPager.getPaddingLeft -> int
        v1 = _result;
        _result = v10.getPaddingRight(); // android.support.v4.view.ViewPager.getPaddingRight -> int
        v2 = _result;
        _result = v10.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v5 = _result;
        _result = v10.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v6 = _result;
        v0 = 0;
        v3 = v0;
        if (v3 >= v6) /* goto L_0075 */;
        _result = v10.getChildAt(v3); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v7 = _result;
        _result = v7.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        v8 = v0.isDecor; // android.support.v4.view.ViewPager$LayoutParams.isDecor:boolean
        if (v8 != 0) /* goto L_0034 */;
        v9 = v2;
        v2 = v1;
        v1 = v9;
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        v9 = v1;
        v1 = v2;
        v2 = v9;
        // goto L_001a
        v0 = v0.gravity; // android.support.v4.view.ViewPager$LayoutParams.gravity:int
        v0 = binOpLit8_0xdd(v0, 7);
        // switch(v0)
        v0 = v1;
        v9 = v2;
        v2 = v1;
        v1 = v9;
        v0 = binOp2addr_0xb0(v0, v4);
        _result = v7.getLeft(); // android.view.View.getLeft -> int
        v8 = _result;
        v0 = binOp2addr_0xb1(v0, v8);
        if (v0 == 0) /* goto L_002d */;
        _result = v7.offsetLeftAndRight(v0); // android.view.View.offsetLeftAndRight -> void
        // goto L_002d
        _result = v7.getWidth(); // android.view.View.getWidth -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v9 = v1;
        v1 = v2;
        v2 = v0;
        v0 = v9;
        // goto L_003f
        _result = v7.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v0 = _result;
        v0 = binOp_0x91(v5, v0);
        v0 = binOpLit8_0xdb(v0, 2);
        _result = v0.max(v1); // java.lang.Math.max -> int
        v0 = _result;
        v9 = v2;
        v2 = v1;
        v1 = v9;
        // goto L_003f
        v0 = binOp_0x91(v5, v2);
        _result = v7.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v8 = _result;
        v0 = binOp2addr_0xb1(v0, v8);
        _result = v7.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v8 = _result;
        v2 = binOp2addr_0xb0(v2, v8);
        v9 = v2;
        v2 = v1;
        v1 = v9;
        // goto L_003f
        v0 = v10.mOnPageChangeListener; // android.support.v4.view.ViewPager.mOnPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        if (v0 == 0) /* goto L_007e */;
        v0 = v10.mOnPageChangeListener; // android.support.v4.view.ViewPager.mOnPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        _result = android.support.v4.view.ViewPager$OnPageChangeListener.onPageScrolled(v0, v11, v12, v13); // -> void
        v0 = v10.mInternalPageChangeListener; // android.support.v4.view.ViewPager.mInternalPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        if (v0 == 0) /* goto L_0087 */;
        v0 = v10.mInternalPageChangeListener; // android.support.v4.view.ViewPager.mInternalPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        _result = android.support.v4.view.ViewPager$OnPageChangeListener.onPageScrolled(v0, v11, v12, v13); // -> void
        v0 = 1;
        v10.mCalledSuper = v0; // android.support.v4.view.ViewPager.mCalledSuper:boolean
        return;
    }

    protected boolean onRequestFocusInDescendants(int p0, android.graphics.Rect p1) {
        // Registers (11 total): v8 = this, v9 = p0 (int), v10 = p1 (android.graphics.Rect)
        v2 = 1;
        v4 = 0;
        v1 = -1;
        _result = v8.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v0 = _result;
        v3 = binOpLit8_0xdd(v9, 2);
        if (v3 == 0) /* goto L_002c */;
        v1 = v2;
        v3 = v4;
        if (v3 == v0) /* goto L_0033 */;
        _result = v8.getChildAt(v3); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v5 = _result;
        _result = v5.getVisibility(); // android.view.View.getVisibility -> int
        v6 = _result;
        if (v6 != 0) /* goto L_0031 */;
        _result = v8.infoForChild(v5); // android.support.v4.view.ViewPager.infoForChild -> android.support.v4.view.ViewPager$ItemInfo
        v6 = _result;
        if (v6 == 0) /* goto L_0031 */;
        v6 = v6.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v7 = v8.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v6 != v7) /* goto L_0031 */;
        _result = v5.requestFocus(v9, v10); // android.view.View.requestFocus -> boolean
        v5 = _result;
        if (v5 == 0) /* goto L_0031 */;
        return v2;
        v0 = binOpLit8_0xd8(v0, -1);
        v3 = v0;
        v0 = v1;
        // goto L_000d
        v3 = binOp2addr_0xb0(v3, v1);
        // goto L_000d
        v2 = v4;
        // goto L_002b
    }

    public void onRestoreInstanceState(android.os.Parcelable p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Parcelable)
        v0 = (v4 instanceof android.support.v4.view.ViewPager$SavedState);
        if (v0 != 0) /* goto L_0008 */;
        _result = v3.onRestoreInstanceState(v4); // android.view.ViewGroup.onRestoreInstanceState -> void
        return;
        v4 = (android.support.v4.view.ViewPager$SavedState) v4;
        _result = v4.getSuperState(); // android.support.v4.view.ViewPager$SavedState.getSuperState -> android.os.Parcelable
        v0 = _result;
        _result = v3.onRestoreInstanceState(v0); // android.view.ViewGroup.onRestoreInstanceState -> void
        v0 = v3.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        if (v0 == 0) /* goto L_0026 */;
        v0 = v3.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v1 = v4.adapterState; // android.support.v4.view.ViewPager$SavedState.adapterState:android.os.Parcelable
        v2 = v4.loader; // android.support.v4.view.ViewPager$SavedState.loader:java.lang.ClassLoader
        _result = v0.restoreState(v1, v2); // android.support.v4.view.PagerAdapter.restoreState -> void
        v0 = v4.position; // android.support.v4.view.ViewPager$SavedState.position:int
        v1 = 0;
        v2 = 1;
        _result = v3.setCurrentItemInternal(v0, v1, v2); // android.support.v4.view.ViewPager.setCurrentItemInternal -> void
        // goto L_0007
        v0 = v4.position; // android.support.v4.view.ViewPager$SavedState.position:int
        v3.mRestoredCurItem = v0; // android.support.v4.view.ViewPager.mRestoredCurItem:int
        v0 = v4.adapterState; // android.support.v4.view.ViewPager$SavedState.adapterState:android.os.Parcelable
        v3.mRestoredAdapterState = v0; // android.support.v4.view.ViewPager.mRestoredAdapterState:android.os.Parcelable
        v0 = v4.loader; // android.support.v4.view.ViewPager$SavedState.loader:java.lang.ClassLoader
        v3.mRestoredClassLoader = v0; // android.support.v4.view.ViewPager.mRestoredClassLoader:java.lang.ClassLoader
        // goto L_0007
    }

    public android.os.Parcelable onSaveInstanceState() {
        // Registers (3 total): v2 = this
        _result = v2.onSaveInstanceState(); // android.view.ViewGroup.onSaveInstanceState -> android.os.Parcelable
        v0 = _result;
        v1 = new android.support.v4.view.ViewPager$SavedState;
        _result = v1.<init>(v0); // android.support.v4.view.ViewPager$SavedState.<init> -> void
        v0 = v2.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v1.position = v0; // android.support.v4.view.ViewPager$SavedState.position:int
        v0 = v2.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        if (v0 == 0) /* goto L_0019 */;
        v0 = v2.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v0.saveState(); // android.support.v4.view.PagerAdapter.saveState -> android.os.Parcelable
        v0 = _result;
        v1.adapterState = v0; // android.support.v4.view.ViewPager$SavedState.adapterState:android.os.Parcelable
        return v1;
    }

    protected void onSizeChanged(int p0, int p1, int p2, int p3) {
        // Registers (7 total): v2 = this, v3 = p0 (int), v4 = p1 (int), v5 = p2 (int), v6 = p3 (int)
        _result = v2.onSizeChanged(v3, v4, v5, v6); // android.view.ViewGroup.onSizeChanged -> void
        if (v3 == v5) /* goto L_000c */;
        v0 = v2.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        v1 = v2.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        _result = v2.recomputeScrollPosition(v3, v5, v0, v1); // android.support.v4.view.ViewPager.recomputeScrollPosition -> void
        return;
    }

    public boolean onTouchEvent(android.view.MotionEvent p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.view.MotionEvent)
        v6 = -1;
        v2 = 0;
        v1 = 1;
        v0 = v7.mFakeDragging; // android.support.v4.view.ViewPager.mFakeDragging:boolean
        if (v0 == 0) /* goto L_0009 */;
        v0 = v1;
        return v0;
        _result = v8.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        _result = v8.getEdgeFlags(); // android.view.MotionEvent.getEdgeFlags -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v0 = v2;
        // goto L_0008
        v0 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        if (v0 == 0) /* goto L_0023 */;
        v0 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v0.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0025 */;
        v0 = v2;
        // goto L_0008
        v0 = v7.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        if (v0 != 0) /* goto L_002f */;
        _result = this.obtain(); // android.view.VelocityTracker.obtain -> android.view.VelocityTracker
        v0 = _result;
        v7.mVelocityTracker = v0; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        v0 = v7.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        _result = v0.addMovement(v8); // android.view.VelocityTracker.addMovement -> void
        _result = v8.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        v0 = binOpLit16_0xd5(v0, 255);
        // switch(v0)
        if (v2 == 0) /* goto L_0042 */;
        _result = v7.postInvalidateOnAnimation(); // android.support.v4.view.ViewCompat.postInvalidateOnAnimation -> void
        v0 = v1;
        // goto L_0008
        v0 = v7.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v0.abortAnimation(); // android.widget.Scroller.abortAnimation -> void
        v7.mPopulatePending = v2; // android.support.v4.view.ViewPager.mPopulatePending:boolean
        _result = v7.populate(); // android.support.v4.view.ViewPager.populate -> void
        v7.mIsBeingDragged = v1; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        _result = v7.setScrollState(v1); // android.support.v4.view.ViewPager.setScrollState -> void
        _result = v8.getX(); // android.view.MotionEvent.getX -> float
        v0 = _result;
        v7.mInitialMotionX = v0; // android.support.v4.view.ViewPager.mInitialMotionX:float
        v7.mLastMotionX = v0; // android.support.v4.view.ViewPager.mLastMotionX:float
        _result = v8.getPointerId(v2); // android.support.v4.view.MotionEventCompat.getPointerId -> int
        v0 = _result;
        v7.mActivePointerId = v0; // android.support.v4.view.ViewPager.mActivePointerId:int
        // goto L_003d
        v0 = v7.mIsBeingDragged; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        if (v0 != 0) /* goto L_00a7 */;
        v0 = v7.mActivePointerId; // android.support.v4.view.ViewPager.mActivePointerId:int
        _result = v8.findPointerIndex(v0); // android.support.v4.view.MotionEventCompat.findPointerIndex -> int
        v0 = _result;
        _result = v8.getX(v0); // android.support.v4.view.MotionEventCompat.getX -> float
        v3 = _result;
        v4 = v7.mLastMotionX; // android.support.v4.view.ViewPager.mLastMotionX:float
        v4 = binOp_0xa7(v3, v4);
        _result = v4.abs(); // java.lang.Math.abs -> float
        v4 = _result;
        _result = v8.getY(v0); // android.support.v4.view.MotionEventCompat.getY -> float
        v0 = _result;
        v5 = v7.mLastMotionY; // android.support.v4.view.ViewPager.mLastMotionY:float
        v0 = binOp2addr_0xc7(v0, v5);
        _result = v0.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v5 = v7.mTouchSlop; // android.support.v4.view.ViewPager.mTouchSlop:int
        v5 = unaryOp_0x82(v5);
        v5 = cmp(v4, v5);
        if (v5 <= 0) /* goto L_00a7 */;
        v0 = cmp(v4, v0);
        if (v0 <= 0) /* goto L_00a7 */;
        v7.mIsBeingDragged = v1; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        v0 = v7.mInitialMotionX; // android.support.v4.view.ViewPager.mInitialMotionX:float
        v0 = binOp_0xa7(v3, v0);
        v3 = 0;
        v0 = cmp(v0, v3);
        if (v0 <= 0) /* goto L_00bb */;
        v0 = v7.mInitialMotionX; // android.support.v4.view.ViewPager.mInitialMotionX:float
        v3 = v7.mTouchSlop; // android.support.v4.view.ViewPager.mTouchSlop:int
        v3 = unaryOp_0x82(v3);
        v0 = binOp2addr_0xc6(v0, v3);
        v7.mLastMotionX = v0; // android.support.v4.view.ViewPager.mLastMotionX:float
        _result = v7.setScrollState(v1); // android.support.v4.view.ViewPager.setScrollState -> void
        _result = v7.setScrollingCacheEnabled(v1); // android.support.v4.view.ViewPager.setScrollingCacheEnabled -> void
        v0 = v7.mIsBeingDragged; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        if (v0 == 0) /* goto L_003d */;
        v0 = v7.mActivePointerId; // android.support.v4.view.ViewPager.mActivePointerId:int
        _result = v8.findPointerIndex(v0); // android.support.v4.view.MotionEventCompat.findPointerIndex -> int
        v0 = _result;
        _result = v8.getX(v0); // android.support.v4.view.MotionEventCompat.getX -> float
        v0 = _result;
        _result = v7.performDrag(v0); // android.support.v4.view.ViewPager.performDrag -> boolean
        v0 = _result;
        v2 = binOp2addr_0xb6(v2, v0);
        // goto L_003d
        v0 = v7.mInitialMotionX; // android.support.v4.view.ViewPager.mInitialMotionX:float
        v3 = v7.mTouchSlop; // android.support.v4.view.ViewPager.mTouchSlop:int
        v3 = unaryOp_0x82(v3);
        v0 = binOp2addr_0xc7(v0, v3);
        // goto L_009f
        v0 = v7.mIsBeingDragged; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        if (v0 == 0) /* goto L_003d */;
        v0 = v7.mVelocityTracker; // android.support.v4.view.ViewPager.mVelocityTracker:android.view.VelocityTracker
        v2 = 1000;
        v3 = v7.mMaximumVelocity; // android.support.v4.view.ViewPager.mMaximumVelocity:int
        v3 = unaryOp_0x82(v3);
        _result = v0.computeCurrentVelocity(v2, v3); // android.view.VelocityTracker.computeCurrentVelocity -> void
        v2 = v7.mActivePointerId; // android.support.v4.view.ViewPager.mActivePointerId:int
        _result = v0.getXVelocity(v2); // android.support.v4.view.VelocityTrackerCompat.getXVelocity -> float
        v0 = _result;
        v0 = unaryOp_0x87(v0);
        v7.mPopulatePending = v1; // android.support.v4.view.ViewPager.mPopulatePending:boolean
        _result = v7.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v2 = _result;
        _result = v7.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v3 = _result;
        _result = v7.infoForCurrentScrollPosition(); // android.support.v4.view.ViewPager.infoForCurrentScrollPosition -> android.support.v4.view.ViewPager$ItemInfo
        v4 = _result;
        v5 = v4.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v3 = unaryOp_0x82(v3);
        v2 = unaryOp_0x82(v2);
        v2 = binOp_0xa9(v3, v2);
        v3 = v4.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v2 = binOp2addr_0xc7(v2, v3);
        v3 = v4.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v2 = binOp2addr_0xc9(v2, v3);
        v3 = v7.mActivePointerId; // android.support.v4.view.ViewPager.mActivePointerId:int
        _result = v8.findPointerIndex(v3); // android.support.v4.view.MotionEventCompat.findPointerIndex -> int
        v3 = _result;
        _result = v8.getX(v3); // android.support.v4.view.MotionEventCompat.getX -> float
        v3 = _result;
        v4 = v7.mInitialMotionX; // android.support.v4.view.ViewPager.mInitialMotionX:float
        v3 = binOp2addr_0xc7(v3, v4);
        v3 = unaryOp_0x87(v3);
        _result = v7.determineTargetPage(v5, v2, v0, v3); // android.support.v4.view.ViewPager.determineTargetPage -> int
        v2 = _result;
        _result = v7.setCurrentItemInternal(v2, v1, v1, v0); // android.support.v4.view.ViewPager.setCurrentItemInternal -> void
        v7.mActivePointerId = v6; // android.support.v4.view.ViewPager.mActivePointerId:int
        _result = v7.endDrag(); // android.support.v4.view.ViewPager.endDrag -> void
        v0 = v7.mLeftEdge; // android.support.v4.view.ViewPager.mLeftEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v0.onRelease(); // android.support.v4.widget.EdgeEffectCompat.onRelease -> boolean
        v0 = _result;
        v2 = v7.mRightEdge; // android.support.v4.view.ViewPager.mRightEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v2.onRelease(); // android.support.v4.widget.EdgeEffectCompat.onRelease -> boolean
        v2 = _result;
        v2 = binOp2addr_0xb6(v2, v0);
        // goto L_003d
        v0 = v7.mIsBeingDragged; // android.support.v4.view.ViewPager.mIsBeingDragged:boolean
        if (v0 == 0) /* goto L_003d */;
        v0 = v7.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        _result = v7.setCurrentItemInternal(v0, v1, v1); // android.support.v4.view.ViewPager.setCurrentItemInternal -> void
        v7.mActivePointerId = v6; // android.support.v4.view.ViewPager.mActivePointerId:int
        _result = v7.endDrag(); // android.support.v4.view.ViewPager.endDrag -> void
        v0 = v7.mLeftEdge; // android.support.v4.view.ViewPager.mLeftEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v0.onRelease(); // android.support.v4.widget.EdgeEffectCompat.onRelease -> boolean
        v0 = _result;
        v2 = v7.mRightEdge; // android.support.v4.view.ViewPager.mRightEdge:android.support.v4.widget.EdgeEffectCompat
        _result = v2.onRelease(); // android.support.v4.widget.EdgeEffectCompat.onRelease -> boolean
        v2 = _result;
        v2 = binOp2addr_0xb6(v2, v0);
        // goto L_003d
        _result = v8.getActionIndex(); // android.support.v4.view.MotionEventCompat.getActionIndex -> int
        v0 = _result;
        _result = v8.getX(v0); // android.support.v4.view.MotionEventCompat.getX -> float
        v3 = _result;
        v7.mLastMotionX = v3; // android.support.v4.view.ViewPager.mLastMotionX:float
        _result = v8.getPointerId(v0); // android.support.v4.view.MotionEventCompat.getPointerId -> int
        v0 = _result;
        v7.mActivePointerId = v0; // android.support.v4.view.ViewPager.mActivePointerId:int
        // goto L_003d
        _result = v7.onSecondaryPointerUp(v8); // android.support.v4.view.ViewPager.onSecondaryPointerUp -> void
        v0 = v7.mActivePointerId; // android.support.v4.view.ViewPager.mActivePointerId:int
        _result = v8.findPointerIndex(v0); // android.support.v4.view.MotionEventCompat.findPointerIndex -> int
        v0 = _result;
        _result = v8.getX(v0); // android.support.v4.view.MotionEventCompat.getX -> float
        v0 = _result;
        v7.mLastMotionX = v0; // android.support.v4.view.ViewPager.mLastMotionX:float
        // goto L_003d
    }

    boolean pageLeft() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v1 <= 0) /* goto L_000d */;
        v1 = v2.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v1 = binOpLit8_0xd8(v1, -1);
        _result = v2.setCurrentItem(v1, v0); // android.support.v4.view.ViewPager.setCurrentItem -> void
        return v0;
        v0 = 0;
        // goto L_000c
    }

    boolean pageRight() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        if (v1 == 0) /* goto L_0019 */;
        v1 = v3.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v2 = v3.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v2.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v2 = _result;
        v2 = binOpLit8_0xd8(v2, -1);
        if (v1 >= v2) /* goto L_0019 */;
        v1 = v3.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v3.setCurrentItem(v1, v0); // android.support.v4.view.ViewPager.setCurrentItem -> void
        return v0;
        v0 = 0;
        // goto L_0018
    }

    void populate() {
        // Registers (2 total): v1 = this
        v0 = v1.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        _result = v1.populate(v0); // android.support.v4.view.ViewPager.populate -> void
        return;
    }

    void populate(int p0) {
        // Registers (16 total): v14 = this, v15 = p0 (int)
        v0 = 0;
        v1 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v1 == v15) /* goto L_0216 */;
        v0 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        _result = v14.infoForPosition(v0); // android.support.v4.view.ViewPager.infoForPosition -> android.support.v4.view.ViewPager$ItemInfo
        v0 = _result;
        v14.mCurItem = v15; // android.support.v4.view.ViewPager.mCurItem:int
        v1 = v0;
        v0 = v14.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        if (v0 != 0) /* goto L_0013 */;
        return;
        v0 = v14.mPopulatePending; // android.support.v4.view.ViewPager.mPopulatePending:boolean
        if (v0 != 0) /* goto L_0012 */;
        _result = v14.getWindowToken(); // android.support.v4.view.ViewPager.getWindowToken -> android.os.IBinder
        v0 = _result;
        if (v0 == 0) /* goto L_0012 */;
        v0 = v14.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v0.startUpdate(v14); // android.support.v4.view.PagerAdapter.startUpdate -> void
        v0 = v14.mOffscreenPageLimit; // android.support.v4.view.ViewPager.mOffscreenPageLimit:int
        v2 = 0;
        v3 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v3 = binOp2addr_0xb1(v3, v0);
        _result = v2.max(v3); // java.lang.Math.max -> int
        v7 = _result;
        v2 = v14.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v2.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v8 = _result;
        v2 = binOpLit8_0xd8(v8, -1);
        v3 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v0 = binOp2addr_0xb0(v0, v3);
        _result = v2.min(v0); // java.lang.Math.min -> int
        v9 = _result;
        v3 = 0;
        v0 = 0;
        v2 = v0;
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v2 >= v0) /* goto L_0213 */;
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v4 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v5 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v4 < v5) /* goto L_00fa */;
        v4 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v5 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v4 != v5) /* goto L_0213 */;
        if (v0 != 0) /* goto L_0210 */;
        if (v8 <= 0) /* goto L_0210 */;
        v0 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        _result = v14.addNewItem(v0, v2); // android.support.v4.view.ViewPager.addNewItem -> android.support.v4.view.ViewPager$ItemInfo
        v0 = _result;
        v6 = v0;
        if (v6 == 0) /* goto L_00bf */;
        v5 = 0;
        v4 = binOpLit8_0xd8(v2, -1);
        if (v4 < 0) /* goto L_00ff */;
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v3 = 0x40000000;
        v10 = v6.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v10 = binOp_0xa7(v3, v10);
        v3 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v3 = binOpLit8_0xd8(v3, -1);
        v12 = v3;
        v3 = v5;
        v5 = v12;
        v13 = v4;
        v4 = v2;
        v2 = v13;
        if (v5 < 0) /* goto L_008e */;
        v11 = cmp(v3, v10);
        if (v11 < 0) /* goto L_012a */;
        if (v5 >= v7) /* goto L_012a */;
        if (v0 != 0) /* goto L_0102 */;
        v3 = v6.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v5 = binOpLit8_0xd8(v4, 1);
        v0 = 0x40000000;
        v0 = cmp(v3, v0);
        if (v0 >= 0) /* goto L_00bc */;
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v5 >= v0) /* goto L_015a */;
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v2 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v2 = binOpLit8_0xd8(v2, 1);
        v12 = v2;
        v2 = v3;
        v3 = v5;
        v5 = v12;
        if (v5 >= v8) /* goto L_00bc */;
        v7 = 0x40000000;
        v7 = cmp(v2, v7);
        if (v7 < 0) /* goto L_018d */;
        if (v5 <= v9) /* goto L_018d */;
        if (v0 != 0) /* goto L_015d */;
        _result = v14.calculatePageOffsets(v6, v4, v1); // android.support.v4.view.ViewPager.calculatePageOffsets -> void
        v1 = v14.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v2 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v6 == 0) /* goto L_01cd */;
        v0 = v6.object; // android.support.v4.view.ViewPager$ItemInfo.object:java.lang.Object
        _result = v1.setPrimaryItem(v14, v2, v0); // android.support.v4.view.PagerAdapter.setPrimaryItem -> void
        v0 = v14.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v0.finishUpdate(v14); // android.support.v4.view.PagerAdapter.finishUpdate -> void
        _result = v14.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v2 = _result;
        v0 = 0;
        v1 = v0;
        if (v1 >= v2) /* goto L_01d0 */;
        _result = v14.getChildAt(v1); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v3 = _result;
        _result = v3.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        v4 = v0.isDecor; // android.support.v4.view.ViewPager$LayoutParams.isDecor:boolean
        if (v4 != 0) /* goto L_00f6 */;
        v4 = v0.widthFactor; // android.support.v4.view.ViewPager$LayoutParams.widthFactor:float
        v5 = 0;
        v4 = cmp(v4, v5);
        if (v4 != 0) /* goto L_00f6 */;
        _result = v14.infoForChild(v3); // android.support.v4.view.ViewPager.infoForChild -> android.support.v4.view.ViewPager$ItemInfo
        v3 = _result;
        if (v3 == 0) /* goto L_00f6 */;
        v3 = v3.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v0.widthFactor = v3; // android.support.v4.view.ViewPager$LayoutParams.widthFactor:float
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_00d5
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_003e
        v0 = 0;
        // goto L_0074
        v11 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v5 != v11) /* goto L_0124 */;
        v11 = v0.scrolling; // android.support.v4.view.ViewPager$ItemInfo.scrolling:boolean
        if (v11 != 0) /* goto L_0124 */;
        v11 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v11.remove(v2); // java.util.ArrayList.remove -> java.lang.Object
        v11 = v14.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v0 = v0.object; // android.support.v4.view.ViewPager$ItemInfo.object:java.lang.Object
        _result = v11.destroyItem(v14, v5, v0); // android.support.v4.view.PagerAdapter.destroyItem -> void
        v2 = binOpLit8_0xd8(v2, -1);
        v4 = binOpLit8_0xd8(v4, -1);
        if (v2 < 0) /* goto L_0128 */;
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v5 = binOpLit8_0xd8(v5, -1);
        // goto L_0084
        v0 = 0;
        // goto L_0124
        if (v0 == 0) /* goto L_0142 */;
        v11 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v5 != v11) /* goto L_0142 */;
        v0 = v0.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v3 = binOp2addr_0xc6(v3, v0);
        v2 = binOpLit8_0xd8(v2, -1);
        if (v2 < 0) /* goto L_0140 */;
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        // goto L_0124
        v0 = 0;
        // goto L_0124
        v0 = binOpLit8_0xd8(v2, 1);
        _result = v14.addNewItem(v5, v0); // android.support.v4.view.ViewPager.addNewItem -> android.support.v4.view.ViewPager$ItemInfo
        v0 = _result;
        v0 = v0.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v3 = binOp2addr_0xc6(v3, v0);
        v4 = binOpLit8_0xd8(v4, 1);
        if (v2 < 0) /* goto L_0158 */;
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        // goto L_0124
        v0 = 0;
        // goto L_0124
        v0 = 0;
        // goto L_00a8
        v7 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v5 != v7) /* goto L_020b */;
        v7 = v0.scrolling; // android.support.v4.view.ViewPager$ItemInfo.scrolling:boolean
        if (v7 != 0) /* goto L_020b */;
        v7 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v7.remove(v3); // java.util.ArrayList.remove -> java.lang.Object
        v7 = v14.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v0 = v0.object; // android.support.v4.view.ViewPager$ItemInfo.object:java.lang.Object
        _result = v7.destroyItem(v14, v5, v0); // android.support.v4.view.PagerAdapter.destroyItem -> void
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_018b */;
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v12 = v2;
        v2 = v0;
        v0 = v12;
        v5 = binOpLit8_0xd8(v5, 1);
        v12 = v0;
        v0 = v2;
        v2 = v12;
        // goto L_00b0
        v0 = 0;
        // goto L_0181
        if (v0 == 0) /* goto L_01ae */;
        v7 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        if (v5 != v7) /* goto L_01ae */;
        v0 = v0.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v2 = binOp2addr_0xc6(v2, v0);
        v3 = binOpLit8_0xd8(v3, 1);
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_01ac */;
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v12 = v2;
        v2 = v0;
        v0 = v12;
        // goto L_0184
        v0 = 0;
        // goto L_01a8
        _result = v14.addNewItem(v5, v3); // android.support.v4.view.ViewPager.addNewItem -> android.support.v4.view.ViewPager$ItemInfo
        v0 = _result;
        v3 = binOpLit8_0xd8(v3, 1);
        v0 = v0.widthFactor; // android.support.v4.view.ViewPager$ItemInfo.widthFactor:float
        v2 = binOp2addr_0xc6(v2, v0);
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_01cb */;
        v0 = v14.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v12 = v2;
        v2 = v0;
        v0 = v12;
        // goto L_0184
        v0 = 0;
        // goto L_01c7
        v0 = 0;
        // goto L_00c7
        _result = v14.hasFocus(); // android.support.v4.view.ViewPager.hasFocus -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0012 */;
        _result = v14.findFocus(); // android.support.v4.view.ViewPager.findFocus -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0209 */;
        _result = v14.infoForAnyChild(v0); // android.support.v4.view.ViewPager.infoForAnyChild -> android.support.v4.view.ViewPager$ItemInfo
        v0 = _result;
        if (v0 == 0) /* goto L_01e8 */;
        v0 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v1 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v0 == v1) /* goto L_0012 */;
        v0 = 0;
        _result = v14.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_0012 */;
        _result = v14.getChildAt(v0); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v1 = _result;
        _result = v14.infoForChild(v1); // android.support.v4.view.ViewPager.infoForChild -> android.support.v4.view.ViewPager$ItemInfo
        v2 = _result;
        if (v2 == 0) /* goto L_0206 */;
        v2 = v2.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v3 = v14.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v2 != v3) /* goto L_0206 */;
        v2 = 2;
        _result = v1.requestFocus(v2); // android.view.View.requestFocus -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0012 */;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_01e9
        v0 = 0;
        // goto L_01e0
        v12 = v2;
        v2 = v0;
        v0 = v12;
        // goto L_0184
        v6 = v0;
        // goto L_0065
        v0 = v3;
        // goto L_005a
        v1 = v0;
        // goto L_000e
    }

    public void setAdapter(android.support.v4.view.PagerAdapter p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.support.v4.view.PagerAdapter)
        v6 = 1;
        v5 = 0;
        v2 = 0;
        v0 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        if (v0 == 0) /* goto L_0043 */;
        v0 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v1 = v7.mObserver; // android.support.v4.view.ViewPager.mObserver:android.support.v4.view.ViewPager$PagerObserver
        _result = v0.unregisterDataSetObserver(v1); // android.support.v4.view.PagerAdapter.unregisterDataSetObserver -> void
        v0 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v0.startUpdate(v7); // android.support.v4.view.PagerAdapter.startUpdate -> void
        v1 = v2;
        v0 = v7.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0031 */;
        v0 = v7.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v3 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v4 = v0.position; // android.support.v4.view.ViewPager$ItemInfo.position:int
        v0 = v0.object; // android.support.v4.view.ViewPager$ItemInfo.object:java.lang.Object
        _result = v3.destroyItem(v7, v4, v0); // android.support.v4.view.PagerAdapter.destroyItem -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0014
        v0 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v0.finishUpdate(v7); // android.support.v4.view.PagerAdapter.finishUpdate -> void
        v0 = v7.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        _result = v7.removeNonDecorViews(); // android.support.v4.view.ViewPager.removeNonDecorViews -> void
        v7.mCurItem = v2; // android.support.v4.view.ViewPager.mCurItem:int
        _result = v7.scrollTo(v2, v2); // android.support.v4.view.ViewPager.scrollTo -> void
        v0 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v7.mAdapter = v8; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v1 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        if (v1 == 0) /* goto L_007a */;
        v1 = v7.mObserver; // android.support.v4.view.ViewPager.mObserver:android.support.v4.view.ViewPager$PagerObserver
        if (v1 != 0) /* goto L_0056 */;
        v1 = new android.support.v4.view.ViewPager$PagerObserver;
        _result = v1.<init>(v7, v5); // android.support.v4.view.ViewPager$PagerObserver.<init> -> void
        v7.mObserver = v1; // android.support.v4.view.ViewPager.mObserver:android.support.v4.view.ViewPager$PagerObserver
        v1 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v3 = v7.mObserver; // android.support.v4.view.ViewPager.mObserver:android.support.v4.view.ViewPager$PagerObserver
        _result = v1.registerDataSetObserver(v3); // android.support.v4.view.PagerAdapter.registerDataSetObserver -> void
        v7.mPopulatePending = v2; // android.support.v4.view.ViewPager.mPopulatePending:boolean
        v7.mFirstLayout = v6; // android.support.v4.view.ViewPager.mFirstLayout:boolean
        v1 = v7.mRestoredCurItem; // android.support.v4.view.ViewPager.mRestoredCurItem:int
        if (v1 < 0) /* goto L_0086 */;
        v1 = v7.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v3 = v7.mRestoredAdapterState; // android.support.v4.view.ViewPager.mRestoredAdapterState:android.os.Parcelable
        v4 = v7.mRestoredClassLoader; // android.support.v4.view.ViewPager.mRestoredClassLoader:java.lang.ClassLoader
        _result = v1.restoreState(v3, v4); // android.support.v4.view.PagerAdapter.restoreState -> void
        v1 = v7.mRestoredCurItem; // android.support.v4.view.ViewPager.mRestoredCurItem:int
        _result = v7.setCurrentItemInternal(v1, v2, v6); // android.support.v4.view.ViewPager.setCurrentItemInternal -> void
        v1 = -1;
        v7.mRestoredCurItem = v1; // android.support.v4.view.ViewPager.mRestoredCurItem:int
        v7.mRestoredAdapterState = v5; // android.support.v4.view.ViewPager.mRestoredAdapterState:android.os.Parcelable
        v7.mRestoredClassLoader = v5; // android.support.v4.view.ViewPager.mRestoredClassLoader:java.lang.ClassLoader
        v1 = v7.mAdapterChangeListener; // android.support.v4.view.ViewPager.mAdapterChangeListener:android.support.v4.view.ViewPager$OnAdapterChangeListener
        if (v1 == 0) /* goto L_0085 */;
        if (v0 == v8) /* goto L_0085 */;
        v1 = v7.mAdapterChangeListener; // android.support.v4.view.ViewPager.mAdapterChangeListener:android.support.v4.view.ViewPager$OnAdapterChangeListener
        _result = android.support.v4.view.ViewPager$OnAdapterChangeListener.onAdapterChanged(v1, v0, v8); // -> void
        return;
        _result = v7.populate(); // android.support.v4.view.ViewPager.populate -> void
        // goto L_007a
    }

    public void setCurrentItem(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v1 = 0;
        v2.mPopulatePending = v1; // android.support.v4.view.ViewPager.mPopulatePending:boolean
        v0 = v2.mFirstLayout; // android.support.v4.view.ViewPager.mFirstLayout:boolean
        if (v0 != 0) /* goto L_000c */;
        v0 = 1;
        _result = v2.setCurrentItemInternal(v3, v0, v1); // android.support.v4.view.ViewPager.setCurrentItemInternal -> void
        return;
        v0 = v1;
        // goto L_0008
    }

    public void setCurrentItem(int p0, boolean p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (boolean)
        v0 = 0;
        v1.mPopulatePending = v0; // android.support.v4.view.ViewPager.mPopulatePending:boolean
        _result = v1.setCurrentItemInternal(v2, v3, v0); // android.support.v4.view.ViewPager.setCurrentItemInternal -> void
        return;
    }

    void setCurrentItemInternal(int p0, boolean p1, boolean p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (boolean), v4 = p2 (boolean)
        v0 = 0;
        _result = v1.setCurrentItemInternal(v2, v3, v4, v0); // android.support.v4.view.ViewPager.setCurrentItemInternal -> void
        return;
    }

    void setCurrentItemInternal(int p0, boolean p1, boolean p2, int p3) {
        // Registers (11 total): v6 = this, v7 = p0 (int), v8 = p1 (boolean), v9 = p2 (boolean), v10 = p3 (int)
        v3 = 1;
        v1 = 0;
        v0 = v6.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        if (v0 == 0) /* goto L_000e */;
        v0 = v6.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v0.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v0 = _result;
        if (v0 > 0) /* goto L_0012 */;
        _result = v6.setScrollingCacheEnabled(v1); // android.support.v4.view.ViewPager.setScrollingCacheEnabled -> void
        return;
        if (v9 != 0) /* goto L_0024 */;
        v0 = v6.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v0 != v7) /* goto L_0024 */;
        v0 = v6.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0024 */;
        _result = v6.setScrollingCacheEnabled(v1); // android.support.v4.view.ViewPager.setScrollingCacheEnabled -> void
        // goto L_0011
        if (v7 >= 0) /* goto L_004b */;
        v7 = v1;
        v0 = v6.mOffscreenPageLimit; // android.support.v4.view.ViewPager.mOffscreenPageLimit:int
        v2 = v6.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v2 = binOp2addr_0xb0(v2, v0);
        if (v7 > v2) /* goto L_0034 */;
        v2 = v6.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        v0 = binOp_0x91(v2, v0);
        if (v7 >= v0) /* goto L_005c */;
        v2 = v1;
        v0 = v6.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v2 >= v0) /* goto L_005c */;
        v0 = v6.mItems; // android.support.v4.view.ViewPager.mItems:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$ItemInfo) v0;
        v0.scrolling = v3; // android.support.v4.view.ViewPager$ItemInfo.scrolling:boolean
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0035
        v0 = v6.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v0.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v0 = _result;
        if (v7 < v0) /* goto L_0027 */;
        v0 = v6.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        _result = v0.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v0 = _result;
        v7 = binOpLit8_0xd8(v0, -1);
        // goto L_0027
        v0 = v6.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        if (v0 == v7) /* goto L_009c */;
        v0 = v3;
        _result = v6.populate(v7); // android.support.v4.view.ViewPager.populate -> void
        _result = v6.infoForPosition(v7); // android.support.v4.view.ViewPager.infoForPosition -> android.support.v4.view.ViewPager$ItemInfo
        v2 = _result;
        if (v2 == 0) /* goto L_00bc */;
        _result = v6.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v3 = _result;
        v3 = unaryOp_0x82(v3);
        v4 = v6.mFirstOffset; // android.support.v4.view.ViewPager.mFirstOffset:float
        v2 = v2.offset; // android.support.v4.view.ViewPager$ItemInfo.offset:float
        v5 = v6.mLastOffset; // android.support.v4.view.ViewPager.mLastOffset:float
        _result = v2.min(v5); // java.lang.Math.min -> float
        v2 = _result;
        _result = v4.max(v2); // java.lang.Math.max -> float
        v2 = _result;
        v2 = binOp2addr_0xc8(v2, v3);
        v2 = unaryOp_0x87(v2);
        if (v8 == 0) /* goto L_009e */;
        _result = v6.smoothScrollTo(v2, v1, v10); // android.support.v4.view.ViewPager.smoothScrollTo -> void
        if (v0 == 0) /* goto L_008f */;
        v1 = v6.mOnPageChangeListener; // android.support.v4.view.ViewPager.mOnPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        if (v1 == 0) /* goto L_008f */;
        v1 = v6.mOnPageChangeListener; // android.support.v4.view.ViewPager.mOnPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        _result = android.support.v4.view.ViewPager$OnPageChangeListener.onPageSelected(v1, v7); // -> void
        if (v0 == 0) /* goto L_0011 */;
        v0 = v6.mInternalPageChangeListener; // android.support.v4.view.ViewPager.mInternalPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        if (v0 == 0) /* goto L_0011 */;
        v0 = v6.mInternalPageChangeListener; // android.support.v4.view.ViewPager.mInternalPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        _result = android.support.v4.view.ViewPager$OnPageChangeListener.onPageSelected(v0, v7); // -> void
        // goto L_0011
        v0 = v1;
        // goto L_0061
        if (v0 == 0) /* goto L_00a9 */;
        v3 = v6.mOnPageChangeListener; // android.support.v4.view.ViewPager.mOnPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        if (v3 == 0) /* goto L_00a9 */;
        v3 = v6.mOnPageChangeListener; // android.support.v4.view.ViewPager.mOnPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        _result = android.support.v4.view.ViewPager$OnPageChangeListener.onPageSelected(v3, v7); // -> void
        if (v0 == 0) /* goto L_00b4 */;
        v0 = v6.mInternalPageChangeListener; // android.support.v4.view.ViewPager.mInternalPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        if (v0 == 0) /* goto L_00b4 */;
        v0 = v6.mInternalPageChangeListener; // android.support.v4.view.ViewPager.mInternalPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        _result = android.support.v4.view.ViewPager$OnPageChangeListener.onPageSelected(v0, v7); // -> void
        _result = v6.completeScroll(); // android.support.v4.view.ViewPager.completeScroll -> void
        _result = v6.scrollTo(v2, v1); // android.support.v4.view.ViewPager.scrollTo -> void
        // goto L_0011
        v2 = v1;
        // goto L_007f
    }

    android.support.v4.view.ViewPager$OnPageChangeListener setInternalPageChangeListener(android.support.v4.view.ViewPager$OnPageChangeListener p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.ViewPager$OnPageChangeListener)
        v0 = v1.mInternalPageChangeListener; // android.support.v4.view.ViewPager.mInternalPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        v1.mInternalPageChangeListener = v2; // android.support.v4.view.ViewPager.mInternalPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        return v0;
    }

    public void setOffscreenPageLimit(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        v0 = 1;
        if (v5 >= v0) /* goto L_0026 */;
        v1 = "ViewPager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Requested offscreen page limit ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " too small; defaulting to ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.w(v2); // android.util.Log.w -> int
        v5 = v0;
        v0 = v4.mOffscreenPageLimit; // android.support.v4.view.ViewPager.mOffscreenPageLimit:int
        if (v5 == v0) /* goto L_002f */;
        v4.mOffscreenPageLimit = v5; // android.support.v4.view.ViewPager.mOffscreenPageLimit:int
        _result = v4.populate(); // android.support.v4.view.ViewPager.populate -> void
        return;
    }

    void setOnAdapterChangeListener(android.support.v4.view.ViewPager$OnAdapterChangeListener p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.ViewPager$OnAdapterChangeListener)
        v0.mAdapterChangeListener = v1; // android.support.v4.view.ViewPager.mAdapterChangeListener:android.support.v4.view.ViewPager$OnAdapterChangeListener
        return;
    }

    public void setOnPageChangeListener(android.support.v4.view.ViewPager$OnPageChangeListener p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.ViewPager$OnPageChangeListener)
        v0.mOnPageChangeListener = v1; // android.support.v4.view.ViewPager.mOnPageChangeListener:android.support.v4.view.ViewPager$OnPageChangeListener
        return;
    }

    public void setPageMargin(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        v2.mPageMargin = v3; // android.support.v4.view.ViewPager.mPageMargin:int
        _result = v2.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v1 = _result;
        _result = v2.recomputeScrollPosition(v1, v1, v3, v0); // android.support.v4.view.ViewPager.recomputeScrollPosition -> void
        _result = v2.requestLayout(); // android.support.v4.view.ViewPager.requestLayout -> void
        return;
    }

    public void setPageMarginDrawable(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.getContext(); // android.support.v4.view.ViewPager.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDrawable(v2); // android.content.res.Resources.getDrawable -> android.graphics.drawable.Drawable
        v0 = _result;
        _result = v1.setPageMarginDrawable(v0); // android.support.v4.view.ViewPager.setPageMarginDrawable -> void
        return;
    }

    public void setPageMarginDrawable(android.graphics.drawable.Drawable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.graphics.drawable.Drawable)
        v1.mMarginDrawable = v2; // android.support.v4.view.ViewPager.mMarginDrawable:android.graphics.drawable.Drawable
        if (v2 == 0) /* goto L_0007 */;
        _result = v1.refreshDrawableState(); // android.support.v4.view.ViewPager.refreshDrawableState -> void
        if (v2 != 0) /* goto L_0011 */;
        v0 = 1;
        _result = v1.setWillNotDraw(v0); // android.support.v4.view.ViewPager.setWillNotDraw -> void
        _result = v1.invalidate(); // android.support.v4.view.ViewPager.invalidate -> void
        return;
        v0 = 0;
        // goto L_000a
    }

    void smoothScrollTo(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = 0;
        _result = v1.smoothScrollTo(v2, v3, v0); // android.support.v4.view.ViewPager.smoothScrollTo -> void
        return;
    }

    void smoothScrollTo(int p0, int p1, int p2) {
        // Registers (13 total): v9 = this, v10 = p0 (int), v11 = p1 (int), v12 = p2 (int)
        v5 = 0;
        v8 = 0x3f800000;
        _result = v9.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v0 = _result;
        if (v0 != 0) /* goto L_000d */;
        _result = v9.setScrollingCacheEnabled(v5); // android.support.v4.view.ViewPager.setScrollingCacheEnabled -> void
        return;
        _result = v9.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v1 = _result;
        _result = v9.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v2 = _result;
        v3 = binOp_0x91(v10, v1);
        v4 = binOp_0x91(v11, v2);
        if (v3 != 0) /* goto L_0027 */;
        if (v4 != 0) /* goto L_0027 */;
        _result = v9.completeScroll(); // android.support.v4.view.ViewPager.completeScroll -> void
        _result = v9.populate(); // android.support.v4.view.ViewPager.populate -> void
        _result = v9.setScrollState(v5); // android.support.v4.view.ViewPager.setScrollState -> void
        // goto L_000c
        v0 = 1;
        _result = v9.setScrollingCacheEnabled(v0); // android.support.v4.view.ViewPager.setScrollingCacheEnabled -> void
        v0 = 2;
        _result = v9.setScrollState(v0); // android.support.v4.view.ViewPager.setScrollState -> void
        _result = v9.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v0 = _result;
        v5 = binOpLit8_0xdb(v0, 2);
        _result = v3.abs(); // java.lang.Math.abs -> int
        v6 = _result;
        v6 = unaryOp_0x82(v6);
        v6 = binOp2addr_0xc8(v6, v8);
        v7 = unaryOp_0x82(v0);
        v6 = binOp2addr_0xc9(v6, v7);
        _result = v8.min(v6); // java.lang.Math.min -> float
        v6 = _result;
        v7 = unaryOp_0x82(v5);
        v5 = unaryOp_0x82(v5);
        _result = v9.distanceInfluenceForSnapDuration(v6); // android.support.v4.view.ViewPager.distanceInfluenceForSnapDuration -> float
        v6 = _result;
        v5 = binOp2addr_0xc8(v5, v6);
        v5 = binOp2addr_0xc6(v5, v7);
        _result = v12.abs(); // java.lang.Math.abs -> int
        v6 = _result;
        if (v6 <= 0) /* goto L_006d */;
        v0 = 0x447a0000;
        v6 = unaryOp_0x82(v6);
        v5 = binOp2addr_0xc9(v5, v6);
        _result = v5.abs(); // java.lang.Math.abs -> float
        v5 = _result;
        v0 = binOp2addr_0xc8(v0, v5);
        _result = v0.round(); // java.lang.Math.round -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 4);
        v5 = 600;
        _result = v0.min(v5); // java.lang.Math.min -> int
        v5 = _result;
        v0 = v9.mScroller; // android.support.v4.view.ViewPager.mScroller:android.widget.Scroller
        _result = v0.startScroll(v0..v5); // android.widget.Scroller.startScroll -> void
        _result = v9.postInvalidateOnAnimation(); // android.support.v4.view.ViewCompat.postInvalidateOnAnimation -> void
        // goto L_000c
        v0 = unaryOp_0x82(v0);
        v5 = v9.mAdapter; // android.support.v4.view.ViewPager.mAdapter:android.support.v4.view.PagerAdapter
        v6 = v9.mCurItem; // android.support.v4.view.ViewPager.mCurItem:int
        _result = v5.getPageWidth(v6); // android.support.v4.view.PagerAdapter.getPageWidth -> float
        v5 = _result;
        v0 = binOp2addr_0xc8(v0, v5);
        _result = v3.abs(); // java.lang.Math.abs -> int
        v5 = _result;
        v5 = unaryOp_0x82(v5);
        v6 = v9.mPageMargin; // android.support.v4.view.ViewPager.mPageMargin:int
        v6 = unaryOp_0x82(v6);
        v0 = binOp2addr_0xc6(v0, v6);
        v0 = binOp_0xa9(v5, v0);
        v0 = binOp2addr_0xc6(v0, v8);
        v5 = 0x42c80000;
        v0 = binOp2addr_0xc8(v0, v5);
        v0 = unaryOp_0x87(v0);
        // goto L_005e
    }

    protected boolean verifyDrawable(android.graphics.drawable.Drawable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.graphics.drawable.Drawable)
        _result = v1.verifyDrawable(v2); // android.view.ViewGroup.verifyDrawable -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v0 = v1.mMarginDrawable; // android.support.v4.view.ViewPager.mMarginDrawable:android.graphics.drawable.Drawable
        if (v2 != v0) /* goto L_000c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000b
    }

}