package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityManagerCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerVersionImpl;
 */
interface AccessibilityManagerCompat$AccessibilityManagerVersionImpl {
    public abstract boolean addAccessibilityStateChangeListener(android.view.accessibility.AccessibilityManager p0, android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p1);
    public abstract java.util.List getEnabledAccessibilityServiceList(android.view.accessibility.AccessibilityManager p0, int p1);
    public abstract java.util.List getInstalledAccessibilityServiceList(android.view.accessibility.AccessibilityManager p0);
    public abstract boolean isTouchExplorationEnabled(android.view.accessibility.AccessibilityManager p0);
    public abstract java.lang.Object newAccessiblityStateChangeListener(android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p0);
    public abstract boolean removeAccessibilityStateChangeListener(android.view.accessibility.AccessibilityManager p0, android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p1);
}