package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityRecordCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordIcsMr1Impl;
 */
class AccessibilityRecordCompat$AccessibilityRecordIcsMr1Impl extends android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordIcsImpl {
    AccessibilityRecordCompat$AccessibilityRecordIcsMr1Impl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordIcsImpl.<init> -> void
        return;
    }

    public int getMaxScrollX(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getMaxScrollX(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcsMr1.getMaxScrollX -> int
        v0 = _result;
        return v0;
    }

    public int getMaxScrollY(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getMaxScrollY(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcsMr1.getMaxScrollY -> int
        v0 = _result;
        return v0;
    }

    public void setMaxScrollX(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.setMaxScrollX(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcsMr1.setMaxScrollX -> void
        return;
    }

    public void setMaxScrollY(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.setMaxScrollY(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcsMr1.setMaxScrollY -> void
        return;
    }

}