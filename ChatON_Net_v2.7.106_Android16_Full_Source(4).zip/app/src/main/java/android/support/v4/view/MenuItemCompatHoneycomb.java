package android.support.v4.view;

/**
 * Original SourceFile: MenuItemCompatHoneycomb.java
 * Descriptor: Landroid/support/v4/view/MenuItemCompatHoneycomb;
 */
class MenuItemCompatHoneycomb {
    MenuItemCompatHoneycomb() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static android.view.MenuItem setActionView(android.view.MenuItem p0, android.view.View p1) {
        // Registers (3 total): v1 = p0 (android.view.MenuItem), v2 = p1 (android.view.View)
        _result = android.view.MenuItem.setActionView(v1, v2); // -> android.view.MenuItem
        v0 = _result;
        return v0;
    }

    public static void setShowAsAction(android.view.MenuItem p0, int p1) {
        // Registers (2 total): v0 = p0 (android.view.MenuItem), v1 = p1 (int)
        _result = android.view.MenuItem.setShowAsAction(v0, v1); // -> void
        return;
    }

}