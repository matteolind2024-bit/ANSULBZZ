package android.support.v4.app;

/**
 * Original SourceFile: LoaderManager.java
 * Descriptor: Landroid/support/v4/app/LoaderManager;
 */
public abstract class LoaderManager {
    public LoaderManager() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void enableDebugLogging(boolean p0) {
        // Registers (1 total): v0 = p0 (boolean)
        android.support.v4.app.LoaderManagerImpl.DEBUG = v0; // :boolean
        return;
    }

    public abstract void destroyLoader(int p0);
    public abstract void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3);
    public abstract android.support.v4.content.Loader getLoader(int p0);
    public boolean hasRunningLoaders() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public abstract android.support.v4.content.Loader initLoader(int p0, android.os.Bundle p1, android.support.v4.app.LoaderManager$LoaderCallbacks p2);
    public abstract android.support.v4.content.Loader restartLoader(int p0, android.os.Bundle p1, android.support.v4.app.LoaderManager$LoaderCallbacks p2);
}