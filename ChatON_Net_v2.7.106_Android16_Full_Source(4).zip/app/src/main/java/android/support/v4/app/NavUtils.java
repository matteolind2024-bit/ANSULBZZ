package android.support.v4.app;

/**
 * Original SourceFile: NavUtils.java
 * Descriptor: Landroid/support/v4/app/NavUtils;
 */
public class NavUtils {
    private static final android.support.v4.app.NavUtils$NavUtilsImpl IMPL;
    public static final java.lang.String PARENT_ACTIVITY;
    private static final java.lang.String TAG;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.app.NavUtils$NavUtilsImplJB;
        _result = v0.<init>(); // android.support.v4.app.NavUtils$NavUtilsImplJB.<init> -> void
        android.support.v4.app.NavUtils.IMPL = v0; // :android.support.v4.app.NavUtils$NavUtilsImpl
        return;
        v0 = new android.support.v4.app.NavUtils$NavUtilsImplBase;
        _result = v0.<init>(); // android.support.v4.app.NavUtils$NavUtilsImplBase.<init> -> void
        android.support.v4.app.NavUtils.IMPL = v0; // :android.support.v4.app.NavUtils$NavUtilsImpl
        // goto L_000d
    }

    private NavUtils() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static android.content.Intent getParentActivityIntent(android.app.Activity p0) {
        // Registers (2 total): v1 = p0 (android.app.Activity)
        v0 = android.support.v4.app.NavUtils.IMPL; // :android.support.v4.app.NavUtils$NavUtilsImpl
        _result = android.support.v4.app.NavUtils$NavUtilsImpl.getParentActivityIntent(v0, v1); // -> android.content.Intent
        v0 = _result;
        return v0;
    }

    public static android.content.Intent getParentActivityIntent(android.content.Context p0, android.content.ComponentName p1) {
        // Registers (5 total): v3 = p0 (android.content.Context), v4 = p1 (android.content.ComponentName)
        _result = v3.getParentActivityName(v4); // android.support.v4.app.NavUtils.getParentActivityName -> java.lang.String
        v0 = _result;
        if (v0 != 0) /* goto L_0008 */;
        v0 = 0;
        return v0;
        v1 = new android.content.Intent;
        _result = v1.<init>(); // android.content.Intent.<init> -> void
        _result = v4.getPackageName(); // android.content.ComponentName.getPackageName -> java.lang.String
        v2 = _result;
        _result = v1.setClassName(v2, v0); // android.content.Intent.setClassName -> android.content.Intent
        v0 = _result;
        // goto L_0007
    }

    public static android.content.Intent getParentActivityIntent(android.content.Context p0, java.lang.Class p1) {
        // Registers (4 total): v2 = p0 (android.content.Context), v3 = p1 (java.lang.Class)
        v0 = new android.content.ComponentName;
        _result = v0.<init>(v2, v3); // android.content.ComponentName.<init> -> void
        _result = v2.getParentActivityName(v0); // android.support.v4.app.NavUtils.getParentActivityName -> java.lang.String
        v0 = _result;
        if (v0 != 0) /* goto L_000d */;
        v0 = 0;
        return v0;
        v1 = new android.content.Intent;
        _result = v1.<init>(); // android.content.Intent.<init> -> void
        _result = v1.setClassName(v2, v0); // android.content.Intent.setClassName -> android.content.Intent
        v0 = _result;
        // goto L_000c
    }

    public static java.lang.String getParentActivityName(android.app.Activity p0) {
        // Registers (3 total): v2 = p0 (android.app.Activity)
        _result = v2.getComponentName(); // android.app.Activity.getComponentName -> android.content.ComponentName
        v0 = _result;
        _result = v2.getParentActivityName(v0); // android.support.v4.app.NavUtils.getParentActivityName -> java.lang.String
        v0 = _result;
        return v0;
        v0 = _exception;
        v1 = new java.lang.IllegalArgumentException;
        _result = v1.<init>(v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v1;
    }

    public static java.lang.String getParentActivityName(android.content.Context p0, android.content.ComponentName p1) {
        // Registers (4 total): v2 = p0 (android.content.Context), v3 = p1 (android.content.ComponentName)
        _result = v2.getPackageManager(); // android.content.Context.getPackageManager -> android.content.pm.PackageManager
        v0 = _result;
        v1 = 128;
        _result = v0.getActivityInfo(v3, v1); // android.content.pm.PackageManager.getActivityInfo -> android.content.pm.ActivityInfo
        v0 = _result;
        v1 = android.support.v4.app.NavUtils.IMPL; // :android.support.v4.app.NavUtils$NavUtilsImpl
        _result = android.support.v4.app.NavUtils$NavUtilsImpl.getParentActivityName(v1, v2, v0); // -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static void navigateUpFromSameTask(android.app.Activity p0) {
        // Registers (4 total): v3 = p0 (android.app.Activity)
        _result = v3.getParentActivityIntent(); // android.support.v4.app.NavUtils.getParentActivityIntent -> android.content.Intent
        v0 = _result;
        if (v0 != 0) /* goto L_0039 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Activity ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v2.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " does not have a parent activity name specified.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " (Did you forget to add the android.support.PARENT_ACTIVITY <meta-data> ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " element in your manifest?)";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = v3.navigateUpTo(v0); // android.support.v4.app.NavUtils.navigateUpTo -> void
        return;
    }

    public static void navigateUpTo(android.app.Activity p0, android.content.Intent p1) {
        // Registers (3 total): v1 = p0 (android.app.Activity), v2 = p1 (android.content.Intent)
        v0 = android.support.v4.app.NavUtils.IMPL; // :android.support.v4.app.NavUtils$NavUtilsImpl
        _result = android.support.v4.app.NavUtils$NavUtilsImpl.navigateUpTo(v0, v1, v2); // -> void
        return;
    }

    public static boolean shouldUpRecreateTask(android.app.Activity p0, android.content.Intent p1) {
        // Registers (3 total): v1 = p0 (android.app.Activity), v2 = p1 (android.content.Intent)
        v0 = android.support.v4.app.NavUtils.IMPL; // :android.support.v4.app.NavUtils$NavUtilsImpl
        _result = android.support.v4.app.NavUtils$NavUtilsImpl.shouldUpRecreateTask(v0, v1, v2); // -> boolean
        v0 = _result;
        return v0;
    }

}