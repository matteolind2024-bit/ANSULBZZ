package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompat.java
 * Descriptor: Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatImpl;
 */
interface ViewGroupCompat$ViewGroupCompatImpl {
    public abstract boolean onRequestSendAccessibilityEvent(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2);
}