package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityNodeProviderCompatJellyBean.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean;
 */
class AccessibilityNodeProviderCompatJellyBean {
    AccessibilityNodeProviderCompatJellyBean() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static java.lang.Object newAccessibilityNodeProviderBridge(android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge)
        v0 = new android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean$1;
        _result = v0.<init>(v1); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean$1.<init> -> void
        return v0;
    }

}