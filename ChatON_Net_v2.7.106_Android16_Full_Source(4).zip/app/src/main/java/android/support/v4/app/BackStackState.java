package android.support.v4.app;

/**
 * Original SourceFile: BackStackRecord.java
 * Descriptor: Landroid/support/v4/app/BackStackState;
 */
final class BackStackState implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
    final int mBreadCrumbShortTitleRes;
    final java.lang.CharSequence mBreadCrumbShortTitleText;
    final int mBreadCrumbTitleRes;
    final java.lang.CharSequence mBreadCrumbTitleText;
    final int mIndex;
    final java.lang.String mName;
    final int[] mOps;
    final int mTransition;
    final int mTransitionStyle;

    static {
        v0 = new android.support.v4.app.BackStackState$1;
        _result = v0.<init>(); // android.support.v4.app.BackStackState$1.<init> -> void
        android.support.v4.app.BackStackState.CREATOR = v0; // :android.os.Parcelable$Creator
        return;
    }

    public BackStackState(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        _result = v2.createIntArray(); // android.os.Parcel.createIntArray -> int[]
        v0 = _result;
        v1.mOps = v0; // android.support.v4.app.BackStackState.mOps:int[]
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.mTransition = v0; // android.support.v4.app.BackStackState.mTransition:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.mTransitionStyle = v0; // android.support.v4.app.BackStackState.mTransitionStyle:int
        _result = v2.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        v1.mName = v0; // android.support.v4.app.BackStackState.mName:java.lang.String
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.mIndex = v0; // android.support.v4.app.BackStackState.mIndex:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.mBreadCrumbTitleRes = v0; // android.support.v4.app.BackStackState.mBreadCrumbTitleRes:int
        v0 = android.text.TextUtils.CHAR_SEQUENCE_CREATOR; // :android.os.Parcelable$Creator
        _result = android.os.Parcelable$Creator.createFromParcel(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.CharSequence) v0;
        v1.mBreadCrumbTitleText = v0; // android.support.v4.app.BackStackState.mBreadCrumbTitleText:java.lang.CharSequence
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.mBreadCrumbShortTitleRes = v0; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleRes:int
        v0 = android.text.TextUtils.CHAR_SEQUENCE_CREATOR; // :android.os.Parcelable$Creator
        _result = android.os.Parcelable$Creator.createFromParcel(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.CharSequence) v0;
        v1.mBreadCrumbShortTitleText = v0; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleText:java.lang.CharSequence
        return;
    }

    public BackStackState(android.support.v4.app.FragmentManagerImpl p0, android.support.v4.app.BackStackRecord p1) {
        // Registers (11 total): v8 = this, v9 = p0 (android.support.v4.app.FragmentManagerImpl), v10 = p1 (android.support.v4.app.BackStackRecord)
        v3 = 0;
        _result = v8.<init>(); // java.lang.Object.<init> -> void
        v0 = v10.mHead; // android.support.v4.app.BackStackRecord.mHead:android.support.v4.app.BackStackRecord$Op
        v1 = v0;
        v0 = v3;
        if (v1 == 0) /* goto L_0018 */;
        v2 = v1.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        if (v2 == 0) /* goto L_0015 */;
        v2 = v1.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v1 = v1.next; // android.support.v4.app.BackStackRecord$Op.next:android.support.v4.app.BackStackRecord$Op
        // goto L_0008
        v1 = v10.mNumOp; // android.support.v4.app.BackStackRecord.mNumOp:int
        v1 = binOpLit8_0xda(v1, 7);
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = new int[][size=v0];
        v8.mOps = v0; // android.support.v4.app.BackStackState.mOps:int[]
        v0 = v10.mAddToBackStack; // android.support.v4.app.BackStackRecord.mAddToBackStack:boolean
        if (v0 != 0) /* goto L_002d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Not on back stack";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v10.mHead; // android.support.v4.app.BackStackRecord.mHead:android.support.v4.app.BackStackRecord$Op
        v5 = v0;
        v0 = v3;
        if (v5 == 0) /* goto L_009f */;
        v1 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v2 = binOpLit8_0xd8(v0, 1);
        v4 = v5.cmd; // android.support.v4.app.BackStackRecord$Op.cmd:int
        v1[v0] = v4;
        v1 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v4 = binOpLit8_0xd8(v2, 1);
        v0 = v5.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0091 */;
        v0 = v5.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v0 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v1[v2] = v0;
        v0 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v1 = binOpLit8_0xd8(v4, 1);
        v2 = v5.enterAnim; // android.support.v4.app.BackStackRecord$Op.enterAnim:int
        v0[v4] = v2;
        v0 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v2 = binOpLit8_0xd8(v1, 1);
        v4 = v5.exitAnim; // android.support.v4.app.BackStackRecord$Op.exitAnim:int
        v0[v1] = v4;
        v0 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v1 = binOpLit8_0xd8(v2, 1);
        v4 = v5.popEnterAnim; // android.support.v4.app.BackStackRecord$Op.popEnterAnim:int
        v0[v2] = v4;
        v0 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v2 = binOpLit8_0xd8(v1, 1);
        v4 = v5.popExitAnim; // android.support.v4.app.BackStackRecord$Op.popExitAnim:int
        v0[v1] = v4;
        v0 = v5.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        if (v0 == 0) /* goto L_0098 */;
        v0 = v5.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v6 = _result;
        v0 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v1 = binOpLit8_0xd8(v2, 1);
        v0[v2] = v6;
        v2 = v3;
        if (v2 >= v6) /* goto L_0093 */;
        v7 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v4 = binOpLit8_0xd8(v1, 1);
        v0 = v5.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v0 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v7[v1] = v0;
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        v1 = v4;
        // goto L_007a
        v0 = -1;
        // goto L_0047
        v0 = v1;
        v1 = v5.next; // android.support.v4.app.BackStackRecord$Op.next:android.support.v4.app.BackStackRecord$Op
        v5 = v1;
        // goto L_0031
        v1 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v0 = binOpLit8_0xd8(v2, 1);
        v1[v2] = v3;
        // goto L_0094
        v0 = v10.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        v8.mTransition = v0; // android.support.v4.app.BackStackState.mTransition:int
        v0 = v10.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        v8.mTransitionStyle = v0; // android.support.v4.app.BackStackState.mTransitionStyle:int
        v0 = v10.mName; // android.support.v4.app.BackStackRecord.mName:java.lang.String
        v8.mName = v0; // android.support.v4.app.BackStackState.mName:java.lang.String
        v0 = v10.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        v8.mIndex = v0; // android.support.v4.app.BackStackState.mIndex:int
        v0 = v10.mBreadCrumbTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleRes:int
        v8.mBreadCrumbTitleRes = v0; // android.support.v4.app.BackStackState.mBreadCrumbTitleRes:int
        v0 = v10.mBreadCrumbTitleText; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleText:java.lang.CharSequence
        v8.mBreadCrumbTitleText = v0; // android.support.v4.app.BackStackState.mBreadCrumbTitleText:java.lang.CharSequence
        v0 = v10.mBreadCrumbShortTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleRes:int
        v8.mBreadCrumbShortTitleRes = v0; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleRes:int
        v0 = v10.mBreadCrumbShortTitleText; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleText:java.lang.CharSequence
        v8.mBreadCrumbShortTitleText = v0; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleText:java.lang.CharSequence
        return;
    }

    public int describeContents() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public android.support.v4.app.BackStackRecord instantiate(android.support.v4.app.FragmentManagerImpl p0) {
        // Registers (12 total): v10 = this, v11 = p0 (android.support.v4.app.FragmentManagerImpl)
        v9 = 1;
        v1 = 0;
        v4 = new android.support.v4.app.BackStackRecord;
        _result = v4.<init>(v11); // android.support.v4.app.BackStackRecord.<init> -> void
        v0 = v1;
        v2 = v10.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v2 = v2.length;
        if (v0 >= v2) /* goto L_00d3 */;
        v5 = new android.support.v4.app.BackStackRecord$Op;
        _result = v5.<init>(); // android.support.v4.app.BackStackRecord$Op.<init> -> void
        v2 = v10.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v3 = binOpLit8_0xd8(v0, 1);
        v0 = v2[v0];
        v5.cmd = v0; // android.support.v4.app.BackStackRecord$Op.cmd:int
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0044 */;
        v0 = "FragmentManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "BSE ";
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v6 = " set base fragment #";
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v6 = v10.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v6 = v6[v3];
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v0.v(v2); // android.util.Log.v -> int
        v0 = v10.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v2 = binOpLit8_0xd8(v3, 1);
        v0 = v0[v3];
        if (v0 < 0) /* goto L_00ca */;
        v3 = v11.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v3.get(v0); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v5.fragment = v0; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v0 = v10.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v3 = binOpLit8_0xd8(v2, 1);
        v0 = v0[v2];
        v5.enterAnim = v0; // android.support.v4.app.BackStackRecord$Op.enterAnim:int
        v0 = v10.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v2 = binOpLit8_0xd8(v3, 1);
        v0 = v0[v3];
        v5.exitAnim = v0; // android.support.v4.app.BackStackRecord$Op.exitAnim:int
        v0 = v10.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v3 = binOpLit8_0xd8(v2, 1);
        v0 = v0[v2];
        v5.popEnterAnim = v0; // android.support.v4.app.BackStackRecord$Op.popEnterAnim:int
        v0 = v10.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v2 = binOpLit8_0xd8(v3, 1);
        v0 = v0[v3];
        v5.popExitAnim = v0; // android.support.v4.app.BackStackRecord$Op.popExitAnim:int
        v3 = v10.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v0 = binOpLit8_0xd8(v2, 1);
        v6 = v3[v2];
        if (v6 <= 0) /* goto L_00ce */;
        v2 = new java.util.ArrayList;
        _result = v2.<init>(v6); // java.util.ArrayList.<init> -> void
        v5.removed = v2; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        v2 = v1;
        if (v2 >= v6) /* goto L_00ce */;
        v3 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v3 == 0) /* goto L_00b2 */;
        v3 = "FragmentManager";
        v7 = new java.lang.StringBuilder;
        _result = v7.<init>(); // java.lang.StringBuilder.<init> -> void
        v8 = "BSE ";
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        v8 = " set remove fragment #";
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        v8 = v10.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v8 = v8[v0];
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v7 = _result;
        _result = v3.v(v7); // android.util.Log.v -> int
        v7 = v11.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        v8 = v10.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v3 = binOpLit8_0xd8(v0, 1);
        v0 = v8[v0];
        _result = v7.get(v0); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v7 = v5.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v7.add(v0); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        v0 = v3;
        // goto L_0086
        v0 = 0;
        v5.fragment = v0; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        // goto L_0056
        _result = v4.addOp(v5); // android.support.v4.app.BackStackRecord.addOp -> void
        // goto L_0008
        v0 = v10.mTransition; // android.support.v4.app.BackStackState.mTransition:int
        v4.mTransition = v0; // android.support.v4.app.BackStackRecord.mTransition:int
        v0 = v10.mTransitionStyle; // android.support.v4.app.BackStackState.mTransitionStyle:int
        v4.mTransitionStyle = v0; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        v0 = v10.mName; // android.support.v4.app.BackStackState.mName:java.lang.String
        v4.mName = v0; // android.support.v4.app.BackStackRecord.mName:java.lang.String
        v0 = v10.mIndex; // android.support.v4.app.BackStackState.mIndex:int
        v4.mIndex = v0; // android.support.v4.app.BackStackRecord.mIndex:int
        v4.mAddToBackStack = v9; // android.support.v4.app.BackStackRecord.mAddToBackStack:boolean
        v0 = v10.mBreadCrumbTitleRes; // android.support.v4.app.BackStackState.mBreadCrumbTitleRes:int
        v4.mBreadCrumbTitleRes = v0; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleRes:int
        v0 = v10.mBreadCrumbTitleText; // android.support.v4.app.BackStackState.mBreadCrumbTitleText:java.lang.CharSequence
        v4.mBreadCrumbTitleText = v0; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleText:java.lang.CharSequence
        v0 = v10.mBreadCrumbShortTitleRes; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleRes:int
        v4.mBreadCrumbShortTitleRes = v0; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleRes:int
        v0 = v10.mBreadCrumbShortTitleText; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleText:java.lang.CharSequence
        v4.mBreadCrumbShortTitleText = v0; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleText:java.lang.CharSequence
        _result = v4.bumpBackStackNesting(v9); // android.support.v4.app.BackStackRecord.bumpBackStackNesting -> void
        return v4;
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.os.Parcel), v4 = p1 (int)
        v1 = 0;
        v0 = v2.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        _result = v3.writeIntArray(v0); // android.os.Parcel.writeIntArray -> void
        v0 = v2.mTransition; // android.support.v4.app.BackStackState.mTransition:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.mTransitionStyle; // android.support.v4.app.BackStackState.mTransitionStyle:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.mName; // android.support.v4.app.BackStackState.mName:java.lang.String
        _result = v3.writeString(v0); // android.os.Parcel.writeString -> void
        v0 = v2.mIndex; // android.support.v4.app.BackStackState.mIndex:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.mBreadCrumbTitleRes; // android.support.v4.app.BackStackState.mBreadCrumbTitleRes:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.mBreadCrumbTitleText; // android.support.v4.app.BackStackState.mBreadCrumbTitleText:java.lang.CharSequence
        _result = v0.writeToParcel(v3, v1); // android.text.TextUtils.writeToParcel -> void
        v0 = v2.mBreadCrumbShortTitleRes; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleRes:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.mBreadCrumbShortTitleText; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleText:java.lang.CharSequence
        _result = v0.writeToParcel(v3, v1); // android.text.TextUtils.writeToParcel -> void
        return;
    }

}