package android.support.v4.content;

/**
 * Original SourceFile: ContextCompatHoneycomb.java
 * Descriptor: Landroid/support/v4/content/ContextCompatHoneycomb;
 */
class ContextCompatHoneycomb {
    ContextCompatHoneycomb() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    static void startActivities(android.content.Context p0, android.content.Intent[] p1) {
        // Registers (2 total): v0 = p0 (android.content.Context), v1 = p1 (android.content.Intent[])
        _result = v0.startActivities(v1); // android.content.Context.startActivities -> void
        return;
    }

}