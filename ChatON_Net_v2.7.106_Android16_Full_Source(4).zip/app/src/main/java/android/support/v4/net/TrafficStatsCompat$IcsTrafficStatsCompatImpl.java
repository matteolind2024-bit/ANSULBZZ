package android.support.v4.net;

/**
 * Original SourceFile: TrafficStatsCompat.java
 * Descriptor: Landroid/support/v4/net/TrafficStatsCompat$IcsTrafficStatsCompatImpl;
 */
class TrafficStatsCompat$IcsTrafficStatsCompatImpl implements android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl {
    TrafficStatsCompat$IcsTrafficStatsCompatImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void clearThreadStatsTag() {
        // Registers (1 total): v0 = this
        _result = this.clearThreadStatsTag(); // android.support.v4.net.TrafficStatsCompatIcs.clearThreadStatsTag -> void
        return;
    }

    public int getThreadStatsTag() {
        // Registers (2 total): v1 = this
        _result = this.getThreadStatsTag(); // android.support.v4.net.TrafficStatsCompatIcs.getThreadStatsTag -> int
        v0 = _result;
        return v0;
    }

    public void incrementOperationCount(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        _result = v1.incrementOperationCount(); // android.support.v4.net.TrafficStatsCompatIcs.incrementOperationCount -> void
        return;
    }

    public void incrementOperationCount(int p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (int), v2 = p1 (int)
        _result = v1.incrementOperationCount(v2); // android.support.v4.net.TrafficStatsCompatIcs.incrementOperationCount -> void
        return;
    }

    public void setThreadStatsTag(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        _result = v1.setThreadStatsTag(); // android.support.v4.net.TrafficStatsCompatIcs.setThreadStatsTag -> void
        return;
    }

    public void tagSocket(java.net.Socket p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.net.Socket)
        _result = v1.tagSocket(); // android.support.v4.net.TrafficStatsCompatIcs.tagSocket -> void
        return;
    }

    public void untagSocket(java.net.Socket p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.net.Socket)
        _result = v1.untagSocket(); // android.support.v4.net.TrafficStatsCompatIcs.untagSocket -> void
        return;
    }

}