package android.support.v4.view;

/**
 * Original SourceFile: VelocityTrackerCompat.java
 * Descriptor: Landroid/support/v4/view/VelocityTrackerCompat$HoneycombVelocityTrackerVersionImpl;
 */
class VelocityTrackerCompat$HoneycombVelocityTrackerVersionImpl implements android.support.v4.view.VelocityTrackerCompat$VelocityTrackerVersionImpl {
    VelocityTrackerCompat$HoneycombVelocityTrackerVersionImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public float getXVelocity(android.view.VelocityTracker p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.VelocityTracker), v3 = p1 (int)
        _result = v2.getXVelocity(v3); // android.support.v4.view.VelocityTrackerCompatHoneycomb.getXVelocity -> float
        v0 = _result;
        return v0;
    }

    public float getYVelocity(android.view.VelocityTracker p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.VelocityTracker), v3 = p1 (int)
        _result = v2.getYVelocity(v3); // android.support.v4.view.VelocityTrackerCompatHoneycomb.getYVelocity -> float
        v0 = _result;
        return v0;
    }

}