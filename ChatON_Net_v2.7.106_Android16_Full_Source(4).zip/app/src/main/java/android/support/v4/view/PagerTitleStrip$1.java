package android.support.v4.view;

/**
 * Original SourceFile: PagerTitleStrip.java
 * Descriptor: Landroid/support/v4/view/PagerTitleStrip$1;
 */
class PagerTitleStrip$1 {
}