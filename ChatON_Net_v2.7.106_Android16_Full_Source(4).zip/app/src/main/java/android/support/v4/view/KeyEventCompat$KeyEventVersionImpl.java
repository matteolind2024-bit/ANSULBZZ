package android.support.v4.view;

/**
 * Original SourceFile: KeyEventCompat.java
 * Descriptor: Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;
 */
interface KeyEventCompat$KeyEventVersionImpl {
    public abstract boolean metaStateHasModifiers(int p0, int p1);
    public abstract boolean metaStateHasNoModifiers(int p0);
    public abstract int normalizeMetaState(int p0);
}