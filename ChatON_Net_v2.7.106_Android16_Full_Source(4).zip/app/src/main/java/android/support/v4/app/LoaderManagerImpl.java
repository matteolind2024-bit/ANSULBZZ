package android.support.v4.app;

/**
 * Original SourceFile: LoaderManager.java
 * Descriptor: Landroid/support/v4/app/LoaderManagerImpl;
 */
class LoaderManagerImpl extends android.support.v4.app.LoaderManager {
    static boolean DEBUG;
    static final java.lang.String TAG;
     android.support.v4.app.FragmentActivity mActivity;
     boolean mCreatingLoader;
    final android.support.v4.util.SparseArrayCompat mInactiveLoaders;
    final android.support.v4.util.SparseArrayCompat mLoaders;
     boolean mRetaining;
     boolean mRetainingStarted;
     boolean mStarted;

    static {
        v0 = 0;
        android.support.v4.app.LoaderManagerImpl.DEBUG = v0; // :boolean
        return;
    }

    LoaderManagerImpl(android.support.v4.app.FragmentActivity p0, boolean p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.support.v4.app.FragmentActivity), v3 = p1 (boolean)
        _result = v1.<init>(); // android.support.v4.app.LoaderManager.<init> -> void
        v0 = new android.support.v4.util.SparseArrayCompat;
        _result = v0.<init>(); // android.support.v4.util.SparseArrayCompat.<init> -> void
        v1.mLoaders = v0; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        v0 = new android.support.v4.util.SparseArrayCompat;
        _result = v0.<init>(); // android.support.v4.util.SparseArrayCompat.<init> -> void
        v1.mInactiveLoaders = v0; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        v1.mActivity = v2; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1.mStarted = v3; // android.support.v4.app.LoaderManagerImpl.mStarted:boolean
        return;
    }

    private android.support.v4.app.LoaderManagerImpl$LoaderInfo createAndInstallLoader(int p0, android.os.Bundle p1, android.support.v4.app.LoaderManager$LoaderCallbacks p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (android.os.Bundle), v5 = p2 (android.support.v4.app.LoaderManager$LoaderCallbacks)
        v1 = 0;
        v0 = 1;
        v2.mCreatingLoader = v0; // android.support.v4.app.LoaderManagerImpl.mCreatingLoader:boolean
        _result = v2.createLoader(v3, v4, v5); // android.support.v4.app.LoaderManagerImpl.createLoader -> android.support.v4.app.LoaderManagerImpl$LoaderInfo
        v0 = _result;
        _result = v2.installLoader(v0); // android.support.v4.app.LoaderManagerImpl.installLoader -> void
        v2.mCreatingLoader = v1; // android.support.v4.app.LoaderManagerImpl.mCreatingLoader:boolean
        return v0;
        v0 = _exception;
        v2.mCreatingLoader = v1; // android.support.v4.app.LoaderManagerImpl.mCreatingLoader:boolean
        throw v0;
    }

    private android.support.v4.app.LoaderManagerImpl$LoaderInfo createLoader(int p0, android.os.Bundle p1, android.support.v4.app.LoaderManager$LoaderCallbacks p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (android.os.Bundle), v5 = p2 (android.support.v4.app.LoaderManager$LoaderCallbacks)
        v0 = new android.support.v4.app.LoaderManagerImpl$LoaderInfo;
        _result = v0.<init>(v2, v3, v4, v5); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.<init> -> void
        _result = android.support.v4.app.LoaderManager$LoaderCallbacks.onCreateLoader(v5, v3, v4); // -> android.support.v4.content.Loader
        v1 = _result;
        v0.mLoader = v1; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        return v0;
    }

    public void destroyLoader(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.mCreatingLoader; // android.support.v4.app.LoaderManagerImpl.mCreatingLoader:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Called while creating a loader";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0032 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "destroyLoader in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " of ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v3.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.indexOfKey(v4); // android.support.v4.util.SparseArrayCompat.indexOfKey -> int
        v1 = _result;
        if (v1 < 0) /* goto L_004a */;
        v0 = v3.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        v2 = v3.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v2.removeAt(v1); // android.support.v4.util.SparseArrayCompat.removeAt -> void
        _result = v0.destroy(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.destroy -> void
        v0 = v3.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.indexOfKey(v4); // android.support.v4.util.SparseArrayCompat.indexOfKey -> int
        v1 = _result;
        if (v1 < 0) /* goto L_0062 */;
        v0 = v3.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        v2 = v3.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v2.removeAt(v1); // android.support.v4.util.SparseArrayCompat.removeAt -> void
        _result = v0.destroy(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.destroy -> void
        v0 = v3.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_0073 */;
        _result = v3.hasRunningLoaders(); // android.support.v4.app.LoaderManagerImpl.hasRunningLoaders -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0073 */;
        v0 = v3.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        _result = v0.startPendingDeferredFragments(); // android.support.v4.app.FragmentManagerImpl.startPendingDeferredFragments -> void
        return;
    }

    void doDestroy() {
        // Registers (4 total): v3 = this
        v0 = v3.mRetaining; // android.support.v4.app.LoaderManagerImpl.mRetaining:boolean
        if (v0 != 0) /* goto L_003a */;
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0020 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Destroying Active in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v3.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_003a */;
        v0 = v3.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        _result = v0.destroy(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.destroy -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0029
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0056 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Destroying Inactive in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v3.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0070 */;
        v0 = v3.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        _result = v0.destroy(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.destroy -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_005f
        v0 = v3.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.clear(); // android.support.v4.util.SparseArrayCompat.clear -> void
        return;
    }

    void doReportNextStart() {
        // Registers (4 total): v3 = this
        v0 = v3.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_001a */;
        v0 = v3.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        v2 = 1;
        v0.mReportNextStart = v2; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mReportNextStart:boolean
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0009
        return;
    }

    void doReportStart() {
        // Registers (3 total): v2 = this
        v0 = v2.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_001a */;
        v0 = v2.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        _result = v0.reportStart(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.reportStart -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0009
        return;
    }

    void doRetain() {
        // Registers (5 total): v4 = this
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001c */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Retaining in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.mStarted; // android.support.v4.app.LoaderManagerImpl.mStarted:boolean
        if (v0 != 0) /* goto L_0043 */;
        v0 = new java.lang.RuntimeException;
        v1 = "here";
        _result = v0.<init>(v1); // java.lang.RuntimeException.<init> -> void
        _result = v0.fillInStackTrace(); // java.lang.RuntimeException.fillInStackTrace -> java.lang.Throwable
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Called doRetain when not started: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.w(v2, v0); // android.util.Log.w -> int
        return;
        v0 = 1;
        v4.mRetaining = v0; // android.support.v4.app.LoaderManagerImpl.mRetaining:boolean
        v0 = 0;
        v4.mStarted = v0; // android.support.v4.app.LoaderManagerImpl.mStarted:boolean
        v0 = v4.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0042 */;
        v0 = v4.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        _result = v0.retain(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.retain -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0052
    }

    void doStart() {
        // Registers (5 total): v4 = this
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001c */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Starting in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.mStarted; // android.support.v4.app.LoaderManagerImpl.mStarted:boolean
        if (v0 == 0) /* goto L_0043 */;
        v0 = new java.lang.RuntimeException;
        v1 = "here";
        _result = v0.<init>(v1); // java.lang.RuntimeException.<init> -> void
        _result = v0.fillInStackTrace(); // java.lang.RuntimeException.fillInStackTrace -> java.lang.Throwable
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Called doStart when already started: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.w(v2, v0); // android.util.Log.w -> int
        return;
        v0 = 1;
        v4.mStarted = v0; // android.support.v4.app.LoaderManagerImpl.mStarted:boolean
        v0 = v4.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0042 */;
        v0 = v4.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        _result = v0.start(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.start -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_004f
    }

    void doStop() {
        // Registers (5 total): v4 = this
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001c */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Stopping in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.mStarted; // android.support.v4.app.LoaderManagerImpl.mStarted:boolean
        if (v0 != 0) /* goto L_0043 */;
        v0 = new java.lang.RuntimeException;
        v1 = "here";
        _result = v0.<init>(v1); // java.lang.RuntimeException.<init> -> void
        _result = v0.fillInStackTrace(); // java.lang.RuntimeException.fillInStackTrace -> java.lang.Throwable
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Called doStop when not started: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.w(v2, v0); // android.util.Log.w -> int
        return;
        v0 = v4.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_005d */;
        v0 = v4.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        _result = v0.stop(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.stop -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_004c
        v0 = 0;
        v4.mStarted = v0; // android.support.v4.app.LoaderManagerImpl.mStarted:boolean
        // goto L_0042
    }

    public void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (10 total): v5 = this, v6 = p0 (java.lang.String), v7 = p1 (java.io.FileDescriptor), v8 = p2 (java.io.PrintWriter), v9 = p3 (java.lang.String[])
        v2 = 0;
        v0 = v5.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0059 */;
        _result = v8.print(v6); // java.io.PrintWriter.print -> void
        v0 = "Active Loaders:";
        _result = v8.println(v0); // java.io.PrintWriter.println -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "    ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v1 = v2;
        v0 = v5.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0059 */;
        v0 = v5.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        _result = v8.print(v6); // java.io.PrintWriter.print -> void
        v4 = "  #";
        _result = v8.print(v4); // java.io.PrintWriter.print -> void
        v4 = v5.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v4.keyAt(v1); // android.support.v4.util.SparseArrayCompat.keyAt -> int
        v4 = _result;
        _result = v8.print(v4); // java.io.PrintWriter.print -> void
        v4 = ": ";
        _result = v8.print(v4); // java.io.PrintWriter.print -> void
        _result = v0.toString(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.toString -> java.lang.String
        v4 = _result;
        _result = v8.println(v4); // java.io.PrintWriter.println -> void
        _result = v0.dump(v3, v7, v8, v9); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.dump -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0025
        v0 = v5.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_00af */;
        _result = v8.print(v6); // java.io.PrintWriter.print -> void
        v0 = "Inactive Loaders:";
        _result = v8.println(v0); // java.io.PrintWriter.println -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "    ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        v0 = v5.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        if (v2 >= v0) /* goto L_00af */;
        v0 = v5.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v2); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        _result = v8.print(v6); // java.io.PrintWriter.print -> void
        v3 = "  #";
        _result = v8.print(v3); // java.io.PrintWriter.print -> void
        v3 = v5.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v3.keyAt(v2); // android.support.v4.util.SparseArrayCompat.keyAt -> int
        v3 = _result;
        _result = v8.print(v3); // java.io.PrintWriter.print -> void
        v3 = ": ";
        _result = v8.print(v3); // java.io.PrintWriter.print -> void
        _result = v0.toString(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.toString -> java.lang.String
        v3 = _result;
        _result = v8.println(v3); // java.io.PrintWriter.println -> void
        _result = v0.dump(v1, v7, v8, v9); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.dump -> void
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_007c
        return;
    }

    void finishRetain() {
        // Registers (4 total): v3 = this
        v0 = v3.mRetaining; // android.support.v4.app.LoaderManagerImpl.mRetaining:boolean
        if (v0 == 0) /* goto L_003d */;
        v0 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0020 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Finished Retaining in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = 0;
        v3.mRetaining = v0; // android.support.v4.app.LoaderManagerImpl.mRetaining:boolean
        v0 = v3.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_003d */;
        v0 = v3.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v1); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        _result = v0.finishRetain(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.finishRetain -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_002c
        return;
    }

    public android.support.v4.content.Loader getLoader(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.mCreatingLoader; // android.support.v4.app.LoaderManagerImpl.mCreatingLoader:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Called while creating a loader";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v2.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.get(v3); // android.support.v4.util.SparseArrayCompat.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        if (v0 == 0) /* goto L_0022 */;
        v1 = v0.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        if (v1 == 0) /* goto L_001f */;
        v0 = v0.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        v0 = v0.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        return v0;
        v0 = v0.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        // goto L_001e
        v0 = 0;
        // goto L_001e
    }

    public boolean hasRunningLoaders() {
        // Registers (7 total): v6 = this
        v1 = 0;
        v0 = v6.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.size(); // android.support.v4.util.SparseArrayCompat.size -> int
        v4 = _result;
        v2 = v1;
        v3 = v1;
        if (v2 >= v4) /* goto L_0023 */;
        v0 = v6.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.valueAt(v2); // android.support.v4.util.SparseArrayCompat.valueAt -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        v5 = v0.mStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        if (v5 == 0) /* goto L_0021 */;
        v0 = v0.mDeliveredData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mDeliveredData:boolean
        if (v0 != 0) /* goto L_0021 */;
        v0 = 1;
        v3 = binOp2addr_0xb6(v3, v0);
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0009
        v0 = v1;
        // goto L_001c
        return v3;
    }

    public android.support.v4.content.Loader initLoader(int p0, android.os.Bundle p1, android.support.v4.app.LoaderManager$LoaderCallbacks p2) {
        // Registers (8 total): v4 = this, v5 = p0 (int), v6 = p1 (android.os.Bundle), v7 = p2 (android.support.v4.app.LoaderManager$LoaderCallbacks)
        v0 = v4.mCreatingLoader; // android.support.v4.app.LoaderManagerImpl.mCreatingLoader:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Called while creating a loader";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v4.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.get(v5); // android.support.v4.util.SparseArrayCompat.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        v1 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_003a */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "initLoader in ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": args=";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        if (v0 != 0) /* goto L_006e */;
        _result = v4.createAndInstallLoader(v5, v6, v7); // android.support.v4.app.LoaderManagerImpl.createAndInstallLoader -> android.support.v4.app.LoaderManagerImpl$LoaderInfo
        v0 = _result;
        v1 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_005c */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Created new loader ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v0.mHaveData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mHaveData:boolean
        if (v1 == 0) /* goto L_006b */;
        v1 = v4.mStarted; // android.support.v4.app.LoaderManagerImpl.mStarted:boolean
        if (v1 == 0) /* goto L_006b */;
        v1 = v0.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        v2 = v0.mData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mData:java.lang.Object
        _result = v0.callOnLoadFinished(v1, v2); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.callOnLoadFinished -> void
        v0 = v0.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        return v0;
        v1 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_008a */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Re-using existing loader ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v0.mCallbacks = v7; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mCallbacks:android.support.v4.app.LoaderManager$LoaderCallbacks
        // goto L_005c
    }

    void installLoader(android.support.v4.app.LoaderManagerImpl$LoaderInfo p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.LoaderManagerImpl$LoaderInfo)
        v0 = v2.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        v1 = v3.mId; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mId:int
        _result = v0.put(v1, v3); // android.support.v4.util.SparseArrayCompat.put -> void
        v0 = v2.mStarted; // android.support.v4.app.LoaderManagerImpl.mStarted:boolean
        if (v0 == 0) /* goto L_000e */;
        _result = v3.start(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.start -> void
        return;
    }

    public android.support.v4.content.Loader restartLoader(int p0, android.os.Bundle p1, android.support.v4.app.LoaderManager$LoaderCallbacks p2) {
        // Registers (9 total): v5 = this, v6 = p0 (int), v7 = p1 (android.os.Bundle), v8 = p2 (android.support.v4.app.LoaderManager$LoaderCallbacks)
        v4 = 0;
        v0 = v5.mCreatingLoader; // android.support.v4.app.LoaderManagerImpl.mCreatingLoader:boolean
        if (v0 == 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Called while creating a loader";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v5.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v0.get(v6); // android.support.v4.util.SparseArrayCompat.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v0;
        v1 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_003b */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "restartLoader in ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": args=";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        if (v0 == 0) /* goto L_0077 */;
        v1 = v5.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v1.get(v6); // android.support.v4.util.SparseArrayCompat.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.app.LoaderManagerImpl$LoaderInfo) v1;
        if (v1 == 0) /* goto L_00d5 */;
        v2 = v0.mHaveData; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mHaveData:boolean
        if (v2 == 0) /* goto L_007e */;
        v2 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v2 == 0) /* goto L_0067 */;
        v2 = "LoaderManager";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "  Removing last inactive loader: ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v2.v(v3); // android.util.Log.v -> int
        v2 = 0;
        v1.mDeliveredData = v2; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mDeliveredData:boolean
        _result = v1.destroy(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.destroy -> void
        v1 = v0.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v1.abandon(); // android.support.v4.content.Loader.abandon -> void
        v1 = v5.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v1.put(v6, v0); // android.support.v4.util.SparseArrayCompat.put -> void
        _result = v5.createAndInstallLoader(v6, v7, v8); // android.support.v4.app.LoaderManagerImpl.createAndInstallLoader -> android.support.v4.app.LoaderManagerImpl$LoaderInfo
        v0 = _result;
        v0 = v0.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        return v0;
        v1 = v0.mStarted; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mStarted:boolean
        if (v1 != 0) /* goto L_0096 */;
        v1 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_008d */;
        v1 = "LoaderManager";
        v2 = "  Current loader is stopped; replacing";
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v5.mLoaders; // android.support.v4.app.LoaderManagerImpl.mLoaders:android.support.v4.util.SparseArrayCompat
        _result = v1.put(v6, v4); // android.support.v4.util.SparseArrayCompat.put -> void
        _result = v0.destroy(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.destroy -> void
        // goto L_0077
        v1 = v0.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        if (v1 == 0) /* goto L_00bf */;
        v1 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_00b8 */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Removing pending loader: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v0.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v0.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        _result = v1.destroy(); // android.support.v4.app.LoaderManagerImpl$LoaderInfo.destroy -> void
        v0.mPendingLoader = v4; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        v1 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_00ca */;
        v1 = "LoaderManager";
        v2 = "  Enqueuing as new pending loader";
        _result = v1.v(v2); // android.util.Log.v -> int
        _result = v5.createLoader(v6, v7, v8); // android.support.v4.app.LoaderManagerImpl.createLoader -> android.support.v4.app.LoaderManagerImpl$LoaderInfo
        v1 = _result;
        v0.mPendingLoader = v1; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        v0 = v0.mPendingLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mPendingLoader:android.support.v4.app.LoaderManagerImpl$LoaderInfo
        v0 = v0.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        // goto L_007d
        v1 = android.support.v4.app.LoaderManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_00f1 */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Making last loader inactive: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v0.mLoader; // android.support.v4.app.LoaderManagerImpl$LoaderInfo.mLoader:android.support.v4.content.Loader
        _result = v1.abandon(); // android.support.v4.content.Loader.abandon -> void
        v1 = v5.mInactiveLoaders; // android.support.v4.app.LoaderManagerImpl.mInactiveLoaders:android.support.v4.util.SparseArrayCompat
        _result = v1.put(v6, v0); // android.support.v4.util.SparseArrayCompat.put -> void
        // goto L_0077
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 128;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = "LoaderManager{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v2.identityHashCode(); // java.lang.System.identityHashCode -> int
        v1 = _result;
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = " in ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mActivity; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v1.buildShortClassTag(v0); // android.support.v4.util.DebugUtils.buildShortClassTag -> void
        v1 = "}}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    void updateActivity(android.support.v4.app.FragmentActivity p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.FragmentActivity)
        v0.mActivity = v1; // android.support.v4.app.LoaderManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        return;
    }

}