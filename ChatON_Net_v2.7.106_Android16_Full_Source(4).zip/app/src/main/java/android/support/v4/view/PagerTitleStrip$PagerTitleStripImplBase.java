package android.support.v4.view;

/**
 * Original SourceFile: PagerTitleStrip.java
 * Descriptor: Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImplBase;
 */
class PagerTitleStrip$PagerTitleStripImplBase implements android.support.v4.view.PagerTitleStrip$PagerTitleStripImpl {
    PagerTitleStrip$PagerTitleStripImplBase() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void setSingleLineAllCaps(android.widget.TextView p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.widget.TextView)
        _result = v1.setSingleLine(); // android.widget.TextView.setSingleLine -> void
        return;
    }

}