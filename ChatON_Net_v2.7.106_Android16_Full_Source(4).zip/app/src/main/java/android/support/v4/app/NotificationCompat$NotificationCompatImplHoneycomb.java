package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/NotificationCompat$NotificationCompatImplHoneycomb;
 */
class NotificationCompat$NotificationCompatImplHoneycomb implements android.support.v4.app.NotificationCompat$NotificationCompatImpl {
    NotificationCompat$NotificationCompatImplHoneycomb() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.app.Notification getNotification(android.support.v4.app.NotificationCompat$Builder p0) {
        // Registers (12 total): v10 = this, v11 = p0 (android.support.v4.app.NotificationCompat$Builder)
        v0 = v11.mContext; // android.support.v4.app.NotificationCompat$Builder.mContext:android.content.Context
        v1 = v11.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v2 = v11.mContentTitle; // android.support.v4.app.NotificationCompat$Builder.mContentTitle:java.lang.CharSequence
        v3 = v11.mContentText; // android.support.v4.app.NotificationCompat$Builder.mContentText:java.lang.CharSequence
        v4 = v11.mContentInfo; // android.support.v4.app.NotificationCompat$Builder.mContentInfo:java.lang.CharSequence
        v5 = v11.mTickerView; // android.support.v4.app.NotificationCompat$Builder.mTickerView:android.widget.RemoteViews
        v6 = v11.mNumber; // android.support.v4.app.NotificationCompat$Builder.mNumber:int
        v7 = v11.mContentIntent; // android.support.v4.app.NotificationCompat$Builder.mContentIntent:android.app.PendingIntent
        v8 = v11.mFullScreenIntent; // android.support.v4.app.NotificationCompat$Builder.mFullScreenIntent:android.app.PendingIntent
        v9 = v11.mLargeIcon; // android.support.v4.app.NotificationCompat$Builder.mLargeIcon:android.graphics.Bitmap
        _result = v0.add(v0..v9); // android.support.v4.app.NotificationCompatHoneycomb.add -> android.app.Notification
        v0 = _result;
        return v0;
    }

}