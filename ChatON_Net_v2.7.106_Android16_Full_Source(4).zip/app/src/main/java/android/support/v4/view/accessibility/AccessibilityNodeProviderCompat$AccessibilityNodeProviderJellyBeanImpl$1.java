package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityNodeProviderCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1;
 */
class AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1 implements android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge {
    final android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl this$0;
    final android.support.v4.view.accessibility.AccessibilityNodeProviderCompat val$compat;

    AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1(android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl p0, android.support.v4.view.accessibility.AccessibilityNodeProviderCompat p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl), v2 = p1 (android.support.v4.view.accessibility.AccessibilityNodeProviderCompat)
        v0.this$0 = v1; // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1.this$0:android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl
        v0.val$compat = v2; // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1.val$compat:android.support.v4.view.accessibility.AccessibilityNodeProviderCompat
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.lang.Object createAccessibilityNodeInfo(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.val$compat; // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1.val$compat:android.support.v4.view.accessibility.AccessibilityNodeProviderCompat
        _result = v0.createAccessibilityNodeInfo(v2); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.createAccessibilityNodeInfo -> android.support.v4.view.accessibility.AccessibilityNodeInfoCompat
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v0 = 0;
        return v0;
        _result = v0.getInfo(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.getInfo -> java.lang.Object
        v0 = _result;
        // goto L_0009
    }

    public java.util.List findAccessibilityNodeInfosByText(java.lang.String p0, int p1) {
        // Registers (8 total): v5 = this, v6 = p0 (java.lang.String), v7 = p1 (int)
        v0 = v5.val$compat; // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1.val$compat:android.support.v4.view.accessibility.AccessibilityNodeProviderCompat
        _result = v0.findAccessibilityNodeInfosByText(v6, v7); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.findAccessibilityNodeInfosByText -> java.util.List
        v2 = _result;
        v3 = new java.util.ArrayList;
        _result = v3.<init>(); // java.util.ArrayList.<init> -> void
        _result = java.util.List.size(v2); // -> int
        v4 = _result;
        v0 = 0;
        v1 = v0;
        if (v1 >= v4) /* goto L_0024 */;
        _result = java.util.List.get(v2, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.accessibility.AccessibilityNodeInfoCompat) v0;
        _result = v0.getInfo(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.getInfo -> java.lang.Object
        v0 = _result;
        _result = java.util.List.add(v3, v0); // -> boolean
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0011
        return v3;
    }

    public boolean performAction(int p0, int p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (int), v4 = p2 (android.os.Bundle)
        v0 = v1.val$compat; // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1.val$compat:android.support.v4.view.accessibility.AccessibilityNodeProviderCompat
        _result = v0.performAction(v2, v3, v4); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.performAction -> boolean
        v0 = _result;
        return v0;
    }

}