package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/NotificationCompat$NotificationCompatImplBase;
 */
class NotificationCompat$NotificationCompatImplBase implements android.support.v4.app.NotificationCompat$NotificationCompatImpl {
    NotificationCompat$NotificationCompatImplBase() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.app.Notification getNotification(android.support.v4.app.NotificationCompat$Builder p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.support.v4.app.NotificationCompat$Builder)
        v0 = v6.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v1 = v6.mContext; // android.support.v4.app.NotificationCompat$Builder.mContext:android.content.Context
        v2 = v6.mContentTitle; // android.support.v4.app.NotificationCompat$Builder.mContentTitle:java.lang.CharSequence
        v3 = v6.mContentText; // android.support.v4.app.NotificationCompat$Builder.mContentText:java.lang.CharSequence
        v4 = v6.mContentIntent; // android.support.v4.app.NotificationCompat$Builder.mContentIntent:android.app.PendingIntent
        _result = v0.setLatestEventInfo(v1, v2, v3, v4); // android.app.Notification.setLatestEventInfo -> void
        return v0;
    }

}