package android.support.v4.net;

/**
 * Original SourceFile: ConnectivityManagerCompat.java
 * Descriptor: Landroid/support/v4/net/ConnectivityManagerCompat$GingerbreadConnectivityManagerCompatImpl;
 */
class ConnectivityManagerCompat$GingerbreadConnectivityManagerCompatImpl implements android.support.v4.net.ConnectivityManagerCompat$ConnectivityManagerCompatImpl {
    ConnectivityManagerCompat$GingerbreadConnectivityManagerCompatImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean isActiveNetworkMetered(android.net.ConnectivityManager p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.net.ConnectivityManager)
        _result = v2.isActiveNetworkMetered(); // android.support.v4.net.ConnectivityManagerCompatGingerbread.isActiveNetworkMetered -> boolean
        v0 = _result;
        return v0;
    }

}