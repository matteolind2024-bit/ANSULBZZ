package android.support.v4.view;

/**
 * Original SourceFile: PagerTabStrip.java
 * Descriptor: Landroid/support/v4/view/PagerTabStrip$1;
 */
class PagerTabStrip$1 implements android.view.View$OnClickListener {
    final android.support.v4.view.PagerTabStrip this$0;

    PagerTabStrip$1(android.support.v4.view.PagerTabStrip p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.PagerTabStrip)
        v0.this$0 = v1; // android.support.v4.view.PagerTabStrip$1.this$0:android.support.v4.view.PagerTabStrip
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onClick(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = v2.this$0; // android.support.v4.view.PagerTabStrip$1.this$0:android.support.v4.view.PagerTabStrip
        v0 = v0.mPager; // android.support.v4.view.PagerTabStrip.mPager:android.support.v4.view.ViewPager
        v1 = v2.this$0; // android.support.v4.view.PagerTabStrip$1.this$0:android.support.v4.view.PagerTabStrip
        v1 = v1.mPager; // android.support.v4.view.PagerTabStrip.mPager:android.support.v4.view.ViewPager
        _result = v1.getCurrentItem(); // android.support.v4.view.ViewPager.getCurrentItem -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        _result = v0.setCurrentItem(v1); // android.support.v4.view.ViewPager.setCurrentItem -> void
        return;
    }

}