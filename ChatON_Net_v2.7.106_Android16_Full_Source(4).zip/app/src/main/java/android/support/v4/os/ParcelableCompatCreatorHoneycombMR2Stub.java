package android.support.v4.os;

/**
 * Original SourceFile: ParcelableCompatHoneycombMR2.java
 * Descriptor: Landroid/support/v4/os/ParcelableCompatCreatorHoneycombMR2Stub;
 */
class ParcelableCompatCreatorHoneycombMR2Stub {
    ParcelableCompatCreatorHoneycombMR2Stub() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    static android.os.Parcelable$Creator instantiate(android.support.v4.os.ParcelableCompatCreatorCallbacks p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.os.ParcelableCompatCreatorCallbacks)
        v0 = new android.support.v4.os.ParcelableCompatCreatorHoneycombMR2;
        _result = v0.<init>(v1); // android.support.v4.os.ParcelableCompatCreatorHoneycombMR2.<init> -> void
        return v0;
    }

}