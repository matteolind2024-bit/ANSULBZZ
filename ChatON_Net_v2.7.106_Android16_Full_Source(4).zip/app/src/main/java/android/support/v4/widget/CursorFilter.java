package android.support.v4.widget;

/**
 * Original SourceFile: CursorFilter.java
 * Descriptor: Landroid/support/v4/widget/CursorFilter;
 */
class CursorFilter extends android.widget.Filter {
     android.support.v4.widget.CursorFilter$CursorFilterClient mClient;

    CursorFilter(android.support.v4.widget.CursorFilter$CursorFilterClient p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.CursorFilter$CursorFilterClient)
        _result = v0.<init>(); // android.widget.Filter.<init> -> void
        v0.mClient = v1; // android.support.v4.widget.CursorFilter.mClient:android.support.v4.widget.CursorFilter$CursorFilterClient
        return;
    }

    public java.lang.CharSequence convertResultToString(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = v1.mClient; // android.support.v4.widget.CursorFilter.mClient:android.support.v4.widget.CursorFilter$CursorFilterClient
        v2 = (android.database.Cursor) v2;
        _result = android.support.v4.widget.CursorFilter$CursorFilterClient.convertToString(v0, v2); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    protected android.widget.Filter$FilterResults performFiltering(java.lang.CharSequence p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.CharSequence)
        v0 = v3.mClient; // android.support.v4.widget.CursorFilter.mClient:android.support.v4.widget.CursorFilter$CursorFilterClient
        _result = android.support.v4.widget.CursorFilter$CursorFilterClient.runQueryOnBackgroundThread(v0, v4); // -> android.database.Cursor
        v0 = _result;
        v1 = new android.widget.Filter$FilterResults;
        _result = v1.<init>(); // android.widget.Filter$FilterResults.<init> -> void
        if (v0 == 0) /* goto L_0016 */;
        _result = android.database.Cursor.getCount(v0); // -> int
        v2 = _result;
        v1.count = v2; // android.widget.Filter$FilterResults.count:int
        v1.values = v0; // android.widget.Filter$FilterResults.values:java.lang.Object
        return v1;
        v0 = 0;
        v1.count = v0; // android.widget.Filter$FilterResults.count:int
        v0 = 0;
        v1.values = v0; // android.widget.Filter$FilterResults.values:java.lang.Object
        // goto L_0015
    }

    protected void publishResults(java.lang.CharSequence p0, android.widget.Filter$FilterResults p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.CharSequence), v4 = p1 (android.widget.Filter$FilterResults)
        v0 = v2.mClient; // android.support.v4.widget.CursorFilter.mClient:android.support.v4.widget.CursorFilter$CursorFilterClient
        _result = android.support.v4.widget.CursorFilter$CursorFilterClient.getCursor(v0); // -> android.database.Cursor
        v0 = _result;
        v1 = v4.values; // android.widget.Filter$FilterResults.values:java.lang.Object
        if (v1 == 0) /* goto L_0017 */;
        v1 = v4.values; // android.widget.Filter$FilterResults.values:java.lang.Object
        if (v1 == v0) /* goto L_0017 */;
        v1 = v2.mClient; // android.support.v4.widget.CursorFilter.mClient:android.support.v4.widget.CursorFilter$CursorFilterClient
        v0 = v4.values; // android.widget.Filter$FilterResults.values:java.lang.Object
        v0 = (android.database.Cursor) v0;
        _result = android.support.v4.widget.CursorFilter$CursorFilterClient.changeCursor(v1, v0); // -> void
        return;
    }

}