package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$PagerObserver;
 */
class ViewPager$PagerObserver extends android.database.DataSetObserver {
    final android.support.v4.view.ViewPager this$0;

    private ViewPager$PagerObserver(android.support.v4.view.ViewPager p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.ViewPager)
        v0.this$0 = v1; // android.support.v4.view.ViewPager$PagerObserver.this$0:android.support.v4.view.ViewPager
        _result = v0.<init>(); // android.database.DataSetObserver.<init> -> void
        return;
    }

    ViewPager$PagerObserver(android.support.v4.view.ViewPager p0, android.support.v4.view.ViewPager$1 p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.view.ViewPager), v2 = p1 (android.support.v4.view.ViewPager$1)
        _result = v0.<init>(v1); // android.support.v4.view.ViewPager$PagerObserver.<init> -> void
        return;
    }

    public void onChanged() {
        // Registers (2 total): v1 = this
        v0 = v1.this$0; // android.support.v4.view.ViewPager$PagerObserver.this$0:android.support.v4.view.ViewPager
        _result = v0.dataSetChanged(); // android.support.v4.view.ViewPager.dataSetChanged -> void
        return;
    }

    public void onInvalidated() {
        // Registers (2 total): v1 = this
        v0 = v1.this$0; // android.support.v4.view.ViewPager$PagerObserver.this$0:android.support.v4.view.ViewPager
        _result = v0.dataSetChanged(); // android.support.v4.view.ViewPager.dataSetChanged -> void
        return;
    }

}