package android.support.v4.app;

/**
 * Original SourceFile: ShareCompat.java
 * Descriptor: Landroid/support/v4/app/ShareCompat$IntentReader;
 */
public class ShareCompat$IntentReader {
    private static final java.lang.String TAG;
    private android.app.Activity mActivity;
    private android.content.ComponentName mCallingActivity;
    private java.lang.String mCallingPackage;
    private android.content.Intent mIntent;
    private java.util.ArrayList mStreams;

    private ShareCompat$IntentReader(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v1.mActivity = v2; // android.support.v4.app.ShareCompat$IntentReader.mActivity:android.app.Activity
        _result = v2.getIntent(); // android.app.Activity.getIntent -> android.content.Intent
        v0 = _result;
        v1.mIntent = v0; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        _result = v2.getCallingPackage(); // android.support.v4.app.ShareCompat.getCallingPackage -> java.lang.String
        v0 = _result;
        v1.mCallingPackage = v0; // android.support.v4.app.ShareCompat$IntentReader.mCallingPackage:java.lang.String
        _result = v2.getCallingActivity(); // android.support.v4.app.ShareCompat.getCallingActivity -> android.content.ComponentName
        v0 = _result;
        v1.mCallingActivity = v0; // android.support.v4.app.ShareCompat$IntentReader.mCallingActivity:android.content.ComponentName
        return;
    }

    public static android.support.v4.app.ShareCompat$IntentReader from(android.app.Activity p0) {
        // Registers (2 total): v1 = p0 (android.app.Activity)
        v0 = new android.support.v4.app.ShareCompat$IntentReader;
        _result = v0.<init>(v1); // android.support.v4.app.ShareCompat$IntentReader.<init> -> void
        return v0;
    }

    public android.content.ComponentName getCallingActivity() {
        // Registers (2 total): v1 = this
        v0 = v1.mCallingActivity; // android.support.v4.app.ShareCompat$IntentReader.mCallingActivity:android.content.ComponentName
        return v0;
    }

    public android.graphics.drawable.Drawable getCallingActivityIcon() {
        // Registers (5 total): v4 = this
        v0 = 0;
        v1 = v4.mCallingActivity; // android.support.v4.app.ShareCompat$IntentReader.mCallingActivity:android.content.ComponentName
        if (v1 != 0) /* goto L_0006 */;
        return v0;
        v1 = v4.mActivity; // android.support.v4.app.ShareCompat$IntentReader.mActivity:android.app.Activity
        _result = v1.getPackageManager(); // android.app.Activity.getPackageManager -> android.content.pm.PackageManager
        v1 = _result;
        v2 = v4.mCallingActivity; // android.support.v4.app.ShareCompat$IntentReader.mCallingActivity:android.content.ComponentName
        _result = v1.getActivityIcon(v2); // android.content.pm.PackageManager.getActivityIcon -> android.graphics.drawable.Drawable
        v0 = _result;
        // goto L_0005
        v1 = _exception;
        v2 = "IntentReader";
        v3 = "Could not retrieve icon for calling activity";
        _result = v2.e(v3, v1); // android.util.Log.e -> int
        // goto L_0005
    }

    public android.graphics.drawable.Drawable getCallingApplicationIcon() {
        // Registers (5 total): v4 = this
        v0 = 0;
        v1 = v4.mCallingPackage; // android.support.v4.app.ShareCompat$IntentReader.mCallingPackage:java.lang.String
        if (v1 != 0) /* goto L_0006 */;
        return v0;
        v1 = v4.mActivity; // android.support.v4.app.ShareCompat$IntentReader.mActivity:android.app.Activity
        _result = v1.getPackageManager(); // android.app.Activity.getPackageManager -> android.content.pm.PackageManager
        v1 = _result;
        v2 = v4.mCallingPackage; // android.support.v4.app.ShareCompat$IntentReader.mCallingPackage:java.lang.String
        _result = v1.getApplicationIcon(v2); // android.content.pm.PackageManager.getApplicationIcon -> android.graphics.drawable.Drawable
        v0 = _result;
        // goto L_0005
        v1 = _exception;
        v2 = "IntentReader";
        v3 = "Could not retrieve icon for calling application";
        _result = v2.e(v3, v1); // android.util.Log.e -> int
        // goto L_0005
    }

    public java.lang.CharSequence getCallingApplicationLabel() {
        // Registers (5 total): v4 = this
        v0 = 0;
        v1 = v4.mCallingPackage; // android.support.v4.app.ShareCompat$IntentReader.mCallingPackage:java.lang.String
        if (v1 != 0) /* goto L_0006 */;
        return v0;
        v1 = v4.mActivity; // android.support.v4.app.ShareCompat$IntentReader.mActivity:android.app.Activity
        _result = v1.getPackageManager(); // android.app.Activity.getPackageManager -> android.content.pm.PackageManager
        v1 = _result;
        v2 = v4.mCallingPackage; // android.support.v4.app.ShareCompat$IntentReader.mCallingPackage:java.lang.String
        v3 = 0;
        _result = v1.getApplicationInfo(v2, v3); // android.content.pm.PackageManager.getApplicationInfo -> android.content.pm.ApplicationInfo
        v2 = _result;
        _result = v1.getApplicationLabel(v2); // android.content.pm.PackageManager.getApplicationLabel -> java.lang.CharSequence
        v0 = _result;
        // goto L_0005
        v1 = _exception;
        v2 = "IntentReader";
        v3 = "Could not retrieve label for calling application";
        _result = v2.e(v3, v1); // android.util.Log.e -> int
        // goto L_0005
    }

    public java.lang.String getCallingPackage() {
        // Registers (2 total): v1 = this
        v0 = v1.mCallingPackage; // android.support.v4.app.ShareCompat$IntentReader.mCallingPackage:java.lang.String
        return v0;
    }

    public java.lang.String[] getEmailBcc() {
        // Registers (3 total): v2 = this
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        v1 = "android.intent.extra.BCC";
        _result = v0.getStringArrayExtra(v1); // android.content.Intent.getStringArrayExtra -> java.lang.String[]
        v0 = _result;
        return v0;
    }

    public java.lang.String[] getEmailCc() {
        // Registers (3 total): v2 = this
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        v1 = "android.intent.extra.CC";
        _result = v0.getStringArrayExtra(v1); // android.content.Intent.getStringArrayExtra -> java.lang.String[]
        v0 = _result;
        return v0;
    }

    public java.lang.String[] getEmailTo() {
        // Registers (3 total): v2 = this
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        v1 = "android.intent.extra.EMAIL";
        _result = v0.getStringArrayExtra(v1); // android.content.Intent.getStringArrayExtra -> java.lang.String[]
        v0 = _result;
        return v0;
    }

    public java.lang.String getHtmlText() {
        // Registers (4 total): v3 = this
        v0 = v3.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        v1 = "android.intent.extra.HTML_TEXT";
        _result = v0.getStringExtra(v1); // android.content.Intent.getStringExtra -> java.lang.String
        v1 = _result;
        v0 = v3.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        if (v0 != 0) /* goto L_0026 */;
        _result = v3.getText(); // android.support.v4.app.ShareCompat$IntentReader.getText -> java.lang.CharSequence
        v0 = _result;
        v2 = (v0 instanceof android.text.Spanned);
        if (v2 == 0) /* goto L_001b */;
        v0 = (android.text.Spanned) v0;
        _result = v0.toHtml(); // android.text.Html.toHtml -> java.lang.String
        v0 = _result;
        return v0;
        if (v0 == 0) /* goto L_0026 */;
        _result = this.access$000(); // android.support.v4.app.ShareCompat.access$000 -> android.support.v4.app.ShareCompat$ShareCompatImpl
        v1 = _result;
        _result = android.support.v4.app.ShareCompat$ShareCompatImpl.escapeHtml(v1, v0); // -> java.lang.String
        v0 = _result;
        // goto L_001a
        v0 = v1;
        // goto L_001a
    }

    public android.net.Uri getStream() {
        // Registers (3 total): v2 = this
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        v1 = "android.intent.extra.STREAM";
        _result = v0.getParcelableExtra(v1); // android.content.Intent.getParcelableExtra -> android.os.Parcelable
        v0 = _result;
        v0 = (android.net.Uri) v0;
        return v0;
    }

    public android.net.Uri getStream(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.mStreams; // android.support.v4.app.ShareCompat$IntentReader.mStreams:java.util.ArrayList
        if (v0 != 0) /* goto L_0014 */;
        _result = v3.isMultipleShare(); // android.support.v4.app.ShareCompat$IntentReader.isMultipleShare -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        v0 = v3.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        v1 = "android.intent.extra.STREAM";
        _result = v0.getParcelableArrayListExtra(v1); // android.content.Intent.getParcelableArrayListExtra -> java.util.ArrayList
        v0 = _result;
        v3.mStreams = v0; // android.support.v4.app.ShareCompat$IntentReader.mStreams:java.util.ArrayList
        v0 = v3.mStreams; // android.support.v4.app.ShareCompat$IntentReader.mStreams:java.util.ArrayList
        if (v0 == 0) /* goto L_0021 */;
        v0 = v3.mStreams; // android.support.v4.app.ShareCompat$IntentReader.mStreams:java.util.ArrayList
        _result = v0.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.net.Uri) v0;
        return v0;
        if (v4 != 0) /* goto L_002e */;
        v0 = v3.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        v1 = "android.intent.extra.STREAM";
        _result = v0.getParcelableExtra(v1); // android.content.Intent.getParcelableExtra -> android.os.Parcelable
        v0 = _result;
        v0 = (android.net.Uri) v0;
        // goto L_0020
        v0 = new java.lang.IndexOutOfBoundsException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Stream items available: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v3.getStreamCount(); // android.support.v4.app.ShareCompat$IntentReader.getStreamCount -> int
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " index requested: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IndexOutOfBoundsException.<init> -> void
        throw v0;
    }

    public int getStreamCount() {
        // Registers (3 total): v2 = this
        v0 = v2.mStreams; // android.support.v4.app.ShareCompat$IntentReader.mStreams:java.util.ArrayList
        if (v0 != 0) /* goto L_0014 */;
        _result = v2.isMultipleShare(); // android.support.v4.app.ShareCompat$IntentReader.isMultipleShare -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        v1 = "android.intent.extra.STREAM";
        _result = v0.getParcelableArrayListExtra(v1); // android.content.Intent.getParcelableArrayListExtra -> java.util.ArrayList
        v0 = _result;
        v2.mStreams = v0; // android.support.v4.app.ShareCompat$IntentReader.mStreams:java.util.ArrayList
        v0 = v2.mStreams; // android.support.v4.app.ShareCompat$IntentReader.mStreams:java.util.ArrayList
        if (v0 == 0) /* goto L_001f */;
        v0 = v2.mStreams; // android.support.v4.app.ShareCompat$IntentReader.mStreams:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        return v0;
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        v1 = "android.intent.extra.STREAM";
        _result = v0.hasExtra(v1); // android.content.Intent.hasExtra -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002b */;
        v0 = 1;
        // goto L_001e
        v0 = 0;
        // goto L_001e
    }

    public java.lang.String getSubject() {
        // Registers (3 total): v2 = this
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        v1 = "android.intent.extra.SUBJECT";
        _result = v0.getStringExtra(v1); // android.content.Intent.getStringExtra -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getText() {
        // Registers (3 total): v2 = this
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        v1 = "android.intent.extra.TEXT";
        _result = v0.getCharSequenceExtra(v1); // android.content.Intent.getCharSequenceExtra -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.String getType() {
        // Registers (2 total): v1 = this
        v0 = v1.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        _result = v0.getType(); // android.content.Intent.getType -> java.lang.String
        v0 = _result;
        return v0;
    }

    public boolean isMultipleShare() {
        // Registers (3 total): v2 = this
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        _result = v0.getAction(); // android.content.Intent.getAction -> java.lang.String
        v0 = _result;
        v1 = "android.intent.action.SEND_MULTIPLE";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isShareIntent() {
        // Registers (3 total): v2 = this
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        _result = v0.getAction(); // android.content.Intent.getAction -> java.lang.String
        v0 = _result;
        v1 = "android.intent.action.SEND";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0016 */;
        v1 = "android.intent.action.SEND_MULTIPLE";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0018 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0017
    }

    public boolean isSingleShare() {
        // Registers (3 total): v2 = this
        v0 = v2.mIntent; // android.support.v4.app.ShareCompat$IntentReader.mIntent:android.content.Intent
        _result = v0.getAction(); // android.content.Intent.getAction -> java.lang.String
        v0 = _result;
        v1 = "android.intent.action.SEND";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        return v0;
    }

}