package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/FragmentManagerImpl$1;
 */
class FragmentManagerImpl$1 implements java.lang.Runnable {
    final android.support.v4.app.FragmentManagerImpl this$0;

    FragmentManagerImpl$1(android.support.v4.app.FragmentManagerImpl p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.FragmentManagerImpl)
        v0.this$0 = v1; // android.support.v4.app.FragmentManagerImpl$1.this$0:android.support.v4.app.FragmentManagerImpl
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (2 total): v1 = this
        v0 = v1.this$0; // android.support.v4.app.FragmentManagerImpl$1.this$0:android.support.v4.app.FragmentManagerImpl
        _result = v0.execPendingActions(); // android.support.v4.app.FragmentManagerImpl.execPendingActions -> boolean
        return;
    }

}