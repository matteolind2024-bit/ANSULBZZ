package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityManagerCompatIcs.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge;
 */
interface AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge {
    public abstract void onAccessibilityStateChanged(boolean p0);
}