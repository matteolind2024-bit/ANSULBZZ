package android.support.v4.view;

/**
 * Original SourceFile: VelocityTrackerCompatHoneycomb.java
 * Descriptor: Landroid/support/v4/view/VelocityTrackerCompatHoneycomb;
 */
class VelocityTrackerCompatHoneycomb {
    VelocityTrackerCompatHoneycomb() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static float getXVelocity(android.view.VelocityTracker p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.VelocityTracker), v2 = p1 (int)
        _result = v1.getXVelocity(v2); // android.view.VelocityTracker.getXVelocity -> float
        v0 = _result;
        return v0;
    }

    public static float getYVelocity(android.view.VelocityTracker p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.VelocityTracker), v2 = p1 (int)
        _result = v1.getYVelocity(v2); // android.view.VelocityTracker.getYVelocity -> float
        v0 = _result;
        return v0;
    }

}