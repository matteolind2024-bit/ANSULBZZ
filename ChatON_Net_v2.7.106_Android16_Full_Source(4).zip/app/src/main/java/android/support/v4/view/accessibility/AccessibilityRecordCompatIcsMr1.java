package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityRecordCompatIcsMr1.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcsMr1;
 */
class AccessibilityRecordCompatIcsMr1 {
    AccessibilityRecordCompatIcsMr1() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static int getMaxScrollX(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getMaxScrollX(); // android.view.accessibility.AccessibilityRecord.getMaxScrollX -> int
        v0 = _result;
        return v0;
    }

    public static int getMaxScrollY(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getMaxScrollY(); // android.view.accessibility.AccessibilityRecord.getMaxScrollY -> int
        v0 = _result;
        return v0;
    }

    public static void setMaxScrollX(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setMaxScrollX(v1); // android.view.accessibility.AccessibilityRecord.setMaxScrollX -> void
        return;
    }

    public static void setMaxScrollY(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setMaxScrollY(v1); // android.view.accessibility.AccessibilityRecord.setMaxScrollY -> void
        return;
    }

}