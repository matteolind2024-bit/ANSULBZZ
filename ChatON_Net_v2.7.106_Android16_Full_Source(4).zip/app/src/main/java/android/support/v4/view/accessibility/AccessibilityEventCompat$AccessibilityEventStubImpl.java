package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityEventCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventStubImpl;
 */
class AccessibilityEventCompat$AccessibilityEventStubImpl implements android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventVersionImpl {
    AccessibilityEventCompat$AccessibilityEventStubImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void appendRecord(android.view.accessibility.AccessibilityEvent p0, java.lang.Object p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.accessibility.AccessibilityEvent), v2 = p1 (java.lang.Object)
        return;
    }

    public java.lang.Object getRecord(android.view.accessibility.AccessibilityEvent p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityEvent), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

    public int getRecordCount(android.view.accessibility.AccessibilityEvent p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityEvent)
        v0 = 0;
        return v0;
    }

}