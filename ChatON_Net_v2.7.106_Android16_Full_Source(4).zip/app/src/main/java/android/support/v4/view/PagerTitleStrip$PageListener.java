package android.support.v4.view;

/**
 * Original SourceFile: PagerTitleStrip.java
 * Descriptor: Landroid/support/v4/view/PagerTitleStrip$PageListener;
 */
class PagerTitleStrip$PageListener extends android.database.DataSetObserver implements android.support.v4.view.ViewPager$OnAdapterChangeListener, android.support.v4.view.ViewPager$OnPageChangeListener {
    private int mScrollState;
    final android.support.v4.view.PagerTitleStrip this$0;

    private PagerTitleStrip$PageListener(android.support.v4.view.PagerTitleStrip p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.PagerTitleStrip)
        v0.this$0 = v1; // android.support.v4.view.PagerTitleStrip$PageListener.this$0:android.support.v4.view.PagerTitleStrip
        _result = v0.<init>(); // android.database.DataSetObserver.<init> -> void
        return;
    }

    PagerTitleStrip$PageListener(android.support.v4.view.PagerTitleStrip p0, android.support.v4.view.PagerTitleStrip$1 p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.view.PagerTitleStrip), v2 = p1 (android.support.v4.view.PagerTitleStrip$1)
        _result = v0.<init>(v1); // android.support.v4.view.PagerTitleStrip$PageListener.<init> -> void
        return;
    }

    public void onAdapterChanged(android.support.v4.view.PagerAdapter p0, android.support.v4.view.PagerAdapter p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.support.v4.view.PagerAdapter), v3 = p1 (android.support.v4.view.PagerAdapter)
        v0 = v1.this$0; // android.support.v4.view.PagerTitleStrip$PageListener.this$0:android.support.v4.view.PagerTitleStrip
        _result = v0.updateAdapter(v2, v3); // android.support.v4.view.PagerTitleStrip.updateAdapter -> void
        return;
    }

    public void onChanged() {
        // Registers (4 total): v3 = this
        v0 = v3.this$0; // android.support.v4.view.PagerTitleStrip$PageListener.this$0:android.support.v4.view.PagerTitleStrip
        v1 = v3.this$0; // android.support.v4.view.PagerTitleStrip$PageListener.this$0:android.support.v4.view.PagerTitleStrip
        v1 = v1.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        _result = v1.getCurrentItem(); // android.support.v4.view.ViewPager.getCurrentItem -> int
        v1 = _result;
        v2 = v3.this$0; // android.support.v4.view.PagerTitleStrip$PageListener.this$0:android.support.v4.view.PagerTitleStrip
        v2 = v2.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        _result = v2.getAdapter(); // android.support.v4.view.ViewPager.getAdapter -> android.support.v4.view.PagerAdapter
        v2 = _result;
        _result = v0.updateText(v1, v2); // android.support.v4.view.PagerTitleStrip.updateText -> void
        return;
    }

    public void onPageScrollStateChanged(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.mScrollState = v1; // android.support.v4.view.PagerTitleStrip$PageListener.mScrollState:int
        return;
    }

    public void onPageScrolled(int p0, float p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (float), v5 = p2 (int)
        v0 = 0x3f000000;
        v0 = cmp(v4, v0);
        if (v0 <= 0) /* goto L_0008 */;
        v3 = binOpLit8_0xd8(v3, 1);
        v0 = v2.this$0; // android.support.v4.view.PagerTitleStrip$PageListener.this$0:android.support.v4.view.PagerTitleStrip
        v1 = 0;
        _result = v0.updateTextPositions(v3, v4, v1); // android.support.v4.view.PagerTitleStrip.updateTextPositions -> void
        return;
    }

    public void onPageSelected(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.mScrollState; // android.support.v4.view.PagerTitleStrip$PageListener.mScrollState:int
        if (v0 != 0) /* goto L_0019 */;
        v0 = v3.this$0; // android.support.v4.view.PagerTitleStrip$PageListener.this$0:android.support.v4.view.PagerTitleStrip
        v1 = v3.this$0; // android.support.v4.view.PagerTitleStrip$PageListener.this$0:android.support.v4.view.PagerTitleStrip
        v1 = v1.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        _result = v1.getCurrentItem(); // android.support.v4.view.ViewPager.getCurrentItem -> int
        v1 = _result;
        v2 = v3.this$0; // android.support.v4.view.PagerTitleStrip$PageListener.this$0:android.support.v4.view.PagerTitleStrip
        v2 = v2.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        _result = v2.getAdapter(); // android.support.v4.view.ViewPager.getAdapter -> android.support.v4.view.PagerAdapter
        v2 = _result;
        _result = v0.updateText(v1, v2); // android.support.v4.view.PagerTitleStrip.updateText -> void
        return;
    }

}