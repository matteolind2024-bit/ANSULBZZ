package android.support.v4.accessibilityservice;

/**
 * Original SourceFile: AccessibilityServiceInfoCompatIcs.java
 * Descriptor: Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompatIcs;
 */
class AccessibilityServiceInfoCompatIcs {
    AccessibilityServiceInfoCompatIcs() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean getCanRetrieveWindowContent(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (2 total): v1 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        _result = v1.getCanRetrieveWindowContent(); // android.accessibilityservice.AccessibilityServiceInfo.getCanRetrieveWindowContent -> boolean
        v0 = _result;
        return v0;
    }

    public static java.lang.String getDescription(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (2 total): v1 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        _result = v1.getDescription(); // android.accessibilityservice.AccessibilityServiceInfo.getDescription -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String getId(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (2 total): v1 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        _result = v1.getId(); // android.accessibilityservice.AccessibilityServiceInfo.getId -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static android.content.pm.ResolveInfo getResolveInfo(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (2 total): v1 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        _result = v1.getResolveInfo(); // android.accessibilityservice.AccessibilityServiceInfo.getResolveInfo -> android.content.pm.ResolveInfo
        v0 = _result;
        return v0;
    }

    public static java.lang.String getSettingsActivityName(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (2 total): v1 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        _result = v1.getSettingsActivityName(); // android.accessibilityservice.AccessibilityServiceInfo.getSettingsActivityName -> java.lang.String
        v0 = _result;
        return v0;
    }

}