package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityNodeProviderCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
 */
public class AccessibilityNodeProviderCompat {
    private static final android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl IMPL;
    private final java.lang.Object mProvider;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl
        return;
        v0 = new android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl
        // goto L_000d
    }

    public AccessibilityNodeProviderCompat() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl
        _result = android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl.newAccessibilityNodeProviderBridge(v0, v1); // -> java.lang.Object
        v0 = _result;
        v1.mProvider = v0; // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.mProvider:java.lang.Object
        return;
    }

    public AccessibilityNodeProviderCompat(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.mProvider = v1; // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.mProvider:java.lang.Object
        return;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeInfoCompat createAccessibilityNodeInfo(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public java.util.List findAccessibilityNodeInfosByText(java.lang.String p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

    public java.lang.Object getProvider() {
        // Registers (2 total): v1 = this
        v0 = v1.mProvider; // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.mProvider:java.lang.Object
        return v0;
    }

    public boolean performAction(int p0, int p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (int), v4 = p2 (android.os.Bundle)
        v0 = 0;
        return v0;
    }

}