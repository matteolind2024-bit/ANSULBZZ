package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;
 */
class ViewPager$MyAccessibilityDelegate extends android.support.v4.view.AccessibilityDelegateCompat {
    final android.support.v4.view.ViewPager this$0;

    ViewPager$MyAccessibilityDelegate(android.support.v4.view.ViewPager p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.ViewPager)
        v0.this$0 = v1; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v0.<init>(); // android.support.v4.view.AccessibilityDelegateCompat.<init> -> void
        return;
    }

    public void onInitializeAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        _result = v1.onInitializeAccessibilityEvent(v2, v3); // android.support.v4.view.AccessibilityDelegateCompat.onInitializeAccessibilityEvent -> void
        v0 = android.support.v4.view.ViewPager.class;
        _result = v0.getName(); // java.lang.Class.getName -> java.lang.String
        v0 = _result;
        _result = v3.setClassName(v0); // android.view.accessibility.AccessibilityEvent.setClassName -> void
        return;
    }

    public void onInitializeAccessibilityNodeInfo(android.view.View p0, android.support.v4.view.accessibility.AccessibilityNodeInfoCompat p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.support.v4.view.accessibility.AccessibilityNodeInfoCompat)
        v0 = 1;
        _result = v2.onInitializeAccessibilityNodeInfo(v3, v4); // android.support.v4.view.AccessibilityDelegateCompat.onInitializeAccessibilityNodeInfo -> void
        v1 = android.support.v4.view.ViewPager.class;
        _result = v1.getName(); // java.lang.Class.getName -> java.lang.String
        v1 = _result;
        _result = v4.setClassName(v1); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.setClassName -> void
        v1 = v2.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v1.access$100(); // android.support.v4.view.ViewPager.access$100 -> android.support.v4.view.PagerAdapter
        v1 = _result;
        if (v1 == 0) /* goto L_0075 */;
        v1 = v2.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v1.access$100(); // android.support.v4.view.ViewPager.access$100 -> android.support.v4.view.PagerAdapter
        v1 = _result;
        _result = v1.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v1 = _result;
        if (v1 <= v0) /* goto L_0075 */;
        _result = v4.setScrollable(v0); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.setScrollable -> void
        v0 = v2.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v0.access$100(); // android.support.v4.view.ViewPager.access$100 -> android.support.v4.view.PagerAdapter
        v0 = _result;
        if (v0 == 0) /* goto L_004d */;
        v0 = v2.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v0.access$200(); // android.support.v4.view.ViewPager.access$200 -> int
        v0 = _result;
        if (v0 < 0) /* goto L_004d */;
        v0 = v2.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v0.access$200(); // android.support.v4.view.ViewPager.access$200 -> int
        v0 = _result;
        v1 = v2.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v1.access$100(); // android.support.v4.view.ViewPager.access$100 -> android.support.v4.view.PagerAdapter
        v1 = _result;
        _result = v1.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        if (v0 >= v1) /* goto L_004d */;
        v0 = 4096;
        _result = v4.addAction(v0); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.addAction -> void
        v0 = v2.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v0.access$100(); // android.support.v4.view.ViewPager.access$100 -> android.support.v4.view.PagerAdapter
        v0 = _result;
        if (v0 == 0) /* goto L_0074 */;
        v0 = v2.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v0.access$200(); // android.support.v4.view.ViewPager.access$200 -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0074 */;
        v0 = v2.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v0.access$200(); // android.support.v4.view.ViewPager.access$200 -> int
        v0 = _result;
        v1 = v2.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v1.access$100(); // android.support.v4.view.ViewPager.access$100 -> android.support.v4.view.PagerAdapter
        v1 = _result;
        _result = v1.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_0074 */;
        v0 = 8192;
        _result = v4.addAction(v0); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.addAction -> void
        return;
        v0 = 0;
        // goto L_0021
    }

    public boolean performAccessibilityAction(android.view.View p0, int p1, android.os.Bundle p2) {
        // Registers (8 total): v4 = this, v5 = p0 (android.view.View), v6 = p1 (int), v7 = p2 (android.os.Bundle)
        v0 = 1;
        v1 = 0;
        _result = v4.performAccessibilityAction(v5, v6, v7); // android.support.v4.view.AccessibilityDelegateCompat.performAccessibilityAction -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0009 */;
        return v0;
        // switch(v6)
        v0 = v1;
        // goto L_0008
        v2 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v2.access$100(); // android.support.v4.view.ViewPager.access$100 -> android.support.v4.view.PagerAdapter
        v2 = _result;
        if (v2 == 0) /* goto L_0040 */;
        v2 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v2.access$200(); // android.support.v4.view.ViewPager.access$200 -> int
        v2 = _result;
        if (v2 < 0) /* goto L_0040 */;
        v2 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v2.access$200(); // android.support.v4.view.ViewPager.access$200 -> int
        v2 = _result;
        v3 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v3.access$100(); // android.support.v4.view.ViewPager.access$100 -> android.support.v4.view.PagerAdapter
        v3 = _result;
        _result = v3.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v3 = _result;
        v3 = binOpLit8_0xd8(v3, -1);
        if (v2 >= v3) /* goto L_0040 */;
        v1 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        v2 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v2.access$200(); // android.support.v4.view.ViewPager.access$200 -> int
        v2 = _result;
        v2 = binOpLit8_0xd8(v2, 1);
        _result = v1.setCurrentItem(v2); // android.support.v4.view.ViewPager.setCurrentItem -> void
        // goto L_0008
        v0 = v1;
        // goto L_0008
        v2 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v2.access$100(); // android.support.v4.view.ViewPager.access$100 -> android.support.v4.view.PagerAdapter
        v2 = _result;
        if (v2 == 0) /* goto L_0072 */;
        v2 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v2.access$200(); // android.support.v4.view.ViewPager.access$200 -> int
        v2 = _result;
        if (v2 <= 0) /* goto L_0072 */;
        v2 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v2.access$200(); // android.support.v4.view.ViewPager.access$200 -> int
        v2 = _result;
        v3 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v3.access$100(); // android.support.v4.view.ViewPager.access$100 -> android.support.v4.view.PagerAdapter
        v3 = _result;
        _result = v3.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v3 = _result;
        if (v2 >= v3) /* goto L_0072 */;
        v1 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        v2 = v4.this$0; // android.support.v4.view.ViewPager$MyAccessibilityDelegate.this$0:android.support.v4.view.ViewPager
        _result = v2.access$200(); // android.support.v4.view.ViewPager.access$200 -> int
        v2 = _result;
        v2 = binOpLit8_0xd8(v2, -1);
        _result = v1.setCurrentItem(v2); // android.support.v4.view.ViewPager.setCurrentItem -> void
        // goto L_0008
        v0 = v1;
        // goto L_0008
    }

}