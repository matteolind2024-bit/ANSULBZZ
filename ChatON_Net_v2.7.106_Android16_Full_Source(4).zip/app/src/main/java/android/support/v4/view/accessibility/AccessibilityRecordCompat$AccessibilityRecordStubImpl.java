package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityRecordCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordStubImpl;
 */
class AccessibilityRecordCompat$AccessibilityRecordStubImpl implements android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl {
    AccessibilityRecordCompat$AccessibilityRecordStubImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int getAddedCount(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public java.lang.CharSequence getBeforeText(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public java.lang.CharSequence getClassName(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public java.lang.CharSequence getContentDescription(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public int getCurrentItemIndex(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public int getFromIndex(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public int getItemCount(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public int getMaxScrollX(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public int getMaxScrollY(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public android.os.Parcelable getParcelableData(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public int getRemovedCount(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public int getScrollX(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public int getScrollY(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeInfoCompat getSource(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public java.util.List getText(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        return v0;
    }

    public int getToIndex(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public int getWindowId(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public boolean isChecked(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public boolean isEnabled(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public boolean isFullScreen(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public boolean isPassword(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public boolean isScrollable(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public java.lang.Object obtain() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public java.lang.Object obtain(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public void recycle(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        return;
    }

    public void setAddedCount(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

    public void setBeforeText(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        return;
    }

    public void setChecked(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        return;
    }

    public void setClassName(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        return;
    }

    public void setContentDescription(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        return;
    }

    public void setCurrentItemIndex(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

    public void setEnabled(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        return;
    }

    public void setFromIndex(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

    public void setFullScreen(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        return;
    }

    public void setItemCount(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

    public void setMaxScrollX(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

    public void setMaxScrollY(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

    public void setParcelableData(java.lang.Object p0, android.os.Parcelable p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.os.Parcelable)
        return;
    }

    public void setPassword(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        return;
    }

    public void setRemovedCount(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

    public void setScrollX(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

    public void setScrollY(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

    public void setScrollable(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        return;
    }

    public void setSource(java.lang.Object p0, android.view.View p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View)
        return;
    }

    public void setSource(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (int)
        return;
    }

    public void setToIndex(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

}