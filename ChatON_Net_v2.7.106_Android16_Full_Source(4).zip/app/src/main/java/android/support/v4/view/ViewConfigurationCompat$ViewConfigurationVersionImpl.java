package android.support.v4.view;

/**
 * Original SourceFile: ViewConfigurationCompat.java
 * Descriptor: Landroid/support/v4/view/ViewConfigurationCompat$ViewConfigurationVersionImpl;
 */
interface ViewConfigurationCompat$ViewConfigurationVersionImpl {
    public abstract int getScaledPagingTouchSlop(android.view.ViewConfiguration p0);
}