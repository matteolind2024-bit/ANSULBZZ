package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompat.java
 * Descriptor: Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatStubImpl;
 */
class ViewGroupCompat$ViewGroupCompatStubImpl implements android.support.v4.view.ViewGroupCompat$ViewGroupCompatImpl {
    ViewGroupCompat$ViewGroupCompatStubImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean onRequestSendAccessibilityEvent(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (android.view.View), v4 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = 1;
        return v0;
    }

}