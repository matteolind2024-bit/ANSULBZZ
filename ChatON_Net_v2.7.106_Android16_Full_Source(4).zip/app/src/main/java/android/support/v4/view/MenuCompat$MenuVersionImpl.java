package android.support.v4.view;

/**
 * Original SourceFile: MenuCompat.java
 * Descriptor: Landroid/support/v4/view/MenuCompat$MenuVersionImpl;
 */
interface MenuCompat$MenuVersionImpl {
    public abstract boolean setShowAsAction(android.view.MenuItem p0, int p1);
}