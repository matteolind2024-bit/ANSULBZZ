package android.support.v4.app;

/**
 * Original SourceFile: FragmentStatePagerAdapter.java
 * Descriptor: Landroid/support/v4/app/FragmentStatePagerAdapter;
 */
public abstract class FragmentStatePagerAdapter extends android.support.v4.view.PagerAdapter {
    private static final boolean DEBUG;
    private static final java.lang.String TAG;
    private android.support.v4.app.FragmentTransaction mCurTransaction;
    private android.support.v4.app.Fragment mCurrentPrimaryItem;
    private final android.support.v4.app.FragmentManager mFragmentManager;
    private java.util.ArrayList mFragments;
    private java.util.ArrayList mSavedState;

    public FragmentStatePagerAdapter(android.support.v4.app.FragmentManager p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.FragmentManager)
        v1 = 0;
        _result = v2.<init>(); // android.support.v4.view.PagerAdapter.<init> -> void
        v2.mCurTransaction = v1; // android.support.v4.app.FragmentStatePagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v2.mSavedState = v0; // android.support.v4.app.FragmentStatePagerAdapter.mSavedState:java.util.ArrayList
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v2.mFragments = v0; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        v2.mCurrentPrimaryItem = v1; // android.support.v4.app.FragmentStatePagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        v2.mFragmentManager = v3; // android.support.v4.app.FragmentStatePagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        return;
    }

    public void destroyItem(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.view.ViewGroup), v5 = p1 (int), v6 = p2 (java.lang.Object)
        v2 = 0;
        v6 = (android.support.v4.app.Fragment) v6;
        v0 = v3.mCurTransaction; // android.support.v4.app.FragmentStatePagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        if (v0 != 0) /* goto L_000f */;
        v0 = v3.mFragmentManager; // android.support.v4.app.FragmentStatePagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        _result = v0.beginTransaction(); // android.support.v4.app.FragmentManager.beginTransaction -> android.support.v4.app.FragmentTransaction
        v0 = _result;
        v3.mCurTransaction = v0; // android.support.v4.app.FragmentStatePagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        v0 = v3.mSavedState; // android.support.v4.app.FragmentStatePagerAdapter.mSavedState:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > v5) /* goto L_001d */;
        v0 = v3.mSavedState; // android.support.v4.app.FragmentStatePagerAdapter.mSavedState:java.util.ArrayList
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        // goto L_000f
        v0 = v3.mSavedState; // android.support.v4.app.FragmentStatePagerAdapter.mSavedState:java.util.ArrayList
        v1 = v3.mFragmentManager; // android.support.v4.app.FragmentStatePagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        _result = v1.saveFragmentInstanceState(v6); // android.support.v4.app.FragmentManager.saveFragmentInstanceState -> android.support.v4.app.Fragment$SavedState
        v1 = _result;
        _result = v0.set(v5, v1); // java.util.ArrayList.set -> java.lang.Object
        v0 = v3.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        _result = v0.set(v5, v2); // java.util.ArrayList.set -> java.lang.Object
        v0 = v3.mCurTransaction; // android.support.v4.app.FragmentStatePagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        _result = v0.remove(v6); // android.support.v4.app.FragmentTransaction.remove -> android.support.v4.app.FragmentTransaction
        return;
    }

    public void finishUpdate(android.view.ViewGroup p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup)
        v0 = v1.mCurTransaction; // android.support.v4.app.FragmentStatePagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        if (v0 == 0) /* goto L_0011 */;
        v0 = v1.mCurTransaction; // android.support.v4.app.FragmentStatePagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        _result = v0.commitAllowingStateLoss(); // android.support.v4.app.FragmentTransaction.commitAllowingStateLoss -> int
        v0 = 0;
        v1.mCurTransaction = v0; // android.support.v4.app.FragmentStatePagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        v0 = v1.mFragmentManager; // android.support.v4.app.FragmentStatePagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        _result = v0.executePendingTransactions(); // android.support.v4.app.FragmentManager.executePendingTransactions -> boolean
        return;
    }

    public abstract android.support.v4.app.Fragment getItem(int p0);
    public java.lang.Object instantiateItem(android.view.ViewGroup p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.view.ViewGroup), v5 = p1 (int)
        v0 = v3.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= v5) /* goto L_0013 */;
        v0 = v3.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        _result = v0.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0013 */;
        return v0;
        v0 = v3.mCurTransaction; // android.support.v4.app.FragmentStatePagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        if (v0 != 0) /* goto L_001f */;
        v0 = v3.mFragmentManager; // android.support.v4.app.FragmentStatePagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        _result = v0.beginTransaction(); // android.support.v4.app.FragmentManager.beginTransaction -> android.support.v4.app.FragmentTransaction
        v0 = _result;
        v3.mCurTransaction = v0; // android.support.v4.app.FragmentStatePagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        _result = v3.getItem(v5); // android.support.v4.app.FragmentStatePagerAdapter.getItem -> android.support.v4.app.Fragment
        v1 = _result;
        v0 = v3.mSavedState; // android.support.v4.app.FragmentStatePagerAdapter.mSavedState:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= v5) /* goto L_0038 */;
        v0 = v3.mSavedState; // android.support.v4.app.FragmentStatePagerAdapter.mSavedState:java.util.ArrayList
        _result = v0.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment$SavedState) v0;
        if (v0 == 0) /* goto L_0038 */;
        _result = v1.setInitialSavedState(v0); // android.support.v4.app.Fragment.setInitialSavedState -> void
        v0 = v3.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > v5) /* goto L_0047 */;
        v0 = v3.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        v2 = 0;
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        // goto L_0038
        v0 = 0;
        _result = v1.setMenuVisibility(v0); // android.support.v4.app.Fragment.setMenuVisibility -> void
        v0 = v3.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        _result = v0.set(v5, v1); // java.util.ArrayList.set -> java.lang.Object
        v0 = v3.mCurTransaction; // android.support.v4.app.FragmentStatePagerAdapter.mCurTransaction:android.support.v4.app.FragmentTransaction
        _result = v4.getId(); // android.view.ViewGroup.getId -> int
        v2 = _result;
        _result = v0.add(v2, v1); // android.support.v4.app.FragmentTransaction.add -> android.support.v4.app.FragmentTransaction
        v0 = v1;
        // goto L_0012
    }

    public boolean isViewFromObject(android.view.View p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (java.lang.Object)
        v3 = (android.support.v4.app.Fragment) v3;
        _result = v3.getView(); // android.support.v4.app.Fragment.getView -> android.view.View
        v0 = _result;
        if (v0 != v2) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public void restoreState(android.os.Parcelable p0, java.lang.ClassLoader p1) {
        // Registers (9 total): v6 = this, v7 = p0 (android.os.Parcelable), v8 = p1 (java.lang.ClassLoader)
        v2 = 0;
        if (v7 == 0) /* goto L_0089 */;
        v7 = (android.os.Bundle) v7;
        _result = v7.setClassLoader(v8); // android.os.Bundle.setClassLoader -> void
        v0 = "states";
        _result = v7.getParcelableArray(v0); // android.os.Bundle.getParcelableArray -> android.os.Parcelable[]
        v3 = _result;
        v0 = v6.mSavedState; // android.support.v4.app.FragmentStatePagerAdapter.mSavedState:java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        v0 = v6.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        if (v3 == 0) /* goto L_002b */;
        v1 = v2;
        v0 = v3.length;
        if (v1 >= v0) /* goto L_002b */;
        v4 = v6.mSavedState; // android.support.v4.app.FragmentStatePagerAdapter.mSavedState:java.util.ArrayList
        v0 = v3[v1];
        v0 = (android.support.v4.app.Fragment$SavedState) v0;
        _result = v4.add(v0); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_001b
        _result = v7.keySet(); // android.os.Bundle.keySet -> java.util.Set
        v0 = _result;
        _result = java.lang.Iterable.iterator(v0); // -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0089 */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        v3 = "f";
        _result = v0.startsWith(v3); // java.lang.String.startsWith -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0033 */;
        v3 = 1;
        _result = v0.substring(v3); // java.lang.String.substring -> java.lang.String
        v3 = _result;
        _result = v3.parseInt(); // java.lang.Integer.parseInt -> int
        v3 = _result;
        v4 = v6.mFragmentManager; // android.support.v4.app.FragmentStatePagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        _result = v4.getFragment(v7, v0); // android.support.v4.app.FragmentManager.getFragment -> android.support.v4.app.Fragment
        v4 = _result;
        if (v4 == 0) /* goto L_0070 */;
        v0 = v6.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > v3) /* goto L_0067 */;
        v0 = v6.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        v5 = 0;
        _result = v0.add(v5); // java.util.ArrayList.add -> boolean
        // goto L_0058
        _result = v4.setMenuVisibility(v2); // android.support.v4.app.Fragment.setMenuVisibility -> void
        v0 = v6.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        _result = v0.set(v3, v4); // java.util.ArrayList.set -> java.lang.Object
        // goto L_0033
        v3 = "FragmentStatePagerAdapter";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "Bad fragment at key ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v3.w(v0); // android.util.Log.w -> int
        // goto L_0033
        return;
    }

    public android.os.Parcelable saveState() {
        // Registers (6 total): v5 = this
        v0 = 0;
        v1 = v5.mSavedState; // android.support.v4.app.FragmentStatePagerAdapter.mSavedState:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_0020 */;
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        v1 = v5.mSavedState; // android.support.v4.app.FragmentStatePagerAdapter.mSavedState:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = new android.support.v4.app.Fragment$SavedState[][size=v1];
        v2 = v5.mSavedState; // android.support.v4.app.FragmentStatePagerAdapter.mSavedState:java.util.ArrayList
        _result = v2.toArray(v1); // java.util.ArrayList.toArray -> java.lang.Object[]
        v2 = "states";
        _result = v0.putParcelableArray(v2, v1); // android.os.Bundle.putParcelableArray -> void
        v1 = 0;
        v2 = v0;
        v0 = v5.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0057 */;
        v0 = v5.mFragments; // android.support.v4.app.FragmentStatePagerAdapter.mFragments:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0053 */;
        if (v2 != 0) /* goto L_003b */;
        v2 = new android.os.Bundle;
        _result = v2.<init>(); // android.os.Bundle.<init> -> void
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "f";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v4 = v5.mFragmentManager; // android.support.v4.app.FragmentStatePagerAdapter.mFragmentManager:android.support.v4.app.FragmentManager
        _result = v4.putFragment(v2, v3, v0); // android.support.v4.app.FragmentManager.putFragment -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0022
        return v2;
    }

    public void setPrimaryItem(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.ViewGroup), v4 = p1 (int), v5 = p2 (java.lang.Object)
        v5 = (android.support.v4.app.Fragment) v5;
        v0 = v2.mCurrentPrimaryItem; // android.support.v4.app.FragmentStatePagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        if (v5 == v0) /* goto L_0018 */;
        v0 = v2.mCurrentPrimaryItem; // android.support.v4.app.FragmentStatePagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0010 */;
        v0 = v2.mCurrentPrimaryItem; // android.support.v4.app.FragmentStatePagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        v1 = 0;
        _result = v0.setMenuVisibility(v1); // android.support.v4.app.Fragment.setMenuVisibility -> void
        if (v5 == 0) /* goto L_0016 */;
        v0 = 1;
        _result = v5.setMenuVisibility(v0); // android.support.v4.app.Fragment.setMenuVisibility -> void
        v2.mCurrentPrimaryItem = v5; // android.support.v4.app.FragmentStatePagerAdapter.mCurrentPrimaryItem:android.support.v4.app.Fragment
        return;
    }

    public void startUpdate(android.view.ViewGroup p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.ViewGroup)
        return;
    }

}