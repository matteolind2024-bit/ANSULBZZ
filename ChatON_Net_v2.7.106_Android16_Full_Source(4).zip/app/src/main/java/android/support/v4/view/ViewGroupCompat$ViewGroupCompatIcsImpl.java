package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompat.java
 * Descriptor: Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatIcsImpl;
 */
class ViewGroupCompat$ViewGroupCompatIcsImpl extends android.support.v4.view.ViewGroupCompat$ViewGroupCompatStubImpl {
    ViewGroupCompat$ViewGroupCompatIcsImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.ViewGroupCompat$ViewGroupCompatStubImpl.<init> -> void
        return;
    }

    public boolean onRequestSendAccessibilityEvent(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (android.view.View), v4 = p2 (android.view.accessibility.AccessibilityEvent)
        _result = v2.onRequestSendAccessibilityEvent(v3, v4); // android.support.v4.view.ViewGroupCompatIcs.onRequestSendAccessibilityEvent -> boolean
        v0 = _result;
        return v0;
    }

}