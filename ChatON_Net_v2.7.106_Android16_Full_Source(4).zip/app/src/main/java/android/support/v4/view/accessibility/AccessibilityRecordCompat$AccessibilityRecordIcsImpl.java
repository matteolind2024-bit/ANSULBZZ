package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityRecordCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordIcsImpl;
 */
class AccessibilityRecordCompat$AccessibilityRecordIcsImpl extends android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordStubImpl {
    AccessibilityRecordCompat$AccessibilityRecordIcsImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordStubImpl.<init> -> void
        return;
    }

    public int getAddedCount(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getAddedCount(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getAddedCount -> int
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getBeforeText(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getBeforeText(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getBeforeText -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getClassName(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getClassName(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getClassName -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getContentDescription(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getContentDescription(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getContentDescription -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public int getCurrentItemIndex(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getCurrentItemIndex(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getCurrentItemIndex -> int
        v0 = _result;
        return v0;
    }

    public int getFromIndex(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getFromIndex(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getFromIndex -> int
        v0 = _result;
        return v0;
    }

    public int getItemCount(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getItemCount(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getItemCount -> int
        v0 = _result;
        return v0;
    }

    public android.os.Parcelable getParcelableData(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getParcelableData(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getParcelableData -> android.os.Parcelable
        v0 = _result;
        return v0;
    }

    public int getRemovedCount(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getRemovedCount(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getRemovedCount -> int
        v0 = _result;
        return v0;
    }

    public int getScrollX(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getScrollX(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getScrollX -> int
        v0 = _result;
        return v0;
    }

    public int getScrollY(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getScrollY(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getScrollY -> int
        v0 = _result;
        return v0;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeInfoCompat getSource(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getSource(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getSource -> java.lang.Object
        v0 = _result;
        _result = v0.wrapNonNullInstance(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.wrapNonNullInstance -> android.support.v4.view.accessibility.AccessibilityNodeInfoCompat
        v0 = _result;
        return v0;
    }

    public java.util.List getText(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getText(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getText -> java.util.List
        v0 = _result;
        return v0;
    }

    public int getToIndex(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getToIndex(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getToIndex -> int
        v0 = _result;
        return v0;
    }

    public int getWindowId(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getWindowId(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.getWindowId -> int
        v0 = _result;
        return v0;
    }

    public boolean isChecked(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isChecked(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.isChecked -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isEnabled(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isEnabled(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.isEnabled -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isFullScreen(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isFullScreen(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.isFullScreen -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isPassword(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isPassword(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.isPassword -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isScrollable(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isScrollable(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.isScrollable -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.Object obtain() {
        // Registers (2 total): v1 = this
        _result = this.obtain(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.obtain -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object obtain(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.obtain(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.obtain -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void recycle(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v1.recycle(); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.recycle -> void
        return;
    }

    public void setAddedCount(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.setAddedCount(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setAddedCount -> void
        return;
    }

    public void setBeforeText(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        _result = v1.setBeforeText(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setBeforeText -> void
        return;
    }

    public void setChecked(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setChecked(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setChecked -> void
        return;
    }

    public void setClassName(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        _result = v1.setClassName(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setClassName -> void
        return;
    }

    public void setContentDescription(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        _result = v1.setContentDescription(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setContentDescription -> void
        return;
    }

    public void setCurrentItemIndex(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.setCurrentItemIndex(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setCurrentItemIndex -> void
        return;
    }

    public void setEnabled(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setEnabled(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setEnabled -> void
        return;
    }

    public void setFromIndex(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.setFromIndex(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setFromIndex -> void
        return;
    }

    public void setFullScreen(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setFullScreen(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setFullScreen -> void
        return;
    }

    public void setItemCount(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.setItemCount(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setItemCount -> void
        return;
    }

    public void setParcelableData(java.lang.Object p0, android.os.Parcelable p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.os.Parcelable)
        _result = v1.setParcelableData(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setParcelableData -> void
        return;
    }

    public void setPassword(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setPassword(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setPassword -> void
        return;
    }

    public void setRemovedCount(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.setRemovedCount(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setRemovedCount -> void
        return;
    }

    public void setScrollX(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.setScrollX(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setScrollX -> void
        return;
    }

    public void setScrollY(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.setScrollY(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setScrollY -> void
        return;
    }

    public void setScrollable(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setScrollable(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setScrollable -> void
        return;
    }

    public void setSource(java.lang.Object p0, android.view.View p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View)
        _result = v1.setSource(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setSource -> void
        return;
    }

    public void setToIndex(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.setToIndex(v2); // android.support.v4.view.accessibility.AccessibilityRecordCompatIcs.setToIndex -> void
        return;
    }

}