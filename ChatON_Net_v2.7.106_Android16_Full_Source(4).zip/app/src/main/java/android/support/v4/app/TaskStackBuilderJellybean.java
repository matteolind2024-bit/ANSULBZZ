package android.support.v4.app;

/**
 * Original SourceFile: TaskStackBuilderJellybean.java
 * Descriptor: Landroid/support/v4/app/TaskStackBuilderJellybean;
 */
class TaskStackBuilderJellybean {
    TaskStackBuilderJellybean() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static android.app.PendingIntent getActivitiesPendingIntent(android.content.Context p0, int p1, android.content.Intent[] p2, int p3, android.os.Bundle p4) {
        // Registers (6 total): v1 = p0 (android.content.Context), v2 = p1 (int), v3 = p2 (android.content.Intent[]), v4 = p3 (int), v5 = p4 (android.os.Bundle)
        _result = v1.getActivities(v2, v3, v4, v5); // android.app.PendingIntent.getActivities -> android.app.PendingIntent
        v0 = _result;
        return v0;
    }

}