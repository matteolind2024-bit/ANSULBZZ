package android.support.v4.app;

/**
 * Original SourceFile: ActivityCompatHoneycomb.java
 * Descriptor: Landroid/support/v4/app/ActivityCompatHoneycomb;
 */
class ActivityCompatHoneycomb {
    ActivityCompatHoneycomb() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    static void dump(android.app.Activity p0, java.lang.String p1, java.io.FileDescriptor p2, java.io.PrintWriter p3, java.lang.String[] p4) {
        // Registers (5 total): v0 = p0 (android.app.Activity), v1 = p1 (java.lang.String), v2 = p2 (java.io.FileDescriptor), v3 = p3 (java.io.PrintWriter), v4 = p4 (java.lang.String[])
        _result = v0.dump(v1, v2, v3, v4); // android.app.Activity.dump -> void
        return;
    }

    static void invalidateOptionsMenu(android.app.Activity p0) {
        // Registers (1 total): v0 = p0 (android.app.Activity)
        _result = v0.invalidateOptionsMenu(); // android.app.Activity.invalidateOptionsMenu -> void
        return;
    }

}