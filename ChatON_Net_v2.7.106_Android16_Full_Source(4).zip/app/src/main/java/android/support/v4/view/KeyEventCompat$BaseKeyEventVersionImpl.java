package android.support.v4.view;

/**
 * Original SourceFile: KeyEventCompat.java
 * Descriptor: Landroid/support/v4/view/KeyEventCompat$BaseKeyEventVersionImpl;
 */
class KeyEventCompat$BaseKeyEventVersionImpl implements android.support.v4.view.KeyEventCompat$KeyEventVersionImpl {
    private static final int META_ALL_MASK;
    private static final int META_MODIFIER_MASK;

    KeyEventCompat$BaseKeyEventVersionImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    private static int metaStateFilterDirectionalModifiers(int p0, int p1, int p2, int p3, int p4) {
        // Registers (10 total): v5 = p0 (int), v6 = p1 (int), v7 = p2 (int), v8 = p3 (int), v9 = p4 (int)
        v0 = 1;
        v1 = 0;
        v2 = binOp_0x95(v6, v7);
        if (v2 == 0) /* goto L_0019 */;
        v2 = v0;
        v3 = binOp_0x96(v8, v9);
        v4 = binOp_0x95(v6, v3);
        if (v4 == 0) /* goto L_001b */;
        if (v2 == 0) /* goto L_0021 */;
        if (v0 == 0) /* goto L_001d */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "bad arguments";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v2 = v1;
        // goto L_0007
        v0 = v1;
        // goto L_000d
        v0 = binOpLit8_0xdf(v3, -1);
        v5 = binOp2addr_0xb5(v5, v0);
        return v5;
        if (v0 == 0) /* goto L_0020 */;
        v0 = binOpLit8_0xdf(v7, -1);
        v5 = binOp2addr_0xb5(v5, v0);
        // goto L_0020
    }

    public boolean metaStateHasModifiers(int p0, int p1) {
        // Registers (8 total): v5 = this, v6 = p0 (int), v7 = p1 (int)
        v0 = 1;
        _result = v5.normalizeMetaState(v6); // android.support.v4.view.KeyEventCompat$BaseKeyEventVersionImpl.normalizeMetaState -> int
        v1 = _result;
        v1 = binOpLit16_0xd5(v1, 247);
        v2 = 64;
        v3 = 128;
        _result = v1.metaStateFilterDirectionalModifiers(v7, v0, v2, v3); // android.support.v4.view.KeyEventCompat$BaseKeyEventVersionImpl.metaStateFilterDirectionalModifiers -> int
        v1 = _result;
        v2 = 2;
        v3 = 16;
        v4 = 32;
        _result = v1.metaStateFilterDirectionalModifiers(v7, v2, v3, v4); // android.support.v4.view.KeyEventCompat$BaseKeyEventVersionImpl.metaStateFilterDirectionalModifiers -> int
        v1 = _result;
        if (v1 != v7) /* goto L_001b */;
        return v0;
        v0 = 0;
        // goto L_001a
    }

    public boolean metaStateHasNoModifiers(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.normalizeMetaState(v2); // android.support.v4.view.KeyEventCompat$BaseKeyEventVersionImpl.normalizeMetaState -> int
        v0 = _result;
        v0 = binOpLit16_0xd5(v0, 247);
        if (v0 != 0) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public int normalizeMetaState(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = binOpLit16_0xd5(v3, 192);
        if (v0 == 0) /* goto L_000f */;
        v0 = binOpLit8_0xde(v3, 1);
        v1 = binOpLit8_0xdd(v0, 48);
        if (v1 == 0) /* goto L_000c */;
        v0 = binOpLit8_0xde(v0, 2);
        v0 = binOpLit16_0xd5(v0, 247);
        return v0;
        v0 = v3;
        // goto L_0006
    }

}