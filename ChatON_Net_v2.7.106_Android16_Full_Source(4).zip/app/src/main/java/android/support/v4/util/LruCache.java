package android.support.v4.util;

/**
 * Original SourceFile: LruCache.java
 * Descriptor: Landroid/support/v4/util/LruCache;
 */
public class LruCache {
    private int createCount;
    private int evictionCount;
    private int hitCount;
    private final java.util.LinkedHashMap map;
    private int maxSize;
    private int missCount;
    private int putCount;
    private int size;

    public LruCache(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        _result = v4.<init>(); // java.lang.Object.<init> -> void
        if (v5 > 0) /* goto L_000d */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "maxSize <= 0";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v4.maxSize = v5; // android.support.v4.util.LruCache.maxSize:int
        v0 = new java.util.LinkedHashMap;
        v1 = 0;
        v2 = 0x3f400000;
        v3 = 1;
        _result = v0.<init>(v1, v2, v3); // java.util.LinkedHashMap.<init> -> void
        v4.map = v0; // android.support.v4.util.LruCache.map:java.util.LinkedHashMap
        return;
    }

    private int safeSizeOf(java.lang.Object p0, java.lang.Object p1) {
        // Registers (6 total): v3 = this, v4 = p0 (java.lang.Object), v5 = p1 (java.lang.Object)
        _result = v3.sizeOf(v4, v5); // android.support.v4.util.LruCache.sizeOf -> int
        v0 = _result;
        if (v0 >= 0) /* goto L_0029 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Negative size: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "=";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        return v0;
    }

    private void trimToSize(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        // monitor-enter(v4)
        v0 = v4.size; // android.support.v4.util.LruCache.size:int
        if (v0 < 0) /* goto L_0011 */;
        v0 = v4.map; // android.support.v4.util.LruCache.map:java.util.LinkedHashMap
        _result = v0.isEmpty(); // java.util.LinkedHashMap.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0035 */;
        v0 = v4.size; // android.support.v4.util.LruCache.size:int
        if (v0 == 0) /* goto L_0035 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v2.getName(); // java.lang.Class.getName -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ".sizeOf() is reporting inconsistent results!";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = _exception;
        // monitor-exit(v4)
        throw v0;
        v0 = v4.size; // android.support.v4.util.LruCache.size:int
        if (v0 <= v5) /* goto L_0041 */;
        v0 = v4.map; // android.support.v4.util.LruCache.map:java.util.LinkedHashMap
        _result = v0.isEmpty(); // java.util.LinkedHashMap.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0043 */;
        // monitor-exit(v4)
        return;
        v0 = v4.map; // android.support.v4.util.LruCache.map:java.util.LinkedHashMap
        _result = v0.entrySet(); // java.util.LinkedHashMap.entrySet -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = java.util.Map$Entry.getKey(v0); // -> java.lang.Object
        v1 = _result;
        _result = java.util.Map$Entry.getValue(v0); // -> java.lang.Object
        v0 = _result;
        v2 = v4.map; // android.support.v4.util.LruCache.map:java.util.LinkedHashMap
        _result = v2.remove(v1); // java.util.LinkedHashMap.remove -> java.lang.Object
        v2 = v4.size; // android.support.v4.util.LruCache.size:int
        _result = v4.safeSizeOf(v1, v0); // android.support.v4.util.LruCache.safeSizeOf -> int
        v3 = _result;
        v2 = binOp2addr_0xb1(v2, v3);
        v4.size = v2; // android.support.v4.util.LruCache.size:int
        v2 = v4.evictionCount; // android.support.v4.util.LruCache.evictionCount:int
        v2 = binOpLit8_0xd8(v2, 1);
        v4.evictionCount = v2; // android.support.v4.util.LruCache.evictionCount:int
        // monitor-exit(v4)
        v2 = 1;
        v3 = 0;
        _result = v4.entryRemoved(v2, v1, v0, v3); // android.support.v4.util.LruCache.entryRemoved -> void
        // goto L_0000
    }

    protected java.lang.Object create(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public final int createCount() {
        // Registers (2 total): v1 = this
        // monitor-enter(v1)
        v0 = v1.createCount; // android.support.v4.util.LruCache.createCount:int
        // monitor-exit(v1)
        return v0;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

    protected void entryRemoved(boolean p0, java.lang.Object p1, java.lang.Object p2, java.lang.Object p3) {
        // Registers (5 total): v0 = this, v1 = p0 (boolean), v2 = p1 (java.lang.Object), v3 = p2 (java.lang.Object), v4 = p3 (java.lang.Object)
        return;
    }

    public final void evictAll() {
        // Registers (2 total): v1 = this
        v0 = -1;
        _result = v1.trimToSize(v0); // android.support.v4.util.LruCache.trimToSize -> void
        return;
    }

    public final int evictionCount() {
        // Registers (2 total): v1 = this
        // monitor-enter(v1)
        v0 = v1.evictionCount; // android.support.v4.util.LruCache.evictionCount:int
        // monitor-exit(v1)
        return v0;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

    public final java.lang.Object get(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        if (v5 != 0) /* goto L_000a */;
        v0 = new java.lang.NullPointerException;
        v1 = "key == null";
        _result = v0.<init>(v1); // java.lang.NullPointerException.<init> -> void
        throw v0;
        // monitor-enter(v4)
        v0 = v4.map; // android.support.v4.util.LruCache.map:java.util.LinkedHashMap
        _result = v0.get(v5); // java.util.LinkedHashMap.get -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_001b */;
        v1 = v4.hitCount; // android.support.v4.util.LruCache.hitCount:int
        v1 = binOpLit8_0xd8(v1, 1);
        v4.hitCount = v1; // android.support.v4.util.LruCache.hitCount:int
        // monitor-exit(v4)
        return v0;
        v0 = v4.missCount; // android.support.v4.util.LruCache.missCount:int
        v0 = binOpLit8_0xd8(v0, 1);
        v4.missCount = v0; // android.support.v4.util.LruCache.missCount:int
        // monitor-exit(v4)
        _result = v4.create(v5); // android.support.v4.util.LruCache.create -> java.lang.Object
        v1 = _result;
        if (v1 != 0) /* goto L_002d */;
        v0 = 0;
        // goto L_001a
        v0 = _exception;
        // monitor-exit(v4)
        throw v0;
        // monitor-enter(v4)
        v0 = v4.createCount; // android.support.v4.util.LruCache.createCount:int
        v0 = binOpLit8_0xd8(v0, 1);
        v4.createCount = v0; // android.support.v4.util.LruCache.createCount:int
        v0 = v4.map; // android.support.v4.util.LruCache.map:java.util.LinkedHashMap
        _result = v0.put(v5, v1); // java.util.LinkedHashMap.put -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_0049 */;
        v2 = v4.map; // android.support.v4.util.LruCache.map:java.util.LinkedHashMap
        _result = v2.put(v5, v0); // java.util.LinkedHashMap.put -> java.lang.Object
        // monitor-exit(v4)
        if (v0 == 0) /* goto L_0056 */;
        v2 = 0;
        _result = v4.entryRemoved(v2, v5, v1, v0); // android.support.v4.util.LruCache.entryRemoved -> void
        // goto L_001a
        v2 = v4.size; // android.support.v4.util.LruCache.size:int
        _result = v4.safeSizeOf(v5, v1); // android.support.v4.util.LruCache.safeSizeOf -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v4.size = v2; // android.support.v4.util.LruCache.size:int
        // goto L_0041
        v0 = _exception;
        // monitor-exit(v4)
        throw v0;
        v0 = v4.maxSize; // android.support.v4.util.LruCache.maxSize:int
        _result = v4.trimToSize(v0); // android.support.v4.util.LruCache.trimToSize -> void
        v0 = v1;
        // goto L_001a
    }

    public final int hitCount() {
        // Registers (2 total): v1 = this
        // monitor-enter(v1)
        v0 = v1.hitCount; // android.support.v4.util.LruCache.hitCount:int
        // monitor-exit(v1)
        return v0;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

    public final int maxSize() {
        // Registers (2 total): v1 = this
        // monitor-enter(v1)
        v0 = v1.maxSize; // android.support.v4.util.LruCache.maxSize:int
        // monitor-exit(v1)
        return v0;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

    public final int missCount() {
        // Registers (2 total): v1 = this
        // monitor-enter(v1)
        v0 = v1.missCount; // android.support.v4.util.LruCache.missCount:int
        // monitor-exit(v1)
        return v0;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

    public final java.lang.Object put(java.lang.Object p0, java.lang.Object p1) {
        // Registers (6 total): v3 = this, v4 = p0 (java.lang.Object), v5 = p1 (java.lang.Object)
        if (v4 == 0) /* goto L_0004 */;
        if (v5 != 0) /* goto L_000c */;
        v0 = new java.lang.NullPointerException;
        v1 = "key == null || value == null";
        _result = v0.<init>(v1); // java.lang.NullPointerException.<init> -> void
        throw v0;
        // monitor-enter(v3)
        v0 = v3.putCount; // android.support.v4.util.LruCache.putCount:int
        v0 = binOpLit8_0xd8(v0, 1);
        v3.putCount = v0; // android.support.v4.util.LruCache.putCount:int
        v0 = v3.size; // android.support.v4.util.LruCache.size:int
        _result = v3.safeSizeOf(v4, v5); // android.support.v4.util.LruCache.safeSizeOf -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v3.size = v0; // android.support.v4.util.LruCache.size:int
        v0 = v3.map; // android.support.v4.util.LruCache.map:java.util.LinkedHashMap
        _result = v0.put(v4, v5); // java.util.LinkedHashMap.put -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_002d */;
        v1 = v3.size; // android.support.v4.util.LruCache.size:int
        _result = v3.safeSizeOf(v4, v0); // android.support.v4.util.LruCache.safeSizeOf -> int
        v2 = _result;
        v1 = binOp2addr_0xb1(v1, v2);
        v3.size = v1; // android.support.v4.util.LruCache.size:int
        // monitor-exit(v3)
        if (v0 == 0) /* goto L_0034 */;
        v1 = 0;
        _result = v3.entryRemoved(v1, v4, v0, v5); // android.support.v4.util.LruCache.entryRemoved -> void
        v1 = v3.maxSize; // android.support.v4.util.LruCache.maxSize:int
        _result = v3.trimToSize(v1); // android.support.v4.util.LruCache.trimToSize -> void
        return v0;
        v0 = _exception;
        // monitor-exit(v3)
        throw v0;
    }

    public final int putCount() {
        // Registers (2 total): v1 = this
        // monitor-enter(v1)
        v0 = v1.putCount; // android.support.v4.util.LruCache.putCount:int
        // monitor-exit(v1)
        return v0;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

    public final java.lang.Object remove(java.lang.Object p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.Object)
        if (v4 != 0) /* goto L_000a */;
        v0 = new java.lang.NullPointerException;
        v1 = "key == null";
        _result = v0.<init>(v1); // java.lang.NullPointerException.<init> -> void
        throw v0;
        // monitor-enter(v3)
        v0 = v3.map; // android.support.v4.util.LruCache.map:java.util.LinkedHashMap
        _result = v0.remove(v4); // java.util.LinkedHashMap.remove -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_001c */;
        v1 = v3.size; // android.support.v4.util.LruCache.size:int
        _result = v3.safeSizeOf(v4, v0); // android.support.v4.util.LruCache.safeSizeOf -> int
        v2 = _result;
        v1 = binOp2addr_0xb1(v1, v2);
        v3.size = v1; // android.support.v4.util.LruCache.size:int
        // monitor-exit(v3)
        if (v0 == 0) /* goto L_0024 */;
        v1 = 0;
        v2 = 0;
        _result = v3.entryRemoved(v1, v4, v0, v2); // android.support.v4.util.LruCache.entryRemoved -> void
        return v0;
        v0 = _exception;
        // monitor-exit(v3)
        throw v0;
    }

    public final int size() {
        // Registers (2 total): v1 = this
        // monitor-enter(v1)
        v0 = v1.size; // android.support.v4.util.LruCache.size:int
        // monitor-exit(v1)
        return v0;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

    protected int sizeOf(java.lang.Object p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (java.lang.Object)
        v0 = 1;
        return v0;
    }

    public final java.util.Map snapshot() {
        // Registers (3 total): v2 = this
        // monitor-enter(v2)
        v0 = new java.util.LinkedHashMap;
        v1 = v2.map; // android.support.v4.util.LruCache.map:java.util.LinkedHashMap
        _result = v0.<init>(v1); // java.util.LinkedHashMap.<init> -> void
        // monitor-exit(v2)
        return v0;
        v0 = _exception;
        // monitor-exit(v2)
        throw v0;
    }

    public final java.lang.String toString() {
        // Registers (6 total): v5 = this
        v0 = 0;
        // monitor-enter(v5)
        v1 = v5.hitCount; // android.support.v4.util.LruCache.hitCount:int
        v2 = v5.missCount; // android.support.v4.util.LruCache.missCount:int
        v1 = binOp2addr_0xb0(v1, v2);
        if (v1 == 0) /* goto L_000e */;
        v0 = v5.hitCount; // android.support.v4.util.LruCache.hitCount:int
        v0 = binOpLit8_0xda(v0, 100);
        v0 = binOp2addr_0xb3(v0, v1);
        v1 = "LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]";
        v2 = 4;
        v2 = new java.lang.Object[][size=v2];
        v3 = 0;
        v4 = v5.maxSize; // android.support.v4.util.LruCache.maxSize:int
        _result = v4.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v4 = _result;
        v2[v3] = v4;
        v3 = 1;
        v4 = v5.hitCount; // android.support.v4.util.LruCache.hitCount:int
        _result = v4.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v4 = _result;
        v2[v3] = v4;
        v3 = 2;
        v4 = v5.missCount; // android.support.v4.util.LruCache.missCount:int
        _result = v4.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v4 = _result;
        v2[v3] = v4;
        v3 = 3;
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v0 = _result;
        v2[v3] = v0;
        _result = v1.format(v2); // java.lang.String.format -> java.lang.String
        v0 = _result;
        // monitor-exit(v5)
        return v0;
        v0 = _exception;
        // monitor-exit(v5)
        throw v0;
    }

}