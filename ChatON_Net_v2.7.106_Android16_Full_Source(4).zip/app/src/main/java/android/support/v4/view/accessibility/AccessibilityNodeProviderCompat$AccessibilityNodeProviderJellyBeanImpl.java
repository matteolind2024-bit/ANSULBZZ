package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityNodeProviderCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl;
 */
class AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl extends android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl {
    AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl.<init> -> void
        return;
    }

    public java.lang.Object newAccessibilityNodeProviderBridge(android.support.v4.view.accessibility.AccessibilityNodeProviderCompat p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.accessibility.AccessibilityNodeProviderCompat)
        v0 = new android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1;
        _result = v0.<init>(v1, v2); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1.<init> -> void
        _result = v0.newAccessibilityNodeProviderBridge(); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean.newAccessibilityNodeProviderBridge -> java.lang.Object
        v0 = _result;
        return v0;
    }

}