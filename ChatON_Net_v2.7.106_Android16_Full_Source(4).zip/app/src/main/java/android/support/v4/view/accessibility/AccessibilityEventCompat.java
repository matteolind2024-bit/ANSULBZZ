package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityEventCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityEventCompat;
 */
public class AccessibilityEventCompat {
    private static final android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventVersionImpl IMPL;
    public static final int TYPES_ALL_MASK;
    public static final int TYPE_ANNOUNCEMENT;
    public static final int TYPE_TOUCH_EXPLORATION_GESTURE_END;
    public static final int TYPE_TOUCH_EXPLORATION_GESTURE_START;
    public static final int TYPE_VIEW_ACCESSIBILITY_FOCUSED;
    public static final int TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED;
    public static final int TYPE_VIEW_HOVER_ENTER;
    public static final int TYPE_VIEW_HOVER_EXIT;
    public static final int TYPE_VIEW_SCROLLED;
    public static final int TYPE_VIEW_TEXT_SELECTION_CHANGED;
    public static final int TYPE_VIEW_TEXT_TRAVERSED_AT_MOVEMENT_GRANULARITY;
    public static final int TYPE_WINDOW_CONTENT_CHANGED;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventIcsImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventIcsImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventVersionImpl
        return;
        v0 = new android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventStubImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventStubImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventVersionImpl
        // goto L_000d
    }

    private AccessibilityEventCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void appendRecord(android.view.accessibility.AccessibilityEvent p0, android.support.v4.view.accessibility.AccessibilityRecordCompat p1) {
        // Registers (4 total): v2 = p0 (android.view.accessibility.AccessibilityEvent), v3 = p1 (android.support.v4.view.accessibility.AccessibilityRecordCompat)
        v0 = android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventVersionImpl
        _result = v3.getImpl(); // android.support.v4.view.accessibility.AccessibilityRecordCompat.getImpl -> java.lang.Object
        v1 = _result;
        _result = android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventVersionImpl.appendRecord(v0, v2, v1); // -> void
        return;
    }

    public static android.support.v4.view.accessibility.AccessibilityRecordCompat getRecord(android.view.accessibility.AccessibilityEvent p0, int p1) {
        // Registers (4 total): v2 = p0 (android.view.accessibility.AccessibilityEvent), v3 = p1 (int)
        v0 = new android.support.v4.view.accessibility.AccessibilityRecordCompat;
        v1 = android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventVersionImpl
        _result = android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventVersionImpl.getRecord(v1, v2, v3); // -> java.lang.Object
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.view.accessibility.AccessibilityRecordCompat.<init> -> void
        return v0;
    }

    public static int getRecordCount(android.view.accessibility.AccessibilityEvent p0) {
        // Registers (2 total): v1 = p0 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.accessibility.AccessibilityEventCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventVersionImpl
        _result = android.support.v4.view.accessibility.AccessibilityEventCompat$AccessibilityEventVersionImpl.getRecordCount(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

}