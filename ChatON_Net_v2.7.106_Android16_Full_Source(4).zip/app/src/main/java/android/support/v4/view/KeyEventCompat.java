package android.support.v4.view;

/**
 * Original SourceFile: KeyEventCompat.java
 * Descriptor: Landroid/support/v4/view/KeyEventCompat;
 */
public class KeyEventCompat {
    static final android.support.v4.view.KeyEventCompat$KeyEventVersionImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.KeyEventCompat$HoneycombKeyEventVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.KeyEventCompat$HoneycombKeyEventVersionImpl.<init> -> void
        android.support.v4.view.KeyEventCompat.IMPL = v0; // :android.support.v4.view.KeyEventCompat$KeyEventVersionImpl
        return;
        v0 = new android.support.v4.view.KeyEventCompat$BaseKeyEventVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.KeyEventCompat$BaseKeyEventVersionImpl.<init> -> void
        android.support.v4.view.KeyEventCompat.IMPL = v0; // :android.support.v4.view.KeyEventCompat$KeyEventVersionImpl
        // goto L_000d
    }

    public KeyEventCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean hasModifiers(android.view.KeyEvent p0, int p1) {
        // Registers (4 total): v2 = p0 (android.view.KeyEvent), v3 = p1 (int)
        v0 = android.support.v4.view.KeyEventCompat.IMPL; // :android.support.v4.view.KeyEventCompat$KeyEventVersionImpl
        _result = v2.getMetaState(); // android.view.KeyEvent.getMetaState -> int
        v1 = _result;
        _result = android.support.v4.view.KeyEventCompat$KeyEventVersionImpl.metaStateHasModifiers(v0, v1, v3); // -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean hasNoModifiers(android.view.KeyEvent p0) {
        // Registers (3 total): v2 = p0 (android.view.KeyEvent)
        v0 = android.support.v4.view.KeyEventCompat.IMPL; // :android.support.v4.view.KeyEventCompat$KeyEventVersionImpl
        _result = v2.getMetaState(); // android.view.KeyEvent.getMetaState -> int
        v1 = _result;
        _result = android.support.v4.view.KeyEventCompat$KeyEventVersionImpl.metaStateHasNoModifiers(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean metaStateHasModifiers(int p0, int p1) {
        // Registers (3 total): v1 = p0 (int), v2 = p1 (int)
        v0 = android.support.v4.view.KeyEventCompat.IMPL; // :android.support.v4.view.KeyEventCompat$KeyEventVersionImpl
        _result = android.support.v4.view.KeyEventCompat$KeyEventVersionImpl.metaStateHasModifiers(v0, v1, v2); // -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean metaStateHasNoModifiers(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = android.support.v4.view.KeyEventCompat.IMPL; // :android.support.v4.view.KeyEventCompat$KeyEventVersionImpl
        _result = android.support.v4.view.KeyEventCompat$KeyEventVersionImpl.metaStateHasNoModifiers(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public static int normalizeMetaState(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = android.support.v4.view.KeyEventCompat.IMPL; // :android.support.v4.view.KeyEventCompat$KeyEventVersionImpl
        _result = android.support.v4.view.KeyEventCompat$KeyEventVersionImpl.normalizeMetaState(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

}