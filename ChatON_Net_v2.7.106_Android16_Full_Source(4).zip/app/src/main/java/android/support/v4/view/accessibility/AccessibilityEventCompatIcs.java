package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityEventCompatIcs.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityEventCompatIcs;
 */
class AccessibilityEventCompatIcs {
    AccessibilityEventCompatIcs() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void appendRecord(android.view.accessibility.AccessibilityEvent p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (android.view.accessibility.AccessibilityEvent), v1 = p1 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v0.appendRecord(v1); // android.view.accessibility.AccessibilityEvent.appendRecord -> void
        return;
    }

    public static java.lang.Object getRecord(android.view.accessibility.AccessibilityEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.accessibility.AccessibilityEvent), v2 = p1 (int)
        _result = v1.getRecord(v2); // android.view.accessibility.AccessibilityEvent.getRecord -> android.view.accessibility.AccessibilityRecord
        v0 = _result;
        return v0;
    }

    public static int getRecordCount(android.view.accessibility.AccessibilityEvent p0) {
        // Registers (2 total): v1 = p0 (android.view.accessibility.AccessibilityEvent)
        _result = v1.getRecordCount(); // android.view.accessibility.AccessibilityEvent.getRecordCount -> int
        v0 = _result;
        return v0;
    }

}