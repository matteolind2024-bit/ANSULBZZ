package android.support.v4.net;

/**
 * Original SourceFile: TrafficStatsCompat.java
 * Descriptor: Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$1;
 */
class TrafficStatsCompat$BaseTrafficStatsCompatImpl$1 extends java.lang.ThreadLocal {
    final android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl this$0;

    TrafficStatsCompat$BaseTrafficStatsCompatImpl$1(android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl)
        v0.this$0 = v1; // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$1.this$0:android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl
        _result = v0.<init>(); // java.lang.ThreadLocal.<init> -> void
        return;
    }

    protected android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags initialValue() {
        // Registers (3 total): v2 = this
        v0 = new android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;
        v1 = 0;
        _result = v0.<init>(v1); // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags.<init> -> void
        return v0;
    }

    protected java.lang.Object initialValue() {
        // Registers (2 total): v1 = this
        _result = v1.initialValue(); // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$1.initialValue -> android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags
        v0 = _result;
        return v0;
    }

}