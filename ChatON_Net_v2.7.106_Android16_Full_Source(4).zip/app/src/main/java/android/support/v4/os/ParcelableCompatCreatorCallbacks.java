package android.support.v4.os;

/**
 * Original SourceFile: ParcelableCompatCreatorCallbacks.java
 * Descriptor: Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;
 */
public interface ParcelableCompatCreatorCallbacks {
    public abstract java.lang.Object createFromParcel(android.os.Parcel p0, java.lang.ClassLoader p1);
    public abstract java.lang.Object[] newArray(int p0);
}