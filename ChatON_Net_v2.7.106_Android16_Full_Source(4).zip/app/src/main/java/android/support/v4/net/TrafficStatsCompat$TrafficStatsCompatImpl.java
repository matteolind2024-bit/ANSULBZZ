package android.support.v4.net;

/**
 * Original SourceFile: TrafficStatsCompat.java
 * Descriptor: Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;
 */
interface TrafficStatsCompat$TrafficStatsCompatImpl {
    public abstract void clearThreadStatsTag();
    public abstract int getThreadStatsTag();
    public abstract void incrementOperationCount(int p0);
    public abstract void incrementOperationCount(int p0, int p1);
    public abstract void setThreadStatsTag(int p0);
    public abstract void tagSocket(java.net.Socket p0);
    public abstract void untagSocket(java.net.Socket p0);
}