package android.support.v4.view;

/**
 * Original SourceFile: MotionEventCompat.java
 * Descriptor: Landroid/support/v4/view/MotionEventCompat$EclairMotionEventVersionImpl;
 */
class MotionEventCompat$EclairMotionEventVersionImpl implements android.support.v4.view.MotionEventCompat$MotionEventVersionImpl {
    MotionEventCompat$EclairMotionEventVersionImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int findPointerIndex(android.view.MotionEvent p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MotionEvent), v3 = p1 (int)
        _result = v2.findPointerIndex(v3); // android.support.v4.view.MotionEventCompatEclair.findPointerIndex -> int
        v0 = _result;
        return v0;
    }

    public int getPointerId(android.view.MotionEvent p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MotionEvent), v3 = p1 (int)
        _result = v2.getPointerId(v3); // android.support.v4.view.MotionEventCompatEclair.getPointerId -> int
        v0 = _result;
        return v0;
    }

    public float getX(android.view.MotionEvent p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MotionEvent), v3 = p1 (int)
        _result = v2.getX(v3); // android.support.v4.view.MotionEventCompatEclair.getX -> float
        v0 = _result;
        return v0;
    }

    public float getY(android.view.MotionEvent p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MotionEvent), v3 = p1 (int)
        _result = v2.getY(v3); // android.support.v4.view.MotionEventCompatEclair.getY -> float
        v0 = _result;
        return v0;
    }

}