package android.support.v4.app;

/**
 * Original SourceFile: Fragment.java
 * Descriptor: Landroid/support/v4/app/Fragment;
 */
public class Fragment implements android.content.ComponentCallbacks, android.view.View$OnCreateContextMenuListener {
    static final int ACTIVITY_CREATED;
    static final int CREATED;
    static final int INITIALIZING;
    static final int RESUMED;
    static final int STARTED;
    static final int STOPPED;
    private static final java.util.HashMap sClassMap;
     android.support.v4.app.FragmentActivity mActivity;
     boolean mAdded;
     android.view.View mAnimatingAway;
     android.os.Bundle mArguments;
     int mBackStackNesting;
     boolean mCalled;
     boolean mCheckedForLoaderManager;
     android.view.ViewGroup mContainer;
     int mContainerId;
     boolean mDeferStart;
     boolean mDetached;
     int mFragmentId;
     android.support.v4.app.FragmentManagerImpl mFragmentManager;
     boolean mFromLayout;
     boolean mHasMenu;
     boolean mHidden;
     boolean mInLayout;
     int mIndex;
     android.view.View mInnerView;
     android.support.v4.app.LoaderManagerImpl mLoaderManager;
     boolean mLoadersStarted;
     boolean mMenuVisible;
     int mNextAnim;
     boolean mRemoving;
     boolean mRestored;
     boolean mResumed;
     boolean mRetainInstance;
     boolean mRetaining;
     android.os.Bundle mSavedFragmentState;
     android.util.SparseArray mSavedViewState;
     int mState;
     int mStateAfterAnimating;
     java.lang.String mTag;
     android.support.v4.app.Fragment mTarget;
     int mTargetIndex;
     int mTargetRequestCode;
     boolean mUserVisibleHint;
     android.view.View mView;
     java.lang.String mWho;

    static {
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        android.support.v4.app.Fragment.sClassMap = v0; // :java.util.HashMap
        return;
    }

    public Fragment() {
        // Registers (4 total): v3 = this
        v2 = 1;
        v1 = -1;
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v3.mState = v0; // android.support.v4.app.Fragment.mState:int
        v3.mIndex = v1; // android.support.v4.app.Fragment.mIndex:int
        v3.mTargetIndex = v1; // android.support.v4.app.Fragment.mTargetIndex:int
        v3.mMenuVisible = v2; // android.support.v4.app.Fragment.mMenuVisible:boolean
        v3.mUserVisibleHint = v2; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        return;
    }

    public static android.support.v4.app.Fragment instantiate(android.content.Context p0, java.lang.String p1) {
        // Registers (3 total): v1 = p0 (android.content.Context), v2 = p1 (java.lang.String)
        v0 = 0;
        _result = v1.instantiate(v2, v0); // android.support.v4.app.Fragment.instantiate -> android.support.v4.app.Fragment
        v0 = _result;
        return v0;
    }

    public static android.support.v4.app.Fragment instantiate(android.content.Context p0, java.lang.String p1, android.os.Bundle p2) {
        // Registers (7 total): v4 = p0 (android.content.Context), v5 = p1 (java.lang.String), v6 = p2 (android.os.Bundle)
        v0 = android.support.v4.app.Fragment.sClassMap; // :java.util.HashMap
        _result = v0.get(v5); // java.util.HashMap.get -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Class) v0;
        if (v0 != 0) /* goto L_0017 */;
        _result = v4.getClassLoader(); // android.content.Context.getClassLoader -> java.lang.ClassLoader
        v0 = _result;
        _result = v0.loadClass(v5); // java.lang.ClassLoader.loadClass -> java.lang.Class
        v0 = _result;
        v1 = android.support.v4.app.Fragment.sClassMap; // :java.util.HashMap
        _result = v1.put(v5, v0); // java.util.HashMap.put -> java.lang.Object
        _result = v0.newInstance(); // java.lang.Class.newInstance -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v6 == 0) /* goto L_002c */;
        _result = v0.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getClassLoader(); // java.lang.Class.getClassLoader -> java.lang.ClassLoader
        v1 = _result;
        _result = v6.setClassLoader(v1); // android.os.Bundle.setClassLoader -> void
        v0.mArguments = v6; // android.support.v4.app.Fragment.mArguments:android.os.Bundle
        return v0;
        v0 = _exception;
        v1 = new android.support.v4.app.Fragment$InstantiationException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Unable to instantiate fragment ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": make sure class name exists, is public, and has an";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " empty constructor that is public";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // android.support.v4.app.Fragment$InstantiationException.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new android.support.v4.app.Fragment$InstantiationException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Unable to instantiate fragment ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": make sure class name exists, is public, and has an";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " empty constructor that is public";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // android.support.v4.app.Fragment$InstantiationException.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new android.support.v4.app.Fragment$InstantiationException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Unable to instantiate fragment ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": make sure class name exists, is public, and has an";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " empty constructor that is public";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // android.support.v4.app.Fragment$InstantiationException.<init> -> void
        throw v1;
    }

    public void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (8 total): v3 = this, v4 = p0 (java.lang.String), v5 = p1 (java.io.FileDescriptor), v6 = p2 (java.io.PrintWriter), v7 = p3 (java.lang.String[])
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mFragmentId=#";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mContainerId=#";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mTag=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mState=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mState; // android.support.v4.app.Fragment.mState:int
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mIndex=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mWho=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mWho; // android.support.v4.app.Fragment.mWho:java.lang.String
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mBackStackNesting=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mAdded=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mRemoving=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mRemoving; // android.support.v4.app.Fragment.mRemoving:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mResumed=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mResumed; // android.support.v4.app.Fragment.mResumed:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mFromLayout=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mFromLayout; // android.support.v4.app.Fragment.mFromLayout:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mInLayout=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mInLayout; // android.support.v4.app.Fragment.mInLayout:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mHidden=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mDetached=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mMenuVisible=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mHasMenu=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mRetainInstance=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mRetainInstance; // android.support.v4.app.Fragment.mRetainInstance:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mRetaining=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mRetaining; // android.support.v4.app.Fragment.mRetaining:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mUserVisibleHint=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mFragmentManager; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.FragmentManagerImpl
        if (v0 == 0) /* goto L_00e6 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mFragmentManager=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mFragmentManager; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.FragmentManagerImpl
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_00f7 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mActivity=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mArguments; // android.support.v4.app.Fragment.mArguments:android.os.Bundle
        if (v0 == 0) /* goto L_0108 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mArguments=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mArguments; // android.support.v4.app.Fragment.mArguments:android.os.Bundle
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        if (v0 == 0) /* goto L_0119 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mSavedFragmentState=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        if (v0 == 0) /* goto L_012a */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mSavedViewState=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0145 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mTarget=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mTargetRequestCode=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mTargetRequestCode; // android.support.v4.app.Fragment.mTargetRequestCode:int
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mNextAnim; // android.support.v4.app.Fragment.mNextAnim:int
        if (v0 == 0) /* goto L_0156 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mNextAnim=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mNextAnim; // android.support.v4.app.Fragment.mNextAnim:int
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mContainer; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        if (v0 == 0) /* goto L_0167 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mContainer=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mContainer; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_0178 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mView=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mInnerView; // android.support.v4.app.Fragment.mInnerView:android.view.View
        if (v0 == 0) /* goto L_0189 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mInnerView=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        if (v0 == 0) /* goto L_01a7 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mAnimatingAway=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mStateAfterAnimating=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mStateAfterAnimating; // android.support.v4.app.Fragment.mStateAfterAnimating:int
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_01cb */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "Loader Manager:";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "  ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.dump(v1, v5, v6, v7); // android.support.v4.app.LoaderManagerImpl.dump -> void
        return;
    }

    public final boolean equals(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v1.equals(v2); // java.lang.Object.equals -> boolean
        v0 = _result;
        return v0;
    }

    public final android.support.v4.app.FragmentActivity getActivity() {
        // Registers (2 total): v1 = this
        v0 = v1.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        return v0;
    }

    public final android.os.Bundle getArguments() {
        // Registers (2 total): v1 = this
        v0 = v1.mArguments; // android.support.v4.app.Fragment.mArguments:android.os.Bundle
        return v0;
    }

    public final android.support.v4.app.FragmentManager getFragmentManager() {
        // Registers (2 total): v1 = this
        v0 = v1.mFragmentManager; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.FragmentManagerImpl
        return v0;
    }

    public final int getId() {
        // Registers (2 total): v1 = this
        v0 = v1.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        return v0;
    }

    public android.view.LayoutInflater getLayoutInflater(android.os.Bundle p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Bundle)
        v0 = v1.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.getLayoutInflater(); // android.support.v4.app.FragmentActivity.getLayoutInflater -> android.view.LayoutInflater
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.LoaderManager getLoaderManager() {
        // Registers (5 total): v4 = this
        v3 = 1;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_0008 */;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        return v0;
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_002b */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " not attached to Activity";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v4.mCheckedForLoaderManager = v3; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v2 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        _result = v0.getLoaderManager(v1, v2, v3); // android.support.v4.app.FragmentActivity.getLoaderManager -> android.support.v4.app.LoaderManagerImpl
        v0 = _result;
        v4.mLoaderManager = v0; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        // goto L_0007
    }

    public final android.content.res.Resources getResources() {
        // Registers (4 total): v3 = this
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_0023 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " not attached to Activity";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.getResources(); // android.support.v4.app.FragmentActivity.getResources -> android.content.res.Resources
        v0 = _result;
        return v0;
    }

    public final boolean getRetainInstance() {
        // Registers (2 total): v1 = this
        v0 = v1.mRetainInstance; // android.support.v4.app.Fragment.mRetainInstance:boolean
        return v0;
    }

    public final java.lang.String getString(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.getResources(); // android.support.v4.app.Fragment.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getString(v2); // android.content.res.Resources.getString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public final java.lang.String getString(int p0, java.lang.Object[] p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (java.lang.Object[])
        _result = v1.getResources(); // android.support.v4.app.Fragment.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getString(v2, v3); // android.content.res.Resources.getString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public final java.lang.String getTag() {
        // Registers (2 total): v1 = this
        v0 = v1.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        return v0;
    }

    public final android.support.v4.app.Fragment getTargetFragment() {
        // Registers (2 total): v1 = this
        v0 = v1.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        return v0;
    }

    public final int getTargetRequestCode() {
        // Registers (2 total): v1 = this
        v0 = v1.mTargetRequestCode; // android.support.v4.app.Fragment.mTargetRequestCode:int
        return v0;
    }

    public final java.lang.CharSequence getText(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.getResources(); // android.support.v4.app.Fragment.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getText(v2); // android.content.res.Resources.getText -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public boolean getUserVisibleHint() {
        // Registers (2 total): v1 = this
        v0 = v1.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        return v0;
    }

    public android.view.View getView() {
        // Registers (2 total): v1 = this
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        return v0;
    }

    public final int hashCode() {
        // Registers (2 total): v1 = this
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        return v0;
    }

    void initState() {
        // Registers (4 total): v3 = this
        v2 = 0;
        v1 = 0;
        v0 = -1;
        v3.mIndex = v0; // android.support.v4.app.Fragment.mIndex:int
        v3.mWho = v2; // android.support.v4.app.Fragment.mWho:java.lang.String
        v3.mAdded = v1; // android.support.v4.app.Fragment.mAdded:boolean
        v3.mRemoving = v1; // android.support.v4.app.Fragment.mRemoving:boolean
        v3.mResumed = v1; // android.support.v4.app.Fragment.mResumed:boolean
        v3.mFromLayout = v1; // android.support.v4.app.Fragment.mFromLayout:boolean
        v3.mInLayout = v1; // android.support.v4.app.Fragment.mInLayout:boolean
        v3.mRestored = v1; // android.support.v4.app.Fragment.mRestored:boolean
        v3.mBackStackNesting = v1; // android.support.v4.app.Fragment.mBackStackNesting:int
        v3.mFragmentManager = v2; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.FragmentManagerImpl
        v3.mActivity = v2; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v3.mFragmentId = v1; // android.support.v4.app.Fragment.mFragmentId:int
        v3.mContainerId = v1; // android.support.v4.app.Fragment.mContainerId:int
        v3.mTag = v2; // android.support.v4.app.Fragment.mTag:java.lang.String
        v3.mHidden = v1; // android.support.v4.app.Fragment.mHidden:boolean
        v3.mDetached = v1; // android.support.v4.app.Fragment.mDetached:boolean
        v3.mRetaining = v1; // android.support.v4.app.Fragment.mRetaining:boolean
        v3.mLoaderManager = v2; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        v3.mLoadersStarted = v1; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        v3.mCheckedForLoaderManager = v1; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        return;
    }

    public final boolean isAdded() {
        // Registers (2 total): v1 = this
        v0 = v1.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_000a */;
        v0 = v1.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 == 0) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public final boolean isDetached() {
        // Registers (2 total): v1 = this
        v0 = v1.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        return v0;
    }

    public final boolean isHidden() {
        // Registers (2 total): v1 = this
        v0 = v1.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        return v0;
    }

    final boolean isInBackStack() {
        // Registers (2 total): v1 = this
        v0 = v1.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        if (v0 <= 0) /* goto L_0006 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0005
    }

    public final boolean isInLayout() {
        // Registers (2 total): v1 = this
        v0 = v1.mInLayout; // android.support.v4.app.Fragment.mInLayout:boolean
        return v0;
    }

    public final boolean isRemoving() {
        // Registers (2 total): v1 = this
        v0 = v1.mRemoving; // android.support.v4.app.Fragment.mRemoving:boolean
        return v0;
    }

    public final boolean isResumed() {
        // Registers (2 total): v1 = this
        v0 = v1.mResumed; // android.support.v4.app.Fragment.mResumed:boolean
        return v0;
    }

    public final boolean isVisible() {
        // Registers (2 total): v1 = this
        _result = v1.isAdded(); // android.support.v4.app.Fragment.isAdded -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0022 */;
        _result = v1.isHidden(); // android.support.v4.app.Fragment.isHidden -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0022 */;
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_0022 */;
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.getWindowToken(); // android.view.View.getWindowToken -> android.os.IBinder
        v0 = _result;
        if (v0 == 0) /* goto L_0022 */;
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.getVisibility(); // android.view.View.getVisibility -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0022 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0021
    }

    public void onActivityCreated(android.os.Bundle p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Bundle)
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onActivityResult(int p0, int p1, android.content.Intent p2) {
        // Registers (4 total): v0 = this, v1 = p0 (int), v2 = p1 (int), v3 = p2 (android.content.Intent)
        return;
    }

    public void onAttach(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onConfigurationChanged(android.content.res.Configuration p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.res.Configuration)
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public boolean onContextItemSelected(android.view.MenuItem p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.MenuItem)
        v0 = 0;
        return v0;
    }

    public void onCreate(android.os.Bundle p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Bundle)
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public android.view.animation.Animation onCreateAnimation(int p0, boolean p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (boolean), v4 = p2 (int)
        v0 = 0;
        return v0;
    }

    public void onCreateContextMenu(android.view.ContextMenu p0, android.view.View p1, android.view.ContextMenu$ContextMenuInfo p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ContextMenu), v3 = p1 (android.view.View), v4 = p2 (android.view.ContextMenu$ContextMenuInfo)
        _result = v1.getActivity(); // android.support.v4.app.Fragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.onCreateContextMenu(v2, v3, v4); // android.support.v4.app.FragmentActivity.onCreateContextMenu -> void
        return;
    }

    public void onCreateOptionsMenu(android.view.Menu p0, android.view.MenuInflater p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.Menu), v2 = p1 (android.view.MenuInflater)
        return;
    }

    public android.view.View onCreateView(android.view.LayoutInflater p0, android.view.ViewGroup p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.LayoutInflater), v3 = p1 (android.view.ViewGroup), v4 = p2 (android.os.Bundle)
        v0 = 0;
        return v0;
    }

    public void onDestroy() {
        // Registers (5 total): v4 = this
        v1 = 1;
        v4.mCalled = v1; // android.support.v4.app.Fragment.mCalled:boolean
        v0 = v4.mCheckedForLoaderManager; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        if (v0 != 0) /* goto L_0016 */;
        v4.mCheckedForLoaderManager = v1; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v2 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        v3 = 0;
        _result = v0.getLoaderManager(v1, v2, v3); // android.support.v4.app.FragmentActivity.getLoaderManager -> android.support.v4.app.LoaderManagerImpl
        v0 = _result;
        v4.mLoaderManager = v0; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_001f */;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.doDestroy(); // android.support.v4.app.LoaderManagerImpl.doDestroy -> void
        return;
    }

    public void onDestroyOptionsMenu() {
        // Registers (1 total): v0 = this
        return;
    }

    public void onDestroyView() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onDetach() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onHiddenChanged(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        return;
    }

    public void onInflate(android.app.Activity p0, android.util.AttributeSet p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.app.Activity), v3 = p1 (android.util.AttributeSet), v4 = p2 (android.os.Bundle)
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onLowMemory() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public boolean onOptionsItemSelected(android.view.MenuItem p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.MenuItem)
        v0 = 0;
        return v0;
    }

    public void onOptionsMenuClosed(android.view.Menu p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.Menu)
        return;
    }

    public void onPause() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onPrepareOptionsMenu(android.view.Menu p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.Menu)
        return;
    }

    public void onResume() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onSaveInstanceState(android.os.Bundle p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.Bundle)
        return;
    }

    public void onStart() {
        // Registers (5 total): v4 = this
        v1 = 1;
        v4.mCalled = v1; // android.support.v4.app.Fragment.mCalled:boolean
        v0 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        if (v0 != 0) /* goto L_0025 */;
        v4.mLoadersStarted = v1; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        v0 = v4.mCheckedForLoaderManager; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        if (v0 != 0) /* goto L_001c */;
        v4.mCheckedForLoaderManager = v1; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v2 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        v3 = 0;
        _result = v0.getLoaderManager(v1, v2, v3); // android.support.v4.app.FragmentActivity.getLoaderManager -> android.support.v4.app.LoaderManagerImpl
        v0 = _result;
        v4.mLoaderManager = v0; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_0025 */;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.doStart(); // android.support.v4.app.LoaderManagerImpl.doStart -> void
        return;
    }

    public void onStop() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onViewCreated(android.view.View p0, android.os.Bundle p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.os.Bundle)
        return;
    }

    void performDestroyView() {
        // Registers (2 total): v1 = this
        _result = v1.onDestroyView(); // android.support.v4.app.Fragment.onDestroyView -> void
        v0 = v1.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_000c */;
        v0 = v1.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.doReportNextStart(); // android.support.v4.app.LoaderManagerImpl.doReportNextStart -> void
        return;
    }

    void performReallyStop() {
        // Registers (5 total): v4 = this
        v3 = 0;
        v0 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        if (v0 == 0) /* goto L_0029 */;
        v4.mLoadersStarted = v3; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        v0 = v4.mCheckedForLoaderManager; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        if (v0 != 0) /* goto L_001a */;
        v0 = 1;
        v4.mCheckedForLoaderManager = v0; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v2 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        _result = v0.getLoaderManager(v1, v2, v3); // android.support.v4.app.FragmentActivity.getLoaderManager -> android.support.v4.app.LoaderManagerImpl
        v0 = _result;
        v4.mLoaderManager = v0; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_0029 */;
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mRetaining; // android.support.v4.app.FragmentActivity.mRetaining:boolean
        if (v0 != 0) /* goto L_002a */;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.doStop(); // android.support.v4.app.LoaderManagerImpl.doStop -> void
        return;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.doRetain(); // android.support.v4.app.LoaderManagerImpl.doRetain -> void
        // goto L_0029
    }

    void performStart() {
        // Registers (2 total): v1 = this
        _result = v1.onStart(); // android.support.v4.app.Fragment.onStart -> void
        v0 = v1.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_000c */;
        v0 = v1.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.doReportStart(); // android.support.v4.app.LoaderManagerImpl.doReportStart -> void
        return;
    }

    void performStop() {
        // Registers (1 total): v0 = this
        _result = v0.onStop(); // android.support.v4.app.Fragment.onStop -> void
        return;
    }

    public void registerForContextMenu(android.view.View p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.View)
        _result = v1.setOnCreateContextMenuListener(v0); // android.view.View.setOnCreateContextMenuListener -> void
        return;
    }

    final void restoreViewState() {
        // Registers (3 total): v2 = this
        v0 = v2.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        if (v0 == 0) /* goto L_000e */;
        v0 = v2.mInnerView; // android.support.v4.app.Fragment.mInnerView:android.view.View
        v1 = v2.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        _result = v0.restoreHierarchyState(v1); // android.view.View.restoreHierarchyState -> void
        v0 = 0;
        v2.mSavedViewState = v0; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        return;
    }

    public void setArguments(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        v0 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v0 < 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Fragment already active";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v2.mArguments = v3; // android.support.v4.app.Fragment.mArguments:android.os.Bundle
        return;
    }

    public void setHasOptionsMenu(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == v2) /* goto L_0017 */;
        v1.mHasMenu = v2; // android.support.v4.app.Fragment.mHasMenu:boolean
        _result = v1.isAdded(); // android.support.v4.app.Fragment.isAdded -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        _result = v1.isHidden(); // android.support.v4.app.Fragment.isHidden -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        v0 = v1.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.supportInvalidateOptionsMenu(); // android.support.v4.app.FragmentActivity.supportInvalidateOptionsMenu -> void
        return;
    }

    final void setIndex(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v2.mIndex = v3; // android.support.v4.app.Fragment.mIndex:int
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "android:fragment:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v2.mWho = v0; // android.support.v4.app.Fragment.mWho:java.lang.String
        return;
    }

    public void setInitialSavedState(android.support.v4.app.Fragment$SavedState p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment$SavedState)
        v0 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v0 < 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Fragment already active";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        if (v3 == 0) /* goto L_0017 */;
        v0 = v3.mState; // android.support.v4.app.Fragment$SavedState.mState:android.os.Bundle
        if (v0 == 0) /* goto L_0017 */;
        v0 = v3.mState; // android.support.v4.app.Fragment$SavedState.mState:android.os.Bundle
        v2.mSavedFragmentState = v0; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        return;
        v0 = 0;
        // goto L_0014
    }

    public void setMenuVisibility(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == v2) /* goto L_001b */;
        v1.mMenuVisible = v2; // android.support.v4.app.Fragment.mMenuVisible:boolean
        v0 = v1.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_001b */;
        _result = v1.isAdded(); // android.support.v4.app.Fragment.isAdded -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001b */;
        _result = v1.isHidden(); // android.support.v4.app.Fragment.isHidden -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_001b */;
        v0 = v1.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.supportInvalidateOptionsMenu(); // android.support.v4.app.FragmentActivity.supportInvalidateOptionsMenu -> void
        return;
    }

    public void setRetainInstance(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        v0.mRetainInstance = v1; // android.support.v4.app.Fragment.mRetainInstance:boolean
        return;
    }

    public void setTargetFragment(android.support.v4.app.Fragment p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.app.Fragment), v2 = p1 (int)
        v0.mTarget = v1; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v0.mTargetRequestCode = v2; // android.support.v4.app.Fragment.mTargetRequestCode:int
        return;
    }

    public void setUserVisibleHint(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = v2.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        if (v0 != 0) /* goto L_0010 */;
        if (v3 == 0) /* goto L_0010 */;
        v0 = v2.mState; // android.support.v4.app.Fragment.mState:int
        v1 = 4;
        if (v0 >= v1) /* goto L_0010 */;
        v0 = v2.mFragmentManager; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.FragmentManagerImpl
        _result = v0.performPendingDeferredStart(v2); // android.support.v4.app.FragmentManagerImpl.performPendingDeferredStart -> void
        v2.mUserVisibleHint = v3; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        if (v3 != 0) /* goto L_0018 */;
        v0 = 1;
        v2.mDeferStart = v0; // android.support.v4.app.Fragment.mDeferStart:boolean
        return;
        v0 = 0;
        // goto L_0015
    }

    public void startActivity(android.content.Intent p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Intent)
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_0023 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " not attached to Activity";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = -1;
        _result = v0.startActivityFromFragment(v3, v4, v1); // android.support.v4.app.FragmentActivity.startActivityFromFragment -> void
        return;
    }

    public void startActivityForResult(android.content.Intent p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.Intent), v5 = p1 (int)
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_0023 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " not attached to Activity";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.startActivityFromFragment(v3, v4, v5); // android.support.v4.app.FragmentActivity.startActivityFromFragment -> void
        return;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 128;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v2.buildShortClassTag(v0); // android.support.v4.util.DebugUtils.buildShortClassTag -> void
        v1 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v1 < 0) /* goto L_0018 */;
        v1 = " #";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        if (v1 == 0) /* goto L_002a */;
        v1 = " id=0x";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        if (v1 == 0) /* goto L_0038 */;
        v1 = " ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void unregisterForContextMenu(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 0;
        _result = v2.setOnCreateContextMenuListener(v0); // android.view.View.setOnCreateContextMenuListener -> void
        return;
    }

}