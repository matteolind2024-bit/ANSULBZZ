package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/ModernAsyncTask$2;
 */
class ModernAsyncTask$2 extends android.support.v4.content.ModernAsyncTask$WorkerRunnable {
    final android.support.v4.content.ModernAsyncTask this$0;

    ModernAsyncTask$2(android.support.v4.content.ModernAsyncTask p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.content.ModernAsyncTask)
        v1.this$0 = v2; // android.support.v4.content.ModernAsyncTask$2.this$0:android.support.v4.content.ModernAsyncTask
        v0 = 0;
        _result = v1.<init>(v0); // android.support.v4.content.ModernAsyncTask$WorkerRunnable.<init> -> void
        return;
    }

    public java.lang.Object call() {
        // Registers (4 total): v3 = this
        v0 = v3.this$0; // android.support.v4.content.ModernAsyncTask$2.this$0:android.support.v4.content.ModernAsyncTask
        _result = v0.access$200(); // android.support.v4.content.ModernAsyncTask.access$200 -> java.util.concurrent.atomic.AtomicBoolean
        v0 = _result;
        v1 = 1;
        _result = v0.set(v1); // java.util.concurrent.atomic.AtomicBoolean.set -> void
        v0 = 10;
        _result = v0.setThreadPriority(); // android.os.Process.setThreadPriority -> void
        v0 = v3.this$0; // android.support.v4.content.ModernAsyncTask$2.this$0:android.support.v4.content.ModernAsyncTask
        v1 = v3.this$0; // android.support.v4.content.ModernAsyncTask$2.this$0:android.support.v4.content.ModernAsyncTask
        v2 = v3.mParams; // android.support.v4.content.ModernAsyncTask$2.mParams:java.lang.Object[]
        _result = v1.doInBackground(v2); // android.support.v4.content.ModernAsyncTask.doInBackground -> java.lang.Object
        v1 = _result;
        _result = v0.access$300(v1); // android.support.v4.content.ModernAsyncTask.access$300 -> java.lang.Object
        v0 = _result;
        return v0;
    }

}