package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityRecordCompatJellyBean.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityRecordCompatJellyBean;
 */
class AccessibilityRecordCompatJellyBean {
    AccessibilityRecordCompatJellyBean() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void setSource(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setSource(v1, v2); // android.view.accessibility.AccessibilityRecord.setSource -> void
        return;
    }

}