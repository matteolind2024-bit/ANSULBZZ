package android.support.v4.widget;

/**
 * Original SourceFile: SimpleCursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/SimpleCursorAdapter$ViewBinder;
 */
public interface SimpleCursorAdapter$ViewBinder {
    public abstract boolean setViewValue(android.view.View p0, android.database.Cursor p1, int p2);
}