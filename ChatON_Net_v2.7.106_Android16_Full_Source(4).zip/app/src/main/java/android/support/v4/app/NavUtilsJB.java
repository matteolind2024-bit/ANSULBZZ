package android.support.v4.app;

/**
 * Original SourceFile: NavUtilsJB.java
 * Descriptor: Landroid/support/v4/app/NavUtilsJB;
 */
class NavUtilsJB {
    NavUtilsJB() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static android.content.Intent getParentActivityIntent(android.app.Activity p0) {
        // Registers (2 total): v1 = p0 (android.app.Activity)
        _result = v1.getParentActivityIntent(); // android.app.Activity.getParentActivityIntent -> android.content.Intent
        v0 = _result;
        return v0;
    }

    public static java.lang.String getParentActivityName(android.content.pm.ActivityInfo p0) {
        // Registers (2 total): v1 = p0 (android.content.pm.ActivityInfo)
        v0 = v1.parentActivityName; // android.content.pm.ActivityInfo.parentActivityName:java.lang.String
        return v0;
    }

    public static void navigateUpTo(android.app.Activity p0, android.content.Intent p1) {
        // Registers (2 total): v0 = p0 (android.app.Activity), v1 = p1 (android.content.Intent)
        _result = v0.navigateUpTo(v1); // android.app.Activity.navigateUpTo -> boolean
        return;
    }

    public static boolean shouldUpRecreateTask(android.app.Activity p0, android.content.Intent p1) {
        // Registers (3 total): v1 = p0 (android.app.Activity), v2 = p1 (android.content.Intent)
        _result = v1.shouldUpRecreateTask(v2); // android.app.Activity.shouldUpRecreateTask -> boolean
        v0 = _result;
        return v0;
    }

}