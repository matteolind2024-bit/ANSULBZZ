package android.support.v4.widget;

/**
 * Original SourceFile: EdgeEffectCompat.java
 * Descriptor: Landroid/support/v4/widget/EdgeEffectCompat;
 */
public class EdgeEffectCompat {
    private static final android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl IMPL;
    private java.lang.Object mEdgeEffect;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.widget.EdgeEffectCompat$EdgeEffectIcsImpl;
        _result = v0.<init>(); // android.support.v4.widget.EdgeEffectCompat$EdgeEffectIcsImpl.<init> -> void
        android.support.v4.widget.EdgeEffectCompat.IMPL = v0; // :android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl
        return;
        v0 = new android.support.v4.widget.EdgeEffectCompat$BaseEdgeEffectImpl;
        _result = v0.<init>(); // android.support.v4.widget.EdgeEffectCompat$BaseEdgeEffectImpl.<init> -> void
        android.support.v4.widget.EdgeEffectCompat.IMPL = v0; // :android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl
        // goto L_000d
    }

    public EdgeEffectCompat(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = android.support.v4.widget.EdgeEffectCompat.IMPL; // :android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl
        _result = android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl.newEdgeEffect(v0, v2); // -> java.lang.Object
        v0 = _result;
        v1.mEdgeEffect = v0; // android.support.v4.widget.EdgeEffectCompat.mEdgeEffect:java.lang.Object
        return;
    }

    public boolean draw(android.graphics.Canvas p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Canvas)
        v0 = android.support.v4.widget.EdgeEffectCompat.IMPL; // :android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl
        v1 = v2.mEdgeEffect; // android.support.v4.widget.EdgeEffectCompat.mEdgeEffect:java.lang.Object
        _result = android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl.draw(v0, v1, v3); // -> boolean
        v0 = _result;
        return v0;
    }

    public void finish() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.EdgeEffectCompat.IMPL; // :android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl
        v1 = v2.mEdgeEffect; // android.support.v4.widget.EdgeEffectCompat.mEdgeEffect:java.lang.Object
        _result = android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl.finish(v0, v1); // -> void
        return;
    }

    public boolean isFinished() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.EdgeEffectCompat.IMPL; // :android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl
        v1 = v2.mEdgeEffect; // android.support.v4.widget.EdgeEffectCompat.mEdgeEffect:java.lang.Object
        _result = android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl.isFinished(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean onAbsorb(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.widget.EdgeEffectCompat.IMPL; // :android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl
        v1 = v2.mEdgeEffect; // android.support.v4.widget.EdgeEffectCompat.mEdgeEffect:java.lang.Object
        _result = android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl.onAbsorb(v0, v1, v3); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean onPull(float p0) {
        // Registers (4 total): v2 = this, v3 = p0 (float)
        v0 = android.support.v4.widget.EdgeEffectCompat.IMPL; // :android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl
        v1 = v2.mEdgeEffect; // android.support.v4.widget.EdgeEffectCompat.mEdgeEffect:java.lang.Object
        _result = android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl.onPull(v0, v1, v3); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean onRelease() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.EdgeEffectCompat.IMPL; // :android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl
        v1 = v2.mEdgeEffect; // android.support.v4.widget.EdgeEffectCompat.mEdgeEffect:java.lang.Object
        _result = android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl.onRelease(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public void setSize(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v0 = android.support.v4.widget.EdgeEffectCompat.IMPL; // :android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl
        v1 = v2.mEdgeEffect; // android.support.v4.widget.EdgeEffectCompat.mEdgeEffect:java.lang.Object
        _result = android.support.v4.widget.EdgeEffectCompat$EdgeEffectImpl.setSize(v0, v1, v3, v4); // -> void
        return;
    }

}