package android.support.v4.widget;

/**
 * Original SourceFile: CursorFilter.java
 * Descriptor: Landroid/support/v4/widget/CursorFilter$CursorFilterClient;
 */
interface CursorFilter$CursorFilterClient {
    public abstract void changeCursor(android.database.Cursor p0);
    public abstract java.lang.CharSequence convertToString(android.database.Cursor p0);
    public abstract android.database.Cursor getCursor();
    public abstract android.database.Cursor runQueryOnBackgroundThread(java.lang.CharSequence p0);
}