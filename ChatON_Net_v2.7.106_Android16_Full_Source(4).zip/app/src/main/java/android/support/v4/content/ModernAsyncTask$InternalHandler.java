package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/ModernAsyncTask$InternalHandler;
 */
class ModernAsyncTask$InternalHandler extends android.os.Handler {
    private ModernAsyncTask$InternalHandler() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.os.Handler.<init> -> void
        return;
    }

    ModernAsyncTask$InternalHandler(android.support.v4.content.ModernAsyncTask$1 p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.content.ModernAsyncTask$1)
        _result = v0.<init>(); // android.support.v4.content.ModernAsyncTask$InternalHandler.<init> -> void
        return;
    }

    public void handleMessage(android.os.Message p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Message)
        v0 = v4.obj; // android.os.Message.obj:java.lang.Object
        v0 = (android.support.v4.content.ModernAsyncTask$AsyncTaskResult) v0;
        v1 = v4.what; // android.os.Message.what:int
        // switch(v1)
        return;
        v1 = v0.mTask; // android.support.v4.content.ModernAsyncTask$AsyncTaskResult.mTask:android.support.v4.content.ModernAsyncTask
        v0 = v0.mData; // android.support.v4.content.ModernAsyncTask$AsyncTaskResult.mData:java.lang.Object[]
        v2 = 0;
        v0 = v0[v2];
        _result = v1.access$500(v0); // android.support.v4.content.ModernAsyncTask.access$500 -> void
        // goto L_0009
        v1 = v0.mTask; // android.support.v4.content.ModernAsyncTask$AsyncTaskResult.mTask:android.support.v4.content.ModernAsyncTask
        v0 = v0.mData; // android.support.v4.content.ModernAsyncTask$AsyncTaskResult.mData:java.lang.Object[]
        _result = v1.onProgressUpdate(v0); // android.support.v4.content.ModernAsyncTask.onProgressUpdate -> void
        // goto L_0009
    }

}