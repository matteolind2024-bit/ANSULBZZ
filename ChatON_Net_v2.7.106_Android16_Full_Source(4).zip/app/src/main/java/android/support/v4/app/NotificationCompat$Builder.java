package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/NotificationCompat$Builder;
 */
public class NotificationCompat$Builder {
     java.lang.CharSequence mContentInfo;
     android.app.PendingIntent mContentIntent;
     java.lang.CharSequence mContentText;
     java.lang.CharSequence mContentTitle;
     android.content.Context mContext;
     android.app.PendingIntent mFullScreenIntent;
     android.graphics.Bitmap mLargeIcon;
     android.app.Notification mNotification;
     int mNumber;
     android.widget.RemoteViews mTickerView;

    public NotificationCompat$Builder(android.content.Context p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Context)
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v0 = new android.app.Notification;
        _result = v0.<init>(); // android.app.Notification.<init> -> void
        v3.mNotification = v0; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v3.mContext = v4; // android.support.v4.app.NotificationCompat$Builder.mContext:android.content.Context
        v0 = v3.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v1 = _result;
        v0.when = v1; // android.app.Notification.when:long
        v0 = v3.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v1 = -1;
        v0.audioStreamType = v1; // android.app.Notification.audioStreamType:int
        return;
    }

    private void setFlag(int p0, boolean p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (boolean)
        if (v5 == 0) /* goto L_000a */;
        v0 = v3.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v1 = v0.flags; // android.app.Notification.flags:int
        v1 = binOp2addr_0xb6(v1, v4);
        v0.flags = v1; // android.app.Notification.flags:int
        return;
        v0 = v3.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v1 = v0.flags; // android.app.Notification.flags:int
        v2 = binOpLit8_0xdf(v4, -1);
        v1 = binOp2addr_0xb5(v1, v2);
        v0.flags = v1; // android.app.Notification.flags:int
        // goto L_0009
    }

    public android.app.Notification getNotification() {
        // Registers (2 total): v1 = this
        _result = this.access$000(); // android.support.v4.app.NotificationCompat.access$000 -> android.support.v4.app.NotificationCompat$NotificationCompatImpl
        v0 = _result;
        _result = android.support.v4.app.NotificationCompat$NotificationCompatImpl.getNotification(v0, v1); // -> android.app.Notification
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.NotificationCompat$Builder setAutoCancel(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = 16;
        _result = v1.setFlag(v0, v2); // android.support.v4.app.NotificationCompat$Builder.setFlag -> void
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setContent(android.widget.RemoteViews p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.widget.RemoteViews)
        v0 = v1.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.contentView = v2; // android.app.Notification.contentView:android.widget.RemoteViews
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setContentInfo(java.lang.CharSequence p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.CharSequence)
        v0.mContentInfo = v1; // android.support.v4.app.NotificationCompat$Builder.mContentInfo:java.lang.CharSequence
        return v0;
    }

    public android.support.v4.app.NotificationCompat$Builder setContentIntent(android.app.PendingIntent p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.app.PendingIntent)
        v0.mContentIntent = v1; // android.support.v4.app.NotificationCompat$Builder.mContentIntent:android.app.PendingIntent
        return v0;
    }

    public android.support.v4.app.NotificationCompat$Builder setContentText(java.lang.CharSequence p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.CharSequence)
        v0.mContentText = v1; // android.support.v4.app.NotificationCompat$Builder.mContentText:java.lang.CharSequence
        return v0;
    }

    public android.support.v4.app.NotificationCompat$Builder setContentTitle(java.lang.CharSequence p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.CharSequence)
        v0.mContentTitle = v1; // android.support.v4.app.NotificationCompat$Builder.mContentTitle:java.lang.CharSequence
        return v0;
    }

    public android.support.v4.app.NotificationCompat$Builder setDefaults(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.defaults = v3; // android.app.Notification.defaults:int
        v0 = binOpLit8_0xdd(v3, 4);
        if (v0 == 0) /* goto L_0010 */;
        v0 = v2.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v1 = v0.flags; // android.app.Notification.flags:int
        v1 = binOpLit8_0xde(v1, 1);
        v0.flags = v1; // android.app.Notification.flags:int
        return v2;
    }

    public android.support.v4.app.NotificationCompat$Builder setDeleteIntent(android.app.PendingIntent p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.PendingIntent)
        v0 = v1.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.deleteIntent = v2; // android.app.Notification.deleteIntent:android.app.PendingIntent
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setFullScreenIntent(android.app.PendingIntent p0, boolean p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.app.PendingIntent), v3 = p1 (boolean)
        v1.mFullScreenIntent = v2; // android.support.v4.app.NotificationCompat$Builder.mFullScreenIntent:android.app.PendingIntent
        v0 = 128;
        _result = v1.setFlag(v0, v3); // android.support.v4.app.NotificationCompat$Builder.setFlag -> void
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setLargeIcon(android.graphics.Bitmap p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.graphics.Bitmap)
        v0.mLargeIcon = v1; // android.support.v4.app.NotificationCompat$Builder.mLargeIcon:android.graphics.Bitmap
        return v0;
    }

    public android.support.v4.app.NotificationCompat$Builder setLights(int p0, int p1, int p2) {
        // Registers (9 total): v5 = this, v6 = p0 (int), v7 = p1 (int), v8 = p2 (int)
        v1 = 1;
        v2 = 0;
        v0 = v5.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.ledARGB = v6; // android.app.Notification.ledARGB:int
        v0 = v5.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.ledOnMS = v7; // android.app.Notification.ledOnMS:int
        v0 = v5.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.ledOffMS = v8; // android.app.Notification.ledOffMS:int
        v0 = v5.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0 = v0.ledOnMS; // android.app.Notification.ledOnMS:int
        if (v0 == 0) /* goto L_002a */;
        v0 = v5.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0 = v0.ledOffMS; // android.app.Notification.ledOffMS:int
        if (v0 == 0) /* goto L_002a */;
        v0 = v1;
        v3 = v5.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v4 = v5.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v4 = v4.flags; // android.app.Notification.flags:int
        v4 = binOpLit8_0xdd(v4, -2);
        if (v0 == 0) /* goto L_002c */;
        v0 = binOp_0x96(v4, v1);
        v3.flags = v0; // android.app.Notification.flags:int
        return v5;
        v0 = v2;
        // goto L_001b
        v1 = v2;
        // goto L_0025
    }

    public android.support.v4.app.NotificationCompat$Builder setNumber(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.mNumber = v1; // android.support.v4.app.NotificationCompat$Builder.mNumber:int
        return v0;
    }

    public android.support.v4.app.NotificationCompat$Builder setOngoing(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = 2;
        _result = v1.setFlag(v0, v2); // android.support.v4.app.NotificationCompat$Builder.setFlag -> void
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setOnlyAlertOnce(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = 8;
        _result = v1.setFlag(v0, v2); // android.support.v4.app.NotificationCompat$Builder.setFlag -> void
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setSmallIcon(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.icon = v2; // android.app.Notification.icon:int
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setSmallIcon(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = v1.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.icon = v2; // android.app.Notification.icon:int
        v0 = v1.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.iconLevel = v3; // android.app.Notification.iconLevel:int
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setSound(android.net.Uri p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.net.Uri)
        v0 = v2.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.sound = v3; // android.app.Notification.sound:android.net.Uri
        v0 = v2.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v1 = -1;
        v0.audioStreamType = v1; // android.app.Notification.audioStreamType:int
        return v2;
    }

    public android.support.v4.app.NotificationCompat$Builder setSound(android.net.Uri p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.net.Uri), v3 = p1 (int)
        v0 = v1.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.sound = v2; // android.app.Notification.sound:android.net.Uri
        v0 = v1.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.audioStreamType = v3; // android.app.Notification.audioStreamType:int
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setTicker(java.lang.CharSequence p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.CharSequence)
        v0 = v1.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.tickerText = v2; // android.app.Notification.tickerText:java.lang.CharSequence
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setTicker(java.lang.CharSequence p0, android.widget.RemoteViews p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.CharSequence), v3 = p1 (android.widget.RemoteViews)
        v0 = v1.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.tickerText = v2; // android.app.Notification.tickerText:java.lang.CharSequence
        v1.mTickerView = v3; // android.support.v4.app.NotificationCompat$Builder.mTickerView:android.widget.RemoteViews
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setVibrate(long[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (long[])
        v0 = v1.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.vibrate = v2; // android.app.Notification.vibrate:long[]
        return v1;
    }

    public android.support.v4.app.NotificationCompat$Builder setWhen(long p0) {
        // Registers (4 total): v1 = this, v2 = p0 (long)
        v0 = v1.mNotification; // android.support.v4.app.NotificationCompat$Builder.mNotification:android.app.Notification
        v0.when = v2; // android.app.Notification.when:long
        return v1;
    }

}