package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$OnAdapterChangeListener;
 */
interface ViewPager$OnAdapterChangeListener {
    public abstract void onAdapterChanged(android.support.v4.view.PagerAdapter p0, android.support.v4.view.PagerAdapter p1);
}