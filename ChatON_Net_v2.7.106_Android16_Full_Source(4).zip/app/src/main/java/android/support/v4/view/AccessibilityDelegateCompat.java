package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompat.java
 * Descriptor: Landroid/support/v4/view/AccessibilityDelegateCompat;
 */
public class AccessibilityDelegateCompat {
    private static final java.lang.Object DEFAULT_DELEGATE;
    private static final android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl IMPL;
    final java.lang.Object mBridge;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_0016 */;
        v0 = new android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl;
        _result = v0.<init>(); // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl.<init> -> void
        android.support.v4.view.AccessibilityDelegateCompat.IMPL = v0; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        v0 = android.support.v4.view.AccessibilityDelegateCompat.IMPL; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        _result = android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl.newAccessiblityDelegateDefaultImpl(v0); // -> java.lang.Object
        v0 = _result;
        android.support.v4.view.AccessibilityDelegateCompat.DEFAULT_DELEGATE = v0; // :java.lang.Object
        return;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_0024 */;
        v0 = new android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateIcsImpl;
        _result = v0.<init>(); // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateIcsImpl.<init> -> void
        android.support.v4.view.AccessibilityDelegateCompat.IMPL = v0; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        // goto L_000d
        v0 = new android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateStubImpl;
        _result = v0.<init>(); // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateStubImpl.<init> -> void
        android.support.v4.view.AccessibilityDelegateCompat.IMPL = v0; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        // goto L_000d
    }

    public AccessibilityDelegateCompat() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = android.support.v4.view.AccessibilityDelegateCompat.IMPL; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        _result = android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl.newAccessiblityDelegateBridge(v0, v1); // -> java.lang.Object
        v0 = _result;
        v1.mBridge = v0; // android.support.v4.view.AccessibilityDelegateCompat.mBridge:java.lang.Object
        return;
    }

    public boolean dispatchPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.AccessibilityDelegateCompat.IMPL; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        v1 = android.support.v4.view.AccessibilityDelegateCompat.DEFAULT_DELEGATE; // :java.lang.Object
        _result = android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl.dispatchPopulateAccessibilityEvent(v0, v1, v3, v4); // -> boolean
        v0 = _result;
        return v0;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeProviderCompat getAccessibilityNodeProvider(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = android.support.v4.view.AccessibilityDelegateCompat.IMPL; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        v1 = android.support.v4.view.AccessibilityDelegateCompat.DEFAULT_DELEGATE; // :java.lang.Object
        _result = android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl.getAccessibilityNodeProvider(v0, v1, v3); // -> android.support.v4.view.accessibility.AccessibilityNodeProviderCompat
        v0 = _result;
        return v0;
    }

    java.lang.Object getBridge() {
        // Registers (2 total): v1 = this
        v0 = v1.mBridge; // android.support.v4.view.AccessibilityDelegateCompat.mBridge:java.lang.Object
        return v0;
    }

    public void onInitializeAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.AccessibilityDelegateCompat.IMPL; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        v1 = android.support.v4.view.AccessibilityDelegateCompat.DEFAULT_DELEGATE; // :java.lang.Object
        _result = android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl.onInitializeAccessibilityEvent(v0, v1, v3, v4); // -> void
        return;
    }

    public void onInitializeAccessibilityNodeInfo(android.view.View p0, android.support.v4.view.accessibility.AccessibilityNodeInfoCompat p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.support.v4.view.accessibility.AccessibilityNodeInfoCompat)
        v0 = android.support.v4.view.AccessibilityDelegateCompat.IMPL; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        v1 = android.support.v4.view.AccessibilityDelegateCompat.DEFAULT_DELEGATE; // :java.lang.Object
        _result = android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl.onInitializeAccessibilityNodeInfo(v0, v1, v3, v4); // -> void
        return;
    }

    public void onPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.AccessibilityDelegateCompat.IMPL; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        v1 = android.support.v4.view.AccessibilityDelegateCompat.DEFAULT_DELEGATE; // :java.lang.Object
        _result = android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl.onPopulateAccessibilityEvent(v0, v1, v3, v4); // -> void
        return;
    }

    public boolean onRequestSendAccessibilityEvent(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.ViewGroup), v4 = p1 (android.view.View), v5 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.AccessibilityDelegateCompat.IMPL; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        v1 = android.support.v4.view.AccessibilityDelegateCompat.DEFAULT_DELEGATE; // :java.lang.Object
        _result = android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl.onRequestSendAccessibilityEvent(v0, v1, v3, v4, v5); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean performAccessibilityAction(android.view.View p0, int p1, android.os.Bundle p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int), v5 = p2 (android.os.Bundle)
        v0 = android.support.v4.view.AccessibilityDelegateCompat.IMPL; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        v1 = android.support.v4.view.AccessibilityDelegateCompat.DEFAULT_DELEGATE; // :java.lang.Object
        _result = android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl.performAccessibilityAction(v0, v1, v3, v4, v5); // -> boolean
        v0 = _result;
        return v0;
    }

    public void sendAccessibilityEvent(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = android.support.v4.view.AccessibilityDelegateCompat.IMPL; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        v1 = android.support.v4.view.AccessibilityDelegateCompat.DEFAULT_DELEGATE; // :java.lang.Object
        _result = android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl.sendAccessibilityEvent(v0, v1, v3, v4); // -> void
        return;
    }

    public void sendAccessibilityEventUnchecked(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.AccessibilityDelegateCompat.IMPL; // :android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl
        v1 = android.support.v4.view.AccessibilityDelegateCompat.DEFAULT_DELEGATE; // :java.lang.Object
        _result = android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateImpl.sendAccessibilityEventUnchecked(v0, v1, v3, v4); // -> void
        return;
    }

}