package android.support.v4.net;

/**
 * Original SourceFile: TrafficStatsCompat.java
 * Descriptor: Landroid/support/v4/net/TrafficStatsCompat;
 */
public class TrafficStatsCompat {
    private static final android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.net.TrafficStatsCompat$IcsTrafficStatsCompatImpl;
        _result = v0.<init>(); // android.support.v4.net.TrafficStatsCompat$IcsTrafficStatsCompatImpl.<init> -> void
        android.support.v4.net.TrafficStatsCompat.IMPL = v0; // :android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl
        return;
        v0 = new android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl;
        _result = v0.<init>(); // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl.<init> -> void
        android.support.v4.net.TrafficStatsCompat.IMPL = v0; // :android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl
        // goto L_000d
    }

    public TrafficStatsCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void clearThreadStatsTag() {
        v0 = android.support.v4.net.TrafficStatsCompat.IMPL; // :android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl
        _result = android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl.clearThreadStatsTag(v0); // -> void
        return;
    }

    public static int getThreadStatsTag() {
        v0 = android.support.v4.net.TrafficStatsCompat.IMPL; // :android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl
        _result = android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl.getThreadStatsTag(v0); // -> int
        v0 = _result;
        return v0;
    }

    public static void incrementOperationCount(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = android.support.v4.net.TrafficStatsCompat.IMPL; // :android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl
        _result = android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl.incrementOperationCount(v0, v1); // -> void
        return;
    }

    public static void incrementOperationCount(int p0, int p1) {
        // Registers (3 total): v1 = p0 (int), v2 = p1 (int)
        v0 = android.support.v4.net.TrafficStatsCompat.IMPL; // :android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl
        _result = android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl.incrementOperationCount(v0, v1, v2); // -> void
        return;
    }

    public static void setThreadStatsTag(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = android.support.v4.net.TrafficStatsCompat.IMPL; // :android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl
        _result = android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl.setThreadStatsTag(v0, v1); // -> void
        return;
    }

    public static void tagSocket(java.net.Socket p0) {
        // Registers (2 total): v1 = p0 (java.net.Socket)
        v0 = android.support.v4.net.TrafficStatsCompat.IMPL; // :android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl
        _result = android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl.tagSocket(v0, v1); // -> void
        return;
    }

    public static void untagSocket(java.net.Socket p0) {
        // Registers (2 total): v1 = p0 (java.net.Socket)
        v0 = android.support.v4.net.TrafficStatsCompat.IMPL; // :android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl
        _result = android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl.untagSocket(v0, v1); // -> void
        return;
    }

}