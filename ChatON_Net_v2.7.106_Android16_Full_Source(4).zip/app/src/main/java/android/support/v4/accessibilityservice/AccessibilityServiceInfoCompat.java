package android.support.v4.accessibilityservice;

/**
 * Original SourceFile: AccessibilityServiceInfoCompat.java
 * Descriptor: Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat;
 */
public class AccessibilityServiceInfoCompat {
    public static final int FEEDBACK_ALL_MASK;
    private static final android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoIcsImpl;
        _result = v0.<init>(); // android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoIcsImpl.<init> -> void
        android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat.IMPL = v0; // :android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl
        return;
        v0 = new android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl;
        _result = v0.<init>(); // android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl.<init> -> void
        android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat.IMPL = v0; // :android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl
        // goto L_000d
    }

    private AccessibilityServiceInfoCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static java.lang.String feedbackTypeToString(int p0) {
        // Registers (5 total): v4 = p0 (int)
        v3 = 1;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "[";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        if (v4 <= 0) /* goto L_0043 */;
        _result = v4.numberOfTrailingZeros(); // java.lang.Integer.numberOfTrailingZeros -> int
        v1 = _result;
        v1 = binOp_0x98(v3, v1);
        v2 = binOpLit8_0xdf(v1, -1);
        v4 = binOp2addr_0xb5(v4, v2);
        _result = v0.length(); // java.lang.StringBuilder.length -> int
        v2 = _result;
        if (v2 <= v3) /* goto L_0021 */;
        v2 = ", ";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // switch(v1)
        // goto L_000b
        v1 = "FEEDBACK_SPOKEN";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_000b
        v1 = "FEEDBACK_AUDIBLE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_000b
        v1 = "FEEDBACK_HAPTIC";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_000b
        v1 = "FEEDBACK_GENERIC";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_000b
        v1 = "FEEDBACK_VISUAL";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_000b
        v1 = "]";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String flagToString(int p0) {
        // Registers (2 total): v1 = p0 (int)
        // switch(v1)
        v0 = 0;
        return v0;
        v0 = "DEFAULT";
        // goto L_0004
    }

    public static boolean getCanRetrieveWindowContent(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (2 total): v1 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        v0 = android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat.IMPL; // :android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl
        _result = android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl.getCanRetrieveWindowContent(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public static java.lang.String getDescription(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (2 total): v1 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        v0 = android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat.IMPL; // :android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl
        _result = android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl.getDescription(v0, v1); // -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String getId(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (2 total): v1 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        v0 = android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat.IMPL; // :android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl
        _result = android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl.getId(v0, v1); // -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static android.content.pm.ResolveInfo getResolveInfo(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (2 total): v1 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        v0 = android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat.IMPL; // :android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl
        _result = android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl.getResolveInfo(v0, v1); // -> android.content.pm.ResolveInfo
        v0 = _result;
        return v0;
    }

    public static java.lang.String getSettingsActivityName(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (2 total): v1 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        v0 = android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat.IMPL; // :android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl
        _result = android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl.getSettingsActivityName(v0, v1); // -> java.lang.String
        v0 = _result;
        return v0;
    }

}