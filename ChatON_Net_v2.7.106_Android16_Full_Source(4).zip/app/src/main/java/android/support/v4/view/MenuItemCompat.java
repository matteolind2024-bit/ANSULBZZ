package android.support.v4.view;

/**
 * Original SourceFile: MenuItemCompat.java
 * Descriptor: Landroid/support/v4/view/MenuItemCompat;
 */
public class MenuItemCompat {
    static final android.support.v4.view.MenuItemCompat$MenuVersionImpl IMPL;
    public static final int SHOW_AS_ACTION_ALWAYS;
    public static final int SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW;
    public static final int SHOW_AS_ACTION_IF_ROOM;
    public static final int SHOW_AS_ACTION_NEVER;
    public static final int SHOW_AS_ACTION_WITH_TEXT;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.MenuItemCompat$HoneycombMenuVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.MenuItemCompat$HoneycombMenuVersionImpl.<init> -> void
        android.support.v4.view.MenuItemCompat.IMPL = v0; // :android.support.v4.view.MenuItemCompat$MenuVersionImpl
        return;
        v0 = new android.support.v4.view.MenuItemCompat$BaseMenuVersionImpl;
        _result = v0.<init>(); // android.support.v4.view.MenuItemCompat$BaseMenuVersionImpl.<init> -> void
        android.support.v4.view.MenuItemCompat.IMPL = v0; // :android.support.v4.view.MenuItemCompat$MenuVersionImpl
        // goto L_000d
    }

    public MenuItemCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static android.view.MenuItem setActionView(android.view.MenuItem p0, android.view.View p1) {
        // Registers (3 total): v1 = p0 (android.view.MenuItem), v2 = p1 (android.view.View)
        v0 = android.support.v4.view.MenuItemCompat.IMPL; // :android.support.v4.view.MenuItemCompat$MenuVersionImpl
        _result = android.support.v4.view.MenuItemCompat$MenuVersionImpl.setActionView(v0, v1, v2); // -> android.view.MenuItem
        v0 = _result;
        return v0;
    }

    public static boolean setShowAsAction(android.view.MenuItem p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MenuItem), v2 = p1 (int)
        v0 = android.support.v4.view.MenuItemCompat.IMPL; // :android.support.v4.view.MenuItemCompat$MenuVersionImpl
        _result = android.support.v4.view.MenuItemCompat$MenuVersionImpl.setShowAsAction(v0, v1, v2); // -> boolean
        v0 = _result;
        return v0;
    }

}