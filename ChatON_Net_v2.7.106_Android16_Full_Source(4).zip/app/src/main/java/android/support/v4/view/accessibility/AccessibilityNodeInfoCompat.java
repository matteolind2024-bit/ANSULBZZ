package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityNodeInfoCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;
 */
public class AccessibilityNodeInfoCompat {
    public static final int ACTION_ACCESSIBILITY_FOCUS;
    public static final java.lang.String ACTION_ARGUMENT_HTML_ELEMENT_STRING;
    public static final java.lang.String ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT;
    public static final int ACTION_CLEAR_ACCESSIBILITY_FOCUS;
    public static final int ACTION_CLEAR_FOCUS;
    public static final int ACTION_CLEAR_SELECTION;
    public static final int ACTION_CLICK;
    public static final int ACTION_FOCUS;
    public static final int ACTION_LONG_CLICK;
    public static final int ACTION_NEXT_AT_MOVEMENT_GRANULARITY;
    public static final int ACTION_NEXT_HTML_ELEMENT;
    public static final int ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY;
    public static final int ACTION_PREVIOUS_HTML_ELEMENT;
    public static final int ACTION_SCROLL_BACKWARD;
    public static final int ACTION_SCROLL_FORWARD;
    public static final int ACTION_SELECT;
    public static final int FOCUS_ACCESSIBILITY;
    public static final int FOCUS_INPUT;
    private static final android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl IMPL;
    public static final int MOVEMENT_GRANULARITY_CHARACTER;
    public static final int MOVEMENT_GRANULARITY_LINE;
    public static final int MOVEMENT_GRANULARITY_PAGE;
    public static final int MOVEMENT_GRANULARITY_PARAGRAPH;
    public static final int MOVEMENT_GRANULARITY_WORD;
    private final java.lang.Object mInfo;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        return;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_001c */;
        v0 = new android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoIcsImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoIcsImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        // goto L_000d
        v0 = new android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoStubImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoStubImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        // goto L_000d
    }

    public AccessibilityNodeInfoCompat(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.mInfo = v1; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        return;
    }

    public static android.support.v4.view.accessibility.AccessibilityNodeInfoCompat obtain() {
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.obtain(v0); // -> java.lang.Object
        v0 = _result;
        _result = v0.wrapNonNullInstance(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.wrapNonNullInstance -> android.support.v4.view.accessibility.AccessibilityNodeInfoCompat
        v0 = _result;
        return v0;
    }

    public static android.support.v4.view.accessibility.AccessibilityNodeInfoCompat obtain(android.support.v4.view.accessibility.AccessibilityNodeInfoCompat p0) {
        // Registers (3 total): v2 = p0 (android.support.v4.view.accessibility.AccessibilityNodeInfoCompat)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.obtain(v0, v1); // -> java.lang.Object
        v0 = _result;
        _result = v0.wrapNonNullInstance(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.wrapNonNullInstance -> android.support.v4.view.accessibility.AccessibilityNodeInfoCompat
        v0 = _result;
        return v0;
    }

    public static android.support.v4.view.accessibility.AccessibilityNodeInfoCompat obtain(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.obtain(v0, v1); // -> java.lang.Object
        v0 = _result;
        _result = v0.wrapNonNullInstance(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.wrapNonNullInstance -> android.support.v4.view.accessibility.AccessibilityNodeInfoCompat
        v0 = _result;
        return v0;
    }

    public static android.support.v4.view.accessibility.AccessibilityNodeInfoCompat obtain(android.view.View p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.obtain(v0, v1, v2); // -> java.lang.Object
        v0 = _result;
        _result = v0.wrapNonNullInstance(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.wrapNonNullInstance -> android.support.v4.view.accessibility.AccessibilityNodeInfoCompat
        v0 = _result;
        return v0;
    }

    static android.support.v4.view.accessibility.AccessibilityNodeInfoCompat wrapNonNullInstance(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        if (v1 == 0) /* goto L_0008 */;
        v0 = new android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
        _result = v0.<init>(v1); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.<init> -> void
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public void addAction(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.addAction(v0, v1, v3); // -> void
        return;
    }

    public void addChild(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.addChild(v0, v1, v3); // -> void
        return;
    }

    public void addChild(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.addChild(v0, v1, v3, v4); // -> void
        return;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        if (v5 != 0) /* goto L_0009 */;
        v0 = v1;
        // goto L_0004
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0015 */;
        v0 = v1;
        // goto L_0004
        v5 = (android.support.v4.view.accessibility.AccessibilityNodeInfoCompat) v5;
        v2 = v4.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        if (v2 != 0) /* goto L_0021 */;
        v2 = v5.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        if (v2 == 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v4.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        v3 = v5.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public java.util.List findAccessibilityNodeInfosByText(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v2 = v6.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.findAccessibilityNodeInfosByText(v0, v2, v7); // -> java.util.List
        v2 = _result;
        _result = java.util.List.size(v2); // -> int
        v3 = _result;
        v0 = 0;
        if (v0 >= v3) /* goto L_0023 */;
        _result = java.util.List.get(v2, v0); // -> java.lang.Object
        v4 = _result;
        v5 = new android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
        _result = v5.<init>(v4); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.<init> -> void
        _result = java.util.List.add(v1, v5); // -> boolean
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0012
        return v1;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeInfoCompat findFocus(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.findFocus(v0, v1, v3); // -> java.lang.Object
        v0 = _result;
        _result = v0.wrapNonNullInstance(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.wrapNonNullInstance -> android.support.v4.view.accessibility.AccessibilityNodeInfoCompat
        v0 = _result;
        return v0;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeInfoCompat focusSearch(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.focusSearch(v0, v1, v3); // -> java.lang.Object
        v0 = _result;
        _result = v0.wrapNonNullInstance(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.wrapNonNullInstance -> android.support.v4.view.accessibility.AccessibilityNodeInfoCompat
        v0 = _result;
        return v0;
    }

    public int getActions() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getActions(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public void getBoundsInParent(android.graphics.Rect p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Rect)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getBoundsInParent(v0, v1, v3); // -> void
        return;
    }

    public void getBoundsInScreen(android.graphics.Rect p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Rect)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getBoundsInScreen(v0, v1, v3); // -> void
        return;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeInfoCompat getChild(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getChild(v0, v1, v3); // -> java.lang.Object
        v0 = _result;
        _result = v0.wrapNonNullInstance(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.wrapNonNullInstance -> android.support.v4.view.accessibility.AccessibilityNodeInfoCompat
        v0 = _result;
        return v0;
    }

    public int getChildCount() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getChildCount(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getClassName() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getClassName(v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getContentDescription() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getContentDescription(v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.Object getInfo() {
        // Registers (2 total): v1 = this
        v0 = v1.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        return v0;
    }

    public int getMovementGranularities() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getMovementGranularities(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getPackageName() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getPackageName(v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeInfoCompat getParent() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getParent(v0, v1); // -> java.lang.Object
        v0 = _result;
        _result = v0.wrapNonNullInstance(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.wrapNonNullInstance -> android.support.v4.view.accessibility.AccessibilityNodeInfoCompat
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getText() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getText(v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public int getWindowId() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.getWindowId(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int hashCode() {
        // Registers (2 total): v1 = this
        v0 = v1.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        if (v0 != 0) /* goto L_0006 */;
        v0 = 0;
        return v0;
        v0 = v1.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        // goto L_0005
    }

    public boolean isAccessibilityFocused() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isAccessibilityFocused(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isCheckable() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isCheckable(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isChecked() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isChecked(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isClickable() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isClickable(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isEnabled() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isEnabled(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isFocusable() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isFocusable(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isFocused() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isFocused(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isLongClickable() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isLongClickable(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isPassword() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isPassword(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isScrollable() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isScrollable(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isSelected() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isSelected(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isVisibleToUser() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.isVisibleToUser(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean performAction(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.performAction(v0, v1, v3); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean performAction(int p0, android.os.Bundle p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (android.os.Bundle)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.performAction(v0, v1, v3, v4); // -> boolean
        v0 = _result;
        return v0;
    }

    public void recycle() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.recycle(v0, v1); // -> void
        return;
    }

    public void setAccessibilityFocused(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setAccessibilityFocused(v0, v1, v3); // -> void
        return;
    }

    public void setBoundsInParent(android.graphics.Rect p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Rect)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setBoundsInParent(v0, v1, v3); // -> void
        return;
    }

    public void setBoundsInScreen(android.graphics.Rect p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Rect)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setBoundsInScreen(v0, v1, v3); // -> void
        return;
    }

    public void setCheckable(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setCheckable(v0, v1, v3); // -> void
        return;
    }

    public void setChecked(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setChecked(v0, v1, v3); // -> void
        return;
    }

    public void setClassName(java.lang.CharSequence p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.CharSequence)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setClassName(v0, v1, v3); // -> void
        return;
    }

    public void setClickable(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setClickable(v0, v1, v3); // -> void
        return;
    }

    public void setContentDescription(java.lang.CharSequence p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.CharSequence)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setContentDescription(v0, v1, v3); // -> void
        return;
    }

    public void setEnabled(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setEnabled(v0, v1, v3); // -> void
        return;
    }

    public void setFocusable(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setFocusable(v0, v1, v3); // -> void
        return;
    }

    public void setFocused(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setFocused(v0, v1, v3); // -> void
        return;
    }

    public void setLongClickable(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setLongClickable(v0, v1, v3); // -> void
        return;
    }

    public void setMovementGranularities(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setMovementGranularities(v0, v1, v3); // -> void
        return;
    }

    public void setPackageName(java.lang.CharSequence p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.CharSequence)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setPackageName(v0, v1, v3); // -> void
        return;
    }

    public void setParent(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setParent(v0, v1, v3); // -> void
        return;
    }

    public void setParent(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setParent(v0, v1, v3, v4); // -> void
        return;
    }

    public void setPassword(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setPassword(v0, v1, v3); // -> void
        return;
    }

    public void setScrollable(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setScrollable(v0, v1, v3); // -> void
        return;
    }

    public void setSelected(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setSelected(v0, v1, v3); // -> void
        return;
    }

    public void setSource(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setSource(v0, v1, v3); // -> void
        return;
    }

    public void setSource(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setSource(v0, v1, v3, v4); // -> void
        return;
    }

    public void setText(java.lang.CharSequence p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.CharSequence)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setText(v0, v1, v3); // -> void
        return;
    }

    public void setVisibleToUser(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl
        v1 = v2.mInfo; // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.mInfo:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl.setVisibleToUser(v0, v1, v3); // -> void
        return;
    }

}