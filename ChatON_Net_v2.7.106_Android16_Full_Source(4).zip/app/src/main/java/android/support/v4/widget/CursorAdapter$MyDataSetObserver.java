package android.support.v4.widget;

/**
 * Original SourceFile: CursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/CursorAdapter$MyDataSetObserver;
 */
class CursorAdapter$MyDataSetObserver extends android.database.DataSetObserver {
    final android.support.v4.widget.CursorAdapter this$0;

    private CursorAdapter$MyDataSetObserver(android.support.v4.widget.CursorAdapter p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.CursorAdapter)
        v0.this$0 = v1; // android.support.v4.widget.CursorAdapter$MyDataSetObserver.this$0:android.support.v4.widget.CursorAdapter
        _result = v0.<init>(); // android.database.DataSetObserver.<init> -> void
        return;
    }

    CursorAdapter$MyDataSetObserver(android.support.v4.widget.CursorAdapter p0, android.support.v4.widget.CursorAdapter$1 p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.widget.CursorAdapter), v2 = p1 (android.support.v4.widget.CursorAdapter$1)
        _result = v0.<init>(v1); // android.support.v4.widget.CursorAdapter$MyDataSetObserver.<init> -> void
        return;
    }

    public void onChanged() {
        // Registers (3 total): v2 = this
        v0 = v2.this$0; // android.support.v4.widget.CursorAdapter$MyDataSetObserver.this$0:android.support.v4.widget.CursorAdapter
        v1 = 1;
        v0.mDataValid = v1; // android.support.v4.widget.CursorAdapter.mDataValid:boolean
        v0 = v2.this$0; // android.support.v4.widget.CursorAdapter$MyDataSetObserver.this$0:android.support.v4.widget.CursorAdapter
        _result = v0.notifyDataSetChanged(); // android.support.v4.widget.CursorAdapter.notifyDataSetChanged -> void
        return;
    }

    public void onInvalidated() {
        // Registers (3 total): v2 = this
        v0 = v2.this$0; // android.support.v4.widget.CursorAdapter$MyDataSetObserver.this$0:android.support.v4.widget.CursorAdapter
        v1 = 0;
        v0.mDataValid = v1; // android.support.v4.widget.CursorAdapter.mDataValid:boolean
        v0 = v2.this$0; // android.support.v4.widget.CursorAdapter$MyDataSetObserver.this$0:android.support.v4.widget.CursorAdapter
        _result = v0.notifyDataSetInvalidated(); // android.support.v4.widget.CursorAdapter.notifyDataSetInvalidated -> void
        return;
    }

}