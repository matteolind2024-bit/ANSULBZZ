package android.support.v4.view;

/**
 * Original SourceFile: PagerTitleStripIcs.java
 * Descriptor: Landroid/support/v4/view/PagerTitleStripIcs$SingleLineAllCapsTransform;
 */
class PagerTitleStripIcs$SingleLineAllCapsTransform extends android.text.method.SingleLineTransformationMethod {
    private static final java.lang.String TAG;
    private java.util.Locale mLocale;

    public PagerTitleStripIcs$SingleLineAllCapsTransform(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        _result = v1.<init>(); // android.text.method.SingleLineTransformationMethod.<init> -> void
        _result = v2.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getConfiguration(); // android.content.res.Resources.getConfiguration -> android.content.res.Configuration
        v0 = _result;
        v0 = v0.locale; // android.content.res.Configuration.locale:java.util.Locale
        v1.mLocale = v0; // android.support.v4.view.PagerTitleStripIcs$SingleLineAllCapsTransform.mLocale:java.util.Locale
        return;
    }

    public java.lang.CharSequence getTransformation(java.lang.CharSequence p0, android.view.View p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.CharSequence), v4 = p1 (android.view.View)
        _result = v2.getTransformation(v3, v4); // android.text.method.SingleLineTransformationMethod.getTransformation -> java.lang.CharSequence
        v0 = _result;
        if (v0 == 0) /* goto L_0011 */;
        _result = v0.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        v1 = v2.mLocale; // android.support.v4.view.PagerTitleStripIcs$SingleLineAllCapsTransform.mLocale:java.util.Locale
        _result = v0.toUpperCase(v1); // java.lang.String.toUpperCase -> java.lang.String
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_0010
    }

}