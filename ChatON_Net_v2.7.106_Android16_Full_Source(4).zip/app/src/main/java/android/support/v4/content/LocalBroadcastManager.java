package android.support.v4.content;

/**
 * Original SourceFile: LocalBroadcastManager.java
 * Descriptor: Landroid/support/v4/content/LocalBroadcastManager;
 */
public class LocalBroadcastManager {
    private static final boolean DEBUG;
    static final int MSG_EXEC_PENDING_BROADCASTS;
    private static final java.lang.String TAG;
    private static android.support.v4.content.LocalBroadcastManager mInstance;
    private static final java.lang.Object mLock;
    private final java.util.HashMap mActions;
    private final android.content.Context mAppContext;
    private final android.os.Handler mHandler;
    private final java.util.ArrayList mPendingBroadcasts;
    private final java.util.HashMap mReceivers;

    static {
        v0 = new java.lang.Object;
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        android.support.v4.content.LocalBroadcastManager.mLock = v0; // :java.lang.Object
        return;
    }

    private LocalBroadcastManager(android.content.Context p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Context)
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        v2.mReceivers = v0; // android.support.v4.content.LocalBroadcastManager.mReceivers:java.util.HashMap
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        v2.mActions = v0; // android.support.v4.content.LocalBroadcastManager.mActions:java.util.HashMap
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v2.mPendingBroadcasts = v0; // android.support.v4.content.LocalBroadcastManager.mPendingBroadcasts:java.util.ArrayList
        v2.mAppContext = v3; // android.support.v4.content.LocalBroadcastManager.mAppContext:android.content.Context
        v0 = new android.support.v4.content.LocalBroadcastManager$1;
        _result = v3.getMainLooper(); // android.content.Context.getMainLooper -> android.os.Looper
        v1 = _result;
        _result = v0.<init>(v2, v1); // android.support.v4.content.LocalBroadcastManager$1.<init> -> void
        v2.mHandler = v0; // android.support.v4.content.LocalBroadcastManager.mHandler:android.os.Handler
        return;
    }

    static void access$000(android.support.v4.content.LocalBroadcastManager p0) {
        // Registers (1 total): v0 = p0 (android.support.v4.content.LocalBroadcastManager)
        _result = v0.executePendingBroadcasts(); // android.support.v4.content.LocalBroadcastManager.executePendingBroadcasts -> void
        return;
    }

    private void executePendingBroadcasts() {
        // Registers (9 total): v8 = this
        v2 = 0;
        v1 = v8.mReceivers; // android.support.v4.content.LocalBroadcastManager.mReceivers:java.util.HashMap
        // monitor-enter(v1)
        v0 = v8.mPendingBroadcasts; // android.support.v4.content.LocalBroadcastManager.mPendingBroadcasts:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > 0) /* goto L_000e */;
        // monitor-exit(v1)
        return;
        v4 = new android.support.v4.content.LocalBroadcastManager$BroadcastRecord[][size=v0];
        v0 = v8.mPendingBroadcasts; // android.support.v4.content.LocalBroadcastManager.mPendingBroadcasts:java.util.ArrayList
        _result = v0.toArray(v4); // java.util.ArrayList.toArray -> java.lang.Object[]
        v0 = v8.mPendingBroadcasts; // android.support.v4.content.LocalBroadcastManager.mPendingBroadcasts:java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        // monitor-exit(v1)
        v3 = v2;
        v0 = v4.length;
        if (v3 >= v0) /* goto L_0001 */;
        v5 = v4[v3];
        v1 = v2;
        v0 = v5.receivers; // android.support.v4.content.LocalBroadcastManager$BroadcastRecord.receivers:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0042 */;
        v0 = v5.receivers; // android.support.v4.content.LocalBroadcastManager$BroadcastRecord.receivers:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.content.LocalBroadcastManager$ReceiverRecord) v0;
        v0 = v0.receiver; // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.receiver:android.content.BroadcastReceiver
        v6 = v8.mAppContext; // android.support.v4.content.LocalBroadcastManager.mAppContext:android.content.Context
        v7 = v5.intent; // android.support.v4.content.LocalBroadcastManager$BroadcastRecord.intent:android.content.Intent
        _result = v0.onReceive(v6, v7); // android.content.BroadcastReceiver.onReceive -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0022
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_001c
    }

    public static android.support.v4.content.LocalBroadcastManager getInstance(android.content.Context p0) {
        // Registers (4 total): v3 = p0 (android.content.Context)
        v1 = android.support.v4.content.LocalBroadcastManager.mLock; // :java.lang.Object
        // monitor-enter(v1)
        v0 = android.support.v4.content.LocalBroadcastManager.mInstance; // :android.support.v4.content.LocalBroadcastManager
        if (v0 != 0) /* goto L_0012 */;
        v0 = new android.support.v4.content.LocalBroadcastManager;
        _result = v3.getApplicationContext(); // android.content.Context.getApplicationContext -> android.content.Context
        v2 = _result;
        _result = v0.<init>(v2); // android.support.v4.content.LocalBroadcastManager.<init> -> void
        android.support.v4.content.LocalBroadcastManager.mInstance = v0; // :android.support.v4.content.LocalBroadcastManager
        v0 = android.support.v4.content.LocalBroadcastManager.mInstance; // :android.support.v4.content.LocalBroadcastManager
        // monitor-exit(v1)
        return v0;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

    public void registerReceiver(android.content.BroadcastReceiver p0, android.content.IntentFilter p1) {
        // Registers (9 total): v6 = this, v7 = p0 (android.content.BroadcastReceiver), v8 = p1 (android.content.IntentFilter)
        v2 = v6.mReceivers; // android.support.v4.content.LocalBroadcastManager.mReceivers:java.util.HashMap
        // monitor-enter(v2)
        v3 = new android.support.v4.content.LocalBroadcastManager$ReceiverRecord;
        _result = v3.<init>(v8, v7); // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.<init> -> void
        v0 = v6.mReceivers; // android.support.v4.content.LocalBroadcastManager.mReceivers:java.util.HashMap
        _result = v0.get(v7); // java.util.HashMap.get -> java.lang.Object
        v0 = _result;
        v0 = (java.util.ArrayList) v0;
        if (v0 != 0) /* goto L_001d */;
        v0 = new java.util.ArrayList;
        v1 = 1;
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v1 = v6.mReceivers; // android.support.v4.content.LocalBroadcastManager.mReceivers:java.util.HashMap
        _result = v1.put(v7, v0); // java.util.HashMap.put -> java.lang.Object
        _result = v0.add(v8); // java.util.ArrayList.add -> boolean
        v0 = 0;
        v1 = v0;
        _result = v8.countActions(); // android.content.IntentFilter.countActions -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0048 */;
        _result = v8.getAction(v1); // android.content.IntentFilter.getAction -> java.lang.String
        v4 = _result;
        v0 = v6.mActions; // android.support.v4.content.LocalBroadcastManager.mActions:java.util.HashMap
        _result = v0.get(v4); // java.util.HashMap.get -> java.lang.Object
        v0 = _result;
        v0 = (java.util.ArrayList) v0;
        if (v0 != 0) /* goto L_0041 */;
        v0 = new java.util.ArrayList;
        v5 = 1;
        _result = v0.<init>(v5); // java.util.ArrayList.<init> -> void
        v5 = v6.mActions; // android.support.v4.content.LocalBroadcastManager.mActions:java.util.HashMap
        _result = v5.put(v4, v0); // java.util.HashMap.put -> java.lang.Object
        _result = v0.add(v3); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0022
        // monitor-exit(v2)
        return;
        v0 = _exception;
        // monitor-exit(v2)
        throw v0;
    }

    public boolean sendBroadcast(android.content.Intent p0) {
        // Registers (18 total): v16 = this, v17 = p0 (android.content.Intent)
        v0 = v16;
        v13 = v0.mReceivers; // android.support.v4.content.LocalBroadcastManager.mReceivers:java.util.HashMap
        // monitor-enter(v13)
        _result = v17.getAction(v17..v17); // android.content.Intent.getAction -> java.lang.String
        v2 = _result;
        v0 = v16;
        v1 = v0.mAppContext; // android.support.v4.content.LocalBroadcastManager.mAppContext:android.content.Context
        _result = v1.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v1 = _result;
        v0 = v17;
        _result = v0.resolveTypeIfNeeded(v1); // android.content.Intent.resolveTypeIfNeeded -> java.lang.String
        v3 = _result;
        _result = v17.getData(v17..v17); // android.content.Intent.getData -> android.net.Uri
        v5 = _result;
        _result = v17.getScheme(v17..v17); // android.content.Intent.getScheme -> java.lang.String
        v4 = _result;
        _result = v17.getCategories(v17..v17); // android.content.Intent.getCategories -> java.util.Set
        v6 = _result;
        _result = v17.getFlags(v17..v17); // android.content.Intent.getFlags -> int
        v1 = _result;
        v1 = binOpLit8_0xdd(v1, 8);
        if (v1 == 0) /* goto L_00c9 */;
        v1 = 1;
        v12 = v1;
        if (v12 == 0) /* goto L_005d */;
        v1 = "LocalBroadcastManager";
        v7 = new java.lang.StringBuilder;
        _result = v7.<init>(); // java.lang.StringBuilder.<init> -> void
        v8 = "Resolving type ";
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        v8 = " scheme ";
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        v8 = " of intent ";
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        v0 = v17;
        _result = v7.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v7 = _result;
        _result = v1.v(v7); // android.util.Log.v -> int
        v0 = v16;
        v1 = v0.mActions; // android.support.v4.content.LocalBroadcastManager.mActions:java.util.HashMap
        _result = v17.getAction(v17..v17); // android.content.Intent.getAction -> java.lang.String
        v7 = _result;
        _result = v1.get(v7); // java.util.HashMap.get -> java.lang.Object
        v1 = _result;
        v0 = v1;
        v0 = (java.util.ArrayList) v0;
        v8 = v0;
        if (v8 == 0) /* goto L_016e */;
        if (v12 == 0) /* goto L_0089 */;
        v1 = "LocalBroadcastManager";
        v7 = new java.lang.StringBuilder;
        _result = v7.<init>(); // java.lang.StringBuilder.<init> -> void
        v9 = "Action list: ";
        _result = v7.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v7 = _result;
        _result = v1.v(v7); // android.util.Log.v -> int
        v10 = 0;
        v1 = 0;
        v11 = v1;
        _result = v8.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v11 >= v1) /* goto L_0133 */;
        _result = v8.get(v11); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v0 = v1;
        v0 = (android.support.v4.content.LocalBroadcastManager$ReceiverRecord) v0;
        v9 = v0;
        if (v12 == 0) /* goto L_00b6 */;
        v1 = "LocalBroadcastManager";
        v7 = new java.lang.StringBuilder;
        _result = v7.<init>(); // java.lang.StringBuilder.<init> -> void
        v14 = "Matching against filter ";
        _result = v7.append(v14); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        v14 = v9.filter; // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.filter:android.content.IntentFilter
        _result = v7.append(v14); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v7 = _result;
        _result = v1.v(v7); // android.util.Log.v -> int
        v1 = v9.broadcasting; // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.broadcasting:boolean
        if (v1 == 0) /* goto L_00cd */;
        if (v12 == 0) /* goto L_0125 */;
        v1 = "LocalBroadcastManager";
        v7 = "  Filter's target already added";
        _result = v1.v(v7); // android.util.Log.v -> int
        v1 = v10;
        v7 = binOpLit8_0xd8(v11, 1);
        v11 = v7;
        v10 = v1;
        // goto L_008c
        v1 = 0;
        v12 = v1;
        // goto L_002d
        v1 = v9.filter; // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.filter:android.content.IntentFilter
        v7 = "LocalBroadcastManager";
        _result = v1.match(v1..v7); // android.content.IntentFilter.match -> int
        v1 = _result;
        if (v1 < 0) /* goto L_0106 */;
        if (v12 == 0) /* goto L_00f5 */;
        v7 = "LocalBroadcastManager";
        v14 = new java.lang.StringBuilder;
        _result = v14.<init>(); // java.lang.StringBuilder.<init> -> void
        v15 = "  Filter matched!  match=0x";
        _result = v14.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v14 = _result;
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v14.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v7.v(v1); // android.util.Log.v -> int
        if (v10 != 0) /* goto L_0171 */;
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        _result = v1.add(v9); // java.util.ArrayList.add -> boolean
        v7 = 1;
        v9.broadcasting = v7; // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.broadcasting:boolean
        // goto L_00c4
        v1 = _exception;
        // monitor-exit(v13)
        throw v1;
        if (v12 == 0) /* goto L_0125 */;
        // switch(v1)
        v1 = "unknown reason";
        v7 = "LocalBroadcastManager";
        v9 = new java.lang.StringBuilder;
        _result = v9.<init>(); // java.lang.StringBuilder.<init> -> void
        v14 = "  Filter did not match: ";
        _result = v9.append(v14); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        _result = v9.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v7.v(v1); // android.util.Log.v -> int
        v1 = v10;
        // goto L_00c4
        v1 = "action";
        // goto L_010d
        v1 = "category";
        // goto L_010d
        v1 = "data";
        // goto L_010d
        v1 = "type";
        // goto L_010d
        if (v10 == 0) /* goto L_016e */;
        v1 = 0;
        v2 = v1;
        _result = v10.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v2 >= v1) /* goto L_014a */;
        _result = v10.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.content.LocalBroadcastManager$ReceiverRecord) v1;
        v3 = 0;
        v1.broadcasting = v3; // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.broadcasting:boolean
        v1 = binOpLit8_0xd8(v2, 1);
        v2 = v1;
        // goto L_0137
        v0 = v16;
        v1 = v0.mPendingBroadcasts; // android.support.v4.content.LocalBroadcastManager.mPendingBroadcasts:java.util.ArrayList
        v2 = new android.support.v4.content.LocalBroadcastManager$BroadcastRecord;
        v0 = v17;
        _result = v2.<init>(v0, v10); // android.support.v4.content.LocalBroadcastManager$BroadcastRecord.<init> -> void
        _result = v1.add(v2); // java.util.ArrayList.add -> boolean
        v0 = v16;
        v1 = v0.mHandler; // android.support.v4.content.LocalBroadcastManager.mHandler:android.os.Handler
        v2 = 1;
        _result = v1.hasMessages(v2); // android.os.Handler.hasMessages -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_016b */;
        v0 = v16;
        v1 = v0.mHandler; // android.support.v4.content.LocalBroadcastManager.mHandler:android.os.Handler
        v2 = 1;
        _result = v1.sendEmptyMessage(v2); // android.os.Handler.sendEmptyMessage -> boolean
        v1 = 1;
        // monitor-exit(v13)
        return v1;
        // monitor-exit(v13)
        v1 = 0;
        // goto L_016d
        v1 = v10;
        // goto L_00fc
    }

    public void sendBroadcastSync(android.content.Intent p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Intent)
        _result = v1.sendBroadcast(v2); // android.support.v4.content.LocalBroadcastManager.sendBroadcast -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0009 */;
        _result = v1.executePendingBroadcasts(); // android.support.v4.content.LocalBroadcastManager.executePendingBroadcasts -> void
        return;
    }

    public void unregisterReceiver(android.content.BroadcastReceiver p0) {
        // Registers (12 total): v10 = this, v11 = p0 (android.content.BroadcastReceiver)
        v5 = 0;
        v8 = v10.mReceivers; // android.support.v4.content.LocalBroadcastManager.mReceivers:java.util.HashMap
        // monitor-enter(v8)
        v0 = v10.mReceivers; // android.support.v4.content.LocalBroadcastManager.mReceivers:java.util.HashMap
        _result = v0.remove(v11); // java.util.HashMap.remove -> java.lang.Object
        v0 = _result;
        v0 = (java.util.ArrayList) v0;
        if (v0 != 0) /* goto L_0010 */;
        // monitor-exit(v8)
        return;
        v7 = v5;
        _result = v0.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v7 >= v1) /* goto L_005e */;
        _result = v0.get(v7); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.content.IntentFilter) v1;
        v6 = v5;
        _result = v1.countActions(); // android.content.IntentFilter.countActions -> int
        v2 = _result;
        if (v6 >= v2) /* goto L_005a */;
        _result = v1.getAction(v6); // android.content.IntentFilter.getAction -> java.lang.String
        v9 = _result;
        v2 = v10.mActions; // android.support.v4.content.LocalBroadcastManager.mActions:java.util.HashMap
        _result = v2.get(v9); // java.util.HashMap.get -> java.lang.Object
        v2 = _result;
        v2 = (java.util.ArrayList) v2;
        if (v2 == 0) /* goto L_0056 */;
        v4 = v5;
        _result = v2.size(); // java.util.ArrayList.size -> int
        v3 = _result;
        if (v4 >= v3) /* goto L_004b */;
        _result = v2.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v3 = _result;
        v3 = (android.support.v4.content.LocalBroadcastManager$ReceiverRecord) v3;
        v3 = v3.receiver; // android.support.v4.content.LocalBroadcastManager$ReceiverRecord.receiver:android.content.BroadcastReceiver
        if (v3 != v11) /* goto L_0063 */;
        _result = v2.remove(v4); // java.util.ArrayList.remove -> java.lang.Object
        v3 = binOpLit8_0xd8(v4, -1);
        v4 = binOpLit8_0xd8(v3, 1);
        // goto L_0033
        _result = v2.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        if (v2 > 0) /* goto L_0056 */;
        v2 = v10.mActions; // android.support.v4.content.LocalBroadcastManager.mActions:java.util.HashMap
        _result = v2.remove(v9); // java.util.HashMap.remove -> java.lang.Object
        v2 = binOpLit8_0xd8(v6, 1);
        v6 = v2;
        // goto L_001e
        v1 = binOpLit8_0xd8(v7, 1);
        v7 = v1;
        // goto L_0011
        // monitor-exit(v8)
        // goto L_000f
        v0 = _exception;
        // monitor-exit(v8)
        throw v0;
        v3 = v4;
        // goto L_0048
    }

}