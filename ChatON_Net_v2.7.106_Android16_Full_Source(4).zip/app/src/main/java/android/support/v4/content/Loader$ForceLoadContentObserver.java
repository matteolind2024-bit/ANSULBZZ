package android.support.v4.content;

/**
 * Original SourceFile: Loader.java
 * Descriptor: Landroid/support/v4/content/Loader$ForceLoadContentObserver;
 */
public final class Loader$ForceLoadContentObserver extends android.database.ContentObserver {
    final android.support.v4.content.Loader this$0;

    public Loader$ForceLoadContentObserver(android.support.v4.content.Loader p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.content.Loader)
        v1.this$0 = v2; // android.support.v4.content.Loader$ForceLoadContentObserver.this$0:android.support.v4.content.Loader
        v0 = new android.os.Handler;
        _result = v0.<init>(); // android.os.Handler.<init> -> void
        _result = v1.<init>(v0); // android.database.ContentObserver.<init> -> void
        return;
    }

    public boolean deliverSelfNotifications() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public void onChange(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.this$0; // android.support.v4.content.Loader$ForceLoadContentObserver.this$0:android.support.v4.content.Loader
        _result = v0.onContentChanged(); // android.support.v4.content.Loader.onContentChanged -> void
        return;
    }

}