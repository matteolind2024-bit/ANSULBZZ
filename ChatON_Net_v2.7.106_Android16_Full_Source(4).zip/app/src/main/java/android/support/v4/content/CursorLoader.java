package android.support.v4.content;

/**
 * Original SourceFile: CursorLoader.java
 * Descriptor: Landroid/support/v4/content/CursorLoader;
 */
public class CursorLoader extends android.support.v4.content.AsyncTaskLoader {
     android.database.Cursor mCursor;
    final android.support.v4.content.Loader$ForceLoadContentObserver mObserver;
     java.lang.String[] mProjection;
     java.lang.String mSelection;
     java.lang.String[] mSelectionArgs;
     java.lang.String mSortOrder;
     android.net.Uri mUri;

    public CursorLoader(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        _result = v1.<init>(v2); // android.support.v4.content.AsyncTaskLoader.<init> -> void
        v0 = new android.support.v4.content.Loader$ForceLoadContentObserver;
        _result = v0.<init>(v1); // android.support.v4.content.Loader$ForceLoadContentObserver.<init> -> void
        v1.mObserver = v0; // android.support.v4.content.CursorLoader.mObserver:android.support.v4.content.Loader$ForceLoadContentObserver
        return;
    }

    public CursorLoader(android.content.Context p0, android.net.Uri p1, java.lang.String[] p2, java.lang.String p3, java.lang.String[] p4, java.lang.String p5) {
        // Registers (8 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.net.Uri), v4 = p2 (java.lang.String[]), v5 = p3 (java.lang.String), v6 = p4 (java.lang.String[]), v7 = p5 (java.lang.String)
        _result = v1.<init>(v2); // android.support.v4.content.AsyncTaskLoader.<init> -> void
        v0 = new android.support.v4.content.Loader$ForceLoadContentObserver;
        _result = v0.<init>(v1); // android.support.v4.content.Loader$ForceLoadContentObserver.<init> -> void
        v1.mObserver = v0; // android.support.v4.content.CursorLoader.mObserver:android.support.v4.content.Loader$ForceLoadContentObserver
        v1.mUri = v3; // android.support.v4.content.CursorLoader.mUri:android.net.Uri
        v1.mProjection = v4; // android.support.v4.content.CursorLoader.mProjection:java.lang.String[]
        v1.mSelection = v5; // android.support.v4.content.CursorLoader.mSelection:java.lang.String
        v1.mSelectionArgs = v6; // android.support.v4.content.CursorLoader.mSelectionArgs:java.lang.String[]
        v1.mSortOrder = v7; // android.support.v4.content.CursorLoader.mSortOrder:java.lang.String
        return;
    }

    public void deliverResult(android.database.Cursor p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.database.Cursor)
        _result = v2.isReset(); // android.support.v4.content.CursorLoader.isReset -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000c */;
        if (v3 == 0) /* goto L_000b */;
        _result = android.database.Cursor.close(v3); // -> void
        return;
        v0 = v2.mCursor; // android.support.v4.content.CursorLoader.mCursor:android.database.Cursor
        v2.mCursor = v3; // android.support.v4.content.CursorLoader.mCursor:android.database.Cursor
        _result = v2.isStarted(); // android.support.v4.content.CursorLoader.isStarted -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0019 */;
        _result = v2.deliverResult(v3); // android.support.v4.content.AsyncTaskLoader.deliverResult -> void
        if (v0 == 0) /* goto L_000b */;
        if (v0 == v3) /* goto L_000b */;
        _result = android.database.Cursor.isClosed(v0); // -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000b */;
        _result = android.database.Cursor.close(v0); // -> void
        // goto L_000b
    }

    public void deliverResult(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        v1 = (android.database.Cursor) v1;
        _result = v0.deliverResult(v1); // android.support.v4.content.CursorLoader.deliverResult -> void
        return;
    }

    public void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.io.FileDescriptor), v4 = p2 (java.io.PrintWriter), v5 = p3 (java.lang.String[])
        _result = v1.dump(v2, v3, v4, v5); // android.support.v4.content.AsyncTaskLoader.dump -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mUri=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mUri; // android.support.v4.content.CursorLoader.mUri:android.net.Uri
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mProjection=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mProjection; // android.support.v4.content.CursorLoader.mProjection:java.lang.String[]
        _result = v0.toString(); // java.util.Arrays.toString -> java.lang.String
        v0 = _result;
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mSelection=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mSelection; // android.support.v4.content.CursorLoader.mSelection:java.lang.String
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mSelectionArgs=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mSelectionArgs; // android.support.v4.content.CursorLoader.mSelectionArgs:java.lang.String[]
        _result = v0.toString(); // java.util.Arrays.toString -> java.lang.String
        v0 = _result;
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mSortOrder=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mSortOrder; // android.support.v4.content.CursorLoader.mSortOrder:java.lang.String
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mCursor=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mCursor; // android.support.v4.content.CursorLoader.mCursor:android.database.Cursor
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mContentChanged=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.mContentChanged; // android.support.v4.content.CursorLoader.mContentChanged:boolean
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        return;
    }

    public java.lang.String[] getProjection() {
        // Registers (2 total): v1 = this
        v0 = v1.mProjection; // android.support.v4.content.CursorLoader.mProjection:java.lang.String[]
        return v0;
    }

    public java.lang.String getSelection() {
        // Registers (2 total): v1 = this
        v0 = v1.mSelection; // android.support.v4.content.CursorLoader.mSelection:java.lang.String
        return v0;
    }

    public java.lang.String[] getSelectionArgs() {
        // Registers (2 total): v1 = this
        v0 = v1.mSelectionArgs; // android.support.v4.content.CursorLoader.mSelectionArgs:java.lang.String[]
        return v0;
    }

    public java.lang.String getSortOrder() {
        // Registers (2 total): v1 = this
        v0 = v1.mSortOrder; // android.support.v4.content.CursorLoader.mSortOrder:java.lang.String
        return v0;
    }

    public android.net.Uri getUri() {
        // Registers (2 total): v1 = this
        v0 = v1.mUri; // android.support.v4.content.CursorLoader.mUri:android.net.Uri
        return v0;
    }

    public android.database.Cursor loadInBackground() {
        // Registers (7 total): v6 = this
        _result = v6.getContext(); // android.support.v4.content.CursorLoader.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        v1 = v6.mUri; // android.support.v4.content.CursorLoader.mUri:android.net.Uri
        v2 = v6.mProjection; // android.support.v4.content.CursorLoader.mProjection:java.lang.String[]
        v3 = v6.mSelection; // android.support.v4.content.CursorLoader.mSelection:java.lang.String
        v4 = v6.mSelectionArgs; // android.support.v4.content.CursorLoader.mSelectionArgs:java.lang.String[]
        v5 = v6.mSortOrder; // android.support.v4.content.CursorLoader.mSortOrder:java.lang.String
        _result = v0.query(v0..v5); // android.content.ContentResolver.query -> android.database.Cursor
        v0 = _result;
        if (v0 == 0) /* goto L_0020 */;
        _result = android.database.Cursor.getCount(v0); // -> int
        v1 = v6.mObserver; // android.support.v4.content.CursorLoader.mObserver:android.support.v4.content.Loader$ForceLoadContentObserver
        _result = v6.registerContentObserver(v0, v1); // android.support.v4.content.CursorLoader.registerContentObserver -> void
        return v0;
    }

    public java.lang.Object loadInBackground() {
        // Registers (2 total): v1 = this
        _result = v1.loadInBackground(); // android.support.v4.content.CursorLoader.loadInBackground -> android.database.Cursor
        v0 = _result;
        return v0;
    }

    public void onCanceled(android.database.Cursor p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.database.Cursor)
        if (v2 == 0) /* goto L_000b */;
        _result = android.database.Cursor.isClosed(v2); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000b */;
        _result = android.database.Cursor.close(v2); // -> void
        return;
    }

    public void onCanceled(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        v1 = (android.database.Cursor) v1;
        _result = v0.onCanceled(v1); // android.support.v4.content.CursorLoader.onCanceled -> void
        return;
    }

    protected void onReset() {
        // Registers (2 total): v1 = this
        _result = v1.onReset(); // android.support.v4.content.AsyncTaskLoader.onReset -> void
        _result = v1.onStopLoading(); // android.support.v4.content.CursorLoader.onStopLoading -> void
        v0 = v1.mCursor; // android.support.v4.content.CursorLoader.mCursor:android.database.Cursor
        if (v0 == 0) /* goto L_0017 */;
        v0 = v1.mCursor; // android.support.v4.content.CursorLoader.mCursor:android.database.Cursor
        _result = android.database.Cursor.isClosed(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        v0 = v1.mCursor; // android.support.v4.content.CursorLoader.mCursor:android.database.Cursor
        _result = android.database.Cursor.close(v0); // -> void
        v0 = 0;
        v1.mCursor = v0; // android.support.v4.content.CursorLoader.mCursor:android.database.Cursor
        return;
    }

    protected void onStartLoading() {
        // Registers (2 total): v1 = this
        v0 = v1.mCursor; // android.support.v4.content.CursorLoader.mCursor:android.database.Cursor
        if (v0 == 0) /* goto L_0009 */;
        v0 = v1.mCursor; // android.support.v4.content.CursorLoader.mCursor:android.database.Cursor
        _result = v1.deliverResult(v0); // android.support.v4.content.CursorLoader.deliverResult -> void
        _result = v1.takeContentChanged(); // android.support.v4.content.CursorLoader.takeContentChanged -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0013 */;
        v0 = v1.mCursor; // android.support.v4.content.CursorLoader.mCursor:android.database.Cursor
        if (v0 != 0) /* goto L_0016 */;
        _result = v1.forceLoad(); // android.support.v4.content.CursorLoader.forceLoad -> void
        return;
    }

    protected void onStopLoading() {
        // Registers (1 total): v0 = this
        _result = v0.cancelLoad(); // android.support.v4.content.CursorLoader.cancelLoad -> boolean
        return;
    }

    void registerContentObserver(android.database.Cursor p0, android.database.ContentObserver p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.database.Cursor), v3 = p1 (android.database.ContentObserver)
        v0 = v1.mObserver; // android.support.v4.content.CursorLoader.mObserver:android.support.v4.content.Loader$ForceLoadContentObserver
        _result = android.database.Cursor.registerContentObserver(v2, v0); // -> void
        return;
    }

    public void setProjection(java.lang.String[] p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String[])
        v0.mProjection = v1; // android.support.v4.content.CursorLoader.mProjection:java.lang.String[]
        return;
    }

    public void setSelection(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.mSelection = v1; // android.support.v4.content.CursorLoader.mSelection:java.lang.String
        return;
    }

    public void setSelectionArgs(java.lang.String[] p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String[])
        v0.mSelectionArgs = v1; // android.support.v4.content.CursorLoader.mSelectionArgs:java.lang.String[]
        return;
    }

    public void setSortOrder(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        v0.mSortOrder = v1; // android.support.v4.content.CursorLoader.mSortOrder:java.lang.String
        return;
    }

    public void setUri(android.net.Uri p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.net.Uri)
        v0.mUri = v1; // android.support.v4.content.CursorLoader.mUri:android.net.Uri
        return;
    }

}