package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompatIcs.java
 * Descriptor: Landroid/support/v4/view/AccessibilityDelegateCompatIcs;
 */
class AccessibilityDelegateCompatIcs {
    AccessibilityDelegateCompatIcs() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean dispatchPopulateAccessibilityEvent(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        v1 = (android.view.View$AccessibilityDelegate) v1;
        _result = v1.dispatchPopulateAccessibilityEvent(v2, v3); // android.view.View$AccessibilityDelegate.dispatchPopulateAccessibilityEvent -> boolean
        v0 = _result;
        return v0;
    }

    public static java.lang.Object newAccessibilityDelegateBridge(android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.view.AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge)
        v0 = new android.support.v4.view.AccessibilityDelegateCompatIcs$1;
        _result = v0.<init>(v1); // android.support.v4.view.AccessibilityDelegateCompatIcs$1.<init> -> void
        return v0;
    }

    public static java.lang.Object newAccessibilityDelegateDefaultImpl() {
        v0 = new android.view.View$AccessibilityDelegate;
        _result = v0.<init>(); // android.view.View$AccessibilityDelegate.<init> -> void
        return v0;
    }

    public static void onInitializeAccessibilityEvent(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = (android.view.View$AccessibilityDelegate) v0;
        _result = v0.onInitializeAccessibilityEvent(v1, v2); // android.view.View$AccessibilityDelegate.onInitializeAccessibilityEvent -> void
        return;
    }

    public static void onInitializeAccessibilityNodeInfo(java.lang.Object p0, android.view.View p1, java.lang.Object p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (java.lang.Object)
        v0 = (android.view.View$AccessibilityDelegate) v0;
        v2 = (android.view.accessibility.AccessibilityNodeInfo) v2;
        _result = v0.onInitializeAccessibilityNodeInfo(v1, v2); // android.view.View$AccessibilityDelegate.onInitializeAccessibilityNodeInfo -> void
        return;
    }

    public static void onPopulateAccessibilityEvent(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = (android.view.View$AccessibilityDelegate) v0;
        _result = v0.onPopulateAccessibilityEvent(v1, v2); // android.view.View$AccessibilityDelegate.onPopulateAccessibilityEvent -> void
        return;
    }

    public static boolean onRequestSendAccessibilityEvent(java.lang.Object p0, android.view.ViewGroup p1, android.view.View p2, android.view.accessibility.AccessibilityEvent p3) {
        // Registers (5 total): v1 = p0 (java.lang.Object), v2 = p1 (android.view.ViewGroup), v3 = p2 (android.view.View), v4 = p3 (android.view.accessibility.AccessibilityEvent)
        v1 = (android.view.View$AccessibilityDelegate) v1;
        _result = v1.onRequestSendAccessibilityEvent(v2, v3, v4); // android.view.View$AccessibilityDelegate.onRequestSendAccessibilityEvent -> boolean
        v0 = _result;
        return v0;
    }

    public static void sendAccessibilityEvent(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (int)
        v0 = (android.view.View$AccessibilityDelegate) v0;
        _result = v0.sendAccessibilityEvent(v1, v2); // android.view.View$AccessibilityDelegate.sendAccessibilityEvent -> void
        return;
    }

    public static void sendAccessibilityEventUnchecked(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = (android.view.View$AccessibilityDelegate) v0;
        _result = v0.sendAccessibilityEventUnchecked(v1, v2); // android.view.View$AccessibilityDelegate.sendAccessibilityEventUnchecked -> void
        return;
    }

}