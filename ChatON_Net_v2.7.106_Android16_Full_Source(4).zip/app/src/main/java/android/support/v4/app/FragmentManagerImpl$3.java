package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/FragmentManagerImpl$3;
 */
class FragmentManagerImpl$3 implements java.lang.Runnable {
    final android.support.v4.app.FragmentManagerImpl this$0;
    final int val$flags;
    final java.lang.String val$name;

    FragmentManagerImpl$3(android.support.v4.app.FragmentManagerImpl p0, java.lang.String p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.support.v4.app.FragmentManagerImpl), v2 = p1 (java.lang.String), v3 = p2 (int)
        v0.this$0 = v1; // android.support.v4.app.FragmentManagerImpl$3.this$0:android.support.v4.app.FragmentManagerImpl
        v0.val$name = v2; // android.support.v4.app.FragmentManagerImpl$3.val$name:java.lang.String
        v0.val$flags = v3; // android.support.v4.app.FragmentManagerImpl$3.val$flags:int
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (6 total): v5 = this
        v0 = v5.this$0; // android.support.v4.app.FragmentManagerImpl$3.this$0:android.support.v4.app.FragmentManagerImpl
        v1 = v5.this$0; // android.support.v4.app.FragmentManagerImpl$3.this$0:android.support.v4.app.FragmentManagerImpl
        v1 = v1.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = v1.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v2 = v5.val$name; // android.support.v4.app.FragmentManagerImpl$3.val$name:java.lang.String
        v3 = -1;
        v4 = v5.val$flags; // android.support.v4.app.FragmentManagerImpl$3.val$flags:int
        _result = v0.popBackStackState(v1, v2, v3, v4); // android.support.v4.app.FragmentManagerImpl.popBackStackState -> boolean
        return;
    }

}