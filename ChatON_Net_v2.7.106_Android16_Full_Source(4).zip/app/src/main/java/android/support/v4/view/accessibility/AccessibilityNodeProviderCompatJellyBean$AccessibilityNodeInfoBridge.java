package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityNodeProviderCompatJellyBean.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;
 */
interface AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge {
    public abstract java.lang.Object createAccessibilityNodeInfo(int p0);
    public abstract java.util.List findAccessibilityNodeInfosByText(java.lang.String p0, int p1);
    public abstract boolean performAction(int p0, int p1, android.os.Bundle p2);
}