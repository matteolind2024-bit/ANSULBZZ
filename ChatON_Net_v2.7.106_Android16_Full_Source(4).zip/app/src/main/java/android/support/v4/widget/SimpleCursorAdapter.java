package android.support.v4.widget;

/**
 * Original SourceFile: SimpleCursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/SimpleCursorAdapter;
 */
public class SimpleCursorAdapter extends android.support.v4.widget.ResourceCursorAdapter {
    private android.support.v4.widget.SimpleCursorAdapter$CursorToStringConverter mCursorToStringConverter;
    protected int[] mFrom;
     java.lang.String[] mOriginalFrom;
    private int mStringConversionColumn;
    protected int[] mTo;
    private android.support.v4.widget.SimpleCursorAdapter$ViewBinder mViewBinder;

    public SimpleCursorAdapter(android.content.Context p0, int p1, android.database.Cursor p2, java.lang.String[] p3, int[] p4) {
        // Registers (7 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (int), v4 = p2 (android.database.Cursor), v5 = p3 (java.lang.String[]), v6 = p4 (int[])
        _result = v1.<init>(v2, v3, v4); // android.support.v4.widget.ResourceCursorAdapter.<init> -> void
        v0 = -1;
        v1.mStringConversionColumn = v0; // android.support.v4.widget.SimpleCursorAdapter.mStringConversionColumn:int
        v1.mTo = v6; // android.support.v4.widget.SimpleCursorAdapter.mTo:int[]
        v1.mOriginalFrom = v5; // android.support.v4.widget.SimpleCursorAdapter.mOriginalFrom:java.lang.String[]
        _result = v1.findColumns(v5); // android.support.v4.widget.SimpleCursorAdapter.findColumns -> void
        return;
    }

    public SimpleCursorAdapter(android.content.Context p0, int p1, android.database.Cursor p2, java.lang.String[] p3, int[] p4, int p5) {
        // Registers (8 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (int), v4 = p2 (android.database.Cursor), v5 = p3 (java.lang.String[]), v6 = p4 (int[]), v7 = p5 (int)
        _result = v1.<init>(v2, v3, v4, v7); // android.support.v4.widget.ResourceCursorAdapter.<init> -> void
        v0 = -1;
        v1.mStringConversionColumn = v0; // android.support.v4.widget.SimpleCursorAdapter.mStringConversionColumn:int
        v1.mTo = v6; // android.support.v4.widget.SimpleCursorAdapter.mTo:int[]
        v1.mOriginalFrom = v5; // android.support.v4.widget.SimpleCursorAdapter.mOriginalFrom:java.lang.String[]
        _result = v1.findColumns(v5); // android.support.v4.widget.SimpleCursorAdapter.findColumns -> void
        return;
    }

    private void findColumns(java.lang.String[] p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.String[])
        v0 = v5.mCursor; // android.support.v4.widget.SimpleCursorAdapter.mCursor:android.database.Cursor
        if (v0 == 0) /* goto L_0024 */;
        v1 = v6.length;
        v0 = v5.mFrom; // android.support.v4.widget.SimpleCursorAdapter.mFrom:int[]
        if (v0 == 0) /* goto L_000e */;
        v0 = v5.mFrom; // android.support.v4.widget.SimpleCursorAdapter.mFrom:int[]
        v0 = v0.length;
        if (v0 == v1) /* goto L_0012 */;
        v0 = new int[][size=v1];
        v5.mFrom = v0; // android.support.v4.widget.SimpleCursorAdapter.mFrom:int[]
        v0 = 0;
        if (v0 >= v1) /* goto L_0027 */;
        v2 = v5.mFrom; // android.support.v4.widget.SimpleCursorAdapter.mFrom:int[]
        v3 = v5.mCursor; // android.support.v4.widget.SimpleCursorAdapter.mCursor:android.database.Cursor
        v4 = v6[v0];
        _result = android.database.Cursor.getColumnIndexOrThrow(v3, v4); // -> int
        v3 = _result;
        v2[v0] = v3;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0013
        v0 = 0;
        v5.mFrom = v0; // android.support.v4.widget.SimpleCursorAdapter.mFrom:int[]
        return;
    }

    public void bindView(android.view.View p0, android.content.Context p1, android.database.Cursor p2) {
        // Registers (13 total): v9 = this, v10 = p0 (android.view.View), v11 = p1 (android.content.Context), v12 = p2 (android.database.Cursor)
        v2 = 0;
        v4 = v9.mViewBinder; // android.support.v4.widget.SimpleCursorAdapter.mViewBinder:android.support.v4.widget.SimpleCursorAdapter$ViewBinder
        v0 = v9.mTo; // android.support.v4.widget.SimpleCursorAdapter.mTo:int[]
        v5 = v0.length;
        v6 = v9.mFrom; // android.support.v4.widget.SimpleCursorAdapter.mFrom:int[]
        v7 = v9.mTo; // android.support.v4.widget.SimpleCursorAdapter.mTo:int[]
        v3 = v2;
        if (v3 >= v5) /* goto L_0067 */;
        v0 = v7[v3];
        _result = v10.findViewById(v0); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0032 */;
        if (v4 == 0) /* goto L_0068 */;
        v1 = v6[v3];
        _result = android.support.v4.widget.SimpleCursorAdapter$ViewBinder.setViewValue(v4, v0, v12, v1); // -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0032 */;
        v1 = v6[v3];
        _result = android.database.Cursor.getString(v12, v1); // -> java.lang.String
        v1 = _result;
        if (v1 != 0) /* goto L_0029 */;
        v1 = "";
        v8 = (v0 instanceof android.widget.TextView);
        if (v8 == 0) /* goto L_0036 */;
        v0 = (android.widget.TextView) v0;
        _result = v9.setViewText(v0, v1); // android.support.v4.widget.SimpleCursorAdapter.setViewText -> void
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_000b
        v8 = (v0 instanceof android.widget.ImageView);
        if (v8 == 0) /* goto L_0040 */;
        v0 = (android.widget.ImageView) v0;
        _result = v9.setViewImage(v0, v1); // android.support.v4.widget.SimpleCursorAdapter.setViewImage -> void
        // goto L_0032
        v1 = new java.lang.IllegalStateException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getName(); // java.lang.Class.getName -> java.lang.String
        v0 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = " is not a ";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = " view that can be bounds by this SimpleCursorAdapter";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.IllegalStateException.<init> -> void
        throw v1;
        return;
        v1 = v2;
        // goto L_001d
    }

    public void changeCursorAndColumns(android.database.Cursor p0, java.lang.String[] p1, int[] p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.database.Cursor), v3 = p1 (java.lang.String[]), v4 = p2 (int[])
        v1.mOriginalFrom = v3; // android.support.v4.widget.SimpleCursorAdapter.mOriginalFrom:java.lang.String[]
        v1.mTo = v4; // android.support.v4.widget.SimpleCursorAdapter.mTo:int[]
        _result = v1.changeCursor(v2); // android.support.v4.widget.ResourceCursorAdapter.changeCursor -> void
        v0 = v1.mOriginalFrom; // android.support.v4.widget.SimpleCursorAdapter.mOriginalFrom:java.lang.String[]
        _result = v1.findColumns(v0); // android.support.v4.widget.SimpleCursorAdapter.findColumns -> void
        return;
    }

    public java.lang.CharSequence convertToString(android.database.Cursor p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.database.Cursor)
        v0 = v2.mCursorToStringConverter; // android.support.v4.widget.SimpleCursorAdapter.mCursorToStringConverter:android.support.v4.widget.SimpleCursorAdapter$CursorToStringConverter
        if (v0 == 0) /* goto L_000b */;
        v0 = v2.mCursorToStringConverter; // android.support.v4.widget.SimpleCursorAdapter.mCursorToStringConverter:android.support.v4.widget.SimpleCursorAdapter$CursorToStringConverter
        _result = android.support.v4.widget.SimpleCursorAdapter$CursorToStringConverter.convertToString(v0, v3); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
        v0 = v2.mStringConversionColumn; // android.support.v4.widget.SimpleCursorAdapter.mStringConversionColumn:int
        v1 = -1;
        if (v0 <= v1) /* goto L_0017 */;
        v0 = v2.mStringConversionColumn; // android.support.v4.widget.SimpleCursorAdapter.mStringConversionColumn:int
        _result = android.database.Cursor.getString(v3, v0); // -> java.lang.String
        v0 = _result;
        // goto L_000a
        _result = v2.convertToString(v3); // android.support.v4.widget.ResourceCursorAdapter.convertToString -> java.lang.CharSequence
        v0 = _result;
        // goto L_000a
    }

    public android.support.v4.widget.SimpleCursorAdapter$CursorToStringConverter getCursorToStringConverter() {
        // Registers (2 total): v1 = this
        v0 = v1.mCursorToStringConverter; // android.support.v4.widget.SimpleCursorAdapter.mCursorToStringConverter:android.support.v4.widget.SimpleCursorAdapter$CursorToStringConverter
        return v0;
    }

    public int getStringConversionColumn() {
        // Registers (2 total): v1 = this
        v0 = v1.mStringConversionColumn; // android.support.v4.widget.SimpleCursorAdapter.mStringConversionColumn:int
        return v0;
    }

    public android.support.v4.widget.SimpleCursorAdapter$ViewBinder getViewBinder() {
        // Registers (2 total): v1 = this
        v0 = v1.mViewBinder; // android.support.v4.widget.SimpleCursorAdapter.mViewBinder:android.support.v4.widget.SimpleCursorAdapter$ViewBinder
        return v0;
    }

    public void setCursorToStringConverter(android.support.v4.widget.SimpleCursorAdapter$CursorToStringConverter p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.SimpleCursorAdapter$CursorToStringConverter)
        v0.mCursorToStringConverter = v1; // android.support.v4.widget.SimpleCursorAdapter.mCursorToStringConverter:android.support.v4.widget.SimpleCursorAdapter$CursorToStringConverter
        return;
    }

    public void setStringConversionColumn(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.mStringConversionColumn = v1; // android.support.v4.widget.SimpleCursorAdapter.mStringConversionColumn:int
        return;
    }

    public void setViewBinder(android.support.v4.widget.SimpleCursorAdapter$ViewBinder p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.SimpleCursorAdapter$ViewBinder)
        v0.mViewBinder = v1; // android.support.v4.widget.SimpleCursorAdapter.mViewBinder:android.support.v4.widget.SimpleCursorAdapter$ViewBinder
        return;
    }

    public void setViewImage(android.widget.ImageView p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.widget.ImageView), v3 = p1 (java.lang.String)
        _result = v3.parseInt(); // java.lang.Integer.parseInt -> int
        v0 = _result;
        _result = v2.setImageResource(v0); // android.widget.ImageView.setImageResource -> void
        return;
        v0 = _exception;
        _result = v3.parse(); // android.net.Uri.parse -> android.net.Uri
        v0 = _result;
        _result = v2.setImageURI(v0); // android.widget.ImageView.setImageURI -> void
        // goto L_0007
    }

    public void setViewText(android.widget.TextView p0, java.lang.String p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.widget.TextView), v2 = p1 (java.lang.String)
        _result = v1.setText(v2); // android.widget.TextView.setText -> void
        return;
    }

    public android.database.Cursor swapCursor(android.database.Cursor p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.database.Cursor)
        _result = v2.swapCursor(v3); // android.support.v4.widget.ResourceCursorAdapter.swapCursor -> android.database.Cursor
        v0 = _result;
        v1 = v2.mOriginalFrom; // android.support.v4.widget.SimpleCursorAdapter.mOriginalFrom:java.lang.String[]
        _result = v2.findColumns(v1); // android.support.v4.widget.SimpleCursorAdapter.findColumns -> void
        return v0;
    }

}