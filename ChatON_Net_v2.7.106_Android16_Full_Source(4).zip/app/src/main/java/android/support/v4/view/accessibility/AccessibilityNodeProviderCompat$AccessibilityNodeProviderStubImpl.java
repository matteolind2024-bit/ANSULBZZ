package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityNodeProviderCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl;
 */
class AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl implements android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl {
    AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.lang.Object newAccessibilityNodeProviderBridge(android.support.v4.view.accessibility.AccessibilityNodeProviderCompat p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.accessibility.AccessibilityNodeProviderCompat)
        v0 = 0;
        return v0;
    }

}