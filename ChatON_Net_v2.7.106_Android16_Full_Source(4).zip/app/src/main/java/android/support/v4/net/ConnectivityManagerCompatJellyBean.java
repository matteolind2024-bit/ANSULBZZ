package android.support.v4.net;

/**
 * Original SourceFile: ConnectivityManagerCompatJellyBean.java
 * Descriptor: Landroid/support/v4/net/ConnectivityManagerCompatJellyBean;
 */
class ConnectivityManagerCompatJellyBean {
    ConnectivityManagerCompatJellyBean() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean isActiveNetworkMetered(android.net.ConnectivityManager p0) {
        // Registers (2 total): v1 = p0 (android.net.ConnectivityManager)
        _result = v1.isActiveNetworkMetered(); // android.net.ConnectivityManager.isActiveNetworkMetered -> boolean
        v0 = _result;
        return v0;
    }

}