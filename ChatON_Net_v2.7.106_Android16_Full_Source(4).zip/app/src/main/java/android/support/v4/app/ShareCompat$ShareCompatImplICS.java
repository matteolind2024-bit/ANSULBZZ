package android.support.v4.app;

/**
 * Original SourceFile: ShareCompat.java
 * Descriptor: Landroid/support/v4/app/ShareCompat$ShareCompatImplICS;
 */
class ShareCompat$ShareCompatImplICS extends android.support.v4.app.ShareCompat$ShareCompatImplBase {
    ShareCompat$ShareCompatImplICS() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.app.ShareCompat$ShareCompatImplBase.<init> -> void
        return;
    }

    public void configureMenuItem(android.view.MenuItem p0, android.support.v4.app.ShareCompat$IntentBuilder p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.MenuItem), v4 = p1 (android.support.v4.app.ShareCompat$IntentBuilder)
        _result = v4.getActivity(); // android.support.v4.app.ShareCompat$IntentBuilder.getActivity -> android.app.Activity
        v0 = _result;
        _result = v4.getIntent(); // android.support.v4.app.ShareCompat$IntentBuilder.getIntent -> android.content.Intent
        v1 = _result;
        _result = v3.configureMenuItem(v0, v1); // android.support.v4.app.ShareCompatICS.configureMenuItem -> void
        _result = v2.shouldAddChooserIntent(v3); // android.support.v4.app.ShareCompat$ShareCompatImplICS.shouldAddChooserIntent -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0018 */;
        _result = v4.createChooserIntent(); // android.support.v4.app.ShareCompat$IntentBuilder.createChooserIntent -> android.content.Intent
        v0 = _result;
        _result = android.view.MenuItem.setIntent(v3, v0); // -> android.view.MenuItem
        return;
    }

    boolean shouldAddChooserIntent(android.view.MenuItem p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.MenuItem)
        _result = android.view.MenuItem.hasSubMenu(v2); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0008 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0007
    }

}