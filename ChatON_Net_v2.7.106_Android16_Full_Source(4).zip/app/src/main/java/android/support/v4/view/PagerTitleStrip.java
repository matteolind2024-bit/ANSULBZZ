package android.support.v4.view;

/**
 * Original SourceFile: PagerTitleStrip.java
 * Descriptor: Landroid/support/v4/view/PagerTitleStrip;
 */
public class PagerTitleStrip extends android.view.ViewGroup implements android.support.v4.view.ViewPager$Decor {
    private static final int[] ATTRS;
    private static final android.support.v4.view.PagerTitleStrip$PagerTitleStripImpl IMPL;
    private static final float SIDE_ALPHA;
    private static final java.lang.String TAG;
    private static final int[] TEXT_ATTRS;
    private static final int TEXT_SPACING;
     android.widget.TextView mCurrText;
    private int mGravity;
    private int mLastKnownCurrentPage;
    private float mLastKnownPositionOffset;
     android.widget.TextView mNextText;
    private int mNonPrimaryAlpha;
    private final android.support.v4.view.PagerTitleStrip$PageListener mPageListener;
     android.support.v4.view.ViewPager mPager;
     android.widget.TextView mPrevText;
    private int mScaledTextSpacing;
     int mTextColor;
    private boolean mUpdatingPositions;
    private boolean mUpdatingText;

    static {
        v0 = 4;
        v0 = new int[][size=v0];
        android.support.v4.view.PagerTitleStrip.ATTRS = v0; // :int[]
        v0 = 1;
        v0 = new int[][size=v0];
        v1 = 0;
        v2 = 16843660; // 0x0101038c
        v0[v1] = v2;
        android.support.v4.view.PagerTitleStrip.TEXT_ATTRS = v0; // :int[]
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_0021 */;
        v0 = new android.support.v4.view.PagerTitleStrip$PagerTitleStripImplIcs;
        _result = v0.<init>(); // android.support.v4.view.PagerTitleStrip$PagerTitleStripImplIcs.<init> -> void
        android.support.v4.view.PagerTitleStrip.IMPL = v0; // :android.support.v4.view.PagerTitleStrip$PagerTitleStripImpl
        return;
        v0 = new android.support.v4.view.PagerTitleStrip$PagerTitleStripImplBase;
        _result = v0.<init>(); // android.support.v4.view.PagerTitleStrip$PagerTitleStripImplBase.<init> -> void
        android.support.v4.view.PagerTitleStrip.IMPL = v0; // :android.support.v4.view.PagerTitleStrip$PagerTitleStripImpl
        // goto L_0020
    }

    public PagerTitleStrip(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        v0 = 0;
        _result = v1.<init>(v2, v0); // android.support.v4.view.PagerTitleStrip.<init> -> void
        return;
    }

    public PagerTitleStrip(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.content.Context), v7 = p1 (android.util.AttributeSet)
        v4 = 2;
        v0 = 0;
        _result = v5.<init>(v6, v7); // android.view.ViewGroup.<init> -> void
        v1 = -1;
        v5.mLastKnownCurrentPage = v1; // android.support.v4.view.PagerTitleStrip.mLastKnownCurrentPage:int
        v1 = 0xbf800000;
        v5.mLastKnownPositionOffset = v1; // android.support.v4.view.PagerTitleStrip.mLastKnownPositionOffset:float
        v1 = new android.support.v4.view.PagerTitleStrip$PageListener;
        v2 = 0;
        _result = v1.<init>(v5, v2); // android.support.v4.view.PagerTitleStrip$PageListener.<init> -> void
        v5.mPageListener = v1; // android.support.v4.view.PagerTitleStrip.mPageListener:android.support.v4.view.PagerTitleStrip$PageListener
        v1 = new android.widget.TextView;
        _result = v1.<init>(v6); // android.widget.TextView.<init> -> void
        v5.mPrevText = v1; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v5.addView(v1); // android.support.v4.view.PagerTitleStrip.addView -> void
        v1 = new android.widget.TextView;
        _result = v1.<init>(v6); // android.widget.TextView.<init> -> void
        v5.mCurrText = v1; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v5.addView(v1); // android.support.v4.view.PagerTitleStrip.addView -> void
        v1 = new android.widget.TextView;
        _result = v1.<init>(v6); // android.widget.TextView.<init> -> void
        v5.mNextText = v1; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v5.addView(v1); // android.support.v4.view.PagerTitleStrip.addView -> void
        v1 = android.support.v4.view.PagerTitleStrip.ATTRS; // :int[]
        _result = v6.obtainStyledAttributes(v7, v1); // android.content.Context.obtainStyledAttributes -> android.content.res.TypedArray
        v1 = _result;
        _result = v1.getResourceId(v0, v0); // android.content.res.TypedArray.getResourceId -> int
        v2 = _result;
        if (v2 == 0) /* goto L_004d */;
        v3 = v5.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v3.setTextAppearance(v6, v2); // android.widget.TextView.setTextAppearance -> void
        v3 = v5.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v3.setTextAppearance(v6, v2); // android.widget.TextView.setTextAppearance -> void
        v3 = v5.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v3.setTextAppearance(v6, v2); // android.widget.TextView.setTextAppearance -> void
        v3 = 1;
        _result = v1.getDimensionPixelSize(v3, v0); // android.content.res.TypedArray.getDimensionPixelSize -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0058 */;
        v3 = unaryOp_0x82(v3);
        _result = v5.setTextSize(v0, v3); // android.support.v4.view.PagerTitleStrip.setTextSize -> void
        _result = v1.hasValue(v4); // android.content.res.TypedArray.hasValue -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0071 */;
        _result = v1.getColor(v4, v0); // android.content.res.TypedArray.getColor -> int
        v3 = _result;
        v4 = v5.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v4.setTextColor(v3); // android.widget.TextView.setTextColor -> void
        v4 = v5.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v4.setTextColor(v3); // android.widget.TextView.setTextColor -> void
        v4 = v5.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v4.setTextColor(v3); // android.widget.TextView.setTextColor -> void
        v3 = 3;
        v4 = 80;
        _result = v1.getInteger(v3, v4); // android.content.res.TypedArray.getInteger -> int
        v3 = _result;
        v5.mGravity = v3; // android.support.v4.view.PagerTitleStrip.mGravity:int
        _result = v1.recycle(); // android.content.res.TypedArray.recycle -> void
        v1 = v5.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v1.getTextColors(); // android.widget.TextView.getTextColors -> android.content.res.ColorStateList
        v1 = _result;
        _result = v1.getDefaultColor(); // android.content.res.ColorStateList.getDefaultColor -> int
        v1 = _result;
        v5.mTextColor = v1; // android.support.v4.view.PagerTitleStrip.mTextColor:int
        v1 = 1058642330; // 0x3f19999a
        _result = v5.setNonPrimaryAlpha(v1); // android.support.v4.view.PagerTitleStrip.setNonPrimaryAlpha -> void
        v1 = v5.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        v3 = android.text.TextUtils$TruncateAt.END; // :android.text.TextUtils$TruncateAt
        _result = v1.setEllipsize(v3); // android.widget.TextView.setEllipsize -> void
        v1 = v5.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        v3 = android.text.TextUtils$TruncateAt.END; // :android.text.TextUtils$TruncateAt
        _result = v1.setEllipsize(v3); // android.widget.TextView.setEllipsize -> void
        v1 = v5.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        v3 = android.text.TextUtils$TruncateAt.END; // :android.text.TextUtils$TruncateAt
        _result = v1.setEllipsize(v3); // android.widget.TextView.setEllipsize -> void
        if (v2 == 0) /* goto L_00b3 */;
        v1 = android.support.v4.view.PagerTitleStrip.TEXT_ATTRS; // :int[]
        _result = v6.obtainStyledAttributes(v2, v1); // android.content.Context.obtainStyledAttributes -> android.content.res.TypedArray
        v1 = _result;
        _result = v1.getBoolean(v0, v0); // android.content.res.TypedArray.getBoolean -> boolean
        v0 = _result;
        _result = v1.recycle(); // android.content.res.TypedArray.recycle -> void
        if (v0 == 0) /* goto L_00d5 */;
        v0 = v5.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v0.setSingleLineAllCaps(); // android.support.v4.view.PagerTitleStrip.setSingleLineAllCaps -> void
        v0 = v5.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v0.setSingleLineAllCaps(); // android.support.v4.view.PagerTitleStrip.setSingleLineAllCaps -> void
        v0 = v5.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v0.setSingleLineAllCaps(); // android.support.v4.view.PagerTitleStrip.setSingleLineAllCaps -> void
        _result = v6.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v0 = _result;
        v0 = v0.density; // android.util.DisplayMetrics.density:float
        v1 = 0x41800000;
        v0 = binOp2addr_0xc8(v0, v1);
        v0 = unaryOp_0x87(v0);
        v5.mScaledTextSpacing = v0; // android.support.v4.view.PagerTitleStrip.mScaledTextSpacing:int
        return;
        v0 = v5.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v0.setSingleLine(); // android.widget.TextView.setSingleLine -> void
        v0 = v5.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v0.setSingleLine(); // android.widget.TextView.setSingleLine -> void
        v0 = v5.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v0.setSingleLine(); // android.widget.TextView.setSingleLine -> void
        // goto L_00c4
    }

    private static void setSingleLineAllCaps(android.widget.TextView p0) {
        // Registers (2 total): v1 = p0 (android.widget.TextView)
        v0 = android.support.v4.view.PagerTitleStrip.IMPL; // :android.support.v4.view.PagerTitleStrip$PagerTitleStripImpl
        _result = android.support.v4.view.PagerTitleStrip$PagerTitleStripImpl.setSingleLineAllCaps(v0, v1); // -> void
        return;
    }

    int getMinHeight() {
        // Registers (3 total): v2 = this
        v0 = 0;
        _result = v2.getBackground(); // android.support.v4.view.PagerTitleStrip.getBackground -> android.graphics.drawable.Drawable
        v1 = _result;
        if (v1 == 0) /* goto L_000b */;
        _result = v1.getIntrinsicHeight(); // android.graphics.drawable.Drawable.getIntrinsicHeight -> int
        v0 = _result;
        return v0;
    }

    public int getTextSpacing() {
        // Registers (2 total): v1 = this
        v0 = v1.mScaledTextSpacing; // android.support.v4.view.PagerTitleStrip.mScaledTextSpacing:int
        return v0;
    }

    protected void onAttachedToWindow() {
        // Registers (4 total): v3 = this
        _result = v3.onAttachedToWindow(); // android.view.ViewGroup.onAttachedToWindow -> void
        _result = v3.getParent(); // android.support.v4.view.PagerTitleStrip.getParent -> android.view.ViewParent
        v0 = _result;
        v1 = (v0 instanceof android.support.v4.view.ViewPager);
        if (v1 != 0) /* goto L_0013 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "PagerTitleStrip must be a direct child of a ViewPager.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = (android.support.v4.view.ViewPager) v0;
        _result = v0.getAdapter(); // android.support.v4.view.ViewPager.getAdapter -> android.support.v4.view.PagerAdapter
        v1 = _result;
        v2 = v3.mPageListener; // android.support.v4.view.PagerTitleStrip.mPageListener:android.support.v4.view.PagerTitleStrip$PageListener
        _result = v0.setInternalPageChangeListener(v2); // android.support.v4.view.ViewPager.setInternalPageChangeListener -> android.support.v4.view.ViewPager$OnPageChangeListener
        v2 = v3.mPageListener; // android.support.v4.view.PagerTitleStrip.mPageListener:android.support.v4.view.PagerTitleStrip$PageListener
        _result = v0.setOnAdapterChangeListener(v2); // android.support.v4.view.ViewPager.setOnAdapterChangeListener -> void
        v3.mPager = v0; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        v0 = 0;
        _result = v3.updateAdapter(v0, v1); // android.support.v4.view.PagerTitleStrip.updateAdapter -> void
        return;
    }

    protected void onDetachedFromWindow() {
        // Registers (3 total): v2 = this
        v1 = 0;
        _result = v2.onDetachedFromWindow(); // android.view.ViewGroup.onDetachedFromWindow -> void
        v0 = v2.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        if (v0 == 0) /* goto L_001d */;
        v0 = v2.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        _result = v0.getAdapter(); // android.support.v4.view.ViewPager.getAdapter -> android.support.v4.view.PagerAdapter
        v0 = _result;
        _result = v2.updateAdapter(v0, v1); // android.support.v4.view.PagerTitleStrip.updateAdapter -> void
        v0 = v2.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        _result = v0.setInternalPageChangeListener(v1); // android.support.v4.view.ViewPager.setInternalPageChangeListener -> android.support.v4.view.ViewPager$OnPageChangeListener
        v0 = v2.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        _result = v0.setOnAdapterChangeListener(v1); // android.support.v4.view.ViewPager.setOnAdapterChangeListener -> void
        v2.mPager = v1; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        return;
    }

    protected void onLayout(boolean p0, int p1, int p2, int p3, int p4) {
        // Registers (9 total): v3 = this, v4 = p0 (boolean), v5 = p1 (int), v6 = p2 (int), v7 = p3 (int), v8 = p4 (int)
        v0 = 0;
        v1 = v3.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        if (v1 == 0) /* goto L_0017 */;
        v1 = v3.mLastKnownPositionOffset; // android.support.v4.view.PagerTitleStrip.mLastKnownPositionOffset:float
        v1 = cmp(v1, v0);
        if (v1 < 0) /* goto L_000d */;
        v0 = v3.mLastKnownPositionOffset; // android.support.v4.view.PagerTitleStrip.mLastKnownPositionOffset:float
        v1 = v3.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        _result = v1.getCurrentItem(); // android.support.v4.view.ViewPager.getCurrentItem -> int
        v1 = _result;
        v2 = 1;
        _result = v3.updateTextPositions(v1, v0, v2); // android.support.v4.view.PagerTitleStrip.updateTextPositions -> void
        return;
    }

    protected void onMeasure(int p0, int p1) {
        // Registers (13 total): v10 = this, v11 = p0 (int), v12 = p1 (int)
        v9 = 0x40000000;
        v8 = 0x80000000;
        _result = v11.getMode(); // android.view.View$MeasureSpec.getMode -> int
        v0 = _result;
        _result = v12.getMode(); // android.view.View$MeasureSpec.getMode -> int
        v1 = _result;
        _result = v11.getSize(); // android.view.View$MeasureSpec.getSize -> int
        v2 = _result;
        _result = v12.getSize(); // android.view.View$MeasureSpec.getSize -> int
        v3 = _result;
        if (v0 == v9) /* goto L_001e */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Must measure with an exact width";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        _result = v10.getMinHeight(); // android.support.v4.view.PagerTitleStrip.getMinHeight -> int
        v0 = _result;
        _result = v10.getPaddingTop(); // android.support.v4.view.PagerTitleStrip.getPaddingTop -> int
        v4 = _result;
        _result = v10.getPaddingBottom(); // android.support.v4.view.PagerTitleStrip.getPaddingBottom -> int
        v5 = _result;
        v4 = binOp2addr_0xb0(v4, v5);
        v5 = binOp_0x91(v3, v4);
        v6 = unaryOp_0x82(v2);
        v7 = 1061997773; // 0x3f4ccccd
        v6 = binOp2addr_0xc8(v6, v7);
        v6 = unaryOp_0x87(v6);
        _result = v6.makeMeasureSpec(v8); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v6 = _result;
        _result = v5.makeMeasureSpec(v8); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v5 = _result;
        v7 = v10.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v7.measure(v6, v5); // android.widget.TextView.measure -> void
        v7 = v10.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v7.measure(v6, v5); // android.widget.TextView.measure -> void
        v7 = v10.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v7.measure(v6, v5); // android.widget.TextView.measure -> void
        if (v1 != v9) /* goto L_0050 */;
        _result = v10.setMeasuredDimension(v2, v3); // android.support.v4.view.PagerTitleStrip.setMeasuredDimension -> void
        return;
        v1 = v10.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v1.getMeasuredHeight(); // android.widget.TextView.getMeasuredHeight -> int
        v1 = _result;
        v1 = binOp2addr_0xb0(v1, v4);
        _result = v0.max(v1); // java.lang.Math.max -> int
        v0 = _result;
        _result = v10.setMeasuredDimension(v2, v0); // android.support.v4.view.PagerTitleStrip.setMeasuredDimension -> void
        // goto L_004f
    }

    public void requestLayout() {
        // Registers (2 total): v1 = this
        v0 = v1.mUpdatingText; // android.support.v4.view.PagerTitleStrip.mUpdatingText:boolean
        if (v0 != 0) /* goto L_0007 */;
        _result = v1.requestLayout(); // android.view.ViewGroup.requestLayout -> void
        return;
    }

    public void setGravity(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.mGravity = v1; // android.support.v4.view.PagerTitleStrip.mGravity:int
        _result = v0.requestLayout(); // android.support.v4.view.PagerTitleStrip.requestLayout -> void
        return;
    }

    public void setNonPrimaryAlpha(float p0) {
        // Registers (5 total): v3 = this, v4 = p0 (float)
        v0 = 0x437f0000;
        v0 = binOp2addr_0xc8(v0, v4);
        v0 = unaryOp_0x87(v0);
        v0 = binOpLit16_0xd5(v0, 255);
        v3.mNonPrimaryAlpha = v0; // android.support.v4.view.PagerTitleStrip.mNonPrimaryAlpha:int
        v0 = v3.mNonPrimaryAlpha; // android.support.v4.view.PagerTitleStrip.mNonPrimaryAlpha:int
        v0 = binOpLit8_0xe0(v0, 24);
        v1 = v3.mTextColor; // android.support.v4.view.PagerTitleStrip.mTextColor:int
        v2 = 16777215; // 0x00ffffff
        v1 = binOp2addr_0xb5(v1, v2);
        v0 = binOp2addr_0xb6(v0, v1);
        v1 = v3.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v1.setTextColor(v0); // android.widget.TextView.setTextColor -> void
        v1 = v3.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v1.setTextColor(v0); // android.widget.TextView.setTextColor -> void
        return;
    }

    public void setTextColor(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v3.mTextColor = v4; // android.support.v4.view.PagerTitleStrip.mTextColor:int
        v0 = v3.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v0.setTextColor(v4); // android.widget.TextView.setTextColor -> void
        v0 = v3.mNonPrimaryAlpha; // android.support.v4.view.PagerTitleStrip.mNonPrimaryAlpha:int
        v0 = binOpLit8_0xe0(v0, 24);
        v1 = v3.mTextColor; // android.support.v4.view.PagerTitleStrip.mTextColor:int
        v2 = 16777215; // 0x00ffffff
        v1 = binOp2addr_0xb5(v1, v2);
        v0 = binOp2addr_0xb6(v0, v1);
        v1 = v3.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v1.setTextColor(v0); // android.widget.TextView.setTextColor -> void
        v1 = v3.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v1.setTextColor(v0); // android.widget.TextView.setTextColor -> void
        return;
    }

    public void setTextSize(int p0, float p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (float)
        v0 = v1.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v0.setTextSize(v2, v3); // android.widget.TextView.setTextSize -> void
        v0 = v1.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v0.setTextSize(v2, v3); // android.widget.TextView.setTextSize -> void
        v0 = v1.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v0.setTextSize(v2, v3); // android.widget.TextView.setTextSize -> void
        return;
    }

    public void setTextSpacing(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.mScaledTextSpacing = v1; // android.support.v4.view.PagerTitleStrip.mScaledTextSpacing:int
        _result = v0.requestLayout(); // android.support.v4.view.PagerTitleStrip.requestLayout -> void
        return;
    }

    void updateAdapter(android.support.v4.view.PagerAdapter p0, android.support.v4.view.PagerAdapter p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.support.v4.view.PagerAdapter), v3 = p1 (android.support.v4.view.PagerAdapter)
        if (v2 == 0) /* goto L_0007 */;
        v0 = v1.mPageListener; // android.support.v4.view.PagerTitleStrip.mPageListener:android.support.v4.view.PagerTitleStrip$PageListener
        _result = v2.unregisterDataSetObserver(v0); // android.support.v4.view.PagerAdapter.unregisterDataSetObserver -> void
        if (v3 == 0) /* goto L_000e */;
        v0 = v1.mPageListener; // android.support.v4.view.PagerTitleStrip.mPageListener:android.support.v4.view.PagerTitleStrip$PageListener
        _result = v3.registerDataSetObserver(v0); // android.support.v4.view.PagerAdapter.registerDataSetObserver -> void
        v0 = v1.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        if (v0 == 0) /* goto L_0025 */;
        v0 = -1;
        v1.mLastKnownCurrentPage = v0; // android.support.v4.view.PagerTitleStrip.mLastKnownCurrentPage:int
        v0 = 0xbf800000;
        v1.mLastKnownPositionOffset = v0; // android.support.v4.view.PagerTitleStrip.mLastKnownPositionOffset:float
        v0 = v1.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        _result = v0.getCurrentItem(); // android.support.v4.view.ViewPager.getCurrentItem -> int
        v0 = _result;
        _result = v1.updateText(v0, v3); // android.support.v4.view.PagerTitleStrip.updateText -> void
        _result = v1.requestLayout(); // android.support.v4.view.PagerTitleStrip.requestLayout -> void
        return;
    }

    void updateText(int p0, android.support.v4.view.PagerAdapter p1) {
        // Registers (9 total): v6 = this, v7 = p0 (int), v8 = p1 (android.support.v4.view.PagerAdapter)
        v2 = 1;
        v5 = 0x80000000;
        v3 = 0;
        v1 = 0;
        if (v8 == 0) /* goto L_0081 */;
        _result = v8.getCount(); // android.support.v4.view.PagerAdapter.getCount -> int
        v0 = _result;
        v6.mUpdatingText = v2; // android.support.v4.view.PagerTitleStrip.mUpdatingText:boolean
        if (v7 < v2) /* goto L_0085 */;
        if (v8 == 0) /* goto L_0085 */;
        v2 = binOpLit8_0xd8(v7, -1);
        _result = v8.getPageTitle(v2); // android.support.v4.view.PagerAdapter.getPageTitle -> java.lang.CharSequence
        v2 = _result;
        v4 = v6.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v4.setText(v2); // android.widget.TextView.setText -> void
        v4 = v6.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        if (v8 == 0) /* goto L_0083 */;
        if (v7 >= v0) /* goto L_0083 */;
        _result = v8.getPageTitle(v7); // android.support.v4.view.PagerAdapter.getPageTitle -> java.lang.CharSequence
        v2 = _result;
        _result = v4.setText(v2); // android.widget.TextView.setText -> void
        v2 = binOpLit8_0xd8(v7, 1);
        if (v2 >= v0) /* goto L_0035 */;
        if (v8 == 0) /* goto L_0035 */;
        v0 = binOpLit8_0xd8(v7, 1);
        _result = v8.getPageTitle(v0); // android.support.v4.view.PagerAdapter.getPageTitle -> java.lang.CharSequence
        v3 = _result;
        v0 = v6.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v0.setText(v3); // android.widget.TextView.setText -> void
        _result = v6.getWidth(); // android.support.v4.view.PagerTitleStrip.getWidth -> int
        v0 = _result;
        _result = v6.getPaddingLeft(); // android.support.v4.view.PagerTitleStrip.getPaddingLeft -> int
        v2 = _result;
        v0 = binOp2addr_0xb1(v0, v2);
        _result = v6.getPaddingRight(); // android.support.v4.view.PagerTitleStrip.getPaddingRight -> int
        v2 = _result;
        v0 = binOp2addr_0xb1(v0, v2);
        _result = v6.getHeight(); // android.support.v4.view.PagerTitleStrip.getHeight -> int
        v2 = _result;
        _result = v6.getPaddingTop(); // android.support.v4.view.PagerTitleStrip.getPaddingTop -> int
        v3 = _result;
        v2 = binOp2addr_0xb1(v2, v3);
        _result = v6.getPaddingBottom(); // android.support.v4.view.PagerTitleStrip.getPaddingBottom -> int
        v3 = _result;
        v2 = binOp2addr_0xb1(v2, v3);
        v0 = unaryOp_0x82(v0);
        v3 = 1061997773; // 0x3f4ccccd
        v0 = binOp2addr_0xc8(v0, v3);
        v0 = unaryOp_0x87(v0);
        _result = v0.makeMeasureSpec(v5); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        _result = v2.makeMeasureSpec(v5); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v2 = _result;
        v3 = v6.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v3.measure(v0, v2); // android.widget.TextView.measure -> void
        v3 = v6.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v3.measure(v0, v2); // android.widget.TextView.measure -> void
        v3 = v6.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v3.measure(v0, v2); // android.widget.TextView.measure -> void
        v6.mLastKnownCurrentPage = v7; // android.support.v4.view.PagerTitleStrip.mLastKnownCurrentPage:int
        v0 = v6.mUpdatingPositions; // android.support.v4.view.PagerTitleStrip.mUpdatingPositions:boolean
        if (v0 != 0) /* goto L_007e */;
        v0 = v6.mLastKnownPositionOffset; // android.support.v4.view.PagerTitleStrip.mLastKnownPositionOffset:float
        _result = v6.updateTextPositions(v7, v0, v1); // android.support.v4.view.PagerTitleStrip.updateTextPositions -> void
        v6.mUpdatingText = v1; // android.support.v4.view.PagerTitleStrip.mUpdatingText:boolean
        return;
        v0 = v1;
        // goto L_000b
        v2 = v3;
        // goto L_0026
        v2 = v3;
        // goto L_0017
    }

    void updateTextPositions(int p0, float p1, boolean p2) {
        // Registers (22 total): v18 = this, v19 = p0 (int), v20 = p1 (float), v21 = p2 (boolean)
        v0 = v18;
        v2 = v0.mLastKnownCurrentPage; // android.support.v4.view.PagerTitleStrip.mLastKnownCurrentPage:int
        v0 = v19;
        if (v0 == v2) /* goto L_0127 */;
        v0 = v18;
        v2 = v0.mPager; // android.support.v4.view.PagerTitleStrip.mPager:android.support.v4.view.ViewPager
        _result = v2.getAdapter(); // android.support.v4.view.ViewPager.getAdapter -> android.support.v4.view.PagerAdapter
        v2 = _result;
        v0 = v18;
        v1 = v19;
        _result = v0.updateText(v1, v2); // android.support.v4.view.PagerTitleStrip.updateText -> void
        v2 = 1;
        v0 = v18;
        v0.mUpdatingPositions = v2; // android.support.v4.view.PagerTitleStrip.mUpdatingPositions:boolean
        v0 = v18;
        v2 = v0.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v2.getMeasuredWidth(); // android.widget.TextView.getMeasuredWidth -> int
        v5 = _result;
        v0 = v18;
        v2 = v0.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v2.getMeasuredWidth(); // android.widget.TextView.getMeasuredWidth -> int
        v3 = _result;
        v0 = v18;
        v2 = v0.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v2.getMeasuredWidth(); // android.widget.TextView.getMeasuredWidth -> int
        v6 = _result;
        v2 = binOpLit8_0xdb(v3, 2);
        _result = v18.getWidth(v18..v18); // android.support.v4.view.PagerTitleStrip.getWidth -> int
        v7 = _result;
        _result = v18.getHeight(v18..v18); // android.support.v4.view.PagerTitleStrip.getHeight -> int
        v4 = _result;
        _result = v18.getPaddingLeft(v18..v18); // android.support.v4.view.PagerTitleStrip.getPaddingLeft -> int
        v8 = _result;
        _result = v18.getPaddingRight(v18..v18); // android.support.v4.view.PagerTitleStrip.getPaddingRight -> int
        v9 = _result;
        _result = v18.getPaddingTop(v18..v18); // android.support.v4.view.PagerTitleStrip.getPaddingTop -> int
        v10 = _result;
        _result = v18.getPaddingBottom(v18..v18); // android.support.v4.view.PagerTitleStrip.getPaddingBottom -> int
        v11 = _result;
        v12 = binOp_0x90(v8, v2);
        v13 = binOp_0x90(v9, v2);
        v2 = binOp_0x91(v7, v12);
        v12 = binOp_0x91(v2, v13);
        v2 = 0x3f000000;
        v2 = binOp_0xa6(v2, v20);
        v14 = 0x3f800000;
        v14 = cmp(v2, v14);
        if (v14 <= 0) /* goto L_0063 */;
        v14 = 0x3f800000;
        v2 = binOp2addr_0xc7(v2, v14);
        v13 = binOp_0x91(v7, v13);
        v12 = unaryOp_0x82(v12);
        v2 = binOp2addr_0xc8(v2, v12);
        v2 = unaryOp_0x87(v2);
        v2 = binOp_0x91(v13, v2);
        v12 = binOpLit8_0xdb(v3, 2);
        v12 = binOp_0x91(v2, v12);
        v13 = binOp_0x90(v12, v3);
        v0 = v18;
        v2 = v0.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v2.getBaseline(); // android.widget.TextView.getBaseline -> int
        v2 = _result;
        v0 = v18;
        v3 = v0.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v3.getBaseline(); // android.widget.TextView.getBaseline -> int
        v3 = _result;
        v0 = v18;
        v14 = v0.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v14.getBaseline(); // android.widget.TextView.getBaseline -> int
        v14 = _result;
        _result = v2.max(v3); // java.lang.Math.max -> int
        v15 = _result;
        _result = v15.max(v14); // java.lang.Math.max -> int
        v15 = _result;
        v2 = binOp_0x91(v15, v2);
        v3 = binOp_0x91(v15, v3);
        v14 = binOp_0x91(v15, v14);
        v0 = v18;
        v15 = v0.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v15.getMeasuredHeight(); // android.widget.TextView.getMeasuredHeight -> int
        v15 = _result;
        v15 = binOp2addr_0xb0(v15, v2);
        v0 = v18;
        v0 = v0.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        v16 = v0;
        _result = v16.getMeasuredHeight(v16..v16); // android.widget.TextView.getMeasuredHeight -> int
        v16 = _result;
        v16 = binOp_0x90(v16, v3);
        v0 = v18;
        v0 = v0.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        v17 = v0;
        _result = v17.getMeasuredHeight(v17..v17); // android.widget.TextView.getMeasuredHeight -> int
        v17 = _result;
        v17 = binOp_0x90(v17, v14);
        _result = v15.max(v15..v16); // java.lang.Math.max -> int
        v15 = _result;
        v0 = v17;
        _result = v15.max(v0); // java.lang.Math.max -> int
        v15 = _result;
        v0 = v18;
        v0 = v0.mGravity; // android.support.v4.view.PagerTitleStrip.mGravity:int
        v16 = v0;
        v16 = binOpLit8_0xdd(v16, 112);
        // switch(v16)
        v4 = binOp_0x90(v10, v2);
        v3 = binOp2addr_0xb0(v3, v10);
        v2 = binOp_0x90(v10, v14);
        v0 = v18;
        v10 = v0.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        v0 = v18;
        v11 = v0.mCurrText; // android.support.v4.view.PagerTitleStrip.mCurrText:android.widget.TextView
        _result = v11.getMeasuredHeight(); // android.widget.TextView.getMeasuredHeight -> int
        v11 = _result;
        v11 = binOp2addr_0xb0(v11, v3);
        _result = v10.layout(v12, v3, v13, v11); // android.widget.TextView.layout -> void
        v0 = v18;
        v3 = v0.mScaledTextSpacing; // android.support.v4.view.PagerTitleStrip.mScaledTextSpacing:int
        v3 = binOp_0x91(v12, v3);
        v3 = binOp2addr_0xb1(v3, v5);
        _result = v8.min(v3); // java.lang.Math.min -> int
        v3 = _result;
        v0 = v18;
        v8 = v0.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        v5 = binOp2addr_0xb0(v5, v3);
        v0 = v18;
        v10 = v0.mPrevText; // android.support.v4.view.PagerTitleStrip.mPrevText:android.widget.TextView
        _result = v10.getMeasuredHeight(); // android.widget.TextView.getMeasuredHeight -> int
        v10 = _result;
        v10 = binOp2addr_0xb0(v10, v4);
        _result = v8.layout(v3, v4, v5, v10); // android.widget.TextView.layout -> void
        v3 = binOp_0x91(v7, v9);
        v3 = binOp2addr_0xb1(v3, v6);
        v0 = v18;
        v4 = v0.mScaledTextSpacing; // android.support.v4.view.PagerTitleStrip.mScaledTextSpacing:int
        v4 = binOp2addr_0xb0(v4, v13);
        _result = v3.max(v4); // java.lang.Math.max -> int
        v3 = _result;
        v0 = v18;
        v4 = v0.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        v5 = binOp_0x90(v3, v6);
        v0 = v18;
        v6 = v0.mNextText; // android.support.v4.view.PagerTitleStrip.mNextText:android.widget.TextView
        _result = v6.getMeasuredHeight(); // android.widget.TextView.getMeasuredHeight -> int
        v6 = _result;
        v6 = binOp2addr_0xb0(v6, v2);
        _result = v4.layout(v3, v2, v5, v6); // android.widget.TextView.layout -> void
        v0 = v20;
        v1 = v18;
        v1.mLastKnownPositionOffset = v0; // android.support.v4.view.PagerTitleStrip.mLastKnownPositionOffset:float
        v2 = 0;
        v0 = v18;
        v0.mUpdatingPositions = v2; // android.support.v4.view.PagerTitleStrip.mUpdatingPositions:boolean
        return;
        if (v21 != 0) /* goto L_0017 */;
        v0 = v18;
        v2 = v0.mLastKnownPositionOffset; // android.support.v4.view.PagerTitleStrip.mLastKnownPositionOffset:float
        v2 = cmp(v20, v2);
        if (v2 != 0) /* goto L_0017 */;
        // goto L_0126
        v4 = binOp2addr_0xb1(v4, v10);
        v4 = binOp2addr_0xb1(v4, v11);
        v4 = binOp2addr_0xb1(v4, v15);
        v10 = binOpLit8_0xdb(v4, 2);
        v4 = binOp_0x90(v10, v2);
        v3 = binOp2addr_0xb0(v3, v10);
        v2 = binOp_0x90(v10, v14);
        // goto L_00d1
        v4 = binOp2addr_0xb1(v4, v11);
        v10 = binOp_0x91(v4, v15);
        v4 = binOp_0x90(v10, v2);
        v3 = binOp2addr_0xb0(v3, v10);
        v2 = binOp_0x90(v10, v14);
        // goto L_00d1
    }

}