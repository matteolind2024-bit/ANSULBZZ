package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityManagerCompatIcs.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs;
 */
class AccessibilityManagerCompatIcs {
    AccessibilityManagerCompatIcs() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean addAccessibilityStateChangeListener(android.view.accessibility.AccessibilityManager p0, java.lang.Object p1) {
        // Registers (3 total): v1 = p0 (android.view.accessibility.AccessibilityManager), v2 = p1 (java.lang.Object)
        v2 = (android.view.accessibility.AccessibilityManager$AccessibilityStateChangeListener) v2;
        _result = v1.addAccessibilityStateChangeListener(v2); // android.view.accessibility.AccessibilityManager.addAccessibilityStateChangeListener -> boolean
        v0 = _result;
        return v0;
    }

    public static java.util.List getEnabledAccessibilityServiceList(android.view.accessibility.AccessibilityManager p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.accessibility.AccessibilityManager), v2 = p1 (int)
        _result = v1.getEnabledAccessibilityServiceList(v2); // android.view.accessibility.AccessibilityManager.getEnabledAccessibilityServiceList -> java.util.List
        v0 = _result;
        return v0;
    }

    public static java.util.List getInstalledAccessibilityServiceList(android.view.accessibility.AccessibilityManager p0) {
        // Registers (2 total): v1 = p0 (android.view.accessibility.AccessibilityManager)
        _result = v1.getInstalledAccessibilityServiceList(); // android.view.accessibility.AccessibilityManager.getInstalledAccessibilityServiceList -> java.util.List
        v0 = _result;
        return v0;
    }

    public static boolean isTouchExplorationEnabled(android.view.accessibility.AccessibilityManager p0) {
        // Registers (2 total): v1 = p0 (android.view.accessibility.AccessibilityManager)
        _result = v1.isTouchExplorationEnabled(); // android.view.accessibility.AccessibilityManager.isTouchExplorationEnabled -> boolean
        v0 = _result;
        return v0;
    }

    public static java.lang.Object newAccessibilityStateChangeListener(android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge)
        v0 = new android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$1;
        _result = v0.<init>(v1); // android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$1.<init> -> void
        return v0;
    }

    public static boolean removeAccessibilityStateChangeListener(android.view.accessibility.AccessibilityManager p0, java.lang.Object p1) {
        // Registers (3 total): v1 = p0 (android.view.accessibility.AccessibilityManager), v2 = p1 (java.lang.Object)
        v2 = (android.view.accessibility.AccessibilityManager$AccessibilityStateChangeListener) v2;
        _result = v1.removeAccessibilityStateChangeListener(v2); // android.view.accessibility.AccessibilityManager.removeAccessibilityStateChangeListener -> boolean
        v0 = _result;
        return v0;
    }

}