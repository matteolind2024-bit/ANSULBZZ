package android.support.v4.widget;

/**
 * Original SourceFile: SearchViewCompat.java
 * Descriptor: Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;
 */
public abstract class SearchViewCompat$OnQueryTextListenerCompat {
    final java.lang.Object mListener;

    public SearchViewCompat$OnQueryTextListenerCompat() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        _result = this.access$000(); // android.support.v4.widget.SearchViewCompat.access$000 -> android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl
        v0 = _result;
        _result = android.support.v4.widget.SearchViewCompat$SearchViewCompatImpl.newOnQueryTextListener(v0, v1); // -> java.lang.Object
        v0 = _result;
        v1.mListener = v0; // android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat.mListener:java.lang.Object
        return;
    }

    public boolean onQueryTextChange(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = 0;
        return v0;
    }

    public boolean onQueryTextSubmit(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = 0;
        return v0;
    }

}