package android.support.v4.app;

/**
 * Original SourceFile: LoaderManager.java
 * Descriptor: Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
 */
public interface LoaderManager$LoaderCallbacks {
    public abstract android.support.v4.content.Loader onCreateLoader(int p0, android.os.Bundle p1);
    public abstract void onLoadFinished(android.support.v4.content.Loader p0, java.lang.Object p1);
    public abstract void onLoaderReset(android.support.v4.content.Loader p0);
}