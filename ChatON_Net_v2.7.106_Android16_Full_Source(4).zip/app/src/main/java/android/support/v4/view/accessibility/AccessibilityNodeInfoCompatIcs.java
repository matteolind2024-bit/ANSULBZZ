package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityNodeInfoCompatIcs.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatIcs;
 */
class AccessibilityNodeInfoCompatIcs {
    AccessibilityNodeInfoCompatIcs() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void addAction(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.addAction(v1); // android.view.accessibility.AccessibilityNodeInfo.addAction -> void
        return;
    }

    public static void addChild(java.lang.Object p0, android.view.View p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.addChild(v1); // android.view.accessibility.AccessibilityNodeInfo.addChild -> void
        return;
    }

    public static java.util.List findAccessibilityNodeInfosByText(java.lang.Object p0, java.lang.String p1) {
        // Registers (3 total): v1 = p0 (java.lang.Object), v2 = p1 (java.lang.String)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.findAccessibilityNodeInfosByText(v2); // android.view.accessibility.AccessibilityNodeInfo.findAccessibilityNodeInfosByText -> java.util.List
        v0 = _result;
        v0 = (java.util.List) v0;
        return v0;
    }

    public static int getActions(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getActions(); // android.view.accessibility.AccessibilityNodeInfo.getActions -> int
        v0 = _result;
        return v0;
    }

    public static void getBoundsInParent(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.graphics.Rect)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.getBoundsInParent(v1); // android.view.accessibility.AccessibilityNodeInfo.getBoundsInParent -> void
        return;
    }

    public static void getBoundsInScreen(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.graphics.Rect)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.getBoundsInScreen(v1); // android.view.accessibility.AccessibilityNodeInfo.getBoundsInScreen -> void
        return;
    }

    public static java.lang.Object getChild(java.lang.Object p0, int p1) {
        // Registers (3 total): v1 = p0 (java.lang.Object), v2 = p1 (int)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getChild(v2); // android.view.accessibility.AccessibilityNodeInfo.getChild -> android.view.accessibility.AccessibilityNodeInfo
        v0 = _result;
        return v0;
    }

    public static int getChildCount(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getChildCount(); // android.view.accessibility.AccessibilityNodeInfo.getChildCount -> int
        v0 = _result;
        return v0;
    }

    public static java.lang.CharSequence getClassName(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getClassName(); // android.view.accessibility.AccessibilityNodeInfo.getClassName -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public static java.lang.CharSequence getContentDescription(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getContentDescription(); // android.view.accessibility.AccessibilityNodeInfo.getContentDescription -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public static java.lang.CharSequence getPackageName(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getPackageName(); // android.view.accessibility.AccessibilityNodeInfo.getPackageName -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public static java.lang.Object getParent(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getParent(); // android.view.accessibility.AccessibilityNodeInfo.getParent -> android.view.accessibility.AccessibilityNodeInfo
        v0 = _result;
        return v0;
    }

    public static java.lang.CharSequence getText(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getText(); // android.view.accessibility.AccessibilityNodeInfo.getText -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public static int getWindowId(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getWindowId(); // android.view.accessibility.AccessibilityNodeInfo.getWindowId -> int
        v0 = _result;
        return v0;
    }

    public static boolean isCheckable(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isCheckable(); // android.view.accessibility.AccessibilityNodeInfo.isCheckable -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isChecked(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isChecked(); // android.view.accessibility.AccessibilityNodeInfo.isChecked -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isClickable(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isClickable(); // android.view.accessibility.AccessibilityNodeInfo.isClickable -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isEnabled(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isEnabled(); // android.view.accessibility.AccessibilityNodeInfo.isEnabled -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isFocusable(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isFocusable(); // android.view.accessibility.AccessibilityNodeInfo.isFocusable -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isFocused(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isFocused(); // android.view.accessibility.AccessibilityNodeInfo.isFocused -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isLongClickable(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isLongClickable(); // android.view.accessibility.AccessibilityNodeInfo.isLongClickable -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isPassword(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isPassword(); // android.view.accessibility.AccessibilityNodeInfo.isPassword -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isScrollable(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isScrollable(); // android.view.accessibility.AccessibilityNodeInfo.isScrollable -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isSelected(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isSelected(); // android.view.accessibility.AccessibilityNodeInfo.isSelected -> boolean
        v0 = _result;
        return v0;
    }

    public static java.lang.Object obtain() {
        _result = this.obtain(); // android.view.accessibility.AccessibilityNodeInfo.obtain -> android.view.accessibility.AccessibilityNodeInfo
        v0 = _result;
        return v0;
    }

    public static java.lang.Object obtain(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        _result = v1.obtain(); // android.view.accessibility.AccessibilityNodeInfo.obtain -> android.view.accessibility.AccessibilityNodeInfo
        v0 = _result;
        return v0;
    }

    public static java.lang.Object obtain(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.obtain(); // android.view.accessibility.AccessibilityNodeInfo.obtain -> android.view.accessibility.AccessibilityNodeInfo
        v0 = _result;
        return v0;
    }

    public static boolean performAction(java.lang.Object p0, int p1) {
        // Registers (3 total): v1 = p0 (java.lang.Object), v2 = p1 (int)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.performAction(v2); // android.view.accessibility.AccessibilityNodeInfo.performAction -> boolean
        v0 = _result;
        return v0;
    }

    public static void recycle(java.lang.Object p0) {
        // Registers (1 total): v0 = p0 (java.lang.Object)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.recycle(); // android.view.accessibility.AccessibilityNodeInfo.recycle -> void
        return;
    }

    public static void setBoundsInParent(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.graphics.Rect)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setBoundsInParent(v1); // android.view.accessibility.AccessibilityNodeInfo.setBoundsInParent -> void
        return;
    }

    public static void setBoundsInScreen(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.graphics.Rect)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setBoundsInScreen(v1); // android.view.accessibility.AccessibilityNodeInfo.setBoundsInScreen -> void
        return;
    }

    public static void setCheckable(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setCheckable(v1); // android.view.accessibility.AccessibilityNodeInfo.setCheckable -> void
        return;
    }

    public static void setChecked(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setChecked(v1); // android.view.accessibility.AccessibilityNodeInfo.setChecked -> void
        return;
    }

    public static void setClassName(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (java.lang.CharSequence)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setClassName(v1); // android.view.accessibility.AccessibilityNodeInfo.setClassName -> void
        return;
    }

    public static void setClickable(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setClickable(v1); // android.view.accessibility.AccessibilityNodeInfo.setClickable -> void
        return;
    }

    public static void setContentDescription(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (java.lang.CharSequence)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setContentDescription(v1); // android.view.accessibility.AccessibilityNodeInfo.setContentDescription -> void
        return;
    }

    public static void setEnabled(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setEnabled(v1); // android.view.accessibility.AccessibilityNodeInfo.setEnabled -> void
        return;
    }

    public static void setFocusable(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setFocusable(v1); // android.view.accessibility.AccessibilityNodeInfo.setFocusable -> void
        return;
    }

    public static void setFocused(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setFocused(v1); // android.view.accessibility.AccessibilityNodeInfo.setFocused -> void
        return;
    }

    public static void setLongClickable(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setLongClickable(v1); // android.view.accessibility.AccessibilityNodeInfo.setLongClickable -> void
        return;
    }

    public static void setPackageName(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (java.lang.CharSequence)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setPackageName(v1); // android.view.accessibility.AccessibilityNodeInfo.setPackageName -> void
        return;
    }

    public static void setParent(java.lang.Object p0, android.view.View p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setParent(v1); // android.view.accessibility.AccessibilityNodeInfo.setParent -> void
        return;
    }

    public static void setPassword(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setPassword(v1); // android.view.accessibility.AccessibilityNodeInfo.setPassword -> void
        return;
    }

    public static void setScrollable(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setScrollable(v1); // android.view.accessibility.AccessibilityNodeInfo.setScrollable -> void
        return;
    }

    public static void setSelected(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setSelected(v1); // android.view.accessibility.AccessibilityNodeInfo.setSelected -> void
        return;
    }

    public static void setSource(java.lang.Object p0, android.view.View p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setSource(v1); // android.view.accessibility.AccessibilityNodeInfo.setSource -> void
        return;
    }

    public static void setText(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (java.lang.CharSequence)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setText(v1); // android.view.accessibility.AccessibilityNodeInfo.setText -> void
        return;
    }

}