package android.support.v4.app;

/**
 * Original SourceFile: BackStackRecord.java
 * Descriptor: Landroid/support/v4/app/BackStackRecord;
 */
final class BackStackRecord extends android.support.v4.app.FragmentTransaction implements android.support.v4.app.FragmentManager$BackStackEntry, java.lang.Runnable {
    static final int OP_ADD;
    static final int OP_ATTACH;
    static final int OP_DETACH;
    static final int OP_HIDE;
    static final int OP_NULL;
    static final int OP_REMOVE;
    static final int OP_REPLACE;
    static final int OP_SHOW;
    static final java.lang.String TAG;
     boolean mAddToBackStack;
     boolean mAllowAddToBackStack;
     int mBreadCrumbShortTitleRes;
     java.lang.CharSequence mBreadCrumbShortTitleText;
     int mBreadCrumbTitleRes;
     java.lang.CharSequence mBreadCrumbTitleText;
     boolean mCommitted;
     int mEnterAnim;
     int mExitAnim;
     android.support.v4.app.BackStackRecord$Op mHead;
     int mIndex;
    final android.support.v4.app.FragmentManagerImpl mManager;
     java.lang.String mName;
     int mNumOp;
     int mPopEnterAnim;
     int mPopExitAnim;
     android.support.v4.app.BackStackRecord$Op mTail;
     int mTransition;
     int mTransitionStyle;

    public BackStackRecord(android.support.v4.app.FragmentManagerImpl p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.FragmentManagerImpl)
        _result = v1.<init>(); // android.support.v4.app.FragmentTransaction.<init> -> void
        v0 = 1;
        v1.mAllowAddToBackStack = v0; // android.support.v4.app.BackStackRecord.mAllowAddToBackStack:boolean
        v1.mManager = v2; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        return;
    }

    private void doAddOp(int p0, android.support.v4.app.Fragment p1, java.lang.String p2, int p3) {
        // Registers (8 total): v3 = this, v4 = p0 (int), v5 = p1 (android.support.v4.app.Fragment), v6 = p2 (java.lang.String), v7 = p3 (int)
        v0 = v3.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v5.mFragmentManager = v0; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.FragmentManagerImpl
        if (v6 == 0) /* goto L_0043 */;
        v0 = v5.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        if (v0 == 0) /* goto L_0041 */;
        v0 = v5.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v6.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0041 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Can't change tag of fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ": was ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v5.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " now ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v5.mTag = v6; // android.support.v4.app.Fragment.mTag:java.lang.String
        if (v4 == 0) /* goto L_0080 */;
        v0 = v5.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        if (v0 == 0) /* goto L_007c */;
        v0 = v5.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        if (v0 == v4) /* goto L_007c */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Can't change container ID of fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ": was ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v5.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " now ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v5.mFragmentId = v4; // android.support.v4.app.Fragment.mFragmentId:int
        v5.mContainerId = v4; // android.support.v4.app.Fragment.mContainerId:int
        v0 = new android.support.v4.app.BackStackRecord$Op;
        _result = v0.<init>(); // android.support.v4.app.BackStackRecord$Op.<init> -> void
        v0.cmd = v7; // android.support.v4.app.BackStackRecord$Op.cmd:int
        v0.fragment = v5; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        _result = v3.addOp(v0); // android.support.v4.app.BackStackRecord.addOp -> void
        return;
    }

    public android.support.v4.app.FragmentTransaction add(int p0, android.support.v4.app.Fragment p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (android.support.v4.app.Fragment)
        v0 = 0;
        v1 = 1;
        _result = v2.doAddOp(v3, v4, v0, v1); // android.support.v4.app.BackStackRecord.doAddOp -> void
        return v2;
    }

    public android.support.v4.app.FragmentTransaction add(int p0, android.support.v4.app.Fragment p1, java.lang.String p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (android.support.v4.app.Fragment), v4 = p2 (java.lang.String)
        v0 = 1;
        _result = v1.doAddOp(v2, v3, v4, v0); // android.support.v4.app.BackStackRecord.doAddOp -> void
        return v1;
    }

    public android.support.v4.app.FragmentTransaction add(android.support.v4.app.Fragment p0, java.lang.String p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment), v4 = p1 (java.lang.String)
        v0 = 0;
        v1 = 1;
        _result = v2.doAddOp(v0, v3, v4, v1); // android.support.v4.app.BackStackRecord.doAddOp -> void
        return v2;
    }

    void addOp(android.support.v4.app.BackStackRecord$Op p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.BackStackRecord$Op)
        v0 = v1.mHead; // android.support.v4.app.BackStackRecord.mHead:android.support.v4.app.BackStackRecord$Op
        if (v0 != 0) /* goto L_001f */;
        v1.mTail = v2; // android.support.v4.app.BackStackRecord.mTail:android.support.v4.app.BackStackRecord$Op
        v1.mHead = v2; // android.support.v4.app.BackStackRecord.mHead:android.support.v4.app.BackStackRecord$Op
        v0 = v1.mEnterAnim; // android.support.v4.app.BackStackRecord.mEnterAnim:int
        v2.enterAnim = v0; // android.support.v4.app.BackStackRecord$Op.enterAnim:int
        v0 = v1.mExitAnim; // android.support.v4.app.BackStackRecord.mExitAnim:int
        v2.exitAnim = v0; // android.support.v4.app.BackStackRecord$Op.exitAnim:int
        v0 = v1.mPopEnterAnim; // android.support.v4.app.BackStackRecord.mPopEnterAnim:int
        v2.popEnterAnim = v0; // android.support.v4.app.BackStackRecord$Op.popEnterAnim:int
        v0 = v1.mPopExitAnim; // android.support.v4.app.BackStackRecord.mPopExitAnim:int
        v2.popExitAnim = v0; // android.support.v4.app.BackStackRecord$Op.popExitAnim:int
        v0 = v1.mNumOp; // android.support.v4.app.BackStackRecord.mNumOp:int
        v0 = binOpLit8_0xd8(v0, 1);
        v1.mNumOp = v0; // android.support.v4.app.BackStackRecord.mNumOp:int
        return;
        v0 = v1.mTail; // android.support.v4.app.BackStackRecord.mTail:android.support.v4.app.BackStackRecord$Op
        v2.prev = v0; // android.support.v4.app.BackStackRecord$Op.prev:android.support.v4.app.BackStackRecord$Op
        v0 = v1.mTail; // android.support.v4.app.BackStackRecord.mTail:android.support.v4.app.BackStackRecord$Op
        v0.next = v2; // android.support.v4.app.BackStackRecord$Op.next:android.support.v4.app.BackStackRecord$Op
        v1.mTail = v2; // android.support.v4.app.BackStackRecord.mTail:android.support.v4.app.BackStackRecord$Op
        // goto L_0008
    }

    public android.support.v4.app.FragmentTransaction addToBackStack(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = v2.mAllowAddToBackStack; // android.support.v4.app.BackStackRecord.mAllowAddToBackStack:boolean
        if (v0 != 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "This FragmentTransaction is not allowed to be added to the back stack.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = 1;
        v2.mAddToBackStack = v0; // android.support.v4.app.BackStackRecord.mAddToBackStack:boolean
        v2.mName = v3; // android.support.v4.app.BackStackRecord.mName:java.lang.String
        return v2;
    }

    public android.support.v4.app.FragmentTransaction attach(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = new android.support.v4.app.BackStackRecord$Op;
        _result = v0.<init>(); // android.support.v4.app.BackStackRecord$Op.<init> -> void
        v1 = 7;
        v0.cmd = v1; // android.support.v4.app.BackStackRecord$Op.cmd:int
        v0.fragment = v3; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        _result = v2.addOp(v0); // android.support.v4.app.BackStackRecord.addOp -> void
        return v2;
    }

    void bumpBackStackNesting(int p0) {
        // Registers (8 total): v6 = this, v7 = p0 (int)
        v0 = v6.mAddToBackStack; // android.support.v4.app.BackStackRecord.mAddToBackStack:boolean
        if (v0 != 0) /* goto L_0005 */;
        return;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_002b */;
        v0 = "BackStackEntry";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Bump nesting in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " by ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v6.mHead; // android.support.v4.app.BackStackRecord.mHead:android.support.v4.app.BackStackRecord$Op
        v2 = v0;
        if (v2 == 0) /* goto L_0004 */;
        v0 = v2.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0067 */;
        v0 = v2.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v0.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        v1 = binOp2addr_0xb0(v1, v7);
        v0.mBackStackNesting = v1; // android.support.v4.app.Fragment.mBackStackNesting:int
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0067 */;
        v0 = "BackStackEntry";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Bump nesting of ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v3 = v2.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v3 = " to ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v3 = v2.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v3 = v3.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v2.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        if (v0 == 0) /* goto L_00af */;
        v0 = v2.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_00af */;
        v0 = v2.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v3 = v0.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        v3 = binOp2addr_0xb0(v3, v7);
        v0.mBackStackNesting = v3; // android.support.v4.app.Fragment.mBackStackNesting:int
        v3 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v3 == 0) /* goto L_00ab */;
        v3 = "BackStackEntry";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "Bump nesting of ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = " to ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v0 = v0.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v3.v(v0); // android.util.Log.v -> int
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0074
        v0 = v2.next; // android.support.v4.app.BackStackRecord$Op.next:android.support.v4.app.BackStackRecord$Op
        v2 = v0;
        // goto L_002e
    }

    public int commit() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.commitInternal(v0); // android.support.v4.app.BackStackRecord.commitInternal -> int
        v0 = _result;
        return v0;
    }

    public int commitAllowingStateLoss() {
        // Registers (2 total): v1 = this
        v0 = 1;
        _result = v1.commitInternal(v0); // android.support.v4.app.BackStackRecord.commitInternal -> int
        v0 = _result;
        return v0;
    }

    int commitInternal(boolean p0) {
        // Registers (5 total): v3 = this, v4 = p0 (boolean)
        v0 = v3.mCommitted; // android.support.v4.app.BackStackRecord.mCommitted:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "commit already called";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0028 */;
        v0 = "BackStackEntry";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Commit: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = 1;
        v3.mCommitted = v0; // android.support.v4.app.BackStackRecord.mCommitted:boolean
        v0 = v3.mAddToBackStack; // android.support.v4.app.BackStackRecord.mAddToBackStack:boolean
        if (v0 == 0) /* goto L_003f */;
        v0 = v3.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        _result = v0.allocBackStackIndex(v3); // android.support.v4.app.FragmentManagerImpl.allocBackStackIndex -> int
        v0 = _result;
        v3.mIndex = v0; // android.support.v4.app.BackStackRecord.mIndex:int
        v0 = v3.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        _result = v0.enqueueAction(v3, v4); // android.support.v4.app.FragmentManagerImpl.enqueueAction -> void
        v0 = v3.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        return v0;
        v0 = -1;
        v3.mIndex = v0; // android.support.v4.app.BackStackRecord.mIndex:int
        // goto L_0037
    }

    public android.support.v4.app.FragmentTransaction detach(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = new android.support.v4.app.BackStackRecord$Op;
        _result = v0.<init>(); // android.support.v4.app.BackStackRecord$Op.<init> -> void
        v1 = 6;
        v0.cmd = v1; // android.support.v4.app.BackStackRecord$Op.cmd:int
        v0.fragment = v3; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        _result = v2.addOp(v0); // android.support.v4.app.BackStackRecord.addOp -> void
        return v2;
    }

    public android.support.v4.app.FragmentTransaction disallowAddToBackStack() {
        // Registers (3 total): v2 = this
        v0 = v2.mAddToBackStack; // android.support.v4.app.BackStackRecord.mAddToBackStack:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "This transaction is already being added to the back stack";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = 0;
        v2.mAllowAddToBackStack = v0; // android.support.v4.app.BackStackRecord.mAllowAddToBackStack:boolean
        return v2;
    }

    public void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (11 total): v6 = this, v7 = p0 (java.lang.String), v8 = p1 (java.io.FileDescriptor), v9 = p2 (java.io.PrintWriter), v10 = p3 (java.lang.String[])
        v1 = 0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "mName=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mName; // android.support.v4.app.BackStackRecord.mName:java.lang.String
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mIndex=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mCommitted=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mCommitted; // android.support.v4.app.BackStackRecord.mCommitted:boolean
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        if (v0 == 0) /* goto L_0045 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "mTransition=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mTransitionStyle=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.mEnterAnim; // android.support.v4.app.BackStackRecord.mEnterAnim:int
        if (v0 != 0) /* goto L_004d */;
        v0 = v6.mExitAnim; // android.support.v4.app.BackStackRecord.mExitAnim:int
        if (v0 == 0) /* goto L_006c */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "mEnterAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mEnterAnim; // android.support.v4.app.BackStackRecord.mEnterAnim:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mExitAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mExitAnim; // android.support.v4.app.BackStackRecord.mExitAnim:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.mPopEnterAnim; // android.support.v4.app.BackStackRecord.mPopEnterAnim:int
        if (v0 != 0) /* goto L_0074 */;
        v0 = v6.mPopExitAnim; // android.support.v4.app.BackStackRecord.mPopExitAnim:int
        if (v0 == 0) /* goto L_0093 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "mPopEnterAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mPopEnterAnim; // android.support.v4.app.BackStackRecord.mPopEnterAnim:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mPopExitAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mPopExitAnim; // android.support.v4.app.BackStackRecord.mPopExitAnim:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.mBreadCrumbTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleRes:int
        if (v0 != 0) /* goto L_009b */;
        v0 = v6.mBreadCrumbTitleText; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleText:java.lang.CharSequence
        if (v0 == 0) /* goto L_00b6 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "mBreadCrumbTitleRes=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mBreadCrumbTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleRes:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mBreadCrumbTitleText=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mBreadCrumbTitleText; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleText:java.lang.CharSequence
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.mBreadCrumbShortTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleRes:int
        if (v0 != 0) /* goto L_00be */;
        v0 = v6.mBreadCrumbShortTitleText; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleText:java.lang.CharSequence
        if (v0 == 0) /* goto L_00d9 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "mBreadCrumbShortTitleRes=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mBreadCrumbShortTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleRes:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mBreadCrumbShortTitleText=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mBreadCrumbShortTitleText; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleText:java.lang.CharSequence
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.mHead; // android.support.v4.app.BackStackRecord.mHead:android.support.v4.app.BackStackRecord$Op
        if (v0 == 0) /* goto L_01bf */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Operations:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = "    ";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v0 = v6.mHead; // android.support.v4.app.BackStackRecord.mHead:android.support.v4.app.BackStackRecord$Op
        v2 = v0;
        if (v2 == 0) /* goto L_01bf */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  Op #";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        _result = v9.print(v1); // java.io.PrintWriter.print -> void
        v0 = ":";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        _result = v9.print(v3); // java.io.PrintWriter.print -> void
        v0 = "cmd=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v2.cmd; // android.support.v4.app.BackStackRecord$Op.cmd:int
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " fragment=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v2.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v2.enterAnim; // android.support.v4.app.BackStackRecord$Op.enterAnim:int
        if (v0 != 0) /* goto L_012c */;
        v0 = v2.exitAnim; // android.support.v4.app.BackStackRecord$Op.exitAnim:int
        if (v0 == 0) /* goto L_014b */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "enterAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v2.enterAnim; // android.support.v4.app.BackStackRecord$Op.enterAnim:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " exitAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v2.exitAnim; // android.support.v4.app.BackStackRecord$Op.exitAnim:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v2.popEnterAnim; // android.support.v4.app.BackStackRecord$Op.popEnterAnim:int
        if (v0 != 0) /* goto L_0153 */;
        v0 = v2.popExitAnim; // android.support.v4.app.BackStackRecord$Op.popExitAnim:int
        if (v0 == 0) /* goto L_0172 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "popEnterAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v2.popEnterAnim; // android.support.v4.app.BackStackRecord$Op.popEnterAnim:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " popExitAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v2.popExitAnim; // android.support.v4.app.BackStackRecord$Op.popExitAnim:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v2.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        if (v0 == 0) /* goto L_01ba */;
        v0 = v2.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_01ba */;
        v0 = v1;
        v4 = v2.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v4.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        if (v0 >= v4) /* goto L_01ba */;
        _result = v9.print(v3); // java.io.PrintWriter.print -> void
        v4 = v2.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v4.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        v5 = 1;
        if (v4 != v5) /* goto L_01a4 */;
        v4 = "Removed: ";
        _result = v9.print(v4); // java.io.PrintWriter.print -> void
        v4 = v2.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v4.get(v0); // java.util.ArrayList.get -> java.lang.Object
        v4 = _result;
        _result = v9.println(v4); // java.io.PrintWriter.println -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_017f
        v4 = "Removed:";
        _result = v9.println(v4); // java.io.PrintWriter.println -> void
        _result = v9.print(v3); // java.io.PrintWriter.print -> void
        v4 = "  #";
        _result = v9.print(v4); // java.io.PrintWriter.print -> void
        _result = v9.print(v1); // java.io.PrintWriter.print -> void
        v4 = ": ";
        _result = v9.print(v4); // java.io.PrintWriter.print -> void
        // goto L_0198
        v0 = v2.next; // android.support.v4.app.BackStackRecord$Op.next:android.support.v4.app.BackStackRecord$Op
        v2 = v0;
        // goto L_00fb
        return;
    }

    public java.lang.CharSequence getBreadCrumbShortTitle() {
        // Registers (3 total): v2 = this
        v0 = v2.mBreadCrumbShortTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleRes:int
        if (v0 == 0) /* goto L_000f */;
        v0 = v2.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v0 = v0.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = v2.mBreadCrumbShortTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleRes:int
        _result = v0.getText(v1); // android.support.v4.app.FragmentActivity.getText -> java.lang.CharSequence
        v0 = _result;
        return v0;
        v0 = v2.mBreadCrumbShortTitleText; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleText:java.lang.CharSequence
        // goto L_000e
    }

    public int getBreadCrumbShortTitleRes() {
        // Registers (2 total): v1 = this
        v0 = v1.mBreadCrumbShortTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleRes:int
        return v0;
    }

    public java.lang.CharSequence getBreadCrumbTitle() {
        // Registers (3 total): v2 = this
        v0 = v2.mBreadCrumbTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleRes:int
        if (v0 == 0) /* goto L_000f */;
        v0 = v2.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v0 = v0.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = v2.mBreadCrumbTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleRes:int
        _result = v0.getText(v1); // android.support.v4.app.FragmentActivity.getText -> java.lang.CharSequence
        v0 = _result;
        return v0;
        v0 = v2.mBreadCrumbTitleText; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleText:java.lang.CharSequence
        // goto L_000e
    }

    public int getBreadCrumbTitleRes() {
        // Registers (2 total): v1 = this
        v0 = v1.mBreadCrumbTitleRes; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleRes:int
        return v0;
    }

    public int getId() {
        // Registers (2 total): v1 = this
        v0 = v1.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        return v0;
    }

    public java.lang.String getName() {
        // Registers (2 total): v1 = this
        v0 = v1.mName; // android.support.v4.app.BackStackRecord.mName:java.lang.String
        return v0;
    }

    public int getTransition() {
        // Registers (2 total): v1 = this
        v0 = v1.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        return v0;
    }

    public int getTransitionStyle() {
        // Registers (2 total): v1 = this
        v0 = v1.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        return v0;
    }

    public android.support.v4.app.FragmentTransaction hide(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = new android.support.v4.app.BackStackRecord$Op;
        _result = v0.<init>(); // android.support.v4.app.BackStackRecord$Op.<init> -> void
        v1 = 4;
        v0.cmd = v1; // android.support.v4.app.BackStackRecord$Op.cmd:int
        v0.fragment = v3; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        _result = v2.addOp(v0); // android.support.v4.app.BackStackRecord.addOp -> void
        return v2;
    }

    public boolean isAddToBackStackAllowed() {
        // Registers (2 total): v1 = this
        v0 = v1.mAllowAddToBackStack; // android.support.v4.app.BackStackRecord.mAllowAddToBackStack:boolean
        return v0;
    }

    public boolean isEmpty() {
        // Registers (2 total): v1 = this
        v0 = v1.mNumOp; // android.support.v4.app.BackStackRecord.mNumOp:int
        if (v0 != 0) /* goto L_0006 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0005
    }

    public void popFromBackStack(boolean p0) {
        // Registers (9 total): v7 = this, v8 = p0 (boolean)
        v6 = -1;
        v2 = 0;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001e */;
        v0 = "BackStackEntry";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "popFromBackStack: ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        _result = v7.bumpBackStackNesting(v6); // android.support.v4.app.BackStackRecord.bumpBackStackNesting -> void
        v0 = v7.mTail; // android.support.v4.app.BackStackRecord.mTail:android.support.v4.app.BackStackRecord$Op
        v3 = v0;
        if (v3 == 0) /* goto L_00f2 */;
        v0 = v3.cmd; // android.support.v4.app.BackStackRecord$Op.cmd:int
        // switch(v0)
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Unknown cmd: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.cmd; // android.support.v4.app.BackStackRecord$Op.cmd:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v3.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v3.popExitAnim; // android.support.v4.app.BackStackRecord$Op.popExitAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v4 = v7.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        _result = v4.reverseTransit(); // android.support.v4.app.FragmentManagerImpl.reverseTransit -> int
        v4 = _result;
        v5 = v7.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v1.removeFragment(v0, v4, v5); // android.support.v4.app.FragmentManagerImpl.removeFragment -> void
        v0 = v3.prev; // android.support.v4.app.BackStackRecord$Op.prev:android.support.v4.app.BackStackRecord$Op
        v3 = v0;
        // goto L_0024
        v0 = v3.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0072 */;
        v1 = v3.popExitAnim; // android.support.v4.app.BackStackRecord$Op.popExitAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v4 = v7.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        _result = v4.reverseTransit(); // android.support.v4.app.FragmentManagerImpl.reverseTransit -> int
        v4 = _result;
        v5 = v7.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v1.removeFragment(v0, v4, v5); // android.support.v4.app.FragmentManagerImpl.removeFragment -> void
        v0 = v3.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        if (v0 == 0) /* goto L_0059 */;
        v1 = v2;
        v0 = v3.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0059 */;
        v0 = v3.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v4 = v3.popEnterAnim; // android.support.v4.app.BackStackRecord$Op.popEnterAnim:int
        v0.mNextAnim = v4; // android.support.v4.app.Fragment.mNextAnim:int
        v4 = v7.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        _result = v4.addFragment(v0, v2); // android.support.v4.app.FragmentManagerImpl.addFragment -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0077
        v0 = v3.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v3.popEnterAnim; // android.support.v4.app.BackStackRecord$Op.popEnterAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        _result = v1.addFragment(v0, v2); // android.support.v4.app.FragmentManagerImpl.addFragment -> void
        // goto L_0059
        v0 = v3.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v3.popEnterAnim; // android.support.v4.app.BackStackRecord$Op.popEnterAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v4 = v7.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        _result = v4.reverseTransit(); // android.support.v4.app.FragmentManagerImpl.reverseTransit -> int
        v4 = _result;
        v5 = v7.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v1.showFragment(v0, v4, v5); // android.support.v4.app.FragmentManagerImpl.showFragment -> void
        // goto L_0059
        v0 = v3.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v3.popExitAnim; // android.support.v4.app.BackStackRecord$Op.popExitAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v4 = v7.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        _result = v4.reverseTransit(); // android.support.v4.app.FragmentManagerImpl.reverseTransit -> int
        v4 = _result;
        v5 = v7.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v1.hideFragment(v0, v4, v5); // android.support.v4.app.FragmentManagerImpl.hideFragment -> void
        // goto L_0059
        v0 = v3.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v3.popEnterAnim; // android.support.v4.app.BackStackRecord$Op.popEnterAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v4 = v7.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        _result = v4.reverseTransit(); // android.support.v4.app.FragmentManagerImpl.reverseTransit -> int
        v4 = _result;
        v5 = v7.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v1.attachFragment(v0, v4, v5); // android.support.v4.app.FragmentManagerImpl.attachFragment -> void
        // goto L_0059
        v0 = v3.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v3.popEnterAnim; // android.support.v4.app.BackStackRecord$Op.popEnterAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v4 = v7.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        _result = v4.reverseTransit(); // android.support.v4.app.FragmentManagerImpl.reverseTransit -> int
        v4 = _result;
        v5 = v7.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v1.detachFragment(v0, v4, v5); // android.support.v4.app.FragmentManagerImpl.detachFragment -> void
        // goto L_0059
        if (v8 == 0) /* goto L_0106 */;
        v0 = v7.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v1 = v7.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v1 = v1.mCurState; // android.support.v4.app.FragmentManagerImpl.mCurState:int
        v2 = v7.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        _result = v2.reverseTransit(); // android.support.v4.app.FragmentManagerImpl.reverseTransit -> int
        v2 = _result;
        v3 = v7.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        v4 = 1;
        _result = v0.moveToState(v1, v2, v3, v4); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        v0 = v7.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        if (v0 < 0) /* goto L_0113 */;
        v0 = v7.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v1 = v7.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        _result = v0.freeBackStackIndex(v1); // android.support.v4.app.FragmentManagerImpl.freeBackStackIndex -> void
        v7.mIndex = v6; // android.support.v4.app.BackStackRecord.mIndex:int
        return;
    }

    public android.support.v4.app.FragmentTransaction remove(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = new android.support.v4.app.BackStackRecord$Op;
        _result = v0.<init>(); // android.support.v4.app.BackStackRecord$Op.<init> -> void
        v1 = 3;
        v0.cmd = v1; // android.support.v4.app.BackStackRecord$Op.cmd:int
        v0.fragment = v3; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        _result = v2.addOp(v0); // android.support.v4.app.BackStackRecord.addOp -> void
        return v2;
    }

    public android.support.v4.app.FragmentTransaction replace(int p0, android.support.v4.app.Fragment p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (android.support.v4.app.Fragment)
        v0 = 0;
        _result = v1.replace(v2, v3, v0); // android.support.v4.app.BackStackRecord.replace -> android.support.v4.app.FragmentTransaction
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.FragmentTransaction replace(int p0, android.support.v4.app.Fragment p1, java.lang.String p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (android.support.v4.app.Fragment), v5 = p2 (java.lang.String)
        if (v3 != 0) /* goto L_000a */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Must use non-zero containerViewId";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = 2;
        _result = v2.doAddOp(v3, v4, v5, v0); // android.support.v4.app.BackStackRecord.doAddOp -> void
        return v2;
    }

    public void run() {
        // Registers (10 total): v9 = this
        v8 = 1;
        v2 = 0;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001e */;
        v0 = "BackStackEntry";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Run: ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v9.mAddToBackStack; // android.support.v4.app.BackStackRecord.mAddToBackStack:boolean
        if (v0 == 0) /* goto L_002e */;
        v0 = v9.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        if (v0 >= 0) /* goto L_002e */;
        v0 = new java.lang.IllegalStateException;
        v1 = "addToBackStack() called after commit()";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        _result = v9.bumpBackStackNesting(v8); // android.support.v4.app.BackStackRecord.bumpBackStackNesting -> void
        v0 = v9.mHead; // android.support.v4.app.BackStackRecord.mHead:android.support.v4.app.BackStackRecord$Op
        v4 = v0;
        if (v4 == 0) /* goto L_016d */;
        v0 = v4.cmd; // android.support.v4.app.BackStackRecord$Op.cmd:int
        // switch(v0)
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Unknown cmd: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.cmd; // android.support.v4.app.BackStackRecord$Op.cmd:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v4.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v4.enterAnim; // android.support.v4.app.BackStackRecord$Op.enterAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        _result = v1.addFragment(v0, v2); // android.support.v4.app.FragmentManagerImpl.addFragment -> void
        v0 = v4.next; // android.support.v4.app.BackStackRecord$Op.next:android.support.v4.app.BackStackRecord$Op
        v4 = v0;
        // goto L_0034
        v0 = v4.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v1 = v1.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v1 == 0) /* goto L_010a */;
        v1 = v2;
        v3 = v0;
        v0 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v0 = v0.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_010b */;
        v0 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v0 = v0.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v5 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v5 == 0) /* goto L_00a9 */;
        v5 = "BackStackEntry";
        v6 = new java.lang.StringBuilder;
        _result = v6.<init>(); // java.lang.StringBuilder.<init> -> void
        v7 = "OP_REPLACE: adding=";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v7 = " old=";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v6 = _result;
        _result = v5.v(v6); // android.util.Log.v -> int
        if (v3 == 0) /* goto L_00b1 */;
        v5 = v0.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        v6 = v3.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        if (v5 != v6) /* goto L_00b6 */;
        if (v0 != v3) /* goto L_00ba */;
        v3 = 0;
        v4.fragment = v3; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_006f
        v5 = v4.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        if (v5 != 0) /* goto L_00c5 */;
        v5 = new java.util.ArrayList;
        _result = v5.<init>(); // java.util.ArrayList.<init> -> void
        v4.removed = v5; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        v5 = v4.removed; // android.support.v4.app.BackStackRecord$Op.removed:java.util.ArrayList
        _result = v5.add(v0); // java.util.ArrayList.add -> boolean
        v5 = v4.exitAnim; // android.support.v4.app.BackStackRecord$Op.exitAnim:int
        v0.mNextAnim = v5; // android.support.v4.app.Fragment.mNextAnim:int
        v5 = v9.mAddToBackStack; // android.support.v4.app.BackStackRecord.mAddToBackStack:boolean
        if (v5 == 0) /* goto L_0100 */;
        v5 = v0.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        v5 = binOpLit8_0xd8(v5, 1);
        v0.mBackStackNesting = v5; // android.support.v4.app.Fragment.mBackStackNesting:int
        v5 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v5 == 0) /* goto L_0100 */;
        v5 = "BackStackEntry";
        v6 = new java.lang.StringBuilder;
        _result = v6.<init>(); // java.lang.StringBuilder.<init> -> void
        v7 = "Bump nesting of ";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v7 = " to ";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v7 = v0.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v6 = _result;
        _result = v5.v(v6); // android.util.Log.v -> int
        v5 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v6 = v9.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        v7 = v9.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v5.removeFragment(v0, v6, v7); // android.support.v4.app.FragmentManagerImpl.removeFragment -> void
        // goto L_00b6
        v3 = v0;
        if (v3 == 0) /* goto L_0061 */;
        v0 = v4.enterAnim; // android.support.v4.app.BackStackRecord$Op.enterAnim:int
        v3.mNextAnim = v0; // android.support.v4.app.Fragment.mNextAnim:int
        v0 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        _result = v0.addFragment(v3, v2); // android.support.v4.app.FragmentManagerImpl.addFragment -> void
        // goto L_0061
        v0 = v4.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v4.exitAnim; // android.support.v4.app.BackStackRecord$Op.exitAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v3 = v9.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        v5 = v9.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v1.removeFragment(v0, v3, v5); // android.support.v4.app.FragmentManagerImpl.removeFragment -> void
        // goto L_0061
        v0 = v4.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v4.exitAnim; // android.support.v4.app.BackStackRecord$Op.exitAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v3 = v9.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        v5 = v9.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v1.hideFragment(v0, v3, v5); // android.support.v4.app.FragmentManagerImpl.hideFragment -> void
        // goto L_0061
        v0 = v4.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v4.enterAnim; // android.support.v4.app.BackStackRecord$Op.enterAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v3 = v9.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        v5 = v9.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v1.showFragment(v0, v3, v5); // android.support.v4.app.FragmentManagerImpl.showFragment -> void
        // goto L_0061
        v0 = v4.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v4.exitAnim; // android.support.v4.app.BackStackRecord$Op.exitAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v3 = v9.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        v5 = v9.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v1.detachFragment(v0, v3, v5); // android.support.v4.app.FragmentManagerImpl.detachFragment -> void
        // goto L_0061
        v0 = v4.fragment; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        v1 = v4.enterAnim; // android.support.v4.app.BackStackRecord$Op.enterAnim:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v3 = v9.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        v5 = v9.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v1.attachFragment(v0, v3, v5); // android.support.v4.app.FragmentManagerImpl.attachFragment -> void
        // goto L_0061
        v0 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v1 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        v1 = v1.mCurState; // android.support.v4.app.FragmentManagerImpl.mCurState:int
        v2 = v9.mTransition; // android.support.v4.app.BackStackRecord.mTransition:int
        v3 = v9.mTransitionStyle; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        _result = v0.moveToState(v1, v2, v3, v8); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        v0 = v9.mAddToBackStack; // android.support.v4.app.BackStackRecord.mAddToBackStack:boolean
        if (v0 == 0) /* goto L_0183 */;
        v0 = v9.mManager; // android.support.v4.app.BackStackRecord.mManager:android.support.v4.app.FragmentManagerImpl
        _result = v0.addBackStackState(v9); // android.support.v4.app.FragmentManagerImpl.addBackStackState -> void
        return;
    }

    public android.support.v4.app.FragmentTransaction setBreadCrumbShortTitle(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v1.mBreadCrumbShortTitleRes = v2; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleRes:int
        v0 = 0;
        v1.mBreadCrumbShortTitleText = v0; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleText:java.lang.CharSequence
        return v1;
    }

    public android.support.v4.app.FragmentTransaction setBreadCrumbShortTitle(java.lang.CharSequence p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.CharSequence)
        v0 = 0;
        v1.mBreadCrumbShortTitleRes = v0; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleRes:int
        v1.mBreadCrumbShortTitleText = v2; // android.support.v4.app.BackStackRecord.mBreadCrumbShortTitleText:java.lang.CharSequence
        return v1;
    }

    public android.support.v4.app.FragmentTransaction setBreadCrumbTitle(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v1.mBreadCrumbTitleRes = v2; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleRes:int
        v0 = 0;
        v1.mBreadCrumbTitleText = v0; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleText:java.lang.CharSequence
        return v1;
    }

    public android.support.v4.app.FragmentTransaction setBreadCrumbTitle(java.lang.CharSequence p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.CharSequence)
        v0 = 0;
        v1.mBreadCrumbTitleRes = v0; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleRes:int
        v1.mBreadCrumbTitleText = v2; // android.support.v4.app.BackStackRecord.mBreadCrumbTitleText:java.lang.CharSequence
        return v1;
    }

    public android.support.v4.app.FragmentTransaction setCustomAnimations(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = 0;
        _result = v1.setCustomAnimations(v2, v3, v0, v0); // android.support.v4.app.BackStackRecord.setCustomAnimations -> android.support.v4.app.FragmentTransaction
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.FragmentTransaction setCustomAnimations(int p0, int p1, int p2, int p3) {
        // Registers (5 total): v0 = this, v1 = p0 (int), v2 = p1 (int), v3 = p2 (int), v4 = p3 (int)
        v0.mEnterAnim = v1; // android.support.v4.app.BackStackRecord.mEnterAnim:int
        v0.mExitAnim = v2; // android.support.v4.app.BackStackRecord.mExitAnim:int
        v0.mPopEnterAnim = v3; // android.support.v4.app.BackStackRecord.mPopEnterAnim:int
        v0.mPopExitAnim = v4; // android.support.v4.app.BackStackRecord.mPopExitAnim:int
        return v0;
    }

    public android.support.v4.app.FragmentTransaction setTransition(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.mTransition = v1; // android.support.v4.app.BackStackRecord.mTransition:int
        return v0;
    }

    public android.support.v4.app.FragmentTransaction setTransitionStyle(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.mTransitionStyle = v1; // android.support.v4.app.BackStackRecord.mTransitionStyle:int
        return v0;
    }

    public android.support.v4.app.FragmentTransaction show(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = new android.support.v4.app.BackStackRecord$Op;
        _result = v0.<init>(); // android.support.v4.app.BackStackRecord$Op.<init> -> void
        v1 = 5;
        v0.cmd = v1; // android.support.v4.app.BackStackRecord$Op.cmd:int
        v0.fragment = v3; // android.support.v4.app.BackStackRecord$Op.fragment:android.support.v4.app.Fragment
        _result = v2.addOp(v0); // android.support.v4.app.BackStackRecord.addOp -> void
        return v2;
    }

}