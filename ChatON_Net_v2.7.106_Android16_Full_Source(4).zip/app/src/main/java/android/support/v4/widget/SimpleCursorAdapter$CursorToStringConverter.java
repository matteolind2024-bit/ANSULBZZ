package android.support.v4.widget;

/**
 * Original SourceFile: SimpleCursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/SimpleCursorAdapter$CursorToStringConverter;
 */
public interface SimpleCursorAdapter$CursorToStringConverter {
    public abstract java.lang.CharSequence convertToString(android.database.Cursor p0);
}