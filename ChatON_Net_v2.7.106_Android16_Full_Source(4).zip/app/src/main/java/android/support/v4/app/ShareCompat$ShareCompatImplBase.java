package android.support.v4.app;

/**
 * Original SourceFile: ShareCompat.java
 * Descriptor: Landroid/support/v4/app/ShareCompat$ShareCompatImplBase;
 */
class ShareCompat$ShareCompatImplBase implements android.support.v4.app.ShareCompat$ShareCompatImpl {
    ShareCompat$ShareCompatImplBase() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    private static void withinStyle(java.lang.StringBuilder p0, java.lang.CharSequence p1, int p2, int p3) {
        // Registers (9 total): v5 = p0 (java.lang.StringBuilder), v6 = p1 (java.lang.CharSequence), v7 = p2 (int), v8 = p3 (int)
        v4 = 32;
        v0 = v7;
        if (v0 >= v8) /* goto L_006a */;
        _result = java.lang.CharSequence.charAt(v6, v0); // -> char
        v1 = _result;
        v2 = 60;
        if (v1 != v2) /* goto L_0015 */;
        v1 = "&lt;";
        _result = v5.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0003
        v2 = 62;
        if (v1 != v2) /* goto L_001f */;
        v1 = "&gt;";
        _result = v5.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0012
        v2 = 38;
        if (v1 != v2) /* goto L_0029 */;
        v1 = "&amp;";
        _result = v5.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0012
        v2 = 126;
        if (v1 > v2) /* goto L_002f */;
        if (v1 >= v4) /* goto L_004c */;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "&#";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ";";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v5.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0012
        if (v1 != v4) /* goto L_0066 */;
        v1 = binOpLit8_0xd8(v0, 1);
        if (v1 >= v8) /* goto L_0062 */;
        v1 = binOpLit8_0xd8(v0, 1);
        _result = java.lang.CharSequence.charAt(v6, v1); // -> char
        v1 = _result;
        if (v1 != v4) /* goto L_0062 */;
        v1 = "&nbsp;";
        _result = v5.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_004e
        _result = v5.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0012
        _result = v5.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0012
        return;
    }

    public void configureMenuItem(android.view.MenuItem p0, android.support.v4.app.ShareCompat$IntentBuilder p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MenuItem), v3 = p1 (android.support.v4.app.ShareCompat$IntentBuilder)
        _result = v3.createChooserIntent(); // android.support.v4.app.ShareCompat$IntentBuilder.createChooserIntent -> android.content.Intent
        v0 = _result;
        _result = android.view.MenuItem.setIntent(v2, v0); // -> android.view.MenuItem
        return;
    }

    public java.lang.String escapeHtml(java.lang.CharSequence p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.CharSequence)
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = 0;
        _result = java.lang.CharSequence.length(v4); // -> int
        v2 = _result;
        _result = v0.withinStyle(v4, v1, v2); // android.support.v4.app.ShareCompat$ShareCompatImplBase.withinStyle -> void
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}