package android.support.v4.app;

/**
 * Original SourceFile: FragmentActivity.java
 * Descriptor: Landroid/support/v4/app/FragmentActivity$FragmentTag;
 */
class FragmentActivity$FragmentTag {
    public static final int[] Fragment;
    public static final int Fragment_id;
    public static final int Fragment_name;
    public static final int Fragment_tag;

    static {
        v0 = 3;
        v0 = new int[][size=v0];
        android.support.v4.app.FragmentActivity$FragmentTag.Fragment = v0; // :int[]
        return;
    }

    FragmentActivity$FragmentTag() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}