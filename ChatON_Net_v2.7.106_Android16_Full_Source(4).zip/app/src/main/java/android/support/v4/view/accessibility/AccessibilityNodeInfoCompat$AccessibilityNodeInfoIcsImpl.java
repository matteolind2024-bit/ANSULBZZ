package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityNodeInfoCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat$AccessibilityNodeInfoIcsImpl;
 */
class AccessibilityNodeInfoCompat$AccessibilityNodeInfoIcsImpl extends android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoStubImpl {
    AccessibilityNodeInfoCompat$AccessibilityNodeInfoIcsImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoStubImpl.<init> -> void
        return;
    }

    public void addAction(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.addAction(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.addAction -> void
        return;
    }

    public void addChild(java.lang.Object p0, android.view.View p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View)
        _result = v1.addChild(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.addChild -> void
        return;
    }

    public java.util.List findAccessibilityNodeInfosByText(java.lang.Object p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (java.lang.String)
        _result = v2.findAccessibilityNodeInfosByText(v3); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.findAccessibilityNodeInfosByText -> java.util.List
        v0 = _result;
        return v0;
    }

    public int getActions(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getActions(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.getActions -> int
        v0 = _result;
        return v0;
    }

    public void getBoundsInParent(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.graphics.Rect)
        _result = v1.getBoundsInParent(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.getBoundsInParent -> void
        return;
    }

    public void getBoundsInScreen(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.graphics.Rect)
        _result = v1.getBoundsInScreen(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.getBoundsInScreen -> void
        return;
    }

    public java.lang.Object getChild(java.lang.Object p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (int)
        _result = v2.getChild(v3); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.getChild -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public int getChildCount(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getChildCount(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.getChildCount -> int
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getClassName(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getClassName(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.getClassName -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getContentDescription(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getContentDescription(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.getContentDescription -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getPackageName(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getPackageName(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.getPackageName -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.Object getParent(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getParent(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.getParent -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getText(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getText(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.getText -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public int getWindowId(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getWindowId(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.getWindowId -> int
        v0 = _result;
        return v0;
    }

    public boolean isCheckable(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isCheckable(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.isCheckable -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isChecked(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isChecked(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.isChecked -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isClickable(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isClickable(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.isClickable -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isEnabled(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isEnabled(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.isEnabled -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isFocusable(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isFocusable(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.isFocusable -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isFocused(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isFocused(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.isFocused -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isLongClickable(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isLongClickable(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.isLongClickable -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isPassword(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isPassword(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.isPassword -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isScrollable(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isScrollable(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.isScrollable -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isSelected(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isSelected(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.isSelected -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.Object obtain() {
        // Registers (2 total): v1 = this
        _result = this.obtain(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.obtain -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object obtain(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.obtain(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.obtain -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object obtain(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.obtain(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.obtain -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public boolean performAction(java.lang.Object p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (int)
        _result = v2.performAction(v3); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.performAction -> boolean
        v0 = _result;
        return v0;
    }

    public void recycle(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v1.recycle(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.recycle -> void
        return;
    }

    public void setBoundsInParent(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.graphics.Rect)
        _result = v1.setBoundsInParent(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setBoundsInParent -> void
        return;
    }

    public void setBoundsInScreen(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.graphics.Rect)
        _result = v1.setBoundsInScreen(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setBoundsInScreen -> void
        return;
    }

    public void setCheckable(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setCheckable(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setCheckable -> void
        return;
    }

    public void setChecked(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setChecked(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setChecked -> void
        return;
    }

    public void setClassName(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        _result = v1.setClassName(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setClassName -> void
        return;
    }

    public void setClickable(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setClickable(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setClickable -> void
        return;
    }

    public void setContentDescription(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        _result = v1.setContentDescription(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setContentDescription -> void
        return;
    }

    public void setEnabled(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setEnabled(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setEnabled -> void
        return;
    }

    public void setFocusable(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setFocusable(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setFocusable -> void
        return;
    }

    public void setFocused(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setFocused(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setFocused -> void
        return;
    }

    public void setLongClickable(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setLongClickable(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setLongClickable -> void
        return;
    }

    public void setPackageName(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        _result = v1.setPackageName(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setPackageName -> void
        return;
    }

    public void setParent(java.lang.Object p0, android.view.View p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View)
        _result = v1.setParent(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setParent -> void
        return;
    }

    public void setPassword(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setPassword(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setPassword -> void
        return;
    }

    public void setScrollable(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setScrollable(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setScrollable -> void
        return;
    }

    public void setSelected(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setSelected(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setSelected -> void
        return;
    }

    public void setSource(java.lang.Object p0, android.view.View p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View)
        _result = v1.setSource(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setSource -> void
        return;
    }

    public void setText(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        _result = v1.setText(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatIcs.setText -> void
        return;
    }

}