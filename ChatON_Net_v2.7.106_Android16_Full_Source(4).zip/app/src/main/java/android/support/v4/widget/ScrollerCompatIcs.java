package android.support.v4.widget;

/**
 * Original SourceFile: ScrollerCompatIcs.java
 * Descriptor: Landroid/support/v4/widget/ScrollerCompatIcs;
 */
class ScrollerCompatIcs {
    ScrollerCompatIcs() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static float getCurrVelocity(android.widget.Scroller p0) {
        // Registers (2 total): v1 = p0 (android.widget.Scroller)
        _result = v1.getCurrVelocity(); // android.widget.Scroller.getCurrVelocity -> float
        v0 = _result;
        return v0;
    }

}