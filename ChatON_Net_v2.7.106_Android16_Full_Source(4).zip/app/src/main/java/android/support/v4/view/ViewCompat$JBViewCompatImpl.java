package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/ViewCompat$JBViewCompatImpl;
 */
class ViewCompat$JBViewCompatImpl extends android.support.v4.view.ViewCompat$ICSViewCompatImpl {
    ViewCompat$JBViewCompatImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.ViewCompat$ICSViewCompatImpl.<init> -> void
        return;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeProviderCompat getAccessibilityNodeProvider(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        _result = v3.getAccessibilityNodeProvider(); // android.support.v4.view.ViewCompatJB.getAccessibilityNodeProvider -> java.lang.Object
        v1 = _result;
        if (v1 == 0) /* goto L_000c */;
        v0 = new android.support.v4.view.accessibility.AccessibilityNodeProviderCompat;
        _result = v0.<init>(v1); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.<init> -> void
        return v0;
        v0 = 0;
        // goto L_000b
    }

    public int getImportantForAccessibility(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.getImportantForAccessibility(); // android.support.v4.view.ViewCompatJB.getImportantForAccessibility -> int
        v0 = _result;
        return v0;
    }

    public boolean hasTransientState(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.hasTransientState(); // android.support.v4.view.ViewCompatJB.hasTransientState -> boolean
        v0 = _result;
        return v0;
    }

    public void postInvalidateOnAnimation(android.view.View p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.View)
        _result = v1.postInvalidateOnAnimation(); // android.support.v4.view.ViewCompatJB.postInvalidateOnAnimation -> void
        return;
    }

    public void postInvalidateOnAnimation(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (6 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int), v3 = p2 (int), v4 = p3 (int), v5 = p4 (int)
        _result = v1.postInvalidateOnAnimation(v2, v3, v4, v5); // android.support.v4.view.ViewCompatJB.postInvalidateOnAnimation -> void
        return;
    }

    public void postOnAnimation(android.view.View p0, java.lang.Runnable p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (java.lang.Runnable)
        _result = v1.postOnAnimation(v2); // android.support.v4.view.ViewCompatJB.postOnAnimation -> void
        return;
    }

    public void postOnAnimationDelayed(android.view.View p0, java.lang.Runnable p1, long p2) {
        // Registers (5 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (java.lang.Runnable), v3 = p2 (long)
        _result = v1.postOnAnimationDelayed(v2, v3, v4); // android.support.v4.view.ViewCompatJB.postOnAnimationDelayed -> void
        return;
    }

    public void setHasTransientState(android.view.View p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (boolean)
        _result = v1.setHasTransientState(v2); // android.support.v4.view.ViewCompatJB.setHasTransientState -> void
        return;
    }

    public void setImportantForAccessibility(android.view.View p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int)
        _result = v1.setImportantForAccessibility(v2); // android.support.v4.view.ViewCompatJB.setImportantForAccessibility -> void
        return;
    }

}