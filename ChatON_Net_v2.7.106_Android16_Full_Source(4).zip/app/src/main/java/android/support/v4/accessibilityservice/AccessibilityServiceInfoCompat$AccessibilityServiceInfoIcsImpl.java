package android.support.v4.accessibilityservice;

/**
 * Original SourceFile: AccessibilityServiceInfoCompat.java
 * Descriptor: Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoIcsImpl;
 */
class AccessibilityServiceInfoCompat$AccessibilityServiceInfoIcsImpl extends android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl {
    AccessibilityServiceInfoCompat$AccessibilityServiceInfoIcsImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.accessibilityservice.AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl.<init> -> void
        return;
    }

    public boolean getCanRetrieveWindowContent(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        _result = v2.getCanRetrieveWindowContent(); // android.support.v4.accessibilityservice.AccessibilityServiceInfoCompatIcs.getCanRetrieveWindowContent -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.String getDescription(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        _result = v2.getDescription(); // android.support.v4.accessibilityservice.AccessibilityServiceInfoCompatIcs.getDescription -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String getId(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        _result = v2.getId(); // android.support.v4.accessibilityservice.AccessibilityServiceInfoCompatIcs.getId -> java.lang.String
        v0 = _result;
        return v0;
    }

    public android.content.pm.ResolveInfo getResolveInfo(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        _result = v2.getResolveInfo(); // android.support.v4.accessibilityservice.AccessibilityServiceInfoCompatIcs.getResolveInfo -> android.content.pm.ResolveInfo
        v0 = _result;
        return v0;
    }

    public java.lang.String getSettingsActivityName(android.accessibilityservice.AccessibilityServiceInfo p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.accessibilityservice.AccessibilityServiceInfo)
        _result = v2.getSettingsActivityName(); // android.support.v4.accessibilityservice.AccessibilityServiceInfoCompatIcs.getSettingsActivityName -> java.lang.String
        v0 = _result;
        return v0;
    }

}