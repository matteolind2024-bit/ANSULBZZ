package android.support.v4.view;

/**
 * Original SourceFile: PagerAdapter.java
 * Descriptor: Landroid/support/v4/view/PagerAdapter;
 */
public abstract class PagerAdapter {
    public static final int POSITION_NONE;
    public static final int POSITION_UNCHANGED;
    private android.database.DataSetObservable mObservable;

    public PagerAdapter() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new android.database.DataSetObservable;
        _result = v0.<init>(); // android.database.DataSetObservable.<init> -> void
        v1.mObservable = v0; // android.support.v4.view.PagerAdapter.mObservable:android.database.DataSetObservable
        return;
    }

    public void destroyItem(android.view.View p0, int p1, java.lang.Object p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int), v5 = p2 (java.lang.Object)
        v0 = new java.lang.UnsupportedOperationException;
        v1 = "Required method destroyItem was not overridden";
        _result = v0.<init>(v1); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public void destroyItem(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.view.ViewGroup), v2 = p1 (int), v3 = p2 (java.lang.Object)
        _result = v0.destroyItem(v1, v2, v3); // android.support.v4.view.PagerAdapter.destroyItem -> void
        return;
    }

    public void finishUpdate(android.view.View p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.View)
        return;
    }

    public void finishUpdate(android.view.ViewGroup p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.ViewGroup)
        _result = v0.finishUpdate(v1); // android.support.v4.view.PagerAdapter.finishUpdate -> void
        return;
    }

    public abstract int getCount();
    public int getItemPosition(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = -1;
        return v0;
    }

    public java.lang.CharSequence getPageTitle(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public float getPageWidth(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0x3f800000;
        return v0;
    }

    public java.lang.Object instantiateItem(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = new java.lang.UnsupportedOperationException;
        v1 = "Required method instantiateItem was not overridden";
        _result = v0.<init>(v1); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public java.lang.Object instantiateItem(android.view.ViewGroup p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (int)
        _result = v1.instantiateItem(v2, v3); // android.support.v4.view.PagerAdapter.instantiateItem -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public abstract boolean isViewFromObject(android.view.View p0, java.lang.Object p1);
    public void notifyDataSetChanged() {
        // Registers (2 total): v1 = this
        v0 = v1.mObservable; // android.support.v4.view.PagerAdapter.mObservable:android.database.DataSetObservable
        _result = v0.notifyChanged(); // android.database.DataSetObservable.notifyChanged -> void
        return;
    }

    void registerDataSetObserver(android.database.DataSetObserver p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.database.DataSetObserver)
        v0 = v1.mObservable; // android.support.v4.view.PagerAdapter.mObservable:android.database.DataSetObservable
        _result = v0.registerObserver(v2); // android.database.DataSetObservable.registerObserver -> void
        return;
    }

    public void restoreState(android.os.Parcelable p0, java.lang.ClassLoader p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.os.Parcelable), v2 = p1 (java.lang.ClassLoader)
        return;
    }

    public android.os.Parcelable saveState() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public void setPrimaryItem(android.view.View p0, int p1, java.lang.Object p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int), v3 = p2 (java.lang.Object)
        return;
    }

    public void setPrimaryItem(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.view.ViewGroup), v2 = p1 (int), v3 = p2 (java.lang.Object)
        _result = v0.setPrimaryItem(v1, v2, v3); // android.support.v4.view.PagerAdapter.setPrimaryItem -> void
        return;
    }

    public void startUpdate(android.view.View p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.View)
        return;
    }

    public void startUpdate(android.view.ViewGroup p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.ViewGroup)
        _result = v0.startUpdate(v1); // android.support.v4.view.PagerAdapter.startUpdate -> void
        return;
    }

    void unregisterDataSetObserver(android.database.DataSetObserver p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.database.DataSetObserver)
        v0 = v1.mObservable; // android.support.v4.view.PagerAdapter.mObservable:android.database.DataSetObservable
        _result = v0.unregisterObserver(v2); // android.database.DataSetObservable.unregisterObserver -> void
        return;
    }

}