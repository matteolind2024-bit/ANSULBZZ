package android.support.v4.view;

/**
 * Original SourceFile: PagerTitleStrip.java
 * Descriptor: Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImpl;
 */
interface PagerTitleStrip$PagerTitleStripImpl {
    public abstract void setSingleLineAllCaps(android.widget.TextView p0);
}