package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/ViewCompat$GBViewCompatImpl;
 */
class ViewCompat$GBViewCompatImpl extends android.support.v4.view.ViewCompat$BaseViewCompatImpl {
    ViewCompat$GBViewCompatImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.ViewCompat$BaseViewCompatImpl.<init> -> void
        return;
    }

    public int getOverScrollMode(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.getOverScrollMode(); // android.support.v4.view.ViewCompatGingerbread.getOverScrollMode -> int
        v0 = _result;
        return v0;
    }

    public void setOverScrollMode(android.view.View p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int)
        _result = v1.setOverScrollMode(v2); // android.support.v4.view.ViewCompatGingerbread.setOverScrollMode -> void
        return;
    }

}