package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityManagerCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerIcsImpl;
 */
class AccessibilityManagerCompat$AccessibilityManagerIcsImpl extends android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerStubImpl {
    AccessibilityManagerCompat$AccessibilityManagerIcsImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerStubImpl.<init> -> void
        return;
    }

    public boolean addAccessibilityStateChangeListener(android.view.accessibility.AccessibilityManager p0, android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityManager), v3 = p1 (android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat)
        v0 = v3.mListener; // android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat.mListener:java.lang.Object
        _result = v2.addAccessibilityStateChangeListener(v0); // android.support.v4.view.accessibility.AccessibilityManagerCompatIcs.addAccessibilityStateChangeListener -> boolean
        v0 = _result;
        return v0;
    }

    public java.util.List getEnabledAccessibilityServiceList(android.view.accessibility.AccessibilityManager p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityManager), v3 = p1 (int)
        _result = v2.getEnabledAccessibilityServiceList(v3); // android.support.v4.view.accessibility.AccessibilityManagerCompatIcs.getEnabledAccessibilityServiceList -> java.util.List
        v0 = _result;
        return v0;
    }

    public java.util.List getInstalledAccessibilityServiceList(android.view.accessibility.AccessibilityManager p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityManager)
        _result = v2.getInstalledAccessibilityServiceList(); // android.support.v4.view.accessibility.AccessibilityManagerCompatIcs.getInstalledAccessibilityServiceList -> java.util.List
        v0 = _result;
        return v0;
    }

    public boolean isTouchExplorationEnabled(android.view.accessibility.AccessibilityManager p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityManager)
        _result = v2.isTouchExplorationEnabled(); // android.support.v4.view.accessibility.AccessibilityManagerCompatIcs.isTouchExplorationEnabled -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.Object newAccessiblityStateChangeListener(android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat)
        v0 = new android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1;
        _result = v0.<init>(v1, v2); // android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1.<init> -> void
        _result = v0.newAccessibilityStateChangeListener(); // android.support.v4.view.accessibility.AccessibilityManagerCompatIcs.newAccessibilityStateChangeListener -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public boolean removeAccessibilityStateChangeListener(android.view.accessibility.AccessibilityManager p0, android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityManager), v3 = p1 (android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat)
        v0 = v3.mListener; // android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat.mListener:java.lang.Object
        _result = v2.removeAccessibilityStateChangeListener(v0); // android.support.v4.view.accessibility.AccessibilityManagerCompatIcs.removeAccessibilityStateChangeListener -> boolean
        v0 = _result;
        return v0;
    }

}