package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityManagerCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityManagerCompat;
 */
public class AccessibilityManagerCompat {
    private static final android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerIcsImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerIcsImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityManagerCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl
        return;
        v0 = new android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerStubImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerStubImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityManagerCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl
        // goto L_000d
    }

    public AccessibilityManagerCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    static android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl access$000() {
        v0 = android.support.v4.view.accessibility.AccessibilityManagerCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl
        return v0;
    }

    public static boolean addAccessibilityStateChangeListener(android.view.accessibility.AccessibilityManager p0, android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p1) {
        // Registers (3 total): v1 = p0 (android.view.accessibility.AccessibilityManager), v2 = p1 (android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat)
        v0 = android.support.v4.view.accessibility.AccessibilityManagerCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl
        _result = android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl.addAccessibilityStateChangeListener(v0, v1, v2); // -> boolean
        v0 = _result;
        return v0;
    }

    public static java.util.List getEnabledAccessibilityServiceList(android.view.accessibility.AccessibilityManager p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.accessibility.AccessibilityManager), v2 = p1 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityManagerCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl
        _result = android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl.getEnabledAccessibilityServiceList(v0, v1, v2); // -> java.util.List
        v0 = _result;
        return v0;
    }

    public static java.util.List getInstalledAccessibilityServiceList(android.view.accessibility.AccessibilityManager p0) {
        // Registers (2 total): v1 = p0 (android.view.accessibility.AccessibilityManager)
        v0 = android.support.v4.view.accessibility.AccessibilityManagerCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl
        _result = android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl.getInstalledAccessibilityServiceList(v0, v1); // -> java.util.List
        v0 = _result;
        return v0;
    }

    public static boolean isTouchExplorationEnabled(android.view.accessibility.AccessibilityManager p0) {
        // Registers (2 total): v1 = p0 (android.view.accessibility.AccessibilityManager)
        v0 = android.support.v4.view.accessibility.AccessibilityManagerCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl
        _result = android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl.isTouchExplorationEnabled(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean removeAccessibilityStateChangeListener(android.view.accessibility.AccessibilityManager p0, android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p1) {
        // Registers (3 total): v1 = p0 (android.view.accessibility.AccessibilityManager), v2 = p1 (android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat)
        v0 = android.support.v4.view.accessibility.AccessibilityManagerCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl
        _result = android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl.removeAccessibilityStateChangeListener(v0, v1, v2); // -> boolean
        v0 = _result;
        return v0;
    }

}