package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompat.java
 * Descriptor: Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateIcsImpl;
 */
class AccessibilityDelegateCompat$AccessibilityDelegateIcsImpl extends android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateStubImpl {
    AccessibilityDelegateCompat$AccessibilityDelegateIcsImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateStubImpl.<init> -> void
        return;
    }

    public boolean dispatchPopulateAccessibilityEvent(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.view.View), v4 = p2 (android.view.accessibility.AccessibilityEvent)
        _result = v2.dispatchPopulateAccessibilityEvent(v3, v4); // android.support.v4.view.AccessibilityDelegateCompatIcs.dispatchPopulateAccessibilityEvent -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.Object newAccessiblityDelegateBridge(android.support.v4.view.AccessibilityDelegateCompat p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.AccessibilityDelegateCompat)
        v0 = new android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateIcsImpl$1;
        _result = v0.<init>(v1, v2); // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateIcsImpl$1.<init> -> void
        _result = v0.newAccessibilityDelegateBridge(); // android.support.v4.view.AccessibilityDelegateCompatIcs.newAccessibilityDelegateBridge -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object newAccessiblityDelegateDefaultImpl() {
        // Registers (2 total): v1 = this
        _result = this.newAccessibilityDelegateDefaultImpl(); // android.support.v4.view.AccessibilityDelegateCompatIcs.newAccessibilityDelegateDefaultImpl -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void onInitializeAccessibilityEvent(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        _result = v1.onInitializeAccessibilityEvent(v2, v3); // android.support.v4.view.AccessibilityDelegateCompatIcs.onInitializeAccessibilityEvent -> void
        return;
    }

    public void onInitializeAccessibilityNodeInfo(java.lang.Object p0, android.view.View p1, android.support.v4.view.accessibility.AccessibilityNodeInfoCompat p2) {
        // Registers (5 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.view.View), v4 = p2 (android.support.v4.view.accessibility.AccessibilityNodeInfoCompat)
        _result = v4.getInfo(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.getInfo -> java.lang.Object
        v0 = _result;
        _result = v2.onInitializeAccessibilityNodeInfo(v3, v0); // android.support.v4.view.AccessibilityDelegateCompatIcs.onInitializeAccessibilityNodeInfo -> void
        return;
    }

    public void onPopulateAccessibilityEvent(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        _result = v1.onPopulateAccessibilityEvent(v2, v3); // android.support.v4.view.AccessibilityDelegateCompatIcs.onPopulateAccessibilityEvent -> void
        return;
    }

    public boolean onRequestSendAccessibilityEvent(java.lang.Object p0, android.view.ViewGroup p1, android.view.View p2, android.view.accessibility.AccessibilityEvent p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.view.ViewGroup), v4 = p2 (android.view.View), v5 = p3 (android.view.accessibility.AccessibilityEvent)
        _result = v2.onRequestSendAccessibilityEvent(v3, v4, v5); // android.support.v4.view.AccessibilityDelegateCompatIcs.onRequestSendAccessibilityEvent -> boolean
        v0 = _result;
        return v0;
    }

    public void sendAccessibilityEvent(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (int)
        _result = v1.sendAccessibilityEvent(v2, v3); // android.support.v4.view.AccessibilityDelegateCompatIcs.sendAccessibilityEvent -> void
        return;
    }

    public void sendAccessibilityEventUnchecked(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        _result = v1.sendAccessibilityEventUnchecked(v2, v3); // android.support.v4.view.AccessibilityDelegateCompatIcs.sendAccessibilityEventUnchecked -> void
        return;
    }

}