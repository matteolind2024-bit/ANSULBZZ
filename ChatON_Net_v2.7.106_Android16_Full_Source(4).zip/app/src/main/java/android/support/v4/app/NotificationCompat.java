package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/NotificationCompat;
 */
public class NotificationCompat {
    public static final int FLAG_HIGH_PRIORITY;
    private static final android.support.v4.app.NotificationCompat$NotificationCompatImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.app.NotificationCompat$NotificationCompatImplHoneycomb;
        _result = v0.<init>(); // android.support.v4.app.NotificationCompat$NotificationCompatImplHoneycomb.<init> -> void
        android.support.v4.app.NotificationCompat.IMPL = v0; // :android.support.v4.app.NotificationCompat$NotificationCompatImpl
        return;
        v0 = new android.support.v4.app.NotificationCompat$NotificationCompatImplBase;
        _result = v0.<init>(); // android.support.v4.app.NotificationCompat$NotificationCompatImplBase.<init> -> void
        android.support.v4.app.NotificationCompat.IMPL = v0; // :android.support.v4.app.NotificationCompat$NotificationCompatImpl
        // goto L_000d
    }

    public NotificationCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    static android.support.v4.app.NotificationCompat$NotificationCompatImpl access$000() {
        v0 = android.support.v4.app.NotificationCompat.IMPL; // :android.support.v4.app.NotificationCompat$NotificationCompatImpl
        return v0;
    }

}