package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/ViewCompat$ICSViewCompatImpl;
 */
class ViewCompat$ICSViewCompatImpl extends android.support.v4.view.ViewCompat$HCViewCompatImpl {
    ViewCompat$ICSViewCompatImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.ViewCompat$HCViewCompatImpl.<init> -> void
        return;
    }

    public boolean canScrollHorizontally(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        _result = v2.canScrollHorizontally(v3); // android.support.v4.view.ViewCompatICS.canScrollHorizontally -> boolean
        v0 = _result;
        return v0;
    }

    public boolean canScrollVertically(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        _result = v2.canScrollVertically(v3); // android.support.v4.view.ViewCompatICS.canScrollVertically -> boolean
        v0 = _result;
        return v0;
    }

    public void onInitializeAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.view.accessibility.AccessibilityEvent)
        _result = v1.onInitializeAccessibilityEvent(v2); // android.support.v4.view.ViewCompatICS.onInitializeAccessibilityEvent -> void
        return;
    }

    public void onInitializeAccessibilityNodeInfo(android.view.View p0, android.support.v4.view.accessibility.AccessibilityNodeInfoCompat p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.support.v4.view.accessibility.AccessibilityNodeInfoCompat)
        _result = v3.getInfo(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.getInfo -> java.lang.Object
        v0 = _result;
        _result = v2.onInitializeAccessibilityNodeInfo(v0); // android.support.v4.view.ViewCompatICS.onInitializeAccessibilityNodeInfo -> void
        return;
    }

    public void onPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.view.accessibility.AccessibilityEvent)
        _result = v1.onPopulateAccessibilityEvent(v2); // android.support.v4.view.ViewCompatICS.onPopulateAccessibilityEvent -> void
        return;
    }

    public void setAccessibilityDelegate(android.view.View p0, android.support.v4.view.AccessibilityDelegateCompat p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.support.v4.view.AccessibilityDelegateCompat)
        _result = v3.getBridge(); // android.support.v4.view.AccessibilityDelegateCompat.getBridge -> java.lang.Object
        v0 = _result;
        _result = v2.setAccessibilityDelegate(v0); // android.support.v4.view.ViewCompatICS.setAccessibilityDelegate -> void
        return;
    }

}