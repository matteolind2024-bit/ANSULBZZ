package android.support.v4.view;

/**
 * Original SourceFile: ViewCompatHC.java
 * Descriptor: Landroid/support/v4/view/ViewCompatHC;
 */
class ViewCompatHC {
    ViewCompatHC() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    static long getFrameTime() {
        _result = this.getFrameDelay(); // android.animation.ValueAnimator.getFrameDelay -> long
        v0 = _result;
        return v0;
    }

}