package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/ModernAsyncTask$WorkerRunnable;
 */
abstract class ModernAsyncTask$WorkerRunnable implements java.util.concurrent.Callable {
     java.lang.Object[] mParams;

    private ModernAsyncTask$WorkerRunnable() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    ModernAsyncTask$WorkerRunnable(android.support.v4.content.ModernAsyncTask$1 p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.content.ModernAsyncTask$1)
        _result = v0.<init>(); // android.support.v4.content.ModernAsyncTask$WorkerRunnable.<init> -> void
        return;
    }

}