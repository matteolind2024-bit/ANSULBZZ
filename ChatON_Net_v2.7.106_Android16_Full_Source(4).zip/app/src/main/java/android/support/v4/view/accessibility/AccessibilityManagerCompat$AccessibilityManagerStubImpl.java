package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityManagerCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerStubImpl;
 */
class AccessibilityManagerCompat$AccessibilityManagerStubImpl implements android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityManagerVersionImpl {
    AccessibilityManagerCompat$AccessibilityManagerStubImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean addAccessibilityStateChangeListener(android.view.accessibility.AccessibilityManager p0, android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityManager), v3 = p1 (android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat)
        v0 = 0;
        return v0;
    }

    public java.util.List getEnabledAccessibilityServiceList(android.view.accessibility.AccessibilityManager p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityManager), v3 = p1 (int)
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        return v0;
    }

    public java.util.List getInstalledAccessibilityServiceList(android.view.accessibility.AccessibilityManager p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityManager)
        _result = this.emptyList(); // java.util.Collections.emptyList -> java.util.List
        v0 = _result;
        return v0;
    }

    public boolean isTouchExplorationEnabled(android.view.accessibility.AccessibilityManager p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityManager)
        v0 = 0;
        return v0;
    }

    public java.lang.Object newAccessiblityStateChangeListener(android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat)
        v0 = 0;
        return v0;
    }

    public boolean removeAccessibilityStateChangeListener(android.view.accessibility.AccessibilityManager p0, android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.accessibility.AccessibilityManager), v3 = p1 (android.support.v4.view.accessibility.AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat)
        v0 = 0;
        return v0;
    }

}