package android.support.v4.widget;

/**
 * Original SourceFile: SearchViewCompatHoneycomb.java
 * Descriptor: Landroid/support/v4/widget/SearchViewCompatHoneycomb$1;
 */
final class SearchViewCompatHoneycomb$1 implements android.widget.SearchView$OnQueryTextListener {
    final android.support.v4.widget.SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge val$listener;

    SearchViewCompatHoneycomb$1(android.support.v4.widget.SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge)
        v0.val$listener = v1; // android.support.v4.widget.SearchViewCompatHoneycomb$1.val$listener:android.support.v4.widget.SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean onQueryTextChange(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.val$listener; // android.support.v4.widget.SearchViewCompatHoneycomb$1.val$listener:android.support.v4.widget.SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge
        _result = android.support.v4.widget.SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge.onQueryTextChange(v0, v2); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean onQueryTextSubmit(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.val$listener; // android.support.v4.widget.SearchViewCompatHoneycomb$1.val$listener:android.support.v4.widget.SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge
        _result = android.support.v4.widget.SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge.onQueryTextSubmit(v0, v2); // -> boolean
        v0 = _result;
        return v0;
    }

}