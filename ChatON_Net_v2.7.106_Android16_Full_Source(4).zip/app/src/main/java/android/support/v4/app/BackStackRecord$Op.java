package android.support.v4.app;

/**
 * Original SourceFile: BackStackRecord.java
 * Descriptor: Landroid/support/v4/app/BackStackRecord$Op;
 */
final class BackStackRecord$Op {
     int cmd;
     int enterAnim;
     int exitAnim;
     android.support.v4.app.Fragment fragment;
     android.support.v4.app.BackStackRecord$Op next;
     int popEnterAnim;
     int popExitAnim;
     android.support.v4.app.BackStackRecord$Op prev;
     java.util.ArrayList removed;

    BackStackRecord$Op() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}