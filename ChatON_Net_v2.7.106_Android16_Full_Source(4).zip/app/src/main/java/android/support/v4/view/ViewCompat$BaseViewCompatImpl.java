package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/ViewCompat$BaseViewCompatImpl;
 */
class ViewCompat$BaseViewCompatImpl implements android.support.v4.view.ViewCompat$ViewCompatImpl {
    ViewCompat$BaseViewCompatImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean canScrollHorizontally(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

    public boolean canScrollVertically(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeProviderCompat getAccessibilityNodeProvider(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 0;
        return v0;
    }

    long getFrameTime() {
        // Registers (3 total): v2 = this
        v0 = 10L;
        return v0;
    }

    public int getImportantForAccessibility(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 0;
        return v0;
    }

    public int getOverScrollMode(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 2;
        return v0;
    }

    public boolean hasTransientState(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 0;
        return v0;
    }

    public void onInitializeAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.view.accessibility.AccessibilityEvent)
        return;
    }

    public void onInitializeAccessibilityNodeInfo(android.view.View p0, android.support.v4.view.accessibility.AccessibilityNodeInfoCompat p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.support.v4.view.accessibility.AccessibilityNodeInfoCompat)
        return;
    }

    public void onPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.view.accessibility.AccessibilityEvent)
        return;
    }

    public void postInvalidateOnAnimation(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        _result = v2.getFrameTime(); // android.support.v4.view.ViewCompat$BaseViewCompatImpl.getFrameTime -> long
        v0 = _result;
        _result = v3.postInvalidateDelayed(v0, v1); // android.view.View.postInvalidateDelayed -> void
        return;
    }

    public void postInvalidateOnAnimation(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (13 total): v7 = this, v8 = p0 (android.view.View), v9 = p1 (int), v10 = p2 (int), v11 = p3 (int), v12 = p4 (int)
        _result = v7.getFrameTime(); // android.support.v4.view.ViewCompat$BaseViewCompatImpl.getFrameTime -> long
        v1 = _result;
        v0 = v8;
        v3 = v9;
        v4 = v10;
        v5 = v11;
        v6 = v12;
        _result = v0.postInvalidateDelayed(v0..v6); // android.view.View.postInvalidateDelayed -> void
        return;
    }

    public void postOnAnimation(android.view.View p0, java.lang.Runnable p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (java.lang.Runnable)
        _result = v2.getFrameTime(); // android.support.v4.view.ViewCompat$BaseViewCompatImpl.getFrameTime -> long
        v0 = _result;
        _result = v3.postDelayed(v4, v0, v1); // android.view.View.postDelayed -> boolean
        return;
    }

    public void postOnAnimationDelayed(android.view.View p0, java.lang.Runnable p1, long p2) {
        // Registers (7 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (java.lang.Runnable), v5 = p2 (long)
        _result = v2.getFrameTime(); // android.support.v4.view.ViewCompat$BaseViewCompatImpl.getFrameTime -> long
        v0 = _result;
        v0 = binOp2addr_0xbb(v0, v5);
        _result = v3.postDelayed(v4, v0, v1); // android.view.View.postDelayed -> boolean
        return;
    }

    public void setAccessibilityDelegate(android.view.View p0, android.support.v4.view.AccessibilityDelegateCompat p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.support.v4.view.AccessibilityDelegateCompat)
        return;
    }

    public void setHasTransientState(android.view.View p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (boolean)
        return;
    }

    public void setImportantForAccessibility(android.view.View p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int)
        return;
    }

    public void setOverScrollMode(android.view.View p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int)
        return;
    }

}