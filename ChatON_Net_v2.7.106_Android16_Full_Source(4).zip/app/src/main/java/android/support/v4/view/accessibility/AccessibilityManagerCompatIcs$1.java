package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityManagerCompatIcs.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$1;
 */
final class AccessibilityManagerCompatIcs$1 implements android.view.accessibility.AccessibilityManager$AccessibilityStateChangeListener {
    final android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge val$bridge;

    AccessibilityManagerCompatIcs$1(android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge)
        v0.val$bridge = v1; // android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$1.val$bridge:android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onAccessibilityStateChanged(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.val$bridge; // android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$1.val$bridge:android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge
        _result = android.support.v4.view.accessibility.AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge.onAccessibilityStateChanged(v0, v2); // -> void
        return;
    }

}