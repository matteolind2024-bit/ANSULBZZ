package android.support.v4.view;

/**
 * Original SourceFile: VelocityTrackerCompat.java
 * Descriptor: Landroid/support/v4/view/VelocityTrackerCompat$VelocityTrackerVersionImpl;
 */
interface VelocityTrackerCompat$VelocityTrackerVersionImpl {
    public abstract float getXVelocity(android.view.VelocityTracker p0, int p1);
    public abstract float getYVelocity(android.view.VelocityTracker p0, int p1);
}