package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/ModernAsyncTask$4;
 */
class ModernAsyncTask$4 {
    static final int[] $SwitchMap$android$support$v4$content$ModernAsyncTask$Status;

    static {
        _result = this.values(); // android.support.v4.content.ModernAsyncTask$Status.values -> android.support.v4.content.ModernAsyncTask$Status[]
        v0 = _result;
        v0 = v0.length;
        v0 = new int[][size=v0];
        android.support.v4.content.ModernAsyncTask$4.$SwitchMap$android$support$v4$content$ModernAsyncTask$Status = v0; // :int[]
        v0 = android.support.v4.content.ModernAsyncTask$4.$SwitchMap$android$support$v4$content$ModernAsyncTask$Status; // :int[]
        v1 = android.support.v4.content.ModernAsyncTask$Status.RUNNING; // :android.support.v4.content.ModernAsyncTask$Status
        _result = v1.ordinal(); // android.support.v4.content.ModernAsyncTask$Status.ordinal -> int
        v1 = _result;
        v2 = 1;
        v0[v1] = v2;
        v0 = android.support.v4.content.ModernAsyncTask$4.$SwitchMap$android$support$v4$content$ModernAsyncTask$Status; // :int[]
        v1 = android.support.v4.content.ModernAsyncTask$Status.FINISHED; // :android.support.v4.content.ModernAsyncTask$Status
        _result = v1.ordinal(); // android.support.v4.content.ModernAsyncTask$Status.ordinal -> int
        v1 = _result;
        v2 = 2;
        v0[v1] = v2;
        return;
        v0 = _exception;
        // goto L_001f
        v0 = _exception;
        // goto L_0014
    }

}