package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/FragmentManagerImpl;
 */
final class FragmentManagerImpl extends android.support.v4.app.FragmentManager {
    static final android.view.animation.Interpolator ACCELERATE_CUBIC;
    static final android.view.animation.Interpolator ACCELERATE_QUINT;
    static final int ANIM_DUR;
    public static final int ANIM_STYLE_CLOSE_ENTER;
    public static final int ANIM_STYLE_CLOSE_EXIT;
    public static final int ANIM_STYLE_FADE_ENTER;
    public static final int ANIM_STYLE_FADE_EXIT;
    public static final int ANIM_STYLE_OPEN_ENTER;
    public static final int ANIM_STYLE_OPEN_EXIT;
    static boolean DEBUG;
    static final android.view.animation.Interpolator DECELERATE_CUBIC;
    static final android.view.animation.Interpolator DECELERATE_QUINT;
    static final boolean HONEYCOMB;
    static final java.lang.String TAG;
    static final java.lang.String TARGET_REQUEST_CODE_STATE_TAG;
    static final java.lang.String TARGET_STATE_TAG;
    static final java.lang.String USER_VISIBLE_HINT_TAG;
    static final java.lang.String VIEW_STATE_TAG;
     java.util.ArrayList mActive;
     android.support.v4.app.FragmentActivity mActivity;
     java.util.ArrayList mAdded;
     java.util.ArrayList mAvailBackStackIndices;
     java.util.ArrayList mAvailIndices;
     java.util.ArrayList mBackStack;
     java.util.ArrayList mBackStackChangeListeners;
     java.util.ArrayList mBackStackIndices;
     java.util.ArrayList mCreatedMenus;
     int mCurState;
     boolean mDestroyed;
     java.lang.Runnable mExecCommit;
     boolean mExecutingActions;
     boolean mHavePendingDeferredStart;
     boolean mNeedMenuInvalidate;
     java.lang.String mNoTransactionsBecause;
     java.util.ArrayList mPendingActions;
     android.util.SparseArray mStateArray;
     android.os.Bundle mStateBundle;
     boolean mStateSaved;
     java.lang.Runnable[] mTmpActions;

    static {
        v0 = 0;
        v4 = 0x40200000;
        v3 = 0x3fc00000;
        android.support.v4.app.FragmentManagerImpl.DEBUG = v0; // :boolean
        v1 = android.os.Build$VERSION.SDK_INT; // :int
        v2 = 11;
        if (v1 < v2) /* goto L_000e */;
        v0 = 1;
        android.support.v4.app.FragmentManagerImpl.HONEYCOMB = v0; // :boolean
        v0 = new android.view.animation.DecelerateInterpolator;
        _result = v0.<init>(v4); // android.view.animation.DecelerateInterpolator.<init> -> void
        android.support.v4.app.FragmentManagerImpl.DECELERATE_QUINT = v0; // :android.view.animation.Interpolator
        v0 = new android.view.animation.DecelerateInterpolator;
        _result = v0.<init>(v3); // android.view.animation.DecelerateInterpolator.<init> -> void
        android.support.v4.app.FragmentManagerImpl.DECELERATE_CUBIC = v0; // :android.view.animation.Interpolator
        v0 = new android.view.animation.AccelerateInterpolator;
        _result = v0.<init>(v4); // android.view.animation.AccelerateInterpolator.<init> -> void
        android.support.v4.app.FragmentManagerImpl.ACCELERATE_QUINT = v0; // :android.view.animation.Interpolator
        v0 = new android.view.animation.AccelerateInterpolator;
        _result = v0.<init>(v3); // android.view.animation.AccelerateInterpolator.<init> -> void
        android.support.v4.app.FragmentManagerImpl.ACCELERATE_CUBIC = v0; // :android.view.animation.Interpolator
        return;
    }

    FragmentManagerImpl() {
        // Registers (3 total): v2 = this
        v1 = 0;
        _result = v2.<init>(); // android.support.v4.app.FragmentManager.<init> -> void
        v0 = 0;
        v2.mCurState = v0; // android.support.v4.app.FragmentManagerImpl.mCurState:int
        v2.mStateBundle = v1; // android.support.v4.app.FragmentManagerImpl.mStateBundle:android.os.Bundle
        v2.mStateArray = v1; // android.support.v4.app.FragmentManagerImpl.mStateArray:android.util.SparseArray
        v0 = new android.support.v4.app.FragmentManagerImpl$1;
        _result = v0.<init>(v2); // android.support.v4.app.FragmentManagerImpl$1.<init> -> void
        v2.mExecCommit = v0; // android.support.v4.app.FragmentManagerImpl.mExecCommit:java.lang.Runnable
        return;
    }

    private void checkStateLoss() {
        // Registers (4 total): v3 = this
        v0 = v3.mStateSaved; // android.support.v4.app.FragmentManagerImpl.mStateSaved:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Can not perform this action after onSaveInstanceState";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.mNoTransactionsBecause; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        if (v0 == 0) /* goto L_002b */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Can not perform this action inside of ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.mNoTransactionsBecause; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        return;
    }

    static android.view.animation.Animation makeFadeAnimation(android.content.Context p0, float p1, float p2) {
        // Registers (6 total): v3 = p0 (android.content.Context), v4 = p1 (float), v5 = p2 (float)
        v0 = new android.view.animation.AlphaAnimation;
        _result = v0.<init>(v4, v5); // android.view.animation.AlphaAnimation.<init> -> void
        v1 = android.support.v4.app.FragmentManagerImpl.DECELERATE_CUBIC; // :android.view.animation.Interpolator
        _result = v0.setInterpolator(v1); // android.view.animation.AlphaAnimation.setInterpolator -> void
        v1 = 220L;
        _result = v0.setDuration(v1, v2); // android.view.animation.AlphaAnimation.setDuration -> void
        return v0;
    }

    static android.view.animation.Animation makeOpenCloseAnimation(android.content.Context p0, float p1, float p2, float p3, float p4) {
        // Registers (15 total): v10 = p0 (android.content.Context), v11 = p1 (float), v12 = p2 (float), v13 = p3 (float), v14 = p4 (float)
        v9 = new android.view.animation.AnimationSet;
        v0 = 0;
        _result = v9.<init>(v0); // android.view.animation.AnimationSet.<init> -> void
        v0 = new android.view.animation.ScaleAnimation;
        v5 = 1;
        v6 = 0x3f000000;
        v7 = 1;
        v8 = 0x3f000000;
        v1 = v11;
        v2 = v12;
        v3 = v11;
        v4 = v12;
        _result = v0.<init>(v0..v8); // android.view.animation.ScaleAnimation.<init> -> void
        v1 = android.support.v4.app.FragmentManagerImpl.DECELERATE_QUINT; // :android.view.animation.Interpolator
        _result = v0.setInterpolator(v1); // android.view.animation.ScaleAnimation.setInterpolator -> void
        v1 = 220L;
        _result = v0.setDuration(v1, v2); // android.view.animation.ScaleAnimation.setDuration -> void
        _result = v9.addAnimation(v0); // android.view.animation.AnimationSet.addAnimation -> void
        v0 = new android.view.animation.AlphaAnimation;
        _result = v0.<init>(v13, v14); // android.view.animation.AlphaAnimation.<init> -> void
        v1 = android.support.v4.app.FragmentManagerImpl.DECELERATE_CUBIC; // :android.view.animation.Interpolator
        _result = v0.setInterpolator(v1); // android.view.animation.AlphaAnimation.setInterpolator -> void
        v1 = 220L;
        _result = v0.setDuration(v1, v2); // android.view.animation.AlphaAnimation.setDuration -> void
        _result = v9.addAnimation(v0); // android.view.animation.AnimationSet.addAnimation -> void
        return v9;
    }

    public static int reverseTransit(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = 0;
        // switch(v1)
        return v0;
        v0 = 8194;
        // goto L_0004
        v0 = 4097;
        // goto L_0004
        v0 = 4099;
        // goto L_0004
    }

    public static int transitToStyleIndex(int p0, boolean p1) {
        // Registers (3 total): v1 = p0 (int), v2 = p1 (boolean)
        v0 = -1;
        // switch(v1)
        return v0;
        if (v2 == 0) /* goto L_0009 */;
        v0 = 1;
        // goto L_0004
        v0 = 2;
        // goto L_0004
        if (v2 == 0) /* goto L_000f */;
        v0 = 3;
        // goto L_0004
        v0 = 4;
        // goto L_0004
        if (v2 == 0) /* goto L_0015 */;
        v0 = 5;
        // goto L_0004
        v0 = 6;
        // goto L_0004
    }

    void addBackStackState(android.support.v4.app.BackStackRecord p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.BackStackRecord)
        v0 = v1.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        if (v0 != 0) /* goto L_000b */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.mBackStack = v0; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        v0 = v1.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        _result = v1.reportBackStackChanged(); // android.support.v4.app.FragmentManagerImpl.reportBackStackChanged -> void
        return;
    }

    public void addFragment(android.support.v4.app.Fragment p0, boolean p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.support.v4.app.Fragment), v6 = p1 (boolean)
        v3 = 1;
        v0 = v4.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 != 0) /* goto L_000c */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v4.mAdded = v0; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0028 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "add: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        _result = v4.makeActive(v5); // android.support.v4.app.FragmentManagerImpl.makeActive -> void
        v0 = v5.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        if (v0 != 0) /* goto L_0048 */;
        v0 = v4.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.add(v5); // java.util.ArrayList.add -> boolean
        v5.mAdded = v3; // android.support.v4.app.Fragment.mAdded:boolean
        v0 = 0;
        v5.mRemoving = v0; // android.support.v4.app.Fragment.mRemoving:boolean
        v0 = v5.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_0043 */;
        v0 = v5.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == 0) /* goto L_0043 */;
        v4.mNeedMenuInvalidate = v3; // android.support.v4.app.FragmentManagerImpl.mNeedMenuInvalidate:boolean
        if (v6 == 0) /* goto L_0048 */;
        _result = v4.moveToState(v5); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    public void addOnBackStackChangedListener(android.support.v4.app.FragmentManager$OnBackStackChangedListener p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.FragmentManager$OnBackStackChangedListener)
        v0 = v1.mBackStackChangeListeners; // android.support.v4.app.FragmentManagerImpl.mBackStackChangeListeners:java.util.ArrayList
        if (v0 != 0) /* goto L_000b */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.mBackStackChangeListeners = v0; // android.support.v4.app.FragmentManagerImpl.mBackStackChangeListeners:java.util.ArrayList
        v0 = v1.mBackStackChangeListeners; // android.support.v4.app.FragmentManagerImpl.mBackStackChangeListeners:java.util.ArrayList
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        return;
    }

    public int allocBackStackIndex(android.support.v4.app.BackStackRecord p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.support.v4.app.BackStackRecord)
        // monitor-enter(v4)
        v0 = v4.mAvailBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        if (v0 == 0) /* goto L_000d */;
        v0 = v4.mAvailBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > 0) /* goto L_004b */;
        v0 = v4.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        if (v0 != 0) /* goto L_0018 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v4.mBackStackIndices = v0; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        v0 = v4.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v1 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_0044 */;
        v1 = "FragmentManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Setting back stack index ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " to ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v4.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        _result = v1.add(v5); // java.util.ArrayList.add -> boolean
        // monitor-exit(v4)
        return v0;
        v0 = v4.mAvailBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        v1 = v4.mAvailBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        _result = v0.remove(v1); // java.util.ArrayList.remove -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Integer) v0;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        v1 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_0085 */;
        v1 = "FragmentManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Adding back stack index ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " with ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v4.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        _result = v1.set(v0, v5); // java.util.ArrayList.set -> java.lang.Object
        // monitor-exit(v4)
        // goto L_004a
        v0 = _exception;
        // monitor-exit(v4)
        throw v0;
    }

    public void attachActivity(android.support.v4.app.FragmentActivity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.FragmentActivity)
        v0 = v1.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_000a */;
        v0 = new java.lang.IllegalStateException;
        _result = v0.<init>(); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v1.mActivity = v2; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        return;
    }

    public void attachFragment(android.support.v4.app.Fragment p0, int p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment), v8 = p1 (int), v9 = p2 (int)
        v3 = 1;
        v5 = 0;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001e */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "attach: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v7.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        if (v0 == 0) /* goto L_004d */;
        v7.mDetached = v5; // android.support.v4.app.Fragment.mDetached:boolean
        v0 = v7.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 != 0) /* goto L_004d */;
        v0 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 != 0) /* goto L_0033 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v6.mAdded = v0; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        v0 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.add(v7); // java.util.ArrayList.add -> boolean
        v7.mAdded = v3; // android.support.v4.app.Fragment.mAdded:boolean
        v0 = v7.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_0044 */;
        v0 = v7.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == 0) /* goto L_0044 */;
        v6.mNeedMenuInvalidate = v3; // android.support.v4.app.FragmentManagerImpl.mNeedMenuInvalidate:boolean
        v2 = v6.mCurState; // android.support.v4.app.FragmentManagerImpl.mCurState:int
        v0 = v6;
        v1 = v7;
        v3 = v8;
        v4 = v9;
        _result = v0.moveToState(v0..v5); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    public android.support.v4.app.FragmentTransaction beginTransaction() {
        // Registers (2 total): v1 = this
        v0 = new android.support.v4.app.BackStackRecord;
        _result = v0.<init>(v1); // android.support.v4.app.BackStackRecord.<init> -> void
        return v0;
    }

    public void detachFragment(android.support.v4.app.Fragment p0, int p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment), v8 = p1 (int), v9 = p2 (int)
        v5 = 0;
        v2 = 1;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001e */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "detach: ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v7.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        if (v0 != 0) /* goto L_0044 */;
        v7.mDetached = v2; // android.support.v4.app.Fragment.mDetached:boolean
        v0 = v7.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 == 0) /* goto L_0044 */;
        v0 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 == 0) /* goto L_0031 */;
        v0 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.remove(v7); // java.util.ArrayList.remove -> boolean
        v0 = v7.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_003b */;
        v0 = v7.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == 0) /* goto L_003b */;
        v6.mNeedMenuInvalidate = v2; // android.support.v4.app.FragmentManagerImpl.mNeedMenuInvalidate:boolean
        v7.mAdded = v5; // android.support.v4.app.Fragment.mAdded:boolean
        v0 = v6;
        v1 = v7;
        v3 = v8;
        v4 = v9;
        _result = v0.moveToState(v0..v5); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    public void dispatchActivityCreated() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v2.mStateSaved = v1; // android.support.v4.app.FragmentManagerImpl.mStateSaved:boolean
        v0 = 2;
        _result = v2.moveToState(v0, v1); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    public void dispatchConfigurationChanged(android.content.res.Configuration p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.res.Configuration)
        v0 = v2.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 == 0) /* goto L_001f */;
        v0 = 0;
        v1 = v0;
        v0 = v2.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001f */;
        v0 = v2.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_001b */;
        _result = v0.onConfigurationChanged(v3); // android.support.v4.app.Fragment.onConfigurationChanged -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
        return;
    }

    public boolean dispatchContextItemSelected(android.view.MenuItem p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.view.MenuItem)
        v2 = 0;
        v0 = v4.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 == 0) /* goto L_0027 */;
        v1 = v2;
        v0 = v4.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0027 */;
        v0 = v4.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0028 */;
        v3 = v0.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v3 != 0) /* goto L_0028 */;
        v3 = v0.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        if (v3 == 0) /* goto L_0028 */;
        _result = v0.onContextItemSelected(v5); // android.support.v4.app.Fragment.onContextItemSelected -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0028 */;
        v2 = 1;
        return v2;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
    }

    public void dispatchCreate() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v2.mStateSaved = v1; // android.support.v4.app.FragmentManagerImpl.mStateSaved:boolean
        v0 = 1;
        _result = v2.moveToState(v0, v1); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    public boolean dispatchCreateOptionsMenu(android.view.Menu p0, android.view.MenuInflater p1) {
        // Registers (9 total): v6 = this, v7 = p0 (android.view.Menu), v8 = p1 (android.view.MenuInflater)
        v4 = 0;
        v1 = 0;
        v0 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 == 0) /* goto L_003a */;
        v3 = v4;
        v2 = v4;
        v0 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_003b */;
        v0 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0034 */;
        v5 = v0.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v5 != 0) /* goto L_0034 */;
        v5 = v0.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v5 == 0) /* goto L_0034 */;
        v5 = v0.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v5 == 0) /* goto L_0034 */;
        v2 = 1;
        _result = v0.onCreateOptionsMenu(v7, v8); // android.support.v4.app.Fragment.onCreateOptionsMenu -> void
        if (v1 != 0) /* goto L_0031 */;
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        _result = v1.add(v0); // java.util.ArrayList.add -> boolean
        v0 = v2;
        v2 = binOpLit8_0xd8(v3, 1);
        v3 = v2;
        v2 = v0;
        // goto L_0008
        v2 = v4;
        v0 = v6.mCreatedMenus; // android.support.v4.app.FragmentManagerImpl.mCreatedMenus:java.util.ArrayList
        if (v0 == 0) /* goto L_005d */;
        v0 = v6.mCreatedMenus; // android.support.v4.app.FragmentManagerImpl.mCreatedMenus:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v4 >= v0) /* goto L_005d */;
        v0 = v6.mCreatedMenus; // android.support.v4.app.FragmentManagerImpl.mCreatedMenus:java.util.ArrayList
        _result = v0.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v1 == 0) /* goto L_0057 */;
        _result = v1.contains(v0); // java.util.ArrayList.contains -> boolean
        v3 = _result;
        if (v3 != 0) /* goto L_005a */;
        _result = v0.onDestroyOptionsMenu(); // android.support.v4.app.Fragment.onDestroyOptionsMenu -> void
        v4 = binOpLit8_0xd8(v4, 1);
        // goto L_003f
        v6.mCreatedMenus = v1; // android.support.v4.app.FragmentManagerImpl.mCreatedMenus:java.util.ArrayList
        return v2;
    }

    public void dispatchDestroy() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v0 = 1;
        v2.mDestroyed = v0; // android.support.v4.app.FragmentManagerImpl.mDestroyed:boolean
        _result = v2.execPendingActions(); // android.support.v4.app.FragmentManagerImpl.execPendingActions -> boolean
        _result = v2.moveToState(v1, v1); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        v0 = 0;
        v2.mActivity = v0; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        return;
    }

    public void dispatchLowMemory() {
        // Registers (3 total): v2 = this
        v0 = v2.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 == 0) /* goto L_001f */;
        v0 = 0;
        v1 = v0;
        v0 = v2.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001f */;
        v0 = v2.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_001b */;
        _result = v0.onLowMemory(); // android.support.v4.app.Fragment.onLowMemory -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
        return;
    }

    public boolean dispatchOptionsItemSelected(android.view.MenuItem p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.view.MenuItem)
        v2 = 0;
        v0 = v4.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 == 0) /* goto L_002b */;
        v1 = v2;
        v0 = v4.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_002b */;
        v0 = v4.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_002c */;
        v3 = v0.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v3 != 0) /* goto L_002c */;
        v3 = v0.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v3 == 0) /* goto L_002c */;
        v3 = v0.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v3 == 0) /* goto L_002c */;
        _result = v0.onOptionsItemSelected(v5); // android.support.v4.app.Fragment.onOptionsItemSelected -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002c */;
        v2 = 1;
        return v2;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
    }

    public void dispatchOptionsMenuClosed(android.view.Menu p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.Menu)
        v0 = v3.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 == 0) /* goto L_002b */;
        v0 = 0;
        v1 = v0;
        v0 = v3.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_002b */;
        v0 = v3.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0027 */;
        v2 = v0.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v2 != 0) /* goto L_0027 */;
        v2 = v0.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v2 == 0) /* goto L_0027 */;
        v2 = v0.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v2 == 0) /* goto L_0027 */;
        _result = v0.onOptionsMenuClosed(v4); // android.support.v4.app.Fragment.onOptionsMenuClosed -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
        return;
    }

    public void dispatchPause() {
        // Registers (3 total): v2 = this
        v0 = 4;
        v1 = 0;
        _result = v2.moveToState(v0, v1); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    public boolean dispatchPrepareOptionsMenu(android.view.Menu p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.view.Menu)
        v0 = 0;
        v1 = v4.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v1 == 0) /* goto L_002d */;
        v1 = v0;
        v2 = v0;
        v0 = v4.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_002e */;
        v0 = v4.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0029 */;
        v3 = v0.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v3 != 0) /* goto L_0029 */;
        v3 = v0.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v3 == 0) /* goto L_0029 */;
        v3 = v0.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v3 == 0) /* goto L_0029 */;
        v2 = 1;
        _result = v0.onPrepareOptionsMenu(v5); // android.support.v4.app.Fragment.onPrepareOptionsMenu -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0007
        v2 = v0;
        return v2;
    }

    public void dispatchReallyStop() {
        // Registers (3 total): v2 = this
        v0 = 2;
        v1 = 0;
        _result = v2.moveToState(v0, v1); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    public void dispatchResume() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v2.mStateSaved = v1; // android.support.v4.app.FragmentManagerImpl.mStateSaved:boolean
        v0 = 5;
        _result = v2.moveToState(v0, v1); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    public void dispatchStart() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v2.mStateSaved = v1; // android.support.v4.app.FragmentManagerImpl.mStateSaved:boolean
        v0 = 4;
        _result = v2.moveToState(v0, v1); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    public void dispatchStop() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v2.mStateSaved = v0; // android.support.v4.app.FragmentManagerImpl.mStateSaved:boolean
        v0 = 3;
        v1 = 0;
        _result = v2.moveToState(v0, v1); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    public void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (11 total): v6 = this, v7 = p0 (java.lang.String), v8 = p1 (java.io.FileDescriptor), v9 = p2 (java.io.PrintWriter), v10 = p3 (java.lang.String[])
        v1 = 0;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = "    ";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v0 = v6.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        if (v0 == 0) /* goto L_005f */;
        v0 = v6.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        if (v4 <= 0) /* goto L_005f */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Active Fragments in ";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        _result = v6.identityHashCode(); // java.lang.System.identityHashCode -> int
        v0 = _result;
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = ":";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v2 = v1;
        if (v2 >= v4) /* goto L_005f */;
        v0 = v6.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v5 = "  #";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.print(v2); // java.io.PrintWriter.print -> void
        v5 = ": ";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        if (v0 == 0) /* goto L_005b */;
        _result = v0.dump(v3, v8, v9, v10); // android.support.v4.app.Fragment.dump -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0039
        v0 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 == 0) /* goto L_0099 */;
        v0 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        if (v4 <= 0) /* goto L_0099 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Added Fragments:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v2 = v1;
        if (v2 >= v4) /* goto L_0099 */;
        v0 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v5 = "  #";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.print(v2); // java.io.PrintWriter.print -> void
        v5 = ": ";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v0.toString(); // android.support.v4.app.Fragment.toString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0074
        v0 = v6.mCreatedMenus; // android.support.v4.app.FragmentManagerImpl.mCreatedMenus:java.util.ArrayList
        if (v0 == 0) /* goto L_00d3 */;
        v0 = v6.mCreatedMenus; // android.support.v4.app.FragmentManagerImpl.mCreatedMenus:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        if (v4 <= 0) /* goto L_00d3 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Fragments Created Menus:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v2 = v1;
        if (v2 >= v4) /* goto L_00d3 */;
        v0 = v6.mCreatedMenus; // android.support.v4.app.FragmentManagerImpl.mCreatedMenus:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v5 = "  #";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.print(v2); // java.io.PrintWriter.print -> void
        v5 = ": ";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v0.toString(); // android.support.v4.app.Fragment.toString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_00ae
        v0 = v6.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        if (v0 == 0) /* goto L_0110 */;
        v0 = v6.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        if (v4 <= 0) /* goto L_0110 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Back Stack:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v2 = v1;
        if (v2 >= v4) /* goto L_0110 */;
        v0 = v6.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.BackStackRecord) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v5 = "  #";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.print(v2); // java.io.PrintWriter.print -> void
        v5 = ": ";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v0.toString(); // java.lang.Object.toString -> java.lang.String
        v5 = _result;
        _result = v9.println(v5); // java.io.PrintWriter.println -> void
        _result = v0.dump(v3, v8, v9, v10); // android.support.v4.app.BackStackRecord.dump -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_00e8
        // monitor-enter(v6)
        v0 = v6.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        if (v0 == 0) /* goto L_0147 */;
        v0 = v6.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v3 = _result;
        if (v3 <= 0) /* goto L_0147 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Back Stack Indices:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v2 = v1;
        if (v2 >= v3) /* goto L_0147 */;
        v0 = v6.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.BackStackRecord) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v4 = "  #";
        _result = v9.print(v4); // java.io.PrintWriter.print -> void
        _result = v9.print(v2); // java.io.PrintWriter.print -> void
        v4 = ": ";
        _result = v9.print(v4); // java.io.PrintWriter.print -> void
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0126
        v0 = v6.mAvailBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        if (v0 == 0) /* goto L_0168 */;
        v0 = v6.mAvailBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0168 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "mAvailBackStackIndices: ";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mAvailBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        _result = v0.toArray(); // java.util.ArrayList.toArray -> java.lang.Object[]
        v0 = _result;
        _result = v0.toString(); // java.util.Arrays.toString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        // monitor-exit(v6)
        v0 = v6.mPendingActions; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        if (v0 == 0) /* goto L_01a1 */;
        v0 = v6.mPendingActions; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        if (v2 <= 0) /* goto L_01a1 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Pending Actions:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        if (v1 >= v2) /* goto L_01a1 */;
        v0 = v6.mPendingActions; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Runnable) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v3 = "  #";
        _result = v9.print(v3); // java.io.PrintWriter.print -> void
        _result = v9.print(v1); // java.io.PrintWriter.print -> void
        v3 = ": ";
        _result = v9.print(v3); // java.io.PrintWriter.print -> void
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_017d
        v0 = _exception;
        // monitor-exit(v6)
        throw v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "FragmentManager misc state:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  mCurState=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mCurState; // android.support.v4.app.FragmentManagerImpl.mCurState:int
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mStateSaved=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mStateSaved; // android.support.v4.app.FragmentManagerImpl.mStateSaved:boolean
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mDestroyed=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mDestroyed; // android.support.v4.app.FragmentManagerImpl.mDestroyed:boolean
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.mNeedMenuInvalidate; // android.support.v4.app.FragmentManagerImpl.mNeedMenuInvalidate:boolean
        if (v0 == 0) /* goto L_01db */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  mNeedMenuInvalidate=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mNeedMenuInvalidate; // android.support.v4.app.FragmentManagerImpl.mNeedMenuInvalidate:boolean
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.mNoTransactionsBecause; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        if (v0 == 0) /* goto L_01ec */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  mNoTransactionsBecause=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mNoTransactionsBecause; // android.support.v4.app.FragmentManagerImpl.mNoTransactionsBecause:java.lang.String
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        if (v0 == 0) /* goto L_020d */;
        v0 = v6.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_020d */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  mAvailIndices: ";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        _result = v0.toArray(); // java.util.ArrayList.toArray -> java.lang.Object[]
        v0 = _result;
        _result = v0.toString(); // java.util.Arrays.toString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        return;
    }

    public void enqueueAction(java.lang.Runnable p0, boolean p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.Runnable), v4 = p1 (boolean)
        if (v4 != 0) /* goto L_0005 */;
        _result = v2.checkStateLoss(); // android.support.v4.app.FragmentManagerImpl.checkStateLoss -> void
        // monitor-enter(v2)
        v0 = v2.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_0015 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Activity has been destroyed";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = _exception;
        // monitor-exit(v2)
        throw v0;
        v0 = v2.mPendingActions; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        if (v0 != 0) /* goto L_0020 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v2.mPendingActions = v0; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        v0 = v2.mPendingActions; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        _result = v0.add(v3); // java.util.ArrayList.add -> boolean
        v0 = v2.mPendingActions; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v1 = 1;
        if (v0 != v1) /* goto L_0040 */;
        v0 = v2.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v1 = v2.mExecCommit; // android.support.v4.app.FragmentManagerImpl.mExecCommit:java.lang.Runnable
        _result = v0.removeCallbacks(v1); // android.os.Handler.removeCallbacks -> void
        v0 = v2.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v1 = v2.mExecCommit; // android.support.v4.app.FragmentManagerImpl.mExecCommit:java.lang.Runnable
        _result = v0.post(v1); // android.os.Handler.post -> boolean
        // monitor-exit(v2)
        return;
    }

    public boolean execPendingActions() {
        // Registers (7 total): v6 = this
        v0 = 1;
        v2 = 0;
        v1 = v6.mExecutingActions; // android.support.v4.app.FragmentManagerImpl.mExecutingActions:boolean
        if (v1 == 0) /* goto L_000e */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Recursive entry to executePendingTransactions";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        _result = this.myLooper(); // android.os.Looper.myLooper -> android.os.Looper
        v1 = _result;
        v3 = v6.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v3 = v3.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        _result = v3.getLooper(); // android.os.Handler.getLooper -> android.os.Looper
        v3 = _result;
        if (v1 == v3) /* goto L_0024 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Must be called from main thread of process";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v1 = v2;
        // monitor-enter(v6)
        v3 = v6.mPendingActions; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        if (v3 == 0) /* goto L_0032 */;
        v3 = v6.mPendingActions; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        _result = v3.size(); // java.util.ArrayList.size -> int
        v3 = _result;
        if (v3 != 0) /* goto L_005a */;
        // monitor-exit(v6)
        v0 = v6.mHavePendingDeferredStart; // android.support.v4.app.FragmentManagerImpl.mHavePendingDeferredStart:boolean
        if (v0 == 0) /* goto L_00a5 */;
        v3 = v2;
        v4 = v2;
        v0 = v6.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_009e */;
        v0 = v6.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0056 */;
        v5 = v0.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v5 == 0) /* goto L_0056 */;
        v0 = v0.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.hasRunningLoaders(); // android.support.v4.app.LoaderManagerImpl.hasRunningLoaders -> boolean
        v0 = _result;
        v4 = binOp2addr_0xb6(v4, v0);
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_0039
        v1 = v6.mPendingActions; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v3 = _result;
        v1 = v6.mTmpActions; // android.support.v4.app.FragmentManagerImpl.mTmpActions:java.lang.Runnable[]
        if (v1 == 0) /* goto L_0069 */;
        v1 = v6.mTmpActions; // android.support.v4.app.FragmentManagerImpl.mTmpActions:java.lang.Runnable[]
        v1 = v1.length;
        if (v1 >= v3) /* goto L_006d */;
        v1 = new java.lang.Runnable[][size=v3];
        v6.mTmpActions = v1; // android.support.v4.app.FragmentManagerImpl.mTmpActions:java.lang.Runnable[]
        v1 = v6.mPendingActions; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        v4 = v6.mTmpActions; // android.support.v4.app.FragmentManagerImpl.mTmpActions:java.lang.Runnable[]
        _result = v1.toArray(v4); // java.util.ArrayList.toArray -> java.lang.Object[]
        v1 = v6.mPendingActions; // android.support.v4.app.FragmentManagerImpl.mPendingActions:java.util.ArrayList
        _result = v1.clear(); // java.util.ArrayList.clear -> void
        v1 = v6.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = v1.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v4 = v6.mExecCommit; // android.support.v4.app.FragmentManagerImpl.mExecCommit:java.lang.Runnable
        _result = v1.removeCallbacks(v4); // android.os.Handler.removeCallbacks -> void
        // monitor-exit(v6)
        v6.mExecutingActions = v0; // android.support.v4.app.FragmentManagerImpl.mExecutingActions:boolean
        v1 = v2;
        if (v1 >= v3) /* goto L_009a */;
        v4 = v6.mTmpActions; // android.support.v4.app.FragmentManagerImpl.mTmpActions:java.lang.Runnable[]
        v4 = v4[v1];
        _result = java.lang.Runnable.run(v4); // -> void
        v4 = v6.mTmpActions; // android.support.v4.app.FragmentManagerImpl.mTmpActions:java.lang.Runnable[]
        v5 = 0;
        v4[v1] = v5;
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0086
        v0 = _exception;
        // monitor-exit(v6)
        throw v0;
        v6.mExecutingActions = v2; // android.support.v4.app.FragmentManagerImpl.mExecutingActions:boolean
        v1 = v0;
        // goto L_0025
        if (v4 != 0) /* goto L_00a5 */;
        v6.mHavePendingDeferredStart = v2; // android.support.v4.app.FragmentManagerImpl.mHavePendingDeferredStart:boolean
        _result = v6.startPendingDeferredFragments(); // android.support.v4.app.FragmentManagerImpl.startPendingDeferredFragments -> void
        return v1;
    }

    public boolean executePendingTransactions() {
        // Registers (2 total): v1 = this
        _result = v1.execPendingActions(); // android.support.v4.app.FragmentManagerImpl.execPendingActions -> boolean
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.Fragment findFragmentById(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 == 0) /* goto L_0022 */;
        v0 = v3.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0022 */;
        v0 = v3.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_001e */;
        v2 = v0.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        if (v2 != v4) /* goto L_001e */;
        return v0;
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_000d
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        if (v0 == 0) /* goto L_0043 */;
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0043 */;
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_003f */;
        v2 = v0.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        if (v2 == v4) /* goto L_001d */;
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_002f
        v0 = 0;
        // goto L_001d
    }

    public android.support.v4.app.Fragment findFragmentByTag(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        v0 = v3.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 == 0) /* goto L_0028 */;
        if (v4 == 0) /* goto L_0028 */;
        v0 = v3.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0028 */;
        v0 = v3.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0024 */;
        v2 = v0.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v4.equals(v2); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0024 */;
        return v0;
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_000f
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        if (v0 == 0) /* goto L_004f */;
        if (v4 == 0) /* goto L_004f */;
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_004f */;
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_004b */;
        v2 = v0.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v4.equals(v2); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0023 */;
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0037
        v0 = 0;
        // goto L_0023
    }

    public android.support.v4.app.Fragment findFragmentByWho(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        if (v0 == 0) /* goto L_0028 */;
        if (v4 == 0) /* goto L_0028 */;
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0028 */;
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0024 */;
        v2 = v0.mWho; // android.support.v4.app.Fragment.mWho:java.lang.String
        _result = v4.equals(v2); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0024 */;
        return v0;
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_000f
        v0 = 0;
        // goto L_0023
    }

    public void freeBackStackIndex(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        // monitor-enter(v3)
        v0 = v3.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        v1 = 0;
        _result = v0.set(v4, v1); // java.util.ArrayList.set -> java.lang.Object
        v0 = v3.mAvailBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        if (v0 != 0) /* goto L_0012 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v3.mAvailBackStackIndices = v0; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_002e */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Freeing back stack index ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v3.mAvailBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        _result = v4.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        // monitor-exit(v3)
        return;
        v0 = _exception;
        // monitor-exit(v3)
        throw v0;
    }

    public android.support.v4.app.FragmentManager$BackStackEntry getBackStackEntryAt(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.FragmentManager$BackStackEntry) v0;
        return v0;
    }

    public int getBackStackEntryCount() {
        // Registers (2 total): v1 = this
        v0 = v1.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        if (v0 == 0) /* goto L_000b */;
        v0 = v1.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_000a
    }

    public android.support.v4.app.Fragment getFragment(android.os.Bundle p0, java.lang.String p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.os.Bundle), v6 = p1 (java.lang.String)
        v0 = -1;
        _result = v5.getInt(v6, v0); // android.os.Bundle.getInt -> int
        v1 = _result;
        if (v1 != v0) /* goto L_0009 */;
        v0 = 0;
        return v0;
        v0 = v4.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 < v0) /* goto L_0034 */;
        v0 = new java.lang.IllegalStateException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Fragement no longer exists for key ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": index ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v4.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 != 0) /* goto L_0008 */;
        v0 = new java.lang.IllegalStateException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Fragement no longer exists for key ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": index ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
    }

    public void hideFragment(android.support.v4.app.Fragment p0, int p1, int p2) {
        // Registers (8 total): v4 = this, v5 = p0 (android.support.v4.app.Fragment), v6 = p1 (int), v7 = p2 (int)
        v3 = 1;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001d */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "hide: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v5.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v0 != 0) /* goto L_004a */;
        v5.mHidden = v3; // android.support.v4.app.Fragment.mHidden:boolean
        v0 = v5.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_0039 */;
        _result = v4.loadAnimation(v5, v6, v3, v7); // android.support.v4.app.FragmentManagerImpl.loadAnimation -> android.view.animation.Animation
        v0 = _result;
        if (v0 == 0) /* goto L_0032 */;
        v1 = v5.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v1.startAnimation(v0); // android.view.View.startAnimation -> void
        v0 = v5.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = 8;
        _result = v0.setVisibility(v1); // android.view.View.setVisibility -> void
        v0 = v5.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 == 0) /* goto L_0047 */;
        v0 = v5.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_0047 */;
        v0 = v5.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == 0) /* goto L_0047 */;
        v4.mNeedMenuInvalidate = v3; // android.support.v4.app.FragmentManagerImpl.mNeedMenuInvalidate:boolean
        _result = v5.onHiddenChanged(v3); // android.support.v4.app.Fragment.onHiddenChanged -> void
        return;
    }

    android.view.animation.Animation loadAnimation(android.support.v4.app.Fragment p0, int p1, boolean p2, int p3) {
        // Registers (11 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment), v8 = p1 (int), v9 = p2 (boolean), v10 = p3 (int)
        v5 = 1064933786; // 0x3f79999a
        v1 = 0;
        v4 = 0;
        v3 = 0x3f800000;
        v0 = v7.mNextAnim; // android.support.v4.app.Fragment.mNextAnim:int
        _result = v7.onCreateAnimation(v8, v9, v0); // android.support.v4.app.Fragment.onCreateAnimation -> android.view.animation.Animation
        v0 = _result;
        if (v0 == 0) /* goto L_0010 */;
        return v0;
        v0 = v7.mNextAnim; // android.support.v4.app.Fragment.mNextAnim:int
        if (v0 == 0) /* goto L_001e */;
        v0 = v6.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v2 = v7.mNextAnim; // android.support.v4.app.Fragment.mNextAnim:int
        _result = v0.loadAnimation(v2); // android.view.animation.AnimationUtils.loadAnimation -> android.view.animation.Animation
        v0 = _result;
        if (v0 != 0) /* goto L_000f */;
        if (v8 != 0) /* goto L_0022 */;
        v0 = v1;
        // goto L_000f
        _result = v8.transitToStyleIndex(v9); // android.support.v4.app.FragmentManagerImpl.transitToStyleIndex -> int
        v0 = _result;
        if (v0 >= 0) /* goto L_002a */;
        v0 = v1;
        // goto L_000f
        // switch(v0)
        if (v10 != 0) /* goto L_0043 */;
        v0 = v6.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.getWindow(); // android.support.v4.app.FragmentActivity.getWindow -> android.view.Window
        v0 = _result;
        if (v0 == 0) /* goto L_0043 */;
        v0 = v6.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.getWindow(); // android.support.v4.app.FragmentActivity.getWindow -> android.view.Window
        v0 = _result;
        _result = v0.getAttributes(); // android.view.Window.getAttributes -> android.view.WindowManager$LayoutParams
        v0 = _result;
        v10 = v0.windowAnimations; // android.view.WindowManager$LayoutParams.windowAnimations:int
        if (v10 != 0) /* goto L_0076 */;
        v0 = v1;
        // goto L_000f
        v0 = v6.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = 0x3f900000;
        _result = v0.makeOpenCloseAnimation(v1, v3, v4, v3); // android.support.v4.app.FragmentManagerImpl.makeOpenCloseAnimation -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v6.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.makeOpenCloseAnimation(v3, v5, v3, v4); // android.support.v4.app.FragmentManagerImpl.makeOpenCloseAnimation -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v6.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.makeOpenCloseAnimation(v5, v3, v4, v3); // android.support.v4.app.FragmentManagerImpl.makeOpenCloseAnimation -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v6.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = 1065982362; // 0x3f89999a
        _result = v0.makeOpenCloseAnimation(v3, v1, v3, v4); // android.support.v4.app.FragmentManagerImpl.makeOpenCloseAnimation -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v6.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.makeFadeAnimation(v4, v3); // android.support.v4.app.FragmentManagerImpl.makeFadeAnimation -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v6.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.makeFadeAnimation(v3, v4); // android.support.v4.app.FragmentManagerImpl.makeFadeAnimation -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v1;
        // goto L_000f
    }

    void makeActive(android.support.v4.app.Fragment p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.support.v4.app.Fragment)
        v0 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v0 < 0) /* goto L_0005 */;
        return;
        v0 = v3.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        if (v0 == 0) /* goto L_0011 */;
        v0 = v3.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > 0) /* goto L_0047 */;
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        if (v0 != 0) /* goto L_001c */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v3.mActive = v0; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        _result = v4.setIndex(v0); // android.support.v4.app.Fragment.setIndex -> void
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.add(v4); // java.util.ArrayList.add -> boolean
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0004 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Allocated fragment index ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        // goto L_0004
        v0 = v3.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        v1 = v3.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        _result = v0.remove(v1); // java.util.ArrayList.remove -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Integer) v0;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v4.setIndex(v0); // android.support.v4.app.Fragment.setIndex -> void
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v0.set(v1, v4); // java.util.ArrayList.set -> java.lang.Object
        // goto L_002a
    }

    void makeInactive(android.support.v4.app.Fragment p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.support.v4.app.Fragment)
        v0 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v0 >= 0) /* goto L_0005 */;
        return;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0021 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Freeing fragment index ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v3.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v2 = 0;
        _result = v0.set(v1, v2); // java.util.ArrayList.set -> java.lang.Object
        v0 = v3.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        if (v0 != 0) /* goto L_0034 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v3.mAvailIndices = v0; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        v0 = v3.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        v0 = v3.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v0.invalidateSupportFragmentIndex(v1); // android.support.v4.app.FragmentActivity.invalidateSupportFragmentIndex -> void
        _result = v4.initState(); // android.support.v4.app.Fragment.initState -> void
        // goto L_0004
    }

    void moveToState(int p0, int p1, int p2, boolean p3) {
        // Registers (13 total): v8 = this, v9 = p0 (int), v10 = p1 (int), v11 = p2 (int), v12 = p3 (boolean)
        v5 = 0;
        v0 = v8.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_000f */;
        if (v9 == 0) /* goto L_000f */;
        v0 = new java.lang.IllegalStateException;
        v1 = "No activity";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        if (v12 != 0) /* goto L_0016 */;
        v0 = v8.mCurState; // android.support.v4.app.FragmentManagerImpl.mCurState:int
        if (v0 != v9) /* goto L_0016 */;
        return;
        v8.mCurState = v9; // android.support.v4.app.FragmentManagerImpl.mCurState:int
        v0 = v8.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        if (v0 == 0) /* goto L_0015 */;
        v6 = v5;
        v7 = v5;
        v0 = v8.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v6 >= v0) /* goto L_0048 */;
        v0 = v8.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.get(v6); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.app.Fragment) v1;
        if (v1 == 0) /* goto L_0062 */;
        v0 = v8;
        v2 = v9;
        v3 = v10;
        v4 = v11;
        _result = v0.moveToState(v0..v5); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        v0 = v1.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        if (v0 == 0) /* goto L_0062 */;
        v0 = v1.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.LoaderManagerImpl
        _result = v0.hasRunningLoaders(); // android.support.v4.app.LoaderManagerImpl.hasRunningLoaders -> boolean
        v0 = _result;
        v7 = binOp2addr_0xb6(v7, v0);
        v1 = v7;
        v0 = binOpLit8_0xd8(v6, 1);
        v6 = v0;
        v7 = v1;
        // goto L_001e
        if (v7 != 0) /* goto L_004d */;
        _result = v8.startPendingDeferredFragments(); // android.support.v4.app.FragmentManagerImpl.startPendingDeferredFragments -> void
        v0 = v8.mNeedMenuInvalidate; // android.support.v4.app.FragmentManagerImpl.mNeedMenuInvalidate:boolean
        if (v0 == 0) /* goto L_0015 */;
        v0 = v8.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_0015 */;
        v0 = v8.mCurState; // android.support.v4.app.FragmentManagerImpl.mCurState:int
        v1 = 5;
        if (v0 != v1) /* goto L_0015 */;
        v0 = v8.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.supportInvalidateOptionsMenu(); // android.support.v4.app.FragmentActivity.supportInvalidateOptionsMenu -> void
        v8.mNeedMenuInvalidate = v5; // android.support.v4.app.FragmentManagerImpl.mNeedMenuInvalidate:boolean
        // goto L_0015
        v1 = v7;
        // goto L_0043
    }

    void moveToState(int p0, boolean p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (boolean)
        v0 = 0;
        _result = v1.moveToState(v2, v0, v0, v3); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    void moveToState(android.support.v4.app.Fragment p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment)
        v3 = 0;
        v2 = v6.mCurState; // android.support.v4.app.FragmentManagerImpl.mCurState:int
        v0 = v6;
        v1 = v7;
        v4 = v3;
        v5 = v3;
        _result = v0.moveToState(v0..v5); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
    }

    void moveToState(android.support.v4.app.Fragment p0, int p1, int p2, int p3, boolean p4) {
        // Registers (15 total): v9 = this, v10 = p0 (android.support.v4.app.Fragment), v11 = p1 (int), v12 = p2 (int), v13 = p3 (int), v14 = p4 (boolean)
        v8 = 4;
        v6 = 3;
        v5 = 1;
        v7 = 0;
        v3 = 0;
        v0 = v10.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 != 0) /* goto L_000c */;
        if (v11 <= v5) /* goto L_000c */;
        v11 = v5;
        v0 = v10.mRemoving; // android.support.v4.app.Fragment.mRemoving:boolean
        if (v0 == 0) /* goto L_0016 */;
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        if (v11 <= v0) /* goto L_0016 */;
        v11 = v10.mState; // android.support.v4.app.Fragment.mState:int
        v0 = v10.mDeferStart; // android.support.v4.app.Fragment.mDeferStart:boolean
        if (v0 == 0) /* goto L_0021 */;
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        if (v0 >= v8) /* goto L_0021 */;
        if (v11 <= v6) /* goto L_0021 */;
        v11 = v6;
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        if (v0 >= v11) /* goto L_02a7 */;
        v0 = v10.mFromLayout; // android.support.v4.app.Fragment.mFromLayout:boolean
        if (v0 == 0) /* goto L_002e */;
        v0 = v10.mInLayout; // android.support.v4.app.Fragment.mInLayout:boolean
        if (v0 != 0) /* goto L_002e */;
        return;
        v0 = v10.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        if (v0 == 0) /* goto L_003c */;
        v10.mAnimatingAway = v7; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        v2 = v10.mStateAfterAnimating; // android.support.v4.app.Fragment.mStateAfterAnimating:int
        v0 = v9;
        v1 = v10;
        v4 = v3;
        _result = v0.moveToState(v0..v5); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        // switch(v0)
        v10.mState = v11; // android.support.v4.app.Fragment.mState:int
        // goto L_002d
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0060 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "moveto CREATED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        if (v0 == 0) /* goto L_0099 */;
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v1 = "android:view_state";
        _result = v0.getSparseParcelableArray(v1); // android.os.Bundle.getSparseParcelableArray -> android.util.SparseArray
        v0 = _result;
        v10.mSavedViewState = v0; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v1 = "android:target_state";
        _result = v9.getFragment(v0, v1); // android.support.v4.app.FragmentManagerImpl.getFragment -> android.support.v4.app.Fragment
        v0 = _result;
        v10.mTarget = v0; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v0 = v10.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0086 */;
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v1 = "android:target_req_state";
        _result = v0.getInt(v1, v3); // android.os.Bundle.getInt -> int
        v0 = _result;
        v10.mTargetRequestCode = v0; // android.support.v4.app.Fragment.mTargetRequestCode:int
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v1 = "android:user_visible_hint";
        _result = v0.getBoolean(v1, v5); // android.os.Bundle.getBoolean -> boolean
        v0 = _result;
        v10.mUserVisibleHint = v0; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        v0 = v10.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        if (v0 != 0) /* goto L_0099 */;
        v10.mDeferStart = v5; // android.support.v4.app.Fragment.mDeferStart:boolean
        if (v11 <= v6) /* goto L_0099 */;
        v11 = v6;
        v0 = v9.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v10.mActivity = v0; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v0 = v9.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mFragments; // android.support.v4.app.FragmentActivity.mFragments:android.support.v4.app.FragmentManagerImpl
        v10.mFragmentManager = v0; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.FragmentManagerImpl
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        v0 = v9.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v10.onAttach(v0); // android.support.v4.app.Fragment.onAttach -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_00cd */;
        v0 = new android.support.v4.app.SuperNotCalledException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onAttach()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.SuperNotCalledException.<init> -> void
        throw v0;
        v0 = v9.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.onAttachFragment(v10); // android.support.v4.app.FragmentActivity.onAttachFragment -> void
        v0 = v10.mRetaining; // android.support.v4.app.Fragment.mRetaining:boolean
        if (v0 != 0) /* goto L_0100 */;
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.onCreate(v0); // android.support.v4.app.Fragment.onCreate -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0100 */;
        v0 = new android.support.v4.app.SuperNotCalledException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onCreate()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.SuperNotCalledException.<init> -> void
        throw v0;
        v10.mRetaining = v3; // android.support.v4.app.Fragment.mRetaining:boolean
        v0 = v10.mFromLayout; // android.support.v4.app.Fragment.mFromLayout:boolean
        if (v0 == 0) /* goto L_0136 */;
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.getLayoutInflater(v0); // android.support.v4.app.Fragment.getLayoutInflater -> android.view.LayoutInflater
        v0 = _result;
        v1 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.onCreateView(v0, v7, v1); // android.support.v4.app.Fragment.onCreateView -> android.view.View
        v0 = _result;
        v10.mView = v0; // android.support.v4.app.Fragment.mView:android.view.View
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_0195 */;
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v10.mInnerView = v0; // android.support.v4.app.Fragment.mInnerView:android.view.View
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.wrap(); // android.support.v4.app.NoSaveStateFrameLayout.wrap -> android.view.ViewGroup
        v0 = _result;
        v10.mView = v0; // android.support.v4.app.Fragment.mView:android.view.View
        v0 = v10.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v0 == 0) /* goto L_012f */;
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = 8;
        _result = v0.setVisibility(v1); // android.view.View.setVisibility -> void
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.onViewCreated(v0, v1); // android.support.v4.app.Fragment.onViewCreated -> void
        if (v11 <= v5) /* goto L_0213 */;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0154 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "moveto ACTIVITY_CREATED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v10.mFromLayout; // android.support.v4.app.Fragment.mFromLayout:boolean
        if (v0 != 0) /* goto L_01dd */;
        v0 = v10.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        if (v0 == 0) /* goto L_0198 */;
        v0 = v9.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v1 = v10.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        _result = v0.findViewById(v1); // android.support.v4.app.FragmentActivity.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.view.ViewGroup) v0;
        if (v0 != 0) /* goto L_0199 */;
        v1 = v10.mRestored; // android.support.v4.app.Fragment.mRestored:boolean
        if (v1 != 0) /* goto L_0199 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "No view found for id 0x";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v10.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        _result = v2.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " for fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v10.mInnerView = v7; // android.support.v4.app.Fragment.mInnerView:android.view.View
        // goto L_0136
        v0 = v7;
        v10.mContainer = v0; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        v1 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.getLayoutInflater(v1); // android.support.v4.app.Fragment.getLayoutInflater -> android.view.LayoutInflater
        v1 = _result;
        v2 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.onCreateView(v1, v0, v2); // android.support.v4.app.Fragment.onCreateView -> android.view.View
        v1 = _result;
        v10.mView = v1; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v1 == 0) /* goto L_0207 */;
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v10.mInnerView = v1; // android.support.v4.app.Fragment.mInnerView:android.view.View
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v1.wrap(); // android.support.v4.app.NoSaveStateFrameLayout.wrap -> android.view.ViewGroup
        v1 = _result;
        v10.mView = v1; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_01cb */;
        _result = v9.loadAnimation(v10, v12, v5, v13); // android.support.v4.app.FragmentManagerImpl.loadAnimation -> android.view.animation.Animation
        v1 = _result;
        if (v1 == 0) /* goto L_01c6 */;
        v2 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v2.startAnimation(v1); // android.view.View.startAnimation -> void
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.addView(v1); // android.view.ViewGroup.addView -> void
        v0 = v10.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v0 == 0) /* goto L_01d6 */;
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = 8;
        _result = v0.setVisibility(v1); // android.view.View.setVisibility -> void
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.onViewCreated(v0, v1); // android.support.v4.app.Fragment.onViewCreated -> void
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.onActivityCreated(v0); // android.support.v4.app.Fragment.onActivityCreated -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_020a */;
        v0 = new android.support.v4.app.SuperNotCalledException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onActivityCreated()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.SuperNotCalledException.<init> -> void
        throw v0;
        v10.mInnerView = v7; // android.support.v4.app.Fragment.mInnerView:android.view.View
        // goto L_01dd
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_0211 */;
        _result = v10.restoreViewState(); // android.support.v4.app.Fragment.restoreViewState -> void
        v10.mSavedFragmentState = v7; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        if (v11 <= v6) /* goto L_0259 */;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0231 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "moveto STARTED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v10.performStart(); // android.support.v4.app.Fragment.performStart -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0259 */;
        v0 = new android.support.v4.app.SuperNotCalledException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onStart()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.SuperNotCalledException.<init> -> void
        throw v0;
        if (v11 <= v8) /* goto L_0041 */;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0277 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "moveto RESUMED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        v10.mResumed = v5; // android.support.v4.app.Fragment.mResumed:boolean
        _result = v10.onResume(); // android.support.v4.app.Fragment.onResume -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_02a1 */;
        v0 = new android.support.v4.app.SuperNotCalledException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onResume()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.SuperNotCalledException.<init> -> void
        throw v0;
        v10.mSavedFragmentState = v7; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v10.mSavedViewState = v7; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        // goto L_0041
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        if (v0 <= v11) /* goto L_0041 */;
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        // switch(v0)
        // goto L_0041
        if (v11 >= v5) /* goto L_0041 */;
        v0 = v9.mDestroyed; // android.support.v4.app.FragmentManagerImpl.mDestroyed:boolean
        if (v0 == 0) /* goto L_02c3 */;
        v0 = v10.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        if (v0 == 0) /* goto L_02c3 */;
        v0 = v10.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        v10.mAnimatingAway = v7; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        _result = v0.clearAnimation(); // android.view.View.clearAnimation -> void
        v0 = v10.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        if (v0 == 0) /* goto L_040e */;
        v10.mStateAfterAnimating = v11; // android.support.v4.app.Fragment.mStateAfterAnimating:int
        v11 = v5;
        // goto L_0041
        v0 = 5;
        if (v11 >= v0) /* goto L_0315 */;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_02eb */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "movefrom RESUMED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v10.onPause(); // android.support.v4.app.Fragment.onPause -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0313 */;
        v0 = new android.support.v4.app.SuperNotCalledException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onPause()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.SuperNotCalledException.<init> -> void
        throw v0;
        v10.mResumed = v3; // android.support.v4.app.Fragment.mResumed:boolean
        if (v11 >= v8) /* goto L_035b */;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0333 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "movefrom STARTED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v10.performStop(); // android.support.v4.app.Fragment.performStop -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_035b */;
        v0 = new android.support.v4.app.SuperNotCalledException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onStop()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.SuperNotCalledException.<init> -> void
        throw v0;
        if (v11 >= v6) /* goto L_037c */;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0379 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "movefrom STOPPED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        _result = v10.performReallyStop(); // android.support.v4.app.Fragment.performReallyStop -> void
        v0 = 2;
        if (v11 >= v0) /* goto L_02b2 */;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_039b */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "movefrom ACTIVITY_CREATED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_03ae */;
        v0 = v9.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.isFinishing(); // android.support.v4.app.FragmentActivity.isFinishing -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_03ae */;
        v0 = v10.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        if (v0 != 0) /* goto L_03ae */;
        _result = v9.saveFragmentViewState(v10); // android.support.v4.app.FragmentManagerImpl.saveFragmentViewState -> void
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v10.performDestroyView(); // android.support.v4.app.Fragment.performDestroyView -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_03d6 */;
        v0 = new android.support.v4.app.SuperNotCalledException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onDestroyView()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.SuperNotCalledException.<init> -> void
        throw v0;
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_0406 */;
        v0 = v10.mContainer; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        if (v0 == 0) /* goto L_0406 */;
        v0 = v9.mCurState; // android.support.v4.app.FragmentManagerImpl.mCurState:int
        if (v0 <= 0) /* goto L_048f */;
        v0 = v9.mDestroyed; // android.support.v4.app.FragmentManagerImpl.mDestroyed:boolean
        if (v0 != 0) /* goto L_048f */;
        _result = v9.loadAnimation(v10, v12, v3, v13); // android.support.v4.app.FragmentManagerImpl.loadAnimation -> android.view.animation.Animation
        v0 = _result;
        if (v0 == 0) /* goto L_03ff */;
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v10.mAnimatingAway = v1; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        v10.mStateAfterAnimating = v11; // android.support.v4.app.Fragment.mStateAfterAnimating:int
        v1 = new android.support.v4.app.FragmentManagerImpl$5;
        _result = v1.<init>(v9, v10); // android.support.v4.app.FragmentManagerImpl$5.<init> -> void
        _result = v0.setAnimationListener(v1); // android.view.animation.Animation.setAnimationListener -> void
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v1.startAnimation(v0); // android.view.View.startAnimation -> void
        v0 = v10.mContainer; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.removeView(v1); // android.view.ViewGroup.removeView -> void
        v10.mContainer = v7; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        v10.mView = v7; // android.support.v4.app.Fragment.mView:android.view.View
        v10.mInnerView = v7; // android.support.v4.app.Fragment.mInnerView:android.view.View
        // goto L_02b2
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_042a */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "movefrom CREATED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v10.mRetaining; // android.support.v4.app.Fragment.mRetaining:boolean
        if (v0 != 0) /* goto L_0456 */;
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v10.onDestroy(); // android.support.v4.app.Fragment.onDestroy -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0456 */;
        v0 = new android.support.v4.app.SuperNotCalledException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onDestroy()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.SuperNotCalledException.<init> -> void
        throw v0;
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v10.onDetach(); // android.support.v4.app.Fragment.onDetach -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_047e */;
        v0 = new android.support.v4.app.SuperNotCalledException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onDetach()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.SuperNotCalledException.<init> -> void
        throw v0;
        if (v14 != 0) /* goto L_0041 */;
        v0 = v10.mRetaining; // android.support.v4.app.Fragment.mRetaining:boolean
        if (v0 != 0) /* goto L_0489 */;
        _result = v9.makeInactive(v10); // android.support.v4.app.FragmentManagerImpl.makeInactive -> void
        // goto L_0041
        v10.mActivity = v7; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v10.mFragmentManager = v7; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.FragmentManagerImpl
        // goto L_0041
        v0 = v7;
        // goto L_03ea
    }

    public void noteStateNotSaved() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.mStateSaved = v0; // android.support.v4.app.FragmentManagerImpl.mStateSaved:boolean
        return;
    }

    public void performPendingDeferredStart(android.support.v4.app.Fragment p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment)
        v3 = 0;
        v0 = v7.mDeferStart; // android.support.v4.app.Fragment.mDeferStart:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = v6.mExecutingActions; // android.support.v4.app.FragmentManagerImpl.mExecutingActions:boolean
        if (v0 == 0) /* goto L_000d */;
        v0 = 1;
        v6.mHavePendingDeferredStart = v0; // android.support.v4.app.FragmentManagerImpl.mHavePendingDeferredStart:boolean
        return;
        v7.mDeferStart = v3; // android.support.v4.app.Fragment.mDeferStart:boolean
        v2 = v6.mCurState; // android.support.v4.app.FragmentManagerImpl.mCurState:int
        v0 = v6;
        v1 = v7;
        v4 = v3;
        v5 = v3;
        _result = v0.moveToState(v0..v5); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        // goto L_000c
    }

    public void popBackStack() {
        // Registers (3 total): v2 = this
        v0 = new android.support.v4.app.FragmentManagerImpl$2;
        _result = v0.<init>(v2); // android.support.v4.app.FragmentManagerImpl$2.<init> -> void
        v1 = 0;
        _result = v2.enqueueAction(v0, v1); // android.support.v4.app.FragmentManagerImpl.enqueueAction -> void
        return;
    }

    public void popBackStack(int p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (int)
        if (v4 >= 0) /* goto L_001b */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Bad id: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = new android.support.v4.app.FragmentManagerImpl$4;
        _result = v0.<init>(v3, v4, v5); // android.support.v4.app.FragmentManagerImpl$4.<init> -> void
        v1 = 0;
        _result = v3.enqueueAction(v0, v1); // android.support.v4.app.FragmentManagerImpl.enqueueAction -> void
        return;
    }

    public void popBackStack(java.lang.String p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.String), v4 = p1 (int)
        v0 = new android.support.v4.app.FragmentManagerImpl$3;
        _result = v0.<init>(v2, v3, v4); // android.support.v4.app.FragmentManagerImpl$3.<init> -> void
        v1 = 0;
        _result = v2.enqueueAction(v0, v1); // android.support.v4.app.FragmentManagerImpl.enqueueAction -> void
        return;
    }

    public boolean popBackStackImmediate() {
        // Registers (5 total): v4 = this
        _result = v4.checkStateLoss(); // android.support.v4.app.FragmentManagerImpl.checkStateLoss -> void
        _result = v4.executePendingTransactions(); // android.support.v4.app.FragmentManagerImpl.executePendingTransactions -> boolean
        v0 = v4.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v1 = 0;
        v2 = -1;
        v3 = 0;
        _result = v4.popBackStackState(v0, v1, v2, v3); // android.support.v4.app.FragmentManagerImpl.popBackStackState -> boolean
        v0 = _result;
        return v0;
    }

    public boolean popBackStackImmediate(int p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (int)
        _result = v3.checkStateLoss(); // android.support.v4.app.FragmentManagerImpl.checkStateLoss -> void
        _result = v3.executePendingTransactions(); // android.support.v4.app.FragmentManagerImpl.executePendingTransactions -> boolean
        if (v4 >= 0) /* goto L_0021 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Bad id: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v3.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v1 = 0;
        _result = v3.popBackStackState(v0, v1, v4, v5); // android.support.v4.app.FragmentManagerImpl.popBackStackState -> boolean
        v0 = _result;
        return v0;
    }

    public boolean popBackStackImmediate(java.lang.String p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.String), v4 = p1 (int)
        _result = v2.checkStateLoss(); // android.support.v4.app.FragmentManagerImpl.checkStateLoss -> void
        _result = v2.executePendingTransactions(); // android.support.v4.app.FragmentManagerImpl.executePendingTransactions -> boolean
        v0 = v2.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.mHandler; // android.support.v4.app.FragmentActivity.mHandler:android.os.Handler
        v1 = -1;
        _result = v2.popBackStackState(v0, v3, v1, v4); // android.support.v4.app.FragmentManagerImpl.popBackStackState -> boolean
        v0 = _result;
        return v0;
    }

    boolean popBackStackState(android.os.Handler p0, java.lang.String p1, int p2, int p3) {
        // Registers (13 total): v8 = this, v9 = p0 (android.os.Handler), v10 = p1 (java.lang.String), v11 = p2 (int), v12 = p3 (int)
        v2 = 1;
        v3 = 0;
        v0 = v8.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        if (v0 != 0) /* goto L_0007 */;
        return v3;
        if (v10 != 0) /* goto L_0029 */;
        if (v11 >= 0) /* goto L_0029 */;
        v0 = binOpLit8_0xdd(v12, 1);
        if (v0 != 0) /* goto L_0029 */;
        v0 = v8.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        if (v0 < 0) /* goto L_0006 */;
        v1 = v8.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v1.remove(v0); // java.util.ArrayList.remove -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.BackStackRecord) v0;
        _result = v0.popFromBackStack(v2); // android.support.v4.app.BackStackRecord.popFromBackStack -> void
        _result = v8.reportBackStackChanged(); // android.support.v4.app.FragmentManagerImpl.reportBackStackChanged -> void
        v3 = v2;
        // goto L_0006
        v0 = -1;
        if (v10 != 0) /* goto L_002e */;
        if (v11 < 0) /* goto L_007d */;
        v0 = v8.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v1 = binOpLit8_0xd8(v0, -1);
        if (v1 < 0) /* goto L_004c */;
        v0 = v8.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.BackStackRecord) v0;
        if (v10 == 0) /* goto L_0073 */;
        _result = v0.getName(); // android.support.v4.app.BackStackRecord.getName -> java.lang.String
        v4 = _result;
        _result = v10.equals(v4); // java.lang.String.equals -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_0073 */;
        if (v1 < 0) /* goto L_0006 */;
        v0 = binOpLit8_0xdd(v12, 1);
        if (v0 == 0) /* goto L_007c */;
        v1 = binOpLit8_0xd8(v1, -1);
        if (v1 < 0) /* goto L_007c */;
        v0 = v8.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.BackStackRecord) v0;
        if (v10 == 0) /* goto L_006a */;
        _result = v0.getName(); // android.support.v4.app.BackStackRecord.getName -> java.lang.String
        v4 = _result;
        _result = v10.equals(v4); // java.lang.String.equals -> boolean
        v4 = _result;
        if (v4 != 0) /* goto L_0070 */;
        if (v11 < 0) /* goto L_007c */;
        v0 = v0.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        if (v11 != v0) /* goto L_007c */;
        v1 = binOpLit8_0xd8(v1, -1);
        // goto L_0054
        if (v11 < 0) /* goto L_0079 */;
        v0 = v0.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        if (v11 == v0) /* goto L_004c */;
        v1 = binOpLit8_0xd8(v1, -1);
        // goto L_0036
        v0 = v1;
        v1 = v8.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        if (v0 == v1) /* goto L_0006 */;
        v5 = new java.util.ArrayList;
        _result = v5.<init>(); // java.util.ArrayList.<init> -> void
        v1 = v8.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        if (v1 <= v0) /* goto L_00a2 */;
        v4 = v8.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v4.remove(v1); // java.util.ArrayList.remove -> java.lang.Object
        v4 = _result;
        _result = v5.add(v4); // java.util.ArrayList.add -> boolean
        v1 = binOpLit8_0xd8(v1, -1);
        // goto L_0094
        _result = v5.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v6 = binOpLit8_0xd8(v0, -1);
        v4 = v3;
        if (v4 > v6) /* goto L_00dd */;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_00cb */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v7 = "Popping back stack state: ";
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v5.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v7 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        _result = v5.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.BackStackRecord) v0;
        if (v4 != v6) /* goto L_00db */;
        v1 = v2;
        _result = v0.popFromBackStack(v1); // android.support.v4.app.BackStackRecord.popFromBackStack -> void
        v0 = binOpLit8_0xd8(v4, 1);
        v4 = v0;
        // goto L_00a9
        v1 = v3;
        // goto L_00d4
        _result = v8.reportBackStackChanged(); // android.support.v4.app.FragmentManagerImpl.reportBackStackChanged -> void
        // goto L_0027
    }

    public void putFragment(android.os.Bundle p0, java.lang.String p1, android.support.v4.app.Fragment p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.os.Bundle), v5 = p1 (java.lang.String), v6 = p2 (android.support.v4.app.Fragment)
        v0 = v6.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v0 >= 0) /* goto L_0023 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " is not currently in the FragmentManager";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v6.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v4.putInt(v5, v0); // android.os.Bundle.putInt -> void
        return;
    }

    public void removeFragment(android.support.v4.app.Fragment p0, int p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment), v8 = p1 (int), v9 = p2 (int)
        v1 = 1;
        v5 = 0;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_002a */;
        v0 = "FragmentManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "remove: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " nesting=";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v7.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v0.v(v2); // android.util.Log.v -> int
        _result = v7.isInBackStack(); // android.support.v4.app.Fragment.isInBackStack -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0059 */;
        v0 = v1;
        v2 = v7.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        if (v2 == 0) /* goto L_0037 */;
        if (v0 == 0) /* goto L_0058 */;
        v2 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v2 == 0) /* goto L_0040 */;
        v2 = v6.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v2.remove(v7); // java.util.ArrayList.remove -> boolean
        v2 = v7.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v2 == 0) /* goto L_004a */;
        v2 = v7.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v2 == 0) /* goto L_004a */;
        v6.mNeedMenuInvalidate = v1; // android.support.v4.app.FragmentManagerImpl.mNeedMenuInvalidate:boolean
        v7.mAdded = v5; // android.support.v4.app.Fragment.mAdded:boolean
        v7.mRemoving = v1; // android.support.v4.app.Fragment.mRemoving:boolean
        if (v0 == 0) /* goto L_005b */;
        v2 = v5;
        v0 = v6;
        v1 = v7;
        v3 = v8;
        v4 = v9;
        _result = v0.moveToState(v0..v5); // android.support.v4.app.FragmentManagerImpl.moveToState -> void
        return;
        v0 = v5;
        // goto L_0031
        v2 = v1;
        // goto L_0051
    }

    public void removeOnBackStackChangedListener(android.support.v4.app.FragmentManager$OnBackStackChangedListener p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.FragmentManager$OnBackStackChangedListener)
        v0 = v1.mBackStackChangeListeners; // android.support.v4.app.FragmentManagerImpl.mBackStackChangeListeners:java.util.ArrayList
        if (v0 == 0) /* goto L_0009 */;
        v0 = v1.mBackStackChangeListeners; // android.support.v4.app.FragmentManagerImpl.mBackStackChangeListeners:java.util.ArrayList
        _result = v0.remove(v2); // java.util.ArrayList.remove -> boolean
        return;
    }

    void reportBackStackChanged() {
        // Registers (3 total): v2 = this
        v0 = v2.mBackStackChangeListeners; // android.support.v4.app.FragmentManagerImpl.mBackStackChangeListeners:java.util.ArrayList
        if (v0 == 0) /* goto L_001d */;
        v0 = 0;
        v1 = v0;
        v0 = v2.mBackStackChangeListeners; // android.support.v4.app.FragmentManagerImpl.mBackStackChangeListeners:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001d */;
        v0 = v2.mBackStackChangeListeners; // android.support.v4.app.FragmentManagerImpl.mBackStackChangeListeners:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.FragmentManager$OnBackStackChangedListener) v0;
        _result = android.support.v4.app.FragmentManager$OnBackStackChangedListener.onBackStackChanged(v0); // -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
        return;
    }

    void restoreAllState(android.os.Parcelable p0, java.util.ArrayList p1) {
        // Registers (11 total): v8 = this, v9 = p0 (android.os.Parcelable), v10 = p1 (java.util.ArrayList)
        v7 = 0;
        v2 = 0;
        if (v9 != 0) /* goto L_0005 */;
        return;
        v9 = (android.support.v4.app.FragmentManagerState) v9;
        v0 = v9.mActive; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        if (v0 == 0) /* goto L_0004 */;
        if (v10 == 0) /* goto L_0065 */;
        v1 = v2;
        _result = v10.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0065 */;
        _result = v10.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v3 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v3 == 0) /* goto L_0036 */;
        v3 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "restoreAllState: re-attaching retained ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v3.v(v4); // android.util.Log.v -> int
        v3 = v9.mActive; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        v4 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v3 = v3[v4];
        v3.mInstance = v0; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v0.mSavedViewState = v7; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        v0.mBackStackNesting = v2; // android.support.v4.app.Fragment.mBackStackNesting:int
        v0.mInLayout = v2; // android.support.v4.app.Fragment.mInLayout:boolean
        v0.mAdded = v2; // android.support.v4.app.Fragment.mAdded:boolean
        v0.mTarget = v7; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v4 = v3.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        if (v4 == 0) /* goto L_0061 */;
        v4 = v3.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v5 = v8.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v5.getClassLoader(); // android.support.v4.app.FragmentActivity.getClassLoader -> java.lang.ClassLoader
        v5 = _result;
        _result = v4.setClassLoader(v5); // android.os.Bundle.setClassLoader -> void
        v3 = v3.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v4 = "android:view_state";
        _result = v3.getSparseParcelableArray(v4); // android.os.Bundle.getSparseParcelableArray -> android.util.SparseArray
        v3 = _result;
        v0.mSavedViewState = v3; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_000e
        v0 = new java.util.ArrayList;
        v1 = v9.mActive; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        v1 = v1.length;
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v8.mActive = v0; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        v0 = v8.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        if (v0 == 0) /* goto L_0078 */;
        v0 = v8.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        v0 = v2;
        v1 = v9.mActive; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        v1 = v1.length;
        if (v0 >= v1) /* goto L_0112 */;
        v1 = v9.mActive; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        v1 = v1[v0];
        if (v1 == 0) /* goto L_00ba */;
        v3 = v8.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v1.instantiate(v3); // android.support.v4.app.FragmentState.instantiate -> android.support.v4.app.Fragment
        v3 = _result;
        v4 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v4 == 0) /* goto L_00b0 */;
        v4 = "FragmentManager";
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "restoreAllState: adding #";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = ": ";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v5 = _result;
        _result = v4.v(v5); // android.util.Log.v -> int
        v4 = v8.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v4.add(v3); // java.util.ArrayList.add -> boolean
        v1.mInstance = v7; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0079
        v1 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_00dc */;
        v1 = "FragmentManager";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "restoreAllState: adding #";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ": (null)";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v1.v(v3); // android.util.Log.v -> int
        v1 = v8.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v1.add(v7); // java.util.ArrayList.add -> boolean
        v1 = v8.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        if (v1 != 0) /* goto L_00ec */;
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        v8.mAvailIndices = v1; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        v1 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_0108 */;
        v1 = "FragmentManager";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "restoreAllState: adding avail #";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v1.v(v3); // android.util.Log.v -> int
        v1 = v8.mAvailIndices; // android.support.v4.app.FragmentManagerImpl.mAvailIndices:java.util.ArrayList
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v3 = _result;
        _result = v1.add(v3); // java.util.ArrayList.add -> boolean
        // goto L_00b7
        if (v10 == 0) /* goto L_0166 */;
        v3 = v2;
        _result = v10.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_0166 */;
        _result = v10.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v1 = v0.mTargetIndex; // android.support.v4.app.Fragment.mTargetIndex:int
        if (v1 < 0) /* goto L_013b */;
        v1 = v0.mTargetIndex; // android.support.v4.app.Fragment.mTargetIndex:int
        v4 = v8.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v4.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        if (v1 >= v4) /* goto L_013f */;
        v1 = v8.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        v4 = v0.mTargetIndex; // android.support.v4.app.Fragment.mTargetIndex:int
        _result = v1.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.app.Fragment) v1;
        v0.mTarget = v1; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_0115
        v1 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "Re-attaching retained fragment ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = " target no longer exists: ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = v0.mTargetIndex; // android.support.v4.app.Fragment.mTargetIndex:int
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v1.w(v4); // android.util.Log.w -> int
        v0.mTarget = v7; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        // goto L_013b
        v0 = v9.mAdded; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        if (v0 == 0) /* goto L_01d7 */;
        v0 = new java.util.ArrayList;
        v1 = v9.mAdded; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        v1 = v1.length;
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v8.mAdded = v0; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        v1 = v2;
        v0 = v9.mAdded; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        v0 = v0.length;
        if (v1 >= v0) /* goto L_01d9 */;
        v0 = v8.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        v3 = v9.mAdded; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        v3 = v3[v1];
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 != 0) /* goto L_01a5 */;
        v0 = new java.lang.IllegalStateException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "No instantiated fragment for index #";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v9.mAdded; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        v1 = v3[v1];
        _result = v2.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v3 = 1;
        v0.mAdded = v3; // android.support.v4.app.Fragment.mAdded:boolean
        v3 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v3 == 0) /* goto L_01ce */;
        v3 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "restoreAllState: making added #";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = ": ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v3.v(v4); // android.util.Log.v -> int
        v3 = v8.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v3.add(v0); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0175
        v8.mAdded = v7; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        v0 = v9.mBackStack; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        if (v0 == 0) /* goto L_0237 */;
        v0 = new java.util.ArrayList;
        v1 = v9.mBackStack; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        v1 = v1.length;
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v8.mBackStack = v0; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        v0 = v9.mBackStack; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        v0 = v0.length;
        if (v2 >= v0) /* goto L_0004 */;
        v0 = v9.mBackStack; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        v0 = v0[v2];
        _result = v0.instantiate(v8); // android.support.v4.app.BackStackState.instantiate -> android.support.v4.app.BackStackRecord
        v0 = _result;
        v1 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_0226 */;
        v1 = "FragmentManager";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "restoreAllState: adding bse #";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = " (index ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = v0.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = "): ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v1.v(v3); // android.util.Log.v -> int
        v1 = v8.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v1.add(v0); // java.util.ArrayList.add -> boolean
        v1 = v0.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        if (v1 < 0) /* goto L_0234 */;
        v1 = v0.mIndex; // android.support.v4.app.BackStackRecord.mIndex:int
        _result = v8.setBackStackIndex(v1, v0); // android.support.v4.app.FragmentManagerImpl.setBackStackIndex -> void
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_01e7
        v8.mBackStack = v7; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        // goto L_0004
    }

    java.util.ArrayList retainNonConfig() {
        // Registers (7 total): v6 = this
        v1 = 0;
        v0 = v6.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        if (v0 == 0) /* goto L_0056 */;
        v0 = 0;
        v3 = v0;
        v0 = v6.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_0056 */;
        v0 = v6.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0050 */;
        v2 = v0.mRetainInstance; // android.support.v4.app.Fragment.mRetainInstance:boolean
        if (v2 == 0) /* goto L_0050 */;
        if (v1 != 0) /* goto L_0024 */;
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        _result = v1.add(v0); // java.util.ArrayList.add -> boolean
        v2 = 1;
        v0.mRetaining = v2; // android.support.v4.app.Fragment.mRetaining:boolean
        v2 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        if (v2 == 0) /* goto L_0054 */;
        v2 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v2 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v0.mTargetIndex = v2; // android.support.v4.app.Fragment.mTargetIndex:int
        v2 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v2 == 0) /* goto L_0050 */;
        v2 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "retainNonConfig: keeping retained ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v2.v(v0); // android.util.Log.v -> int
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_0007
        v2 = -1;
        // goto L_0032
        return v1;
    }

    android.os.Parcelable saveAllState() {
        // Registers (12 total): v11 = this
        v1 = 1;
        v3 = 0;
        v4 = 0;
        _result = v11.execPendingActions(); // android.support.v4.app.FragmentManagerImpl.execPendingActions -> boolean
        v0 = android.support.v4.app.FragmentManagerImpl.HONEYCOMB; // :boolean
        if (v0 == 0) /* goto L_000c */;
        v11.mStateSaved = v1; // android.support.v4.app.FragmentManagerImpl.mStateSaved:boolean
        v0 = v11.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        if (v0 == 0) /* goto L_0018 */;
        v0 = v11.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > 0) /* goto L_0019 */;
        return v3;
        v0 = v11.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v6 = _result;
        v7 = new android.support.v4.app.FragmentState[][size=v6];
        v5 = v4;
        v2 = v4;
        if (v5 >= v6) /* goto L_0121 */;
        v0 = v11.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0224 */;
        v2 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v2 >= 0) /* goto L_0070 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Failure saving state: active ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " has cleared index: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v0 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = "FragmentManager";
        _result = v1.e(v0); // android.util.Log.e -> int
        v1 = "  ";
        v2 = new java.io.PrintWriter;
        v5 = new android.support.v4.util.LogWriter;
        v6 = "FragmentManager";
        _result = v5.<init>(v6); // android.support.v4.util.LogWriter.<init> -> void
        _result = v2.<init>(v5); // java.io.PrintWriter.<init> -> void
        v4 = new java.lang.String[][size=v4];
        _result = v11.dump(v1, v3, v2, v4); // android.support.v4.app.FragmentManagerImpl.dump -> void
        v1 = new java.lang.IllegalStateException;
        _result = v1.<init>(v0); // java.lang.IllegalStateException.<init> -> void
        throw v1;
        v2 = new android.support.v4.app.FragmentState;
        _result = v2.<init>(v0); // android.support.v4.app.FragmentState.<init> -> void
        v7[v5] = v2;
        v8 = v0.mState; // android.support.v4.app.Fragment.mState:int
        if (v8 <= 0) /* goto L_011c */;
        v8 = v2.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        if (v8 != 0) /* goto L_011c */;
        _result = v11.saveFragmentBasicState(v0); // android.support.v4.app.FragmentManagerImpl.saveFragmentBasicState -> android.os.Bundle
        v8 = _result;
        v2.mSavedFragmentState = v8; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v8 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        if (v8 == 0) /* goto L_00ed */;
        v8 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v8 = v8.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v8 >= 0) /* goto L_00cc */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Failure saving state: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " has target not in fragment manager: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v0 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = "FragmentManager";
        _result = v1.e(v0); // android.util.Log.e -> int
        v1 = "  ";
        v2 = new java.io.PrintWriter;
        v5 = new android.support.v4.util.LogWriter;
        v6 = "FragmentManager";
        _result = v5.<init>(v6); // android.support.v4.util.LogWriter.<init> -> void
        _result = v2.<init>(v5); // java.io.PrintWriter.<init> -> void
        v4 = new java.lang.String[][size=v4];
        _result = v11.dump(v1, v3, v2, v4); // android.support.v4.app.FragmentManagerImpl.dump -> void
        v1 = new java.lang.IllegalStateException;
        _result = v1.<init>(v0); // java.lang.IllegalStateException.<init> -> void
        throw v1;
        v8 = v2.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        if (v8 != 0) /* goto L_00d7 */;
        v8 = new android.os.Bundle;
        _result = v8.<init>(); // android.os.Bundle.<init> -> void
        v2.mSavedFragmentState = v8; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v8 = v2.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v9 = "android:target_state";
        v10 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        _result = v11.putFragment(v8, v9, v10); // android.support.v4.app.FragmentManagerImpl.putFragment -> void
        v8 = v0.mTargetRequestCode; // android.support.v4.app.Fragment.mTargetRequestCode:int
        if (v8 == 0) /* goto L_00ed */;
        v8 = v2.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v9 = "android:target_req_state";
        v10 = v0.mTargetRequestCode; // android.support.v4.app.Fragment.mTargetRequestCode:int
        _result = v8.putInt(v9, v10); // android.os.Bundle.putInt -> void
        v8 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v8 == 0) /* goto L_0115 */;
        v8 = "FragmentManager";
        v9 = new java.lang.StringBuilder;
        _result = v9.<init>(); // java.lang.StringBuilder.<init> -> void
        v10 = "Saved state of ";
        _result = v9.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        _result = v9.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v9 = ": ";
        _result = v0.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = v2.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v8.v(v0); // android.util.Log.v -> int
        v0 = v1;
        v2 = binOpLit8_0xd8(v5, 1);
        v5 = v2;
        v2 = v0;
        // goto L_0023
        v8 = v0.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v2.mSavedFragmentState = v8; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        // goto L_00ed
        if (v2 != 0) /* goto L_0130 */;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0018 */;
        v0 = "FragmentManager";
        v1 = "saveAllState: no fragments!";
        _result = v0.v(v1); // android.util.Log.v -> int
        // goto L_0018
        v0 = v11.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        if (v0 == 0) /* goto L_01c5 */;
        v0 = v11.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v5 = _result;
        if (v5 <= 0) /* goto L_01c5 */;
        v1 = new int[][size=v5];
        v2 = v4;
        if (v2 >= v5) /* goto L_01c6 */;
        v0 = v11.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v0 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v1[v2] = v0;
        v0 = v1[v2];
        if (v0 >= 0) /* goto L_0194 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "Failure saving state: active ";
        _result = v0.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v5 = v11.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v5.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v5 = _result;
        _result = v0.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v5 = " has cleared index: ";
        _result = v0.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v1[v2];
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = "FragmentManager";
        _result = v1.e(v0); // android.util.Log.e -> int
        v1 = "  ";
        v2 = new java.io.PrintWriter;
        v5 = new android.support.v4.util.LogWriter;
        v6 = "FragmentManager";
        _result = v5.<init>(v6); // android.support.v4.util.LogWriter.<init> -> void
        _result = v2.<init>(v5); // java.io.PrintWriter.<init> -> void
        v4 = new java.lang.String[][size=v4];
        _result = v11.dump(v1, v3, v2, v4); // android.support.v4.app.FragmentManagerImpl.dump -> void
        v1 = new java.lang.IllegalStateException;
        _result = v1.<init>(v0); // java.lang.IllegalStateException.<init> -> void
        throw v1;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_01c0 */;
        v0 = "FragmentManager";
        v6 = new java.lang.StringBuilder;
        _result = v6.<init>(); // java.lang.StringBuilder.<init> -> void
        v8 = "saveAllState: adding fragment #";
        _result = v6.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v8 = ": ";
        _result = v6.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v8 = v11.mAdded; // android.support.v4.app.FragmentManagerImpl.mAdded:java.util.ArrayList
        _result = v8.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v8 = _result;
        _result = v6.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v6 = _result;
        _result = v0.v(v6); // android.util.Log.v -> int
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_013f
        v1 = v3;
        v0 = v11.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        if (v0 == 0) /* goto L_0216 */;
        v0 = v11.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v5 = _result;
        if (v5 <= 0) /* goto L_0216 */;
        v3 = new android.support.v4.app.BackStackState[][size=v5];
        v2 = v4;
        if (v2 >= v5) /* goto L_0216 */;
        v4 = new android.support.v4.app.BackStackState;
        v0 = v11.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.BackStackRecord) v0;
        _result = v4.<init>(v11, v0); // android.support.v4.app.BackStackState.<init> -> void
        v3[v2] = v4;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_0212 */;
        v0 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "saveAllState: adding back stack #";
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v6 = ": ";
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v6 = v11.mBackStack; // android.support.v4.app.FragmentManagerImpl.mBackStack:java.util.ArrayList
        _result = v6.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v6 = _result;
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v0.v(v4); // android.util.Log.v -> int
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_01d5
        v0 = new android.support.v4.app.FragmentManagerState;
        _result = v0.<init>(); // android.support.v4.app.FragmentManagerState.<init> -> void
        v0.mActive = v7; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        v0.mAdded = v1; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        v0.mBackStack = v3; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        v3 = v0;
        // goto L_0018
        v0 = v2;
        // goto L_0116
    }

    android.os.Bundle saveFragmentBasicState(android.support.v4.app.Fragment p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.support.v4.app.Fragment)
        v1 = 0;
        v0 = v3.mStateBundle; // android.support.v4.app.FragmentManagerImpl.mStateBundle:android.os.Bundle
        if (v0 != 0) /* goto L_000c */;
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        v3.mStateBundle = v0; // android.support.v4.app.FragmentManagerImpl.mStateBundle:android.os.Bundle
        v0 = v3.mStateBundle; // android.support.v4.app.FragmentManagerImpl.mStateBundle:android.os.Bundle
        _result = v4.onSaveInstanceState(v0); // android.support.v4.app.Fragment.onSaveInstanceState -> void
        v0 = v3.mStateBundle; // android.support.v4.app.FragmentManagerImpl.mStateBundle:android.os.Bundle
        _result = v0.isEmpty(); // android.os.Bundle.isEmpty -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0049 */;
        v0 = v3.mStateBundle; // android.support.v4.app.FragmentManagerImpl.mStateBundle:android.os.Bundle
        v3.mStateBundle = v1; // android.support.v4.app.FragmentManagerImpl.mStateBundle:android.os.Bundle
        v1 = v4.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v1 == 0) /* goto L_0024 */;
        _result = v3.saveFragmentViewState(v4); // android.support.v4.app.FragmentManagerImpl.saveFragmentViewState -> void
        v1 = v4.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        if (v1 == 0) /* goto L_0036 */;
        if (v0 != 0) /* goto L_002f */;
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        v1 = "android:view_state";
        v2 = v4.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        _result = v0.putSparseParcelableArray(v1, v2); // android.os.Bundle.putSparseParcelableArray -> void
        v1 = v4.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        if (v1 != 0) /* goto L_0048 */;
        if (v0 != 0) /* goto L_0041 */;
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        v1 = "android:user_visible_hint";
        v2 = v4.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        _result = v0.putBoolean(v1, v2); // android.os.Bundle.putBoolean -> void
        return v0;
        v0 = v1;
        // goto L_001d
    }

    public android.support.v4.app.Fragment$SavedState saveFragmentInstanceState(android.support.v4.app.Fragment p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.support.v4.app.Fragment)
        v0 = 0;
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v1 >= 0) /* goto L_0024 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " is not currently in the FragmentManager";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v1 = v4.mState; // android.support.v4.app.Fragment.mState:int
        if (v1 <= 0) /* goto L_0033 */;
        _result = v3.saveFragmentBasicState(v4); // android.support.v4.app.FragmentManagerImpl.saveFragmentBasicState -> android.os.Bundle
        v1 = _result;
        if (v1 == 0) /* goto L_0033 */;
        v0 = new android.support.v4.app.Fragment$SavedState;
        _result = v0.<init>(v1); // android.support.v4.app.Fragment$SavedState.<init> -> void
        return v0;
    }

    void saveFragmentViewState(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = v3.mInnerView; // android.support.v4.app.Fragment.mInnerView:android.view.View
        if (v0 != 0) /* goto L_0005 */;
        return;
        v0 = v2.mStateArray; // android.support.v4.app.FragmentManagerImpl.mStateArray:android.util.SparseArray
        if (v0 != 0) /* goto L_0027 */;
        v0 = new android.util.SparseArray;
        _result = v0.<init>(); // android.util.SparseArray.<init> -> void
        v2.mStateArray = v0; // android.support.v4.app.FragmentManagerImpl.mStateArray:android.util.SparseArray
        v0 = v3.mInnerView; // android.support.v4.app.Fragment.mInnerView:android.view.View
        v1 = v2.mStateArray; // android.support.v4.app.FragmentManagerImpl.mStateArray:android.util.SparseArray
        _result = v0.saveHierarchyState(v1); // android.view.View.saveHierarchyState -> void
        v0 = v2.mStateArray; // android.support.v4.app.FragmentManagerImpl.mStateArray:android.util.SparseArray
        _result = v0.size(); // android.util.SparseArray.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0004 */;
        v0 = v2.mStateArray; // android.support.v4.app.FragmentManagerImpl.mStateArray:android.util.SparseArray
        v3.mSavedViewState = v0; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        v0 = 0;
        v2.mStateArray = v0; // android.support.v4.app.FragmentManagerImpl.mStateArray:android.util.SparseArray
        // goto L_0004
        v0 = v2.mStateArray; // android.support.v4.app.FragmentManagerImpl.mStateArray:android.util.SparseArray
        _result = v0.clear(); // android.util.SparseArray.clear -> void
        // goto L_0010
    }

    public void setBackStackIndex(int p0, android.support.v4.app.BackStackRecord p1) {
        // Registers (7 total): v4 = this, v5 = p0 (int), v6 = p1 (android.support.v4.app.BackStackRecord)
        // monitor-enter(v4)
        v0 = v4.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        if (v0 != 0) /* goto L_000c */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v4.mBackStackIndices = v0; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        v0 = v4.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v5 >= v0) /* goto L_0041 */;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_003a */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Setting back stack index ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " to ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        _result = v0.set(v5, v6); // java.util.ArrayList.set -> java.lang.Object
        // monitor-exit(v4)
        return;
        if (v0 >= v5) /* goto L_007c */;
        v1 = v4.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        v2 = 0;
        _result = v1.add(v2); // java.util.ArrayList.add -> boolean
        v1 = v4.mAvailBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        if (v1 != 0) /* goto L_0054 */;
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        v4.mAvailBackStackIndices = v1; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        v1 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v1 == 0) /* goto L_0070 */;
        v1 = "FragmentManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Adding available back stack index ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v4.mAvailBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mAvailBackStackIndices:java.util.ArrayList
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v1.add(v2); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0041
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_00a2 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Adding back stack index ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " with ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.mBackStackIndices; // android.support.v4.app.FragmentManagerImpl.mBackStackIndices:java.util.ArrayList
        _result = v0.add(v6); // java.util.ArrayList.add -> boolean
        // goto L_003f
        v0 = _exception;
        // monitor-exit(v4)
        throw v0;
    }

    public void showFragment(android.support.v4.app.Fragment p0, int p1, int p2) {
        // Registers (9 total): v5 = this, v6 = p0 (android.support.v4.app.Fragment), v7 = p1 (int), v8 = p2 (int)
        v4 = 1;
        v3 = 0;
        v0 = android.support.v4.app.FragmentManagerImpl.DEBUG; // :boolean
        if (v0 == 0) /* goto L_001e */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "show: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v6.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v0 == 0) /* goto L_0049 */;
        v6.mHidden = v3; // android.support.v4.app.Fragment.mHidden:boolean
        v0 = v6.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_0038 */;
        _result = v5.loadAnimation(v6, v7, v4, v8); // android.support.v4.app.FragmentManagerImpl.loadAnimation -> android.view.animation.Animation
        v0 = _result;
        if (v0 == 0) /* goto L_0033 */;
        v1 = v6.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v1.startAnimation(v0); // android.view.View.startAnimation -> void
        v0 = v6.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.setVisibility(v3); // android.view.View.setVisibility -> void
        v0 = v6.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 == 0) /* goto L_0046 */;
        v0 = v6.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_0046 */;
        v0 = v6.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == 0) /* goto L_0046 */;
        v5.mNeedMenuInvalidate = v4; // android.support.v4.app.FragmentManagerImpl.mNeedMenuInvalidate:boolean
        _result = v6.onHiddenChanged(v3); // android.support.v4.app.Fragment.onHiddenChanged -> void
        return;
    }

    void startPendingDeferredFragments() {
        // Registers (3 total): v2 = this
        v0 = v2.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        if (v0 != 0) /* goto L_0005 */;
        return;
        v0 = 0;
        v1 = v0;
        v0 = v2.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0004 */;
        v0 = v2.mActive; // android.support.v4.app.FragmentManagerImpl.mActive:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_001c */;
        _result = v2.performPendingDeferredStart(v0); // android.support.v4.app.FragmentManagerImpl.performPendingDeferredStart -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0007
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 128;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = "FragmentManager{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v2.identityHashCode(); // java.lang.System.identityHashCode -> int
        v1 = _result;
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = " in ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mActivity; // android.support.v4.app.FragmentManagerImpl.mActivity:android.support.v4.app.FragmentActivity
        _result = v1.buildShortClassTag(v0); // android.support.v4.util.DebugUtils.buildShortClassTag -> void
        v1 = "}}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}