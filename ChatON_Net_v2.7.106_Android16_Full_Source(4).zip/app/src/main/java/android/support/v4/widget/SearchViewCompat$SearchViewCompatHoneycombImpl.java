package android.support.v4.widget;

/**
 * Original SourceFile: SearchViewCompat.java
 * Descriptor: Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl;
 */
class SearchViewCompat$SearchViewCompatHoneycombImpl extends android.support.v4.widget.SearchViewCompat$SearchViewCompatStubImpl {
    SearchViewCompat$SearchViewCompatHoneycombImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.widget.SearchViewCompat$SearchViewCompatStubImpl.<init> -> void
        return;
    }

    public java.lang.Object newOnQueryTextListener(android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat)
        v0 = new android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl$1;
        _result = v0.<init>(v1, v2); // android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl$1.<init> -> void
        _result = v0.newOnQueryTextListener(); // android.support.v4.widget.SearchViewCompatHoneycomb.newOnQueryTextListener -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public android.view.View newSearchView(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        _result = v2.newSearchView(); // android.support.v4.widget.SearchViewCompatHoneycomb.newSearchView -> android.view.View
        v0 = _result;
        return v0;
    }

    public void setOnQueryTextListener(java.lang.Object p0, java.lang.Object p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.Object)
        _result = v1.setOnQueryTextListener(v2); // android.support.v4.widget.SearchViewCompatHoneycomb.setOnQueryTextListener -> void
        return;
    }

}