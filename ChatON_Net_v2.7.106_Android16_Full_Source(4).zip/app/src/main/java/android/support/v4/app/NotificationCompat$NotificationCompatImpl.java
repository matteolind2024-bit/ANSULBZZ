package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/NotificationCompat$NotificationCompatImpl;
 */
interface NotificationCompat$NotificationCompatImpl {
    public abstract android.app.Notification getNotification(android.support.v4.app.NotificationCompat$Builder p0);
}