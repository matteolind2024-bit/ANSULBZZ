package android.support.v4.view;

/**
 * Original SourceFile: MenuCompat.java
 * Descriptor: Landroid/support/v4/view/MenuCompat$BaseMenuVersionImpl;
 */
class MenuCompat$BaseMenuVersionImpl implements android.support.v4.view.MenuCompat$MenuVersionImpl {
    MenuCompat$BaseMenuVersionImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean setShowAsAction(android.view.MenuItem p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MenuItem), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

}