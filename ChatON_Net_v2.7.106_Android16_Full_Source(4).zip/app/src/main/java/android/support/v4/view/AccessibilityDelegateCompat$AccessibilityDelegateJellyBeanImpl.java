package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompat.java
 * Descriptor: Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl;
 */
class AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl extends android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateIcsImpl {
    AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateIcsImpl.<init> -> void
        return;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeProviderCompat getAccessibilityNodeProvider(java.lang.Object p0, android.view.View p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.Object), v4 = p1 (android.view.View)
        _result = v3.getAccessibilityNodeProvider(v4); // android.support.v4.view.AccessibilityDelegateCompatJellyBean.getAccessibilityNodeProvider -> java.lang.Object
        v1 = _result;
        if (v1 == 0) /* goto L_000c */;
        v0 = new android.support.v4.view.accessibility.AccessibilityNodeProviderCompat;
        _result = v0.<init>(v1); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.<init> -> void
        return v0;
        v0 = 0;
        // goto L_000b
    }

    public java.lang.Object newAccessiblityDelegateBridge(android.support.v4.view.AccessibilityDelegateCompat p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.AccessibilityDelegateCompat)
        v0 = new android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1;
        _result = v0.<init>(v1, v2); // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.<init> -> void
        _result = v0.newAccessibilityDelegateBridge(); // android.support.v4.view.AccessibilityDelegateCompatJellyBean.newAccessibilityDelegateBridge -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public boolean performAccessibilityAction(java.lang.Object p0, android.view.View p1, int p2, android.os.Bundle p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.view.View), v4 = p2 (int), v5 = p3 (android.os.Bundle)
        _result = v2.performAccessibilityAction(v3, v4, v5); // android.support.v4.view.AccessibilityDelegateCompatJellyBean.performAccessibilityAction -> boolean
        v0 = _result;
        return v0;
    }

}