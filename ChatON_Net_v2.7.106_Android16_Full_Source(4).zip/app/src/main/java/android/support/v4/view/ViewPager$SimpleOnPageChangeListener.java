package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$SimpleOnPageChangeListener;
 */
public class ViewPager$SimpleOnPageChangeListener implements android.support.v4.view.ViewPager$OnPageChangeListener {
    public ViewPager$SimpleOnPageChangeListener() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onPageScrollStateChanged(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        return;
    }

    public void onPageScrolled(int p0, float p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (int), v2 = p1 (float), v3 = p2 (int)
        return;
    }

    public void onPageSelected(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        return;
    }

}