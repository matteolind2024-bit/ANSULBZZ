package android.support.v4.content;

/**
 * Original SourceFile: ContextCompat.java
 * Descriptor: Landroid/support/v4/content/ContextCompat;
 */
public class ContextCompat {
    public ContextCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean startActivities(android.content.Context p0, android.content.Intent[] p1) {
        // Registers (3 total): v1 = p0 (android.content.Context), v2 = p1 (android.content.Intent[])
        v0 = 0;
        _result = v1.startActivities(v2, v0); // android.support.v4.content.ContextCompat.startActivities -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean startActivities(android.content.Context p0, android.content.Intent[] p1, android.os.Bundle p2) {
        // Registers (6 total): v3 = p0 (android.content.Context), v4 = p1 (android.content.Intent[]), v5 = p2 (android.os.Bundle)
        v0 = 1;
        v1 = android.os.Build$VERSION.SDK_INT; // :int
        v2 = 16;
        if (v1 < v2) /* goto L_000b */;
        _result = v3.startActivities(v4, v5); // android.support.v4.content.ContextCompatJellybean.startActivities -> void
        return v0;
        v2 = 11;
        if (v1 < v2) /* goto L_0013 */;
        _result = v3.startActivities(v4); // android.support.v4.content.ContextCompatHoneycomb.startActivities -> void
        // goto L_000a
        v0 = 0;
        // goto L_000a
    }

}