package android.support.v4.net;

/**
 * Original SourceFile: TrafficStatsCompatIcs.java
 * Descriptor: Landroid/support/v4/net/TrafficStatsCompatIcs;
 */
public class TrafficStatsCompatIcs {
    public TrafficStatsCompatIcs() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void clearThreadStatsTag() {
        _result = this.clearThreadStatsTag(); // android.net.TrafficStats.clearThreadStatsTag -> void
        return;
    }

    public static int getThreadStatsTag() {
        _result = this.getThreadStatsTag(); // android.net.TrafficStats.getThreadStatsTag -> int
        v0 = _result;
        return v0;
    }

    public static void incrementOperationCount(int p0) {
        // Registers (1 total): v0 = p0 (int)
        _result = v0.incrementOperationCount(); // android.net.TrafficStats.incrementOperationCount -> void
        return;
    }

    public static void incrementOperationCount(int p0, int p1) {
        // Registers (2 total): v0 = p0 (int), v1 = p1 (int)
        _result = v0.incrementOperationCount(v1); // android.net.TrafficStats.incrementOperationCount -> void
        return;
    }

    public static void setThreadStatsTag(int p0) {
        // Registers (1 total): v0 = p0 (int)
        _result = v0.setThreadStatsTag(); // android.net.TrafficStats.setThreadStatsTag -> void
        return;
    }

    public static void tagSocket(java.net.Socket p0) {
        // Registers (1 total): v0 = p0 (java.net.Socket)
        _result = v0.tagSocket(); // android.net.TrafficStats.tagSocket -> void
        return;
    }

    public static void untagSocket(java.net.Socket p0) {
        // Registers (1 total): v0 = p0 (java.net.Socket)
        _result = v0.untagSocket(); // android.net.TrafficStats.untagSocket -> void
        return;
    }

}