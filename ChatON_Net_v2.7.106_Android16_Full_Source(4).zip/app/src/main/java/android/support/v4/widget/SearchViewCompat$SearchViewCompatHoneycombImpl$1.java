package android.support.v4.widget;

/**
 * Original SourceFile: SearchViewCompat.java
 * Descriptor: Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl$1;
 */
class SearchViewCompat$SearchViewCompatHoneycombImpl$1 implements android.support.v4.widget.SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge {
    final android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl this$0;
    final android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat val$listener;

    SearchViewCompat$SearchViewCompatHoneycombImpl$1(android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl p0, android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl), v2 = p1 (android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat)
        v0.this$0 = v1; // android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl$1.this$0:android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl
        v0.val$listener = v2; // android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl$1.val$listener:android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean onQueryTextChange(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.val$listener; // android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl$1.val$listener:android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat
        _result = v0.onQueryTextChange(v2); // android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat.onQueryTextChange -> boolean
        v0 = _result;
        return v0;
    }

    public boolean onQueryTextSubmit(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.val$listener; // android.support.v4.widget.SearchViewCompat$SearchViewCompatHoneycombImpl$1.val$listener:android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat
        _result = v0.onQueryTextSubmit(v2); // android.support.v4.widget.SearchViewCompat$OnQueryTextListenerCompat.onQueryTextSubmit -> boolean
        v0 = _result;
        return v0;
    }

}