package android.support.v4.accessibilityservice;

/**
 * Original SourceFile: AccessibilityServiceInfoCompat.java
 * Descriptor: Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;
 */
interface AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl {
    public abstract boolean getCanRetrieveWindowContent(android.accessibilityservice.AccessibilityServiceInfo p0);
    public abstract java.lang.String getDescription(android.accessibilityservice.AccessibilityServiceInfo p0);
    public abstract java.lang.String getId(android.accessibilityservice.AccessibilityServiceInfo p0);
    public abstract android.content.pm.ResolveInfo getResolveInfo(android.accessibilityservice.AccessibilityServiceInfo p0);
    public abstract java.lang.String getSettingsActivityName(android.accessibilityservice.AccessibilityServiceInfo p0);
}