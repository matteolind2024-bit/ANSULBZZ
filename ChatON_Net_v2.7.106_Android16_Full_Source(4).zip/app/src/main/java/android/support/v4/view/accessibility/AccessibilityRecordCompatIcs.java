package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityRecordCompatIcs.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;
 */
class AccessibilityRecordCompatIcs {
    AccessibilityRecordCompatIcs() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static int getAddedCount(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getAddedCount(); // android.view.accessibility.AccessibilityRecord.getAddedCount -> int
        v0 = _result;
        return v0;
    }

    public static java.lang.CharSequence getBeforeText(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getBeforeText(); // android.view.accessibility.AccessibilityRecord.getBeforeText -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public static java.lang.CharSequence getClassName(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getClassName(); // android.view.accessibility.AccessibilityRecord.getClassName -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public static java.lang.CharSequence getContentDescription(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getContentDescription(); // android.view.accessibility.AccessibilityRecord.getContentDescription -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public static int getCurrentItemIndex(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getCurrentItemIndex(); // android.view.accessibility.AccessibilityRecord.getCurrentItemIndex -> int
        v0 = _result;
        return v0;
    }

    public static int getFromIndex(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getFromIndex(); // android.view.accessibility.AccessibilityRecord.getFromIndex -> int
        v0 = _result;
        return v0;
    }

    public static int getItemCount(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getItemCount(); // android.view.accessibility.AccessibilityRecord.getItemCount -> int
        v0 = _result;
        return v0;
    }

    public static android.os.Parcelable getParcelableData(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getParcelableData(); // android.view.accessibility.AccessibilityRecord.getParcelableData -> android.os.Parcelable
        v0 = _result;
        return v0;
    }

    public static int getRemovedCount(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getRemovedCount(); // android.view.accessibility.AccessibilityRecord.getRemovedCount -> int
        v0 = _result;
        return v0;
    }

    public static int getScrollX(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getScrollX(); // android.view.accessibility.AccessibilityRecord.getScrollX -> int
        v0 = _result;
        return v0;
    }

    public static int getScrollY(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getScrollY(); // android.view.accessibility.AccessibilityRecord.getScrollY -> int
        v0 = _result;
        return v0;
    }

    public static java.lang.Object getSource(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getSource(); // android.view.accessibility.AccessibilityRecord.getSource -> android.view.accessibility.AccessibilityNodeInfo
        v0 = _result;
        return v0;
    }

    public static java.util.List getText(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getText(); // android.view.accessibility.AccessibilityRecord.getText -> java.util.List
        v0 = _result;
        return v0;
    }

    public static int getToIndex(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getToIndex(); // android.view.accessibility.AccessibilityRecord.getToIndex -> int
        v0 = _result;
        return v0;
    }

    public static int getWindowId(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.getWindowId(); // android.view.accessibility.AccessibilityRecord.getWindowId -> int
        v0 = _result;
        return v0;
    }

    public static boolean isChecked(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.isChecked(); // android.view.accessibility.AccessibilityRecord.isChecked -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isEnabled(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.isEnabled(); // android.view.accessibility.AccessibilityRecord.isEnabled -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isFullScreen(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.isFullScreen(); // android.view.accessibility.AccessibilityRecord.isFullScreen -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isPassword(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.isPassword(); // android.view.accessibility.AccessibilityRecord.isPassword -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean isScrollable(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.isScrollable(); // android.view.accessibility.AccessibilityRecord.isScrollable -> boolean
        v0 = _result;
        return v0;
    }

    public static java.lang.Object obtain() {
        _result = this.obtain(); // android.view.accessibility.AccessibilityRecord.obtain -> android.view.accessibility.AccessibilityRecord
        v0 = _result;
        return v0;
    }

    public static java.lang.Object obtain(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityRecord) v1;
        _result = v1.obtain(); // android.view.accessibility.AccessibilityRecord.obtain -> android.view.accessibility.AccessibilityRecord
        v0 = _result;
        return v0;
    }

    public static void recycle(java.lang.Object p0) {
        // Registers (1 total): v0 = p0 (java.lang.Object)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.recycle(); // android.view.accessibility.AccessibilityRecord.recycle -> void
        return;
    }

    public static void setAddedCount(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setAddedCount(v1); // android.view.accessibility.AccessibilityRecord.setAddedCount -> void
        return;
    }

    public static void setBeforeText(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (java.lang.CharSequence)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setBeforeText(v1); // android.view.accessibility.AccessibilityRecord.setBeforeText -> void
        return;
    }

    public static void setChecked(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setChecked(v1); // android.view.accessibility.AccessibilityRecord.setChecked -> void
        return;
    }

    public static void setClassName(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (java.lang.CharSequence)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setClassName(v1); // android.view.accessibility.AccessibilityRecord.setClassName -> void
        return;
    }

    public static void setContentDescription(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (java.lang.CharSequence)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setContentDescription(v1); // android.view.accessibility.AccessibilityRecord.setContentDescription -> void
        return;
    }

    public static void setCurrentItemIndex(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setCurrentItemIndex(v1); // android.view.accessibility.AccessibilityRecord.setCurrentItemIndex -> void
        return;
    }

    public static void setEnabled(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setEnabled(v1); // android.view.accessibility.AccessibilityRecord.setEnabled -> void
        return;
    }

    public static void setFromIndex(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setFromIndex(v1); // android.view.accessibility.AccessibilityRecord.setFromIndex -> void
        return;
    }

    public static void setFullScreen(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setFullScreen(v1); // android.view.accessibility.AccessibilityRecord.setFullScreen -> void
        return;
    }

    public static void setItemCount(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setItemCount(v1); // android.view.accessibility.AccessibilityRecord.setItemCount -> void
        return;
    }

    public static void setParcelableData(java.lang.Object p0, android.os.Parcelable p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.os.Parcelable)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setParcelableData(v1); // android.view.accessibility.AccessibilityRecord.setParcelableData -> void
        return;
    }

    public static void setPassword(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setPassword(v1); // android.view.accessibility.AccessibilityRecord.setPassword -> void
        return;
    }

    public static void setRemovedCount(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setRemovedCount(v1); // android.view.accessibility.AccessibilityRecord.setRemovedCount -> void
        return;
    }

    public static void setScrollX(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setScrollX(v1); // android.view.accessibility.AccessibilityRecord.setScrollX -> void
        return;
    }

    public static void setScrollY(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setScrollY(v1); // android.view.accessibility.AccessibilityRecord.setScrollY -> void
        return;
    }

    public static void setScrollable(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setScrollable(v1); // android.view.accessibility.AccessibilityRecord.setScrollable -> void
        return;
    }

    public static void setSource(java.lang.Object p0, android.view.View p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setSource(v1); // android.view.accessibility.AccessibilityRecord.setSource -> void
        return;
    }

    public static void setToIndex(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setToIndex(v1); // android.view.accessibility.AccessibilityRecord.setToIndex -> void
        return;
    }

}