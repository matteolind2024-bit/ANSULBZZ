package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompat.java
 * Descriptor: Landroid/support/v4/view/ViewGroupCompat;
 */
public class ViewGroupCompat {
    static final android.support.v4.view.ViewGroupCompat$ViewGroupCompatImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.ViewGroupCompat$ViewGroupCompatIcsImpl;
        _result = v0.<init>(); // android.support.v4.view.ViewGroupCompat$ViewGroupCompatIcsImpl.<init> -> void
        android.support.v4.view.ViewGroupCompat.IMPL = v0; // :android.support.v4.view.ViewGroupCompat$ViewGroupCompatImpl
        return;
        v0 = new android.support.v4.view.ViewGroupCompat$ViewGroupCompatStubImpl;
        _result = v0.<init>(); // android.support.v4.view.ViewGroupCompat$ViewGroupCompatStubImpl.<init> -> void
        android.support.v4.view.ViewGroupCompat.IMPL = v0; // :android.support.v4.view.ViewGroupCompat$ViewGroupCompatImpl
        // goto L_000d
    }

    private ViewGroupCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean onRequestSendAccessibilityEvent(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v1 = p0 (android.view.ViewGroup), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.ViewGroupCompat.IMPL; // :android.support.v4.view.ViewGroupCompat$ViewGroupCompatImpl
        _result = android.support.v4.view.ViewGroupCompat$ViewGroupCompatImpl.onRequestSendAccessibilityEvent(v0, v1, v2, v3); // -> boolean
        v0 = _result;
        return v0;
    }

}