package android.support.v4.view;

/**
 * Original SourceFile: ViewCompatJB.java
 * Descriptor: Landroid/support/v4/view/ViewCompatJB;
 */
public class ViewCompatJB {
    public ViewCompatJB() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static java.lang.Object getAccessibilityNodeProvider(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        _result = v1.getAccessibilityNodeProvider(); // android.view.View.getAccessibilityNodeProvider -> android.view.accessibility.AccessibilityNodeProvider
        v0 = _result;
        return v0;
    }

    public static int getImportantForAccessibility(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        _result = v1.getImportantForAccessibility(); // android.view.View.getImportantForAccessibility -> int
        v0 = _result;
        return v0;
    }

    public static boolean hasTransientState(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        _result = v1.hasTransientState(); // android.view.View.hasTransientState -> boolean
        v0 = _result;
        return v0;
    }

    public static void postInvalidateOnAnimation(android.view.View p0) {
        // Registers (1 total): v0 = p0 (android.view.View)
        _result = v0.postInvalidateOnAnimation(); // android.view.View.postInvalidateOnAnimation -> void
        return;
    }

    public static void postInvalidateOnAnimation(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (5 total): v0 = p0 (android.view.View), v1 = p1 (int), v2 = p2 (int), v3 = p3 (int), v4 = p4 (int)
        _result = v0.postInvalidate(v1, v2, v3, v4); // android.view.View.postInvalidate -> void
        return;
    }

    public static void postOnAnimation(android.view.View p0, java.lang.Runnable p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (java.lang.Runnable)
        _result = v0.postOnAnimation(v1); // android.view.View.postOnAnimation -> void
        return;
    }

    public static void postOnAnimationDelayed(android.view.View p0, java.lang.Runnable p1, long p2) {
        // Registers (4 total): v0 = p0 (android.view.View), v1 = p1 (java.lang.Runnable), v2 = p2 (long)
        _result = v0.postOnAnimationDelayed(v1, v2, v3); // android.view.View.postOnAnimationDelayed -> void
        return;
    }

    public static void setHasTransientState(android.view.View p0, boolean p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (boolean)
        _result = v0.setHasTransientState(v1); // android.view.View.setHasTransientState -> void
        return;
    }

    public static void setImportantForAccessibility(android.view.View p0, int p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (int)
        _result = v0.setImportantForAccessibility(v1); // android.view.View.setImportantForAccessibility -> void
        return;
    }

}