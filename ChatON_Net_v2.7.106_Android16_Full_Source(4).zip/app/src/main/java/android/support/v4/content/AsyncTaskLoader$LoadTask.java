package android.support.v4.content;

/**
 * Original SourceFile: AsyncTaskLoader.java
 * Descriptor: Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
 */
final class AsyncTaskLoader$LoadTask extends android.support.v4.content.ModernAsyncTask implements java.lang.Runnable {
    private java.util.concurrent.CountDownLatch done;
     java.lang.Object result;
    final android.support.v4.content.AsyncTaskLoader this$0;
     boolean waiting;

    AsyncTaskLoader$LoadTask(android.support.v4.content.AsyncTaskLoader p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.content.AsyncTaskLoader)
        v2.this$0 = v3; // android.support.v4.content.AsyncTaskLoader$LoadTask.this$0:android.support.v4.content.AsyncTaskLoader
        _result = v2.<init>(); // android.support.v4.content.ModernAsyncTask.<init> -> void
        v0 = new java.util.concurrent.CountDownLatch;
        v1 = 1;
        _result = v0.<init>(v1); // java.util.concurrent.CountDownLatch.<init> -> void
        v2.done = v0; // android.support.v4.content.AsyncTaskLoader$LoadTask.done:java.util.concurrent.CountDownLatch
        return;
    }

    static java.util.concurrent.CountDownLatch access$000(android.support.v4.content.AsyncTaskLoader$LoadTask p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.content.AsyncTaskLoader$LoadTask)
        v0 = v1.done; // android.support.v4.content.AsyncTaskLoader$LoadTask.done:java.util.concurrent.CountDownLatch
        return v0;
    }

    protected java.lang.Object doInBackground(java.lang.Object[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object[])
        v2 = (java.lang.Void[]) v2;
        _result = v1.doInBackground(v2); // android.support.v4.content.AsyncTaskLoader$LoadTask.doInBackground -> java.lang.Object
        v0 = _result;
        return v0;
    }

    protected java.lang.Object doInBackground(java.lang.Void[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Void[])
        v0 = v1.this$0; // android.support.v4.content.AsyncTaskLoader$LoadTask.this$0:android.support.v4.content.AsyncTaskLoader
        _result = v0.onLoadInBackground(); // android.support.v4.content.AsyncTaskLoader.onLoadInBackground -> java.lang.Object
        v0 = _result;
        v1.result = v0; // android.support.v4.content.AsyncTaskLoader$LoadTask.result:java.lang.Object
        v0 = v1.result; // android.support.v4.content.AsyncTaskLoader$LoadTask.result:java.lang.Object
        return v0;
    }

    protected void onCancelled() {
        // Registers (3 total): v2 = this
        v0 = v2.this$0; // android.support.v4.content.AsyncTaskLoader$LoadTask.this$0:android.support.v4.content.AsyncTaskLoader
        v1 = v2.result; // android.support.v4.content.AsyncTaskLoader$LoadTask.result:java.lang.Object
        _result = v0.dispatchOnCancelled(v2, v1); // android.support.v4.content.AsyncTaskLoader.dispatchOnCancelled -> void
        v0 = v2.done; // android.support.v4.content.AsyncTaskLoader$LoadTask.done:java.util.concurrent.CountDownLatch
        _result = v0.countDown(); // java.util.concurrent.CountDownLatch.countDown -> void
        return;
        v0 = _exception;
        v1 = v2.done; // android.support.v4.content.AsyncTaskLoader$LoadTask.done:java.util.concurrent.CountDownLatch
        _result = v1.countDown(); // java.util.concurrent.CountDownLatch.countDown -> void
        throw v0;
    }

    protected void onPostExecute(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v0 = v2.this$0; // android.support.v4.content.AsyncTaskLoader$LoadTask.this$0:android.support.v4.content.AsyncTaskLoader
        _result = v0.dispatchOnLoadComplete(v2, v3); // android.support.v4.content.AsyncTaskLoader.dispatchOnLoadComplete -> void
        v0 = v2.done; // android.support.v4.content.AsyncTaskLoader$LoadTask.done:java.util.concurrent.CountDownLatch
        _result = v0.countDown(); // java.util.concurrent.CountDownLatch.countDown -> void
        return;
        v0 = _exception;
        v1 = v2.done; // android.support.v4.content.AsyncTaskLoader$LoadTask.done:java.util.concurrent.CountDownLatch
        _result = v1.countDown(); // java.util.concurrent.CountDownLatch.countDown -> void
        throw v0;
    }

    public void run() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.waiting = v0; // android.support.v4.content.AsyncTaskLoader$LoadTask.waiting:boolean
        v0 = v1.this$0; // android.support.v4.content.AsyncTaskLoader$LoadTask.this$0:android.support.v4.content.AsyncTaskLoader
        _result = v0.executePendingTask(); // android.support.v4.content.AsyncTaskLoader.executePendingTask -> void
        return;
    }

}