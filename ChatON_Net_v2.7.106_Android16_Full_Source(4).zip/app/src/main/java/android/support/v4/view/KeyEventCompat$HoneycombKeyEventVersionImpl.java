package android.support.v4.view;

/**
 * Original SourceFile: KeyEventCompat.java
 * Descriptor: Landroid/support/v4/view/KeyEventCompat$HoneycombKeyEventVersionImpl;
 */
class KeyEventCompat$HoneycombKeyEventVersionImpl implements android.support.v4.view.KeyEventCompat$KeyEventVersionImpl {
    KeyEventCompat$HoneycombKeyEventVersionImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean metaStateHasModifiers(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        _result = v2.metaStateHasModifiers(v3); // android.support.v4.view.KeyEventCompatHoneycomb.metaStateHasModifiers -> boolean
        v0 = _result;
        return v0;
    }

    public boolean metaStateHasNoModifiers(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v2.metaStateHasNoModifiers(); // android.support.v4.view.KeyEventCompatHoneycomb.metaStateHasNoModifiers -> boolean
        v0 = _result;
        return v0;
    }

    public int normalizeMetaState(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v2.normalizeMetaState(); // android.support.v4.view.KeyEventCompatHoneycomb.normalizeMetaState -> int
        v0 = _result;
        return v0;
    }

}