package android.support.v4.view;

/**
 * Original SourceFile: MenuItemCompat.java
 * Descriptor: Landroid/support/v4/view/MenuItemCompat$HoneycombMenuVersionImpl;
 */
class MenuItemCompat$HoneycombMenuVersionImpl implements android.support.v4.view.MenuItemCompat$MenuVersionImpl {
    MenuItemCompat$HoneycombMenuVersionImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.view.MenuItem setActionView(android.view.MenuItem p0, android.view.View p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MenuItem), v3 = p1 (android.view.View)
        _result = v2.setActionView(v3); // android.support.v4.view.MenuItemCompatHoneycomb.setActionView -> android.view.MenuItem
        v0 = _result;
        return v0;
    }

    public boolean setShowAsAction(android.view.MenuItem p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MenuItem), v3 = p1 (int)
        _result = v2.setShowAsAction(v3); // android.support.v4.view.MenuItemCompatHoneycomb.setShowAsAction -> void
        v0 = 1;
        return v0;
    }

}