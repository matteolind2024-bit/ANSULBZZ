package android.support.v4.app;

/**
 * Original SourceFile: FragmentTransaction.java
 * Descriptor: Landroid/support/v4/app/FragmentTransaction;
 */
public abstract class FragmentTransaction {
    public static final int TRANSIT_ENTER_MASK;
    public static final int TRANSIT_EXIT_MASK;
    public static final int TRANSIT_FRAGMENT_CLOSE;
    public static final int TRANSIT_FRAGMENT_FADE;
    public static final int TRANSIT_FRAGMENT_OPEN;
    public static final int TRANSIT_NONE;
    public static final int TRANSIT_UNSET;

    public FragmentTransaction() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public abstract android.support.v4.app.FragmentTransaction add(int p0, android.support.v4.app.Fragment p1);
    public abstract android.support.v4.app.FragmentTransaction add(int p0, android.support.v4.app.Fragment p1, java.lang.String p2);
    public abstract android.support.v4.app.FragmentTransaction add(android.support.v4.app.Fragment p0, java.lang.String p1);
    public abstract android.support.v4.app.FragmentTransaction addToBackStack(java.lang.String p0);
    public abstract android.support.v4.app.FragmentTransaction attach(android.support.v4.app.Fragment p0);
    public abstract int commit();
    public abstract int commitAllowingStateLoss();
    public abstract android.support.v4.app.FragmentTransaction detach(android.support.v4.app.Fragment p0);
    public abstract android.support.v4.app.FragmentTransaction disallowAddToBackStack();
    public abstract android.support.v4.app.FragmentTransaction hide(android.support.v4.app.Fragment p0);
    public abstract boolean isAddToBackStackAllowed();
    public abstract boolean isEmpty();
    public abstract android.support.v4.app.FragmentTransaction remove(android.support.v4.app.Fragment p0);
    public abstract android.support.v4.app.FragmentTransaction replace(int p0, android.support.v4.app.Fragment p1);
    public abstract android.support.v4.app.FragmentTransaction replace(int p0, android.support.v4.app.Fragment p1, java.lang.String p2);
    public abstract android.support.v4.app.FragmentTransaction setBreadCrumbShortTitle(int p0);
    public abstract android.support.v4.app.FragmentTransaction setBreadCrumbShortTitle(java.lang.CharSequence p0);
    public abstract android.support.v4.app.FragmentTransaction setBreadCrumbTitle(int p0);
    public abstract android.support.v4.app.FragmentTransaction setBreadCrumbTitle(java.lang.CharSequence p0);
    public abstract android.support.v4.app.FragmentTransaction setCustomAnimations(int p0, int p1);
    public abstract android.support.v4.app.FragmentTransaction setCustomAnimations(int p0, int p1, int p2, int p3);
    public abstract android.support.v4.app.FragmentTransaction setTransition(int p0);
    public abstract android.support.v4.app.FragmentTransaction setTransitionStyle(int p0);
    public abstract android.support.v4.app.FragmentTransaction show(android.support.v4.app.Fragment p0);
}