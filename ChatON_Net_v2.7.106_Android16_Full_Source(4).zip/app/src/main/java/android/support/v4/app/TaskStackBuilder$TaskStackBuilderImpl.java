package android.support.v4.app;

/**
 * Original SourceFile: TaskStackBuilder.java
 * Descriptor: Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImpl;
 */
interface TaskStackBuilder$TaskStackBuilderImpl {
    public abstract android.app.PendingIntent getPendingIntent(android.content.Context p0, android.content.Intent[] p1, int p2, int p3, android.os.Bundle p4);
}