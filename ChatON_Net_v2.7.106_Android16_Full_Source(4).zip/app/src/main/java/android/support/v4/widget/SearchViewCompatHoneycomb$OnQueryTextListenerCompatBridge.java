package android.support.v4.widget;

/**
 * Original SourceFile: SearchViewCompatHoneycomb.java
 * Descriptor: Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;
 */
interface SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge {
    public abstract boolean onQueryTextChange(java.lang.String p0);
    public abstract boolean onQueryTextSubmit(java.lang.String p0);
}