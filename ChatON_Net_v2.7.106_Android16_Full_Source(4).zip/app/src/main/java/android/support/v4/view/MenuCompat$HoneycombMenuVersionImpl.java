package android.support.v4.view;

/**
 * Original SourceFile: MenuCompat.java
 * Descriptor: Landroid/support/v4/view/MenuCompat$HoneycombMenuVersionImpl;
 */
class MenuCompat$HoneycombMenuVersionImpl implements android.support.v4.view.MenuCompat$MenuVersionImpl {
    MenuCompat$HoneycombMenuVersionImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean setShowAsAction(android.view.MenuItem p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MenuItem), v3 = p1 (int)
        _result = v2.setShowAsAction(v3); // android.support.v4.view.MenuItemCompatHoneycomb.setShowAsAction -> void
        v0 = 1;
        return v0;
    }

}