package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$SavedState$1;
 */
final class ViewPager$SavedState$1 implements android.support.v4.os.ParcelableCompatCreatorCallbacks {
    ViewPager$SavedState$1() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.support.v4.view.ViewPager$SavedState createFromParcel(android.os.Parcel p0, java.lang.ClassLoader p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (java.lang.ClassLoader)
        v0 = new android.support.v4.view.ViewPager$SavedState;
        _result = v0.<init>(v2, v3); // android.support.v4.view.ViewPager$SavedState.<init> -> void
        return v0;
    }

    public java.lang.Object createFromParcel(android.os.Parcel p0, java.lang.ClassLoader p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (java.lang.ClassLoader)
        _result = v1.createFromParcel(v2, v3); // android.support.v4.view.ViewPager$SavedState$1.createFromParcel -> android.support.v4.view.ViewPager$SavedState
        v0 = _result;
        return v0;
    }

    public android.support.v4.view.ViewPager$SavedState[] newArray(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = new android.support.v4.view.ViewPager$SavedState[][size=v2];
        return v0;
    }

    public java.lang.Object[] newArray(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.newArray(v2); // android.support.v4.view.ViewPager$SavedState$1.newArray -> android.support.v4.view.ViewPager$SavedState[]
        v0 = _result;
        return v0;
    }

}