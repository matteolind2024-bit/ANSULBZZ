package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityNodeInfoCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanImpl;
 */
class AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanImpl extends android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoIcsImpl {
    AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanImpl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoIcsImpl.<init> -> void
        return;
    }

    public void addChild(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (int)
        _result = v1.addChild(v2, v3); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.addChild -> void
        return;
    }

    public java.lang.Object findFocus(java.lang.Object p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (int)
        _result = v2.findFocus(v3); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.findFocus -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object focusSearch(java.lang.Object p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (int)
        _result = v2.focusSearch(v3); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.focusSearch -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public int getMovementGranularities(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.getMovementGranularities(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.getMovementGranularities -> int
        v0 = _result;
        return v0;
    }

    public boolean isAccessibilityFocused(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isAccessibilityFocused(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.isAccessibilityFocused -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isVisibleToUser(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.isVisibleToUser(); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.isVisibleToUser -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.Object obtain(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        _result = v2.obtain(v3); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.obtain -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public boolean performAction(java.lang.Object p0, int p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (int), v4 = p2 (android.os.Bundle)
        _result = v2.performAction(v3, v4); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.performAction -> boolean
        v0 = _result;
        return v0;
    }

    public void setAccessibilityFocused(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setAccesibilityFocused(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.setAccesibilityFocused -> void
        return;
    }

    public void setMovementGranularities(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.setMovementGranularities(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.setMovementGranularities -> void
        return;
    }

    public void setParent(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (int)
        _result = v1.setParent(v2, v3); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.setParent -> void
        return;
    }

    public void setSource(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (int)
        _result = v1.setSource(v2, v3); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.setSource -> void
        return;
    }

    public void setVisibleToUser(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.setVisibleToUser(v2); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompatJellyBean.setVisibleToUser -> void
        return;
    }

}