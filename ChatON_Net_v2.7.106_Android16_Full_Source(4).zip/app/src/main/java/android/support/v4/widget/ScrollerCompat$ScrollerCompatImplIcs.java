package android.support.v4.widget;

/**
 * Original SourceFile: ScrollerCompat.java
 * Descriptor: Landroid/support/v4/widget/ScrollerCompat$ScrollerCompatImplIcs;
 */
class ScrollerCompat$ScrollerCompatImplIcs extends android.support.v4.widget.ScrollerCompat {
    public ScrollerCompat$ScrollerCompatImplIcs(android.content.Context p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.content.Context)
        _result = v0.<init>(v1); // android.support.v4.widget.ScrollerCompat.<init> -> void
        return;
    }

    public float getCurrVelocity() {
        // Registers (2 total): v1 = this
        v0 = v1.mScroller; // android.support.v4.widget.ScrollerCompat$ScrollerCompatImplIcs.mScroller:android.widget.Scroller
        _result = v0.getCurrVelocity(); // android.support.v4.widget.ScrollerCompatIcs.getCurrVelocity -> float
        v0 = _result;
        return v0;
    }

}