package android.support.v4.app;

/**
 * Original SourceFile: ServiceCompat.java
 * Descriptor: Landroid/support/v4/app/ServiceCompat;
 */
public class ServiceCompat {
    public static final int START_STICKY;

    private ServiceCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}