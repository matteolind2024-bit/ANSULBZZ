package android.support.v4.content;

/**
 * Original SourceFile: ContextCompatJellybean.java
 * Descriptor: Landroid/support/v4/content/ContextCompatJellybean;
 */
class ContextCompatJellybean {
    ContextCompatJellybean() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void startActivities(android.content.Context p0, android.content.Intent[] p1, android.os.Bundle p2) {
        // Registers (3 total): v0 = p0 (android.content.Context), v1 = p1 (android.content.Intent[]), v2 = p2 (android.os.Bundle)
        _result = v0.startActivities(v1, v2); // android.content.Context.startActivities -> void
        return;
    }

}