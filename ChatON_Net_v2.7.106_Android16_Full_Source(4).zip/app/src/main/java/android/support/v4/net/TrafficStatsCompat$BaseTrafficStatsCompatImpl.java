package android.support.v4.net;

/**
 * Original SourceFile: TrafficStatsCompat.java
 * Descriptor: Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl;
 */
class TrafficStatsCompat$BaseTrafficStatsCompatImpl implements android.support.v4.net.TrafficStatsCompat$TrafficStatsCompatImpl {
    private java.lang.ThreadLocal mThreadSocketTags;

    TrafficStatsCompat$BaseTrafficStatsCompatImpl() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$1;
        _result = v0.<init>(v1); // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$1.<init> -> void
        v1.mThreadSocketTags = v0; // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl.mThreadSocketTags:java.lang.ThreadLocal
        return;
    }

    public void clearThreadStatsTag() {
        // Registers (3 total): v2 = this
        v0 = v2.mThreadSocketTags; // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl.mThreadSocketTags:java.lang.ThreadLocal
        _result = v0.get(); // java.lang.ThreadLocal.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags) v0;
        v1 = -1;
        v0.statsTag = v1; // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags.statsTag:int
        return;
    }

    public int getThreadStatsTag() {
        // Registers (2 total): v1 = this
        v0 = v1.mThreadSocketTags; // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl.mThreadSocketTags:java.lang.ThreadLocal
        _result = v0.get(); // java.lang.ThreadLocal.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags) v0;
        v0 = v0.statsTag; // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags.statsTag:int
        return v0;
    }

    public void incrementOperationCount(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        return;
    }

    public void incrementOperationCount(int p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (int), v2 = p1 (int)
        return;
    }

    public void setThreadStatsTag(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mThreadSocketTags; // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl.mThreadSocketTags:java.lang.ThreadLocal
        _result = v0.get(); // java.lang.ThreadLocal.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags) v0;
        v0.statsTag = v2; // android.support.v4.net.TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags.statsTag:int
        return;
    }

    public void tagSocket(java.net.Socket p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.net.Socket)
        return;
    }

    public void untagSocket(java.net.Socket p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.net.Socket)
        return;
    }

}