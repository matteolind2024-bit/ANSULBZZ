package android.support.v4.app;

/**
 * Original SourceFile: ShareCompat.java
 * Descriptor: Landroid/support/v4/app/ShareCompat;
 */
public class ShareCompat {
    public static final java.lang.String EXTRA_CALLING_ACTIVITY;
    public static final java.lang.String EXTRA_CALLING_PACKAGE;
    private static android.support.v4.app.ShareCompat$ShareCompatImpl IMPL;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.app.ShareCompat$ShareCompatImplJB;
        _result = v0.<init>(); // android.support.v4.app.ShareCompat$ShareCompatImplJB.<init> -> void
        android.support.v4.app.ShareCompat.IMPL = v0; // :android.support.v4.app.ShareCompat$ShareCompatImpl
        return;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_001c */;
        v0 = new android.support.v4.app.ShareCompat$ShareCompatImplICS;
        _result = v0.<init>(); // android.support.v4.app.ShareCompat$ShareCompatImplICS.<init> -> void
        android.support.v4.app.ShareCompat.IMPL = v0; // :android.support.v4.app.ShareCompat$ShareCompatImpl
        // goto L_000d
        v0 = new android.support.v4.app.ShareCompat$ShareCompatImplBase;
        _result = v0.<init>(); // android.support.v4.app.ShareCompat$ShareCompatImplBase.<init> -> void
        android.support.v4.app.ShareCompat.IMPL = v0; // :android.support.v4.app.ShareCompat$ShareCompatImpl
        // goto L_000d
    }

    public ShareCompat() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    static android.support.v4.app.ShareCompat$ShareCompatImpl access$000() {
        v0 = android.support.v4.app.ShareCompat.IMPL; // :android.support.v4.app.ShareCompat$ShareCompatImpl
        return v0;
    }

    public static void configureMenuItem(android.view.Menu p0, int p1, android.support.v4.app.ShareCompat$IntentBuilder p2) {
        // Registers (6 total): v3 = p0 (android.view.Menu), v4 = p1 (int), v5 = p2 (android.support.v4.app.ShareCompat$IntentBuilder)
        _result = android.view.Menu.findItem(v3, v4); // -> android.view.MenuItem
        v0 = _result;
        if (v0 != 0) /* goto L_0025 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Could not find menu item with id ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " in the supplied menu";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = v0.configureMenuItem(v5); // android.support.v4.app.ShareCompat.configureMenuItem -> void
        return;
    }

    public static void configureMenuItem(android.view.MenuItem p0, android.support.v4.app.ShareCompat$IntentBuilder p1) {
        // Registers (3 total): v1 = p0 (android.view.MenuItem), v2 = p1 (android.support.v4.app.ShareCompat$IntentBuilder)
        v0 = android.support.v4.app.ShareCompat.IMPL; // :android.support.v4.app.ShareCompat$ShareCompatImpl
        _result = android.support.v4.app.ShareCompat$ShareCompatImpl.configureMenuItem(v0, v1, v2); // -> void
        return;
    }

    public static android.content.ComponentName getCallingActivity(android.app.Activity p0) {
        // Registers (3 total): v2 = p0 (android.app.Activity)
        _result = v2.getCallingActivity(); // android.app.Activity.getCallingActivity -> android.content.ComponentName
        v0 = _result;
        if (v0 != 0) /* goto L_0012 */;
        _result = v2.getIntent(); // android.app.Activity.getIntent -> android.content.Intent
        v0 = _result;
        v1 = "android.support.v4.app.EXTRA_CALLING_ACTIVITY";
        _result = v0.getParcelableExtra(v1); // android.content.Intent.getParcelableExtra -> android.os.Parcelable
        v0 = _result;
        v0 = (android.content.ComponentName) v0;
        return v0;
    }

    public static java.lang.String getCallingPackage(android.app.Activity p0) {
        // Registers (3 total): v2 = p0 (android.app.Activity)
        _result = v2.getCallingPackage(); // android.app.Activity.getCallingPackage -> java.lang.String
        v0 = _result;
        if (v0 != 0) /* goto L_0010 */;
        _result = v2.getIntent(); // android.app.Activity.getIntent -> android.content.Intent
        v0 = _result;
        v1 = "android.support.v4.app.EXTRA_CALLING_PACKAGE";
        _result = v0.getStringExtra(v1); // android.content.Intent.getStringExtra -> java.lang.String
        v0 = _result;
        return v0;
    }

}