package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompat.java
 * Descriptor: Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1;
 */
class AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1 implements android.support.v4.view.AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean {
    final android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl this$0;
    final android.support.v4.view.AccessibilityDelegateCompat val$compat;

    AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1(android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl p0, android.support.v4.view.AccessibilityDelegateCompat p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl), v2 = p1 (android.support.v4.view.AccessibilityDelegateCompat)
        v0.this$0 = v1; // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.this$0:android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl
        v0.val$compat = v2; // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.val$compat:android.support.v4.view.AccessibilityDelegateCompat
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean dispatchPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$compat; // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.val$compat:android.support.v4.view.AccessibilityDelegateCompat
        _result = v0.dispatchPopulateAccessibilityEvent(v2, v3); // android.support.v4.view.AccessibilityDelegateCompat.dispatchPopulateAccessibilityEvent -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.Object getAccessibilityNodeProvider(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = v1.val$compat; // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.val$compat:android.support.v4.view.AccessibilityDelegateCompat
        _result = v0.getAccessibilityNodeProvider(v2); // android.support.v4.view.AccessibilityDelegateCompat.getAccessibilityNodeProvider -> android.support.v4.view.accessibility.AccessibilityNodeProviderCompat
        v0 = _result;
        if (v0 == 0) /* goto L_000d */;
        _result = v0.getProvider(); // android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.getProvider -> java.lang.Object
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_000c
    }

    public void onInitializeAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$compat; // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.val$compat:android.support.v4.view.AccessibilityDelegateCompat
        _result = v0.onInitializeAccessibilityEvent(v2, v3); // android.support.v4.view.AccessibilityDelegateCompat.onInitializeAccessibilityEvent -> void
        return;
    }

    public void onInitializeAccessibilityNodeInfo(android.view.View p0, java.lang.Object p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (java.lang.Object)
        v0 = v2.val$compat; // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.val$compat:android.support.v4.view.AccessibilityDelegateCompat
        v1 = new android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
        _result = v1.<init>(v4); // android.support.v4.view.accessibility.AccessibilityNodeInfoCompat.<init> -> void
        _result = v0.onInitializeAccessibilityNodeInfo(v3, v1); // android.support.v4.view.AccessibilityDelegateCompat.onInitializeAccessibilityNodeInfo -> void
        return;
    }

    public void onPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$compat; // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.val$compat:android.support.v4.view.AccessibilityDelegateCompat
        _result = v0.onPopulateAccessibilityEvent(v2, v3); // android.support.v4.view.AccessibilityDelegateCompat.onPopulateAccessibilityEvent -> void
        return;
    }

    public boolean onRequestSendAccessibilityEvent(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (android.view.View), v4 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$compat; // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.val$compat:android.support.v4.view.AccessibilityDelegateCompat
        _result = v0.onRequestSendAccessibilityEvent(v2, v3, v4); // android.support.v4.view.AccessibilityDelegateCompat.onRequestSendAccessibilityEvent -> boolean
        v0 = _result;
        return v0;
    }

    public boolean performAccessibilityAction(android.view.View p0, int p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int), v4 = p2 (android.os.Bundle)
        v0 = v1.val$compat; // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.val$compat:android.support.v4.view.AccessibilityDelegateCompat
        _result = v0.performAccessibilityAction(v2, v3, v4); // android.support.v4.view.AccessibilityDelegateCompat.performAccessibilityAction -> boolean
        v0 = _result;
        return v0;
    }

    public void sendAccessibilityEvent(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        v0 = v1.val$compat; // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.val$compat:android.support.v4.view.AccessibilityDelegateCompat
        _result = v0.sendAccessibilityEvent(v2, v3); // android.support.v4.view.AccessibilityDelegateCompat.sendAccessibilityEvent -> void
        return;
    }

    public void sendAccessibilityEventUnchecked(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.val$compat; // android.support.v4.view.AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl$1.val$compat:android.support.v4.view.AccessibilityDelegateCompat
        _result = v0.sendAccessibilityEventUnchecked(v2, v3); // android.support.v4.view.AccessibilityDelegateCompat.sendAccessibilityEventUnchecked -> void
        return;
    }

}