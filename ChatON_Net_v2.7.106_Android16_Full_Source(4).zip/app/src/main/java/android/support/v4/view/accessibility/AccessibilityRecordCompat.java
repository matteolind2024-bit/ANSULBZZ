package android.support.v4.view.accessibility;

/**
 * Original SourceFile: AccessibilityRecordCompat.java
 * Descriptor: Landroid/support/v4/view/accessibility/AccessibilityRecordCompat;
 */
public class AccessibilityRecordCompat {
    private static final android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl IMPL;
    private final java.lang.Object mRecord;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordJellyBeanImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordJellyBeanImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        return;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 15;
        if (v0 < v1) /* goto L_001c */;
        v0 = new android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordIcsMr1Impl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordIcsMr1Impl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        // goto L_000d
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_002a */;
        v0 = new android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordIcsImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordIcsImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        // goto L_000d
        v0 = new android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordStubImpl;
        _result = v0.<init>(); // android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordStubImpl.<init> -> void
        android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL = v0; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        // goto L_000d
    }

    public AccessibilityRecordCompat(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.mRecord = v1; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        return;
    }

    public static android.support.v4.view.accessibility.AccessibilityRecordCompat obtain() {
        v0 = new android.support.v4.view.accessibility.AccessibilityRecordCompat;
        v1 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.obtain(v1); // -> java.lang.Object
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.view.accessibility.AccessibilityRecordCompat.<init> -> void
        return v0;
    }

    public static android.support.v4.view.accessibility.AccessibilityRecordCompat obtain(android.support.v4.view.accessibility.AccessibilityRecordCompat p0) {
        // Registers (4 total): v3 = p0 (android.support.v4.view.accessibility.AccessibilityRecordCompat)
        v0 = new android.support.v4.view.accessibility.AccessibilityRecordCompat;
        v1 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v2 = v3.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.obtain(v1, v2); // -> java.lang.Object
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.view.accessibility.AccessibilityRecordCompat.<init> -> void
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        if (v5 != 0) /* goto L_0009 */;
        v0 = v1;
        // goto L_0004
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0015 */;
        v0 = v1;
        // goto L_0004
        v5 = (android.support.v4.view.accessibility.AccessibilityRecordCompat) v5;
        v2 = v4.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        if (v2 != 0) /* goto L_0021 */;
        v2 = v5.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        if (v2 == 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v4.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        v3 = v5.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public int getAddedCount() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getAddedCount(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getBeforeText() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getBeforeText(v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getClassName() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getClassName(v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence getContentDescription() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getContentDescription(v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public int getCurrentItemIndex() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getCurrentItemIndex(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int getFromIndex() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getFromIndex(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public java.lang.Object getImpl() {
        // Registers (2 total): v1 = this
        v0 = v1.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        return v0;
    }

    public int getItemCount() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getItemCount(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int getMaxScrollX() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getMaxScrollX(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int getMaxScrollY() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getMaxScrollY(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public android.os.Parcelable getParcelableData() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getParcelableData(v0, v1); // -> android.os.Parcelable
        v0 = _result;
        return v0;
    }

    public int getRemovedCount() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getRemovedCount(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int getScrollX() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getScrollX(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int getScrollY() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getScrollY(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public android.support.v4.view.accessibility.AccessibilityNodeInfoCompat getSource() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getSource(v0, v1); // -> android.support.v4.view.accessibility.AccessibilityNodeInfoCompat
        v0 = _result;
        return v0;
    }

    public java.util.List getText() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getText(v0, v1); // -> java.util.List
        v0 = _result;
        return v0;
    }

    public int getToIndex() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getToIndex(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int getWindowId() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.getWindowId(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int hashCode() {
        // Registers (2 total): v1 = this
        v0 = v1.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        if (v0 != 0) /* goto L_0006 */;
        v0 = 0;
        return v0;
        v0 = v1.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        // goto L_0005
    }

    public boolean isChecked() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.isChecked(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isEnabled() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.isEnabled(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isFullScreen() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.isFullScreen(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isPassword() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.isPassword(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isScrollable() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.isScrollable(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public void recycle() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.recycle(v0, v1); // -> void
        return;
    }

    public void setAddedCount(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setAddedCount(v0, v1, v3); // -> void
        return;
    }

    public void setBeforeText(java.lang.CharSequence p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.CharSequence)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setBeforeText(v0, v1, v3); // -> void
        return;
    }

    public void setChecked(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setChecked(v0, v1, v3); // -> void
        return;
    }

    public void setClassName(java.lang.CharSequence p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.CharSequence)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setClassName(v0, v1, v3); // -> void
        return;
    }

    public void setContentDescription(java.lang.CharSequence p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.CharSequence)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setContentDescription(v0, v1, v3); // -> void
        return;
    }

    public void setCurrentItemIndex(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setCurrentItemIndex(v0, v1, v3); // -> void
        return;
    }

    public void setEnabled(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setEnabled(v0, v1, v3); // -> void
        return;
    }

    public void setFromIndex(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setFromIndex(v0, v1, v3); // -> void
        return;
    }

    public void setFullScreen(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setFullScreen(v0, v1, v3); // -> void
        return;
    }

    public void setItemCount(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setItemCount(v0, v1, v3); // -> void
        return;
    }

    public void setMaxScrollX(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setMaxScrollX(v0, v1, v3); // -> void
        return;
    }

    public void setMaxScrollY(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setMaxScrollY(v0, v1, v3); // -> void
        return;
    }

    public void setParcelableData(android.os.Parcelable p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Parcelable)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setParcelableData(v0, v1, v3); // -> void
        return;
    }

    public void setPassword(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setPassword(v0, v1, v3); // -> void
        return;
    }

    public void setRemovedCount(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setRemovedCount(v0, v1, v3); // -> void
        return;
    }

    public void setScrollX(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setScrollX(v0, v1, v3); // -> void
        return;
    }

    public void setScrollY(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setScrollY(v0, v1, v3); // -> void
        return;
    }

    public void setScrollable(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setScrollable(v0, v1, v3); // -> void
        return;
    }

    public void setSource(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setSource(v0, v1, v3); // -> void
        return;
    }

    public void setSource(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setSource(v0, v1, v3, v4); // -> void
        return;
    }

    public void setToIndex(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.accessibility.AccessibilityRecordCompat.IMPL; // :android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl
        v1 = v2.mRecord; // android.support.v4.view.accessibility.AccessibilityRecordCompat.mRecord:java.lang.Object
        _result = android.support.v4.view.accessibility.AccessibilityRecordCompat$AccessibilityRecordImpl.setToIndex(v0, v1, v3); // -> void
        return;
    }

}