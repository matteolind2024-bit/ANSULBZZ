package android.os;

/**
 * Original SourceFile: ServiceManager.java
 * Descriptor: Landroid/os/ServiceManager;
 */
public final class ServiceManager {
    private static final java.lang.String TAG;
    private static java.util.HashMap sCache;
    private static android.os.IServiceManager sServiceManager;

    static {
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        android.os.ServiceManager.sCache = v0; // :java.util.HashMap
        return;
    }

    public ServiceManager() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static void addService(java.lang.String p0, android.os.IBinder p1) {
        // Registers (5 total): v3 = p0 (java.lang.String), v4 = p1 (android.os.IBinder)
        _result = this.getIServiceManager(); // android.os.ServiceManager.getIServiceManager -> android.os.IServiceManager
        v0 = _result;
        _result = android.os.IServiceManager.addService(v0, v3, v4); // -> void
        return;
        v0 = _exception;
        v1 = "ServiceManager";
        v2 = "error in addService";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_0007
    }

    public static android.os.IBinder checkService(java.lang.String p0) {
        // Registers (4 total): v3 = p0 (java.lang.String)
        v0 = android.os.ServiceManager.sCache; // :java.util.HashMap
        _result = v0.get(v3); // java.util.HashMap.get -> java.lang.Object
        v0 = _result;
        v0 = (android.os.IBinder) v0;
        if (v0 == 0) /* goto L_000b */;
        return v0;
        _result = this.getIServiceManager(); // android.os.ServiceManager.getIServiceManager -> android.os.IServiceManager
        v0 = _result;
        _result = android.os.IServiceManager.checkService(v0, v3); // -> android.os.IBinder
        v0 = _result;
        // goto L_000a
        v0 = _exception;
        v1 = "ServiceManager";
        v2 = "error in checkService";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        v0 = 0;
        // goto L_000a
    }

    private static android.os.IServiceManager getIServiceManager() {
        v0 = android.os.ServiceManager.sServiceManager; // :android.os.IServiceManager
        if (v0 == 0) /* goto L_0007 */;
        v0 = android.os.ServiceManager.sServiceManager; // :android.os.IServiceManager
        return v0;
        _result = this.getContextObject(); // com.android.internal.os.BinderInternal.getContextObject -> android.os.IBinder
        v0 = _result;
        _result = v0.asInterface(); // android.os.ServiceManagerNative.asInterface -> android.os.IServiceManager
        v0 = _result;
        android.os.ServiceManager.sServiceManager = v0; // :android.os.IServiceManager
        v0 = android.os.ServiceManager.sServiceManager; // :android.os.IServiceManager
        // goto L_0006
    }

    public static android.os.IBinder getService(java.lang.String p0) {
        // Registers (4 total): v3 = p0 (java.lang.String)
        v0 = android.os.ServiceManager.sCache; // :java.util.HashMap
        _result = v0.get(v3); // java.util.HashMap.get -> java.lang.Object
        v0 = _result;
        v0 = (android.os.IBinder) v0;
        if (v0 == 0) /* goto L_000b */;
        return v0;
        _result = this.getIServiceManager(); // android.os.ServiceManager.getIServiceManager -> android.os.IServiceManager
        v0 = _result;
        _result = android.os.IServiceManager.getService(v0, v3); // -> android.os.IBinder
        v0 = _result;
        // goto L_000a
        v0 = _exception;
        v1 = "ServiceManager";
        v2 = "error in getService";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        v0 = 0;
        // goto L_000a
    }

    public static void initServiceCache(java.util.Map p0) {
        // Registers (3 total): v2 = p0 (java.util.Map)
        v0 = android.os.ServiceManager.sCache; // :java.util.HashMap
        _result = v0.size(); // java.util.HashMap.size -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0016 */;
        _result = this.supportsProcesses(); // android.os.Process.supportsProcesses -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0016 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "setServiceCache may only be called once";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = android.os.ServiceManager.sCache; // :java.util.HashMap
        _result = v0.putAll(v2); // java.util.HashMap.putAll -> void
        return;
    }

    public static java.lang.String[] listServices() {
        _result = this.getIServiceManager(); // android.os.ServiceManager.getIServiceManager -> android.os.IServiceManager
        v0 = _result;
        _result = android.os.IServiceManager.listServices(v0); // -> java.lang.String[]
        v0 = _result;
        return v0;
        v0 = _exception;
        v1 = "ServiceManager";
        v2 = "error in listServices";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        v0 = 0;
        // goto L_0008
    }

}