package android.os;

/**
 * Original SourceFile: IVoIPInterface.java
 * Descriptor: Landroid/os/IVoIPInterface$Stub$Proxy;
 */
class IVoIPInterface$Stub$Proxy implements android.os.IVoIPInterface {
    private android.os.IBinder mRemote;

    IVoIPInterface$Stub$Proxy(android.os.IBinder p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.IBinder)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.mRemote = v1; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        return;
    }

    public boolean answerVoIPCall() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 4;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_001f */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public android.os.IBinder asBinder() {
        // Registers (2 total): v1 = this
        v0 = v1.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        return v0;
    }

    public void callInVoIP(java.lang.String p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.String)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v0 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v0); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v6); // android.os.Parcel.writeString -> void
        v0 = v5.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v3 = 26;
        v4 = 0;
        _result = android.os.IBinder.transact(v0, v3, v1, v2, v4); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean canUseBTInVoIP(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 18;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0023 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean createCallSession(java.lang.String p0, java.lang.String p1, java.lang.String p2, android.os.IVoIPCallbackInterface p3) {
        // Registers (12 total): v7 = this, v8 = p0 (java.lang.String), v9 = p1 (java.lang.String), v10 = p2 (java.lang.String), v11 = p3 (android.os.IVoIPCallbackInterface)
        v0 = 1;
        v1 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v3 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v4 = _result;
        v2 = "android.os.IVoIPInterface";
        _result = v3.writeInterfaceToken(v2); // android.os.Parcel.writeInterfaceToken -> void
        _result = v3.writeString(v8); // android.os.Parcel.writeString -> void
        _result = v3.writeString(v9); // android.os.Parcel.writeString -> void
        _result = v3.writeString(v10); // android.os.Parcel.writeString -> void
        if (v11 == 0) /* goto L_0038 */;
        _result = android.os.IVoIPCallbackInterface.asBinder(v11); // -> android.os.IBinder
        v2 = _result;
        _result = v3.writeStrongBinder(v2); // android.os.Parcel.writeStrongBinder -> void
        v2 = v7.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v5 = 1;
        v6 = 0;
        _result = android.os.IBinder.transact(v2, v5, v3, v4, v6); // -> boolean
        _result = v4.readException(); // android.os.Parcel.readException -> void
        _result = v4.readInt(); // android.os.Parcel.readInt -> int
        v2 = _result;
        if (v2 == 0) /* goto L_003a */;
        _result = v4.recycle(); // android.os.Parcel.recycle -> void
        _result = v3.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v2 = 0;
        // goto L_001e
        v0 = v1;
        // goto L_0031
        v0 = _exception;
        _result = v4.recycle(); // android.os.Parcel.recycle -> void
        _result = v3.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean destroyCallSession(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 2;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0022 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public void dumpCallSessionInfoDB(java.lang.String p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.String)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v0 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v0); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v6); // android.os.Parcel.writeString -> void
        v0 = v5.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v3 = 28;
        v4 = 0;
        _result = android.os.IBinder.transact(v0, v3, v1, v2, v4); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public java.lang.String getCurrentVoIPNumber() {
        // Registers (6 total): v5 = this
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v0 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v0); // android.os.Parcel.writeInterfaceToken -> void
        v0 = v5.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v3 = 25;
        v4 = 0;
        _result = android.os.IBinder.transact(v0, v3, v1, v2, v4); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public java.lang.String getInterfaceDescriptor() {
        // Registers (2 total): v1 = this
        v0 = "android.os.IVoIPInterface";
        return v0;
    }

    public int getSessionCount() {
        // Registers (6 total): v5 = this
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v0 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v0); // android.os.Parcel.writeInterfaceToken -> void
        v0 = v5.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v3 = 27;
        v4 = 0;
        _result = android.os.IBinder.transact(v0, v3, v1, v2, v4); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public int getVoIPCallCount(java.lang.String p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.String)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v0 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v0); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v6); // android.os.Parcel.writeString -> void
        v0 = v5.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v3 = 9;
        v4 = 0;
        _result = android.os.IBinder.transact(v0, v3, v1, v2, v4); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean hangupVoIPCall() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 5;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_001f */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean holdVoIPCall() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 6;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_001f */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean isVoIPActivated() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 24;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0020 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean isVoIPDialing() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 23;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0020 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean isVoIPIdle() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 20;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0020 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean isVoIPRingOrDialing() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 21;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0020 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean isVoIPRinging() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 22;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0020 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean moveVoIPToTop() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 3;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_001f */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean resumeVoIPCall() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 7;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_001f */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean setBTUserWantsAudioOn(boolean p0) {
        // Registers (9 total): v7 = this, v8 = p0 (boolean)
        v0 = 1;
        v1 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v3 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v4 = _result;
        v2 = "android.os.IVoIPInterface";
        _result = v3.writeInterfaceToken(v2); // android.os.Parcel.writeInterfaceToken -> void
        if (v8 == 0) /* goto L_002d */;
        v2 = v0;
        _result = v3.writeInt(v2); // android.os.Parcel.writeInt -> void
        v2 = v7.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v5 = 19;
        v6 = 0;
        _result = android.os.IBinder.transact(v2, v5, v3, v4, v6); // -> boolean
        _result = v4.readException(); // android.os.Parcel.readException -> void
        _result = v4.readInt(); // android.os.Parcel.readInt -> int
        v2 = _result;
        if (v2 == 0) /* goto L_002f */;
        _result = v4.recycle(); // android.os.Parcel.recycle -> void
        _result = v3.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v2 = v1;
        // goto L_0012
        v0 = v1;
        // goto L_0026
        v0 = _exception;
        _result = v4.recycle(); // android.os.Parcel.recycle -> void
        _result = v3.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public void setEngMode(java.lang.String p0, int p1) {
        // Registers (8 total): v5 = this, v6 = p0 (java.lang.String), v7 = p1 (int)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v0 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v0); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v6); // android.os.Parcel.writeString -> void
        _result = v1.writeInt(v7); // android.os.Parcel.writeInt -> void
        v0 = v5.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v3 = 29;
        v4 = 0;
        _result = android.os.IBinder.transact(v0, v3, v1, v2, v4); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean setUseBTInVoIP(java.lang.String p0, boolean p1) {
        // Registers (10 total): v7 = this, v8 = p0 (java.lang.String), v9 = p1 (boolean)
        v0 = 1;
        v1 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v3 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v4 = _result;
        v2 = "android.os.IVoIPInterface";
        _result = v3.writeInterfaceToken(v2); // android.os.Parcel.writeInterfaceToken -> void
        _result = v3.writeString(v8); // android.os.Parcel.writeString -> void
        if (v9 == 0) /* goto L_0030 */;
        v2 = v0;
        _result = v3.writeInt(v2); // android.os.Parcel.writeInt -> void
        v2 = v7.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v5 = 17;
        v6 = 0;
        _result = android.os.IBinder.transact(v2, v5, v3, v4, v6); // -> boolean
        _result = v4.readException(); // android.os.Parcel.readException -> void
        _result = v4.readInt(); // android.os.Parcel.readInt -> int
        v2 = _result;
        if (v2 == 0) /* goto L_0032 */;
        _result = v4.recycle(); // android.os.Parcel.recycle -> void
        _result = v3.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v2 = v1;
        // goto L_0015
        v0 = v1;
        // goto L_0029
        v0 = _exception;
        _result = v4.recycle(); // android.os.Parcel.recycle -> void
        _result = v3.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean setVoIPActive(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 13;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0023 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean setVoIPCallCount(java.lang.String p0, int p1) {
        // Registers (9 total): v6 = this, v7 = p0 (java.lang.String), v8 = p1 (int)
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        _result = v1.writeInt(v8); // android.os.Parcel.writeInt -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 8;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0026 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean setVoIPDialing(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 12;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0023 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean setVoIPDisconnected(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 16;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0023 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean setVoIPDisconnecting(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 15;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0023 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean setVoIPHolding(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 14;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0023 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean setVoIPIdle(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 10;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0023 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean setVoIPRinging(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        v3 = v6.mRemote; // android.os.IVoIPInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 11;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0023 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

}