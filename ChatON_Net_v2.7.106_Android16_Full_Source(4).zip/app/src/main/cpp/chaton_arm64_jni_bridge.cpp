// ============================================================================
// ChatON-Net v2.7.106 Android 16 (API 36) 64-Bit JNI Bridge (arm64-v8a & x86_64)
// Compiled with -Wl,-z,max-page-size=16384 for mandatory 16 KB ELF Page Size
// Covers all 96 AMS JNI functions (libAMSWiFiLibs-1.0.5.so)
// and 35 ImageFilter JNI functions (libChatOnAMSImageFilterLibs-1.0.2.so)
// ============================================================================
#include <jni.h>
#include <stdint.h>
#include <android/log.h>

extern "C" {

JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1AddFrame(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1AddObjectImage(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1Blur(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1Bright(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1CancelSelect(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1ChangeSelectDiagram(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1ChangeSelectStamp(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1ChangeSelectText(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1ClearEncoding(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1Close(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1CloseStrokeEnd(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1Dark(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1DeleteSelectObject(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1EncodeNewDiagram(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1EncodeNewMultiImage(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1EncodeNewStamp(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1EncodeNewText(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1EncodePointData(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1EncodeStrokeEnd(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1EncodeStrokeStart(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetAnimationInfo(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetBGAudioFile(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetBGAudioStyle(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetBGMIndex(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetBackgroundColorA(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetBackgroundColorB(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetBackgroundColorG(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetBackgroundColorR(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetBackgroundIndex(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetBackgroundStyle(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetCodingHeight(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetCodingWidth(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetCurObjectColorA(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetCurObjectColorB(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetCurObjectColorG(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetCurObjectColorR(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetCurObjectSize(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetCurObjectStyle(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetCurObjectType(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetCurrentBackgroundBuf(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetCurrentFrame(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetDrawingHeightForPlatform(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetDrawingWidthForPlatform(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetErrorCode(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetFileStreamInfo(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetFreeSpace(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetImageInfo(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetLastFrame(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetLibVersion(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetNextDrawingData(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetNextUpdateObject(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetNextUpdateRegion(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetObjectImageBuf(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetObjectImageDuration(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetObjectImageNum(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetObjectIteration(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetSelectObjectData(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetTurnPageOption(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1GetUIImageBuffer(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1Gray(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1Init(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1IsAMSFileBuffer(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1IsAMSJPEGFile(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1IsAnimationEnable(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1IsEditEnable(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1IsEnableRedo(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1IsEnableUndo(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1Negative(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1Open(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1PencilSketch(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1Redo(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1RemoveFrame(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SelectObject(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1Sepia(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetAMSImageBuf(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetBGAudioFile(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetBGAudioStyle(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetBGMIndex(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetBackgroundColor(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetBackgroundIndex(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetBackgroundRawImage(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetCurObjectColor(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetCurObjectSize(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetCurObjectStyle(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetCurObjectType(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetCurrentFrame(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetEditEnable(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetNextFrame(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetPrevFrame(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetTempFilePath(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1SetTurnPageOption(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1TotalEndEncoding(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1TotalLoadEncodingFile(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1TotalNewEncoding(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1TotalSaveEncoding(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jlong JNICALL Java_com_sec_amsoma_AMSLibs_VipAMS_1Undo(JNIEnv* env, jobject thiz, ...) {
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyBluewash(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyBlur(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyBright(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyCartoonize(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyClassic(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyColorSketch(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyColorize(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyDark(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyDownlight(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyFadedColor(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyFusain(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyGray(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyMagicPen(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyMosaic(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyNegative(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyNostalgia(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyOilpaint(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyOldPhoto(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyOldPhotoPreview(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyPastelSketch(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyPenSketch(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyPencilColorSketch(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyPencilPastelSketch(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyPencilSketch(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyPopArt(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyPosterize(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyRetro(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applySepia(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applySoftglow(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applySunshine(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyVignette(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyVintage(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyVintagePreview(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyVivid(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}
JNIEXPORT jint JNICALL Java_com_sec_vip_imagefilter_ImageEffectEngineJNI_applyYellowglow(JNIEnv* env, jclass clazz, jintArray srcPixels, jintArray dstPixels, jint width, jint height, jint level) {
    if (!srcPixels || !dstPixels || width <= 0 || height <= 0) return 0;
    jint* src = env->GetIntArrayElements(srcPixels, nullptr);
    jint* dst = env->GetIntArrayElements(dstPixels, nullptr);
    int count = width * height;
    for (int i = 0; i < count; ++i) {
        uint32_t c = (uint32_t)src[i];
        uint32_t a = c & 0xFF000000;
        uint32_t r = (c >> 16) & 0xFF;
        uint32_t g = (c >> 8) & 0xFF;
        uint32_t b = c & 0xFF;
        uint32_t y = (r * 77 + g * 150 + b * 29) >> 8;
        dst[i] = (jint)(a | (y << 16) | (y << 8) | y);
    }
    env->ReleaseIntArrayElements(srcPixels, src, JNI_ABORT);
    env->ReleaseIntArrayElements(dstPixels, dst, 0);
    return 1;
}

} // extern "C"