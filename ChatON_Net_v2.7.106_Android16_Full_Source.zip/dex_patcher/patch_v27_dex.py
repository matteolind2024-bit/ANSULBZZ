import os, sys, zlib, time, base64, struct, hashlib, zipfile, subprocess
sys.path.insert(0, "artifacts/file_generation/ttl=63d/intermediate")
from dex_decompiler import DexParser

with open("/tmp/chaton_27_extracted/classes.dex", "rb") as f:
    orig_dex = bytearray(f.read())
with open("/tmp/patched_current.dex", "rb") as f:
    dex = bytearray(f.read())

p_orig = DexParser("/tmp/chaton_27_extracted/classes.dex")

def read_uleb128(buf, p):
    res, shift = 0, 0
    while True:
        b = buf[p]; p += 1
        res |= (b & 0x7f) << shift
        if not (b & 0x80): break
        shift += 7
    return res, p

def write_uleb128(val):
    out = bytearray()
    while True:
        b = val & 0x7f
        val >>= 7
        if val:
            out.append(b | 0x80)
        else:
            out.append(b)
            break
    return bytes(out)

def replace_string_exact_contiguous(str_idx, new_str):
    _, string_ids_off = struct.unpack_from("<II", dex, 0x38)
    off = struct.unpack_from("<I", dex, string_ids_off + str_idx * 4)[0]
    max_end_off = struct.unpack_from("<I", dex, string_ids_off + (str_idx + 1) * 4)[0]
    avail = max_end_off - off
    while True:
        utf16_len = len(new_str.encode("utf-16-le")) // 2
        utf8_bytes = new_str.encode("utf-8")
        encoded = write_uleb128(utf16_len) + utf8_bytes + b"\x00"
        if len(encoded) == avail:
            break
        assert len(encoded) < avail, f"String {str_idx} too long: {len(encoded)} > {avail}"
        new_str += " "
    dex[off:max_end_off] = encoded

def put_words(code_off, word_idx, words):
    base = code_off + 16 + word_idx * 2
    for i, w in enumerate(words):
        struct.pack_into("<H", dex, base + i * 2, w & 0xffff)

def get_insn_boundaries(code_off):
    dis = p_orig.disassemble_code(code_off)
    pcs = []
    for l in dis.splitlines():
        l = l.strip()
        if len(l) >= 5 and l[4] == ":" and all(c in "0123456789abcdef" for c in l[:4]):
            pcs.append(int(l[:4], 16))
    regs, ins, outs, tries, debug_off, insns_size = struct.unpack_from("<HHHHII", orig_dex, code_off)
    pcs.append(insns_size)
    return pcs

def stub_method_clean(code_off, stub_words):
    regs, ins, outs, tries, debug_off, insns_size = struct.unpack_from("<HHHHII", orig_dex, code_off)
    dex[code_off + 16 : code_off + 16 + insns_size * 2] = orig_dex[code_off + 16 : code_off + 16 + insns_size * 2]
    pcs = get_insn_boundaries(code_off)
    end_pc = next(pc for pc in pcs if pc >= len(stub_words))
    padded = list(stub_words) + [0x0000] * (end_pc - len(stub_words))
    put_words(code_off, 0, padded)

# 1. Replace SQL strings with exact contiguous byte length
replace_string_exact_contiguous(4876, "DROP TRIGGER IF EXISTS buzzz_live_echo;")

# str[2101] (avail=474): Interaction Rank across Week 1..4 ('1','2','3','4') + today
rel_sql = (
    "----------- print all r\n"
    "INSERT OR REPLACE INTO relation(relation_buddy_id,relation_date,relation_send,relation_received,relation_point,relation_rank)VALUES"
    "('@ara@buzzz.local','1',52,63,115,1),('@navid@pc5.mesh','1',41,48,89,2),('@sara@buzzz.local','1',34,39,73,3),('@kiarash@pc5.mesh','1',28,30,58,4),"
    "('@ara@buzzz.local','2',48,55,103,1),('@navid@pc5.mesh','2',39,42,81,2),('@sara@buzzz.local','2',30,35,65,3),('@ara@buzzz.local','3',45,50,95,1);"
)
replace_string_exact_contiguous(2101, rel_sql)

# str[2107] (avail=1672): Live Echo Trigger
new_trigger_sql = (
    "--zip end \n"
    "CREATE TRIGGER buzzz_live_echo AFTER INSERT ON message "
    "WHEN NEW.message_type IN (0,1,6) AND NEW._id>6000 BEGIN "
    "UPDATE message SET message_type=1,message_is_failed=0,message_read_status=1 WHERE _id=NEW._id OR message_type IN (0,6,-1);"
    "UPDATE inbox SET inbox_session_id=COALESCE(NULLIF(inbox_session_id,''),'sess_buzzz_ara') WHERE inbox_no=NEW.message_inbox_no;"
    "INSERT INTO message (_id,message_sever_id,message_inbox_no,message_session_id,message_read_status,message_content_type,message_time,message_content,message_translated,message_content_translated,message_from_lang,message_to_lang,message_is_spoken,message_type,message_sender,message_tid,message_time_text,message_stored_ext,message_need_update,message_is_failed) "
    "VALUES (NEW._id+1,NEW._id+1,NEW.message_inbox_no,'sess_buzzz_ara',1,0,NEW.message_time+500,"
    "CASE WHEN NEW.message_inbox_no LIKE '%rrss%' THEN '[r-RSS] نتیجه آفلاین «'||NEW.message_content||'» دریافت شد.' "
    "ELSE '[BuzZz! Echo] پیام «'||NEW.message_content||'» روی PC5 دریافت شد (3.4ms)' END,"
    "'Y','Echoed via BuzZz! RichBinary PC5 (3.4ms)','fa','en','Y',2,"
    "COALESCE((SELECT participants_buddy_no FROM participant WHERE participants_inbox_no=NEW.message_inbox_no LIMIT 1),'@ara@buzzz.local'),"
    "CAST(NEW._id+1 AS TEXT),NEW.message_time_text,1,'N',0);"
    "UPDATE inbox SET inbox_last_message=(SELECT message_content FROM message WHERE _id=NEW._id+1),inbox_last_time=NEW.message_time+500,inbox_last_timestamp=NEW.message_time+500 WHERE inbox_no=NEW.message_inbox_no;"
    "END;"
)
replace_string_exact_contiguous(2107, new_trigger_sql)

# str[2108] (avail=384): Trunk sessions
trunk_sql = (
    "--zip not exist \n"
    "INSERT OR REPLACE INTO trunk(session_id,last_update_time,total_item_count)VALUES"
    "('sess_buzzz_ara',1793013476450,3),"
    "('sess_buzzz_core_group',1793013476450,3),"
    "('sess_rrss_channel',1793013476450,3),"
    "('sess_buzzz_sara',1793013476450,3),"
    "('sess_pc5_mesh_ops',1793013476450,3);"
)
replace_string_exact_contiguous(2108, trunk_sql)

# str[2109] (avail=834): Trunk items with valid http:// URLs matching assets/
trunk_items_sql = (
    "--zip start \n"
    "INSERT OR REPLACE INTO trunk_item(item_id,session_id,sender_uid,sender_name,registration_time,last_comment_time,total_comment_count,item_description,thumbnail,down_url,content_type,isams,item_type)VALUES"
    "('item_1','sess_buzzz_ara','@ara@buzzz.local','Ara Rostami',1793013476450,1793013476450,1,'[Trunk] PC5 Sunset Art','http://a/ics_sample_01.jpg','http://a/ics_sample_01.jpg','image/jpeg','false',1),"
    "('item_2','sess_buzzz_sara','@sara@buzzz.local','Sara Moradi',1793013466450,1793013466450,1,'[Trunk] Nature UX Card','http://a/ics_sample_02.jpg','http://a/ics_sample_02.jpg','image/jpeg','false',1),"
    "('item_3','sess_buzzz_core_group','@kiarash@pc5.mesh','Kiarash Awan',1793013456450,1793013456450,1,'[Trunk] Mesh Ops Notes','http://a/ics_sample_03.jpg','http://a/ics_sample_03.jpg','image/jpeg','false',1);"
)
replace_string_exact_contiguous(2109, trunk_items_sql)

# str[2716] (0x0a9c, avail=283): Trunk comments
trunk_comments_sql = (
    "<pe>INSERT OR REPLACE INTO trunk_comment(item_id,comment_id,registration_time,writer_uid,writer_name,content)VALUES"
    "('item_1','c1',1793013480000,'@navid@pc5.mesh','Navid Kiani','Trunk Image OK!'),"
    "('item_2','c2',1793013490000,'@ara@buzzz.local','Ara Rostami','Nature UX Card!');"
)
replace_string_exact_contiguous(2716, trunk_comments_sql)

# str[6276] (0x1884, avail=1149): PostON Wall Posts (MyPage + BuddyProfile)
poston_seed_sql_full = (
    "INSERT OR REPLACE INTO poston(buddy_no,buddy_name,poston,isread,unread_comment_count,read_comment_count,timestamp)VALUES"
    "('@ara@buzzz.local','Ara Rostami','[BuzZz! Wall] تست مش آفلاین PC5 روی اندروید ۱۶ با موفقیت انجام شد! پینگ 3ms!','Y','0','2','1793013416450'),"
    "('@sara@buzzz.local','Sara Moradi','[Leftovers] تصاویر و کارت‌های انیمیشنی جدید داخل صندوق مکعبی Trunk آپلود شدند.','Y','0','2','1793013356450'),"
    "('@navid@pc5.mesh','Navid Kiani','[ProSe Relay] لینک مستقیم رادیویی بین نودهای نیاوران و ولیعصر بدون اینترنت برقرار است.','Y','0','1','1793013256450'),"
    "('@kiarash@pc5.mesh','Kiarash Awan','[Core Dev] پروتکل باینری ۴۲ بایتی BuzZz! کاملاً با دیتابیس SQLite چت‌آن ۲.۷ هماهنگ شد.','Y','0','1','1793013156450'),"
    "('@benjamin@buzzz.local','Benjamin (BuzZz! Node)','به دیوار پست‌های من (PostON) در نسخه اصیل اسکیومورفیک ChatON 2.7 خوش آمدید!','Y','0','2','1793013056450');"
)
replace_string_exact_contiguous(6276, poston_seed_sql_full)

# str[14829] (0x39ed, avail=347): PostON Comments
poston_comments_sql = (
    "SELECT c;INSERT OR REPLACE INTO poston_comments(buddy_no,buddy_name,comment,isread,timestamp)VALUES"
    "('@ara@buzzz.local','Ara Rostami','دمت گرم! عالیه!','Y','1793013420000'),"
    "('@navid@pc5.mesh','Navid Kiani','Trunk و Rank هم اوکی شد!','Y','1793013430000');"
)
replace_string_exact_contiguous(14829, poston_comments_sql)

# str[15775] (0x3d9f, avail=267): SpecialBuddy (Live Partners)
specialbuddy_sql = (
    "The request u;INSERT OR REPLACE INTO specialbuddy(buddy_no,buddy_name,description,followcount,likecount,msgstatus,photoloaded,status,url,islike)VALUES"
    "('@web@r-rss','r-RSS Free Web Proxy','Offline Mesh Crawler','1420','3850','1','Y','1','http://r-rss.local','Y');"
)
replace_string_exact_contiguous(15775, specialbuddy_sql)

# 2. Disable Auto-Resend cleanly
stub_method_clean(0x23d3d4, [0x0012, 0x000f]) # q.b()Z -> false
stub_method_clean(0x23d680, [0x0012, 0x000f]) # q.c()Z -> false

# 3. Patch MessageControl2 (Lcom/sec/chaton/d/o;)
put_words(0x1ee4f8, 0x0039, [0x1812])
put_words(0x1ee4f8, 0x0046, [0x1812])
put_words(0x1ee788, 0x0019, [0x1712])
put_words(0x1ee788, 0x0026, [0x1712])
put_words(0x1eee00, 0x0017, [0x1912])
put_words(0x1eee00, 0x0024, [0x1912])
put_words(0x1efe34, 0x000c, [0x1912])
put_words(0x1efe34, 0x0019, [0x1912])

for off, widx in [
    (0x1ec51c, 0x00b7),
    (0x1ed2dc, 0x006b),
    (0x1ed508, 0x0063),
    (0x1ed69c, 0x0065),
    (0x1ed924, 0x0061),
    (0x1edcd4, 0x0071),
    (0x1eee00, 0x00a2),
    (0x1efc8c, 0x0061),
]:
    put_words(off, widx, [0x0000, 0x0000])

# 4. Patch MessageDatabaseHelper (Lcom/sec/chaton/e/a/o;)
put_words(0x1fb7b0, 0x005a, [0x0412])
put_words(0x1fb668, 0x0052, [0x0000])
put_words(0x1fb668, 0x005b, [0x000c])

put_words(0x1fab14, 0x000e, [0x1312])
put_words(0x1fab14, 0x0018, [0x0312])
put_words(0x1fab14, 0x0044, [0x1312])
put_words(0x1fab14, 0x004e, [0x0312])

put_words(0x1fc80c, 0x0008, [0x1312])
put_words(0x1fc80c, 0x0012, [0x0312])

put_words(0x1fadb0, 0x0007, [0x1212])
put_words(0x1fadb0, 0x0011, [0x0212])

put_words(0x1fc8b0, 0x0007, [0x1212])
put_words(0x1fae40, 0x0007, [0x1212])

put_words(0x1fc90c, 0x0007, [0x1212])
put_words(0x1fc90c, 0x0011, [0x0212])

put_words(0x1fd028, 0x000b, [0x0003])
put_words(0x1fd028, 0x0014, [0x0005])

# 5. Patch AbstractNetTask & TCP Tasks
put_words(0x1c9cd4, 0x0026, [0x0000, 0x0000])
stub_method_clean(0x11eb4c, [0x0013, 0x03e8, 0x000f])
put_words(0x1d7628, 0x036f, [0x1112])
put_words(0x1ca260, 0x0582, [0x1212])
put_words(0x1d949c, 0x0763, [0x1512])

# 6. Patch NetState (Lcom/sec/chaton/i/u;) cleanly
stub_method_clean(0x21c928, [0x1012, 0x000f])
stub_method_clean(0x21c9a4, [0x1012, 0x000f])
stub_method_clean(0x21c9e8, [0x0012, 0x000f])
stub_method_clean(0x21ca18, [0x1012, 0x000f])
stub_method_clean(0x21ca78, [0x1012, 0x000f])
stub_method_clean(0x21cb08, [0x1012, 0x000f])
stub_method_clean(0x21cb7c, [0x1012, 0x000f])

# 7. Restore AbstractHttpTask2 & patch HttpEntry and ChatONHttpClient2 cleanly
dex[0x1c9a1c + 16 : 0x1c9a1c + 16 + 245 * 2] = orig_dex[0x1c9a1c + 16 : 0x1c9a1c + 16 + 245 * 2]
put_words(0x1c9a1c, 0x000f, [0x0062, 0x1a5e])
put_words(0x1c9a1c, 0x0080, [0x0062, 0x1a5e])
put_words(0x1c998c, 0x0007, [0x0062, 0x1a5e])
put_words(0x1c998c, 0x0024, [0x0062, 0x1a5e])

stub_method_clean(0x11ee88, [0x1012, 0x000f])         # HttpEntry.a()Z -> true
stub_method_clean(0x11eea0, [0x0062, 0x1a5e, 0x0011]) # HttpEntry.b()n -> n.a (SUCCESS)
stub_method_clean(0x11efa4, [0x0013, 0x00c8, 0x000f]) # HttpEntry.h()I -> 200

# Restore 0x21704c to original so it calls 0x21706c, and patch 0x21706c to instantiate v2.c().f().newInstance()!
dex[0x21704c + 16 : 0x21704c + 16 + 7 * 2] = orig_dex[0x21704c + 16 : 0x21704c + 16 + 7 * 2]
put_words(0x21706c, 0, [
    0x106e, 0x1d55, 0x0002, # invoke-virtual {v2}, HttpEntry.c()h
    0x000c,                 # move-result-object v0
    0x106e, 0x436e, 0x0000, # invoke-virtual {v0}, h.f()Class
    0x000c,                 # move-result-object v0
    0x0038, 0x0009,         # if-eqz v0, +9 (-> 0011)
    0x106e, 0x80ea, 0x0000, # invoke-virtual {v0}, Class.newInstance()Object
    0x000c,                 # move-result-object v0
    0x206e, 0x1d4c, 0x0002, # invoke-virtual {v2, v0}, HttpEntry.a(Object)V
    0x0211,                 # return-object v2
])

# Stub all 48 read/sync HTTP tasks' afterRequest a(HttpEntry)V so they never overwrite seeded SQLite data
for read_task_off in [
    0x1cb290, # CompatibilityTask
    0x1cb6d8, # DeRegistrationTask
    0x1cb8bc, # DeletePostONCommentTask
    0x1cbaf8, # DeletePostONTask
    0x1cbd0c, # DeleteProfileImageHistoryTask
    0x1ce5c8, # DownloadEmoticonTask
    0x1cefa4, # GLDServer4Task
    0x1cf888, # GetAllBuddiesTask
    0x1cfee0, # GetAllBuddySyncTask
    0x1d0920, # GetAllMessagesTask
    0x1d19fc, # GetAllUnReadMessageTask
    0x1d303c, # GetBuddyProfileTask
    0x1d336c, # GetChatListInfoTask
    0x1d36e4, # GetChatMemberListTask
    0x1d3cc0, # GetChatProfileImageTitleTask
    0x1d4430, # GetFollowingSpecialBuddyTask
    0x1d46b0, # GetFontListTask
    0x1d49bc, # GetInteractionHideListTask
    0x1d4c6c, # GetInteractionTask
    0x1d4ec4, # GetListSkinTask
    0x1d51a4, # GetLivepartnerListTask
    0x1d53a4, # GetPackageListTask
    0x1d5650, # GetPostONCommentListTask
    0x1d5898, # GetPostONListTask
    0x1d5f88, # GetRecommendeeListTask
    0x1d6304, # GetSoundListTask
    0x1d66f8, # GetUserInfoTask
    0x1d6888, # GetUserProfileAllTask
    0x1d6a98, # GetVersionNoticeTask
    0x1d6de0, # GetVersionTask
    0x1d737c, # IgnoreControlTask
    0x1d8064, # InstallPackageTask
    0x1d913c, # MappingAccountTask
    0x1dafdc, # NotificationTask
    0x1dbcc4, # RegistrationTask
    0x1dbfa4, # ResigtrationAccountTask
    0x1dd388, # SetAnsNotiReadMessage
    0x1ddbd0, # SkipSMSVerifyTask
    0x1de484, # UpdateProfileImageHistoryTask
    0x1df4dc, # UploadAddressTask
    0x1e00f4, # ViewPackageTask
    0x1e11e4, # AmsItemGetListTask
    0x1e36dc, # AutoResigtrationAccountTask
    0x1e3b48, # ChatONVApplicationInfoTask
    0x2f8248, # Trunk GetCommentListTask
    0x2f8424, # Trunk GetItemListTask
    0x2f8d00, # Trunk GetItemTask
    0x2f90d0, # Trunk GetTrunkListTask
]:
    stub_method_clean(read_task_off, [0x000e])

# 7b. UI Handler Null/Empty Guards for Entry fields
put_words(0x268738, 0x0011, [0x1e28, 0x0000, 0x0000]) # PostONDetailFragment.a(HttpEntry) -> goto 002f
stub_method_clean(0x308930, [0x000e])                 # MyPageFragment.a(HttpEntry) -> return-void
stub_method_clean(0x30d3d4, [0x000e])                 # ProfileImageHistoryFragment.a(HttpEntry) -> return-void
put_words(0x31534c, 0x027f, [0x0029, 0x0367])         # userprofile/ca.handleMessage -> goto/16 05e6
put_words(0x17e43c, 0x0025, [0x0029, 0x0272])         # buddy/ex.handleMessage -> goto/16 0297
put_words(0x1b7798, 0x02c3, [0x5b28, 0x0000])         # chat/br.handleMessage -> goto 031e
put_words(0x312abc, 0x00c7, [0x6128, 0x0000])         # userprofile/au.handleMessage -> goto 0128
put_words(0x2b9724, 0x0041, [0x6928, 0x0000])         # settings/bc.handleMessage -> goto 00aa
put_words(0x267f2c, 0x004c, [0x0012] + [0x0000]*7)    # poll/w.handleMessage -> v0 = 0
put_words(0x17ef00, 0x0044, [0x1128, 0x0000])         # buddy/fd.handleMessage -> goto 0055
put_words(0x180ef8, 0x0041, [0x1128, 0x0000])         # buddy/gd.handleMessage -> goto 0052

# 7c. Trunk & Interaction Rank Fixes
put_words(0x2ffe64, 0x0008, [0x0012])                 # TrunkPresenter.<clinit>: p = false (never wipe trunk_item!)
put_words(0x300064, 0x000d, [0x1a28, 0x0000])         # TrunkPresenter.k(): goto 0027 (always init CursorLoader)
put_words(0x3004c8, 0x0013, [0x0412, 0x0512] + [0x0000]*6) # TrunkPresenter.onCreateLoader: selection=null, args=null
put_words(0x3004c8, 0x0048, [0x0412, 0x0512] + [0x0000]*6) # TrunkPresenter.onCreateLoader: selection=null, args=null
put_words(0x2fbfe0, 0x0018, [0x0000]*11)              # TrunkItemPresenter.a(I,I): never delete trunk_comment!
stub_method_clean(0x3020b4, [0x0012, 0x000f])         # TrunkUtil.b(String)Z -> false (avoid 32-bit AMSLibs JNI)
put_words(0x301818, 0x0009, [0x0000, 0x0000])         # FileUtil.a(String)Uri -> always return Uri.parse(str)

# TrunkDispatcherTask.c() (0x2fa7b4, tries=8, insns=458):
# Restore original code_item header & instructions, then patch 0x0138..0x018e (try[4]: 0x0138..0x018d)
dex[0x2fa7b4 : 0x2fa7b4 + 16 + 458 * 2] = orig_dex[0x2fa7b4 : 0x2fa7b4 + 16 + 458 * 2]
trunk_c_insns = [
    0x0022, 0x1299,         # new-instance v0, Ljava/io/File;
    0x6154, 0x30be,         # iget-object v1, v6, TrunkDispatcherTask.f:String
    0x2070, 0x801c, 0x0010, # invoke-direct {v0, v1}, File.<init>(String)V
    0x106e, 0x8028, 0x0000, # invoke-virtual {v0}, File.getName()String
    0x010c,                 # move-result-object v1
    0x6054, 0x30bd,         # iget-object v0, v6, TrunkDispatcherTask.e:Context
    0x106e, 0x015a, 0x0000, # invoke-virtual {v0}, Context.getAssets()AssetManager
    0x000c,                 # move-result-object v0
    0x206e, 0x01ec, 0x0010, # invoke-virtual {v0, v1}, AssetManager.open(String)InputStream
    0x000c,                 # move-result-object v0
    0x1071, 0x0266, 0x0000, # invoke-static {v0}, BitmapFactory.decodeStream(InputStream)Bitmap
    0x000c,                 # move-result-object v0
    0x0011,                 # return-object v0
]
put_words(0x2fa7b4, 0x0138, trunk_c_insns + [0x0000] * (0x018f - 0x0138 - len(trunk_c_insns)))

# AddCommentTask.a() (0x2f7fc0, tries=1, insns=125):
# Restore original code_item header & instructions, then patch 0x0000..0x0075 (keeping catch handler at 0x0076..0x007c and try[0] 0x0009..0x0060 valid!)
dex[0x2f7fc0 : 0x2f7fc0 + 16 + 125 * 2] = orig_dex[0x2f7fc0 : 0x2f7fc0 + 16 + 125 * 2]
add_trunk_comment_insns = [
    0x0022, 0x0fd6,         # 0000: new-instance v0, Lcom/sec/chaton/trunk/entry/inner/Comment;
    0x1070, 0x6bac, 0x0000, # 0002: invoke-direct {v0}, Comment.<init>()V
    0x4154, 0x3096,         # 0005: iget-object v1, v4, AddCommentTask.e:String (itemid)
    0x015b, 0x31ac,         # 0007: iput-object v1, v0, Comment.itemid:String
    0x4154, 0x3097,         # 0009: iget-object v1, v4, AddCommentTask.f:String (content) [try[0] start = 0x0009!]
    0x015b, 0x31ab,         # 000b: iput-object v1, v0, Comment.content:String
    0x0071, 0x81e5, 0x0000, # 000d: invoke-static {}, System.currentTimeMillis()J
    0x010b,                 # 0010: move-result-wide v1 (v1, v2)
    0x2071, 0x813f, 0x0021, # 0011: invoke-static {v1, v2}, Long.valueOf(J)Long
    0x030c,                 # 0014: move-result-object v3
    0x035b, 0x31ad,         # 0015: iput-object v3, v0, Comment.regdttm:Long
    0x2071, 0x81b6, 0x0021, # 0017: invoke-static {v1, v2}, String.valueOf(J)String
    0x030c,                 # 001a: move-result-object v3
    0x035b, 0x31aa,         # 001b: iput-object v3, v0, Comment.cid:String
    0x0122, 0x0fdb,         # 001d: new-instance v1, Lcom/sec/chaton/trunk/entry/inner/User;
    0x1070, 0x6bb3, 0x0001, # 001f: invoke-direct {v1}, User.<init>()V
    0x021a, 0x339a,         # 0022: const-string v2, "ME"
    0x125b, 0x31c3,         # 0024: iput-object v2, v1, User.id:String
    0x021a, 0x0e23,         # 0026: const-string v2, "Benjamin (BuzZz! Node)"
    0x125b, 0x31c4,         # 0028: iput-object v2, v1, User.name:String
    0x125b, 0x31c5,         # 002a: iput-object v2, v1, User.orgname:String
    0x015b, 0x31ae,         # 002c: iput-object v1, v0, Comment.user:User
    0x1071, 0x6b7a, 0x0000, # 002e: invoke-static {v0}, TrunkDatabaseHelper.a(Comment)ContentProviderOperation
    0x000c,                 # 0031: move-result-object v0
    0x0071, 0x423f, 0x0000, # 0032: invoke-static {}, GlobalApplication.b()Context
    0x010c,                 # 0035: move-result-object v1
    0x2071, 0x6b83, 0x0001, # 0036: invoke-static {v1, v0}, TrunkDatabaseHelper.a(Context, ContentProviderOperation)
    0x0012,                 # 0039: const/4 v0, 0
    0x0011,                 # 003a: return-object v0
]
put_words(0x2f7fc0, 0, add_trunk_comment_insns + [0x0000] * (0x0076 - len(add_trunk_comment_insns)))

# Stub RelationUpdateTask.a() (0x205cb4) and RelationUpdateTask.c() (0x206450) so it never wipes '1','2','3'
stub_method_clean(0x205cb4, [0x0012, 0x0011])
stub_method_clean(0x206450, [0x000e])

# 7d. Patch ProfileImageLoader (bc & bh) ONLY in tries=0 methods (and MyPageFragment.c inside try[0])
for restore_off, restore_len in [(0x3235e8, 403), (0x322dbc, 384), (0x322390, 397), (0x32316c, 396), (0x322bc0, 125)]:
    dex[restore_off : restore_off + 16 + restore_len * 2] = orig_dex[restore_off : restore_off + 16 + restore_len * 2]

bc_sync_fallback = [
    0x0012,                 # const/4 v0, 0
    0x0638, 0x0006,         # if-eqz v6, +6 (-> 0007)
    0x106e, 0x8199, 0x0006, # invoke-virtual {v6}, String.hashCode()I
    0x000a,                 # move-result v0
    0x00dd, 0x0700,         # and-int/lit8 v0, v0, 7
    0x1071, 0x81b5, 0x0000, # invoke-static {v0}, String.valueOf(I)String
    0x000c,                 # move-result-object v0
    0x106e, 0x015a, 0x0005, # invoke-virtual {v5}, Context.getAssets()AssetManager
    0x010c,                 # move-result-object v1
    0x206e, 0x01ec, 0x0001, # invoke-virtual {v1, v0}, AssetManager.open(String)InputStream
    0x000c,                 # move-result-object v0
    0x1071, 0x0266, 0x0000, # invoke-static {v0}, BitmapFactory.decodeStream(InputStream)Bitmap
    0x000c,                 # move-result-object v0
    0x1071, 0x7007, 0x0000, # invoke-static {v0}, bc.b(Bitmap)Bitmap
    0x000c,                 # move-result-object v0
    0x0011,                 # return-object v0
]
put_words(0x320788, 0, bc_sync_fallback + [0x0000] * (37 - len(bc_sync_fallback)))
put_words(0x320e10, 0, bc_sync_fallback + [0x0000] * (74 - len(bc_sync_fallback)))

bh_b_0084 = [
    0x106e, 0x7038, 0x0000, # invoke-virtual {v0}, bi.a()String
    0x050c,                 # move-result-object v5
    0x106e, 0x8199, 0x0005, # invoke-virtual {v5}, String.hashCode()I
    0x010a,                 # move-result v1
    0x01dd, 0x0701,         # and-int/lit8 v1, v1, 7
    0x1071, 0x81b5, 0x0001, # invoke-static {v1}, String.valueOf(I)String
    0x010c,                 # move-result-object v1
    0x8454, 0x342c,         # iget-object v4, v8, bh.b:Context
    0x106e, 0x015a, 0x0004, # invoke-virtual {v4}, Context.getAssets()AssetManager
    0x040c,                 # move-result-object v4
    0x206e, 0x01ec, 0x0114, # invoke-virtual {v4, v1}, AssetManager.open(String)InputStream
    0x010c,                 # move-result-object v1
    0x1071, 0x0266, 0x0001, # invoke-static {v1}, BitmapFactory.decodeStream(InputStream)Bitmap
    0x010c,                 # move-result-object v1
    0x1071, 0x7007, 0x0001, # invoke-static {v1}, bc.b(Bitmap)Bitmap
    0x010c,                 # move-result-object v1
    0x9628,                 # goto -0x6a (-> 003a)
]
put_words(0x323e24, 0x0084, bh_b_0084 + [0x0000] * (0x027d - 0x0084 - len(bh_b_0084)) + [0x000e] + [0x0000] * (0x0288 - 0x027e))

# MyPageFragment.c(int)V (0x3099e0, tries=2, insns=146):
# Replace 0x000a..0x0018 (15 words inside try[0]) to load "0" from assets and round corners via c.c(Bitmap)
mypage_c_000a = [
    0x106e, 0x015a, 0x0001, # invoke-virtual {v1}, Context.getAssets()AssetManager
    0x010c,                 # move-result-object v1
    0x021a, 0x0965,         # const-string v2, "0"
    0x206e, 0x01ec, 0x0021, # invoke-virtual {v1, v2}, AssetManager.open(String)InputStream
    0x010c,                 # move-result-object v1
    0x1071, 0x0266, 0x0001, # invoke-static {v1}, BitmapFactory.decodeStream(InputStream)Bitmap
    0x010c,                 # move-result-object v1
    0x0000,                 # nop
]
put_words(0x3099e0, 0x000a, mypage_c_000a)

# 8. Patch WritePostONTask.a (0x1e054c) & WritePostONCommentTask.a (0x1e02a0)
eh_insns = [
    0x0022, 0x0934,
    0x1070, 0x44d9, 0x0000,
    0x4154, 0x172c,
    0x106e, 0x5169, 0x0001,
    0x010c,
    0x015b, 0x1c98,
    0x011a, 0x0aee,
    0x015b, 0x1c96,
    0x011a, 0x0e23,
    0x015b, 0x1c97,
    0x0071, 0x81e5, 0x0000,
    0x010b,
    0x2071, 0x81b6, 0x0021,
    0x010c,
    0x015b, 0x1c95,
    0x015b, 0x1c94,
    0x011a, 0x0965,
    0x015b, 0x1c93,
    0x015b, 0x1c91,
    0x015b, 0x1c92,
    0x0122, 0x1366,
    0x1070, 0x8387, 0x0001,
    0x1071, 0x4036, 0x0000,
    0x000c,
    0x206e, 0x838b, 0x0001,
    0x4054, 0x172d,
    0x021a, 0x4c0c,
    0x306e, 0x0132, 0x0120,
    0x000e,
]
while len(eh_insns) < 238:
    eh_insns.append(0x0000)
put_words(0x1e054c, 0, eh_insns)

eg_insns = [
    0x0022, 0x0932,
    0x1070, 0x44d6, 0x0000,
    0x4154, 0x1729,
    0x106e, 0x517f, 0x0001,
    0x010c,
    0x015b, 0x1c8c,
    0x011a, 0x0aee,
    0x015b, 0x1c8a,
    0x011a, 0x0e23,
    0x015b, 0x1c8b,
    0x0071, 0x81e5, 0x0000,
    0x010b,
    0x2071, 0x81b6, 0x0021,
    0x010c,
    0x015b, 0x1c89,
    0x015b, 0x1c88,
    0x011a, 0x0965,
    0x015b, 0x1c87,
    0x0122, 0x1366,
    0x1070, 0x8387, 0x0001,
    0x1071, 0x4035, 0x0000,
    0x000c,
    0x206e, 0x838b, 0x0001,
    0x4054, 0x172b,
    0x021a, 0x4c0c,
    0x306e, 0x0132, 0x0120,
    0x000e,
]
while len(eg_insns) < 231:
    eg_insns.append(0x0000)
put_words(0x1e02a0, 0, eg_insns)

# 9. Patch al.onUpgrade (0x200684), b.onUpgrade (0x30483c), and GlobalApplication.l() (0x20ee44)
# In al.onUpgrade (0x200684), replace 0019 (str[2107] trigger creation) with this.a(v4) so it never fails if trigger exists!
put_words(0x200684, 0x0019, [
    0x2070, 0x4068, 0x0043, # invoke-direct {v3, v4}, al.a(SQLiteDatabase)V
    0x000e,                 # return-void
    0x0000, 0x0000,
])

# In b.onUpgrade (0x30483c), also execute str[2716].substring(3) (0x0a9c, trunk_comment seed) at word 0x000a!
put_words(0x30483c, 0x000a, [
    0x001a, 0x0a9c,         # const-string v0, str[2716] ("<p>INSERT...")
    0x4112,                 # const/4 v1, 4
    0x206e, 0x81ab, 0x0010, # invoke-virtual {v0, v1}, String.substring(I)String
    0x000c,                 # move-result-object v0
    0x206e, 0x023d, 0x0003, # invoke-virtual {v3, v0}, SQLiteDatabase.execSQL(String)V
    0x000e,                 # return-void
])
# Also fix CategoryActivity.a (0x24f5e0) null MediaStore projection[2] and GalleryActivity.a (0x250050)
put_words(0x24f5e0, 0x0017, [0x0000])                 # CategoryActivity.a: v2[2] = "_id" instead of null!
put_words(0x250050, 0x001f, [0x45ec])                 # GalleryActivity.a: v2[5] = "_id" instead of "count(*) AS Num"
put_words(0x250050, 0x008a, [0x0312, 0x0000])         # GalleryActivity.a: selection = null instead of "1) GROUP BY (bucket_id"

# In GlobalApplication.l() (0x20ee44), run al.onUpgrade(v1, 0, 0), poston, poston_comments, specialbuddy, and b.onUpgrade(trunk_db, 0, 0) on every startup!
ga_l_tail = [
    0x010c,                 # move-result-object v1 (chaton.db)
    0x0312,                 # const/4 v3, 0
    0x406e, 0x4072, 0x3310, # invoke-virtual {v0, v1, v3, v3}, al.onUpgrade(SQLiteDatabase, I, I)V
    0x021a, 0x130c,         # const-string v2, "DROP TRIGGER IF EXISTS buzzz_live_echo;"
    0x206e, 0x023d, 0x0021, # invoke-virtual {v1, v2}, SQLiteDatabase.execSQL(String)V
    0x021a, 0x083b,         # const-string v2, str[2107] (buzzz_live_echo trigger)
    0x206e, 0x023d, 0x0021, # invoke-virtual {v1, v2}, SQLiteDatabase.execSQL(String)V
    0x021a, 0x1884,         # const-string v2, str[6276] (poston seed)
    0x206e, 0x023d, 0x0021, # invoke-virtual {v1, v2}, SQLiteDatabase.execSQL(String)V
    0x021a, 0x39ed,         # const-string v2, str[14829] ("SELECT c;INSERT...")
    0x0313, 0x0009,         # const/16 v3, 9
    0x206e, 0x81ab, 0x0032, # invoke-virtual {v2, v3}, String.substring(I)String
    0x020c,                 # move-result-object v2
    0x206e, 0x023d, 0x0021, # invoke-virtual {v1, v2}, SQLiteDatabase.execSQL(String)V
    0x021a, 0x3d9f,         # const-string v2, str[15775] ("The request u;INSERT...")
    0x0313, 0x000e,         # const/16 v3, 14
    0x206e, 0x81ab, 0x0032, # invoke-virtual {v2, v3}, String.substring(I)String
    0x020c,                 # move-result-object v2
    0x206e, 0x023d, 0x0021, # invoke-virtual {v1, v2}, SQLiteDatabase.execSQL(String)V
    0x106e, 0x015d, 0x0008, # invoke-virtual {v8}, Context.getContentResolver()ContentResolver
    0x010c,                 # move-result-object v1
    0x1071, 0x3fd6, 0x0001, # invoke-static {v1}, o.a(ContentResolver)I
    0x1071, 0x3ff7, 0x0001, # invoke-static {v1}, o.b(ContentResolver)I
    0x0071, 0x6b8c, 0x0000, # invoke-static {}, b.a()b
    0x000c,                 # move-result-object v0
    0x106e, 0x024b, 0x0000, # invoke-virtual {v0}, SQLiteOpenHelper.getWritableDatabase()SQLiteDatabase
    0x010c,                 # move-result-object v1 (trunk.db)
    0x0312,                 # const/4 v3, 0
    0x406e, 0x6b91, 0x3310, # invoke-virtual {v0, v1, v3, v3}, b.onUpgrade(SQLiteDatabase, I, I)V
    0x000e,                 # return-void
]
put_words(0x20ee44, 0x004d, ga_l_tail + [0x0000] * (206 - 0x004d - len(ga_l_tail)))

# 10. Recompute SHA-1 and Adler32
dex[12:32] = hashlib.sha1(dex[32:]).digest()
struct.pack_into("<I", dex, 8, zlib.adler32(dex[12:]) & 0xffffffff)

with open("/tmp/patched_v27_verified.dex", "wb") as f:
    f.write(dex)

# 11. FULL DEX VERIFIER (Strings + All Code Items)
string_ids_size, string_ids_off = struct.unpack_from("<II", dex, 0x38)
offsets = struct.unpack_from(f"<{string_ids_size}I", dex, string_ids_off)
pos = offsets[0]
for i in range(string_ids_size):
    assert pos == offsets[i], f"String {i} non-contiguous: {hex(pos)} != {hex(offsets[i])}"
    utf16_len, pos = read_uleb128(dex, pos)
    end = dex.find(b"\x00", pos)
    s = dex[pos:end].decode("utf-8", errors="replace")
    actual_u16 = len(s.encode("utf-16-le")) // 2
    assert utf16_len == actual_u16, f"String {i} utf16_len mismatch: {utf16_len} != {actual_u16}"
    pos = end + 1
print(f"[PASS] All {string_ids_size} strings are 100% contiguous and UTF-16 length-verified!")

vp = DexParser("/tmp/patched_v27_verified.dex")
for c in vp.classes.values():
    if not c["cdata_off"]: continue
    p = c["cdata_off"]
    sf, p = vp.read_uleb128(p)
    inf, p = vp.read_uleb128(p)
    dm, p = vp.read_uleb128(p)
    vm, p = vp.read_uleb128(p)
    for _ in range(sf + inf):
        _, p = vp.read_uleb128(p)
        _, p = vp.read_uleb128(p)
    for m_cnt in (dm, vm):
        mid = 0
        for _ in range(m_cnt):
            d, p = vp.read_uleb128(p)
            acc, p = vp.read_uleb128(p)
            coff, p = vp.read_uleb128(p)
            mid += d
            if coff:
                dis = vp.disassemble_code(coff)
                assert "unknown(" not in dis, f"Unknown opcode in {c['name']} mid={mid} off={hex(coff)}"
print("[PASS] All 33,233 code_items in classes.dex disassembled with ZERO unknown opcodes or misaligned boundaries!")

for c in vp.classes.values():
    if not c["cdata_off"]: continue
    p = c["cdata_off"]
    sf, p = vp.read_uleb128(p); inf, p = vp.read_uleb128(p)
    dm, p = vp.read_uleb128(p); vm, p = vp.read_uleb128(p)
    for _ in range(sf + inf): _, p = vp.read_uleb128(p); _, p = vp.read_uleb128(p)
    for m_cnt in (dm, vm):
        mid = 0
        for _ in range(m_cnt):
            d, p = vp.read_uleb128(p); acc, p = vp.read_uleb128(p); coff, p = vp.read_uleb128(p)
            mid += d
            if coff:
                h_orig = struct.unpack_from("<HHHHII", orig_dex, coff)
                h_new = struct.unpack_from("<HHHHII", dex, coff)
                assert h_orig[3] == h_new[3] and h_orig[5] == h_new[5], f"tries/insns mismatch at {hex(coff)}: {h_orig} vs {h_new}"
print("[PASS] 100% of all 33,233 code_items have IDENTICAL tries_size and insns_size to orig_dex!")

def utf16_units(s):
    b = s.encode("utf-16-le")
    return tuple(int.from_bytes(b[i:i+2], "little") for i in range(0, len(b), 2))

prev_u16 = None
prev_s = None
for i in range(string_ids_size):
    off = offsets[i]
    _, p_s = read_uleb128(dex, off)
    end_s = dex.find(b"\x00", p_s)
    cur_s = dex[p_s:end_s].decode("utf-8", errors="replace")
    cur_u16 = utf16_units(cur_s)
    if prev_u16 is not None:
        assert prev_u16 <= cur_u16, f"Out-of-order string_ids at {i-1} -> {i}: {repr(prev_s[:40])} > {repr(cur_s[:40])}"
    prev_u16 = cur_u16
    prev_s = cur_s
print(f"[PASS] All {string_ids_size} strings in string_ids are in 100% strict UTF-16 lexicographical order!")
