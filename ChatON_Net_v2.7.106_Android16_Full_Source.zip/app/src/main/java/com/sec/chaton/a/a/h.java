=== CLASS Lcom/sec/chaton/a/a/h; (Source: ResultEntry.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] a: Z
  [Instance Field] b: Lcom/sec/chaton/a/a/i;
  [Instance Field] c: Ljava/lang/String;

  [Direct Method] <init>(Z) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Lcom/sec/chaton/a/a/h;->a:Z
    0005: return-void

  [Direct Method] <init>(Z, Lcom/sec/chaton/a/a/i;) -> V
    // registers=3, ins=3, outs=1, insns_size=8
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Lcom/sec/chaton/a/a/h;->a:Z
    0005: iput v2, v0.Lcom/sec/chaton/a/a/h;->b:Lcom/sec/chaton/a/a/i;
    0007: return-void

  [Direct Method] <init>(Z, Ljava/lang/String;) -> V
    // registers=3, ins=3, outs=1, insns_size=8
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Lcom/sec/chaton/a/a/h;->a:Z
    0005: iput v2, v0.Lcom/sec/chaton/a/a/h;->c:Ljava/lang/String;
    0007: return-void