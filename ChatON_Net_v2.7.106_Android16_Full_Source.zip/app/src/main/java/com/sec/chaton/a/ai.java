=== CLASS Lcom/sec/chaton/a/ai; (Source: ) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/MessageLiteOrBuilder;