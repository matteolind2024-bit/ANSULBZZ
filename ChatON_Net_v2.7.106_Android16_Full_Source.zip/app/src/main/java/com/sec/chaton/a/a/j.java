=== CLASS Lcom/sec/chaton/a/a/j; (Source: UserProfileEntry.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] a: Ljava/lang/String;
  [Instance Field] b: Ljava/lang/String;
  [Instance Field] c: Ljava/lang/String;
  [Instance Field] d: Ljava/lang/String;
  [Instance Field] e: Ljava/lang/String;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] a() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/j;->a:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] a(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/j;->a:Ljava/lang/String;
    0002: return-void

  [Virtual Method] b() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/j;->b:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] b(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/j;->b:Ljava/lang/String;
    0002: return-void

  [Virtual Method] c() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/j;->c:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] c(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/j;->c:Ljava/lang/String;
    0002: return-void

  [Virtual Method] d() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/j;->d:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] e() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/j;->e:Ljava/lang/String;
    0002: return-object v0