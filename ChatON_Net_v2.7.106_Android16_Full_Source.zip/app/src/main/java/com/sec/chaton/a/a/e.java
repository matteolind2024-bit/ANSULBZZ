=== CLASS Lcom/sec/chaton/a/a/e; (Source: ImageRequestResult.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] a: Landroid/graphics/Bitmap;
  [Instance Field] b: Lcom/sec/chaton/util/am;

  [Direct Method] <init>(Landroid/graphics/Bitmap;, Lcom/sec/chaton/util/am;) -> V
    // registers=3, ins=3, outs=1, insns_size=8
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Lcom/sec/chaton/a/a/e;->a:Landroid/graphics/Bitmap;
    0005: iput v2, v0.Lcom/sec/chaton/a/a/e;->b:Lcom/sec/chaton/util/am;
    0007: return-void

  [Virtual Method] a() -> Landroid/graphics/Bitmap;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/e;->a:Landroid/graphics/Bitmap;
    0002: return-object v0

  [Virtual Method] a(Landroid/graphics/Bitmap;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/e;->a:Landroid/graphics/Bitmap;
    0002: return-void

  [Virtual Method] b() -> Lcom/sec/chaton/util/am;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/e;->b:Lcom/sec/chaton/util/am;
    0002: return-object v0