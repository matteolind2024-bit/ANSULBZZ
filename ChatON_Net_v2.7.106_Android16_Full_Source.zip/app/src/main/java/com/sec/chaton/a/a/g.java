=== CLASS Lcom/sec/chaton/a/a/g; (Source: MessageResultEntry.java) ===
  Super: Ljava/lang/Enum;
  [Static Field] a: Lcom/sec/chaton/a/a/g;
  [Static Field] b: Lcom/sec/chaton/a/a/g;
  [Static Field] c: Lcom/sec/chaton/a/a/g;
  [Static Field] d: Lcom/sec/chaton/a/a/g;
  [Static Field] e: Lcom/sec/chaton/a/a/g;
  [Static Field] f: Lcom/sec/chaton/a/a/g;
  [Static Field] g: Lcom/sec/chaton/a/a/g;
  [Static Field] h: Lcom/sec/chaton/a/a/g;
  [Static Field] i: Lcom/sec/chaton/a/a/g;
  [Static Field] j: Lcom/sec/chaton/a/a/g;
  [Static Field] k: Lcom/sec/chaton/a/a/g;
  [Static Field] l: Lcom/sec/chaton/a/a/g;
  [Static Field] m: Lcom/sec/chaton/a/a/g;
  [Static Field] n: Lcom/sec/chaton/a/a/g;
  [Static Field] o: [Lcom/sec/chaton/a/a/g;

  [Direct Method] <clinit>() -> V
    // registers=8, ins=0, outs=3, insns_size=224
    0000: const/4 v7, 4
    0001: const/4 v6, 3
    0002: const/4 v5, 2
    0003: const/4 v4, 1
    0004: const/4 v3, 0
    0005: new-instance v0, Lcom/sec/chaton/a/a/g;
    0007: const-string v1, 'SUCCESS_RECEIVER_ERROR'
    0009: invoke-direct {v0, v1, v3}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    000c: sput v0, Lcom/sec/chaton/a/a/g;->a:Lcom/sec/chaton/a/a/g;
    000e: new-instance v0, Lcom/sec/chaton/a/a/g;
    0010: const-string v1, 'RETRY'
    0012: invoke-direct {v0, v1, v4}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    0015: sput v0, Lcom/sec/chaton/a/a/g;->b:Lcom/sec/chaton/a/a/g;
    0017: new-instance v0, Lcom/sec/chaton/a/a/g;
    0019: const-string v1, 'CHANGE_SERVER'
    001b: invoke-direct {v0, v1, v5}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    001e: sput v0, Lcom/sec/chaton/a/a/g;->c:Lcom/sec/chaton/a/a/g;
    0020: new-instance v0, Lcom/sec/chaton/a/a/g;
    0022: const-string v1, 'FAIL'
    0024: invoke-direct {v0, v1, v6}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    0027: sput v0, Lcom/sec/chaton/a/a/g;->d:Lcom/sec/chaton/a/a/g;
    0029: new-instance v0, Lcom/sec/chaton/a/a/g;
    002b: const-string v1, 'REGARD_SUCCEESS'
    002d: invoke-direct {v0, v1, v7}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    0030: sput v0, Lcom/sec/chaton/a/a/g;->e:Lcom/sec/chaton/a/a/g;
    0032: new-instance v0, Lcom/sec/chaton/a/a/g;
    0034: const-string v1, 'NEED_HANDLE'
    0036: const/4 v2, 5
    0037: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    003a: sput v0, Lcom/sec/chaton/a/a/g;->f:Lcom/sec/chaton/a/a/g;
    003c: new-instance v0, Lcom/sec/chaton/a/a/g;
    003e: const-string v1, 'BLOCK_RECEIVER'
    0040: const/4 v2, 6
    0041: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    0044: sput v0, Lcom/sec/chaton/a/a/g;->g:Lcom/sec/chaton/a/a/g;
    0046: new-instance v0, Lcom/sec/chaton/a/a/g;
    0048: const-string v1, 'INVALID_USER'
    004a: const/4 v2, 7
    004b: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    004e: sput v0, Lcom/sec/chaton/a/a/g;->h:Lcom/sec/chaton/a/a/g;
    0050: new-instance v0, Lcom/sec/chaton/a/a/g;
    0052: const-string v1, 'END_APP'
    0054: const/16 v2, 8 (0x8)
    0056: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    0059: sput v0, Lcom/sec/chaton/a/a/g;->i:Lcom/sec/chaton/a/a/g;
    005b: new-instance v0, Lcom/sec/chaton/a/a/g;
    005d: const-string v1, 'RESTART_APP'
    005f: const/16 v2, 9 (0x9)
    0061: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    0064: sput v0, Lcom/sec/chaton/a/a/g;->j:Lcom/sec/chaton/a/a/g;
    0066: new-instance v0, Lcom/sec/chaton/a/a/g;
    0068: const-string v1, 'SESSION_USER_NOT_EXIST'
    006a: const/16 v2, 10 (0xa)
    006c: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    006f: sput v0, Lcom/sec/chaton/a/a/g;->k:Lcom/sec/chaton/a/a/g;
    0071: new-instance v0, Lcom/sec/chaton/a/a/g;
    0073: const-string v1, 'RESET_BY_WEB'
    0075: const/16 v2, 11 (0xb)
    0077: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    007a: sput v0, Lcom/sec/chaton/a/a/g;->l:Lcom/sec/chaton/a/a/g;
    007c: new-instance v0, Lcom/sec/chaton/a/a/g;
    007e: const-string v1, 'NON_WEB_USER_DETECTED'
    0080: const/16 v2, 12 (0xc)
    0082: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    0085: sput v0, Lcom/sec/chaton/a/a/g;->m:Lcom/sec/chaton/a/a/g;
    0087: new-instance v0, Lcom/sec/chaton/a/a/g;
    0089: const-string v1, 'SESSION_DEACTIVATED'
    008b: const/16 v2, 13 (0xd)
    008d: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/a/a/g;-><init>(Ljava/lang/String;I)V
    0090: sput v0, Lcom/sec/chaton/a/a/g;->n:Lcom/sec/chaton/a/a/g;
    0092: const/16 v0, 14 (0xe)
    0094: new-array v0, v0, [Lcom/sec/chaton/a/a/g;
    0096: sget v1, Lcom/sec/chaton/a/a/g;->a:Lcom/sec/chaton/a/a/g;
    0098: aput(op=4d) v1, v0[v3]
    009a: sget v1, Lcom/sec/chaton/a/a/g;->b:Lcom/sec/chaton/a/a/g;
    009c: aput(op=4d) v1, v0[v4]
    009e: sget v1, Lcom/sec/chaton/a/a/g;->c:Lcom/sec/chaton/a/a/g;
    00a0: aput(op=4d) v1, v0[v5]
    00a2: sget v1, Lcom/sec/chaton/a/a/g;->d:Lcom/sec/chaton/a/a/g;
    00a4: aput(op=4d) v1, v0[v6]
    00a6: sget v1, Lcom/sec/chaton/a/a/g;->e:Lcom/sec/chaton/a/a/g;
    00a8: aput(op=4d) v1, v0[v7]
    00aa: const/4 v1, 5
    00ab: sget v2, Lcom/sec/chaton/a/a/g;->f:Lcom/sec/chaton/a/a/g;
    00ad: aput(op=4d) v2, v0[v1]
    00af: const/4 v1, 6
    00b0: sget v2, Lcom/sec/chaton/a/a/g;->g:Lcom/sec/chaton/a/a/g;
    00b2: aput(op=4d) v2, v0[v1]
    00b4: const/4 v1, 7
    00b5: sget v2, Lcom/sec/chaton/a/a/g;->h:Lcom/sec/chaton/a/a/g;
    00b7: aput(op=4d) v2, v0[v1]
    00b9: const/16 v1, 8 (0x8)
    00bb: sget v2, Lcom/sec/chaton/a/a/g;->i:Lcom/sec/chaton/a/a/g;
    00bd: aput(op=4d) v2, v0[v1]
    00bf: const/16 v1, 9 (0x9)
    00c1: sget v2, Lcom/sec/chaton/a/a/g;->j:Lcom/sec/chaton/a/a/g;
    00c3: aput(op=4d) v2, v0[v1]
    00c5: const/16 v1, 10 (0xa)
    00c7: sget v2, Lcom/sec/chaton/a/a/g;->k:Lcom/sec/chaton/a/a/g;
    00c9: aput(op=4d) v2, v0[v1]
    00cb: const/16 v1, 11 (0xb)
    00cd: sget v2, Lcom/sec/chaton/a/a/g;->l:Lcom/sec/chaton/a/a/g;
    00cf: aput(op=4d) v2, v0[v1]
    00d1: const/16 v1, 12 (0xc)
    00d3: sget v2, Lcom/sec/chaton/a/a/g;->m:Lcom/sec/chaton/a/a/g;
    00d5: aput(op=4d) v2, v0[v1]
    00d7: const/16 v1, 13 (0xd)
    00d9: sget v2, Lcom/sec/chaton/a/a/g;->n:Lcom/sec/chaton/a/a/g;
    00db: aput(op=4d) v2, v0[v1]
    00dd: sput v0, Lcom/sec/chaton/a/a/g;->o:[Lcom/sec/chaton/a/a/g;
    00df: return-void

  [Direct Method] <init>(Ljava/lang/String;, I) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    0003: return-void

  [Direct Method] valueOf(Ljava/lang/String;) -> Lcom/sec/chaton/a/a/g;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: const-class v0, Lcom/sec/chaton/a/a/g;
    0002: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    0005: move-result-object v0
    0006: check-cast v0, Lcom/sec/chaton/a/a/g;
    0008: return-object v0

  [Direct Method] values() -> [Lcom/sec/chaton/a/a/g;
    // registers=1, ins=0, outs=1, insns_size=9
    0000: sget v0, Lcom/sec/chaton/a/a/g;->o:[Lcom/sec/chaton/a/a/g;
    0002: invoke-virtual {v0}, [Lcom/sec/chaton/a/a/g;->clone()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, [Lcom/sec/chaton/a/a/g;
    0008: return-object v0