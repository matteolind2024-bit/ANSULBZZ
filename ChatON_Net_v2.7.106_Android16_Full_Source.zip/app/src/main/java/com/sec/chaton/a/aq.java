=== CLASS Lcom/sec/chaton/a/aq; (Source: ) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/MessageLiteOrBuilder;