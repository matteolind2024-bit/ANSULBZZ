=== CLASS Lcom/sec/chaton/a/a; (Source: SSMGPB.java) ===
  Super: Ljava/lang/Object;