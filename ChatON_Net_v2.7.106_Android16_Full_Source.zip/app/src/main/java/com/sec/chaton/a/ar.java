=== CLASS Lcom/sec/chaton/a/ar; (Source: SSMGPB.java) ===
  Super: Ljava/lang/Enum;
  Interfaces: Lcom/google/protobuf/Internal$EnumLite;
  [Static Field] a: Lcom/sec/chaton/a/ar;
  [Static Field] b: Lcom/sec/chaton/a/ar;
  [Static Field] c: Lcom/sec/chaton/a/ar;
  [Static Field] d: Lcom/google/protobuf/Internal$EnumLiteMap;
  [Static Field] f: [Lcom/sec/chaton/a/ar;
  [Instance Field] e: I

  [Direct Method] <clinit>() -> V
    // registers=5, ins=0, outs=5, insns_size=55
    0000: const/4 v4, 2
    0001: const/4 v3, 1
    0002: const/4 v2, 0
    0003: new-instance v0, Lcom/sec/chaton/a/ar;
    0005: const-string v1, 'SINGLE'
    0007: invoke-direct {v0, v1, v2, v2, v2}, Lcom/sec/chaton/a/ar;-><init>(Ljava/lang/String;III)V
    000a: sput v0, Lcom/sec/chaton/a/ar;->a:Lcom/sec/chaton/a/ar;
    000c: new-instance v0, Lcom/sec/chaton/a/ar;
    000e: const-string v1, 'GROUP'
    0010: invoke-direct {v0, v1, v3, v3, v3}, Lcom/sec/chaton/a/ar;-><init>(Ljava/lang/String;III)V
    0013: sput v0, Lcom/sec/chaton/a/ar;->b:Lcom/sec/chaton/a/ar;
    0015: new-instance v0, Lcom/sec/chaton/a/ar;
    0017: const-string v1, 'BROADCAST'
    0019: invoke-direct {v0, v1, v4, v4, v4}, Lcom/sec/chaton/a/ar;-><init>(Ljava/lang/String;III)V
    001c: sput v0, Lcom/sec/chaton/a/ar;->c:Lcom/sec/chaton/a/ar;
    001e: const/4 v0, 3
    001f: new-array v0, v0, [Lcom/sec/chaton/a/ar;
    0021: sget v1, Lcom/sec/chaton/a/ar;->a:Lcom/sec/chaton/a/ar;
    0023: aput(op=4d) v1, v0[v2]
    0025: sget v1, Lcom/sec/chaton/a/ar;->b:Lcom/sec/chaton/a/ar;
    0027: aput(op=4d) v1, v0[v3]
    0029: sget v1, Lcom/sec/chaton/a/ar;->c:Lcom/sec/chaton/a/ar;
    002b: aput(op=4d) v1, v0[v4]
    002d: sput v0, Lcom/sec/chaton/a/ar;->f:[Lcom/sec/chaton/a/ar;
    002f: new-instance v0, Lcom/sec/chaton/a/as;
    0031: invoke-direct {v0}, Lcom/sec/chaton/a/as;-><init>()V
    0034: sput v0, Lcom/sec/chaton/a/ar;->d:Lcom/google/protobuf/Internal$EnumLiteMap;
    0036: return-void

  [Direct Method] <init>(Ljava/lang/String;, I, I, I) -> V
    // registers=5, ins=5, outs=3, insns_size=6
    0000: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    0003: iput v4, v0.Lcom/sec/chaton/a/ar;->e:I
    0005: return-void

  [Direct Method] a(I) -> Lcom/sec/chaton/a/ar;
    // registers=2, ins=1, outs=0, insns_size=24
    0000: packed-switch v1, +14 (-> 000e)
    0003: const/4 v0, 0
    0004: return-object v0
    0005: sget v0, Lcom/sec/chaton/a/ar;->a:Lcom/sec/chaton/a/ar;
    0007: goto 0004
    0008: sget v0, Lcom/sec/chaton/a/ar;->b:Lcom/sec/chaton/a/ar;
    000a: goto 0004
    000b: sget v0, Lcom/sec/chaton/a/ar;->c:Lcom/sec/chaton/a/ar;
    000d: goto 0004
    000e: packed-switch-payload first=0 targets=[5, 8, 11]

  [Direct Method] valueOf(Ljava/lang/String;) -> Lcom/sec/chaton/a/ar;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: const-class v0, Lcom/sec/chaton/a/ar;
    0002: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    0005: move-result-object v0
    0006: check-cast v0, Lcom/sec/chaton/a/ar;
    0008: return-object v0

  [Direct Method] values() -> [Lcom/sec/chaton/a/ar;
    // registers=1, ins=0, outs=1, insns_size=9
    0000: sget v0, Lcom/sec/chaton/a/ar;->f:[Lcom/sec/chaton/a/ar;
    0002: invoke-virtual {v0}, [Lcom/sec/chaton/a/ar;->clone()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, [Lcom/sec/chaton/a/ar;
    0008: return-object v0

  [Virtual Method] getNumber() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/ar;->e:I
    0002: return v0