=== CLASS Lcom/sec/chaton/a/bd; (Source: ) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/MessageLiteOrBuilder;