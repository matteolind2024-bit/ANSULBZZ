=== CLASS Lcom/sec/chaton/a/bf; (Source: SSMGPB.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/Internal$EnumLiteMap;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] a(I) -> Lcom/sec/chaton/a/be;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Lcom/sec/chaton/a/be;->a(I)Lcom/sec/chaton/a/be;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] findValueByNumber(I) -> Lcom/google/protobuf/Internal$EnumLite;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Lcom/sec/chaton/a/bf;->a(I)Lcom/sec/chaton/a/be;
    0003: move-result-object v0
    0004: return-object v0