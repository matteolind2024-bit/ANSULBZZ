=== CLASS Lcom/sec/chaton/a/an; (Source: ) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/MessageLiteOrBuilder;