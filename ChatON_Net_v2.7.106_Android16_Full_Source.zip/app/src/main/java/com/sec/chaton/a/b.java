=== CLASS Lcom/sec/chaton/a/b; (Source: SSMGPB.java) ===
  Super: Ljava/lang/Object;