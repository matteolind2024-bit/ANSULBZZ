=== CLASS Lcom/sec/chaton/a/a/i; (Source: ResultEntry.java) ===
  Super: Ljava/lang/Enum;
  [Static Field] a: Lcom/sec/chaton/a/a/i;
  [Static Field] b: Lcom/sec/chaton/a/a/i;
  [Static Field] c: Lcom/sec/chaton/a/a/i;
  [Static Field] d: Lcom/sec/chaton/a/a/i;
  [Static Field] e: [Lcom/sec/chaton/a/a/i;

  [Direct Method] <clinit>() -> V
    // registers=6, ins=0, outs=3, insns_size=62
    0000: const/4 v5, 3
    0001: const/4 v4, 2
    0002: const/4 v3, 1
    0003: const/4 v2, 0
    0004: new-instance v0, Lcom/sec/chaton/a/a/i;
    0006: const-string v1, 'SUCCESS'
    0008: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/a/a/i;-><init>(Ljava/lang/String;I)V
    000b: sput v0, Lcom/sec/chaton/a/a/i;->a:Lcom/sec/chaton/a/a/i;
    000d: new-instance v0, Lcom/sec/chaton/a/a/i;
    000f: const-string v1, 'SUCCESS_UPLOAD_ONLY'
    0011: invoke-direct {v0, v1, v3}, Lcom/sec/chaton/a/a/i;-><init>(Ljava/lang/String;I)V
    0014: sput v0, Lcom/sec/chaton/a/a/i;->b:Lcom/sec/chaton/a/a/i;
    0016: new-instance v0, Lcom/sec/chaton/a/a/i;
    0018: const-string v1, 'FAIL'
    001a: invoke-direct {v0, v1, v4}, Lcom/sec/chaton/a/a/i;-><init>(Ljava/lang/String;I)V
    001d: sput v0, Lcom/sec/chaton/a/a/i;->c:Lcom/sec/chaton/a/a/i;
    001f: new-instance v0, Lcom/sec/chaton/a/a/i;
    0021: const-string v1, 'NETWORKFAIL'
    0023: invoke-direct {v0, v1, v5}, Lcom/sec/chaton/a/a/i;-><init>(Ljava/lang/String;I)V
    0026: sput v0, Lcom/sec/chaton/a/a/i;->d:Lcom/sec/chaton/a/a/i;
    0028: const/4 v0, 4
    0029: new-array v0, v0, [Lcom/sec/chaton/a/a/i;
    002b: sget v1, Lcom/sec/chaton/a/a/i;->a:Lcom/sec/chaton/a/a/i;
    002d: aput(op=4d) v1, v0[v2]
    002f: sget v1, Lcom/sec/chaton/a/a/i;->b:Lcom/sec/chaton/a/a/i;
    0031: aput(op=4d) v1, v0[v3]
    0033: sget v1, Lcom/sec/chaton/a/a/i;->c:Lcom/sec/chaton/a/a/i;
    0035: aput(op=4d) v1, v0[v4]
    0037: sget v1, Lcom/sec/chaton/a/a/i;->d:Lcom/sec/chaton/a/a/i;
    0039: aput(op=4d) v1, v0[v5]
    003b: sput v0, Lcom/sec/chaton/a/a/i;->e:[Lcom/sec/chaton/a/a/i;
    003d: return-void

  [Direct Method] <init>(Ljava/lang/String;, I) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    0003: return-void

  [Direct Method] valueOf(Ljava/lang/String;) -> Lcom/sec/chaton/a/a/i;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: const-class v0, Lcom/sec/chaton/a/a/i;
    0002: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    0005: move-result-object v0
    0006: check-cast v0, Lcom/sec/chaton/a/a/i;
    0008: return-object v0

  [Direct Method] values() -> [Lcom/sec/chaton/a/a/i;
    // registers=1, ins=0, outs=1, insns_size=9
    0000: sget v0, Lcom/sec/chaton/a/a/i;->e:[Lcom/sec/chaton/a/a/i;
    0002: invoke-virtual {v0}, [Lcom/sec/chaton/a/a/i;->clone()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, [Lcom/sec/chaton/a/a/i;
    0008: return-object v0