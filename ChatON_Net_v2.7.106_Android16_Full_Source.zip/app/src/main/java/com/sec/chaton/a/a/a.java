=== CLASS Lcom/sec/chaton/a/a/a; (Source: BuddyEntry.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] a: Ljava/lang/String;
  [Instance Field] b: Ljava/lang/String;
  [Instance Field] c: Ljava/lang/String;

  [Direct Method] <init>(Ljava/lang/String;) -> V
    // registers=4, ins=2, outs=2, insns_size=19
    0000: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0003: iput v3, v2.Lcom/sec/chaton/a/a/a;->a:Ljava/lang/String;
    0005: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->c()Landroid/content/res/Resources;
    0008: move-result-object v0
    0009: const v1, 2131493165 (0x7f0c012d)
    000c: invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    000f: move-result-object v0
    0010: iput v0, v2.Lcom/sec/chaton/a/a/a;->b:Ljava/lang/String;
    0012: return-void

  [Direct Method] <init>(Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;) -> V
    // registers=4, ins=4, outs=1, insns_size=10
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Lcom/sec/chaton/a/a/a;->a:Ljava/lang/String;
    0005: iput v2, v0.Lcom/sec/chaton/a/a/a;->b:Ljava/lang/String;
    0007: iput v3, v0.Lcom/sec/chaton/a/a/a;->c:Ljava/lang/String;
    0009: return-void

  [Virtual Method] a() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/a;->b:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] a(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/a;->b:Ljava/lang/String;
    0002: return-void

  [Virtual Method] b(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/a;->c:Ljava/lang/String;
    0002: return-void