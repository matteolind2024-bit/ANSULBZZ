=== CLASS Lcom/sec/chaton/a/af; (Source: ) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/MessageLiteOrBuilder;