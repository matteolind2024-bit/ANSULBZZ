=== CLASS Lcom/sec/chaton/a/a/c; (Source: DeliveryChatResultEntry.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] a: Z
  [Instance Field] b: Lcom/sec/chaton/a/a/i;
  [Instance Field] c: I
  [Instance Field] d: Ljava/lang/String;
  [Instance Field] e: Z
  [Instance Field] f: I
  [Instance Field] g: Ljava/lang/String;
  [Instance Field] h: Ljava/lang/String;
  [Instance Field] i: Lcom/sec/chaton/e/s;
  [Instance Field] j: Ljava/util/ArrayList;

  [Direct Method] <init>() -> V
    // registers=3, ins=1, outs=1, insns_size=26
    0000: const/4 v1, 0
    0001: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0004: iput v1, v2.Lcom/sec/chaton/a/a/c;->a:Z
    0006: sget v0, Lcom/sec/chaton/a/a/i;->a:Lcom/sec/chaton/a/a/i;
    0008: iput v0, v2.Lcom/sec/chaton/a/a/c;->b:Lcom/sec/chaton/a/a/i;
    000a: const/16 v0, 1000 (0x3e8)
    000c: iput v0, v2.Lcom/sec/chaton/a/a/c;->c:I
    000e: const-string v0, ''
    0010: iput v0, v2.Lcom/sec/chaton/a/a/c;->d:Ljava/lang/String;
    0012: iput v1, v2.Lcom/sec/chaton/a/a/c;->e:Z
    0014: iput v1, v2.Lcom/sec/chaton/a/a/c;->f:I
    0016: const/4 v0, 0
    0017: iput v0, v2.Lcom/sec/chaton/a/a/c;->j:Ljava/util/ArrayList;
    0019: return-void

  [Virtual Method] a() -> Lcom/sec/chaton/a/a/b;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Lcom/sec/chaton/a/a/b;
    0002: invoke-direct {v0, v1}, Lcom/sec/chaton/a/a/b;-><init>(Lcom/sec/chaton/a/a/c;)V
    0005: return-object v0

  [Virtual Method] a(I) -> Lcom/sec/chaton/a/a/c;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/c;->f:I
    0002: return-object v0

  [Virtual Method] a(Lcom/sec/chaton/a/a/i;) -> Lcom/sec/chaton/a/a/c;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/c;->b:Lcom/sec/chaton/a/a/i;
    0002: return-object v0

  [Virtual Method] a(Lcom/sec/chaton/e/s;) -> Lcom/sec/chaton/a/a/c;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/c;->i:Lcom/sec/chaton/e/s;
    0002: return-object v0

  [Virtual Method] a(Ljava/lang/String;) -> Lcom/sec/chaton/a/a/c;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/c;->d:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] a(Ljava/util/List;) -> Lcom/sec/chaton/a/a/c;
    // registers=3, ins=2, outs=2, insns_size=8
    0000: new-instance v0, Ljava/util/ArrayList;
    0002: invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    0005: iput v0, v1.Lcom/sec/chaton/a/a/c;->j:Ljava/util/ArrayList;
    0007: return-object v1

  [Virtual Method] a(Z) -> Lcom/sec/chaton/a/a/c;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/c;->a:Z
    0002: return-object v0

  [Virtual Method] b(Ljava/lang/String;) -> Lcom/sec/chaton/a/a/c;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/c;->h:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] b(Z) -> Lcom/sec/chaton/a/a/c;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/c;->e:Z
    0002: return-object v0

  [Virtual Method] c(Ljava/lang/String;) -> Lcom/sec/chaton/a/a/c;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/a/c;->g:Ljava/lang/String;
    0002: return-object v0