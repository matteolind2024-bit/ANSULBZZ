=== CLASS Lcom/sec/chaton/a/a/f; (Source: MessageResultEntry.java) ===
  Super: Lcom/sec/chaton/a/a/h;
  [Instance Field] d: I
  [Instance Field] e: J

  [Direct Method] <init>(Z, I) -> V
    // registers=5, ins=3, outs=2, insns_size=14
    0000: invoke-direct {v2, v3}, Lcom/sec/chaton/a/a/h;-><init>(Z)V
    0003: iput v4, v2.Lcom/sec/chaton/a/a/f;->d:I
    0005: sget v0, Lcom/sec/chaton/a/a/i;->a:Lcom/sec/chaton/a/a/i;
    0007: iput v0, v2.Lcom/sec/chaton/a/a/f;->b:Lcom/sec/chaton/a/a/i;
    0009: const-wide/16 v0, -1
    000b: iput v0, v2.Lcom/sec/chaton/a/a/f;->e:J
    000d: return-void

  [Direct Method] <init>(Z, I, J) -> V
    // registers=6, ins=5, outs=2, insns_size=12
    0000: invoke-direct {v1, v2}, Lcom/sec/chaton/a/a/h;-><init>(Z)V
    0003: iput v3, v1.Lcom/sec/chaton/a/a/f;->d:I
    0005: sget v0, Lcom/sec/chaton/a/a/i;->a:Lcom/sec/chaton/a/a/i;
    0007: iput v0, v1.Lcom/sec/chaton/a/a/f;->b:Lcom/sec/chaton/a/a/i;
    0009: iput v4, v1.Lcom/sec/chaton/a/a/f;->e:J
    000b: return-void

  [Direct Method] <init>(Z, I, Ljava/lang/String;) -> V
    // registers=6, ins=4, outs=3, insns_size=14
    0000: invoke-direct {v2, v3, v5}, Lcom/sec/chaton/a/a/h;-><init>(ZLjava/lang/String;)V
    0003: iput v4, v2.Lcom/sec/chaton/a/a/f;->d:I
    0005: sget v0, Lcom/sec/chaton/a/a/i;->a:Lcom/sec/chaton/a/a/i;
    0007: iput v0, v2.Lcom/sec/chaton/a/a/f;->b:Lcom/sec/chaton/a/a/i;
    0009: const-wide/16 v0, -1
    000b: iput v0, v2.Lcom/sec/chaton/a/a/f;->e:J
    000d: return-void

  [Direct Method] <init>(Z, I, Ljava/lang/String;, J) -> V
    // registers=7, ins=6, outs=3, insns_size=12
    0000: invoke-direct {v1, v2, v4}, Lcom/sec/chaton/a/a/h;-><init>(ZLjava/lang/String;)V
    0003: iput v3, v1.Lcom/sec/chaton/a/a/f;->d:I
    0005: sget v0, Lcom/sec/chaton/a/a/i;->a:Lcom/sec/chaton/a/a/i;
    0007: iput v0, v1.Lcom/sec/chaton/a/a/f;->b:Lcom/sec/chaton/a/a/i;
    0009: iput v5, v1.Lcom/sec/chaton/a/a/f;->e:J
    000b: return-void

  [Direct Method] <init>(Z, Lcom/sec/chaton/a/a/i;) -> V
    // registers=5, ins=3, outs=3, insns_size=11
    0000: invoke-direct {v2, v3, v4}, Lcom/sec/chaton/a/a/h;-><init>(ZLcom/sec/chaton/a/a/i;)V
    0003: const/4 v0, -1
    0004: iput v0, v2.Lcom/sec/chaton/a/a/f;->d:I
    0006: const-wide/16 v0, -1
    0008: iput v0, v2.Lcom/sec/chaton/a/a/f;->e:J
    000a: return-void

  [Virtual Method] g() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: const/16 v0, 1000 (0x3e8)
    0002: return v0

  [Virtual Method] h() -> J
    // registers=3, ins=1, outs=0, insns_size=3
    0000: iget v0, v2.Lcom/sec/chaton/a/a/f;->e:J
    0002: return-wide v0