=== CLASS Lcom/sec/chaton/a/a/b; (Source: DeliveryChatResultEntry.java) ===
  Super: Lcom/sec/chaton/a/a/f;
  [Instance Field] d: Ljava/lang/String;
  [Instance Field] e: Z
  [Instance Field] f: I
  [Instance Field] g: Ljava/util/ArrayList;
  [Instance Field] h: Ljava/lang/String;
  [Instance Field] i: Ljava/lang/String;
  [Instance Field] j: Lcom/sec/chaton/e/s;

  [Direct Method] <init>(Lcom/sec/chaton/a/a/c;) -> V
    // registers=4, ins=2, outs=3, insns_size=41
    0000: iget v0, v3.Lcom/sec/chaton/a/a/c;->a:Z
    0002: iget v1, v3.Lcom/sec/chaton/a/a/c;->b:Lcom/sec/chaton/a/a/i;
    0004: invoke-direct {v2, v0, v1}, Lcom/sec/chaton/a/a/f;-><init>(ZLcom/sec/chaton/a/a/i;)V
    0007: iget v0, v3.Lcom/sec/chaton/a/a/c;->d:Ljava/lang/String;
    0009: iput v0, v2.Lcom/sec/chaton/a/a/b;->d:Ljava/lang/String;
    000b: iget v0, v3.Lcom/sec/chaton/a/a/c;->e:Z
    000d: iput v0, v2.Lcom/sec/chaton/a/a/b;->e:Z
    000f: iget v0, v3.Lcom/sec/chaton/a/a/c;->f:I
    0011: iput v0, v2.Lcom/sec/chaton/a/a/b;->f:I
    0013: iget v0, v3.Lcom/sec/chaton/a/a/c;->g:Ljava/lang/String;
    0015: iput v0, v2.Lcom/sec/chaton/a/a/b;->i:Ljava/lang/String;
    0017: iget v0, v3.Lcom/sec/chaton/a/a/c;->h:Ljava/lang/String;
    0019: iput v0, v2.Lcom/sec/chaton/a/a/b;->h:Ljava/lang/String;
    001b: iget v0, v3.Lcom/sec/chaton/a/a/c;->i:Lcom/sec/chaton/e/s;
    001d: iput v0, v2.Lcom/sec/chaton/a/a/b;->j:Lcom/sec/chaton/e/s;
    001f: new-instance v0, Ljava/util/ArrayList;
    0021: iget v1, v3.Lcom/sec/chaton/a/a/c;->j:Ljava/util/ArrayList;
    0023: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    0026: iput v0, v2.Lcom/sec/chaton/a/a/b;->g:Ljava/util/ArrayList;
    0028: return-void

  [Virtual Method] a() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/b;->e:Z
    0002: return v0

  [Virtual Method] b() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/b;->f:I
    0002: return v0

  [Virtual Method] c() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/b;->h:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] d() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/b;->i:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] e() -> Lcom/sec/chaton/e/s;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/a/b;->j:Lcom/sec/chaton/e/s;
    0002: return-object v0

  [Virtual Method] f() -> [Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=12
    0000: iget v0, v2.Lcom/sec/chaton/a/a/b;->g:Ljava/util/ArrayList;
    0002: const/4 v1, 0
    0003: new-array v1, v1, [Ljava/lang/String;
    0005: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    0008: move-result-object v0
    0009: check-cast v0, [Ljava/lang/String;
    000b: return-object v0