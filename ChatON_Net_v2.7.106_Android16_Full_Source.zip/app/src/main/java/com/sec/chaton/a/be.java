=== CLASS Lcom/sec/chaton/a/be; (Source: SSMGPB.java) ===
  Super: Ljava/lang/Enum;
  Interfaces: Lcom/google/protobuf/Internal$EnumLite;
  [Static Field] a: Lcom/sec/chaton/a/be;
  [Static Field] b: Lcom/sec/chaton/a/be;
  [Static Field] c: Lcom/google/protobuf/Internal$EnumLiteMap;
  [Static Field] e: [Lcom/sec/chaton/a/be;
  [Instance Field] d: I

  [Direct Method] <clinit>() -> V
    // registers=4, ins=0, outs=5, insns_size=41
    0000: const/4 v3, 1
    0001: const/4 v2, 0
    0002: new-instance v0, Lcom/sec/chaton/a/be;
    0004: const-string v1, 'CLOSE'
    0006: invoke-direct {v0, v1, v2, v2, v2}, Lcom/sec/chaton/a/be;-><init>(Ljava/lang/String;III)V
    0009: sput v0, Lcom/sec/chaton/a/be;->a:Lcom/sec/chaton/a/be;
    000b: new-instance v0, Lcom/sec/chaton/a/be;
    000d: const-string v1, 'HOLD_ON'
    000f: invoke-direct {v0, v1, v3, v3, v3}, Lcom/sec/chaton/a/be;-><init>(Ljava/lang/String;III)V
    0012: sput v0, Lcom/sec/chaton/a/be;->b:Lcom/sec/chaton/a/be;
    0014: const/4 v0, 2
    0015: new-array v0, v0, [Lcom/sec/chaton/a/be;
    0017: sget v1, Lcom/sec/chaton/a/be;->a:Lcom/sec/chaton/a/be;
    0019: aput(op=4d) v1, v0[v2]
    001b: sget v1, Lcom/sec/chaton/a/be;->b:Lcom/sec/chaton/a/be;
    001d: aput(op=4d) v1, v0[v3]
    001f: sput v0, Lcom/sec/chaton/a/be;->e:[Lcom/sec/chaton/a/be;
    0021: new-instance v0, Lcom/sec/chaton/a/bf;
    0023: invoke-direct {v0}, Lcom/sec/chaton/a/bf;-><init>()V
    0026: sput v0, Lcom/sec/chaton/a/be;->c:Lcom/google/protobuf/Internal$EnumLiteMap;
    0028: return-void

  [Direct Method] <init>(Ljava/lang/String;, I, I, I) -> V
    // registers=5, ins=5, outs=3, insns_size=6
    0000: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    0003: iput v4, v0.Lcom/sec/chaton/a/be;->d:I
    0005: return-void

  [Direct Method] a(I) -> Lcom/sec/chaton/a/be;
    // registers=2, ins=1, outs=0, insns_size=20
    0000: packed-switch v1, +12 (-> 000c)
    0003: const/4 v0, 0
    0004: return-object v0
    0005: sget v0, Lcom/sec/chaton/a/be;->a:Lcom/sec/chaton/a/be;
    0007: goto 0004
    0008: sget v0, Lcom/sec/chaton/a/be;->b:Lcom/sec/chaton/a/be;
    000a: goto 0004
    000b: nop
    000c: packed-switch-payload first=0 targets=[5, 8]

  [Direct Method] valueOf(Ljava/lang/String;) -> Lcom/sec/chaton/a/be;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: const-class v0, Lcom/sec/chaton/a/be;
    0002: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    0005: move-result-object v0
    0006: check-cast v0, Lcom/sec/chaton/a/be;
    0008: return-object v0

  [Direct Method] values() -> [Lcom/sec/chaton/a/be;
    // registers=1, ins=0, outs=1, insns_size=9
    0000: sget v0, Lcom/sec/chaton/a/be;->e:[Lcom/sec/chaton/a/be;
    0002: invoke-virtual {v0}, [Lcom/sec/chaton/a/be;->clone()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, [Lcom/sec/chaton/a/be;
    0008: return-object v0

  [Virtual Method] getNumber() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/be;->d:I
    0002: return v0