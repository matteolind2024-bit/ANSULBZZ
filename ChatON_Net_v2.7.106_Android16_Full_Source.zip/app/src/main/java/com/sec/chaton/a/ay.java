=== CLASS Lcom/sec/chaton/a/ay; (Source: SSMGPB.java) ===
  Super: Lcom/google/protobuf/GeneratedMessageLite;
  Interfaces: Lcom/sec/chaton/a/bd;
  [Static Field] a: Lcom/sec/chaton/a/ay;
  [Instance Field] b: I
  [Instance Field] c: Ljava/lang/Object;
  [Instance Field] d: Ljava/util/List;
  [Instance Field] e: Lcom/sec/chaton/a/dd;
  [Instance Field] f: I
  [Instance Field] g: J
  [Instance Field] h: Ljava/lang/Object;
  [Instance Field] i: B
  [Instance Field] j: I

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=2, insns_size=14
    0000: new-instance v0, Lcom/sec/chaton/a/ay;
    0002: const/4 v1, 1
    0003: invoke-direct {v0, v1}, Lcom/sec/chaton/a/ay;-><init>(Z)V
    0006: sput v0, Lcom/sec/chaton/a/ay;->a:Lcom/sec/chaton/a/ay;
    0008: sget v0, Lcom/sec/chaton/a/ay;->a:Lcom/sec/chaton/a/ay;
    000a: invoke-direct {v0}, Lcom/sec/chaton/a/ay;->s()V
    000d: return-void

  [Direct Method] <init>(Lcom/sec/chaton/a/az;) -> V
    // registers=3, ins=2, outs=2, insns_size=9
    0000: const/4 v0, -1
    0001: invoke-direct {v1, v2}, Lcom/google/protobuf/GeneratedMessageLite;-><init>(Lcom/google/protobuf/GeneratedMessageLite$Builder;)V
    0004: iput v0, v1.Lcom/sec/chaton/a/ay;->i:B
    0006: iput v0, v1.Lcom/sec/chaton/a/ay;->j:I
    0008: return-void

  [Direct Method] <init>(Lcom/sec/chaton/a/az;, Lcom/sec/chaton/a/b;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/sec/chaton/a/ay;-><init>(Lcom/sec/chaton/a/az;)V
    0003: return-void

  [Direct Method] <init>(Z) -> V
    // registers=3, ins=2, outs=1, insns_size=9
    0000: const/4 v0, -1
    0001: invoke-direct {v1}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V
    0004: iput v0, v1.Lcom/sec/chaton/a/ay;->i:B
    0006: iput v0, v1.Lcom/sec/chaton/a/ay;->j:I
    0008: return-void

  [Direct Method] a(Lcom/sec/chaton/a/ay;, I) -> I
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/ay;->f:I
    0002: return v1

  [Direct Method] a(Lcom/sec/chaton/a/ay;, J) -> J
    // registers=3, ins=3, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/ay;->g:J
    0002: return-wide v1

  [Direct Method] a() -> Lcom/sec/chaton/a/ay;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/sec/chaton/a/ay;->a:Lcom/sec/chaton/a/ay;
    0002: return-object v0

  [Direct Method] a([B) -> Lcom/sec/chaton/a/ay;
    // registers=2, ins=1, outs=2, insns_size=15
    0000: invoke-static {}, Lcom/sec/chaton/a/ay;->newBuilder()Lcom/sec/chaton/a/az;
    0003: move-result-object v0
    0004: invoke-virtual {v0, v1}, Lcom/sec/chaton/a/az;->mergeFrom([B)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0007: move-result-object v0
    0008: check-cast v0, Lcom/sec/chaton/a/az;
    000a: invoke-static {v0}, Lcom/sec/chaton/a/az;->a(Lcom/sec/chaton/a/az;)Lcom/sec/chaton/a/ay;
    000d: move-result-object v0
    000e: return-object v0

  [Direct Method] a(Lcom/sec/chaton/a/ay;) -> Lcom/sec/chaton/a/az;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: invoke-static {}, Lcom/sec/chaton/a/ay;->newBuilder()Lcom/sec/chaton/a/az;
    0003: move-result-object v0
    0004: invoke-virtual {v0, v1}, Lcom/sec/chaton/a/az;->a(Lcom/sec/chaton/a/ay;)Lcom/sec/chaton/a/az;
    0007: move-result-object v0
    0008: return-object v0

  [Direct Method] a(Lcom/sec/chaton/a/ay;, Lcom/sec/chaton/a/dd;) -> Lcom/sec/chaton/a/dd;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/ay;->e:Lcom/sec/chaton/a/dd;
    0002: return-object v1

  [Direct Method] a(Lcom/sec/chaton/a/ay;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/ay;->c:Ljava/lang/Object;
    0002: return-object v1

  [Direct Method] a(Lcom/sec/chaton/a/ay;, Ljava/util/List;) -> Ljava/util/List;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/ay;->d:Ljava/util/List;
    0002: return-object v1

  [Direct Method] b(Lcom/sec/chaton/a/ay;, I) -> I
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/ay;->b:I
    0002: return v1

  [Direct Method] b(Lcom/sec/chaton/a/ay;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/a/ay;->h:Ljava/lang/Object;
    0002: return-object v1

  [Direct Method] b(Lcom/sec/chaton/a/ay;) -> Ljava/util/List;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/ay;->d:Ljava/util/List;
    0002: return-object v0

  [Direct Method] newBuilder() -> Lcom/sec/chaton/a/az;
    // registers=1, ins=0, outs=0, insns_size=5
    0000: invoke-static {}, Lcom/sec/chaton/a/az;->k()Lcom/sec/chaton/a/az;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] q() -> Lcom/google/protobuf/ByteString;
    // registers=3, ins=1, outs=1, insns_size=18
    0000: iget v0, v2.Lcom/sec/chaton/a/ay;->c:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 000f
    0006: check-cast v0, Ljava/lang/String;
    0008: invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;
    000b: move-result-object v0
    000c: iput v0, v2.Lcom/sec/chaton/a/ay;->c:Ljava/lang/Object;
    000e: return-object v0
    000f: check-cast v0, Lcom/google/protobuf/ByteString;
    0011: goto 000e

  [Direct Method] r() -> Lcom/google/protobuf/ByteString;
    // registers=3, ins=1, outs=1, insns_size=18
    0000: iget v0, v2.Lcom/sec/chaton/a/ay;->h:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 000f
    0006: check-cast v0, Ljava/lang/String;
    0008: invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;
    000b: move-result-object v0
    000c: iput v0, v2.Lcom/sec/chaton/a/ay;->h:Ljava/lang/Object;
    000e: return-object v0
    000f: check-cast v0, Lcom/google/protobuf/ByteString;
    0011: goto 000e

  [Direct Method] s() -> V
    // registers=3, ins=1, outs=0, insns_size=28
    0000: const-string v0, ''
    0002: iput v0, v2.Lcom/sec/chaton/a/ay;->c:Ljava/lang/Object;
    0004: invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;
    0007: move-result-object v0
    0008: iput v0, v2.Lcom/sec/chaton/a/ay;->d:Ljava/util/List;
    000a: invoke-static {}, Lcom/sec/chaton/a/dd;->a()Lcom/sec/chaton/a/dd;
    000d: move-result-object v0
    000e: iput v0, v2.Lcom/sec/chaton/a/ay;->e:Lcom/sec/chaton/a/dd;
    0010: const/4 v0, 0
    0011: iput v0, v2.Lcom/sec/chaton/a/ay;->f:I
    0013: const-wide/16 v0, 0
    0015: iput v0, v2.Lcom/sec/chaton/a/ay;->g:J
    0017: const-string v0, ''
    0019: iput v0, v2.Lcom/sec/chaton/a/ay;->h:Ljava/lang/Object;
    001b: return-void

  [Virtual Method] a(I) -> Lcom/sec/chaton/a/ba;
    // registers=3, ins=2, outs=2, insns_size=9
    0000: iget v0, v1.Lcom/sec/chaton/a/ay;->d:Ljava/util/List;
    0002: invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Lcom/sec/chaton/a/ba;
    0008: return-object v0

  [Virtual Method] b() -> Lcom/sec/chaton/a/ay;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: sget v0, Lcom/sec/chaton/a/ay;->a:Lcom/sec/chaton/a/ay;
    0002: return-object v0

  [Virtual Method] c() -> Z
    // registers=3, ins=1, outs=0, insns_size=10
    0000: const/4 v0, 1
    0001: iget v1, v2.Lcom/sec/chaton/a/ay;->b:I
    0003: binop/lit8(op=dd) v1, v1, 1 (0x1)
    0005: if-ne v1, v0, 0008
    0007: return v0
    0008: const/4 v0, 0
    0009: goto 0007

  [Virtual Method] d() -> Ljava/lang/String;
    // registers=3, ins=1, outs=1, insns_size=25
    0000: iget v0, v2.Lcom/sec/chaton/a/ay;->c:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 0009
    0006: check-cast v0, Ljava/lang/String;
    0008: return-object v0
    0009: check-cast v0, Lcom/google/protobuf/ByteString;
    000b: invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;
    000e: move-result-object v1
    000f: invoke-static {v0}, Lcom/google/protobuf/Internal;->isValidUtf8(Lcom/google/protobuf/ByteString;)Z
    0012: move-result v0
    0013: if-eqz v0, 0017
    0015: iput v1, v2.Lcom/sec/chaton/a/ay;->c:Ljava/lang/Object;
    0017: move(op=07) v0, v1
    0018: goto 0008

  [Virtual Method] e() -> Ljava/util/List;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/ay;->d:Ljava/util/List;
    0002: return-object v0

  [Virtual Method] f() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/sec/chaton/a/ay;->d:Ljava/util/List;
    0002: invoke-interface {v0}, Ljava/util/List;->size()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] g() -> Z
    // registers=3, ins=1, outs=0, insns_size=11
    0000: iget v0, v2.Lcom/sec/chaton/a/ay;->b:I
    0002: binop/lit8(op=dd) v0, v0, 2 (0x2)
    0004: const/4 v1, 2
    0005: if-ne v0, v1, 0009
    0007: const/4 v0, 1
    0008: return v0
    0009: const/4 v0, 0
    000a: goto 0008

  [Virtual Method] getDefaultInstanceForType() -> Lcom/google/protobuf/MessageLite;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/chaton/a/ay;->b()Lcom/sec/chaton/a/ay;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getSerializedSize() -> I
    // registers=7, ins=1, outs=3, insns_size=117
    0000: const/4 v5, 4
    0001: const/4 v4, 2
    0002: const/4 v3, 1
    0003: const/4 v1, 0
    0004: iget v2, v6.Lcom/sec/chaton/a/ay;->j:I
    0006: const/4 v0, -1
    0007: if-eq v2, v0, 000a
    0009: return v2
    000a: iget v0, v6.Lcom/sec/chaton/a/ay;->b:I
    000c: binop/lit8(op=dd) v0, v0, 1 (0x1)
    000e: if-ne v0, v3, 0073
    0010: invoke-direct {v6}, Lcom/sec/chaton/a/ay;->q()Lcom/google/protobuf/ByteString;
    0013: move-result-object v0
    0014: invoke-static {v3, v0}, Lcom/google/protobuf/CodedOutputStream;->computeBytesSize(ILcom/google/protobuf/ByteString;)I
    0017: move-result v0
    0018: binop/2addr(op=b0) v0, v1
    0019: move(op=01) v2, v0
    001a: iget v0, v6.Lcom/sec/chaton/a/ay;->d:Ljava/util/List;
    001c: invoke-interface {v0}, Ljava/util/List;->size()I
    001f: move-result v0
    0020: if-ge v1, v0, 0033
    0022: iget v0, v6.Lcom/sec/chaton/a/ay;->d:Ljava/util/List;
    0024: invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0027: move-result-object v0
    0028: check-cast v0, Lcom/google/protobuf/MessageLite;
    002a: invoke-static {v4, v0}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I
    002d: move-result v0
    002e: binop/2addr(op=b0) v0, v2
    002f: binop/lit8(op=d8) v1, v1, 1 (0x1)
    0031: move(op=01) v2, v0
    0032: goto 001a
    0033: iget v0, v6.Lcom/sec/chaton/a/ay;->b:I
    0035: binop/lit8(op=dd) v0, v0, 2 (0x2)
    0037: if-ne v0, v4, 0041
    0039: const/4 v0, 3
    003a: iget v1, v6.Lcom/sec/chaton/a/ay;->e:Lcom/sec/chaton/a/dd;
    003c: invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I
    003f: move-result v0
    0040: binop/2addr(op=b0) v2, v0
    0041: iget v0, v6.Lcom/sec/chaton/a/ay;->b:I
    0043: binop/lit8(op=dd) v0, v0, 4 (0x4)
    0045: if-ne v0, v5, 004e
    0047: iget v0, v6.Lcom/sec/chaton/a/ay;->f:I
    0049: invoke-static {v5, v0}, Lcom/google/protobuf/CodedOutputStream;->computeInt32Size(II)I
    004c: move-result v0
    004d: binop/2addr(op=b0) v2, v0
    004e: iget v0, v6.Lcom/sec/chaton/a/ay;->b:I
    0050: binop/lit8(op=dd) v0, v0, 8 (0x8)
    0052: const/16 v1, 8 (0x8)
    0054: if-ne v0, v1, 005e
    0056: const/4 v0, 5
    0057: iget v3, v6.Lcom/sec/chaton/a/ay;->g:J
    0059: invoke-static {v0, v3, v4}, Lcom/google/protobuf/CodedOutputStream;->computeInt64Size(IJ)I
    005c: move-result v0
    005d: binop/2addr(op=b0) v2, v0
    005e: iget v0, v6.Lcom/sec/chaton/a/ay;->b:I
    0060: binop/lit8(op=dd) v0, v0, 16 (0x10)
    0062: const/16 v1, 16 (0x10)
    0064: if-ne v0, v1, 0070
    0066: const/4 v0, 6
    0067: invoke-direct {v6}, Lcom/sec/chaton/a/ay;->r()Lcom/google/protobuf/ByteString;
    006a: move-result-object v1
    006b: invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeBytesSize(ILcom/google/protobuf/ByteString;)I
    006e: move-result v0
    006f: binop/2addr(op=b0) v2, v0
    0070: iput v2, v6.Lcom/sec/chaton/a/ay;->j:I
    0072: goto 0009
    0073: move(op=01) v0, v1
    0074: goto 0019

  [Virtual Method] h() -> Lcom/sec/chaton/a/dd;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/ay;->e:Lcom/sec/chaton/a/dd;
    0002: return-object v0

  [Virtual Method] i() -> Z
    // registers=3, ins=1, outs=0, insns_size=11
    0000: iget v0, v2.Lcom/sec/chaton/a/ay;->b:I
    0002: binop/lit8(op=dd) v0, v0, 4 (0x4)
    0004: const/4 v1, 4
    0005: if-ne v0, v1, 0009
    0007: const/4 v0, 1
    0008: return v0
    0009: const/4 v0, 0
    000a: goto 0008

  [Virtual Method] isInitialized() -> Z
    // registers=4, ins=1, outs=0, insns_size=14
    0000: const/4 v0, 1
    0001: iget v1, v3.Lcom/sec/chaton/a/ay;->i:B
    0003: const/4 v2, -1
    0004: if-eq v1, v2, 000b
    0006: if-ne v1, v0, 0009
    0008: return v0
    0009: const/4 v0, 0
    000a: goto 0008
    000b: iput v0, v3.Lcom/sec/chaton/a/ay;->i:B
    000d: goto 0008

  [Virtual Method] j() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/a/ay;->f:I
    0002: return v0

  [Virtual Method] k() -> Z
    // registers=3, ins=1, outs=0, insns_size=12
    0000: iget v0, v2.Lcom/sec/chaton/a/ay;->b:I
    0002: binop/lit8(op=dd) v0, v0, 8 (0x8)
    0004: const/16 v1, 8 (0x8)
    0006: if-ne v0, v1, 000a
    0008: const/4 v0, 1
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] l() -> J
    // registers=3, ins=1, outs=0, insns_size=3
    0000: iget v0, v2.Lcom/sec/chaton/a/ay;->g:J
    0002: return-wide v0

  [Virtual Method] m() -> Z
    // registers=3, ins=1, outs=0, insns_size=12
    0000: iget v0, v2.Lcom/sec/chaton/a/ay;->b:I
    0002: binop/lit8(op=dd) v0, v0, 16 (0x10)
    0004: const/16 v1, 16 (0x10)
    0006: if-ne v0, v1, 000a
    0008: const/4 v0, 1
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] n() -> Ljava/lang/String;
    // registers=3, ins=1, outs=1, insns_size=25
    0000: iget v0, v2.Lcom/sec/chaton/a/ay;->h:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 0009
    0006: check-cast v0, Ljava/lang/String;
    0008: return-object v0
    0009: check-cast v0, Lcom/google/protobuf/ByteString;
    000b: invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;
    000e: move-result-object v1
    000f: invoke-static {v0}, Lcom/google/protobuf/Internal;->isValidUtf8(Lcom/google/protobuf/ByteString;)Z
    0012: move-result v0
    0013: if-eqz v0, 0017
    0015: iput v1, v2.Lcom/sec/chaton/a/ay;->h:Ljava/lang/Object;
    0017: move(op=07) v0, v1
    0018: goto 0008

  [Virtual Method] newBuilderForType() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/chaton/a/ay;->o()Lcom/sec/chaton/a/az;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] o() -> Lcom/sec/chaton/a/az;
    // registers=2, ins=1, outs=0, insns_size=5
    0000: invoke-static {}, Lcom/sec/chaton/a/ay;->newBuilder()Lcom/sec/chaton/a/az;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] p() -> Lcom/sec/chaton/a/az;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-static {v1}, Lcom/sec/chaton/a/ay;->a(Lcom/sec/chaton/a/ay;)Lcom/sec/chaton/a/az;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] toBuilder() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/chaton/a/ay;->p()Lcom/sec/chaton/a/az;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] writeReplace() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-super {v1}, Lcom/google/protobuf/GeneratedMessageLite;->writeReplace()Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] writeTo(Lcom/google/protobuf/CodedOutputStream;) -> V
    // registers=6, ins=2, outs=4, insns_size=98
    0000: const/4 v3, 4
    0001: const/4 v2, 2
    0002: const/4 v1, 1
    0003: invoke-virtual {v4}, Lcom/sec/chaton/a/ay;->getSerializedSize()I
    0006: iget v0, v4.Lcom/sec/chaton/a/ay;->b:I
    0008: binop/lit8(op=dd) v0, v0, 1 (0x1)
    000a: if-ne v0, v1, 0013
    000c: invoke-direct {v4}, Lcom/sec/chaton/a/ay;->q()Lcom/google/protobuf/ByteString;
    000f: move-result-object v0
    0010: invoke-virtual {v5, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeBytes(ILcom/google/protobuf/ByteString;)V
    0013: const/4 v0, 0
    0014: move(op=01) v1, v0
    0015: iget v0, v4.Lcom/sec/chaton/a/ay;->d:Ljava/util/List;
    0017: invoke-interface {v0}, Ljava/util/List;->size()I
    001a: move-result v0
    001b: if-ge v1, v0, 002c
    001d: iget v0, v4.Lcom/sec/chaton/a/ay;->d:Ljava/util/List;
    001f: invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0022: move-result-object v0
    0023: check-cast v0, Lcom/google/protobuf/MessageLite;
    0025: invoke-virtual {v5, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V
    0028: binop/lit8(op=d8) v0, v1, 1 (0x1)
    002a: move(op=01) v1, v0
    002b: goto 0015
    002c: iget v0, v4.Lcom/sec/chaton/a/ay;->b:I
    002e: binop/lit8(op=dd) v0, v0, 2 (0x2)
    0030: if-ne v0, v2, 0038
    0032: const/4 v0, 3
    0033: iget v1, v4.Lcom/sec/chaton/a/ay;->e:Lcom/sec/chaton/a/dd;
    0035: invoke-virtual {v5, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V
    0038: iget v0, v4.Lcom/sec/chaton/a/ay;->b:I
    003a: binop/lit8(op=dd) v0, v0, 4 (0x4)
    003c: if-ne v0, v3, 0043
    003e: iget v0, v4.Lcom/sec/chaton/a/ay;->f:I
    0040: invoke-virtual {v5, v3, v0}, Lcom/google/protobuf/CodedOutputStream;->writeInt32(II)V
    0043: iget v0, v4.Lcom/sec/chaton/a/ay;->b:I
    0045: binop/lit8(op=dd) v0, v0, 8 (0x8)
    0047: const/16 v1, 8 (0x8)
    0049: if-ne v0, v1, 0051
    004b: const/4 v0, 5
    004c: iget v1, v4.Lcom/sec/chaton/a/ay;->g:J
    004e: invoke-virtual {v5, v0, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeInt64(IJ)V
    0051: iget v0, v4.Lcom/sec/chaton/a/ay;->b:I
    0053: binop/lit8(op=dd) v0, v0, 16 (0x10)
    0055: const/16 v1, 16 (0x10)
    0057: if-ne v0, v1, 0061
    0059: const/4 v0, 6
    005a: invoke-direct {v4}, Lcom/sec/chaton/a/ay;->r()Lcom/google/protobuf/ByteString;
    005d: move-result-object v1
    005e: invoke-virtual {v5, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeBytes(ILcom/google/protobuf/ByteString;)V
    0061: return-void