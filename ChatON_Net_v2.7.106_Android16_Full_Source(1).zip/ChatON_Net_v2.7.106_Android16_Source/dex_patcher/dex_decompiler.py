import struct
import sys

class DexParser:
    def __init__(self, path):
        with open(path, "rb") as f:
            self.data = f.read()
        self._parse_header()
        self._parse_tables()

    def _parse_header(self):
        (self.magic, self.checksum, self.sig, self.file_size, self.header_size,
         self.endian_tag, self.link_size, self.link_off, self.map_off,
         self.string_ids_size, self.string_ids_off,
         self.type_ids_size, self.type_ids_off,
         self.proto_ids_size, self.proto_ids_off,
         self.field_ids_size, self.field_ids_off,
         self.method_ids_size, self.method_ids_off,
         self.class_defs_size, self.class_defs_off,
         self.data_size, self.data_off) = struct.unpack("<8sI20sIIIIIIIIIIIIIIIIIIII", self.data[:112])

    def read_uleb128(self, offset):
        result = 0
        shift = 0
        while True:
            b = self.data[offset]
            offset += 1
            result |= (b & 0x7f) << shift
            if (b & 0x80) == 0:
                break
            shift += 7
        return result, offset

    def read_sleb128(self, offset):
        result = 0
        shift = 0
        while True:
            b = self.data[offset]
            offset += 1
            result |= (b & 0x7f) << shift
            shift += 7
            if (b & 0x80) == 0:
                if shift < 32 and (b & 0x40) != 0:
                    result |= -(1 << shift)
                break
        return result, offset

    def _parse_tables(self):
        self.strings = []
        for i in range(self.string_ids_size):
            off = struct.unpack_from("<I", self.data, self.string_ids_off + i * 4)[0]
            _, pos = self.read_uleb128(off)
            end = self.data.find(b'\x00', pos)
            self.strings.append(self.data[pos:end].decode('utf-8', errors='replace'))

        self.types = [self.strings[struct.unpack_from("<I", self.data, self.type_ids_off + i * 4)[0]]
                      for i in range(self.type_ids_size)]

        self.protos = []
        for i in range(self.proto_ids_size):
            shorty_idx, ret_idx, params_off = struct.unpack_from("<III", self.data, self.proto_ids_off + i * 12)
            params = []
            if params_off != 0:
                psize = struct.unpack_from("<I", self.data, params_off)[0]
                for j in range(psize):
                    t_idx = struct.unpack_from("<H", self.data, params_off + 4 + j * 2)[0]
                    params.append(self.types[t_idx])
            self.protos.append((self.types[ret_idx], params))

        self.fields = []
        for i in range(self.field_ids_size):
            c_idx, t_idx, n_idx = struct.unpack_from("<HHI", self.data, self.field_ids_off + i * 8)
            self.fields.append((self.types[c_idx], self.types[t_idx], self.strings[n_idx]))

        self.methods = []
        for i in range(self.method_ids_size):
            c_idx, p_idx, n_idx = struct.unpack_from("<HHI", self.data, self.method_ids_off + i * 8)
            ret, params = self.protos[p_idx]
            self.methods.append((self.types[c_idx], self.strings[n_idx], ret, params))

        self.classes = {}
        for i in range(self.class_defs_size):
            c_off = self.class_defs_off + i * 32
            (c_idx, access, super_idx, ifaces_off, src_idx,
             annot_off, cdata_off, static_off) = struct.unpack_from("<IIIIIIII", self.data, c_off)
            cname = self.types[c_idx]
            super_name = self.types[super_idx] if super_idx != 0xffffffff else ""
            src_name = self.strings[src_idx] if src_idx != 0xffffffff else ""
            ifaces = []
            if ifaces_off != 0:
                isize = struct.unpack_from("<I", self.data, ifaces_off)[0]
                for j in range(isize):
                    t_idx = struct.unpack_from("<H", self.data, ifaces_off + 4 + j * 2)[0]
                    ifaces.append(self.types[t_idx])
            self.classes[cname] = {
                "name": cname,
                "access": access,
                "super": super_name,
                "interfaces": ifaces,
                "source": src_name,
                "cdata_off": cdata_off,
                "static_off": static_off
            }

    def read_encoded_value(self, offset):
        b = self.data[offset]
        offset += 1
        val_type = b & 0x1f
        val_arg = (b >> 5) & 0x7
        size = val_arg + 1
        if val_type == 0x00: # BYTE
            val = struct.unpack_from("<b", self.data, offset)[0]
            return val, offset + 1
        elif val_type in (0x02, 0x03, 0x04, 0x06): # SHORT, CHAR, INT, LONG
            raw = self.data[offset:offset+size]
            signed = val_type != 0x03
            val = int.from_bytes(raw, byteorder='little', signed=signed)
            return val, offset + size
        elif val_type == 0x10: # FLOAT
            raw = self.data[offset:offset+size] + b'\x00' * (4 - size)
            val = struct.unpack("<f", raw)[0]
            return val, offset + size
        elif val_type == 0x11: # DOUBLE
            raw = self.data[offset:offset+size] + b'\x00' * (8 - size)
            val = struct.unpack("<d", raw)[0]
            return val, offset + size
        elif val_type == 0x17: # STRING
            idx = int.from_bytes(self.data[offset:offset+size], 'little', signed=False)
            return repr(self.strings[idx]), offset + size
        elif val_type == 0x18: # TYPE
            idx = int.from_bytes(self.data[offset:offset+size], 'little', signed=False)
            return self.types[idx], offset + size
        elif val_type == 0x19: # FIELD
            idx = int.from_bytes(self.data[offset:offset+size], 'little', signed=False)
            return f"Field({self.fields[idx]})", offset + size
        elif val_type == 0x1b: # ENUM
            idx = int.from_bytes(self.data[offset:offset+size], 'little', signed=False)
            return f"Enum({self.fields[idx]})", offset + size
        elif val_type == 0x1c: # ARRAY
            arr_size, offset = self.read_uleb128(offset)
            items = []
            for _ in range(arr_size):
                v, offset = self.read_encoded_value(offset)
                items.append(v)
            return items, offset
        elif val_type == 0x1e: # NULL
            return None, offset
        elif val_type == 0x1f: # BOOLEAN
            return bool(val_arg), offset
        else:
            return f"<type {hex(val_type)}>", offset + size

    def disassemble_code(self, code_off):
        registers_size, ins_size, outs_size, tries_size, debug_off, insns_size = struct.unpack_from("<HHHHII", self.data, code_off)
        insns_start = code_off + 16
        pc = 0
        lines = [f"    // registers={registers_size}, ins={ins_size}, outs={outs_size}, insns_size={insns_size}"]
        while pc < insns_size:
            word = struct.unpack_from("<H", self.data, insns_start + pc * 2)[0]
            op = word & 0xff
            hi = (word >> 8) & 0xff
            # Check payload pseudo-instructions
            if word == 0x0100: # packed-switch-payload
                size = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                first_key = struct.unpack_from("<i", self.data, insns_start + (pc + 2) * 2)[0]
                targets = [struct.unpack_from("<i", self.data, insns_start + (pc + 4 + i*2) * 2)[0] for i in range(size)]
                lines.append(f"    {pc:04x}: packed-switch-payload first={first_key} targets={targets}")
                pc += (size * 2) + 4
                continue
            elif word == 0x0200: # sparse-switch-payload
                size = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                keys = [struct.unpack_from("<i", self.data, insns_start + (pc + 2 + i*2) * 2)[0] for i in range(size)]
                targets = [struct.unpack_from("<i", self.data, insns_start + (pc + 2 + size*2 + i*2) * 2)[0] for i in range(size)]
                pairs = dict(zip(keys, targets))
                lines.append(f"    {pc:04x}: sparse-switch-payload {pairs}")
                pc += (size * 4) + 2
                continue
            elif word == 0x0300: # fill-array-data-payload
                elem_width = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                size = struct.unpack_from("<I", self.data, insns_start + (pc + 2) * 2)[0]
                total_bytes = elem_width * size
                raw_bytes = self.data[insns_start + (pc + 4) * 2 : insns_start + (pc + 4) * 2 + total_bytes]
                lines.append(f"    {pc:04x}: fill-array-data-payload width={elem_width} size={size} data={raw_bytes.hex()}")
                pc += ((total_bytes + 1) // 2) + 4
                continue

            # Standard Dalvik opcodes
            if op == 0x00:
                lines.append(f"    {pc:04x}: nop")
                pc += 1
            elif op in (0x01, 0x04, 0x07, 0x21):
                vA = hi & 0xf
                vB = (hi >> 4) & 0xf
                lines.append(f"    {pc:04x}: move(op={op:02x}) v{vA}, v{vB}")
                pc += 1
            elif op in (0x02, 0x05, 0x08):
                vA = hi
                vB = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: move/from16 v{vA}, v{vB}")
                pc += 2
            elif op in (0x03, 0x06, 0x09):
                vA = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                vB = struct.unpack_from("<H", self.data, insns_start + (pc + 2) * 2)[0]
                lines.append(f"    {pc:04x}: move/16 v{vA}, v{vB}")
                pc += 3
            elif op in (0x0a, 0x0b, 0x0c, 0x0d):
                names = {0x0a: "move-result", 0x0b: "move-result-wide", 0x0c: "move-result-object", 0x0d: "move-exception"}
                lines.append(f"    {pc:04x}: {names[op]} v{hi}")
                pc += 1
            elif op == 0x0e:
                lines.append(f"    {pc:04x}: return-void")
                pc += 1
            elif op in (0x0f, 0x10, 0x11):
                names = {0x0f: "return", 0x10: "return-wide", 0x11: "return-object"}
                lines.append(f"    {pc:04x}: {names[op]} v{hi}")
                pc += 1
            elif op == 0x12: # const/4
                vA = hi & 0xf
                lit = (hi >> 4)
                if lit & 0x8:
                    lit -= 16
                lines.append(f"    {pc:04x}: const/4 v{vA}, {lit}")
                pc += 1
            elif op == 0x13: # const/16
                vA = hi
                lit = struct.unpack_from("<h", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: const/16 v{vA}, {lit} ({hex(lit)})")
                pc += 2
            elif op == 0x14: # const
                vA = hi
                lit = struct.unpack_from("<i", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: const v{vA}, {lit} ({hex(lit)})")
                pc += 3
            elif op == 0x15: # const/high16
                vA = hi
                lit = struct.unpack_from("<h", self.data, insns_start + (pc + 1) * 2)[0] << 16
                lines.append(f"    {pc:04x}: const/high16 v{vA}, {lit} ({hex(lit)})")
                pc += 2
            elif op == 0x16: # const-wide/16
                vA = hi
                lit = struct.unpack_from("<h", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: const-wide/16 v{vA}, {lit}")
                pc += 2
            elif op == 0x17: # const-wide/32
                vA = hi
                lit = struct.unpack_from("<i", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: const-wide/32 v{vA}, {lit}")
                pc += 3
            elif op == 0x18: # const-wide
                vA = hi
                lit = struct.unpack_from("<q", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: const-wide v{vA}, {lit} ({hex(lit)})")
                pc += 5
            elif op == 0x19: # const-wide/high16
                vA = hi
                lit = struct.unpack_from("<h", self.data, insns_start + (pc + 1) * 2)[0] << 48
                lines.append(f"    {pc:04x}: const-wide/high16 v{vA}, {lit}")
                pc += 2
            elif op == 0x1a: # const-string
                vA = hi
                idx = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: const-string v{vA}, {repr(self.strings[idx])}")
                pc += 2
            elif op == 0x1b: # const-string/jumbo
                vA = hi
                idx = struct.unpack_from("<I", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: const-string/jumbo v{vA}, {repr(self.strings[idx])}")
                pc += 3
            elif op == 0x1c: # const-class
                vA = hi
                idx = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: const-class v{vA}, {self.types[idx]}")
                pc += 2
            elif op in (0x1d, 0x1e):
                name = "monitor-enter" if op == 0x1d else "monitor-exit"
                lines.append(f"    {pc:04x}: {name} v{hi}")
                pc += 1
            elif op == 0x1f: # check-cast
                vA = hi
                idx = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: check-cast v{vA}, {self.types[idx]}")
                pc += 2
            elif op == 0x20: # instance-of
                vA = hi & 0xf
                vB = (hi >> 4) & 0xf
                idx = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: instance-of v{vA}, v{vB}, {self.types[idx]}")
                pc += 2
            elif op == 0x22: # new-instance
                vA = hi
                idx = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: new-instance v{vA}, {self.types[idx]}")
                pc += 2
            elif op == 0x23: # new-array
                vA = hi & 0xf
                vB = (hi >> 4) & 0xf
                idx = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: new-array v{vA}, v{vB}, {self.types[idx]}")
                pc += 2
            elif op in (0x24, 0x25): # filled-new-array
                idx = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: filled-new-array {self.types[idx]}")
                pc += 3
            elif op == 0x26: # fill-array-data
                vA = hi
                off = struct.unpack_from("<i", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: fill-array-data v{vA}, +{off} (-> {pc+off:04x})")
                pc += 3
            elif op == 0x27: # throw
                lines.append(f"    {pc:04x}: throw v{hi}")
                pc += 1
            elif op == 0x28: # goto
                off = struct.unpack_from("<b", self.data, insns_start + pc * 2 + 1)[0]
                lines.append(f"    {pc:04x}: goto {pc+off:04x}")
                pc += 1
            elif op == 0x29: # goto/16
                off = struct.unpack_from("<h", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: goto/16 {pc+off:04x}")
                pc += 2
            elif op == 0x2a: # goto/32
                off = struct.unpack_from("<i", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: goto/32 {pc+off:04x}")
                pc += 3
            elif op in (0x2b, 0x2c): # switch
                name = "packed-switch" if op == 0x2b else "sparse-switch"
                off = struct.unpack_from("<i", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: {name} v{hi}, +{off} (-> {pc+off:04x})")
                pc += 3
            elif 0x2d <= op <= 0x31: # cmp
                vA = hi
                w2 = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                vB = w2 & 0xff
                vC = (w2 >> 8) & 0xff
                lines.append(f"    {pc:04x}: cmp(op={op:02x}) v{vA}, v{vB}, v{vC}")
                pc += 2
            elif 0x32 <= op <= 0x37: # if-test
                names = {0x32: "if-eq", 0x33: "if-ne", 0x34: "if-lt", 0x35: "if-ge", 0x36: "if-gt", 0x37: "if-le"}
                vA = hi & 0xf
                vB = (hi >> 4) & 0xf
                off = struct.unpack_from("<h", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: {names[op]} v{vA}, v{vB}, {pc+off:04x}")
                pc += 2
            elif 0x38 <= op <= 0x3d: # if-testz
                names = {0x38: "if-eqz", 0x39: "if-nez", 0x3a: "if-ltz", 0x3b: "if-gez", 0x3c: "if-gtz", 0x3d: "if-lez"}
                vA = hi
                off = struct.unpack_from("<h", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: {names[op]} v{vA}, {pc+off:04x}")
                pc += 2
            elif 0x44 <= op <= 0x51: # arrayop
                vA = hi
                w2 = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                vB = w2 & 0xff
                vC = (w2 >> 8) & 0xff
                opname = "aget" if op <= 0x4a else "aput"
                lines.append(f"    {pc:04x}: {opname}(op={op:02x}) v{vA}, v{vB}[v{vC}]")
                pc += 2
            elif 0x52 <= op <= 0x5f: # iinstanceop
                vA = hi & 0xf
                vB = (hi >> 4) & 0xf
                idx = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                fc, ft, fn = self.fields[idx]
                opname = "iget" if op <= 0x58 else "iput"
                lines.append(f"    {pc:04x}: {opname} v{vA}, v{vB}.{fc}->{fn}:{ft}")
                pc += 2
            elif 0x60 <= op <= 0x6d: # sstaticop
                vA = hi
                idx = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                fc, ft, fn = self.fields[idx]
                opname = "sget" if op <= 0x66 else "sput"
                lines.append(f"    {pc:04x}: {opname} v{vA}, {fc}->{fn}:{ft}")
                pc += 2
            elif 0x6e <= op <= 0x72: # invoke-kind
                names = {0x6e: "invoke-virtual", 0x6f: "invoke-super", 0x70: "invoke-direct", 0x71: "invoke-static", 0x72: "invoke-interface"}
                argc = (hi >> 4) & 0xf
                vG = hi & 0xf
                idx = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                w3 = struct.unpack_from("<H", self.data, insns_start + (pc + 2) * 2)[0]
                regs = [w3 & 0xf, (w3 >> 4) & 0xf, (w3 >> 8) & 0xf, (w3 >> 12) & 0xf, vG][:argc]
                reg_str = ", ".join(f"v{r}" for r in regs)
                mc, mn, mret, mparams = self.methods[idx]
                lines.append(f"    {pc:04x}: {names[op]} {{{reg_str}}}, {mc}->{mn}({''.join(mparams)}){mret}")
                pc += 3
            elif 0x74 <= op <= 0x78: # invoke-kind/range
                names = {0x74: "invoke-virtual/range", 0x75: "invoke-super/range", 0x76: "invoke-direct/range", 0x77: "invoke-static/range", 0x78: "invoke-interface/range"}
                argc = hi
                idx = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                vC = struct.unpack_from("<H", self.data, insns_start + (pc + 2) * 2)[0]
                mc, mn, mret, mparams = self.methods[idx]
                lines.append(f"    {pc:04x}: {names[op]} {{v{vC}..v{vC+argc-1}}}, {mc}->{mn}({''.join(mparams)}){mret}")
                pc += 3
            elif 0x7b <= op <= 0x8f: # unop
                vA = hi & 0xf
                vB = (hi >> 4) & 0xf
                lines.append(f"    {pc:04x}: unop(op={op:02x}) v{vA}, v{vB}")
                pc += 1
            elif 0x90 <= op <= 0xaf: # binop
                vA = hi
                w2 = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                vB = w2 & 0xff
                vC = (w2 >> 8) & 0xff
                lines.append(f"    {pc:04x}: binop(op={op:02x}) v{vA}, v{vB}, v{vC}")
                pc += 2
            elif 0xb0 <= op <= 0xcf: # binop/2addr
                vA = hi & 0xf
                vB = (hi >> 4) & 0xf
                lines.append(f"    {pc:04x}: binop/2addr(op={op:02x}) v{vA}, v{vB}")
                pc += 1
            elif 0xd0 <= op <= 0xd7: # binop/lit16
                vA = hi & 0xf
                vB = (hi >> 4) & 0xf
                lit = struct.unpack_from("<h", self.data, insns_start + (pc + 1) * 2)[0]
                lines.append(f"    {pc:04x}: binop/lit16(op={op:02x}) v{vA}, v{vB}, {lit} ({hex(lit)})")
                pc += 2
            elif 0xd8 <= op <= 0xe2: # binop/lit8
                vA = hi
                w2 = struct.unpack_from("<H", self.data, insns_start + (pc + 1) * 2)[0]
                vB = w2 & 0xff
                lit = struct.unpack_from("<b", self.data, insns_start + (pc + 1) * 2 + 1)[0]
                lines.append(f"    {pc:04x}: binop/lit8(op={op:02x}) v{vA}, v{vB}, {lit} ({hex(lit)})")
                pc += 2
            else:
                lines.append(f"    {pc:04x}: unknown(op={op:02x})")
                pc += 1
        return "\n".join(lines)

    def dump_class(self, cname, include_code=True):
        if cname not in self.classes:
            return f"Class {cname} not found"
        c = self.classes[cname]
        out = [f"=== CLASS {c['name']} (Source: {c['source']}) ==="]
        out.append(f"  Super: {c['super']}")
        if c['interfaces']:
            out.append(f"  Interfaces: {', '.join(c['interfaces'])}")

        static_vals = []
        if c['static_off'] != 0:
            pos = c['static_off']
            ssize, pos = self.read_uleb128(pos)
            for _ in range(ssize):
                v, pos = self.read_encoded_value(pos)
                static_vals.append(v)

        if c['cdata_off'] == 0:
            return "\n".join(out)

        pos = c['cdata_off']
        sf_size, pos = self.read_uleb128(pos)
        if_size, pos = self.read_uleb128(pos)
        dm_size, pos = self.read_uleb128(pos)
        vm_size, pos = self.read_uleb128(pos)

        f_idx = 0
        for i in range(sf_size):
            diff, pos = self.read_uleb128(pos)
            acc, pos = self.read_uleb128(pos)
            f_idx += diff
            _, ft, fn = self.fields[f_idx]
            sval = f" = {static_vals[i]}" if i < len(static_vals) else ""
            out.append(f"  [Static Field] {fn}: {ft}{sval}")

        f_idx = 0
        for i in range(if_size):
            diff, pos = self.read_uleb128(pos)
            acc, pos = self.read_uleb128(pos)
            f_idx += diff
            _, ft, fn = self.fields[f_idx]
            out.append(f"  [Instance Field] {fn}: {ft}")

        m_idx = 0
        for i in range(dm_size):
            diff, pos = self.read_uleb128(pos)
            acc, pos = self.read_uleb128(pos)
            code_off, pos = self.read_uleb128(pos)
            m_idx += diff
            _, mn, mret, mparams = self.methods[m_idx]
            out.append(f"\n  [Direct Method] {mn}({', '.join(mparams)}) -> {mret}")
            if include_code and code_off != 0:
                out.append(self.disassemble_code(code_off))

        m_idx = 0
        for i in range(vm_size):
            diff, pos = self.read_uleb128(pos)
            acc, pos = self.read_uleb128(pos)
            code_off, pos = self.read_uleb128(pos)
            m_idx += diff
            _, mn, mret, mparams = self.methods[m_idx]
            out.append(f"\n  [Virtual Method] {mn}({', '.join(mparams)}) -> {mret}")
            if include_code and code_off != 0:
                out.append(self.disassemble_code(code_off))

        return "\n".join(out)

if __name__ == "__main__":
    dex = DexParser("/tmp/chaton_extracted/classes.dex")
    for cname in sys.argv[1:]:
        print(dex.dump_class(cname))
