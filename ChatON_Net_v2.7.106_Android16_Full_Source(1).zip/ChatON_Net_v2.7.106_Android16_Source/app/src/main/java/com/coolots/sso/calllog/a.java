=== CLASS Lcom/coolots/sso/calllog/a; (Source: ) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/Parcelable$Creator;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] a(Landroid/os/Parcel;) -> Lcom/coolots/sso/calllog/ChatONCallLogData;
    // registers=3, ins=2, outs=2, insns_size=6
    0000: new-instance v0, Lcom/coolots/sso/calllog/ChatONCallLogData;
    0002: invoke-direct {v0, v2}, Lcom/coolots/sso/calllog/ChatONCallLogData;-><init>(Landroid/os/Parcel;)V
    0005: return-object v0

  [Virtual Method] createFromParcel(Landroid/os/Parcel;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Lcom/coolots/sso/calllog/a;->a(Landroid/os/Parcel;)Lcom/coolots/sso/calllog/ChatONCallLogData;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] newArray(I) -> [Ljava/lang/Object;
    // registers=3, ins=2, outs=0, insns_size=3
    0000: new-array v0, v2, [Lcom/coolots/sso/calllog/ChatONCallLogData;
    0002: return-object v0