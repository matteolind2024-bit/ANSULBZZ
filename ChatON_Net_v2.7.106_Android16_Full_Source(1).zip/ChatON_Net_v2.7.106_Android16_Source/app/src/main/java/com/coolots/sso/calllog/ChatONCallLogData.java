=== CLASS Lcom/coolots/sso/calllog/ChatONCallLogData; (Source: ) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/Parcelable;
  [Static Field] CREATOR: Landroid/os/Parcelable$Creator;
  [Instance Field] a: Ljava/lang/String;
  [Instance Field] b: I
  [Instance Field] c: I
  [Instance Field] d: I
  [Instance Field] e: Ljava/lang/String;
  [Instance Field] f: Ljava/lang/String;
  [Instance Field] g: I
  [Instance Field] h: Ljava/lang/String;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=8
    0000: new-instance v0, Lcom/coolots/sso/calllog/a;
    0002: invoke-direct {v0}, Lcom/coolots/sso/calllog/a;-><init>()V
    0005: sput v0, Lcom/coolots/sso/calllog/ChatONCallLogData;->CREATOR:Landroid/os/Parcelable$Creator;
    0007: return-void

  [Direct Method] <init>() -> V
    // registers=3, ins=1, outs=1, insns_size=30
    0000: const/4 v1, -1
    0001: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0004: const-string v0, ''
    0006: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->a:Ljava/lang/String;
    0008: const/4 v0, 0
    0009: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->b:I
    000b: iput v1, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->c:I
    000d: iput v1, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->d:I
    000f: const-string v0, ''
    0011: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->e:Ljava/lang/String;
    0013: const-string v0, ''
    0015: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->f:Ljava/lang/String;
    0017: iput v1, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->g:I
    0019: const-string v0, ''
    001b: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->h:Ljava/lang/String;
    001d: return-void

  [Direct Method] <init>(Landroid/os/Parcel;) -> V
    // registers=4, ins=2, outs=2, insns_size=33
    0000: const/4 v1, -1
    0001: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0004: const-string v0, ''
    0006: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->a:Ljava/lang/String;
    0008: const/4 v0, 0
    0009: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->b:I
    000b: iput v1, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->c:I
    000d: iput v1, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->d:I
    000f: const-string v0, ''
    0011: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->e:Ljava/lang/String;
    0013: const-string v0, ''
    0015: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->f:Ljava/lang/String;
    0017: iput v1, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->g:I
    0019: const-string v0, ''
    001b: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->h:Ljava/lang/String;
    001d: invoke-direct {v2, v3}, Lcom/coolots/sso/calllog/ChatONCallLogData;->a(Landroid/os/Parcel;)V
    0020: return-void

  [Direct Method] a(Landroid/os/Parcel;) -> V
    // registers=4, ins=2, outs=1, insns_size=86
    0000: const/4 v1, 0
    0001: invoke-virtual {v3}, Landroid/os/Parcel;->readInt()I
    0004: move-result v0
    0005: if-nez v0, 003a
    0007: iput v1, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->a:Ljava/lang/String;
    0009: invoke-virtual {v3}, Landroid/os/Parcel;->readInt()I
    000c: move-result v0
    000d: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->b:I
    000f: invoke-virtual {v3}, Landroid/os/Parcel;->readInt()I
    0012: move-result v0
    0013: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->c:I
    0015: invoke-virtual {v3}, Landroid/os/Parcel;->readInt()I
    0018: move-result v0
    0019: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->d:I
    001b: invoke-virtual {v3}, Landroid/os/Parcel;->readInt()I
    001e: move-result v0
    001f: if-nez v0, 0041
    0021: iput v1, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->e:Ljava/lang/String;
    0023: invoke-virtual {v3}, Landroid/os/Parcel;->readInt()I
    0026: move-result v0
    0027: if-nez v0, 0048
    0029: iput v1, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->f:Ljava/lang/String;
    002b: invoke-virtual {v3}, Landroid/os/Parcel;->readInt()I
    002e: move-result v0
    002f: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->g:I
    0031: invoke-virtual {v3}, Landroid/os/Parcel;->readInt()I
    0034: move-result v0
    0035: if-nez v0, 004f
    0037: iput v1, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->h:Ljava/lang/String;
    0039: return-void
    003a: invoke-virtual {v3}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    003d: move-result-object v0
    003e: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->a:Ljava/lang/String;
    0040: goto 0009
    0041: invoke-virtual {v3}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0044: move-result-object v0
    0045: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->e:Ljava/lang/String;
    0047: goto 0023
    0048: invoke-virtual {v3}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    004b: move-result-object v0
    004c: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->f:Ljava/lang/String;
    004e: goto 002b
    004f: invoke-virtual {v3}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0052: move-result-object v0
    0053: iput v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->h:Ljava/lang/String;
    0055: goto 0039

  [Virtual Method] a() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/calllog/ChatONCallLogData;->a:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] a(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/coolots/sso/calllog/ChatONCallLogData;->g:I
    0002: return-void

  [Virtual Method] b() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/calllog/ChatONCallLogData;->b:I
    0002: return v0

  [Virtual Method] c() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/calllog/ChatONCallLogData;->c:I
    0002: return v0

  [Virtual Method] d() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/calllog/ChatONCallLogData;->d:I
    0002: return v0

  [Virtual Method] describeContents() -> I
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] e() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/calllog/ChatONCallLogData;->e:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] f() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/calllog/ChatONCallLogData;->f:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] g() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/calllog/ChatONCallLogData;->g:I
    0002: return v0

  [Virtual Method] h() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/calllog/ChatONCallLogData;->h:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] writeToParcel(Landroid/os/Parcel;, I) -> V
    // registers=5, ins=3, outs=2, insns_size=142
    0000: const/4 v1, 0
    0001: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->a:Ljava/lang/String;
    0003: if-eqz v0, 000d
    0005: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->a:Ljava/lang/String;
    0007: invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    000a: move-result v0
    000b: if-eqz v0, 0052
    000d: invoke-virtual {v3, v1}, Landroid/os/Parcel;->writeInt(I)V
    0010: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->b:I
    0012: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    0015: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->c:I
    0017: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    001a: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->d:I
    001c: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    001f: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->e:Ljava/lang/String;
    0021: if-eqz v0, 002b
    0023: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->e:Ljava/lang/String;
    0025: invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    0028: move-result v0
    0029: if-eqz v0, 0061
    002b: invoke-virtual {v3, v1}, Landroid/os/Parcel;->writeInt(I)V
    002e: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->f:Ljava/lang/String;
    0030: if-eqz v0, 003a
    0032: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->f:Ljava/lang/String;
    0034: invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    0037: move-result v0
    0038: if-eqz v0, 0070
    003a: invoke-virtual {v3, v1}, Landroid/os/Parcel;->writeInt(I)V
    003d: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->g:I
    003f: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    0042: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->h:Ljava/lang/String;
    0044: if-eqz v0, 004e
    0046: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->h:Ljava/lang/String;
    0048: invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    004b: move-result v0
    004c: if-eqz v0, 007f
    004e: invoke-virtual {v3, v1}, Landroid/os/Parcel;->writeInt(I)V
    0051: return-void
    0052: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->a:Ljava/lang/String;
    0054: invoke-virtual {v0}, Ljava/lang/String;->length()I
    0057: move-result v0
    0058: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    005b: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->a:Ljava/lang/String;
    005d: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0060: goto 0010
    0061: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->e:Ljava/lang/String;
    0063: invoke-virtual {v0}, Ljava/lang/String;->length()I
    0066: move-result v0
    0067: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    006a: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->e:Ljava/lang/String;
    006c: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    006f: goto 002e
    0070: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->f:Ljava/lang/String;
    0072: invoke-virtual {v0}, Ljava/lang/String;->length()I
    0075: move-result v0
    0076: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    0079: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->f:Ljava/lang/String;
    007b: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    007e: goto 003d
    007f: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->h:Ljava/lang/String;
    0081: invoke-virtual {v0}, Ljava/lang/String;->length()I
    0084: move-result v0
    0085: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    0088: iget v0, v2.Lcom/coolots/sso/calllog/ChatONCallLogData;->h:Ljava/lang/String;
    008a: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    008d: goto 0051