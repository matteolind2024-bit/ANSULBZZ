=== CLASS Lcom/coolots/sso/a/e; (Source: ) ===
  Super: Landroid/content/BroadcastReceiver;
  [Instance Field] a: Lcom/coolots/sso/a/a;

  [Direct Method] <init>(Lcom/coolots/sso/a/a;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/coolots/sso/a/e;->a:Lcom/coolots/sso/a/a;
    0002: invoke-direct {v0}, Landroid/content/BroadcastReceiver;-><init>()V
    0005: return-void

  [Direct Method] <init>(Lcom/coolots/sso/a/a;, Lcom/coolots/sso/a/e;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/coolots/sso/a/e;-><init>(Lcom/coolots/sso/a/a;)V
    0003: return-void

  [Virtual Method] onReceive(Landroid/content/Context;, Landroid/content/Intent;) -> V
    // registers=6, ins=3, outs=3, insns_size=205
    0000: invoke-virtual {v5}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0003: move-result-object v0
    0004: if-nez v0, 0007
    0006: return-void
    0007: new-instance v1, Ljava/lang/StringBuilder;
    0009: const-string v2, 'ChatONVAPIICallReceiver() action: '
    000b: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0011: move-result-object v1
    0012: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0015: move-result-object v1
    0016: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    0019: new-instance v1, Ljava/lang/StringBuilder;
    001b: const-string v2, 'ChatONVAPIICallReceiver() this: '
    001d: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0020: invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0023: move-result-object v2
    0024: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0027: move-result-object v1
    0028: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002b: move-result-object v1
    002c: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    002f: new-instance v1, Ljava/lang/StringBuilder;
    0031: const-string v2, 'ChatONVAPIICallReceiver() mCallListener: '
    0033: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0036: iget v2, v3.Lcom/coolots/sso/a/e;->a:Lcom/coolots/sso/a/a;
    0038: invoke-static {v2}, Lcom/coolots/sso/a/a;->c(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/b;
    003b: move-result-object v2
    003c: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    003f: move-result-object v2
    0040: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0043: move-result-object v1
    0044: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0047: move-result-object v1
    0048: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    004b: new-instance v1, Ljava/lang/StringBuilder;
    004d: const-string v2, 'ChatONVAPIICallReceiver() mCallReceiver: '
    004f: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0052: iget v2, v3.Lcom/coolots/sso/a/e;->a:Lcom/coolots/sso/a/a;
    0054: invoke-static {v2}, Lcom/coolots/sso/a/a;->d(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/e;
    0057: move-result-object v2
    0058: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    005b: move-result-object v2
    005c: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    005f: move-result-object v1
    0060: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0063: move-result-object v1
    0064: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    0067: const-string v1, 'com.coolots.chaton.account.CALL_STATE_CHANGE_INFO'
    0069: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    006c: move-result v1
    006d: if-eqz v1, 00ad
    006f: const-string v0, 'result'
    0071: invoke-virtual {v5, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z
    0074: move-result v0
    0075: if-eqz v0, 0006
    0077: const-string v0, 'result'
    0079: const/4 v1, 3
    007a: invoke-virtual {v5, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    007d: move-result v0
    007e: new-instance v1, Ljava/lang/StringBuilder;
    0080: const-string v2, 'BR_CALL_STATE_CHANGE_INFO state('
    0082: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0085: invoke-static {v0}, Lcom/coolots/sso/a/a;->a(I)Ljava/lang/String;
    0088: move-result-object v2
    0089: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    008c: move-result-object v1
    008d: const-string v2, ')'
    008f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0092: move-result-object v1
    0093: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0096: move-result-object v1
    0097: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    009a: iget v1, v3.Lcom/coolots/sso/a/e;->a:Lcom/coolots/sso/a/a;
    009c: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/b;
    009f: move-result-object v1
    00a0: if-eqz v1, 0006
    00a2: iget v1, v3.Lcom/coolots/sso/a/e;->a:Lcom/coolots/sso/a/a;
    00a4: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/b;
    00a7: move-result-object v1
    00a8: invoke-interface {v1, v0}, Lcom/coolots/sso/a/b;->a(I)V
    00ab: goto/16 0006
    00ad: const-string v1, 'com.coolots.chaton.version.CONFERENCE_MEMBER_CHANGED'
    00af: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    00b2: move-result v0
    00b3: if-eqz v0, 0006
    00b5: const-string v0, 'BR_CONFERENCE_MEMBER_CHANGED'
    00b7: invoke-static {v0}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    00ba: iget v0, v3.Lcom/coolots/sso/a/e;->a:Lcom/coolots/sso/a/a;
    00bc: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/b;
    00bf: move-result-object v0
    00c0: if-eqz v0, 0006
    00c2: iget v0, v3.Lcom/coolots/sso/a/e;->a:Lcom/coolots/sso/a/a;
    00c4: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/b;
    00c7: move-result-object v0
    00c8: invoke-interface {v0}, Lcom/coolots/sso/a/b;->a()V
    00cb: goto/16 0006