=== CLASS Lcom/coolots/sso/a/a; (Source: ) ===
  Super: Ljava/lang/Object;
  [Static Field] a: Z
  [Instance Field] b: Lcom/coolots/sso/a/f;
  [Instance Field] c: Lcom/coolots/sso/a/c;
  [Instance Field] d: Lcom/coolots/sso/a/e;
  [Instance Field] e: Lcom/coolots/sso/a/b;
  [Instance Field] f: Lcom/coolots/sso/a/g;
  [Instance Field] g: Lcom/coolots/sso/a/d;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=0, insns_size=4
    0000: const/4 v0, 0
    0001: sput v0, Lcom/coolots/sso/a/a;->a:Z
    0003: return-void

  [Direct Method] <init>() -> V
    // registers=3, ins=1, outs=2, insns_size=39
    0000: const/4 v0, 0
    0001: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0004: iput v0, v2.Lcom/coolots/sso/a/a;->b:Lcom/coolots/sso/a/f;
    0006: iput v0, v2.Lcom/coolots/sso/a/a;->c:Lcom/coolots/sso/a/c;
    0008: iput v0, v2.Lcom/coolots/sso/a/a;->d:Lcom/coolots/sso/a/e;
    000a: iput v0, v2.Lcom/coolots/sso/a/a;->e:Lcom/coolots/sso/a/b;
    000c: iput v0, v2.Lcom/coolots/sso/a/a;->f:Lcom/coolots/sso/a/g;
    000e: iput v0, v2.Lcom/coolots/sso/a/a;->g:Lcom/coolots/sso/a/d;
    0010: new-instance v0, Ljava/lang/StringBuilder;
    0012: const-string v1, 'ChatONVAPII create() '
    0014: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0017: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    001a: move-result-object v1
    001b: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001e: move-result-object v0
    001f: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0022: move-result-object v0
    0023: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0026: return-void

  [Direct Method] a(Lcom/coolots/sso/a/a;) -> Lcom/coolots/sso/a/c;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/a/a;->c:Lcom/coolots/sso/a/c;
    0002: return-object v0

  [Direct Method] a(I) -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=64
    0000: sparse-switch v1, +30 (-> 001e)
    0003: const/4 v0, 0
    0004: return-object v0
    0005: const-string v0, 'STATE_INIT'
    0007: goto 0004
    0008: const-string v0, 'STATE_CALLING'
    000a: goto 0004
    000b: const-string v0, 'STATE_CONNECTED'
    000d: goto 0004
    000e: const-string v0, 'STATE_DISCONNECTED'
    0010: goto 0004
    0011: const-string v0, 'STATE_CHANGE_TO_CONFERENCE_CONNECTED'
    0013: goto 0004
    0014: const-string v0, 'STATE_CHANGE_TO_P2P_CONNECTED'
    0016: goto 0004
    0017: const-string v0, 'STATE_CHANGE_TO_CONFERENCE_DISCONNECTED'
    0019: goto 0004
    001a: const-string v0, 'STATE_CHANGE_TO_P2P_DISCONNECTED'
    001c: goto 0004
    001d: nop
    001e: sparse-switch-payload {0: 5, 1: 8, 2: 11, 3: 14, 100: 17, 101: 20, 102: 23, 103: 26}

  [Direct Method] a(Landroid/content/Context;, Z) -> V
    // registers=7, ins=2, outs=5, insns_size=83
    0000: sput v6, Lcom/coolots/sso/a/a;->a:Z
    0002: new-instance v0, Ljava/lang/StringBuilder;
    0004: const-string v1, 'setDisplayLog: '
    0006: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0009: invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    000c: move-result-object v0
    000d: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0010: move-result-object v0
    0011: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0014: invoke-static {v5}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    0017: move-result v0
    0018: if-nez v0, 0020
    001a: const-string v0, 'ChatON V is not installed'
    001c: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    001f: return-void
    0020: const-string v0, 'content://com.coolots.chaton/set_log_display'
    0022: invoke-static {v5, v0}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0025: move-result v0
    0026: const/4 v1, 1
    0027: if-ne v0, v1, 002f
    0029: const-string v0, 'not allowed access'
    002b: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    002e: goto 001f
    002f: const/4 v1, 2
    0030: if-ne v0, v1, 0038
    0032: const-string v0, 'not supported function'
    0034: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0037: goto 001f
    0038: const-string v0, 'content://com.coolots.chaton/set_log_display'
    003a: new-instance v1, Landroid/content/ContentValues;
    003c: invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V
    003f: invoke-virtual {v5}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    0042: move-result-object v2
    0043: invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    0046: move-result-object v3
    0047: if-eqz v6, 0050
    0049: const-string v0, '1'
    004b: const/4 v4, 0
    004c: invoke-virtual {v2, v3, v1, v0, v4}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    004f: goto 001f
    0050: const-string v0, '0'
    0052: goto 004b

  [Direct Method] a(Ljava/lang/String;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0003: return-void

  [Direct Method] a() -> Z
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/coolots/sso/a/a;->a:Z
    0002: return v0

  [Direct Method] a(Landroid/content/Context;, Ljava/lang/String;) -> Z
    // registers=4, ins=2, outs=3, insns_size=58
    0000: invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    0003: move-result-object v0
    0004: const/16 v1, 128 (0x80)
    0006: invoke-virtual {v0, v3, v1}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    0009: new-instance v0, Ljava/lang/StringBuilder;
    000b: invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    000e: move-result-object v1
    000f: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0012: const-string v1, 'isInstalled() true'
    0014: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0017: move-result-object v0
    0018: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001b: move-result-object v0
    001c: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    001f: const/4 v0, 1
    0020: return v0
    0021: move-exception v0
    0022: new-instance v0, Ljava/lang/StringBuilder;
    0024: invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    0027: move-result-object v1
    0028: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    002b: const-string v1, 'isInstalled() false'
    002d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0030: move-result-object v0
    0031: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0034: move-result-object v0
    0035: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0038: const/4 v0, 0
    0039: goto 0020

  [Direct Method] b(Landroid/content/Context;, Ljava/lang/String;) -> I
    // registers=6, ins=2, outs=3, insns_size=72
    0000: const-string v0, 'checkKey()'
    0002: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0005: const-string v0, 'content://com.coolots.chaton/key'
    0007: new-instance v1, Landroid/content/ContentValues;
    0009: invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V
    000c: const-string v2, 'key'
    000e: invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    0011: move-result-object v3
    0012: invoke-virtual {v1, v2, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V
    0015: const-string v2, 'function'
    0017: invoke-virtual {v1, v2, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V
    001a: invoke-virtual {v4}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    001d: move-result-object v2
    001e: invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    0021: move-result-object v0
    0022: invoke-virtual {v2, v0, v1}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    0025: move-result-object v0
    0026: if-nez v0, 002a
    0028: const/4 v0, 1
    0029: return v0
    002a: invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;
    002d: move-result-object v1
    002e: const-string v2, 'content://com.coolots.chaton/not_supported_function'
    0030: invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0033: move-result v1
    0034: if-eqz v1, 0038
    0036: const/4 v0, 2
    0037: goto 0029
    0038: invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;
    003b: move-result-object v0
    003c: const-string v1, 'content://com.coolots.chaton/no_account'
    003e: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0041: move-result v0
    0042: if-eqz v0, 0046
    0044: const/4 v0, 3
    0045: goto 0029
    0046: const/4 v0, 0
    0047: goto 0029

  [Direct Method] b(Lcom/coolots/sso/a/a;) -> Lcom/coolots/sso/a/f;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/a/a;->b:Lcom/coolots/sso/a/f;
    0002: return-object v0

  [Direct Method] b(I) -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=86
    0000: const-string v0, ''
    0002: packed-switch v1, +50 (-> 0034)
    0005: return-object v0
    0006: const-string v0, 'RET_CHATONV_SUCCESS'
    0008: goto 0005
    0009: const-string v0, 'RET_CHATONV_FAIL'
    000b: goto 0005
    000c: const-string v0, 'RET_CHATONV_NOT_INSTALLED'
    000e: goto 0005
    000f: const-string v0, 'RET_CHATONV_ID_EMPTY'
    0011: goto 0005
    0012: const-string v0, 'RET_CHATONV_UNEXPECTED_ERROR'
    0014: goto 0005
    0015: const-string v0, 'RET_CHATONV_NOT_ALLOWED_ACCESS'
    0017: goto 0005
    0018: const-string v0, 'RET_CHATONV_NATIONAL_CODE_EMPTY'
    001a: goto 0005
    001b: const-string v0, 'RET_CHATONV_GUID_EMPTY'
    001d: goto 0005
    001e: const-string v0, 'RET_CHATONV_CALLER_NAME_EMPTY'
    0020: goto 0005
    0021: const-string v0, 'RET_CHATONV_CHATON_NUMBER_EMPTY'
    0023: goto 0005
    0024: const-string v0, 'RET_CHATONV_CHATON_UID_EMPTY'
    0026: goto 0005
    0027: const-string v0, 'RET_CHATONV_IMEI_EMPTY'
    0029: goto 0005
    002a: const-string v0, 'RET_CHATONV_BIRTHDAY_EMPTY'
    002c: goto 0005
    002d: const-string v0, 'RET_CHATONV_NOT_SUPPORTED_FUNCTION'
    002f: goto 0005
    0030: const-string v0, 'RET_CHATONV_NO_ACCOUNT'
    0032: goto 0005
    0033: nop
    0034: packed-switch-payload first=0 targets=[4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46]

  [Direct Method] b(Ljava/lang/String;) -> V
    // registers=2, ins=1, outs=2, insns_size=10
    0000: sget v0, Lcom/coolots/sso/a/a;->a:Z
    0002: if-eqz v0, 0009
    0004: const-string v0, 'ChatONVAPII(1.0.0.1)'
    0006: invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    0009: return-void

  [Direct Method] b(Landroid/content/Context;) -> Z
    // registers=3, ins=1, outs=2, insns_size=20
    0000: const/4 v0, 0
    0001: return v0
    0002: nop
    0003: invoke-static {v2, v1}, Lcom/coolots/sso/a/a;->a(Landroid/content/Context;Ljava/lang/String;)Z
    0006: move-result v1
    0007: if-eqz v1, 000a
    0009: return v0
    000a: const-string v1, 'com.coolots.chatonforcanada'
    000c: invoke-static {v2, v1}, Lcom/coolots/sso/a/a;->a(Landroid/content/Context;Ljava/lang/String;)Z
    000f: move-result v1
    0010: if-nez v1, 0009
    0012: const/4 v0, 0
    0013: goto 0009

  [Direct Method] c(Lcom/coolots/sso/a/a;) -> Lcom/coolots/sso/a/b;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/a/a;->e:Lcom/coolots/sso/a/b;
    0002: return-object v0

  [Direct Method] c(Ljava/lang/String;) -> V
    // registers=2, ins=1, outs=2, insns_size=10
    0000: sget v0, Lcom/coolots/sso/a/a;->a:Z
    0002: if-eqz v0, 0009
    0004: const-string v0, 'ChatONVAPII(1.0.0.1)'
    0006: invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    0009: return-void

  [Direct Method] d(Lcom/coolots/sso/a/a;) -> Lcom/coolots/sso/a/e;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/a/a;->d:Lcom/coolots/sso/a/e;
    0002: return-object v0

  [Direct Method] e(Lcom/coolots/sso/a/a;) -> Lcom/coolots/sso/a/d;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/a/a;->g:Lcom/coolots/sso/a/d;
    0002: return-object v0

  [Direct Method] f(Lcom/coolots/sso/a/a;) -> Lcom/coolots/sso/a/g;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/coolots/sso/a/a;->f:Lcom/coolots/sso/a/g;
    0002: return-object v0

  [Direct Method] p(Landroid/content/Context;) -> V
    // registers=5, ins=2, outs=2, insns_size=79
    0000: const/4 v2, 0
    0001: iget v0, v3.Lcom/coolots/sso/a/a;->c:Lcom/coolots/sso/a/c;
    0003: if-eqz v0, 0025
    0005: new-instance v0, Ljava/lang/StringBuilder;
    0007: const-string v1, 'clearAccountListener: mListener :'
    0009: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    000c: iget v1, v3.Lcom/coolots/sso/a/a;->c:Lcom/coolots/sso/a/c;
    000e: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0011: move-result-object v1
    0012: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0015: move-result-object v0
    0016: const-string v1, ' => removed'
    0018: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001b: move-result-object v0
    001c: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001f: move-result-object v0
    0020: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0023: iput v2, v3.Lcom/coolots/sso/a/a;->c:Lcom/coolots/sso/a/c;
    0025: iget v0, v3.Lcom/coolots/sso/a/a;->b:Lcom/coolots/sso/a/f;
    0027: if-eqz v0, 004e
    0029: new-instance v0, Ljava/lang/StringBuilder;
    002b: const-string v1, 'clearAccountListener: mReceiver :'
    002d: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0030: iget v1, v3.Lcom/coolots/sso/a/a;->b:Lcom/coolots/sso/a/f;
    0032: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0035: move-result-object v1
    0036: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0039: move-result-object v0
    003a: const-string v1, ' => removed'
    003c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003f: move-result-object v0
    0040: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0043: move-result-object v0
    0044: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0047: iget v0, v3.Lcom/coolots/sso/a/a;->b:Lcom/coolots/sso/a/f;
    0049: invoke-virtual {v4, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    004c: iput v2, v3.Lcom/coolots/sso/a/a;->b:Lcom/coolots/sso/a/f;
    004e: return-void

  [Direct Method] q(Landroid/content/Context;) -> V
    // registers=5, ins=2, outs=2, insns_size=79
    0000: const/4 v2, 0
    0001: iget v0, v3.Lcom/coolots/sso/a/a;->e:Lcom/coolots/sso/a/b;
    0003: if-eqz v0, 0025
    0005: new-instance v0, Ljava/lang/StringBuilder;
    0007: const-string v1, 'clearCallListener: mCallListener :'
    0009: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    000c: iget v1, v3.Lcom/coolots/sso/a/a;->e:Lcom/coolots/sso/a/b;
    000e: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0011: move-result-object v1
    0012: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0015: move-result-object v0
    0016: const-string v1, ' => removed'
    0018: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001b: move-result-object v0
    001c: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001f: move-result-object v0
    0020: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0023: iput v2, v3.Lcom/coolots/sso/a/a;->e:Lcom/coolots/sso/a/b;
    0025: iget v0, v3.Lcom/coolots/sso/a/a;->d:Lcom/coolots/sso/a/e;
    0027: if-eqz v0, 004e
    0029: new-instance v0, Ljava/lang/StringBuilder;
    002b: const-string v1, 'clearCallListener: mCallReceiver :'
    002d: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0030: iget v1, v3.Lcom/coolots/sso/a/a;->d:Lcom/coolots/sso/a/e;
    0032: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0035: move-result-object v1
    0036: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0039: move-result-object v0
    003a: const-string v1, ' => removed'
    003c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003f: move-result-object v0
    0040: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0043: move-result-object v0
    0044: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0047: iget v0, v3.Lcom/coolots/sso/a/a;->d:Lcom/coolots/sso/a/e;
    0049: invoke-virtual {v4, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    004c: iput v2, v3.Lcom/coolots/sso/a/a;->d:Lcom/coolots/sso/a/e;
    004e: return-void

  [Direct Method] r(Landroid/content/Context;) -> V
    // registers=5, ins=2, outs=2, insns_size=79
    0000: const/4 v2, 0
    0001: iget v0, v3.Lcom/coolots/sso/a/a;->g:Lcom/coolots/sso/a/d;
    0003: if-eqz v0, 0025
    0005: new-instance v0, Ljava/lang/StringBuilder;
    0007: const-string v1, 'clearUpdateListener: mUpdateListener :'
    0009: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    000c: iget v1, v3.Lcom/coolots/sso/a/a;->g:Lcom/coolots/sso/a/d;
    000e: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0011: move-result-object v1
    0012: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0015: move-result-object v0
    0016: const-string v1, ' => removed'
    0018: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001b: move-result-object v0
    001c: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001f: move-result-object v0
    0020: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0023: iput v2, v3.Lcom/coolots/sso/a/a;->g:Lcom/coolots/sso/a/d;
    0025: iget v0, v3.Lcom/coolots/sso/a/a;->f:Lcom/coolots/sso/a/g;
    0027: if-eqz v0, 004e
    0029: new-instance v0, Ljava/lang/StringBuilder;
    002b: const-string v1, 'clearUpdateListener: mUpdateReceiver :'
    002d: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0030: iget v1, v3.Lcom/coolots/sso/a/a;->f:Lcom/coolots/sso/a/g;
    0032: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0035: move-result-object v1
    0036: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0039: move-result-object v0
    003a: const-string v1, ' => removed'
    003c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003f: move-result-object v0
    0040: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0043: move-result-object v0
    0044: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0047: iget v0, v3.Lcom/coolots/sso/a/a;->f:Lcom/coolots/sso/a/g;
    0049: invoke-virtual {v4, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    004c: iput v2, v3.Lcom/coolots/sso/a/a;->f:Lcom/coolots/sso/a/g;
    004e: return-void

  [Virtual Method] a(Landroid/content/Context;, Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;) -> I
    // registers=16, ins=10, outs=6, insns_size=261
    0000: const-string v0, 'createAccount() call start'
    0002: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0005: invoke-static {v7}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    0008: move-result v0
    0009: if-nez v0, 0012
    000b: const-string v0, 'ChatON V is not installed'
    000d: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0010: const/4 v0, 2
    0011: return v0
    0012: const-string v0, 'content://com.coolots.chaton/create_account'
    0014: invoke-static {v7, v0}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0017: move-result v0
    0018: const/4 v1, 1
    0019: if-ne v0, v1, 0022
    001b: const-string v0, 'not allowed access'
    001d: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0020: const/4 v0, 5
    0021: goto 0011
    0022: const/4 v1, 2
    0023: if-ne v0, v1, 002d
    0025: const-string v0, 'not supported function'
    0027: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    002a: const/16 v0, 13 (0xd)
    002c: goto 0011
    002d: const/4 v1, 3
    002e: if-ne v0, v1, 0035
    0030: const-string v0, 'no account'
    0032: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0035: if-eqz v9, 003d
    0037: invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z
    003a: move-result v0
    003b: if-eqz v0, 0044
    003d: const-string v0, 'samsungAccount is empty'
    003f: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0042: const/4 v0, 3
    0043: goto 0011
    0044: if-eqz v10, 004c
    0046: invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z
    0049: move-result v0
    004a: if-eqz v0, 0053
    004c: const-string v0, 'nationalCode is empty'
    004e: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0051: const/4 v0, 6
    0052: goto 0011
    0053: if-eqz v11, 005b
    0055: invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z
    0058: move-result v0
    0059: if-eqz v0, 0062
    005b: const-string v0, 'GUID is empty'
    005d: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0060: const/4 v0, 7
    0061: goto 0011
    0062: if-eqz v12, 006a
    0064: invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z
    0067: move-result v0
    0068: if-eqz v0, 0072
    006a: const-string v0, 'callerName is empty'
    006c: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    006f: const/16 v0, 8 (0x8)
    0071: goto 0011
    0072: if-eqz v8, 007a
    0074: invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z
    0077: move-result v0
    0078: if-eqz v0, 0082
    007a: const-string v0, 'chatonID is empty'
    007c: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    007f: const/16 v0, 9 (0x9)
    0081: goto 0011
    0082: if-eqz v13, 008a
    0084: invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z
    0087: move-result v0
    0088: if-eqz v0, 0092
    008a: const-string v0, 'IMEI is empty'
    008c: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    008f: const/16 v0, 11 (0xb)
    0091: goto 0011
    0092: if-eqz v14, 009a
    0094: invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z
    0097: move-result v0
    0098: if-eqz v0, 00a3
    009a: const-string v0, 'chatONUID is empty'
    009c: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    009f: const/16 v0, 10 (0xa)
    00a1: goto/16 0011
    00a3: if-eqz v15, 00ab
    00a5: invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z
    00a8: move-result v0
    00a9: if-eqz v0, 00b0
    00ab: const-string v0, 'birthday is empty'
    00ad: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    00b0: const-string v1, 'content://com.coolots.chaton/create_account'
    00b2: const/16 v0, 8 (0x8)
    00b4: new-array v4, v0, [Ljava/lang/String;
    00b6: const/4 v0, 0
    00b7: invoke-static {v9}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    00ba: move-result-object v2
    00bb: aput(op=4d) v2, v4[v0]
    00bd: const/4 v0, 1
    00be: invoke-static {v10}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    00c1: move-result-object v2
    00c2: aput(op=4d) v2, v4[v0]
    00c4: const/4 v0, 2
    00c5: invoke-static {v12}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    00c8: move-result-object v2
    00c9: aput(op=4d) v2, v4[v0]
    00cb: const/4 v0, 3
    00cc: invoke-static {v11}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    00cf: move-result-object v2
    00d0: aput(op=4d) v2, v4[v0]
    00d2: const/4 v0, 4
    00d3: invoke-static {v8}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    00d6: move-result-object v2
    00d7: aput(op=4d) v2, v4[v0]
    00d9: const/4 v0, 5
    00da: invoke-static {v13}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    00dd: move-result-object v2
    00de: aput(op=4d) v2, v4[v0]
    00e0: const/4 v0, 6
    00e1: invoke-static {v14}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    00e4: move-result-object v2
    00e5: aput(op=4d) v2, v4[v0]
    00e7: const/4 v0, 7
    00e8: invoke-static {v15}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    00eb: move-result-object v2
    00ec: aput(op=4d) v2, v4[v0]
    00ee: invoke-virtual {v7}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    00f1: move-result-object v0
    00f2: invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    00f5: move-result-object v1
    00f6: const/4 v2, 0
    00f7: const/4 v3, 0
    00f8: const/4 v5, 0
    00f9: invoke-virtual/range {v0..v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    00fc: move-result-object v0
    00fd: if-eqz v0, 0102
    00ff: invoke-interface {v0}, Landroid/database/Cursor;->close()V
    0102: const/4 v0, 0
    0103: goto/16 0011

  [Virtual Method] a(Landroid/content/Context;, Z, Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;) -> I
    // registers=14, ins=6, outs=6, insns_size=130
    0000: const/4 v7, 1
    0001: const/4 v6, 0
    0002: const/4 v2, 0
    0003: const/4 v3, 3
    0004: const/4 v1, 2
    0005: const-string v0, 'outgoingCall() call start'
    0007: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    000a: invoke-static {v9}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    000d: move-result v0
    000e: if-nez v0, 0017
    0010: const-string v0, 'ChatON V is not installed'
    0012: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0015: move(op=01) v0, v1
    0016: return v0
    0017: const-string v0, 'content://com.coolots.chaton/outgoingcall'
    0019: invoke-static {v9, v0}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    001c: move-result v0
    001d: if-ne v0, v7, 0026
    001f: const-string v0, 'not allowed access'
    0021: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0024: const/4 v0, 5
    0025: goto 0016
    0026: if-ne v0, v1, 0030
    0028: const-string v0, 'not supported function'
    002a: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    002d: const/16 v0, 13 (0xd)
    002f: goto 0016
    0030: if-ne v0, v3, 003a
    0032: const-string v0, 'no account'
    0034: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0037: const/16 v0, 14 (0xe)
    0039: goto 0016
    003a: if-eqz v11, 0042
    003c: invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z
    003f: move-result v0
    0040: if-eqz v0, 0049
    0042: const-string v0, 'chatonID is empty'
    0044: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0047: move(op=01) v0, v3
    0048: goto 0016
    0049: const-string v5, 'content://com.coolots.chaton/outgoingcall'
    004b: const/4 v0, 4
    004c: new-array v4, v0, [Ljava/lang/String;
    004e: if-eqz v10, 007f
    0050: const-string v0, '1'
    0052: invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    0055: move-result-object v0
    0056: aput(op=4d) v0, v4[v6]
    0058: invoke-static {v12}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    005b: move-result-object v0
    005c: aput(op=4d) v0, v4[v7]
    005e: invoke-static {v11}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    0061: move-result-object v0
    0062: aput(op=4d) v0, v4[v1]
    0064: invoke-static {v13}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    0067: move-result-object v0
    0068: aput(op=4d) v0, v4[v3]
    006a: invoke-virtual {v9}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    006d: move-result-object v0
    006e: invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    0071: move-result-object v1
    0072: move(op=07) v3, v2
    0073: move(op=07) v5, v2
    0074: invoke-virtual/range {v0..v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    0077: move-result-object v0
    0078: if-eqz v0, 007d
    007a: invoke-interface {v0}, Landroid/database/Cursor;->close()V
    007d: move(op=01) v0, v6
    007e: goto 0016
    007f: const-string v0, '0'
    0081: goto 0052

  [Virtual Method] a(Landroid/content/Context;, Z, [Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;) -> I
    // registers=15, ins=7, outs=6, insns_size=142
    0000: const/4 v7, 1
    0001: const/4 v2, 0
    0002: const/4 v3, 3
    0003: const/4 v1, 2
    0004: const/4 v6, 0
    0005: const-string v0, 'outgoingConferenceCall() call start'
    0007: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    000a: invoke-static {v9}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    000d: move-result v0
    000e: if-nez v0, 0017
    0010: const-string v0, 'ChatON V is not installed'
    0012: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0015: move(op=01) v0, v1
    0016: return v0
    0017: const-string v0, 'content://com.coolots.chaton/outgoingconferencecall'
    0019: invoke-static {v9, v0}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    001c: move-result v0
    001d: if-ne v0, v7, 0026
    001f: const-string v0, 'not allowed access'
    0021: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0024: const/4 v0, 5
    0025: goto 0016
    0026: if-ne v0, v1, 0030
    0028: const-string v0, 'not supported function'
    002a: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    002d: const/16 v0, 13 (0xd)
    002f: goto 0016
    0030: if-ne v0, v3, 003a
    0032: const-string v0, 'no account'
    0034: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0037: const/16 v0, 14 (0xe)
    0039: goto 0016
    003a: if-eqz v11, 003f
    003c: move(op=21) v0, v11
    003d: if-nez v0, 0046
    003f: const-string v0, 'samsungAccount is empty'
    0041: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0044: move(op=01) v0, v3
    0045: goto 0016
    0046: const-string v5, 'content://com.coolots.chaton/outgoingconferencecall'
    0048: move(op=21) v0, v11
    0049: binop/lit8(op=d8) v0, v0, 5 (0x5)
    004b: new-array v4, v0, [Ljava/lang/String;
    004d: if-eqz v10, 008b
    004f: const-string v0, '1'
    0051: invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    0054: move-result-object v0
    0055: aput(op=4d) v0, v4[v6]
    0057: invoke-static {v12}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    005a: move-result-object v0
    005b: aput(op=4d) v0, v4[v7]
    005d: invoke-static {v13}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    0060: move-result-object v0
    0061: aput(op=4d) v0, v4[v1]
    0063: invoke-static {v14}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    0066: move-result-object v0
    0067: aput(op=4d) v0, v4[v3]
    0069: const/4 v0, 4
    006a: move(op=21) v1, v11
    006b: invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    006e: move-result-object v1
    006f: aput(op=4d) v1, v4[v0]
    0071: const/4 v0, 5
    0072: move(op=21) v1, v11
    0073: invoke-static {v11, v6, v4, v0, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0076: invoke-virtual {v9}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    0079: move-result-object v0
    007a: invoke-static {v5}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    007d: move-result-object v1
    007e: move(op=07) v3, v2
    007f: move(op=07) v5, v2
    0080: invoke-virtual/range {v0..v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    0083: move-result-object v0
    0084: if-eqz v0, 0089
    0086: invoke-interface {v0}, Landroid/database/Cursor;->close()V
    0089: move(op=01) v0, v6
    008a: goto 0016
    008b: const-string v0, '0'
    008d: goto 0051

  [Virtual Method] a(Landroid/content/Context;) -> V
    // registers=3, ins=2, outs=2, insns_size=15
    0000: return-void
    0001: nop
    0002: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0005: invoke-direct {v1, v2}, Lcom/coolots/sso/a/a;->p(Landroid/content/Context;)V
    0008: invoke-direct {v1, v2}, Lcom/coolots/sso/a/a;->q(Landroid/content/Context;)V
    000b: invoke-direct {v1, v2}, Lcom/coolots/sso/a/a;->r(Landroid/content/Context;)V
    000e: return-void

  [Virtual Method] a(Landroid/content/Context;, Lcom/coolots/sso/a/b;) -> V
    // registers=7, ins=3, outs=5, insns_size=134
    0000: return-void
    0001: if-nez v6, 001d
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: const-string v1, 'setCallListener: clear '
    0007: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    000a: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    000d: move-result-object v1
    000e: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0011: move-result-object v0
    0012: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0015: move-result-object v0
    0016: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0019: invoke-direct {v4, v5}, Lcom/coolots/sso/a/a;->q(Landroid/content/Context;)V
    001c: return-void
    001d: invoke-direct {v4, v5}, Lcom/coolots/sso/a/a;->q(Landroid/content/Context;)V
    0020: iput v6, v4.Lcom/coolots/sso/a/a;->e:Lcom/coolots/sso/a/b;
    0022: new-instance v0, Lcom/coolots/sso/a/e;
    0024: invoke-direct {v0, v4, v3}, Lcom/coolots/sso/a/e;-><init>(Lcom/coolots/sso/a/a;Lcom/coolots/sso/a/e;)V
    0027: iput v0, v4.Lcom/coolots/sso/a/a;->d:Lcom/coolots/sso/a/e;
    0029: new-instance v0, Ljava/lang/StringBuilder;
    002b: const-string v1, 'setCallListener: set '
    002d: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0030: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0033: move-result-object v1
    0034: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0037: move-result-object v0
    0038: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    003b: move-result-object v0
    003c: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    003f: new-instance v0, Ljava/lang/StringBuilder;
    0041: const-string v1, 'setCallListener: mCallListener '
    0043: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0046: iget v1, v4.Lcom/coolots/sso/a/a;->e:Lcom/coolots/sso/a/b;
    0048: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    004b: move-result-object v1
    004c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004f: move-result-object v0
    0050: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0053: move-result-object v0
    0054: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0057: new-instance v0, Ljava/lang/StringBuilder;
    0059: const-string v1, 'setCallListener: mCallReceiver '
    005b: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    005e: iget v1, v4.Lcom/coolots/sso/a/a;->d:Lcom/coolots/sso/a/e;
    0060: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0063: move-result-object v1
    0064: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0067: move-result-object v0
    0068: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    006b: move-result-object v0
    006c: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    006f: new-instance v0, Landroid/content/IntentFilter;
    0071: invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V
    0074: const-string v1, 'com.coolots.chaton.version.CONFERENCE_MEMBER_CHANGED'
    0076: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    0079: const-string v1, 'com.coolots.chaton.account.CALL_STATE_CHANGE_INFO'
    007b: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    007e: iget v1, v4.Lcom/coolots/sso/a/a;->d:Lcom/coolots/sso/a/e;
    0080: const-string v2, 'com.coolots.permission.COOLOTS'
    0082: invoke-virtual {v5, v1, v0, v2, v3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;
    0085: goto 001c

  [Virtual Method] a(Landroid/content/Context;, Lcom/coolots/sso/a/c;) -> V
    // registers=7, ins=3, outs=5, insns_size=134
    0000: return-void
    0001: if-nez v6, 001d
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: const-string v1, 'setListener: clear '
    0007: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    000a: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    000d: move-result-object v1
    000e: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0011: move-result-object v0
    0012: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0015: move-result-object v0
    0016: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0019: invoke-direct {v4, v5}, Lcom/coolots/sso/a/a;->p(Landroid/content/Context;)V
    001c: return-void
    001d: invoke-direct {v4, v5}, Lcom/coolots/sso/a/a;->p(Landroid/content/Context;)V
    0020: iput v6, v4.Lcom/coolots/sso/a/a;->c:Lcom/coolots/sso/a/c;
    0022: new-instance v0, Lcom/coolots/sso/a/f;
    0024: invoke-direct {v0, v4, v3}, Lcom/coolots/sso/a/f;-><init>(Lcom/coolots/sso/a/a;Lcom/coolots/sso/a/f;)V
    0027: iput v0, v4.Lcom/coolots/sso/a/a;->b:Lcom/coolots/sso/a/f;
    0029: new-instance v0, Ljava/lang/StringBuilder;
    002b: const-string v1, 'setListener: set :'
    002d: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0030: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0033: move-result-object v1
    0034: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0037: move-result-object v0
    0038: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    003b: move-result-object v0
    003c: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    003f: new-instance v0, Ljava/lang/StringBuilder;
    0041: const-string v1, 'setListener: mListener :'
    0043: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0046: iget v1, v4.Lcom/coolots/sso/a/a;->c:Lcom/coolots/sso/a/c;
    0048: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    004b: move-result-object v1
    004c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004f: move-result-object v0
    0050: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0053: move-result-object v0
    0054: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0057: new-instance v0, Ljava/lang/StringBuilder;
    0059: const-string v1, 'setListener: mReceiver :'
    005b: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    005e: iget v1, v4.Lcom/coolots/sso/a/a;->b:Lcom/coolots/sso/a/f;
    0060: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0063: move-result-object v1
    0064: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0067: move-result-object v0
    0068: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    006b: move-result-object v0
    006c: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    006f: new-instance v0, Landroid/content/IntentFilter;
    0071: invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V
    0074: const-string v1, 'com.coolots.chaton.account.ACCOUNT_RESULTINFO'
    0076: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    0079: const-string v1, 'com.coolots.chaton.account.REMOVE_ACCOUNT_RESULTINFO'
    007b: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    007e: iget v1, v4.Lcom/coolots/sso/a/a;->b:Lcom/coolots/sso/a/f;
    0080: const-string v2, 'com.coolots.permission.COOLOTS'
    0082: invoke-virtual {v5, v1, v0, v2, v3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;
    0085: goto 001c

  [Virtual Method] a(Landroid/content/Context;, Lcom/coolots/sso/a/d;) -> V
    // registers=7, ins=3, outs=5, insns_size=129
    0000: return-void
    0001: if-nez v6, 001d
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: const-string v1, 'setUpdateListener: clear '
    0007: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    000a: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    000d: move-result-object v1
    000e: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0011: move-result-object v0
    0012: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0015: move-result-object v0
    0016: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0019: invoke-direct {v4, v5}, Lcom/coolots/sso/a/a;->r(Landroid/content/Context;)V
    001c: return-void
    001d: invoke-direct {v4, v5}, Lcom/coolots/sso/a/a;->r(Landroid/content/Context;)V
    0020: iput v6, v4.Lcom/coolots/sso/a/a;->g:Lcom/coolots/sso/a/d;
    0022: new-instance v0, Lcom/coolots/sso/a/g;
    0024: invoke-direct {v0, v4, v3}, Lcom/coolots/sso/a/g;-><init>(Lcom/coolots/sso/a/a;Lcom/coolots/sso/a/g;)V
    0027: iput v0, v4.Lcom/coolots/sso/a/a;->f:Lcom/coolots/sso/a/g;
    0029: new-instance v0, Ljava/lang/StringBuilder;
    002b: const-string v1, 'setUpdateListener: set '
    002d: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0030: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0033: move-result-object v1
    0034: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0037: move-result-object v0
    0038: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    003b: move-result-object v0
    003c: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    003f: new-instance v0, Ljava/lang/StringBuilder;
    0041: const-string v1, 'setUpdateListener: mUpdateListener '
    0043: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0046: iget v1, v4.Lcom/coolots/sso/a/a;->g:Lcom/coolots/sso/a/d;
    0048: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    004b: move-result-object v1
    004c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004f: move-result-object v0
    0050: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0053: move-result-object v0
    0054: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0057: new-instance v0, Ljava/lang/StringBuilder;
    0059: const-string v1, 'setUpdateListener: mUpdateReceiver '
    005b: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    005e: iget v1, v4.Lcom/coolots/sso/a/a;->f:Lcom/coolots/sso/a/g;
    0060: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0063: move-result-object v1
    0064: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0067: move-result-object v0
    0068: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    006b: move-result-object v0
    006c: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    006f: new-instance v0, Landroid/content/IntentFilter;
    0071: invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V
    0074: const-string v1, 'com.coolots.chaton.version.UPGRADE_NEW_APK_INFO'
    0076: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    0079: iget v1, v4.Lcom/coolots/sso/a/a;->f:Lcom/coolots/sso/a/g;
    007b: const-string v2, 'com.coolots.permission.COOLOTS'
    007d: invoke-virtual {v5, v1, v0, v2, v3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;
    0080: goto 001c

  [Virtual Method] b(Landroid/content/Context;, Z) -> I
    // registers=8, ins=3, outs=5, insns_size=79
    0000: const/4 v0, 0
    0001: return v0
    0002: nop
    0003: invoke-static {v1}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0006: invoke-static {v6}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    0009: move-result v1
    000a: if-nez v1, 0012
    000c: const-string v1, 'ChatON V is not installed'
    000e: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0011: return v0
    0012: const-string v1, 'content://com.coolots.chaton/maxconferencecallnum'
    0014: invoke-static {v6, v1}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0017: move-result v1
    0018: const/4 v2, 1
    0019: if-ne v1, v2, 0021
    001b: const-string v1, 'not allowed access'
    001d: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0020: goto 0011
    0021: const/4 v2, 2
    0022: if-ne v1, v2, 002a
    0024: const-string v1, 'not supported function'
    0026: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0029: goto 0011
    002a: const/4 v2, 3
    002b: if-ne v1, v2, 0033
    002d: const-string v1, 'no account'
    002f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0032: goto 0011
    0033: const-string v0, 'content://com.coolots.chaton/maxconferencecallnum'
    0035: new-instance v1, Landroid/content/ContentValues;
    0037: invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V
    003a: invoke-virtual {v6}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    003d: move-result-object v2
    003e: invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    0041: move-result-object v3
    0042: if-eqz v7, 004c
    0044: const-string v0, '1'
    0046: const/4 v4, 0
    0047: invoke-virtual {v2, v3, v1, v0, v4}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    004a: move-result v0
    004b: goto 0011
    004c: const-string v0, '0'
    004e: goto 0046

  [Virtual Method] c(Landroid/content/Context;) -> I
    // registers=8, ins=2, outs=6, insns_size=69
    0000: const/4 v0, 0
    0001: return v0
    0002: const-string v1, 'removeAccountInDevice() call start'
    0004: invoke-static {v1}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0007: invoke-static {v7}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    000a: move-result v1
    000b: if-nez v1, 0013
    000d: const-string v1, 'ChatON V is not installed'
    000f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0012: return v0
    0013: const-string v1, 'content://com.coolots.chaton/remove_account'
    0015: invoke-static {v7, v1}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0018: move-result v1
    0019: const/4 v3, 1
    001a: if-ne v1, v3, 0023
    001c: const-string v0, 'not allowed access'
    001e: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0021: const/4 v0, 5
    0022: goto 0012
    0023: if-ne v1, v0, 002d
    0025: const-string v0, 'not supported function'
    0027: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    002a: const/16 v0, 13 (0xd)
    002c: goto 0012
    002d: const-string v1, 'content://com.coolots.chaton/remove_account'
    002f: invoke-virtual {v7}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    0032: move-result-object v0
    0033: invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    0036: move-result-object v1
    0037: move(op=07) v3, v2
    0038: move(op=07) v4, v2
    0039: move(op=07) v5, v2
    003a: invoke-virtual/range {v0..v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    003d: move-result-object v0
    003e: if-eqz v0, 0043
    0040: invoke-interface {v0}, Landroid/database/Cursor;->close()V
    0043: const/4 v0, 0
    0044: goto 0012

  [Virtual Method] d(Landroid/content/Context;) -> Z
    // registers=6, ins=2, outs=2, insns_size=53
    0000: const/4 v0, 0
    0001: return v0
    0002: const-string v2, 'isReadyToCall() call start'
    0004: invoke-static {v2}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0007: invoke-static {v5}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    000a: move-result v2
    000b: if-nez v2, 0013
    000d: const-string v1, 'ChatON V is not installed'
    000f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0012: return v0
    0013: const-string v2, 'content://com.coolots.chaton/account'
    0015: invoke-static {v5, v2}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0018: move-result v2
    0019: if-ne v2, v1, 0021
    001b: const-string v1, 'not allowed access'
    001d: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0020: goto 0012
    0021: const/4 v3, 2
    0022: if-ne v2, v3, 002a
    0024: const-string v1, 'not supported function'
    0026: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0029: goto 0012
    002a: const/4 v3, 3
    002b: if-ne v2, v3, 0033
    002d: const-string v1, 'no account'
    002f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0032: goto 0012
    0033: move(op=01) v0, v1
    0034: goto 0012

  [Virtual Method] e(Landroid/content/Context;) -> Landroid/content/Intent;
    // registers=4, ins=2, outs=2, insns_size=29
    0000: const-string v0, 'getIntentSettingActivity()'
    0002: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0005: invoke-virtual {v2, v3}, Lcom/coolots/sso/a/a;->d(Landroid/content/Context;)Z
    0008: move-result v0
    0009: if-eqz v0, 0016
    000b: new-instance v0, Landroid/content/Intent;
    000d: invoke-direct {v0}, Landroid/content/Intent;-><init>()V
    0010: const-string v1, 'com.coolots.chaton.USER_SETTING_SUBPAGE_CALL_SETTINGS'
    0012: invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;
    0015: return-object v0
    0016: const-string v0, 'getIntentSettingActivity() return null'
    0018: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    001b: const/4 v0, 0
    001c: goto 0015

  [Virtual Method] f(Landroid/content/Context;) -> Landroid/content/Intent;
    // registers=4, ins=2, outs=2, insns_size=29
    0000: const-string v0, 'getIntentAboutChatONVActivity()'
    0002: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0005: invoke-virtual {v2, v3}, Lcom/coolots/sso/a/a;->d(Landroid/content/Context;)Z
    0008: move-result v0
    0009: if-eqz v0, 0016
    000b: new-instance v0, Landroid/content/Intent;
    000d: invoke-direct {v0}, Landroid/content/Intent;-><init>()V
    0010: const-string v1, 'com.coolots.chaton.USER_SETTING_SUBPAGE_ABOUNT_CHATON_CALL'
    0012: invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;
    0015: return-object v0
    0016: const-string v0, 'getIntentAboutChatONVActivity() return null'
    0018: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    001b: const/4 v0, 0
    001c: goto 0015

  [Virtual Method] g(Landroid/content/Context;) -> Landroid/content/Intent;
    // registers=4, ins=2, outs=2, insns_size=29
    0000: const-string v0, 'getIntentDataUsageActivity()'
    0002: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0005: invoke-virtual {v2, v3}, Lcom/coolots/sso/a/a;->d(Landroid/content/Context;)Z
    0008: move-result v0
    0009: if-eqz v0, 0016
    000b: new-instance v0, Landroid/content/Intent;
    000d: invoke-direct {v0}, Landroid/content/Intent;-><init>()V
    0010: const-string v1, 'com.coolots.chaton.USER_SETTING_SUBPAGE_DATA_USGAE'
    0012: invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;
    0015: return-object v0
    0016: const-string v0, 'getIntentDataUsageActivity() return null'
    0018: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    001b: const/4 v0, 0
    001c: goto 0015

  [Virtual Method] h(Landroid/content/Context;) -> Z
    // registers=9, ins=2, outs=5, insns_size=77
    0000: const/4 v0, 0
    0001: return v0
    0002: const-string v2, 'showCallActivity() call start'
    0004: invoke-static {v2}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0007: invoke-static {v8}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    000a: move-result v2
    000b: if-nez v2, 0013
    000d: const-string v1, 'ChatON V is not installed'
    000f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0012: return v0
    0013: const-string v2, 'content://com.coolots.chaton/remotecallactivity'
    0015: invoke-static {v8, v2}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0018: move-result v2
    0019: if-ne v2, v1, 0021
    001b: const-string v1, 'not allowed access'
    001d: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0020: goto 0012
    0021: const/4 v3, 2
    0022: if-ne v2, v3, 002a
    0024: const-string v1, 'not supported function'
    0026: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0029: goto 0012
    002a: const/4 v3, 3
    002b: if-ne v2, v3, 0033
    002d: const-string v1, 'no account'
    002f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0032: goto 0012
    0033: const-string v2, 'content://com.coolots.chaton/remotecallactivity'
    0035: new-instance v3, Landroid/content/ContentValues;
    0037: invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V
    003a: invoke-virtual {v8}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    003d: move-result-object v4
    003e: invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    0041: move-result-object v2
    0042: const-string v5, '0'
    0044: const/4 v6, 0
    0045: invoke-virtual {v4, v2, v3, v5, v6}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    0048: move-result v2
    0049: if-ne v2, v1, 0012
    004b: move(op=01) v0, v1
    004c: goto 0012

  [Virtual Method] i(Landroid/content/Context;) -> Z
    // registers=9, ins=2, outs=5, insns_size=77
    0000: const/4 v0, 0
    0001: return v0
    0002: const-string v2, 'endCallActivity() call start'
    0004: invoke-static {v2}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0007: invoke-static {v8}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    000a: move-result v2
    000b: if-nez v2, 0013
    000d: const-string v1, 'ChatON V is not installed'
    000f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0012: return v0
    0013: const-string v2, 'content://com.coolots.chaton/remotecallactivity'
    0015: invoke-static {v8, v2}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0018: move-result v2
    0019: if-ne v2, v1, 0021
    001b: const-string v1, 'not allowed access'
    001d: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0020: goto 0012
    0021: const/4 v3, 2
    0022: if-ne v2, v3, 002a
    0024: const-string v1, 'not supported function'
    0026: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0029: goto 0012
    002a: const/4 v3, 3
    002b: if-ne v2, v3, 0033
    002d: const-string v1, 'no account'
    002f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0032: goto 0012
    0033: const-string v2, 'content://com.coolots.chaton/remotecallactivity'
    0035: new-instance v3, Landroid/content/ContentValues;
    0037: invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V
    003a: invoke-virtual {v8}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    003d: move-result-object v4
    003e: invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    0041: move-result-object v2
    0042: const-string v5, '1'
    0044: const/4 v6, 0
    0045: invoke-virtual {v4, v2, v3, v5, v6}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    0048: move-result v2
    0049: if-ne v2, v1, 0012
    004b: move(op=01) v0, v1
    004c: goto 0012

  [Virtual Method] j(Landroid/content/Context;) -> I
    // registers=5, ins=2, outs=2, insns_size=72
    0000: const/4 v0, -1
    0001: const-string v1, 'getCallDuration() call start'
    0003: invoke-static {v1}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0006: invoke-static {v4}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    0009: move-result v1
    000a: if-nez v1, 0012
    000c: const-string v1, 'ChatON V is not installed'
    000e: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0011: return v0
    0012: const-string v1, 'content://com.coolots.chaton/callduration'
    0014: invoke-static {v4, v1}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0017: move-result v1
    0018: const/4 v2, 1
    0019: if-ne v1, v2, 0021
    001b: const-string v1, 'not allowed access'
    001d: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0020: goto 0011
    0021: const/4 v2, 2
    0022: if-ne v1, v2, 002a
    0024: const-string v1, 'not supported function'
    0026: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0029: goto 0011
    002a: const/4 v2, 3
    002b: if-ne v1, v2, 0033
    002d: const-string v1, 'no account'
    002f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0032: goto 0011
    0033: const-string v1, 'content://com.coolots.chaton/callduration'
    0035: invoke-virtual {v4}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    0038: move-result-object v2
    0039: invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    003c: move-result-object v1
    003d: invoke-virtual {v2, v1}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;
    0040: move-result-object v1
    0041: if-eqz v1, 0011
    0043: invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    0046: move-result v0
    0047: goto 0011

  [Virtual Method] k(Landroid/content/Context;) -> Z
    // registers=6, ins=2, outs=2, insns_size=69
    0000: const/4 v0, 0
    0001: return v0
    0002: const-string v2, 'isCalling() call start'
    0004: invoke-static {v2}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0007: invoke-static {v5}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    000a: move-result v2
    000b: if-nez v2, 0013
    000d: const-string v1, 'ChatON V is not installed'
    000f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0012: return v0
    0013: const-string v2, 'content://com.coolots.chaton/iscalling'
    0015: invoke-static {v5, v2}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0018: move-result v2
    0019: if-ne v2, v1, 0021
    001b: const-string v1, 'not allowed access'
    001d: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0020: goto 0012
    0021: const/4 v3, 2
    0022: if-ne v2, v3, 002a
    0024: const-string v1, 'not supported function'
    0026: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0029: goto 0012
    002a: const/4 v3, 3
    002b: if-ne v2, v3, 0033
    002d: const-string v1, 'no account'
    002f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0032: goto 0012
    0033: const-string v2, 'content://com.coolots.chaton/iscalling'
    0035: invoke-virtual {v5}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    0038: move-result-object v3
    0039: invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    003c: move-result-object v2
    003d: invoke-virtual {v3, v2}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;
    0040: move-result-object v2
    0041: if-eqz v2, 0012
    0043: move(op=01) v0, v1
    0044: goto 0012

  [Virtual Method] l(Landroid/content/Context;) -> I
    // registers=6, ins=2, outs=2, insns_size=74
    0000: const/4 v1, 3
    0001: const/4 v0, 0
    0002: const-string v2, 'getCallStateDuringCall() call start'
    0004: invoke-static {v2}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0007: invoke-static {v5}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    000a: move-result v2
    000b: if-nez v2, 0013
    000d: const-string v1, 'ChatON V is not installed'
    000f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0012: return v0
    0013: const-string v2, 'content://com.coolots.chaton/callstate'
    0015: invoke-static {v5, v2}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0018: move-result v2
    0019: const/4 v3, 1
    001a: if-ne v2, v3, 0022
    001c: const-string v1, 'not allowed access'
    001e: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0021: goto 0012
    0022: const/4 v3, 2
    0023: if-ne v2, v3, 002b
    0025: const-string v1, 'not supported function'
    0027: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    002a: goto 0012
    002b: if-ne v2, v1, 0033
    002d: const-string v1, 'no account'
    002f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0032: goto 0012
    0033: const-string v0, 'content://com.coolots.chaton/callstate'
    0035: invoke-virtual {v5}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    0038: move-result-object v2
    0039: invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    003c: move-result-object v0
    003d: invoke-virtual {v2, v0}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;
    0040: move-result-object v0
    0041: if-nez v0, 0045
    0043: move(op=01) v0, v1
    0044: goto 0012
    0045: invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    0048: move-result v0
    0049: goto 0012

  [Virtual Method] m(Landroid/content/Context;) -> I
    // registers=6, ins=2, outs=5, insns_size=72
    0000: const/4 v3, 0
    0001: const/4 v0, 0
    0002: const-string v1, 'getCallType() call start'
    0004: invoke-static {v1}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0007: invoke-static {v5}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    000a: move-result v1
    000b: if-nez v1, 0013
    000d: const-string v1, 'ChatON V is not installed'
    000f: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0012: return v0
    0013: const-string v1, 'content://com.coolots.chaton/get_call_type'
    0015: invoke-static {v5, v1}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0018: move-result v1
    0019: const/4 v2, 1
    001a: if-ne v1, v2, 0022
    001c: const-string v1, 'not allowed access'
    001e: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0021: goto 0012
    0022: const/4 v2, 2
    0023: if-ne v1, v2, 002b
    0025: const-string v1, 'not supported function'
    0027: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    002a: goto 0012
    002b: const/4 v2, 3
    002c: if-ne v1, v2, 0034
    002e: const-string v1, 'no account'
    0030: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0033: goto 0012
    0034: const-string v0, 'content://com.coolots.chaton/get_call_type'
    0036: new-instance v1, Landroid/content/ContentValues;
    0038: invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V
    003b: invoke-virtual {v5}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    003e: move-result-object v2
    003f: invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    0042: move-result-object v0
    0043: invoke-virtual {v2, v0, v1, v3, v3}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    0046: move-result v0
    0047: goto 0012

  [Virtual Method] n(Landroid/content/Context;) -> Ljava/util/ArrayList;
    // registers=7, ins=2, outs=2, insns_size=130
    0000: const/4 v1, 0
    0001: const-string v0, 'getCallMember() call start'
    0003: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0006: invoke-static {v6}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    0009: move-result v0
    000a: if-nez v0, 0013
    000c: const-string v0, 'ChatON V is not installed'
    000e: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0011: move(op=07) v0, v1
    0012: return-object v0
    0013: const-string v0, 'content://com.coolots.chaton/get_call_member'
    0015: invoke-static {v6, v0}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0018: move-result v0
    0019: const/4 v2, 1
    001a: if-ne v0, v2, 0023
    001c: const-string v0, 'not allowed access'
    001e: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0021: move(op=07) v0, v1
    0022: goto 0012
    0023: const/4 v2, 2
    0024: if-ne v0, v2, 002d
    0026: const-string v0, 'not supported function'
    0028: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    002b: move(op=07) v0, v1
    002c: goto 0012
    002d: const/4 v2, 3
    002e: if-ne v0, v2, 0037
    0030: const-string v0, 'no account'
    0032: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0035: move(op=07) v0, v1
    0036: goto 0012
    0037: const-string v0, 'content://com.coolots.chaton/get_call_member'
    0039: invoke-virtual {v6}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    003c: move-result-object v3
    003d: new-instance v2, Ljava/util/ArrayList;
    003f: invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V
    0042: invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    0045: move-result-object v0
    0046: invoke-virtual {v3, v0}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;
    0049: move-result-object v0
    004a: if-eqz v0, 0052
    004c: invoke-virtual {v0}, Ljava/lang/String;->length()I
    004f: move-result v3
    0050: if-nez v3, 0054
    0052: move(op=07) v0, v1
    0053: goto 0012
    0054: const-string v3, ':'
    0056: invoke-virtual {v0, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;
    0059: move-result-object v3
    005a: const/4 v0, 0
    005b: move(op=21) v4, v3
    005c: if-lt v0, v4, 0078
    005e: new-instance v0, Ljava/lang/StringBuilder;
    0060: const-string v3, 'call member: '
    0062: invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0065: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0068: move-result-object v0
    0069: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    006c: move-result-object v0
    006d: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0070: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    0073: move-result v0
    0074: if-nez v0, 0080
    0076: move(op=07) v0, v1
    0077: goto 0012
    0078: aget(op=46) v4, v3[v0]
    007a: invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    007d: binop/lit8(op=d8) v0, v0, 1 (0x1)
    007f: goto 005b
    0080: move(op=07) v0, v2
    0081: goto 0012

  [Virtual Method] o(Landroid/content/Context;) -> I
    // registers=5, ins=2, outs=2, insns_size=70
    0000: const/4 v0, 2
    0001: const-string v1, 'getLatestApkVersion() call start'
    0003: invoke-static {v1}, Lcom/coolots/sso/a/a;->b(Ljava/lang/String;)V
    0006: invoke-static {v4}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    0009: move-result v1
    000a: if-nez v1, 0012
    000c: const-string v1, 'ChatON V is not installed'
    000e: invoke-static {v1}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0011: return v0
    0012: const-string v1, 'content://com.coolots.chaton/get_latest_version'
    0014: invoke-static {v4, v1}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;Ljava/lang/String;)I
    0017: move-result v1
    0018: const/4 v2, 1
    0019: if-ne v1, v2, 0022
    001b: const-string v0, 'not allowed access'
    001d: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0020: const/4 v0, 5
    0021: goto 0011
    0022: if-ne v1, v0, 002c
    0024: const-string v0, 'not supported function'
    0026: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0029: const/16 v0, 13 (0xd)
    002b: goto 0011
    002c: const/4 v0, 3
    002d: if-ne v1, v0, 0037
    002f: const-string v0, 'no account'
    0031: invoke-static {v0}, Lcom/coolots/sso/a/a;->c(Ljava/lang/String;)V
    0034: const/16 v0, 14 (0xe)
    0036: goto 0011
    0037: const-string v0, 'content://com.coolots.chaton/get_latest_version'
    0039: invoke-virtual {v4}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    003c: move-result-object v1
    003d: invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    0040: move-result-object v0
    0041: invoke-virtual {v1, v0}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;
    0044: const/4 v0, 0
    0045: goto 0011