=== CLASS Lcom/coolots/sso/a/c; (Source: ) ===
  Super: Ljava/lang/Object;

  [Virtual Method] a(Z) -> V

  [Virtual Method] a(Z, Ljava/lang/String;) -> V