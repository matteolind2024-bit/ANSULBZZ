=== CLASS Lcom/coolots/sso/a/b; (Source: ) ===
  Super: Ljava/lang/Object;

  [Virtual Method] a() -> V

  [Virtual Method] a(I) -> V