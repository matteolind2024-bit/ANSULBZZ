=== CLASS Lcom/coolots/sso/a/g; (Source: ) ===
  Super: Landroid/content/BroadcastReceiver;
  [Instance Field] a: Lcom/coolots/sso/a/a;

  [Direct Method] <init>(Lcom/coolots/sso/a/a;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/coolots/sso/a/g;->a:Lcom/coolots/sso/a/a;
    0002: invoke-direct {v0}, Landroid/content/BroadcastReceiver;-><init>()V
    0005: return-void

  [Direct Method] <init>(Lcom/coolots/sso/a/a;, Lcom/coolots/sso/a/g;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/coolots/sso/a/g;-><init>(Lcom/coolots/sso/a/a;)V
    0003: return-void

  [Virtual Method] onReceive(Landroid/content/Context;, Landroid/content/Intent;) -> V
    // registers=8, ins=3, outs=4, insns_size=203
    0000: invoke-virtual {v7}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0003: move-result-object v0
    0004: if-nez v0, 0007
    0006: return-void
    0007: new-instance v1, Ljava/lang/StringBuilder;
    0009: const-string v2, 'ChatONVAPIIUpdateReceiver() action: '
    000b: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0011: move-result-object v1
    0012: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0015: move-result-object v1
    0016: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    0019: new-instance v1, Ljava/lang/StringBuilder;
    001b: const-string v2, 'ChatONVAPIIUpdateReceiver() this: '
    001d: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0020: invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0023: move-result-object v2
    0024: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0027: move-result-object v1
    0028: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002b: move-result-object v1
    002c: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    002f: new-instance v1, Ljava/lang/StringBuilder;
    0031: const-string v2, 'ChatONVAPIIUpdateReceiver() mUpdateListener: '
    0033: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0036: iget v2, v5.Lcom/coolots/sso/a/g;->a:Lcom/coolots/sso/a/a;
    0038: invoke-static {v2}, Lcom/coolots/sso/a/a;->e(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/d;
    003b: move-result-object v2
    003c: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    003f: move-result-object v2
    0040: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0043: move-result-object v1
    0044: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0047: move-result-object v1
    0048: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    004b: new-instance v1, Ljava/lang/StringBuilder;
    004d: const-string v2, 'ChatONVAPIIUpdateReceiver() mUpdateReceiver: '
    004f: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0052: iget v2, v5.Lcom/coolots/sso/a/g;->a:Lcom/coolots/sso/a/a;
    0054: invoke-static {v2}, Lcom/coolots/sso/a/a;->f(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/g;
    0057: move-result-object v2
    0058: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    005b: move-result-object v2
    005c: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    005f: move-result-object v1
    0060: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0063: move-result-object v1
    0064: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    0067: const-string v1, 'com.coolots.chaton.version.UPGRADE_NEW_APK_INFO'
    0069: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    006c: move-result v0
    006d: if-eqz v0, 0006
    006f: const-string v0, 'version_name'
    0071: invoke-virtual {v7, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z
    0074: move-result v0
    0075: if-eqz v0, 0006
    0077: const-string v0, 'version_info'
    0079: invoke-virtual {v7, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z
    007c: move-result v0
    007d: if-eqz v0, 0006
    007f: const-string v0, 'current_version_name'
    0081: invoke-virtual {v7, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    0084: move-result-object v0
    0085: const-string v1, 'version_name'
    0087: invoke-virtual {v7, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    008a: move-result-object v1
    008b: const-string v2, 'version_info'
    008d: const/4 v3, 0
    008e: invoke-virtual {v7, v2, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    0091: move-result v2
    0092: new-instance v3, Ljava/lang/StringBuilder;
    0094: const-string v4, 'BR_UPGRADE_NEW_APK_INFO '
    0096: invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0099: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    009c: move-result-object v3
    009d: const-string v4, ', '
    009f: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a2: move-result-object v3
    00a3: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a6: move-result-object v3
    00a7: const-string v4, ', '
    00a9: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00ac: move-result-object v3
    00ad: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    00b0: move-result-object v3
    00b1: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00b4: move-result-object v3
    00b5: invoke-static {v3}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    00b8: iget v3, v5.Lcom/coolots/sso/a/g;->a:Lcom/coolots/sso/a/a;
    00ba: invoke-static {v3}, Lcom/coolots/sso/a/a;->e(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/d;
    00bd: move-result-object v3
    00be: if-eqz v3, 0006
    00c0: iget v3, v5.Lcom/coolots/sso/a/g;->a:Lcom/coolots/sso/a/a;
    00c2: invoke-static {v3}, Lcom/coolots/sso/a/a;->e(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/d;
    00c5: move-result-object v3
    00c6: invoke-interface {v3, v0, v1, v2}, Lcom/coolots/sso/a/d;->a(Ljava/lang/String;Ljava/lang/String;I)V
    00c9: goto/16 0006