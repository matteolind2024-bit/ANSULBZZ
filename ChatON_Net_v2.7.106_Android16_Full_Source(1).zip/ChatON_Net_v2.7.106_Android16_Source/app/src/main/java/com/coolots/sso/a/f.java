=== CLASS Lcom/coolots/sso/a/f; (Source: ) ===
  Super: Landroid/content/BroadcastReceiver;
  [Instance Field] a: Lcom/coolots/sso/a/a;

  [Direct Method] <init>(Lcom/coolots/sso/a/a;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/coolots/sso/a/f;->a:Lcom/coolots/sso/a/a;
    0002: invoke-direct {v0}, Landroid/content/BroadcastReceiver;-><init>()V
    0005: return-void

  [Direct Method] <init>(Lcom/coolots/sso/a/a;, Lcom/coolots/sso/a/f;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/coolots/sso/a/f;-><init>(Lcom/coolots/sso/a/a;)V
    0003: return-void

  [Virtual Method] onReceive(Landroid/content/Context;, Landroid/content/Intent;) -> V
    // registers=7, ins=3, outs=3, insns_size=230
    0000: const/4 v3, 0
    0001: invoke-virtual {v6}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0004: move-result-object v0
    0005: if-nez v0, 0008
    0007: return-void
    0008: new-instance v1, Ljava/lang/StringBuilder;
    000a: const-string v2, 'ChatONVAPIIReceiver() action: '
    000c: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    000f: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0016: move-result-object v1
    0017: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    001a: new-instance v1, Ljava/lang/StringBuilder;
    001c: const-string v2, 'ChatONVAPIIReceiver() this: '
    001e: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0021: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0024: move-result-object v2
    0025: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0028: move-result-object v1
    0029: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002c: move-result-object v1
    002d: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    0030: new-instance v1, Ljava/lang/StringBuilder;
    0032: const-string v2, 'ChatONVAPIIReceiver() mListener: '
    0034: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0037: iget v2, v4.Lcom/coolots/sso/a/f;->a:Lcom/coolots/sso/a/a;
    0039: invoke-static {v2}, Lcom/coolots/sso/a/a;->a(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/c;
    003c: move-result-object v2
    003d: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0040: move-result-object v2
    0041: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0044: move-result-object v1
    0045: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0048: move-result-object v1
    0049: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    004c: new-instance v1, Ljava/lang/StringBuilder;
    004e: const-string v2, 'ChatONVAPIIReceiver() mReceiver: '
    0050: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0053: iget v2, v4.Lcom/coolots/sso/a/f;->a:Lcom/coolots/sso/a/a;
    0055: invoke-static {v2}, Lcom/coolots/sso/a/a;->b(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/f;
    0058: move-result-object v2
    0059: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    005c: move-result-object v2
    005d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0060: move-result-object v1
    0061: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0064: move-result-object v1
    0065: invoke-static {v1}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    0068: const-string v1, 'com.coolots.chaton.account.ACCOUNT_RESULTINFO'
    006a: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    006d: move-result v1
    006e: if-eqz v1, 00b8
    0070: const-string v0, 'result'
    0072: invoke-virtual {v6, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z
    0075: move-result v0
    0076: if-eqz v0, 0007
    0078: const-string v0, 'BR_ACCOUNT_RESULT_INFO'
    007a: invoke-static {v0}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    007d: iget v0, v4.Lcom/coolots/sso/a/f;->a:Lcom/coolots/sso/a/a;
    007f: invoke-static {v0}, Lcom/coolots/sso/a/a;->a(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/c;
    0082: move-result-object v0
    0083: if-eqz v0, 0007
    0085: const-string v0, 'result'
    0087: invoke-virtual {v6, v0, v3}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    008a: move-result v0
    008b: const-string v1, 'account_fail_string'
    008d: invoke-virtual {v6, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    0090: move-result-object v1
    0091: new-instance v2, Ljava/lang/StringBuilder;
    0093: const-string v3, 'result: '
    0095: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0098: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    009b: move-result-object v2
    009c: const-string v3, ', result string: '
    009e: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a1: move-result-object v2
    00a2: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a5: move-result-object v2
    00a6: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00a9: move-result-object v2
    00aa: invoke-static {v2}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    00ad: iget v2, v4.Lcom/coolots/sso/a/f;->a:Lcom/coolots/sso/a/a;
    00af: invoke-static {v2}, Lcom/coolots/sso/a/a;->a(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/c;
    00b2: move-result-object v2
    00b3: invoke-interface {v2, v0, v1}, Lcom/coolots/sso/a/c;->a(ZLjava/lang/String;)V
    00b6: goto/16 0007
    00b8: const-string v1, 'com.coolots.chaton.account.REMOVE_ACCOUNT_RESULTINFO'
    00ba: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    00bd: move-result v0
    00be: if-eqz v0, 0007
    00c0: const-string v0, 'result'
    00c2: invoke-virtual {v6, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z
    00c5: move-result v0
    00c6: if-eqz v0, 0007
    00c8: const-string v0, 'BR_REMOVE_ACCOUNT_RESULT_INFO'
    00ca: invoke-static {v0}, Lcom/coolots/sso/a/a;->a(Ljava/lang/String;)V
    00cd: iget v0, v4.Lcom/coolots/sso/a/f;->a:Lcom/coolots/sso/a/a;
    00cf: invoke-static {v0}, Lcom/coolots/sso/a/a;->a(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/c;
    00d2: move-result-object v0
    00d3: if-eqz v0, 0007
    00d5: iget v0, v4.Lcom/coolots/sso/a/f;->a:Lcom/coolots/sso/a/a;
    00d7: invoke-static {v0}, Lcom/coolots/sso/a/a;->a(Lcom/coolots/sso/a/a;)Lcom/coolots/sso/a/c;
    00da: move-result-object v0
    00db: const-string v1, 'result'
    00dd: invoke-virtual {v6, v1, v3}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    00e0: move-result v1
    00e1: invoke-interface {v0, v1}, Lcom/coolots/sso/a/c;->a(Z)V
    00e4: goto/16 0007