=== CLASS Lcom/samsung/spen/SPenLibrary; (Source: SPenLibrary.java) ===
  Super: Ljava/lang/Object;
  [Static Field] REQUIRE_SUPPORTED_DEVICE: Z
  [Static Field] VERSION: Lcom/samsung/spen/SPenLibraryVersion;

  [Direct Method] <clinit>() -> V
    // registers=4, ins=0, outs=4, insns_size=11
    0000: new-instance v0, Lcom/samsung/spen/SPenLibraryVersion;
    0002: const/4 v1, 0
    0003: const/4 v2, 5
    0004: const/4 v3, 1
    0005: invoke-direct {v0, v1, v2, v3}, Lcom/samsung/spen/SPenLibraryVersion;-><init>(III)V
    0008: sput v0, Lcom/samsung/spen/SPenLibrary;->VERSION:Lcom/samsung/spen/SPenLibraryVersion;
    000a: return-void

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getEvent(Landroid/view/MotionEvent;) -> Lcom/samsung/spen/SPenEvent;
    // registers=3, ins=1, outs=3, insns_size=17
    0000: if-nez v2, 000a
    0002: new-instance v0, Ljava/lang/IllegalArgumentException;
    0004: const-string v1, "Event can't be null."
    0006: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0009: throw v0
    000a: new-instance v0, Lcom/samsung/spen/SPenEvent;
    000c: const/4 v1, 0
    000d: invoke-direct {v0, v2, v1}, Lcom/samsung/spen/SPenEvent;-><init>(Landroid/view/MotionEvent;Z)V
    0010: return-object v0

  [Direct Method] getSupportedModels() -> [Ljava/lang/String;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/samsung/spen/DeviceModel;->SUPPORTED_MODELS:[Ljava/lang/String;
    0002: return-object v0

  [Direct Method] isSupportedDevice() -> Z
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/samsung/spen/DeviceModel;->IS_SUPPORTED_DEVICE:Z
    0002: return v0