=== CLASS Lcom/samsung/spen/package-info; (Source: package-info.java) ===
  Super: Ljava/lang/Object;