=== CLASS Lcom/samsung/spen/SPenLibraryVersion; (Source: SPenLibraryVersion.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] BUILD: I
  [Instance Field] MAJOR: I
  [Instance Field] MINOR: I
  [Instance Field] RELEASE: Ljava/lang/String;

  [Direct Method] <init>(I, I, I) -> V
    // registers=6, ins=4, outs=2, insns_size=43
    0000: const/16 v1, 46 (0x2e)
    0002: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0005: iput v3, v2.Lcom/samsung/spen/SPenLibraryVersion;->MAJOR:I
    0007: iput v4, v2.Lcom/samsung/spen/SPenLibraryVersion;->MINOR:I
    0009: iput v5, v2.Lcom/samsung/spen/SPenLibraryVersion;->BUILD:I
    000b: new-instance v0, Ljava/lang/StringBuilder;
    000d: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0010: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0013: move-result-object v0
    0014: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    0017: move-result-object v0
    0018: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    001b: move-result-object v0
    001c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    001f: move-result-object v0
    0020: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0023: move-result-object v0
    0024: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0027: move-result-object v0
    0028: iput v0, v2.Lcom/samsung/spen/SPenLibraryVersion;->RELEASE:Ljava/lang/String;
    002a: return-void