=== CLASS Lcom/samsung/spen/SPenEvent; (Source: SPenEvent.java) ===
  Super: Ljava/lang/Object;
  [Static Field] BUTTON_ERASER: I = 1
  [Static Field] BUTTON_NONE: I = 0
  [Static Field] BUTTON_SIDE: I = 2
  [Static Field] META_BUTTON_ERASER: I = 1024
  [Static Field] META_BUTTON_SIDE: I = 2048
  [Static Field] META_PEN_ON: I = 512
  [Instance Field] mMetaState: I
  [Instance Field] mMotionEvent: Landroid/view/MotionEvent;
  [Instance Field] mPressedButtons: I

  [Direct Method] <init>(Landroid/view/MotionEvent;, Z) -> V
    // registers=4, ins=3, outs=1, insns_size=24
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: const/4 v0, 0
    0004: iput v0, v1.Lcom/samsung/spen/SPenEvent;->mPressedButtons:I
    0006: iput v2, v1.Lcom/samsung/spen/SPenEvent;->mMotionEvent:Landroid/view/MotionEvent;
    0008: sget v0, Lcom/samsung/spen/DeviceModel;->IS_SUPPORTED_DEVICE:Z
    000a: if-nez v0, 000e
    000c: if-nez v3, 0017
    000e: invoke-virtual {v2}, Landroid/view/MotionEvent;->getMetaState()I
    0011: move-result v0
    0012: iput v0, v1.Lcom/samsung/spen/SPenEvent;->mMetaState:I
    0014: invoke-direct {v1}, Lcom/samsung/spen/SPenEvent;->setPressedButtons()V
    0017: return-void

  [Direct Method] setPressedButtons() -> V
    // registers=2, ins=1, outs=0, insns_size=25
    0000: iget v0, v1.Lcom/samsung/spen/SPenEvent;->mMetaState:I
    0002: binop/lit16(op=d5) v0, v0, 1024 (0x400)
    0004: if-eqz v0, 000c
    0006: iget v0, v1.Lcom/samsung/spen/SPenEvent;->mPressedButtons:I
    0008: binop/lit8(op=d8) v0, v0, 1 (0x1)
    000a: iput v0, v1.Lcom/samsung/spen/SPenEvent;->mPressedButtons:I
    000c: iget v0, v1.Lcom/samsung/spen/SPenEvent;->mMetaState:I
    000e: binop/lit16(op=d5) v0, v0, 2048 (0x800)
    0010: if-eqz v0, 0018
    0012: iget v0, v1.Lcom/samsung/spen/SPenEvent;->mPressedButtons:I
    0014: binop/lit8(op=d8) v0, v0, 2 (0x2)
    0016: iput v0, v1.Lcom/samsung/spen/SPenEvent;->mPressedButtons:I
    0018: return-void

  [Virtual Method] getPressedButtons() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/samsung/spen/SPenEvent;->mPressedButtons:I
    0002: return v0

  [Virtual Method] getPressure() -> F
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/samsung/spen/SPenEvent;->mMotionEvent:Landroid/view/MotionEvent;
    0002: invoke-virtual {v0}, Landroid/view/MotionEvent;->getPressure()F
    0005: move-result v0
    0006: return v0

  [Virtual Method] getX() -> F
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/samsung/spen/SPenEvent;->mMotionEvent:Landroid/view/MotionEvent;
    0002: invoke-virtual {v0}, Landroid/view/MotionEvent;->getX()F
    0005: move-result v0
    0006: return v0

  [Virtual Method] getY() -> F
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/samsung/spen/SPenEvent;->mMotionEvent:Landroid/view/MotionEvent;
    0002: invoke-virtual {v0}, Landroid/view/MotionEvent;->getY()F
    0005: move-result v0
    0006: return v0

  [Virtual Method] isPen() -> Z
    // registers=2, ins=1, outs=0, insns_size=10
    0000: iget v0, v1.Lcom/samsung/spen/SPenEvent;->mMetaState:I
    0002: binop/lit16(op=d5) v0, v0, 512 (0x200)
    0004: if-eqz v0, 0008
    0006: const/4 v0, 1
    0007: return v0
    0008: const/4 v0, 0
    0009: goto 0007

  [Virtual Method] isPressedButton(I) -> Z
    // registers=3, ins=2, outs=0, insns_size=9
    0000: iget v0, v1.Lcom/samsung/spen/SPenEvent;->mPressedButtons:I
    0002: binop/2addr(op=b5) v0, v2
    0003: if-eqz v0, 0007
    0005: const/4 v0, 1
    0006: return v0
    0007: const/4 v0, 0
    0008: goto 0006