=== CLASS Lcom/samsung/spen/DeviceModel; (Source: DeviceModel.java) ===
  Super: Ljava/lang/Object;
  [Static Field] DEVICE_MODEL: Ljava/lang/String;
  [Static Field] IS_SUPPORTED_DEVICE: Z
  [Static Field] SUPPORTED_MODELS: [Ljava/lang/String;

  [Direct Method] <clinit>() -> V
    // registers=3, ins=0, outs=0, insns_size=31
    0000: sget v0, Landroid/os/Build;->PRODUCT:Ljava/lang/String;
    0002: sput v0, Lcom/samsung/spen/DeviceModel;->DEVICE_MODEL:Ljava/lang/String;
    0004: const/4 v0, 3
    0005: new-array v0, v0, [Ljava/lang/String;
    0007: const/4 v1, 0
    0008: const-string v2, 'GT-I9220'
    000a: aput(op=4d) v2, v0[v1]
    000c: const/4 v1, 1
    000d: const-string v2, 'GT-I9221'
    000f: aput(op=4d) v2, v0[v1]
    0011: const/4 v1, 2
    0012: const-string v2, 'GT-N7000'
    0014: aput(op=4d) v2, v0[v1]
    0016: sput v0, Lcom/samsung/spen/DeviceModel;->SUPPORTED_MODELS:[Ljava/lang/String;
    0018: invoke-static {}, Lcom/samsung/spen/DeviceModel;->checkForSupportedDevice()Z
    001b: move-result v0
    001c: sput v0, Lcom/samsung/spen/DeviceModel;->IS_SUPPORTED_DEVICE:Z
    001e: return-void

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] checkForSupportedDevice() -> Z
    // registers=6, ins=0, outs=2, insns_size=86
    0000: const/4 v0, 0
    0001: const-string v1, 'SPen'
    0003: const-string v2, 'Checking for supported device.'
    0005: invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0008: sget v2, Lcom/samsung/spen/DeviceModel;->SUPPORTED_MODELS:[Ljava/lang/String;
    000a: move(op=21) v3, v2
    000b: move(op=01) v1, v0
    000c: if-lt v1, v3, 002b
    000e: const-string v1, 'SPen'
    0010: new-instance v2, Ljava/lang/StringBuilder;
    0012: const-string v3, "Device '"
    0014: invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0017: sget v3, Lcom/samsung/spen/DeviceModel;->DEVICE_MODEL:Ljava/lang/String;
    0019: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: move-result-object v2
    001d: const-string v3, "' is not supported."
    001f: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0022: move-result-object v2
    0023: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0026: move-result-object v2
    0027: invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    002a: return v0
    002b: aget(op=46) v4, v2[v1]
    002d: sget v5, Lcom/samsung/spen/DeviceModel;->DEVICE_MODEL:Ljava/lang/String;
    002f: invoke-virtual {v4, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z
    0032: move-result v4
    0033: if-eqz v4, 0053
    0035: const-string v0, 'SPen'
    0037: new-instance v1, Ljava/lang/StringBuilder;
    0039: const-string v2, "Device '"
    003b: invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    003e: sget v2, Lcom/samsung/spen/DeviceModel;->DEVICE_MODEL:Ljava/lang/String;
    0040: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0043: move-result-object v1
    0044: const-string v2, "' is supported."
    0046: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0049: move-result-object v1
    004a: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    004d: move-result-object v1
    004e: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0051: const/4 v0, 1
    0052: goto 002a
    0053: binop/lit8(op=d8) v1, v1, 1 (0x1)
    0055: goto 000c