=== CLASS Lcom/google/protobuf/LazyStringList; (Source: LazyStringList.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/util/List;

  [Virtual Method] add(Lcom/google/protobuf/ByteString;) -> V

  [Virtual Method] getByteString(I) -> Lcom/google/protobuf/ByteString;