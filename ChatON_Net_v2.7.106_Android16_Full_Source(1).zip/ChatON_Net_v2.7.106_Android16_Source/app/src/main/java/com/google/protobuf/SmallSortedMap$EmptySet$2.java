=== CLASS Lcom/google/protobuf/SmallSortedMap$EmptySet$2; (Source: SmallSortedMap.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/lang/Iterable;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] iterator() -> Ljava/util/Iterator;
    // registers=2, ins=1, outs=0, insns_size=5
    0000: invoke-static {}, Lcom/google/protobuf/SmallSortedMap$EmptySet;->access$700()Ljava/util/Iterator;
    0003: move-result-object v0
    0004: return-object v0