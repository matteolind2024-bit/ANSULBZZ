=== CLASS Lcom/google/protobuf/CodedInputStream; (Source: CodedInputStream.java) ===
  Super: Ljava/lang/Object;
  [Static Field] BUFFER_SIZE: I = 4096
  [Static Field] DEFAULT_RECURSION_LIMIT: I = 64
  [Static Field] DEFAULT_SIZE_LIMIT: I = 67108864
  [Instance Field] buffer: [B
  [Instance Field] bufferPos: I
  [Instance Field] bufferSize: I
  [Instance Field] bufferSizeAfterLimit: I
  [Instance Field] currentLimit: I
  [Instance Field] input: Ljava/io/InputStream;
  [Instance Field] lastTag: I
  [Instance Field] recursionDepth: I
  [Instance Field] recursionLimit: I
  [Instance Field] sizeLimit: I
  [Instance Field] totalBytesRetired: I

  [Direct Method] <init>(Ljava/io/InputStream;) -> V
    // registers=4, ins=2, outs=1, insns_size=32
    0000: const/4 v1, 0
    0001: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0004: const v0, 2147483647 (0x7fffffff)
    0007: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0009: const/16 v0, 64 (0x40)
    000b: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->recursionLimit:I
    000d: const/high16 v0, 67108864 (0x4000000)
    000f: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->sizeLimit:I
    0011: const/16 v0, 4096 (0x1000)
    0013: new-array v0, v0, [B
    0015: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->buffer:[B
    0017: iput v1, v2.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0019: iput v1, v2.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    001b: iput v1, v2.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    001d: iput v3, v2.Lcom/google/protobuf/CodedInputStream;->input:Ljava/io/InputStream;
    001f: return-void

  [Direct Method] <init>([B, I, I) -> V
    // registers=5, ins=4, outs=1, insns_size=31
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: const v0, 2147483647 (0x7fffffff)
    0006: iput v0, v1.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0008: const/16 v0, 64 (0x40)
    000a: iput v0, v1.Lcom/google/protobuf/CodedInputStream;->recursionLimit:I
    000c: const/high16 v0, 67108864 (0x4000000)
    000e: iput v0, v1.Lcom/google/protobuf/CodedInputStream;->sizeLimit:I
    0010: iput v2, v1.Lcom/google/protobuf/CodedInputStream;->buffer:[B
    0012: binop(op=90) v0, v3, v4
    0014: iput v0, v1.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0016: iput v3, v1.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0018: unop(op=7b) v0, v3
    0019: iput v0, v1.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    001b: const/4 v0, 0
    001c: iput v0, v1.Lcom/google/protobuf/CodedInputStream;->input:Ljava/io/InputStream;
    001e: return-void

  [Direct Method] decodeZigZag32(I) -> I
    // registers=3, ins=1, outs=0, insns_size=7
    0000: binop/lit8(op=e2) v0, v2, 1 (0x1)
    0002: binop/lit8(op=dd) v1, v2, 1 (0x1)
    0004: unop(op=7b) v1, v1
    0005: binop/2addr(op=b7) v0, v1
    0006: return v0

  [Direct Method] decodeZigZag64(J) -> J
    // registers=6, ins=2, outs=0, insns_size=9
    0000: const/4 v0, 1
    0001: binop(op=a5) v0, v4, v0
    0003: const-wide/16 v2, 1
    0005: binop/2addr(op=c0) v2, v4
    0006: unop(op=7d) v2, v2
    0007: binop/2addr(op=c2) v0, v2
    0008: return-wide v0

  [Direct Method] newInstance(Ljava/io/InputStream;) -> Lcom/google/protobuf/CodedInputStream;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Lcom/google/protobuf/CodedInputStream;
    0002: invoke-direct {v0, v1}, Lcom/google/protobuf/CodedInputStream;-><init>(Ljava/io/InputStream;)V
    0005: return-object v0

  [Direct Method] newInstance([B) -> Lcom/google/protobuf/CodedInputStream;
    // registers=3, ins=1, outs=3, insns_size=7
    0000: const/4 v0, 0
    0001: move(op=21) v1, v2
    0002: invoke-static {v2, v0, v1}, Lcom/google/protobuf/CodedInputStream;->newInstance([BII)Lcom/google/protobuf/CodedInputStream;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] newInstance([B, I, I) -> Lcom/google/protobuf/CodedInputStream;
    // registers=5, ins=3, outs=4, insns_size=16
    0000: new-instance v0, Lcom/google/protobuf/CodedInputStream;
    0002: invoke-direct {v0, v2, v3, v4}, Lcom/google/protobuf/CodedInputStream;-><init>([BII)V
    0005: invoke-virtual {v0, v4}, Lcom/google/protobuf/CodedInputStream;->pushLimit(I)I
    0008: return-object v0
    0009: move-exception v0
    000a: new-instance v1, Ljava/lang/IllegalArgumentException;
    000c: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V
    000f: throw v1

  [Direct Method] readRawVarint32(I, Ljava/io/InputStream;) -> I
    // registers=6, ins=2, outs=1, insns_size=62
    0000: const/4 v3, -1
    0001: binop/lit16(op=d5) v0, v4, 128 (0x80)
    0003: if-nez v0, 0006
    0005: return v4
    0006: binop/lit8(op=dd) v4, v4, 127 (0x7f)
    0008: const/4 v0, 7
    0009: const/16 v1, 32 (0x20)
    000b: if-ge v0, v1, 0025
    000d: invoke-virtual {v5}, Ljava/io/InputStream;->read()I
    0010: move-result v1
    0011: if-ne v1, v3, 0018
    0013: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;
    0016: move-result-object v0
    0017: throw v0
    0018: binop/lit8(op=dd) v2, v1, 127 (0x7f)
    001a: binop/2addr(op=b8) v2, v0
    001b: binop/2addr(op=b6) v4, v2
    001c: binop/lit16(op=d5) v1, v1, 128 (0x80)
    001e: if-eqz v1, 0005
    0020: binop/lit8(op=d8) v0, v0, 7 (0x7)
    0022: goto 0009
    0023: binop/lit8(op=d8) v0, v0, 7 (0x7)
    0025: const/16 v1, 64 (0x40)
    0027: if-ge v0, v1, 0039
    0029: invoke-virtual {v5}, Ljava/io/InputStream;->read()I
    002c: move-result v1
    002d: if-ne v1, v3, 0034
    002f: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;
    0032: move-result-object v0
    0033: throw v0
    0034: binop/lit16(op=d5) v1, v1, 128 (0x80)
    0036: if-nez v1, 0023
    0038: goto 0005
    0039: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;
    003c: move-result-object v0
    003d: throw v0

  [Direct Method] readRawVarint32(Ljava/io/InputStream;) -> I
    // registers=3, ins=1, outs=2, insns_size=17
    0000: invoke-virtual {v2}, Ljava/io/InputStream;->read()I
    0003: move-result v0
    0004: const/4 v1, -1
    0005: if-ne v0, v1, 000c
    0007: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;
    000a: move-result-object v0
    000b: throw v0
    000c: invoke-static {v0, v2}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32(ILjava/io/InputStream;)I
    000f: move-result v0
    0010: return v0

  [Direct Method] recomputeBufferSizeAfterLimit() -> V
    // registers=3, ins=1, outs=0, insns_size=33
    0000: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0002: iget v1, v2.Lcom/google/protobuf/CodedInputStream;->bufferSizeAfterLimit:I
    0004: binop/2addr(op=b0) v0, v1
    0005: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0007: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    0009: iget v1, v2.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    000b: binop/2addr(op=b0) v0, v1
    000c: iget v1, v2.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    000e: if-le v0, v1, 001d
    0010: iget v1, v2.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0012: binop/2addr(op=b1) v0, v1
    0013: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->bufferSizeAfterLimit:I
    0015: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0017: iget v1, v2.Lcom/google/protobuf/CodedInputStream;->bufferSizeAfterLimit:I
    0019: binop/2addr(op=b1) v0, v1
    001a: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    001c: return-void
    001d: const/4 v0, 0
    001e: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->bufferSizeAfterLimit:I
    0020: goto 001c

  [Direct Method] refillBuffer(Z) -> Z
    // registers=6, ins=2, outs=2, insns_size=139
    0000: const/4 v1, -1
    0001: const/4 v2, 0
    0002: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0004: iget v3, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0006: if-ge v0, v3, 0010
    0008: new-instance v0, Ljava/lang/IllegalStateException;
    000a: const-string v1, "refillBuffer() called when buffer wasn't empty."
    000c: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000f: throw v0
    0010: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    0012: iget v3, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0014: binop/2addr(op=b0) v0, v3
    0015: iget v3, v4.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0017: if-ne v0, v3, 0022
    0019: if-eqz v5, 0020
    001b: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;
    001e: move-result-object v0
    001f: throw v0
    0020: move(op=01) v0, v2
    0021: return v0
    0022: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    0024: iget v3, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0026: binop/2addr(op=b0) v0, v3
    0027: iput v0, v4.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    0029: iput v2, v4.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    002b: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->input:Ljava/io/InputStream;
    002d: if-nez v0, 005b
    002f: move(op=01) v0, v1
    0030: iput v0, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0032: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0034: if-eqz v0, 003a
    0036: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0038: if-ge v0, v1, 0064
    003a: new-instance v0, Ljava/lang/IllegalStateException;
    003c: new-instance v1, Ljava/lang/StringBuilder;
    003e: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0041: const-string v2, 'InputStream#read(byte[]) returned invalid result: '
    0043: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0046: move-result-object v1
    0047: iget v2, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0049: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    004c: move-result-object v1
    004d: const-string v2, '\nThe InputStream implementation is buggy.'
    004f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0052: move-result-object v1
    0053: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0056: move-result-object v1
    0057: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    005a: throw v0
    005b: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->input:Ljava/io/InputStream;
    005d: iget v3, v4.Lcom/google/protobuf/CodedInputStream;->buffer:[B
    005f: invoke-virtual {v0, v3}, Ljava/io/InputStream;->read([B)I
    0062: move-result v0
    0063: goto 0030
    0064: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0066: if-ne v0, v1, 0073
    0068: iput v2, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    006a: if-eqz v5, 0071
    006c: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;
    006f: move-result-object v0
    0070: throw v0
    0071: move(op=01) v0, v2
    0072: goto 0021
    0073: invoke-direct {v4}, Lcom/google/protobuf/CodedInputStream;->recomputeBufferSizeAfterLimit()V
    0076: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    0078: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    007a: binop/2addr(op=b0) v0, v1
    007b: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->bufferSizeAfterLimit:I
    007d: binop/2addr(op=b0) v0, v1
    007e: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->sizeLimit:I
    0080: if-gt v0, v1, 0084
    0082: if-gez v0, 0089
    0084: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->sizeLimitExceeded()Lcom/google/protobuf/InvalidProtocolBufferException;
    0087: move-result-object v0
    0088: throw v0
    0089: const/4 v0, 1
    008a: goto 0021

  [Virtual Method] checkLastTagWas(I) -> V
    // registers=3, ins=2, outs=0, insns_size=10
    0000: iget v0, v1.Lcom/google/protobuf/CodedInputStream;->lastTag:I
    0002: if-eq v0, v2, 0009
    0004: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidEndTag()Lcom/google/protobuf/InvalidProtocolBufferException;
    0007: move-result-object v0
    0008: throw v0
    0009: return-void

  [Virtual Method] getBytesUntilLimit() -> I
    // registers=3, ins=1, outs=0, insns_size=19
    0000: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0002: const v1, 2147483647 (0x7fffffff)
    0005: if-ne v0, v1, 0009
    0007: const/4 v0, -1
    0008: return v0
    0009: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    000b: iget v1, v2.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    000d: binop/2addr(op=b0) v0, v1
    000e: iget v1, v2.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0010: binop(op=91) v0, v1, v0
    0012: goto 0008

  [Virtual Method] getTotalBytesRead() -> I
    // registers=3, ins=1, outs=0, insns_size=6
    0000: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    0002: iget v1, v2.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0004: binop/2addr(op=b0) v0, v1
    0005: return v0

  [Virtual Method] isAtEnd() -> Z
    // registers=4, ins=1, outs=2, insns_size=15
    0000: const/4 v0, 0
    0001: iget v1, v3.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0003: iget v2, v3.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0005: if-ne v1, v2, 000e
    0007: invoke-direct {v3, v0}, Lcom/google/protobuf/CodedInputStream;->refillBuffer(Z)Z
    000a: move-result v1
    000b: if-nez v1, 000e
    000d: const/4 v0, 1
    000e: return v0

  [Virtual Method] popLimit(I) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0002: invoke-direct {v0}, Lcom/google/protobuf/CodedInputStream;->recomputeBufferSizeAfterLimit()V
    0005: return-void

  [Virtual Method] pushLimit(I) -> I
    // registers=4, ins=2, outs=1, insns_size=28
    0000: if-gez v3, 0007
    0002: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;
    0005: move-result-object v0
    0006: throw v0
    0007: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    0009: iget v1, v2.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    000b: binop/2addr(op=b0) v0, v1
    000c: binop/2addr(op=b0) v0, v3
    000d: iget v1, v2.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    000f: if-le v0, v1, 0016
    0011: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;
    0014: move-result-object v0
    0015: throw v0
    0016: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0018: invoke-direct {v2}, Lcom/google/protobuf/CodedInputStream;->recomputeBufferSizeAfterLimit()V
    001b: return v1

  [Virtual Method] readBool() -> Z
    // registers=2, ins=1, outs=1, insns_size=10
    0000: invoke-virtual {v1}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32()I
    0003: move-result v0
    0004: if-eqz v0, 0008
    0006: const/4 v0, 1
    0007: return v0
    0008: const/4 v0, 0
    0009: goto 0007

  [Virtual Method] readBytes() -> Lcom/google/protobuf/ByteString;
    // registers=4, ins=1, outs=3, insns_size=41
    0000: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32()I
    0003: move-result v1
    0004: if-nez v1, 0009
    0006: sget v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;
    0008: return-object v0
    0009: iget v0, v3.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    000b: iget v2, v3.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    000d: binop/2addr(op=b1) v0, v2
    000e: if-gt v1, v0, 0020
    0010: if-lez v1, 0020
    0012: iget v0, v3.Lcom/google/protobuf/CodedInputStream;->buffer:[B
    0014: iget v2, v3.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0016: invoke-static {v0, v2, v1}, Lcom/google/protobuf/ByteString;->copyFrom([BII)Lcom/google/protobuf/ByteString;
    0019: move-result-object v0
    001a: iget v2, v3.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    001c: binop/2addr(op=b0) v1, v2
    001d: iput v1, v3.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    001f: goto 0008
    0020: invoke-virtual {v3, v1}, Lcom/google/protobuf/CodedInputStream;->readRawBytes(I)[B
    0023: move-result-object v0
    0024: invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFrom([B)Lcom/google/protobuf/ByteString;
    0027: move-result-object v0
    0028: goto 0008

  [Virtual Method] readDouble() -> D
    // registers=3, ins=1, outs=2, insns_size=9
    0000: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readRawLittleEndian64()J
    0003: move-result-wide v0
    0004: invoke-static {v0, v1}, Ljava/lang/Double;->longBitsToDouble(J)D
    0007: move-result-wide v0
    0008: return-wide v0

  [Virtual Method] readEnum() -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32()I
    0003: move-result v0
    0004: return v0

  [Virtual Method] readFixed32() -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/CodedInputStream;->readRawLittleEndian32()I
    0003: move-result v0
    0004: return v0

  [Virtual Method] readFixed64() -> J
    // registers=3, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readRawLittleEndian64()J
    0003: move-result-wide v0
    0004: return-wide v0

  [Virtual Method] readFloat() -> F
    // registers=2, ins=1, outs=1, insns_size=9
    0000: invoke-virtual {v1}, Lcom/google/protobuf/CodedInputStream;->readRawLittleEndian32()I
    0003: move-result v0
    0004: invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F
    0007: move-result v0
    0008: return v0

  [Virtual Method] readGroup(I, Lcom/google/protobuf/MessageLite$Builder;, Lcom/google/protobuf/ExtensionRegistryLite;) -> V
    // registers=6, ins=4, outs=3, insns_size=35
    0000: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->recursionDepth:I
    0002: iget v1, v2.Lcom/google/protobuf/CodedInputStream;->recursionLimit:I
    0004: if-lt v0, v1, 000b
    0006: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->recursionLimitExceeded()Lcom/google/protobuf/InvalidProtocolBufferException;
    0009: move-result-object v0
    000a: throw v0
    000b: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->recursionDepth:I
    000d: binop/lit8(op=d8) v0, v0, 1 (0x1)
    000f: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->recursionDepth:I
    0011: invoke-interface {v4, v2, v5}, Lcom/google/protobuf/MessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;
    0014: const/4 v0, 4
    0015: invoke-static {v3, v0}, Lcom/google/protobuf/WireFormat;->makeTag(II)I
    0018: move-result v0
    0019: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedInputStream;->checkLastTagWas(I)V
    001c: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->recursionDepth:I
    001e: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0020: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->recursionDepth:I
    0022: return-void

  [Virtual Method] readInt32() -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32()I
    0003: move-result v0
    0004: return v0

  [Virtual Method] readInt64() -> J
    // registers=3, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readRawVarint64()J
    0003: move-result-wide v0
    0004: return-wide v0

  [Virtual Method] readMessage(Lcom/google/protobuf/MessageLite$Builder;, Lcom/google/protobuf/ExtensionRegistryLite;) -> V
    // registers=6, ins=3, outs=3, insns_size=42
    0000: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32()I
    0003: move-result v0
    0004: iget v1, v3.Lcom/google/protobuf/CodedInputStream;->recursionDepth:I
    0006: iget v2, v3.Lcom/google/protobuf/CodedInputStream;->recursionLimit:I
    0008: if-lt v1, v2, 000f
    000a: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->recursionLimitExceeded()Lcom/google/protobuf/InvalidProtocolBufferException;
    000d: move-result-object v0
    000e: throw v0
    000f: invoke-virtual {v3, v0}, Lcom/google/protobuf/CodedInputStream;->pushLimit(I)I
    0012: move-result v0
    0013: iget v1, v3.Lcom/google/protobuf/CodedInputStream;->recursionDepth:I
    0015: binop/lit8(op=d8) v1, v1, 1 (0x1)
    0017: iput v1, v3.Lcom/google/protobuf/CodedInputStream;->recursionDepth:I
    0019: invoke-interface {v4, v3, v5}, Lcom/google/protobuf/MessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;
    001c: const/4 v1, 0
    001d: invoke-virtual {v3, v1}, Lcom/google/protobuf/CodedInputStream;->checkLastTagWas(I)V
    0020: iget v1, v3.Lcom/google/protobuf/CodedInputStream;->recursionDepth:I
    0022: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0024: iput v1, v3.Lcom/google/protobuf/CodedInputStream;->recursionDepth:I
    0026: invoke-virtual {v3, v0}, Lcom/google/protobuf/CodedInputStream;->popLimit(I)V
    0029: return-void

  [Virtual Method] readRawByte() -> B
    // registers=4, ins=1, outs=2, insns_size=21
    0000: iget v0, v3.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0002: iget v1, v3.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0004: if-ne v0, v1, 000a
    0006: const/4 v0, 1
    0007: invoke-direct {v3, v0}, Lcom/google/protobuf/CodedInputStream;->refillBuffer(Z)Z
    000a: iget v0, v3.Lcom/google/protobuf/CodedInputStream;->buffer:[B
    000c: iget v1, v3.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    000e: binop/lit8(op=d8) v2, v1, 1 (0x1)
    0010: iput v2, v3.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0012: aget(op=48) v0, v0[v1]
    0014: return v0

  [Virtual Method] readRawBytes(I) -> [B
    // registers=13, ins=2, outs=5, insns_size=230
    0000: const/16 v10, 4096 (0x1000)
    0002: const/4 v5, 1
    0003: const/4 v3, -1
    0004: const/4 v1, 0
    0005: if-gez v12, 000c
    0007: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;
    000a: move-result-object v0
    000b: throw v0
    000c: iget v0, v11.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    000e: iget v2, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0010: binop/2addr(op=b0) v0, v2
    0011: binop/2addr(op=b0) v0, v12
    0012: iget v2, v11.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0014: if-le v0, v2, 0026
    0016: iget v0, v11.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0018: iget v1, v11.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    001a: binop/2addr(op=b1) v0, v1
    001b: iget v1, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    001d: binop/2addr(op=b1) v0, v1
    001e: invoke-virtual {v11, v0}, Lcom/google/protobuf/CodedInputStream;->skipRawBytes(I)V
    0021: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;
    0024: move-result-object v0
    0025: throw v0
    0026: iget v0, v11.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0028: iget v2, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    002a: binop/2addr(op=b1) v0, v2
    002b: if-gt v12, v0, 003c
    002d: new-array v0, v12, [B
    002f: iget v2, v11.Lcom/google/protobuf/CodedInputStream;->buffer:[B
    0031: iget v3, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0033: invoke-static {v2, v3, v0, v1, v12}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0036: iget v1, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0038: binop/2addr(op=b0) v1, v12
    0039: iput v1, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    003b: return-object v0
    003c: if-ge v12, v10, 0078
    003e: new-array v2, v12, [B
    0040: iget v0, v11.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0042: iget v3, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0044: binop/2addr(op=b1) v0, v3
    0045: iget v3, v11.Lcom/google/protobuf/CodedInputStream;->buffer:[B
    0047: iget v4, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0049: invoke-static {v3, v4, v2, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    004c: iget v3, v11.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    004e: iput v3, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0050: invoke-direct {v11, v5}, Lcom/google/protobuf/CodedInputStream;->refillBuffer(Z)Z
    0053: binop(op=91) v3, v12, v0
    0055: iget v4, v11.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0057: if-le v3, v4, 006b
    0059: iget v3, v11.Lcom/google/protobuf/CodedInputStream;->buffer:[B
    005b: iget v4, v11.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    005d: invoke-static {v3, v1, v2, v0, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0060: iget v3, v11.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0062: binop/2addr(op=b0) v0, v3
    0063: iget v3, v11.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0065: iput v3, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0067: invoke-direct {v11, v5}, Lcom/google/protobuf/CodedInputStream;->refillBuffer(Z)Z
    006a: goto 0053
    006b: iget v3, v11.Lcom/google/protobuf/CodedInputStream;->buffer:[B
    006d: binop(op=91) v4, v12, v0
    006f: invoke-static {v3, v1, v2, v0, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0072: binop(op=91) v0, v12, v0
    0074: iput v0, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0076: move(op=07) v0, v2
    0077: goto 003b
    0078: iget v5, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    007a: iget v6, v11.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    007c: iget v0, v11.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    007e: iget v2, v11.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0080: binop/2addr(op=b0) v0, v2
    0081: iput v0, v11.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    0083: iput v1, v11.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0085: iput v1, v11.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0087: binop(op=91) v0, v6, v5
    0089: binop(op=91) v0, v12, v0
    008b: new-instance v7, Ljava/util/ArrayList;
    008d: invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V
    0090: move(op=01) v4, v0
    0091: if-lez v4, 00c1
    0093: invoke-static {v4, v10}, Ljava/lang/Math;->min(II)I
    0096: move-result v0
    0097: new-array v8, v0, [B
    0099: move(op=01) v0, v1
    009a: move(op=21) v2, v8
    009b: if-ge v0, v2, 00b9
    009d: iget v2, v11.Lcom/google/protobuf/CodedInputStream;->input:Ljava/io/InputStream;
    009f: if-nez v2, 00a9
    00a1: move(op=01) v2, v3
    00a2: if-ne v2, v3, 00b2
    00a4: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;
    00a7: move-result-object v0
    00a8: throw v0
    00a9: iget v2, v11.Lcom/google/protobuf/CodedInputStream;->input:Ljava/io/InputStream;
    00ab: move(op=21) v9, v8
    00ac: binop/2addr(op=b1) v9, v0
    00ad: invoke-virtual {v2, v8, v0, v9}, Ljava/io/InputStream;->read([BII)I
    00b0: move-result v2
    00b1: goto 00a2
    00b2: iget v9, v11.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    00b4: binop/2addr(op=b0) v9, v2
    00b5: iput v9, v11.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    00b7: binop/2addr(op=b0) v0, v2
    00b8: goto 009a
    00b9: move(op=21) v0, v8
    00ba: binop(op=91) v0, v4, v0
    00bc: invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    00bf: move(op=01) v4, v0
    00c0: goto 0091
    00c1: new-array v3, v12, [B
    00c3: binop(op=91) v0, v6, v5
    00c5: iget v2, v11.Lcom/google/protobuf/CodedInputStream;->buffer:[B
    00c7: invoke-static {v2, v5, v3, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    00ca: invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    00cd: move-result-object v4
    00ce: move(op=01) v2, v0
    00cf: invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z
    00d2: move-result v0
    00d3: if-eqz v0, 00e3
    00d5: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    00d8: move-result-object v0
    00d9: check-cast v0, [B
    00db: move(op=21) v5, v0
    00dc: invoke-static {v0, v1, v3, v2, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    00df: move(op=21) v0, v0
    00e0: binop/2addr(op=b0) v0, v2
    00e1: move(op=01) v2, v0
    00e2: goto 00cf
    00e3: move(op=07) v0, v3
    00e4: goto/16 003b

  [Virtual Method] readRawLittleEndian32() -> I
    // registers=5, ins=1, outs=1, insns_size=34
    0000: invoke-virtual {v4}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    0003: move-result v0
    0004: invoke-virtual {v4}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    0007: move-result v1
    0008: invoke-virtual {v4}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    000b: move-result v2
    000c: invoke-virtual {v4}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    000f: move-result v3
    0010: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0012: binop/lit16(op=d5) v1, v1, 255 (0xff)
    0014: binop/lit8(op=e0) v1, v1, 8 (0x8)
    0016: binop/2addr(op=b6) v0, v1
    0017: binop/lit16(op=d5) v1, v2, 255 (0xff)
    0019: binop/lit8(op=e0) v1, v1, 16 (0x10)
    001b: binop/2addr(op=b6) v0, v1
    001c: binop/lit16(op=d5) v1, v3, 255 (0xff)
    001e: binop/lit8(op=e0) v1, v1, 24 (0x18)
    0020: binop/2addr(op=b6) v0, v1
    0021: return v0

  [Virtual Method] readRawLittleEndian64() -> J
    // registers=14, ins=1, outs=1, insns_size=79
    0000: const-wide/16 v11, 255
    0002: invoke-virtual {v13}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    0005: move-result v0
    0006: invoke-virtual {v13}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    0009: move-result v1
    000a: invoke-virtual {v13}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    000d: move-result v2
    000e: invoke-virtual {v13}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    0011: move-result v3
    0012: invoke-virtual {v13}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    0015: move-result v4
    0016: invoke-virtual {v13}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    0019: move-result v5
    001a: invoke-virtual {v13}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    001d: move-result v6
    001e: invoke-virtual {v13}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    0021: move-result v7
    0022: unop(op=81) v8, v0
    0023: binop/2addr(op=c0) v8, v11
    0024: unop(op=81) v0, v1
    0025: binop/2addr(op=c0) v0, v11
    0026: const/16 v10, 8 (0x8)
    0028: binop/2addr(op=c3) v0, v10
    0029: binop/2addr(op=c1) v0, v8
    002a: unop(op=81) v8, v2
    002b: binop/2addr(op=c0) v8, v11
    002c: const/16 v2, 16 (0x10)
    002e: binop/2addr(op=c3) v8, v2
    002f: binop/2addr(op=c1) v0, v8
    0030: unop(op=81) v2, v3
    0031: binop/2addr(op=c0) v2, v11
    0032: const/16 v8, 24 (0x18)
    0034: binop/2addr(op=c3) v2, v8
    0035: binop/2addr(op=c1) v0, v2
    0036: unop(op=81) v2, v4
    0037: binop/2addr(op=c0) v2, v11
    0038: const/16 v4, 32 (0x20)
    003a: binop/2addr(op=c3) v2, v4
    003b: binop/2addr(op=c1) v0, v2
    003c: unop(op=81) v2, v5
    003d: binop/2addr(op=c0) v2, v11
    003e: const/16 v4, 40 (0x28)
    0040: binop/2addr(op=c3) v2, v4
    0041: binop/2addr(op=c1) v0, v2
    0042: unop(op=81) v2, v6
    0043: binop/2addr(op=c0) v2, v11
    0044: const/16 v4, 48 (0x30)
    0046: binop/2addr(op=c3) v2, v4
    0047: binop/2addr(op=c1) v0, v2
    0048: unop(op=81) v2, v7
    0049: binop/2addr(op=c0) v2, v11
    004a: const/16 v4, 56 (0x38)
    004c: binop/2addr(op=c3) v2, v4
    004d: binop/2addr(op=c1) v0, v2
    004e: return-wide v0

  [Virtual Method] readRawVarint32() -> I
    // registers=4, ins=1, outs=1, insns_size=81
    0000: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    0003: move-result v0
    0004: if-ltz v0, 0007
    0006: return v0
    0007: binop/lit8(op=dd) v0, v0, 127 (0x7f)
    0009: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    000c: move-result v1
    000d: if-ltz v1, 0013
    000f: binop/lit8(op=e0) v1, v1, 7 (0x7)
    0011: binop/2addr(op=b6) v0, v1
    0012: goto 0006
    0013: binop/lit8(op=dd) v1, v1, 127 (0x7f)
    0015: binop/lit8(op=e0) v1, v1, 7 (0x7)
    0017: binop/2addr(op=b6) v0, v1
    0018: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    001b: move-result v1
    001c: if-ltz v1, 0022
    001e: binop/lit8(op=e0) v1, v1, 14 (0xe)
    0020: binop/2addr(op=b6) v0, v1
    0021: goto 0006
    0022: binop/lit8(op=dd) v1, v1, 127 (0x7f)
    0024: binop/lit8(op=e0) v1, v1, 14 (0xe)
    0026: binop/2addr(op=b6) v0, v1
    0027: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    002a: move-result v1
    002b: if-ltz v1, 0031
    002d: binop/lit8(op=e0) v1, v1, 21 (0x15)
    002f: binop/2addr(op=b6) v0, v1
    0030: goto 0006
    0031: binop/lit8(op=dd) v1, v1, 127 (0x7f)
    0033: binop/lit8(op=e0) v1, v1, 21 (0x15)
    0035: binop/2addr(op=b6) v0, v1
    0036: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    0039: move-result v1
    003a: binop/lit8(op=e0) v2, v1, 28 (0x1c)
    003c: binop/2addr(op=b6) v0, v2
    003d: if-gez v1, 0006
    003f: const/4 v1, 0
    0040: const/4 v2, 5
    0041: if-ge v1, v2, 004c
    0043: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    0046: move-result v2
    0047: if-gez v2, 0006
    0049: binop/lit8(op=d8) v1, v1, 1 (0x1)
    004b: goto 0040
    004c: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;
    004f: move-result-object v0
    0050: throw v0

  [Virtual Method] readRawVarint64() -> J
    // registers=7, ins=1, outs=1, insns_size=29
    0000: const/4 v2, 0
    0001: const-wide/16 v0, 0
    0003: const/16 v3, 64 (0x40)
    0005: if-ge v2, v3, 0018
    0007: invoke-virtual {v6}, Lcom/google/protobuf/CodedInputStream;->readRawByte()B
    000a: move-result v3
    000b: binop/lit8(op=dd) v4, v3, 127 (0x7f)
    000d: unop(op=81) v4, v4
    000e: binop/2addr(op=c3) v4, v2
    000f: binop/2addr(op=c1) v0, v4
    0010: binop/lit16(op=d5) v3, v3, 128 (0x80)
    0012: if-nez v3, 0015
    0014: return-wide v0
    0015: binop/lit8(op=d8) v2, v2, 7 (0x7)
    0017: goto 0003
    0018: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;
    001b: move-result-object v0
    001c: throw v0

  [Virtual Method] readSFixed32() -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/CodedInputStream;->readRawLittleEndian32()I
    0003: move-result v0
    0004: return v0

  [Virtual Method] readSFixed64() -> J
    // registers=3, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readRawLittleEndian64()J
    0003: move-result-wide v0
    0004: return-wide v0

  [Virtual Method] readSInt32() -> I
    // registers=2, ins=1, outs=1, insns_size=9
    0000: invoke-virtual {v1}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32()I
    0003: move-result v0
    0004: invoke-static {v0}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I
    0007: move-result v0
    0008: return v0

  [Virtual Method] readSInt64() -> J
    // registers=3, ins=1, outs=2, insns_size=9
    0000: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readRawVarint64()J
    0003: move-result-wide v0
    0004: invoke-static {v0, v1}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J
    0007: move-result-wide v0
    0008: return-wide v0

  [Virtual Method] readString() -> Ljava/lang/String;
    // registers=6, ins=1, outs=5, insns_size=42
    0000: invoke-virtual {v5}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32()I
    0003: move-result v1
    0004: iget v0, v5.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0006: iget v2, v5.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0008: binop/2addr(op=b1) v0, v2
    0009: if-gt v1, v0, 001e
    000b: if-lez v1, 001e
    000d: new-instance v0, Ljava/lang/String;
    000f: iget v2, v5.Lcom/google/protobuf/CodedInputStream;->buffer:[B
    0011: iget v3, v5.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0013: const-string v4, 'UTF-8'
    0015: invoke-direct {v0, v2, v3, v1, v4}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V
    0018: iget v2, v5.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    001a: binop/2addr(op=b0) v1, v2
    001b: iput v1, v5.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    001d: return-object v0
    001e: new-instance v0, Ljava/lang/String;
    0020: invoke-virtual {v5, v1}, Lcom/google/protobuf/CodedInputStream;->readRawBytes(I)[B
    0023: move-result-object v1
    0024: const-string v2, 'UTF-8'
    0026: invoke-direct {v0, v1, v2}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    0029: goto 001d

  [Virtual Method] readTag() -> I
    // registers=3, ins=1, outs=1, insns_size=32
    0000: const/4 v0, 0
    0001: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->isAtEnd()Z
    0004: move-result v1
    0005: if-eqz v1, 000a
    0007: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->lastTag:I
    0009: return v0
    000a: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32()I
    000d: move-result v0
    000e: iput v0, v2.Lcom/google/protobuf/CodedInputStream;->lastTag:I
    0010: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->lastTag:I
    0012: invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I
    0015: move-result v0
    0016: if-nez v0, 001d
    0018: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidTag()Lcom/google/protobuf/InvalidProtocolBufferException;
    001b: move-result-object v0
    001c: throw v0
    001d: iget v0, v2.Lcom/google/protobuf/CodedInputStream;->lastTag:I
    001f: goto 0009

  [Virtual Method] readUInt32() -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32()I
    0003: move-result v0
    0004: return v0

  [Virtual Method] readUInt64() -> J
    // registers=3, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readRawVarint64()J
    0003: move-result-wide v0
    0004: return-wide v0

  [Virtual Method] readUnknownGroup(I, Lcom/google/protobuf/MessageLite$Builder;) -> V
    // registers=4, ins=3, outs=4, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v3, v0}, Lcom/google/protobuf/CodedInputStream;->readGroup(ILcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    0004: return-void

  [Virtual Method] resetSizeCounter() -> V
    // registers=2, ins=1, outs=0, insns_size=6
    0000: iget v0, v1.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0002: unop(op=7b) v0, v0
    0003: iput v0, v1.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    0005: return-void

  [Virtual Method] setRecursionLimit(I) -> I
    // registers=5, ins=2, outs=2, insns_size=32
    0000: if-gez v4, 001b
    0002: new-instance v0, Ljava/lang/IllegalArgumentException;
    0004: new-instance v1, Ljava/lang/StringBuilder;
    0006: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0009: const-string v2, 'Recursion limit cannot be negative: '
    000b: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000e: move-result-object v1
    000f: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0016: move-result-object v1
    0017: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    001a: throw v0
    001b: iget v0, v3.Lcom/google/protobuf/CodedInputStream;->recursionLimit:I
    001d: iput v4, v3.Lcom/google/protobuf/CodedInputStream;->recursionLimit:I
    001f: return v0

  [Virtual Method] setSizeLimit(I) -> I
    // registers=5, ins=2, outs=2, insns_size=32
    0000: if-gez v4, 001b
    0002: new-instance v0, Ljava/lang/IllegalArgumentException;
    0004: new-instance v1, Ljava/lang/StringBuilder;
    0006: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0009: const-string v2, 'Size limit cannot be negative: '
    000b: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000e: move-result-object v1
    000f: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0016: move-result-object v1
    0017: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    001a: throw v0
    001b: iget v0, v3.Lcom/google/protobuf/CodedInputStream;->sizeLimit:I
    001d: iput v4, v3.Lcom/google/protobuf/CodedInputStream;->sizeLimit:I
    001f: return v0

  [Virtual Method] skipField(I) -> Z
    // registers=5, ins=2, outs=2, insns_size=68
    0000: const/4 v0, 1
    0001: invoke-static {v4}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I
    0004: move-result v1
    0005: packed-switch v1, +47 (-> 0034)
    0008: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException;
    000b: move-result-object v0
    000c: throw v0
    000d: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readInt32()I
    0010: return v0
    0011: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readRawLittleEndian64()J
    0014: goto 0010
    0015: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32()I
    0018: move-result v1
    0019: invoke-virtual {v3, v1}, Lcom/google/protobuf/CodedInputStream;->skipRawBytes(I)V
    001c: goto 0010
    001d: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->skipMessage()V
    0020: invoke-static {v4}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I
    0023: move-result v1
    0024: const/4 v2, 4
    0025: invoke-static {v1, v2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I
    0028: move-result v1
    0029: invoke-virtual {v3, v1}, Lcom/google/protobuf/CodedInputStream;->checkLastTagWas(I)V
    002c: goto 0010
    002d: const/4 v0, 0
    002e: goto 0010
    002f: invoke-virtual {v3}, Lcom/google/protobuf/CodedInputStream;->readRawLittleEndian32()I
    0032: goto 0010
    0033: nop
    0034: packed-switch-payload first=0 targets=[8, 12, 16, 24, 40, 42]

  [Virtual Method] skipMessage() -> V
    // registers=2, ins=1, outs=2, insns_size=13
    0000: invoke-virtual {v1}, Lcom/google/protobuf/CodedInputStream;->readTag()I
    0003: move-result v0
    0004: if-eqz v0, 000c
    0006: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedInputStream;->skipField(I)Z
    0009: move-result v0
    000a: if-nez v0, 0000
    000c: return-void

  [Virtual Method] skipRawBytes(I) -> V
    // registers=6, ins=2, outs=2, insns_size=81
    0000: const/4 v3, 1
    0001: if-gez v5, 0008
    0003: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;
    0006: move-result-object v0
    0007: throw v0
    0008: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    000a: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    000c: binop/2addr(op=b0) v0, v1
    000d: binop/2addr(op=b0) v0, v5
    000e: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0010: if-le v0, v1, 0022
    0012: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->currentLimit:I
    0014: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->totalBytesRetired:I
    0016: binop/2addr(op=b1) v0, v1
    0017: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0019: binop/2addr(op=b1) v0, v1
    001a: invoke-virtual {v4, v0}, Lcom/google/protobuf/CodedInputStream;->skipRawBytes(I)V
    001d: invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;
    0020: move-result-object v0
    0021: throw v0
    0022: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0024: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0026: binop/2addr(op=b1) v0, v1
    0027: if-gt v5, v0, 002f
    0029: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    002b: binop/2addr(op=b0) v0, v5
    002c: iput v0, v4.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    002e: return-void
    002f: iget v0, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0031: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0033: binop/2addr(op=b1) v0, v1
    0034: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0036: iput v1, v4.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0038: invoke-direct {v4, v3}, Lcom/google/protobuf/CodedInputStream;->refillBuffer(Z)Z
    003b: binop(op=91) v1, v5, v0
    003d: iget v2, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    003f: if-le v1, v2, 004c
    0041: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0043: binop/2addr(op=b0) v0, v1
    0044: iget v1, v4.Lcom/google/protobuf/CodedInputStream;->bufferSize:I
    0046: iput v1, v4.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0048: invoke-direct {v4, v3}, Lcom/google/protobuf/CodedInputStream;->refillBuffer(Z)Z
    004b: goto 003b
    004c: binop(op=91) v0, v5, v0
    004e: iput v0, v4.Lcom/google/protobuf/CodedInputStream;->bufferPos:I
    0050: goto 002e