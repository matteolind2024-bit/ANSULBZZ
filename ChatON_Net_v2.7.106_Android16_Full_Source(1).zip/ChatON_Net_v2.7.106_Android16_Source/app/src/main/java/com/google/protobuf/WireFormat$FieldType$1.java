=== CLASS Lcom/google/protobuf/WireFormat$FieldType$1; (Source: WireFormat.java) ===
  Super: Lcom/google/protobuf/WireFormat$FieldType;

  [Direct Method] <init>(Ljava/lang/String;, I, Lcom/google/protobuf/WireFormat$JavaType;, I) -> V
    // registers=11, ins=5, outs=6, insns_size=10
    0000: const/4 v5, 0
    0001: move(op=07) v0, v6
    0002: move(op=07) v1, v7
    0003: move(op=01) v2, v8
    0004: move(op=07) v3, v9
    0005: move(op=01) v4, v10
    0006: invoke-direct/range {v0..v5}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;ILcom/google/protobuf/WireFormat$1;)V
    0009: return-void

  [Virtual Method] isPackable() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0