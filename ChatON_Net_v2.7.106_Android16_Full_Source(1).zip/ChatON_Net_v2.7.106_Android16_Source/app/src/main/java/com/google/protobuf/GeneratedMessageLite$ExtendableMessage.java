=== CLASS Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage; (Source: GeneratedMessageLite.java) ===
  Super: Lcom/google/protobuf/GeneratedMessageLite;
  Interfaces: Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessageOrBuilder;
  [Instance Field] extensions: Lcom/google/protobuf/FieldSet;

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=10
    0000: invoke-direct {v1}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V
    0003: invoke-static {}, Lcom/google/protobuf/FieldSet;->newFieldSet()Lcom/google/protobuf/FieldSet;
    0006: move-result-object v0
    0007: iput v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->extensions:Lcom/google/protobuf/FieldSet;
    0009: return-void

  [Direct Method] <init>(Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;) -> V
    // registers=3, ins=2, outs=1, insns_size=10
    0000: invoke-direct {v1}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V
    0003: invoke-static {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->access$000(Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;)Lcom/google/protobuf/FieldSet;
    0006: move-result-object v0
    0007: iput v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->extensions:Lcom/google/protobuf/FieldSet;
    0009: return-void

  [Direct Method] access$300(Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;) -> Lcom/google/protobuf/FieldSet;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->extensions:Lcom/google/protobuf/FieldSet;
    0002: return-object v0

  [Direct Method] verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> V
    // registers=4, ins=2, outs=2, insns_size=19
    0000: invoke-virtual {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->getContainingTypeDefaultInstance()Lcom/google/protobuf/MessageLite;
    0003: move-result-object v0
    0004: invoke-virtual {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    0007: move-result-object v1
    0008: if-eq v0, v1, 0012
    000a: new-instance v0, Ljava/lang/IllegalArgumentException;
    000c: const-string v1, 'This extension is for a different message type.  Please make sure that you are not suppressing any generics type warnings.'
    000e: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0011: throw v0
    0012: return-void

  [Virtual Method] extensionsAreInitialized() -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->extensions:Lcom/google/protobuf/FieldSet;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/FieldSet;->isInitialized()Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] extensionsSerializedSize() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->extensions:Lcom/google/protobuf/FieldSet;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/FieldSet;->getSerializedSize()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] extensionsSerializedSizeAsMessageSet() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->extensions:Lcom/google/protobuf/FieldSet;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/FieldSet;->getMessageSetSerializedSize()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] getExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> Ljava/lang/Object;
    // registers=4, ins=2, outs=2, insns_size=20
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->extensions:Lcom/google/protobuf/FieldSet;
    0005: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0008: move-result-object v1
    0009: invoke-virtual {v0, v1}, Lcom/google/protobuf/FieldSet;->getField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;
    000c: move-result-object v0
    000d: if-nez v0, 0013
    000f: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$200(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Ljava/lang/Object;
    0012: move-result-object v0
    0013: return-object v0

  [Virtual Method] getExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;, I) -> Ljava/lang/Object;
    // registers=5, ins=3, outs=3, insns_size=14
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->extensions:Lcom/google/protobuf/FieldSet;
    0005: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0008: move-result-object v1
    0009: invoke-virtual {v0, v1, v4}, Lcom/google/protobuf/FieldSet;->getRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;I)Ljava/lang/Object;
    000c: move-result-object v0
    000d: return-object v0

  [Virtual Method] getExtensionCount(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> I
    // registers=4, ins=2, outs=2, insns_size=14
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->extensions:Lcom/google/protobuf/FieldSet;
    0005: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0008: move-result-object v1
    0009: invoke-virtual {v0, v1}, Lcom/google/protobuf/FieldSet;->getRepeatedFieldCount(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)I
    000c: move-result v0
    000d: return v0

  [Virtual Method] hasExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> Z
    // registers=4, ins=2, outs=2, insns_size=14
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->extensions:Lcom/google/protobuf/FieldSet;
    0005: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0008: move-result-object v1
    0009: invoke-virtual {v0, v1}, Lcom/google/protobuf/FieldSet;->hasField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Z
    000c: move-result v0
    000d: return v0

  [Virtual Method] newExtensionWriter() -> Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;
    // registers=4, ins=1, outs=4, insns_size=8
    0000: new-instance v0, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;
    0002: const/4 v1, 0
    0003: const/4 v2, 0
    0004: invoke-direct {v0, v3, v1, v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;-><init>(Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;ZLcom/google/protobuf/GeneratedMessageLite$1;)V
    0007: return-object v0

  [Virtual Method] newMessageSetExtensionWriter() -> Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;
    // registers=4, ins=1, outs=4, insns_size=8
    0000: new-instance v0, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;
    0002: const/4 v1, 1
    0003: const/4 v2, 0
    0004: invoke-direct {v0, v3, v1, v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;-><init>(Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;ZLcom/google/protobuf/GeneratedMessageLite$1;)V
    0007: return-object v0