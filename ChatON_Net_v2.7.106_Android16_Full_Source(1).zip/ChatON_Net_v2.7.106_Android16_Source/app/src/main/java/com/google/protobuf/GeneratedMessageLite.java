=== CLASS Lcom/google/protobuf/GeneratedMessageLite; (Source: GeneratedMessageLite.java) ===
  Super: Lcom/google/protobuf/AbstractMessageLite;
  Interfaces: Ljava/io/Serializable;
  [Static Field] serialVersionUID: J = 1

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/google/protobuf/AbstractMessageLite;-><init>()V
    0003: return-void

  [Direct Method] <init>(Lcom/google/protobuf/GeneratedMessageLite$Builder;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/google/protobuf/AbstractMessageLite;-><init>()V
    0003: return-void

  [Direct Method] newRepeatedGeneratedExtension(Lcom/google/protobuf/MessageLite;, Lcom/google/protobuf/MessageLite;, Lcom/google/protobuf/Internal$EnumLiteMap;, I, Lcom/google/protobuf/WireFormat$FieldType;, Z) -> Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;
    // registers=15, ins=6, outs=7, insns_size=26
    0000: const/4 v6, 0
    0001: invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;
    0004: move-result-object v7
    0005: new-instance v8, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;
    0007: new-instance v0, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0009: const/4 v4, 1
    000a: move(op=07) v1, v11
    000b: move(op=01) v2, v12
    000c: move(op=07) v3, v13
    000d: move(op=01) v5, v14
    000e: invoke-direct/range {v0..v6}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;-><init>(Lcom/google/protobuf/Internal$EnumLiteMap;ILcom/google/protobuf/WireFormat$FieldType;ZZLcom/google/protobuf/GeneratedMessageLite$1;)V
    0011: move(op=07) v1, v8
    0012: move(op=07) v2, v9
    0013: move(op=07) v3, v7
    0014: move(op=07) v4, v10
    0015: move(op=07) v5, v0
    0016: invoke-direct/range {v1..v6}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;-><init>(Lcom/google/protobuf/MessageLite;Ljava/lang/Object;Lcom/google/protobuf/MessageLite;Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;Lcom/google/protobuf/GeneratedMessageLite$1;)V
    0019: return-object v8

  [Direct Method] newSingularGeneratedExtension(Lcom/google/protobuf/MessageLite;, Ljava/lang/Object;, Lcom/google/protobuf/MessageLite;, Lcom/google/protobuf/Internal$EnumLiteMap;, I, Lcom/google/protobuf/WireFormat$FieldType;) -> Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;
    // registers=14, ins=6, outs=7, insns_size=22
    0000: const/4 v6, 0
    0001: const/4 v4, 0
    0002: new-instance v7, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;
    0004: new-instance v0, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0006: move(op=07) v1, v11
    0007: move(op=01) v2, v12
    0008: move(op=07) v3, v13
    0009: move(op=01) v5, v4
    000a: invoke-direct/range {v0..v6}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;-><init>(Lcom/google/protobuf/Internal$EnumLiteMap;ILcom/google/protobuf/WireFormat$FieldType;ZZLcom/google/protobuf/GeneratedMessageLite$1;)V
    000d: move(op=07) v1, v7
    000e: move(op=07) v2, v8
    000f: move(op=07) v3, v9
    0010: move(op=07) v4, v10
    0011: move(op=07) v5, v0
    0012: invoke-direct/range {v1..v6}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;-><init>(Lcom/google/protobuf/MessageLite;Ljava/lang/Object;Lcom/google/protobuf/MessageLite;Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;Lcom/google/protobuf/GeneratedMessageLite$1;)V
    0015: return-object v7

  [Virtual Method] writeReplace() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Lcom/google/protobuf/GeneratedMessageLite$SerializedForm;
    0002: invoke-direct {v0, v1}, Lcom/google/protobuf/GeneratedMessageLite$SerializedForm;-><init>(Lcom/google/protobuf/MessageLite;)V
    0005: return-object v0