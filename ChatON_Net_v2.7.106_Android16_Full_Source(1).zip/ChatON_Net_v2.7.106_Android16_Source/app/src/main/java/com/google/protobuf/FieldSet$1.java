=== CLASS Lcom/google/protobuf/FieldSet$1; (Source: FieldSet.java) ===
  Super: Ljava/lang/Object;
  [Static Field] $SwitchMap$com$google$protobuf$WireFormat$FieldType: [I
  [Static Field] $SwitchMap$com$google$protobuf$WireFormat$JavaType: [I

  [Direct Method] <clinit>() -> V
    // registers=3, ins=0, outs=1, insns_size=401
    0000: invoke-static {}, Lcom/google/protobuf/WireFormat$FieldType;->values()[Lcom/google/protobuf/WireFormat$FieldType;
    0003: move-result-object v0
    0004: move(op=21) v0, v0
    0005: new-array v0, v0, [I
    0007: sput v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0009: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    000b: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->DOUBLE:Lcom/google/protobuf/WireFormat$FieldType;
    000d: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0010: move-result v1
    0011: const/4 v2, 1
    0012: aput(op=4b) v2, v0[v1]
    0014: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0016: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->FLOAT:Lcom/google/protobuf/WireFormat$FieldType;
    0018: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    001b: move-result v1
    001c: const/4 v2, 2
    001d: aput(op=4b) v2, v0[v1]
    001f: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0021: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->INT64:Lcom/google/protobuf/WireFormat$FieldType;
    0023: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0026: move-result v1
    0027: const/4 v2, 3
    0028: aput(op=4b) v2, v0[v1]
    002a: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    002c: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->UINT64:Lcom/google/protobuf/WireFormat$FieldType;
    002e: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0031: move-result v1
    0032: const/4 v2, 4
    0033: aput(op=4b) v2, v0[v1]
    0035: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0037: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->INT32:Lcom/google/protobuf/WireFormat$FieldType;
    0039: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    003c: move-result v1
    003d: const/4 v2, 5
    003e: aput(op=4b) v2, v0[v1]
    0040: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0042: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->FIXED64:Lcom/google/protobuf/WireFormat$FieldType;
    0044: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0047: move-result v1
    0048: const/4 v2, 6
    0049: aput(op=4b) v2, v0[v1]
    004b: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    004d: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->FIXED32:Lcom/google/protobuf/WireFormat$FieldType;
    004f: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0052: move-result v1
    0053: const/4 v2, 7
    0054: aput(op=4b) v2, v0[v1]
    0056: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0058: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->BOOL:Lcom/google/protobuf/WireFormat$FieldType;
    005a: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    005d: move-result v1
    005e: const/16 v2, 8 (0x8)
    0060: aput(op=4b) v2, v0[v1]
    0062: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0064: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->STRING:Lcom/google/protobuf/WireFormat$FieldType;
    0066: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0069: move-result v1
    006a: const/16 v2, 9 (0x9)
    006c: aput(op=4b) v2, v0[v1]
    006e: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0070: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->BYTES:Lcom/google/protobuf/WireFormat$FieldType;
    0072: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0075: move-result v1
    0076: const/16 v2, 10 (0xa)
    0078: aput(op=4b) v2, v0[v1]
    007a: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    007c: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->UINT32:Lcom/google/protobuf/WireFormat$FieldType;
    007e: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0081: move-result v1
    0082: const/16 v2, 11 (0xb)
    0084: aput(op=4b) v2, v0[v1]
    0086: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0088: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->SFIXED32:Lcom/google/protobuf/WireFormat$FieldType;
    008a: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    008d: move-result v1
    008e: const/16 v2, 12 (0xc)
    0090: aput(op=4b) v2, v0[v1]
    0092: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0094: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->SFIXED64:Lcom/google/protobuf/WireFormat$FieldType;
    0096: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0099: move-result v1
    009a: const/16 v2, 13 (0xd)
    009c: aput(op=4b) v2, v0[v1]
    009e: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    00a0: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->SINT32:Lcom/google/protobuf/WireFormat$FieldType;
    00a2: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    00a5: move-result v1
    00a6: const/16 v2, 14 (0xe)
    00a8: aput(op=4b) v2, v0[v1]
    00aa: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    00ac: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->SINT64:Lcom/google/protobuf/WireFormat$FieldType;
    00ae: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    00b1: move-result v1
    00b2: const/16 v2, 15 (0xf)
    00b4: aput(op=4b) v2, v0[v1]
    00b6: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    00b8: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->GROUP:Lcom/google/protobuf/WireFormat$FieldType;
    00ba: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    00bd: move-result v1
    00be: const/16 v2, 16 (0x10)
    00c0: aput(op=4b) v2, v0[v1]
    00c2: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    00c4: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->MESSAGE:Lcom/google/protobuf/WireFormat$FieldType;
    00c6: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    00c9: move-result v1
    00ca: const/16 v2, 17 (0x11)
    00cc: aput(op=4b) v2, v0[v1]
    00ce: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    00d0: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->ENUM:Lcom/google/protobuf/WireFormat$FieldType;
    00d2: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    00d5: move-result v1
    00d6: const/16 v2, 18 (0x12)
    00d8: aput(op=4b) v2, v0[v1]
    00da: invoke-static {}, Lcom/google/protobuf/WireFormat$JavaType;->values()[Lcom/google/protobuf/WireFormat$JavaType;
    00dd: move-result-object v0
    00de: move(op=21) v0, v0
    00df: new-array v0, v0, [I
    00e1: sput v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    00e3: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    00e5: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->INT:Lcom/google/protobuf/WireFormat$JavaType;
    00e7: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    00ea: move-result v1
    00eb: const/4 v2, 1
    00ec: aput(op=4b) v2, v0[v1]
    00ee: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    00f0: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->LONG:Lcom/google/protobuf/WireFormat$JavaType;
    00f2: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    00f5: move-result v1
    00f6: const/4 v2, 2
    00f7: aput(op=4b) v2, v0[v1]
    00f9: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    00fb: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->FLOAT:Lcom/google/protobuf/WireFormat$JavaType;
    00fd: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    0100: move-result v1
    0101: const/4 v2, 3
    0102: aput(op=4b) v2, v0[v1]
    0104: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    0106: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->DOUBLE:Lcom/google/protobuf/WireFormat$JavaType;
    0108: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    010b: move-result v1
    010c: const/4 v2, 4
    010d: aput(op=4b) v2, v0[v1]
    010f: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    0111: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->BOOLEAN:Lcom/google/protobuf/WireFormat$JavaType;
    0113: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    0116: move-result v1
    0117: const/4 v2, 5
    0118: aput(op=4b) v2, v0[v1]
    011a: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    011c: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->STRING:Lcom/google/protobuf/WireFormat$JavaType;
    011e: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    0121: move-result v1
    0122: const/4 v2, 6
    0123: aput(op=4b) v2, v0[v1]
    0125: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    0127: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->BYTE_STRING:Lcom/google/protobuf/WireFormat$JavaType;
    0129: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    012c: move-result v1
    012d: const/4 v2, 7
    012e: aput(op=4b) v2, v0[v1]
    0130: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    0132: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->ENUM:Lcom/google/protobuf/WireFormat$JavaType;
    0134: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    0137: move-result v1
    0138: const/16 v2, 8 (0x8)
    013a: aput(op=4b) v2, v0[v1]
    013c: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    013e: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;
    0140: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    0143: move-result v1
    0144: const/16 v2, 9 (0x9)
    0146: aput(op=4b) v2, v0[v1]
    0148: return-void
    0149: move-exception v0
    014a: goto 0148
    014b: move-exception v0
    014c: goto 013c
    014d: move-exception v0
    014e: goto 0130
    014f: move-exception v0
    0150: goto 0125
    0151: move-exception v0
    0152: goto 011a
    0153: move-exception v0
    0154: goto 010f
    0155: move-exception v0
    0156: goto 0104
    0157: move-exception v0
    0158: goto 00f9
    0159: move-exception v0
    015a: goto 00ee
    015b: move-exception v0
    015c: goto/16 00da
    015e: move-exception v0
    015f: goto/16 00ce
    0161: move-exception v0
    0162: goto/16 00c2
    0164: move-exception v0
    0165: goto/16 00b6
    0167: move-exception v0
    0168: goto/16 00aa
    016a: move-exception v0
    016b: goto/16 009e
    016d: move-exception v0
    016e: goto/16 0092
    0170: move-exception v0
    0171: goto/16 0086
    0173: move-exception v0
    0174: goto/16 007a
    0176: move-exception v0
    0177: goto/16 006e
    0179: move-exception v0
    017a: goto/16 0062
    017c: move-exception v0
    017d: goto/16 0056
    017f: move-exception v0
    0180: goto/16 004b
    0182: move-exception v0
    0183: goto/16 0040
    0185: move-exception v0
    0186: goto/16 0035
    0188: move-exception v0
    0189: goto/16 002a
    018b: move-exception v0
    018c: goto/16 001f
    018e: move-exception v0
    018f: goto/16 0014