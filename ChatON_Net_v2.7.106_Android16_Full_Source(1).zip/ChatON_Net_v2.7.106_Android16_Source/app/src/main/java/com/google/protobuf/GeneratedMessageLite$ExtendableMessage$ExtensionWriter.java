=== CLASS Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter; (Source: GeneratedMessageLite.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] iter: Ljava/util/Iterator;
  [Instance Field] messageSetWireFormat: Z
  [Instance Field] next: Ljava/util/Map$Entry;
  [Instance Field] this$0: Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;

  [Direct Method] <init>(Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;, Z) -> V
    // registers=4, ins=3, outs=1, insns_size=38
    0000: iput v2, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->this$0:Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;
    0002: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0005: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->this$0:Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;
    0007: invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->access$300(Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;)Lcom/google/protobuf/FieldSet;
    000a: move-result-object v0
    000b: invoke-virtual {v0}, Lcom/google/protobuf/FieldSet;->iterator()Ljava/util/Iterator;
    000e: move-result-object v0
    000f: iput v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->iter:Ljava/util/Iterator;
    0011: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->iter:Ljava/util/Iterator;
    0013: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    0016: move-result v0
    0017: if-eqz v0, 0023
    0019: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->iter:Ljava/util/Iterator;
    001b: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    001e: move-result-object v0
    001f: check-cast v0, Ljava/util/Map$Entry;
    0021: iput v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;
    0023: iput v3, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->messageSetWireFormat:Z
    0025: return-void

  [Direct Method] <init>(Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;, Z, Lcom/google/protobuf/GeneratedMessageLite$1;) -> V
    // registers=4, ins=4, outs=3, insns_size=4
    0000: invoke-direct {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;-><init>(Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;Z)V
    0003: return-void

  [Virtual Method] writeUntil(I, Lcom/google/protobuf/CodedOutputStream;) -> V
    // registers=6, ins=3, outs=3, insns_size=93
    0000: iget v0, v3.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;
    0002: if-eqz v0, 005c
    0004: iget v0, v3.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;
    0006: invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0009: move-result-object v0
    000a: check-cast v0, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    000c: invoke-virtual {v0}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getNumber()I
    000f: move-result v0
    0010: if-ge v0, v4, 005c
    0012: iget v0, v3.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;
    0014: invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0017: move-result-object v0
    0018: check-cast v0, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    001a: iget v1, v3.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->messageSetWireFormat:Z
    001c: if-eqz v1, 004e
    001e: invoke-virtual {v0}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getLiteJavaType()Lcom/google/protobuf/WireFormat$JavaType;
    0021: move-result-object v1
    0022: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;
    0024: if-ne v1, v2, 004e
    0026: invoke-virtual {v0}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->isRepeated()Z
    0029: move-result v1
    002a: if-nez v1, 004e
    002c: invoke-virtual {v0}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getNumber()I
    002f: move-result v1
    0030: iget v0, v3.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;
    0032: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0035: move-result-object v0
    0036: check-cast v0, Lcom/google/protobuf/MessageLite;
    0038: invoke-virtual {v5, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeMessageSetExtension(ILcom/google/protobuf/MessageLite;)V
    003b: iget v0, v3.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->iter:Ljava/util/Iterator;
    003d: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    0040: move-result v0
    0041: if-eqz v0, 0058
    0043: iget v0, v3.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->iter:Ljava/util/Iterator;
    0045: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0048: move-result-object v0
    0049: check-cast v0, Ljava/util/Map$Entry;
    004b: iput v0, v3.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;
    004d: goto 0000
    004e: iget v1, v3.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;
    0050: invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0053: move-result-object v1
    0054: invoke-static {v0, v1, v5}, Lcom/google/protobuf/FieldSet;->writeField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;Lcom/google/protobuf/CodedOutputStream;)V
    0057: goto 003b
    0058: const/4 v0, 0
    0059: iput v0, v3.Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;
    005b: goto 0000
    005c: return-void