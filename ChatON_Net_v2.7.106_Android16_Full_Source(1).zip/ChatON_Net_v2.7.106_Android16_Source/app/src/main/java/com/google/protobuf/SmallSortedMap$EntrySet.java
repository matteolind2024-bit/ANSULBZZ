=== CLASS Lcom/google/protobuf/SmallSortedMap$EntrySet; (Source: SmallSortedMap.java) ===
  Super: Ljava/util/AbstractSet;
  [Instance Field] this$0: Lcom/google/protobuf/SmallSortedMap;

  [Direct Method] <init>(Lcom/google/protobuf/SmallSortedMap;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/google/protobuf/SmallSortedMap$EntrySet;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-direct {v0}, Ljava/util/AbstractSet;-><init>()V
    0005: return-void

  [Direct Method] <init>(Lcom/google/protobuf/SmallSortedMap;, Lcom/google/protobuf/SmallSortedMap$1;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/google/protobuf/SmallSortedMap$EntrySet;-><init>(Lcom/google/protobuf/SmallSortedMap;)V
    0003: return-void

  [Virtual Method] add(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v2, Ljava/util/Map$Entry;
    0002: invoke-virtual {v1, v2}, Lcom/google/protobuf/SmallSortedMap$EntrySet;->add(Ljava/util/Map$Entry;)Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] add(Ljava/util/Map$Entry;) -> Z
    // registers=5, ins=2, outs=3, insns_size=25
    0000: invoke-virtual {v3, v4}, Lcom/google/protobuf/SmallSortedMap$EntrySet;->contains(Ljava/lang/Object;)Z
    0003: move-result v0
    0004: if-nez v0, 0017
    0006: iget v1, v3.Lcom/google/protobuf/SmallSortedMap$EntrySet;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0008: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    000b: move-result-object v0
    000c: check-cast v0, Ljava/lang/Comparable;
    000e: invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0011: move-result-object v2
    0012: invoke-virtual {v1, v0, v2}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;
    0015: const/4 v0, 1
    0016: return v0
    0017: const/4 v0, 0
    0018: goto 0016

  [Virtual Method] clear() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap$EntrySet;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->clear()V
    0005: return-void

  [Virtual Method] contains(Ljava/lang/Object;) -> Z
    // registers=4, ins=2, outs=2, insns_size=30
    0000: check-cast v3, Ljava/util/Map$Entry;
    0002: iget v0, v2.Lcom/google/protobuf/SmallSortedMap$EntrySet;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0004: invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0007: move-result-object v1
    0008: invoke-virtual {v0, v1}, Lcom/google/protobuf/SmallSortedMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    000b: move-result-object v0
    000c: invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    000f: move-result-object v1
    0010: if-eq v0, v1, 001a
    0012: if-eqz v0, 001c
    0014: invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    0017: move-result v0
    0018: if-eqz v0, 001c
    001a: const/4 v0, 1
    001b: return v0
    001c: const/4 v0, 0
    001d: goto 001b

  [Virtual Method] iterator() -> Ljava/util/Iterator;
    // registers=4, ins=1, outs=3, insns_size=9
    0000: new-instance v0, Lcom/google/protobuf/SmallSortedMap$EntryIterator;
    0002: iget v1, v3.Lcom/google/protobuf/SmallSortedMap$EntrySet;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0004: const/4 v2, 0
    0005: invoke-direct {v0, v1, v2}, Lcom/google/protobuf/SmallSortedMap$EntryIterator;-><init>(Lcom/google/protobuf/SmallSortedMap;Lcom/google/protobuf/SmallSortedMap$1;)V
    0008: return-object v0

  [Virtual Method] remove(Ljava/lang/Object;) -> Z
    // registers=4, ins=2, outs=2, insns_size=21
    0000: check-cast v3, Ljava/util/Map$Entry;
    0002: invoke-virtual {v2, v3}, Lcom/google/protobuf/SmallSortedMap$EntrySet;->contains(Ljava/lang/Object;)Z
    0005: move-result v0
    0006: if-eqz v0, 0013
    0008: iget v0, v2.Lcom/google/protobuf/SmallSortedMap$EntrySet;->this$0:Lcom/google/protobuf/SmallSortedMap;
    000a: invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    000d: move-result-object v1
    000e: invoke-virtual {v0, v1}, Lcom/google/protobuf/SmallSortedMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    0011: const/4 v0, 1
    0012: return v0
    0013: const/4 v0, 0
    0014: goto 0012

  [Virtual Method] size() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap$EntrySet;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->size()I
    0005: move-result v0
    0006: return v0