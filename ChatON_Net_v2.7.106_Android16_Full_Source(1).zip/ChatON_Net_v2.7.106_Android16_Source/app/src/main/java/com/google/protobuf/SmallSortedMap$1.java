=== CLASS Lcom/google/protobuf/SmallSortedMap$1; (Source: SmallSortedMap.java) ===
  Super: Lcom/google/protobuf/SmallSortedMap;

  [Direct Method] <init>(I) -> V
    // registers=3, ins=2, outs=3, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-direct {v1, v2, v0}, Lcom/google/protobuf/SmallSortedMap;-><init>(ILcom/google/protobuf/SmallSortedMap$1;)V
    0004: return-void

  [Virtual Method] makeImmutable() -> V
    // registers=4, ins=1, outs=2, insns_size=97
    0000: invoke-virtual {v3}, Lcom/google/protobuf/SmallSortedMap$1;->isImmutable()Z
    0003: move-result v0
    0004: if-nez v0, 005d
    0006: const/4 v0, 0
    0007: move(op=01) v1, v0
    0008: invoke-virtual {v3}, Lcom/google/protobuf/SmallSortedMap$1;->getNumArrayEntries()I
    000b: move-result v0
    000c: if-ge v1, v0, 002f
    000e: invoke-virtual {v3, v1}, Lcom/google/protobuf/SmallSortedMap$1;->getArrayEntryAt(I)Ljava/util/Map$Entry;
    0011: move-result-object v2
    0012: invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0015: move-result-object v0
    0016: check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0018: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    001b: move-result v0
    001c: if-eqz v0, 002b
    001e: invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0021: move-result-object v0
    0022: check-cast v0, Ljava/util/List;
    0024: invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;
    0027: move-result-object v0
    0028: invoke-interface {v2, v0}, Ljava/util/Map$Entry;->setValue(Ljava/lang/Object;)Ljava/lang/Object;
    002b: binop/lit8(op=d8) v0, v1, 1 (0x1)
    002d: move(op=01) v1, v0
    002e: goto 0008
    002f: invoke-virtual {v3}, Lcom/google/protobuf/SmallSortedMap$1;->getOverflowEntries()Ljava/lang/Iterable;
    0032: move-result-object v0
    0033: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    0036: move-result-object v2
    0037: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    003a: move-result v0
    003b: if-eqz v0, 005d
    003d: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0040: move-result-object v0
    0041: check-cast v0, Ljava/util/Map$Entry;
    0043: invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0046: move-result-object v1
    0047: check-cast v1, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0049: invoke-interface {v1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    004c: move-result v1
    004d: if-eqz v1, 0037
    004f: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0052: move-result-object v1
    0053: check-cast v1, Ljava/util/List;
    0055: invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;
    0058: move-result-object v1
    0059: invoke-interface {v0, v1}, Ljava/util/Map$Entry;->setValue(Ljava/lang/Object;)Ljava/lang/Object;
    005c: goto 0037
    005d: invoke-super {v3}, Lcom/google/protobuf/SmallSortedMap;->makeImmutable()V
    0060: return-void

  [Virtual Method] put(Ljava/lang/Object;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=4, ins=3, outs=3, insns_size=7
    0000: check-cast v2, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0002: invoke-super {v1, v2, v3}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: return-object v0