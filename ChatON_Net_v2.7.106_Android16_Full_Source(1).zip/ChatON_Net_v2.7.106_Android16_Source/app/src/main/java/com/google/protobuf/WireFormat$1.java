=== CLASS Lcom/google/protobuf/WireFormat$1; (Source: WireFormat.java) ===
  Super: Ljava/lang/Object;