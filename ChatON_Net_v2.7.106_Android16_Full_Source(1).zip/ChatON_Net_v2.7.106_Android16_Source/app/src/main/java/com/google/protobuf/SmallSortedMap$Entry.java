=== CLASS Lcom/google/protobuf/SmallSortedMap$Entry; (Source: SmallSortedMap.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/lang/Comparable;, Ljava/util/Map$Entry;
  [Instance Field] key: Ljava/lang/Comparable;
  [Instance Field] this$0: Lcom/google/protobuf/SmallSortedMap;
  [Instance Field] value: Ljava/lang/Object;

  [Direct Method] <init>(Lcom/google/protobuf/SmallSortedMap;, Ljava/lang/Comparable;, Ljava/lang/Object;) -> V
    // registers=4, ins=4, outs=1, insns_size=10
    0000: iput v1, v0.Lcom/google/protobuf/SmallSortedMap$Entry;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: iput v2, v0.Lcom/google/protobuf/SmallSortedMap$Entry;->key:Ljava/lang/Comparable;
    0007: iput v3, v0.Lcom/google/protobuf/SmallSortedMap$Entry;->value:Ljava/lang/Object;
    0009: return-void

  [Direct Method] <init>(Lcom/google/protobuf/SmallSortedMap;, Ljava/util/Map$Entry;) -> V
    // registers=5, ins=3, outs=4, insns_size=14
    0000: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0003: move-result-object v0
    0004: check-cast v0, Ljava/lang/Comparable;
    0006: invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0009: move-result-object v1
    000a: invoke-direct {v2, v3, v0, v1}, Lcom/google/protobuf/SmallSortedMap$Entry;-><init>(Lcom/google/protobuf/SmallSortedMap;Ljava/lang/Comparable;Ljava/lang/Object;)V
    000d: return-void

  [Direct Method] equals(Ljava/lang/Object;, Ljava/lang/Object;) -> Z
    // registers=4, ins=3, outs=2, insns_size=13
    0000: if-nez v2, 0008
    0002: if-nez v3, 0006
    0004: const/4 v0, 1
    0005: return v0
    0006: const/4 v0, 0
    0007: goto 0005
    0008: invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    000b: move-result v0
    000c: goto 0005

  [Virtual Method] compareTo(Lcom/google/protobuf/SmallSortedMap$Entry;) -> I
    // registers=4, ins=2, outs=2, insns_size=13
    0000: invoke-virtual {v2}, Lcom/google/protobuf/SmallSortedMap$Entry;->getKey()Ljava/lang/Comparable;
    0003: move-result-object v0
    0004: invoke-virtual {v3}, Lcom/google/protobuf/SmallSortedMap$Entry;->getKey()Ljava/lang/Comparable;
    0007: move-result-object v1
    0008: invoke-interface {v0, v1}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I
    000b: move-result v0
    000c: return v0

  [Virtual Method] compareTo(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v2, Lcom/google/protobuf/SmallSortedMap$Entry;
    0002: invoke-virtual {v1, v2}, Lcom/google/protobuf/SmallSortedMap$Entry;->compareTo(Lcom/google/protobuf/SmallSortedMap$Entry;)I
    0005: move-result v0
    0006: return v0

  [Virtual Method] equals(Ljava/lang/Object;) -> Z
    // registers=6, ins=2, outs=3, insns_size=39
    0000: const/4 v0, 1
    0001: const/4 v1, 0
    0002: if-ne v5, v4, 0005
    0004: return v0
    0005: instance-of v2, v5, Ljava/util/Map$Entry;
    0007: if-nez v2, 000b
    0009: move(op=01) v0, v1
    000a: goto 0004
    000b: check-cast v5, Ljava/util/Map$Entry;
    000d: iget v2, v4.Lcom/google/protobuf/SmallSortedMap$Entry;->key:Ljava/lang/Comparable;
    000f: invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0012: move-result-object v3
    0013: invoke-direct {v4, v2, v3}, Lcom/google/protobuf/SmallSortedMap$Entry;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z
    0016: move-result v2
    0017: if-eqz v2, 0025
    0019: iget v2, v4.Lcom/google/protobuf/SmallSortedMap$Entry;->value:Ljava/lang/Object;
    001b: invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    001e: move-result-object v3
    001f: invoke-direct {v4, v2, v3}, Lcom/google/protobuf/SmallSortedMap$Entry;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z
    0022: move-result v2
    0023: if-nez v2, 0004
    0025: move(op=01) v0, v1
    0026: goto 0004

  [Virtual Method] getKey() -> Ljava/lang/Comparable;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap$Entry;->key:Ljava/lang/Comparable;
    0002: return-object v0

  [Virtual Method] getKey() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/SmallSortedMap$Entry;->getKey()Ljava/lang/Comparable;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getValue() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap$Entry;->value:Ljava/lang/Object;
    0002: return-object v0

  [Virtual Method] hashCode() -> I
    // registers=4, ins=1, outs=1, insns_size=26
    0000: const/4 v1, 0
    0001: iget v0, v3.Lcom/google/protobuf/SmallSortedMap$Entry;->key:Ljava/lang/Comparable;
    0003: if-nez v0, 000c
    0005: move(op=01) v0, v1
    0006: iget v2, v3.Lcom/google/protobuf/SmallSortedMap$Entry;->value:Ljava/lang/Object;
    0008: if-nez v2, 0013
    000a: binop/2addr(op=b7) v0, v1
    000b: return v0
    000c: iget v0, v3.Lcom/google/protobuf/SmallSortedMap$Entry;->key:Ljava/lang/Comparable;
    000e: invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I
    0011: move-result v0
    0012: goto 0006
    0013: iget v1, v3.Lcom/google/protobuf/SmallSortedMap$Entry;->value:Ljava/lang/Object;
    0015: invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I
    0018: move-result v1
    0019: goto 000a

  [Virtual Method] setValue(Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=1, insns_size=10
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap$Entry;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-static {v0}, Lcom/google/protobuf/SmallSortedMap;->access$200(Lcom/google/protobuf/SmallSortedMap;)V
    0005: iget v0, v1.Lcom/google/protobuf/SmallSortedMap$Entry;->value:Ljava/lang/Object;
    0007: iput v2, v1.Lcom/google/protobuf/SmallSortedMap$Entry;->value:Ljava/lang/Object;
    0009: return-object v0

  [Virtual Method] toString() -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=28
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0005: iget v1, v2.Lcom/google/protobuf/SmallSortedMap$Entry;->key:Ljava/lang/Comparable;
    0007: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    000a: move-result-object v0
    000b: const-string v1, '='
    000d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v0
    0011: iget v1, v2.Lcom/google/protobuf/SmallSortedMap$Entry;->value:Ljava/lang/Object;
    0013: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0016: move-result-object v0
    0017: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001a: move-result-object v0
    001b: return-object v0