=== CLASS Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair; (Source: ExtensionRegistryLite.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] number: I
  [Instance Field] object: Ljava/lang/Object;

  [Direct Method] <init>(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=1, insns_size=8
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;->object:Ljava/lang/Object;
    0005: iput v2, v0.Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;->number:I
    0007: return-void

  [Virtual Method] equals(Ljava/lang/Object;) -> Z
    // registers=5, ins=2, outs=0, insns_size=22
    0000: const/4 v0, 0
    0001: instance-of v1, v4, Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;
    0003: if-nez v1, 0006
    0005: return v0
    0006: check-cast v4, Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;
    0008: iget v1, v3.Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;->object:Ljava/lang/Object;
    000a: iget v2, v4.Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;->object:Ljava/lang/Object;
    000c: if-ne v1, v2, 0005
    000e: iget v1, v3.Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;->number:I
    0010: iget v2, v4.Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;->number:I
    0012: if-ne v1, v2, 0005
    0014: const/4 v0, 1
    0015: goto 0005

  [Virtual Method] hashCode() -> I
    // registers=3, ins=1, outs=1, insns_size=14
    0000: iget v0, v2.Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;->object:Ljava/lang/Object;
    0002: invoke-static {v0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I
    0005: move-result v0
    0006: const v1, 65535 (0xffff)
    0009: binop/2addr(op=b2) v0, v1
    000a: iget v1, v2.Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;->number:I
    000c: binop/2addr(op=b0) v0, v1
    000d: return v0