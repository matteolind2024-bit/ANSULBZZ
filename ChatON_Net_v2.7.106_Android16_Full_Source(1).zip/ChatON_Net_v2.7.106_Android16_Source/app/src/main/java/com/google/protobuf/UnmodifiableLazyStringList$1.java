=== CLASS Lcom/google/protobuf/UnmodifiableLazyStringList$1; (Source: UnmodifiableLazyStringList.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/util/ListIterator;
  [Instance Field] iter: Ljava/util/ListIterator;
  [Instance Field] this$0: Lcom/google/protobuf/UnmodifiableLazyStringList;
  [Instance Field] val$index: I

  [Direct Method] <init>(Lcom/google/protobuf/UnmodifiableLazyStringList;, I) -> V
    // registers=5, ins=3, outs=2, insns_size=22
    0000: iput v3, v2.Lcom/google/protobuf/UnmodifiableLazyStringList$1;->this$0:Lcom/google/protobuf/UnmodifiableLazyStringList;
    0002: iput v4, v2.Lcom/google/protobuf/UnmodifiableLazyStringList$1;->val$index:I
    0004: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0007: iget v0, v2.Lcom/google/protobuf/UnmodifiableLazyStringList$1;->this$0:Lcom/google/protobuf/UnmodifiableLazyStringList;
    0009: invoke-static {v0}, Lcom/google/protobuf/UnmodifiableLazyStringList;->access$000(Lcom/google/protobuf/UnmodifiableLazyStringList;)Lcom/google/protobuf/LazyStringList;
    000c: move-result-object v0
    000d: iget v1, v2.Lcom/google/protobuf/UnmodifiableLazyStringList$1;->val$index:I
    000f: invoke-interface {v0, v1}, Lcom/google/protobuf/LazyStringList;->listIterator(I)Ljava/util/ListIterator;
    0012: move-result-object v0
    0013: iput v0, v2.Lcom/google/protobuf/UnmodifiableLazyStringList$1;->iter:Ljava/util/ListIterator;
    0015: return-void

  [Virtual Method] add(Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v1, Ljava/lang/String;
    0002: invoke-virtual {v0, v1}, Lcom/google/protobuf/UnmodifiableLazyStringList$1;->add(Ljava/lang/String;)V
    0005: return-void

  [Virtual Method] add(Ljava/lang/String;) -> V
    // registers=3, ins=2, outs=1, insns_size=6
    0000: new-instance v0, Ljava/lang/UnsupportedOperationException;
    0002: invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V
    0005: throw v0

  [Virtual Method] hasNext() -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList$1;->iter:Ljava/util/ListIterator;
    0002: invoke-interface {v0}, Ljava/util/ListIterator;->hasNext()Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] hasPrevious() -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList$1;->iter:Ljava/util/ListIterator;
    0002: invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] next() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/UnmodifiableLazyStringList$1;->next()Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] next() -> Ljava/lang/String;
    // registers=2, ins=1, outs=1, insns_size=9
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList$1;->iter:Ljava/util/ListIterator;
    0002: invoke-interface {v0}, Ljava/util/ListIterator;->next()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Ljava/lang/String;
    0008: return-object v0

  [Virtual Method] nextIndex() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList$1;->iter:Ljava/util/ListIterator;
    0002: invoke-interface {v0}, Ljava/util/ListIterator;->nextIndex()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] previous() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/UnmodifiableLazyStringList$1;->previous()Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] previous() -> Ljava/lang/String;
    // registers=2, ins=1, outs=1, insns_size=9
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList$1;->iter:Ljava/util/ListIterator;
    0002: invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Ljava/lang/String;
    0008: return-object v0

  [Virtual Method] previousIndex() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList$1;->iter:Ljava/util/ListIterator;
    0002: invoke-interface {v0}, Ljava/util/ListIterator;->previousIndex()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] remove() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: new-instance v0, Ljava/lang/UnsupportedOperationException;
    0002: invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V
    0005: throw v0

  [Virtual Method] set(Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v1, Ljava/lang/String;
    0002: invoke-virtual {v0, v1}, Lcom/google/protobuf/UnmodifiableLazyStringList$1;->set(Ljava/lang/String;)V
    0005: return-void

  [Virtual Method] set(Ljava/lang/String;) -> V
    // registers=3, ins=2, outs=1, insns_size=6
    0000: new-instance v0, Ljava/lang/UnsupportedOperationException;
    0002: invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V
    0005: throw v0