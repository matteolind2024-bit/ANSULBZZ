=== CLASS Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessageOrBuilder; (Source: GeneratedMessageLite.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/MessageLiteOrBuilder;

  [Virtual Method] getExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> Ljava/lang/Object;

  [Virtual Method] getExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;, I) -> Ljava/lang/Object;

  [Virtual Method] getExtensionCount(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> I

  [Virtual Method] hasExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> Z