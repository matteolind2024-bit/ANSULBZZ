=== CLASS Lcom/google/protobuf/CodedOutputStream; (Source: CodedOutputStream.java) ===
  Super: Ljava/lang/Object;
  [Static Field] DEFAULT_BUFFER_SIZE: I = 4096
  [Static Field] LITTLE_ENDIAN_32_SIZE: I = 4
  [Static Field] LITTLE_ENDIAN_64_SIZE: I = 8
  [Instance Field] buffer: [B
  [Instance Field] limit: I
  [Instance Field] output: Ljava/io/OutputStream;
  [Instance Field] position: I

  [Direct Method] <init>(Ljava/io/OutputStream;, [B) -> V
    // registers=4, ins=3, outs=1, insns_size=14
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: iput v2, v1.Lcom/google/protobuf/CodedOutputStream;->output:Ljava/io/OutputStream;
    0005: iput v3, v1.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    0007: const/4 v0, 0
    0008: iput v0, v1.Lcom/google/protobuf/CodedOutputStream;->position:I
    000a: move(op=21) v0, v3
    000b: iput v0, v1.Lcom/google/protobuf/CodedOutputStream;->limit:I
    000d: return-void

  [Direct Method] <init>([B, I, I) -> V
    // registers=5, ins=4, outs=1, insns_size=15
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: const/4 v0, 0
    0004: iput v0, v1.Lcom/google/protobuf/CodedOutputStream;->output:Ljava/io/OutputStream;
    0006: iput v2, v1.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    0008: iput v3, v1.Lcom/google/protobuf/CodedOutputStream;->position:I
    000a: binop(op=90) v0, v3, v4
    000c: iput v0, v1.Lcom/google/protobuf/CodedOutputStream;->limit:I
    000e: return-void

  [Direct Method] computeBoolSize(I, Z) -> I
    // registers=4, ins=2, outs=1, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeBoolSizeNoTag(Z)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeBoolSizeNoTag(Z) -> I
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Direct Method] computeBytesSize(I, Lcom/google/protobuf/ByteString;) -> I
    // registers=4, ins=2, outs=1, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeBytesSizeNoTag(Lcom/google/protobuf/ByteString;)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeBytesSizeNoTag(Lcom/google/protobuf/ByteString;) -> I
    // registers=3, ins=1, outs=1, insns_size=14
    0000: invoke-virtual {v2}, Lcom/google/protobuf/ByteString;->size()I
    0003: move-result v0
    0004: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint32Size(I)I
    0007: move-result v0
    0008: invoke-virtual {v2}, Lcom/google/protobuf/ByteString;->size()I
    000b: move-result v1
    000c: binop/2addr(op=b0) v0, v1
    000d: return v0

  [Direct Method] computeDoubleSize(I, D) -> I
    // registers=5, ins=3, outs=2, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3, v4}, Lcom/google/protobuf/CodedOutputStream;->computeDoubleSizeNoTag(D)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeDoubleSizeNoTag(D) -> I
    // registers=3, ins=2, outs=0, insns_size=3
    0000: const/16 v0, 8 (0x8)
    0002: return v0

  [Direct Method] computeEnumSize(I, I) -> I
    // registers=4, ins=2, outs=1, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSizeNoTag(I)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeEnumSizeNoTag(I) -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-static {v1}, Lcom/google/protobuf/CodedOutputStream;->computeInt32SizeNoTag(I)I
    0003: move-result v0
    0004: return v0

  [Direct Method] computeFixed32Size(I, I) -> I
    // registers=4, ins=2, outs=1, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeFixed32SizeNoTag(I)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeFixed32SizeNoTag(I) -> I
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 4
    0001: return v0

  [Direct Method] computeFixed64Size(I, J) -> I
    // registers=5, ins=3, outs=2, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3, v4}, Lcom/google/protobuf/CodedOutputStream;->computeFixed64SizeNoTag(J)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeFixed64SizeNoTag(J) -> I
    // registers=3, ins=2, outs=0, insns_size=3
    0000: const/16 v0, 8 (0x8)
    0002: return v0

  [Direct Method] computeFloatSize(I, F) -> I
    // registers=4, ins=2, outs=1, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeFloatSizeNoTag(F)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeFloatSizeNoTag(F) -> I
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 4
    0001: return v0

  [Direct Method] computeGroupSize(I, Lcom/google/protobuf/MessageLite;) -> I
    // registers=4, ins=2, outs=1, insns_size=12
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: binop/lit8(op=da) v0, v0, 2 (0x2)
    0006: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeGroupSizeNoTag(Lcom/google/protobuf/MessageLite;)I
    0009: move-result v1
    000a: binop/2addr(op=b0) v0, v1
    000b: return v0

  [Direct Method] computeGroupSizeNoTag(Lcom/google/protobuf/MessageLite;) -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-interface {v1}, Lcom/google/protobuf/MessageLite;->getSerializedSize()I
    0003: move-result v0
    0004: return v0

  [Direct Method] computeInt32Size(I, I) -> I
    // registers=4, ins=2, outs=1, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeInt32SizeNoTag(I)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeInt32SizeNoTag(I) -> I
    // registers=2, ins=1, outs=1, insns_size=10
    0000: if-ltz v1, 0007
    0002: invoke-static {v1}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint32Size(I)I
    0005: move-result v0
    0006: return v0
    0007: const/16 v0, 10 (0xa)
    0009: goto 0006

  [Direct Method] computeInt64Size(I, J) -> I
    // registers=5, ins=3, outs=2, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3, v4}, Lcom/google/protobuf/CodedOutputStream;->computeInt64SizeNoTag(J)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeInt64SizeNoTag(J) -> I
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-static {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint64Size(J)I
    0003: move-result v0
    0004: return v0

  [Direct Method] computeMessageSetExtensionSize(I, Lcom/google/protobuf/MessageLite;) -> I
    // registers=4, ins=2, outs=2, insns_size=20
    0000: const/4 v0, 1
    0001: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0004: move-result v0
    0005: binop/lit8(op=da) v0, v0, 2 (0x2)
    0007: const/4 v1, 2
    0008: invoke-static {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32Size(II)I
    000b: move-result v1
    000c: binop/2addr(op=b0) v0, v1
    000d: const/4 v1, 3
    000e: invoke-static {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I
    0011: move-result v1
    0012: binop/2addr(op=b0) v0, v1
    0013: return v0

  [Direct Method] computeMessageSize(I, Lcom/google/protobuf/MessageLite;) -> I
    // registers=4, ins=2, outs=1, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSizeNoTag(Lcom/google/protobuf/MessageLite;)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeMessageSizeNoTag(Lcom/google/protobuf/MessageLite;) -> I
    // registers=3, ins=1, outs=1, insns_size=10
    0000: invoke-interface {v2}, Lcom/google/protobuf/MessageLite;->getSerializedSize()I
    0003: move-result v0
    0004: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint32Size(I)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computePreferredBufferSize(I) -> I
    // registers=2, ins=1, outs=0, insns_size=6
    0000: const/16 v0, 4096 (0x1000)
    0002: if-le v1, v0, 0005
    0004: move(op=01) v1, v0
    0005: return v1

  [Direct Method] computeRawMessageSetExtensionSize(I, Lcom/google/protobuf/ByteString;) -> I
    // registers=4, ins=2, outs=2, insns_size=20
    0000: const/4 v0, 1
    0001: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0004: move-result v0
    0005: binop/lit8(op=da) v0, v0, 2 (0x2)
    0007: const/4 v1, 2
    0008: invoke-static {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32Size(II)I
    000b: move-result v1
    000c: binop/2addr(op=b0) v0, v1
    000d: const/4 v1, 3
    000e: invoke-static {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->computeBytesSize(ILcom/google/protobuf/ByteString;)I
    0011: move-result v1
    0012: binop/2addr(op=b0) v0, v1
    0013: return v0

  [Direct Method] computeRawVarint32Size(I) -> I
    // registers=2, ins=1, outs=0, insns_size=28
    0000: binop/lit8(op=dd) v0, v1, -128 (-0x80)
    0002: if-nez v0, 0006
    0004: const/4 v0, 1
    0005: return v0
    0006: binop/lit16(op=d5) v0, v1, -16384 (-0x4000)
    0008: if-nez v0, 000c
    000a: const/4 v0, 2
    000b: goto 0005
    000c: const/high16 v0, -2097152 (-0x200000)
    000e: binop/2addr(op=b5) v0, v1
    000f: if-nez v0, 0013
    0011: const/4 v0, 3
    0012: goto 0005
    0013: const/high16 v0, -268435456 (-0x10000000)
    0015: binop/2addr(op=b5) v0, v1
    0016: if-nez v0, 001a
    0018: const/4 v0, 4
    0019: goto 0005
    001a: const/4 v0, 5
    001b: goto 0005

  [Direct Method] computeRawVarint64Size(J) -> I
    // registers=6, ins=2, outs=0, insns_size=96
    0000: const-wide/16 v2, 0
    0002: const-wide/16 v0, -128
    0004: binop/2addr(op=c0) v0, v4
    0005: cmp(op=31) v0, v0, v2
    0007: if-nez v0, 000b
    0009: const/4 v0, 1
    000a: return v0
    000b: const-wide/16 v0, -16384
    000d: binop/2addr(op=c0) v0, v4
    000e: cmp(op=31) v0, v0, v2
    0010: if-nez v0, 0014
    0012: const/4 v0, 2
    0013: goto 000a
    0014: const-wide/32 v0, -2097152
    0017: binop/2addr(op=c0) v0, v4
    0018: cmp(op=31) v0, v0, v2
    001a: if-nez v0, 001e
    001c: const/4 v0, 3
    001d: goto 000a
    001e: const-wide/32 v0, -268435456
    0021: binop/2addr(op=c0) v0, v4
    0022: cmp(op=31) v0, v0, v2
    0024: if-nez v0, 0028
    0026: const/4 v0, 4
    0027: goto 000a
    0028: const-wide v0, -34359738368 (-0x800000000)
    002d: binop/2addr(op=c0) v0, v4
    002e: cmp(op=31) v0, v0, v2
    0030: if-nez v0, 0034
    0032: const/4 v0, 5
    0033: goto 000a
    0034: const-wide v0, -4398046511104 (-0x40000000000)
    0039: binop/2addr(op=c0) v0, v4
    003a: cmp(op=31) v0, v0, v2
    003c: if-nez v0, 0040
    003e: const/4 v0, 6
    003f: goto 000a
    0040: const-wide/high16 v0, -562949953421312
    0042: binop/2addr(op=c0) v0, v4
    0043: cmp(op=31) v0, v0, v2
    0045: if-nez v0, 0049
    0047: const/4 v0, 7
    0048: goto 000a
    0049: const-wide/high16 v0, -72057594037927936
    004b: binop/2addr(op=c0) v0, v4
    004c: cmp(op=31) v0, v0, v2
    004e: if-nez v0, 0053
    0050: const/16 v0, 8 (0x8)
    0052: goto 000a
    0053: const-wide/high16 v0, -9223372036854775808
    0055: binop/2addr(op=c0) v0, v4
    0056: cmp(op=31) v0, v0, v2
    0058: if-nez v0, 005d
    005a: const/16 v0, 9 (0x9)
    005c: goto 000a
    005d: const/16 v0, 10 (0xa)
    005f: goto 000a

  [Direct Method] computeSFixed32Size(I, I) -> I
    // registers=4, ins=2, outs=1, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeSFixed32SizeNoTag(I)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeSFixed32SizeNoTag(I) -> I
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 4
    0001: return v0

  [Direct Method] computeSFixed64Size(I, J) -> I
    // registers=5, ins=3, outs=2, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3, v4}, Lcom/google/protobuf/CodedOutputStream;->computeSFixed64SizeNoTag(J)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeSFixed64SizeNoTag(J) -> I
    // registers=3, ins=2, outs=0, insns_size=3
    0000: const/16 v0, 8 (0x8)
    0002: return v0

  [Direct Method] computeSInt32Size(I, I) -> I
    // registers=4, ins=2, outs=1, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeSInt32SizeNoTag(I)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeSInt32SizeNoTag(I) -> I
    // registers=2, ins=1, outs=1, insns_size=9
    0000: invoke-static {v1}, Lcom/google/protobuf/CodedOutputStream;->encodeZigZag32(I)I
    0003: move-result v0
    0004: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint32Size(I)I
    0007: move-result v0
    0008: return v0

  [Direct Method] computeSInt64Size(I, J) -> I
    // registers=5, ins=3, outs=2, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3, v4}, Lcom/google/protobuf/CodedOutputStream;->computeSInt64SizeNoTag(J)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeSInt64SizeNoTag(J) -> I
    // registers=4, ins=2, outs=2, insns_size=9
    0000: invoke-static {v2, v3}, Lcom/google/protobuf/CodedOutputStream;->encodeZigZag64(J)J
    0003: move-result-wide v0
    0004: invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint64Size(J)I
    0007: move-result v0
    0008: return v0

  [Direct Method] computeStringSize(I, Ljava/lang/String;) -> I
    // registers=4, ins=2, outs=1, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeStringSizeNoTag(Ljava/lang/String;)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeStringSizeNoTag(Ljava/lang/String;) -> I
    // registers=4, ins=1, outs=3, insns_size=23
    0000: const-string v0, 'UTF-8'
    0002: invoke-virtual {v3, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B
    0005: move-result-object v0
    0006: move(op=21) v1, v0
    0007: invoke-static {v1}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint32Size(I)I
    000a: move-result v1
    000b: move(op=21) v0, v0
    000c: binop/2addr(op=b0) v0, v1
    000d: return v0
    000e: move-exception v0
    000f: new-instance v1, Ljava/lang/RuntimeException;
    0011: const-string v2, 'UTF-8 not supported.'
    0013: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0016: throw v1

  [Direct Method] computeTagSize(I) -> I
    // registers=2, ins=1, outs=2, insns_size=10
    0000: const/4 v0, 0
    0001: invoke-static {v1, v0}, Lcom/google/protobuf/WireFormat;->makeTag(II)I
    0004: move-result v0
    0005: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint32Size(I)I
    0008: move-result v0
    0009: return v0

  [Direct Method] computeUInt32Size(I, I) -> I
    // registers=4, ins=2, outs=1, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32SizeNoTag(I)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeUInt32SizeNoTag(I) -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-static {v1}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint32Size(I)I
    0003: move-result v0
    0004: return v0

  [Direct Method] computeUInt64Size(I, J) -> I
    // registers=5, ins=3, outs=2, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: invoke-static {v3, v4}, Lcom/google/protobuf/CodedOutputStream;->computeUInt64SizeNoTag(J)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v0, v1
    0009: return v0

  [Direct Method] computeUInt64SizeNoTag(J) -> I
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-static {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint64Size(J)I
    0003: move-result v0
    0004: return v0

  [Direct Method] computeUnknownGroupSize(I, Lcom/google/protobuf/MessageLite;) -> I
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-static {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->computeGroupSize(ILcom/google/protobuf/MessageLite;)I
    0003: move-result v0
    0004: return v0

  [Direct Method] computeUnknownGroupSizeNoTag(Lcom/google/protobuf/MessageLite;) -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-static {v1}, Lcom/google/protobuf/CodedOutputStream;->computeGroupSizeNoTag(Lcom/google/protobuf/MessageLite;)I
    0003: move-result v0
    0004: return v0

  [Direct Method] encodeZigZag32(I) -> I
    // registers=3, ins=1, outs=0, insns_size=6
    0000: binop/lit8(op=e0) v0, v2, 1 (0x1)
    0002: binop/lit8(op=e1) v1, v2, 31 (0x1f)
    0004: binop/2addr(op=b7) v0, v1
    0005: return v0

  [Direct Method] encodeZigZag64(J) -> J
    // registers=6, ins=2, outs=0, insns_size=9
    0000: const/4 v0, 1
    0001: binop(op=a3) v0, v4, v0
    0003: const/16 v2, 63 (0x3f)
    0005: binop(op=a4) v2, v4, v2
    0007: binop/2addr(op=c2) v0, v2
    0008: return-wide v0

  [Direct Method] newInstance(Ljava/io/OutputStream;) -> Lcom/google/protobuf/CodedOutputStream;
    // registers=2, ins=1, outs=2, insns_size=7
    0000: const/16 v0, 4096 (0x1000)
    0002: invoke-static {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->newInstance(Ljava/io/OutputStream;I)Lcom/google/protobuf/CodedOutputStream;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] newInstance(Ljava/io/OutputStream;, I) -> Lcom/google/protobuf/CodedOutputStream;
    // registers=4, ins=2, outs=3, insns_size=8
    0000: new-instance v0, Lcom/google/protobuf/CodedOutputStream;
    0002: new-array v1, v3, [B
    0004: invoke-direct {v0, v2, v1}, Lcom/google/protobuf/CodedOutputStream;-><init>(Ljava/io/OutputStream;[B)V
    0007: return-object v0

  [Direct Method] newInstance([B) -> Lcom/google/protobuf/CodedOutputStream;
    // registers=3, ins=1, outs=3, insns_size=7
    0000: const/4 v0, 0
    0001: move(op=21) v1, v2
    0002: invoke-static {v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->newInstance([BII)Lcom/google/protobuf/CodedOutputStream;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] newInstance([B, I, I) -> Lcom/google/protobuf/CodedOutputStream;
    // registers=4, ins=3, outs=4, insns_size=6
    0000: new-instance v0, Lcom/google/protobuf/CodedOutputStream;
    0002: invoke-direct {v0, v1, v2, v3}, Lcom/google/protobuf/CodedOutputStream;-><init>([BII)V
    0005: return-object v0

  [Direct Method] refreshBuffer() -> V
    // registers=5, ins=1, outs=4, insns_size=23
    0000: const/4 v3, 0
    0001: iget v0, v4.Lcom/google/protobuf/CodedOutputStream;->output:Ljava/io/OutputStream;
    0003: if-nez v0, 000b
    0005: new-instance v0, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;
    0007: invoke-direct {v0}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>()V
    000a: throw v0
    000b: iget v0, v4.Lcom/google/protobuf/CodedOutputStream;->output:Ljava/io/OutputStream;
    000d: iget v1, v4.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    000f: iget v2, v4.Lcom/google/protobuf/CodedOutputStream;->position:I
    0011: invoke-virtual {v0, v1, v3, v2}, Ljava/io/OutputStream;->write([BII)V
    0014: iput v3, v4.Lcom/google/protobuf/CodedOutputStream;->position:I
    0016: return-void

  [Virtual Method] checkNoSpaceLeft() -> V
    // registers=3, ins=1, outs=2, insns_size=15
    0000: invoke-virtual {v2}, Lcom/google/protobuf/CodedOutputStream;->spaceLeft()I
    0003: move-result v0
    0004: if-eqz v0, 000e
    0006: new-instance v0, Ljava/lang/IllegalStateException;
    0008: const-string v1, 'Did not write as much data as expected.'
    000a: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000d: throw v0
    000e: return-void

  [Virtual Method] flush() -> V
    // registers=2, ins=1, outs=1, insns_size=8
    0000: iget v0, v1.Lcom/google/protobuf/CodedOutputStream;->output:Ljava/io/OutputStream;
    0002: if-eqz v0, 0007
    0004: invoke-direct {v1}, Lcom/google/protobuf/CodedOutputStream;->refreshBuffer()V
    0007: return-void

  [Virtual Method] spaceLeft() -> I
    // registers=3, ins=1, outs=2, insns_size=18
    0000: iget v0, v2.Lcom/google/protobuf/CodedOutputStream;->output:Ljava/io/OutputStream;
    0002: if-nez v0, 000a
    0004: iget v0, v2.Lcom/google/protobuf/CodedOutputStream;->limit:I
    0006: iget v1, v2.Lcom/google/protobuf/CodedOutputStream;->position:I
    0008: binop/2addr(op=b1) v0, v1
    0009: return v0
    000a: new-instance v0, Ljava/lang/UnsupportedOperationException;
    000c: const-string v1, 'spaceLeft() can only be called on CodedOutputStreams that are writing to a flat array.'
    000e: invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    0011: throw v0

  [Virtual Method] writeBool(I, Z) -> V
    // registers=4, ins=3, outs=3, insns_size=8
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeBoolNoTag(Z)V
    0007: return-void

  [Virtual Method] writeBoolNoTag(Z) -> V
    // registers=3, ins=2, outs=2, insns_size=9
    0000: if-eqz v2, 0007
    0002: const/4 v0, 1
    0003: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    0006: return-void
    0007: const/4 v0, 0
    0008: goto 0003

  [Virtual Method] writeBytes(I, Lcom/google/protobuf/ByteString;) -> V
    // registers=4, ins=3, outs=3, insns_size=8
    0000: const/4 v0, 2
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeBytesNoTag(Lcom/google/protobuf/ByteString;)V
    0007: return-void

  [Virtual Method] writeBytesNoTag(Lcom/google/protobuf/ByteString;) -> V
    // registers=3, ins=2, outs=2, insns_size=11
    0000: invoke-virtual {v2}, Lcom/google/protobuf/ByteString;->size()I
    0003: move-result v0
    0004: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint32(I)V
    0007: invoke-virtual {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeRawBytes(Lcom/google/protobuf/ByteString;)V
    000a: return-void

  [Virtual Method] writeDouble(I, D) -> V
    // registers=5, ins=4, outs=3, insns_size=8
    0000: const/4 v0, 1
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3, v4}, Lcom/google/protobuf/CodedOutputStream;->writeDoubleNoTag(D)V
    0007: return-void

  [Virtual Method] writeDoubleNoTag(D) -> V
    // registers=5, ins=3, outs=3, insns_size=8
    0000: invoke-static {v3, v4}, Ljava/lang/Double;->doubleToRawLongBits(D)J
    0003: move-result-wide v0
    0004: invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeRawLittleEndian64(J)V
    0007: return-void

  [Virtual Method] writeEnum(I, I) -> V
    // registers=4, ins=3, outs=3, insns_size=8
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeEnumNoTag(I)V
    0007: return-void

  [Virtual Method] writeEnumNoTag(I) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeInt32NoTag(I)V
    0003: return-void

  [Virtual Method] writeFixed32(I, I) -> V
    // registers=4, ins=3, outs=3, insns_size=8
    0000: const/4 v0, 5
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeFixed32NoTag(I)V
    0007: return-void

  [Virtual Method] writeFixed32NoTag(I) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeRawLittleEndian32(I)V
    0003: return-void

  [Virtual Method] writeFixed64(I, J) -> V
    // registers=5, ins=4, outs=3, insns_size=8
    0000: const/4 v0, 1
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3, v4}, Lcom/google/protobuf/CodedOutputStream;->writeFixed64NoTag(J)V
    0007: return-void

  [Virtual Method] writeFixed64NoTag(J) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeRawLittleEndian64(J)V
    0003: return-void

  [Virtual Method] writeFloat(I, F) -> V
    // registers=4, ins=3, outs=3, insns_size=8
    0000: const/4 v0, 5
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeFloatNoTag(F)V
    0007: return-void

  [Virtual Method] writeFloatNoTag(F) -> V
    // registers=3, ins=2, outs=2, insns_size=8
    0000: invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I
    0003: move-result v0
    0004: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawLittleEndian32(I)V
    0007: return-void

  [Virtual Method] writeGroup(I, Lcom/google/protobuf/MessageLite;) -> V
    // registers=4, ins=3, outs=3, insns_size=12
    0000: const/4 v0, 3
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeGroupNoTag(Lcom/google/protobuf/MessageLite;)V
    0007: const/4 v0, 4
    0008: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    000b: return-void

  [Virtual Method] writeGroupNoTag(Lcom/google/protobuf/MessageLite;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-interface {v1, v0}, Lcom/google/protobuf/MessageLite;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    0003: return-void

  [Virtual Method] writeInt32(I, I) -> V
    // registers=4, ins=3, outs=3, insns_size=8
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeInt32NoTag(I)V
    0007: return-void

  [Virtual Method] writeInt32NoTag(I) -> V
    // registers=4, ins=2, outs=3, insns_size=11
    0000: if-ltz v3, 0006
    0002: invoke-virtual {v2, v3}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint32(I)V
    0005: return-void
    0006: unop(op=81) v0, v3
    0007: invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint64(J)V
    000a: goto 0005

  [Virtual Method] writeInt64(I, J) -> V
    // registers=5, ins=4, outs=3, insns_size=8
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3, v4}, Lcom/google/protobuf/CodedOutputStream;->writeInt64NoTag(J)V
    0007: return-void

  [Virtual Method] writeInt64NoTag(J) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint64(J)V
    0003: return-void

  [Virtual Method] writeMessage(I, Lcom/google/protobuf/MessageLite;) -> V
    // registers=4, ins=3, outs=3, insns_size=8
    0000: const/4 v0, 2
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeMessageNoTag(Lcom/google/protobuf/MessageLite;)V
    0007: return-void

  [Virtual Method] writeMessageNoTag(Lcom/google/protobuf/MessageLite;) -> V
    // registers=3, ins=2, outs=2, insns_size=11
    0000: invoke-interface {v2}, Lcom/google/protobuf/MessageLite;->getSerializedSize()I
    0003: move-result v0
    0004: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint32(I)V
    0007: invoke-interface {v2, v1}, Lcom/google/protobuf/MessageLite;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    000a: return-void

  [Virtual Method] writeMessageSetExtension(I, Lcom/google/protobuf/MessageLite;) -> V
    // registers=6, ins=3, outs=3, insns_size=17
    0000: const/4 v2, 3
    0001: const/4 v1, 1
    0002: invoke-virtual {v3, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0005: const/4 v0, 2
    0006: invoke-virtual {v3, v0, v4}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32(II)V
    0009: invoke-virtual {v3, v2, v5}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V
    000c: const/4 v0, 4
    000d: invoke-virtual {v3, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0010: return-void

  [Virtual Method] writeRawByte(B) -> V
    // registers=5, ins=2, outs=1, insns_size=20
    0000: iget v0, v3.Lcom/google/protobuf/CodedOutputStream;->position:I
    0002: iget v1, v3.Lcom/google/protobuf/CodedOutputStream;->limit:I
    0004: if-ne v0, v1, 0009
    0006: invoke-direct {v3}, Lcom/google/protobuf/CodedOutputStream;->refreshBuffer()V
    0009: iget v0, v3.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    000b: iget v1, v3.Lcom/google/protobuf/CodedOutputStream;->position:I
    000d: binop/lit8(op=d8) v2, v1, 1 (0x1)
    000f: iput v2, v3.Lcom/google/protobuf/CodedOutputStream;->position:I
    0011: aput(op=4f) v4, v0[v1]
    0013: return-void

  [Virtual Method] writeRawByte(I) -> V
    // registers=3, ins=2, outs=2, insns_size=5
    0000: unop(op=8d) v0, v2
    0001: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(B)V
    0004: return-void

  [Virtual Method] writeRawBytes(Lcom/google/protobuf/ByteString;) -> V
    // registers=4, ins=2, outs=4, insns_size=9
    0000: const/4 v0, 0
    0001: invoke-virtual {v3}, Lcom/google/protobuf/ByteString;->size()I
    0004: move-result v1
    0005: invoke-virtual {v2, v3, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeRawBytes(Lcom/google/protobuf/ByteString;II)V
    0008: return-void

  [Virtual Method] writeRawBytes(Lcom/google/protobuf/ByteString;, I, I) -> V
    // registers=12, ins=4, outs=5, insns_size=110
    0000: const/4 v7, 0
    0001: iget v0, v8.Lcom/google/protobuf/CodedOutputStream;->limit:I
    0003: iget v1, v8.Lcom/google/protobuf/CodedOutputStream;->position:I
    0005: binop/2addr(op=b1) v0, v1
    0006: if-lt v0, v11, 0015
    0008: iget v0, v8.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    000a: iget v1, v8.Lcom/google/protobuf/CodedOutputStream;->position:I
    000c: invoke-virtual {v9, v0, v10, v1, v11}, Lcom/google/protobuf/ByteString;->copyTo([BIII)V
    000f: iget v0, v8.Lcom/google/protobuf/CodedOutputStream;->position:I
    0011: binop/2addr(op=b0) v0, v11
    0012: iput v0, v8.Lcom/google/protobuf/CodedOutputStream;->position:I
    0014: return-void
    0015: iget v0, v8.Lcom/google/protobuf/CodedOutputStream;->limit:I
    0017: iget v1, v8.Lcom/google/protobuf/CodedOutputStream;->position:I
    0019: binop/2addr(op=b1) v0, v1
    001a: iget v1, v8.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    001c: iget v2, v8.Lcom/google/protobuf/CodedOutputStream;->position:I
    001e: invoke-virtual {v9, v1, v10, v2, v0}, Lcom/google/protobuf/ByteString;->copyTo([BIII)V
    0021: binop(op=90) v1, v10, v0
    0023: binop(op=91) v0, v11, v0
    0025: iget v2, v8.Lcom/google/protobuf/CodedOutputStream;->limit:I
    0027: iput v2, v8.Lcom/google/protobuf/CodedOutputStream;->position:I
    0029: invoke-direct {v8}, Lcom/google/protobuf/CodedOutputStream;->refreshBuffer()V
    002c: iget v2, v8.Lcom/google/protobuf/CodedOutputStream;->limit:I
    002e: if-gt v0, v2, 0038
    0030: iget v2, v8.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    0032: invoke-virtual {v9, v2, v1, v7, v0}, Lcom/google/protobuf/ByteString;->copyTo([BIII)V
    0035: iput v0, v8.Lcom/google/protobuf/CodedOutputStream;->position:I
    0037: goto 0014
    0038: invoke-virtual {v9}, Lcom/google/protobuf/ByteString;->newInput()Ljava/io/InputStream;
    003b: move-result-object v2
    003c: unop(op=81) v3, v1
    003d: unop(op=81) v5, v1
    003e: invoke-virtual {v2, v5, v6}, Ljava/io/InputStream;->skip(J)J
    0041: move-result-wide v5
    0042: cmp(op=31) v1, v3, v5
    0044: if-eqz v1, 0056
    0046: new-instance v0, Ljava/lang/IllegalStateException;
    0048: const-string v1, 'Skip failed? Should never happen.'
    004a: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    004d: throw v0
    004e: iget v1, v8.Lcom/google/protobuf/CodedOutputStream;->output:Ljava/io/OutputStream;
    0050: iget v4, v8.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    0052: invoke-virtual {v1, v4, v7, v3}, Ljava/io/OutputStream;->write([BII)V
    0055: binop/2addr(op=b1) v0, v3
    0056: if-lez v0, 0014
    0058: iget v1, v8.Lcom/google/protobuf/CodedOutputStream;->limit:I
    005a: invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I
    005d: move-result v1
    005e: iget v3, v8.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    0060: invoke-virtual {v2, v3, v7, v1}, Ljava/io/InputStream;->read([BII)I
    0063: move-result v3
    0064: if-eq v3, v1, 004e
    0066: new-instance v0, Ljava/lang/IllegalStateException;
    0068: const-string v1, 'Read failed? Should never happen'
    006a: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    006d: throw v0

  [Virtual Method] writeRawBytes([B) -> V
    // registers=4, ins=2, outs=4, insns_size=6
    0000: const/4 v0, 0
    0001: move(op=21) v1, v3
    0002: invoke-virtual {v2, v3, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeRawBytes([BII)V
    0005: return-void

  [Virtual Method] writeRawBytes([B, I, I) -> V
    // registers=8, ins=4, outs=5, insns_size=62
    0000: iget v0, v4.Lcom/google/protobuf/CodedOutputStream;->limit:I
    0002: iget v1, v4.Lcom/google/protobuf/CodedOutputStream;->position:I
    0004: binop/2addr(op=b1) v0, v1
    0005: if-lt v0, v7, 0014
    0007: iget v0, v4.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    0009: iget v1, v4.Lcom/google/protobuf/CodedOutputStream;->position:I
    000b: invoke-static {v5, v6, v0, v1, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    000e: iget v0, v4.Lcom/google/protobuf/CodedOutputStream;->position:I
    0010: binop/2addr(op=b0) v0, v7
    0011: iput v0, v4.Lcom/google/protobuf/CodedOutputStream;->position:I
    0013: return-void
    0014: iget v0, v4.Lcom/google/protobuf/CodedOutputStream;->limit:I
    0016: iget v1, v4.Lcom/google/protobuf/CodedOutputStream;->position:I
    0018: binop/2addr(op=b1) v0, v1
    0019: iget v1, v4.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    001b: iget v2, v4.Lcom/google/protobuf/CodedOutputStream;->position:I
    001d: invoke-static {v5, v6, v1, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0020: binop(op=90) v1, v6, v0
    0022: binop(op=91) v0, v7, v0
    0024: iget v2, v4.Lcom/google/protobuf/CodedOutputStream;->limit:I
    0026: iput v2, v4.Lcom/google/protobuf/CodedOutputStream;->position:I
    0028: invoke-direct {v4}, Lcom/google/protobuf/CodedOutputStream;->refreshBuffer()V
    002b: iget v2, v4.Lcom/google/protobuf/CodedOutputStream;->limit:I
    002d: if-gt v0, v2, 0038
    002f: iget v2, v4.Lcom/google/protobuf/CodedOutputStream;->buffer:[B
    0031: const/4 v3, 0
    0032: invoke-static {v5, v1, v2, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0035: iput v0, v4.Lcom/google/protobuf/CodedOutputStream;->position:I
    0037: goto 0013
    0038: iget v2, v4.Lcom/google/protobuf/CodedOutputStream;->output:Ljava/io/OutputStream;
    003a: invoke-virtual {v2, v5, v1, v0}, Ljava/io/OutputStream;->write([BII)V
    003d: goto 0013

  [Virtual Method] writeRawLittleEndian32(I) -> V
    // registers=3, ins=2, outs=2, insns_size=27
    0000: binop/lit16(op=d5) v0, v2, 255 (0xff)
    0002: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    0005: binop/lit8(op=e1) v0, v2, 8 (0x8)
    0007: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0009: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    000c: binop/lit8(op=e1) v0, v2, 16 (0x10)
    000e: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0010: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    0013: binop/lit8(op=e1) v0, v2, 24 (0x18)
    0015: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0017: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    001a: return-void

  [Virtual Method] writeRawLittleEndian64(J) -> V
    // registers=5, ins=3, outs=2, insns_size=77
    0000: unop(op=84) v0, v3
    0001: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0003: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    0006: const/16 v0, 8 (0x8)
    0008: binop(op=a4) v0, v3, v0
    000a: unop(op=84) v0, v0
    000b: binop/lit16(op=d5) v0, v0, 255 (0xff)
    000d: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    0010: const/16 v0, 16 (0x10)
    0012: binop(op=a4) v0, v3, v0
    0014: unop(op=84) v0, v0
    0015: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0017: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    001a: const/16 v0, 24 (0x18)
    001c: binop(op=a4) v0, v3, v0
    001e: unop(op=84) v0, v0
    001f: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0021: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    0024: const/16 v0, 32 (0x20)
    0026: binop(op=a4) v0, v3, v0
    0028: unop(op=84) v0, v0
    0029: binop/lit16(op=d5) v0, v0, 255 (0xff)
    002b: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    002e: const/16 v0, 40 (0x28)
    0030: binop(op=a4) v0, v3, v0
    0032: unop(op=84) v0, v0
    0033: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0035: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    0038: const/16 v0, 48 (0x30)
    003a: binop(op=a4) v0, v3, v0
    003c: unop(op=84) v0, v0
    003d: binop/lit16(op=d5) v0, v0, 255 (0xff)
    003f: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    0042: const/16 v0, 56 (0x38)
    0044: binop(op=a4) v0, v3, v0
    0046: unop(op=84) v0, v0
    0047: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0049: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    004c: return-void

  [Virtual Method] writeRawMessageSetExtension(I, Lcom/google/protobuf/ByteString;) -> V
    // registers=6, ins=3, outs=3, insns_size=17
    0000: const/4 v2, 3
    0001: const/4 v1, 1
    0002: invoke-virtual {v3, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0005: const/4 v0, 2
    0006: invoke-virtual {v3, v0, v4}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32(II)V
    0009: invoke-virtual {v3, v2, v5}, Lcom/google/protobuf/CodedOutputStream;->writeBytes(ILcom/google/protobuf/ByteString;)V
    000c: const/4 v0, 4
    000d: invoke-virtual {v3, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0010: return-void

  [Virtual Method] writeRawVarint32(I) -> V
    // registers=3, ins=2, outs=2, insns_size=18
    0000: binop/lit8(op=dd) v0, v2, -128 (-0x80)
    0002: if-nez v0, 0008
    0004: invoke-virtual {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    0007: return-void
    0008: binop/lit8(op=dd) v0, v2, 127 (0x7f)
    000a: binop/lit16(op=d6) v0, v0, 128 (0x80)
    000c: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    000f: binop/lit8(op=e2) v2, v2, 7 (0x7)
    0011: goto 0000

  [Virtual Method] writeRawVarint64(J) -> V
    // registers=7, ins=3, outs=2, insns_size=25
    0000: const-wide/16 v0, -128
    0002: binop/2addr(op=c0) v0, v5
    0003: const-wide/16 v2, 0
    0005: cmp(op=31) v0, v0, v2
    0007: if-nez v0, 000e
    0009: unop(op=84) v0, v5
    000a: invoke-virtual {v4, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    000d: return-void
    000e: unop(op=84) v0, v5
    000f: binop/lit8(op=dd) v0, v0, 127 (0x7f)
    0011: binop/lit16(op=d6) v0, v0, 128 (0x80)
    0013: invoke-virtual {v4, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawByte(I)V
    0016: const/4 v0, 7
    0017: binop/2addr(op=c5) v5, v0
    0018: goto 0000

  [Virtual Method] writeSFixed32(I, I) -> V
    // registers=4, ins=3, outs=3, insns_size=8
    0000: const/4 v0, 5
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeSFixed32NoTag(I)V
    0007: return-void

  [Virtual Method] writeSFixed32NoTag(I) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeRawLittleEndian32(I)V
    0003: return-void

  [Virtual Method] writeSFixed64(I, J) -> V
    // registers=5, ins=4, outs=3, insns_size=8
    0000: const/4 v0, 1
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3, v4}, Lcom/google/protobuf/CodedOutputStream;->writeSFixed64NoTag(J)V
    0007: return-void

  [Virtual Method] writeSFixed64NoTag(J) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeRawLittleEndian64(J)V
    0003: return-void

  [Virtual Method] writeSInt32(I, I) -> V
    // registers=4, ins=3, outs=3, insns_size=8
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeSInt32NoTag(I)V
    0007: return-void

  [Virtual Method] writeSInt32NoTag(I) -> V
    // registers=3, ins=2, outs=2, insns_size=8
    0000: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->encodeZigZag32(I)I
    0003: move-result v0
    0004: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint32(I)V
    0007: return-void

  [Virtual Method] writeSInt64(I, J) -> V
    // registers=5, ins=4, outs=3, insns_size=8
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3, v4}, Lcom/google/protobuf/CodedOutputStream;->writeSInt64NoTag(J)V
    0007: return-void

  [Virtual Method] writeSInt64NoTag(J) -> V
    // registers=5, ins=3, outs=3, insns_size=8
    0000: invoke-static {v3, v4}, Lcom/google/protobuf/CodedOutputStream;->encodeZigZag64(J)J
    0003: move-result-wide v0
    0004: invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint64(J)V
    0007: return-void

  [Virtual Method] writeString(I, Ljava/lang/String;) -> V
    // registers=4, ins=3, outs=3, insns_size=8
    0000: const/4 v0, 2
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeStringNoTag(Ljava/lang/String;)V
    0007: return-void

  [Virtual Method] writeStringNoTag(Ljava/lang/String;) -> V
    // registers=4, ins=2, outs=2, insns_size=14
    0000: const-string v0, 'UTF-8'
    0002: invoke-virtual {v3, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B
    0005: move-result-object v0
    0006: move(op=21) v1, v0
    0007: invoke-virtual {v2, v1}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint32(I)V
    000a: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawBytes([B)V
    000d: return-void

  [Virtual Method] writeTag(I, I) -> V
    // registers=4, ins=3, outs=2, insns_size=8
    0000: invoke-static {v2, v3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I
    0003: move-result v0
    0004: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint32(I)V
    0007: return-void

  [Virtual Method] writeUInt32(I, I) -> V
    // registers=4, ins=3, outs=3, insns_size=8
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V
    0007: return-void

  [Virtual Method] writeUInt32NoTag(I) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint32(I)V
    0003: return-void

  [Virtual Method] writeUInt64(I, J) -> V
    // registers=5, ins=4, outs=3, insns_size=8
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0004: invoke-virtual {v1, v3, v4}, Lcom/google/protobuf/CodedOutputStream;->writeUInt64NoTag(J)V
    0007: return-void

  [Virtual Method] writeUInt64NoTag(J) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint64(J)V
    0003: return-void

  [Virtual Method] writeUnknownGroup(I, Lcom/google/protobuf/MessageLite;) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeGroup(ILcom/google/protobuf/MessageLite;)V
    0003: return-void

  [Virtual Method] writeUnknownGroupNoTag(Lcom/google/protobuf/MessageLite;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeGroupNoTag(Lcom/google/protobuf/MessageLite;)V
    0003: return-void