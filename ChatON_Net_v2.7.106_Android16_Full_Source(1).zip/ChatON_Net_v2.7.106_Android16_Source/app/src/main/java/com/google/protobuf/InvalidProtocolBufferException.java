=== CLASS Lcom/google/protobuf/InvalidProtocolBufferException; (Source: InvalidProtocolBufferException.java) ===
  Super: Ljava/io/IOException;
  [Static Field] serialVersionUID: J = -1616151763072450476

  [Direct Method] <init>(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    0003: return-void

  [Direct Method] invalidEndTag() -> Lcom/google/protobuf/InvalidProtocolBufferException;
    // registers=2, ins=0, outs=2, insns_size=8
    0000: new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;
    0002: const-string v1, 'Protocol message end-group tag did not match expected tag.'
    0004: invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V
    0007: return-object v0

  [Direct Method] invalidTag() -> Lcom/google/protobuf/InvalidProtocolBufferException;
    // registers=2, ins=0, outs=2, insns_size=8
    0000: new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;
    0002: const-string v1, 'Protocol message contained an invalid tag (zero).'
    0004: invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V
    0007: return-object v0

  [Direct Method] invalidWireType() -> Lcom/google/protobuf/InvalidProtocolBufferException;
    // registers=2, ins=0, outs=2, insns_size=8
    0000: new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;
    0002: const-string v1, 'Protocol message tag had invalid wire type.'
    0004: invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V
    0007: return-object v0

  [Direct Method] malformedVarint() -> Lcom/google/protobuf/InvalidProtocolBufferException;
    // registers=2, ins=0, outs=2, insns_size=8
    0000: new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;
    0002: const-string v1, 'CodedInputStream encountered a malformed varint.'
    0004: invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V
    0007: return-object v0

  [Direct Method] negativeSize() -> Lcom/google/protobuf/InvalidProtocolBufferException;
    // registers=2, ins=0, outs=2, insns_size=8
    0000: new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;
    0002: const-string v1, 'CodedInputStream encountered an embedded string or message which claimed to have negative size.'
    0004: invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V
    0007: return-object v0

  [Direct Method] recursionLimitExceeded() -> Lcom/google/protobuf/InvalidProtocolBufferException;
    // registers=2, ins=0, outs=2, insns_size=8
    0000: new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;
    0002: const-string v1, 'Protocol message had too'
    0004: invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V
    0007: return-object v0

  [Direct Method] sizeLimitExceeded() -> Lcom/google/protobuf/InvalidProtocolBufferException;
    // registers=2, ins=0, outs=2, insns_size=8
    0000: new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;
    0002: const-string v1, 'Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.'
    0004: invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V
    0007: return-object v0

  [Direct Method] truncatedMessage() -> Lcom/google/protobuf/InvalidProtocolBufferException;
    // registers=2, ins=0, outs=2, insns_size=8
    0000: new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;
    0002: const-string v1, 'While parsing a protocol'
    0004: invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V
    0007: return-object v0