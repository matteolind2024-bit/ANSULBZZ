=== CLASS Lcom/google/protobuf/UnmodifiableLazyStringList$2; (Source: UnmodifiableLazyStringList.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/util/Iterator;
  [Instance Field] iter: Ljava/util/Iterator;
  [Instance Field] this$0: Lcom/google/protobuf/UnmodifiableLazyStringList;

  [Direct Method] <init>(Lcom/google/protobuf/UnmodifiableLazyStringList;) -> V
    // registers=3, ins=2, outs=1, insns_size=18
    0000: iput v2, v1.Lcom/google/protobuf/UnmodifiableLazyStringList$2;->this$0:Lcom/google/protobuf/UnmodifiableLazyStringList;
    0002: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0005: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList$2;->this$0:Lcom/google/protobuf/UnmodifiableLazyStringList;
    0007: invoke-static {v0}, Lcom/google/protobuf/UnmodifiableLazyStringList;->access$000(Lcom/google/protobuf/UnmodifiableLazyStringList;)Lcom/google/protobuf/LazyStringList;
    000a: move-result-object v0
    000b: invoke-interface {v0}, Lcom/google/protobuf/LazyStringList;->iterator()Ljava/util/Iterator;
    000e: move-result-object v0
    000f: iput v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList$2;->iter:Ljava/util/Iterator;
    0011: return-void

  [Virtual Method] hasNext() -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList$2;->iter:Ljava/util/Iterator;
    0002: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] next() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/UnmodifiableLazyStringList$2;->next()Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] next() -> Ljava/lang/String;
    // registers=2, ins=1, outs=1, insns_size=9
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList$2;->iter:Ljava/util/Iterator;
    0002: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Ljava/lang/String;
    0008: return-object v0

  [Virtual Method] remove() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: new-instance v0, Ljava/lang/UnsupportedOperationException;
    0002: invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V
    0005: throw v0