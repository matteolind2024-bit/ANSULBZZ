=== CLASS Lcom/google/protobuf/UnmodifiableLazyStringList; (Source: UnmodifiableLazyStringList.java) ===
  Super: Ljava/util/AbstractList;
  Interfaces: Lcom/google/protobuf/LazyStringList;, Ljava/util/RandomAccess;
  [Instance Field] list: Lcom/google/protobuf/LazyStringList;

  [Direct Method] <init>(Lcom/google/protobuf/LazyStringList;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: invoke-direct {v0}, Ljava/util/AbstractList;-><init>()V
    0003: iput v1, v0.Lcom/google/protobuf/UnmodifiableLazyStringList;->list:Lcom/google/protobuf/LazyStringList;
    0005: return-void

  [Direct Method] access$000(Lcom/google/protobuf/UnmodifiableLazyStringList;) -> Lcom/google/protobuf/LazyStringList;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList;->list:Lcom/google/protobuf/LazyStringList;
    0002: return-object v0

  [Virtual Method] add(Lcom/google/protobuf/ByteString;) -> V
    // registers=3, ins=2, outs=1, insns_size=6
    0000: new-instance v0, Ljava/lang/UnsupportedOperationException;
    0002: invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V
    0005: throw v0

  [Virtual Method] get(I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Lcom/google/protobuf/UnmodifiableLazyStringList;->get(I)Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] get(I) -> Ljava/lang/String;
    // registers=3, ins=2, outs=2, insns_size=9
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList;->list:Lcom/google/protobuf/LazyStringList;
    0002: invoke-interface {v0, v2}, Lcom/google/protobuf/LazyStringList;->get(I)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Ljava/lang/String;
    0008: return-object v0

  [Virtual Method] getByteString(I) -> Lcom/google/protobuf/ByteString;
    // registers=3, ins=2, outs=2, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList;->list:Lcom/google/protobuf/LazyStringList;
    0002: invoke-interface {v0, v2}, Lcom/google/protobuf/LazyStringList;->getByteString(I)Lcom/google/protobuf/ByteString;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] iterator() -> Ljava/util/Iterator;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Lcom/google/protobuf/UnmodifiableLazyStringList$2;
    0002: invoke-direct {v0, v1}, Lcom/google/protobuf/UnmodifiableLazyStringList$2;-><init>(Lcom/google/protobuf/UnmodifiableLazyStringList;)V
    0005: return-object v0

  [Virtual Method] listIterator(I) -> Ljava/util/ListIterator;
    // registers=3, ins=2, outs=3, insns_size=6
    0000: new-instance v0, Lcom/google/protobuf/UnmodifiableLazyStringList$1;
    0002: invoke-direct {v0, v1, v2}, Lcom/google/protobuf/UnmodifiableLazyStringList$1;-><init>(Lcom/google/protobuf/UnmodifiableLazyStringList;I)V
    0005: return-object v0

  [Virtual Method] size() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/UnmodifiableLazyStringList;->list:Lcom/google/protobuf/LazyStringList;
    0002: invoke-interface {v0}, Lcom/google/protobuf/LazyStringList;->size()I
    0005: move-result v0
    0006: return v0