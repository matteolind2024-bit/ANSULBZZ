=== CLASS Lcom/google/protobuf/WireFormat$FieldType; (Source: WireFormat.java) ===
  Super: Ljava/lang/Enum;
  [Static Field] $VALUES: [Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] BOOL: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] BYTES: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] DOUBLE: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] ENUM: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] FIXED32: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] FIXED64: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] FLOAT: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] GROUP: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] INT32: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] INT64: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] MESSAGE: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] SFIXED32: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] SFIXED64: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] SINT32: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] SINT64: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] STRING: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] UINT32: Lcom/google/protobuf/WireFormat$FieldType;
  [Static Field] UINT64: Lcom/google/protobuf/WireFormat$FieldType;
  [Instance Field] javaType: Lcom/google/protobuf/WireFormat$JavaType;
  [Instance Field] wireType: I

  [Direct Method] <clinit>() -> V
    // registers=9, ins=0, outs=5, insns_size=328
    0000: const/4 v8, 3
    0001: const/4 v7, 5
    0002: const/4 v6, 2
    0003: const/4 v5, 1
    0004: const/4 v4, 0
    0005: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    0007: const-string v1, 'DOUBLE'
    0009: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->DOUBLE:Lcom/google/protobuf/WireFormat$JavaType;
    000b: invoke-direct {v0, v1, v4, v2, v5}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    000e: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->DOUBLE:Lcom/google/protobuf/WireFormat$FieldType;
    0010: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    0012: const-string v1, 'FLOAT'
    0014: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->FLOAT:Lcom/google/protobuf/WireFormat$JavaType;
    0016: invoke-direct {v0, v1, v5, v2, v7}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    0019: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->FLOAT:Lcom/google/protobuf/WireFormat$FieldType;
    001b: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    001d: const-string v1, 'INT64'
    001f: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->LONG:Lcom/google/protobuf/WireFormat$JavaType;
    0021: invoke-direct {v0, v1, v6, v2, v4}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    0024: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->INT64:Lcom/google/protobuf/WireFormat$FieldType;
    0026: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    0028: const-string v1, 'UINT64'
    002a: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->LONG:Lcom/google/protobuf/WireFormat$JavaType;
    002c: invoke-direct {v0, v1, v8, v2, v4}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    002f: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->UINT64:Lcom/google/protobuf/WireFormat$FieldType;
    0031: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    0033: const-string v1, 'INT32'
    0035: const/4 v2, 4
    0036: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->INT:Lcom/google/protobuf/WireFormat$JavaType;
    0038: invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    003b: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->INT32:Lcom/google/protobuf/WireFormat$FieldType;
    003d: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    003f: const-string v1, 'FIXED64'
    0041: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->LONG:Lcom/google/protobuf/WireFormat$JavaType;
    0043: invoke-direct {v0, v1, v7, v2, v5}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    0046: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->FIXED64:Lcom/google/protobuf/WireFormat$FieldType;
    0048: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    004a: const-string v1, 'FIXED32'
    004c: const/4 v2, 6
    004d: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->INT:Lcom/google/protobuf/WireFormat$JavaType;
    004f: invoke-direct {v0, v1, v2, v3, v7}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    0052: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->FIXED32:Lcom/google/protobuf/WireFormat$FieldType;
    0054: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    0056: const-string v1, 'BOOL'
    0058: const/4 v2, 7
    0059: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->BOOLEAN:Lcom/google/protobuf/WireFormat$JavaType;
    005b: invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    005e: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->BOOL:Lcom/google/protobuf/WireFormat$FieldType;
    0060: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType$1;
    0062: const-string v1, 'STRING'
    0064: const/16 v2, 8 (0x8)
    0066: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->STRING:Lcom/google/protobuf/WireFormat$JavaType;
    0068: invoke-direct {v0, v1, v2, v3, v6}, Lcom/google/protobuf/WireFormat$FieldType$1;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    006b: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->STRING:Lcom/google/protobuf/WireFormat$FieldType;
    006d: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType$2;
    006f: const-string v1, 'GROUP'
    0071: const/16 v2, 9 (0x9)
    0073: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;
    0075: invoke-direct {v0, v1, v2, v3, v8}, Lcom/google/protobuf/WireFormat$FieldType$2;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    0078: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->GROUP:Lcom/google/protobuf/WireFormat$FieldType;
    007a: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType$3;
    007c: const-string v1, 'MESSAGE'
    007e: const/16 v2, 10 (0xa)
    0080: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;
    0082: invoke-direct {v0, v1, v2, v3, v6}, Lcom/google/protobuf/WireFormat$FieldType$3;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    0085: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->MESSAGE:Lcom/google/protobuf/WireFormat$FieldType;
    0087: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType$4;
    0089: const-string v1, 'BYTES'
    008b: const/16 v2, 11 (0xb)
    008d: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->BYTE_STRING:Lcom/google/protobuf/WireFormat$JavaType;
    008f: invoke-direct {v0, v1, v2, v3, v6}, Lcom/google/protobuf/WireFormat$FieldType$4;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    0092: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->BYTES:Lcom/google/protobuf/WireFormat$FieldType;
    0094: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    0096: const-string v1, 'UINT32'
    0098: const/16 v2, 12 (0xc)
    009a: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->INT:Lcom/google/protobuf/WireFormat$JavaType;
    009c: invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    009f: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->UINT32:Lcom/google/protobuf/WireFormat$FieldType;
    00a1: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    00a3: const-string v1, 'ENUM'
    00a5: const/16 v2, 13 (0xd)
    00a7: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->ENUM:Lcom/google/protobuf/WireFormat$JavaType;
    00a9: invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    00ac: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->ENUM:Lcom/google/protobuf/WireFormat$FieldType;
    00ae: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    00b0: const-string v1, 'SFIXED32'
    00b2: const/16 v2, 14 (0xe)
    00b4: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->INT:Lcom/google/protobuf/WireFormat$JavaType;
    00b6: invoke-direct {v0, v1, v2, v3, v7}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    00b9: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->SFIXED32:Lcom/google/protobuf/WireFormat$FieldType;
    00bb: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    00bd: const-string v1, 'SFIXED64'
    00bf: const/16 v2, 15 (0xf)
    00c1: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->LONG:Lcom/google/protobuf/WireFormat$JavaType;
    00c3: invoke-direct {v0, v1, v2, v3, v5}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    00c6: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->SFIXED64:Lcom/google/protobuf/WireFormat$FieldType;
    00c8: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    00ca: const-string v1, 'SINT32'
    00cc: const/16 v2, 16 (0x10)
    00ce: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->INT:Lcom/google/protobuf/WireFormat$JavaType;
    00d0: invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    00d3: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->SINT32:Lcom/google/protobuf/WireFormat$FieldType;
    00d5: new-instance v0, Lcom/google/protobuf/WireFormat$FieldType;
    00d7: const-string v1, 'SINT64'
    00d9: const/16 v2, 17 (0x11)
    00db: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->LONG:Lcom/google/protobuf/WireFormat$JavaType;
    00dd: invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    00e0: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->SINT64:Lcom/google/protobuf/WireFormat$FieldType;
    00e2: const/16 v0, 18 (0x12)
    00e4: new-array v0, v0, [Lcom/google/protobuf/WireFormat$FieldType;
    00e6: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->DOUBLE:Lcom/google/protobuf/WireFormat$FieldType;
    00e8: aput(op=4d) v1, v0[v4]
    00ea: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->FLOAT:Lcom/google/protobuf/WireFormat$FieldType;
    00ec: aput(op=4d) v1, v0[v5]
    00ee: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->INT64:Lcom/google/protobuf/WireFormat$FieldType;
    00f0: aput(op=4d) v1, v0[v6]
    00f2: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->UINT64:Lcom/google/protobuf/WireFormat$FieldType;
    00f4: aput(op=4d) v1, v0[v8]
    00f6: const/4 v1, 4
    00f7: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->INT32:Lcom/google/protobuf/WireFormat$FieldType;
    00f9: aput(op=4d) v2, v0[v1]
    00fb: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->FIXED64:Lcom/google/protobuf/WireFormat$FieldType;
    00fd: aput(op=4d) v1, v0[v7]
    00ff: const/4 v1, 6
    0100: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->FIXED32:Lcom/google/protobuf/WireFormat$FieldType;
    0102: aput(op=4d) v2, v0[v1]
    0104: const/4 v1, 7
    0105: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->BOOL:Lcom/google/protobuf/WireFormat$FieldType;
    0107: aput(op=4d) v2, v0[v1]
    0109: const/16 v1, 8 (0x8)
    010b: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->STRING:Lcom/google/protobuf/WireFormat$FieldType;
    010d: aput(op=4d) v2, v0[v1]
    010f: const/16 v1, 9 (0x9)
    0111: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->GROUP:Lcom/google/protobuf/WireFormat$FieldType;
    0113: aput(op=4d) v2, v0[v1]
    0115: const/16 v1, 10 (0xa)
    0117: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->MESSAGE:Lcom/google/protobuf/WireFormat$FieldType;
    0119: aput(op=4d) v2, v0[v1]
    011b: const/16 v1, 11 (0xb)
    011d: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->BYTES:Lcom/google/protobuf/WireFormat$FieldType;
    011f: aput(op=4d) v2, v0[v1]
    0121: const/16 v1, 12 (0xc)
    0123: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->UINT32:Lcom/google/protobuf/WireFormat$FieldType;
    0125: aput(op=4d) v2, v0[v1]
    0127: const/16 v1, 13 (0xd)
    0129: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->ENUM:Lcom/google/protobuf/WireFormat$FieldType;
    012b: aput(op=4d) v2, v0[v1]
    012d: const/16 v1, 14 (0xe)
    012f: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->SFIXED32:Lcom/google/protobuf/WireFormat$FieldType;
    0131: aput(op=4d) v2, v0[v1]
    0133: const/16 v1, 15 (0xf)
    0135: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->SFIXED64:Lcom/google/protobuf/WireFormat$FieldType;
    0137: aput(op=4d) v2, v0[v1]
    0139: const/16 v1, 16 (0x10)
    013b: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->SINT32:Lcom/google/protobuf/WireFormat$FieldType;
    013d: aput(op=4d) v2, v0[v1]
    013f: const/16 v1, 17 (0x11)
    0141: sget v2, Lcom/google/protobuf/WireFormat$FieldType;->SINT64:Lcom/google/protobuf/WireFormat$FieldType;
    0143: aput(op=4d) v2, v0[v1]
    0145: sput v0, Lcom/google/protobuf/WireFormat$FieldType;->$VALUES:[Lcom/google/protobuf/WireFormat$FieldType;
    0147: return-void

  [Direct Method] <init>(Ljava/lang/String;, I, Lcom/google/protobuf/WireFormat$JavaType;, I) -> V
    // registers=5, ins=5, outs=3, insns_size=8
    0000: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    0003: iput v3, v0.Lcom/google/protobuf/WireFormat$FieldType;->javaType:Lcom/google/protobuf/WireFormat$JavaType;
    0005: iput v4, v0.Lcom/google/protobuf/WireFormat$FieldType;->wireType:I
    0007: return-void

  [Direct Method] <init>(Ljava/lang/String;, I, Lcom/google/protobuf/WireFormat$JavaType;, I, Lcom/google/protobuf/WireFormat$1;) -> V
    // registers=6, ins=6, outs=5, insns_size=4
    0000: invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/protobuf/WireFormat$FieldType;-><init>(Ljava/lang/String;ILcom/google/protobuf/WireFormat$JavaType;I)V
    0003: return-void

  [Direct Method] valueOf(Ljava/lang/String;) -> Lcom/google/protobuf/WireFormat$FieldType;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: const-class v0, Lcom/google/protobuf/WireFormat$FieldType;
    0002: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    0005: move-result-object v0
    0006: check-cast v0, Lcom/google/protobuf/WireFormat$FieldType;
    0008: return-object v0

  [Direct Method] values() -> [Lcom/google/protobuf/WireFormat$FieldType;
    // registers=1, ins=0, outs=1, insns_size=9
    0000: sget v0, Lcom/google/protobuf/WireFormat$FieldType;->$VALUES:[Lcom/google/protobuf/WireFormat$FieldType;
    0002: invoke-virtual {v0}, [Lcom/google/protobuf/WireFormat$FieldType;->clone()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, [Lcom/google/protobuf/WireFormat$FieldType;
    0008: return-object v0

  [Virtual Method] getJavaType() -> Lcom/google/protobuf/WireFormat$JavaType;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/WireFormat$FieldType;->javaType:Lcom/google/protobuf/WireFormat$JavaType;
    0002: return-object v0

  [Virtual Method] getWireType() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/WireFormat$FieldType;->wireType:I
    0002: return v0

  [Virtual Method] isPackable() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0