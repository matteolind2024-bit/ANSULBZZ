=== CLASS Lcom/google/protobuf/UninitializedMessageException; (Source: UninitializedMessageException.java) ===
  Super: Ljava/lang/RuntimeException;
  [Static Field] serialVersionUID: J = -7466929953374883507
  [Instance Field] missingFields: Ljava/util/List;

  [Direct Method] <init>(Lcom/google/protobuf/MessageLite;) -> V
    // registers=3, ins=2, outs=2, insns_size=9
    0000: const-string v0, 'Message was missing required fields.  (Lite runtime could not determine which fields were missing).'
    0002: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    0005: const/4 v0, 0
    0006: iput v0, v1.Lcom/google/protobuf/UninitializedMessageException;->missingFields:Ljava/util/List;
    0008: return-void

  [Direct Method] <init>(Ljava/util/List;) -> V
    // registers=3, ins=2, outs=2, insns_size=10
    0000: invoke-static {v2}, Lcom/google/protobuf/UninitializedMessageException;->buildDescription(Ljava/util/List;)Ljava/lang/String;
    0003: move-result-object v0
    0004: invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    0007: iput v2, v1.Lcom/google/protobuf/UninitializedMessageException;->missingFields:Ljava/util/List;
    0009: return-void

  [Direct Method] buildDescription(Ljava/util/List;) -> Ljava/lang/String;
    // registers=6, ins=1, outs=2, insns_size=43
    0000: new-instance v2, Ljava/lang/StringBuilder;
    0002: const-string v0, 'Message missing required fields: '
    0004: invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    0007: const/4 v0, 1
    0008: invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    000b: move-result-object v3
    000c: move(op=01) v1, v0
    000d: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    0010: move-result v0
    0011: if-eqz v0, 0026
    0013: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0016: move-result-object v0
    0017: check-cast v0, Ljava/lang/String;
    0019: if-eqz v1, 0020
    001b: const/4 v1, 0
    001c: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001f: goto 000d
    0020: const-string v4, ', '
    0022: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0025: goto 001c
    0026: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0029: move-result-object v0
    002a: return-object v0

  [Virtual Method] asInvalidProtocolBufferException() -> Lcom/google/protobuf/InvalidProtocolBufferException;
    // registers=3, ins=1, outs=2, insns_size=10
    0000: new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;
    0002: invoke-virtual {v2}, Lcom/google/protobuf/UninitializedMessageException;->getMessage()Ljava/lang/String;
    0005: move-result-object v1
    0006: invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V
    0009: return-object v0

  [Virtual Method] getMissingFields() -> Ljava/util/List;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/UninitializedMessageException;->missingFields:Ljava/util/List;
    0002: invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;
    0005: move-result-object v0
    0006: return-object v0