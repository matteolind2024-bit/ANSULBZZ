=== CLASS Lcom/google/protobuf/LazyStringArrayList; (Source: LazyStringArrayList.java) ===
  Super: Ljava/util/AbstractList;
  Interfaces: Lcom/google/protobuf/LazyStringList;, Ljava/util/RandomAccess;
  [Static Field] EMPTY: Lcom/google/protobuf/LazyStringList;
  [Instance Field] list: Ljava/util/List;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=2, insns_size=13
    0000: new-instance v0, Lcom/google/protobuf/UnmodifiableLazyStringList;
    0002: new-instance v1, Lcom/google/protobuf/LazyStringArrayList;
    0004: invoke-direct {v1}, Lcom/google/protobuf/LazyStringArrayList;-><init>()V
    0007: invoke-direct {v0, v1}, Lcom/google/protobuf/UnmodifiableLazyStringList;-><init>(Lcom/google/protobuf/LazyStringList;)V
    000a: sput v0, Lcom/google/protobuf/LazyStringArrayList;->EMPTY:Lcom/google/protobuf/LazyStringList;
    000c: return-void

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=11
    0000: invoke-direct {v1}, Ljava/util/AbstractList;-><init>()V
    0003: new-instance v0, Ljava/util/ArrayList;
    0005: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0008: iput v0, v1.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    000a: return-void

  [Direct Method] <init>(Ljava/util/List;) -> V
    // registers=3, ins=2, outs=2, insns_size=11
    0000: invoke-direct {v1}, Ljava/util/AbstractList;-><init>()V
    0003: new-instance v0, Ljava/util/ArrayList;
    0005: invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    0008: iput v0, v1.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    000a: return-void

  [Direct Method] asString(Ljava/lang/Object;) -> Ljava/lang/String;
    // registers=3, ins=2, outs=1, insns_size=14
    0000: instance-of v0, v2, Ljava/lang/String;
    0002: if-eqz v0, 0007
    0004: check-cast v2, Ljava/lang/String;
    0006: return-object v2
    0007: check-cast v2, Lcom/google/protobuf/ByteString;
    0009: invoke-virtual {v2}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;
    000c: move-result-object v2
    000d: goto 0006

  [Virtual Method] add(I, Ljava/lang/Object;) -> V
    // registers=3, ins=3, outs=3, insns_size=6
    0000: check-cast v2, Ljava/lang/String;
    0002: invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/LazyStringArrayList;->add(ILjava/lang/String;)V
    0005: return-void

  [Virtual Method] add(I, Ljava/lang/String;) -> V
    // registers=4, ins=3, outs=3, insns_size=12
    0000: iget v0, v1.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    0002: invoke-interface {v0, v2, v3}, Ljava/util/List;->add(ILjava/lang/Object;)V
    0005: iget v0, v1.Lcom/google/protobuf/LazyStringArrayList;->modCount:I
    0007: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0009: iput v0, v1.Lcom/google/protobuf/LazyStringArrayList;->modCount:I
    000b: return-void

  [Virtual Method] add(Lcom/google/protobuf/ByteString;) -> V
    // registers=3, ins=2, outs=2, insns_size=12
    0000: iget v0, v1.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    0002: invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    0005: iget v0, v1.Lcom/google/protobuf/LazyStringArrayList;->modCount:I
    0007: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0009: iput v0, v1.Lcom/google/protobuf/LazyStringArrayList;->modCount:I
    000b: return-void

  [Virtual Method] addAll(I, Ljava/util/Collection;) -> Z
    // registers=5, ins=3, outs=3, insns_size=13
    0000: iget v0, v2.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    0002: invoke-interface {v0, v3, v4}, Ljava/util/List;->addAll(ILjava/util/Collection;)Z
    0005: move-result v0
    0006: iget v1, v2.Lcom/google/protobuf/LazyStringArrayList;->modCount:I
    0008: binop/lit8(op=d8) v1, v1, 1 (0x1)
    000a: iput v1, v2.Lcom/google/protobuf/LazyStringArrayList;->modCount:I
    000c: return v0

  [Virtual Method] clear() -> V
    // registers=2, ins=1, outs=1, insns_size=12
    0000: iget v0, v1.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    0002: invoke-interface {v0}, Ljava/util/List;->clear()V
    0005: iget v0, v1.Lcom/google/protobuf/LazyStringArrayList;->modCount:I
    0007: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0009: iput v0, v1.Lcom/google/protobuf/LazyStringArrayList;->modCount:I
    000b: return-void

  [Virtual Method] get(I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Lcom/google/protobuf/LazyStringArrayList;->get(I)Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] get(I) -> Ljava/lang/String;
    // registers=4, ins=2, outs=3, insns_size=32
    0000: iget v0, v2.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    0002: invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0005: move-result-object v0
    0006: instance-of v1, v0, Ljava/lang/String;
    0008: if-eqz v1, 000d
    000a: check-cast v0, Ljava/lang/String;
    000c: return-object v0
    000d: check-cast v0, Lcom/google/protobuf/ByteString;
    000f: invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;
    0012: move-result-object v1
    0013: invoke-static {v0}, Lcom/google/protobuf/Internal;->isValidUtf8(Lcom/google/protobuf/ByteString;)Z
    0016: move-result v0
    0017: if-eqz v0, 001e
    0019: iget v0, v2.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    001b: invoke-interface {v0, v3, v1}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;
    001e: move(op=07) v0, v1
    001f: goto 000c

  [Virtual Method] getByteString(I) -> Lcom/google/protobuf/ByteString;
    // registers=4, ins=2, outs=3, insns_size=25
    0000: iget v0, v2.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    0002: invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0005: move-result-object v0
    0006: instance-of v1, v0, Ljava/lang/String;
    0008: if-eqz v1, 0016
    000a: check-cast v0, Ljava/lang/String;
    000c: invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;
    000f: move-result-object v0
    0010: iget v1, v2.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    0012: invoke-interface {v1, v3, v0}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;
    0015: return-object v0
    0016: check-cast v0, Lcom/google/protobuf/ByteString;
    0018: goto 0015

  [Virtual Method] remove(I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Lcom/google/protobuf/LazyStringArrayList;->remove(I)Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] remove(I) -> Ljava/lang/String;
    // registers=4, ins=2, outs=2, insns_size=17
    0000: iget v0, v2.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    0002: invoke-interface {v0, v3}, Ljava/util/List;->remove(I)Ljava/lang/Object;
    0005: move-result-object v0
    0006: iget v1, v2.Lcom/google/protobuf/LazyStringArrayList;->modCount:I
    0008: binop/lit8(op=d8) v1, v1, 1 (0x1)
    000a: iput v1, v2.Lcom/google/protobuf/LazyStringArrayList;->modCount:I
    000c: invoke-direct {v2, v0}, Lcom/google/protobuf/LazyStringArrayList;->asString(Ljava/lang/Object;)Ljava/lang/String;
    000f: move-result-object v0
    0010: return-object v0

  [Virtual Method] set(I, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=4, ins=3, outs=3, insns_size=7
    0000: check-cast v3, Ljava/lang/String;
    0002: invoke-virtual {v1, v2, v3}, Lcom/google/protobuf/LazyStringArrayList;->set(ILjava/lang/String;)Ljava/lang/String;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] set(I, Ljava/lang/String;) -> Ljava/lang/String;
    // registers=4, ins=3, outs=3, insns_size=11
    0000: iget v0, v1.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    0002: invoke-interface {v0, v2, v3}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: invoke-direct {v1, v0}, Lcom/google/protobuf/LazyStringArrayList;->asString(Ljava/lang/Object;)Ljava/lang/String;
    0009: move-result-object v0
    000a: return-object v0

  [Virtual Method] size() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/LazyStringArrayList;->list:Ljava/util/List;
    0002: invoke-interface {v0}, Ljava/util/List;->size()I
    0005: move-result v0
    0006: return v0