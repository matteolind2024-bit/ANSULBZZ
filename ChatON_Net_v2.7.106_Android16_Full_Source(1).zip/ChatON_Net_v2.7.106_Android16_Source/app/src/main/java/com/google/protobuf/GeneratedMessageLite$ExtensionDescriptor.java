=== CLASS Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor; (Source: GeneratedMessageLite.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
  [Instance Field] enumTypeMap: Lcom/google/protobuf/Internal$EnumLiteMap;
  [Instance Field] isPacked: Z
  [Instance Field] isRepeated: Z
  [Instance Field] number: I
  [Instance Field] type: Lcom/google/protobuf/WireFormat$FieldType;

  [Direct Method] <init>(Lcom/google/protobuf/Internal$EnumLiteMap;, I, Lcom/google/protobuf/WireFormat$FieldType;, Z, Z) -> V
    // registers=6, ins=6, outs=1, insns_size=14
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->enumTypeMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    0005: iput v2, v0.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->number:I
    0007: iput v3, v0.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->type:Lcom/google/protobuf/WireFormat$FieldType;
    0009: iput v4, v0.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->isRepeated:Z
    000b: iput v5, v0.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->isPacked:Z
    000d: return-void

  [Direct Method] <init>(Lcom/google/protobuf/Internal$EnumLiteMap;, I, Lcom/google/protobuf/WireFormat$FieldType;, Z, Z, Lcom/google/protobuf/GeneratedMessageLite$1;) -> V
    // registers=7, ins=7, outs=6, insns_size=4
    0000: invoke-direct/range {v0..v5}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;-><init>(Lcom/google/protobuf/Internal$EnumLiteMap;ILcom/google/protobuf/WireFormat$FieldType;ZZ)V
    0003: return-void

  [Direct Method] access$500(Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;) -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->isRepeated:Z
    0002: return v0

  [Direct Method] access$600(Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;) -> Lcom/google/protobuf/WireFormat$FieldType;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->type:Lcom/google/protobuf/WireFormat$FieldType;
    0002: return-object v0

  [Virtual Method] compareTo(Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;) -> I
    // registers=4, ins=2, outs=0, insns_size=6
    0000: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->number:I
    0002: iget v1, v3.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->number:I
    0004: binop/2addr(op=b1) v0, v1
    0005: return v0

  [Virtual Method] compareTo(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v2, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0002: invoke-virtual {v1, v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->compareTo(Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;)I
    0005: move-result v0
    0006: return v0

  [Virtual Method] getEnumType() -> Lcom/google/protobuf/Internal$EnumLiteMap;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->enumTypeMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    0002: return-object v0

  [Virtual Method] getLiteJavaType() -> Lcom/google/protobuf/WireFormat$JavaType;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->type:Lcom/google/protobuf/WireFormat$FieldType;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/WireFormat$FieldType;->getJavaType()Lcom/google/protobuf/WireFormat$JavaType;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] getLiteType() -> Lcom/google/protobuf/WireFormat$FieldType;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->type:Lcom/google/protobuf/WireFormat$FieldType;
    0002: return-object v0

  [Virtual Method] getNumber() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->number:I
    0002: return v0

  [Virtual Method] internalMergeFrom(Lcom/google/protobuf/MessageLite$Builder;, Lcom/google/protobuf/MessageLite;) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=4, ins=3, outs=2, insns_size=9
    0000: check-cast v2, Lcom/google/protobuf/GeneratedMessageLite$Builder;
    0002: check-cast v3, Lcom/google/protobuf/GeneratedMessageLite;
    0004: invoke-virtual {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;)Lcom/google/protobuf/GeneratedMessageLite$Builder;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] isPacked() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->isPacked:Z
    0002: return v0

  [Virtual Method] isRepeated() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->isRepeated:Z
    0002: return v0