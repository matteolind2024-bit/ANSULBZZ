=== CLASS Lcom/google/protobuf/ExtensionRegistryLite; (Source: ExtensionRegistryLite.java) ===
  Super: Ljava/lang/Object;
  [Static Field] EMPTY: Lcom/google/protobuf/ExtensionRegistryLite;
  [Instance Field] extensionsByNumber: Ljava/util/Map;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=2, insns_size=9
    0000: new-instance v0, Lcom/google/protobuf/ExtensionRegistryLite;
    0002: const/4 v1, 1
    0003: invoke-direct {v0, v1}, Lcom/google/protobuf/ExtensionRegistryLite;-><init>(Z)V
    0006: sput v0, Lcom/google/protobuf/ExtensionRegistryLite;->EMPTY:Lcom/google/protobuf/ExtensionRegistryLite;
    0008: return-void

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=11
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Ljava/util/HashMap;
    0005: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    0008: iput v0, v1.Lcom/google/protobuf/ExtensionRegistryLite;->extensionsByNumber:Ljava/util/Map;
    000a: return-void

  [Direct Method] <init>(Lcom/google/protobuf/ExtensionRegistryLite;) -> V
    // registers=3, ins=2, outs=1, insns_size=23
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: sget v0, Lcom/google/protobuf/ExtensionRegistryLite;->EMPTY:Lcom/google/protobuf/ExtensionRegistryLite;
    0005: if-ne v2, v0, 000e
    0007: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    000a: move-result-object v0
    000b: iput v0, v1.Lcom/google/protobuf/ExtensionRegistryLite;->extensionsByNumber:Ljava/util/Map;
    000d: return-void
    000e: iget v0, v2.Lcom/google/protobuf/ExtensionRegistryLite;->extensionsByNumber:Ljava/util/Map;
    0010: invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;
    0013: move-result-object v0
    0014: iput v0, v1.Lcom/google/protobuf/ExtensionRegistryLite;->extensionsByNumber:Ljava/util/Map;
    0016: goto 000d

  [Direct Method] <init>(Z) -> V
    // registers=3, ins=2, outs=1, insns_size=10
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    0006: move-result-object v0
    0007: iput v0, v1.Lcom/google/protobuf/ExtensionRegistryLite;->extensionsByNumber:Ljava/util/Map;
    0009: return-void

  [Direct Method] getEmptyRegistry() -> Lcom/google/protobuf/ExtensionRegistryLite;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/google/protobuf/ExtensionRegistryLite;->EMPTY:Lcom/google/protobuf/ExtensionRegistryLite;
    0002: return-object v0

  [Direct Method] newInstance() -> Lcom/google/protobuf/ExtensionRegistryLite;
    // registers=1, ins=0, outs=1, insns_size=6
    0000: new-instance v0, Lcom/google/protobuf/ExtensionRegistryLite;
    0002: invoke-direct {v0}, Lcom/google/protobuf/ExtensionRegistryLite;-><init>()V
    0005: return-object v0

  [Virtual Method] add(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> V
    // registers=6, ins=2, outs=3, insns_size=19
    0000: iget v0, v4.Lcom/google/protobuf/ExtensionRegistryLite;->extensionsByNumber:Ljava/util/Map;
    0002: new-instance v1, Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;
    0004: invoke-virtual {v5}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->getContainingTypeDefaultInstance()Lcom/google/protobuf/MessageLite;
    0007: move-result-object v2
    0008: invoke-virtual {v5}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->getNumber()I
    000b: move-result v3
    000c: invoke-direct {v1, v2, v3}, Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;-><init>(Ljava/lang/Object;I)V
    000f: invoke-interface {v0, v1, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    0012: return-void

  [Virtual Method] findLiteExtensionByNumber(Lcom/google/protobuf/MessageLite;, I) -> Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;
    // registers=5, ins=3, outs=3, insns_size=14
    0000: iget v0, v2.Lcom/google/protobuf/ExtensionRegistryLite;->extensionsByNumber:Ljava/util/Map;
    0002: new-instance v1, Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;
    0004: invoke-direct {v1, v3, v4}, Lcom/google/protobuf/ExtensionRegistryLite$ObjectIntPair;-><init>(Ljava/lang/Object;I)V
    0007: invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    000a: move-result-object v0
    000b: check-cast v0, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;
    000d: return-object v0

  [Virtual Method] getUnmodifiable() -> Lcom/google/protobuf/ExtensionRegistryLite;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Lcom/google/protobuf/ExtensionRegistryLite;
    0002: invoke-direct {v0, v1}, Lcom/google/protobuf/ExtensionRegistryLite;-><init>(Lcom/google/protobuf/ExtensionRegistryLite;)V
    0005: return-object v0