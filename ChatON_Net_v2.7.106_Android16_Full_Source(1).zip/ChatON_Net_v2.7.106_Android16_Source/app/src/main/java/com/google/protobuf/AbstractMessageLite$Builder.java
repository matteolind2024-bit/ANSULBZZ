=== CLASS Lcom/google/protobuf/AbstractMessageLite$Builder; (Source: AbstractMessageLite.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/MessageLite$Builder;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] addAll(Ljava/lang/Iterable;, Ljava/util/Collection;) -> V
    // registers=4, ins=2, outs=2, insns_size=50
    0000: invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    0003: move-result-object v0
    0004: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    0007: move-result v1
    0008: if-eqz v1, 0016
    000a: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    000d: move-result-object v1
    000e: if-nez v1, 0004
    0010: new-instance v0, Ljava/lang/NullPointerException;
    0012: invoke-direct {v0}, Ljava/lang/NullPointerException;-><init>()V
    0015: throw v0
    0016: instance-of v0, v2, Ljava/util/Collection;
    0018: if-eqz v0, 0020
    001a: check-cast v2, Ljava/util/Collection;
    001c: invoke-interface {v3, v2}, Ljava/util/Collection;->addAll(Ljava/util/Collection;)Z
    001f: return-void
    0020: invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    0023: move-result-object v0
    0024: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    0027: move-result v1
    0028: if-eqz v1, 001f
    002a: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    002d: move-result-object v1
    002e: invoke-interface {v3, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z
    0031: goto 0024

  [Direct Method] newUninitializedMessageException(Lcom/google/protobuf/MessageLite;) -> Lcom/google/protobuf/UninitializedMessageException;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Lcom/google/protobuf/UninitializedMessageException;
    0002: invoke-direct {v0, v1}, Lcom/google/protobuf/UninitializedMessageException;-><init>(Lcom/google/protobuf/MessageLite;)V
    0005: return-object v0

  [Virtual Method] clone() -> Lcom/google/protobuf/AbstractMessageLite$Builder;

  [Virtual Method] clone() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/AbstractMessageLite$Builder;->clone()Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clone() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/AbstractMessageLite$Builder;->clone()Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeDelimitedFrom(Ljava/io/InputStream;) -> Z
    // registers=3, ins=2, outs=3, insns_size=9
    0000: invoke-static {}, Lcom/google/protobuf/ExtensionRegistryLite;->getEmptyRegistry()Lcom/google/protobuf/ExtensionRegistryLite;
    0003: move-result-object v0
    0004: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Z
    0007: move-result v0
    0008: return v0

  [Virtual Method] mergeDelimitedFrom(Ljava/io/InputStream;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Z
    // registers=5, ins=3, outs=3, insns_size=23
    0000: invoke-virtual {v3}, Ljava/io/InputStream;->read()I
    0003: move-result v0
    0004: const/4 v1, -1
    0005: if-ne v0, v1, 0009
    0007: const/4 v0, 0
    0008: return v0
    0009: invoke-static {v0, v3}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32(ILjava/io/InputStream;)I
    000c: move-result v0
    000d: new-instance v1, Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;
    000f: invoke-direct {v1, v3, v0}, Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;-><init>(Ljava/io/InputStream;I)V
    0012: invoke-virtual {v2, v1, v4}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0015: const/4 v0, 1
    0016: goto 0008

  [Virtual Method] mergeFrom(Lcom/google/protobuf/ByteString;) -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=5, ins=2, outs=3, insns_size=23
    0000: invoke-virtual {v4}, Lcom/google/protobuf/ByteString;->newCodedInput()Lcom/google/protobuf/CodedInputStream;
    0003: move-result-object v0
    0004: invoke-virtual {v3, v0}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0007: const/4 v1, 0
    0008: invoke-virtual {v0, v1}, Lcom/google/protobuf/CodedInputStream;->checkLastTagWas(I)V
    000b: return-object v3
    000c: move-exception v0
    000d: throw v0
    000e: move-exception v0
    000f: new-instance v1, Ljava/lang/RuntimeException;
    0011: const-string v2, 'Reading from a ByteString threw an IOException (should never happen).'
    0013: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0016: throw v1

  [Virtual Method] mergeFrom(Lcom/google/protobuf/ByteString;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=6, ins=3, outs=3, insns_size=23
    0000: invoke-virtual {v4}, Lcom/google/protobuf/ByteString;->newCodedInput()Lcom/google/protobuf/CodedInputStream;
    0003: move-result-object v0
    0004: invoke-virtual {v3, v0, v5}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0007: const/4 v1, 0
    0008: invoke-virtual {v0, v1}, Lcom/google/protobuf/CodedInputStream;->checkLastTagWas(I)V
    000b: return-object v3
    000c: move-exception v0
    000d: throw v0
    000e: move-exception v0
    000f: new-instance v1, Ljava/lang/RuntimeException;
    0011: const-string v2, 'Reading from a ByteString threw an IOException (should never happen).'
    0013: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0016: throw v1

  [Virtual Method] mergeFrom(Lcom/google/protobuf/CodedInputStream;) -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=3, ins=2, outs=3, insns_size=9
    0000: invoke-static {}, Lcom/google/protobuf/ExtensionRegistryLite;->getEmptyRegistry()Lcom/google/protobuf/ExtensionRegistryLite;
    0003: move-result-object v0
    0004: invoke-virtual {v1, v2, v0}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] mergeFrom(Lcom/google/protobuf/CodedInputStream;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/AbstractMessageLite$Builder;

  [Virtual Method] mergeFrom(Ljava/io/InputStream;) -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=4, ins=2, outs=2, insns_size=12
    0000: invoke-static {v3}, Lcom/google/protobuf/CodedInputStream;->newInstance(Ljava/io/InputStream;)Lcom/google/protobuf/CodedInputStream;
    0003: move-result-object v0
    0004: invoke-virtual {v2, v0}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0007: const/4 v1, 0
    0008: invoke-virtual {v0, v1}, Lcom/google/protobuf/CodedInputStream;->checkLastTagWas(I)V
    000b: return-object v2

  [Virtual Method] mergeFrom(Ljava/io/InputStream;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=5, ins=3, outs=3, insns_size=12
    0000: invoke-static {v3}, Lcom/google/protobuf/CodedInputStream;->newInstance(Ljava/io/InputStream;)Lcom/google/protobuf/CodedInputStream;
    0003: move-result-object v0
    0004: invoke-virtual {v2, v0, v4}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0007: const/4 v1, 0
    0008: invoke-virtual {v0, v1}, Lcom/google/protobuf/CodedInputStream;->checkLastTagWas(I)V
    000b: return-object v2

  [Virtual Method] mergeFrom([B) -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=4, ins=2, outs=4, insns_size=7
    0000: const/4 v0, 0
    0001: move(op=21) v1, v3
    0002: invoke-virtual {v2, v3, v0, v1}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom([BII)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] mergeFrom([B, I, I) -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=7, ins=4, outs=3, insns_size=23
    0000: invoke-static {v4, v5, v6}, Lcom/google/protobuf/CodedInputStream;->newInstance([BII)Lcom/google/protobuf/CodedInputStream;
    0003: move-result-object v0
    0004: invoke-virtual {v3, v0}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0007: const/4 v1, 0
    0008: invoke-virtual {v0, v1}, Lcom/google/protobuf/CodedInputStream;->checkLastTagWas(I)V
    000b: return-object v3
    000c: move-exception v0
    000d: throw v0
    000e: move-exception v0
    000f: new-instance v1, Ljava/lang/RuntimeException;
    0011: const-string v2, 'Reading from a byte array threw an IOException (should never happen).'
    0013: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0016: throw v1

  [Virtual Method] mergeFrom([B, I, I, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=8, ins=5, outs=3, insns_size=23
    0000: invoke-static {v4, v5, v6}, Lcom/google/protobuf/CodedInputStream;->newInstance([BII)Lcom/google/protobuf/CodedInputStream;
    0003: move-result-object v0
    0004: invoke-virtual {v3, v0, v7}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0007: const/4 v1, 0
    0008: invoke-virtual {v0, v1}, Lcom/google/protobuf/CodedInputStream;->checkLastTagWas(I)V
    000b: return-object v3
    000c: move-exception v0
    000d: throw v0
    000e: move-exception v0
    000f: new-instance v1, Ljava/lang/RuntimeException;
    0011: const-string v2, 'Reading from a byte array threw an IOException (should never happen).'
    0013: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0016: throw v1

  [Virtual Method] mergeFrom([B, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=5, ins=3, outs=5, insns_size=7
    0000: const/4 v0, 0
    0001: move(op=21) v1, v3
    0002: invoke-virtual {v2, v3, v0, v1, v4}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom([BIILcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] mergeFrom(Lcom/google/protobuf/ByteString;) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeFrom(Lcom/google/protobuf/ByteString;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=4, ins=3, outs=3, insns_size=5
    0000: invoke-virtual {v1, v2, v3}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeFrom(Lcom/google/protobuf/CodedInputStream;) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeFrom(Lcom/google/protobuf/CodedInputStream;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=4, ins=3, outs=3, insns_size=5
    0000: invoke-virtual {v1, v2, v3}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeFrom(Ljava/io/InputStream;) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Ljava/io/InputStream;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeFrom(Ljava/io/InputStream;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=4, ins=3, outs=3, insns_size=5
    0000: invoke-virtual {v1, v2, v3}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeFrom([B) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom([B)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeFrom([B, I, I) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=5, ins=4, outs=4, insns_size=5
    0000: invoke-virtual {v1, v2, v3, v4}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom([BII)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeFrom([B, I, I, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=6, ins=5, outs=5, insns_size=5
    0000: invoke-virtual {v1, v2, v3, v4, v5}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom([BIILcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeFrom([B, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=4, ins=3, outs=3, insns_size=5
    0000: invoke-virtual {v1, v2, v3}, Lcom/google/protobuf/AbstractMessageLite$Builder;->mergeFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0