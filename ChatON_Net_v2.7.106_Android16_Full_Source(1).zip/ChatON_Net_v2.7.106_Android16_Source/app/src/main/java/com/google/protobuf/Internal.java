=== CLASS Lcom/google/protobuf/Internal; (Source: Internal.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] bytesDefaultValue(Ljava/lang/String;) -> Lcom/google/protobuf/ByteString;
    // registers=4, ins=1, outs=3, insns_size=20
    0000: const-string v0, 'ISO-8859-1'
    0002: invoke-virtual {v3, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B
    0005: move-result-object v0
    0006: invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFrom([B)Lcom/google/protobuf/ByteString;
    0009: move-result-object v0
    000a: return-object v0
    000b: move-exception v0
    000c: new-instance v1, Ljava/lang/IllegalStateException;
    000e: const-string v2, 'Java VM does not support a standard character set.'
    0010: invoke-direct {v1, v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0013: throw v1

  [Direct Method] isValidUtf8(Lcom/google/protobuf/ByteString;) -> Z
    // registers=11, ins=1, outs=2, insns_size=136
    0000: const/16 v9, 244 (0xf4)
    0002: const/16 v8, 191 (0xbf)
    0004: const/16 v7, 128 (0x80)
    0006: const/4 v2, 0
    0007: invoke-virtual {v10}, Lcom/google/protobuf/ByteString;->size()I
    000a: move-result v4
    000b: move(op=01) v0, v2
    000c: if-ge v0, v4, 0084
    000e: binop/lit8(op=d8) v1, v0, 1 (0x1)
    0010: invoke-virtual {v10, v0}, Lcom/google/protobuf/ByteString;->byteAt(I)B
    0013: move-result v0
    0014: binop/lit16(op=d5) v5, v0, 255 (0xff)
    0016: if-ge v5, v7, 001a
    0018: move(op=01) v0, v1
    0019: goto 000c
    001a: const/16 v0, 194 (0xc2)
    001c: if-lt v5, v0, 0020
    001e: if-le v5, v9, 0022
    0020: move(op=01) v0, v2
    0021: return v0
    0022: if-lt v1, v4, 0026
    0024: move(op=01) v0, v2
    0025: goto 0021
    0026: binop/lit8(op=d8) v3, v1, 1 (0x1)
    0028: invoke-virtual {v10, v1}, Lcom/google/protobuf/ByteString;->byteAt(I)B
    002b: move-result v0
    002c: binop/lit16(op=d5) v6, v0, 255 (0xff)
    002e: if-lt v6, v7, 0032
    0030: if-le v6, v8, 0034
    0032: move(op=01) v0, v2
    0033: goto 0021
    0034: const/16 v0, 223 (0xdf)
    0036: if-gt v5, v0, 003a
    0038: move(op=01) v0, v3
    0039: goto 000c
    003a: if-lt v3, v4, 003e
    003c: move(op=01) v0, v2
    003d: goto 0021
    003e: binop/lit8(op=d8) v0, v3, 1 (0x1)
    0040: invoke-virtual {v10, v3}, Lcom/google/protobuf/ByteString;->byteAt(I)B
    0043: move-result v1
    0044: binop/lit16(op=d5) v1, v1, 255 (0xff)
    0046: if-lt v1, v7, 004a
    0048: if-le v1, v8, 004c
    004a: move(op=01) v0, v2
    004b: goto 0021
    004c: const/16 v1, 239 (0xef)
    004e: if-gt v5, v1, 0062
    0050: const/16 v1, 224 (0xe0)
    0052: if-ne v5, v1, 0058
    0054: const/16 v1, 160 (0xa0)
    0056: if-lt v6, v1, 0060
    0058: const/16 v1, 237 (0xed)
    005a: if-ne v5, v1, 000c
    005c: const/16 v1, 159 (0x9f)
    005e: if-le v6, v1, 000c
    0060: move(op=01) v0, v2
    0061: goto 0021
    0062: if-lt v0, v4, 0066
    0064: move(op=01) v0, v2
    0065: goto 0021
    0066: binop/lit8(op=d8) v1, v0, 1 (0x1)
    0068: invoke-virtual {v10, v0}, Lcom/google/protobuf/ByteString;->byteAt(I)B
    006b: move-result v0
    006c: binop/lit16(op=d5) v0, v0, 255 (0xff)
    006e: if-lt v0, v7, 0072
    0070: if-le v0, v8, 0074
    0072: move(op=01) v0, v2
    0073: goto 0021
    0074: const/16 v0, 240 (0xf0)
    0076: if-ne v5, v0, 007c
    0078: const/16 v0, 144 (0x90)
    007a: if-lt v6, v0, 0082
    007c: if-ne v5, v9, 0086
    007e: const/16 v0, 143 (0x8f)
    0080: if-le v6, v0, 0086
    0082: move(op=01) v0, v2
    0083: goto 0021
    0084: const/4 v0, 1
    0085: goto 0021
    0086: move(op=01) v0, v1
    0087: goto 000c

  [Direct Method] stringDefaultValue(Ljava/lang/String;) -> Ljava/lang/String;
    // registers=4, ins=1, outs=3, insns_size=23
    0000: new-instance v0, Ljava/lang/String;
    0002: const-string v1, 'ISO-8859-1'
    0004: invoke-virtual {v3, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B
    0007: move-result-object v1
    0008: const-string v2, 'UTF-8'
    000a: invoke-direct {v0, v1, v2}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    000d: return-object v0
    000e: move-exception v0
    000f: new-instance v1, Ljava/lang/IllegalStateException;
    0011: const-string v2, 'Java VM does not support a standard character set.'
    0013: invoke-direct {v1, v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0016: throw v1