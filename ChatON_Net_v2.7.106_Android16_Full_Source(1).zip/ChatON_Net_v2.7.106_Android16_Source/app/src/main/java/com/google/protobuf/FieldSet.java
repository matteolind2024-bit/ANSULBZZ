=== CLASS Lcom/google/protobuf/FieldSet; (Source: FieldSet.java) ===
  Super: Ljava/lang/Object;
  [Static Field] DEFAULT_INSTANCE: Lcom/google/protobuf/FieldSet;
  [Instance Field] fields: Lcom/google/protobuf/SmallSortedMap;
  [Instance Field] isImmutable: Z

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=2, insns_size=9
    0000: new-instance v0, Lcom/google/protobuf/FieldSet;
    0002: const/4 v1, 1
    0003: invoke-direct {v0, v1}, Lcom/google/protobuf/FieldSet;-><init>(Z)V
    0006: sput v0, Lcom/google/protobuf/FieldSet;->DEFAULT_INSTANCE:Lcom/google/protobuf/FieldSet;
    0008: return-void

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=12
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: const/16 v0, 16 (0x10)
    0005: invoke-static {v0}, Lcom/google/protobuf/SmallSortedMap;->newFieldMap(I)Lcom/google/protobuf/SmallSortedMap;
    0008: move-result-object v0
    0009: iput v0, v1.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    000b: return-void

  [Direct Method] <init>(Z) -> V
    // registers=3, ins=2, outs=1, insns_size=14
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: const/4 v0, 0
    0004: invoke-static {v0}, Lcom/google/protobuf/SmallSortedMap;->newFieldMap(I)Lcom/google/protobuf/SmallSortedMap;
    0007: move-result-object v0
    0008: iput v0, v1.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    000a: invoke-virtual {v1}, Lcom/google/protobuf/FieldSet;->makeImmutable()V
    000d: return-void

  [Direct Method] computeElementSize(Lcom/google/protobuf/WireFormat$FieldType;, I, Ljava/lang/Object;) -> I
    // registers=5, ins=3, outs=2, insns_size=16
    0000: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    0003: move-result v0
    0004: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->GROUP:Lcom/google/protobuf/WireFormat$FieldType;
    0006: if-ne v2, v1, 000a
    0008: binop/lit8(op=da) v0, v0, 2 (0x2)
    000a: invoke-static {v2, v4}, Lcom/google/protobuf/FieldSet;->computeElementSizeNoTag(Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)I
    000d: move-result v1
    000e: binop/2addr(op=b0) v0, v1
    000f: return v0

  [Direct Method] computeElementSizeNoTag(Lcom/google/protobuf/WireFormat$FieldType;, Ljava/lang/Object;) -> I
    // registers=4, ins=2, outs=2, insns_size=246
    0000: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0002: invoke-virtual {v2}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0005: move-result v1
    0006: aget(op=44) v0, v0[v1]
    0008: packed-switch v0, +198 (-> 00ce)
    000b: new-instance v0, Ljava/lang/RuntimeException;
    000d: const-string v1, 'There is no way to get here, but the compiler thinks otherwise.'
    000f: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    0012: throw v0
    0013: check-cast v3, Ljava/lang/Double;
    0015: invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D
    0018: move-result-wide v0
    0019: invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeDoubleSizeNoTag(D)I
    001c: move-result v0
    001d: return v0
    001e: check-cast v3, Ljava/lang/Float;
    0020: invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F
    0023: move-result v0
    0024: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeFloatSizeNoTag(F)I
    0027: move-result v0
    0028: goto 001d
    0029: check-cast v3, Ljava/lang/Long;
    002b: invoke-virtual {v3}, Ljava/lang/Long;->longValue()J
    002e: move-result-wide v0
    002f: invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeInt64SizeNoTag(J)I
    0032: move-result v0
    0033: goto 001d
    0034: check-cast v3, Ljava/lang/Long;
    0036: invoke-virtual {v3}, Ljava/lang/Long;->longValue()J
    0039: move-result-wide v0
    003a: invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeUInt64SizeNoTag(J)I
    003d: move-result v0
    003e: goto 001d
    003f: check-cast v3, Ljava/lang/Integer;
    0041: invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I
    0044: move-result v0
    0045: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeInt32SizeNoTag(I)I
    0048: move-result v0
    0049: goto 001d
    004a: check-cast v3, Ljava/lang/Long;
    004c: invoke-virtual {v3}, Ljava/lang/Long;->longValue()J
    004f: move-result-wide v0
    0050: invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeFixed64SizeNoTag(J)I
    0053: move-result v0
    0054: goto 001d
    0055: check-cast v3, Ljava/lang/Integer;
    0057: invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I
    005a: move-result v0
    005b: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeFixed32SizeNoTag(I)I
    005e: move-result v0
    005f: goto 001d
    0060: check-cast v3, Ljava/lang/Boolean;
    0062: invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z
    0065: move-result v0
    0066: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeBoolSizeNoTag(Z)I
    0069: move-result v0
    006a: goto 001d
    006b: check-cast v3, Ljava/lang/String;
    006d: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeStringSizeNoTag(Ljava/lang/String;)I
    0070: move-result v0
    0071: goto 001d
    0072: check-cast v3, Lcom/google/protobuf/MessageLite;
    0074: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeGroupSizeNoTag(Lcom/google/protobuf/MessageLite;)I
    0077: move-result v0
    0078: goto 001d
    0079: check-cast v3, Lcom/google/protobuf/MessageLite;
    007b: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSizeNoTag(Lcom/google/protobuf/MessageLite;)I
    007e: move-result v0
    007f: goto 001d
    0080: check-cast v3, Lcom/google/protobuf/ByteString;
    0082: invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeBytesSizeNoTag(Lcom/google/protobuf/ByteString;)I
    0085: move-result v0
    0086: goto 001d
    0087: check-cast v3, Ljava/lang/Integer;
    0089: invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I
    008c: move-result v0
    008d: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32SizeNoTag(I)I
    0090: move-result v0
    0091: goto 001d
    0092: check-cast v3, Ljava/lang/Integer;
    0094: invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I
    0097: move-result v0
    0098: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeSFixed32SizeNoTag(I)I
    009b: move-result v0
    009c: goto 001d
    009d: check-cast v3, Ljava/lang/Long;
    009f: invoke-virtual {v3}, Ljava/lang/Long;->longValue()J
    00a2: move-result-wide v0
    00a3: invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeSFixed64SizeNoTag(J)I
    00a6: move-result v0
    00a7: goto/16 001d
    00a9: check-cast v3, Ljava/lang/Integer;
    00ab: invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I
    00ae: move-result v0
    00af: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeSInt32SizeNoTag(I)I
    00b2: move-result v0
    00b3: goto/16 001d
    00b5: check-cast v3, Ljava/lang/Long;
    00b7: invoke-virtual {v3}, Ljava/lang/Long;->longValue()J
    00ba: move-result-wide v0
    00bb: invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeSInt64SizeNoTag(J)I
    00be: move-result v0
    00bf: goto/16 001d
    00c1: check-cast v3, Lcom/google/protobuf/Internal$EnumLite;
    00c3: invoke-interface {v3}, Lcom/google/protobuf/Internal$EnumLite;->getNumber()I
    00c6: move-result v0
    00c7: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSizeNoTag(I)I
    00ca: move-result v0
    00cb: goto/16 001d
    00cd: nop
    00ce: packed-switch-payload first=1 targets=[11, 22, 33, 44, 55, 66, 77, 88, 99, 120, 127, 138, 149, 161, 173, 106, 113, 185]

  [Direct Method] computeFieldSize(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;, Ljava/lang/Object;) -> I
    // registers=7, ins=2, outs=3, insns_size=81
    0000: const/4 v0, 0
    0001: invoke-interface {v5}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    0004: move-result-object v1
    0005: invoke-interface {v5}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getNumber()I
    0008: move-result v2
    0009: invoke-interface {v5}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    000c: move-result v3
    000d: if-eqz v3, 004c
    000f: invoke-interface {v5}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isPacked()Z
    0012: move-result v3
    0013: if-eqz v3, 0036
    0015: check-cast v6, Ljava/util/List;
    0017: invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    001a: move-result-object v3
    001b: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    001e: move-result v4
    001f: if-eqz v4, 002b
    0021: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0024: move-result-object v4
    0025: invoke-static {v1, v4}, Lcom/google/protobuf/FieldSet;->computeElementSizeNoTag(Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)I
    0028: move-result v4
    0029: binop/2addr(op=b0) v0, v4
    002a: goto 001b
    002b: invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeTagSize(I)I
    002e: move-result v1
    002f: binop/2addr(op=b0) v1, v0
    0030: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint32Size(I)I
    0033: move-result v0
    0034: binop/2addr(op=b0) v0, v1
    0035: return v0
    0036: check-cast v6, Ljava/util/List;
    0038: invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    003b: move-result-object v3
    003c: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    003f: move-result v4
    0040: if-eqz v4, 0035
    0042: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0045: move-result-object v4
    0046: invoke-static {v1, v2, v4}, Lcom/google/protobuf/FieldSet;->computeElementSize(Lcom/google/protobuf/WireFormat$FieldType;ILjava/lang/Object;)I
    0049: move-result v4
    004a: binop/2addr(op=b0) v0, v4
    004b: goto 003c
    004c: invoke-static {v1, v2, v6}, Lcom/google/protobuf/FieldSet;->computeElementSize(Lcom/google/protobuf/WireFormat$FieldType;ILjava/lang/Object;)I
    004f: move-result v0
    0050: goto 0035

  [Direct Method] emptySet() -> Lcom/google/protobuf/FieldSet;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/google/protobuf/FieldSet;->DEFAULT_INSTANCE:Lcom/google/protobuf/FieldSet;
    0002: return-object v0

  [Direct Method] getMessageSetSerializedSize(Ljava/util/Map$Entry;) -> I
    // registers=5, ins=2, outs=2, insns_size=56
    0000: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0003: move-result-object v0
    0004: check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0006: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteJavaType()Lcom/google/protobuf/WireFormat$JavaType;
    0009: move-result-object v1
    000a: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;
    000c: if-ne v1, v2, 002f
    000e: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    0011: move-result v1
    0012: if-nez v1, 002f
    0014: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isPacked()Z
    0017: move-result v1
    0018: if-nez v1, 002f
    001a: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    001d: move-result-object v0
    001e: check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0020: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getNumber()I
    0023: move-result v1
    0024: invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0027: move-result-object v0
    0028: check-cast v0, Lcom/google/protobuf/MessageLite;
    002a: invoke-static {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSetExtensionSize(ILcom/google/protobuf/MessageLite;)I
    002d: move-result v0
    002e: return v0
    002f: invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0032: move-result-object v1
    0033: invoke-static {v0, v1}, Lcom/google/protobuf/FieldSet;->computeFieldSize(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)I
    0036: move-result v0
    0037: goto 002e

  [Direct Method] getWireFormatForFieldType(Lcom/google/protobuf/WireFormat$FieldType;, Z) -> I
    // registers=3, ins=2, outs=1, insns_size=9
    0000: if-eqz v2, 0004
    0002: const/4 v0, 2
    0003: return v0
    0004: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$FieldType;->getWireType()I
    0007: move-result v0
    0008: goto 0003

  [Direct Method] isInitialized(Ljava/util/Map$Entry;) -> Z
    // registers=6, ins=2, outs=1, insns_size=67
    0000: const/4 v1, 0
    0001: invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0004: move-result-object v0
    0005: check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0007: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteJavaType()Lcom/google/protobuf/WireFormat$JavaType;
    000a: move-result-object v2
    000b: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;
    000d: if-ne v2, v3, 0041
    000f: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    0012: move-result v0
    0013: if-eqz v0, 0033
    0015: invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0018: move-result-object v0
    0019: check-cast v0, Ljava/util/List;
    001b: invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    001e: move-result-object v2
    001f: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    0022: move-result v0
    0023: if-eqz v0, 0041
    0025: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0028: move-result-object v0
    0029: check-cast v0, Lcom/google/protobuf/MessageLite;
    002b: invoke-interface {v0}, Lcom/google/protobuf/MessageLite;->isInitialized()Z
    002e: move-result v0
    002f: if-nez v0, 001f
    0031: move(op=01) v0, v1
    0032: return v0
    0033: invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0036: move-result-object v0
    0037: check-cast v0, Lcom/google/protobuf/MessageLite;
    0039: invoke-interface {v0}, Lcom/google/protobuf/MessageLite;->isInitialized()Z
    003c: move-result v0
    003d: if-nez v0, 0041
    003f: move(op=01) v0, v1
    0040: goto 0032
    0041: const/4 v0, 1
    0042: goto 0032

  [Direct Method] mergeFromField(Ljava/util/Map$Entry;) -> V
    // registers=6, ins=2, outs=3, insns_size=96
    0000: invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0003: move-result-object v0
    0004: check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0006: invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0009: move-result-object v1
    000a: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    000d: move-result v2
    000e: if-eqz v2, 002e
    0010: iget v2, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0012: invoke-virtual {v2, v0}, Lcom/google/protobuf/SmallSortedMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0015: move-result-object v2
    0016: if-nez v2, 0025
    0018: iget v2, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    001a: new-instance v3, Ljava/util/ArrayList;
    001c: check-cast v1, Ljava/util/List;
    001e: invoke-direct {v3, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    0021: invoke-virtual {v2, v0, v3}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;
    0024: return-void
    0025: move(op=07) v0, v2
    0026: check-cast v0, Ljava/util/List;
    0028: check-cast v1, Ljava/util/List;
    002a: invoke-interface {v0, v1}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z
    002d: goto 0024
    002e: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteJavaType()Lcom/google/protobuf/WireFormat$JavaType;
    0031: move-result-object v2
    0032: sget v3, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;
    0034: if-ne v2, v3, 005a
    0036: iget v2, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0038: invoke-virtual {v2, v0}, Lcom/google/protobuf/SmallSortedMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    003b: move-result-object v2
    003c: if-nez v2, 0044
    003e: iget v2, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0040: invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;
    0043: goto 0024
    0044: iget v3, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0046: check-cast v2, Lcom/google/protobuf/MessageLite;
    0048: invoke-interface {v2}, Lcom/google/protobuf/MessageLite;->toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    004b: move-result-object v2
    004c: check-cast v1, Lcom/google/protobuf/MessageLite;
    004e: invoke-interface {v0, v2, v1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->internalMergeFrom(Lcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/MessageLite;)Lcom/google/protobuf/MessageLite$Builder;
    0051: move-result-object v1
    0052: invoke-interface {v1}, Lcom/google/protobuf/MessageLite$Builder;->build()Lcom/google/protobuf/MessageLite;
    0055: move-result-object v1
    0056: invoke-virtual {v3, v0, v1}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;
    0059: goto 0024
    005a: iget v2, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    005c: invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;
    005f: goto 0024

  [Direct Method] newFieldSet() -> Lcom/google/protobuf/FieldSet;
    // registers=1, ins=0, outs=1, insns_size=6
    0000: new-instance v0, Lcom/google/protobuf/FieldSet;
    0002: invoke-direct {v0}, Lcom/google/protobuf/FieldSet;-><init>()V
    0005: return-object v0

  [Direct Method] readPrimitiveField(Lcom/google/protobuf/CodedInputStream;, Lcom/google/protobuf/WireFormat$FieldType;) -> Ljava/lang/Object;
    // registers=4, ins=2, outs=2, insns_size=210
    0000: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0002: invoke-virtual {v3}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0005: move-result v1
    0006: aget(op=44) v0, v0[v1]
    0008: packed-switch v0, +162 (-> 00aa)
    000b: new-instance v0, Ljava/lang/RuntimeException;
    000d: const-string v1, 'There is no way to get here, but the compiler thinks otherwise.'
    000f: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    0012: throw v0
    0013: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readDouble()D
    0016: move-result-wide v0
    0017: invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    001a: move-result-object v0
    001b: return-object v0
    001c: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readFloat()F
    001f: move-result v0
    0020: invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    0023: move-result-object v0
    0024: goto 001b
    0025: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readInt64()J
    0028: move-result-wide v0
    0029: invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    002c: move-result-object v0
    002d: goto 001b
    002e: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readUInt64()J
    0031: move-result-wide v0
    0032: invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    0035: move-result-object v0
    0036: goto 001b
    0037: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readInt32()I
    003a: move-result v0
    003b: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    003e: move-result-object v0
    003f: goto 001b
    0040: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readFixed64()J
    0043: move-result-wide v0
    0044: invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    0047: move-result-object v0
    0048: goto 001b
    0049: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readFixed32()I
    004c: move-result v0
    004d: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0050: move-result-object v0
    0051: goto 001b
    0052: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readBool()Z
    0055: move-result v0
    0056: invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0059: move-result-object v0
    005a: goto 001b
    005b: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readString()Ljava/lang/String;
    005e: move-result-object v0
    005f: goto 001b
    0060: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readBytes()Lcom/google/protobuf/ByteString;
    0063: move-result-object v0
    0064: goto 001b
    0065: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readUInt32()I
    0068: move-result v0
    0069: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    006c: move-result-object v0
    006d: goto 001b
    006e: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readSFixed32()I
    0071: move-result v0
    0072: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0075: move-result-object v0
    0076: goto 001b
    0077: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readSFixed64()J
    007a: move-result-wide v0
    007b: invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    007e: move-result-object v0
    007f: goto 001b
    0080: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readSInt32()I
    0083: move-result v0
    0084: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0087: move-result-object v0
    0088: goto 001b
    0089: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readSInt64()J
    008c: move-result-wide v0
    008d: invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    0090: move-result-object v0
    0091: goto 001b
    0092: new-instance v0, Ljava/lang/IllegalArgumentException;
    0094: const-string v1, 'readPrimitiveField() cannot handle nested groups.'
    0096: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0099: throw v0
    009a: new-instance v0, Ljava/lang/IllegalArgumentException;
    009c: const-string v1, 'readPrimitiveField() cannot handle embedded messages.'
    009e: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    00a1: throw v0
    00a2: new-instance v0, Ljava/lang/IllegalArgumentException;
    00a4: const-string v1, 'readPrimitiveField() cannot handle enums.'
    00a6: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    00a9: throw v0
    00aa: packed-switch-payload first=1 targets=[11, 20, 29, 38, 47, 56, 65, 74, 83, 88, 93, 102, 111, 120, 129, 138, 146, 154]

  [Direct Method] verifyType(Lcom/google/protobuf/WireFormat$FieldType;, Ljava/lang/Object;) -> V
    // registers=5, ins=2, outs=2, insns_size=84
    0000: if-nez v4, 0008
    0002: new-instance v0, Ljava/lang/NullPointerException;
    0004: invoke-direct {v0}, Ljava/lang/NullPointerException;-><init>()V
    0007: throw v0
    0008: const/4 v0, 0
    0009: sget v1, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    000b: invoke-virtual {v3}, Lcom/google/protobuf/WireFormat$FieldType;->getJavaType()Lcom/google/protobuf/WireFormat$JavaType;
    000e: move-result-object v2
    000f: invoke-virtual {v2}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    0012: move-result v2
    0013: aget(op=44) v1, v1[v2]
    0015: packed-switch v1, +41 (-> 003e)
    0018: if-nez v0, 003d
    001a: new-instance v0, Ljava/lang/IllegalArgumentException;
    001c: const-string v1, 'Wrong object type used with protocol message reflection.'
    001e: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0021: throw v0
    0022: instance-of v0, v4, Ljava/lang/Integer;
    0024: goto 0018
    0025: instance-of v0, v4, Ljava/lang/Long;
    0027: goto 0018
    0028: instance-of v0, v4, Ljava/lang/Float;
    002a: goto 0018
    002b: instance-of v0, v4, Ljava/lang/Double;
    002d: goto 0018
    002e: instance-of v0, v4, Ljava/lang/Boolean;
    0030: goto 0018
    0031: instance-of v0, v4, Ljava/lang/String;
    0033: goto 0018
    0034: instance-of v0, v4, Lcom/google/protobuf/ByteString;
    0036: goto 0018
    0037: instance-of v0, v4, Lcom/google/protobuf/Internal$EnumLite;
    0039: goto 0018
    003a: instance-of v0, v4, Lcom/google/protobuf/MessageLite;
    003c: goto 0018
    003d: return-void
    003e: packed-switch-payload first=1 targets=[13, 16, 19, 22, 25, 28, 31, 34, 37]

  [Direct Method] writeElement(Lcom/google/protobuf/CodedOutputStream;, Lcom/google/protobuf/WireFormat$FieldType;, I, Ljava/lang/Object;) -> V
    // registers=5, ins=4, outs=3, insns_size=22
    0000: sget v0, Lcom/google/protobuf/WireFormat$FieldType;->GROUP:Lcom/google/protobuf/WireFormat$FieldType;
    0002: if-ne v2, v0, 000a
    0004: check-cast v4, Lcom/google/protobuf/MessageLite;
    0006: invoke-virtual {v1, v3, v4}, Lcom/google/protobuf/CodedOutputStream;->writeGroup(ILcom/google/protobuf/MessageLite;)V
    0009: return-void
    000a: const/4 v0, 0
    000b: invoke-static {v2, v0}, Lcom/google/protobuf/FieldSet;->getWireFormatForFieldType(Lcom/google/protobuf/WireFormat$FieldType;Z)I
    000e: move-result v0
    000f: invoke-virtual {v1, v3, v0}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    0012: invoke-static {v1, v2, v4}, Lcom/google/protobuf/FieldSet;->writeElementNoTag(Lcom/google/protobuf/CodedOutputStream;Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)V
    0015: goto 0009

  [Direct Method] writeElementNoTag(Lcom/google/protobuf/CodedOutputStream;, Lcom/google/protobuf/WireFormat$FieldType;, Ljava/lang/Object;) -> V
    // registers=5, ins=3, outs=3, insns_size=220
    0000: sget v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I
    0002: invoke-virtual {v3}, Lcom/google/protobuf/WireFormat$FieldType;->ordinal()I
    0005: move-result v1
    0006: aget(op=44) v0, v0[v1]
    0008: packed-switch v0, +172 (-> 00b4)
    000b: return-void
    000c: check-cast v4, Ljava/lang/Double;
    000e: invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D
    0011: move-result-wide v0
    0012: invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeDoubleNoTag(D)V
    0015: goto 000b
    0016: check-cast v4, Ljava/lang/Float;
    0018: invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F
    001b: move-result v0
    001c: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeFloatNoTag(F)V
    001f: goto 000b
    0020: check-cast v4, Ljava/lang/Long;
    0022: invoke-virtual {v4}, Ljava/lang/Long;->longValue()J
    0025: move-result-wide v0
    0026: invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeInt64NoTag(J)V
    0029: goto 000b
    002a: check-cast v4, Ljava/lang/Long;
    002c: invoke-virtual {v4}, Ljava/lang/Long;->longValue()J
    002f: move-result-wide v0
    0030: invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt64NoTag(J)V
    0033: goto 000b
    0034: check-cast v4, Ljava/lang/Integer;
    0036: invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I
    0039: move-result v0
    003a: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeInt32NoTag(I)V
    003d: goto 000b
    003e: check-cast v4, Ljava/lang/Long;
    0040: invoke-virtual {v4}, Ljava/lang/Long;->longValue()J
    0043: move-result-wide v0
    0044: invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeFixed64NoTag(J)V
    0047: goto 000b
    0048: check-cast v4, Ljava/lang/Integer;
    004a: invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I
    004d: move-result v0
    004e: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeFixed32NoTag(I)V
    0051: goto 000b
    0052: check-cast v4, Ljava/lang/Boolean;
    0054: invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z
    0057: move-result v0
    0058: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeBoolNoTag(Z)V
    005b: goto 000b
    005c: check-cast v4, Ljava/lang/String;
    005e: invoke-virtual {v2, v4}, Lcom/google/protobuf/CodedOutputStream;->writeStringNoTag(Ljava/lang/String;)V
    0061: goto 000b
    0062: check-cast v4, Lcom/google/protobuf/MessageLite;
    0064: invoke-virtual {v2, v4}, Lcom/google/protobuf/CodedOutputStream;->writeGroupNoTag(Lcom/google/protobuf/MessageLite;)V
    0067: goto 000b
    0068: check-cast v4, Lcom/google/protobuf/MessageLite;
    006a: invoke-virtual {v2, v4}, Lcom/google/protobuf/CodedOutputStream;->writeMessageNoTag(Lcom/google/protobuf/MessageLite;)V
    006d: goto 000b
    006e: check-cast v4, Lcom/google/protobuf/ByteString;
    0070: invoke-virtual {v2, v4}, Lcom/google/protobuf/CodedOutputStream;->writeBytesNoTag(Lcom/google/protobuf/ByteString;)V
    0073: goto 000b
    0074: check-cast v4, Ljava/lang/Integer;
    0076: invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I
    0079: move-result v0
    007a: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V
    007d: goto 000b
    007e: check-cast v4, Ljava/lang/Integer;
    0080: invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I
    0083: move-result v0
    0084: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeSFixed32NoTag(I)V
    0087: goto 000b
    0088: check-cast v4, Ljava/lang/Long;
    008a: invoke-virtual {v4}, Ljava/lang/Long;->longValue()J
    008d: move-result-wide v0
    008e: invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeSFixed64NoTag(J)V
    0091: goto/16 000b
    0093: check-cast v4, Ljava/lang/Integer;
    0095: invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I
    0098: move-result v0
    0099: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeSInt32NoTag(I)V
    009c: goto/16 000b
    009e: check-cast v4, Ljava/lang/Long;
    00a0: invoke-virtual {v4}, Ljava/lang/Long;->longValue()J
    00a3: move-result-wide v0
    00a4: invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeSInt64NoTag(J)V
    00a7: goto/16 000b
    00a9: check-cast v4, Lcom/google/protobuf/Internal$EnumLite;
    00ab: invoke-interface {v4}, Lcom/google/protobuf/Internal$EnumLite;->getNumber()I
    00ae: move-result v0
    00af: invoke-virtual {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeEnumNoTag(I)V
    00b2: goto/16 000b
    00b4: packed-switch-payload first=1 targets=[4, 14, 24, 34, 44, 54, 64, 74, 84, 102, 108, 118, 128, 139, 150, 90, 96, 161]

  [Direct Method] writeField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;, Ljava/lang/Object;, Lcom/google/protobuf/CodedOutputStream;) -> V
    // registers=7, ins=3, outs=4, insns_size=90
    0000: invoke-interface {v4}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    0003: move-result-object v1
    0004: invoke-interface {v4}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getNumber()I
    0007: move-result v0
    0008: invoke-interface {v4}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    000b: move-result v2
    000c: if-eqz v2, 0056
    000e: check-cast v5, Ljava/util/List;
    0010: invoke-interface {v4}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isPacked()Z
    0013: move-result v2
    0014: if-eqz v2, 0044
    0016: const/4 v2, 2
    0017: invoke-virtual {v6, v0, v2}, Lcom/google/protobuf/CodedOutputStream;->writeTag(II)V
    001a: const/4 v0, 0
    001b: invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    001e: move-result-object v2
    001f: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    0022: move-result v3
    0023: if-eqz v3, 002f
    0025: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0028: move-result-object v3
    0029: invoke-static {v1, v3}, Lcom/google/protobuf/FieldSet;->computeElementSizeNoTag(Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)I
    002c: move-result v3
    002d: binop/2addr(op=b0) v0, v3
    002e: goto 001f
    002f: invoke-virtual {v6, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint32(I)V
    0032: invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    0035: move-result-object v0
    0036: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    0039: move-result v2
    003a: if-eqz v2, 0059
    003c: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    003f: move-result-object v2
    0040: invoke-static {v6, v1, v2}, Lcom/google/protobuf/FieldSet;->writeElementNoTag(Lcom/google/protobuf/CodedOutputStream;Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)V
    0043: goto 0036
    0044: invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    0047: move-result-object v2
    0048: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    004b: move-result v3
    004c: if-eqz v3, 0059
    004e: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0051: move-result-object v3
    0052: invoke-static {v6, v1, v0, v3}, Lcom/google/protobuf/FieldSet;->writeElement(Lcom/google/protobuf/CodedOutputStream;Lcom/google/protobuf/WireFormat$FieldType;ILjava/lang/Object;)V
    0055: goto 0048
    0056: invoke-static {v6, v1, v0, v5}, Lcom/google/protobuf/FieldSet;->writeElement(Lcom/google/protobuf/CodedOutputStream;Lcom/google/protobuf/WireFormat$FieldType;ILjava/lang/Object;)V
    0059: return-void

  [Direct Method] writeMessageSetTo(Ljava/util/Map$Entry;, Lcom/google/protobuf/CodedOutputStream;) -> V
    // registers=6, ins=3, outs=3, insns_size=54
    0000: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0003: move-result-object v0
    0004: check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0006: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteJavaType()Lcom/google/protobuf/WireFormat$JavaType;
    0009: move-result-object v1
    000a: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;
    000c: if-ne v1, v2, 002e
    000e: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    0011: move-result v1
    0012: if-nez v1, 002e
    0014: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isPacked()Z
    0017: move-result v1
    0018: if-nez v1, 002e
    001a: invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    001d: move-result-object v0
    001e: check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0020: invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getNumber()I
    0023: move-result v1
    0024: invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0027: move-result-object v0
    0028: check-cast v0, Lcom/google/protobuf/MessageLite;
    002a: invoke-virtual {v5, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeMessageSetExtension(ILcom/google/protobuf/MessageLite;)V
    002d: return-void
    002e: invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0031: move-result-object v1
    0032: invoke-static {v0, v1, v5}, Lcom/google/protobuf/FieldSet;->writeField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;Lcom/google/protobuf/CodedOutputStream;)V
    0035: goto 002d

  [Virtual Method] addRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;, Ljava/lang/Object;) -> V
    // registers=5, ins=3, outs=3, insns_size=46
    0000: invoke-interface {v3}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    0003: move-result v0
    0004: if-nez v0, 000e
    0006: new-instance v0, Ljava/lang/IllegalArgumentException;
    0008: const-string v1, 'addRepeatedField() can only be called on repeated fields.'
    000a: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    000d: throw v0
    000e: invoke-interface {v3}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    0011: move-result-object v0
    0012: invoke-static {v0, v4}, Lcom/google/protobuf/FieldSet;->verifyType(Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)V
    0015: iget v0, v2.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0017: invoke-virtual {v0, v3}, Lcom/google/protobuf/SmallSortedMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    001a: move-result-object v0
    001b: if-nez v0, 002b
    001d: new-instance v0, Ljava/util/ArrayList;
    001f: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0022: iget v1, v2.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0024: invoke-virtual {v1, v3, v0}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;
    0027: invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    002a: return-void
    002b: check-cast v0, Ljava/util/List;
    002d: goto 0027

  [Virtual Method] clear() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: iget v0, v1.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->clear()V
    0005: return-void

  [Virtual Method] clearField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;) -> V
    // registers=3, ins=2, outs=2, insns_size=6
    0000: iget v0, v1.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-virtual {v0, v2}, Lcom/google/protobuf/SmallSortedMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    0005: return-void

  [Virtual Method] clone() -> Lcom/google/protobuf/FieldSet;
    // registers=5, ins=1, outs=3, insns_size=74
    0000: invoke-static {}, Lcom/google/protobuf/FieldSet;->newFieldSet()Lcom/google/protobuf/FieldSet;
    0003: move-result-object v2
    0004: const/4 v0, 0
    0005: move(op=01) v1, v0
    0006: iget v0, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0008: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->getNumArrayEntries()I
    000b: move-result v0
    000c: if-ge v1, v0, 0025
    000e: iget v0, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0010: invoke-virtual {v0, v1}, Lcom/google/protobuf/SmallSortedMap;->getArrayEntryAt(I)Ljava/util/Map$Entry;
    0013: move-result-object v3
    0014: invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0017: move-result-object v0
    0018: check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    001a: invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    001d: move-result-object v3
    001e: invoke-virtual {v2, v0, v3}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V
    0021: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0023: move(op=01) v1, v0
    0024: goto 0006
    0025: iget v0, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0027: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntries()Ljava/lang/Iterable;
    002a: move-result-object v0
    002b: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    002e: move-result-object v3
    002f: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    0032: move-result v0
    0033: if-eqz v0, 0049
    0035: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0038: move-result-object v0
    0039: check-cast v0, Ljava/util/Map$Entry;
    003b: invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    003e: move-result-object v1
    003f: check-cast v1, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0041: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0044: move-result-object v0
    0045: invoke-virtual {v2, v1, v0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V
    0048: goto 002f
    0049: return-object v2

  [Virtual Method] clone() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/FieldSet;->clone()Lcom/google/protobuf/FieldSet;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getAllFields() -> Ljava/util/Map;
    // registers=2, ins=1, outs=1, insns_size=18
    0000: iget v0, v1.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->isImmutable()Z
    0005: move-result v0
    0006: if-eqz v0, 000b
    0008: iget v0, v1.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    000a: return-object v0
    000b: iget v0, v1.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    000d: invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;
    0010: move-result-object v0
    0011: goto 000a

  [Virtual Method] getField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-virtual {v0, v2}, Lcom/google/protobuf/SmallSortedMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] getMessageSetSerializedSize() -> I
    // registers=4, ins=1, outs=2, insns_size=53
    0000: const/4 v0, 0
    0001: move(op=01) v1, v0
    0002: iget v2, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0004: invoke-virtual {v2}, Lcom/google/protobuf/SmallSortedMap;->getNumArrayEntries()I
    0007: move-result v2
    0008: if-ge v0, v2, 0018
    000a: iget v2, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    000c: invoke-virtual {v2, v0}, Lcom/google/protobuf/SmallSortedMap;->getArrayEntryAt(I)Ljava/util/Map$Entry;
    000f: move-result-object v2
    0010: invoke-direct {v3, v2}, Lcom/google/protobuf/FieldSet;->getMessageSetSerializedSize(Ljava/util/Map$Entry;)I
    0013: move-result v2
    0014: binop/2addr(op=b0) v1, v2
    0015: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0017: goto 0002
    0018: iget v0, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    001a: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntries()Ljava/lang/Iterable;
    001d: move-result-object v0
    001e: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    0021: move-result-object v2
    0022: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    0025: move-result v0
    0026: if-eqz v0, 0034
    0028: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    002b: move-result-object v0
    002c: check-cast v0, Ljava/util/Map$Entry;
    002e: invoke-direct {v3, v0}, Lcom/google/protobuf/FieldSet;->getMessageSetSerializedSize(Ljava/util/Map$Entry;)I
    0031: move-result v0
    0032: binop/2addr(op=b0) v1, v0
    0033: goto 0022
    0034: return v1

  [Virtual Method] getRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;, I) -> Ljava/lang/Object;
    // registers=5, ins=3, outs=2, insns_size=35
    0000: invoke-interface {v3}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    0003: move-result v0
    0004: if-nez v0, 000e
    0006: new-instance v0, Ljava/lang/IllegalArgumentException;
    0008: const-string v1, 'getRepeatedField() can only be called on repeated fields.'
    000a: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    000d: throw v0
    000e: iget v0, v2.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0010: invoke-virtual {v0, v3}, Lcom/google/protobuf/SmallSortedMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0013: move-result-object v0
    0014: if-nez v0, 001c
    0016: new-instance v0, Ljava/lang/IndexOutOfBoundsException;
    0018: invoke-direct {v0}, Ljava/lang/IndexOutOfBoundsException;-><init>()V
    001b: throw v0
    001c: check-cast v0, Ljava/util/List;
    001e: invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0021: move-result-object v0
    0022: return-object v0

  [Virtual Method] getRepeatedFieldCount(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;) -> I
    // registers=4, ins=2, outs=2, insns_size=31
    0000: invoke-interface {v3}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    0003: move-result v0
    0004: if-nez v0, 000e
    0006: new-instance v0, Ljava/lang/IllegalArgumentException;
    0008: const-string v1, 'getRepeatedField() can only be called on repeated fields.'
    000a: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    000d: throw v0
    000e: iget v0, v2.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0010: invoke-virtual {v0, v3}, Lcom/google/protobuf/SmallSortedMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0013: move-result-object v0
    0014: if-nez v0, 0018
    0016: const/4 v0, 0
    0017: return v0
    0018: check-cast v0, Ljava/util/List;
    001a: invoke-interface {v0}, Ljava/util/List;->size()I
    001d: move-result v0
    001e: goto 0017

  [Virtual Method] getSerializedSize() -> I
    // registers=5, ins=1, outs=2, insns_size=75
    0000: const/4 v0, 0
    0001: move(op=01) v1, v0
    0002: move(op=01) v2, v0
    0003: iget v0, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0005: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->getNumArrayEntries()I
    0008: move-result v0
    0009: if-ge v1, v0, 0024
    000b: iget v0, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    000d: invoke-virtual {v0, v1}, Lcom/google/protobuf/SmallSortedMap;->getArrayEntryAt(I)Ljava/util/Map$Entry;
    0010: move-result-object v3
    0011: invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0014: move-result-object v0
    0015: check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0017: invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    001a: move-result-object v3
    001b: invoke-static {v0, v3}, Lcom/google/protobuf/FieldSet;->computeFieldSize(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)I
    001e: move-result v0
    001f: binop/2addr(op=b0) v2, v0
    0020: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0022: move(op=01) v1, v0
    0023: goto 0003
    0024: iget v0, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0026: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntries()Ljava/lang/Iterable;
    0029: move-result-object v0
    002a: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    002d: move-result-object v3
    002e: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    0031: move-result v0
    0032: if-eqz v0, 004a
    0034: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0037: move-result-object v0
    0038: check-cast v0, Ljava/util/Map$Entry;
    003a: invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    003d: move-result-object v1
    003e: check-cast v1, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0040: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0043: move-result-object v0
    0044: invoke-static {v1, v0}, Lcom/google/protobuf/FieldSet;->computeFieldSize(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)I
    0047: move-result v0
    0048: binop/2addr(op=b0) v2, v0
    0049: goto 002e
    004a: return v2

  [Virtual Method] hasField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;) -> Z
    // registers=4, ins=2, outs=2, insns_size=26
    0000: invoke-interface {v3}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    0003: move-result v0
    0004: if-eqz v0, 000e
    0006: new-instance v0, Ljava/lang/IllegalArgumentException;
    0008: const-string v1, 'hasField() can only be called on non-repeated fields.'
    000a: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    000d: throw v0
    000e: iget v0, v2.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0010: invoke-virtual {v0, v3}, Lcom/google/protobuf/SmallSortedMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0013: move-result-object v0
    0014: if-eqz v0, 0018
    0016: const/4 v0, 1
    0017: return v0
    0018: const/4 v0, 0
    0019: goto 0017

  [Virtual Method] isImmutable() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/FieldSet;->isImmutable:Z
    0002: return v0

  [Virtual Method] isInitialized() -> Z
    // registers=4, ins=1, outs=2, insns_size=57
    0000: const/4 v1, 0
    0001: move(op=01) v0, v1
    0002: iget v2, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0004: invoke-virtual {v2}, Lcom/google/protobuf/SmallSortedMap;->getNumArrayEntries()I
    0007: move-result v2
    0008: if-ge v0, v2, 001a
    000a: iget v2, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    000c: invoke-virtual {v2, v0}, Lcom/google/protobuf/SmallSortedMap;->getArrayEntryAt(I)Ljava/util/Map$Entry;
    000f: move-result-object v2
    0010: invoke-direct {v3, v2}, Lcom/google/protobuf/FieldSet;->isInitialized(Ljava/util/Map$Entry;)Z
    0013: move-result v2
    0014: if-nez v2, 0017
    0016: return v1
    0017: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0019: goto 0002
    001a: iget v0, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    001c: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntries()Ljava/lang/Iterable;
    001f: move-result-object v0
    0020: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    0023: move-result-object v2
    0024: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    0027: move-result v0
    0028: if-eqz v0, 0037
    002a: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    002d: move-result-object v0
    002e: check-cast v0, Ljava/util/Map$Entry;
    0030: invoke-direct {v3, v0}, Lcom/google/protobuf/FieldSet;->isInitialized(Ljava/util/Map$Entry;)Z
    0033: move-result v0
    0034: if-nez v0, 0024
    0036: goto 0016
    0037: const/4 v1, 1
    0038: goto 0016

  [Virtual Method] iterator() -> Ljava/util/Iterator;
    // registers=2, ins=1, outs=1, insns_size=11
    0000: iget v0, v1.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->entrySet()Ljava/util/Set;
    0005: move-result-object v0
    0006: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    0009: move-result-object v0
    000a: return-object v0

  [Virtual Method] makeImmutable() -> V
    // registers=2, ins=1, outs=1, insns_size=14
    0000: iget v0, v1.Lcom/google/protobuf/FieldSet;->isImmutable:Z
    0002: if-eqz v0, 0005
    0004: return-void
    0005: iget v0, v1.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0007: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->makeImmutable()V
    000a: const/4 v0, 1
    000b: iput v0, v1.Lcom/google/protobuf/FieldSet;->isImmutable:Z
    000d: goto 0004

  [Virtual Method] mergeFrom(Lcom/google/protobuf/FieldSet;) -> V
    // registers=4, ins=2, outs=2, insns_size=48
    0000: const/4 v0, 0
    0001: iget v1, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0003: invoke-virtual {v1}, Lcom/google/protobuf/SmallSortedMap;->getNumArrayEntries()I
    0006: move-result v1
    0007: if-ge v0, v1, 0015
    0009: iget v1, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    000b: invoke-virtual {v1, v0}, Lcom/google/protobuf/SmallSortedMap;->getArrayEntryAt(I)Ljava/util/Map$Entry;
    000e: move-result-object v1
    000f: invoke-direct {v2, v1}, Lcom/google/protobuf/FieldSet;->mergeFromField(Ljava/util/Map$Entry;)V
    0012: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0014: goto 0001
    0015: iget v0, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0017: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntries()Ljava/lang/Iterable;
    001a: move-result-object v0
    001b: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    001e: move-result-object v1
    001f: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    0022: move-result v0
    0023: if-eqz v0, 002f
    0025: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0028: move-result-object v0
    0029: check-cast v0, Ljava/util/Map$Entry;
    002b: invoke-direct {v2, v0}, Lcom/google/protobuf/FieldSet;->mergeFromField(Ljava/util/Map$Entry;)V
    002e: goto 001f
    002f: return-void

  [Virtual Method] setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;, Ljava/lang/Object;) -> V
    // registers=7, ins=3, outs=3, insns_size=65
    0000: invoke-interface {v5}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    0003: move-result v0
    0004: if-eqz v0, 0039
    0006: instance-of v0, v6, Ljava/util/List;
    0008: if-nez v0, 0012
    000a: new-instance v0, Ljava/lang/IllegalArgumentException;
    000c: const-string v1, 'Wrong object type used with protocol message reflection.'
    000e: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0011: throw v0
    0012: new-instance v0, Ljava/util/ArrayList;
    0014: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0017: check-cast v6, Ljava/util/List;
    0019: invoke-interface {v0, v6}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z
    001c: invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    001f: move-result-object v1
    0020: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    0023: move-result v2
    0024: if-eqz v2, 0032
    0026: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0029: move-result-object v2
    002a: invoke-interface {v5}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    002d: move-result-object v3
    002e: invoke-static {v3, v2}, Lcom/google/protobuf/FieldSet;->verifyType(Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)V
    0031: goto 0020
    0032: move(op=07) v6, v0
    0033: iget v0, v4.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0035: invoke-virtual {v0, v5, v6}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;
    0038: return-void
    0039: invoke-interface {v5}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    003c: move-result-object v0
    003d: invoke-static {v0, v6}, Lcom/google/protobuf/FieldSet;->verifyType(Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)V
    0040: goto 0033

  [Virtual Method] setRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;, I, Ljava/lang/Object;) -> V
    // registers=6, ins=4, outs=3, insns_size=41
    0000: invoke-interface {v3}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z
    0003: move-result v0
    0004: if-nez v0, 000e
    0006: new-instance v0, Ljava/lang/IllegalArgumentException;
    0008: const-string v1, 'getRepeatedField() can only be called on repeated fields.'
    000a: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    000d: throw v0
    000e: iget v0, v2.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0010: invoke-virtual {v0, v3}, Lcom/google/protobuf/SmallSortedMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0013: move-result-object v0
    0014: if-nez v0, 001c
    0016: new-instance v0, Ljava/lang/IndexOutOfBoundsException;
    0018: invoke-direct {v0}, Ljava/lang/IndexOutOfBoundsException;-><init>()V
    001b: throw v0
    001c: invoke-interface {v3}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    001f: move-result-object v1
    0020: invoke-static {v1, v5}, Lcom/google/protobuf/FieldSet;->verifyType(Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)V
    0023: check-cast v0, Ljava/util/List;
    0025: invoke-interface {v0, v4, v5}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;
    0028: return-void

  [Virtual Method] writeMessageSetTo(Lcom/google/protobuf/CodedOutputStream;) -> V
    // registers=4, ins=2, outs=3, insns_size=48
    0000: const/4 v0, 0
    0001: iget v1, v2.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0003: invoke-virtual {v1}, Lcom/google/protobuf/SmallSortedMap;->getNumArrayEntries()I
    0006: move-result v1
    0007: if-ge v0, v1, 0015
    0009: iget v1, v2.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    000b: invoke-virtual {v1, v0}, Lcom/google/protobuf/SmallSortedMap;->getArrayEntryAt(I)Ljava/util/Map$Entry;
    000e: move-result-object v1
    000f: invoke-direct {v2, v1, v3}, Lcom/google/protobuf/FieldSet;->writeMessageSetTo(Ljava/util/Map$Entry;Lcom/google/protobuf/CodedOutputStream;)V
    0012: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0014: goto 0001
    0015: iget v0, v2.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0017: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntries()Ljava/lang/Iterable;
    001a: move-result-object v0
    001b: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    001e: move-result-object v1
    001f: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    0022: move-result v0
    0023: if-eqz v0, 002f
    0025: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0028: move-result-object v0
    0029: check-cast v0, Ljava/util/Map$Entry;
    002b: invoke-direct {v2, v0, v3}, Lcom/google/protobuf/FieldSet;->writeMessageSetTo(Ljava/util/Map$Entry;Lcom/google/protobuf/CodedOutputStream;)V
    002e: goto 001f
    002f: return-void

  [Virtual Method] writeTo(Lcom/google/protobuf/CodedOutputStream;) -> V
    // registers=5, ins=2, outs=3, insns_size=70
    0000: const/4 v0, 0
    0001: move(op=01) v1, v0
    0002: iget v0, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0004: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->getNumArrayEntries()I
    0007: move-result v0
    0008: if-ge v1, v0, 0021
    000a: iget v0, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    000c: invoke-virtual {v0, v1}, Lcom/google/protobuf/SmallSortedMap;->getArrayEntryAt(I)Ljava/util/Map$Entry;
    000f: move-result-object v2
    0010: invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0013: move-result-object v0
    0014: check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    0016: invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0019: move-result-object v2
    001a: invoke-static {v0, v2, v4}, Lcom/google/protobuf/FieldSet;->writeField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;Lcom/google/protobuf/CodedOutputStream;)V
    001d: binop/lit8(op=d8) v0, v1, 1 (0x1)
    001f: move(op=01) v1, v0
    0020: goto 0002
    0021: iget v0, v3.Lcom/google/protobuf/FieldSet;->fields:Lcom/google/protobuf/SmallSortedMap;
    0023: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntries()Ljava/lang/Iterable;
    0026: move-result-object v0
    0027: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    002a: move-result-object v2
    002b: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    002e: move-result v0
    002f: if-eqz v0, 0045
    0031: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0034: move-result-object v0
    0035: check-cast v0, Ljava/util/Map$Entry;
    0037: invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    003a: move-result-object v1
    003b: check-cast v1, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;
    003d: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    0040: move-result-object v0
    0041: invoke-static {v1, v0, v4}, Lcom/google/protobuf/FieldSet;->writeField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;Lcom/google/protobuf/CodedOutputStream;)V
    0044: goto 002b
    0045: return-void