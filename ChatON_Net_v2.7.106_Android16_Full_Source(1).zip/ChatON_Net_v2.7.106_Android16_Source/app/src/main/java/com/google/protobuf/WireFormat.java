=== CLASS Lcom/google/protobuf/WireFormat; (Source: WireFormat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] MESSAGE_SET_ITEM: I = 1
  [Static Field] MESSAGE_SET_ITEM_END_TAG: I = 0
  [Static Field] MESSAGE_SET_ITEM_TAG: I = 0
  [Static Field] MESSAGE_SET_MESSAGE: I = 3
  [Static Field] MESSAGE_SET_MESSAGE_TAG: I = 0
  [Static Field] MESSAGE_SET_TYPE_ID: I = 2
  [Static Field] MESSAGE_SET_TYPE_ID_TAG: I = 0
  [Static Field] TAG_TYPE_BITS: I = 3
  [Static Field] TAG_TYPE_MASK: I = 7
  [Static Field] WIRETYPE_END_GROUP: I = 4
  [Static Field] WIRETYPE_FIXED32: I = 5
  [Static Field] WIRETYPE_FIXED64: I = 1
  [Static Field] WIRETYPE_LENGTH_DELIMITED: I = 2
  [Static Field] WIRETYPE_START_GROUP: I = 3
  [Static Field] WIRETYPE_VARINT: I

  [Direct Method] <clinit>() -> V
    // registers=4, ins=0, outs=2, insns_size=30
    0000: const/4 v3, 3
    0001: const/4 v2, 2
    0002: const/4 v1, 1
    0003: invoke-static {v1, v3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I
    0006: move-result v0
    0007: sput v0, Lcom/google/protobuf/WireFormat;->MESSAGE_SET_ITEM_TAG:I
    0009: const/4 v0, 4
    000a: invoke-static {v1, v0}, Lcom/google/protobuf/WireFormat;->makeTag(II)I
    000d: move-result v0
    000e: sput v0, Lcom/google/protobuf/WireFormat;->MESSAGE_SET_ITEM_END_TAG:I
    0010: const/4 v0, 0
    0011: invoke-static {v2, v0}, Lcom/google/protobuf/WireFormat;->makeTag(II)I
    0014: move-result v0
    0015: sput v0, Lcom/google/protobuf/WireFormat;->MESSAGE_SET_TYPE_ID_TAG:I
    0017: invoke-static {v3, v2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I
    001a: move-result v0
    001b: sput v0, Lcom/google/protobuf/WireFormat;->MESSAGE_SET_MESSAGE_TAG:I
    001d: return-void

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getTagFieldNumber(I) -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: binop/lit8(op=e2) v0, v1, 3 (0x3)
    0002: return v0

  [Direct Method] getTagWireType(I) -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: binop/lit8(op=dd) v0, v1, 7 (0x7)
    0002: return v0

  [Direct Method] makeTag(I, I) -> I
    // registers=3, ins=2, outs=0, insns_size=4
    0000: binop/lit8(op=e0) v0, v1, 3 (0x3)
    0002: binop/2addr(op=b6) v0, v2
    0003: return v0