=== CLASS Lcom/google/protobuf/GeneratedMessageLite$Builder; (Source: GeneratedMessageLite.java) ===
  Super: Lcom/google/protobuf/AbstractMessageLite$Builder;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/google/protobuf/AbstractMessageLite$Builder;-><init>()V
    0003: return-void

  [Virtual Method] clear() -> Lcom/google/protobuf/GeneratedMessageLite$Builder;
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-object v0

  [Virtual Method] clear() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/GeneratedMessageLite$Builder;->clear()Lcom/google/protobuf/GeneratedMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clone() -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/GeneratedMessageLite$Builder;->clone()Lcom/google/protobuf/GeneratedMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clone() -> Lcom/google/protobuf/GeneratedMessageLite$Builder;
    // registers=3, ins=1, outs=2, insns_size=8
    0000: new-instance v0, Ljava/lang/UnsupportedOperationException;
    0002: const-string v1, 'This is supposed to be overridden by subclasses.'
    0004: invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    0007: throw v0

  [Virtual Method] clone() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/GeneratedMessageLite$Builder;->clone()Lcom/google/protobuf/GeneratedMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clone() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/GeneratedMessageLite$Builder;->clone()Lcom/google/protobuf/GeneratedMessageLite$Builder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getDefaultInstanceForType() -> Lcom/google/protobuf/GeneratedMessageLite;

  [Virtual Method] getDefaultInstanceForType() -> Lcom/google/protobuf/MessageLite;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/GeneratedMessageLite$Builder;->getDefaultInstanceForType()Lcom/google/protobuf/GeneratedMessageLite;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;) -> Lcom/google/protobuf/GeneratedMessageLite$Builder;

  [Virtual Method] parseUnknownField(Lcom/google/protobuf/CodedInputStream;, Lcom/google/protobuf/ExtensionRegistryLite;, I) -> Z
    // registers=5, ins=4, outs=2, insns_size=5
    0000: invoke-virtual {v2, v4}, Lcom/google/protobuf/CodedInputStream;->skipField(I)Z
    0003: move-result v0
    0004: return v0