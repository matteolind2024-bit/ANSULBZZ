=== CLASS Lcom/google/protobuf/MessageLite$Builder; (Source: MessageLite.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/MessageLiteOrBuilder;, Ljava/lang/Cloneable;

  [Virtual Method] build() -> Lcom/google/protobuf/MessageLite;

  [Virtual Method] buildPartial() -> Lcom/google/protobuf/MessageLite;

  [Virtual Method] clear() -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] clone() -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] mergeDelimitedFrom(Ljava/io/InputStream;) -> Z

  [Virtual Method] mergeDelimitedFrom(Ljava/io/InputStream;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Z

  [Virtual Method] mergeFrom(Lcom/google/protobuf/ByteString;) -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] mergeFrom(Lcom/google/protobuf/ByteString;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] mergeFrom(Lcom/google/protobuf/CodedInputStream;) -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] mergeFrom(Lcom/google/protobuf/CodedInputStream;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] mergeFrom(Ljava/io/InputStream;) -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] mergeFrom(Ljava/io/InputStream;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] mergeFrom([B) -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] mergeFrom([B, I, I) -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] mergeFrom([B, I, I, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] mergeFrom([B, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/MessageLite$Builder;