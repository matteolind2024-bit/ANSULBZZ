=== CLASS Lcom/google/protobuf/ByteString$Output; (Source: ByteString.java) ===
  Super: Ljava/io/FilterOutputStream;
  [Instance Field] bout: Ljava/io/ByteArrayOutputStream;

  [Direct Method] <init>(Ljava/io/ByteArrayOutputStream;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: invoke-direct {v0, v1}, Ljava/io/FilterOutputStream;-><init>(Ljava/io/OutputStream;)V
    0003: iput v1, v0.Lcom/google/protobuf/ByteString$Output;->bout:Ljava/io/ByteArrayOutputStream;
    0005: return-void

  [Direct Method] <init>(Ljava/io/ByteArrayOutputStream;, Lcom/google/protobuf/ByteString$1;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/google/protobuf/ByteString$Output;-><init>(Ljava/io/ByteArrayOutputStream;)V
    0003: return-void

  [Virtual Method] toByteString() -> Lcom/google/protobuf/ByteString;
    // registers=4, ins=1, outs=3, insns_size=13
    0000: iget v0, v3.Lcom/google/protobuf/ByteString$Output;->bout:Ljava/io/ByteArrayOutputStream;
    0002: invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    0005: move-result-object v0
    0006: new-instance v1, Lcom/google/protobuf/ByteString;
    0008: const/4 v2, 0
    0009: invoke-direct {v1, v0, v2}, Lcom/google/protobuf/ByteString;-><init>([BLcom/google/protobuf/ByteString$1;)V
    000c: return-object v1