=== CLASS Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream; (Source: AbstractMessageLite.java) ===
  Super: Ljava/io/FilterInputStream;
  [Instance Field] limit: I

  [Direct Method] <init>(Ljava/io/InputStream;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=6
    0000: invoke-direct {v0, v1}, Ljava/io/FilterInputStream;-><init>(Ljava/io/InputStream;)V
    0003: iput v2, v0.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    0005: return-void

  [Virtual Method] available() -> I
    // registers=3, ins=1, outs=2, insns_size=11
    0000: invoke-super {v2}, Ljava/io/FilterInputStream;->available()I
    0003: move-result v0
    0004: iget v1, v2.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    0006: invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I
    0009: move-result v0
    000a: return v0

  [Virtual Method] read() -> I
    // registers=3, ins=1, outs=1, insns_size=19
    0000: iget v0, v2.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    0002: if-gtz v0, 0006
    0004: const/4 v0, -1
    0005: return v0
    0006: invoke-super {v2}, Ljava/io/FilterInputStream;->read()I
    0009: move-result v0
    000a: if-ltz v0, 0005
    000c: iget v1, v2.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    000e: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0010: iput v1, v2.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    0012: goto 0005

  [Virtual Method] read([B, I, I) -> I
    // registers=6, ins=4, outs=4, insns_size=24
    0000: iget v0, v2.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    0002: if-gtz v0, 0006
    0004: const/4 v0, -1
    0005: return v0
    0006: iget v0, v2.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    0008: invoke-static {v5, v0}, Ljava/lang/Math;->min(II)I
    000b: move-result v0
    000c: invoke-super {v2, v3, v4, v0}, Ljava/io/FilterInputStream;->read([BII)I
    000f: move-result v0
    0010: if-ltz v0, 0005
    0012: iget v1, v2.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    0014: binop/2addr(op=b1) v1, v0
    0015: iput v1, v2.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    0017: goto 0005

  [Virtual Method] skip(J) -> J
    // registers=7, ins=3, outs=4, insns_size=25
    0000: iget v0, v4.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    0002: unop(op=81) v0, v0
    0003: invoke-static {v5, v6, v0, v1}, Ljava/lang/Math;->min(JJ)J
    0006: move-result-wide v0
    0007: invoke-super {v4, v0, v1}, Ljava/io/FilterInputStream;->skip(J)J
    000a: move-result-wide v0
    000b: const-wide/16 v2, 0
    000d: cmp(op=31) v2, v0, v2
    000f: if-ltz v2, 0018
    0011: iget v2, v4.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    0013: unop(op=81) v2, v2
    0014: binop/2addr(op=bc) v2, v0
    0015: unop(op=84) v2, v2
    0016: iput v2, v4.Lcom/google/protobuf/AbstractMessageLite$Builder$LimitedInputStream;->limit:I
    0018: return-wide v0