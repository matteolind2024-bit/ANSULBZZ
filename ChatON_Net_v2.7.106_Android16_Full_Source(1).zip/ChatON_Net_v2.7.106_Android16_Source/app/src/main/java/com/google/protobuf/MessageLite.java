=== CLASS Lcom/google/protobuf/MessageLite; (Source: MessageLite.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/MessageLiteOrBuilder;

  [Virtual Method] getSerializedSize() -> I

  [Virtual Method] newBuilderForType() -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] toBuilder() -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] toByteArray() -> [B

  [Virtual Method] toByteString() -> Lcom/google/protobuf/ByteString;

  [Virtual Method] writeDelimitedTo(Ljava/io/OutputStream;) -> V

  [Virtual Method] writeTo(Lcom/google/protobuf/CodedOutputStream;) -> V

  [Virtual Method] writeTo(Ljava/io/OutputStream;) -> V