=== CLASS Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension; (Source: GeneratedMessageLite.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] containingTypeDefaultInstance: Lcom/google/protobuf/MessageLite;
  [Instance Field] defaultValue: Ljava/lang/Object;
  [Instance Field] descriptor: Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
  [Instance Field] messageDefaultInstance: Lcom/google/protobuf/MessageLite;

  [Direct Method] <init>(Lcom/google/protobuf/MessageLite;, Ljava/lang/Object;, Lcom/google/protobuf/MessageLite;, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;) -> V
    // registers=7, ins=5, outs=2, insns_size=40
    0000: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0003: if-nez v3, 000d
    0005: new-instance v0, Ljava/lang/IllegalArgumentException;
    0007: const-string v1, 'Null containingTypeDefaultInstance'
    0009: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    000c: throw v0
    000d: invoke-virtual {v6}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    0010: move-result-object v0
    0011: sget v1, Lcom/google/protobuf/WireFormat$FieldType;->MESSAGE:Lcom/google/protobuf/WireFormat$FieldType;
    0013: if-ne v0, v1, 001f
    0015: if-nez v5, 001f
    0017: new-instance v0, Ljava/lang/IllegalArgumentException;
    0019: const-string v1, 'Null messageDefaultInstance'
    001b: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    001e: throw v0
    001f: iput v3, v2.Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->containingTypeDefaultInstance:Lcom/google/protobuf/MessageLite;
    0021: iput v4, v2.Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->defaultValue:Ljava/lang/Object;
    0023: iput v5, v2.Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->messageDefaultInstance:Lcom/google/protobuf/MessageLite;
    0025: iput v6, v2.Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0027: return-void

  [Direct Method] <init>(Lcom/google/protobuf/MessageLite;, Ljava/lang/Object;, Lcom/google/protobuf/MessageLite;, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;, Lcom/google/protobuf/GeneratedMessageLite$1;) -> V
    // registers=6, ins=6, outs=5, insns_size=4
    0000: invoke-direct {v0, v1, v2, v3, v4}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;-><init>(Lcom/google/protobuf/MessageLite;Ljava/lang/Object;Lcom/google/protobuf/MessageLite;Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;)V
    0003: return-void

  [Direct Method] access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0002: return-object v0

  [Direct Method] access$200(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> Ljava/lang/Object;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->defaultValue:Ljava/lang/Object;
    0002: return-object v0

  [Direct Method] access$700(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> Lcom/google/protobuf/MessageLite;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->messageDefaultInstance:Lcom/google/protobuf/MessageLite;
    0002: return-object v0

  [Virtual Method] getContainingTypeDefaultInstance() -> Lcom/google/protobuf/MessageLite;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->containingTypeDefaultInstance:Lcom/google/protobuf/MessageLite;
    0002: return-object v0

  [Virtual Method] getMessageDefaultInstance() -> Lcom/google/protobuf/MessageLite;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->messageDefaultInstance:Lcom/google/protobuf/MessageLite;
    0002: return-object v0

  [Virtual Method] getNumber() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getNumber()I
    0005: move-result v0
    0006: return v0