=== CLASS Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder; (Source: GeneratedMessageLite.java) ===
  Super: Lcom/google/protobuf/GeneratedMessageLite$Builder;
  Interfaces: Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessageOrBuilder;
  [Instance Field] extensions: Lcom/google/protobuf/FieldSet;
  [Instance Field] extensionsIsMutable: Z

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=10
    0000: invoke-direct {v1}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>()V
    0003: invoke-static {}, Lcom/google/protobuf/FieldSet;->emptySet()Lcom/google/protobuf/FieldSet;
    0006: move-result-object v0
    0007: iput v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0009: return-void

  [Direct Method] access$000(Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;) -> Lcom/google/protobuf/FieldSet;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-direct {v1}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->buildExtensions()Lcom/google/protobuf/FieldSet;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] buildExtensions() -> Lcom/google/protobuf/FieldSet;
    // registers=2, ins=1, outs=1, insns_size=11
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/FieldSet;->makeImmutable()V
    0005: const/4 v0, 0
    0006: iput v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensionsIsMutable:Z
    0008: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    000a: return-object v0

  [Direct Method] ensureExtensionsIsMutable() -> V
    // registers=2, ins=1, outs=1, insns_size=16
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensionsIsMutable:Z
    0002: if-nez v0, 000f
    0004: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0006: invoke-virtual {v0}, Lcom/google/protobuf/FieldSet;->clone()Lcom/google/protobuf/FieldSet;
    0009: move-result-object v0
    000a: iput v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    000c: const/4 v0, 1
    000d: iput v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensionsIsMutable:Z
    000f: return-void

  [Direct Method] verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> V
    // registers=4, ins=2, outs=2, insns_size=19
    0000: invoke-virtual {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->getContainingTypeDefaultInstance()Lcom/google/protobuf/MessageLite;
    0003: move-result-object v0
    0004: invoke-virtual {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->getDefaultInstanceForType()Lcom/google/protobuf/GeneratedMessageLite;
    0007: move-result-object v1
    0008: if-eq v0, v1, 0012
    000a: new-instance v0, Ljava/lang/IllegalArgumentException;
    000c: const-string v1, 'This extension is for a different message type.  Please make sure that you are not suppressing any generics type warnings.'
    000e: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0011: throw v0
    0012: return-void

  [Virtual Method] addExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;, Ljava/lang/Object;) -> Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    // registers=5, ins=3, outs=3, insns_size=16
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: invoke-direct {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->ensureExtensionsIsMutable()V
    0006: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0008: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    000b: move-result-object v1
    000c: invoke-virtual {v0, v1, v4}, Lcom/google/protobuf/FieldSet;->addRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V
    000f: return-object v2

  [Virtual Method] clear() -> Lcom/google/protobuf/GeneratedMessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->clear()Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clear() -> Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    // registers=2, ins=1, outs=1, insns_size=15
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/FieldSet;->clear()V
    0005: const/4 v0, 0
    0006: iput v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensionsIsMutable:Z
    0008: invoke-super {v1}, Lcom/google/protobuf/GeneratedMessageLite$Builder;->clear()Lcom/google/protobuf/GeneratedMessageLite$Builder;
    000b: move-result-object v0
    000c: check-cast v0, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    000e: return-object v0

  [Virtual Method] clear() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->clear()Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clearExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    // registers=4, ins=2, outs=2, insns_size=16
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: invoke-direct {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->ensureExtensionsIsMutable()V
    0006: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0008: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    000b: move-result-object v1
    000c: invoke-virtual {v0, v1}, Lcom/google/protobuf/FieldSet;->clearField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)V
    000f: return-object v2

  [Virtual Method] clone() -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->clone()Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clone() -> Lcom/google/protobuf/GeneratedMessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->clone()Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clone() -> Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    // registers=3, ins=1, outs=2, insns_size=8
    0000: new-instance v0, Ljava/lang/UnsupportedOperationException;
    0002: const-string v1, 'This is supposed to be overridden by subclasses.'
    0004: invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    0007: throw v0

  [Virtual Method] clone() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->clone()Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clone() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->clone()Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] extensionsAreInitialized() -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/FieldSet;->isInitialized()Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] getExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> Ljava/lang/Object;
    // registers=4, ins=2, outs=2, insns_size=20
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0005: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0008: move-result-object v1
    0009: invoke-virtual {v0, v1}, Lcom/google/protobuf/FieldSet;->getField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;
    000c: move-result-object v0
    000d: if-nez v0, 0013
    000f: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$200(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Ljava/lang/Object;
    0012: move-result-object v0
    0013: return-object v0

  [Virtual Method] getExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;, I) -> Ljava/lang/Object;
    // registers=5, ins=3, outs=3, insns_size=14
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0005: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0008: move-result-object v1
    0009: invoke-virtual {v0, v1, v4}, Lcom/google/protobuf/FieldSet;->getRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;I)Ljava/lang/Object;
    000c: move-result-object v0
    000d: return-object v0

  [Virtual Method] getExtensionCount(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> I
    // registers=4, ins=2, outs=2, insns_size=14
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0005: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0008: move-result-object v1
    0009: invoke-virtual {v0, v1}, Lcom/google/protobuf/FieldSet;->getRepeatedFieldCount(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)I
    000c: move-result v0
    000d: return v0

  [Virtual Method] hasExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;) -> Z
    // registers=4, ins=2, outs=2, insns_size=14
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0005: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0008: move-result-object v1
    0009: invoke-virtual {v0, v1}, Lcom/google/protobuf/FieldSet;->hasField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Z
    000c: move-result v0
    000d: return v0

  [Virtual Method] mergeExtensionFields(Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;) -> V
    // registers=4, ins=2, outs=2, insns_size=13
    0000: invoke-direct {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->ensureExtensionsIsMutable()V
    0003: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0005: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->access$300(Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;)Lcom/google/protobuf/FieldSet;
    0008: move-result-object v1
    0009: invoke-virtual {v0, v1}, Lcom/google/protobuf/FieldSet;->mergeFrom(Lcom/google/protobuf/FieldSet;)V
    000c: return-void

  [Virtual Method] parseUnknownField(Lcom/google/protobuf/CodedInputStream;, Lcom/google/protobuf/ExtensionRegistryLite;, I) -> Z
    // registers=10, ins=4, outs=4, insns_size=352
    0000: const/4 v0, 0
    0001: const/4 v1, 1
    0002: invoke-static {v9}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I
    0005: move-result v2
    0006: invoke-static {v9}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I
    0009: move-result v3
    000a: invoke-virtual {v6}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->getDefaultInstanceForType()Lcom/google/protobuf/GeneratedMessageLite;
    000d: move-result-object v4
    000e: invoke-virtual {v8, v4, v3}, Lcom/google/protobuf/ExtensionRegistryLite;->findLiteExtensionByNumber(Lcom/google/protobuf/MessageLite;I)Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;
    0011: move-result-object v3
    0012: if-nez v3, 001c
    0014: move(op=01) v2, v1
    0015: if-eqz v2, 0057
    0017: invoke-virtual {v7, v9}, Lcom/google/protobuf/CodedInputStream;->skipField(I)Z
    001a: move-result v0
    001b: return v0
    001c: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    001f: move-result-object v4
    0020: invoke-virtual {v4}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    0023: move-result-object v4
    0024: invoke-static {v4, v0}, Lcom/google/protobuf/FieldSet;->getWireFormatForFieldType(Lcom/google/protobuf/WireFormat$FieldType;Z)I
    0027: move-result v4
    0028: if-ne v2, v4, 002c
    002a: move(op=01) v2, v0
    002b: goto 0015
    002c: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    002f: move-result-object v4
    0030: invoke-static {v4}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->access$500(Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;)Z
    0033: move-result v4
    0034: if-eqz v4, 0055
    0036: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0039: move-result-object v4
    003a: invoke-static {v4}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->access$600(Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;)Lcom/google/protobuf/WireFormat$FieldType;
    003d: move-result-object v4
    003e: invoke-virtual {v4}, Lcom/google/protobuf/WireFormat$FieldType;->isPackable()Z
    0041: move-result v4
    0042: if-eqz v4, 0055
    0044: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0047: move-result-object v4
    0048: invoke-virtual {v4}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    004b: move-result-object v4
    004c: invoke-static {v4, v1}, Lcom/google/protobuf/FieldSet;->getWireFormatForFieldType(Lcom/google/protobuf/WireFormat$FieldType;Z)I
    004f: move-result v4
    0050: if-ne v2, v4, 0055
    0052: move(op=01) v2, v0
    0053: move(op=01) v0, v1
    0054: goto 0015
    0055: move(op=01) v2, v1
    0056: goto 0015
    0057: if-eqz v0, 00b9
    0059: invoke-virtual {v7}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32()I
    005c: move-result v0
    005d: invoke-virtual {v7, v0}, Lcom/google/protobuf/CodedInputStream;->pushLimit(I)I
    0060: move-result v0
    0061: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0064: move-result-object v2
    0065: invoke-virtual {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    0068: move-result-object v2
    0069: sget v4, Lcom/google/protobuf/WireFormat$FieldType;->ENUM:Lcom/google/protobuf/WireFormat$FieldType;
    006b: if-ne v2, v4, 0094
    006d: invoke-virtual {v7}, Lcom/google/protobuf/CodedInputStream;->getBytesUntilLimit()I
    0070: move-result v2
    0071: if-lez v2, 00b3
    0073: invoke-virtual {v7}, Lcom/google/protobuf/CodedInputStream;->readEnum()I
    0076: move-result v2
    0077: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    007a: move-result-object v4
    007b: invoke-virtual {v4}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getEnumType()Lcom/google/protobuf/Internal$EnumLiteMap;
    007e: move-result-object v4
    007f: invoke-interface {v4, v2}, Lcom/google/protobuf/Internal$EnumLiteMap;->findValueByNumber(I)Lcom/google/protobuf/Internal$EnumLite;
    0082: move-result-object v2
    0083: if-nez v2, 0087
    0085: move(op=01) v0, v1
    0086: goto 001b
    0087: invoke-direct {v6}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->ensureExtensionsIsMutable()V
    008a: iget v4, v6.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    008c: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    008f: move-result-object v5
    0090: invoke-virtual {v4, v5, v2}, Lcom/google/protobuf/FieldSet;->addRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V
    0093: goto 006d
    0094: invoke-virtual {v7}, Lcom/google/protobuf/CodedInputStream;->getBytesUntilLimit()I
    0097: move-result v2
    0098: if-lez v2, 00b3
    009a: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    009d: move-result-object v2
    009e: invoke-virtual {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    00a1: move-result-object v2
    00a2: invoke-static {v7, v2}, Lcom/google/protobuf/FieldSet;->readPrimitiveField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/WireFormat$FieldType;)Ljava/lang/Object;
    00a5: move-result-object v2
    00a6: invoke-direct {v6}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->ensureExtensionsIsMutable()V
    00a9: iget v4, v6.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    00ab: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    00ae: move-result-object v5
    00af: invoke-virtual {v4, v5, v2}, Lcom/google/protobuf/FieldSet;->addRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V
    00b2: goto 0094
    00b3: invoke-virtual {v7, v0}, Lcom/google/protobuf/CodedInputStream;->popLimit(I)V
    00b6: move(op=01) v0, v1
    00b7: goto/16 001b
    00b9: sget v0, Lcom/google/protobuf/GeneratedMessageLite$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    00bb: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    00be: move-result-object v2
    00bf: invoke-virtual {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getLiteJavaType()Lcom/google/protobuf/WireFormat$JavaType;
    00c2: move-result-object v2
    00c3: invoke-virtual {v2}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    00c6: move-result v2
    00c7: aget(op=44) v0, v0[v2]
    00c9: packed-switch v0, +143 (-> 0158)
    00cc: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    00cf: move-result-object v0
    00d0: invoke-virtual {v0}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    00d3: move-result-object v0
    00d4: invoke-static {v7, v0}, Lcom/google/protobuf/FieldSet;->readPrimitiveField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/WireFormat$FieldType;)Ljava/lang/Object;
    00d7: move-result-object v0
    00d8: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    00db: move-result-object v2
    00dc: invoke-virtual {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->isRepeated()Z
    00df: move-result v2
    00e0: if-eqz v2, 0147
    00e2: invoke-direct {v6}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->ensureExtensionsIsMutable()V
    00e5: iget v2, v6.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    00e7: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    00ea: move-result-object v3
    00eb: invoke-virtual {v2, v3, v0}, Lcom/google/protobuf/FieldSet;->addRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V
    00ee: goto 00b6
    00ef: const/4 v2, 0
    00f0: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    00f3: move-result-object v0
    00f4: invoke-virtual {v0}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->isRepeated()Z
    00f7: move-result v0
    00f8: if-nez v0, 0155
    00fa: iget v0, v6.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    00fc: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    00ff: move-result-object v4
    0100: invoke-virtual {v0, v4}, Lcom/google/protobuf/FieldSet;->getField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;
    0103: move-result-object v0
    0104: check-cast v0, Lcom/google/protobuf/MessageLite;
    0106: if-eqz v0, 0155
    0108: invoke-interface {v0}, Lcom/google/protobuf/MessageLite;->toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    010b: move-result-object v0
    010c: if-nez v0, 0116
    010e: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$700(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/MessageLite;
    0111: move-result-object v0
    0112: invoke-interface {v0}, Lcom/google/protobuf/MessageLite;->newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    0115: move-result-object v0
    0116: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0119: move-result-object v2
    011a: invoke-virtual {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    011d: move-result-object v2
    011e: sget v4, Lcom/google/protobuf/WireFormat$FieldType;->GROUP:Lcom/google/protobuf/WireFormat$FieldType;
    0120: if-ne v2, v4, 012e
    0122: invoke-virtual {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->getNumber()I
    0125: move-result v2
    0126: invoke-virtual {v7, v2, v0, v8}, Lcom/google/protobuf/CodedInputStream;->readGroup(ILcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    0129: invoke-interface {v0}, Lcom/google/protobuf/MessageLite$Builder;->build()Lcom/google/protobuf/MessageLite;
    012c: move-result-object v0
    012d: goto 00d8
    012e: invoke-virtual {v7, v0, v8}, Lcom/google/protobuf/CodedInputStream;->readMessage(Lcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    0131: goto 0129
    0132: invoke-virtual {v7}, Lcom/google/protobuf/CodedInputStream;->readEnum()I
    0135: move-result v0
    0136: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    0139: move-result-object v2
    013a: invoke-virtual {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getEnumType()Lcom/google/protobuf/Internal$EnumLiteMap;
    013d: move-result-object v2
    013e: invoke-interface {v2, v0}, Lcom/google/protobuf/Internal$EnumLiteMap;->findValueByNumber(I)Lcom/google/protobuf/Internal$EnumLite;
    0141: move-result-object v0
    0142: if-nez v0, 00d8
    0144: move(op=01) v0, v1
    0145: goto/16 001b
    0147: invoke-direct {v6}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->ensureExtensionsIsMutable()V
    014a: iget v2, v6.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    014c: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    014f: move-result-object v3
    0150: invoke-virtual {v2, v3, v0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V
    0153: goto/16 00b6
    0155: move(op=07) v0, v2
    0156: goto 010c
    0157: nop
    0158: packed-switch-payload first=1 targets=[38, 105]

  [Virtual Method] setExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;, I, Ljava/lang/Object;) -> Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    // registers=6, ins=4, outs=4, insns_size=16
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: invoke-direct {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->ensureExtensionsIsMutable()V
    0006: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0008: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    000b: move-result-object v1
    000c: invoke-virtual {v0, v1, v4, v5}, Lcom/google/protobuf/FieldSet;->setRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;ILjava/lang/Object;)V
    000f: return-object v2

  [Virtual Method] setExtension(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;, Ljava/lang/Object;) -> Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;
    // registers=5, ins=3, outs=3, insns_size=16
    0000: invoke-direct {v2, v3}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->verifyExtensionContainingType(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)V
    0003: invoke-direct {v2}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->ensureExtensionsIsMutable()V
    0006: iget v0, v2.Lcom/google/protobuf/GeneratedMessageLite$ExtendableBuilder;->extensions:Lcom/google/protobuf/FieldSet;
    0008: invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->access$100(Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;)Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;
    000b: move-result-object v1
    000c: invoke-virtual {v0, v1, v4}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V
    000f: return-object v2