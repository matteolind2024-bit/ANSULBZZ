=== CLASS Lcom/google/protobuf/SmallSortedMap$EntryIterator; (Source: SmallSortedMap.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/util/Iterator;
  [Instance Field] lazyOverflowIterator: Ljava/util/Iterator;
  [Instance Field] nextCalledBeforeRemove: Z
  [Instance Field] pos: I
  [Instance Field] this$0: Lcom/google/protobuf/SmallSortedMap;

  [Direct Method] <init>(Lcom/google/protobuf/SmallSortedMap;) -> V
    // registers=3, ins=2, outs=1, insns_size=9
    0000: iput v2, v1.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0005: const/4 v0, -1
    0006: iput v0, v1.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->pos:I
    0008: return-void

  [Direct Method] <init>(Lcom/google/protobuf/SmallSortedMap;, Lcom/google/protobuf/SmallSortedMap$1;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/google/protobuf/SmallSortedMap$EntryIterator;-><init>(Lcom/google/protobuf/SmallSortedMap;)V
    0003: return-void

  [Direct Method] getOverflowIterator() -> Ljava/util/Iterator;
    // registers=2, ins=1, outs=1, insns_size=23
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->lazyOverflowIterator:Ljava/util/Iterator;
    0002: if-nez v0, 0014
    0004: iget v0, v1.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0006: invoke-static {v0}, Lcom/google/protobuf/SmallSortedMap;->access$600(Lcom/google/protobuf/SmallSortedMap;)Ljava/util/Map;
    0009: move-result-object v0
    000a: invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    000d: move-result-object v0
    000e: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    0011: move-result-object v0
    0012: iput v0, v1.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->lazyOverflowIterator:Ljava/util/Iterator;
    0014: iget v0, v1.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->lazyOverflowIterator:Ljava/util/Iterator;
    0016: return-object v0

  [Virtual Method] hasNext() -> Z
    // registers=3, ins=1, outs=1, insns_size=30
    0000: iget v0, v2.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->pos:I
    0002: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0004: iget v1, v2.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0006: invoke-static {v1}, Lcom/google/protobuf/SmallSortedMap;->access$400(Lcom/google/protobuf/SmallSortedMap;)Ljava/util/List;
    0009: move-result-object v1
    000a: invoke-interface {v1}, Ljava/util/List;->size()I
    000d: move-result v1
    000e: if-lt v0, v1, 001a
    0010: invoke-direct {v2}, Lcom/google/protobuf/SmallSortedMap$EntryIterator;->getOverflowIterator()Ljava/util/Iterator;
    0013: move-result-object v0
    0014: invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z
    0017: move-result v0
    0018: if-eqz v0, 001c
    001a: const/4 v0, 1
    001b: return v0
    001c: const/4 v0, 0
    001d: goto 001b

  [Virtual Method] next() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/google/protobuf/SmallSortedMap$EntryIterator;->next()Ljava/util/Map$Entry;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] next() -> Ljava/util/Map$Entry;
    // registers=3, ins=1, outs=2, insns_size=47
    0000: const/4 v0, 1
    0001: iput v0, v2.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->nextCalledBeforeRemove:Z
    0003: iget v0, v2.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->pos:I
    0005: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0007: iput v0, v2.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->pos:I
    0009: iget v1, v2.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->this$0:Lcom/google/protobuf/SmallSortedMap;
    000b: invoke-static {v1}, Lcom/google/protobuf/SmallSortedMap;->access$400(Lcom/google/protobuf/SmallSortedMap;)Ljava/util/List;
    000e: move-result-object v1
    000f: invoke-interface {v1}, Ljava/util/List;->size()I
    0012: move-result v1
    0013: if-ge v0, v1, 0024
    0015: iget v0, v2.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0017: invoke-static {v0}, Lcom/google/protobuf/SmallSortedMap;->access$400(Lcom/google/protobuf/SmallSortedMap;)Ljava/util/List;
    001a: move-result-object v0
    001b: iget v1, v2.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->pos:I
    001d: invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0020: move-result-object v0
    0021: check-cast v0, Ljava/util/Map$Entry;
    0023: return-object v0
    0024: invoke-direct {v2}, Lcom/google/protobuf/SmallSortedMap$EntryIterator;->getOverflowIterator()Ljava/util/Iterator;
    0027: move-result-object v0
    0028: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    002b: move-result-object v0
    002c: check-cast v0, Ljava/util/Map$Entry;
    002e: goto 0023

  [Virtual Method] remove() -> V
    // registers=4, ins=1, outs=2, insns_size=54
    0000: iget v0, v3.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->nextCalledBeforeRemove:Z
    0002: if-nez v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'remove() was called before next()'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: const/4 v0, 0
    000d: iput v0, v3.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->nextCalledBeforeRemove:Z
    000f: iget v0, v3.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0011: invoke-static {v0}, Lcom/google/protobuf/SmallSortedMap;->access$200(Lcom/google/protobuf/SmallSortedMap;)V
    0014: iget v0, v3.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->pos:I
    0016: iget v1, v3.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0018: invoke-static {v1}, Lcom/google/protobuf/SmallSortedMap;->access$400(Lcom/google/protobuf/SmallSortedMap;)Ljava/util/List;
    001b: move-result-object v1
    001c: invoke-interface {v1}, Ljava/util/List;->size()I
    001f: move-result v1
    0020: if-ge v0, v1, 002e
    0022: iget v0, v3.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->this$0:Lcom/google/protobuf/SmallSortedMap;
    0024: iget v1, v3.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->pos:I
    0026: binop/lit8(op=d8) v2, v1, -1 (-0x1)
    0028: iput v2, v3.Lcom/google/protobuf/SmallSortedMap$EntryIterator;->pos:I
    002a: invoke-static {v0, v1}, Lcom/google/protobuf/SmallSortedMap;->access$500(Lcom/google/protobuf/SmallSortedMap;I)Ljava/lang/Object;
    002d: return-void
    002e: invoke-direct {v3}, Lcom/google/protobuf/SmallSortedMap$EntryIterator;->getOverflowIterator()Ljava/util/Iterator;
    0031: move-result-object v0
    0032: invoke-interface {v0}, Ljava/util/Iterator;->remove()V
    0035: goto 002d