=== CLASS Lcom/google/protobuf/Internal$EnumLiteMap; (Source: Internal.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] findValueByNumber(I) -> Lcom/google/protobuf/Internal$EnumLite;