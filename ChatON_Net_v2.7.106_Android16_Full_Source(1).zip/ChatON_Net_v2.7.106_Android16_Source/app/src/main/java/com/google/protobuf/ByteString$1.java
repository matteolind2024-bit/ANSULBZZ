=== CLASS Lcom/google/protobuf/ByteString$1; (Source: ByteString.java) ===
  Super: Ljava/lang/Object;