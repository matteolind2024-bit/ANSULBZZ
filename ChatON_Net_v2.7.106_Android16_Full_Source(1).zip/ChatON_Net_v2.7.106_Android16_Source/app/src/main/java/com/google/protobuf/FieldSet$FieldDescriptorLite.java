=== CLASS Lcom/google/protobuf/FieldSet$FieldDescriptorLite; (Source: FieldSet.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/lang/Comparable;

  [Virtual Method] getEnumType() -> Lcom/google/protobuf/Internal$EnumLiteMap;

  [Virtual Method] getLiteJavaType() -> Lcom/google/protobuf/WireFormat$JavaType;

  [Virtual Method] getLiteType() -> Lcom/google/protobuf/WireFormat$FieldType;

  [Virtual Method] getNumber() -> I

  [Virtual Method] internalMergeFrom(Lcom/google/protobuf/MessageLite$Builder;, Lcom/google/protobuf/MessageLite;) -> Lcom/google/protobuf/MessageLite$Builder;

  [Virtual Method] isPacked() -> Z

  [Virtual Method] isRepeated() -> Z