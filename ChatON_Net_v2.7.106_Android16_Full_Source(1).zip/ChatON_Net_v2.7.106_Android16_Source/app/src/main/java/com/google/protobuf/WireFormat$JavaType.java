=== CLASS Lcom/google/protobuf/WireFormat$JavaType; (Source: WireFormat.java) ===
  Super: Ljava/lang/Enum;
  [Static Field] $VALUES: [Lcom/google/protobuf/WireFormat$JavaType;
  [Static Field] BOOLEAN: Lcom/google/protobuf/WireFormat$JavaType;
  [Static Field] BYTE_STRING: Lcom/google/protobuf/WireFormat$JavaType;
  [Static Field] DOUBLE: Lcom/google/protobuf/WireFormat$JavaType;
  [Static Field] ENUM: Lcom/google/protobuf/WireFormat$JavaType;
  [Static Field] FLOAT: Lcom/google/protobuf/WireFormat$JavaType;
  [Static Field] INT: Lcom/google/protobuf/WireFormat$JavaType;
  [Static Field] LONG: Lcom/google/protobuf/WireFormat$JavaType;
  [Static Field] MESSAGE: Lcom/google/protobuf/WireFormat$JavaType;
  [Static Field] STRING: Lcom/google/protobuf/WireFormat$JavaType;
  [Instance Field] defaultDefault: Ljava/lang/Object;

  [Direct Method] <clinit>() -> V
    // registers=9, ins=0, outs=4, insns_size=170
    0000: const/4 v8, 4
    0001: const/4 v7, 3
    0002: const/4 v6, 2
    0003: const/4 v5, 1
    0004: const/4 v4, 0
    0005: new-instance v0, Lcom/google/protobuf/WireFormat$JavaType;
    0007: const-string v1, 'INT'
    0009: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    000c: move-result-object v2
    000d: invoke-direct {v0, v1, v4, v2}, Lcom/google/protobuf/WireFormat$JavaType;-><init>(Ljava/lang/String;ILjava/lang/Object;)V
    0010: sput v0, Lcom/google/protobuf/WireFormat$JavaType;->INT:Lcom/google/protobuf/WireFormat$JavaType;
    0012: new-instance v0, Lcom/google/protobuf/WireFormat$JavaType;
    0014: const-string v1, 'LONG'
    0016: const-wide/16 v2, 0
    0018: invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    001b: move-result-object v2
    001c: invoke-direct {v0, v1, v5, v2}, Lcom/google/protobuf/WireFormat$JavaType;-><init>(Ljava/lang/String;ILjava/lang/Object;)V
    001f: sput v0, Lcom/google/protobuf/WireFormat$JavaType;->LONG:Lcom/google/protobuf/WireFormat$JavaType;
    0021: new-instance v0, Lcom/google/protobuf/WireFormat$JavaType;
    0023: const-string v1, 'FLOAT'
    0025: const/4 v2, 0
    0026: invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;
    0029: move-result-object v2
    002a: invoke-direct {v0, v1, v6, v2}, Lcom/google/protobuf/WireFormat$JavaType;-><init>(Ljava/lang/String;ILjava/lang/Object;)V
    002d: sput v0, Lcom/google/protobuf/WireFormat$JavaType;->FLOAT:Lcom/google/protobuf/WireFormat$JavaType;
    002f: new-instance v0, Lcom/google/protobuf/WireFormat$JavaType;
    0031: const-string v1, 'DOUBLE'
    0033: const-wide/16 v2, 0
    0035: invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;
    0038: move-result-object v2
    0039: invoke-direct {v0, v1, v7, v2}, Lcom/google/protobuf/WireFormat$JavaType;-><init>(Ljava/lang/String;ILjava/lang/Object;)V
    003c: sput v0, Lcom/google/protobuf/WireFormat$JavaType;->DOUBLE:Lcom/google/protobuf/WireFormat$JavaType;
    003e: new-instance v0, Lcom/google/protobuf/WireFormat$JavaType;
    0040: const-string v1, 'BOOLEAN'
    0042: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0045: move-result-object v2
    0046: invoke-direct {v0, v1, v8, v2}, Lcom/google/protobuf/WireFormat$JavaType;-><init>(Ljava/lang/String;ILjava/lang/Object;)V
    0049: sput v0, Lcom/google/protobuf/WireFormat$JavaType;->BOOLEAN:Lcom/google/protobuf/WireFormat$JavaType;
    004b: new-instance v0, Lcom/google/protobuf/WireFormat$JavaType;
    004d: const-string v1, 'STRING'
    004f: const/4 v2, 5
    0050: const-string v3, ''
    0052: invoke-direct {v0, v1, v2, v3}, Lcom/google/protobuf/WireFormat$JavaType;-><init>(Ljava/lang/String;ILjava/lang/Object;)V
    0055: sput v0, Lcom/google/protobuf/WireFormat$JavaType;->STRING:Lcom/google/protobuf/WireFormat$JavaType;
    0057: new-instance v0, Lcom/google/protobuf/WireFormat$JavaType;
    0059: const-string v1, 'BYTE_STRING'
    005b: const/4 v2, 6
    005c: sget v3, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;
    005e: invoke-direct {v0, v1, v2, v3}, Lcom/google/protobuf/WireFormat$JavaType;-><init>(Ljava/lang/String;ILjava/lang/Object;)V
    0061: sput v0, Lcom/google/protobuf/WireFormat$JavaType;->BYTE_STRING:Lcom/google/protobuf/WireFormat$JavaType;
    0063: new-instance v0, Lcom/google/protobuf/WireFormat$JavaType;
    0065: const-string v1, 'ENUM'
    0067: const/4 v2, 7
    0068: const/4 v3, 0
    0069: invoke-direct {v0, v1, v2, v3}, Lcom/google/protobuf/WireFormat$JavaType;-><init>(Ljava/lang/String;ILjava/lang/Object;)V
    006c: sput v0, Lcom/google/protobuf/WireFormat$JavaType;->ENUM:Lcom/google/protobuf/WireFormat$JavaType;
    006e: new-instance v0, Lcom/google/protobuf/WireFormat$JavaType;
    0070: const-string v1, 'MESSAGE'
    0072: const/16 v2, 8 (0x8)
    0074: const/4 v3, 0
    0075: invoke-direct {v0, v1, v2, v3}, Lcom/google/protobuf/WireFormat$JavaType;-><init>(Ljava/lang/String;ILjava/lang/Object;)V
    0078: sput v0, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;
    007a: const/16 v0, 9 (0x9)
    007c: new-array v0, v0, [Lcom/google/protobuf/WireFormat$JavaType;
    007e: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->INT:Lcom/google/protobuf/WireFormat$JavaType;
    0080: aput(op=4d) v1, v0[v4]
    0082: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->LONG:Lcom/google/protobuf/WireFormat$JavaType;
    0084: aput(op=4d) v1, v0[v5]
    0086: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->FLOAT:Lcom/google/protobuf/WireFormat$JavaType;
    0088: aput(op=4d) v1, v0[v6]
    008a: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->DOUBLE:Lcom/google/protobuf/WireFormat$JavaType;
    008c: aput(op=4d) v1, v0[v7]
    008e: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->BOOLEAN:Lcom/google/protobuf/WireFormat$JavaType;
    0090: aput(op=4d) v1, v0[v8]
    0092: const/4 v1, 5
    0093: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->STRING:Lcom/google/protobuf/WireFormat$JavaType;
    0095: aput(op=4d) v2, v0[v1]
    0097: const/4 v1, 6
    0098: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->BYTE_STRING:Lcom/google/protobuf/WireFormat$JavaType;
    009a: aput(op=4d) v2, v0[v1]
    009c: const/4 v1, 7
    009d: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->ENUM:Lcom/google/protobuf/WireFormat$JavaType;
    009f: aput(op=4d) v2, v0[v1]
    00a1: const/16 v1, 8 (0x8)
    00a3: sget v2, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;
    00a5: aput(op=4d) v2, v0[v1]
    00a7: sput v0, Lcom/google/protobuf/WireFormat$JavaType;->$VALUES:[Lcom/google/protobuf/WireFormat$JavaType;
    00a9: return-void

  [Direct Method] <init>(Ljava/lang/String;, I, Ljava/lang/Object;) -> V
    // registers=4, ins=4, outs=3, insns_size=6
    0000: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    0003: iput v3, v0.Lcom/google/protobuf/WireFormat$JavaType;->defaultDefault:Ljava/lang/Object;
    0005: return-void

  [Direct Method] valueOf(Ljava/lang/String;) -> Lcom/google/protobuf/WireFormat$JavaType;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: const-class v0, Lcom/google/protobuf/WireFormat$JavaType;
    0002: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    0005: move-result-object v0
    0006: check-cast v0, Lcom/google/protobuf/WireFormat$JavaType;
    0008: return-object v0

  [Direct Method] values() -> [Lcom/google/protobuf/WireFormat$JavaType;
    // registers=1, ins=0, outs=1, insns_size=9
    0000: sget v0, Lcom/google/protobuf/WireFormat$JavaType;->$VALUES:[Lcom/google/protobuf/WireFormat$JavaType;
    0002: invoke-virtual {v0}, [Lcom/google/protobuf/WireFormat$JavaType;->clone()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, [Lcom/google/protobuf/WireFormat$JavaType;
    0008: return-object v0

  [Virtual Method] getDefaultDefault() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/WireFormat$JavaType;->defaultDefault:Ljava/lang/Object;
    0002: return-object v0