=== CLASS Lcom/google/protobuf/SmallSortedMap; (Source: SmallSortedMap.java) ===
  Super: Ljava/util/AbstractMap;
  [Instance Field] entryList: Ljava/util/List;
  [Instance Field] isImmutable: Z
  [Instance Field] lazyEntrySet: Lcom/google/protobuf/SmallSortedMap$EntrySet;
  [Instance Field] maxArraySize: I
  [Instance Field] overflowEntries: Ljava/util/Map;

  [Direct Method] <init>(I) -> V
    // registers=3, ins=2, outs=1, insns_size=18
    0000: invoke-direct {v1}, Ljava/util/AbstractMap;-><init>()V
    0003: iput v2, v1.Lcom/google/protobuf/SmallSortedMap;->maxArraySize:I
    0005: invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;
    0008: move-result-object v0
    0009: iput v0, v1.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    000b: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    000e: move-result-object v0
    000f: iput v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0011: return-void

  [Direct Method] <init>(I, Lcom/google/protobuf/SmallSortedMap$1;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/google/protobuf/SmallSortedMap;-><init>(I)V
    0003: return-void

  [Direct Method] access$200(Lcom/google/protobuf/SmallSortedMap;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/google/protobuf/SmallSortedMap;->checkMutable()V
    0003: return-void

  [Direct Method] access$400(Lcom/google/protobuf/SmallSortedMap;) -> Ljava/util/List;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    0002: return-object v0

  [Direct Method] access$500(Lcom/google/protobuf/SmallSortedMap;, I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-direct {v1, v2}, Lcom/google/protobuf/SmallSortedMap;->removeArrayEntryAt(I)Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] access$600(Lcom/google/protobuf/SmallSortedMap;) -> Ljava/util/Map;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0002: return-object v0

  [Direct Method] binarySearchInArray(Ljava/lang/Comparable;) -> I
    // registers=7, ins=2, outs=2, insns_size=81
    0000: const/4 v2, 0
    0001: iget v0, v5.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    0003: invoke-interface {v0}, Ljava/util/List;->size()I
    0006: move-result v0
    0007: binop/lit8(op=d8) v1, v0, -1 (-0x1)
    0009: if-ltz v1, 0025
    000b: iget v0, v5.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    000d: invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0010: move-result-object v0
    0011: check-cast v0, Lcom/google/protobuf/SmallSortedMap$Entry;
    0013: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap$Entry;->getKey()Ljava/lang/Comparable;
    0016: move-result-object v0
    0017: invoke-interface {v6, v0}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I
    001a: move-result v0
    001b: if-lez v0, 0021
    001d: binop/lit8(op=d8) v0, v1, 2 (0x2)
    001f: unop(op=7b) v0, v0
    0020: return v0
    0021: if-nez v0, 0025
    0023: move(op=01) v0, v1
    0024: goto 0020
    0025: if-gt v2, v1, 004d
    0027: binop(op=90) v0, v2, v1
    0029: binop/lit8(op=db) v3, v0, 2 (0x2)
    002b: iget v0, v5.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    002d: invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0030: move-result-object v0
    0031: check-cast v0, Lcom/google/protobuf/SmallSortedMap$Entry;
    0033: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap$Entry;->getKey()Ljava/lang/Comparable;
    0036: move-result-object v0
    0037: invoke-interface {v6, v0}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I
    003a: move-result v0
    003b: if-gez v0, 0043
    003d: binop/lit8(op=d8) v0, v3, -1 (-0x1)
    003f: move(op=01) v1, v2
    0040: move(op=01) v2, v1
    0041: move(op=01) v1, v0
    0042: goto 0025
    0043: if-lez v0, 004b
    0045: binop/lit8(op=d8) v0, v3, 1 (0x1)
    0047: move(op=01) v4, v1
    0048: move(op=01) v1, v0
    0049: move(op=01) v0, v4
    004a: goto 0040
    004b: move(op=01) v0, v3
    004c: goto 0020
    004d: binop/lit8(op=d8) v0, v2, 1 (0x1)
    004f: unop(op=7b) v0, v0
    0050: goto 0020

  [Direct Method] checkMutable() -> V
    // registers=2, ins=1, outs=1, insns_size=11
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->isImmutable:Z
    0002: if-eqz v0, 000a
    0004: new-instance v0, Ljava/lang/UnsupportedOperationException;
    0006: invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V
    0009: throw v0
    000a: return-void

  [Direct Method] ensureEntryArrayMutable() -> V
    // registers=3, ins=1, outs=2, insns_size=27
    0000: invoke-direct {v2}, Lcom/google/protobuf/SmallSortedMap;->checkMutable()V
    0003: iget v0, v2.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    0005: invoke-interface {v0}, Ljava/util/List;->isEmpty()Z
    0008: move-result v0
    0009: if-eqz v0, 001a
    000b: iget v0, v2.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    000d: instance-of v0, v0, Ljava/util/ArrayList;
    000f: if-nez v0, 001a
    0011: new-instance v0, Ljava/util/ArrayList;
    0013: iget v1, v2.Lcom/google/protobuf/SmallSortedMap;->maxArraySize:I
    0015: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V
    0018: iput v0, v2.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    001a: return-void

  [Direct Method] getOverflowEntriesMutable() -> Ljava/util/SortedMap;
    // registers=2, ins=1, outs=1, insns_size=29
    0000: invoke-direct {v1}, Lcom/google/protobuf/SmallSortedMap;->checkMutable()V
    0003: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0005: invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z
    0008: move-result v0
    0009: if-eqz v0, 0018
    000b: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    000d: instance-of v0, v0, Ljava/util/TreeMap;
    000f: if-nez v0, 0018
    0011: new-instance v0, Ljava/util/TreeMap;
    0013: invoke-direct {v0}, Ljava/util/TreeMap;-><init>()V
    0016: iput v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0018: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    001a: check-cast v0, Ljava/util/SortedMap;
    001c: return-object v0

  [Direct Method] newFieldMap(I) -> Lcom/google/protobuf/SmallSortedMap;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Lcom/google/protobuf/SmallSortedMap$1;
    0002: invoke-direct {v0, v1}, Lcom/google/protobuf/SmallSortedMap$1;-><init>(I)V
    0005: return-object v0

  [Direct Method] newInstanceForTest(I) -> Lcom/google/protobuf/SmallSortedMap;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Lcom/google/protobuf/SmallSortedMap;
    0002: invoke-direct {v0, v1}, Lcom/google/protobuf/SmallSortedMap;-><init>(I)V
    0005: return-object v0

  [Direct Method] removeArrayEntryAt(I) -> Ljava/lang/Object;
    // registers=7, ins=2, outs=3, insns_size=55
    0000: invoke-direct {v5}, Lcom/google/protobuf/SmallSortedMap;->checkMutable()V
    0003: iget v0, v5.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    0005: invoke-interface {v0, v6}, Ljava/util/List;->remove(I)Ljava/lang/Object;
    0008: move-result-object v0
    0009: check-cast v0, Lcom/google/protobuf/SmallSortedMap$Entry;
    000b: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap$Entry;->getValue()Ljava/lang/Object;
    000e: move-result-object v1
    000f: iget v0, v5.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0011: invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z
    0014: move-result v0
    0015: if-nez v0, 0036
    0017: invoke-direct {v5}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntriesMutable()Ljava/util/SortedMap;
    001a: move-result-object v0
    001b: invoke-interface {v0}, Ljava/util/SortedMap;->entrySet()Ljava/util/Set;
    001e: move-result-object v0
    001f: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    0022: move-result-object v2
    0023: iget v3, v5.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    0025: new-instance v4, Lcom/google/protobuf/SmallSortedMap$Entry;
    0027: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    002a: move-result-object v0
    002b: check-cast v0, Ljava/util/Map$Entry;
    002d: invoke-direct {v4, v5, v0}, Lcom/google/protobuf/SmallSortedMap$Entry;-><init>(Lcom/google/protobuf/SmallSortedMap;Ljava/util/Map$Entry;)V
    0030: invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    0033: invoke-interface {v2}, Ljava/util/Iterator;->remove()V
    0036: return-object v1

  [Virtual Method] clear() -> V
    // registers=2, ins=1, outs=1, insns_size=30
    0000: invoke-direct {v1}, Lcom/google/protobuf/SmallSortedMap;->checkMutable()V
    0003: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    0005: invoke-interface {v0}, Ljava/util/List;->isEmpty()Z
    0008: move-result v0
    0009: if-nez v0, 0010
    000b: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    000d: invoke-interface {v0}, Ljava/util/List;->clear()V
    0010: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0012: invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z
    0015: move-result v0
    0016: if-nez v0, 001d
    0018: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    001a: invoke-interface {v0}, Ljava/util/Map;->clear()V
    001d: return-void

  [Virtual Method] containsKey(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=2, insns_size=20
    0000: check-cast v2, Ljava/lang/Comparable;
    0002: invoke-direct {v1, v2}, Lcom/google/protobuf/SmallSortedMap;->binarySearchInArray(Ljava/lang/Comparable;)I
    0005: move-result v0
    0006: if-gez v0, 0010
    0008: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    000a: invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z
    000d: move-result v0
    000e: if-eqz v0, 0012
    0010: const/4 v0, 1
    0011: return v0
    0012: const/4 v0, 0
    0013: goto 0011

  [Virtual Method] entrySet() -> Ljava/util/Set;
    // registers=3, ins=1, outs=3, insns_size=15
    0000: iget v0, v2.Lcom/google/protobuf/SmallSortedMap;->lazyEntrySet:Lcom/google/protobuf/SmallSortedMap$EntrySet;
    0002: if-nez v0, 000c
    0004: new-instance v0, Lcom/google/protobuf/SmallSortedMap$EntrySet;
    0006: const/4 v1, 0
    0007: invoke-direct {v0, v2, v1}, Lcom/google/protobuf/SmallSortedMap$EntrySet;-><init>(Lcom/google/protobuf/SmallSortedMap;Lcom/google/protobuf/SmallSortedMap$1;)V
    000a: iput v0, v2.Lcom/google/protobuf/SmallSortedMap;->lazyEntrySet:Lcom/google/protobuf/SmallSortedMap$EntrySet;
    000c: iget v0, v2.Lcom/google/protobuf/SmallSortedMap;->lazyEntrySet:Lcom/google/protobuf/SmallSortedMap$EntrySet;
    000e: return-object v0

  [Virtual Method] get(Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=4, ins=2, outs=2, insns_size=28
    0000: check-cast v3, Ljava/lang/Comparable;
    0002: invoke-direct {v2, v3}, Lcom/google/protobuf/SmallSortedMap;->binarySearchInArray(Ljava/lang/Comparable;)I
    0005: move-result v0
    0006: if-ltz v0, 0015
    0008: iget v1, v2.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    000a: invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    000d: move-result-object v0
    000e: check-cast v0, Lcom/google/protobuf/SmallSortedMap$Entry;
    0010: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap$Entry;->getValue()Ljava/lang/Object;
    0013: move-result-object v0
    0014: return-object v0
    0015: iget v0, v2.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0017: invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    001a: move-result-object v0
    001b: goto 0014

  [Virtual Method] getArrayEntryAt(I) -> Ljava/util/Map$Entry;
    // registers=3, ins=2, outs=2, insns_size=9
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    0002: invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Ljava/util/Map$Entry;
    0008: return-object v0

  [Virtual Method] getNumArrayEntries() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    0002: invoke-interface {v0}, Ljava/util/List;->size()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] getNumOverflowEntries() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0002: invoke-interface {v0}, Ljava/util/Map;->size()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] getOverflowEntries() -> Ljava/lang/Iterable;
    // registers=2, ins=1, outs=1, insns_size=20
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0002: invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z
    0005: move-result v0
    0006: if-eqz v0, 000d
    0008: invoke-static {}, Lcom/google/protobuf/SmallSortedMap$EmptySet;->iterable()Ljava/lang/Iterable;
    000b: move-result-object v0
    000c: return-object v0
    000d: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    000f: invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;
    0012: move-result-object v0
    0013: goto 000c

  [Virtual Method] isImmutable() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->isImmutable:Z
    0002: return v0

  [Virtual Method] makeImmutable() -> V
    // registers=2, ins=1, outs=1, insns_size=29
    0000: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->isImmutable:Z
    0002: if-nez v0, 0015
    0004: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0006: invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z
    0009: move-result v0
    000a: if-eqz v0, 0016
    000c: invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;
    000f: move-result-object v0
    0010: iput v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0012: const/4 v0, 1
    0013: iput v0, v1.Lcom/google/protobuf/SmallSortedMap;->isImmutable:Z
    0015: return-void
    0016: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0018: invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;
    001b: move-result-object v0
    001c: goto 0010

  [Virtual Method] put(Ljava/lang/Comparable;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=7, ins=3, outs=4, insns_size=90
    0000: invoke-direct {v4}, Lcom/google/protobuf/SmallSortedMap;->checkMutable()V
    0003: invoke-direct {v4, v5}, Lcom/google/protobuf/SmallSortedMap;->binarySearchInArray(Ljava/lang/Comparable;)I
    0006: move-result v0
    0007: if-ltz v0, 0016
    0009: iget v1, v4.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    000b: invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;
    000e: move-result-object v0
    000f: check-cast v0, Lcom/google/protobuf/SmallSortedMap$Entry;
    0011: invoke-virtual {v0, v6}, Lcom/google/protobuf/SmallSortedMap$Entry;->setValue(Ljava/lang/Object;)Ljava/lang/Object;
    0014: move-result-object v0
    0015: return-object v0
    0016: invoke-direct {v4}, Lcom/google/protobuf/SmallSortedMap;->ensureEntryArrayMutable()V
    0019: binop/lit8(op=d8) v0, v0, 1 (0x1)
    001b: unop(op=7b) v1, v0
    001c: iget v0, v4.Lcom/google/protobuf/SmallSortedMap;->maxArraySize:I
    001e: if-lt v1, v0, 0029
    0020: invoke-direct {v4}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntriesMutable()Ljava/util/SortedMap;
    0023: move-result-object v0
    0024: invoke-interface {v0, v5, v6}, Ljava/util/SortedMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    0027: move-result-object v0
    0028: goto 0015
    0029: iget v0, v4.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    002b: invoke-interface {v0}, Ljava/util/List;->size()I
    002e: move-result v0
    002f: iget v2, v4.Lcom/google/protobuf/SmallSortedMap;->maxArraySize:I
    0031: if-ne v0, v2, 004e
    0033: iget v0, v4.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    0035: iget v2, v4.Lcom/google/protobuf/SmallSortedMap;->maxArraySize:I
    0037: binop/lit8(op=d8) v2, v2, -1 (-0x1)
    0039: invoke-interface {v0, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;
    003c: move-result-object v0
    003d: check-cast v0, Lcom/google/protobuf/SmallSortedMap$Entry;
    003f: invoke-direct {v4}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntriesMutable()Ljava/util/SortedMap;
    0042: move-result-object v2
    0043: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap$Entry;->getKey()Ljava/lang/Comparable;
    0046: move-result-object v3
    0047: invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap$Entry;->getValue()Ljava/lang/Object;
    004a: move-result-object v0
    004b: invoke-interface {v2, v3, v0}, Ljava/util/SortedMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    004e: iget v0, v4.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    0050: new-instance v2, Lcom/google/protobuf/SmallSortedMap$Entry;
    0052: invoke-direct {v2, v4, v5, v6}, Lcom/google/protobuf/SmallSortedMap$Entry;-><init>(Lcom/google/protobuf/SmallSortedMap;Ljava/lang/Comparable;Ljava/lang/Object;)V
    0055: invoke-interface {v0, v1, v2}, Ljava/util/List;->add(ILjava/lang/Object;)V
    0058: const/4 v0, 0
    0059: goto 0015

  [Virtual Method] put(Ljava/lang/Object;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=4, ins=3, outs=3, insns_size=7
    0000: check-cast v2, Ljava/lang/Comparable;
    0002: invoke-virtual {v1, v2, v3}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] remove(Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=33
    0000: invoke-direct {v1}, Lcom/google/protobuf/SmallSortedMap;->checkMutable()V
    0003: check-cast v2, Ljava/lang/Comparable;
    0005: invoke-direct {v1, v2}, Lcom/google/protobuf/SmallSortedMap;->binarySearchInArray(Ljava/lang/Comparable;)I
    0008: move-result v0
    0009: if-ltz v0, 0010
    000b: invoke-direct {v1, v0}, Lcom/google/protobuf/SmallSortedMap;->removeArrayEntryAt(I)Ljava/lang/Object;
    000e: move-result-object v0
    000f: return-object v0
    0010: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0012: invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z
    0015: move-result v0
    0016: if-eqz v0, 001a
    0018: const/4 v0, 0
    0019: goto 000f
    001a: iget v0, v1.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    001c: invoke-interface {v0, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    001f: move-result-object v0
    0020: goto 000f

  [Virtual Method] size() -> I
    // registers=3, ins=1, outs=1, insns_size=14
    0000: iget v0, v2.Lcom/google/protobuf/SmallSortedMap;->entryList:Ljava/util/List;
    0002: invoke-interface {v0}, Ljava/util/List;->size()I
    0005: move-result v0
    0006: iget v1, v2.Lcom/google/protobuf/SmallSortedMap;->overflowEntries:Ljava/util/Map;
    0008: invoke-interface {v1}, Ljava/util/Map;->size()I
    000b: move-result v1
    000c: binop/2addr(op=b0) v0, v1
    000d: return v0