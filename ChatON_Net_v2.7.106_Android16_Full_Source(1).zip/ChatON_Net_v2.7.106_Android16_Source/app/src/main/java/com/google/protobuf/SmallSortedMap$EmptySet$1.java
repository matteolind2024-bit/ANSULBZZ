=== CLASS Lcom/google/protobuf/SmallSortedMap$EmptySet$1; (Source: SmallSortedMap.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/util/Iterator;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] hasNext() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] next() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=6
    0000: new-instance v0, Ljava/util/NoSuchElementException;
    0002: invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V
    0005: throw v0

  [Virtual Method] remove() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: new-instance v0, Ljava/lang/UnsupportedOperationException;
    0002: invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V
    0005: throw v0