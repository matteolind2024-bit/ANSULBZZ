=== CLASS Lcom/google/protobuf/GeneratedMessageLite$SerializedForm; (Source: GeneratedMessageLite.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/io/Serializable;
  [Static Field] serialVersionUID: J
  [Instance Field] asBytes: [B
  [Instance Field] messageClassName: Ljava/lang/String;

  [Direct Method] <init>(Lcom/google/protobuf/MessageLite;) -> V
    // registers=3, ins=2, outs=1, insns_size=20
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0006: move-result-object v0
    0007: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    000a: move-result-object v0
    000b: iput v0, v1.Lcom/google/protobuf/GeneratedMessageLite$SerializedForm;->messageClassName:Ljava/lang/String;
    000d: invoke-interface {v2}, Lcom/google/protobuf/MessageLite;->toByteArray()[B
    0010: move-result-object v0
    0011: iput v0, v1.Lcom/google/protobuf/GeneratedMessageLite$SerializedForm;->asBytes:[B
    0013: return-void

  [Virtual Method] readResolve() -> Ljava/lang/Object;
    // registers=4, ins=1, outs=3, insns_size=84
    0000: iget v0, v3.Lcom/google/protobuf/GeneratedMessageLite$SerializedForm;->messageClassName:Ljava/lang/String;
    0002: invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    0005: move-result-object v0
    0006: const-string v1, 'newBuilder'
    0008: const/4 v2, 0
    0009: new-array v2, v2, [Ljava/lang/Class;
    000b: invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    000e: move-result-object v0
    000f: const/4 v1, 0
    0010: const/4 v2, 0
    0011: new-array v2, v2, [Ljava/lang/Object;
    0013: invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    0016: move-result-object v0
    0017: check-cast v0, Lcom/google/protobuf/MessageLite$Builder;
    0019: iget v1, v3.Lcom/google/protobuf/GeneratedMessageLite$SerializedForm;->asBytes:[B
    001b: invoke-interface {v0, v1}, Lcom/google/protobuf/MessageLite$Builder;->mergeFrom([B)Lcom/google/protobuf/MessageLite$Builder;
    001e: invoke-interface {v0}, Lcom/google/protobuf/MessageLite$Builder;->buildPartial()Lcom/google/protobuf/MessageLite;
    0021: move-result-object v0
    0022: return-object v0
    0023: move-exception v0
    0024: new-instance v1, Ljava/lang/RuntimeException;
    0026: const-string v2, 'Unable to find proto buffer class'
    0028: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    002b: throw v1
    002c: move-exception v0
    002d: new-instance v1, Ljava/lang/RuntimeException;
    002f: const-string v2, 'Unable to find newBuilder method'
    0031: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0034: throw v1
    0035: move-exception v0
    0036: new-instance v1, Ljava/lang/RuntimeException;
    0038: const-string v2, 'Unable to call newBuilder method'
    003a: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    003d: throw v1
    003e: move-exception v0
    003f: new-instance v1, Ljava/lang/RuntimeException;
    0041: const-string v2, 'Error calling newBuilder'
    0043: invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;
    0046: move-result-object v0
    0047: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    004a: throw v1
    004b: move-exception v0
    004c: new-instance v1, Ljava/lang/RuntimeException;
    004e: const-string v2, 'Unable to understand proto buffer'
    0050: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0053: throw v1