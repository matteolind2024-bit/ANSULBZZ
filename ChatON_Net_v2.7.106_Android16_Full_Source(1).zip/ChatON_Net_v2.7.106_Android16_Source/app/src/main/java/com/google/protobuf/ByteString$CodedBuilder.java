=== CLASS Lcom/google/protobuf/ByteString$CodedBuilder; (Source: ByteString.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] buffer: [B
  [Instance Field] output: Lcom/google/protobuf/CodedOutputStream;

  [Direct Method] <init>(I) -> V
    // registers=3, ins=2, outs=1, insns_size=16
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: new-array v0, v2, [B
    0005: iput v0, v1.Lcom/google/protobuf/ByteString$CodedBuilder;->buffer:[B
    0007: iget v0, v1.Lcom/google/protobuf/ByteString$CodedBuilder;->buffer:[B
    0009: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->newInstance([B)Lcom/google/protobuf/CodedOutputStream;
    000c: move-result-object v0
    000d: iput v0, v1.Lcom/google/protobuf/ByteString$CodedBuilder;->output:Lcom/google/protobuf/CodedOutputStream;
    000f: return-void

  [Direct Method] <init>(I, Lcom/google/protobuf/ByteString$1;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/google/protobuf/ByteString$CodedBuilder;-><init>(I)V
    0003: return-void

  [Virtual Method] build() -> Lcom/google/protobuf/ByteString;
    // registers=4, ins=1, outs=3, insns_size=14
    0000: iget v0, v3.Lcom/google/protobuf/ByteString$CodedBuilder;->output:Lcom/google/protobuf/CodedOutputStream;
    0002: invoke-virtual {v0}, Lcom/google/protobuf/CodedOutputStream;->checkNoSpaceLeft()V
    0005: new-instance v0, Lcom/google/protobuf/ByteString;
    0007: iget v1, v3.Lcom/google/protobuf/ByteString$CodedBuilder;->buffer:[B
    0009: const/4 v2, 0
    000a: invoke-direct {v0, v1, v2}, Lcom/google/protobuf/ByteString;-><init>([BLcom/google/protobuf/ByteString$1;)V
    000d: return-object v0

  [Virtual Method] getCodedOutput() -> Lcom/google/protobuf/CodedOutputStream;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/google/protobuf/ByteString$CodedBuilder;->output:Lcom/google/protobuf/CodedOutputStream;
    0002: return-object v0