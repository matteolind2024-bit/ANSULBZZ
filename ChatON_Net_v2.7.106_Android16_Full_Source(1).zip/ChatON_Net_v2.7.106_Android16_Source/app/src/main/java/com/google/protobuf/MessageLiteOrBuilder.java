=== CLASS Lcom/google/protobuf/MessageLiteOrBuilder; (Source: MessageLiteOrBuilder.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] getDefaultInstanceForType() -> Lcom/google/protobuf/MessageLite;

  [Virtual Method] isInitialized() -> Z