=== CLASS Lcom/google/protobuf/GeneratedMessageLite$1; (Source: GeneratedMessageLite.java) ===
  Super: Ljava/lang/Object;
  [Static Field] $SwitchMap$com$google$protobuf$WireFormat$JavaType: [I

  [Direct Method] <clinit>() -> V
    // registers=3, ins=0, outs=1, insns_size=36
    0000: invoke-static {}, Lcom/google/protobuf/WireFormat$JavaType;->values()[Lcom/google/protobuf/WireFormat$JavaType;
    0003: move-result-object v0
    0004: move(op=21) v0, v0
    0005: new-array v0, v0, [I
    0007: sput v0, Lcom/google/protobuf/GeneratedMessageLite$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    0009: sget v0, Lcom/google/protobuf/GeneratedMessageLite$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    000b: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;
    000d: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    0010: move-result v1
    0011: const/4 v2, 1
    0012: aput(op=4b) v2, v0[v1]
    0014: sget v0, Lcom/google/protobuf/GeneratedMessageLite$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I
    0016: sget v1, Lcom/google/protobuf/WireFormat$JavaType;->ENUM:Lcom/google/protobuf/WireFormat$JavaType;
    0018: invoke-virtual {v1}, Lcom/google/protobuf/WireFormat$JavaType;->ordinal()I
    001b: move-result v1
    001c: const/4 v2, 2
    001d: aput(op=4b) v2, v0[v1]
    001f: return-void
    0020: move-exception v0
    0021: goto 001f
    0022: move-exception v0
    0023: goto 0014