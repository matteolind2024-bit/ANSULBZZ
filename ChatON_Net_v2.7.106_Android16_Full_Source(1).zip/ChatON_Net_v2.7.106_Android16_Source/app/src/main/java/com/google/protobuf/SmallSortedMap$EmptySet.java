=== CLASS Lcom/google/protobuf/SmallSortedMap$EmptySet; (Source: SmallSortedMap.java) ===
  Super: Ljava/lang/Object;
  [Static Field] ITERABLE: Ljava/lang/Iterable;
  [Static Field] ITERATOR: Ljava/util/Iterator;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=15
    0000: new-instance v0, Lcom/google/protobuf/SmallSortedMap$EmptySet$1;
    0002: invoke-direct {v0}, Lcom/google/protobuf/SmallSortedMap$EmptySet$1;-><init>()V
    0005: sput v0, Lcom/google/protobuf/SmallSortedMap$EmptySet;->ITERATOR:Ljava/util/Iterator;
    0007: new-instance v0, Lcom/google/protobuf/SmallSortedMap$EmptySet$2;
    0009: invoke-direct {v0}, Lcom/google/protobuf/SmallSortedMap$EmptySet$2;-><init>()V
    000c: sput v0, Lcom/google/protobuf/SmallSortedMap$EmptySet;->ITERABLE:Ljava/lang/Iterable;
    000e: return-void

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] access$700() -> Ljava/util/Iterator;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/google/protobuf/SmallSortedMap$EmptySet;->ITERATOR:Ljava/util/Iterator;
    0002: return-object v0

  [Direct Method] iterable() -> Ljava/lang/Iterable;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/google/protobuf/SmallSortedMap$EmptySet;->ITERABLE:Ljava/lang/Iterable;
    0002: return-object v0