=== CLASS Lcom/google/protobuf/ByteString; (Source: ByteString.java) ===
  Super: Ljava/lang/Object;
  [Static Field] EMPTY: Lcom/google/protobuf/ByteString;
  [Instance Field] bytes: [B
  [Instance Field] hash: I

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=2, insns_size=11
    0000: new-instance v0, Lcom/google/protobuf/ByteString;
    0002: const/4 v1, 0
    0003: new-array v1, v1, [B
    0005: invoke-direct {v0, v1}, Lcom/google/protobuf/ByteString;-><init>([B)V
    0008: sput v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;
    000a: return-void

  [Direct Method] <init>([B) -> V
    // registers=3, ins=2, outs=1, insns_size=9
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: const/4 v0, 0
    0004: iput v0, v1.Lcom/google/protobuf/ByteString;->hash:I
    0006: iput v2, v1.Lcom/google/protobuf/ByteString;->bytes:[B
    0008: return-void

  [Direct Method] <init>([B, Lcom/google/protobuf/ByteString$1;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/google/protobuf/ByteString;-><init>([B)V
    0003: return-void

  [Direct Method] copyFrom(Ljava/lang/String;, Ljava/lang/String;) -> Lcom/google/protobuf/ByteString;
    // registers=4, ins=2, outs=2, insns_size=10
    0000: new-instance v0, Lcom/google/protobuf/ByteString;
    0002: invoke-virtual {v2, v3}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B
    0005: move-result-object v1
    0006: invoke-direct {v0, v1}, Lcom/google/protobuf/ByteString;-><init>([B)V
    0009: return-object v0

  [Direct Method] copyFrom(Ljava/nio/ByteBuffer;) -> Lcom/google/protobuf/ByteString;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: invoke-virtual {v1}, Ljava/nio/ByteBuffer;->remaining()I
    0003: move-result v0
    0004: invoke-static {v1, v0}, Lcom/google/protobuf/ByteString;->copyFrom(Ljava/nio/ByteBuffer;I)Lcom/google/protobuf/ByteString;
    0007: move-result-object v0
    0008: return-object v0

  [Direct Method] copyFrom(Ljava/nio/ByteBuffer;, I) -> Lcom/google/protobuf/ByteString;
    // registers=4, ins=2, outs=2, insns_size=11
    0000: new-array v0, v3, [B
    0002: invoke-virtual {v2, v0}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;
    0005: new-instance v1, Lcom/google/protobuf/ByteString;
    0007: invoke-direct {v1, v0}, Lcom/google/protobuf/ByteString;-><init>([B)V
    000a: return-object v1

  [Direct Method] copyFrom(Ljava/util/List;) -> Lcom/google/protobuf/ByteString;
    // registers=8, ins=1, outs=5, insns_size=89
    0000: const/4 v2, 0
    0001: invoke-interface {v7}, Ljava/util/List;->size()I
    0004: move-result v0
    0005: if-nez v0, 000a
    0007: sget v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;
    0009: return-object v0
    000a: invoke-interface {v7}, Ljava/util/List;->size()I
    000d: move-result v0
    000e: const/4 v1, 1
    000f: if-ne v0, v1, 0018
    0011: invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0014: move-result-object v0
    0015: check-cast v0, Lcom/google/protobuf/ByteString;
    0017: goto 0009
    0018: invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    001b: move-result-object v3
    001c: move(op=01) v1, v2
    001d: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    0020: move-result v0
    0021: if-eqz v0, 0030
    0023: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0026: move-result-object v0
    0027: check-cast v0, Lcom/google/protobuf/ByteString;
    0029: invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->size()I
    002c: move-result v0
    002d: binop/2addr(op=b0) v0, v1
    002e: move(op=01) v1, v0
    002f: goto 001d
    0030: new-array v3, v1, [B
    0032: invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    0035: move-result-object v4
    0036: move(op=01) v1, v2
    0037: invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z
    003a: move-result v0
    003b: if-eqz v0, 0053
    003d: invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0040: move-result-object v0
    0041: check-cast v0, Lcom/google/protobuf/ByteString;
    0043: iget v5, v0.Lcom/google/protobuf/ByteString;->bytes:[B
    0045: invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->size()I
    0048: move-result v6
    0049: invoke-static {v5, v2, v3, v1, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    004c: invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->size()I
    004f: move-result v0
    0050: binop/2addr(op=b0) v0, v1
    0051: move(op=01) v1, v0
    0052: goto 0037
    0053: new-instance v0, Lcom/google/protobuf/ByteString;
    0055: invoke-direct {v0, v3}, Lcom/google/protobuf/ByteString;-><init>([B)V
    0058: goto 0009

  [Direct Method] copyFrom([B) -> Lcom/google/protobuf/ByteString;
    // registers=3, ins=1, outs=3, insns_size=7
    0000: const/4 v0, 0
    0001: move(op=21) v1, v2
    0002: invoke-static {v2, v0, v1}, Lcom/google/protobuf/ByteString;->copyFrom([BII)Lcom/google/protobuf/ByteString;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] copyFrom([B, I, I) -> Lcom/google/protobuf/ByteString;
    // registers=5, ins=3, outs=5, insns_size=12
    0000: new-array v0, v4, [B
    0002: const/4 v1, 0
    0003: invoke-static {v2, v3, v0, v1, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0006: new-instance v1, Lcom/google/protobuf/ByteString;
    0008: invoke-direct {v1, v0}, Lcom/google/protobuf/ByteString;-><init>([B)V
    000b: return-object v1

  [Direct Method] copyFromUtf8(Ljava/lang/String;) -> Lcom/google/protobuf/ByteString;
    // registers=4, ins=1, outs=3, insns_size=21
    0000: new-instance v0, Lcom/google/protobuf/ByteString;
    0002: const-string v1, 'UTF-8'
    0004: invoke-virtual {v3, v1}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B
    0007: move-result-object v1
    0008: invoke-direct {v0, v1}, Lcom/google/protobuf/ByteString;-><init>([B)V
    000b: return-object v0
    000c: move-exception v0
    000d: new-instance v1, Ljava/lang/RuntimeException;
    000f: const-string v2, 'UTF-8 not supported?'
    0011: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0014: throw v1

  [Direct Method] newCodedBuilder(I) -> Lcom/google/protobuf/ByteString$CodedBuilder;
    // registers=3, ins=1, outs=3, insns_size=7
    0000: new-instance v0, Lcom/google/protobuf/ByteString$CodedBuilder;
    0002: const/4 v1, 0
    0003: invoke-direct {v0, v2, v1}, Lcom/google/protobuf/ByteString$CodedBuilder;-><init>(ILcom/google/protobuf/ByteString$1;)V
    0006: return-object v0

  [Direct Method] newOutput() -> Lcom/google/protobuf/ByteString$Output;
    // registers=1, ins=0, outs=1, insns_size=7
    0000: const/16 v0, 32 (0x20)
    0002: invoke-static {v0}, Lcom/google/protobuf/ByteString;->newOutput(I)Lcom/google/protobuf/ByteString$Output;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] newOutput(I) -> Lcom/google/protobuf/ByteString$Output;
    // registers=4, ins=1, outs=3, insns_size=12
    0000: new-instance v0, Lcom/google/protobuf/ByteString$Output;
    0002: new-instance v1, Ljava/io/ByteArrayOutputStream;
    0004: invoke-direct {v1, v3}, Ljava/io/ByteArrayOutputStream;-><init>(I)V
    0007: const/4 v2, 0
    0008: invoke-direct {v0, v1, v2}, Lcom/google/protobuf/ByteString$Output;-><init>(Ljava/io/ByteArrayOutputStream;Lcom/google/protobuf/ByteString$1;)V
    000b: return-object v0

  [Virtual Method] asReadOnlyByteBuffer() -> Ljava/nio/ByteBuffer;
    // registers=2, ins=1, outs=1, insns_size=11
    0000: iget v0, v1.Lcom/google/protobuf/ByteString;->bytes:[B
    0002: invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;
    0005: move-result-object v0
    0006: invoke-virtual {v0}, Ljava/nio/ByteBuffer;->asReadOnlyBuffer()Ljava/nio/ByteBuffer;
    0009: move-result-object v0
    000a: return-object v0

  [Virtual Method] byteAt(I) -> B
    // registers=3, ins=2, outs=0, insns_size=5
    0000: iget v0, v1.Lcom/google/protobuf/ByteString;->bytes:[B
    0002: aget(op=48) v0, v0[v2]
    0004: return v0

  [Virtual Method] copyTo(Ljava/nio/ByteBuffer;) -> V
    // registers=5, ins=2, outs=4, insns_size=10
    0000: iget v0, v3.Lcom/google/protobuf/ByteString;->bytes:[B
    0002: const/4 v1, 0
    0003: iget v2, v3.Lcom/google/protobuf/ByteString;->bytes:[B
    0005: move(op=21) v2, v2
    0006: invoke-virtual {v4, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;
    0009: return-void

  [Virtual Method] copyTo([B, I) -> V
    // registers=6, ins=3, outs=5, insns_size=10
    0000: iget v0, v3.Lcom/google/protobuf/ByteString;->bytes:[B
    0002: const/4 v1, 0
    0003: iget v2, v3.Lcom/google/protobuf/ByteString;->bytes:[B
    0005: move(op=21) v2, v2
    0006: invoke-static {v0, v1, v4, v5, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0009: return-void

  [Virtual Method] copyTo([B, I, I, I) -> V
    // registers=6, ins=5, outs=5, insns_size=6
    0000: iget v0, v1.Lcom/google/protobuf/ByteString;->bytes:[B
    0002: invoke-static {v0, v3, v2, v4, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0005: return-void

  [Virtual Method] equals(Ljava/lang/Object;) -> Z
    // registers=10, ins=2, outs=0, insns_size=41
    0000: const/4 v0, 1
    0001: const/4 v1, 0
    0002: if-ne v9, v8, 0005
    0004: return v0
    0005: instance-of v2, v9, Lcom/google/protobuf/ByteString;
    0007: if-nez v2, 000b
    0009: move(op=01) v0, v1
    000a: goto 0004
    000b: check-cast v9, Lcom/google/protobuf/ByteString;
    000d: iget v2, v8.Lcom/google/protobuf/ByteString;->bytes:[B
    000f: move(op=21) v3, v2
    0010: iget v2, v9.Lcom/google/protobuf/ByteString;->bytes:[B
    0012: move(op=21) v2, v2
    0013: if-eq v3, v2, 0017
    0015: move(op=01) v0, v1
    0016: goto 0004
    0017: iget v4, v8.Lcom/google/protobuf/ByteString;->bytes:[B
    0019: iget v5, v9.Lcom/google/protobuf/ByteString;->bytes:[B
    001b: move(op=01) v2, v1
    001c: if-ge v2, v3, 0004
    001e: aget(op=48) v6, v4[v2]
    0020: aget(op=48) v7, v5[v2]
    0022: if-eq v6, v7, 0026
    0024: move(op=01) v0, v1
    0025: goto 0004
    0026: binop/lit8(op=d8) v2, v2, 1 (0x1)
    0028: goto 001c

  [Virtual Method] hashCode() -> I
    // registers=6, ins=1, outs=0, insns_size=30
    0000: iget v0, v5.Lcom/google/protobuf/ByteString;->hash:I
    0002: if-nez v0, 001d
    0004: iget v4, v5.Lcom/google/protobuf/ByteString;->bytes:[B
    0006: iget v0, v5.Lcom/google/protobuf/ByteString;->bytes:[B
    0008: move(op=21) v2, v0
    0009: const/4 v0, 0
    000a: move(op=01) v1, v0
    000b: move(op=01) v0, v2
    000c: if-ge v1, v2, 0018
    000e: binop/lit8(op=da) v0, v0, 31 (0x1f)
    0010: aget(op=48) v3, v4[v1]
    0012: binop/2addr(op=b0) v3, v0
    0013: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0015: move(op=01) v1, v0
    0016: move(op=01) v0, v3
    0017: goto 000c
    0018: if-nez v0, 001b
    001a: const/4 v0, 1
    001b: iput v0, v5.Lcom/google/protobuf/ByteString;->hash:I
    001d: return v0

  [Virtual Method] isEmpty() -> Z
    // registers=2, ins=1, outs=0, insns_size=9
    0000: iget v0, v1.Lcom/google/protobuf/ByteString;->bytes:[B
    0002: move(op=21) v0, v0
    0003: if-nez v0, 0007
    0005: const/4 v0, 1
    0006: return v0
    0007: const/4 v0, 0
    0008: goto 0006

  [Virtual Method] newCodedInput() -> Lcom/google/protobuf/CodedInputStream;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Lcom/google/protobuf/ByteString;->bytes:[B
    0002: invoke-static {v0}, Lcom/google/protobuf/CodedInputStream;->newInstance([B)Lcom/google/protobuf/CodedInputStream;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] newInput() -> Ljava/io/InputStream;
    // registers=3, ins=1, outs=2, insns_size=8
    0000: new-instance v0, Ljava/io/ByteArrayInputStream;
    0002: iget v1, v2.Lcom/google/protobuf/ByteString;->bytes:[B
    0004: invoke-direct {v0, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V
    0007: return-object v0

  [Virtual Method] size() -> I
    // registers=2, ins=1, outs=0, insns_size=4
    0000: iget v0, v1.Lcom/google/protobuf/ByteString;->bytes:[B
    0002: move(op=21) v0, v0
    0003: return v0

  [Virtual Method] toByteArray() -> [B
    // registers=5, ins=1, outs=5, insns_size=12
    0000: const/4 v3, 0
    0001: iget v0, v4.Lcom/google/protobuf/ByteString;->bytes:[B
    0003: move(op=21) v0, v0
    0004: new-array v1, v0, [B
    0006: iget v2, v4.Lcom/google/protobuf/ByteString;->bytes:[B
    0008: invoke-static {v2, v3, v1, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    000b: return-object v1

  [Virtual Method] toString(Ljava/lang/String;) -> Ljava/lang/String;
    // registers=4, ins=2, outs=3, insns_size=8
    0000: new-instance v0, Ljava/lang/String;
    0002: iget v1, v2.Lcom/google/protobuf/ByteString;->bytes:[B
    0004: invoke-direct {v0, v1, v3}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    0007: return-object v0

  [Virtual Method] toStringUtf8() -> Ljava/lang/String;
    // registers=4, ins=1, outs=3, insns_size=19
    0000: new-instance v0, Ljava/lang/String;
    0002: iget v1, v3.Lcom/google/protobuf/ByteString;->bytes:[B
    0004: const-string v2, 'UTF-8'
    0006: invoke-direct {v0, v1, v2}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    0009: return-object v0
    000a: move-exception v0
    000b: new-instance v1, Ljava/lang/RuntimeException;
    000d: const-string v2, 'UTF-8 not supported?'
    000f: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0012: throw v1