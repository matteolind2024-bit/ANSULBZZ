=== CLASS Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException; (Source: CodedOutputStream.java) ===
  Super: Ljava/io/IOException;
  [Static Field] serialVersionUID: J = -6947486886997889499

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: const-string v0, 'CodedOutputStream was writing to a flat byte array and ran out of space.'
    0002: invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V
    0005: return-void