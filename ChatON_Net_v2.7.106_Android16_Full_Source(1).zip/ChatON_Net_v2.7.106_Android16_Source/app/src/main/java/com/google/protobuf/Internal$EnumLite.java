=== CLASS Lcom/google/protobuf/Internal$EnumLite; (Source: Internal.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] getNumber() -> I