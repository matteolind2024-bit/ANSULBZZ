=== CLASS Lcom/google/protobuf/AbstractMessageLite; (Source: AbstractMessageLite.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/google/protobuf/MessageLite;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] toByteArray() -> [B
    // registers=4, ins=1, outs=3, insns_size=26
    0000: invoke-virtual {v3}, Lcom/google/protobuf/AbstractMessageLite;->getSerializedSize()I
    0003: move-result v0
    0004: new-array v0, v0, [B
    0006: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->newInstance([B)Lcom/google/protobuf/CodedOutputStream;
    0009: move-result-object v1
    000a: invoke-virtual {v3, v1}, Lcom/google/protobuf/AbstractMessageLite;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    000d: invoke-virtual {v1}, Lcom/google/protobuf/CodedOutputStream;->checkNoSpaceLeft()V
    0010: return-object v0
    0011: move-exception v0
    0012: new-instance v1, Ljava/lang/RuntimeException;
    0014: const-string v2, 'Serializing to a byte array threw an IOException (should never happen).'
    0016: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0019: throw v1

  [Virtual Method] toByteString() -> Lcom/google/protobuf/ByteString;
    // registers=4, ins=1, outs=3, insns_size=29
    0000: invoke-virtual {v3}, Lcom/google/protobuf/AbstractMessageLite;->getSerializedSize()I
    0003: move-result v0
    0004: invoke-static {v0}, Lcom/google/protobuf/ByteString;->newCodedBuilder(I)Lcom/google/protobuf/ByteString$CodedBuilder;
    0007: move-result-object v0
    0008: invoke-virtual {v0}, Lcom/google/protobuf/ByteString$CodedBuilder;->getCodedOutput()Lcom/google/protobuf/CodedOutputStream;
    000b: move-result-object v1
    000c: invoke-virtual {v3, v1}, Lcom/google/protobuf/AbstractMessageLite;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    000f: invoke-virtual {v0}, Lcom/google/protobuf/ByteString$CodedBuilder;->build()Lcom/google/protobuf/ByteString;
    0012: move-result-object v0
    0013: return-object v0
    0014: move-exception v0
    0015: new-instance v1, Ljava/lang/RuntimeException;
    0017: const-string v2, 'Serializing to a ByteString threw an IOException (should never happen).'
    0019: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    001c: throw v1

  [Virtual Method] writeDelimitedTo(Ljava/io/OutputStream;) -> V
    // registers=4, ins=2, outs=2, insns_size=27
    0000: invoke-virtual {v2}, Lcom/google/protobuf/AbstractMessageLite;->getSerializedSize()I
    0003: move-result v0
    0004: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeRawVarint32Size(I)I
    0007: move-result v1
    0008: binop/2addr(op=b0) v1, v0
    0009: invoke-static {v1}, Lcom/google/protobuf/CodedOutputStream;->computePreferredBufferSize(I)I
    000c: move-result v1
    000d: invoke-static {v3, v1}, Lcom/google/protobuf/CodedOutputStream;->newInstance(Ljava/io/OutputStream;I)Lcom/google/protobuf/CodedOutputStream;
    0010: move-result-object v1
    0011: invoke-virtual {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeRawVarint32(I)V
    0014: invoke-virtual {v2, v1}, Lcom/google/protobuf/AbstractMessageLite;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    0017: invoke-virtual {v1}, Lcom/google/protobuf/CodedOutputStream;->flush()V
    001a: return-void

  [Virtual Method] writeTo(Ljava/io/OutputStream;) -> V
    // registers=3, ins=2, outs=2, insns_size=19
    0000: invoke-virtual {v1}, Lcom/google/protobuf/AbstractMessageLite;->getSerializedSize()I
    0003: move-result v0
    0004: invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computePreferredBufferSize(I)I
    0007: move-result v0
    0008: invoke-static {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->newInstance(Ljava/io/OutputStream;I)Lcom/google/protobuf/CodedOutputStream;
    000b: move-result-object v0
    000c: invoke-virtual {v1, v0}, Lcom/google/protobuf/AbstractMessageLite;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    000f: invoke-virtual {v0}, Lcom/google/protobuf/CodedOutputStream;->flush()V
    0012: return-void