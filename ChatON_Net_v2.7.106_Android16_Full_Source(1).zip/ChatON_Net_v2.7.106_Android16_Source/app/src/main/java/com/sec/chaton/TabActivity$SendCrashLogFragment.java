=== CLASS Lcom/sec/chaton/TabActivity$SendCrashLogFragment; (Source: TabActivity.java) ===
  Super: Landroid/support/v4/app/Fragment;
  [Static Field] a: Ljava/lang/String;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=9
    0000: const-class v0, Lcom/sec/chaton/TabActivity$SendCrashLogFragment;
    0002: invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0005: move-result-object v0
    0006: sput v0, Lcom/sec/chaton/TabActivity$SendCrashLogFragment;->a:Ljava/lang/String;
    0008: return-void

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/app/Fragment;-><init>()V
    0003: return-void

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=4, ins=2, outs=2, insns_size=15
    0000: invoke-super {v2, v3}, Landroid/support/v4/app/Fragment;->onCreate(Landroid/os/Bundle;)V
    0003: new-instance v0, Lcom/sec/chaton/util/q;
    0005: invoke-direct {v0}, Lcom/sec/chaton/util/q;-><init>()V
    0008: const/4 v1, 0
    0009: new-array v1, v1, [Ljava/lang/Void;
    000b: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/q;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;
    000e: return-void