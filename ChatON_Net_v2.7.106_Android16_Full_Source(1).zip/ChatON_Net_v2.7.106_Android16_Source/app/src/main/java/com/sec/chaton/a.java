=== CLASS Lcom/sec/chaton/a; (Source: AdminMenu.java) ===
  Super: Landroid/os/Handler;
  [Instance Field] a: Lcom/sec/chaton/AdminMenu;

  [Direct Method] <init>(Lcom/sec/chaton/AdminMenu;, Landroid/os/Looper;) -> V
    // registers=3, ins=3, outs=2, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/a;->a:Lcom/sec/chaton/AdminMenu;
    0002: invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    0005: return-void

  [Virtual Method] handleMessage(Landroid/os/Message;) -> V
    // registers=4, ins=2, outs=2, insns_size=48
    0000: invoke-super {v2, v3}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V
    0003: iget v0, v3.Landroid/os/Message;->what:I
    0005: const/16 v1, 1003 (0x3eb)
    0007: if-ne v0, v1, 0023
    0009: iget v0, v3.Landroid/os/Message;->obj:Ljava/lang/Object;
    000b: check-cast v0, Ljava/lang/Boolean;
    000d: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    0010: move-result v0
    0011: sget v1, Lcom/sec/chaton/global/GlobalApplication;->a:Ljava/lang/String;
    0013: if-nez v1, 0016
    0015: const/4 v0, 0
    0016: if-eqz v0, 0024
    0018: iget v0, v2.Lcom/sec/chaton/a;->a:Lcom/sec/chaton/AdminMenu;
    001a: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->a(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    001d: move-result-object v0
    001e: const-string v1, 'Push Status - Available'
    0020: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    0023: return-void
    0024: iget v0, v2.Lcom/sec/chaton/a;->a:Lcom/sec/chaton/AdminMenu;
    0026: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->a(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    0029: move-result-object v0
    002a: const-string v1, 'Push Status - Unvailable'
    002c: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    002f: goto 0023