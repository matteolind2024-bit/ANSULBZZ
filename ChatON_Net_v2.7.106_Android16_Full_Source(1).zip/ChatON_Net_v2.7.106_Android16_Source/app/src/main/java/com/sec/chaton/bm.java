=== CLASS Lcom/sec/chaton/bm; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/sec/chaton/util/bb;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/bm;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] a() -> Z
    // registers=6, ins=1, outs=3, insns_size=92
    0000: const/4 v4, 1
    0001: new-instance v0, Ljava/lang/StringBuilder;
    0003: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0006: const-string v1, 'mGetAllBuddiesSyncTask run [UID] '
    0008: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000b: move-result-object v0
    000c: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    000f: move-result-object v1
    0010: const-string v2, 'uid'
    0012: invoke-virtual {v1, v2}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0015: move-result v1
    0016: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0019: move-result-object v0
    001a: const-string v1, ' [MSISDN] '
    001c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001f: move-result-object v0
    0020: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0023: move-result-object v1
    0024: const-string v2, 'msisdn'
    0026: const-string v3, ''
    0028: invoke-virtual {v1, v2, v3}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    002b: move-result-object v1
    002c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002f: move-result-object v0
    0030: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0033: move-result-object v0
    0034: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    0037: move-result-object v1
    0038: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    003b: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    003e: move-result-object v0
    003f: const-string v1, 'uid'
    0041: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0044: move-result v0
    0045: if-eqz v0, 0052
    0047: new-instance v0, Lcom/sec/chaton/d/h;
    0049: const/4 v1, 0
    004a: invoke-direct {v0, v1}, Lcom/sec/chaton/d/h;-><init>(Landroid/os/Handler;)V
    004d: const/16 v1, 200 (0xc8)
    004f: invoke-virtual {v0, v4, v1}, Lcom/sec/chaton/d/h;->a(ZI)V
    0052: const-string v0, 'mGetAllBuddiesSyncTask finish'
    0054: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    0057: move-result-object v1
    0058: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    005b: return v4