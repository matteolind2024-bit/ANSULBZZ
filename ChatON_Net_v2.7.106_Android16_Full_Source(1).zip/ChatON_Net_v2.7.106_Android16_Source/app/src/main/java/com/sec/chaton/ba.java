=== CLASS Lcom/sec/chaton/ba; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/lang/Runnable;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/ba;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] run() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: iget v0, v1.Lcom/sec/chaton/ba;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-static {v0}, Lcom/sec/chaton/TabActivity;->d(Lcom/sec/chaton/TabActivity;)V
    0005: return-void