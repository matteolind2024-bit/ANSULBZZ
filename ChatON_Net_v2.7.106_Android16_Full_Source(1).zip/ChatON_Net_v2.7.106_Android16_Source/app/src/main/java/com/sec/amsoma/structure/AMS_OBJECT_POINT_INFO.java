=== CLASS Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO; (Source: AMS_OBJECT_POINT_INFO.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] m_bPressureFlag: Z
  [Instance Field] m_nPointNum: I
  [Instance Field] m_nSimpleNum: I
  [Instance Field] m_pcSimpleFlag: [C
  [Instance Field] m_pnAMSPointPressure: [S
  [Instance Field] m_pnAMSPointX: [S
  [Instance Field] m_pnAMSPointY: [S

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getM_bPressureFlag() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_bPressureFlag:Z
    0002: return v0

  [Virtual Method] getM_nPointNum() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_nPointNum:I
    0002: return v0

  [Virtual Method] getM_nSimpleNum() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_nSimpleNum:I
    0002: return v0

  [Virtual Method] getM_pcSimpleFlag(I) -> C
    // registers=3, ins=2, outs=0, insns_size=12
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pcSimpleFlag:[C
    0002: move(op=21) v0, v0
    0003: if-ge v2, v0, 000a
    0005: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pcSimpleFlag:[C
    0007: aget(op=49) v0, v0[v2]
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] getM_pcSimpleFlag() -> [C
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pcSimpleFlag:[C
    0002: return-object v0

  [Virtual Method] getM_pnAMSPointPressure(I) -> S
    // registers=3, ins=2, outs=0, insns_size=12
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointPressure:[S
    0002: move(op=21) v0, v0
    0003: if-ge v2, v0, 000a
    0005: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointPressure:[S
    0007: aget(op=4a) v0, v0[v2]
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] getM_pnAMSPointPressure() -> [S
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointPressure:[S
    0002: return-object v0

  [Virtual Method] getM_pnAMSPointX(I) -> S
    // registers=3, ins=2, outs=0, insns_size=12
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointX:[S
    0002: move(op=21) v0, v0
    0003: if-ge v2, v0, 000a
    0005: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointX:[S
    0007: aget(op=4a) v0, v0[v2]
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] getM_pnAMSPointX() -> [S
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointX:[S
    0002: return-object v0

  [Virtual Method] getM_pnAMSPointY(I) -> S
    // registers=3, ins=2, outs=0, insns_size=12
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointY:[S
    0002: move(op=21) v0, v0
    0003: if-ge v2, v0, 000a
    0005: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointY:[S
    0007: aget(op=4a) v0, v0[v2]
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] getM_pnAMSPointY() -> [S
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointY:[S
    0002: return-object v0

  [Virtual Method] setM_bPressureFlag(Z) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_bPressureFlag:Z
    0002: return-void

  [Virtual Method] setM_nPointNum(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_nPointNum:I
    0002: return-void

  [Virtual Method] setM_nSimpleNum(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_nSimpleNum:I
    0002: return-void

  [Virtual Method] setM_pcSimpleFlag([C) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pcSimpleFlag:[C
    0002: return-void

  [Virtual Method] setM_pnAMSPointPressure([S) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointPressure:[S
    0002: return-void

  [Virtual Method] setM_pnAMSPointX([S) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointX:[S
    0002: return-void

  [Virtual Method] setM_pnAMSPointY([S) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;->m_pnAMSPointY:[S
    0002: return-void