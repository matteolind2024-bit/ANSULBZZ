=== CLASS Lcom/sec/chaton/ak; (Source: MoreFragment.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] a: Ljava/lang/Integer;
  [Instance Field] b: Landroid/widget/TextView;
  [Instance Field] c: Lcom/sec/chaton/MoreFragment;

  [Direct Method] <init>(Lcom/sec/chaton/MoreFragment;, Ljava/lang/Integer;) -> V
    // registers=4, ins=3, outs=1, insns_size=11
    0000: iput v2, v1.Lcom/sec/chaton/ak;->c:Lcom/sec/chaton/MoreFragment;
    0002: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0005: iput v3, v1.Lcom/sec/chaton/ak;->a:Ljava/lang/Integer;
    0007: const/4 v0, 0
    0008: iput v0, v1.Lcom/sec/chaton/ak;->b:Landroid/widget/TextView;
    000a: return-void

  [Virtual Method] a(Landroid/widget/TextView;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/ak;->b:Landroid/widget/TextView;
    0002: return-void