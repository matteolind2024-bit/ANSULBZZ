=== CLASS Lcom/sec/chaton/UpgradeDialog; (Source: UpgradeDialog.java) ===
  Super: Lcom/sec/chaton/base/BaseActivity;
  [Instance Field] a: Ljava/lang/String;
  [Instance Field] b: Landroid/support/v4/content/LocalBroadcastManager;
  [Instance Field] c: Landroid/content/BroadcastReceiver;
  [Instance Field] d: Landroid/content/Context;
  [Instance Field] e: Lcom/sec/chaton/b/b;
  [Instance Field] g: Z
  [Instance Field] h: Landroid/widget/LinearLayout;
  [Instance Field] i: Landroid/widget/LinearLayout;
  [Instance Field] j: Landroid/widget/LinearLayout;
  [Instance Field] k: Landroid/widget/LinearLayout;
  [Instance Field] l: Landroid/widget/TextView;
  [Instance Field] m: Landroid/widget/TextView;
  [Instance Field] n: Landroid/widget/Button;
  [Instance Field] o: Landroid/widget/Button;
  [Instance Field] p: Z
  [Instance Field] q: Z
  [Instance Field] r: Z
  [Instance Field] s: I

  [Direct Method] <init>() -> V
    // registers=3, ins=1, outs=1, insns_size=16
    0000: const/4 v1, 0
    0001: invoke-direct {v2}, Lcom/sec/chaton/base/BaseActivity;-><init>()V
    0004: const-string v0, 'UpgradeDialog'
    0006: iput v0, v2.Lcom/sec/chaton/UpgradeDialog;->a:Ljava/lang/String;
    0008: iput v1, v2.Lcom/sec/chaton/UpgradeDialog;->e:Lcom/sec/chaton/b/b;
    000a: const/4 v0, 0
    000b: iput v0, v2.Lcom/sec/chaton/UpgradeDialog;->g:Z
    000d: iput v1, v2.Lcom/sec/chaton/UpgradeDialog;->l:Landroid/widget/TextView;
    000f: return-void

  [Direct Method] a() -> V
    // registers=4, ins=1, outs=3, insns_size=41
    0000: const-string v0, 'showPasswordLockActivity'
    0002: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0005: move-result-object v1
    0006: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0009: move-result-object v1
    000a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    000d: invoke-virtual {v3}, Lcom/sec/chaton/UpgradeDialog;->getApplicationContext()Landroid/content/Context;
    0010: move-result-object v0
    0011: invoke-static {v0}, Lcom/sec/chaton/util/j;->c(Landroid/content/Context;)Z
    0014: move-result v1
    0015: if-eqz v1, 0028
    0017: new-instance v1, Landroid/content/Intent;
    0019: const-class v2, Lcom/sec/chaton/settings/ActivityPasswordLockSet;
    001b: invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    001e: const-string v0, 'MODE'
    0020: const-string v2, 'HOME'
    0022: invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    0025: invoke-virtual {v3, v1}, Lcom/sec/chaton/UpgradeDialog;->startActivity(Landroid/content/Intent;)V
    0028: return-void

  [Direct Method] a(Lcom/sec/chaton/UpgradeDialog;) -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/UpgradeDialog;->q:Z
    0002: return v0

  [Direct Method] b(Lcom/sec/chaton/UpgradeDialog;) -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/UpgradeDialog;->s:I
    0002: return v0

  [Direct Method] b() -> V
    // registers=5, ins=1, outs=2, insns_size=185
    0000: const/16 v3, 8 (0x8)
    0002: const/4 v2, 0
    0003: invoke-static {}, Lcom/sec/chaton/util/bp;->b()Z
    0006: move-result v0
    0007: iput v0, v4.Lcom/sec/chaton/UpgradeDialog;->q:Z
    0009: invoke-static {}, Lcom/sec/chaton/util/bp;->a()Z
    000c: move-result v0
    000d: iput v0, v4.Lcom/sec/chaton/UpgradeDialog;->p:Z
    000f: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->k:Landroid/widget/LinearLayout;
    0011: invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V
    0014: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->o:Landroid/widget/Button;
    0016: invoke-virtual {v0, v2}, Landroid/widget/Button;->setVisibility(I)V
    0019: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->s:I
    001b: sget v1, Lcom/sec/chaton/settings/AboutFragment;->e:I
    001d: if-ne v0, v1, 004a
    001f: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->j:Landroid/widget/LinearLayout;
    0021: invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V
    0024: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->n:Landroid/widget/Button;
    0026: invoke-virtual {v0, v2}, Landroid/widget/Button;->setVisibility(I)V
    0029: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->n:Landroid/widget/Button;
    002b: new-instance v1, Lcom/sec/chaton/br;
    002d: invoke-direct {v1, v4}, Lcom/sec/chaton/br;-><init>(Lcom/sec/chaton/UpgradeDialog;)V
    0030: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0033: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->r:Z
    0035: if-eqz v0, 00a6
    0037: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->l:Landroid/widget/TextView;
    0039: const v1, 2131493241 (0x7f0c0179)
    003c: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V
    003f: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->o:Landroid/widget/Button;
    0041: new-instance v1, Lcom/sec/chaton/bv;
    0043: invoke-direct {v1, v4}, Lcom/sec/chaton/bv;-><init>(Lcom/sec/chaton/UpgradeDialog;)V
    0046: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0049: return-void
    004a: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->q:Z
    004c: if-eqz v0, 0091
    004e: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->p:Z
    0050: if-eqz v0, 0091
    0052: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->j:Landroid/widget/LinearLayout;
    0054: invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V
    0057: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->n:Landroid/widget/Button;
    0059: invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V
    005c: const v0, 2131232534 (0x7f080716)
    005f: invoke-virtual {v4, v0}, Lcom/sec/chaton/UpgradeDialog;->findViewById(I)Landroid/view/View;
    0062: move-result-object v0
    0063: check-cast v0, Landroid/widget/LinearLayout;
    0065: iput v0, v4.Lcom/sec/chaton/UpgradeDialog;->h:Landroid/widget/LinearLayout;
    0067: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->h:Landroid/widget/LinearLayout;
    0069: invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V
    006c: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->h:Landroid/widget/LinearLayout;
    006e: new-instance v1, Lcom/sec/chaton/bs;
    0070: invoke-direct {v1, v4}, Lcom/sec/chaton/bs;-><init>(Lcom/sec/chaton/UpgradeDialog;)V
    0073: invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0076: const v0, 2131232535 (0x7f080717)
    0079: invoke-virtual {v4, v0}, Lcom/sec/chaton/UpgradeDialog;->findViewById(I)Landroid/view/View;
    007c: move-result-object v0
    007d: check-cast v0, Landroid/widget/LinearLayout;
    007f: iput v0, v4.Lcom/sec/chaton/UpgradeDialog;->i:Landroid/widget/LinearLayout;
    0081: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->i:Landroid/widget/LinearLayout;
    0083: invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V
    0086: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->i:Landroid/widget/LinearLayout;
    0088: new-instance v1, Lcom/sec/chaton/bt;
    008a: invoke-direct {v1, v4}, Lcom/sec/chaton/bt;-><init>(Lcom/sec/chaton/UpgradeDialog;)V
    008d: invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0090: goto 0033
    0091: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->j:Landroid/widget/LinearLayout;
    0093: invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V
    0096: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->n:Landroid/widget/Button;
    0098: invoke-virtual {v0, v2}, Landroid/widget/Button;->setVisibility(I)V
    009b: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->n:Landroid/widget/Button;
    009d: new-instance v1, Lcom/sec/chaton/bu;
    009f: invoke-direct {v1, v4}, Lcom/sec/chaton/bu;-><init>(Lcom/sec/chaton/UpgradeDialog;)V
    00a2: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    00a5: goto 0033
    00a6: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->l:Landroid/widget/TextView;
    00a8: const v1, 2131493240 (0x7f0c0178)
    00ab: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V
    00ae: iget v0, v4.Lcom/sec/chaton/UpgradeDialog;->o:Landroid/widget/Button;
    00b0: new-instance v1, Lcom/sec/chaton/bw;
    00b2: invoke-direct {v1, v4}, Lcom/sec/chaton/bw;-><init>(Lcom/sec/chaton/UpgradeDialog;)V
    00b5: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    00b8: goto 0049

  [Direct Method] c(Lcom/sec/chaton/UpgradeDialog;) -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/UpgradeDialog;->p:Z
    0002: return v0

  [Direct Method] d(Lcom/sec/chaton/UpgradeDialog;) -> Landroid/content/Context;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/UpgradeDialog;->d:Landroid/content/Context;
    0002: return-object v0

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=10, ins=2, outs=3, insns_size=236
    0000: const v7, 2131232517 (0x7f080705)
    0003: const v6, 2131232515 (0x7f080703)
    0006: const/16 v5, 11 (0xb)
    0008: const/16 v4, 8 (0x8)
    000a: const/4 v3, 0
    000b: invoke-super {v8, v9}, Lcom/sec/chaton/base/BaseActivity;->onCreate(Landroid/os/Bundle;)V
    000e: const/4 v0, 1
    000f: invoke-virtual {v8, v0}, Lcom/sec/chaton/UpgradeDialog;->requestWindowFeature(I)Z
    0012: const v0, 2130903439 (0x7f03018f)
    0015: invoke-virtual {v8, v0}, Lcom/sec/chaton/UpgradeDialog;->setContentView(I)V
    0018: invoke-virtual {v8}, Lcom/sec/chaton/UpgradeDialog;->getWindow()Landroid/view/Window;
    001b: move-result-object v0
    001c: const v1, 17170445 (0x106000d)
    001f: invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawableResource(I)V
    0022: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0024: if-lt v0, v5, 0029
    0026: invoke-virtual {v8, v3}, Lcom/sec/chaton/UpgradeDialog;->setFinishOnTouchOutside(Z)V
    0029: iput v8, v8.Lcom/sec/chaton/UpgradeDialog;->d:Landroid/content/Context;
    002b: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    002e: move-result-object v0
    002f: invoke-static {v0}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    0032: move-result-object v0
    0033: iput v0, v8.Lcom/sec/chaton/UpgradeDialog;->b:Landroid/support/v4/content/LocalBroadcastManager;
    0035: new-instance v0, Lcom/sec/chaton/bq;
    0037: invoke-direct {v0, v8}, Lcom/sec/chaton/bq;-><init>(Lcom/sec/chaton/UpgradeDialog;)V
    003a: iput v0, v8.Lcom/sec/chaton/UpgradeDialog;->c:Landroid/content/BroadcastReceiver;
    003c: new-instance v0, Landroid/content/IntentFilter;
    003e: invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V
    0041: const-string v1, 'com.sec.chaton.ACTION_DISMISS'
    0043: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    0046: iget v1, v8.Lcom/sec/chaton/UpgradeDialog;->b:Landroid/support/v4/content/LocalBroadcastManager;
    0048: iget v2, v8.Lcom/sec/chaton/UpgradeDialog;->c:Landroid/content/BroadcastReceiver;
    004a: invoke-virtual {v1, v2, v0}, Landroid/support/v4/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    004d: const v0, 2131232514 (0x7f080702)
    0050: invoke-virtual {v8, v0}, Lcom/sec/chaton/UpgradeDialog;->findViewById(I)Landroid/view/View;
    0053: move-result-object v0
    0054: check-cast v0, Landroid/widget/TextView;
    0056: iput v0, v8.Lcom/sec/chaton/UpgradeDialog;->l:Landroid/widget/TextView;
    0058: const v0, 2131232513 (0x7f080701)
    005b: invoke-virtual {v8, v0}, Lcom/sec/chaton/UpgradeDialog;->findViewById(I)Landroid/view/View;
    005e: move-result-object v0
    005f: check-cast v0, Landroid/widget/TextView;
    0061: iput v0, v8.Lcom/sec/chaton/UpgradeDialog;->m:Landroid/widget/TextView;
    0063: const v0, 2131230847 (0x7f08007f)
    0066: invoke-virtual {v8, v0}, Lcom/sec/chaton/UpgradeDialog;->findViewById(I)Landroid/view/View;
    0069: move-result-object v0
    006a: check-cast v0, Landroid/widget/LinearLayout;
    006c: iput v0, v8.Lcom/sec/chaton/UpgradeDialog;->j:Landroid/widget/LinearLayout;
    006e: const v0, 2131232536 (0x7f080718)
    0071: invoke-virtual {v8, v0}, Lcom/sec/chaton/UpgradeDialog;->findViewById(I)Landroid/view/View;
    0074: move-result-object v0
    0075: check-cast v0, Landroid/widget/LinearLayout;
    0077: iput v0, v8.Lcom/sec/chaton/UpgradeDialog;->k:Landroid/widget/LinearLayout;
    0079: iget v0, v8.Lcom/sec/chaton/UpgradeDialog;->k:Landroid/widget/LinearLayout;
    007b: const v1, 2131232516 (0x7f080704)
    007e: invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;
    0081: move-result-object v0
    0082: check-cast v0, Landroid/widget/Button;
    0084: iput v0, v8.Lcom/sec/chaton/UpgradeDialog;->o:Landroid/widget/Button;
    0086: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0088: if-ge v0, v5, 00c8
    008a: invoke-virtual {v8, v6}, Lcom/sec/chaton/UpgradeDialog;->findViewById(I)Landroid/view/View;
    008d: move-result-object v0
    008e: check-cast v0, Landroid/widget/Button;
    0090: iput v0, v8.Lcom/sec/chaton/UpgradeDialog;->n:Landroid/widget/Button;
    0092: iget v0, v8.Lcom/sec/chaton/UpgradeDialog;->n:Landroid/widget/Button;
    0094: invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V
    0097: invoke-virtual {v8, v7}, Lcom/sec/chaton/UpgradeDialog;->findViewById(I)Landroid/view/View;
    009a: move-result-object v0
    009b: invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V
    009e: invoke-virtual {v8}, Lcom/sec/chaton/UpgradeDialog;->getIntent()Landroid/content/Intent;
    00a1: move-result-object v0
    00a2: const-string v1, 'isCritical'
    00a4: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    00a7: move-result v0
    00a8: iput v0, v8.Lcom/sec/chaton/UpgradeDialog;->r:Z
    00aa: invoke-virtual {v8}, Lcom/sec/chaton/UpgradeDialog;->getIntent()Landroid/content/Intent;
    00ad: move-result-object v0
    00ae: const-string v1, 'which_service'
    00b0: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    00b3: move-result v0
    00b4: iput v0, v8.Lcom/sec/chaton/UpgradeDialog;->s:I
    00b6: iget v0, v8.Lcom/sec/chaton/UpgradeDialog;->s:I
    00b8: sget v1, Lcom/sec/chaton/settings/AboutFragment;->d:I
    00ba: if-ne v0, v1, 00dd
    00bc: iget v0, v8.Lcom/sec/chaton/UpgradeDialog;->m:Landroid/widget/TextView;
    00be: const v1, 2131494260 (0x7f0c0574)
    00c1: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V
    00c4: invoke-direct {v8}, Lcom/sec/chaton/UpgradeDialog;->b()V
    00c7: return-void
    00c8: invoke-virtual {v8, v7}, Lcom/sec/chaton/UpgradeDialog;->findViewById(I)Landroid/view/View;
    00cb: move-result-object v0
    00cc: check-cast v0, Landroid/widget/Button;
    00ce: iput v0, v8.Lcom/sec/chaton/UpgradeDialog;->n:Landroid/widget/Button;
    00d0: iget v0, v8.Lcom/sec/chaton/UpgradeDialog;->n:Landroid/widget/Button;
    00d2: invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V
    00d5: invoke-virtual {v8, v6}, Lcom/sec/chaton/UpgradeDialog;->findViewById(I)Landroid/view/View;
    00d8: move-result-object v0
    00d9: invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V
    00dc: goto 009e
    00dd: iget v0, v8.Lcom/sec/chaton/UpgradeDialog;->s:I
    00df: sget v1, Lcom/sec/chaton/settings/AboutFragment;->e:I
    00e1: if-ne v0, v1, 00c4
    00e3: iget v0, v8.Lcom/sec/chaton/UpgradeDialog;->m:Landroid/widget/TextView;
    00e5: const v1, 2131494009 (0x7f0c0479)
    00e8: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V
    00eb: goto 00c4

  [Virtual Method] onDestroy() -> V
    // registers=3, ins=1, outs=2, insns_size=43
    0000: invoke-super {v2}, Lcom/sec/chaton/base/BaseActivity;->onDestroy()V
    0003: const-string v0, 'check_upgrade_do_not_show'
    0005: iget v1, v2.Lcom/sec/chaton/UpgradeDialog;->g:Z
    0007: invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    000a: move-result-object v1
    000b: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Boolean;)V
    000e: iget v0, v2.Lcom/sec/chaton/UpgradeDialog;->b:Landroid/support/v4/content/LocalBroadcastManager;
    0010: iget v1, v2.Lcom/sec/chaton/UpgradeDialog;->c:Landroid/content/BroadcastReceiver;
    0012: invoke-virtual {v0, v1}, Landroid/support/v4/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    0015: iget v0, v2.Lcom/sec/chaton/UpgradeDialog;->d:Landroid/content/Context;
    0017: if-eqz v0, 002a
    0019: iget v0, v2.Lcom/sec/chaton/UpgradeDialog;->e:Lcom/sec/chaton/b/b;
    001b: if-eqz v0, 002a
    001d: iget v0, v2.Lcom/sec/chaton/UpgradeDialog;->e:Lcom/sec/chaton/b/b;
    001f: invoke-virtual {v0}, Lcom/sec/chaton/b/b;->isShowing()Z
    0022: move-result v0
    0023: if-eqz v0, 002a
    0025: iget v0, v2.Lcom/sec/chaton/UpgradeDialog;->e:Lcom/sec/chaton/b/b;
    0027: invoke-virtual {v0}, Lcom/sec/chaton/b/b;->dismiss()V
    002a: return-void

  [Virtual Method] onKeyDown(I, Landroid/view/KeyEvent;) -> Z
    // registers=4, ins=3, outs=3, insns_size=10
    0000: const/4 v0, 4
    0001: if-ne v2, v0, 0005
    0003: const/4 v0, 1
    0004: return v0
    0005: invoke-super {v1, v2, v3}, Lcom/sec/chaton/base/BaseActivity;->onKeyDown(ILandroid/view/KeyEvent;)Z
    0008: move-result v0
    0009: goto 0004

  [Virtual Method] onResume() -> V
    // registers=1, ins=1, outs=1, insns_size=7
    0000: invoke-super {v0}, Lcom/sec/chaton/base/BaseActivity;->onResume()V
    0003: invoke-direct {v0}, Lcom/sec/chaton/UpgradeDialog;->a()V
    0006: return-void