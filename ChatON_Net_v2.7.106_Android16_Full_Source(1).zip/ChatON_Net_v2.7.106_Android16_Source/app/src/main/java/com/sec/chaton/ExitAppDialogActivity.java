=== CLASS Lcom/sec/chaton/ExitAppDialogActivity; (Source: ExitAppDialogActivity.java) ===
  Super: Landroid/app/Activity;
  [Instance Field] a: I
  [Instance Field] b: Lcom/coolots/sso/a/a;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/app/Activity;-><init>()V
    0003: return-void

  [Direct Method] a(Lcom/sec/chaton/ExitAppDialogActivity;) -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/ExitAppDialogActivity;->a:I
    0002: return v0

  [Direct Method] a(I) -> V
    // registers=3, ins=1, outs=3, insns_size=34
    0000: const-string v0, 'exit_app_done'
    0002: const/4 v1, 1
    0003: invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0006: move-result-object v1
    0007: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Boolean;)V
    000a: new-instance v0, Landroid/content/Intent;
    000c: const-string v1, 'com.sec.chaton.ACTION_EXIT_APP'
    000e: invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    0011: const-string v1, 'reason'
    0013: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    0016: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0019: move-result-object v1
    001a: invoke-static {v1}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    001d: move-result-object v1
    001e: invoke-virtual {v1, v0}, Landroid/support/v4/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z
    0021: return-void

  [Direct Method] a() -> Z
    // registers=3, ins=0, outs=3, insns_size=20
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'exit_app_done'
    0006: const/4 v2, 0
    0007: invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    000a: move-result-object v2
    000b: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    000e: move-result-object v0
    000f: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    0012: move-result v0
    0013: return v0

  [Direct Method] b() -> V
    // registers=3, ins=0, outs=2, insns_size=33
    0000: const/4 v2, 0
    0001: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0004: move-result-object v0
    0005: const-string v1, 'uid'
    0007: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    000a: move-result v0
    000b: if-eqz v0, 0017
    000d: const-string v0, 'Exit App. Unauthorized.'
    000f: invoke-static {v0, v2}, Lcom/sec/chaton/util/p;->a(Ljava/lang/String;Ljava/lang/String;)V
    0012: const/4 v0, 0
    0013: invoke-static {v0}, Lcom/sec/chaton/ExitAppDialogActivity;->a(I)V
    0016: return-void
    0017: sget v0, Lcom/sec/chaton/util/p;->b:Z
    0019: if-eqz v0, 0016
    001b: const-string v0, 'it was already deleted'
    001d: invoke-static {v0, v2}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0020: goto 0016

  [Direct Method] c() -> V
    // registers=4, ins=1, outs=2, insns_size=62
    0000: const v2, 2131231308 (0x7f08024c)
    0003: const-string v0, 'ExitAppDialogActivity initView'
    0005: const/4 v1, 0
    0006: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    0009: const v0, 16908313 (0x1020019)
    000c: invoke-virtual {v3, v0}, Lcom/sec/chaton/ExitAppDialogActivity;->findViewById(I)Landroid/view/View;
    000f: move-result-object v0
    0010: check-cast v0, Landroid/widget/Button;
    0012: new-instance v1, Lcom/sec/chaton/q;
    0014: invoke-direct {v1, v3}, Lcom/sec/chaton/q;-><init>(Lcom/sec/chaton/ExitAppDialogActivity;)V
    0017: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    001a: const/4 v0, 1
    001b: iget v1, v3.Lcom/sec/chaton/ExitAppDialogActivity;->a:I
    001d: if-ne v0, v1, 002c
    001f: invoke-virtual {v3, v2}, Lcom/sec/chaton/ExitAppDialogActivity;->findViewById(I)Landroid/view/View;
    0022: move-result-object v0
    0023: check-cast v0, Landroid/widget/TextView;
    0025: const v1, 2131493699 (0x7f0c0343)
    0028: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V
    002b: return-void
    002c: const/4 v0, 2
    002d: iget v1, v3.Lcom/sec/chaton/ExitAppDialogActivity;->a:I
    002f: if-ne v0, v1, 002b
    0031: invoke-virtual {v3, v2}, Lcom/sec/chaton/ExitAppDialogActivity;->findViewById(I)Landroid/view/View;
    0034: move-result-object v0
    0035: check-cast v0, Landroid/widget/TextView;
    0037: const v1, 2131494265 (0x7f0c0579)
    003a: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V
    003d: goto 002b

  [Virtual Method] onBackPressed() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=5, ins=2, outs=3, insns_size=78
    0000: const/4 v2, 0
    0001: invoke-super {v3, v4}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    0004: const/4 v0, 1
    0005: invoke-virtual {v3, v0}, Lcom/sec/chaton/ExitAppDialogActivity;->requestWindowFeature(I)Z
    0008: const v0, 2130903140 (0x7f030064)
    000b: invoke-virtual {v3, v0}, Lcom/sec/chaton/ExitAppDialogActivity;->setContentView(I)V
    000e: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0010: const/16 v1, 11 (0xb)
    0012: if-lt v0, v1, 0017
    0014: invoke-virtual {v3, v2}, Lcom/sec/chaton/ExitAppDialogActivity;->setFinishOnTouchOutside(Z)V
    0017: invoke-virtual {v3}, Lcom/sec/chaton/ExitAppDialogActivity;->getIntent()Landroid/content/Intent;
    001a: move-result-object v0
    001b: const-string v1, 'reason'
    001d: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    0020: move-result v0
    0021: iput v0, v3.Lcom/sec/chaton/ExitAppDialogActivity;->a:I
    0023: invoke-direct {v3}, Lcom/sec/chaton/ExitAppDialogActivity;->c()V
    0026: invoke-static {v3}, Lcom/sec/chaton/util/bp;->a(Landroid/content/Context;)Z
    0029: move-result v0
    002a: if-eqz v0, 004d
    002c: new-instance v0, Lcom/coolots/sso/a/a;
    002e: invoke-direct {v0}, Lcom/coolots/sso/a/a;-><init>()V
    0031: iput v0, v3.Lcom/sec/chaton/ExitAppDialogActivity;->b:Lcom/coolots/sso/a/a;
    0033: iget v0, v3.Lcom/sec/chaton/ExitAppDialogActivity;->b:Lcom/coolots/sso/a/a;
    0035: invoke-virtual {v0, v3}, Lcom/coolots/sso/a/a;->d(Landroid/content/Context;)Z
    0038: move-result v0
    0039: if-eqz v0, 004d
    003b: iget v0, v3.Lcom/sec/chaton/ExitAppDialogActivity;->b:Lcom/coolots/sso/a/a;
    003d: invoke-virtual {v0, v3}, Lcom/coolots/sso/a/a;->c(Landroid/content/Context;)I
    0040: const-string v0, 'onCreate:mChatonV.removeAccountInDevice()'
    0042: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0045: move-result-object v1
    0046: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0049: move-result-object v1
    004a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    004d: return-void

  [Virtual Method] onNewIntent(Landroid/content/Intent;) -> V
    // registers=4, ins=2, outs=3, insns_size=24
    0000: const/4 v1, 0
    0001: invoke-super {v2, v3}, Landroid/app/Activity;->onNewIntent(Landroid/content/Intent;)V
    0004: invoke-virtual {v2, v3}, Lcom/sec/chaton/ExitAppDialogActivity;->setIntent(Landroid/content/Intent;)V
    0007: if-eqz v3, 0015
    0009: const-string v0, 'reason'
    000b: invoke-virtual {v3, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    000e: move-result v0
    000f: iput v0, v2.Lcom/sec/chaton/ExitAppDialogActivity;->a:I
    0011: invoke-direct {v2}, Lcom/sec/chaton/ExitAppDialogActivity;->c()V
    0014: return-void
    0015: iput v1, v2.Lcom/sec/chaton/ExitAppDialogActivity;->a:I
    0017: goto 0011

  [Virtual Method] onUserLeaveHint() -> V
    // registers=3, ins=1, outs=2, insns_size=14
    0000: const-string v0, 'onUserLeaveHint'
    0002: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0005: move-result-object v1
    0006: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0009: move-result-object v1
    000a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    000d: return-void