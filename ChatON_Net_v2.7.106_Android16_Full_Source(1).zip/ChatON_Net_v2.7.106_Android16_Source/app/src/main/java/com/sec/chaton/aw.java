=== CLASS Lcom/sec/chaton/aw; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/sec/chaton/util/bb;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/aw;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] a() -> Z
    // registers=3, ins=1, outs=2, insns_size=28
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'uid'
    0006: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0009: move-result v0
    000a: if-eqz v0, 001a
    000c: const-string v0, 'Chaton contact DB (delete all contact)'
    000e: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    0011: move-result-object v1
    0012: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    0015: invoke-static {}, Lcom/sec/chaton/e/a/g;->a()V
    0018: const/4 v0, 1
    0019: return v0
    001a: const/4 v0, 0
    001b: goto 0019