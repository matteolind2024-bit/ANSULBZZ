=== CLASS Lcom/sec/a/a/a/a; (Source: MsgFrontend.java) ===
  Super: Ljava/lang/Object;