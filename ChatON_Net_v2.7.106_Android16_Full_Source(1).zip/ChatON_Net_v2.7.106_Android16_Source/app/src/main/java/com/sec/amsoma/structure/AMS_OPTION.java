=== CLASS Lcom/sec/amsoma/structure/AMS_OPTION; (Source: AMS_OPTION.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] m_bBGROrder: Z
  [Instance Field] m_cSimplificationBufSize: B
  [Instance Field] m_cTurnPageEffect: B
  [Instance Field] m_eSamplingOption: I
  [Instance Field] m_eSmoothingOption: I
  [Instance Field] m_fGenerationCurvature: F
  [Instance Field] m_fSimplificationTolerance: F
  [Instance Field] m_nGenerationAddPointGap: I
  [Instance Field] m_nGenerationExceptMaxLength: I
  [Instance Field] m_nGenerationExceptMinLength: I
  [Instance Field] m_nImageBPP: I
  [Instance Field] m_nMaxPageNum: I

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] Init() -> V
    // registers=3, ins=1, outs=0, insns_size=40
    0000: const/4 v1, 0
    0001: const/4 v0, 3
    0002: iput v0, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nMaxPageNum:I
    0004: const/16 v0, 24 (0x18)
    0006: iput v0, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nImageBPP:I
    0008: iput v1, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_bBGROrder:Z
    000a: const/4 v0, 6
    000b: iput v0, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_cSimplificationBufSize:B
    000d: const/high16 v0, 1073741824 (0x40000000)
    000f: iput v0, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_fSimplificationTolerance:F
    0011: iput v1, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_eSmoothingOption:I
    0013: const/4 v0, 2
    0014: iput v0, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_eSamplingOption:I
    0016: const/4 v0, 7
    0017: iput v0, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nGenerationExceptMinLength:I
    0019: const/16 v0, 60 (0x3c)
    001b: iput v0, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nGenerationExceptMaxLength:I
    001d: const/4 v0, 5
    001e: iput v0, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nGenerationAddPointGap:I
    0020: const/high16 v0, 1077936128 (0x40400000)
    0022: iput v0, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_fGenerationCurvature:F
    0024: const/4 v0, 1
    0025: iput v0, v2.Lcom/sec/amsoma/structure/AMS_OPTION;->m_cTurnPageEffect:B
    0027: return-void

  [Virtual Method] getM_eSamplingOption() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OPTION;->m_eSamplingOption:I
    0002: return v0

  [Virtual Method] getM_eSmoothingOption() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OPTION;->m_eSmoothingOption:I
    0002: return v0

  [Virtual Method] getM_fGenerationCurvature() -> F
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OPTION;->m_fGenerationCurvature:F
    0002: return v0

  [Virtual Method] getM_fSimplificationTolerance() -> F
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OPTION;->m_fSimplificationTolerance:F
    0002: return v0

  [Virtual Method] getM_nGenerationAddPointGap() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nGenerationAddPointGap:I
    0002: return v0

  [Virtual Method] getM_nGenerationExceptMaxLength() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nGenerationExceptMaxLength:I
    0002: return v0

  [Virtual Method] getM_nGenerationExceptMinLength() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nGenerationExceptMinLength:I
    0002: return v0

  [Virtual Method] getM_nImageBPP() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nImageBPP:I
    0002: return v0

  [Virtual Method] getM_nMaxPageNum() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nMaxPageNum:I
    0002: return v0

  [Virtual Method] isM_bBGROrder() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OPTION;->m_bBGROrder:Z
    0002: return v0

  [Virtual Method] setM_bBGROrder(Z) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OPTION;->m_bBGROrder:Z
    0002: return-void

  [Virtual Method] setM_eSamplingOption(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OPTION;->m_eSamplingOption:I
    0002: return-void

  [Virtual Method] setM_eSmoothingOption(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OPTION;->m_eSmoothingOption:I
    0002: return-void

  [Virtual Method] setM_fGenerationCurvature(F) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OPTION;->m_fGenerationCurvature:F
    0002: return-void

  [Virtual Method] setM_fSimplificationTolerance(F) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OPTION;->m_fSimplificationTolerance:F
    0002: return-void

  [Virtual Method] setM_nGenerationAddPointGap(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nGenerationAddPointGap:I
    0002: return-void

  [Virtual Method] setM_nGenerationExceptMaxLength(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nGenerationExceptMaxLength:I
    0002: return-void

  [Virtual Method] setM_nGenerationExceptMinLength(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nGenerationExceptMinLength:I
    0002: return-void

  [Virtual Method] setM_nImageBPP(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nImageBPP:I
    0002: return-void

  [Virtual Method] setM_nMaxPageNum(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OPTION;->m_nMaxPageNum:I
    0002: return-void