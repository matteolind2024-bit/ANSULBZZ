=== CLASS Lcom/sec/amsoma/structure/AMS_POINT; (Source: AMS_POINT.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] x: S
  [Instance Field] y: S

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getX() -> S
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_POINT;->x:S
    0002: return v0

  [Virtual Method] getY() -> S
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_POINT;->y:S
    0002: return v0

  [Virtual Method] setX(S) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_POINT;->x:S
    0002: return-void

  [Virtual Method] setY(S) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_POINT;->y:S
    0002: return-void