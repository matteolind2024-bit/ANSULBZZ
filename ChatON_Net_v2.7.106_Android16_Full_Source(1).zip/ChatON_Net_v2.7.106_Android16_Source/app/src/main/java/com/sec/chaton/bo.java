=== CLASS Lcom/sec/chaton/bo; (Source: TabActivity.java) ===
  Super: Landroid/os/Handler;
  [Instance Field] a: Lcom/sec/chaton/bn;

  [Direct Method] <init>(Lcom/sec/chaton/bn;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/bo;->a:Lcom/sec/chaton/bn;
    0002: invoke-direct {v0}, Landroid/os/Handler;-><init>()V
    0005: return-void

  [Virtual Method] handleMessage(Landroid/os/Message;) -> V
    // registers=9, ins=2, outs=7, insns_size=43
    0000: iget v0, v8.Landroid/os/Message;->obj:Ljava/lang/Object;
    0002: check-cast v0, Ljava/lang/Boolean;
    0004: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    0007: move-result v3
    0008: iget v0, v7.Lcom/sec/chaton/bo;->a:Lcom/sec/chaton/bn;
    000a: iget v0, v0.Lcom/sec/chaton/bn;->a:Lcom/sec/chaton/TabActivity;
    000c: invoke-static {v0}, Lcom/sec/chaton/TabActivity;->b(Lcom/sec/chaton/TabActivity;)Lcom/sec/chaton/util/ay;
    000f: move-result-object v0
    0010: const-string v1, 'get_all_unread'
    0012: iget v2, v7.Lcom/sec/chaton/bo;->a:Lcom/sec/chaton/bn;
    0014: iget v2, v2.Lcom/sec/chaton/bn;->a:Lcom/sec/chaton/TabActivity;
    0016: invoke-static {v2}, Lcom/sec/chaton/TabActivity;->a(Lcom/sec/chaton/TabActivity;)Lcom/sec/chaton/util/bb;
    0019: move-result-object v2
    001a: if-eqz v3, 0027
    001c: const v3, 6000000 (0x5b8d80)
    001f: unop(op=81) v3, v3
    0020: const-string v5, 'last_sync_time_get_all_unread'
    0022: const/4 v6, 1
    0023: invoke-virtual/range {v0..v6}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;Z)V
    0026: return-void
    0027: const v3, 60000 (0xea60)
    002a: goto 001f