=== CLASS Lcom/sec/chaton/ah; (Source: MoreFragment.java) ===
  Super: Landroid/content/BroadcastReceiver;
  [Instance Field] a: Lcom/sec/chaton/MoreFragment;

  [Direct Method] <init>(Lcom/sec/chaton/MoreFragment;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/ah;->a:Lcom/sec/chaton/MoreFragment;
    0002: invoke-direct {v0}, Landroid/content/BroadcastReceiver;-><init>()V
    0005: return-void

  [Virtual Method] onReceive(Landroid/content/Context;, Landroid/content/Intent;) -> V
    // registers=4, ins=3, outs=1, insns_size=23
    0000: iget v0, v1.Lcom/sec/chaton/ah;->a:Lcom/sec/chaton/MoreFragment;
    0002: invoke-static {v0}, Lcom/sec/chaton/MoreFragment;->a(Lcom/sec/chaton/MoreFragment;)V
    0005: iget v0, v1.Lcom/sec/chaton/ah;->a:Lcom/sec/chaton/MoreFragment;
    0007: invoke-static {v0}, Lcom/sec/chaton/MoreFragment;->b(Lcom/sec/chaton/MoreFragment;)Lcom/sec/chaton/aj;
    000a: move-result-object v0
    000b: if-eqz v0, 0016
    000d: iget v0, v1.Lcom/sec/chaton/ah;->a:Lcom/sec/chaton/MoreFragment;
    000f: invoke-static {v0}, Lcom/sec/chaton/MoreFragment;->b(Lcom/sec/chaton/MoreFragment;)Lcom/sec/chaton/aj;
    0012: move-result-object v0
    0013: invoke-virtual {v0}, Lcom/sec/chaton/aj;->notifyDataSetChanged()V
    0016: return-void