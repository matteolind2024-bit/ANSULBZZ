=== CLASS Lcom/sec/chaton/bl; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/sec/chaton/util/bb;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/bl;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] a() -> Z
    // registers=7, ins=1, outs=3, insns_size=123
    0000: const/4 v5, 0
    0001: const/4 v4, -1
    0002: new-instance v0, Ljava/lang/StringBuilder;
    0004: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0007: const-string v1, 'mGetAllBuddiesTask run [UID] '
    0009: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000c: move-result-object v0
    000d: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0010: move-result-object v1
    0011: const-string v2, 'uid'
    0013: invoke-virtual {v1, v2}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0016: move-result v1
    0017: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    001a: move-result-object v0
    001b: const-string v1, ' [MSISDN] '
    001d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0020: move-result-object v0
    0021: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0024: move-result-object v1
    0025: const-string v2, 'msisdn'
    0027: const-string v3, ''
    0029: invoke-virtual {v1, v2, v3}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    002c: move-result-object v1
    002d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0030: move-result-object v0
    0031: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0034: move-result-object v0
    0035: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    0038: move-result-object v1
    0039: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    003c: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    003f: move-result-object v0
    0040: const-string v1, 'uid'
    0042: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0045: move-result v0
    0046: if-eqz v0, 0067
    0048: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    004b: move-result-object v0
    004c: const-string v1, 'msisdn'
    004e: const-string v2, ''
    0050: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    0053: move-result-object v0
    0054: invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z
    0057: move-result v0
    0058: if-nez v0, 0072
    005a: const-string v0, 'getAllBuddies'
    005c: invoke-static {v0}, Lcom/sec/chaton/account/i;->c(Ljava/lang/String;)V
    005f: new-instance v0, Lcom/sec/chaton/d/h;
    0061: invoke-direct {v0, v5}, Lcom/sec/chaton/d/h;-><init>(Landroid/os/Handler;)V
    0064: invoke-virtual {v0, v4, v4}, Lcom/sec/chaton/d/h;->a(II)V
    0067: const-string v0, 'mGetAllBuddiesTask finish'
    0069: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    006c: move-result-object v1
    006d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0070: const/4 v0, 1
    0071: return v0
    0072: new-instance v0, Lcom/sec/chaton/d/h;
    0074: invoke-direct {v0, v5}, Lcom/sec/chaton/d/h;-><init>(Landroid/os/Handler;)V
    0077: invoke-virtual {v0}, Lcom/sec/chaton/d/h;->a()V
    007a: goto 005f