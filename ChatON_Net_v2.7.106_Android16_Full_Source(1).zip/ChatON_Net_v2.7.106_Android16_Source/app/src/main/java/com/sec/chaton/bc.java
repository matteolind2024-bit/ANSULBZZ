=== CLASS Lcom/sec/chaton/bc; (Source: TabActivity.java) ===
  Super: Landroid/content/BroadcastReceiver;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/bc;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Landroid/content/BroadcastReceiver;-><init>()V
    0005: return-void

  [Virtual Method] onReceive(Landroid/content/Context;, Landroid/content/Intent;) -> V
    // registers=6, ins=3, outs=3, insns_size=47
    0000: sget v0, Lcom/sec/chaton/util/p;->b:Z
    0002: if-eqz v0, 000d
    0004: const-string v0, 'received Update Push Version'
    0006: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    0009: move-result-object v1
    000a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    000d: new-instance v0, Landroid/content/Intent;
    000f: iget v1, v3.Lcom/sec/chaton/bc;->a:Lcom/sec/chaton/TabActivity;
    0011: const-class v2, Lcom/sec/chaton/UpgradeDialog;
    0013: invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0016: const-string v1, 'isCritical'
    0018: const/4 v2, 0
    0019: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    001c: const-string v1, 'isFromHome'
    001e: const/4 v2, 1
    001f: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    0022: const-string v1, 'which_service'
    0024: sget v2, Lcom/sec/chaton/settings/AboutFragment;->e:I
    0026: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    0029: iget v1, v3.Lcom/sec/chaton/bc;->a:Lcom/sec/chaton/TabActivity;
    002b: invoke-virtual {v1, v0}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    002e: return-void