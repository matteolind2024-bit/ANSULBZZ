=== CLASS Lcom/sec/a/a/a/aa; (Source: MsgFrontend.java) ===
  Super: Lcom/google/protobuf/GeneratedMessageLite;
  Interfaces: Lcom/sec/a/a/a/ac;
  [Static Field] a: Lcom/sec/a/a/a/aa;
  [Instance Field] b: I
  [Instance Field] c: I
  [Instance Field] d: J
  [Instance Field] e: I
  [Instance Field] f: B
  [Instance Field] g: I

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=2, insns_size=14
    0000: new-instance v0, Lcom/sec/a/a/a/aa;
    0002: const/4 v1, 1
    0003: invoke-direct {v0, v1}, Lcom/sec/a/a/a/aa;-><init>(Z)V
    0006: sput v0, Lcom/sec/a/a/a/aa;->a:Lcom/sec/a/a/a/aa;
    0008: sget v0, Lcom/sec/a/a/a/aa;->a:Lcom/sec/a/a/a/aa;
    000a: invoke-direct {v0}, Lcom/sec/a/a/a/aa;->k()V
    000d: return-void

  [Direct Method] <init>(Lcom/sec/a/a/a/ab;) -> V
    // registers=3, ins=2, outs=2, insns_size=9
    0000: const/4 v0, -1
    0001: invoke-direct {v1, v2}, Lcom/google/protobuf/GeneratedMessageLite;-><init>(Lcom/google/protobuf/GeneratedMessageLite$Builder;)V
    0004: iput v0, v1.Lcom/sec/a/a/a/aa;->f:B
    0006: iput v0, v1.Lcom/sec/a/a/a/aa;->g:I
    0008: return-void

  [Direct Method] <init>(Lcom/sec/a/a/a/ab;, Lcom/sec/a/a/a/b;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/sec/a/a/a/aa;-><init>(Lcom/sec/a/a/a/ab;)V
    0003: return-void

  [Direct Method] <init>(Z) -> V
    // registers=3, ins=2, outs=1, insns_size=9
    0000: const/4 v0, -1
    0001: invoke-direct {v1}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V
    0004: iput v0, v1.Lcom/sec/a/a/a/aa;->f:B
    0006: iput v0, v1.Lcom/sec/a/a/a/aa;->g:I
    0008: return-void

  [Direct Method] a(Lcom/sec/a/a/a/aa;, I) -> I
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/a/a/a/aa;->c:I
    0002: return v1

  [Direct Method] a(Lcom/sec/a/a/a/aa;, J) -> J
    // registers=3, ins=3, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/a/a/a/aa;->d:J
    0002: return-wide v1

  [Direct Method] a() -> Lcom/sec/a/a/a/aa;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/sec/a/a/a/aa;->a:Lcom/sec/a/a/a/aa;
    0002: return-object v0

  [Direct Method] a([B) -> Lcom/sec/a/a/a/aa;
    // registers=2, ins=1, outs=2, insns_size=15
    0000: invoke-static {}, Lcom/sec/a/a/a/aa;->newBuilder()Lcom/sec/a/a/a/ab;
    0003: move-result-object v0
    0004: invoke-virtual {v0, v1}, Lcom/sec/a/a/a/ab;->mergeFrom([B)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0007: move-result-object v0
    0008: check-cast v0, Lcom/sec/a/a/a/ab;
    000a: invoke-static {v0}, Lcom/sec/a/a/a/ab;->a(Lcom/sec/a/a/a/ab;)Lcom/sec/a/a/a/aa;
    000d: move-result-object v0
    000e: return-object v0

  [Direct Method] a(Lcom/sec/a/a/a/aa;) -> Lcom/sec/a/a/a/ab;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: invoke-static {}, Lcom/sec/a/a/a/aa;->newBuilder()Lcom/sec/a/a/a/ab;
    0003: move-result-object v0
    0004: invoke-virtual {v0, v1}, Lcom/sec/a/a/a/ab;->a(Lcom/sec/a/a/a/aa;)Lcom/sec/a/a/a/ab;
    0007: move-result-object v0
    0008: return-object v0

  [Direct Method] b(Lcom/sec/a/a/a/aa;, I) -> I
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/a/a/a/aa;->e:I
    0002: return v1

  [Direct Method] c(Lcom/sec/a/a/a/aa;, I) -> I
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/a/a/a/aa;->b:I
    0002: return v1

  [Direct Method] k() -> V
    // registers=4, ins=1, outs=0, insns_size=10
    0000: const/4 v2, 0
    0001: iput v2, v3.Lcom/sec/a/a/a/aa;->c:I
    0003: const-wide/16 v0, 0
    0005: iput v0, v3.Lcom/sec/a/a/a/aa;->d:J
    0007: iput v2, v3.Lcom/sec/a/a/a/aa;->e:I
    0009: return-void

  [Direct Method] newBuilder() -> Lcom/sec/a/a/a/ab;
    // registers=1, ins=0, outs=0, insns_size=5
    0000: invoke-static {}, Lcom/sec/a/a/a/ab;->f()Lcom/sec/a/a/a/ab;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] b() -> Lcom/sec/a/a/a/aa;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: sget v0, Lcom/sec/a/a/a/aa;->a:Lcom/sec/a/a/a/aa;
    0002: return-object v0

  [Virtual Method] c() -> Z
    // registers=3, ins=1, outs=0, insns_size=10
    0000: const/4 v0, 1
    0001: iget v1, v2.Lcom/sec/a/a/a/aa;->b:I
    0003: binop/lit8(op=dd) v1, v1, 1 (0x1)
    0005: if-ne v1, v0, 0008
    0007: return v0
    0008: const/4 v0, 0
    0009: goto 0007

  [Virtual Method] d() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/a/a/a/aa;->c:I
    0002: return v0

  [Virtual Method] e() -> Z
    // registers=3, ins=1, outs=0, insns_size=11
    0000: iget v0, v2.Lcom/sec/a/a/a/aa;->b:I
    0002: binop/lit8(op=dd) v0, v0, 2 (0x2)
    0004: const/4 v1, 2
    0005: if-ne v0, v1, 0009
    0007: const/4 v0, 1
    0008: return v0
    0009: const/4 v0, 0
    000a: goto 0008

  [Virtual Method] f() -> J
    // registers=3, ins=1, outs=0, insns_size=3
    0000: iget v0, v2.Lcom/sec/a/a/a/aa;->d:J
    0002: return-wide v0

  [Virtual Method] g() -> Z
    // registers=3, ins=1, outs=0, insns_size=11
    0000: iget v0, v2.Lcom/sec/a/a/a/aa;->b:I
    0002: binop/lit8(op=dd) v0, v0, 4 (0x4)
    0004: const/4 v1, 4
    0005: if-ne v0, v1, 0009
    0007: const/4 v0, 1
    0008: return v0
    0009: const/4 v0, 0
    000a: goto 0008

  [Virtual Method] getDefaultInstanceForType() -> Lcom/google/protobuf/MessageLite;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/aa;->b()Lcom/sec/a/a/a/aa;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getSerializedSize() -> I
    // registers=5, ins=1, outs=3, insns_size=53
    0000: const/4 v3, 2
    0001: const/4 v2, 1
    0002: iget v0, v4.Lcom/sec/a/a/a/aa;->g:I
    0004: const/4 v1, -1
    0005: if-eq v0, v1, 0008
    0007: return v0
    0008: const/4 v0, 0
    0009: iget v1, v4.Lcom/sec/a/a/a/aa;->b:I
    000b: binop/lit8(op=dd) v1, v1, 1 (0x1)
    000d: if-ne v1, v2, 0016
    000f: iget v1, v4.Lcom/sec/a/a/a/aa;->c:I
    0011: invoke-static {v2, v1}, Lcom/google/protobuf/CodedOutputStream;->computeInt32Size(II)I
    0014: move-result v1
    0015: binop/2addr(op=b0) v0, v1
    0016: iget v1, v4.Lcom/sec/a/a/a/aa;->b:I
    0018: binop/lit8(op=dd) v1, v1, 2 (0x2)
    001a: if-ne v1, v3, 0023
    001c: iget v1, v4.Lcom/sec/a/a/a/aa;->d:J
    001e: invoke-static {v3, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->computeInt64Size(IJ)I
    0021: move-result v1
    0022: binop/2addr(op=b0) v0, v1
    0023: iget v1, v4.Lcom/sec/a/a/a/aa;->b:I
    0025: binop/lit8(op=dd) v1, v1, 4 (0x4)
    0027: const/4 v2, 4
    0028: if-ne v1, v2, 0032
    002a: const/4 v1, 3
    002b: iget v2, v4.Lcom/sec/a/a/a/aa;->e:I
    002d: invoke-static {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->computeInt32Size(II)I
    0030: move-result v1
    0031: binop/2addr(op=b0) v0, v1
    0032: iput v0, v4.Lcom/sec/a/a/a/aa;->g:I
    0034: goto 0007

  [Virtual Method] h() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/a/a/a/aa;->e:I
    0002: return v0

  [Virtual Method] i() -> Lcom/sec/a/a/a/ab;
    // registers=2, ins=1, outs=0, insns_size=5
    0000: invoke-static {}, Lcom/sec/a/a/a/aa;->newBuilder()Lcom/sec/a/a/a/ab;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] isInitialized() -> Z
    // registers=4, ins=1, outs=0, insns_size=14
    0000: const/4 v0, 1
    0001: iget v1, v3.Lcom/sec/a/a/a/aa;->f:B
    0003: const/4 v2, -1
    0004: if-eq v1, v2, 000b
    0006: if-ne v1, v0, 0009
    0008: return v0
    0009: const/4 v0, 0
    000a: goto 0008
    000b: iput v0, v3.Lcom/sec/a/a/a/aa;->f:B
    000d: goto 0008

  [Virtual Method] j() -> Lcom/sec/a/a/a/ab;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-static {v1}, Lcom/sec/a/a/a/aa;->a(Lcom/sec/a/a/a/aa;)Lcom/sec/a/a/a/ab;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] newBuilderForType() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/aa;->i()Lcom/sec/a/a/a/ab;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] toBuilder() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/aa;->j()Lcom/sec/a/a/a/ab;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] writeReplace() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-super {v1}, Lcom/google/protobuf/GeneratedMessageLite;->writeReplace()Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] writeTo(Lcom/google/protobuf/CodedOutputStream;) -> V
    // registers=5, ins=2, outs=4, insns_size=41
    0000: const/4 v2, 2
    0001: const/4 v1, 1
    0002: invoke-virtual {v3}, Lcom/sec/a/a/a/aa;->getSerializedSize()I
    0005: iget v0, v3.Lcom/sec/a/a/a/aa;->b:I
    0007: binop/lit8(op=dd) v0, v0, 1 (0x1)
    0009: if-ne v0, v1, 0010
    000b: iget v0, v3.Lcom/sec/a/a/a/aa;->c:I
    000d: invoke-virtual {v4, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeInt32(II)V
    0010: iget v0, v3.Lcom/sec/a/a/a/aa;->b:I
    0012: binop/lit8(op=dd) v0, v0, 2 (0x2)
    0014: if-ne v0, v2, 001b
    0016: iget v0, v3.Lcom/sec/a/a/a/aa;->d:J
    0018: invoke-virtual {v4, v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeInt64(IJ)V
    001b: iget v0, v3.Lcom/sec/a/a/a/aa;->b:I
    001d: binop/lit8(op=dd) v0, v0, 4 (0x4)
    001f: const/4 v1, 4
    0020: if-ne v0, v1, 0028
    0022: const/4 v0, 3
    0023: iget v1, v3.Lcom/sec/a/a/a/aa;->e:I
    0025: invoke-virtual {v4, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeInt32(II)V
    0028: return-void