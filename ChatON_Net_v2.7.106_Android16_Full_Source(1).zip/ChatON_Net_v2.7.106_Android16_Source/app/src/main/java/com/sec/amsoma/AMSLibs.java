=== CLASS Lcom/sec/amsoma/AMSLibs; (Source: AMSLibs.java) ===
  Super: Ljava/lang/Object;
  [Static Field] DEF_VIP_AMSLIB_BK_COLOR: B = 0
  [Static Field] DEF_VIP_AMSLIB_BK_INDEX_IMAGE: B = 2
  [Static Field] DEF_VIP_AMSLIB_BK_PATTERN: B = 1
  [Static Field] DEF_VIP_AMSLIB_BK_RAW_IMAGE: B = 4
  [Static Field] DEF_VIP_AMSLIB_BK_SCREEN_BUF: B = 5
  [Static Field] DEF_VIP_AMS_ANIMATION_TURN_PAGE_EFFECT_BRIGHT_VAR: I = 3
  [Static Field] DEF_VIP_AMS_ANIMATION_TURN_PAGE_EFFECT_SIDE_CURL: I = 1
  [Static Field] DEF_VIP_AMS_ANIMATION_TURN_PAGE_EFFECT_SLIDE_MOVE: I = 2
  [Static Field] DEF_VIP_AMS_ANIMATION_TURN_PAGE_NONE: I = 0
  [Static Field] ENUM_VIP_AMS_AUDIO_BG_INDEX: I = 1
  [Static Field] ENUM_VIP_AMS_AUDIO_BG_MP3: I = 2
  [Static Field] ENUM_VIP_AMS_AUDIO_BG_VOICE: I = 3
  [Static Field] ENUM_VIP_AMS_AUDIO_NONE: I = 0
  [Static Field] ENUM_VIP_AMS_CB_ERROR_DISK_FULL: B = 44
  [Static Field] ENUM_VIP_AMS_CB_ERROR_DRAW: B = 48
  [Static Field] ENUM_VIP_AMS_CB_ERROR_FILE_OPEN: B = 41
  [Static Field] ENUM_VIP_AMS_CB_ERROR_FILE_READ: B = 42
  [Static Field] ENUM_VIP_AMS_CB_ERROR_FILE_WRITE: B = 43
  [Static Field] ENUM_VIP_AMS_CB_ERROR_INVALID_LIB_VERSION: B = 49
  [Static Field] ENUM_VIP_AMS_CB_ERROR_JPEG_DECODING: B = 47
  [Static Field] ENUM_VIP_AMS_CB_ERROR_JPEG_ENCODING: B = 46
  [Static Field] ENUM_VIP_AMS_CB_ERROR_LIMITED_LIB_VERSION: B = 50
  [Static Field] ENUM_VIP_AMS_CB_ERROR_MEMORY_ALLOC: B = 45
  [Static Field] ENUM_VIP_AMS_DIAGRAMSTYLE_CIRCLE: B = 1
  [Static Field] ENUM_VIP_AMS_DIAGRAMSTYLE_CIRCLE_FILL: B = 4
  [Static Field] ENUM_VIP_AMS_DIAGRAMSTYLE_LINE: B = 6
  [Static Field] ENUM_VIP_AMS_DIAGRAMSTYLE_RECT: B = 0
  [Static Field] ENUM_VIP_AMS_DIAGRAMSTYLE_RECT_FILL: B = 3
  [Static Field] ENUM_VIP_AMS_DIAGRAMSTYLE_TRI: B = 2
  [Static Field] ENUM_VIP_AMS_DIAGRAMSTYLE_TRI_FILL: B = 5
  [Static Field] ENUM_VIP_AMS_DIAGRAM_OBJECT_NUM_FULL: B = 13
  [Static Field] ENUM_VIP_AMS_ERROR_CONVERT_IMAGEBUFFER: B = 18
  [Static Field] ENUM_VIP_AMS_ERROR_DATA_FULL: B = 9
  [Static Field] ENUM_VIP_AMS_ERROR_DECODE_BUFFER: B = 19
  [Static Field] ENUM_VIP_AMS_ERROR_DECODE_DATA: B = 21
  [Static Field] ENUM_VIP_AMS_ERROR_DECODE_EXIF: B = 22
  [Static Field] ENUM_VIP_AMS_ERROR_DECODE_HEADER: B = 20
  [Static Field] ENUM_VIP_AMS_ERROR_DECODE_IMAGE: B = 23
  [Static Field] ENUM_VIP_AMS_ERROR_DRAW: B = 34
  [Static Field] ENUM_VIP_AMS_ERROR_ENCODE_DATA: B = 36
  [Static Field] ENUM_VIP_AMS_ERROR_ENCODE_IMAGE: B = 16
  [Static Field] ENUM_VIP_AMS_ERROR_INVALID_APP_VERSION: B = 2
  [Static Field] ENUM_VIP_AMS_ERROR_INVALID_CLIP: B = 38
  [Static Field] ENUM_VIP_AMS_ERROR_INVALID_DRAWING_DATA: B = 29
  [Static Field] ENUM_VIP_AMS_ERROR_INVALID_FILEFORMAT: B = 3
  [Static Field] ENUM_VIP_AMS_ERROR_INVALID_FILEINFO: B = 26
  [Static Field] ENUM_VIP_AMS_ERROR_INVALID_HEADER: B = 4
  [Static Field] ENUM_VIP_AMS_ERROR_INVALID_IMAGE_SIZE: B = 1
  [Static Field] ENUM_VIP_AMS_ERROR_INVALID_INSTANCE: B = 6
  [Static Field] ENUM_VIP_AMS_ERROR_INVALID_OBJECT_DATA: B = 31
  [Static Field] ENUM_VIP_AMS_ERROR_INVALID_OBJECT_STYLE: B = 32
  [Static Field] ENUM_VIP_AMS_ERROR_INVALID_PAGE: B = 7
  [Static Field] ENUM_VIP_AMS_ERROR_LOAD_JPEGTORAW: B = 17
  [Static Field] ENUM_VIP_AMS_ERROR_NO: B = 0
  [Static Field] ENUM_VIP_AMS_ERROR_NOMORE_PLAY_OBJECT: B = 39
  [Static Field] ENUM_VIP_AMS_ERROR_NOT_READY: B = 5
  [Static Field] ENUM_VIP_AMS_ERROR_OBJECT_ALLOC: B = 30
  [Static Field] ENUM_VIP_AMS_ERROR_OBJECT_IMAGE_NUM_FULL: B = 51
  [Static Field] ENUM_VIP_AMS_ERROR_OBJECT_PROPERTY_SETTING: B = 27
  [Static Field] ENUM_VIP_AMS_ERROR_OBJECT_START_SETTING: B = 28
  [Static Field] ENUM_VIP_AMS_ERROR_POINT_FULL: B = 8
  [Static Field] ENUM_VIP_AMS_ERROR_SAVE_FLASH: B = 24
  [Static Field] ENUM_VIP_AMS_ERROR_STRING_LENGTH: B = 33
  [Static Field] ENUM_VIP_AMS_ERROR_TURN_PAGE: B = 40
  [Static Field] ENUM_VIP_AMS_ERROR_UNDEFINED: B = 25
  [Static Field] ENUM_VIP_AMS_ERROR_UNDO_REDO: B = 35
  [Static Field] ENUM_VIP_AMS_ERROR_USERIMAGE_ID_FULL: B = 15
  [Static Field] ENUM_VIP_AMS_ERROR_USERIMAGE_TRANSMIT_FULL: B = 14
  [Static Field] ENUM_VIP_AMS_ERROR_ZOOM_INVALID_NEXTREGION: B = 37
  [Static Field] ENUM_VIP_AMS_PENSTYLE_CRAYON: B = 1
  [Static Field] ENUM_VIP_AMS_PENSTYLE_DOTLINE: B = 3
  [Static Field] ENUM_VIP_AMS_PENSTYLE_PENCIL: B = 0
  [Static Field] ENUM_VIP_AMS_PENSTYLE_SHINY: B = 2
  [Static Field] ENUM_VIP_AMS_PENSTYLE_TRANSPARENT: B = 4
  [Static Field] ENUM_VIP_AMS_PEN_OBJECT_NUM_FULL: B = 10
  [Static Field] ENUM_VIP_AMS_SAVE_THUMBNAIL_IMAGE_SIZE: I = 400
  [Static Field] ENUM_VIP_AMS_SAVE_USER_STAMPSIZE: B = 120
  [Static Field] ENUM_VIP_AMS_STAMPSIZE_NORMAL: B = 2
  [Static Field] ENUM_VIP_AMS_STAMPSIZE_SMALL: B = 1
  [Static Field] ENUM_VIP_AMS_STAMPSIZE_UNDEFINED: B = 0
  [Static Field] ENUM_VIP_AMS_STAMPSTYLE_ANIMATION: B = 1
  [Static Field] ENUM_VIP_AMS_STAMPSTYLE_BASIC: B = 0
  [Static Field] ENUM_VIP_AMS_STAMPSTYLE_USER: B = 2
  [Static Field] ENUM_VIP_AMS_STAMPSTYLE_USER_CIRCLE: B = 3
  [Static Field] ENUM_VIP_AMS_STAMPSTYLE_USER_HEART: B = 4
  [Static Field] ENUM_VIP_AMS_STAMPSTYLE_USER_RECT: B = 6
  [Static Field] ENUM_VIP_AMS_STAMPSTYLE_USER_STAR: B = 5
  [Static Field] ENUM_VIP_AMS_STAMP_OBJECT_NUM_FULL: B = 12
  [Static Field] ENUM_VIP_AMS_TEXTSIZE_LARGE: B = 2
  [Static Field] ENUM_VIP_AMS_TEXTSIZE_NORMAL: B = 1
  [Static Field] ENUM_VIP_AMS_TEXTSIZE_SMALL: B = 0
  [Static Field] ENUM_VIP_AMS_TEXT_OBJECT_NUM_FULL: B = 11
  [Static Field] ENUM_VIP_AMS_TYPE_DIAGRAM: B = 4
  [Static Field] ENUM_VIP_AMS_TYPE_PEN: B = 1
  [Static Field] ENUM_VIP_AMS_TYPE_STAMP: B = 3
  [Static Field] ENUM_VIP_AMS_TYPE_TEXT: B = 2
  [Static Field] ENUM_VIP_AMS_TYPE_UNDEFINED: B = 0
  [Static Field] ENUM_VIP_AMS_UNDO_REDO_DRAW_ALL: I = 2
  [Static Field] ENUM_VIP_AMS_UNDO_REDO_ERROR: I = 0
  [Static Field] ENUM_VIP_AMS_UNDO_REDO_UPDATE: I = 1
  [Static Field] ENUM_VIP_AMS_WQVGA_DRAW_BASIC_STAMPSIZE: B = 55
  [Static Field] ENUM_VIP_AMS_WQVGA_DRAW_USER_STAMPSIZE_LARGE: B = 60
  [Static Field] ENUM_VIP_AMS_WQVGA_DRAW_USER_STAMPSIZE_SMALL: B = 30
  [Static Field] ENUM_VIP_AMS_WQVGA_SAVE_USER_STAMPIMAGE_SIZE: I = 10240
  [Static Field] ENUM_VIP_AMS_WVGA_DRAW_BASIC_STAMPSIZE: B = 110
  [Static Field] ENUM_VIP_AMS_WVGA_DRAW_USER_STAMPSIZE_LARGE: B = 120
  [Static Field] ENUM_VIP_AMS_WVGA_DRAW_USER_STAMPSIZE_SMALL: B = 60
  [Static Field] g_nCurObjectImageBPP: I
  [Static Field] g_nCurObjectImageHeight: I
  [Static Field] g_nCurObjectImageWidth: I
  [Static Field] g_nCurrentBackgroundBPP: I
  [Static Field] g_nCurrentBackgroundHeight: I
  [Static Field] g_nCurrentBackgroundWidth: I
  [Static Field] g_nNumTotalObject: I
  [Static Field] g_nNumTotalPenPoint: I
  [Static Field] g_nTextHeight: I
  [Static Field] g_nTextWidth: I
  [Instance Field] UIData: Lcom/sec/amsoma/structure/AMS_UI_DATA;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=2, insns_size=13
    0000: const-string v0, 'AMSWiFiLibs-1.0.5'
    0002: invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    0005: return-void
    0006: move-exception v0
    0007: sget v1, Ljava/lang/System;->err:Ljava/io/PrintStream;
    0009: invoke-virtual {v1, v0}, Ljava/io/PrintStream;->println(Ljava/lang/Object;)V
    000c: goto 0005

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=11
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Lcom/sec/amsoma/structure/AMS_UI_DATA;
    0005: invoke-direct {v0}, Lcom/sec/amsoma/structure/AMS_UI_DATA;-><init>()V
    0008: iput v0, v1.Lcom/sec/amsoma/AMSLibs;->UIData:Lcom/sec/amsoma/structure/AMS_UI_DATA;
    000a: return-void

  [Direct Method] makeBuffer([I, I, I) -> Ljava/nio/IntBuffer;
    // registers=4, ins=3, outs=2, insns_size=13
    0000: binop(op=92) v0, v2, v3
    0002: invoke-static {v0}, Ljava/nio/IntBuffer;->allocate(I)Ljava/nio/IntBuffer;
    0005: move-result-object v0
    0006: invoke-virtual {v0, v1}, Ljava/nio/IntBuffer;->put([I)Ljava/nio/IntBuffer;
    0009: invoke-virtual {v0}, Ljava/nio/IntBuffer;->rewind()Ljava/nio/Buffer;
    000c: return-object v0

  [Virtual Method] Callback_deleteTempFile([B) -> V
    // registers=4, ins=2, outs=2, insns_size=22
    0000: new-instance v0, Ljava/lang/String;
    0002: invoke-direct {v0, v3}, Ljava/lang/String;-><init>([B)V
    0005: new-instance v1, Ljava/io/File;
    0007: invoke-direct {v1, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    000a: invoke-virtual {v1}, Ljava/io/File;->isFile()Z
    000d: move-result v0
    000e: if-eqz v0, 0013
    0010: invoke-virtual {v1}, Ljava/io/File;->delete()Z
    0013: if-eqz v1, 0015
    0015: return-void

  [Virtual Method] Callback_loadImageFileToRawImage([B) -> I
    // registers=3, ins=2, outs=2, insns_size=10
    0000: new-instance v0, Ljava/lang/String;
    0002: invoke-direct {v0, v2}, Ljava/lang/String;-><init>([B)V
    0005: invoke-virtual {v1, v0}, Lcom/sec/amsoma/AMSLibs;->loadImageFileToRawImage(Ljava/lang/String;)I
    0008: move-result v0
    0009: return v0

  [Virtual Method] Callback_loadImageStreamToRawImage([B, [B, I) -> I
    // registers=7, ins=4, outs=4, insns_size=76
    0000: invoke-virtual {v3, v4}, Lcom/sec/amsoma/AMSLibs;->Callback_deleteTempFile([B)V
    0003: const/4 v1, 0
    0004: new-instance v2, Ljava/io/File;
    0006: new-instance v0, Ljava/lang/String;
    0008: invoke-direct {v0, v4}, Ljava/lang/String;-><init>([B)V
    000b: invoke-direct {v2, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    000e: new-instance v0, Ljava/io/FileOutputStream;
    0010: invoke-direct {v0, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    0013: if-nez v0, 0018
    0015: const/16 v0, 43 (0x2b)
    0017: return v0
    0018: const/4 v1, 0
    0019: invoke-virtual {v0, v5, v1, v6}, Ljava/io/FileOutputStream;->write([BII)V
    001c: if-eqz v0, 0021
    001e: invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    0021: new-instance v0, Ljava/lang/String;
    0023: invoke-direct {v0, v4}, Ljava/lang/String;-><init>([B)V
    0026: invoke-virtual {v3, v0}, Lcom/sec/amsoma/AMSLibs;->loadImageFileToRawImage(Ljava/lang/String;)I
    0029: move-result v0
    002a: goto 0017
    002b: move-exception v0
    002c: move(op=07) v0, v1
    002d: const-string v1, 'IOException'
    002f: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0032: move-result-object v2
    0033: invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0036: move-result-object v2
    0037: invoke-static {v1, v2}, Lcom/sec/chaton/util/p;->a(Ljava/lang/String;Ljava/lang/String;)V
    003a: goto 001c
    003b: move-exception v0
    003c: const-string v0, 'IOException'
    003e: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0041: move-result-object v1
    0042: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0045: move-result-object v1
    0046: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->a(Ljava/lang/String;Ljava/lang/String;)V
    0049: goto 0021
    004a: move-exception v1
    004b: goto 002d

  [Virtual Method] Callback_saveRawImageToImageFile([B, [I, I, I, I, I, I) -> I
    // registers=16, ins=8, outs=8, insns_size=126
    0000: if-nez v10, 0005
    0002: const/16 v0, 41 (0x29)
    0004: return v0
    0005: invoke-virtual {v8, v9}, Lcom/sec/amsoma/AMSLibs;->Callback_deleteTempFile([B)V
    0008: sget v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;
    000a: invoke-static {v11, v12, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;
    000d: move-result-object v0
    000e: const/4 v2, 0
    000f: const/4 v4, 0
    0010: const/4 v5, 0
    0011: move(op=07) v1, v10
    0012: move(op=01) v3, v11
    0013: move(op=01) v6, v11
    0014: move(op=01) v7, v12
    0015: invoke-virtual/range {v0..v7}, Landroid/graphics/Bitmap;->setPixels([IIIIIII)V
    0018: new-instance v3, Ljava/io/File;
    001a: new-instance v1, Ljava/lang/String;
    001c: invoke-direct {v1, v9}, Ljava/lang/String;-><init>([B)V
    001f: invoke-direct {v3, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    0022: const/4 v2, 0
    0023: new-instance v1, Ljava/io/FileOutputStream;
    0025: invoke-direct {v1, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    0028: if-nez v1, 0036
    002a: const/16 v0, 41 (0x29)
    002c: if-eqz v1, 0004
    002e: invoke-virtual {v1}, Ljava/io/FileOutputStream;->close()V
    0031: goto 0004
    0032: move-exception v0
    0033: const/16 v0, 41 (0x29)
    0035: goto 0004
    0036: if-nez v15, 004a
    0038: sget v2, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;
    003a: invoke-virtual {v0, v2, v14, v1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    003d: invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V
    0040: invoke-static {}, Ljava/lang/System;->gc()V
    0043: if-eqz v1, 0048
    0045: invoke-virtual {v1}, Ljava/io/FileOutputStream;->close()V
    0048: const/4 v0, 0
    0049: goto 0004
    004a: const/4 v2, 1
    004b: if-ne v15, v2, 0063
    004d: sget v2, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;
    004f: invoke-virtual {v0, v2, v14, v1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    0052: goto 003d
    0053: move-exception v0
    0054: invoke-virtual {v0}, Ljava/io/FileNotFoundException;->printStackTrace()V
    0057: const/16 v0, 41 (0x29)
    0059: if-eqz v1, 0004
    005b: invoke-virtual {v1}, Ljava/io/FileOutputStream;->close()V
    005e: goto 0004
    005f: move-exception v0
    0060: const/16 v0, 41 (0x29)
    0062: goto 0004
    0063: sget v2, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;
    0065: invoke-virtual {v0, v2, v14, v1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z
    0068: goto 003d
    0069: move-exception v0
    006a: if-eqz v1, 006f
    006c: invoke-virtual {v1}, Ljava/io/FileOutputStream;->close()V
    006f: throw v0
    0070: move-exception v0
    0071: const/16 v0, 41 (0x29)
    0073: goto 0004
    0074: move-exception v0
    0075: const/16 v0, 41 (0x29)
    0077: goto 0004
    0078: move-exception v0
    0079: move(op=07) v1, v2
    007a: goto 006a
    007b: move-exception v0
    007c: move(op=07) v1, v2
    007d: goto 0054

  [Virtual Method] Callback_saveRawImageToJPEGFileWithLimitSize([B, [I, I, I, I, I, I) -> I
    // registers=18, ins=8, outs=8, insns_size=104
    0000: const/4 v1, 0
    0001: invoke-virtual {v10, v11}, Lcom/sec/amsoma/AMSLibs;->Callback_deleteTempFile([B)V
    0004: move(op=01) v9, v1
    0005: move/from16 v7, v16
    0007: const/4 v8, 0
    0008: move(op=07) v1, v10
    0009: move(op=07) v2, v11
    000a: move(op=07) v3, v12
    000b: move(op=01) v4, v13
    000c: move(op=01) v5, v14
    000d: move(op=01) v6, v15
    000e: invoke-virtual/range {v1..v8}, Lcom/sec/amsoma/AMSLibs;->Callback_saveRawImageToImageFile([B[IIIIII)I
    0011: move-result v1
    0012: if-eqz v1, 0015
    0014: return v1
    0015: new-instance v1, Ljava/io/File;
    0017: new-instance v2, Ljava/lang/String;
    0019: invoke-direct {v2, v11}, Ljava/lang/String;-><init>([B)V
    001c: invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V
    001f: new-instance v2, Ljava/io/FileInputStream;
    0021: invoke-direct {v2, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    0024: if-eqz v2, 0029
    0026: invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    0029: if-eqz v1, 0066
    002b: invoke-virtual {v1}, Ljava/io/File;->length()J
    002e: move-result-wide v1
    002f: unop(op=84) v1, v1
    0030: move/from16 v0, v17
    0032: if-ge v1, v0, 003d
    0034: const/4 v2, 0
    0035: const/16 v3, 43 (0x2b)
    0037: if-eq v2, v3, 003b
    0039: if-nez v1, 0062
    003b: move(op=01) v1, v2
    003c: goto 0014
    003d: invoke-virtual {v10, v11}, Lcom/sec/amsoma/AMSLibs;->Callback_deleteTempFile([B)V
    0040: const/16 v2, 30 (0x1e)
    0042: if-gt v7, v2, 004c
    0044: binop/lit8(op=d8) v7, v7, -5 (-0x5)
    0046: const/4 v2, 5
    0047: if-ge v7, v2, 004f
    0049: const/16 v2, 43 (0x2b)
    004b: goto 0035
    004c: binop/lit8(op=d8) v7, v7, -10 (-0xa)
    004e: goto 0046
    004f: move(op=01) v9, v1
    0050: goto 0007
    0051: move-exception v1
    0052: move(op=01) v1, v9
    0053: const-string v2, 'IOException'
    0055: invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0058: move-result-object v3
    0059: invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    005c: move-result-object v3
    005d: invoke-static {v2, v3}, Lcom/sec/chaton/util/p;->a(Ljava/lang/String;Ljava/lang/String;)V
    0060: move(op=01) v9, v1
    0061: goto 0007
    0062: move(op=01) v1, v2
    0063: goto 0014
    0064: move-exception v2
    0065: goto 0053
    0066: move(op=01) v1, v9
    0067: goto 0030

  [Virtual Method] Callback_writeData([B, I, [B) -> Z
    // registers=11, ins=4, outs=3, insns_size=95
    0000: const/4 v0, 0
    0001: if-eqz v8, 0005
    0003: if-nez v10, 0006
    0005: return v0
    0006: const/4 v3, 0
    0007: new-instance v1, Ljava/lang/String;
    0009: invoke-direct {v1, v8}, Ljava/lang/String;-><init>([B)V
    000c: new-instance v2, Ljava/io/RandomAccessFile;
    000e: const-string v4, 'rw'
    0010: invoke-direct {v2, v1, v4}, Ljava/io/RandomAccessFile;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    0013: if-nez v2, 0020
    0015: if-eqz v2, 0005
    0017: invoke-virtual {v2}, Ljava/io/RandomAccessFile;->close()V
    001a: goto 0005
    001b: move-exception v1
    001c: invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V
    001f: goto 0005
    0020: if-ltz v9, 0032
    0022: unop(op=81) v3, v9
    0023: invoke-virtual {v2}, Ljava/io/RandomAccessFile;->length()J
    0026: move-result-wide v5
    0027: cmp(op=31) v1, v3, v5
    0029: if-gez v1, 0032
    002b: unop(op=81) v3, v9
    002c: invoke-virtual {v2, v3, v4}, Ljava/io/RandomAccessFile;->seek(J)V
    002f: invoke-virtual {v2, v10}, Ljava/io/RandomAccessFile;->write([B)V
    0032: if-eqz v2, 0037
    0034: invoke-virtual {v2}, Ljava/io/RandomAccessFile;->close()V
    0037: const/4 v0, 1
    0038: goto 0005
    0039: move-exception v0
    003a: invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V
    003d: goto 0037
    003e: move-exception v1
    003f: move(op=07) v2, v3
    0040: invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V
    0043: if-eqz v2, 0005
    0045: invoke-virtual {v2}, Ljava/io/RandomAccessFile;->close()V
    0048: goto 0005
    0049: move-exception v1
    004a: invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V
    004d: goto 0005
    004e: move-exception v0
    004f: if-eqz v3, 0054
    0051: invoke-virtual {v3}, Ljava/io/RandomAccessFile;->close()V
    0054: throw v0
    0055: move-exception v1
    0056: invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V
    0059: goto 0054
    005a: move-exception v0
    005b: move(op=07) v3, v2
    005c: goto 004f
    005d: move-exception v1
    005e: goto 0040

  [Virtual Method] Convert565(I, I, I) -> I
    // registers=6, ins=4, outs=0, insns_size=25
    0000: binop/lit8(op=da) v0, v3, 31 (0x1f)
    0002: binop/lit8(op=d8) v0, v0, 127 (0x7f)
    0004: binop/lit16(op=d3) v0, v0, 255 (0xff)
    0006: binop/lit8(op=e0) v0, v0, 11 (0xb)
    0008: binop/lit8(op=da) v1, v4, 63 (0x3f)
    000a: binop/lit8(op=d8) v1, v1, 127 (0x7f)
    000c: binop/lit16(op=d3) v1, v1, 255 (0xff)
    000e: binop/lit8(op=e0) v1, v1, 5 (0x5)
    0010: binop/2addr(op=b6) v0, v1
    0011: binop/lit8(op=da) v1, v5, 31 (0x1f)
    0013: binop/lit8(op=d8) v1, v1, 127 (0x7f)
    0015: binop/lit16(op=d3) v1, v1, 255 (0xff)
    0017: binop/2addr(op=b6) v0, v1
    0018: return v0

  [Virtual Method] GetAnimationObjectInfo(I, I) -> V
    // registers=3, ins=3, outs=0, insns_size=5
    0000: sput v1, Lcom/sec/amsoma/AMSLibs;->g_nNumTotalPenPoint:I
    0002: sput v2, Lcom/sec/amsoma/AMSLibs;->g_nNumTotalObject:I
    0004: return-void

  [Virtual Method] GetBValue(I) -> I
    // registers=3, ins=2, outs=0, insns_size=5
    0000: binop/lit8(op=e1) v0, v2, 0 (0x0)
    0002: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0004: return v0

  [Virtual Method] GetCurObjectImageBufInfo(I, I, I) -> V
    // registers=4, ins=4, outs=0, insns_size=7
    0000: sput v1, Lcom/sec/amsoma/AMSLibs;->g_nCurObjectImageWidth:I
    0002: sput v2, Lcom/sec/amsoma/AMSLibs;->g_nCurObjectImageHeight:I
    0004: sput v3, Lcom/sec/amsoma/AMSLibs;->g_nCurObjectImageBPP:I
    0006: return-void

  [Virtual Method] GetCurrentBackgroundBufInfo(I, I, I) -> V
    // registers=4, ins=4, outs=0, insns_size=7
    0000: sput v1, Lcom/sec/amsoma/AMSLibs;->g_nCurrentBackgroundWidth:I
    0002: sput v2, Lcom/sec/amsoma/AMSLibs;->g_nCurrentBackgroundHeight:I
    0004: sput v3, Lcom/sec/amsoma/AMSLibs;->g_nCurrentBackgroundBPP:I
    0006: return-void

  [Virtual Method] GetGValue(I) -> I
    // registers=3, ins=2, outs=0, insns_size=5
    0000: binop/lit8(op=e1) v0, v2, 8 (0x8)
    0002: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0004: return v0

  [Virtual Method] GetRValue(I) -> I
    // registers=3, ins=2, outs=0, insns_size=5
    0000: binop/lit8(op=e1) v0, v2, 16 (0x10)
    0002: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0004: return v0

  [Virtual Method] NewEncoding(I, Lcom/sec/amsoma/structure/AMS_UI_DATA;) -> Z
    // registers=5, ins=3, outs=4, insns_size=63
    0000: iput v4, v2.Lcom/sec/amsoma/AMSLibs;->UIData:Lcom/sec/amsoma/structure/AMS_UI_DATA;
    0002: new-instance v0, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;
    0004: invoke-direct {v0}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;-><init>()V
    0007: iget v1, v2.Lcom/sec/amsoma/AMSLibs;->UIData:Lcom/sec/amsoma/structure/AMS_UI_DATA;
    0009: iget v1, v1.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_cObjectSize:B
    000b: invoke-virtual {v0, v1}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->setM_cSize(B)V
    000e: iget v1, v2.Lcom/sec/amsoma/AMSLibs;->UIData:Lcom/sec/amsoma/structure/AMS_UI_DATA;
    0010: iget v1, v1.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_cObjectStyle:B
    0012: invoke-virtual {v0, v1}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->setM_cStyle(I)V
    0015: iget v1, v2.Lcom/sec/amsoma/AMSLibs;->UIData:Lcom/sec/amsoma/structure/AMS_UI_DATA;
    0017: iget v1, v1.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rgbPen:I
    0019: invoke-virtual {v2, v1}, Lcom/sec/amsoma/AMSLibs;->GetRValue(I)I
    001c: move-result v1
    001d: invoke-virtual {v0, v1}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->setM_nColorR(I)V
    0020: iget v1, v2.Lcom/sec/amsoma/AMSLibs;->UIData:Lcom/sec/amsoma/structure/AMS_UI_DATA;
    0022: iget v1, v1.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rgbPen:I
    0024: invoke-virtual {v2, v1}, Lcom/sec/amsoma/AMSLibs;->GetGValue(I)I
    0027: move-result v1
    0028: invoke-virtual {v0, v1}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->setM_nColorG(I)V
    002b: iget v1, v2.Lcom/sec/amsoma/AMSLibs;->UIData:Lcom/sec/amsoma/structure/AMS_UI_DATA;
    002d: iget v1, v1.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rgbPen:I
    002f: invoke-virtual {v2, v1}, Lcom/sec/amsoma/AMSLibs;->GetBValue(I)I
    0032: move-result v1
    0033: invoke-virtual {v0, v1}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->setM_nColorB(I)V
    0036: iget v1, v2.Lcom/sec/amsoma/AMSLibs;->UIData:Lcom/sec/amsoma/structure/AMS_UI_DATA;
    0038: iget v1, v1.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rectRegion:Lcom/sec/amsoma/structure/AMS_RECT;
    003a: invoke-virtual {v2, v3, v1, v0}, Lcom/sec/amsoma/AMSLibs;->VipAMS_TotalNewEncoding(ILcom/sec/amsoma/structure/AMS_RECT;Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;)Z
    003d: move-result v0
    003e: return v0

  [Virtual Method] VipAMS_AddFrame(I) -> Z

  [Virtual Method] VipAMS_AddObjectImage(I, B, [I, I, I, I, S) -> Z

  [Virtual Method] VipAMS_AnimationEnd(I) -> Z

  [Virtual Method] VipAMS_AnimationNext(I) -> Z

  [Virtual Method] VipAMS_AnimationStart(I) -> Z

  [Virtual Method] VipAMS_Blur([I, I, I, I) -> Z

  [Virtual Method] VipAMS_Bright([I, I, I) -> Z

  [Virtual Method] VipAMS_CancelSelect(I) -> Z

  [Virtual Method] VipAMS_ChangeSelectDiagram(I, Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;, Lcom/sec/amsoma/structure/AMS_RECT;, B) -> Z

  [Virtual Method] VipAMS_ChangeSelectStamp(I, Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;, Lcom/sec/amsoma/structure/AMS_RECT;, I, I) -> Z

  [Virtual Method] VipAMS_ChangeSelectText(I, Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;, Lcom/sec/amsoma/structure/AMS_RECT;, B, [C, S, [C, S) -> Z

  [Virtual Method] VipAMS_ClearEncoding(I) -> Z

  [Virtual Method] VipAMS_Close(I) -> V

  [Virtual Method] VipAMS_Dark([I, I, I) -> Z

  [Virtual Method] VipAMS_DeleteSelectObject(I, Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;) -> Z

  [Virtual Method] VipAMS_EncodeNewDiagram(I, Lcom/sec/amsoma/structure/AMS_RECT;, B) -> Z

  [Virtual Method] VipAMS_EncodeNewMultiImage(I, Lcom/sec/amsoma/structure/AMS_RECT;, B, B) -> I

  [Virtual Method] VipAMS_EncodeNewStamp(I, Lcom/sec/amsoma/structure/AMS_RECT;, B, B, B, [I, I, I, I) -> Z

  [Virtual Method] VipAMS_EncodeNewText(I, Lcom/sec/amsoma/structure/AMS_RECT;, B, [C, S, [C, S) -> Z

  [Virtual Method] VipAMS_EncodePointData(I, S, S, S) -> Z

  [Virtual Method] VipAMS_EncodeStrokeEnd(I) -> Z

  [Virtual Method] VipAMS_EncodeStrokeStart(I) -> Z

  [Virtual Method] VipAMS_GetAnimationInfo(I) -> Z

  [Virtual Method] VipAMS_GetBGAudioFile(I) -> [B

  [Virtual Method] VipAMS_GetBGAudioStyle(I) -> I

  [Virtual Method] VipAMS_GetBGMIndex(I) -> I

  [Virtual Method] VipAMS_GetBackgroundColorA(I) -> I

  [Virtual Method] VipAMS_GetBackgroundColorB(I) -> I

  [Virtual Method] VipAMS_GetBackgroundColorG(I) -> I

  [Virtual Method] VipAMS_GetBackgroundColorR(I) -> I

  [Virtual Method] VipAMS_GetBackgroundIndex(I) -> B

  [Virtual Method] VipAMS_GetBackgroundStyle(I) -> I

  [Virtual Method] VipAMS_GetCodingHeight(I) -> I

  [Virtual Method] VipAMS_GetCodingWidth(I) -> I

  [Virtual Method] VipAMS_GetCurObjectColorA(I) -> I

  [Virtual Method] VipAMS_GetCurObjectColorB(I) -> I

  [Virtual Method] VipAMS_GetCurObjectColorG(I) -> I

  [Virtual Method] VipAMS_GetCurObjectColorR(I) -> I

  [Virtual Method] VipAMS_GetCurObjectSize(I) -> B

  [Virtual Method] VipAMS_GetCurObjectStyle(I) -> B

  [Virtual Method] VipAMS_GetCurObjectType(I) -> B

  [Virtual Method] VipAMS_GetCurrentBackgroundBuf(I) -> [I

  [Virtual Method] VipAMS_GetCurrentFrame(I) -> I

  [Virtual Method] VipAMS_GetErrorCode(I) -> I

  [Virtual Method] VipAMS_GetFileStreamInfo([B, I) -> V

  [Virtual Method] VipAMS_GetFreeSpace(I) -> I

  [Virtual Method] VipAMS_GetImageInfo([I, I, I, I) -> Z

  [Virtual Method] VipAMS_GetLastFrame(I) -> I

  [Virtual Method] VipAMS_GetLibVersion(I) -> Ljava/lang/String;

  [Virtual Method] VipAMS_GetNextDrawingData(I, I, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;) -> I

  [Virtual Method] VipAMS_GetNextUpdateObject(I, I, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;) -> I

  [Virtual Method] VipAMS_GetNextUpdateRegion(I, I, Lcom/sec/amsoma/structure/AMS_RECT;) -> I

  [Virtual Method] VipAMS_GetObjectImageBuf(I, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;) -> [I
    // registers=4, ins=3, outs=4, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v3, v0}, Lcom/sec/amsoma/AMSLibs;->VipAMS_GetObjectImageBuf(ILcom/sec/amsoma/structure/AMS_OBJECT_DATA;B)[I
    0004: move-result-object v0
    0005: return-object v0

  [Virtual Method] VipAMS_GetObjectImageBuf(I, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;, B) -> [I

  [Virtual Method] VipAMS_GetObjectImageDuration(I, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;, B) -> I

  [Virtual Method] VipAMS_GetObjectImageNum(I, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;) -> I

  [Virtual Method] VipAMS_GetObjectIteration(I, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;) -> I

  [Virtual Method] VipAMS_GetSelectObjectData(I, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;) -> V

  [Virtual Method] VipAMS_GetTotalObjectNum(I) -> I

  [Virtual Method] VipAMS_GetTurnPageOption(I) -> B

  [Virtual Method] VipAMS_GetUIImageBuffer([I, I, I) -> Z

  [Virtual Method] VipAMS_Gray([I, I, I) -> Z

  [Virtual Method] VipAMS_Init() -> V

  [Virtual Method] VipAMS_IsAMSJPEGFile(Lcom/sec/amsoma/structure/AMS_UI_DATA;, [Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;) -> I

  [Virtual Method] VipAMS_IsAnimationEnable(I) -> Z

  [Virtual Method] VipAMS_IsEditEnable(I) -> Z

  [Virtual Method] VipAMS_IsEnableRedo(I) -> Z

  [Virtual Method] VipAMS_IsEnableUndo(I) -> Z

  [Virtual Method] VipAMS_Negative([I, I, I) -> Z

  [Virtual Method] VipAMS_Open(Lcom/sec/amsoma/structure/AMS_OPTION;) -> I

  [Virtual Method] VipAMS_PencilSketch([I, I, I) -> Z

  [Virtual Method] VipAMS_Redo(I) -> I

  [Virtual Method] VipAMS_RemoveFrame(I, B) -> Z

  [Virtual Method] VipAMS_SelectObject(I, I, I, Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;, I) -> Z

  [Virtual Method] VipAMS_Sepia([I, I, I) -> Z

  [Virtual Method] VipAMS_SetAMSImageBuf(I, [I, I, I) -> I

  [Virtual Method] VipAMS_SetBGAudioFile(I, [B, I) -> Z

  [Virtual Method] VipAMS_SetBGAudioStyle(I, I) -> Z

  [Virtual Method] VipAMS_SetBGMIndex(I, I) -> Z

  [Virtual Method] VipAMS_SetBackgroundColor(I, I, I, I) -> Z

  [Virtual Method] VipAMS_SetBackgroundIndex(I, B) -> Z

  [Virtual Method] VipAMS_SetBackgroundRawImage(I, [I, I, I, I) -> Z

  [Virtual Method] VipAMS_SetCurObjectColor(I, I, I, I) -> Z

  [Virtual Method] VipAMS_SetCurObjectSize(I, B) -> Z

  [Virtual Method] VipAMS_SetCurObjectStyle(I, B) -> Z

  [Virtual Method] VipAMS_SetCurObjectType(I, B) -> Z

  [Virtual Method] VipAMS_SetCurrentFrame(I, B) -> Z

  [Virtual Method] VipAMS_SetEditEnable(I, Z) -> Z

  [Virtual Method] VipAMS_SetNextFrame(I) -> Z

  [Virtual Method] VipAMS_SetPrevFrame(I) -> Z

  [Virtual Method] VipAMS_SetTempFilePath([B, I) -> Z

  [Virtual Method] VipAMS_SetTurnPageOption(I, B) -> Z

  [Virtual Method] VipAMS_TotalEndEncoding(I, [Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;) -> I

  [Virtual Method] VipAMS_TotalLoadEncodingFile(I, [Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;, Lcom/sec/amsoma/structure/AMS_RECT;) -> I

  [Virtual Method] VipAMS_TotalNewEncoding(I, Lcom/sec/amsoma/structure/AMS_RECT;, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;) -> Z

  [Virtual Method] VipAMS_TotalSaveEncoding(I, [Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;) -> I

  [Virtual Method] VipAMS_Undo(I) -> I

  [Virtual Method] getUIData() -> Lcom/sec/amsoma/structure/AMS_UI_DATA;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/AMSLibs;->UIData:Lcom/sec/amsoma/structure/AMS_UI_DATA;
    0002: return-object v0

  [Virtual Method] loadImageFileToRawImage(Ljava/lang/String;) -> I
    // registers=12, ins=2, outs=8, insns_size=59
    0000: const/16 v8, 41 (0x29)
    0002: const/4 v2, 0
    0003: new-instance v0, Landroid/graphics/BitmapFactory$Options;
    0005: invoke-direct {v0}, Landroid/graphics/BitmapFactory$Options;-><init>()V
    0008: iput v2, v0.Landroid/graphics/BitmapFactory$Options;->inDither:Z
    000a: invoke-static {v11, v0}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    000d: move-result-object v0
    000e: invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I
    0011: move-result v3
    0012: invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I
    0015: move-result v7
    0016: const/16 v9, 32 (0x20)
    0018: binop(op=92) v1, v3, v7
    001a: new-array v1, v1, [I
    001c: move(op=01) v4, v2
    001d: move(op=01) v5, v2
    001e: move(op=01) v6, v3
    001f: invoke-virtual/range {v0..v7}, Landroid/graphics/Bitmap;->getPixels([IIIIIII)V
    0022: invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V
    0025: if-nez v1, 0030
    0027: move(op=01) v2, v8
    0028: return v2
    0029: move-exception v1
    002a: invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V
    002d: const/16 v2, 45 (0x2d)
    002f: goto 0028
    0030: invoke-virtual {v10, v1, v3, v7, v9}, Lcom/sec/amsoma/AMSLibs;->VipAMS_GetImageInfo([IIII)Z
    0033: move-result v0
    0034: invoke-static {}, Ljava/lang/System;->gc()V
    0037: if-nez v0, 0028
    0039: move(op=01) v2, v8
    003a: goto 0028

  [Virtual Method] setUIData(Lcom/sec/amsoma/structure/AMS_UI_DATA;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/AMSLibs;->UIData:Lcom/sec/amsoma/structure/AMS_UI_DATA;
    0002: return-void