=== CLASS Lcom/sec/a/a/a/b; (Source: MsgFrontend.java) ===
  Super: Ljava/lang/Object;