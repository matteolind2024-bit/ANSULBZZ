=== CLASS Lcom/sec/chaton/bb; (Source: TabActivity.java) ===
  Super: Landroid/content/BroadcastReceiver;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/bb;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Landroid/content/BroadcastReceiver;-><init>()V
    0005: return-void

  [Virtual Method] onReceive(Landroid/content/Context;, Landroid/content/Intent;) -> V
    // registers=7, ins=3, outs=3, insns_size=50
    0000: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0003: move-result-object v0
    0004: invoke-static {v0}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    0007: move-result-object v0
    0008: iget v1, v4.Lcom/sec/chaton/bb;->a:Lcom/sec/chaton/TabActivity;
    000a: invoke-static {v1}, Lcom/sec/chaton/TabActivity;->e(Lcom/sec/chaton/TabActivity;)Landroid/content/BroadcastReceiver;
    000d: move-result-object v1
    000e: invoke-virtual {v0, v1}, Landroid/support/v4/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    0011: iget v0, v4.Lcom/sec/chaton/bb;->a:Lcom/sec/chaton/TabActivity;
    0013: const/4 v1, 0
    0014: invoke-static {v0, v1}, Lcom/sec/chaton/TabActivity;->a(Lcom/sec/chaton/TabActivity;Landroid/content/BroadcastReceiver;)Landroid/content/BroadcastReceiver;
    0017: new-instance v0, Landroid/content/Intent;
    0019: iget v1, v4.Lcom/sec/chaton/bb;->a:Lcom/sec/chaton/TabActivity;
    001b: const-class v2, Lcom/sec/chaton/ExitAppDialogActivity;
    001d: invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0020: const-string v1, 'reason'
    0022: const-string v2, 'reason'
    0024: const/4 v3, 0
    0025: invoke-virtual {v6, v2, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    0028: move-result v2
    0029: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    002c: iget v1, v4.Lcom/sec/chaton/bb;->a:Lcom/sec/chaton/TabActivity;
    002e: invoke-virtual {v1, v0}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    0031: return-void