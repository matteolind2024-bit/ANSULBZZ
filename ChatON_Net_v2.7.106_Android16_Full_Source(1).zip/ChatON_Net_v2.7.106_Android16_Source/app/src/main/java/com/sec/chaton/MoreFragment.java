=== CLASS Lcom/sec/chaton/MoreFragment; (Source: MoreFragment.java) ===
  Super: Landroid/support/v4/app/Fragment;
  Interfaces: Lcom/sec/chaton/ac;
  [Static Field] a: Ljava/lang/String;
  [Static Field] b: Ljava/util/ArrayList;
  [Static Field] c: Lcom/coolots/sso/a/a;
  [Static Field] d: Lcom/coolots/sso/a/d;
  [Instance Field] e: Landroid/widget/AdapterView$OnItemClickListener;
  [Instance Field] f: Z
  [Instance Field] g: Landroid/view/View;
  [Instance Field] h: Landroid/widget/LinearLayout;
  [Instance Field] i: Landroid/widget/ImageView;
  [Instance Field] j: Landroid/widget/GridView;
  [Instance Field] k: Lcom/sec/chaton/aj;
  [Instance Field] l: Lcom/sec/chaton/event/e;
  [Instance Field] m: Landroid/content/BroadcastReceiver;
  [Instance Field] n: Landroid/content/BroadcastReceiver;
  [Instance Field] o: Landroid/os/Handler;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=26
    0000: const-class v0, Lcom/sec/chaton/MoreFragment;
    0002: invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0005: move-result-object v0
    0006: sput v0, Lcom/sec/chaton/MoreFragment;->a:Ljava/lang/String;
    0008: new-instance v0, Ljava/util/ArrayList;
    000a: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    000d: sput v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    000f: const/4 v0, 0
    0010: sput v0, Lcom/sec/chaton/MoreFragment;->c:Lcom/coolots/sso/a/a;
    0012: new-instance v0, Lcom/sec/chaton/ad;
    0014: invoke-direct {v0}, Lcom/sec/chaton/ad;-><init>()V
    0017: sput v0, Lcom/sec/chaton/MoreFragment;->d:Lcom/coolots/sso/a/d;
    0019: return-void

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=35
    0000: invoke-direct {v1}, Landroid/support/v4/app/Fragment;-><init>()V
    0003: const/4 v0, 1
    0004: iput v0, v1.Lcom/sec/chaton/MoreFragment;->f:Z
    0006: new-instance v0, Lcom/sec/chaton/ae;
    0008: invoke-direct {v0, v1}, Lcom/sec/chaton/ae;-><init>(Lcom/sec/chaton/MoreFragment;)V
    000b: iput v0, v1.Lcom/sec/chaton/MoreFragment;->m:Landroid/content/BroadcastReceiver;
    000d: new-instance v0, Lcom/sec/chaton/af;
    000f: invoke-direct {v0, v1}, Lcom/sec/chaton/af;-><init>(Lcom/sec/chaton/MoreFragment;)V
    0012: iput v0, v1.Lcom/sec/chaton/MoreFragment;->e:Landroid/widget/AdapterView$OnItemClickListener;
    0014: new-instance v0, Lcom/sec/chaton/ah;
    0016: invoke-direct {v0, v1}, Lcom/sec/chaton/ah;-><init>(Lcom/sec/chaton/MoreFragment;)V
    0019: iput v0, v1.Lcom/sec/chaton/MoreFragment;->n:Landroid/content/BroadcastReceiver;
    001b: new-instance v0, Lcom/sec/chaton/ai;
    001d: invoke-direct {v0, v1}, Lcom/sec/chaton/ai;-><init>(Lcom/sec/chaton/MoreFragment;)V
    0020: iput v0, v1.Lcom/sec/chaton/MoreFragment;->o:Landroid/os/Handler;
    0022: return-void

  [Direct Method] a(I) -> I
    // registers=6, ins=1, outs=3, insns_size=134
    0000: const/4 v1, 1
    0001: const/4 v2, 0
    0002: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0004: invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0007: move-result-object v0
    0008: check-cast v0, Lcom/sec/chaton/ak;
    000a: iget v0, v0.Lcom/sec/chaton/ak;->a:Ljava/lang/Integer;
    000c: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    000f: move-result v0
    0010: packed-switch v0, +104 (-> 0078)
    0013: move(op=01) v0, v2
    0014: return v0
    0015: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0018: move-result-object v0
    0019: const-string v3, 'UpdateIsCritical'
    001b: invoke-virtual {v0, v3}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    001e: move-result v0
    001f: if-ne v0, v1, 0059
    0021: move(op=01) v0, v1
    0022: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0025: move-result-object v1
    0026: invoke-static {v1}, Lcom/sec/chaton/util/bp;->a(Landroid/content/Context;)Z
    0029: move-result v1
    002a: if-eqz v1, 0042
    002c: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    002f: move-result-object v1
    0030: const-string v3, 'chatonVUpdateStatus'
    0032: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0035: move-result-object v4
    0036: invoke-virtual {v1, v3, v4}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Integer;)Ljava/lang/Integer;
    0039: move-result-object v1
    003a: invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I
    003d: move-result v1
    003e: if-eqz v1, 0042
    0040: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0042: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0045: move-result-object v1
    0046: const-string v3, 'sppIsUpdate'
    0048: invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    004b: move-result-object v2
    004c: invoke-virtual {v1, v3, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    004f: move-result-object v1
    0050: invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z
    0053: move-result v1
    0054: if-eqz v1, 0014
    0056: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0058: goto 0014
    0059: move(op=01) v0, v2
    005a: goto 0022
    005b: invoke-static {}, Lcom/sec/chaton/settings/downloads/ax;->a()I
    005e: move-result v0
    005f: goto 0014
    0060: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0063: move-result-object v0
    0064: const-string v1, 'notice'
    0066: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0069: move-result-object v2
    006a: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Integer;)Ljava/lang/Integer;
    006d: move-result-object v0
    006e: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    0071: move-result v0
    0072: goto 0014
    0073: invoke-static {}, Lcom/sec/chaton/event/f;->m()I
    0076: move-result v0
    0077: goto 0014
    0078: packed-switch-payload first=2130903384 targets=[75, 99, 3, 5, 80]

  [Direct Method] a(Lcom/sec/chaton/MoreFragment;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/MoreFragment;->g()V
    0003: return-void

  [Direct Method] b(Lcom/sec/chaton/MoreFragment;) -> Lcom/sec/chaton/aj;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/MoreFragment;->k:Lcom/sec/chaton/aj;
    0002: return-object v0

  [Direct Method] c(Lcom/sec/chaton/MoreFragment;) -> Lcom/sec/chaton/event/e;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/MoreFragment;->l:Lcom/sec/chaton/event/e;
    0002: return-object v0

  [Direct Method] c() -> V
    // registers=3, ins=0, outs=3, insns_size=52
    0000: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0003: move-result-object v0
    0004: invoke-static {v0}, Lcom/sec/chaton/util/bp;->a(Landroid/content/Context;)Z
    0007: move-result v0
    0008: if-nez v0, 000b
    000a: return-void
    000b: sget v0, Lcom/sec/chaton/MoreFragment;->c:Lcom/coolots/sso/a/a;
    000d: if-eqz v0, 0018
    000f: sget v0, Lcom/sec/chaton/MoreFragment;->c:Lcom/coolots/sso/a/a;
    0011: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0014: move-result-object v1
    0015: invoke-virtual {v0, v1}, Lcom/coolots/sso/a/a;->a(Landroid/content/Context;)V
    0018: new-instance v0, Lcom/coolots/sso/a/a;
    001a: invoke-direct {v0}, Lcom/coolots/sso/a/a;-><init>()V
    001d: sput v0, Lcom/sec/chaton/MoreFragment;->c:Lcom/coolots/sso/a/a;
    001f: sget v0, Lcom/sec/chaton/MoreFragment;->c:Lcom/coolots/sso/a/a;
    0021: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0024: move-result-object v1
    0025: sget v2, Lcom/sec/chaton/MoreFragment;->d:Lcom/coolots/sso/a/d;
    0027: invoke-virtual {v0, v1, v2}, Lcom/coolots/sso/a/a;->a(Landroid/content/Context;Lcom/coolots/sso/a/d;)V
    002a: sget v0, Lcom/sec/chaton/MoreFragment;->c:Lcom/coolots/sso/a/a;
    002c: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    002f: move-result-object v1
    0030: invoke-virtual {v0, v1}, Lcom/coolots/sso/a/a;->o(Landroid/content/Context;)I
    0033: goto 000a

  [Direct Method] d(Lcom/sec/chaton/MoreFragment;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/MoreFragment;->f()V
    0003: return-void

  [Direct Method] e() -> I
    // registers=3, ins=0, outs=1, insns_size=19
    0000: const/4 v0, 0
    0001: move(op=01) v1, v0
    0002: sget v2, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0004: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    0007: move-result v2
    0008: if-ge v0, v2, 0012
    000a: invoke-static {v0}, Lcom/sec/chaton/MoreFragment;->a(I)I
    000d: move-result v2
    000e: binop/2addr(op=b0) v1, v2
    000f: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0011: goto 0002
    0012: return v1

  [Direct Method] f() -> V
    // registers=4, ins=1, outs=3, insns_size=97
    0000: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0002: invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V
    0005: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0007: new-instance v1, Lcom/sec/chaton/ak;
    0009: const v2, 2130903387 (0x7f03015b)
    000c: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    000f: move-result-object v2
    0010: invoke-direct {v1, v3, v2}, Lcom/sec/chaton/ak;-><init>(Lcom/sec/chaton/MoreFragment;Ljava/lang/Integer;)V
    0013: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0016: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0018: new-instance v1, Lcom/sec/chaton/ak;
    001a: const v2, 2130903384 (0x7f030158)
    001d: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0020: move-result-object v2
    0021: invoke-direct {v1, v3, v2}, Lcom/sec/chaton/ak;-><init>(Lcom/sec/chaton/MoreFragment;Ljava/lang/Integer;)V
    0024: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0027: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0029: new-instance v1, Lcom/sec/chaton/ak;
    002b: const v2, 2130903382 (0x7f030156)
    002e: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0031: move-result-object v2
    0032: invoke-direct {v1, v3, v2}, Lcom/sec/chaton/ak;-><init>(Lcom/sec/chaton/MoreFragment;Ljava/lang/Integer;)V
    0035: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0038: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    003a: new-instance v1, Lcom/sec/chaton/ak;
    003c: const v2, 2130903388 (0x7f03015c)
    003f: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0042: move-result-object v2
    0043: invoke-direct {v1, v3, v2}, Lcom/sec/chaton/ak;-><init>(Lcom/sec/chaton/MoreFragment;Ljava/lang/Integer;)V
    0046: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0049: invoke-static {}, Lcom/sec/chaton/event/f;->f()Z
    004c: move-result v0
    004d: if-eqz v0, 0060
    004f: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0051: new-instance v1, Lcom/sec/chaton/ak;
    0053: const v2, 2130903385 (0x7f030159)
    0056: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0059: move-result-object v2
    005a: invoke-direct {v1, v3, v2}, Lcom/sec/chaton/ak;-><init>(Lcom/sec/chaton/MoreFragment;Ljava/lang/Integer;)V
    005d: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0060: return-void

  [Direct Method] g() -> V
    // registers=5, ins=1, outs=2, insns_size=59
    0000: const/4 v2, 0
    0001: move(op=01) v1, v2
    0002: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0004: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0007: move-result v0
    0008: if-ge v1, v0, 002c
    000a: invoke-static {v1}, Lcom/sec/chaton/MoreFragment;->a(I)I
    000d: move-result v3
    000e: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0010: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0013: move-result-object v0
    0014: check-cast v0, Lcom/sec/chaton/ak;
    0016: iget v0, v0.Lcom/sec/chaton/ak;->b:Landroid/widget/TextView;
    0018: if-eqz v0, 0022
    001a: if-lez v3, 0026
    001c: invoke-virtual {v0, v2}, Landroid/widget/TextView;->setVisibility(I)V
    001f: invoke-static {v0, v3}, Lcom/sec/chaton/util/cb;->a(Landroid/widget/TextView;I)V
    0022: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0024: move(op=01) v1, v0
    0025: goto 0002
    0026: const/16 v3, 8 (0x8)
    0028: invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V
    002b: goto 0022
    002c: invoke-virtual {v4}, Lcom/sec/chaton/MoreFragment;->getView()Landroid/view/View;
    002f: move-result-object v0
    0030: invoke-virtual {v0}, Landroid/view/View;->invalidate()V
    0033: return-void
    0034: move-exception v0
    0035: sget v1, Lcom/sec/chaton/MoreFragment;->a:Ljava/lang/String;
    0037: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->a(Ljava/lang/Throwable;Ljava/lang/String;)V
    003a: goto 0033

  [Virtual Method] a() -> V
    // registers=3, ins=1, outs=2, insns_size=30
    0000: const/4 v0, 1
    0001: iput v0, v2.Lcom/sec/chaton/MoreFragment;->f:Z
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0008: const-string v1, 'onTabSelected() / isShow : '
    000a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000d: move-result-object v0
    000e: iget v1, v2.Lcom/sec/chaton/MoreFragment;->f:Z
    0010: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0013: move-result-object v0
    0014: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0017: move-result-object v0
    0018: sget v1, Lcom/sec/chaton/MoreFragment;->a:Ljava/lang/String;
    001a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    001d: return-void

  [Virtual Method] b() -> V
    // registers=3, ins=1, outs=2, insns_size=30
    0000: const/4 v0, 0
    0001: iput v0, v2.Lcom/sec/chaton/MoreFragment;->f:Z
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0008: const-string v1, 'onTabUnSelected() / isShow : '
    000a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000d: move-result-object v0
    000e: iget v1, v2.Lcom/sec/chaton/MoreFragment;->f:Z
    0010: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0013: move-result-object v0
    0014: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0017: move-result-object v0
    0018: sget v1, Lcom/sec/chaton/MoreFragment;->a:Ljava/lang/String;
    001a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    001d: return-void

  [Virtual Method] d() -> V
    // registers=4, ins=1, outs=3, insns_size=32
    0000: monitor-enter v3
    0001: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0004: move-result-object v0
    0005: const-string v1, 'new_event_count'
    0007: const/4 v2, 0
    0008: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    000b: move-result-object v2
    000c: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Integer;)Ljava/lang/Integer;
    000f: move-result-object v0
    0010: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    0013: move-result v0
    0014: if-lez v0, 001b
    0016: iget v0, v3.Lcom/sec/chaton/MoreFragment;->l:Lcom/sec/chaton/event/e;
    0018: invoke-virtual {v0}, Lcom/sec/chaton/event/e;->a()Lcom/sec/chaton/event/g;
    001b: monitor-exit v3
    001c: return-void
    001d: move-exception v0
    001e: monitor-exit v3
    001f: throw v0

  [Virtual Method] onActivityCreated(Landroid/os/Bundle;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-super {v0, v1}, Landroid/support/v4/app/Fragment;->onActivityCreated(Landroid/os/Bundle;)V
    0003: return-void

  [Virtual Method] onConfigurationChanged(Landroid/content/res/Configuration;) -> V
    // registers=4, ins=2, outs=2, insns_size=23
    0000: invoke-super {v2, v3}, Landroid/support/v4/app/Fragment;->onConfigurationChanged(Landroid/content/res/Configuration;)V
    0003: iget v0, v3.Landroid/content/res/Configuration;->orientation:I
    0005: const/4 v1, 2
    0006: if-ne v0, v1, 0010
    0008: iget v0, v2.Lcom/sec/chaton/MoreFragment;->h:Landroid/widget/LinearLayout;
    000a: const/16 v1, 8 (0x8)
    000c: invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V
    000f: return-void
    0010: iget v0, v2.Lcom/sec/chaton/MoreFragment;->h:Landroid/widget/LinearLayout;
    0012: const/4 v1, 0
    0013: invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V
    0016: goto 000f

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=5, ins=2, outs=3, insns_size=46
    0000: invoke-super {v3, v4}, Landroid/support/v4/app/Fragment;->onCreate(Landroid/os/Bundle;)V
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0008: const-string v1, 'onCreate() / isShow : '
    000a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000d: move-result-object v0
    000e: iget v1, v3.Lcom/sec/chaton/MoreFragment;->f:Z
    0010: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0013: move-result-object v0
    0014: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0017: move-result-object v0
    0018: sget v1, Lcom/sec/chaton/MoreFragment;->a:Ljava/lang/String;
    001a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    001d: new-instance v0, Lcom/sec/chaton/event/e;
    001f: invoke-virtual {v3}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0022: move-result-object v1
    0023: iget v2, v3.Lcom/sec/chaton/MoreFragment;->o:Landroid/os/Handler;
    0025: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/event/e;-><init>(Landroid/content/Context;Landroid/os/Handler;)V
    0028: iput v0, v3.Lcom/sec/chaton/MoreFragment;->l:Lcom/sec/chaton/event/e;
    002a: invoke-direct {v3}, Lcom/sec/chaton/MoreFragment;->f()V
    002d: return-void

  [Virtual Method] onCreateView(Landroid/view/LayoutInflater;, Landroid/view/ViewGroup;, Landroid/os/Bundle;) -> Landroid/view/View;
    // registers=9, ins=4, outs=4, insns_size=135
    0000: const/4 v4, 0
    0001: const v0, 2130903245 (0x7f0300cd)
    0004: invoke-virtual {v6, v0, v7, v4}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;
    0007: move-result-object v0
    0008: iput v0, v5.Lcom/sec/chaton/MoreFragment;->g:Landroid/view/View;
    000a: iget v0, v5.Lcom/sec/chaton/MoreFragment;->g:Landroid/view/View;
    000c: const v1, 2131231829 (0x7f080455)
    000f: invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0012: move-result-object v0
    0013: check-cast v0, Landroid/widget/LinearLayout;
    0015: iput v0, v5.Lcom/sec/chaton/MoreFragment;->h:Landroid/widget/LinearLayout;
    0017: iget v0, v5.Lcom/sec/chaton/MoreFragment;->g:Landroid/view/View;
    0019: const v1, 2131231830 (0x7f080456)
    001c: invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    001f: move-result-object v0
    0020: check-cast v0, Landroid/widget/ImageView;
    0022: iput v0, v5.Lcom/sec/chaton/MoreFragment;->i:Landroid/widget/ImageView;
    0024: const/4 v0, 1
    0025: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0028: move-result-object v1
    0029: const-string v2, 'Theme'
    002b: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    002e: move-result-object v3
    002f: invoke-virtual {v1, v2, v3}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Integer;)Ljava/lang/Integer;
    0032: move-result-object v1
    0033: invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I
    0036: move-result v1
    0037: if-ne v0, v1, 0044
    0039: iget v0, v5.Lcom/sec/chaton/MoreFragment;->i:Landroid/widget/ImageView;
    003b: invoke-virtual {v0}, Landroid/widget/ImageView;->getBackground()Landroid/graphics/drawable/Drawable;
    003e: move-result-object v0
    003f: const/16 v1, 95 (0x5f)
    0041: invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V
    0044: iget v0, v5.Lcom/sec/chaton/MoreFragment;->g:Landroid/view/View;
    0046: const v1, 2131231828 (0x7f080454)
    0049: invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    004c: move-result-object v0
    004d: check-cast v0, Landroid/widget/GridView;
    004f: iput v0, v5.Lcom/sec/chaton/MoreFragment;->j:Landroid/widget/GridView;
    0051: new-instance v0, Lcom/sec/chaton/aj;
    0053: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0056: move-result-object v1
    0057: invoke-direct {v0, v5, v1}, Lcom/sec/chaton/aj;-><init>(Lcom/sec/chaton/MoreFragment;Landroid/content/Context;)V
    005a: iput v0, v5.Lcom/sec/chaton/MoreFragment;->k:Lcom/sec/chaton/aj;
    005c: iget v0, v5.Lcom/sec/chaton/MoreFragment;->j:Landroid/widget/GridView;
    005e: iget v1, v5.Lcom/sec/chaton/MoreFragment;->k:Lcom/sec/chaton/aj;
    0060: invoke-virtual {v0, v1}, Landroid/widget/GridView;->setAdapter(Landroid/widget/ListAdapter;)V
    0063: iget v0, v5.Lcom/sec/chaton/MoreFragment;->j:Landroid/widget/GridView;
    0065: iget v1, v5.Lcom/sec/chaton/MoreFragment;->e:Landroid/widget/AdapterView$OnItemClickListener;
    0067: invoke-virtual {v0, v1}, Landroid/widget/GridView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V
    006a: invoke-virtual {v5}, Lcom/sec/chaton/MoreFragment;->getResources()Landroid/content/res/Resources;
    006d: move-result-object v0
    006e: invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;
    0071: move-result-object v0
    0072: iget v0, v0.Landroid/content/res/Configuration;->orientation:I
    0074: const/4 v1, 2
    0075: if-ne v0, v1, 0081
    0077: iget v0, v5.Lcom/sec/chaton/MoreFragment;->h:Landroid/widget/LinearLayout;
    0079: const/16 v1, 8 (0x8)
    007b: invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V
    007e: iget v0, v5.Lcom/sec/chaton/MoreFragment;->g:Landroid/view/View;
    0080: return-object v0
    0081: iget v0, v5.Lcom/sec/chaton/MoreFragment;->h:Landroid/widget/LinearLayout;
    0083: invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setVisibility(I)V
    0086: goto 007e

  [Virtual Method] onDestroy() -> V
    // registers=3, ins=1, outs=2, insns_size=30
    0000: invoke-super {v2}, Landroid/support/v4/app/Fragment;->onDestroy()V
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0008: const-string v1, 'onDestroy() / isShow : '
    000a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000d: move-result-object v0
    000e: iget v1, v2.Lcom/sec/chaton/MoreFragment;->f:Z
    0010: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0013: move-result-object v0
    0014: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0017: move-result-object v0
    0018: sget v1, Lcom/sec/chaton/MoreFragment;->a:Ljava/lang/String;
    001a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    001d: return-void

  [Virtual Method] onPause() -> V
    // registers=3, ins=1, outs=2, insns_size=59
    0000: invoke-super {v2}, Landroid/support/v4/app/Fragment;->onPause()V
    0003: const/4 v0, 0
    0004: iput v0, v2.Lcom/sec/chaton/MoreFragment;->f:Z
    0006: new-instance v0, Ljava/lang/StringBuilder;
    0008: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v1, 'onPause() / isShow : '
    000d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v0
    0011: iget v1, v2.Lcom/sec/chaton/MoreFragment;->f:Z
    0013: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0016: move-result-object v0
    0017: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001a: move-result-object v0
    001b: sget v1, Lcom/sec/chaton/MoreFragment;->a:Ljava/lang/String;
    001d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0020: invoke-virtual {v2}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0023: move-result-object v0
    0024: invoke-static {v0}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    0027: move-result-object v0
    0028: iget v1, v2.Lcom/sec/chaton/MoreFragment;->m:Landroid/content/BroadcastReceiver;
    002a: invoke-virtual {v0, v1}, Landroid/support/v4/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    002d: invoke-virtual {v2}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0030: move-result-object v0
    0031: invoke-static {v0}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    0034: move-result-object v0
    0035: iget v1, v2.Lcom/sec/chaton/MoreFragment;->n:Landroid/content/BroadcastReceiver;
    0037: invoke-virtual {v0, v1}, Landroid/support/v4/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    003a: return-void

  [Virtual Method] onResume() -> V
    // registers=4, ins=1, outs=3, insns_size=118
    0000: invoke-super {v3}, Landroid/support/v4/app/Fragment;->onResume()V
    0003: const/4 v0, 1
    0004: iput v0, v3.Lcom/sec/chaton/MoreFragment;->f:Z
    0006: new-instance v0, Ljava/lang/StringBuilder;
    0008: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v1, 'onResume() / isShow : '
    000d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v0
    0011: iget v1, v3.Lcom/sec/chaton/MoreFragment;->f:Z
    0013: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0016: move-result-object v0
    0017: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001a: move-result-object v0
    001b: sget v1, Lcom/sec/chaton/MoreFragment;->a:Ljava/lang/String;
    001d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0020: invoke-direct {v3}, Lcom/sec/chaton/MoreFragment;->f()V
    0023: iget v0, v3.Lcom/sec/chaton/MoreFragment;->k:Lcom/sec/chaton/aj;
    0025: invoke-virtual {v0}, Lcom/sec/chaton/aj;->notifyDataSetChanged()V
    0028: invoke-virtual {v3}, Lcom/sec/chaton/MoreFragment;->d()V
    002b: new-instance v0, Landroid/content/IntentFilter;
    002d: invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V
    0030: const-string v1, 'more_tab_badge_update'
    0032: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    0035: invoke-virtual {v3}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0038: move-result-object v1
    0039: invoke-static {v1}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    003c: move-result-object v1
    003d: iget v2, v3.Lcom/sec/chaton/MoreFragment;->n:Landroid/content/BroadcastReceiver;
    003f: invoke-virtual {v1, v2, v0}, Landroid/support/v4/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    0042: new-instance v0, Landroid/content/IntentFilter;
    0044: invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V
    0047: const-string v1, 'more_event_update'
    0049: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    004c: invoke-virtual {v3}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    004f: move-result-object v1
    0050: invoke-static {v1}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    0053: move-result-object v1
    0054: iget v2, v3.Lcom/sec/chaton/MoreFragment;->m:Landroid/content/BroadcastReceiver;
    0056: invoke-virtual {v1, v2, v0}, Landroid/support/v4/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    0059: invoke-static {}, Lcom/sec/chaton/settings/PhoneSettingFragment2;->c()Z
    005c: move-result v0
    005d: if-eqz v0, 0075
    005f: new-instance v0, Landroid/content/Intent;
    0061: invoke-virtual {v3}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0064: move-result-object v1
    0065: const-class v2, Lcom/sec/chaton/settings/SettingContainerActivity;
    0067: invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    006a: const-string v1, 'contentId'
    006c: const v2, 2131492954 (0x7f0c005a)
    006f: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    0072: invoke-virtual {v3, v0}, Lcom/sec/chaton/MoreFragment;->startActivity(Landroid/content/Intent;)V
    0075: return-void

  [Virtual Method] onStart() -> V
    // registers=3, ins=1, outs=2, insns_size=30
    0000: invoke-super {v2}, Landroid/support/v4/app/Fragment;->onStart()V
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0008: const-string v1, 'onStart() / isShow : '
    000a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000d: move-result-object v0
    000e: iget v1, v2.Lcom/sec/chaton/MoreFragment;->f:Z
    0010: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0013: move-result-object v0
    0014: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0017: move-result-object v0
    0018: sget v1, Lcom/sec/chaton/MoreFragment;->a:Ljava/lang/String;
    001a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    001d: return-void