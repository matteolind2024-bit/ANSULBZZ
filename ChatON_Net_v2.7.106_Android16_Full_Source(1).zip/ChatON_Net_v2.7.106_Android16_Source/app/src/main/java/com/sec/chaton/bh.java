=== CLASS Lcom/sec/chaton/bh; (Source: TabActivity.java) ===
  Super: Landroid/os/Handler;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/bh;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Landroid/os/Handler;-><init>()V
    0005: return-void

  [Virtual Method] handleMessage(Landroid/os/Message;) -> V
    // registers=4, ins=2, outs=2, insns_size=24
    0000: iget v0, v3.Landroid/os/Message;->obj:Ljava/lang/Object;
    0002: check-cast v0, Lcom/sec/chaton/a/a/d;
    0004: invoke-virtual {v0}, Lcom/sec/chaton/a/a/d;->b()Lcom/sec/chaton/i/n;
    0007: move-result-object v0
    0008: sget v1, Lcom/sec/chaton/i/n;->a:Lcom/sec/chaton/i/n;
    000a: if-ne v0, v1, 0017
    000c: iget v0, v2.Lcom/sec/chaton/bh;->a:Lcom/sec/chaton/TabActivity;
    000e: invoke-static {v0}, Lcom/sec/chaton/TabActivity;->b(Lcom/sec/chaton/TabActivity;)Lcom/sec/chaton/util/ay;
    0011: move-result-object v0
    0012: const-string v1, 'set_compatibility'
    0014: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;)V
    0017: return-void