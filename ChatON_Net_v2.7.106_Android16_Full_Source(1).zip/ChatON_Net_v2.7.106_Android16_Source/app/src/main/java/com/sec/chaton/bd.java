=== CLASS Lcom/sec/chaton/bd; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/content/DialogInterface$OnClickListener;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/bd;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onClick(Landroid/content/DialogInterface;, I) -> V
    // registers=3, ins=3, outs=1, insns_size=4
    0000: invoke-interface {v1}, Landroid/content/DialogInterface;->dismiss()V
    0003: return-void