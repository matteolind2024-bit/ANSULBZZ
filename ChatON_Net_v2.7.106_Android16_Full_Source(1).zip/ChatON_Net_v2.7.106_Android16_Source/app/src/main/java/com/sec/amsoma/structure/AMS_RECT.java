=== CLASS Lcom/sec/amsoma/structure/AMS_RECT; (Source: AMS_RECT.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] nBottom: S
  [Instance Field] nLeft: S
  [Instance Field] nRight: S
  [Instance Field] nTop: S

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getnBottom() -> S
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_RECT;->nBottom:S
    0002: return v0

  [Virtual Method] getnLeft() -> S
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_RECT;->nLeft:S
    0002: return v0

  [Virtual Method] getnRight() -> S
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_RECT;->nRight:S
    0002: return v0

  [Virtual Method] getnTop() -> S
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_RECT;->nTop:S
    0002: return v0

  [Virtual Method] setnBottom(S) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_RECT;->nBottom:S
    0002: return-void

  [Virtual Method] setnLeft(S) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_RECT;->nLeft:S
    0002: return-void

  [Virtual Method] setnRight(S) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_RECT;->nRight:S
    0002: return-void

  [Virtual Method] setnTop(S) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_RECT;->nTop:S
    0002: return-void