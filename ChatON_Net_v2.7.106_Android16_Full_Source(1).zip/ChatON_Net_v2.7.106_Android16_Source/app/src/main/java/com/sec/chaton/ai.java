=== CLASS Lcom/sec/chaton/ai; (Source: MoreFragment.java) ===
  Super: Landroid/os/Handler;
  [Instance Field] a: Lcom/sec/chaton/MoreFragment;

  [Direct Method] <init>(Lcom/sec/chaton/MoreFragment;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/ai;->a:Lcom/sec/chaton/MoreFragment;
    0002: invoke-direct {v0}, Landroid/os/Handler;-><init>()V
    0005: return-void

  [Virtual Method] handleMessage(Landroid/os/Message;) -> V
    // registers=7, ins=2, outs=3, insns_size=235
    0000: const/4 v4, 0
    0001: invoke-super {v5, v6}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V
    0004: iget v0, v6.Landroid/os/Message;->what:I
    0006: const/16 v1, 1200 (0x4b0)
    0008: if-ne v0, v1, 003d
    000a: iget v0, v6.Landroid/os/Message;->obj:Ljava/lang/Object;
    000c: check-cast v0, Lcom/sec/chaton/a/a/d;
    000e: invoke-virtual {v0}, Lcom/sec/chaton/a/a/d;->b()Lcom/sec/chaton/i/n;
    0011: move-result-object v0
    0012: sget v1, Lcom/sec/chaton/i/n;->a:Lcom/sec/chaton/i/n;
    0014: if-ne v0, v1, 003d
    0016: new-instance v0, Ljava/lang/StringBuilder;
    0018: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    001b: const-string v1, 'banner download start'
    001d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0020: move-result-object v0
    0021: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0024: move-result-object v0
    0025: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0028: move-result-object v0
    0029: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    002c: move-result-object v1
    002d: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0030: move-result-object v1
    0031: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    0034: iget v0, v5.Lcom/sec/chaton/ai;->a:Lcom/sec/chaton/MoreFragment;
    0036: invoke-static {v0}, Lcom/sec/chaton/MoreFragment;->c(Lcom/sec/chaton/MoreFragment;)Lcom/sec/chaton/event/e;
    0039: move-result-object v0
    003a: invoke-virtual {v0}, Lcom/sec/chaton/event/e;->b()V
    003d: iget v0, v6.Landroid/os/Message;->what:I
    003f: const/4 v1, 2
    0040: if-ne v0, v1, 009c
    0042: new-instance v0, Ljava/lang/StringBuilder;
    0044: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0047: const-string v1, 'banner downloaded done'
    0049: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004c: move-result-object v0
    004d: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0050: move-result-object v0
    0051: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0054: move-result-object v0
    0055: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0058: move-result-object v1
    0059: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    005c: move-result-object v1
    005d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    0060: const/4 v0, 1
    0061: invoke-static {v0}, Lcom/sec/chaton/event/f;->a(Z)V
    0064: iget v0, v5.Lcom/sec/chaton/ai;->a:Lcom/sec/chaton/MoreFragment;
    0066: invoke-static {v0}, Lcom/sec/chaton/MoreFragment;->d(Lcom/sec/chaton/MoreFragment;)V
    0069: iget v0, v5.Lcom/sec/chaton/ai;->a:Lcom/sec/chaton/MoreFragment;
    006b: invoke-static {v0}, Lcom/sec/chaton/MoreFragment;->b(Lcom/sec/chaton/MoreFragment;)Lcom/sec/chaton/aj;
    006e: move-result-object v0
    006f: invoke-virtual {v0}, Lcom/sec/chaton/aj;->notifyDataSetChanged()V
    0072: new-instance v0, Landroid/content/Intent;
    0074: const-string v1, 'more_tab_badge_update'
    0076: invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    0079: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    007c: move-result-object v1
    007d: invoke-static {v1}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    0080: move-result-object v1
    0081: invoke-virtual {v1, v0}, Landroid/support/v4/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z
    0084: invoke-static {}, Lcom/sec/chaton/event/f;->c()Z
    0087: move-result v0
    0088: if-eqz v0, 009c
    008a: iget v0, v5.Lcom/sec/chaton/ai;->a:Lcom/sec/chaton/MoreFragment;
    008c: new-instance v1, Landroid/content/Intent;
    008e: iget v2, v5.Lcom/sec/chaton/ai;->a:Lcom/sec/chaton/MoreFragment;
    0090: invoke-virtual {v2}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0093: move-result-object v2
    0094: const-class v3, Lcom/sec/chaton/event/EventDialog;
    0096: invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0099: invoke-virtual {v0, v1}, Lcom/sec/chaton/MoreFragment;->startActivity(Landroid/content/Intent;)V
    009c: iget v0, v6.Landroid/os/Message;->what:I
    009e: const/4 v1, 4
    009f: if-ne v0, v1, 00c2
    00a1: new-instance v0, Ljava/lang/StringBuilder;
    00a3: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    00a6: const-string v1, 'banner download failed'
    00a8: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00ab: move-result-object v0
    00ac: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00af: move-result-object v0
    00b0: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00b3: move-result-object v0
    00b4: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    00b7: move-result-object v1
    00b8: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    00bb: move-result-object v1
    00bc: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    00bf: invoke-static {v4}, Lcom/sec/chaton/event/f;->a(Z)V
    00c2: iget v0, v6.Landroid/os/Message;->what:I
    00c4: const/4 v1, 3
    00c5: if-ne v0, v1, 00ca
    00c7: invoke-static {v4}, Lcom/sec/chaton/event/f;->a(Z)V
    00ca: return-void
    00cb: move-exception v0
    00cc: new-instance v0, Ljava/lang/StringBuilder;
    00ce: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    00d1: const-string v1, 'Exception is occurred!'
    00d3: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00d6: move-result-object v0
    00d7: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00da: move-result-object v0
    00db: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00de: move-result-object v0
    00df: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    00e2: move-result-object v1
    00e3: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    00e6: move-result-object v1
    00e7: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    00ea: goto 009c