=== CLASS Lcom/sec/chaton/ChatONVDialog; (Source: ChatONVDialog.java) ===
  Super: Landroid/app/Activity;
  [Instance Field] a: Landroid/widget/Button;
  [Instance Field] b: Landroid/widget/Button;
  [Instance Field] c: Landroid/widget/CheckBox;
  [Instance Field] d: Landroid/widget/LinearLayout;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/app/Activity;-><init>()V
    0003: return-void

  [Direct Method] a(Lcom/sec/chaton/ChatONVDialog;) -> Landroid/widget/CheckBox;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/ChatONVDialog;->c:Landroid/widget/CheckBox;
    0002: return-object v0

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=6, ins=2, outs=3, insns_size=92
    0000: const/4 v3, 0
    0001: invoke-super {v4, v5}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    0004: const/4 v0, 1
    0005: invoke-virtual {v4, v0}, Lcom/sec/chaton/ChatONVDialog;->requestWindowFeature(I)Z
    0008: const v0, 2130903124 (0x7f030054)
    000b: invoke-virtual {v4, v0}, Lcom/sec/chaton/ChatONVDialog;->setContentView(I)V
    000e: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0010: const/16 v1, 11 (0xb)
    0012: if-lt v0, v1, 0017
    0014: invoke-virtual {v4, v3}, Lcom/sec/chaton/ChatONVDialog;->setFinishOnTouchOutside(Z)V
    0017: invoke-virtual {v4}, Lcom/sec/chaton/ChatONVDialog;->getWindow()Landroid/view/Window;
    001a: move-result-object v0
    001b: const/4 v1, -1
    001c: const/4 v2, -2
    001d: invoke-virtual {v0, v1, v2}, Landroid/view/Window;->setLayout(II)V
    0020: const v0, 2131231275 (0x7f08022b)
    0023: invoke-virtual {v4, v0}, Lcom/sec/chaton/ChatONVDialog;->findViewById(I)Landroid/view/View;
    0026: move-result-object v0
    0027: check-cast v0, Landroid/widget/Button;
    0029: iput v0, v4.Lcom/sec/chaton/ChatONVDialog;->a:Landroid/widget/Button;
    002b: const v0, 2131231276 (0x7f08022c)
    002e: invoke-virtual {v4, v0}, Lcom/sec/chaton/ChatONVDialog;->findViewById(I)Landroid/view/View;
    0031: move-result-object v0
    0032: check-cast v0, Landroid/widget/Button;
    0034: iput v0, v4.Lcom/sec/chaton/ChatONVDialog;->b:Landroid/widget/Button;
    0036: const v0, 2131231274 (0x7f08022a)
    0039: invoke-virtual {v4, v0}, Lcom/sec/chaton/ChatONVDialog;->findViewById(I)Landroid/view/View;
    003c: move-result-object v0
    003d: check-cast v0, Landroid/widget/CheckBox;
    003f: iput v0, v4.Lcom/sec/chaton/ChatONVDialog;->c:Landroid/widget/CheckBox;
    0041: const v0, 2131231273 (0x7f080229)
    0044: invoke-virtual {v4, v0}, Lcom/sec/chaton/ChatONVDialog;->findViewById(I)Landroid/view/View;
    0047: move-result-object v0
    0048: check-cast v0, Landroid/widget/LinearLayout;
    004a: iput v0, v4.Lcom/sec/chaton/ChatONVDialog;->d:Landroid/widget/LinearLayout;
    004c: iget v0, v4.Lcom/sec/chaton/ChatONVDialog;->d:Landroid/widget/LinearLayout;
    004e: new-instance v1, Lcom/sec/chaton/m;
    0050: invoke-direct {v1, v4}, Lcom/sec/chaton/m;-><init>(Lcom/sec/chaton/ChatONVDialog;)V
    0053: invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0056: iget v0, v4.Lcom/sec/chaton/ChatONVDialog;->c:Landroid/widget/CheckBox;
    0058: invoke-virtual {v0, v3}, Landroid/widget/CheckBox;->setClickable(Z)V
    005b: return-void