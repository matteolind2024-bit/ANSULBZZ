=== CLASS Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT; (Source: AMS_SELECT_OBJECT.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] m_UserStampHeight: I
  [Instance Field] m_UserStampMemory: [I
  [Instance Field] m_UserStampWidth: I
  [Instance Field] m_nExcludedDrawingBPP: I
  [Instance Field] m_nExcludedDrawingHeight: I
  [Instance Field] m_nExcludedDrawingWidth: I
  [Instance Field] m_nSelectObjectBPP: I
  [Instance Field] m_pExcludedDrawingMemory: [I
  [Instance Field] m_pSelectObjectData: I
  [Instance Field] m_pSelectObjectNode: I

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getM_UserStampHeight() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_UserStampHeight:I
    0002: return v0

  [Virtual Method] getM_UserStampMemory() -> [I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_UserStampMemory:[I
    0002: return-object v0

  [Virtual Method] getM_UserStampWidth() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_UserStampWidth:I
    0002: return v0

  [Virtual Method] getM_nExcludedDrawingBPP() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_nExcludedDrawingBPP:I
    0002: return v0

  [Virtual Method] getM_nExcludedDrawingHeight() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_nExcludedDrawingHeight:I
    0002: return v0

  [Virtual Method] getM_nExcludedDrawingWidth() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_nExcludedDrawingWidth:I
    0002: return v0

  [Virtual Method] getM_nSelectObjectBPP() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_nSelectObjectBPP:I
    0002: return v0

  [Virtual Method] getM_pExcludedDrawingMemory() -> [I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_pExcludedDrawingMemory:[I
    0002: return-object v0

  [Virtual Method] getM_pSelectObjectData() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_pSelectObjectData:I
    0002: return v0

  [Virtual Method] getM_pSelectObjectNode() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_pSelectObjectNode:I
    0002: return v0

  [Virtual Method] setM_UserStampHeight(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_UserStampHeight:I
    0002: return-void

  [Virtual Method] setM_UserStampMemory([I, I, I) -> V
    // registers=8, ins=4, outs=0, insns_size=19
    0000: binop(op=92) v1, v6, v7
    0002: new-array v0, v1, [I
    0004: iput v0, v4.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_UserStampMemory:[I
    0006: const/4 v0, 0
    0007: if-ge v0, v1, 0012
    0009: iget v2, v4.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_UserStampMemory:[I
    000b: aget(op=44) v3, v5[v0]
    000d: aput(op=4b) v3, v2[v0]
    000f: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0011: goto 0007
    0012: return-void

  [Virtual Method] setM_UserStampWidth(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_UserStampWidth:I
    0002: return-void

  [Virtual Method] setM_nExcludedDrawingBPP(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_nExcludedDrawingBPP:I
    0002: return-void

  [Virtual Method] setM_nExcludedDrawingHeight(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_nExcludedDrawingHeight:I
    0002: return-void

  [Virtual Method] setM_nExcludedDrawingWidth(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_nExcludedDrawingWidth:I
    0002: return-void

  [Virtual Method] setM_nSelectObjectBPP(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_nSelectObjectBPP:I
    0002: return-void

  [Virtual Method] setM_pExcludedDrawingMemory([I, I, I) -> V
    // registers=8, ins=4, outs=0, insns_size=19
    0000: binop(op=92) v1, v6, v7
    0002: new-array v0, v1, [I
    0004: iput v0, v4.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_pExcludedDrawingMemory:[I
    0006: const/4 v0, 0
    0007: if-ge v0, v1, 0012
    0009: iget v2, v4.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_pExcludedDrawingMemory:[I
    000b: aget(op=44) v3, v5[v0]
    000d: aput(op=4b) v3, v2[v0]
    000f: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0011: goto 0007
    0012: return-void

  [Virtual Method] setM_pSelectObjectData(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_pSelectObjectData:I
    0002: return-void

  [Virtual Method] setM_pSelectObjectNode(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_SELECT_OBJECT;->m_pSelectObjectNode:I
    0002: return-void