=== CLASS Lcom/sec/chaton/am; (Source: R.java) ===
  Super: Ljava/lang/Object;
  [Static Field] AMSAlertDialog: [I = None
  [Static Field] AMSAlertDialog_bottomBright: I = 7
  [Static Field] AMSAlertDialog_bottomDark: I = 3
  [Static Field] AMSAlertDialog_bottomMedium: I = 8
  [Static Field] AMSAlertDialog_centerBright: I = 6
  [Static Field] AMSAlertDialog_centerDark: I = 2
  [Static Field] AMSAlertDialog_centerMedium: I = 9
  [Static Field] AMSAlertDialog_fullBright: I = 4
  [Static Field] AMSAlertDialog_fullDark: I = 0
  [Static Field] AMSAlertDialog_topBright: I = 5
  [Static Field] AMSAlertDialog_topDark: I = 1
  [Static Field] AMSWeightedLinearLayout: [I = None
  [Static Field] AMSWeightedLinearLayout_majorWeight: I = 0
  [Static Field] AMSWeightedLinearLayout_minorWeight: I = 1
  [Static Field] Carousel: [I = None
  [Static Field] Carousel_Items: I = 3
  [Static Field] Carousel_SelectedItem: I = 4
  [Static Field] Carousel_UseReflection: I = 2
  [Static Field] Carousel_android_animationDuration: I = 1
  [Static Field] Carousel_android_gravity: I = 0
  [Static Field] Carousel_maxQuantity: I = 7
  [Static Field] Carousel_maxTheta: I = 5
  [Static Field] Carousel_minQuantity: I = 6
  [Static Field] ChatONTheme: [I = None
  [Static Field] ChatONTheme_backgroundColor: I = 5
  [Static Field] ChatONTheme_callLogListBackgroundColor: I = 7
  [Static Field] ChatONTheme_callLogListTitle: I = 6
  [Static Field] ChatONTheme_dividerLine: I = 8
  [Static Field] ChatONTheme_listBackgroundColor: I = 0
  [Static Field] ChatONTheme_listDividerColor: I = 4
  [Static Field] ChatONTheme_listStatusColor: I = 2
  [Static Field] ChatONTheme_listStatusColor2: I = 3
  [Static Field] ChatONTheme_listTitleColor: I = 1
  [Static Field] CheckableLinearLayout: [I = None
  [Static Field] CheckableLinearLayout_checkable_multiple: I = 1
  [Static Field] CheckableLinearLayout_checkable_single: I = 0
  [Static Field] EditTextWithClearButton: [I = None
  [Static Field] EditTextWithClearButton_android_maxLength: I = 0
  [Static Field] GeneralHeaderView: [I = None
  [Static Field] GeneralHeaderView_android_button: I = 0
  [Static Field] GeneralHeaderView_android_text: I = 1
  [Static Field] PagerPositionStrip: [I = None
  [Static Field] PagerPositionStrip_firstIndicator: I = 3
  [Static Field] PagerPositionStrip_indicator: I = 0
  [Static Field] PagerPositionStrip_indicatorMargin: I = 5
  [Static Field] PagerPositionStrip_lastIndicator: I = 4
  [Static Field] PagerPositionStrip_leftIndicator: I = 1
  [Static Field] PagerPositionStrip_maxIndicatorCount: I = 6
  [Static Field] PagerPositionStrip_rightIndicator: I = 2
  [Static Field] ProgressBar: [I = None
  [Static Field] ProgressBar_android_max: I = 6
  [Static Field] ProgressBar_android_maxHeight: I = 5
  [Static Field] ProgressBar_android_maxWidth: I = 4
  [Static Field] ProgressBar_android_minHeight: I = 11
  [Static Field] ProgressBar_android_minWidth: I = 10
  [Static Field] ProgressBar_android_paddingBottom: I = 3
  [Static Field] ProgressBar_android_paddingLeft: I = 0
  [Static Field] ProgressBar_android_paddingRight: I = 2
  [Static Field] ProgressBar_android_paddingTop: I = 1
  [Static Field] ProgressBar_android_progress: I = 7
  [Static Field] ProgressBar_android_progressDrawable: I = 9
  [Static Field] ProgressBar_android_secondaryProgress: I = 8
  [Static Field] SeekBar: [I = None
  [Static Field] SeekBar_android_thumb: I = 0
  [Static Field] SeekBar_android_thumbOffset: I = 1
  [Static Field] Theme: [I = None
  [Static Field] Theme_android_disabledAlpha: I = 0
  [Static Field] Theme_android_galleryItemBackground: I = 1
  [Static Field] TwIndexView: [I = None
  [Static Field] TwIndexView_twIndexViewHandlePosition: I = 0
  [Static Field] TwIndexView_twIndexViewIndexInterval: I = 1

  [Direct Method] <clinit>() -> V
    // registers=4, ins=0, outs=0, insns_size=260
    0000: const/4 v3, 2
    0001: const/16 v0, 10 (0xa)
    0003: new-array v0, v0, [I
    0005: fill-array-data v0, +95 (-> 0064)
    0008: sput v0, Lcom/sec/chaton/am;->AMSAlertDialog:[I
    000a: new-array v0, v3, [I
    000c: fill-array-data v0, +112 (-> 007c)
    000f: sput v0, Lcom/sec/chaton/am;->AMSWeightedLinearLayout:[I
    0011: const/16 v0, 8 (0x8)
    0013: new-array v0, v0, [I
    0015: fill-array-data v0, +111 (-> 0084)
    0018: sput v0, Lcom/sec/chaton/am;->Carousel:[I
    001a: const/16 v0, 9 (0x9)
    001c: new-array v0, v0, [I
    001e: fill-array-data v0, +122 (-> 0098)
    0021: sput v0, Lcom/sec/chaton/am;->ChatONTheme:[I
    0023: new-array v0, v3, [I
    0025: fill-array-data v0, +137 (-> 00ae)
    0028: sput v0, Lcom/sec/chaton/am;->CheckableLinearLayout:[I
    002a: const/4 v0, 1
    002b: new-array v0, v0, [I
    002d: const/4 v1, 0
    002e: const v2, 16843104 (0x1010160)
    0031: aput(op=4b) v2, v0[v1]
    0033: sput v0, Lcom/sec/chaton/am;->EditTextWithClearButton:[I
    0035: new-array v0, v3, [I
    0037: fill-array-data v0, +127 (-> 00b6)
    003a: sput v0, Lcom/sec/chaton/am;->GeneralHeaderView:[I
    003c: const/4 v0, 7
    003d: new-array v0, v0, [I
    003f: fill-array-data v0, +127 (-> 00be)
    0042: sput v0, Lcom/sec/chaton/am;->PagerPositionStrip:[I
    0044: const/16 v0, 12 (0xc)
    0046: new-array v0, v0, [I
    0048: fill-array-data v0, +136 (-> 00d0)
    004b: sput v0, Lcom/sec/chaton/am;->ProgressBar:[I
    004d: new-array v0, v3, [I
    004f: fill-array-data v0, +157 (-> 00ec)
    0052: sput v0, Lcom/sec/chaton/am;->SeekBar:[I
    0054: new-array v0, v3, [I
    0056: fill-array-data v0, +158 (-> 00f4)
    0059: sput v0, Lcom/sec/chaton/am;->Theme:[I
    005b: new-array v0, v3, [I
    005d: fill-array-data v0, +159 (-> 00fc)
    0060: sput v0, Lcom/sec/chaton/am;->TwIndexView:[I
    0062: return-void
    0063: nop
    0064: fill-array-data-payload width=4 size=10 data=0600017f0700017f0800017f0900017f0a00017f0b00017f0c00017f0d00017f0e00017f0f00017f
    007c: fill-array-data-payload width=4 size=2 data=1100017f1200017f
    0084: fill-array-data-payload width=4 size=8 data=af000101120101010000017f0100017f0200017f0300017f0400017f0500017f
    0098: fill-array-data-payload width=4 size=9 data=1e00017f1f00017f2000017f2100017f2200017f2300017f2400017f2500017f2600017f
    00ae: fill-array-data-payload width=4 size=2 data=1c00017f1d00017f
    00b6: fill-array-data-payload width=4 size=2 data=070101014f010101
    00be: fill-array-data-payload width=4 size=7 data=1300017f1400017f1500017f1600017f1700017f1800017f1900017f
    00d0: fill-array-data-payload width=4 size=12 data=d6000101d7000101d8000101d90001011f010101200101013601010137010101380101013c0101013f01010140010101
    00ec: fill-array-data-payload width=4 size=2 data=4201010143010101
    00f4: fill-array-data-payload width=4 size=2 data=330001014c000101
    00fc: fill-array-data-payload width=4 size=2 data=1a00017f1b00017f