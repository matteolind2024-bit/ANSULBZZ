=== CLASS Lcom/sec/chaton/be; (Source: TabActivity.java) ===
  Super: Landroid/os/Handler;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;, Landroid/os/Looper;) -> V
    // registers=3, ins=3, outs=2, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/be;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    0005: return-void

  [Virtual Method] handleMessage(Landroid/os/Message;) -> V
    // registers=5, ins=2, outs=1, insns_size=47
    0000: iget v0, v4.Landroid/os/Message;->obj:Ljava/lang/Object;
    0002: check-cast v0, Lcom/sec/chaton/a/a/d;
    0004: invoke-virtual {v0}, Lcom/sec/chaton/a/a/d;->a()Z
    0007: move-result v1
    0008: if-eqz v1, 002e
    000a: invoke-virtual {v0}, Lcom/sec/chaton/a/a/d;->b()Lcom/sec/chaton/i/n;
    000d: move-result-object v1
    000e: sget v2, Lcom/sec/chaton/i/n;->c:Lcom/sec/chaton/i/n;
    0010: if-eq v1, v2, 002e
    0012: invoke-virtual {v0}, Lcom/sec/chaton/a/a/d;->d()Ljava/lang/Object;
    0015: move-result-object v0
    0016: check-cast v0, Lcom/sec/chaton/io/entry/GetVersionNotice;
    0018: if-eqz v0, 002e
    001a: iget v1, v0.Lcom/sec/chaton/io/entry/GetVersionNotice;->uptodate:Ljava/lang/Boolean;
    001c: if-eqz v1, 002e
    001e: iget v0, v0.Lcom/sec/chaton/io/entry/GetVersionNotice;->uptodate:Ljava/lang/Boolean;
    0020: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    0023: move-result v0
    0024: if-eqz v0, 002e
    0026: invoke-static {}, Lcom/sec/chaton/util/ac;->v()V
    0029: iget v0, v3.Lcom/sec/chaton/be;->a:Lcom/sec/chaton/TabActivity;
    002b: invoke-static {v0}, Lcom/sec/chaton/TabActivity;->f(Lcom/sec/chaton/TabActivity;)V
    002e: return-void