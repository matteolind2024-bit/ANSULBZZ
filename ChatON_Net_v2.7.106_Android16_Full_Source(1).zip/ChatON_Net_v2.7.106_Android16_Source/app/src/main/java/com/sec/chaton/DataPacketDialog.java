=== CLASS Lcom/sec/chaton/DataPacketDialog; (Source: DataPacketDialog.java) ===
  Super: Landroid/app/Activity;
  [Instance Field] a: Landroid/widget/Button;
  [Instance Field] b: Landroid/widget/CheckBox;
  [Instance Field] c: Landroid/widget/LinearLayout;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/app/Activity;-><init>()V
    0003: return-void

  [Direct Method] a(Lcom/sec/chaton/DataPacketDialog;) -> Landroid/widget/CheckBox;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/DataPacketDialog;->b:Landroid/widget/CheckBox;
    0002: return-object v0

  [Direct Method] a() -> V
    // registers=4, ins=1, outs=3, insns_size=41
    0000: const-string v0, 'showPasswordLockActivity'
    0002: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0005: move-result-object v1
    0006: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0009: move-result-object v1
    000a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    000d: invoke-virtual {v3}, Lcom/sec/chaton/DataPacketDialog;->getApplicationContext()Landroid/content/Context;
    0010: move-result-object v0
    0011: invoke-static {v0}, Lcom/sec/chaton/util/j;->c(Landroid/content/Context;)Z
    0014: move-result v1
    0015: if-eqz v1, 0028
    0017: new-instance v1, Landroid/content/Intent;
    0019: const-class v2, Lcom/sec/chaton/settings/ActivityPasswordLockSet;
    001b: invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    001e: const-string v0, 'MODE'
    0020: const-string v2, 'HOME'
    0022: invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    0025: invoke-virtual {v3, v1}, Lcom/sec/chaton/DataPacketDialog;->startActivity(Landroid/content/Intent;)V
    0028: return-void

  [Virtual Method] onConfigurationChanged(Landroid/content/res/Configuration;) -> V
    // registers=10, ins=2, outs=5, insns_size=79
    0000: const/high16 v7, 1056964608 (0x3f000000)
    0002: invoke-super {v8, v9}, Landroid/app/Activity;->onConfigurationChanged(Landroid/content/res/Configuration;)V
    0005: const v0, 2131230960 (0x7f0800f0)
    0008: invoke-virtual {v8, v0}, Lcom/sec/chaton/DataPacketDialog;->findViewById(I)Landroid/view/View;
    000b: move-result-object v0
    000c: check-cast v0, Landroid/widget/LinearLayout;
    000e: invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    0011: move-result-object v1
    0012: new-instance v2, Landroid/widget/FrameLayout$LayoutParams;
    0014: invoke-direct {v2, v1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V
    0017: const/4 v1, 0
    0018: const/high16 v3, 1084227584 (0x40a00000)
    001a: invoke-static {v3}, Lcom/sec/chaton/util/ad;->a(F)F
    001d: move-result v3
    001e: unop(op=87) v3, v3
    001f: invoke-virtual {v8}, Lcom/sec/chaton/DataPacketDialog;->getApplicationContext()Landroid/content/Context;
    0022: move-result-object v4
    0023: invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    0026: move-result-object v4
    0027: invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    002a: move-result-object v4
    002b: iget v4, v4.Landroid/util/DisplayMetrics;->density:F
    002d: iget v5, v9.Landroid/content/res/Configuration;->orientation:I
    002f: const/4 v6, 2
    0030: if-ne v5, v6, 0044
    0032: const/high16 v1, 1135869952 (0x43b40000)
    0034: binop/2addr(op=c8) v1, v4
    0035: binop/2addr(op=c6) v1, v7
    0036: unop(op=87) v1, v1
    0037: iput v1, v2.Landroid/widget/FrameLayout$LayoutParams;->width:I
    0039: invoke-virtual {v2, v3, v3, v3, v3}, Landroid/widget/FrameLayout$LayoutParams;->setMargins(IIII)V
    003c: const/16 v1, 17 (0x11)
    003e: iput v1, v2.Landroid/widget/FrameLayout$LayoutParams;->gravity:I
    0040: invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    0043: return-void
    0044: iget v5, v9.Landroid/content/res/Configuration;->orientation:I
    0046: const/4 v6, 1
    0047: if-ne v5, v6, 0037
    0049: const/high16 v1, 1134559232 (0x43a00000)
    004b: binop/2addr(op=c8) v1, v4
    004c: binop/2addr(op=c6) v1, v7
    004d: unop(op=87) v1, v1
    004e: goto 0037

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=12, ins=2, outs=5, insns_size=179
    0000: const/high16 v9, 1056964608 (0x3f000000)
    0002: const/4 v8, 1
    0003: const/4 v2, 0
    0004: invoke-super {v10, v11}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    0007: invoke-virtual {v10, v8}, Lcom/sec/chaton/DataPacketDialog;->requestWindowFeature(I)Z
    000a: const v0, 2130903132 (0x7f03005c)
    000d: invoke-virtual {v10, v0}, Lcom/sec/chaton/DataPacketDialog;->setContentView(I)V
    0010: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0012: const/16 v1, 11 (0xb)
    0014: if-lt v0, v1, 0019
    0016: invoke-virtual {v10, v2}, Lcom/sec/chaton/DataPacketDialog;->setFinishOnTouchOutside(Z)V
    0019: invoke-virtual {v10}, Lcom/sec/chaton/DataPacketDialog;->getWindow()Landroid/view/Window;
    001c: move-result-object v0
    001d: const/4 v1, -1
    001e: const/4 v3, -2
    001f: invoke-virtual {v0, v1, v3}, Landroid/view/Window;->setLayout(II)V
    0022: const v0, 2131230960 (0x7f0800f0)
    0025: invoke-virtual {v10, v0}, Lcom/sec/chaton/DataPacketDialog;->findViewById(I)Landroid/view/View;
    0028: move-result-object v0
    0029: check-cast v0, Landroid/widget/LinearLayout;
    002b: invoke-virtual {v0}, Landroid/widget/LinearLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    002e: move-result-object v1
    002f: new-instance v3, Landroid/widget/FrameLayout$LayoutParams;
    0031: invoke-direct {v3, v1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V
    0034: invoke-virtual {v10}, Lcom/sec/chaton/DataPacketDialog;->getResources()Landroid/content/res/Resources;
    0037: move-result-object v1
    0038: invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;
    003b: move-result-object v1
    003c: const/high16 v4, 1084227584 (0x40a00000)
    003e: invoke-static {v4}, Lcom/sec/chaton/util/ad;->a(F)F
    0041: move-result v4
    0042: unop(op=87) v4, v4
    0043: invoke-virtual {v10}, Lcom/sec/chaton/DataPacketDialog;->getApplicationContext()Landroid/content/Context;
    0046: move-result-object v5
    0047: invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    004a: move-result-object v5
    004b: invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    004e: move-result-object v5
    004f: iget v5, v5.Landroid/util/DisplayMetrics;->density:F
    0051: iget v6, v1.Landroid/content/res/Configuration;->orientation:I
    0053: const/4 v7, 2
    0054: if-ne v6, v7, 00a7
    0056: const/high16 v1, 1135869952 (0x43b40000)
    0058: binop/2addr(op=c8) v1, v5
    0059: binop/2addr(op=c6) v1, v9
    005a: unop(op=87) v1, v1
    005b: iput v1, v3.Landroid/widget/FrameLayout$LayoutParams;->width:I
    005d: invoke-virtual {v3, v4, v4, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;->setMargins(IIII)V
    0060: const/16 v1, 17 (0x11)
    0062: iput v1, v3.Landroid/widget/FrameLayout$LayoutParams;->gravity:I
    0064: invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    0067: const v0, 2131231298 (0x7f080242)
    006a: invoke-virtual {v10, v0}, Lcom/sec/chaton/DataPacketDialog;->findViewById(I)Landroid/view/View;
    006d: move-result-object v0
    006e: check-cast v0, Landroid/widget/Button;
    0070: iput v0, v10.Lcom/sec/chaton/DataPacketDialog;->a:Landroid/widget/Button;
    0072: const v0, 2131231274 (0x7f08022a)
    0075: invoke-virtual {v10, v0}, Lcom/sec/chaton/DataPacketDialog;->findViewById(I)Landroid/view/View;
    0078: move-result-object v0
    0079: check-cast v0, Landroid/widget/CheckBox;
    007b: iput v0, v10.Lcom/sec/chaton/DataPacketDialog;->b:Landroid/widget/CheckBox;
    007d: const v0, 2131231273 (0x7f080229)
    0080: invoke-virtual {v10, v0}, Lcom/sec/chaton/DataPacketDialog;->findViewById(I)Landroid/view/View;
    0083: move-result-object v0
    0084: check-cast v0, Landroid/widget/LinearLayout;
    0086: iput v0, v10.Lcom/sec/chaton/DataPacketDialog;->c:Landroid/widget/LinearLayout;
    0088: iget v0, v10.Lcom/sec/chaton/DataPacketDialog;->c:Landroid/widget/LinearLayout;
    008a: new-instance v1, Lcom/sec/chaton/n;
    008c: invoke-direct {v1, v10}, Lcom/sec/chaton/n;-><init>(Lcom/sec/chaton/DataPacketDialog;)V
    008f: invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0092: iget v0, v10.Lcom/sec/chaton/DataPacketDialog;->c:Landroid/widget/LinearLayout;
    0094: invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->setFocusable(Z)V
    0097: iget v0, v10.Lcom/sec/chaton/DataPacketDialog;->b:Landroid/widget/CheckBox;
    0099: invoke-virtual {v0, v2}, Landroid/widget/CheckBox;->setClickable(Z)V
    009c: iget v0, v10.Lcom/sec/chaton/DataPacketDialog;->a:Landroid/widget/Button;
    009e: new-instance v1, Lcom/sec/chaton/o;
    00a0: invoke-direct {v1, v10}, Lcom/sec/chaton/o;-><init>(Lcom/sec/chaton/DataPacketDialog;)V
    00a3: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    00a6: return-void
    00a7: iget v1, v1.Landroid/content/res/Configuration;->orientation:I
    00a9: if-ne v1, v8, 00b1
    00ab: const/high16 v1, 1134559232 (0x43a00000)
    00ad: binop/2addr(op=c8) v1, v5
    00ae: binop/2addr(op=c6) v1, v9
    00af: unop(op=87) v1, v1
    00b0: goto 005b
    00b1: move(op=01) v1, v2
    00b2: goto 005b

  [Virtual Method] onResume() -> V
    // registers=1, ins=1, outs=1, insns_size=7
    0000: invoke-super {v0}, Landroid/app/Activity;->onResume()V
    0003: invoke-direct {v0}, Lcom/sec/chaton/DataPacketDialog;->a()V
    0006: return-void

  [Virtual Method] onUserLeaveHint() -> V
    // registers=3, ins=1, outs=2, insns_size=21
    0000: const-string v0, 'onUserLeaveHint'
    0002: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0005: move-result-object v1
    0006: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0009: move-result-object v1
    000a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    000d: invoke-virtual {v2}, Lcom/sec/chaton/DataPacketDialog;->getApplicationContext()Landroid/content/Context;
    0010: move-result-object v0
    0011: invoke-static {v0}, Lcom/sec/chaton/util/j;->b(Landroid/content/Context;)V
    0014: return-void