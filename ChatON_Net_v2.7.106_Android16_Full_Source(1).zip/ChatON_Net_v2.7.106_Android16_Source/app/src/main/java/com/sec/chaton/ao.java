=== CLASS Lcom/sec/chaton/ao; (Source: SPPUpgradeDialog.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/view/View$OnClickListener;
  [Instance Field] a: Lcom/sec/chaton/SPPUpgradeDialog;

  [Direct Method] <init>(Lcom/sec/chaton/SPPUpgradeDialog;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/ao;->a:Lcom/sec/chaton/SPPUpgradeDialog;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onClick(Landroid/view/View;) -> V
    // registers=3, ins=2, outs=1, insns_size=6
    0000: iget v0, v1.Lcom/sec/chaton/ao;->a:Lcom/sec/chaton/SPPUpgradeDialog;
    0002: invoke-virtual {v0}, Lcom/sec/chaton/SPPUpgradeDialog;->finish()V
    0005: return-void