=== CLASS Lcom/sec/chaton/an; (Source: SPPUpgradeDialog.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/view/View$OnClickListener;
  [Instance Field] a: Lcom/sec/chaton/SPPUpgradeDialog;

  [Direct Method] <init>(Lcom/sec/chaton/SPPUpgradeDialog;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/an;->a:Lcom/sec/chaton/SPPUpgradeDialog;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onClick(Landroid/view/View;) -> V
    // registers=6, ins=2, outs=3, insns_size=51
    0000: const/4 v3, 1
    0001: new-instance v0, Landroid/content/Intent;
    0003: invoke-direct {v0}, Landroid/content/Intent;-><init>()V
    0006: const-string v1, 'com.sec.android.app.samsungapps'
    0008: const-string v2, 'com.sec.android.app.samsungapps.Main'
    000a: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    000d: const-string v1, 'directcall'
    000f: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    0012: const-string v1, 'callerType'
    0014: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    0017: const-string v1, 'GUID'
    0019: const-string v2, 'com.sec.spp.push'
    001b: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    001e: const/high16 v1, 335544320 (0x14000000)
    0020: invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    0023: iget v1, v4.Lcom/sec/chaton/an;->a:Lcom/sec/chaton/SPPUpgradeDialog;
    0025: invoke-virtual {v1, v0}, Lcom/sec/chaton/SPPUpgradeDialog;->startActivity(Landroid/content/Intent;)V
    0028: iget v0, v4.Lcom/sec/chaton/an;->a:Lcom/sec/chaton/SPPUpgradeDialog;
    002a: invoke-virtual {v0}, Lcom/sec/chaton/SPPUpgradeDialog;->finish()V
    002d: return-void
    002e: move-exception v0
    002f: invoke-virtual {v0}, Landroid/content/ActivityNotFoundException;->printStackTrace()V
    0032: goto 0028