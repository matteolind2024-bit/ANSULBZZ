=== CLASS Lcom/sec/chaton/ap; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/content/DialogInterface$OnClickListener;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/ap;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onClick(Landroid/content/DialogInterface;, I) -> V
    // registers=6, ins=3, outs=3, insns_size=24
    0000: new-instance v0, Landroid/content/Intent;
    0002: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0005: move-result-object v1
    0006: const-class v2, Lcom/sec/chaton/localbackup/ActivitySecretKey;
    0008: invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    000b: const-string v1, 'password_mode'
    000d: const/4 v2, 1
    000e: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    0011: iget v1, v3.Lcom/sec/chaton/ap;->a:Lcom/sec/chaton/TabActivity;
    0013: const/4 v2, 5
    0014: invoke-virtual {v1, v0, v2}, Lcom/sec/chaton/TabActivity;->startActivityForResult(Landroid/content/Intent;I)V
    0017: return-void