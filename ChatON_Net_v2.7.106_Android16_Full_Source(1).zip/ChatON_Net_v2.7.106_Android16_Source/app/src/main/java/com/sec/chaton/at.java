=== CLASS Lcom/sec/chaton/at; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/sec/chaton/util/bb;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/at;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] a() -> Z
    // registers=5, ins=1, outs=3, insns_size=47
    0000: const/4 v0, 1
    0001: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0004: move-result-object v1
    0005: invoke-static {v1}, Lcom/sec/chaton/util/bp;->a(Landroid/content/Context;)Z
    0008: move-result v1
    0009: if-ne v1, v0, 002d
    000b: new-instance v1, Ljava/lang/StringBuilder;
    000d: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0010: const-string v2, 'Running mChatonVUpgradeCheckTask by polling scheduler at time = '
    0012: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0015: move-result-object v1
    0016: invoke-static {}, Ljava/lang/System;->currentTimeMillis()J
    0019: move-result-wide v2
    001a: invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    001d: move-result-object v1
    001e: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0021: move-result-object v1
    0022: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    0025: move-result-object v2
    0026: invoke-static {v1, v2}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0029: invoke-static {}, Lcom/sec/chaton/MoreFragment;->c()V
    002c: return v0
    002d: const/4 v0, 0
    002e: goto 002c