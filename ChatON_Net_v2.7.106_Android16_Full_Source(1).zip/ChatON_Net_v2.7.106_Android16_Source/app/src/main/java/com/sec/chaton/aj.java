=== CLASS Lcom/sec/chaton/aj; (Source: MoreFragment.java) ===
  Super: Landroid/widget/BaseAdapter;
  [Instance Field] a: Landroid/view/LayoutInflater;
  [Instance Field] b: Lcom/sec/chaton/MoreFragment;

  [Direct Method] <init>(Lcom/sec/chaton/MoreFragment;, Landroid/content/Context;) -> V
    // registers=5, ins=3, outs=2, insns_size=20
    0000: iput v3, v2.Lcom/sec/chaton/aj;->b:Lcom/sec/chaton/MoreFragment;
    0002: invoke-direct {v2}, Landroid/widget/BaseAdapter;-><init>()V
    0005: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0008: move-result-object v0
    0009: const-string v1, 'layout_inflater'
    000b: invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    000e: move-result-object v0
    000f: check-cast v0, Landroid/view/LayoutInflater;
    0011: iput v0, v2.Lcom/sec/chaton/aj;->a:Landroid/view/LayoutInflater;
    0013: return-void

  [Virtual Method] getCount() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0002: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] getItem(I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getItemId(I) -> J
    // registers=4, ins=2, outs=0, insns_size=3
    0000: const-wide/16 v0, 0
    0002: return-wide v0

  [Virtual Method] getView(I, Landroid/view/View;, Landroid/view/ViewGroup;) -> Landroid/view/View;
    // registers=8, ins=4, outs=3, insns_size=73
    0000: iget v1, v4.Lcom/sec/chaton/aj;->a:Landroid/view/LayoutInflater;
    0002: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0004: invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0007: move-result-object v0
    0008: check-cast v0, Lcom/sec/chaton/ak;
    000a: iget v0, v0.Lcom/sec/chaton/ak;->a:Ljava/lang/Integer;
    000c: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    000f: move-result v0
    0010: const/4 v2, 0
    0011: invoke-virtual {v1, v0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;
    0014: move-result-object v2
    0015: const v0, 2131232380 (0x7f08067c)
    0018: invoke-virtual {v2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    001b: move-result-object v0
    001c: check-cast v0, Landroid/widget/TextView;
    001e: sget v1, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    0020: invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0023: move-result-object v1
    0024: check-cast v1, Lcom/sec/chaton/ak;
    0026: iget v1, v1.Lcom/sec/chaton/ak;->b:Landroid/widget/TextView;
    0028: if-nez v1, 0035
    002a: sget v1, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    002c: invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    002f: move-result-object v1
    0030: check-cast v1, Lcom/sec/chaton/ak;
    0032: invoke-virtual {v1, v0}, Lcom/sec/chaton/ak;->a(Landroid/widget/TextView;)V
    0035: invoke-static {v5}, Lcom/sec/chaton/MoreFragment;->a(I)I
    0038: move-result v1
    0039: if-lez v1, 0043
    003b: const/4 v3, 0
    003c: invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V
    003f: invoke-static {v0, v1}, Lcom/sec/chaton/util/cb;->a(Landroid/widget/TextView;I)V
    0042: return-object v2
    0043: const/16 v1, 8 (0x8)
    0045: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V
    0048: goto 0042