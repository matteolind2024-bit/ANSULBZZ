=== CLASS Lcom/sec/chaton/TabActivity; (Source: TabActivity.java) ===
  Super: Lcom/sec/chaton/base/BaseMultiPaneActivity;
  [Static Field] a: Ljava/lang/String;
  [Static Field] g: Ljava/lang/String;
  [Static Field] j: I
  [Instance Field] A: Lcom/sec/chaton/util/bb;
  [Instance Field] B: Lcom/sec/chaton/util/bb;
  [Instance Field] C: Lcom/sec/chaton/util/bb;
  [Instance Field] D: Lcom/sec/chaton/util/bb;
  [Instance Field] E: Lcom/sec/chaton/util/bb;
  [Instance Field] F: Lcom/sec/chaton/util/bb;
  [Instance Field] G: Landroid/os/Handler;
  [Instance Field] b: Ljava/lang/Runnable;
  [Instance Field] c: Landroid/os/Handler;
  [Instance Field] d: Landroid/os/Handler;
  [Instance Field] e: Landroid/os/Handler;
  [Instance Field] h: I
  [Instance Field] i: I
  [Instance Field] k: Lcom/sec/chaton/s;
  [Instance Field] l: Landroid/view/View;
  [Instance Field] m: Z
  [Instance Field] n: Landroid/app/AlertDialog;
  [Instance Field] o: Landroid/content/BroadcastReceiver;
  [Instance Field] p: Landroid/content/BroadcastReceiver;
  [Instance Field] q: Lcom/sec/chaton/util/ay;
  [Instance Field] r: Lcom/sec/chaton/util/bb;
  [Instance Field] s: Lcom/sec/chaton/util/bb;
  [Instance Field] t: Lcom/sec/chaton/util/bb;
  [Instance Field] u: Lcom/sec/chaton/util/bb;
  [Instance Field] v: Lcom/sec/chaton/util/bb;
  [Instance Field] w: Lcom/sec/chaton/util/bb;
  [Instance Field] x: Lcom/sec/chaton/util/bb;
  [Instance Field] y: Lcom/sec/chaton/util/bb;
  [Instance Field] z: Lcom/sec/chaton/util/bb;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=17
    0000: const-class v0, Lcom/sec/chaton/TabActivity;
    0002: invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0005: move-result-object v0
    0006: sput v0, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0008: const/high16 v0, 604045312 (0x24010000)
    000a: sput v0, Lcom/sec/chaton/TabActivity;->j:I
    000c: const-string v0, 'baseIntent'
    000e: sput v0, Lcom/sec/chaton/TabActivity;->a:Ljava/lang/String;
    0010: return-void

  [Direct Method] <init>() -> V
    // registers=3, ins=1, outs=3, insns_size=158
    0000: invoke-direct {v2}, Lcom/sec/chaton/base/BaseMultiPaneActivity;-><init>()V
    0003: const/4 v0, 1
    0004: iput v0, v2.Lcom/sec/chaton/TabActivity;->h:I
    0006: const/4 v0, 2
    0007: iput v0, v2.Lcom/sec/chaton/TabActivity;->i:I
    0009: new-instance v0, Lcom/sec/chaton/bk;
    000b: invoke-direct {v0, v2}, Lcom/sec/chaton/bk;-><init>(Lcom/sec/chaton/TabActivity;)V
    000e: iput v0, v2.Lcom/sec/chaton/TabActivity;->r:Lcom/sec/chaton/util/bb;
    0010: new-instance v0, Lcom/sec/chaton/bl;
    0012: invoke-direct {v0, v2}, Lcom/sec/chaton/bl;-><init>(Lcom/sec/chaton/TabActivity;)V
    0015: iput v0, v2.Lcom/sec/chaton/TabActivity;->s:Lcom/sec/chaton/util/bb;
    0017: new-instance v0, Lcom/sec/chaton/bm;
    0019: invoke-direct {v0, v2}, Lcom/sec/chaton/bm;-><init>(Lcom/sec/chaton/TabActivity;)V
    001c: iput v0, v2.Lcom/sec/chaton/TabActivity;->t:Lcom/sec/chaton/util/bb;
    001e: new-instance v0, Lcom/sec/chaton/bn;
    0020: invoke-direct {v0, v2}, Lcom/sec/chaton/bn;-><init>(Lcom/sec/chaton/TabActivity;)V
    0023: iput v0, v2.Lcom/sec/chaton/TabActivity;->u:Lcom/sec/chaton/util/bb;
    0025: new-instance v0, Lcom/sec/chaton/bp;
    0027: invoke-direct {v0, v2}, Lcom/sec/chaton/bp;-><init>(Lcom/sec/chaton/TabActivity;)V
    002a: iput v0, v2.Lcom/sec/chaton/TabActivity;->v:Lcom/sec/chaton/util/bb;
    002c: new-instance v0, Lcom/sec/chaton/aq;
    002e: invoke-direct {v0, v2}, Lcom/sec/chaton/aq;-><init>(Lcom/sec/chaton/TabActivity;)V
    0031: iput v0, v2.Lcom/sec/chaton/TabActivity;->w:Lcom/sec/chaton/util/bb;
    0033: new-instance v0, Lcom/sec/chaton/ar;
    0035: invoke-direct {v0, v2}, Lcom/sec/chaton/ar;-><init>(Lcom/sec/chaton/TabActivity;)V
    0038: iput v0, v2.Lcom/sec/chaton/TabActivity;->x:Lcom/sec/chaton/util/bb;
    003a: new-instance v0, Lcom/sec/chaton/as;
    003c: invoke-direct {v0, v2}, Lcom/sec/chaton/as;-><init>(Lcom/sec/chaton/TabActivity;)V
    003f: iput v0, v2.Lcom/sec/chaton/TabActivity;->y:Lcom/sec/chaton/util/bb;
    0041: new-instance v0, Lcom/sec/chaton/at;
    0043: invoke-direct {v0, v2}, Lcom/sec/chaton/at;-><init>(Lcom/sec/chaton/TabActivity;)V
    0046: iput v0, v2.Lcom/sec/chaton/TabActivity;->z:Lcom/sec/chaton/util/bb;
    0048: new-instance v0, Lcom/sec/chaton/au;
    004a: invoke-direct {v0, v2}, Lcom/sec/chaton/au;-><init>(Lcom/sec/chaton/TabActivity;)V
    004d: iput v0, v2.Lcom/sec/chaton/TabActivity;->A:Lcom/sec/chaton/util/bb;
    004f: new-instance v0, Lcom/sec/chaton/av;
    0051: invoke-direct {v0, v2}, Lcom/sec/chaton/av;-><init>(Lcom/sec/chaton/TabActivity;)V
    0054: iput v0, v2.Lcom/sec/chaton/TabActivity;->B:Lcom/sec/chaton/util/bb;
    0056: new-instance v0, Lcom/sec/chaton/aw;
    0058: invoke-direct {v0, v2}, Lcom/sec/chaton/aw;-><init>(Lcom/sec/chaton/TabActivity;)V
    005b: iput v0, v2.Lcom/sec/chaton/TabActivity;->C:Lcom/sec/chaton/util/bb;
    005d: new-instance v0, Lcom/sec/chaton/ax;
    005f: invoke-direct {v0, v2}, Lcom/sec/chaton/ax;-><init>(Lcom/sec/chaton/TabActivity;)V
    0062: iput v0, v2.Lcom/sec/chaton/TabActivity;->D:Lcom/sec/chaton/util/bb;
    0064: new-instance v0, Lcom/sec/chaton/ay;
    0066: invoke-direct {v0, v2}, Lcom/sec/chaton/ay;-><init>(Lcom/sec/chaton/TabActivity;)V
    0069: iput v0, v2.Lcom/sec/chaton/TabActivity;->E:Lcom/sec/chaton/util/bb;
    006b: new-instance v0, Lcom/sec/chaton/az;
    006d: invoke-direct {v0, v2}, Lcom/sec/chaton/az;-><init>(Lcom/sec/chaton/TabActivity;)V
    0070: iput v0, v2.Lcom/sec/chaton/TabActivity;->F:Lcom/sec/chaton/util/bb;
    0072: new-instance v0, Lcom/sec/chaton/ba;
    0074: invoke-direct {v0, v2}, Lcom/sec/chaton/ba;-><init>(Lcom/sec/chaton/TabActivity;)V
    0077: iput v0, v2.Lcom/sec/chaton/TabActivity;->b:Ljava/lang/Runnable;
    0079: new-instance v0, Lcom/sec/chaton/be;
    007b: invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;
    007e: move-result-object v1
    007f: invoke-direct {v0, v2, v1}, Lcom/sec/chaton/be;-><init>(Lcom/sec/chaton/TabActivity;Landroid/os/Looper;)V
    0082: iput v0, v2.Lcom/sec/chaton/TabActivity;->c:Landroid/os/Handler;
    0084: new-instance v0, Lcom/sec/chaton/bf;
    0086: invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;
    0089: move-result-object v1
    008a: invoke-direct {v0, v2, v1}, Lcom/sec/chaton/bf;-><init>(Lcom/sec/chaton/TabActivity;Landroid/os/Looper;)V
    008d: iput v0, v2.Lcom/sec/chaton/TabActivity;->d:Landroid/os/Handler;
    008f: new-instance v0, Lcom/sec/chaton/bg;
    0091: invoke-direct {v0, v2}, Lcom/sec/chaton/bg;-><init>(Lcom/sec/chaton/TabActivity;)V
    0094: iput v0, v2.Lcom/sec/chaton/TabActivity;->e:Landroid/os/Handler;
    0096: new-instance v0, Lcom/sec/chaton/bh;
    0098: invoke-direct {v0, v2}, Lcom/sec/chaton/bh;-><init>(Lcom/sec/chaton/TabActivity;)V
    009b: iput v0, v2.Lcom/sec/chaton/TabActivity;->G:Landroid/os/Handler;
    009d: return-void

  [Direct Method] a(Lcom/sec/chaton/TabActivity;, Landroid/content/BroadcastReceiver;) -> Landroid/content/BroadcastReceiver;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/TabActivity;->o:Landroid/content/BroadcastReceiver;
    0002: return-object v1

  [Direct Method] a(Landroid/content/Context;) -> Landroid/content/Intent;
    // registers=3, ins=1, outs=3, insns_size=13
    0000: new-instance v0, Landroid/content/Intent;
    0002: const-class v1, Lcom/sec/chaton/TabActivity;
    0004: invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0007: sget v1, Lcom/sec/chaton/TabActivity;->j:I
    0009: invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    000c: return-object v0

  [Direct Method] a(Landroid/content/Context;, Landroid/content/Intent;) -> Landroid/content/Intent;
    // registers=4, ins=2, outs=3, insns_size=10
    0000: invoke-static {v2}, Lcom/sec/chaton/TabActivity;->a(Landroid/content/Context;)Landroid/content/Intent;
    0003: move-result-object v0
    0004: sget v1, Lcom/sec/chaton/TabActivity;->a:Ljava/lang/String;
    0006: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    0009: return-object v0

  [Direct Method] a(Landroid/content/Context;, Z) -> Landroid/content/Intent;
    // registers=5, ins=2, outs=3, insns_size=20
    0000: const/4 v2, 1
    0001: invoke-static {v3}, Lcom/sec/chaton/TabActivity;->a(Landroid/content/Context;)Landroid/content/Intent;
    0004: move-result-object v0
    0005: if-ne v4, v2, 000d
    0007: const-string v1, 'callChatList'
    0009: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    000c: return-object v0
    000d: const-string v1, 'callChatList'
    000f: const/4 v2, 0
    0010: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    0013: goto 000c

  [Direct Method] a(Lcom/sec/chaton/TabActivity;) -> Lcom/sec/chaton/util/bb;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/TabActivity;->v:Lcom/sec/chaton/util/bb;
    0002: return-object v0

  [Direct Method] a(Lcom/sec/chaton/TabActivity;, Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/sec/chaton/TabActivity;->b(Ljava/lang/String;)V
    0003: return-void

  [Direct Method] a(Lcom/sec/chaton/TabActivity;, Z) -> Z
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/TabActivity;->m:Z
    0002: return v1

  [Direct Method] b(Lcom/sec/chaton/TabActivity;) -> Lcom/sec/chaton/util/ay;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    0002: return-object v0

  [Direct Method] b(Ljava/lang/String;) -> V
    // registers=4, ins=2, outs=3, insns_size=47
    0000: invoke-static {}, Lcom/sec/chaton/util/ac;->u()Z
    0003: move-result v0
    0004: if-nez v0, 002e
    0006: const-string v0, 'showDisclaimer'
    0008: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    000a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    000d: const-string v0, 'update_disclaimer_status'
    000f: const-string v1, 'RUN'
    0011: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/String;)V
    0014: const-string v0, 'disclaimer_ID'
    0016: invoke-static {v0, v3}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/String;)V
    0019: new-instance v0, Landroid/content/Intent;
    001b: const-class v1, Lcom/sec/chaton/registration/ActivityDisclaimer;
    001d: invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0020: const-string v1, 'disclaimerUID'
    0022: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    0025: const/high16 v1, 67108864 (0x4000000)
    0027: invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    002a: const/4 v1, 1
    002b: invoke-virtual {v2, v0, v1}, Lcom/sec/chaton/TabActivity;->startActivityForResult(Landroid/content/Intent;I)V
    002e: return-void

  [Direct Method] c(Lcom/sec/chaton/TabActivity;) -> Landroid/os/Handler;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/TabActivity;->G:Landroid/os/Handler;
    0002: return-object v0

  [Direct Method] c() -> Ljava/lang/String;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0002: return-object v0

  [Direct Method] c(Landroid/content/Intent;) -> V
    // registers=5, ins=2, outs=3, insns_size=82
    0000: const/high16 v2, 67108864 (0x4000000)
    0002: invoke-static {v4, v3}, Lcom/sec/chaton/r;->a(Landroid/content/Intent;Landroid/content/Context;)Lcom/sec/chaton/s;
    0005: move-result-object v0
    0006: iput v0, v3.Lcom/sec/chaton/TabActivity;->k:Lcom/sec/chaton/s;
    0008: sget v1, Lcom/sec/chaton/bi;->a:[I
    000a: invoke-virtual {v0}, Lcom/sec/chaton/s;->ordinal()I
    000d: move-result v0
    000e: aget(op=44) v0, v1[v0]
    0010: packed-switch v0, +48 (-> 0040)
    0013: return-void
    0014: invoke-direct {v3, v4}, Lcom/sec/chaton/TabActivity;->d(Landroid/content/Intent;)V
    0017: goto 0013
    0018: invoke-direct {v3, v4}, Lcom/sec/chaton/TabActivity;->e(Landroid/content/Intent;)V
    001b: goto 0013
    001c: new-instance v0, Landroid/content/Intent;
    001e: const-class v1, Lcom/sec/chaton/buddy/dialog/ChatONVInstallDialog;
    0020: invoke-direct {v0, v3, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0023: invoke-virtual {v3, v0}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    0026: goto 0013
    0027: const-class v0, Lcom/sec/chaton/buddy/AddBuddyActivity;
    0029: invoke-virtual {v4, v3, v0}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;
    002c: invoke-virtual {v4, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    002f: invoke-virtual {v3, v4}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    0032: goto 0013
    0033: const-class v0, Lcom/sec/chaton/buddy/BuddyProfileActivity;
    0035: invoke-virtual {v4, v3, v0}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;
    0038: invoke-virtual {v4, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    003b: invoke-virtual {v3, v4}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    003e: goto 0013
    003f: nop
    0040: packed-switch-payload first=1 targets=[4, 8, 3, 3, 12, 23, 35]

  [Direct Method] d() -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=129
    0000: const-string v0, ''
    0002: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->getIntent()Landroid/content/Intent;
    0005: move-result-object v1
    0006: invoke-virtual {v1}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0009: move-result-object v1
    000a: if-eqz v1, 0059
    000c: new-instance v1, Ljava/lang/StringBuilder;
    000e: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0011: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0014: move-result-object v0
    0015: const-string v1, ', Intent Action: '
    0017: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001a: move-result-object v0
    001b: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->getIntent()Landroid/content/Intent;
    001e: move-result-object v1
    001f: invoke-virtual {v1}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0022: move-result-object v1
    0023: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0026: move-result-object v0
    0027: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002a: move-result-object v0
    002b: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->getIntent()Landroid/content/Intent;
    002e: move-result-object v1
    002f: invoke-virtual {v1}, Landroid/content/Intent;->getCategories()Ljava/util/Set;
    0032: move-result-object v1
    0033: if-eqz v1, 006d
    0035: new-instance v1, Ljava/lang/StringBuilder;
    0037: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    003a: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003d: move-result-object v0
    003e: const-string v1, ', Intent Category: '
    0040: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0043: move-result-object v0
    0044: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->getIntent()Landroid/content/Intent;
    0047: move-result-object v1
    0048: invoke-virtual {v1}, Landroid/content/Intent;->getCategories()Ljava/util/Set;
    004b: move-result-object v1
    004c: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    004f: move-result-object v1
    0050: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0053: move-result-object v0
    0054: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0057: move-result-object v0
    0058: return-object v0
    0059: new-instance v1, Ljava/lang/StringBuilder;
    005b: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    005e: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0061: move-result-object v0
    0062: const-string v1, ', Intent Action: Null'
    0064: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0067: move-result-object v0
    0068: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    006b: move-result-object v0
    006c: goto 002b
    006d: new-instance v1, Ljava/lang/StringBuilder;
    006f: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0072: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0075: move-result-object v0
    0076: const-string v1, ', Intent Category: Null'
    0078: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    007b: move-result-object v0
    007c: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    007f: move-result-object v0
    0080: goto 0058

  [Direct Method] d(Landroid/content/Intent;) -> V
    // registers=6, ins=2, outs=3, insns_size=127
    0000: const/4 v3, 0
    0001: const-string v0, 'callChatList'
    0003: invoke-virtual {v5, v0, v3}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    0006: move-result v0
    0007: sget v1, Lcom/sec/chaton/util/p;->c:Z
    0009: if-eqz v1, 0023
    000b: new-instance v1, Ljava/lang/StringBuilder;
    000d: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0010: const-string v2, 'Shortcut or Notification: '
    0012: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0015: move-result-object v1
    0016: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0019: move-result-object v1
    001a: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001d: move-result-object v1
    001e: sget v2, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0020: invoke-static {v1, v2}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    0023: if-eqz v0, 0038
    0025: const-string v0, 'callChatList'
    0027: invoke-virtual {v5, v0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    002a: const-class v0, Lcom/sec/chaton/chat/ChatActivity;
    002c: invoke-virtual {v5, v4, v0}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;
    002f: const/high16 v0, 67108864 (0x4000000)
    0031: invoke-virtual {v5, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    0034: invoke-virtual {v4, v5}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    0037: return-void
    0038: const-string v0, 'chatType'
    003a: const/4 v1, -1
    003b: invoke-virtual {v5, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    003e: move-result v0
    003f: invoke-static {v0}, Lcom/sec/chaton/e/n;->a(I)Lcom/sec/chaton/e/n;
    0042: move-result-object v0
    0043: sget v1, Lcom/sec/chaton/e/n;->e:Lcom/sec/chaton/e/n;
    0045: if-ne v0, v1, 0037
    0047: invoke-static {v4}, Lcom/sec/chaton/chat/notification/a;->a(Landroid/content/Context;)Lcom/sec/chaton/chat/notification/a;
    004a: move-result-object v0
    004b: invoke-virtual {v0}, Lcom/sec/chaton/chat/notification/a;->b()V
    004e: new-instance v0, Lcom/sec/widget/a;
    0050: invoke-direct {v0, v4}, Lcom/sec/widget/a;-><init>(Landroid/content/Context;)V
    0053: const v1, 2131492888 (0x7f0c0018)
    0056: invoke-virtual {v0, v1}, Lcom/sec/widget/a;->setTitle(I)Landroid/app/AlertDialog$Builder;
    0059: move-result-object v0
    005a: const-string v1, 'Content'
    005c: invoke-virtual {v5, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    005f: move-result-object v1
    0060: invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    0063: move-result-object v0
    0064: const v1, 2130839166 (0x7f02067e)
    0067: invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setIcon(I)Landroid/app/AlertDialog$Builder;
    006a: move-result-object v0
    006b: const v1, 2131492971 (0x7f0c006b)
    006e: new-instance v2, Lcom/sec/chaton/bd;
    0070: invoke-direct {v2, v4}, Lcom/sec/chaton/bd;-><init>(Lcom/sec/chaton/TabActivity;)V
    0073: invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    0076: move-result-object v0
    0077: invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;
    007a: move-result-object v0
    007b: invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V
    007e: goto 0037

  [Direct Method] d(Lcom/sec/chaton/TabActivity;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/TabActivity;->e()V
    0003: return-void

  [Direct Method] e(Lcom/sec/chaton/TabActivity;) -> Landroid/content/BroadcastReceiver;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/TabActivity;->o:Landroid/content/BroadcastReceiver;
    0002: return-object v0

  [Direct Method] e() -> V
    // registers=6, ins=1, outs=4, insns_size=35
    0000: const/4 v4, 0
    0001: new-instance v0, Ljava/text/SimpleDateFormat;
    0003: const-string v1, 'yyyy-MM-dd'
    0005: invoke-direct {v0, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V
    0008: invoke-static {}, Ljava/lang/System;->currentTimeMillis()J
    000b: move-result-wide v1
    000c: invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;
    000f: move-result-object v1
    0010: invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/lang/Object;)Ljava/lang/String;
    0013: move-result-object v0
    0014: new-instance v1, Lcom/sec/chaton/e/a/t;
    0016: invoke-direct {v1}, Lcom/sec/chaton/e/a/t;-><init>()V
    0019: const/4 v2, -1
    001a: new-instance v3, Lcom/sec/chaton/e/b/s;
    001c: invoke-direct {v3, v4, v0, v4}, Lcom/sec/chaton/e/b/s;-><init>(Lcom/sec/chaton/e/b/d;Ljava/lang/String;Ljava/util/ArrayList;)V
    001f: invoke-static {v1, v2, v3}, Lcom/sec/chaton/e/a/t;->a(Lcom/sec/chaton/e/a/t;ILcom/sec/chaton/e/b/a;)V
    0022: return-void

  [Direct Method] e(Landroid/content/Intent;) -> V
    // registers=5, ins=2, outs=3, insns_size=62
    0000: const/4 v2, 0
    0001: sget v0, Lcom/sec/chaton/util/p;->c:Z
    0003: if-eqz v0, 0023
    0005: new-instance v0, Ljava/lang/StringBuilder;
    0007: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    000a: const-string v1, 'Shortcut or Notification: '
    000c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000f: move-result-object v0
    0010: const-string v1, 'callChatList'
    0012: invoke-virtual {v4, v1, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    0015: move-result v1
    0016: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0019: move-result-object v0
    001a: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001d: move-result-object v0
    001e: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0020: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    0023: const-string v0, 'callForward'
    0025: invoke-virtual {v4, v0, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    0028: move-result v0
    0029: if-eqz v0, 003d
    002b: const-string v0, 'callForward'
    002d: invoke-virtual {v4, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    0030: const-class v0, Lcom/sec/chaton/forward/ChatForwardActivity;
    0032: invoke-virtual {v4, v3, v0}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;
    0035: const/high16 v0, 67108864 (0x4000000)
    0037: invoke-virtual {v4, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    003a: invoke-virtual {v3, v4}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    003d: return-void

  [Direct Method] f() -> V
    // registers=3, ins=1, outs=3, insns_size=83
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0005: const-string v1, '[LIFE] initView, isTaskRoot: '
    0007: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000a: move-result-object v0
    000b: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->isTaskRoot()Z
    000e: move-result v1
    000f: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0012: move-result-object v0
    0013: const-string v1, ', Task ID: '
    0015: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0018: move-result-object v0
    0019: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->getTaskId()I
    001c: move-result v1
    001d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0020: move-result-object v0
    0021: const-string v1, ', Memory Address:'
    0023: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0026: move-result-object v0
    0027: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    002a: move-result-object v0
    002b: invoke-direct {v2}, Lcom/sec/chaton/TabActivity;->d()Ljava/lang/String;
    002e: move-result-object v1
    002f: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0032: move-result-object v0
    0033: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0036: move-result-object v0
    0037: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0039: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    003c: const v0, 2130903044 (0x7f030004)
    003f: invoke-virtual {v2, v0}, Lcom/sec/chaton/TabActivity;->setContentView(I)V
    0042: invoke-static {}, Lcom/sec/chaton/ExitAppDialogActivity;->a()Z
    0045: move-result v0
    0046: if-eqz v0, 0052
    0048: new-instance v0, Landroid/content/Intent;
    004a: const-class v1, Lcom/sec/chaton/ExitAppDialogActivity;
    004c: invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    004f: invoke-virtual {v2, v0}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    0052: return-void

  [Direct Method] f(Lcom/sec/chaton/TabActivity;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/TabActivity;->p()V
    0003: return-void

  [Direct Method] g(Lcom/sec/chaton/TabActivity;) -> Ljava/lang/String;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-direct {v1}, Lcom/sec/chaton/TabActivity;->o()Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] g() -> V
    // registers=9, ins=1, outs=6, insns_size=209
    0000: const-wide/32 v3, 60000
    0003: const-wide/32 v6, 86400000
    0006: new-instance v0, Lcom/sec/chaton/util/ay;
    0008: invoke-direct {v0}, Lcom/sec/chaton/util/ay;-><init>()V
    000b: iput v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    000d: return-void
    000e: nop
    000f: const-string v1, 'get_chaton_crypto_key'
    0011: iget v2, v8.Lcom/sec/chaton/TabActivity;->D:Lcom/sec/chaton/util/bb;
    0013: const-string v5, 'last_sync_time_get_chaton_crypto_key'
    0015: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    0018: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    001a: const-string v1, 'local_calculation'
    001c: iget v2, v8.Lcom/sec/chaton/TabActivity;->r:Lcom/sec/chaton/util/bb;
    001e: const-string v5, 'last_sync_time_on_start'
    0020: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    0023: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    0025: const-string v1, 'get_push_status'
    0027: iget v2, v8.Lcom/sec/chaton/TabActivity;->u:Lcom/sec/chaton/util/bb;
    0029: const-string v5, 'last_sync_time_get_push_status'
    002b: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    002e: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    0030: const-string v1, 'version_notice'
    0032: iget v2, v8.Lcom/sec/chaton/TabActivity;->x:Lcom/sec/chaton/util/bb;
    0034: const-wide/32 v3, 21600000
    0037: const-string v5, 'last_sync_time_get_version_notice'
    0039: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    003c: const-string v0, 'com.sec.spp.push'
    003e: invoke-static {v0}, Lcom/sec/chaton/util/bp;->b(Ljava/lang/String;)I
    0041: move-result v0
    0042: const/16 v1, 21 (0x15)
    0044: if-ge v0, v1, 00c2
    0046: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    0048: const-string v1, 'spp_update_check'
    004a: iget v2, v8.Lcom/sec/chaton/TabActivity;->y:Lcom/sec/chaton/util/bb;
    004c: const-wide/32 v3, 259200000
    004f: const-string v5, 'last_sync_time_get_spp_update_check'
    0051: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    0054: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    0056: const-string v1, 'chatonv_update_check'
    0058: iget v2, v8.Lcom/sec/chaton/TabActivity;->z:Lcom/sec/chaton/util/bb;
    005a: const-string v5, 'last_chatonv_upgrade_check'
    005c: move(op=04) v3, v6
    005d: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    0060: const-string v0, 'Added mChatonVUpgradeCheckTask to polling scheduler'
    0062: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0064: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0067: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    0069: const-string v1, 'notification'
    006b: iget v2, v8.Lcom/sec/chaton/TabActivity;->w:Lcom/sec/chaton/util/bb;
    006d: const-wide/32 v3, 1800000
    0070: const-string v5, 'last_sync_time_notification'
    0072: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    0075: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    0077: const-string v1, 'get_all_buddies'
    0079: iget v2, v8.Lcom/sec/chaton/TabActivity;->s:Lcom/sec/chaton/util/bb;
    007b: const-wide/32 v3, 10800000
    007e: const-string v5, 'last_sync_time_get_all_buddies'
    0080: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    0083: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    0085: const-string v1, 'recommendee_sync'
    0087: iget v2, v8.Lcom/sec/chaton/TabActivity;->A:Lcom/sec/chaton/util/bb;
    0089: const-string v5, 'last_recommendee_sync_time'
    008b: move(op=04) v3, v6
    008c: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    008f: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    0091: const-string v1, 'interaction_sync'
    0093: iget v2, v8.Lcom/sec/chaton/TabActivity;->B:Lcom/sec/chaton/util/bb;
    0095: const-string v5, 'last_Interaction_sync_time'
    0097: move(op=04) v3, v6
    0098: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    009b: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    009d: const-string v1, 'contactDB_reset'
    009f: iget v2, v8.Lcom/sec/chaton/TabActivity;->C:Lcom/sec/chaton/util/bb;
    00a1: const-string v5, 'last_contact_reset_time'
    00a3: move(op=04) v3, v6
    00a4: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    00a7: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    00a9: const-string v1, 'chatonv_available'
    00ab: iget v2, v8.Lcom/sec/chaton/TabActivity;->F:Lcom/sec/chaton/util/bb;
    00ad: const-string v5, 'last_chatonv_available_time'
    00af: move(op=04) v3, v6
    00b0: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    00b3: iget v0, v8.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    00b5: const-string v1, 'set_compatibility'
    00b7: iget v2, v8.Lcom/sec/chaton/TabActivity;->E:Lcom/sec/chaton/util/bb;
    00b9: const-wide/32 v3, 900000
    00bc: const-string v5, 'last_compatibility_time'
    00be: invoke-virtual/range {v0..v5}, Lcom/sec/chaton/util/ay;->a(Ljava/lang/String;Lcom/sec/chaton/util/bb;JLjava/lang/String;)V
    00c1: return-void
    00c2: sget v0, Lcom/sec/chaton/util/p;->b:Z
    00c4: if-eqz v0, 00cd
    00c6: const-string v0, "don't need to add poliing scheduler for SPP"
    00c8: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    00ca: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    00cd: invoke-direct {v8}, Lcom/sec/chaton/TabActivity;->i()V
    00d0: goto 0054

  [Direct Method] h() -> V
    // registers=4, ins=1, outs=3, insns_size=35
    0000: iget v0, v3.Lcom/sec/chaton/TabActivity;->o:Landroid/content/BroadcastReceiver;
    0002: if-nez v0, 0022
    0004: new-instance v0, Landroid/content/IntentFilter;
    0006: invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V
    0009: const-string v1, 'com.sec.chaton.ACTION_EXIT_APP'
    000b: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    000e: new-instance v1, Lcom/sec/chaton/bb;
    0010: invoke-direct {v1, v3}, Lcom/sec/chaton/bb;-><init>(Lcom/sec/chaton/TabActivity;)V
    0013: iput v1, v3.Lcom/sec/chaton/TabActivity;->o:Landroid/content/BroadcastReceiver;
    0015: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0018: move-result-object v1
    0019: invoke-static {v1}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    001c: move-result-object v1
    001d: iget v2, v3.Lcom/sec/chaton/TabActivity;->o:Landroid/content/BroadcastReceiver;
    001f: invoke-virtual {v1, v2, v0}, Landroid/support/v4/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    0022: return-void

  [Direct Method] i() -> V
    // registers=3, ins=1, outs=3, insns_size=27
    0000: return-void
    0001: nop
    0002: if-nez v0, 001a
    0004: new-instance v0, Landroid/content/IntentFilter;
    0006: invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V
    0009: const-string v1, 'action_noti_spp_update'
    000b: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    000e: new-instance v1, Lcom/sec/chaton/bc;
    0010: invoke-direct {v1, v2}, Lcom/sec/chaton/bc;-><init>(Lcom/sec/chaton/TabActivity;)V
    0013: iput v1, v2.Lcom/sec/chaton/TabActivity;->p:Landroid/content/BroadcastReceiver;
    0015: iget v1, v2.Lcom/sec/chaton/TabActivity;->p:Landroid/content/BroadcastReceiver;
    0017: invoke-virtual {v2, v1, v0}, Lcom/sec/chaton/TabActivity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    001a: return-void

  [Direct Method] j() -> Z
    // registers=3, ins=1, outs=2, insns_size=11
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'uid'
    0006: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0009: move-result v0
    000a: return v0

  [Direct Method] k() -> Z
    // registers=4, ins=1, outs=3, insns_size=20
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'UpdateIsCritical'
    0006: const/4 v2, 0
    0007: invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    000a: move-result-object v2
    000b: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    000e: move-result-object v0
    000f: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    0012: move-result v0
    0013: return v0

  [Direct Method] l() -> Z
    // registers=4, ins=1, outs=3, insns_size=12
    0000: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->getIntent()Landroid/content/Intent;
    0003: move-result-object v0
    0004: const-string v1, 'callRestart'
    0006: const/4 v2, 0
    0007: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    000a: move-result v0
    000b: return v0

  [Direct Method] m() -> Ljava/lang/String;
    // registers=4, ins=1, outs=3, insns_size=13
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'disclaimer_UID'
    0006: const-string v2, ''
    0008: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    000b: move-result-object v0
    000c: return-object v0

  [Direct Method] n() -> Z
    // registers=5, ins=1, outs=3, insns_size=24
    0000: const/high16 v3, 1048576 (0x100000)
    0002: const/4 v0, 0
    0003: invoke-virtual {v4}, Lcom/sec/chaton/TabActivity;->getIntent()Landroid/content/Intent;
    0006: move-result-object v1
    0007: const-string v2, 'finish'
    0009: invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    000c: move-result v2
    000d: if-eqz v2, 0017
    000f: invoke-virtual {v1}, Landroid/content/Intent;->getFlags()I
    0012: move-result v1
    0013: binop/2addr(op=b5) v1, v3
    0014: if-eq v1, v3, 0017
    0016: const/4 v0, 1
    0017: return v0

  [Direct Method] o() -> Ljava/lang/String;
    // registers=4, ins=1, outs=3, insns_size=13
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'update_disclaimer_status'
    0006: const-string v2, ''
    0008: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    000b: move-result-object v0
    000c: return-object v0

  [Direct Method] p() -> V
    // registers=4, ins=1, outs=2, insns_size=37
    0000: new-instance v0, Landroid/content/Intent;
    0002: const-string v1, 'com.sec.chaton.ACTION_DISMISS'
    0004: invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    0007: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->getApplicationContext()Landroid/content/Context;
    000a: move-result-object v1
    000b: invoke-static {v1}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    000e: move-result-object v1
    000f: invoke-virtual {v1, v0}, Landroid/support/v4/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z
    0012: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->getApplicationContext()Landroid/content/Context;
    0015: move-result-object v0
    0016: invoke-static {v0}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    0019: move-result-object v0
    001a: new-instance v1, Landroid/content/Intent;
    001c: const-string v2, 'more_tab_badge_update'
    001e: invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    0021: invoke-virtual {v0, v1}, Landroid/support/v4/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z
    0024: return-void

  [Direct Method] q() -> V
    // registers=4, ins=1, outs=3, insns_size=40
    0000: const-string v0, 'showPasswordLockActivity'
    0002: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0004: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0007: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->getApplicationContext()Landroid/content/Context;
    000a: move-result-object v0
    000b: invoke-static {v0}, Lcom/sec/chaton/util/j;->c(Landroid/content/Context;)Z
    000e: move-result v1
    000f: if-eqz v1, 0027
    0011: new-instance v1, Landroid/content/Intent;
    0013: const-class v2, Lcom/sec/chaton/settings/ActivityPasswordLockSet;
    0015: invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0018: const-string v0, 'MODE'
    001a: const-string v2, 'HOME'
    001c: invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    001f: const/high16 v0, 67108864 (0x4000000)
    0021: invoke-virtual {v1, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    0024: invoke-virtual {v3, v1}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    0027: return-void

  [Direct Method] r() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] a(Ljava/lang/String;) -> Lcom/sec/chaton/base/a;
    // registers=3, ins=2, outs=2, insns_size=14
    0000: const v0, 2131230731 (0x7f08000b)
    0003: invoke-virtual {v1, v0}, Lcom/sec/chaton/TabActivity;->findViewById(I)Landroid/view/View;
    0006: move-result-object v0
    0007: if-eqz v0, 0009
    0009: invoke-super {v1, v2}, Lcom/sec/chaton/base/BaseMultiPaneActivity;->a(Ljava/lang/String;)Lcom/sec/chaton/base/a;
    000c: move-result-object v0
    000d: return-object v0

  [Virtual Method] a() -> V
    // registers=4, ins=1, outs=3, insns_size=75
    0000: new-instance v0, Lcom/sec/widget/a;
    0002: invoke-direct {v0, v3}, Lcom/sec/widget/a;-><init>(Landroid/content/Context;)V
    0005: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->getResources()Landroid/content/res/Resources;
    0008: move-result-object v1
    0009: const v2, 2131493709 (0x7f0c034d)
    000c: invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    000f: move-result-object v1
    0010: invoke-virtual {v0, v1}, Lcom/sec/widget/a;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    0013: move-result-object v0
    0014: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->getResources()Landroid/content/res/Resources;
    0017: move-result-object v1
    0018: const v2, 2131494226 (0x7f0c0552)
    001b: invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    001e: move-result-object v1
    001f: invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    0022: move-result-object v0
    0023: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->getResources()Landroid/content/res/Resources;
    0026: move-result-object v1
    0027: const v2, 2131492971 (0x7f0c006b)
    002a: invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    002d: move-result-object v1
    002e: new-instance v2, Lcom/sec/chaton/ap;
    0030: invoke-direct {v2, v3}, Lcom/sec/chaton/ap;-><init>(Lcom/sec/chaton/TabActivity;)V
    0033: invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    0036: move-result-object v0
    0037: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->getResources()Landroid/content/res/Resources;
    003a: move-result-object v1
    003b: const v2, 2131492973 (0x7f0c006d)
    003e: invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    0041: move-result-object v1
    0042: const/4 v2, 0
    0043: invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    0046: move-result-object v0
    0047: invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;
    004a: return-void

  [Virtual Method] b(Landroid/content/Context;) -> Ljava/lang/String;
    // registers=5, ins=2, outs=2, insns_size=51
    0000: const-string v0, 'activity'
    0002: invoke-virtual {v4, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/app/ActivityManager;
    0008: const/4 v1, 1
    0009: invoke-virtual {v0, v1}, Landroid/app/ActivityManager;->getRunningTasks(I)Ljava/util/List;
    000c: move-result-object v0
    000d: const/4 v1, 0
    000e: invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0011: move-result-object v0
    0012: check-cast v0, Landroid/app/ActivityManager$RunningTaskInfo;
    0014: iget v0, v0.Landroid/app/ActivityManager$RunningTaskInfo;->topActivity:Landroid/content/ComponentName;
    0016: invoke-virtual {v0}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;
    0019: move-result-object v0
    001a: new-instance v1, Ljava/lang/StringBuilder;
    001c: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    001f: const-string v2, 'getClassName : '
    0021: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0024: move-result-object v1
    0025: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0028: move-result-object v1
    0029: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002c: move-result-object v1
    002d: const-string v2, 'HomeActivity'
    002f: invoke-static {v1, v2}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0032: return-object v0

  [Virtual Method] b() -> V
    // registers=4, ins=1, outs=3, insns_size=46
    0000: const-string v0, 'layout_inflater'
    0002: invoke-virtual {v3, v0}, Lcom/sec/chaton/TabActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/view/LayoutInflater;
    0008: const v2, 2130903339 (0x7f03012b)
    000b: const v1, 2131232221 (0x7f0805dd)
    000e: invoke-virtual {v3, v1}, Lcom/sec/chaton/TabActivity;->findViewById(I)Landroid/view/View;
    0011: move-result-object v1
    0012: check-cast v1, Landroid/view/ViewGroup;
    0014: invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;
    0017: move-result-object v0
    0018: iput v0, v3.Lcom/sec/chaton/TabActivity;->l:Landroid/view/View;
    001a: iget v0, v3.Lcom/sec/chaton/TabActivity;->l:Landroid/view/View;
    001c: const v1, 2131231274 (0x7f08022a)
    001f: invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0022: move-result-object v0
    0023: check-cast v0, Landroid/widget/CheckBox;
    0025: new-instance v1, Lcom/sec/chaton/bj;
    0027: invoke-direct {v1, v3}, Lcom/sec/chaton/bj;-><init>(Lcom/sec/chaton/TabActivity;)V
    002a: invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V
    002d: return-void

  [Virtual Method] dispatchKeyEvent(Landroid/view/KeyEvent;) -> Z
    // registers=6, ins=2, outs=2, insns_size=118
    0000: invoke-virtual {v4}, Lcom/sec/chaton/TabActivity;->getSupportFragmentManager()Landroid/support/v4/app/FragmentManager;
    0003: move-result-object v0
    0004: const v1, 2131230727 (0x7f080007)
    0007: invoke-virtual {v0, v1}, Landroid/support/v4/app/FragmentManager;->findFragmentById(I)Landroid/support/v4/app/Fragment;
    000a: move-result-object v0
    000b: check-cast v0, Lcom/sec/chaton/HomeTabFragment;
    000d: invoke-virtual {v4}, Lcom/sec/chaton/TabActivity;->getSupportFragmentManager()Landroid/support/v4/app/FragmentManager;
    0010: move-result-object v1
    0011: const v2, 2131230722 (0x7f080002)
    0014: invoke-virtual {v1, v2}, Landroid/support/v4/app/FragmentManager;->findFragmentById(I)Landroid/support/v4/app/Fragment;
    0017: move-result-object v1
    0018: check-cast v1, Lcom/sec/chaton/buddy/BuddyFragment;
    001a: sget v2, Lcom/sec/chaton/util/p;->b:Z
    001c: if-eqz v2, 003a
    001e: new-instance v2, Ljava/lang/StringBuilder;
    0020: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0023: const-string v3, 'dispatchKeyEvent : KeyCode = '
    0025: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0028: move-result-object v2
    0029: invoke-virtual {v5}, Landroid/view/KeyEvent;->getKeyCode()I
    002c: move-result v3
    002d: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0030: move-result-object v2
    0031: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0034: move-result-object v2
    0035: sget v3, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0037: invoke-static {v2, v3}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    003a: invoke-virtual {v5}, Landroid/view/KeyEvent;->getKeyCode()I
    003d: move-result v2
    003e: const/16 v3, 84 (0x54)
    0040: if-ne v2, v3, 0071
    0042: if-eqz v0, 006f
    0044: if-eqz v1, 006f
    0046: sget v2, Lcom/sec/chaton/util/p;->b:Z
    0048: if-eqz v2, 0066
    004a: new-instance v2, Ljava/lang/StringBuilder;
    004c: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    004f: const-string v3, 'dispatchKeyEvent : Current Tab ID = '
    0051: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0054: move-result-object v2
    0055: invoke-virtual {v0}, Lcom/sec/chaton/HomeTabFragment;->a()I
    0058: move-result v3
    0059: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    005c: move-result-object v2
    005d: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0060: move-result-object v2
    0061: sget v3, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0063: invoke-static {v2, v3}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0066: invoke-virtual {v0}, Lcom/sec/chaton/HomeTabFragment;->a()I
    0069: move-result v0
    006a: if-nez v0, 006f
    006c: invoke-virtual {v1}, Lcom/sec/chaton/buddy/BuddyFragment;->i()V
    006f: const/4 v0, 1
    0070: return v0
    0071: invoke-super {v4, v5}, Lcom/sec/chaton/base/BaseMultiPaneActivity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    0074: move-result v0
    0075: goto 0070

  [Virtual Method] onActivityResult(I, I, Landroid/content/Intent;) -> V
    // registers=7, ins=4, outs=4, insns_size=192
    0000: const/4 v0, -1
    0001: const/4 v2, 0
    0002: invoke-super {v3, v4, v5, v6}, Lcom/sec/chaton/base/BaseMultiPaneActivity;->onActivityResult(IILandroid/content/Intent;)V
    0005: packed-switch v4, +173 (-> 00b2)
    0008: return-void
    0009: if-ne v5, v0, 001a
    000b: const-string v0, 'update_disclaimer_status'
    000d: const-string v1, 'DONE'
    000f: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/String;)V
    0012: const-string v0, 'Success in accpet disclaimer'
    0014: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0016: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0019: goto 0008
    001a: const/4 v0, 2
    001b: if-ne v5, v0, 0008
    001d: const-string v0, 'update_disclaimer_status'
    001f: const-string v1, 'DONE'
    0021: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/String;)V
    0024: goto 0008
    0025: if-ne v5, v0, 0039
    0027: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    002a: move-result-object v0
    002b: invoke-static {v0, v2}, Lcom/sec/chaton/localbackup/noti/a;->a(Landroid/content/Context;Z)V
    002e: const-string v0, 'setting_backup_enable'
    0030: const/4 v1, 1
    0031: invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0034: move-result-object v1
    0035: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Boolean;)V
    0038: goto 0008
    0039: if-nez v5, 0008
    003b: const-string v0, 'auto_backup_on'
    003d: invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0040: move-result-object v1
    0041: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Boolean;)V
    0044: goto 0008
    0045: if-ne v5, v0, 0072
    0047: sget v0, Lcom/sec/chaton/util/p;->b:Z
    0049: if-eqz v0, 0052
    004b: const-string v0, 'Success in Contact sync after registration'
    004d: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    004f: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0052: const-string v0, 'local_backup_feature'
    0054: invoke-static {v0}, Lcom/sec/chaton/global/a;->a(Ljava/lang/String;)Z
    0057: move-result v0
    0058: if-eqz v0, 0008
    005a: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    005d: move-result-object v0
    005e: const-string v1, 'auto_backup_on'
    0060: invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0063: move-result-object v2
    0064: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    0067: move-result-object v0
    0068: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    006b: move-result v0
    006c: if-nez v0, 0008
    006e: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->a()V
    0071: goto 0008
    0072: const/4 v0, 3
    0073: if-ne v5, v0, 00a1
    0075: sget v0, Lcom/sec/chaton/util/p;->b:Z
    0077: if-eqz v0, 0080
    0079: const-string v0, 'Skip in Contact sync after registration'
    007b: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    007d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0080: const-string v0, 'local_backup_feature'
    0082: invoke-static {v0}, Lcom/sec/chaton/global/a;->a(Ljava/lang/String;)Z
    0085: move-result v0
    0086: if-eqz v0, 0008
    0088: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    008b: move-result-object v0
    008c: const-string v1, 'auto_backup_on'
    008e: invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0091: move-result-object v2
    0092: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    0095: move-result-object v0
    0096: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    0099: move-result v0
    009a: if-nez v0, 0008
    009c: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->a()V
    009f: goto/16 0008
    00a1: sget v0, Lcom/sec/chaton/util/p;->b:Z
    00a3: if-eqz v0, 00ac
    00a5: const-string v0, 'Cancel in Contact sync after registration'
    00a7: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    00a9: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    00ac: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->finish()V
    00af: goto/16 0008
    00b1: nop
    00b2: packed-switch-payload first=1 targets=[4, 64, 3, 3, 32]

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=9, ins=2, outs=3, insns_size=370
    0000: const v6, 2130903044 (0x7f030004)
    0003: const/4 v5, 1
    0004: const/4 v4, 0
    0005: invoke-super {v7, v8}, Lcom/sec/chaton/base/BaseMultiPaneActivity;->onCreate(Landroid/os/Bundle;)V
    0008: invoke-virtual {v7}, Lcom/sec/chaton/TabActivity;->getIntent()Landroid/content/Intent;
    000b: move-result-object v1
    000c: invoke-static {}, Lcom/sec/chaton/util/bx;->d()Z
    000f: move-result v0
    0010: if-nez v0, 002f
    0012: sget v0, Lcom/sec/chaton/util/p;->d:Z
    0014: if-eqz v0, 001d
    0016: const-string v0, "There isn't enough memory for executing ChatON."
    0018: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    001a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->d(Ljava/lang/String;Ljava/lang/String;)V
    001d: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0020: move-result-object v0
    0021: const v1, 2131493699 (0x7f0c0343)
    0024: invoke-static {v0, v1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;
    0027: move-result-object v0
    0028: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    002b: invoke-virtual {v7}, Lcom/sec/chaton/TabActivity;->finish()V
    002e: return-void
    002f: invoke-direct {v7}, Lcom/sec/chaton/TabActivity;->n()Z
    0032: move-result v0
    0033: if-eqz v0, 0044
    0035: sget v0, Lcom/sec/chaton/util/p;->c:Z
    0037: if-eqz v0, 0040
    0039: const-string v0, 'HomeActivity is requested finish.'
    003b: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    003d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    0040: invoke-virtual {v7}, Lcom/sec/chaton/TabActivity;->finish()V
    0043: goto 002e
    0044: sget v0, Lcom/sec/chaton/c/a;->f:Z
    0046: if-eqz v0, 007a
    0048: sget v0, Lcom/sec/chaton/util/p;->b:Z
    004a: if-eqz v0, 0053
    004c: const-string v0, 'Welcome, First Time after update ChatON.'
    004e: sget v2, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0050: invoke-static {v0, v2}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0053: invoke-direct {v7}, Lcom/sec/chaton/TabActivity;->r()V
    0056: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0059: move-result-object v0
    005a: const-string v2, 'Setting Sync TimeInMillis'
    005c: const-string v3, '0'
    005e: invoke-virtual {v0, v2, v3}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;Ljava/lang/String;)V
    0061: invoke-static {}, Lcom/sec/chaton/util/ac;->v()V
    0064: const-string v0, 'chaton_version'
    0066: sget v2, Lcom/sec/chaton/c/a;->b:Ljava/lang/String;
    0068: invoke-static {v0, v2}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/String;)V
    006b: sput v4, Lcom/sec/chaton/c/a;->f:Z
    006d: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0070: move-result-object v0
    0071: const-string v2, 'buddy_get_all_buddy_mode_instance'
    0073: invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0076: move-result-object v3
    0077: invoke-virtual {v0, v2, v3}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;Ljava/lang/Boolean;)V
    007a: invoke-direct {v7}, Lcom/sec/chaton/TabActivity;->k()Z
    007d: move-result v0
    007e: if-eqz v0, 009d
    0080: invoke-virtual {v7, v6}, Lcom/sec/chaton/TabActivity;->setContentView(I)V
    0083: const-string v0, 'wifi_80_port'
    0085: invoke-static {v0}, Lcom/sec/chaton/global/a;->a(Ljava/lang/String;)Z
    0088: move-result v0
    0089: if-eqz v0, 002e
    008b: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    008e: move-result-object v0
    008f: const-string v1, 'wifi_port'
    0091: invoke-static {}, Lcom/sec/chaton/util/at;->d()I
    0094: move-result v2
    0095: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0098: move-result-object v2
    0099: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;Ljava/lang/Integer;)V
    009c: goto 002e
    009d: invoke-direct {v7}, Lcom/sec/chaton/TabActivity;->o()Ljava/lang/String;
    00a0: move-result-object v0
    00a1: const-string v2, 'RUN'
    00a3: invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    00a6: move-result v0
    00a7: if-eqz v0, 00ad
    00a9: invoke-virtual {v7, v6}, Lcom/sec/chaton/TabActivity;->setContentView(I)V
    00ac: goto 0083
    00ad: invoke-direct {v7}, Lcom/sec/chaton/TabActivity;->j()Z
    00b0: move-result v0
    00b1: if-nez v0, 00bf
    00b3: invoke-virtual {v7}, Lcom/sec/chaton/TabActivity;->finish()V
    00b6: invoke-static {v7}, Lcom/sec/chaton/HomeActivity;->a(Landroid/content/Context;)Landroid/content/Intent;
    00b9: move-result-object v0
    00ba: invoke-virtual {v7, v0}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    00bd: goto/16 002e
    00bf: invoke-virtual {v7}, Lcom/sec/chaton/TabActivity;->b()V
    00c2: invoke-direct {v7}, Lcom/sec/chaton/TabActivity;->h()V
    00c5: invoke-direct {v7}, Lcom/sec/chaton/TabActivity;->g()V
    00c8: if-nez v8, 00d8
    00ca: sget v0, Lcom/sec/chaton/TabActivity;->a:Ljava/lang/String;
    00cc: invoke-virtual {v1, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;
    00cf: move-result-object v0
    00d0: check-cast v0, Landroid/content/Intent;
    00d2: if-nez v0, 00d5
    00d4: move(op=07) v0, v1
    00d5: invoke-direct {v7, v0}, Lcom/sec/chaton/TabActivity;->c(Landroid/content/Intent;)V
    00d8: if-nez v8, 00f8
    00da: const-string v0, 'extra_from_chaton'
    00dc: invoke-virtual {v1, v0, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    00df: move-result v0
    00e0: if-nez v0, 00f8
    00e2: iget v0, v7.Lcom/sec/chaton/TabActivity;->k:Lcom/sec/chaton/s;
    00e4: sget v1, Lcom/sec/chaton/s;->c:Lcom/sec/chaton/s;
    00e6: if-ne v0, v1, 00f8
    00e8: invoke-static {}, Lcom/sec/chaton/event/f;->c()Z
    00eb: move-result v0
    00ec: if-eqz v0, 00f8
    00ee: new-instance v0, Landroid/content/Intent;
    00f0: const-class v1, Lcom/sec/chaton/event/EventDialog;
    00f2: invoke-direct {v0, v7, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    00f5: invoke-virtual {v7, v0}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    00f8: invoke-direct {v7}, Lcom/sec/chaton/TabActivity;->f()V
    00fb: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    00fe: move-result-object v0
    00ff: const-string v1, 'first_time_after_regi'
    0101: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0104: move-result-object v2
    0105: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    0108: move-result-object v0
    0109: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    010c: move-result v0
    010d: if-ne v0, v5, 0137
    010f: const-string v0, 'local_backup_feature'
    0111: invoke-static {v0}, Lcom/sec/chaton/global/a;->a(Ljava/lang/String;)Z
    0114: move-result v0
    0115: if-eqz v0, 012e
    0117: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    011a: move-result-object v0
    011b: const-string v1, 'auto_backup_on'
    011d: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0120: move-result-object v2
    0121: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    0124: move-result-object v0
    0125: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    0128: move-result v0
    0129: if-nez v0, 012e
    012b: invoke-virtual {v7}, Lcom/sec/chaton/TabActivity;->a()V
    012e: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0131: move-result-object v0
    0132: const-string v1, 'first_time_after_regi'
    0134: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;)V
    0137: sput v5, Lcom/sec/chaton/global/GlobalApplication;->k:Z
    0139: const-string v0, 'onCreate : set setShowPasswordLock value'
    013b: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    013d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0140: invoke-virtual {v7}, Lcom/sec/chaton/TabActivity;->getIntent()Landroid/content/Intent;
    0143: move-result-object v0
    0144: const-string v1, 'extra_from_chaton'
    0146: invoke-virtual {v0, v1, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    0149: move-result v0
    014a: if-ne v0, v5, 0151
    014c: invoke-static {v4}, Lcom/sec/chaton/util/j;->a(Z)V
    014f: goto/16 0083
    0151: if-eqz v8, 016d
    0153: new-instance v0, Ljava/lang/StringBuilder;
    0155: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0158: const-string v1, 'savedInstanceState'
    015a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    015d: move-result-object v0
    015e: invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0161: move-result-object v0
    0162: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0165: move-result-object v0
    0166: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0168: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    016b: goto/16 0083
    016d: invoke-static {v5}, Lcom/sec/chaton/util/j;->a(Z)V
    0170: goto/16 0083

  [Virtual Method] onDestroy() -> V
    // registers=4, ins=1, outs=2, insns_size=112
    0000: const/4 v2, 0
    0001: invoke-super {v3}, Lcom/sec/chaton/base/BaseMultiPaneActivity;->onDestroy()V
    0004: new-instance v0, Ljava/lang/StringBuilder;
    0006: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0009: const-string v1, '[LIFE] onDestroy, isTaskRoot: '
    000b: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000e: move-result-object v0
    000f: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->isTaskRoot()Z
    0012: move-result v1
    0013: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0016: move-result-object v0
    0017: const-string v1, ', Task ID: '
    0019: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: move-result-object v0
    001d: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->getTaskId()I
    0020: move-result v1
    0021: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0024: move-result-object v0
    0025: const-string v1, ', Memory Address:'
    0027: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002a: move-result-object v0
    002b: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    002e: move-result-object v0
    002f: invoke-direct {v3}, Lcom/sec/chaton/TabActivity;->d()Ljava/lang/String;
    0032: move-result-object v1
    0033: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0036: move-result-object v0
    0037: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    003a: move-result-object v0
    003b: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    003d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    0040: iget v0, v3.Lcom/sec/chaton/TabActivity;->o:Landroid/content/BroadcastReceiver;
    0042: if-eqz v0, 0053
    0044: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0047: move-result-object v0
    0048: invoke-static {v0}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    004b: move-result-object v0
    004c: iget v1, v3.Lcom/sec/chaton/TabActivity;->o:Landroid/content/BroadcastReceiver;
    004e: invoke-virtual {v0, v1}, Landroid/support/v4/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    0051: iput v2, v3.Lcom/sec/chaton/TabActivity;->o:Landroid/content/BroadcastReceiver;
    0053: iget v0, v3.Lcom/sec/chaton/TabActivity;->p:Landroid/content/BroadcastReceiver;
    0055: if-eqz v0, 005e
    0057: iget v0, v3.Lcom/sec/chaton/TabActivity;->p:Landroid/content/BroadcastReceiver;
    0059: invoke-virtual {v3, v0}, Lcom/sec/chaton/TabActivity;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    005c: iput v2, v3.Lcom/sec/chaton/TabActivity;->p:Landroid/content/BroadcastReceiver;
    005e: iget v0, v3.Lcom/sec/chaton/TabActivity;->n:Landroid/app/AlertDialog;
    0060: if-eqz v0, 006f
    0062: iget v0, v3.Lcom/sec/chaton/TabActivity;->n:Landroid/app/AlertDialog;
    0064: invoke-virtual {v0}, Landroid/app/AlertDialog;->isShowing()Z
    0067: move-result v0
    0068: if-eqz v0, 006f
    006a: iget v0, v3.Lcom/sec/chaton/TabActivity;->n:Landroid/app/AlertDialog;
    006c: invoke-virtual {v0}, Landroid/app/AlertDialog;->dismiss()V
    006f: return-void

  [Virtual Method] onNewIntent(Landroid/content/Intent;) -> V
    // registers=4, ins=2, outs=2, insns_size=119
    0000: invoke-super {v2, v3}, Lcom/sec/chaton/base/BaseMultiPaneActivity;->onNewIntent(Landroid/content/Intent;)V
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0008: const-string v1, '[LIFE] onNewIntent, isTaskRoot: '
    000a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000d: move-result-object v0
    000e: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->isTaskRoot()Z
    0011: move-result v1
    0012: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0015: move-result-object v0
    0016: const-string v1, ', Task ID: '
    0018: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001b: move-result-object v0
    001c: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->getTaskId()I
    001f: move-result v1
    0020: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0023: move-result-object v0
    0024: const-string v1, ', Memory Address:'
    0026: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0029: move-result-object v0
    002a: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    002d: move-result-object v0
    002e: invoke-direct {v2}, Lcom/sec/chaton/TabActivity;->d()Ljava/lang/String;
    0031: move-result-object v1
    0032: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0035: move-result-object v0
    0036: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0039: move-result-object v0
    003a: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    003c: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    003f: invoke-virtual {v2, v3}, Lcom/sec/chaton/TabActivity;->setIntent(Landroid/content/Intent;)V
    0042: invoke-direct {v2}, Lcom/sec/chaton/TabActivity;->n()Z
    0045: move-result v0
    0046: if-eqz v0, 004c
    0048: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->finish()V
    004b: return-void
    004c: invoke-direct {v2}, Lcom/sec/chaton/TabActivity;->l()Z
    004f: move-result v0
    0050: if-eqz v0, 005d
    0052: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->finish()V
    0055: invoke-static {v2}, Lcom/sec/chaton/TabActivity;->a(Landroid/content/Context;)Landroid/content/Intent;
    0058: move-result-object v0
    0059: invoke-virtual {v2, v0}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    005c: goto 004b
    005d: sget v0, Lcom/sec/chaton/TabActivity;->a:Ljava/lang/String;
    005f: invoke-virtual {v3, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;
    0062: move-result-object v0
    0063: check-cast v0, Landroid/content/Intent;
    0065: if-nez v0, 0075
    0067: invoke-direct {v2, v3}, Lcom/sec/chaton/TabActivity;->c(Landroid/content/Intent;)V
    006a: invoke-static {}, Lcom/sec/chaton/util/j;->b()Z
    006d: move-result v0
    006e: if-eqz v0, 004b
    0070: const/4 v0, 1
    0071: invoke-static {v0}, Lcom/sec/chaton/util/j;->a(Z)V
    0074: goto 004b
    0075: move(op=07) v3, v0
    0076: goto 0067

  [Virtual Method] onPause() -> V
    // registers=3, ins=1, outs=2, insns_size=64
    0000: invoke-super {v2}, Lcom/sec/chaton/base/BaseMultiPaneActivity;->onPause()V
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0008: const-string v1, '[LIFE] onPause, isTaskRoot: '
    000a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000d: move-result-object v0
    000e: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->isTaskRoot()Z
    0011: move-result v1
    0012: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0015: move-result-object v0
    0016: const-string v1, ', Task ID: '
    0018: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001b: move-result-object v0
    001c: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->getTaskId()I
    001f: move-result v1
    0020: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0023: move-result-object v0
    0024: const-string v1, ', Memory Address:'
    0026: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0029: move-result-object v0
    002a: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    002d: move-result-object v0
    002e: invoke-direct {v2}, Lcom/sec/chaton/TabActivity;->d()Ljava/lang/String;
    0031: move-result-object v1
    0032: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0035: move-result-object v0
    0036: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0039: move-result-object v0
    003a: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    003c: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    003f: return-void

  [Virtual Method] onResume() -> V
    // registers=4, ins=1, outs=3, insns_size=103
    0000: invoke-super {v3}, Lcom/sec/chaton/base/BaseMultiPaneActivity;->onResume()V
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0008: const-string v1, '[LIFE] onResume, isTaskRoot: '
    000a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000d: move-result-object v0
    000e: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->isTaskRoot()Z
    0011: move-result v1
    0012: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0015: move-result-object v0
    0016: const-string v1, ', Task ID: '
    0018: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001b: move-result-object v0
    001c: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->getTaskId()I
    001f: move-result v1
    0020: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0023: move-result-object v0
    0024: const-string v1, ', Memory Address:'
    0026: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0029: move-result-object v0
    002a: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    002d: move-result-object v0
    002e: invoke-direct {v3}, Lcom/sec/chaton/TabActivity;->d()Ljava/lang/String;
    0031: move-result-object v1
    0032: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0035: move-result-object v0
    0036: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0039: move-result-object v0
    003a: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    003c: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    003f: invoke-static {}, Lcom/sec/chaton/util/bx;->d()Z
    0042: move-result v0
    0043: if-nez v0, 0063
    0045: sget v0, Lcom/sec/chaton/util/p;->d:Z
    0047: if-eqz v0, 0050
    0049: const-string v0, "There isn't enough memory for executing ChatON."
    004b: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    004d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->d(Ljava/lang/String;Ljava/lang/String;)V
    0050: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0053: move-result-object v0
    0054: const v1, 2131493699 (0x7f0c0343)
    0057: const/4 v2, 0
    0058: invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;
    005b: move-result-object v0
    005c: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    005f: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->finish()V
    0062: return-void
    0063: invoke-direct {v3}, Lcom/sec/chaton/TabActivity;->q()V
    0066: goto 0062

  [Virtual Method] onStart() -> V
    // registers=4, ins=1, outs=3, insns_size=131
    0000: const/4 v2, 1
    0001: invoke-super {v3}, Lcom/sec/chaton/base/BaseMultiPaneActivity;->onStart()V
    0004: new-instance v0, Ljava/lang/StringBuilder;
    0006: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0009: const-string v1, '[LIFE] onStart, isTaskRoot: '
    000b: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000e: move-result-object v0
    000f: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->isTaskRoot()Z
    0012: move-result v1
    0013: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0016: move-result-object v0
    0017: const-string v1, ', Task ID: '
    0019: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: move-result-object v0
    001d: invoke-virtual {v3}, Lcom/sec/chaton/TabActivity;->getTaskId()I
    0020: move-result v1
    0021: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0024: move-result-object v0
    0025: const-string v1, ', Memory Address:'
    0027: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002a: move-result-object v0
    002b: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    002e: move-result-object v0
    002f: invoke-direct {v3}, Lcom/sec/chaton/TabActivity;->d()Ljava/lang/String;
    0032: move-result-object v1
    0033: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0036: move-result-object v0
    0037: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    003a: move-result-object v0
    003b: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    003d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    0040: invoke-direct {v3}, Lcom/sec/chaton/TabActivity;->k()Z
    0043: move-result v0
    0044: if-eqz v0, 0065
    0046: new-instance v0, Landroid/content/Intent;
    0048: const-class v1, Lcom/sec/chaton/UpgradeDialog;
    004a: invoke-direct {v0, v3, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    004d: const-string v1, 'isCritical'
    004f: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    0052: const-string v1, 'isFromHome'
    0054: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    0057: invoke-virtual {v3, v0}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    005a: new-instance v0, Lcom/sec/chaton/d/az;
    005c: iget v1, v3.Lcom/sec/chaton/TabActivity;->c:Landroid/os/Handler;
    005e: invoke-direct {v0, v1}, Lcom/sec/chaton/d/az;-><init>(Landroid/os/Handler;)V
    0061: invoke-virtual {v0}, Lcom/sec/chaton/d/az;->b()Lcom/sec/chaton/d/a/cj;
    0064: return-void
    0065: invoke-direct {v3}, Lcom/sec/chaton/TabActivity;->o()Ljava/lang/String;
    0068: move-result-object v0
    0069: const-string v1, 'RUN'
    006b: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    006e: move-result v0
    006f: if-eqz v0, 0079
    0071: invoke-direct {v3}, Lcom/sec/chaton/TabActivity;->m()Ljava/lang/String;
    0074: move-result-object v0
    0075: invoke-direct {v3, v0}, Lcom/sec/chaton/TabActivity;->b(Ljava/lang/String;)V
    0078: goto 0064
    0079: iget v0, v3.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    007b: if-eqz v0, 0064
    007d: iget v0, v3.Lcom/sec/chaton/TabActivity;->q:Lcom/sec/chaton/util/ay;
    007f: invoke-virtual {v0}, Lcom/sec/chaton/util/ay;->a()V
    0082: goto 0064

  [Virtual Method] onStop() -> V
    // registers=3, ins=1, outs=2, insns_size=64
    0000: invoke-super {v2}, Lcom/sec/chaton/base/BaseMultiPaneActivity;->onStop()V
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0008: const-string v1, '[LIFE] onStop, isTaskRoot: '
    000a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000d: move-result-object v0
    000e: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->isTaskRoot()Z
    0011: move-result v1
    0012: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0015: move-result-object v0
    0016: const-string v1, ', Task ID: '
    0018: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001b: move-result-object v0
    001c: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->getTaskId()I
    001f: move-result v1
    0020: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0023: move-result-object v0
    0024: const-string v1, ', Memory Address:'
    0026: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0029: move-result-object v0
    002a: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    002d: move-result-object v0
    002e: invoke-direct {v2}, Lcom/sec/chaton/TabActivity;->d()Ljava/lang/String;
    0031: move-result-object v1
    0032: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0035: move-result-object v0
    0036: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0039: move-result-object v0
    003a: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    003c: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    003f: return-void

  [Virtual Method] onUserLeaveHint() -> V
    // registers=3, ins=1, outs=2, insns_size=15
    0000: const-string v0, 'onUserLeaveHint'
    0002: sget v1, Lcom/sec/chaton/TabActivity;->g:Ljava/lang/String;
    0004: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0007: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->getApplicationContext()Landroid/content/Context;
    000a: move-result-object v0
    000b: invoke-static {v0}, Lcom/sec/chaton/util/j;->b(Landroid/content/Context;)V
    000e: return-void