=== CLASS Lcom/sec/chaton/HomePhoneFragment; (Source: HomePhoneFragment.java) ===
  Super: Landroid/support/v4/app/Fragment;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/app/Fragment;-><init>()V
    0003: return-void

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-super {v0, v1}, Landroid/support/v4/app/Fragment;->onCreate(Landroid/os/Bundle;)V
    0003: return-void

  [Virtual Method] onCreateView(Landroid/view/LayoutInflater;, Landroid/view/ViewGroup;, Landroid/os/Bundle;) -> Landroid/view/View;
    // registers=6, ins=4, outs=4, insns_size=9
    0000: const v0, 2130903045 (0x7f030005)
    0003: const/4 v1, 0
    0004: invoke-virtual {v3, v0, v4, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;
    0007: move-result-object v0
    0008: return-object v0