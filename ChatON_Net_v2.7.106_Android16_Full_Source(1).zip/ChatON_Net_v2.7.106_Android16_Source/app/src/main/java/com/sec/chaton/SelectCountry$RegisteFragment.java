=== CLASS Lcom/sec/chaton/SelectCountry$RegisteFragment; (Source: SelectCountry.java) ===
  Super: Landroid/support/v4/app/Fragment;
  [Instance Field] a: I
  [Instance Field] b: I
  [Instance Field] c: Ljava/util/Map;
  [Instance Field] d: [Ljava/lang/CharSequence;
  [Instance Field] e: [Ljava/lang/CharSequence;
  [Instance Field] f: Ljava/lang/String;
  [Instance Field] g: Lcom/sec/chaton/b/b;
  [Instance Field] h: Landroid/content/Context;

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=14
    0000: invoke-direct {v1}, Landroid/support/v4/app/Fragment;-><init>()V
    0003: const/16 v0, 16 (0x10)
    0005: iput v0, v1.Lcom/sec/chaton/SelectCountry$RegisteFragment;->a:I
    0007: const/4 v0, 0
    0008: iput v0, v1.Lcom/sec/chaton/SelectCountry$RegisteFragment;->b:I
    000a: const/4 v0, 0
    000b: iput v0, v1.Lcom/sec/chaton/SelectCountry$RegisteFragment;->g:Lcom/sec/chaton/b/b;
    000d: return-void

  [Virtual Method] onActivityResult(I, I, Landroid/content/Intent;) -> V
    // registers=8, ins=4, outs=2, insns_size=152
    0000: const/4 v3, -1
    0001: packed-switch v5, +145 (-> 0092)
    0004: return-void
    0005: if-ne v6, v3, 0076
    0007: invoke-virtual {v7}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    000a: move-result-object v0
    000b: const-string v1, 'PARAMS_COUNTRY_NAME'
    000d: invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    0010: move-result-object v0
    0011: iput v0, v4.Lcom/sec/chaton/SelectCountry$RegisteFragment;->f:Ljava/lang/String;
    0013: iget v0, v4.Lcom/sec/chaton/SelectCountry$RegisteFragment;->f:Ljava/lang/String;
    0015: if-eqz v0, 0068
    0017: iget v0, v4.Lcom/sec/chaton/SelectCountry$RegisteFragment;->c:Ljava/util/Map;
    0019: iget v1, v4.Lcom/sec/chaton/SelectCountry$RegisteFragment;->f:Ljava/lang/String;
    001b: invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;
    001e: move-result-object v0
    001f: invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;
    0022: move-result-object v0
    0023: const-string v1, 'country_letter'
    0025: iget v2, v4.Lcom/sec/chaton/SelectCountry$RegisteFragment;->f:Ljava/lang/String;
    0027: invoke-static {v1, v2}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/String;)V
    002a: const-string v1, 'country_name'
    002c: invoke-static {v1, v0}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/String;)V
    002f: new-instance v1, Ljava/lang/StringBuilder;
    0031: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0034: const-string v2, '[ACS] mCountryLetter: '
    0036: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0039: move-result-object v1
    003a: iget v2, v4.Lcom/sec/chaton/SelectCountry$RegisteFragment;->f:Ljava/lang/String;
    003c: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003f: move-result-object v1
    0040: const-string v2, ' selectedCountryName: '
    0042: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0045: move-result-object v1
    0046: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0049: move-result-object v0
    004a: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    004d: move-result-object v0
    004e: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0051: move-result-object v1
    0052: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0055: move-result-object v1
    0056: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0059: invoke-virtual {v4}, Lcom/sec/chaton/SelectCountry$RegisteFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    005c: move-result-object v0
    005d: invoke-virtual {v0, v3}, Landroid/support/v4/app/FragmentActivity;->setResult(I)V
    0060: invoke-virtual {v4}, Lcom/sec/chaton/SelectCountry$RegisteFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0063: move-result-object v0
    0064: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->finish()V
    0067: goto 0004
    0068: const-string v0, 'selectedCountryName is null'
    006a: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    006d: move-result-object v1
    006e: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0071: move-result-object v1
    0072: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0075: goto 0060
    0076: if-nez v6, 0089
    0078: invoke-virtual {v4}, Lcom/sec/chaton/SelectCountry$RegisteFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    007b: move-result-object v0
    007c: const/4 v1, 0
    007d: invoke-virtual {v0, v1}, Landroid/support/v4/app/FragmentActivity;->setResult(I)V
    0080: invoke-virtual {v4}, Lcom/sec/chaton/SelectCountry$RegisteFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0083: move-result-object v0
    0084: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->finish()V
    0087: goto/16 0004
    0089: invoke-virtual {v4}, Lcom/sec/chaton/SelectCountry$RegisteFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    008c: move-result-object v0
    008d: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->finish()V
    0090: goto/16 0004
    0092: packed-switch-payload first=16 targets=[4]

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=7, ins=2, outs=3, insns_size=115
    0000: const/4 v1, 0
    0001: invoke-super {v5, v6}, Landroid/support/v4/app/Fragment;->onCreate(Landroid/os/Bundle;)V
    0004: invoke-virtual {v5}, Lcom/sec/chaton/SelectCountry$RegisteFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0007: move-result-object v0
    0008: iput v0, v5.Lcom/sec/chaton/SelectCountry$RegisteFragment;->h:Landroid/content/Context;
    000a: const-string v0, 'onCreate..............'
    000c: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    000f: move-result-object v2
    0010: invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0013: move-result-object v2
    0014: invoke-static {v0, v2}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0017: new-instance v0, Lcom/sec/chaton/widget/e;
    0019: invoke-virtual {v5}, Lcom/sec/chaton/SelectCountry$RegisteFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    001c: move-result-object v2
    001d: invoke-direct {v0, v2}, Lcom/sec/chaton/widget/e;-><init>(Landroid/content/Context;)V
    0020: iput v0, v5.Lcom/sec/chaton/SelectCountry$RegisteFragment;->g:Lcom/sec/chaton/b/b;
    0022: new-instance v0, Ljava/util/HashMap;
    0024: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    0027: iput v0, v5.Lcom/sec/chaton/SelectCountry$RegisteFragment;->c:Ljava/util/Map;
    0029: invoke-virtual {v5}, Lcom/sec/chaton/SelectCountry$RegisteFragment;->getResources()Landroid/content/res/Resources;
    002c: move-result-object v0
    002d: const/high16 v2, 2131165184 (0x7f070000)
    002f: invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getTextArray(I)[Ljava/lang/CharSequence;
    0032: move-result-object v0
    0033: iput v0, v5.Lcom/sec/chaton/SelectCountry$RegisteFragment;->d:[Ljava/lang/CharSequence;
    0035: invoke-virtual {v5}, Lcom/sec/chaton/SelectCountry$RegisteFragment;->getResources()Landroid/content/res/Resources;
    0038: move-result-object v0
    0039: const v2, 2131165186 (0x7f070002)
    003c: invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getTextArray(I)[Ljava/lang/CharSequence;
    003f: move-result-object v0
    0040: iput v0, v5.Lcom/sec/chaton/SelectCountry$RegisteFragment;->e:[Ljava/lang/CharSequence;
    0042: move(op=01) v0, v1
    0043: iget v2, v5.Lcom/sec/chaton/SelectCountry$RegisteFragment;->d:[Ljava/lang/CharSequence;
    0045: move(op=21) v2, v2
    0046: if-ge v0, v2, 0058
    0048: iget v2, v5.Lcom/sec/chaton/SelectCountry$RegisteFragment;->c:Ljava/util/Map;
    004a: iget v3, v5.Lcom/sec/chaton/SelectCountry$RegisteFragment;->e:[Ljava/lang/CharSequence;
    004c: aget(op=46) v3, v3[v0]
    004e: iget v4, v5.Lcom/sec/chaton/SelectCountry$RegisteFragment;->d:[Ljava/lang/CharSequence;
    0050: aget(op=46) v4, v4[v0]
    0052: invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    0055: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0057: goto 0043
    0058: new-instance v0, Landroid/content/Intent;
    005a: invoke-virtual {v5}, Lcom/sec/chaton/SelectCountry$RegisteFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    005d: move-result-object v2
    005e: const-class v3, Lcom/sec/chaton/registration/CountryActivity;
    0060: invoke-direct {v0, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0063: const-string v2, 'mode'
    0065: invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    0068: const/high16 v1, 67108864 (0x4000000)
    006a: invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    006d: const/16 v1, 16 (0x10)
    006f: invoke-virtual {v5, v0, v1}, Lcom/sec/chaton/SelectCountry$RegisteFragment;->startActivityForResult(Landroid/content/Intent;I)V
    0072: return-void