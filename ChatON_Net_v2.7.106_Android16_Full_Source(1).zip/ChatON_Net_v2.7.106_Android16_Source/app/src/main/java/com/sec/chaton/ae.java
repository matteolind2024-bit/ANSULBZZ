=== CLASS Lcom/sec/chaton/ae; (Source: MoreFragment.java) ===
  Super: Landroid/content/BroadcastReceiver;
  [Instance Field] a: Lcom/sec/chaton/MoreFragment;

  [Direct Method] <init>(Lcom/sec/chaton/MoreFragment;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/ae;->a:Lcom/sec/chaton/MoreFragment;
    0002: invoke-direct {v0}, Landroid/content/BroadcastReceiver;-><init>()V
    0005: return-void

  [Virtual Method] onReceive(Landroid/content/Context;, Landroid/content/Intent;) -> V
    // registers=4, ins=3, outs=1, insns_size=6
    0000: iget v0, v1.Lcom/sec/chaton/ae;->a:Lcom/sec/chaton/MoreFragment;
    0002: invoke-virtual {v0}, Lcom/sec/chaton/MoreFragment;->d()V
    0005: return-void