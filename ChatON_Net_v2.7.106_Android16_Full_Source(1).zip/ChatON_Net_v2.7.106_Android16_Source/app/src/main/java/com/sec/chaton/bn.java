=== CLASS Lcom/sec/chaton/bn; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/sec/chaton/util/bb;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;
  [Instance Field] b: Landroid/os/Handler;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=3, ins=2, outs=2, insns_size=13
    0000: iput v2, v1.Lcom/sec/chaton/bn;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0005: new-instance v0, Lcom/sec/chaton/bo;
    0007: invoke-direct {v0, v1}, Lcom/sec/chaton/bo;-><init>(Lcom/sec/chaton/bn;)V
    000a: iput v0, v1.Lcom/sec/chaton/bn;->b:Landroid/os/Handler;
    000c: return-void

  [Virtual Method] a() -> Z
    // registers=5, ins=1, outs=3, insns_size=58
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'uid'
    0006: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0009: move-result v0
    000a: if-eqz v0, 0038
    000c: invoke-static {}, Lcom/sec/chaton/d/am;->a()Lcom/sec/chaton/d/a;
    000f: move-result-object v0
    0010: iget v1, v4.Lcom/sec/chaton/bn;->b:Landroid/os/Handler;
    0012: invoke-virtual {v0, v1}, Lcom/sec/chaton/d/a;->c(Landroid/os/Handler;)V
    0015: sget v0, Lcom/sec/chaton/global/GlobalApplication;->a:Ljava/lang/String;
    0017: if-nez v0, 0036
    0019: const-string v0, 'Start PushRegistrationSerivce'
    001b: const-class v1, Lcom/sec/chaton/global/GlobalApplication;
    001d: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0020: move-result-object v1
    0021: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0024: iget v0, v4.Lcom/sec/chaton/bn;->a:Lcom/sec/chaton/TabActivity;
    0026: new-instance v1, Landroid/content/Intent;
    0028: iget v2, v4.Lcom/sec/chaton/bn;->a:Lcom/sec/chaton/TabActivity;
    002a: invoke-virtual {v2}, Lcom/sec/chaton/TabActivity;->getApplicationContext()Landroid/content/Context;
    002d: move-result-object v2
    002e: const-class v3, Lcom/sec/chaton/service/PushRegistrationService;
    0030: invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0033: invoke-virtual {v0, v1}, Lcom/sec/chaton/TabActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    0036: const/4 v0, 1
    0037: return v0
    0038: const/4 v0, 0
    0039: goto 0037