=== CLASS Lcom/sec/chaton/af; (Source: MoreFragment.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/widget/AdapterView$OnItemClickListener;
  [Instance Field] a: Lcom/sec/chaton/MoreFragment;

  [Direct Method] <init>(Lcom/sec/chaton/MoreFragment;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onItemClick(Landroid/widget/AdapterView;, Landroid/view/View;, I, J) -> V
    // registers=9, ins=6, outs=3, insns_size=340
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0005: const-string v1, 'mMoreGridView Position: '
    0007: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000a: move-result-object v0
    000b: invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    000e: move-result-object v0
    000f: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0012: move-result-object v0
    0013: sget v1, Lcom/sec/chaton/MoreFragment;->a:Ljava/lang/String;
    0015: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0018: sget v0, Lcom/sec/chaton/MoreFragment;->b:Ljava/util/ArrayList;
    001a: invoke-virtual {v0, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    001d: move-result-object v0
    001e: check-cast v0, Lcom/sec/chaton/ak;
    0020: iget v0, v0.Lcom/sec/chaton/ak;->a:Ljava/lang/Integer;
    0022: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    0025: move-result v0
    0026: packed-switch v0, +284 (-> 0142)
    0029: return-void
    002a: new-instance v0, Landroid/content/Intent;
    002c: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    002e: invoke-virtual {v1}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0031: move-result-object v1
    0032: const-class v2, Lcom/sec/chaton/settings/SettingContainerActivity;
    0034: invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0037: const-string v1, 'contentId'
    0039: const v2, 2131492954 (0x7f0c005a)
    003c: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    003f: move-result-object v0
    0040: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    0042: invoke-virtual {v1, v0}, Lcom/sec/chaton/MoreFragment;->startActivity(Landroid/content/Intent;)V
    0045: goto 0029
    0046: new-instance v0, Landroid/content/Intent;
    0048: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    004a: invoke-virtual {v1}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    004d: move-result-object v1
    004e: const-class v2, Lcom/sec/chaton/settings/SettingContainerActivity;
    0050: invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0053: const-string v1, 'contentId'
    0055: const v2, 2131493668 (0x7f0c0324)
    0058: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    005b: move-result-object v0
    005c: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    005e: invoke-virtual {v1, v0}, Lcom/sec/chaton/MoreFragment;->startActivity(Landroid/content/Intent;)V
    0061: goto 0029
    0062: new-instance v0, Landroid/content/Intent;
    0064: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    0066: invoke-virtual {v1}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0069: move-result-object v1
    006a: const-class v2, Lcom/sec/chaton/settings/SettingContainerActivity;
    006c: invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    006f: const-string v1, 'contentId'
    0071: const v2, 2131493918 (0x7f0c041e)
    0074: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    0077: move-result-object v0
    0078: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    007a: invoke-virtual {v1, v0}, Lcom/sec/chaton/MoreFragment;->startActivity(Landroid/content/Intent;)V
    007d: goto 0029
    007e: new-instance v0, Landroid/content/Intent;
    0080: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    0082: invoke-virtual {v1}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0085: move-result-object v1
    0086: const-class v2, Lcom/sec/chaton/buddy/SpecialBuddyRecommendListActivity;
    0088: invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    008b: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    008d: invoke-virtual {v1, v0}, Lcom/sec/chaton/MoreFragment;->startActivity(Landroid/content/Intent;)V
    0090: goto 0029
    0091: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0094: move-result-object v0
    0095: const-string v1, 'msisdn'
    0097: const-string v2, ''
    0099: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    009c: move-result-object v0
    009d: invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z
    00a0: move-result v0
    00a1: if-eqz v0, 00e2
    00a3: invoke-static {}, Lcom/sec/chaton/util/ac;->u()Z
    00a6: move-result v0
    00a7: if-nez v0, 00e2
    00a9: new-instance v0, Lcom/sec/widget/a;
    00ab: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    00ad: invoke-virtual {v1}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    00b0: move-result-object v1
    00b1: invoke-direct {v0, v1}, Lcom/sec/widget/a;-><init>(Landroid/content/Context;)V
    00b4: const v1, 2131493486 (0x7f0c026e)
    00b7: invoke-virtual {v0, v1}, Lcom/sec/widget/a;->setTitle(I)Landroid/app/AlertDialog$Builder;
    00ba: move-result-object v0
    00bb: const v1, 2131494001 (0x7f0c0471)
    00be: invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;
    00c1: move-result-object v0
    00c2: const/4 v1, 0
    00c3: invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;
    00c6: move-result-object v0
    00c7: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    00c9: invoke-virtual {v1}, Lcom/sec/chaton/MoreFragment;->getResources()Landroid/content/res/Resources;
    00cc: move-result-object v1
    00cd: const v2, 2131492971 (0x7f0c006b)
    00d0: invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    00d3: move-result-object v1
    00d4: new-instance v2, Lcom/sec/chaton/ag;
    00d6: invoke-direct {v2, v3}, Lcom/sec/chaton/ag;-><init>(Lcom/sec/chaton/af;)V
    00d9: invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    00dc: move-result-object v0
    00dd: invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;
    00e0: goto/16 0029
    00e2: new-instance v0, Landroid/content/Intent;
    00e4: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    00e6: invoke-virtual {v1}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    00e9: move-result-object v1
    00ea: const-class v2, Lcom/sec/chaton/chat/ChatActivity;
    00ec: invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    00ef: const/high16 v1, 67108864 (0x4000000)
    00f1: invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    00f4: move-result-object v0
    00f5: const-string v1, 'eventpage'
    00f7: const/4 v2, 1
    00f8: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    00fb: move-result-object v0
    00fc: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    00fe: invoke-virtual {v1, v0}, Lcom/sec/chaton/MoreFragment;->startActivity(Landroid/content/Intent;)V
    0101: goto/16 0029
    0103: new-instance v0, Lcom/coolots/sso/a/a;
    0105: invoke-direct {v0}, Lcom/coolots/sso/a/a;-><init>()V
    0108: iget v0, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    010a: invoke-virtual {v0}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    010d: move-result-object v0
    010e: invoke-static {v0}, Lcom/coolots/sso/a/a;->b(Landroid/content/Context;)Z
    0111: move-result v0
    0112: if-eqz v0, 0127
    0114: new-instance v0, Landroid/content/Intent;
    0116: invoke-direct {v0}, Landroid/content/Intent;-><init>()V
    0119: const-string v1, 'com.coolots.chaton'
    011b: const-string v2, 'com.coolots.chaton.tab.MainTabActivity'
    011d: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    0120: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    0122: invoke-virtual {v1, v0}, Lcom/sec/chaton/MoreFragment;->startActivity(Landroid/content/Intent;)V
    0125: goto/16 0029
    0127: new-instance v0, Landroid/content/Intent;
    0129: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    012b: invoke-virtual {v1}, Lcom/sec/chaton/MoreFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    012e: move-result-object v1
    012f: const-class v2, Lcom/sec/chaton/settings/ActivityWebView;
    0131: invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0134: const-string v1, 'PARAM_MENU'
    0136: const-string v2, 'SDS_DOWNLOAD_CHATON_V'
    0138: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    013b: iget v1, v3.Lcom/sec/chaton/af;->a:Lcom/sec/chaton/MoreFragment;
    013d: invoke-virtual {v1, v0}, Lcom/sec/chaton/MoreFragment;->startActivity(Landroid/content/Intent;)V
    0140: goto/16 0029
    0142: packed-switch-payload first=2130903382 targets=[88, 221, 32, 107, 3, 4, 60]