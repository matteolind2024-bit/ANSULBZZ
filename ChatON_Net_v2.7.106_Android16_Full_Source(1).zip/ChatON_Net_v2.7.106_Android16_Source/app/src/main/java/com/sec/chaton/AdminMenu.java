=== CLASS Lcom/sec/chaton/AdminMenu; (Source: AdminMenu.java) ===
  Super: Lcom/sec/chaton/base/BaseActivity;
  Interfaces: Landroid/widget/TabHost$OnTabChangeListener;
  [Static Field] b: [Ljava/lang/String;
  [Instance Field] A: Landroid/widget/Button;
  [Instance Field] B: Landroid/widget/Button;
  [Instance Field] C: Landroid/widget/Button;
  [Instance Field] D: Landroid/widget/Button;
  [Instance Field] E: Landroid/widget/Button;
  [Instance Field] F: Landroid/content/Context;
  [Instance Field] G: Landroid/app/ProgressDialog;
  [Instance Field] H: Z
  [Instance Field] I: Landroid/widget/TabHost;
  [Instance Field] J: Landroid/widget/EditText;
  [Instance Field] K: Landroid/widget/EditText;
  [Instance Field] L: Z
  [Instance Field] M: I
  [Instance Field] N: Landroid/widget/EditText;
  [Instance Field] O: Ljava/util/ArrayList;
  [Instance Field] P: Lcom/sec/chaton/d/o;
  [Instance Field] Q: I
  [Instance Field] R: I
  [Instance Field] S: Landroid/os/Handler;
  [Instance Field] T: Landroid/view/View$OnClickListener;
  [Instance Field] a: Landroid/os/Handler;
  [Instance Field] c: Landroid/widget/EditText;
  [Instance Field] d: Landroid/widget/EditText;
  [Instance Field] e: Landroid/widget/EditText;
  [Instance Field] g: Landroid/widget/EditText;
  [Instance Field] h: Landroid/widget/Button;
  [Instance Field] i: Landroid/widget/Button;
  [Instance Field] j: Landroid/widget/Button;
  [Instance Field] k: Landroid/widget/Button;
  [Instance Field] l: Landroid/widget/TextView;
  [Instance Field] m: Landroid/widget/Button;
  [Instance Field] n: Landroid/widget/Button;
  [Instance Field] o: Landroid/widget/Button;
  [Instance Field] p: Landroid/widget/Button;
  [Instance Field] q: Landroid/widget/Button;
  [Instance Field] r: Landroid/widget/Button;
  [Instance Field] s: Landroid/widget/Button;
  [Instance Field] t: Landroid/widget/Button;
  [Instance Field] u: Landroid/widget/Button;
  [Instance Field] v: Landroid/widget/Button;
  [Instance Field] w: Landroid/widget/Button;
  [Instance Field] x: Landroid/widget/Button;
  [Instance Field] y: Landroid/widget/Button;
  [Instance Field] z: Landroid/widget/Button;

  [Direct Method] <clinit>() -> V
    // registers=3, ins=0, outs=0, insns_size=11
    0000: const/4 v0, 1
    0001: new-array v0, v0, [Ljava/lang/String;
    0003: const/4 v1, 0
    0004: const-string v2, 'chatondev@samsung.com'
    0006: aput(op=4d) v2, v0[v1]
    0008: sput v0, Lcom/sec/chaton/AdminMenu;->b:[Ljava/lang/String;
    000a: return-void

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=24
    0000: invoke-direct {v1}, Lcom/sec/chaton/base/BaseActivity;-><init>()V
    0003: const/4 v0, 0
    0004: iput v0, v1.Lcom/sec/chaton/AdminMenu;->G:Landroid/app/ProgressDialog;
    0006: const/4 v0, 0
    0007: iput v0, v1.Lcom/sec/chaton/AdminMenu;->H:Z
    0009: new-instance v0, Lcom/sec/chaton/b;
    000b: invoke-direct {v0, v1}, Lcom/sec/chaton/b;-><init>(Lcom/sec/chaton/AdminMenu;)V
    000e: iput v0, v1.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    0010: new-instance v0, Lcom/sec/chaton/c;
    0012: invoke-direct {v0, v1}, Lcom/sec/chaton/c;-><init>(Lcom/sec/chaton/AdminMenu;)V
    0015: iput v0, v1.Lcom/sec/chaton/AdminMenu;->a:Landroid/os/Handler;
    0017: return-void

  [Direct Method] A(Lcom/sec/chaton/AdminMenu;) -> Lcom/sec/chaton/d/o;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->P:Lcom/sec/chaton/d/o;
    0002: return-object v0

  [Direct Method] B(Lcom/sec/chaton/AdminMenu;) -> I
    // registers=3, ins=1, outs=0, insns_size=7
    0000: iget v0, v2.Lcom/sec/chaton/AdminMenu;->Q:I
    0002: binop/lit8(op=d8) v1, v0, 1 (0x1)
    0004: iput v1, v2.Lcom/sec/chaton/AdminMenu;->Q:I
    0006: return v0

  [Direct Method] C(Lcom/sec/chaton/AdminMenu;) -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->R:I
    0002: return v0

  [Direct Method] a(Lcom/sec/chaton/AdminMenu;, I) -> I
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/AdminMenu;->Q:I
    0002: return v1

  [Direct Method] a(Lcom/sec/chaton/AdminMenu;, Landroid/app/ProgressDialog;) -> Landroid/app/ProgressDialog;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/AdminMenu;->G:Landroid/app/ProgressDialog;
    0002: return-object v1

  [Direct Method] a(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/Button;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->u:Landroid/widget/Button;
    0002: return-object v0

  [Direct Method] a() -> V
    // registers=5, ins=0, outs=3, insns_size=115
    0000: const/4 v1, 0
    0001: const-string v0, 'TEST'
    0003: const-string v2, 'copyPreferenceToSdcard start'
    0005: invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    0008: new-instance v2, Ljava/io/File;
    000a: const-string v0, 'data/data/com.sec.chaton/shared_prefs/'
    000c: const-string v3, 'ChatON.xml'
    000e: invoke-direct {v2, v0, v3}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    0011: new-instance v0, Ljava/io/FileInputStream;
    0013: invoke-direct {v0, v2}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    0016: new-instance v2, Ljava/io/FileOutputStream;
    0018: new-instance v3, Ljava/lang/StringBuilder;
    001a: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    001d: invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;
    0020: move-result-object v4
    0021: invoke-virtual {v4}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;
    0024: move-result-object v4
    0025: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0028: move-result-object v3
    0029: const-string v4, '/chaton.xml'
    002b: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002e: move-result-object v3
    002f: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0032: move-result-object v3
    0033: invoke-direct {v2, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V
    0036: move(op=07) v1, v2
    0037: const/4 v2, 1
    0038: new-array v2, v2, [B
    003a: invoke-virtual {v0, v2}, Ljava/io/InputStream;->read([B)I
    003d: move-result v3
    003e: if-lez v3, 0048
    0040: invoke-virtual {v1, v2}, Ljava/io/OutputStream;->write([B)V
    0043: goto 003a
    0044: move-exception v2
    0045: invoke-virtual {v2}, Ljava/io/IOException;->printStackTrace()V
    0048: invoke-virtual {v1}, Ljava/io/OutputStream;->flush()V
    004b: invoke-virtual {v1}, Ljava/io/OutputStream;->close()V
    004e: invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    0051: const-string v0, 'TEST'
    0053: const-string v1, 'copyPreferenceToSdcard end'
    0055: invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    0058: return-void
    0059: move-exception v0
    005a: invoke-virtual {v0}, Ljava/io/FileNotFoundException;->printStackTrace()V
    005d: move(op=07) v0, v1
    005e: goto 0016
    005f: move-exception v2
    0060: invoke-virtual {v2}, Ljava/io/FileNotFoundException;->printStackTrace()V
    0063: goto 0037
    0064: move-exception v2
    0065: invoke-virtual {v2}, Ljava/io/IOException;->printStackTrace()V
    0068: goto 004b
    0069: move-exception v1
    006a: invoke-virtual {v1}, Ljava/io/IOException;->printStackTrace()V
    006d: goto 004e
    006e: move-exception v0
    006f: invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V
    0072: goto 0051

  [Direct Method] a(Lcom/sec/chaton/AdminMenu;, Z) -> Z
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/AdminMenu;->H:Z
    0002: return v1

  [Direct Method] b(Lcom/sec/chaton/AdminMenu;, I) -> I
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/AdminMenu;->R:I
    0002: return v1

  [Direct Method] b(Lcom/sec/chaton/AdminMenu;) -> Ljava/util/ArrayList;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->O:Ljava/util/ArrayList;
    0002: return-object v0

  [Direct Method] b() -> V
    // registers=5, ins=0, outs=4, insns_size=114
    0000: const-string v0, 'TEST'
    0002: const-string v1, 'copyAutoResendTraceToSdcard start'
    0004: invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    0007: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    000a: move-result-object v0
    000b: invoke-static {v0}, Lcom/sec/chaton/msgsend/q;->a(Landroid/content/Context;)Ljava/io/File;
    000e: move-result-object v0
    000f: invoke-virtual {v0}, Ljava/io/File;->exists()Z
    0012: move-result v1
    0013: if-nez v1, 001e
    0015: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0018: move-result-object v1
    0019: const-string v2, 'try to copy to sdcard, but not exist. make empty trace file now'
    001b: invoke-static {v1, v2}, Lcom/sec/chaton/msgsend/q;->a(Landroid/content/Context;Ljava/lang/String;)V
    001e: new-instance v1, Ljava/io/FileInputStream;
    0020: invoke-direct {v1, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    0023: new-instance v0, Ljava/io/FileOutputStream;
    0025: new-instance v2, Ljava/lang/StringBuilder;
    0027: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    002a: invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;
    002d: move-result-object v3
    002e: invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;
    0031: move-result-object v3
    0032: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0035: move-result-object v2
    0036: const-string v3, '/'
    0038: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003b: move-result-object v2
    003c: invoke-static {}, Lcom/sec/chaton/msgsend/q;->f()Ljava/lang/String;
    003f: move-result-object v3
    0040: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0043: move-result-object v2
    0044: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0047: move-result-object v2
    0048: invoke-direct {v0, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V
    004b: const/16 v2, 1024 (0x400)
    004d: new-array v2, v2, [B
    004f: invoke-virtual {v1, v2}, Ljava/io/InputStream;->read([B)I
    0052: move-result v3
    0053: if-lez v3, 0066
    0055: const/4 v4, 0
    0056: invoke-virtual {v0, v2, v4, v3}, Ljava/io/OutputStream;->write([BII)V
    0059: goto 004f
    005a: move-exception v0
    005b: invoke-virtual {v0}, Ljava/io/FileNotFoundException;->printStackTrace()V
    005e: const-string v0, 'TEST'
    0060: const-string v1, 'copyAutoResendTraceToSdcard end'
    0062: invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    0065: return-void
    0066: invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V
    0069: invoke-virtual {v0}, Ljava/io/OutputStream;->close()V
    006c: invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    006f: goto 005e
    0070: move-exception v0
    0071: goto 005e

  [Direct Method] c(Lcom/sec/chaton/AdminMenu;, I) -> I
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/AdminMenu;->M:I
    0002: return v1

  [Direct Method] c(Lcom/sec/chaton/AdminMenu;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/AdminMenu;->f()V
    0003: return-void

  [Direct Method] c() -> [Ljava/lang/String;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/sec/chaton/AdminMenu;->b:[Ljava/lang/String;
    0002: return-object v0

  [Direct Method] d() -> V
    // registers=6, ins=1, outs=4, insns_size=95
    0000: const/4 v4, 0
    0001: new-instance v1, Lcom/sec/common/widget/b;
    0003: iget v0, v5.Lcom/sec/chaton/AdminMenu;->F:Landroid/content/Context;
    0005: invoke-direct {v1, v0}, Lcom/sec/common/widget/b;-><init>(Landroid/content/Context;)V
    0008: const-string v0, 'DB File SendEmail'
    000a: invoke-virtual {v1, v0}, Lcom/sec/common/widget/b;->setTitle(Ljava/lang/CharSequence;)V
    000d: iget v0, v5.Lcom/sec/chaton/AdminMenu;->F:Landroid/content/Context;
    000f: const-string v2, 'layout_inflater'
    0011: invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    0014: move-result-object v0
    0015: check-cast v0, Landroid/view/LayoutInflater;
    0017: const v2, 2130903047 (0x7f030007)
    001a: const/4 v3, 0
    001b: invoke-virtual {v0, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;
    001e: move-result-object v0
    001f: invoke-virtual {v1, v0}, Lcom/sec/common/widget/b;->setView(Landroid/view/View;)V
    0022: const v2, 2131230748 (0x7f08001c)
    0025: invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0028: move-result-object v0
    0029: check-cast v0, Landroid/widget/EditText;
    002b: iput v0, v5.Lcom/sec/chaton/AdminMenu;->N:Landroid/widget/EditText;
    002d: const/4 v0, -1
    002e: invoke-virtual {v5}, Lcom/sec/chaton/AdminMenu;->getResources()Landroid/content/res/Resources;
    0031: move-result-object v2
    0032: const v3, 2131492971 (0x7f0c006b)
    0035: invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    0038: move-result-object v2
    0039: new-instance v3, Lcom/sec/chaton/d;
    003b: invoke-direct {v3, v5}, Lcom/sec/chaton/d;-><init>(Lcom/sec/chaton/AdminMenu;)V
    003e: invoke-virtual {v1, v0, v2, v3}, Lcom/sec/common/widget/b;->setButton(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)V
    0041: const/4 v0, -2
    0042: invoke-virtual {v5}, Lcom/sec/chaton/AdminMenu;->getResources()Landroid/content/res/Resources;
    0045: move-result-object v2
    0046: const v3, 2131492973 (0x7f0c006d)
    0049: invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    004c: move-result-object v2
    004d: new-instance v3, Lcom/sec/chaton/e;
    004f: invoke-direct {v3, v5}, Lcom/sec/chaton/e;-><init>(Lcom/sec/chaton/AdminMenu;)V
    0052: invoke-virtual {v1, v0, v2, v3}, Lcom/sec/common/widget/b;->setButton(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)V
    0055: invoke-virtual {v1, v4}, Lcom/sec/common/widget/b;->setCancelable(Z)V
    0058: invoke-virtual {v1, v4}, Lcom/sec/common/widget/b;->setCanceledOnTouchOutside(Z)V
    005b: invoke-virtual {v1}, Lcom/sec/common/widget/b;->show()V
    005e: return-void

  [Direct Method] d(Lcom/sec/chaton/AdminMenu;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/AdminMenu;->h()V
    0003: return-void

  [Direct Method] e(Lcom/sec/chaton/AdminMenu;) -> Landroid/content/Context;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->F:Landroid/content/Context;
    0002: return-object v0

  [Direct Method] e() -> V
    // registers=6, ins=1, outs=4, insns_size=106
    0000: const/4 v4, 0
    0001: new-instance v1, Lcom/sec/common/widget/b;
    0003: iget v0, v5.Lcom/sec/chaton/AdminMenu;->F:Landroid/content/Context;
    0005: invoke-direct {v1, v0}, Lcom/sec/common/widget/b;-><init>(Landroid/content/Context;)V
    0008: const-string v0, 'Enter Password'
    000a: invoke-virtual {v1, v0}, Lcom/sec/common/widget/b;->setTitle(Ljava/lang/CharSequence;)V
    000d: iget v0, v5.Lcom/sec/chaton/AdminMenu;->F:Landroid/content/Context;
    000f: const-string v2, 'layout_inflater'
    0011: invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    0014: move-result-object v0
    0015: check-cast v0, Landroid/view/LayoutInflater;
    0017: const v2, 2130903048 (0x7f030008)
    001a: const/4 v3, 0
    001b: invoke-virtual {v0, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;
    001e: move-result-object v2
    001f: invoke-virtual {v1, v2}, Lcom/sec/common/widget/b;->setView(Landroid/view/View;)V
    0022: const v0, 2131230749 (0x7f08001d)
    0025: invoke-virtual {v2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0028: move-result-object v0
    0029: check-cast v0, Landroid/widget/EditText;
    002b: iput v0, v5.Lcom/sec/chaton/AdminMenu;->J:Landroid/widget/EditText;
    002d: const v0, 2131230750 (0x7f08001e)
    0030: invoke-virtual {v2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0033: move-result-object v0
    0034: check-cast v0, Landroid/widget/EditText;
    0036: iput v0, v5.Lcom/sec/chaton/AdminMenu;->K:Landroid/widget/EditText;
    0038: const/4 v0, -1
    0039: invoke-virtual {v5}, Lcom/sec/chaton/AdminMenu;->getResources()Landroid/content/res/Resources;
    003c: move-result-object v2
    003d: const v3, 2131492971 (0x7f0c006b)
    0040: invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    0043: move-result-object v2
    0044: new-instance v3, Lcom/sec/chaton/f;
    0046: invoke-direct {v3, v5}, Lcom/sec/chaton/f;-><init>(Lcom/sec/chaton/AdminMenu;)V
    0049: invoke-virtual {v1, v0, v2, v3}, Lcom/sec/common/widget/b;->setButton(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)V
    004c: const/4 v0, -2
    004d: invoke-virtual {v5}, Lcom/sec/chaton/AdminMenu;->getResources()Landroid/content/res/Resources;
    0050: move-result-object v2
    0051: const v3, 2131492973 (0x7f0c006d)
    0054: invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    0057: move-result-object v2
    0058: new-instance v3, Lcom/sec/chaton/g;
    005a: invoke-direct {v3, v5}, Lcom/sec/chaton/g;-><init>(Lcom/sec/chaton/AdminMenu;)V
    005d: invoke-virtual {v1, v0, v2, v3}, Lcom/sec/common/widget/b;->setButton(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)V
    0060: invoke-virtual {v1, v4}, Lcom/sec/common/widget/b;->setCancelable(Z)V
    0063: invoke-virtual {v1, v4}, Lcom/sec/common/widget/b;->setCanceledOnTouchOutside(Z)V
    0066: invoke-virtual {v1}, Lcom/sec/common/widget/b;->show()V
    0069: return-void

  [Direct Method] f(Lcom/sec/chaton/AdminMenu;) -> Landroid/app/ProgressDialog;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->G:Landroid/app/ProgressDialog;
    0002: return-object v0

  [Direct Method] f() -> V
    // registers=7, ins=1, outs=2, insns_size=111
    0000: const/16 v1, 199 (0xc7)
    0002: const-string v2, '827799990'
    0004: const/4 v0, 0
    0005: if-ge v0, v1, 006e
    0007: const/16 v3, 10 (0xa)
    0009: if-ge v0, v3, 002e
    000b: iget v3, v6.Lcom/sec/chaton/AdminMenu;->O:Ljava/util/ArrayList;
    000d: new-instance v4, Ljava/lang/StringBuilder;
    000f: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    0012: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0015: move-result-object v4
    0016: const-string v5, '00'
    0018: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001b: move-result-object v4
    001c: invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    001f: move-result-object v5
    0020: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0023: move-result-object v4
    0024: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0027: move-result-object v4
    0028: invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    002b: binop/lit8(op=d8) v0, v0, 1 (0x1)
    002d: goto 0005
    002e: const/16 v3, 100 (0x64)
    0030: if-ge v0, v3, 0053
    0032: iget v3, v6.Lcom/sec/chaton/AdminMenu;->O:Ljava/util/ArrayList;
    0034: new-instance v4, Ljava/lang/StringBuilder;
    0036: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    0039: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003c: move-result-object v4
    003d: const-string v5, '0'
    003f: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0042: move-result-object v4
    0043: invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    0046: move-result-object v5
    0047: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004a: move-result-object v4
    004b: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    004e: move-result-object v4
    004f: invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0052: goto 002b
    0053: iget v3, v6.Lcom/sec/chaton/AdminMenu;->O:Ljava/util/ArrayList;
    0055: new-instance v4, Ljava/lang/StringBuilder;
    0057: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    005a: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    005d: move-result-object v4
    005e: invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    0061: move-result-object v5
    0062: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0065: move-result-object v4
    0066: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0069: move-result-object v4
    006a: invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    006d: goto 002b
    006e: return-void

  [Direct Method] g() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Direct Method] g(Lcom/sec/chaton/AdminMenu;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/AdminMenu;->i()V
    0003: return-void

  [Direct Method] h(Lcom/sec/chaton/AdminMenu;) -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->M:I
    0002: return v0

  [Direct Method] h() -> V
    // registers=2, ins=1, outs=2, insns_size=8
    0000: new-instance v0, Lcom/sec/chaton/h;
    0002: invoke-direct {v0, v1}, Lcom/sec/chaton/h;-><init>(Lcom/sec/chaton/AdminMenu;)V
    0005: iput v0, v1.Lcom/sec/chaton/AdminMenu;->S:Landroid/os/Handler;
    0007: return-void

  [Direct Method] i(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/Button;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->q:Landroid/widget/Button;
    0002: return-object v0

  [Direct Method] i() -> V
    // registers=4, ins=1, outs=2, insns_size=28
    0000: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0003: move-result-object v0
    0004: invoke-static {v0}, Lcom/sec/chaton/util/RTLogCollector;->a(Landroid/content/Context;)Lcom/sec/chaton/util/RTLogCollector;
    0007: move-result-object v0
    0008: invoke-virtual {v0}, Lcom/sec/chaton/util/RTLogCollector;->c()Z
    000b: move-result v1
    000c: iget v2, v3.Lcom/sec/chaton/AdminMenu;->o:Landroid/widget/Button;
    000e: if-nez v1, 001a
    0010: const/4 v0, 1
    0011: invoke-virtual {v2, v0}, Landroid/widget/Button;->setEnabled(Z)V
    0014: iget v0, v3.Lcom/sec/chaton/AdminMenu;->p:Landroid/widget/Button;
    0016: invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V
    0019: return-void
    001a: const/4 v0, 0
    001b: goto 0011

  [Direct Method] j(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/TextView;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->l:Landroid/widget/TextView;
    0002: return-object v0

  [Direct Method] k(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/EditText;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->c:Landroid/widget/EditText;
    0002: return-object v0

  [Direct Method] l(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/EditText;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->d:Landroid/widget/EditText;
    0002: return-object v0

  [Direct Method] m(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/EditText;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->e:Landroid/widget/EditText;
    0002: return-object v0

  [Direct Method] n(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/EditText;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->g:Landroid/widget/EditText;
    0002: return-object v0

  [Direct Method] o(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/Button;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->w:Landroid/widget/Button;
    0002: return-object v0

  [Direct Method] p(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/Button;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->x:Landroid/widget/Button;
    0002: return-object v0

  [Direct Method] q(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/Button;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->y:Landroid/widget/Button;
    0002: return-object v0

  [Direct Method] r(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/Button;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->z:Landroid/widget/Button;
    0002: return-object v0

  [Direct Method] s(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/Button;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->A:Landroid/widget/Button;
    0002: return-object v0

  [Direct Method] t(Lcom/sec/chaton/AdminMenu;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/AdminMenu;->d()V
    0003: return-void

  [Direct Method] u(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/EditText;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->N:Landroid/widget/EditText;
    0002: return-object v0

  [Direct Method] v(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/EditText;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->J:Landroid/widget/EditText;
    0002: return-object v0

  [Direct Method] w(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/EditText;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->K:Landroid/widget/EditText;
    0002: return-object v0

  [Direct Method] x(Lcom/sec/chaton/AdminMenu;) -> Landroid/widget/TabHost;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    0002: return-object v0

  [Direct Method] y(Lcom/sec/chaton/AdminMenu;) -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/AdminMenu;->Q:I
    0002: return v0

  [Direct Method] z(Lcom/sec/chaton/AdminMenu;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/AdminMenu;->g()V
    0003: return-void

  [Virtual Method] a(Ljava/lang/String;, Ljava/lang/String;) -> Z
    // registers=7, ins=3, outs=3, insns_size=40
    0000: const/4 v0, 0
    0001: const-string v1, 'MD5'
    0003: invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;
    0006: move-result-object v1
    0007: invoke-virtual {v5}, Ljava/lang/String;->getBytes()[B
    000a: move-result-object v2
    000b: invoke-virtual {v1, v2}, Ljava/security/MessageDigest;->update([B)V
    000e: new-instance v2, Ljava/math/BigInteger;
    0010: const/4 v3, 1
    0011: invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B
    0014: move-result-object v1
    0015: invoke-direct {v2, v3, v1}, Ljava/math/BigInteger;-><init>(I[B)V
    0018: const/16 v1, 16 (0x10)
    001a: invoke-virtual {v2, v1}, Ljava/math/BigInteger;->toString(I)Ljava/lang/String;
    001d: move-result-object v0
    001e: invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0021: move-result v0
    0022: return v0
    0023: move-exception v1
    0024: invoke-virtual {v1}, Ljava/security/NoSuchAlgorithmException;->printStackTrace()V
    0027: goto 001e

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=8, ins=2, outs=3, insns_size=816
    0000: const/4 v5, 1
    0001: const/4 v2, 0
    0002: invoke-super {v6, v7}, Lcom/sec/chaton/base/BaseActivity;->onCreate(Landroid/os/Bundle;)V
    0005: iput v6, v6.Lcom/sec/chaton/AdminMenu;->F:Landroid/content/Context;
    0007: new-instance v0, Ljava/util/ArrayList;
    0009: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    000c: iput v0, v6.Lcom/sec/chaton/AdminMenu;->O:Ljava/util/ArrayList;
    000e: const v0, 2130903049 (0x7f030009)
    0011: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->setContentView(I)V
    0014: const v0, 2131230752 (0x7f080020)
    0017: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    001a: move-result-object v0
    001b: check-cast v0, Landroid/widget/TabHost;
    001d: iput v0, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    001f: iget v0, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    0021: invoke-virtual {v0}, Landroid/widget/TabHost;->setup()V
    0024: iget v0, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    0026: const-string v1, 'Tab1'
    0028: invoke-virtual {v0, v1}, Landroid/widget/TabHost;->newTabSpec(Ljava/lang/String;)Landroid/widget/TabHost$TabSpec;
    002b: move-result-object v0
    002c: const-string v1, 'GENERAL'
    002e: invoke-virtual {v0, v1}, Landroid/widget/TabHost$TabSpec;->setIndicator(Ljava/lang/CharSequence;)Landroid/widget/TabHost$TabSpec;
    0031: const v1, 2131230753 (0x7f080021)
    0034: invoke-virtual {v0, v1}, Landroid/widget/TabHost$TabSpec;->setContent(I)Landroid/widget/TabHost$TabSpec;
    0037: iget v1, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    0039: invoke-virtual {v1, v0}, Landroid/widget/TabHost;->addTab(Landroid/widget/TabHost$TabSpec;)V
    003c: iget v0, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    003e: const-string v1, 'Tab2'
    0040: invoke-virtual {v0, v1}, Landroid/widget/TabHost;->newTabSpec(Ljava/lang/String;)Landroid/widget/TabHost$TabSpec;
    0043: move-result-object v0
    0044: const-string v1, 'SQE'
    0046: invoke-virtual {v0, v1}, Landroid/widget/TabHost$TabSpec;->setIndicator(Ljava/lang/CharSequence;)Landroid/widget/TabHost$TabSpec;
    0049: const v1, 2131230759 (0x7f080027)
    004c: invoke-virtual {v0, v1}, Landroid/widget/TabHost$TabSpec;->setContent(I)Landroid/widget/TabHost$TabSpec;
    004f: iget v1, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    0051: invoke-virtual {v1, v0}, Landroid/widget/TabHost;->addTab(Landroid/widget/TabHost$TabSpec;)V
    0054: iget v0, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    0056: const-string v1, 'Tab3'
    0058: invoke-virtual {v0, v1}, Landroid/widget/TabHost;->newTabSpec(Ljava/lang/String;)Landroid/widget/TabHost$TabSpec;
    005b: move-result-object v0
    005c: const-string v1, 'DEV'
    005e: invoke-virtual {v0, v1}, Landroid/widget/TabHost$TabSpec;->setIndicator(Ljava/lang/CharSequence;)Landroid/widget/TabHost$TabSpec;
    0061: const v1, 2131230761 (0x7f080029)
    0064: invoke-virtual {v0, v1}, Landroid/widget/TabHost$TabSpec;->setContent(I)Landroid/widget/TabHost$TabSpec;
    0067: iget v1, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    0069: invoke-virtual {v1, v0}, Landroid/widget/TabHost;->addTab(Landroid/widget/TabHost$TabSpec;)V
    006c: invoke-virtual {v6}, Lcom/sec/chaton/AdminMenu;->getIntent()Landroid/content/Intent;
    006f: move-result-object v0
    0070: invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    0073: move-result-object v3
    0074: const v0, 2131230766 (0x7f08002e)
    0077: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    007a: move-result-object v0
    007b: check-cast v0, Landroid/widget/EditText;
    007d: iput v0, v6.Lcom/sec/chaton/AdminMenu;->c:Landroid/widget/EditText;
    007f: iget v0, v6.Lcom/sec/chaton/AdminMenu;->c:Landroid/widget/EditText;
    0081: const-string v1, '0'
    0083: invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V
    0086: const v0, 2131230768 (0x7f080030)
    0089: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    008c: move-result-object v0
    008d: check-cast v0, Landroid/widget/EditText;
    008f: iput v0, v6.Lcom/sec/chaton/AdminMenu;->d:Landroid/widget/EditText;
    0091: iget v0, v6.Lcom/sec/chaton/AdminMenu;->d:Landroid/widget/EditText;
    0093: const-string v1, '0'
    0095: invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V
    0098: const v0, 2131230770 (0x7f080032)
    009b: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    009e: move-result-object v0
    009f: check-cast v0, Landroid/widget/EditText;
    00a1: iput v0, v6.Lcom/sec/chaton/AdminMenu;->e:Landroid/widget/EditText;
    00a3: iget v0, v6.Lcom/sec/chaton/AdminMenu;->e:Landroid/widget/EditText;
    00a5: const-string v1, '0'
    00a7: invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V
    00aa: const v0, 2131230772 (0x7f080034)
    00ad: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    00b0: move-result-object v0
    00b1: check-cast v0, Landroid/widget/EditText;
    00b3: iput v0, v6.Lcom/sec/chaton/AdminMenu;->g:Landroid/widget/EditText;
    00b5: iget v0, v6.Lcom/sec/chaton/AdminMenu;->g:Landroid/widget/EditText;
    00b7: const-string v1, '0'
    00b9: invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V
    00bc: const v0, 2131230773 (0x7f080035)
    00bf: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    00c2: move-result-object v0
    00c3: check-cast v0, Landroid/widget/Button;
    00c5: iput v0, v6.Lcom/sec/chaton/AdminMenu;->h:Landroid/widget/Button;
    00c7: iget v0, v6.Lcom/sec/chaton/AdminMenu;->h:Landroid/widget/Button;
    00c9: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    00cb: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    00ce: const v0, 2131230774 (0x7f080036)
    00d1: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    00d4: move-result-object v0
    00d5: check-cast v0, Landroid/widget/Button;
    00d7: iput v0, v6.Lcom/sec/chaton/AdminMenu;->i:Landroid/widget/Button;
    00d9: iget v0, v6.Lcom/sec/chaton/AdminMenu;->i:Landroid/widget/Button;
    00db: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    00dd: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    00e0: const v0, 2131230775 (0x7f080037)
    00e3: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    00e6: move-result-object v0
    00e7: check-cast v0, Landroid/widget/Button;
    00e9: iput v0, v6.Lcom/sec/chaton/AdminMenu;->j:Landroid/widget/Button;
    00eb: iget v0, v6.Lcom/sec/chaton/AdminMenu;->j:Landroid/widget/Button;
    00ed: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    00ef: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    00f2: const v0, 2131230776 (0x7f080038)
    00f5: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    00f8: move-result-object v0
    00f9: check-cast v0, Landroid/widget/Button;
    00fb: iput v0, v6.Lcom/sec/chaton/AdminMenu;->k:Landroid/widget/Button;
    00fd: iget v0, v6.Lcom/sec/chaton/AdminMenu;->k:Landroid/widget/Button;
    00ff: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    0101: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0104: const v0, 2131230764 (0x7f08002c)
    0107: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    010a: move-result-object v0
    010b: check-cast v0, Landroid/widget/TextView;
    010d: iput v0, v6.Lcom/sec/chaton/AdminMenu;->l:Landroid/widget/TextView;
    010f: iget v0, v6.Lcom/sec/chaton/AdminMenu;->l:Landroid/widget/TextView;
    0111: invoke-static {}, Lcom/sec/chaton/util/ac;->f()Ljava/lang/String;
    0114: move-result-object v1
    0115: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    0118: const v0, 2131230777 (0x7f080039)
    011b: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    011e: move-result-object v0
    011f: check-cast v0, Landroid/widget/Button;
    0121: iput v0, v6.Lcom/sec/chaton/AdminMenu;->m:Landroid/widget/Button;
    0123: const v0, 2131230778 (0x7f08003a)
    0126: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    0129: move-result-object v0
    012a: check-cast v0, Landroid/widget/Button;
    012c: iput v0, v6.Lcom/sec/chaton/AdminMenu;->n:Landroid/widget/Button;
    012e: iget v0, v6.Lcom/sec/chaton/AdminMenu;->m:Landroid/widget/Button;
    0130: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    0132: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0135: iget v0, v6.Lcom/sec/chaton/AdminMenu;->n:Landroid/widget/Button;
    0137: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    0139: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    013c: const v0, 2131230756 (0x7f080024)
    013f: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    0142: move-result-object v0
    0143: check-cast v0, Landroid/widget/Button;
    0145: iput v0, v6.Lcom/sec/chaton/AdminMenu;->o:Landroid/widget/Button;
    0147: const v0, 2131230757 (0x7f080025)
    014a: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    014d: move-result-object v0
    014e: check-cast v0, Landroid/widget/Button;
    0150: iput v0, v6.Lcom/sec/chaton/AdminMenu;->p:Landroid/widget/Button;
    0152: iget v0, v6.Lcom/sec/chaton/AdminMenu;->o:Landroid/widget/Button;
    0154: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    0156: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0159: iget v0, v6.Lcom/sec/chaton/AdminMenu;->p:Landroid/widget/Button;
    015b: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    015d: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0160: invoke-direct {v6}, Lcom/sec/chaton/AdminMenu;->i()V
    0163: const v0, 2131230758 (0x7f080026)
    0166: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    0169: move-result-object v0
    016a: check-cast v0, Landroid/widget/Button;
    016c: iput v0, v6.Lcom/sec/chaton/AdminMenu;->z:Landroid/widget/Button;
    016e: const v0, 2131230779 (0x7f08003b)
    0171: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    0174: move-result-object v0
    0175: check-cast v0, Landroid/widget/Button;
    0177: iput v0, v6.Lcom/sec/chaton/AdminMenu;->A:Landroid/widget/Button;
    0179: const v0, 2131230780 (0x7f08003c)
    017c: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    017f: move-result-object v0
    0180: check-cast v0, Landroid/widget/Button;
    0182: iput v0, v6.Lcom/sec/chaton/AdminMenu;->B:Landroid/widget/Button;
    0184: const v0, 2131230782 (0x7f08003e)
    0187: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    018a: move-result-object v0
    018b: check-cast v0, Landroid/widget/Button;
    018d: iput v0, v6.Lcom/sec/chaton/AdminMenu;->C:Landroid/widget/Button;
    018f: const v0, 2131230781 (0x7f08003d)
    0192: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    0195: move-result-object v0
    0196: check-cast v0, Landroid/widget/Button;
    0198: iput v0, v6.Lcom/sec/chaton/AdminMenu;->D:Landroid/widget/Button;
    019a: const v0, 2131230783 (0x7f08003f)
    019d: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    01a0: move-result-object v0
    01a1: check-cast v0, Landroid/widget/Button;
    01a3: iput v0, v6.Lcom/sec/chaton/AdminMenu;->E:Landroid/widget/Button;
    01a5: iget v0, v6.Lcom/sec/chaton/AdminMenu;->z:Landroid/widget/Button;
    01a7: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    01a9: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    01ac: iget v0, v6.Lcom/sec/chaton/AdminMenu;->A:Landroid/widget/Button;
    01ae: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    01b0: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    01b3: iget v0, v6.Lcom/sec/chaton/AdminMenu;->B:Landroid/widget/Button;
    01b5: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    01b7: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    01ba: iget v0, v6.Lcom/sec/chaton/AdminMenu;->C:Landroid/widget/Button;
    01bc: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    01be: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    01c1: iget v0, v6.Lcom/sec/chaton/AdminMenu;->D:Landroid/widget/Button;
    01c3: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    01c5: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    01c8: iget v0, v6.Lcom/sec/chaton/AdminMenu;->E:Landroid/widget/Button;
    01ca: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    01cc: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    01cf: invoke-static {}, Lcom/sec/chaton/msgsend/q;->b()Z
    01d2: move-result v0
    01d3: if-eqz v0, 02f6
    01d5: iget v0, v6.Lcom/sec/chaton/AdminMenu;->z:Landroid/widget/Button;
    01d7: const-string v1, 'A-Resend:ENABLED'
    01d9: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    01dc: invoke-static {}, Lcom/sec/chaton/msgsend/q;->g()Z
    01df: move-result v0
    01e0: if-eqz v0, 02ff
    01e2: iget v0, v6.Lcom/sec/chaton/AdminMenu;->A:Landroid/widget/Button;
    01e4: const-string v1, 'A-Resend:Noti enabled'
    01e6: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    01e9: const v0, 2131230784 (0x7f080040)
    01ec: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    01ef: move-result-object v0
    01f0: check-cast v0, Landroid/widget/Button;
    01f2: iput v0, v6.Lcom/sec/chaton/AdminMenu;->r:Landroid/widget/Button;
    01f4: const v0, 2131230785 (0x7f080041)
    01f7: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    01fa: move-result-object v0
    01fb: check-cast v0, Landroid/widget/Button;
    01fd: iput v0, v6.Lcom/sec/chaton/AdminMenu;->s:Landroid/widget/Button;
    01ff: const v0, 2131230786 (0x7f080042)
    0202: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    0205: move-result-object v0
    0206: check-cast v0, Landroid/widget/Button;
    0208: iput v0, v6.Lcom/sec/chaton/AdminMenu;->t:Landroid/widget/Button;
    020a: const v0, 2131230787 (0x7f080043)
    020d: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    0210: move-result-object v0
    0211: check-cast v0, Landroid/widget/Button;
    0213: iput v0, v6.Lcom/sec/chaton/AdminMenu;->w:Landroid/widget/Button;
    0215: const v0, 2131230788 (0x7f080044)
    0218: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    021b: move-result-object v0
    021c: check-cast v0, Landroid/widget/Button;
    021e: iput v0, v6.Lcom/sec/chaton/AdminMenu;->x:Landroid/widget/Button;
    0220: const v0, 2131230789 (0x7f080045)
    0223: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    0226: move-result-object v0
    0227: check-cast v0, Landroid/widget/Button;
    0229: iput v0, v6.Lcom/sec/chaton/AdminMenu;->y:Landroid/widget/Button;
    022b: iget v0, v6.Lcom/sec/chaton/AdminMenu;->r:Landroid/widget/Button;
    022d: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    022f: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0232: iget v0, v6.Lcom/sec/chaton/AdminMenu;->s:Landroid/widget/Button;
    0234: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    0236: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0239: iget v0, v6.Lcom/sec/chaton/AdminMenu;->t:Landroid/widget/Button;
    023b: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    023d: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0240: iget v0, v6.Lcom/sec/chaton/AdminMenu;->w:Landroid/widget/Button;
    0242: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    0244: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0247: iget v0, v6.Lcom/sec/chaton/AdminMenu;->x:Landroid/widget/Button;
    0249: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    024b: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    024e: iget v0, v6.Lcom/sec/chaton/AdminMenu;->y:Landroid/widget/Button;
    0250: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    0252: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0255: const v0, 2131230755 (0x7f080023)
    0258: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    025b: move-result-object v0
    025c: check-cast v0, Landroid/widget/Button;
    025e: iput v0, v6.Lcom/sec/chaton/AdminMenu;->u:Landroid/widget/Button;
    0260: iget v0, v6.Lcom/sec/chaton/AdminMenu;->u:Landroid/widget/Button;
    0262: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    0264: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0267: invoke-static {}, Lcom/sec/chaton/d/am;->a()Lcom/sec/chaton/d/a;
    026a: move-result-object v0
    026b: new-instance v1, Lcom/sec/chaton/a;
    026d: invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;
    0270: move-result-object v4
    0271: invoke-direct {v1, v6, v4}, Lcom/sec/chaton/a;-><init>(Lcom/sec/chaton/AdminMenu;Landroid/os/Looper;)V
    0274: invoke-virtual {v0, v1}, Lcom/sec/chaton/d/a;->c(Landroid/os/Handler;)V
    0277: const v0, 2131230754 (0x7f080022)
    027a: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    027d: move-result-object v0
    027e: check-cast v0, Landroid/widget/Button;
    0280: iput v0, v6.Lcom/sec/chaton/AdminMenu;->q:Landroid/widget/Button;
    0282: iget v0, v6.Lcom/sec/chaton/AdminMenu;->q:Landroid/widget/Button;
    0284: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    0286: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0289: invoke-static {}, Lcom/sec/chaton/util/p;->b()I
    028c: move-result v0
    028d: iput v0, v6.Lcom/sec/chaton/AdminMenu;->M:I
    028f: invoke-static {v5}, Lcom/sec/chaton/util/p;->a(I)V
    0292: iget v0, v6.Lcom/sec/chaton/AdminMenu;->M:I
    0294: if-lez v0, 0308
    0296: iget v0, v6.Lcom/sec/chaton/AdminMenu;->q:Landroid/widget/Button;
    0298: const-string v1, 'Log Off'
    029a: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    029d: iget v0, v6.Lcom/sec/chaton/AdminMenu;->L:Z
    029f: if-ne v0, v5, 02ab
    02a1: iget v0, v6.Lcom/sec/chaton/AdminMenu;->s:Landroid/widget/Button;
    02a3: invoke-virtual {v0, v2}, Landroid/widget/Button;->setEnabled(Z)V
    02a6: iget v0, v6.Lcom/sec/chaton/AdminMenu;->r:Landroid/widget/Button;
    02a8: invoke-virtual {v0, v2}, Landroid/widget/Button;->setEnabled(Z)V
    02ab: const v0, 2131230760 (0x7f080028)
    02ae: invoke-virtual {v6, v0}, Lcom/sec/chaton/AdminMenu;->findViewById(I)Landroid/view/View;
    02b1: move-result-object v0
    02b2: check-cast v0, Landroid/widget/Button;
    02b4: iput v0, v6.Lcom/sec/chaton/AdminMenu;->v:Landroid/widget/Button;
    02b6: iget v0, v6.Lcom/sec/chaton/AdminMenu;->v:Landroid/widget/Button;
    02b8: iget v1, v6.Lcom/sec/chaton/AdminMenu;->T:Landroid/view/View$OnClickListener;
    02ba: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    02bd: iget v0, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    02bf: const/16 v1, 8 (0x8)
    02c1: invoke-virtual {v0, v1}, Landroid/widget/TabHost;->setVisibility(I)V
    02c4: iget v0, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    02c6: invoke-virtual {v0, v6}, Landroid/widget/TabHost;->setOnTabChangedListener(Landroid/widget/TabHost$OnTabChangeListener;)V
    02c9: move(op=01) v1, v2
    02ca: iget v0, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    02cc: invoke-virtual {v0}, Landroid/widget/TabHost;->getTabWidget()Landroid/widget/TabWidget;
    02cf: move-result-object v0
    02d0: invoke-virtual {v0}, Landroid/widget/TabWidget;->getChildCount()I
    02d3: move-result v0
    02d4: if-ge v1, v0, 0310
    02d6: iget v0, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    02d8: invoke-virtual {v0}, Landroid/widget/TabHost;->getTabWidget()Landroid/widget/TabWidget;
    02db: move-result-object v0
    02dc: invoke-virtual {v0, v1}, Landroid/widget/TabWidget;->getChildAt(I)Landroid/view/View;
    02df: move-result-object v0
    02e0: const v4, 16908310 (0x1020016)
    02e3: invoke-virtual {v0, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    02e6: move-result-object v0
    02e7: check-cast v0, Landroid/widget/TextView;
    02e9: const-string v4, '#ffffff'
    02eb: invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I
    02ee: move-result v4
    02ef: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setTextColor(I)V
    02f2: binop/lit8(op=d8) v0, v1, 1 (0x1)
    02f4: move(op=01) v1, v0
    02f5: goto 02ca
    02f6: iget v0, v6.Lcom/sec/chaton/AdminMenu;->z:Landroid/widget/Button;
    02f8: const-string v1, 'A-Resend:DISABLED'
    02fa: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    02fd: goto/16 01dc
    02ff: iget v0, v6.Lcom/sec/chaton/AdminMenu;->A:Landroid/widget/Button;
    0301: const-string v1, 'A-Resend:Noti disabled'
    0303: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    0306: goto/16 01e9
    0308: iget v0, v6.Lcom/sec/chaton/AdminMenu;->q:Landroid/widget/Button;
    030a: const-string v1, 'Log On'
    030c: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    030f: goto 029d
    0310: if-eqz v3, 032c
    0312: const-string v0, 'mapping_mode'
    0314: invoke-virtual {v3, v0, v2}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z
    0317: move-result v0
    0318: iput v0, v6.Lcom/sec/chaton/AdminMenu;->L:Z
    031a: const-string v0, 'general_tab'
    031c: invoke-virtual {v3, v0, v5}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z
    031f: move-result v0
    0320: if-eqz v0, 0328
    0322: iget v0, v6.Lcom/sec/chaton/AdminMenu;->I:Landroid/widget/TabHost;
    0324: invoke-virtual {v0, v2}, Landroid/widget/TabHost;->setVisibility(I)V
    0327: return-void
    0328: invoke-direct {v6}, Lcom/sec/chaton/AdminMenu;->e()V
    032b: goto 0327
    032c: invoke-direct {v6}, Lcom/sec/chaton/AdminMenu;->e()V
    032f: goto 0327

  [Virtual Method] onTabChanged(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void