=== CLASS Lcom/sec/chaton/aq; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/sec/chaton/util/bb;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/aq;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] a() -> Z
    // registers=4, ins=1, outs=3, insns_size=35
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'uid'
    0006: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0009: move-result v0
    000a: if-eqz v0, 0021
    000c: new-instance v0, Lcom/sec/chaton/d/t;
    000e: iget v1, v3.Lcom/sec/chaton/aq;->a:Lcom/sec/chaton/TabActivity;
    0010: invoke-virtual {v1}, Lcom/sec/chaton/TabActivity;->getApplicationContext()Landroid/content/Context;
    0013: move-result-object v1
    0014: new-instance v2, Landroid/os/Handler;
    0016: invoke-direct {v2}, Landroid/os/Handler;-><init>()V
    0019: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/d/t;-><init>(Landroid/content/Context;Landroid/os/Handler;)V
    001c: invoke-virtual {v0}, Lcom/sec/chaton/d/t;->a()Lcom/sec/chaton/d/a/de;
    001f: const/4 v0, 1
    0020: return v0
    0021: const/4 v0, 0
    0022: goto 0020