=== CLASS Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO; (Source: AMS_OBJECT_TEXT_INFO.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] m_nFontFaceLength: I
  [Instance Field] m_nTextLength: I
  [Instance Field] m_strFontFaceName: Ljava/lang/String;
  [Instance Field] m_strText: Ljava/lang/String;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getM_cFontFaceName() -> [C
    // registers=2, ins=1, outs=1, insns_size=17
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_strFontFaceName:Ljava/lang/String;
    0002: invoke-virtual {v0}, Ljava/lang/String;->length()I
    0005: move-result v0
    0006: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0008: new-array v0, v0, [C
    000a: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_strFontFaceName:Ljava/lang/String;
    000c: invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C
    000f: move-result-object v0
    0010: return-object v0

  [Virtual Method] getM_cText() -> [C
    // registers=2, ins=1, outs=1, insns_size=17
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_strText:Ljava/lang/String;
    0002: invoke-virtual {v0}, Ljava/lang/String;->length()I
    0005: move-result v0
    0006: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0008: new-array v0, v0, [C
    000a: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_strText:Ljava/lang/String;
    000c: invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C
    000f: move-result-object v0
    0010: return-object v0

  [Virtual Method] getM_nFontFaceLength() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_nFontFaceLength:I
    0002: return v0

  [Virtual Method] getM_nTextLength() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_nTextLength:I
    0002: return v0

  [Virtual Method] getM_strFontFaceName() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_strFontFaceName:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] getM_strText() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_strText:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] setM_nFontFaceLength(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_nFontFaceLength:I
    0002: return-void

  [Virtual Method] setM_nTextLength(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_nTextLength:I
    0002: return-void

  [Virtual Method] setM_strFontFaceName(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_strFontFaceName:Ljava/lang/String;
    0002: return-void

  [Virtual Method] setM_strText(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_strText:Ljava/lang/String;
    0002: return-void