=== CLASS Lcom/sec/amsoma/structure/AMS_UI_DATA; (Source: AMS_UI_DATA.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] m_Bitmap: Landroid/graphics/Bitmap;
  [Instance Field] m_bStart: Z
  [Instance Field] m_cObjectSize: B
  [Instance Field] m_cObjectStyle: B
  [Instance Field] m_eObjectType: B
  [Instance Field] m_rectRegion: Lcom/sec/amsoma/structure/AMS_RECT;
  [Instance Field] m_rgbBack: I
  [Instance Field] m_rgbPen: I

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=11
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Lcom/sec/amsoma/structure/AMS_RECT;
    0005: invoke-direct {v0}, Lcom/sec/amsoma/structure/AMS_RECT;-><init>()V
    0008: iput v0, v1.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rectRegion:Lcom/sec/amsoma/structure/AMS_RECT;
    000a: return-void

  [Virtual Method] Init() -> V
    // registers=3, ins=1, outs=2, insns_size=39
    0000: const/4 v1, 0
    0001: const/4 v0, 1
    0002: iput v0, v2.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_eObjectType:B
    0004: iput v1, v2.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_cObjectStyle:B
    0006: const/4 v0, 2
    0007: iput v0, v2.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_cObjectSize:B
    0009: const v0, 65280 (0xff00)
    000c: iput v0, v2.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rgbPen:I
    000e: iput v1, v2.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rgbBack:I
    0010: iget v0, v2.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rectRegion:Lcom/sec/amsoma/structure/AMS_RECT;
    0012: invoke-virtual {v0, v1}, Lcom/sec/amsoma/structure/AMS_RECT;->setnLeft(S)V
    0015: iget v0, v2.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rectRegion:Lcom/sec/amsoma/structure/AMS_RECT;
    0017: invoke-virtual {v0, v1}, Lcom/sec/amsoma/structure/AMS_RECT;->setnTop(S)V
    001a: iget v0, v2.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rectRegion:Lcom/sec/amsoma/structure/AMS_RECT;
    001c: invoke-virtual {v0, v1}, Lcom/sec/amsoma/structure/AMS_RECT;->setnRight(S)V
    001f: iget v0, v2.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rectRegion:Lcom/sec/amsoma/structure/AMS_RECT;
    0021: invoke-virtual {v0, v1}, Lcom/sec/amsoma/structure/AMS_RECT;->setnBottom(S)V
    0024: iput v1, v2.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_bStart:Z
    0026: return-void

  [Virtual Method] SetRect(S, S, S, S) -> V
    // registers=6, ins=5, outs=2, insns_size=21
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rectRegion:Lcom/sec/amsoma/structure/AMS_RECT;
    0002: invoke-virtual {v0, v2}, Lcom/sec/amsoma/structure/AMS_RECT;->setnLeft(S)V
    0005: iget v0, v1.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rectRegion:Lcom/sec/amsoma/structure/AMS_RECT;
    0007: invoke-virtual {v0, v3}, Lcom/sec/amsoma/structure/AMS_RECT;->setnTop(S)V
    000a: iget v0, v1.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rectRegion:Lcom/sec/amsoma/structure/AMS_RECT;
    000c: invoke-virtual {v0, v4}, Lcom/sec/amsoma/structure/AMS_RECT;->setnRight(S)V
    000f: iget v0, v1.Lcom/sec/amsoma/structure/AMS_UI_DATA;->m_rectRegion:Lcom/sec/amsoma/structure/AMS_RECT;
    0011: invoke-virtual {v0, v5}, Lcom/sec/amsoma/structure/AMS_RECT;->setnBottom(S)V
    0014: return-void