=== CLASS Lcom/sec/amsoma/structure/AMS_OBJECT_DATA; (Source: AMS_OBJECT_DATA.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] m_TPoint: Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;
  [Instance Field] m_TRect: Lcom/sec/amsoma/structure/AMS_RECT;
  [Instance Field] m_TText: Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;
  [Instance Field] m_bObjectInputFlag: I
  [Instance Field] m_cAdditionalID: I
  [Instance Field] m_cSize: B
  [Instance Field] m_cStyle: I
  [Instance Field] m_eType: I
  [Instance Field] m_nColor565: I
  [Instance Field] m_nColorB: I
  [Instance Field] m_nColorG: I
  [Instance Field] m_nColorR: I
  [Instance Field] m_nDrawingMapID: I
  [Instance Field] m_nIsThisSimplified: B
  [Instance Field] m_nSpecialCodingBitSize: I

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=25
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Lcom/sec/amsoma/structure/AMS_RECT;
    0005: invoke-direct {v0}, Lcom/sec/amsoma/structure/AMS_RECT;-><init>()V
    0008: iput v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    000a: new-instance v0, Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;
    000c: invoke-direct {v0}, Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;-><init>()V
    000f: iput v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TText:Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;
    0011: new-instance v0, Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;
    0013: invoke-direct {v0}, Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;-><init>()V
    0016: iput v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TPoint:Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;
    0018: return-void

  [Virtual Method] equals(Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;) -> Z
    // registers=6, ins=2, outs=1, insns_size=254
    0000: const/4 v0, 0
    0001: const/4 v1, 1
    0002: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_eType:I
    0004: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_eType()I
    0007: move-result v3
    0008: if-eq v2, v3, 000b
    000a: return v0
    000b: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_eType:I
    000d: packed-switch v2, +231 (-> 00f4)
    0010: goto 000a
    0011: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_cSize:B
    0013: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_cSize()B
    0016: move-result v3
    0017: if-ne v2, v3, 000a
    0019: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorR:I
    001b: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_nColorR()I
    001e: move-result v3
    001f: if-ne v2, v3, 000a
    0021: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorG:I
    0023: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_nColorB()I
    0026: move-result v3
    0027: if-ne v2, v3, 000a
    0029: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorB:I
    002b: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_nColorB()I
    002e: move-result v3
    002f: if-ne v2, v3, 000a
    0031: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0033: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nLeft:S
    0035: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0037: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nLeft:S
    0039: if-ne v2, v3, 000a
    003b: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    003d: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nRight:S
    003f: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0041: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nRight:S
    0043: if-ne v2, v3, 000a
    0045: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0047: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nTop:S
    0049: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    004b: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nTop:S
    004d: if-ne v2, v3, 000a
    004f: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0051: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nBottom:S
    0053: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0055: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nBottom:S
    0057: if-ne v2, v3, 000a
    0059: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TText:Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;
    005b: iget v2, v2.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_strText:Ljava/lang/String;
    005d: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TText:Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;
    005f: iget v3, v3.Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;->m_strText:Ljava/lang/String;
    0061: if-ne v2, v3, 000a
    0063: move(op=01) v0, v1
    0064: goto 000a
    0065: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_cStyle:I
    0067: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_cStyle()I
    006a: move-result v3
    006b: if-ne v2, v3, 000a
    006d: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_cAdditionalID:I
    006f: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_cAdditionalID()I
    0072: move-result v3
    0073: if-ne v2, v3, 000a
    0075: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0077: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nLeft:S
    0079: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    007b: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nLeft:S
    007d: if-ne v2, v3, 000a
    007f: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0081: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nRight:S
    0083: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0085: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nRight:S
    0087: if-ne v2, v3, 000a
    0089: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    008b: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nTop:S
    008d: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    008f: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nTop:S
    0091: if-ne v2, v3, 000a
    0093: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0095: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nBottom:S
    0097: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0099: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nBottom:S
    009b: if-ne v2, v3, 000a
    009d: move(op=01) v0, v1
    009e: goto/16 000a
    00a0: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_cStyle:I
    00a2: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_cStyle()I
    00a5: move-result v3
    00a6: if-ne v2, v3, 000a
    00a8: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_cSize:B
    00aa: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_cSize()B
    00ad: move-result v3
    00ae: if-ne v2, v3, 000a
    00b0: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorR:I
    00b2: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_nColorR()I
    00b5: move-result v3
    00b6: if-ne v2, v3, 000a
    00b8: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorG:I
    00ba: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_nColorG()I
    00bd: move-result v3
    00be: if-ne v2, v3, 000a
    00c0: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorB:I
    00c2: invoke-virtual {v5}, Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->getM_nColorB()I
    00c5: move-result v3
    00c6: if-ne v2, v3, 000a
    00c8: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    00ca: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nLeft:S
    00cc: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    00ce: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nLeft:S
    00d0: if-ne v2, v3, 000a
    00d2: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    00d4: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nRight:S
    00d6: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    00d8: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nRight:S
    00da: if-ne v2, v3, 000a
    00dc: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    00de: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nTop:S
    00e0: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    00e2: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nTop:S
    00e4: if-ne v2, v3, 000a
    00e6: iget v2, v4.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    00e8: iget v2, v2.Lcom/sec/amsoma/structure/AMS_RECT;->nBottom:S
    00ea: iget v3, v5.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    00ec: iget v3, v3.Lcom/sec/amsoma/structure/AMS_RECT;->nBottom:S
    00ee: if-ne v2, v3, 000a
    00f0: move(op=01) v0, v1
    00f1: goto/16 000a
    00f3: nop
    00f4: packed-switch-payload first=2 targets=[4, 88, 147]

  [Virtual Method] getM_TPoint() -> Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TPoint:Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;
    0002: return-object v0

  [Virtual Method] getM_TRect() -> Lcom/sec/amsoma/structure/AMS_RECT;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0002: return-object v0

  [Virtual Method] getM_TText() -> Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TText:Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;
    0002: return-object v0

  [Virtual Method] getM_bObjectInputFlag() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_bObjectInputFlag:I
    0002: return v0

  [Virtual Method] getM_cAdditionalID() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_cAdditionalID:I
    0002: return v0

  [Virtual Method] getM_cSize() -> B
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_cSize:B
    0002: return v0

  [Virtual Method] getM_cStyle() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_cStyle:I
    0002: return v0

  [Virtual Method] getM_eType() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_eType:I
    0002: return v0

  [Virtual Method] getM_nColor565() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColor565:I
    0002: return v0

  [Virtual Method] getM_nColorB() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorB:I
    0002: return v0

  [Virtual Method] getM_nColorG() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorG:I
    0002: return v0

  [Virtual Method] getM_nColorR() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorR:I
    0002: return v0

  [Virtual Method] getM_nDrawingMapID() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nDrawingMapID:I
    0002: return v0

  [Virtual Method] getM_nIsThisSimplified() -> B
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nIsThisSimplified:B
    0002: return v0

  [Virtual Method] getM_nSpecialCodingBitSize() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nSpecialCodingBitSize:I
    0002: return v0

  [Virtual Method] setM_TPoint(Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TPoint:Lcom/sec/amsoma/structure/AMS_OBJECT_POINT_INFO;
    0002: return-void

  [Virtual Method] setM_TRect(Lcom/sec/amsoma/structure/AMS_RECT;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TRect:Lcom/sec/amsoma/structure/AMS_RECT;
    0002: return-void

  [Virtual Method] setM_TText(Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_TText:Lcom/sec/amsoma/structure/AMS_OBJECT_TEXT_INFO;
    0002: return-void

  [Virtual Method] setM_bObjectInputFlag(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_bObjectInputFlag:I
    0002: return-void

  [Virtual Method] setM_cAdditionalID(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_cAdditionalID:I
    0002: return-void

  [Virtual Method] setM_cSize(B) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_cSize:B
    0002: return-void

  [Virtual Method] setM_cStyle(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_cStyle:I
    0002: return-void

  [Virtual Method] setM_eType(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_eType:I
    0002: return-void

  [Virtual Method] setM_nColor565(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColor565:I
    0002: return-void

  [Virtual Method] setM_nColorB(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorB:I
    0002: return-void

  [Virtual Method] setM_nColorG(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorG:I
    0002: return-void

  [Virtual Method] setM_nColorR(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nColorR:I
    0002: return-void

  [Virtual Method] setM_nDrawingMapID(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nDrawingMapID:I
    0002: return-void

  [Virtual Method] setM_nIsThisSimplified(B) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nIsThisSimplified:B
    0002: return-void

  [Virtual Method] setM_nSpecialCodingBitSize(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_OBJECT_DATA;->m_nSpecialCodingBitSize:I
    0002: return-void