=== CLASS Lcom/sec/chaton/bj; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/widget/CompoundButton$OnCheckedChangeListener;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/bj;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onCheckedChanged(Landroid/widget/CompoundButton;, Z) -> V
    // registers=5, ins=3, outs=2, insns_size=32
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0005: const-string v1, '[DataPacket] isChecked '
    0007: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000a: move-result-object v0
    000b: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    000e: move-result-object v0
    000f: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0012: move-result-object v0
    0013: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    0016: move-result-object v1
    0017: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    001a: iget v0, v2.Lcom/sec/chaton/bj;->a:Lcom/sec/chaton/TabActivity;
    001c: invoke-static {v0, v4}, Lcom/sec/chaton/TabActivity;->a(Lcom/sec/chaton/TabActivity;Z)Z
    001f: return-void