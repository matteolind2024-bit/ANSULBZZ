=== CLASS Lcom/sec/chaton/as; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/sec/chaton/util/bb;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/as;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] a() -> Z
    // registers=3, ins=1, outs=2, insns_size=20
    0000: new-instance v0, Lcom/sec/chaton/d/aq;
    0002: iget v1, v2.Lcom/sec/chaton/as;->a:Lcom/sec/chaton/TabActivity;
    0004: iget v1, v1.Lcom/sec/chaton/TabActivity;->e:Landroid/os/Handler;
    0006: invoke-direct {v0, v1}, Lcom/sec/chaton/d/aq;-><init>(Landroid/os/Handler;)V
    0009: iget v1, v2.Lcom/sec/chaton/as;->a:Lcom/sec/chaton/TabActivity;
    000b: invoke-virtual {v1}, Lcom/sec/chaton/TabActivity;->getApplicationContext()Landroid/content/Context;
    000e: move-result-object v1
    000f: invoke-virtual {v0, v1}, Lcom/sec/chaton/d/aq;->a(Landroid/content/Context;)V
    0012: const/4 v0, 1
    0013: return v0