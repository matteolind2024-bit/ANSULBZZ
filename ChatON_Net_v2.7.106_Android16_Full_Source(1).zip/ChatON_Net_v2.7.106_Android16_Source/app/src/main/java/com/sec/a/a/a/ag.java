=== CLASS Lcom/sec/a/a/a/ag; (Source: MsgFrontend.java) ===
  Super: Lcom/google/protobuf/GeneratedMessageLite;
  Interfaces: Lcom/sec/a/a/a/ai;
  [Static Field] a: Lcom/sec/a/a/a/ag;
  [Instance Field] b: I
  [Instance Field] c: Ljava/lang/Object;
  [Instance Field] d: Ljava/lang/Object;
  [Instance Field] e: Ljava/lang/Object;
  [Instance Field] f: Ljava/lang/Object;
  [Instance Field] g: Ljava/lang/Object;
  [Instance Field] h: B
  [Instance Field] i: I

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=2, insns_size=14
    0000: new-instance v0, Lcom/sec/a/a/a/ag;
    0002: const/4 v1, 1
    0003: invoke-direct {v0, v1}, Lcom/sec/a/a/a/ag;-><init>(Z)V
    0006: sput v0, Lcom/sec/a/a/a/ag;->a:Lcom/sec/a/a/a/ag;
    0008: sget v0, Lcom/sec/a/a/a/ag;->a:Lcom/sec/a/a/a/ag;
    000a: invoke-direct {v0}, Lcom/sec/a/a/a/ag;->t()V
    000d: return-void

  [Direct Method] <init>(Lcom/sec/a/a/a/ah;) -> V
    // registers=3, ins=2, outs=2, insns_size=9
    0000: const/4 v0, -1
    0001: invoke-direct {v1, v2}, Lcom/google/protobuf/GeneratedMessageLite;-><init>(Lcom/google/protobuf/GeneratedMessageLite$Builder;)V
    0004: iput v0, v1.Lcom/sec/a/a/a/ag;->h:B
    0006: iput v0, v1.Lcom/sec/a/a/a/ag;->i:I
    0008: return-void

  [Direct Method] <init>(Lcom/sec/a/a/a/ah;, Lcom/sec/a/a/a/b;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/sec/a/a/a/ag;-><init>(Lcom/sec/a/a/a/ah;)V
    0003: return-void

  [Direct Method] <init>(Z) -> V
    // registers=3, ins=2, outs=1, insns_size=9
    0000: const/4 v0, -1
    0001: invoke-direct {v1}, Lcom/google/protobuf/GeneratedMessageLite;-><init>()V
    0004: iput v0, v1.Lcom/sec/a/a/a/ag;->h:B
    0006: iput v0, v1.Lcom/sec/a/a/a/ag;->i:I
    0008: return-void

  [Direct Method] a(Lcom/sec/a/a/a/ag;, I) -> I
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/a/a/a/ag;->b:I
    0002: return v1

  [Direct Method] a() -> Lcom/sec/a/a/a/ag;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/sec/a/a/a/ag;->a:Lcom/sec/a/a/a/ag;
    0002: return-object v0

  [Direct Method] a([B) -> Lcom/sec/a/a/a/ag;
    // registers=2, ins=1, outs=2, insns_size=15
    0000: invoke-static {}, Lcom/sec/a/a/a/ag;->newBuilder()Lcom/sec/a/a/a/ah;
    0003: move-result-object v0
    0004: invoke-virtual {v0, v1}, Lcom/sec/a/a/a/ah;->mergeFrom([B)Lcom/google/protobuf/AbstractMessageLite$Builder;
    0007: move-result-object v0
    0008: check-cast v0, Lcom/sec/a/a/a/ah;
    000a: invoke-static {v0}, Lcom/sec/a/a/a/ah;->a(Lcom/sec/a/a/a/ah;)Lcom/sec/a/a/a/ag;
    000d: move-result-object v0
    000e: return-object v0

  [Direct Method] a(Lcom/sec/a/a/a/ag;) -> Lcom/sec/a/a/a/ah;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: invoke-static {}, Lcom/sec/a/a/a/ag;->newBuilder()Lcom/sec/a/a/a/ah;
    0003: move-result-object v0
    0004: invoke-virtual {v0, v1}, Lcom/sec/a/a/a/ah;->a(Lcom/sec/a/a/a/ag;)Lcom/sec/a/a/a/ah;
    0007: move-result-object v0
    0008: return-object v0

  [Direct Method] a(Lcom/sec/a/a/a/ag;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/a/a/a/ag;->c:Ljava/lang/Object;
    0002: return-object v1

  [Direct Method] b(Lcom/sec/a/a/a/ag;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/a/a/a/ag;->d:Ljava/lang/Object;
    0002: return-object v1

  [Direct Method] c(Lcom/sec/a/a/a/ag;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/a/a/a/ag;->e:Ljava/lang/Object;
    0002: return-object v1

  [Direct Method] d(Lcom/sec/a/a/a/ag;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/a/a/a/ag;->f:Ljava/lang/Object;
    0002: return-object v1

  [Direct Method] e(Lcom/sec/a/a/a/ag;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/a/a/a/ag;->g:Ljava/lang/Object;
    0002: return-object v1

  [Direct Method] newBuilder() -> Lcom/sec/a/a/a/ah;
    // registers=1, ins=0, outs=0, insns_size=5
    0000: invoke-static {}, Lcom/sec/a/a/a/ah;->f()Lcom/sec/a/a/a/ah;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] o() -> Lcom/google/protobuf/ByteString;
    // registers=3, ins=1, outs=1, insns_size=18
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->c:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 000f
    0006: check-cast v0, Ljava/lang/String;
    0008: invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;
    000b: move-result-object v0
    000c: iput v0, v2.Lcom/sec/a/a/a/ag;->c:Ljava/lang/Object;
    000e: return-object v0
    000f: check-cast v0, Lcom/google/protobuf/ByteString;
    0011: goto 000e

  [Direct Method] p() -> Lcom/google/protobuf/ByteString;
    // registers=3, ins=1, outs=1, insns_size=18
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->d:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 000f
    0006: check-cast v0, Ljava/lang/String;
    0008: invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;
    000b: move-result-object v0
    000c: iput v0, v2.Lcom/sec/a/a/a/ag;->d:Ljava/lang/Object;
    000e: return-object v0
    000f: check-cast v0, Lcom/google/protobuf/ByteString;
    0011: goto 000e

  [Direct Method] q() -> Lcom/google/protobuf/ByteString;
    // registers=3, ins=1, outs=1, insns_size=18
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->e:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 000f
    0006: check-cast v0, Ljava/lang/String;
    0008: invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;
    000b: move-result-object v0
    000c: iput v0, v2.Lcom/sec/a/a/a/ag;->e:Ljava/lang/Object;
    000e: return-object v0
    000f: check-cast v0, Lcom/google/protobuf/ByteString;
    0011: goto 000e

  [Direct Method] r() -> Lcom/google/protobuf/ByteString;
    // registers=3, ins=1, outs=1, insns_size=18
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->f:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 000f
    0006: check-cast v0, Ljava/lang/String;
    0008: invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;
    000b: move-result-object v0
    000c: iput v0, v2.Lcom/sec/a/a/a/ag;->f:Ljava/lang/Object;
    000e: return-object v0
    000f: check-cast v0, Lcom/google/protobuf/ByteString;
    0011: goto 000e

  [Direct Method] s() -> Lcom/google/protobuf/ByteString;
    // registers=3, ins=1, outs=1, insns_size=18
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->g:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 000f
    0006: check-cast v0, Ljava/lang/String;
    0008: invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;
    000b: move-result-object v0
    000c: iput v0, v2.Lcom/sec/a/a/a/ag;->g:Ljava/lang/Object;
    000e: return-object v0
    000f: check-cast v0, Lcom/google/protobuf/ByteString;
    0011: goto 000e

  [Direct Method] t() -> V
    // registers=2, ins=1, outs=0, insns_size=21
    0000: const-string v0, ''
    0002: iput v0, v1.Lcom/sec/a/a/a/ag;->c:Ljava/lang/Object;
    0004: const-string v0, ''
    0006: iput v0, v1.Lcom/sec/a/a/a/ag;->d:Ljava/lang/Object;
    0008: const-string v0, ''
    000a: iput v0, v1.Lcom/sec/a/a/a/ag;->e:Ljava/lang/Object;
    000c: const-string v0, ''
    000e: iput v0, v1.Lcom/sec/a/a/a/ag;->f:Ljava/lang/Object;
    0010: const-string v0, ''
    0012: iput v0, v1.Lcom/sec/a/a/a/ag;->g:Ljava/lang/Object;
    0014: return-void

  [Virtual Method] b() -> Lcom/sec/a/a/a/ag;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: sget v0, Lcom/sec/a/a/a/ag;->a:Lcom/sec/a/a/a/ag;
    0002: return-object v0

  [Virtual Method] c() -> Z
    // registers=3, ins=1, outs=0, insns_size=10
    0000: const/4 v0, 1
    0001: iget v1, v2.Lcom/sec/a/a/a/ag;->b:I
    0003: binop/lit8(op=dd) v1, v1, 1 (0x1)
    0005: if-ne v1, v0, 0008
    0007: return v0
    0008: const/4 v0, 0
    0009: goto 0007

  [Virtual Method] d() -> Ljava/lang/String;
    // registers=3, ins=1, outs=1, insns_size=25
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->c:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 0009
    0006: check-cast v0, Ljava/lang/String;
    0008: return-object v0
    0009: check-cast v0, Lcom/google/protobuf/ByteString;
    000b: invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;
    000e: move-result-object v1
    000f: invoke-static {v0}, Lcom/google/protobuf/Internal;->isValidUtf8(Lcom/google/protobuf/ByteString;)Z
    0012: move-result v0
    0013: if-eqz v0, 0017
    0015: iput v1, v2.Lcom/sec/a/a/a/ag;->c:Ljava/lang/Object;
    0017: move(op=07) v0, v1
    0018: goto 0008

  [Virtual Method] e() -> Z
    // registers=3, ins=1, outs=0, insns_size=11
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->b:I
    0002: binop/lit8(op=dd) v0, v0, 2 (0x2)
    0004: const/4 v1, 2
    0005: if-ne v0, v1, 0009
    0007: const/4 v0, 1
    0008: return v0
    0009: const/4 v0, 0
    000a: goto 0008

  [Virtual Method] f() -> Ljava/lang/String;
    // registers=3, ins=1, outs=1, insns_size=25
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->d:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 0009
    0006: check-cast v0, Ljava/lang/String;
    0008: return-object v0
    0009: check-cast v0, Lcom/google/protobuf/ByteString;
    000b: invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;
    000e: move-result-object v1
    000f: invoke-static {v0}, Lcom/google/protobuf/Internal;->isValidUtf8(Lcom/google/protobuf/ByteString;)Z
    0012: move-result v0
    0013: if-eqz v0, 0017
    0015: iput v1, v2.Lcom/sec/a/a/a/ag;->d:Ljava/lang/Object;
    0017: move(op=07) v0, v1
    0018: goto 0008

  [Virtual Method] g() -> Z
    // registers=3, ins=1, outs=0, insns_size=11
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->b:I
    0002: binop/lit8(op=dd) v0, v0, 4 (0x4)
    0004: const/4 v1, 4
    0005: if-ne v0, v1, 0009
    0007: const/4 v0, 1
    0008: return v0
    0009: const/4 v0, 0
    000a: goto 0008

  [Virtual Method] getDefaultInstanceForType() -> Lcom/google/protobuf/MessageLite;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/ag;->b()Lcom/sec/a/a/a/ag;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getSerializedSize() -> I
    // registers=6, ins=1, outs=2, insns_size=95
    0000: const/4 v4, 4
    0001: const/4 v3, 2
    0002: iget v0, v5.Lcom/sec/a/a/a/ag;->i:I
    0004: const/4 v1, -1
    0005: if-eq v0, v1, 0008
    0007: return v0
    0008: const/4 v0, 0
    0009: iget v1, v5.Lcom/sec/a/a/a/ag;->b:I
    000b: binop/lit8(op=dd) v1, v1, 1 (0x1)
    000d: const/4 v2, 1
    000e: if-ne v1, v2, 0019
    0010: invoke-direct {v5}, Lcom/sec/a/a/a/ag;->o()Lcom/google/protobuf/ByteString;
    0013: move-result-object v1
    0014: invoke-static {v3, v1}, Lcom/google/protobuf/CodedOutputStream;->computeBytesSize(ILcom/google/protobuf/ByteString;)I
    0017: move-result v1
    0018: binop/2addr(op=b0) v0, v1
    0019: iget v1, v5.Lcom/sec/a/a/a/ag;->b:I
    001b: binop/lit8(op=dd) v1, v1, 2 (0x2)
    001d: if-ne v1, v3, 0029
    001f: const/4 v1, 3
    0020: invoke-direct {v5}, Lcom/sec/a/a/a/ag;->p()Lcom/google/protobuf/ByteString;
    0023: move-result-object v2
    0024: invoke-static {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->computeBytesSize(ILcom/google/protobuf/ByteString;)I
    0027: move-result v1
    0028: binop/2addr(op=b0) v0, v1
    0029: iget v1, v5.Lcom/sec/a/a/a/ag;->b:I
    002b: binop/lit8(op=dd) v1, v1, 4 (0x4)
    002d: if-ne v1, v4, 0038
    002f: invoke-direct {v5}, Lcom/sec/a/a/a/ag;->q()Lcom/google/protobuf/ByteString;
    0032: move-result-object v1
    0033: invoke-static {v4, v1}, Lcom/google/protobuf/CodedOutputStream;->computeBytesSize(ILcom/google/protobuf/ByteString;)I
    0036: move-result v1
    0037: binop/2addr(op=b0) v0, v1
    0038: iget v1, v5.Lcom/sec/a/a/a/ag;->b:I
    003a: binop/lit8(op=dd) v1, v1, 8 (0x8)
    003c: const/16 v2, 8 (0x8)
    003e: if-ne v1, v2, 004a
    0040: const/4 v1, 5
    0041: invoke-direct {v5}, Lcom/sec/a/a/a/ag;->r()Lcom/google/protobuf/ByteString;
    0044: move-result-object v2
    0045: invoke-static {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->computeBytesSize(ILcom/google/protobuf/ByteString;)I
    0048: move-result v1
    0049: binop/2addr(op=b0) v0, v1
    004a: iget v1, v5.Lcom/sec/a/a/a/ag;->b:I
    004c: binop/lit8(op=dd) v1, v1, 16 (0x10)
    004e: const/16 v2, 16 (0x10)
    0050: if-ne v1, v2, 005c
    0052: const/4 v1, 6
    0053: invoke-direct {v5}, Lcom/sec/a/a/a/ag;->s()Lcom/google/protobuf/ByteString;
    0056: move-result-object v2
    0057: invoke-static {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->computeBytesSize(ILcom/google/protobuf/ByteString;)I
    005a: move-result v1
    005b: binop/2addr(op=b0) v0, v1
    005c: iput v0, v5.Lcom/sec/a/a/a/ag;->i:I
    005e: goto 0007

  [Virtual Method] h() -> Ljava/lang/String;
    // registers=3, ins=1, outs=1, insns_size=25
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->e:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 0009
    0006: check-cast v0, Ljava/lang/String;
    0008: return-object v0
    0009: check-cast v0, Lcom/google/protobuf/ByteString;
    000b: invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;
    000e: move-result-object v1
    000f: invoke-static {v0}, Lcom/google/protobuf/Internal;->isValidUtf8(Lcom/google/protobuf/ByteString;)Z
    0012: move-result v0
    0013: if-eqz v0, 0017
    0015: iput v1, v2.Lcom/sec/a/a/a/ag;->e:Ljava/lang/Object;
    0017: move(op=07) v0, v1
    0018: goto 0008

  [Virtual Method] i() -> Z
    // registers=3, ins=1, outs=0, insns_size=12
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->b:I
    0002: binop/lit8(op=dd) v0, v0, 8 (0x8)
    0004: const/16 v1, 8 (0x8)
    0006: if-ne v0, v1, 000a
    0008: const/4 v0, 1
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] isInitialized() -> Z
    // registers=4, ins=1, outs=0, insns_size=14
    0000: const/4 v0, 1
    0001: iget v1, v3.Lcom/sec/a/a/a/ag;->h:B
    0003: const/4 v2, -1
    0004: if-eq v1, v2, 000b
    0006: if-ne v1, v0, 0009
    0008: return v0
    0009: const/4 v0, 0
    000a: goto 0008
    000b: iput v0, v3.Lcom/sec/a/a/a/ag;->h:B
    000d: goto 0008

  [Virtual Method] j() -> Ljava/lang/String;
    // registers=3, ins=1, outs=1, insns_size=25
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->f:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 0009
    0006: check-cast v0, Ljava/lang/String;
    0008: return-object v0
    0009: check-cast v0, Lcom/google/protobuf/ByteString;
    000b: invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;
    000e: move-result-object v1
    000f: invoke-static {v0}, Lcom/google/protobuf/Internal;->isValidUtf8(Lcom/google/protobuf/ByteString;)Z
    0012: move-result v0
    0013: if-eqz v0, 0017
    0015: iput v1, v2.Lcom/sec/a/a/a/ag;->f:Ljava/lang/Object;
    0017: move(op=07) v0, v1
    0018: goto 0008

  [Virtual Method] k() -> Z
    // registers=3, ins=1, outs=0, insns_size=12
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->b:I
    0002: binop/lit8(op=dd) v0, v0, 16 (0x10)
    0004: const/16 v1, 16 (0x10)
    0006: if-ne v0, v1, 000a
    0008: const/4 v0, 1
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] l() -> Ljava/lang/String;
    // registers=3, ins=1, outs=1, insns_size=25
    0000: iget v0, v2.Lcom/sec/a/a/a/ag;->g:Ljava/lang/Object;
    0002: instance-of v1, v0, Ljava/lang/String;
    0004: if-eqz v1, 0009
    0006: check-cast v0, Ljava/lang/String;
    0008: return-object v0
    0009: check-cast v0, Lcom/google/protobuf/ByteString;
    000b: invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;
    000e: move-result-object v1
    000f: invoke-static {v0}, Lcom/google/protobuf/Internal;->isValidUtf8(Lcom/google/protobuf/ByteString;)Z
    0012: move-result v0
    0013: if-eqz v0, 0017
    0015: iput v1, v2.Lcom/sec/a/a/a/ag;->g:Ljava/lang/Object;
    0017: move(op=07) v0, v1
    0018: goto 0008

  [Virtual Method] m() -> Lcom/sec/a/a/a/ah;
    // registers=2, ins=1, outs=0, insns_size=5
    0000: invoke-static {}, Lcom/sec/a/a/a/ag;->newBuilder()Lcom/sec/a/a/a/ah;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] n() -> Lcom/sec/a/a/a/ah;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-static {v1}, Lcom/sec/a/a/a/ag;->a(Lcom/sec/a/a/a/ag;)Lcom/sec/a/a/a/ah;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] newBuilderForType() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/ag;->m()Lcom/sec/a/a/a/ah;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] toBuilder() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/ag;->n()Lcom/sec/a/a/a/ah;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] writeReplace() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-super {v1}, Lcom/google/protobuf/GeneratedMessageLite;->writeReplace()Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] writeTo(Lcom/google/protobuf/CodedOutputStream;) -> V
    // registers=6, ins=2, outs=3, insns_size=79
    0000: const/4 v3, 4
    0001: const/4 v2, 2
    0002: invoke-virtual {v4}, Lcom/sec/a/a/a/ag;->getSerializedSize()I
    0005: iget v0, v4.Lcom/sec/a/a/a/ag;->b:I
    0007: binop/lit8(op=dd) v0, v0, 1 (0x1)
    0009: const/4 v1, 1
    000a: if-ne v0, v1, 0013
    000c: invoke-direct {v4}, Lcom/sec/a/a/a/ag;->o()Lcom/google/protobuf/ByteString;
    000f: move-result-object v0
    0010: invoke-virtual {v5, v2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeBytes(ILcom/google/protobuf/ByteString;)V
    0013: iget v0, v4.Lcom/sec/a/a/a/ag;->b:I
    0015: binop/lit8(op=dd) v0, v0, 2 (0x2)
    0017: if-ne v0, v2, 0021
    0019: const/4 v0, 3
    001a: invoke-direct {v4}, Lcom/sec/a/a/a/ag;->p()Lcom/google/protobuf/ByteString;
    001d: move-result-object v1
    001e: invoke-virtual {v5, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeBytes(ILcom/google/protobuf/ByteString;)V
    0021: iget v0, v4.Lcom/sec/a/a/a/ag;->b:I
    0023: binop/lit8(op=dd) v0, v0, 4 (0x4)
    0025: if-ne v0, v3, 002e
    0027: invoke-direct {v4}, Lcom/sec/a/a/a/ag;->q()Lcom/google/protobuf/ByteString;
    002a: move-result-object v0
    002b: invoke-virtual {v5, v3, v0}, Lcom/google/protobuf/CodedOutputStream;->writeBytes(ILcom/google/protobuf/ByteString;)V
    002e: iget v0, v4.Lcom/sec/a/a/a/ag;->b:I
    0030: binop/lit8(op=dd) v0, v0, 8 (0x8)
    0032: const/16 v1, 8 (0x8)
    0034: if-ne v0, v1, 003e
    0036: const/4 v0, 5
    0037: invoke-direct {v4}, Lcom/sec/a/a/a/ag;->r()Lcom/google/protobuf/ByteString;
    003a: move-result-object v1
    003b: invoke-virtual {v5, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeBytes(ILcom/google/protobuf/ByteString;)V
    003e: iget v0, v4.Lcom/sec/a/a/a/ag;->b:I
    0040: binop/lit8(op=dd) v0, v0, 16 (0x10)
    0042: const/16 v1, 16 (0x10)
    0044: if-ne v0, v1, 004e
    0046: const/4 v0, 6
    0047: invoke-direct {v4}, Lcom/sec/a/a/a/ag;->s()Lcom/google/protobuf/ByteString;
    004a: move-result-object v1
    004b: invoke-virtual {v5, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeBytes(ILcom/google/protobuf/ByteString;)V
    004e: return-void