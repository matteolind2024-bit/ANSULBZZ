=== CLASS Lcom/sec/chaton/bi; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  [Static Field] a: [I

  [Direct Method] <clinit>() -> V
    // registers=3, ins=0, outs=1, insns_size=101
    0000: invoke-static {}, Lcom/sec/chaton/s;->values()[Lcom/sec/chaton/s;
    0003: move-result-object v0
    0004: move(op=21) v0, v0
    0005: new-array v0, v0, [I
    0007: sput v0, Lcom/sec/chaton/bi;->a:[I
    0009: sget v0, Lcom/sec/chaton/bi;->a:[I
    000b: sget v1, Lcom/sec/chaton/s;->a:Lcom/sec/chaton/s;
    000d: invoke-virtual {v1}, Lcom/sec/chaton/s;->ordinal()I
    0010: move-result v1
    0011: const/4 v2, 1
    0012: aput(op=4b) v2, v0[v1]
    0014: sget v0, Lcom/sec/chaton/bi;->a:[I
    0016: sget v1, Lcom/sec/chaton/s;->b:Lcom/sec/chaton/s;
    0018: invoke-virtual {v1}, Lcom/sec/chaton/s;->ordinal()I
    001b: move-result v1
    001c: const/4 v2, 2
    001d: aput(op=4b) v2, v0[v1]
    001f: sget v0, Lcom/sec/chaton/bi;->a:[I
    0021: sget v1, Lcom/sec/chaton/s;->c:Lcom/sec/chaton/s;
    0023: invoke-virtual {v1}, Lcom/sec/chaton/s;->ordinal()I
    0026: move-result v1
    0027: const/4 v2, 3
    0028: aput(op=4b) v2, v0[v1]
    002a: sget v0, Lcom/sec/chaton/bi;->a:[I
    002c: sget v1, Lcom/sec/chaton/s;->d:Lcom/sec/chaton/s;
    002e: invoke-virtual {v1}, Lcom/sec/chaton/s;->ordinal()I
    0031: move-result v1
    0032: const/4 v2, 4
    0033: aput(op=4b) v2, v0[v1]
    0035: sget v0, Lcom/sec/chaton/bi;->a:[I
    0037: sget v1, Lcom/sec/chaton/s;->e:Lcom/sec/chaton/s;
    0039: invoke-virtual {v1}, Lcom/sec/chaton/s;->ordinal()I
    003c: move-result v1
    003d: const/4 v2, 5
    003e: aput(op=4b) v2, v0[v1]
    0040: sget v0, Lcom/sec/chaton/bi;->a:[I
    0042: sget v1, Lcom/sec/chaton/s;->f:Lcom/sec/chaton/s;
    0044: invoke-virtual {v1}, Lcom/sec/chaton/s;->ordinal()I
    0047: move-result v1
    0048: const/4 v2, 6
    0049: aput(op=4b) v2, v0[v1]
    004b: sget v0, Lcom/sec/chaton/bi;->a:[I
    004d: sget v1, Lcom/sec/chaton/s;->g:Lcom/sec/chaton/s;
    004f: invoke-virtual {v1}, Lcom/sec/chaton/s;->ordinal()I
    0052: move-result v1
    0053: const/4 v2, 7
    0054: aput(op=4b) v2, v0[v1]
    0056: return-void
    0057: move-exception v0
    0058: goto 0056
    0059: move-exception v0
    005a: goto 004b
    005b: move-exception v0
    005c: goto 0040
    005d: move-exception v0
    005e: goto 0035
    005f: move-exception v0
    0060: goto 002a
    0061: move-exception v0
    0062: goto 001f
    0063: move-exception v0
    0064: goto 0014