=== CLASS Lcom/sec/chaton/DataPacketDialog2; (Source: DataPacketDialog2.java) ===
  Super: Landroid/support/v4/app/DialogFragment;
  [Static Field] a: Ljava/lang/String;
  [Instance Field] b: Landroid/widget/Button;
  [Instance Field] c: Landroid/widget/CheckBox;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=9
    0000: const-class v0, Lcom/sec/chaton/DataPacketDialog2;
    0002: invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0005: move-result-object v0
    0006: sput v0, Lcom/sec/chaton/DataPacketDialog2;->a:Ljava/lang/String;
    0008: return-void

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/app/DialogFragment;-><init>()V
    0003: return-void

  [Direct Method] a(Lcom/sec/chaton/DataPacketDialog2;) -> Landroid/widget/CheckBox;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/DataPacketDialog2;->c:Landroid/widget/CheckBox;
    0002: return-object v0

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=4, ins=2, outs=3, insns_size=9
    0000: invoke-super {v2, v3}, Landroid/support/v4/app/DialogFragment;->onCreate(Landroid/os/Bundle;)V
    0003: const/4 v0, 2
    0004: const/4 v1, 0
    0005: invoke-virtual {v2, v0, v1}, Lcom/sec/chaton/DataPacketDialog2;->setStyle(II)V
    0008: return-void

  [Virtual Method] onCreateView(Landroid/view/LayoutInflater;, Landroid/view/ViewGroup;, Landroid/os/Bundle;) -> Landroid/view/View;
    // registers=7, ins=4, outs=4, insns_size=48
    0000: const/4 v1, 0
    0001: invoke-virtual {v3}, Lcom/sec/chaton/DataPacketDialog2;->getDialog()Landroid/app/Dialog;
    0004: move-result-object v0
    0005: invoke-virtual {v0, v1}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V
    0008: const v0, 2130903132 (0x7f03005c)
    000b: invoke-virtual {v4, v0, v5, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;
    000e: move-result-object v1
    000f: const v0, 2131231298 (0x7f080242)
    0012: invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0015: move-result-object v0
    0016: check-cast v0, Landroid/widget/Button;
    0018: iput v0, v3.Lcom/sec/chaton/DataPacketDialog2;->b:Landroid/widget/Button;
    001a: const v0, 2131231274 (0x7f08022a)
    001d: invoke-virtual {v1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0020: move-result-object v0
    0021: check-cast v0, Landroid/widget/CheckBox;
    0023: iput v0, v3.Lcom/sec/chaton/DataPacketDialog2;->c:Landroid/widget/CheckBox;
    0025: iget v0, v3.Lcom/sec/chaton/DataPacketDialog2;->b:Landroid/widget/Button;
    0027: new-instance v2, Lcom/sec/chaton/p;
    0029: invoke-direct {v2, v3}, Lcom/sec/chaton/p;-><init>(Lcom/sec/chaton/DataPacketDialog2;)V
    002c: invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    002f: return-object v1