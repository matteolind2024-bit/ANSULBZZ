=== CLASS Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO; (Source: AMS_CODING_FILE_INFO.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] m_eExportType: I
  [Instance Field] m_nCurPageIndex: I
  [Instance Field] m_nMessageID: I
  [Instance Field] m_nTotalPageNum: I
  [Instance Field] m_strFileName: Ljava/lang/String;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getM_eExportType() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;->m_eExportType:I
    0002: return v0

  [Virtual Method] getM_nCurPageIndex() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;->m_nCurPageIndex:I
    0002: return v0

  [Virtual Method] getM_nMessageID() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;->m_nMessageID:I
    0002: return v0

  [Virtual Method] getM_nTotalPageNum() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;->m_nTotalPageNum:I
    0002: return v0

  [Virtual Method] getM_strFileName() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;->m_strFileName:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] setM_eExportType(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;->m_eExportType:I
    0002: return-void

  [Virtual Method] setM_nCurPageIndex(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;->m_nCurPageIndex:I
    0002: return-void

  [Virtual Method] setM_nMessageID(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;->m_nMessageID:I
    0002: return-void

  [Virtual Method] setM_nTotalPageNum(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;->m_nTotalPageNum:I
    0002: return-void

  [Virtual Method] setM_strFileName(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/amsoma/structure/AMS_CODING_FILE_INFO;->m_strFileName:Ljava/lang/String;
    0002: return-void