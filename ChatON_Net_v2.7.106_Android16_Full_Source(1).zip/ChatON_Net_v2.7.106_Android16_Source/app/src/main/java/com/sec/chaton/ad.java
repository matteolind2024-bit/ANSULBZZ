=== CLASS Lcom/sec/chaton/ad; (Source: MoreFragment.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/coolots/sso/a/d;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] a(Ljava/lang/String;, Ljava/lang/String;, I) -> V
    // registers=7, ins=4, outs=3, insns_size=76
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0005: const-string v1, '[onReceiveUpdateVerion] currentVersionName : '
    0007: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000a: move-result-object v0
    000b: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000e: move-result-object v0
    000f: const-string v1, ',serverVersionName : '
    0011: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0014: move-result-object v0
    0015: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0018: move-result-object v0
    0019: const-string v1, ',versionInfo : '
    001b: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001e: move-result-object v0
    001f: invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0022: move-result-object v0
    0023: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0026: move-result-object v0
    0027: const-string v1, 'chatonVUpgradeListener'
    0029: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    002c: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    002f: move-result-object v0
    0030: const-string v1, 'chatonVUpdateStatus'
    0032: invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0035: move-result-object v2
    0036: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;Ljava/lang/Integer;)V
    0039: new-instance v0, Landroid/content/Intent;
    003b: const-string v1, 'more_tab_badge_update'
    003d: invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    0040: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0043: move-result-object v1
    0044: invoke-static {v1}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    0047: move-result-object v1
    0048: invoke-virtual {v1, v0}, Landroid/support/v4/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z
    004b: return-void