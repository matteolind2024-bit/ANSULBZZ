=== CLASS Lcom/sec/a/a/a/j; (Source: MsgFrontend.java) ===
  Super: Lcom/google/protobuf/GeneratedMessageLite$Builder;
  Interfaces: Lcom/sec/a/a/a/k;
  [Instance Field] a: I
  [Instance Field] b: I
  [Instance Field] c: I
  [Instance Field] d: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=11
    0000: invoke-direct {v1}, Lcom/google/protobuf/GeneratedMessageLite$Builder;-><init>()V
    0003: const-string v0, ''
    0005: iput v0, v1.Lcom/sec/a/a/a/j;->d:Ljava/lang/Object;
    0007: invoke-direct {v1}, Lcom/sec/a/a/a/j;->g()V
    000a: return-void

  [Direct Method] a(Lcom/sec/a/a/a/j;) -> Lcom/sec/a/a/a/i;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-direct {v1}, Lcom/sec/a/a/a/j;->i()Lcom/sec/a/a/a/i;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] f() -> Lcom/sec/a/a/a/j;
    // registers=1, ins=0, outs=0, insns_size=5
    0000: invoke-static {}, Lcom/sec/a/a/a/j;->h()Lcom/sec/a/a/a/j;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] g() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Direct Method] h() -> Lcom/sec/a/a/a/j;
    // registers=1, ins=0, outs=1, insns_size=6
    0000: new-instance v0, Lcom/sec/a/a/a/j;
    0002: invoke-direct {v0}, Lcom/sec/a/a/a/j;-><init>()V
    0005: return-object v0

  [Direct Method] i() -> Lcom/sec/a/a/a/i;
    // registers=3, ins=1, outs=1, insns_size=20
    0000: invoke-virtual {v2}, Lcom/sec/a/a/a/j;->e()Lcom/sec/a/a/a/i;
    0003: move-result-object v0
    0004: invoke-virtual {v0}, Lcom/sec/a/a/a/i;->isInitialized()Z
    0007: move-result v1
    0008: if-nez v1, 0013
    000a: invoke-static {v0}, Lcom/sec/a/a/a/j;->newUninitializedMessageException(Lcom/google/protobuf/MessageLite;)Lcom/google/protobuf/UninitializedMessageException;
    000d: move-result-object v0
    000e: invoke-virtual {v0}, Lcom/google/protobuf/UninitializedMessageException;->asInvalidProtocolBufferException()Lcom/google/protobuf/InvalidProtocolBufferException;
    0011: move-result-object v0
    0012: throw v0
    0013: return-object v0

  [Virtual Method] a() -> Lcom/sec/a/a/a/j;
    // registers=3, ins=1, outs=1, insns_size=31
    0000: const/4 v1, 0
    0001: invoke-super {v2}, Lcom/google/protobuf/GeneratedMessageLite$Builder;->clear()Lcom/google/protobuf/GeneratedMessageLite$Builder;
    0004: iput v1, v2.Lcom/sec/a/a/a/j;->b:I
    0006: iget v0, v2.Lcom/sec/a/a/a/j;->a:I
    0008: binop/lit8(op=dd) v0, v0, -2 (-0x2)
    000a: iput v0, v2.Lcom/sec/a/a/a/j;->a:I
    000c: iput v1, v2.Lcom/sec/a/a/a/j;->c:I
    000e: iget v0, v2.Lcom/sec/a/a/a/j;->a:I
    0010: binop/lit8(op=dd) v0, v0, -3 (-0x3)
    0012: iput v0, v2.Lcom/sec/a/a/a/j;->a:I
    0014: const-string v0, ''
    0016: iput v0, v2.Lcom/sec/a/a/a/j;->d:Ljava/lang/Object;
    0018: iget v0, v2.Lcom/sec/a/a/a/j;->a:I
    001a: binop/lit8(op=dd) v0, v0, -5 (-0x5)
    001c: iput v0, v2.Lcom/sec/a/a/a/j;->a:I
    001e: return-object v2

  [Virtual Method] a(I) -> Lcom/sec/a/a/a/j;
    // registers=3, ins=2, outs=0, insns_size=9
    0000: iget v0, v1.Lcom/sec/a/a/a/j;->a:I
    0002: binop/lit8(op=de) v0, v0, 1 (0x1)
    0004: iput v0, v1.Lcom/sec/a/a/a/j;->a:I
    0006: iput v2, v1.Lcom/sec/a/a/a/j;->b:I
    0008: return-object v1

  [Virtual Method] a(Lcom/google/protobuf/CodedInputStream;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/sec/a/a/a/j;
    // registers=4, ins=3, outs=4, insns_size=72
    0000: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readTag()I
    0003: move-result v0
    0004: sparse-switch v0, +50 (-> 0036)
    0007: invoke-virtual {v1, v2, v3, v0}, Lcom/sec/a/a/a/j;->parseUnknownField(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;I)Z
    000a: move-result v0
    000b: if-nez v0, 0000
    000d: return-object v1
    000e: iget v0, v1.Lcom/sec/a/a/a/j;->a:I
    0010: binop/lit8(op=de) v0, v0, 1 (0x1)
    0012: iput v0, v1.Lcom/sec/a/a/a/j;->a:I
    0014: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readInt32()I
    0017: move-result v0
    0018: iput v0, v1.Lcom/sec/a/a/a/j;->b:I
    001a: goto 0000
    001b: iget v0, v1.Lcom/sec/a/a/a/j;->a:I
    001d: binop/lit8(op=de) v0, v0, 2 (0x2)
    001f: iput v0, v1.Lcom/sec/a/a/a/j;->a:I
    0021: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readInt32()I
    0024: move-result v0
    0025: iput v0, v1.Lcom/sec/a/a/a/j;->c:I
    0027: goto 0000
    0028: iget v0, v1.Lcom/sec/a/a/a/j;->a:I
    002a: binop/lit8(op=de) v0, v0, 4 (0x4)
    002c: iput v0, v1.Lcom/sec/a/a/a/j;->a:I
    002e: invoke-virtual {v2}, Lcom/google/protobuf/CodedInputStream;->readBytes()Lcom/google/protobuf/ByteString;
    0031: move-result-object v0
    0032: iput v0, v1.Lcom/sec/a/a/a/j;->d:Ljava/lang/Object;
    0034: goto 0000
    0035: nop
    0036: sparse-switch-payload {0: 9, 8: 10, 16: 23, 26: 36}

  [Virtual Method] a(Lcom/sec/a/a/a/i;) -> Lcom/sec/a/a/a/j;
    // registers=3, ins=2, outs=2, insns_size=47
    0000: invoke-static {}, Lcom/sec/a/a/a/i;->a()Lcom/sec/a/a/a/i;
    0003: move-result-object v0
    0004: if-ne v2, v0, 0007
    0006: return-object v1
    0007: invoke-virtual {v2}, Lcom/sec/a/a/a/i;->c()Z
    000a: move-result v0
    000b: if-eqz v0, 0014
    000d: invoke-virtual {v2}, Lcom/sec/a/a/a/i;->d()I
    0010: move-result v0
    0011: invoke-virtual {v1, v0}, Lcom/sec/a/a/a/j;->a(I)Lcom/sec/a/a/a/j;
    0014: invoke-virtual {v2}, Lcom/sec/a/a/a/i;->e()Z
    0017: move-result v0
    0018: if-eqz v0, 0021
    001a: invoke-virtual {v2}, Lcom/sec/a/a/a/i;->f()I
    001d: move-result v0
    001e: invoke-virtual {v1, v0}, Lcom/sec/a/a/a/j;->b(I)Lcom/sec/a/a/a/j;
    0021: invoke-virtual {v2}, Lcom/sec/a/a/a/i;->g()Z
    0024: move-result v0
    0025: if-eqz v0, 0006
    0027: invoke-virtual {v2}, Lcom/sec/a/a/a/i;->h()Ljava/lang/String;
    002a: move-result-object v0
    002b: invoke-virtual {v1, v0}, Lcom/sec/a/a/a/j;->a(Ljava/lang/String;)Lcom/sec/a/a/a/j;
    002e: goto 0006

  [Virtual Method] a(Ljava/lang/String;) -> Lcom/sec/a/a/a/j;
    // registers=3, ins=2, outs=1, insns_size=17
    0000: if-nez v2, 0008
    0002: new-instance v0, Ljava/lang/NullPointerException;
    0004: invoke-direct {v0}, Ljava/lang/NullPointerException;-><init>()V
    0007: throw v0
    0008: iget v0, v1.Lcom/sec/a/a/a/j;->a:I
    000a: binop/lit8(op=de) v0, v0, 4 (0x4)
    000c: iput v0, v1.Lcom/sec/a/a/a/j;->a:I
    000e: iput v2, v1.Lcom/sec/a/a/a/j;->d:Ljava/lang/Object;
    0010: return-object v1

  [Virtual Method] b() -> Lcom/sec/a/a/a/j;
    // registers=3, ins=1, outs=2, insns_size=13
    0000: invoke-static {}, Lcom/sec/a/a/a/j;->h()Lcom/sec/a/a/a/j;
    0003: move-result-object v0
    0004: invoke-virtual {v2}, Lcom/sec/a/a/a/j;->e()Lcom/sec/a/a/a/i;
    0007: move-result-object v1
    0008: invoke-virtual {v0, v1}, Lcom/sec/a/a/a/j;->a(Lcom/sec/a/a/a/i;)Lcom/sec/a/a/a/j;
    000b: move-result-object v0
    000c: return-object v0

  [Virtual Method] b(I) -> Lcom/sec/a/a/a/j;
    // registers=3, ins=2, outs=0, insns_size=9
    0000: iget v0, v1.Lcom/sec/a/a/a/j;->a:I
    0002: binop/lit8(op=de) v0, v0, 2 (0x2)
    0004: iput v0, v1.Lcom/sec/a/a/a/j;->a:I
    0006: iput v2, v1.Lcom/sec/a/a/a/j;->c:I
    0008: return-object v1

  [Virtual Method] build() -> Lcom/google/protobuf/MessageLite;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/j;->d()Lcom/sec/a/a/a/i;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] buildPartial() -> Lcom/google/protobuf/MessageLite;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/j;->e()Lcom/sec/a/a/a/i;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] c() -> Lcom/sec/a/a/a/i;
    // registers=2, ins=1, outs=0, insns_size=5
    0000: invoke-static {}, Lcom/sec/a/a/a/i;->a()Lcom/sec/a/a/a/i;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clear() -> Lcom/google/protobuf/GeneratedMessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/j;->a()Lcom/sec/a/a/a/j;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clear() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/j;->a()Lcom/sec/a/a/a/j;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clone() -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/j;->b()Lcom/sec/a/a/a/j;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clone() -> Lcom/google/protobuf/GeneratedMessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/j;->b()Lcom/sec/a/a/a/j;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clone() -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/j;->b()Lcom/sec/a/a/a/j;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] clone() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/j;->b()Lcom/sec/a/a/a/j;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] d() -> Lcom/sec/a/a/a/i;
    // registers=3, ins=1, outs=1, insns_size=16
    0000: invoke-virtual {v2}, Lcom/sec/a/a/a/j;->e()Lcom/sec/a/a/a/i;
    0003: move-result-object v0
    0004: invoke-virtual {v0}, Lcom/sec/a/a/a/i;->isInitialized()Z
    0007: move-result v1
    0008: if-nez v1, 000f
    000a: invoke-static {v0}, Lcom/sec/a/a/a/j;->newUninitializedMessageException(Lcom/google/protobuf/MessageLite;)Lcom/google/protobuf/UninitializedMessageException;
    000d: move-result-object v0
    000e: throw v0
    000f: return-object v0

  [Virtual Method] e() -> Lcom/sec/a/a/a/i;
    // registers=6, ins=1, outs=3, insns_size=49
    0000: const/4 v0, 1
    0001: new-instance v2, Lcom/sec/a/a/a/i;
    0003: const/4 v1, 0
    0004: invoke-direct {v2, v5, v1}, Lcom/sec/a/a/a/i;-><init>(Lcom/sec/a/a/a/j;Lcom/sec/a/a/a/b;)V
    0007: iget v3, v5.Lcom/sec/a/a/a/j;->a:I
    0009: const/4 v1, 0
    000a: binop/lit8(op=dd) v4, v3, 1 (0x1)
    000c: if-ne v4, v0, 002f
    000e: iget v1, v5.Lcom/sec/a/a/a/j;->b:I
    0010: invoke-static {v2, v1}, Lcom/sec/a/a/a/i;->a(Lcom/sec/a/a/a/i;I)I
    0013: binop/lit8(op=dd) v1, v3, 2 (0x2)
    0015: const/4 v4, 2
    0016: if-ne v1, v4, 001a
    0018: binop/lit8(op=de) v0, v0, 2 (0x2)
    001a: iget v1, v5.Lcom/sec/a/a/a/j;->c:I
    001c: invoke-static {v2, v1}, Lcom/sec/a/a/a/i;->b(Lcom/sec/a/a/a/i;I)I
    001f: binop/lit8(op=dd) v1, v3, 4 (0x4)
    0021: const/4 v3, 4
    0022: if-ne v1, v3, 0026
    0024: binop/lit8(op=de) v0, v0, 4 (0x4)
    0026: iget v1, v5.Lcom/sec/a/a/a/j;->d:Ljava/lang/Object;
    0028: invoke-static {v2, v1}, Lcom/sec/a/a/a/i;->a(Lcom/sec/a/a/a/i;Ljava/lang/Object;)Ljava/lang/Object;
    002b: invoke-static {v2, v0}, Lcom/sec/a/a/a/i;->c(Lcom/sec/a/a/a/i;I)I
    002e: return-object v2
    002f: move(op=01) v0, v1
    0030: goto 000e

  [Virtual Method] getDefaultInstanceForType() -> Lcom/google/protobuf/GeneratedMessageLite;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/j;->c()Lcom/sec/a/a/a/i;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getDefaultInstanceForType() -> Lcom/google/protobuf/MessageLite;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Lcom/sec/a/a/a/j;->c()Lcom/sec/a/a/a/i;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] isInitialized() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Virtual Method] mergeFrom(Lcom/google/protobuf/CodedInputStream;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/AbstractMessageLite$Builder;
    // registers=4, ins=3, outs=3, insns_size=5
    0000: invoke-virtual {v1, v2, v3}, Lcom/sec/a/a/a/j;->a(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/sec/a/a/a/j;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] mergeFrom(Lcom/google/protobuf/GeneratedMessageLite;) -> Lcom/google/protobuf/GeneratedMessageLite$Builder;
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v2, Lcom/sec/a/a/a/i;
    0002: invoke-virtual {v1, v2}, Lcom/sec/a/a/a/j;->a(Lcom/sec/a/a/a/i;)Lcom/sec/a/a/a/j;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] mergeFrom(Lcom/google/protobuf/CodedInputStream;, Lcom/google/protobuf/ExtensionRegistryLite;) -> Lcom/google/protobuf/MessageLite$Builder;
    // registers=4, ins=3, outs=3, insns_size=5
    0000: invoke-virtual {v1, v2, v3}, Lcom/sec/a/a/a/j;->a(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/sec/a/a/a/j;
    0003: move-result-object v0
    0004: return-object v0