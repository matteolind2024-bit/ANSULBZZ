=== CLASS Lcom/sec/chaton/SPPUpgradeDialog; (Source: SPPUpgradeDialog.java) ===
  Super: Landroid/app/Activity;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/app/Activity;-><init>()V
    0003: return-void

  [Direct Method] a() -> V
    // registers=4, ins=1, outs=3, insns_size=41
    0000: const-string v0, 'showPasswordLockActivity'
    0002: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0005: move-result-object v1
    0006: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0009: move-result-object v1
    000a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    000d: invoke-virtual {v3}, Lcom/sec/chaton/SPPUpgradeDialog;->getApplicationContext()Landroid/content/Context;
    0010: move-result-object v0
    0011: invoke-static {v0}, Lcom/sec/chaton/util/j;->c(Landroid/content/Context;)Z
    0014: move-result v1
    0015: if-eqz v1, 0028
    0017: new-instance v1, Landroid/content/Intent;
    0019: const-class v2, Lcom/sec/chaton/settings/ActivityPasswordLockSet;
    001b: invoke-direct {v1, v0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    001e: const-string v0, 'MODE'
    0020: const-string v2, 'HOME'
    0022: invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    0025: invoke-virtual {v3, v1}, Lcom/sec/chaton/SPPUpgradeDialog;->startActivity(Landroid/content/Intent;)V
    0028: return-void

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=6, ins=2, outs=2, insns_size=84
    0000: const v3, 2131232515 (0x7f080703)
    0003: const/16 v2, 11 (0xb)
    0005: const/4 v1, 0
    0006: invoke-super {v4, v5}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    0009: const/4 v0, 1
    000a: invoke-virtual {v4, v0}, Lcom/sec/chaton/SPPUpgradeDialog;->requestWindowFeature(I)Z
    000d: const v0, 2130903428 (0x7f030184)
    0010: invoke-virtual {v4, v0}, Lcom/sec/chaton/SPPUpgradeDialog;->setContentView(I)V
    0013: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0015: if-lt v0, v2, 001a
    0017: invoke-virtual {v4, v1}, Lcom/sec/chaton/SPPUpgradeDialog;->setFinishOnTouchOutside(Z)V
    001a: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    001c: if-ge v0, v2, 003e
    001e: invoke-virtual {v4, v3}, Lcom/sec/chaton/SPPUpgradeDialog;->findViewById(I)Landroid/view/View;
    0021: move-result-object v0
    0022: check-cast v0, Landroid/widget/Button;
    0024: new-instance v1, Lcom/sec/chaton/an;
    0026: invoke-direct {v1, v4}, Lcom/sec/chaton/an;-><init>(Lcom/sec/chaton/SPPUpgradeDialog;)V
    0029: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    002c: const v0, 2131232516 (0x7f080704)
    002f: invoke-virtual {v4, v0}, Lcom/sec/chaton/SPPUpgradeDialog;->findViewById(I)Landroid/view/View;
    0032: move-result-object v0
    0033: check-cast v0, Landroid/widget/Button;
    0035: new-instance v1, Lcom/sec/chaton/ao;
    0037: invoke-direct {v1, v4}, Lcom/sec/chaton/ao;-><init>(Lcom/sec/chaton/SPPUpgradeDialog;)V
    003a: invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    003d: return-void
    003e: const v0, 2131232517 (0x7f080705)
    0041: invoke-virtual {v4, v0}, Lcom/sec/chaton/SPPUpgradeDialog;->findViewById(I)Landroid/view/View;
    0044: move-result-object v0
    0045: check-cast v0, Landroid/widget/Button;
    0047: invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V
    004a: invoke-virtual {v4, v3}, Lcom/sec/chaton/SPPUpgradeDialog;->findViewById(I)Landroid/view/View;
    004d: move-result-object v1
    004e: const/16 v2, 8 (0x8)
    0050: invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V
    0053: goto 0024

  [Virtual Method] onDestroy() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-super {v0}, Landroid/app/Activity;->onDestroy()V
    0003: return-void

  [Virtual Method] onKeyDown(I, Landroid/view/KeyEvent;) -> Z
    // registers=4, ins=3, outs=3, insns_size=10
    0000: const/4 v0, 4
    0001: if-ne v2, v0, 0005
    0003: const/4 v0, 1
    0004: return v0
    0005: invoke-super {v1, v2, v3}, Landroid/app/Activity;->onKeyDown(ILandroid/view/KeyEvent;)Z
    0008: move-result v0
    0009: goto 0004

  [Virtual Method] onResume() -> V
    // registers=1, ins=1, outs=1, insns_size=7
    0000: invoke-super {v0}, Landroid/app/Activity;->onResume()V
    0003: invoke-direct {v0}, Lcom/sec/chaton/SPPUpgradeDialog;->a()V
    0006: return-void