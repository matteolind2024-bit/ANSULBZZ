=== CLASS Lcom/sec/chaton/b; (Source: AdminMenu.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/view/View$OnClickListener;
  [Instance Field] a: Lcom/sec/chaton/AdminMenu;

  [Direct Method] <init>(Lcom/sec/chaton/AdminMenu;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onClick(Landroid/view/View;) -> V
    // registers=7, ins=2, outs=5, insns_size=1174
    0000: const/4 v4, 1
    0001: const/4 v0, 0
    0002: invoke-virtual {v6}, Landroid/view/View;->getId()I
    0005: move-result v1
    0006: packed-switch v1, +1082 (-> 0440)
    0009: return-void
    000a: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    000c: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->b(Lcom/sec/chaton/AdminMenu;)Ljava/util/ArrayList;
    000f: move-result-object v1
    0010: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0013: move-result v1
    0014: if-lez v1, 001f
    0016: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0018: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->b(Lcom/sec/chaton/AdminMenu;)Ljava/util/ArrayList;
    001b: move-result-object v1
    001c: invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V
    001f: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0021: invoke-static {v1, v0}, Lcom/sec/chaton/AdminMenu;->a(Lcom/sec/chaton/AdminMenu;I)I
    0024: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0026: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->c(Lcom/sec/chaton/AdminMenu;)V
    0029: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    002b: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->d(Lcom/sec/chaton/AdminMenu;)V
    002e: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0030: const/16 v2, 100 (0x64)
    0032: invoke-static {v1, v2}, Lcom/sec/chaton/AdminMenu;->b(Lcom/sec/chaton/AdminMenu;I)I
    0035: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0037: new-instance v2, Landroid/app/ProgressDialog;
    0039: iget v3, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    003b: invoke-static {v3}, Lcom/sec/chaton/AdminMenu;->e(Lcom/sec/chaton/AdminMenu;)Landroid/content/Context;
    003e: move-result-object v3
    003f: invoke-direct {v2, v3}, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V
    0042: invoke-static {v1, v2}, Lcom/sec/chaton/AdminMenu;->a(Lcom/sec/chaton/AdminMenu;Landroid/app/ProgressDialog;)Landroid/app/ProgressDialog;
    0045: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0047: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->f(Lcom/sec/chaton/AdminMenu;)Landroid/app/ProgressDialog;
    004a: move-result-object v1
    004b: const-string v2, 'Make Dummy ChatRoom ...'
    004d: invoke-virtual {v1, v2}, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V
    0050: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0052: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->f(Lcom/sec/chaton/AdminMenu;)Landroid/app/ProgressDialog;
    0055: move-result-object v1
    0056: invoke-virtual {v1, v0}, Landroid/app/ProgressDialog;->setCancelable(Z)V
    0059: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    005b: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->f(Lcom/sec/chaton/AdminMenu;)Landroid/app/ProgressDialog;
    005e: move-result-object v0
    005f: invoke-virtual {v0}, Landroid/app/ProgressDialog;->show()V
    0062: new-instance v0, Lcom/sec/chaton/j;
    0064: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0066: invoke-direct {v0, v1}, Lcom/sec/chaton/j;-><init>(Lcom/sec/chaton/AdminMenu;)V
    0069: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    006b: invoke-static {v1, v4}, Lcom/sec/chaton/AdminMenu;->a(Lcom/sec/chaton/AdminMenu;Z)Z
    006e: invoke-virtual {v0}, Lcom/sec/chaton/j;->start()V
    0071: goto 0009
    0072: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0074: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->b(Lcom/sec/chaton/AdminMenu;)Ljava/util/ArrayList;
    0077: move-result-object v1
    0078: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    007b: move-result v1
    007c: if-lez v1, 0087
    007e: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0080: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->b(Lcom/sec/chaton/AdminMenu;)Ljava/util/ArrayList;
    0083: move-result-object v1
    0084: invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V
    0087: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0089: invoke-static {v1, v0}, Lcom/sec/chaton/AdminMenu;->a(Lcom/sec/chaton/AdminMenu;I)I
    008c: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    008e: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->c(Lcom/sec/chaton/AdminMenu;)V
    0091: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0093: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->d(Lcom/sec/chaton/AdminMenu;)V
    0096: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0098: const/16 v2, 200 (0xc8)
    009a: invoke-static {v1, v2}, Lcom/sec/chaton/AdminMenu;->b(Lcom/sec/chaton/AdminMenu;I)I
    009d: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    009f: new-instance v2, Landroid/app/ProgressDialog;
    00a1: iget v3, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    00a3: invoke-static {v3}, Lcom/sec/chaton/AdminMenu;->e(Lcom/sec/chaton/AdminMenu;)Landroid/content/Context;
    00a6: move-result-object v3
    00a7: invoke-direct {v2, v3}, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V
    00aa: invoke-static {v1, v2}, Lcom/sec/chaton/AdminMenu;->a(Lcom/sec/chaton/AdminMenu;Landroid/app/ProgressDialog;)Landroid/app/ProgressDialog;
    00ad: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    00af: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->f(Lcom/sec/chaton/AdminMenu;)Landroid/app/ProgressDialog;
    00b2: move-result-object v1
    00b3: const-string v2, 'Make Dummy ChatRoom ...'
    00b5: invoke-virtual {v1, v2}, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V
    00b8: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    00ba: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->f(Lcom/sec/chaton/AdminMenu;)Landroid/app/ProgressDialog;
    00bd: move-result-object v1
    00be: invoke-virtual {v1, v0}, Landroid/app/ProgressDialog;->setCancelable(Z)V
    00c1: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    00c3: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->f(Lcom/sec/chaton/AdminMenu;)Landroid/app/ProgressDialog;
    00c6: move-result-object v0
    00c7: invoke-virtual {v0}, Landroid/app/ProgressDialog;->show()V
    00ca: new-instance v0, Lcom/sec/chaton/j;
    00cc: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    00ce: invoke-direct {v0, v1}, Lcom/sec/chaton/j;-><init>(Lcom/sec/chaton/AdminMenu;)V
    00d1: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    00d3: invoke-static {v1, v4}, Lcom/sec/chaton/AdminMenu;->a(Lcom/sec/chaton/AdminMenu;Z)Z
    00d6: invoke-virtual {v0}, Lcom/sec/chaton/j;->start()V
    00d9: goto/16 0009
    00db: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    00de: move-result-object v0
    00df: invoke-static {v0}, Lcom/sec/chaton/util/RTLogCollector;->a(Landroid/content/Context;)Lcom/sec/chaton/util/RTLogCollector;
    00e2: move-result-object v0
    00e3: invoke-virtual {v0}, Lcom/sec/chaton/util/RTLogCollector;->h()V
    00e6: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    00e8: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->g(Lcom/sec/chaton/AdminMenu;)V
    00eb: goto/16 0009
    00ed: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    00f0: move-result-object v0
    00f1: invoke-static {v0}, Lcom/sec/chaton/util/RTLogCollector;->a(Landroid/content/Context;)Lcom/sec/chaton/util/RTLogCollector;
    00f4: move-result-object v0
    00f5: invoke-virtual {v0}, Lcom/sec/chaton/util/RTLogCollector;->i()V
    00f8: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    00fa: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->g(Lcom/sec/chaton/AdminMenu;)V
    00fd: goto/16 0009
    00ff: new-instance v0, Lcom/sec/widget/a;
    0101: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0103: invoke-direct {v0, v1}, Lcom/sec/widget/a;-><init>(Landroid/content/Context;)V
    0106: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0108: invoke-static {v1}, Lcom/sec/chaton/c/b;->a(Landroid/content/Context;)Ljava/lang/String;
    010b: move-result-object v1
    010c: invoke-virtual {v0, v1}, Lcom/sec/widget/a;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    010f: move-result-object v0
    0110: const v1, 17039370 (0x104000a)
    0113: const/4 v2, 0
    0114: invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    0117: move-result-object v0
    0118: invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;
    011b: goto/16 0009
    011d: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    011f: invoke-static {}, Lcom/sec/chaton/util/p;->b()I
    0122: move-result v2
    0123: invoke-static {v1, v2}, Lcom/sec/chaton/AdminMenu;->c(Lcom/sec/chaton/AdminMenu;I)I
    0126: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0128: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->h(Lcom/sec/chaton/AdminMenu;)I
    012b: move-result v1
    012c: if-lez v1, 0158
    012e: const-string v1, 'Chat ON Log was disenabled...'
    0130: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0133: move-result-object v2
    0134: invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0137: move-result-object v2
    0138: invoke-static {v1, v2}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    013b: invoke-static {v0}, Lcom/sec/chaton/util/p;->b(I)V
    013e: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    0141: move-result-object v0
    0142: const-string v1, 'Log Off'
    0144: invoke-static {v0, v1, v4}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    0147: move-result-object v0
    0148: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    014b: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    014d: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->i(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    0150: move-result-object v0
    0151: const-string v1, 'Log On'
    0153: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    0156: goto/16 0009
    0158: invoke-static {v4}, Lcom/sec/chaton/util/p;->b(I)V
    015b: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    015e: move-result-object v0
    015f: const-string v1, 'Log On'
    0161: invoke-static {v0, v1, v4}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    0164: move-result-object v0
    0165: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    0168: const-string v0, 'Chat ON Log was enabled...'
    016a: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    016d: move-result-object v1
    016e: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0171: move-result-object v1
    0172: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0175: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0177: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->i(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    017a: move-result-object v0
    017b: const-string v1, 'Log Off'
    017d: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    0180: goto/16 0009
    0182: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0184: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->j(Lcom/sec/chaton/AdminMenu;)Landroid/widget/TextView;
    0187: move-result-object v0
    0188: invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;
    018b: move-result-object v0
    018c: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    018f: move-result-object v0
    0190: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0192: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->k(Lcom/sec/chaton/AdminMenu;)Landroid/widget/EditText;
    0195: move-result-object v1
    0196: invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;
    0199: move-result-object v1
    019a: invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;
    019d: move-result-object v1
    019e: invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    01a1: move-result v1
    01a2: invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    01a5: move-result-object v1
    01a6: iget v2, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    01a8: invoke-static {v2}, Lcom/sec/chaton/AdminMenu;->l(Lcom/sec/chaton/AdminMenu;)Landroid/widget/EditText;
    01ab: move-result-object v2
    01ac: invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;
    01af: move-result-object v2
    01b0: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    01b3: move-result-object v2
    01b4: invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    01b7: move-result v2
    01b8: invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    01bb: move-result-object v2
    01bc: iget v3, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    01be: invoke-static {v3}, Lcom/sec/chaton/AdminMenu;->m(Lcom/sec/chaton/AdminMenu;)Landroid/widget/EditText;
    01c1: move-result-object v3
    01c2: invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;
    01c5: move-result-object v3
    01c6: invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;
    01c9: move-result-object v3
    01ca: invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    01cd: move-result v3
    01ce: invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    01d1: move-result-object v3
    01d2: iget v4, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    01d4: invoke-static {v4}, Lcom/sec/chaton/AdminMenu;->n(Lcom/sec/chaton/AdminMenu;)Landroid/widget/EditText;
    01d7: move-result-object v4
    01d8: invoke-virtual {v4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;
    01db: move-result-object v4
    01dc: invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;
    01df: move-result-object v4
    01e0: invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    01e3: move-result v4
    01e4: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    01e7: move-result-object v4
    01e8: invoke-static {v0, v1, v2, v3, v4}, Lcom/sec/chaton/c/g;->a(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;)V
    01eb: invoke-static {}, Lcom/sec/chaton/i/v;->c()Z
    01ee: goto/16 0009
    01f0: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    01f2: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->k(Lcom/sec/chaton/AdminMenu;)Landroid/widget/EditText;
    01f5: move-result-object v0
    01f6: const-string v1, '0'
    01f8: invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V
    01fb: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    01fd: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->l(Lcom/sec/chaton/AdminMenu;)Landroid/widget/EditText;
    0200: move-result-object v0
    0201: const-string v1, '0'
    0203: invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V
    0206: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0208: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->m(Lcom/sec/chaton/AdminMenu;)Landroid/widget/EditText;
    020b: move-result-object v0
    020c: const-string v1, '0'
    020e: invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V
    0211: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0213: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->n(Lcom/sec/chaton/AdminMenu;)Landroid/widget/EditText;
    0216: move-result-object v0
    0217: const-string v1, '0'
    0219: invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V
    021c: invoke-static {}, Lcom/sec/chaton/c/g;->a()V
    021f: goto/16 0009
    0221: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0223: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->e(Lcom/sec/chaton/AdminMenu;)Landroid/content/Context;
    0226: move-result-object v0
    0227: invoke-static {v0}, Lcom/sec/chaton/util/ac;->a(Landroid/content/Context;)V
    022a: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    022c: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->e(Lcom/sec/chaton/AdminMenu;)Landroid/content/Context;
    022f: move-result-object v0
    0230: const-string v1, 'Random device id is generated.'
    0232: invoke-static {v0, v1, v4}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    0235: move-result-object v0
    0236: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    0239: goto/16 0009
    023b: const-string v1, 'admin_dev_gld'
    023d: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0240: move-result-object v2
    0241: invoke-static {v1, v2}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Boolean;)V
    0244: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0246: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->e(Lcom/sec/chaton/AdminMenu;)Landroid/content/Context;
    0249: move-result-object v1
    024a: const-string v2, 'GLD server change to DEV sever'
    024c: invoke-static {v1, v2, v0}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    024f: move-result-object v0
    0250: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    0253: goto/16 0009
    0255: new-instance v0, Landroid/content/Intent;
    0257: invoke-direct {v0}, Landroid/content/Intent;-><init>()V
    025a: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    025c: const/4 v2, 3
    025d: invoke-virtual {v1, v2, v0}, Lcom/sec/chaton/AdminMenu;->setResult(ILandroid/content/Intent;)V
    0260: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0263: move-result-object v0
    0264: const-string v1, 'hidden_skip_mode'
    0266: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0269: move-result-object v2
    026a: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;Ljava/lang/Boolean;)V
    026d: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    026f: invoke-virtual {v0}, Lcom/sec/chaton/AdminMenu;->finish()V
    0272: goto/16 0009
    0274: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0276: new-instance v2, Landroid/app/ProgressDialog;
    0278: iget v3, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    027a: invoke-static {v3}, Lcom/sec/chaton/AdminMenu;->e(Lcom/sec/chaton/AdminMenu;)Landroid/content/Context;
    027d: move-result-object v3
    027e: invoke-direct {v2, v3}, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V
    0281: invoke-static {v1, v2}, Lcom/sec/chaton/AdminMenu;->a(Lcom/sec/chaton/AdminMenu;Landroid/app/ProgressDialog;)Landroid/app/ProgressDialog;
    0284: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0286: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->f(Lcom/sec/chaton/AdminMenu;)Landroid/app/ProgressDialog;
    0289: move-result-object v1
    028a: const-string v2, 'Backup chaton database'
    028c: invoke-virtual {v1, v2}, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V
    028f: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0291: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->f(Lcom/sec/chaton/AdminMenu;)Landroid/app/ProgressDialog;
    0294: move-result-object v1
    0295: invoke-virtual {v1, v0}, Landroid/app/ProgressDialog;->setCancelable(Z)V
    0298: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    029a: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->f(Lcom/sec/chaton/AdminMenu;)Landroid/app/ProgressDialog;
    029d: move-result-object v0
    029e: invoke-virtual {v0}, Landroid/app/ProgressDialog;->show()V
    02a1: new-instance v0, Lcom/sec/chaton/i;
    02a3: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    02a5: invoke-direct {v0, v1}, Lcom/sec/chaton/i;-><init>(Lcom/sec/chaton/AdminMenu;)V
    02a8: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    02aa: invoke-static {v1, v4}, Lcom/sec/chaton/AdminMenu;->a(Lcom/sec/chaton/AdminMenu;Z)Z
    02ad: invoke-virtual {v0}, Lcom/sec/chaton/i;->start()V
    02b0: goto/16 0009
    02b2: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    02b5: move-result-object v1
    02b6: const-string v2, 'admin_upgrade'
    02b8: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    02bb: move-result-object v3
    02bc: invoke-virtual {v1, v2, v3}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Integer;)Ljava/lang/Integer;
    02bf: move-result-object v1
    02c0: invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I
    02c3: move-result v1
    02c4: const/4 v2, 2
    02c5: if-ne v1, v2, 02fb
    02c7: sget v2, Lcom/sec/chaton/util/p;->b:Z
    02c9: if-eqz v2, 02ed
    02cb: new-instance v2, Ljava/lang/StringBuilder;
    02cd: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    02d0: const-string v3, 'Current upgrade : '
    02d2: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    02d5: move-result-object v2
    02d6: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    02d9: move-result-object v1
    02da: const-string v2, ' to '
    02dc: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    02df: move-result-object v1
    02e0: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    02e3: move-result-object v1
    02e4: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    02e7: move-result-object v1
    02e8: const-string v2, 'AdminMenu'
    02ea: invoke-static {v1, v2}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    02ed: packed-switch v0, +415 (-> 048c)
    02f0: const-string v1, 'admin_upgrade'
    02f2: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    02f5: move-result-object v0
    02f6: invoke-static {v1, v0}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Integer;)V
    02f9: goto/16 0009
    02fb: binop/lit8(op=d8) v0, v1, 1 (0x1)
    02fd: goto 02c7
    02fe: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0300: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->o(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    0303: move-result-object v1
    0304: const-string v2, 'upgrade : disable'
    0306: invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    0309: goto 02f0
    030a: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    030c: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->o(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    030f: move-result-object v1
    0310: const-string v2, 'upgrade : normal'
    0312: invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    0315: goto 02f0
    0316: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0318: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->o(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    031b: move-result-object v1
    031c: const-string v2, 'upgrade : critical'
    031e: invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    0321: goto 02f0
    0322: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0325: move-result-object v1
    0326: const-string v2, 'admin_notice'
    0328: invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    032b: move-result-object v3
    032c: invoke-virtual {v1, v2, v3}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    032f: move-result-object v1
    0330: invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z
    0333: move-result v1
    0334: if-ne v1, v4, 034c
    0336: const-string v1, 'admin_notice'
    0338: invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    033b: move-result-object v0
    033c: invoke-static {v1, v0}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Boolean;)V
    033f: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0341: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->p(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    0344: move-result-object v0
    0345: const-string v1, 'notice : disable'
    0347: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    034a: goto/16 0009
    034c: const-string v0, 'admin_notice'
    034e: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0351: move-result-object v1
    0352: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Boolean;)V
    0355: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0357: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->p(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    035a: move-result-object v0
    035b: const-string v1, 'notice : enable'
    035d: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    0360: goto/16 0009
    0362: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0365: move-result-object v1
    0366: const-string v2, 'admin_disclaimer'
    0368: invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    036b: move-result-object v3
    036c: invoke-virtual {v1, v2, v3}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    036f: move-result-object v1
    0370: invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z
    0373: move-result v1
    0374: if-ne v1, v4, 038c
    0376: const-string v1, 'admin_disclaimer'
    0378: invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    037b: move-result-object v0
    037c: invoke-static {v1, v0}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Boolean;)V
    037f: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0381: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->q(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    0384: move-result-object v0
    0385: const-string v1, 'disclaimer : disable'
    0387: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    038a: goto/16 0009
    038c: const-string v0, 'admin_disclaimer'
    038e: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0391: move-result-object v1
    0392: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Boolean;)V
    0395: iget v0, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0397: invoke-static {v0}, Lcom/sec/chaton/AdminMenu;->q(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    039a: move-result-object v0
    039b: const-string v1, 'disclaimer : enable'
    039d: invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    03a0: goto/16 0009
    03a2: invoke-static {}, Lcom/sec/chaton/msgsend/q;->b()Z
    03a5: move-result v1
    03a6: if-eqz v1, 03c7
    03a8: invoke-static {}, Lcom/sec/chaton/msgsend/q;->d()Z
    03ab: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    03ad: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->r(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    03b0: move-result-object v1
    03b1: const-string v2, 'A-Resend:DISABLED'
    03b3: invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    03b6: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    03b8: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->e(Lcom/sec/chaton/AdminMenu;)Landroid/content/Context;
    03bb: move-result-object v1
    03bc: const-string v2, 'disable : AutoResend'
    03be: invoke-static {v1, v2, v0}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    03c1: move-result-object v0
    03c2: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    03c5: goto/16 0009
    03c7: invoke-static {}, Lcom/sec/chaton/msgsend/q;->c()Z
    03ca: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    03cc: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->r(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    03cf: move-result-object v1
    03d0: const-string v2, 'A-Resend:ENABLED'
    03d2: invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    03d5: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    03d7: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->e(Lcom/sec/chaton/AdminMenu;)Landroid/content/Context;
    03da: move-result-object v1
    03db: const-string v2, 'enable : AutoResend'
    03dd: invoke-static {v1, v2, v0}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    03e0: move-result-object v0
    03e1: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    03e4: goto/16 0009
    03e6: invoke-static {}, Lcom/sec/chaton/msgsend/q;->g()Z
    03e9: move-result v1
    03ea: if-eqz v1, 040b
    03ec: invoke-static {v0}, Lcom/sec/chaton/msgsend/q;->a(Z)V
    03ef: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    03f1: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->s(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    03f4: move-result-object v1
    03f5: const-string v2, 'A-Resend:Noti disabled'
    03f7: invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    03fa: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    03fc: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->e(Lcom/sec/chaton/AdminMenu;)Landroid/content/Context;
    03ff: move-result-object v1
    0400: const-string v2, 'disable : Noti '
    0402: invoke-static {v1, v2, v0}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    0405: move-result-object v0
    0406: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    0409: goto/16 0009
    040b: invoke-static {v4}, Lcom/sec/chaton/msgsend/q;->a(Z)V
    040e: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    0410: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->s(Lcom/sec/chaton/AdminMenu;)Landroid/widget/Button;
    0413: move-result-object v1
    0414: const-string v2, 'A-Resend:Noti enabled'
    0416: invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    0419: iget v1, v5.Lcom/sec/chaton/b;->a:Lcom/sec/chaton/AdminMenu;
    041b: invoke-static {v1}, Lcom/sec/chaton/AdminMenu;->e(Lcom/sec/chaton/AdminMenu;)Landroid/content/Context;
    041e: move-result-object v1
    041f: const-string v2, 'enable : Noti'
    0421: invoke-static {v1, v2, v0}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    0424: move-result-object v0
    0425: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    0428: goto/16 0009
    042a: invoke-static {}, Lcom/sec/chaton/msgsend/p;->b()V
    042d: goto/16 0009
    042f: sget v0, Lcom/sec/chaton/msgsend/x;->l:Lcom/sec/chaton/msgsend/x;
    0431: invoke-static {v0}, Lcom/sec/chaton/msgsend/p;->a(Lcom/sec/chaton/msgsend/x;)V
    0434: goto/16 0009
    0436: invoke-static {}, Lcom/sec/chaton/msgsend/p;->a()V
    0439: goto/16 0009
    043b: invoke-static {}, Lcom/sec/chaton/msgsend/p;->c()V
    043e: goto/16 0009
    0440: packed-switch-payload first=2131230754 targets=[279, 249, 213, 231, 924, 3, 622, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 380, 490, 3, 3, 4, 108, 992, 1060, 1072, 1065, 1077, 539, 565, 591, 684, 796, 860]
    048c: packed-switch-payload first=0 targets=[17, 29, 41]