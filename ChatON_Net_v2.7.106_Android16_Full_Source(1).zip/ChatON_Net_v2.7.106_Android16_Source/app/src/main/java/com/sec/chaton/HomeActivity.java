=== CLASS Lcom/sec/chaton/HomeActivity; (Source: HomeActivity.java) ===
  Super: Lcom/sec/chaton/base/BaseActivity;
  Interfaces: Lcom/coolots/sso/a/c;, Lcom/sec/chaton/l;
  [Static Field] a: Ljava/lang/String;
  [Instance Field] b: Lcom/coolots/sso/a/a;
  [Instance Field] c: Landroid/os/Handler;
  [Instance Field] d: Landroid/accounts/AccountManagerCallback;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=9
    0000: const-class v0, Lcom/sec/chaton/HomeActivity;
    0002: invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0005: move-result-object v0
    0006: sput v0, Lcom/sec/chaton/HomeActivity;->a:Ljava/lang/String;
    0008: return-void

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=21
    0000: invoke-direct {v1}, Lcom/sec/chaton/base/BaseActivity;-><init>()V
    0003: const/4 v0, 0
    0004: iput v0, v1.Lcom/sec/chaton/HomeActivity;->b:Lcom/coolots/sso/a/a;
    0006: new-instance v0, Lcom/sec/chaton/u;
    0008: invoke-direct {v0, v1}, Lcom/sec/chaton/u;-><init>(Lcom/sec/chaton/HomeActivity;)V
    000b: iput v0, v1.Lcom/sec/chaton/HomeActivity;->c:Landroid/os/Handler;
    000d: new-instance v0, Lcom/sec/chaton/v;
    000f: invoke-direct {v0, v1}, Lcom/sec/chaton/v;-><init>(Lcom/sec/chaton/HomeActivity;)V
    0012: iput v0, v1.Lcom/sec/chaton/HomeActivity;->d:Landroid/accounts/AccountManagerCallback;
    0014: return-void

  [Direct Method] a(Landroid/content/Context;) -> Landroid/content/Intent;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-static {v1, v0}, Lcom/sec/chaton/HomeActivity;->a(Landroid/content/Context;Z)Landroid/content/Intent;
    0004: move-result-object v0
    0005: return-object v0

  [Direct Method] a(Landroid/content/Context;, Landroid/content/Intent;, Z) -> Landroid/content/Intent;
    // registers=4, ins=3, outs=3, insns_size=16
    0000: const-class v0, Lcom/sec/chaton/HomeActivity;
    0002: invoke-virtual {v2, v1, v0}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;
    0005: const/high16 v0, 65536 (0x10000)
    0007: invoke-virtual {v2, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    000a: const-string v0, 'skipSplash'
    000c: invoke-virtual {v2, v0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    000f: return-object v2

  [Direct Method] a(Landroid/content/Context;, Z) -> Landroid/content/Intent;
    // registers=4, ins=2, outs=3, insns_size=18
    0000: new-instance v0, Landroid/content/Intent;
    0002: const-class v1, Lcom/sec/chaton/HomeActivity;
    0004: invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0007: const/high16 v1, 65536 (0x10000)
    0009: invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    000c: const-string v1, 'skipSplash'
    000e: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    0011: return-object v0

  [Direct Method] a(Lcom/sec/chaton/HomeActivity;, Landroid/content/Intent;) -> Landroid/content/Intent;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-direct {v1, v2}, Lcom/sec/chaton/HomeActivity;->d(Landroid/content/Intent;)Landroid/content/Intent;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] a(Landroid/content/res/Configuration;) -> V
    // registers=5, ins=2, outs=2, insns_size=119
    0000: sget v0, Lcom/sec/chaton/util/p;->b:Z
    0002: if-eqz v0, 001e
    0004: new-instance v0, Ljava/lang/StringBuilder;
    0006: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0009: const-string v1, 'checkScreenMode : '
    000b: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000e: move-result-object v0
    000f: iget v1, v4.Landroid/content/res/Configuration;->orientation:I
    0011: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0014: move-result-object v0
    0015: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0018: move-result-object v0
    0019: sget v1, Lcom/sec/chaton/HomeActivity;->a:Ljava/lang/String;
    001b: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    001e: const v0, 2131232143 (0x7f08058f)
    0021: invoke-virtual {v3, v0}, Lcom/sec/chaton/HomeActivity;->findViewById(I)Landroid/view/View;
    0024: move-result-object v0
    0025: check-cast v0, Landroid/widget/ImageView;
    0027: const v0, 2131232145 (0x7f080591)
    002a: invoke-virtual {v3, v0}, Lcom/sec/chaton/HomeActivity;->findViewById(I)Landroid/view/View;
    002d: move-result-object v0
    002e: check-cast v0, Landroid/widget/ImageView;
    0030: new-instance v0, Landroid/util/DisplayMetrics;
    0032: invoke-direct {v0}, Landroid/util/DisplayMetrics;-><init>()V
    0035: invoke-virtual {v3}, Lcom/sec/chaton/HomeActivity;->getWindowManager()Landroid/view/WindowManager;
    0038: move-result-object v1
    0039: invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    003c: move-result-object v1
    003d: invoke-virtual {v1, v0}, Landroid/view/Display;->getMetrics(Landroid/util/DisplayMetrics;)V
    0040: sget v1, Lcom/sec/chaton/util/p;->b:Z
    0042: if-eqz v1, 0068
    0044: new-instance v1, Ljava/lang/StringBuilder;
    0046: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0049: const-string v2, 'densityDpi : '
    004b: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004e: move-result-object v1
    004f: iget v0, v0.Landroid/util/DisplayMetrics;->densityDpi:I
    0051: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0054: move-result-object v0
    0055: const-string v1, ' Config : '
    0057: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    005a: move-result-object v0
    005b: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    005e: move-result-object v0
    005f: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0062: move-result-object v0
    0063: sget v1, Lcom/sec/chaton/HomeActivity;->a:Ljava/lang/String;
    0065: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0068: iget v0, v4.Landroid/content/res/Configuration;->orientation:I
    006a: const/4 v1, 2
    006b: if-ne v0, v1, 0072
    006d: const/4 v0, 0
    006e: invoke-virtual {v3, v0}, Lcom/sec/chaton/HomeActivity;->setRequestedOrientation(I)V
    0071: return-void
    0072: const/4 v0, 1
    0073: invoke-virtual {v3, v0}, Lcom/sec/chaton/HomeActivity;->setRequestedOrientation(I)V
    0076: goto 0071

  [Direct Method] b() -> Ljava/lang/String;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Lcom/sec/chaton/HomeActivity;->a:Ljava/lang/String;
    0002: return-object v0

  [Direct Method] c(Landroid/content/Intent;) -> V
    // registers=4, ins=2, outs=3, insns_size=17
    0000: const-string v0, 'noti_sso'
    0002: const/4 v1, 0
    0003: invoke-virtual {v3, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    0006: move-result v0
    0007: if-eqz v0, 0010
    0009: invoke-static {v2}, Lcom/sec/chaton/chat/notification/a;->a(Landroid/content/Context;)Lcom/sec/chaton/chat/notification/a;
    000c: move-result-object v0
    000d: invoke-virtual {v0}, Lcom/sec/chaton/chat/notification/a;->c()V
    0010: return-void

  [Direct Method] c() -> Z
    // registers=4, ins=1, outs=3, insns_size=15
    0000: const/4 v0, 0
    0001: invoke-virtual {v3}, Lcom/sec/chaton/HomeActivity;->getIntent()Landroid/content/Intent;
    0004: move-result-object v1
    0005: const-string v2, 'finish'
    0007: invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    000a: move-result v1
    000b: if-eqz v1, 000e
    000d: const/4 v0, 1
    000e: return v0

  [Direct Method] d(Landroid/content/Intent;) -> Landroid/content/Intent;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-static {v1, v2}, Lcom/sec/chaton/TabActivity;->a(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/Intent;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] d() -> Z
    // registers=3, ins=1, outs=2, insns_size=11
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'uid'
    0006: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0009: move-result v0
    000a: return v0

  [Direct Method] e() -> Z
    // registers=6, ins=1, outs=3, insns_size=25
    0000: const/4 v0, 1
    0001: const/4 v1, 0
    0002: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0005: move-result-object v2
    0006: const-string v3, 'back_deregi_fail'
    0008: invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    000b: move-result-object v4
    000c: invoke-virtual {v2, v3, v4}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    000f: move-result-object v2
    0010: invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z
    0013: move-result v2
    0014: if-ne v2, v0, 0017
    0016: return v0
    0017: move(op=01) v0, v1
    0018: goto 0016

  [Direct Method] f() -> Z
    // registers=4, ins=1, outs=3, insns_size=20
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'back_chatonv_deregi_fail'
    0006: const/4 v2, 0
    0007: invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    000a: move-result-object v2
    000b: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    000e: move-result-object v0
    000f: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    0012: move-result v0
    0013: return v0

  [Virtual Method] a() -> V
    // registers=5, ins=1, outs=3, insns_size=25
    0000: const/4 v3, 0
    0001: iget v0, v4.Lcom/sec/chaton/HomeActivity;->c:Landroid/os/Handler;
    0003: invoke-virtual {v0, v3}, Landroid/os/Handler;->hasMessages(I)Z
    0006: move-result v0
    0007: if-nez v0, 0018
    0009: invoke-virtual {v4}, Lcom/sec/chaton/HomeActivity;->getIntent()Landroid/content/Intent;
    000c: move-result-object v0
    000d: iget v1, v4.Lcom/sec/chaton/HomeActivity;->c:Landroid/os/Handler;
    000f: iget v2, v4.Lcom/sec/chaton/HomeActivity;->c:Landroid/os/Handler;
    0011: invoke-static {v2, v3, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;
    0014: move-result-object v0
    0015: invoke-virtual {v1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z
    0018: return-void

  [Virtual Method] a(Z) -> V
    // registers=5, ins=2, outs=3, insns_size=48
    0000: const/4 v2, 0
    0001: new-instance v0, Ljava/lang/StringBuilder;
    0003: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0006: const-string v1, 'onReceiveRemoveAccount : '
    0008: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000b: move-result-object v0
    000c: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    000f: move-result-object v0
    0010: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0013: move-result-object v0
    0014: sget v1, Lcom/sec/chaton/HomeActivity;->a:Ljava/lang/String;
    0016: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0019: if-eqz v4, 0024
    001b: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    001e: move-result-object v0
    001f: const-string v1, 'back_chatonv_deregi_fail'
    0021: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;)V
    0024: iget v0, v3.Lcom/sec/chaton/HomeActivity;->b:Lcom/coolots/sso/a/a;
    0026: if-eqz v0, 002f
    0028: iget v0, v3.Lcom/sec/chaton/HomeActivity;->b:Lcom/coolots/sso/a/a;
    002a: invoke-virtual {v0, v3, v2}, Lcom/coolots/sso/a/a;->a(Landroid/content/Context;Lcom/coolots/sso/a/c;)V
    002d: iput v2, v3.Lcom/sec/chaton/HomeActivity;->b:Lcom/coolots/sso/a/a;
    002f: return-void

  [Virtual Method] a(Z, Ljava/lang/String;) -> V
    // registers=5, ins=3, outs=2, insns_size=25
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0005: const-string v1, 'onReceiveCreateAccount'
    0007: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000a: move-result-object v0
    000b: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    000e: move-result-object v0
    000f: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0012: move-result-object v0
    0013: sget v1, Lcom/sec/chaton/HomeActivity;->a:Ljava/lang/String;
    0015: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0018: return-void

  [Virtual Method] onConfigurationChanged(Landroid/content/res/Configuration;) -> V
    // registers=4, ins=2, outs=2, insns_size=15
    0000: invoke-super {v2, v3}, Lcom/sec/chaton/base/BaseActivity;->onConfigurationChanged(Landroid/content/res/Configuration;)V
    0003: sget v0, Lcom/sec/chaton/util/p;->b:Z
    0005: if-eqz v0, 000e
    0007: const-string v0, 'onConfigurationChanged'
    0009: sget v1, Lcom/sec/chaton/HomeActivity;->a:Ljava/lang/String;
    000b: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    000e: return-void

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=10, ins=2, outs=8, insns_size=283
    0000: const/4 v2, 0
    0001: const/4 v1, 0
    0002: invoke-super {v8, v9}, Lcom/sec/chaton/base/BaseActivity;->onCreate(Landroid/os/Bundle;)V
    0005: const-string v0, 'auto_regi'
    0007: invoke-static {v0}, Lcom/sec/chaton/global/a;->a(Ljava/lang/String;)Z
    000a: move-result v0
    000b: if-eqz v0, 0014
    000d: invoke-virtual {v8}, Lcom/sec/chaton/HomeActivity;->getIntent()Landroid/content/Intent;
    0010: move-result-object v0
    0011: invoke-direct {v8, v0}, Lcom/sec/chaton/HomeActivity;->c(Landroid/content/Intent;)V
    0014: invoke-direct {v8}, Lcom/sec/chaton/HomeActivity;->c()Z
    0017: move-result v0
    0018: if-eqz v0, 002b
    001a: const-string v0, 'AuthenticatorActivity is requested finish.'
    001c: invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    001f: move-result-object v1
    0020: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0023: move-result-object v1
    0024: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    0027: invoke-virtual {v8}, Lcom/sec/chaton/HomeActivity;->finish()V
    002a: return-void
    002b: invoke-direct {v8}, Lcom/sec/chaton/HomeActivity;->d()Z
    002e: move-result v0
    002f: if-nez v0, 006f
    0031: if-nez v9, 006b
    0033: invoke-direct {v8}, Lcom/sec/chaton/HomeActivity;->f()Z
    0036: move-result v0
    0037: if-eqz v0, 0058
    0039: invoke-static {v8}, Lcom/sec/chaton/util/bp;->a(Landroid/content/Context;)Z
    003c: move-result v0
    003d: if-eqz v0, 0058
    003f: new-instance v0, Lcom/coolots/sso/a/a;
    0041: invoke-direct {v0}, Lcom/coolots/sso/a/a;-><init>()V
    0044: iput v0, v8.Lcom/sec/chaton/HomeActivity;->b:Lcom/coolots/sso/a/a;
    0046: iget v0, v8.Lcom/sec/chaton/HomeActivity;->b:Lcom/coolots/sso/a/a;
    0048: invoke-virtual {v0, v8}, Lcom/coolots/sso/a/a;->d(Landroid/content/Context;)Z
    004b: move-result v0
    004c: if-eqz v0, 0058
    004e: iget v0, v8.Lcom/sec/chaton/HomeActivity;->b:Lcom/coolots/sso/a/a;
    0050: invoke-virtual {v0, v8, v8}, Lcom/coolots/sso/a/a;->a(Landroid/content/Context;Lcom/coolots/sso/a/c;)V
    0053: iget v0, v8.Lcom/sec/chaton/HomeActivity;->b:Lcom/coolots/sso/a/a;
    0055: invoke-static {v8, v0}, Lcom/sec/chaton/util/bp;->b(Landroid/content/Context;Lcom/coolots/sso/a/a;)V
    0058: invoke-virtual {v8, v1, v1}, Lcom/sec/chaton/HomeActivity;->overridePendingTransition(II)V
    005b: invoke-static {v8}, Landroid/accounts/AccountManager;->get(Landroid/content/Context;)Landroid/accounts/AccountManager;
    005e: move-result-object v0
    005f: const-string v1, 'com.sec.chaton'
    0061: iget v6, v8.Lcom/sec/chaton/HomeActivity;->d:Landroid/accounts/AccountManagerCallback;
    0063: move(op=07) v3, v2
    0064: move(op=07) v4, v2
    0065: move(op=07) v5, v8
    0066: move(op=07) v7, v2
    0067: invoke-virtual/range {v0..v7}, Landroid/accounts/AccountManager;->addAccount(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Landroid/os/Bundle;Landroid/app/Activity;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;
    006a: goto 002a
    006b: invoke-virtual {v8}, Lcom/sec/chaton/HomeActivity;->finish()V
    006e: goto 002a
    006f: invoke-virtual {v8}, Lcom/sec/chaton/HomeActivity;->getIntent()Landroid/content/Intent;
    0072: move-result-object v2
    0073: goto 008f
    0074: nop
    0075: invoke-virtual {v2, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    0078: move-result v0
    0079: const-string v3, 'skipSplash'
    007b: invoke-virtual {v2, v3}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V
    007e: sget v3, Lcom/sec/chaton/global/GlobalApplication;->i:Lcom/sec/chaton/k;
    0080: if-eqz v3, 008c
    0082: sget v3, Lcom/sec/chaton/global/GlobalApplication;->i:Lcom/sec/chaton/k;
    0084: invoke-virtual {v3}, Lcom/sec/chaton/k;->getStatus()Landroid/os/AsyncTask$Status;
    0087: move-result-object v3
    0088: sget v4, Landroid/os/AsyncTask$Status;->FINISHED:Landroid/os/AsyncTask$Status;
    008a: if-eq v3, v4, 008d
    008c: move(op=01) v0, v1
    008d: if-eqz v0, 009a
    008f: invoke-direct {v8, v2}, Lcom/sec/chaton/HomeActivity;->d(Landroid/content/Intent;)Landroid/content/Intent;
    0092: move-result-object v0
    0093: invoke-virtual {v8, v0}, Lcom/sec/chaton/HomeActivity;->startActivity(Landroid/content/Intent;)V
    0096: invoke-virtual {v8}, Lcom/sec/chaton/HomeActivity;->finish()V
    0099: goto 002a
    009a: const v0, 2130903313 (0x7f030111)
    009d: invoke-virtual {v8, v0}, Lcom/sec/chaton/HomeActivity;->setContentView(I)V
    00a0: invoke-virtual {v8}, Lcom/sec/chaton/HomeActivity;->getResources()Landroid/content/res/Resources;
    00a3: move-result-object v0
    00a4: invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;
    00a7: move-result-object v0
    00a8: invoke-direct {v8, v0}, Lcom/sec/chaton/HomeActivity;->a(Landroid/content/res/Configuration;)V
    00ab: invoke-direct {v8}, Lcom/sec/chaton/HomeActivity;->e()Z
    00ae: move-result v0
    00af: if-eqz v0, 00ce
    00b1: new-instance v0, Landroid/content/Intent;
    00b3: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    00b6: move-result-object v3
    00b7: const-class v4, Lcom/sec/chaton/service/BackGroundRegiService;
    00b9: invoke-direct {v0, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    00bc: const-string v3, 'request_type'
    00be: invoke-virtual {v0, v3, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    00c1: const-string v3, 'request_on_chaton'
    00c3: const/4 v4, 1
    00c4: invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    00c7: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    00ca: move-result-object v3
    00cb: invoke-virtual {v3, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    00ce: iget v0, v8.Lcom/sec/chaton/HomeActivity;->c:Landroid/os/Handler;
    00d0: iget v3, v8.Lcom/sec/chaton/HomeActivity;->c:Landroid/os/Handler;
    00d2: invoke-static {v3, v1, v2}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;
    00d5: move-result-object v2
    00d6: const-wide/16 v3, 500
    00d8: invoke-virtual {v0, v2, v3, v4}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z
    00db: sget v0, Lcom/sec/chaton/global/GlobalApplication;->i:Lcom/sec/chaton/k;
    00dd: if-nez v0, 00ff
    00df: sget v0, Lcom/sec/chaton/util/p;->b:Z
    00e1: if-eqz v0, 00ea
    00e3: const-string v0, "Application initialize logic isn't execute. execute it now."
    00e5: sget v2, Lcom/sec/chaton/HomeActivity;->a:Ljava/lang/String;
    00e7: invoke-static {v0, v2}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    00ea: new-instance v0, Lcom/sec/chaton/k;
    00ec: invoke-direct {v0}, Lcom/sec/chaton/k;-><init>()V
    00ef: sput v0, Lcom/sec/chaton/global/GlobalApplication;->i:Lcom/sec/chaton/k;
    00f1: sget v0, Lcom/sec/chaton/global/GlobalApplication;->i:Lcom/sec/chaton/k;
    00f3: invoke-virtual {v0, v8}, Lcom/sec/chaton/k;->a(Lcom/sec/chaton/l;)V
    00f6: sget v0, Lcom/sec/chaton/global/GlobalApplication;->i:Lcom/sec/chaton/k;
    00f8: new-array v1, v1, [Ljava/lang/Void;
    00fa: invoke-virtual {v0, v1}, Lcom/sec/chaton/k;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;
    00fd: goto/16 002a
    00ff: sget v0, Lcom/sec/chaton/global/GlobalApplication;->i:Lcom/sec/chaton/k;
    0101: invoke-virtual {v0}, Lcom/sec/chaton/k;->getStatus()Landroid/os/AsyncTask$Status;
    0104: move-result-object v0
    0105: sget v1, Landroid/os/AsyncTask$Status;->FINISHED:Landroid/os/AsyncTask$Status;
    0107: if-eq v0, v1, 002a
    0109: sget v0, Lcom/sec/chaton/util/p;->b:Z
    010b: if-eqz v0, 0114
    010d: const-string v0, 'Application initialize logic alrady running.'
    010f: sget v1, Lcom/sec/chaton/HomeActivity;->a:Ljava/lang/String;
    0111: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0114: sget v0, Lcom/sec/chaton/global/GlobalApplication;->i:Lcom/sec/chaton/k;
    0116: invoke-virtual {v0, v8}, Lcom/sec/chaton/k;->a(Lcom/sec/chaton/l;)V
    0119: goto/16 002a

  [Virtual Method] onDestroy() -> V
    // registers=4, ins=1, outs=3, insns_size=29
    0000: const/4 v2, 0
    0001: invoke-super {v3}, Lcom/sec/chaton/base/BaseActivity;->onDestroy()V
    0004: sget v0, Lcom/sec/chaton/global/GlobalApplication;->i:Lcom/sec/chaton/k;
    0006: if-eqz v0, 000d
    0008: sget v0, Lcom/sec/chaton/global/GlobalApplication;->i:Lcom/sec/chaton/k;
    000a: invoke-virtual {v0, v2}, Lcom/sec/chaton/k;->a(Lcom/sec/chaton/l;)V
    000d: iget v0, v3.Lcom/sec/chaton/HomeActivity;->c:Landroid/os/Handler;
    000f: const/4 v1, 0
    0010: invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V
    0013: iget v0, v3.Lcom/sec/chaton/HomeActivity;->b:Lcom/coolots/sso/a/a;
    0015: if-eqz v0, 001c
    0017: iget v0, v3.Lcom/sec/chaton/HomeActivity;->b:Lcom/coolots/sso/a/a;
    0019: invoke-virtual {v0, v3, v2}, Lcom/coolots/sso/a/a;->a(Landroid/content/Context;Lcom/coolots/sso/a/c;)V
    001c: return-void