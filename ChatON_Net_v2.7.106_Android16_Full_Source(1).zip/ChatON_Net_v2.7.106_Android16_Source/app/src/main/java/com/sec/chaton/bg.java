=== CLASS Lcom/sec/chaton/bg; (Source: TabActivity.java) ===
  Super: Landroid/os/Handler;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/bg;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Landroid/os/Handler;-><init>()V
    0005: return-void

  [Virtual Method] handleMessage(Landroid/os/Message;) -> V
    // registers=5, ins=2, outs=3, insns_size=115
    0000: const-string v0, '2'
    0002: iget v0, v4.Landroid/os/Message;->obj:Ljava/lang/Object;
    0004: check-cast v0, Lcom/sec/chaton/a/a/d;
    0006: invoke-virtual {v0}, Lcom/sec/chaton/a/a/d;->d()Ljava/lang/Object;
    0009: move-result-object v1
    000a: check-cast v1, Lcom/sec/chaton/io/entry/AvaliableApps;
    000c: if-nez v1, 000f
    000e: return-void
    000f: invoke-virtual {v0}, Lcom/sec/chaton/a/a/d;->a()Z
    0012: move-result v2
    0013: if-eqz v2, 0069
    0015: invoke-virtual {v0}, Lcom/sec/chaton/a/a/d;->b()Lcom/sec/chaton/i/n;
    0018: move-result-object v0
    0019: sget v2, Lcom/sec/chaton/i/n;->c:Lcom/sec/chaton/i/n;
    001b: if-eq v0, v2, 0069
    001d: iget v0, v1.Lcom/sec/chaton/io/entry/AvaliableApps;->resultCode:Ljava/lang/String;
    001f: if-eqz v0, 0069
    0021: iget v0, v1.Lcom/sec/chaton/io/entry/AvaliableApps;->resultCode:Ljava/lang/String;
    0023: const-string v2, '2'
    0025: invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0028: move-result v0
    0029: if-eqz v0, 0069
    002b: iget v0, v1.Lcom/sec/chaton/io/entry/AvaliableApps;->version:Ljava/lang/String;
    002d: invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z
    0030: move-result v0
    0031: if-nez v0, 003a
    0033: const-string v0, 'sppLatestVer'
    0035: iget v1, v1.Lcom/sec/chaton/io/entry/AvaliableApps;->version:Ljava/lang/String;
    0037: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/String;)V
    003a: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    003d: move-result-object v0
    003e: const-string v1, 'UpdateIsCritical'
    0040: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0043: move-result v0
    0044: if-eqz v0, 0050
    0046: const-string v0, 'ChatON updating process is still progressing.'
    0048: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    004b: move-result-object v1
    004c: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    004f: goto 000e
    0050: new-instance v0, Landroid/content/Intent;
    0052: iget v1, v3.Lcom/sec/chaton/bg;->a:Lcom/sec/chaton/TabActivity;
    0054: const-class v2, Lcom/sec/chaton/SPPUpgradeDialog;
    0056: invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0059: iget v1, v3.Lcom/sec/chaton/bg;->a:Lcom/sec/chaton/TabActivity;
    005b: invoke-virtual {v1, v0}, Lcom/sec/chaton/TabActivity;->startActivity(Landroid/content/Intent;)V
    005e: const-string v0, 'sppIsUpdate'
    0060: const/4 v1, 1
    0061: invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0064: move-result-object v1
    0065: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Boolean;)V
    0068: goto 000e
    0069: const-string v0, 'There is no update of SPPPushClient.'
    006b: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    006e: move-result-object v1
    006f: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0072: goto 000e