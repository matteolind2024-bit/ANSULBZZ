=== CLASS Lcom/sec/chaton/ay; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/sec/chaton/util/bb;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/ay;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] a() -> Z
    // registers=8, ins=1, outs=3, insns_size=148
    0000: const/4 v0, 1
    0001: const/4 v1, 0
    0002: sget v2, Lcom/sec/chaton/util/p;->b:Z
    0004: if-eqz v2, 0046
    0006: const/4 v2, 6
    0007: new-array v2, v2, [Ljava/lang/Object;
    0009: const-string v3, 'UID : '
    000b: aput(op=4d) v3, v2[v1]
    000d: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0010: move-result-object v3
    0011: const-string v4, 'uid'
    0013: invoke-virtual {v3, v4}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0016: move-result v3
    0017: invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    001a: move-result-object v3
    001b: aput(op=4d) v3, v2[v0]
    001d: const/4 v3, 2
    001e: const-string v4, ', compatibility : '
    0020: aput(op=4d) v4, v2[v3]
    0022: const/4 v3, 3
    0023: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0026: move-result-object v4
    0027: const-string v5, 'compatibility'
    0029: const-string v6, ''
    002b: invoke-virtual {v4, v5, v6}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    002e: move-result-object v4
    002f: aput(op=4d) v4, v2[v3]
    0031: const/4 v3, 4
    0032: const-string v4, ', version : '
    0034: aput(op=4d) v4, v2[v3]
    0036: const/4 v3, 5
    0037: sget v4, Lcom/sec/chaton/c/a;->b:Ljava/lang/String;
    0039: aput(op=4d) v4, v2[v3]
    003b: invoke-static {v2}, Lcom/sec/common/b/d/d;->a([Ljava/lang/Object;)Ljava/lang/String;
    003e: move-result-object v2
    003f: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    0042: move-result-object v3
    0043: invoke-static {v2, v3}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0046: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0049: move-result-object v2
    004a: const-string v3, 'uid'
    004c: invoke-virtual {v2, v3}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    004f: move-result v2
    0050: if-eqz v2, 0092
    0052: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0055: move-result-object v2
    0056: const-string v3, 'compatibility'
    0058: const-string v4, ''
    005a: invoke-virtual {v2, v3, v4}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    005d: move-result-object v2
    005e: invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z
    0061: move-result v2
    0062: if-nez v2, 0078
    0064: sget v2, Lcom/sec/chaton/c/a;->b:Ljava/lang/String;
    0066: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0069: move-result-object v3
    006a: const-string v4, 'compatibility'
    006c: const-string v5, ''
    006e: invoke-virtual {v3, v4, v5}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    0071: move-result-object v3
    0072: invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0075: move-result v2
    0076: if-nez v2, 0092
    0078: new-instance v1, Lcom/sec/chaton/d/h;
    007a: iget v2, v7.Lcom/sec/chaton/ay;->a:Lcom/sec/chaton/TabActivity;
    007c: invoke-static {v2}, Lcom/sec/chaton/TabActivity;->c(Lcom/sec/chaton/TabActivity;)Landroid/os/Handler;
    007f: move-result-object v2
    0080: invoke-direct {v1, v2}, Lcom/sec/chaton/d/h;-><init>(Landroid/os/Handler;)V
    0083: invoke-virtual {v1}, Lcom/sec/chaton/d/h;->f()V
    0086: const-string v1, 'Start CompatibilityTask'
    0088: const-class v2, Lcom/sec/chaton/global/GlobalApplication;
    008a: invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    008d: move-result-object v2
    008e: invoke-static {v1, v2}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0091: return v0
    0092: move(op=01) v0, v1
    0093: goto 0091