=== CLASS Lcom/sec/chaton/ShortcutActivity; (Source: ShortcutActivity.java) ===
  Super: Lcom/sec/chaton/base/BaseActivity;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/base/BaseActivity;-><init>()V
    0003: return-void

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=13, ins=2, outs=6, insns_size=449
    0000: const v6, 2131493079 (0x7f0c00d7)
    0003: const/4 v2, 0
    0004: const/4 v10, 1
    0005: const/4 v9, 0
    0006: invoke-super {v11, v12}, Lcom/sec/chaton/base/BaseActivity;->onCreate(Landroid/os/Bundle;)V
    0009: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    000c: move-result-object v0
    000d: const-string v1, 'uid'
    000f: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0012: move-result v0
    0013: if-eqz v0, 01b2
    0015: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getIntent()Landroid/content/Intent;
    0018: move-result-object v0
    0019: invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    001c: move-result-object v0
    001d: if-eqz v0, 00b3
    001f: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getIntent()Landroid/content/Intent;
    0022: move-result-object v0
    0023: invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0026: move-result-object v0
    0027: const-string v1, 'android.intent.action.VIEW'
    0029: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    002c: move-result v0
    002d: if-eqz v0, 00b3
    002f: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getIntent()Landroid/content/Intent;
    0032: move-result-object v0
    0033: invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;
    0036: move-result-object v0
    0037: if-eqz v0, 00b3
    0039: const-string v0, 'Shocrcut from contact'
    003b: invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    003e: move-result-object v1
    003f: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0042: move-result-object v1
    0043: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    0046: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getIntent()Landroid/content/Intent;
    0049: move-result-object v0
    004a: invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;
    004d: move-result-object v1
    004e: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getContentResolver()Landroid/content/ContentResolver;
    0051: move-result-object v0
    0052: move(op=07) v3, v2
    0053: move(op=07) v4, v2
    0054: move(op=07) v5, v2
    0055: invoke-virtual/range {v0..v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    0058: move-result-object v0
    0059: invoke-interface {v0}, Landroid/database/Cursor;->moveToFirst()Z
    005c: move-result v1
    005d: if-eqz v1, 0094
    005f: const-string v1, 'data1'
    0061: invoke-interface {v0, v1}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I
    0064: move-result v1
    0065: invoke-interface {v0, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;
    0068: move-result-object v1
    0069: new-instance v2, Landroid/content/Intent;
    006b: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getApplicationContext()Landroid/content/Context;
    006e: move-result-object v3
    006f: invoke-static {v3, v10}, Lcom/sec/chaton/TabActivity;->a(Landroid/content/Context;Z)Landroid/content/Intent;
    0072: move-result-object v3
    0073: invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V
    0076: const-string v3, 'inboxNO'
    0078: invoke-virtual {v2, v3, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    007b: const-string v3, 'chatType'
    007d: sget v4, Lcom/sec/chaton/e/n;->b:Lcom/sec/chaton/e/n;
    007f: invoke-virtual {v4}, Lcom/sec/chaton/e/n;->a()I
    0082: move-result v4
    0083: invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    0086: const-string v3, 'contact'
    0088: invoke-virtual {v2, v3, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    008b: const-string v3, 'receivers'
    008d: new-array v4, v10, [Ljava/lang/String;
    008f: aput(op=4d) v1, v4[v9]
    0091: invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;
    0094: invoke-interface {v0}, Landroid/database/Cursor;->close()V
    0097: if-eqz v2, 00a0
    0099: invoke-virtual {v11, v2}, Lcom/sec/chaton/ShortcutActivity;->startActivity(Landroid/content/Intent;)V
    009c: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->finish()V
    009f: return-void
    00a0: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getResources()Landroid/content/res/Resources;
    00a3: move-result-object v0
    00a4: invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    00a7: move-result-object v0
    00a8: invoke-static {v11, v0, v9}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    00ab: move-result-object v0
    00ac: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    00af: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->finish()V
    00b2: goto 009f
    00b3: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getIntent()Landroid/content/Intent;
    00b6: move-result-object v0
    00b7: invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    00ba: move-result-object v0
    00bb: if-eqz v0, 019e
    00bd: const-string v1, 'Shocrcut from homescreen'
    00bf: invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    00c2: move-result-object v3
    00c3: invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    00c6: move-result-object v3
    00c7: invoke-static {v1, v3}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    00ca: const-string v1, 'inboxNO'
    00cc: invoke-virtual {v0, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    00cf: move-result-object v1
    00d0: const-string v3, 'chatType'
    00d2: invoke-virtual {v0, v3}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I
    00d5: move-result v0
    00d6: sget v3, Lcom/sec/chaton/e/n;->b:Lcom/sec/chaton/e/n;
    00d8: invoke-virtual {v3}, Lcom/sec/chaton/e/n;->a()I
    00db: move-result v3
    00dc: if-ne v0, v3, 0155
    00de: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getContentResolver()Landroid/content/ContentResolver;
    00e1: move-result-object v3
    00e2: sget v4, Lcom/sec/chaton/e/f;->a:Landroid/net/Uri;
    00e4: new-array v5, v10, [Ljava/lang/String;
    00e6: const-string v6, 'buddy_no'
    00e8: aput(op=4d) v6, v5[v9]
    00ea: const-string v6, 'buddy_no=?'
    00ec: new-array v7, v10, [Ljava/lang/String;
    00ee: aput(op=4d) v1, v7[v9]
    00f0: move(op=07) v8, v2
    00f1: invoke-virtual/range {v3..v8}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    00f4: move-result-object v2
    00f5: if-eqz v2, 00fd
    00f7: invoke-interface {v2}, Landroid/database/Cursor;->getCount()I
    00fa: move-result v3
    00fb: if-nez v3, 0119
    00fd: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getResources()Landroid/content/res/Resources;
    0100: move-result-object v0
    0101: const v1, 2131493079 (0x7f0c00d7)
    0104: invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    0107: move-result-object v0
    0108: const/4 v1, 0
    0109: invoke-static {v11, v0, v1}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    010c: move-result-object v0
    010d: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    0110: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->finish()V
    0113: if-eqz v2, 009f
    0115: invoke-interface {v2}, Landroid/database/Cursor;->close()V
    0118: goto 009f
    0119: if-eqz v2, 011e
    011b: invoke-interface {v2}, Landroid/database/Cursor;->close()V
    011e: new-instance v2, Landroid/content/Intent;
    0120: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getApplicationContext()Landroid/content/Context;
    0123: move-result-object v3
    0124: invoke-static {v3, v10}, Lcom/sec/chaton/TabActivity;->a(Landroid/content/Context;Z)Landroid/content/Intent;
    0127: move-result-object v3
    0128: invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V
    012b: sget v3, Lcom/sec/chaton/e/n;->b:Lcom/sec/chaton/e/n;
    012d: invoke-virtual {v3}, Lcom/sec/chaton/e/n;->a()I
    0130: move-result v3
    0131: if-ne v0, v3, 013c
    0133: new-array v3, v10, [Ljava/lang/String;
    0135: aput(op=4d) v1, v3[v9]
    0137: const-string v4, 'receivers'
    0139: invoke-virtual {v2, v4, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;
    013c: const-string v3, 'inboxNO'
    013e: invoke-virtual {v2, v3, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    0141: const-string v1, 'chatType'
    0143: invoke-virtual {v2, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    0146: invoke-virtual {v11, v2}, Lcom/sec/chaton/ShortcutActivity;->startActivity(Landroid/content/Intent;)V
    0149: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->finish()V
    014c: goto/16 009f
    014e: move-exception v0
    014f: if-eqz v2, 0154
    0151: invoke-interface {v2}, Landroid/database/Cursor;->close()V
    0154: throw v0
    0155: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getContentResolver()Landroid/content/ContentResolver;
    0158: move-result-object v3
    0159: sget v4, Lcom/sec/chaton/e/m;->a:Landroid/net/Uri;
    015b: new-array v5, v10, [Ljava/lang/String;
    015d: const-string v6, 'inbox_no'
    015f: aput(op=4d) v6, v5[v9]
    0161: const-string v6, 'inbox_no=?'
    0163: new-array v7, v10, [Ljava/lang/String;
    0165: aput(op=4d) v1, v7[v9]
    0167: move(op=07) v8, v2
    0168: invoke-virtual/range {v3..v8}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    016b: move-result-object v2
    016c: if-eqz v2, 0174
    016e: invoke-interface {v2}, Landroid/database/Cursor;->getCount()I
    0171: move-result v3
    0172: if-nez v3, 0191
    0174: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getResources()Landroid/content/res/Resources;
    0177: move-result-object v0
    0178: const v1, 2131493079 (0x7f0c00d7)
    017b: invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    017e: move-result-object v0
    017f: const/4 v1, 0
    0180: invoke-static {v11, v0, v1}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    0183: move-result-object v0
    0184: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    0187: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->finish()V
    018a: if-eqz v2, 009f
    018c: invoke-interface {v2}, Landroid/database/Cursor;->close()V
    018f: goto/16 009f
    0191: if-eqz v2, 011e
    0193: invoke-interface {v2}, Landroid/database/Cursor;->close()V
    0196: goto 011e
    0197: move-exception v0
    0198: if-eqz v2, 019d
    019a: invoke-interface {v2}, Landroid/database/Cursor;->close()V
    019d: throw v0
    019e: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->getResources()Landroid/content/res/Resources;
    01a1: move-result-object v0
    01a2: invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    01a5: move-result-object v0
    01a6: invoke-static {v11, v0, v9}, Lcom/sec/widget/ar;->a(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
    01a9: move-result-object v0
    01aa: invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    01ad: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->finish()V
    01b0: goto/16 009f
    01b2: new-instance v0, Landroid/content/Intent;
    01b4: const-class v1, Lcom/sec/chaton/TabActivity;
    01b6: invoke-direct {v0, v11, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    01b9: invoke-virtual {v11, v0}, Lcom/sec/chaton/ShortcutActivity;->startActivity(Landroid/content/Intent;)V
    01bc: invoke-virtual {v11}, Lcom/sec/chaton/ShortcutActivity;->finish()V
    01bf: goto/16 009f