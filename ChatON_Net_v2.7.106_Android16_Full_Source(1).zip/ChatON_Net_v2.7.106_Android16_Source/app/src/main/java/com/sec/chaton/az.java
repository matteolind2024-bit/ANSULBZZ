=== CLASS Lcom/sec/chaton/az; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/sec/chaton/util/bb;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/az;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] a() -> Z
    // registers=3, ins=1, outs=2, insns_size=29
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'uid'
    0006: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0009: move-result v0
    000a: if-eqz v0, 001b
    000c: new-instance v0, Lcom/sec/chaton/d/g;
    000e: new-instance v1, Landroid/os/Handler;
    0010: invoke-direct {v1}, Landroid/os/Handler;-><init>()V
    0013: invoke-direct {v0, v1}, Lcom/sec/chaton/d/g;-><init>(Landroid/os/Handler;)V
    0016: invoke-virtual {v0}, Lcom/sec/chaton/d/g;->a()Lcom/sec/chaton/d/a/y;
    0019: const/4 v0, 1
    001a: return v0
    001b: const/4 v0, 0
    001c: goto 001a