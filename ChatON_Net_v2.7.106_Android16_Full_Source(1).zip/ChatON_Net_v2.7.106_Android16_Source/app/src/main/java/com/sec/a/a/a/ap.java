=== CLASS Lcom/sec/a/a/a/ap; (Source: MsgFrontendCommon.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] a(Ljava/lang/Object;) -> B
    // registers=2, ins=1, outs=0, insns_size=85
    0000: instance-of v0, v1, Lcom/sec/a/a/a/l;
    0002: if-eqz v0, 0006
    0004: const/4 v0, 0
    0005: return v0
    0006: instance-of v0, v1, Lcom/sec/a/a/a/i;
    0008: if-eqz v0, 000c
    000a: const/4 v0, 1
    000b: goto 0005
    000c: instance-of v0, v1, Lcom/sec/a/a/a/am;
    000e: if-eqz v0, 0012
    0010: const/4 v0, 2
    0011: goto 0005
    0012: instance-of v0, v1, Lcom/sec/a/a/a/aj;
    0014: if-eqz v0, 0018
    0016: const/4 v0, 3
    0017: goto 0005
    0018: instance-of v0, v1, Lcom/sec/a/a/a/f;
    001a: if-eqz v0, 001e
    001c: const/4 v0, 4
    001d: goto 0005
    001e: instance-of v0, v1, Lcom/sec/a/a/a/c;
    0020: if-eqz v0, 0024
    0022: const/4 v0, 5
    0023: goto 0005
    0024: instance-of v0, v1, Lcom/sec/a/a/a/aa;
    0026: if-eqz v0, 002a
    0028: const/4 v0, 6
    0029: goto 0005
    002a: instance-of v0, v1, Lcom/sec/a/a/a/x;
    002c: if-eqz v0, 0030
    002e: const/4 v0, 7
    002f: goto 0005
    0030: instance-of v0, v1, Lcom/sec/a/a/a/r;
    0032: if-eqz v0, 0037
    0034: const/16 v0, 8 (0x8)
    0036: goto 0005
    0037: instance-of v0, v1, Lcom/sec/a/a/a/u;
    0039: if-eqz v0, 003e
    003b: const/16 v0, 9 (0x9)
    003d: goto 0005
    003e: instance-of v0, v1, Lcom/sec/a/a/a/o;
    0040: if-eqz v0, 0045
    0042: const/16 v0, 10 (0xa)
    0044: goto 0005
    0045: instance-of v0, v1, Lcom/sec/a/a/a/ag;
    0047: if-eqz v0, 004c
    0049: const/16 v0, 11 (0xb)
    004b: goto 0005
    004c: instance-of v0, v1, Lcom/sec/a/a/a/ad;
    004e: if-eqz v0, 0053
    0050: const/16 v0, 12 (0xc)
    0052: goto 0005
    0053: const/4 v0, -1
    0054: goto 0005

  [Direct Method] a(B, [B) -> Ljava/lang/Object;
    // registers=4, ins=2, outs=1, insns_size=106
    0000: const/4 v0, 0
    0001: packed-switch v2, +75 (-> 004c)
    0004: return-object v0
    0005: invoke-static {v3}, Lcom/sec/a/a/a/l;->a([B)Lcom/sec/a/a/a/l;
    0008: move-result-object v0
    0009: goto 0004
    000a: invoke-static {v3}, Lcom/sec/a/a/a/i;->a([B)Lcom/sec/a/a/a/i;
    000d: move-result-object v0
    000e: goto 0004
    000f: invoke-static {v3}, Lcom/sec/a/a/a/am;->a([B)Lcom/sec/a/a/a/am;
    0012: move-result-object v0
    0013: goto 0004
    0014: invoke-static {v3}, Lcom/sec/a/a/a/aj;->a([B)Lcom/sec/a/a/a/aj;
    0017: move-result-object v0
    0018: goto 0004
    0019: invoke-static {v3}, Lcom/sec/a/a/a/f;->a([B)Lcom/sec/a/a/a/f;
    001c: move-result-object v0
    001d: goto 0004
    001e: invoke-static {v3}, Lcom/sec/a/a/a/c;->a([B)Lcom/sec/a/a/a/c;
    0021: move-result-object v0
    0022: goto 0004
    0023: invoke-static {v3}, Lcom/sec/a/a/a/aa;->a([B)Lcom/sec/a/a/a/aa;
    0026: move-result-object v0
    0027: goto 0004
    0028: invoke-static {v3}, Lcom/sec/a/a/a/x;->a([B)Lcom/sec/a/a/a/x;
    002b: move-result-object v0
    002c: goto 0004
    002d: invoke-static {v3}, Lcom/sec/a/a/a/r;->a([B)Lcom/sec/a/a/a/r;
    0030: move-result-object v0
    0031: goto 0004
    0032: invoke-static {v3}, Lcom/sec/a/a/a/u;->a([B)Lcom/sec/a/a/a/u;
    0035: move-result-object v0
    0036: goto 0004
    0037: invoke-static {v3}, Lcom/sec/a/a/a/o;->a([B)Lcom/sec/a/a/a/o;
    003a: move-result-object v0
    003b: goto 0004
    003c: invoke-static {v3}, Lcom/sec/a/a/a/ag;->a([B)Lcom/sec/a/a/a/ag;
    003f: move-result-object v0
    0040: goto 0004
    0041: invoke-static {v3}, Lcom/sec/a/a/a/ad;->a([B)Lcom/sec/a/a/a/ad;
    0044: move-result-object v0
    0045: goto 0004
    0046: move-exception v1
    0047: invoke-virtual {v1}, Lcom/google/protobuf/InvalidProtocolBufferException;->printStackTrace()V
    004a: goto 0004
    004b: nop
    004c: packed-switch-payload first=0 targets=[4, 9, 14, 19, 24, 29, 34, 39, 44, 49, 54, 59, 64]

  [Direct Method] a(B) -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=74
    0000: const/4 v0, 0
    0001: packed-switch v1, +43 (-> 002c)
    0004: return-object v0
    0005: const-string v0, 'InitRequest'
    0007: goto 0004
    0008: const-string v0, 'InitReply'
    000a: goto 0004
    000b: const-string v0, 'RegistrationRequest'
    000d: goto 0004
    000e: const-string v0, 'RegistrationReply'
    0010: goto 0004
    0011: const-string v0, 'DeregistrationRequest'
    0013: goto 0004
    0014: const-string v0, 'DeregistrationReply'
    0016: goto 0004
    0017: const-string v0, 'PingRequest'
    0019: goto 0004
    001a: const-string v0, 'PingReply'
    001c: goto 0004
    001d: const-string v0, 'NotiElement'
    001f: goto 0004
    0020: const-string v0, 'NotiGroup'
    0022: goto 0004
    0023: const-string v0, 'NotiAcks'
    0025: goto 0004
    0026: const-string v0, 'ProvisionRequest'
    0028: goto 0004
    0029: const-string v0, 'ProvisionReply'
    002b: goto 0004
    002c: packed-switch-payload first=0 targets=[4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40]

  [Direct Method] b(Ljava/lang/Object;) -> Ljava/lang/String;
    // registers=2, ins=1, outs=1, insns_size=9
    0000: invoke-static {v1}, Lcom/sec/a/a/a/ap;->a(Ljava/lang/Object;)B
    0003: move-result v0
    0004: invoke-static {v0}, Lcom/sec/a/a/a/ap;->a(B)Ljava/lang/String;
    0007: move-result-object v0
    0008: return-object v0