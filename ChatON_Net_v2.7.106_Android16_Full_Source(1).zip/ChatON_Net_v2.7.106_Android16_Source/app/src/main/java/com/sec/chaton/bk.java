=== CLASS Lcom/sec/chaton/bk; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/sec/chaton/util/bb;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/bk;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] a() -> Z
    // registers=4, ins=1, outs=2, insns_size=24
    0000: const/4 v0, 1
    0001: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0004: move-result-object v1
    0005: const-string v2, 'uid'
    0007: invoke-virtual {v1, v2}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    000a: move-result v1
    000b: if-eqz v1, 0016
    000d: const-string v1, 'uploadAddress'
    000f: invoke-static {v1}, Lcom/sec/chaton/account/i;->c(Ljava/lang/String;)V
    0012: invoke-static {v0}, Lcom/sec/chaton/util/br;->a(Z)V
    0015: return v0
    0016: const/4 v0, 0
    0017: goto 0015