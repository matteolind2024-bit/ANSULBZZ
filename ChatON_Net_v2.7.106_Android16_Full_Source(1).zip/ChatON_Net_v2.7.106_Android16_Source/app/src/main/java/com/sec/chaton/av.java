=== CLASS Lcom/sec/chaton/av; (Source: TabActivity.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/sec/chaton/util/bb;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/av;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] a() -> Z
    // registers=3, ins=1, outs=2, insns_size=40
    0000: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0003: move-result-object v0
    0004: const-string v1, 'uid'
    0006: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0009: move-result v0
    000a: if-eqz v0, 0026
    000c: new-instance v0, Lcom/sec/chaton/d/n;
    000e: new-instance v1, Landroid/os/Handler;
    0010: invoke-direct {v1}, Landroid/os/Handler;-><init>()V
    0013: invoke-direct {v0, v1}, Lcom/sec/chaton/d/n;-><init>(Landroid/os/Handler;)V
    0016: invoke-virtual {v0}, Lcom/sec/chaton/d/n;->a()V
    0019: const-string v0, 'Start InteractionSyncTask'
    001b: const-class v1, Lcom/sec/chaton/global/GlobalApplication;
    001d: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0020: move-result-object v1
    0021: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0024: const/4 v0, 1
    0025: return v0
    0026: const/4 v0, 0
    0027: goto 0025