=== CLASS Lcom/sec/chaton/ag; (Source: MoreFragment.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/content/DialogInterface$OnClickListener;
  [Instance Field] a: Lcom/sec/chaton/af;

  [Direct Method] <init>(Lcom/sec/chaton/af;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/ag;->a:Lcom/sec/chaton/af;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onClick(Landroid/content/DialogInterface;, I) -> V
    // registers=3, ins=3, outs=1, insns_size=4
    0000: invoke-interface {v1}, Landroid/content/DialogInterface;->cancel()V
    0003: return-void