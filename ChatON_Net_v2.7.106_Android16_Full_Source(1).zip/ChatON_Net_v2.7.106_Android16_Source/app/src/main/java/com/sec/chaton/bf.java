=== CLASS Lcom/sec/chaton/bf; (Source: TabActivity.java) ===
  Super: Landroid/os/Handler;
  [Instance Field] a: Lcom/sec/chaton/TabActivity;

  [Direct Method] <init>(Lcom/sec/chaton/TabActivity;, Landroid/os/Looper;) -> V
    // registers=3, ins=3, outs=2, insns_size=6
    0000: iput v1, v0.Lcom/sec/chaton/bf;->a:Lcom/sec/chaton/TabActivity;
    0002: invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    0005: return-void

  [Virtual Method] handleMessage(Landroid/os/Message;) -> V
    // registers=7, ins=2, outs=3, insns_size=306
    0000: const/4 v4, 1
    0001: iget v0, v6.Landroid/os/Message;->obj:Ljava/lang/Object;
    0003: check-cast v0, Lcom/sec/chaton/a/a/d;
    0005: invoke-virtual {v0}, Lcom/sec/chaton/a/a/d;->a()Z
    0008: move-result v1
    0009: if-eqz v1, 001f
    000b: invoke-virtual {v0}, Lcom/sec/chaton/a/a/d;->b()Lcom/sec/chaton/i/n;
    000e: move-result-object v1
    000f: sget v2, Lcom/sec/chaton/i/n;->c:Lcom/sec/chaton/i/n;
    0011: if-eq v1, v2, 001f
    0013: invoke-virtual {v0}, Lcom/sec/chaton/a/a/d;->d()Ljava/lang/Object;
    0016: move-result-object v0
    0017: check-cast v0, Lcom/sec/chaton/io/entry/GetVersionNotice;
    0019: if-eqz v0, 001f
    001b: iget v1, v0.Lcom/sec/chaton/io/entry/GetVersionNotice;->uptodate:Ljava/lang/Boolean;
    001d: if-nez v1, 0020
    001f: return-void
    0020: iget v1, v0.Lcom/sec/chaton/io/entry/GetVersionNotice;->uptodate:Ljava/lang/Boolean;
    0022: invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z
    0025: move-result v1
    0026: if-eqz v1, 00df
    0028: invoke-static {}, Lcom/sec/chaton/util/ac;->v()V
    002b: iget v1, v5.Lcom/sec/chaton/bf;->a:Lcom/sec/chaton/TabActivity;
    002d: invoke-static {v1}, Lcom/sec/chaton/TabActivity;->f(Lcom/sec/chaton/TabActivity;)V
    0030: iget v1, v5.Lcom/sec/chaton/bf;->a:Lcom/sec/chaton/TabActivity;
    0032: invoke-static {v1}, Lcom/sec/chaton/TabActivity;->g(Lcom/sec/chaton/TabActivity;)Ljava/lang/String;
    0035: move-result-object v1
    0036: new-instance v2, Ljava/lang/StringBuilder;
    0038: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    003b: const-string v3, 'Disclaimer statue : '
    003d: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0040: move-result-object v2
    0041: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0044: move-result-object v2
    0045: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0048: move-result-object v2
    0049: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    004c: move-result-object v3
    004d: invoke-static {v2, v3}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0050: iget v2, v0.Lcom/sec/chaton/io/entry/GetVersionNotice;->uptodate:Ljava/lang/Boolean;
    0052: invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z
    0055: move-result v2
    0056: if-nez v2, 0060
    0058: iget v2, v0.Lcom/sec/chaton/io/entry/GetVersionNotice;->critical:Ljava/lang/Boolean;
    005a: invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z
    005d: move-result v2
    005e: if-eq v2, v4, 001f
    0060: const-string v2, 'RUN'
    0062: invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0065: move-result v1
    0066: if-nez v1, 0127
    0068: iget v1, v0.Lcom/sec/chaton/io/entry/GetVersionNotice;->needPopup:Ljava/lang/Boolean;
    006a: invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z
    006d: move-result v1
    006e: if-eqz v1, 011c
    0070: iget v1, v0.Lcom/sec/chaton/io/entry/GetVersionNotice;->disclaimerUID:Ljava/lang/String;
    0072: if-eqz v1, 011c
    0074: iget v1, v5.Lcom/sec/chaton/bf;->a:Lcom/sec/chaton/TabActivity;
    0076: iget v0, v0.Lcom/sec/chaton/io/entry/GetVersionNotice;->disclaimerUID:Ljava/lang/String;
    0078: invoke-static {v1, v0}, Lcom/sec/chaton/TabActivity;->a(Lcom/sec/chaton/TabActivity;Ljava/lang/String;)V
    007b: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    007e: move-result-object v0
    007f: const-string v1, 'is_first_accept'
    0081: invoke-virtual {v0, v1}, Lcom/sec/chaton/util/s;->b(Ljava/lang/String;)Z
    0084: move-result v0
    0085: if-nez v0, 001f
    0087: new-instance v0, Ljava/lang/StringBuilder;
    0089: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    008c: const-string v1, 'Accept time : '
    008e: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0091: move-result-object v0
    0092: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0095: move-result-object v1
    0096: const-string v2, 'accept_time'
    0098: const-string v3, ''
    009a: invoke-virtual {v1, v2, v3}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    009d: move-result-object v1
    009e: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a1: move-result-object v0
    00a2: const-string v1, ' Server time: '
    00a4: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a7: move-result-object v0
    00a8: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    00ab: move-result-object v1
    00ac: const-string v2, 'server_time'
    00ae: const-string v3, ''
    00b0: invoke-virtual {v1, v2, v3}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    00b3: move-result-object v1
    00b4: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00b7: move-result-object v0
    00b8: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00bb: move-result-object v0
    00bc: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    00bf: move-result-object v1
    00c0: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    00c3: const-string v0, 'accept_time'
    00c5: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    00c8: move-result-object v1
    00c9: const-string v2, 'server_time'
    00cb: const-string v3, ''
    00cd: invoke-virtual {v1, v2, v3}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    00d0: move-result-object v1
    00d1: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/String;)V
    00d4: const-string v0, 'is_first_accept'
    00d6: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    00d9: move-result-object v1
    00da: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/Boolean;)V
    00dd: goto/16 001f
    00df: iget v1, v5.Lcom/sec/chaton/bf;->a:Lcom/sec/chaton/TabActivity;
    00e1: invoke-virtual {v1}, Lcom/sec/chaton/TabActivity;->getApplicationContext()Landroid/content/Context;
    00e4: move-result-object v1
    00e5: iget v2, v5.Lcom/sec/chaton/bf;->a:Lcom/sec/chaton/TabActivity;
    00e7: invoke-virtual {v2, v1}, Lcom/sec/chaton/TabActivity;->b(Landroid/content/Context;)Ljava/lang/String;
    00ea: move-result-object v2
    00eb: const-string v3, 'com.sec.chaton.settings.ActivityPasswordLockSet'
    00ed: invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    00f0: move-result v2
    00f1: if-ne v2, v4, 0115
    00f3: new-instance v0, Ljava/lang/StringBuilder;
    00f5: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    00f8: const-string v2, 'getClassName : '
    00fa: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00fd: move-result-object v0
    00fe: iget v2, v5.Lcom/sec/chaton/bf;->a:Lcom/sec/chaton/TabActivity;
    0100: invoke-virtual {v2, v1}, Lcom/sec/chaton/TabActivity;->b(Landroid/content/Context;)Ljava/lang/String;
    0103: move-result-object v1
    0104: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0107: move-result-object v0
    0108: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    010b: move-result-object v0
    010c: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    010f: move-result-object v1
    0110: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0113: goto/16 001f
    0115: iget v1, v5.Lcom/sec/chaton/bf;->a:Lcom/sec/chaton/TabActivity;
    0117: invoke-static {v0, v1, v4}, Lcom/sec/chaton/util/ac;->a(Lcom/sec/chaton/io/entry/GetVersionNotice;Landroid/content/Context;Z)V
    011a: goto/16 0030
    011c: const-string v0, 'needPopup or disclaimerUID is null'
    011e: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    0121: move-result-object v1
    0122: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0125: goto/16 007b
    0127: const-string v0, 'Disclaimer State is running'
    0129: invoke-static {}, Lcom/sec/chaton/TabActivity;->c()Ljava/lang/String;
    012c: move-result-object v1
    012d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->d(Ljava/lang/String;Ljava/lang/String;)V
    0130: goto/16 007b