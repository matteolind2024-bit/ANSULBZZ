=== CLASS Lcom/sec/chaton/HomeTabFragment; (Source: HomeTabFragment.java) ===
  Super: Landroid/support/v4/app/Fragment;
  Interfaces: Landroid/widget/TabHost$OnTabChangeListener;
  [Instance Field] a: Lcom/sec/chaton/e/a/s;
  [Instance Field] b: Landroid/widget/TabHost;
  [Instance Field] c: Landroid/widget/TabWidget;
  [Instance Field] d: Ljava/util/HashMap;
  [Instance Field] e: Ljava/lang/String;
  [Instance Field] f: Ljava/lang/String;
  [Instance Field] g: I
  [Instance Field] h: I
  [Instance Field] i: Lcom/sec/chaton/e/a/r;
  [Instance Field] j: Z
  [Instance Field] k: Z
  [Instance Field] l: Z
  [Instance Field] m: Z
  [Instance Field] n: Z
  [Instance Field] o: Landroid/database/ContentObserver;
  [Instance Field] p: Landroid/database/ContentObserver;
  [Instance Field] q: Landroid/database/ContentObserver;
  [Instance Field] r: Landroid/content/BroadcastReceiver;
  [Instance Field] s: Landroid/content/BroadcastReceiver;

  [Direct Method] <init>() -> V
    // registers=3, ins=1, outs=3, insns_size=61
    0000: invoke-direct {v2}, Landroid/support/v4/app/Fragment;-><init>()V
    0003: new-instance v0, Lcom/sec/chaton/w;
    0005: invoke-direct {v0, v2}, Lcom/sec/chaton/w;-><init>(Lcom/sec/chaton/HomeTabFragment;)V
    0008: iput v0, v2.Lcom/sec/chaton/HomeTabFragment;->a:Lcom/sec/chaton/e/a/s;
    000a: new-instance v0, Lcom/sec/chaton/x;
    000c: new-instance v1, Landroid/os/Handler;
    000e: invoke-direct {v1}, Landroid/os/Handler;-><init>()V
    0011: invoke-direct {v0, v2, v1}, Lcom/sec/chaton/x;-><init>(Lcom/sec/chaton/HomeTabFragment;Landroid/os/Handler;)V
    0014: iput v0, v2.Lcom/sec/chaton/HomeTabFragment;->o:Landroid/database/ContentObserver;
    0016: new-instance v0, Lcom/sec/chaton/y;
    0018: new-instance v1, Landroid/os/Handler;
    001a: invoke-direct {v1}, Landroid/os/Handler;-><init>()V
    001d: invoke-direct {v0, v2, v1}, Lcom/sec/chaton/y;-><init>(Lcom/sec/chaton/HomeTabFragment;Landroid/os/Handler;)V
    0020: iput v0, v2.Lcom/sec/chaton/HomeTabFragment;->p:Landroid/database/ContentObserver;
    0022: new-instance v0, Lcom/sec/chaton/z;
    0024: new-instance v1, Landroid/os/Handler;
    0026: invoke-direct {v1}, Landroid/os/Handler;-><init>()V
    0029: invoke-direct {v0, v2, v1}, Lcom/sec/chaton/z;-><init>(Lcom/sec/chaton/HomeTabFragment;Landroid/os/Handler;)V
    002c: iput v0, v2.Lcom/sec/chaton/HomeTabFragment;->q:Landroid/database/ContentObserver;
    002e: new-instance v0, Lcom/sec/chaton/aa;
    0030: invoke-direct {v0, v2}, Lcom/sec/chaton/aa;-><init>(Lcom/sec/chaton/HomeTabFragment;)V
    0033: iput v0, v2.Lcom/sec/chaton/HomeTabFragment;->r:Landroid/content/BroadcastReceiver;
    0035: new-instance v0, Lcom/sec/chaton/ab;
    0037: invoke-direct {v0, v2}, Lcom/sec/chaton/ab;-><init>(Lcom/sec/chaton/HomeTabFragment;)V
    003a: iput v0, v2.Lcom/sec/chaton/HomeTabFragment;->s:Landroid/content/BroadcastReceiver;
    003c: return-void

  [Direct Method] a(Lcom/sec/chaton/HomeTabFragment;, I) -> I
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/HomeTabFragment;->g:I
    0002: return v1

  [Direct Method] a(Landroid/database/Cursor;) -> V
    // registers=4, ins=2, outs=2, insns_size=22
    0000: invoke-static {}, Lcom/sec/chaton/e/b/e;->a()Lcom/sec/chaton/e/b/e;
    0003: move-result-object v0
    0004: invoke-virtual {v0}, Lcom/sec/chaton/e/b/e;->c()Landroid/os/Message;
    0007: move-result-object v0
    0008: iput v3, v0.Landroid/os/Message;->obj:Ljava/lang/Object;
    000a: invoke-static {}, Lcom/sec/chaton/e/b/e;->a()Lcom/sec/chaton/e/b/e;
    000d: move-result-object v1
    000e: invoke-virtual {v1}, Lcom/sec/chaton/e/b/e;->b()Landroid/os/Handler;
    0011: move-result-object v1
    0012: invoke-virtual {v1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z
    0015: return-void

  [Direct Method] a(Landroid/support/v4/app/Fragment;, Landroid/widget/TabHost;, Landroid/widget/TabWidget;, Ljava/util/HashMap;, I, I, Ljava/lang/String;, Landroid/support/v4/app/Fragment;) -> V
    // registers=11, ins=8, outs=4, insns_size=98
    0000: const/4 v2, -1
    0001: new-instance v0, Landroid/widget/FrameLayout;
    0003: invoke-virtual {v3}, Landroid/support/v4/app/Fragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0006: move-result-object v1
    0007: invoke-direct {v0, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V
    000a: invoke-virtual {v0, v7}, Landroid/widget/FrameLayout;->setId(I)V
    000d: new-instance v1, Landroid/view/ViewGroup$LayoutParams;
    000f: invoke-direct {v1, v2, v2}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V
    0012: invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    0015: invoke-virtual {v4}, Landroid/widget/TabHost;->getTabContentView()Landroid/widget/FrameLayout;
    0018: move-result-object v1
    0019: invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    001c: invoke-virtual {v3}, Landroid/support/v4/app/Fragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    001f: move-result-object v0
    0020: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getLayoutInflater()Landroid/view/LayoutInflater;
    0023: move-result-object v0
    0024: const/4 v1, 0
    0025: invoke-virtual {v0, v8, v5, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;
    0028: move-result-object v0
    0029: check-cast v0, Landroid/view/ViewGroup;
    002b: invoke-virtual {v0, v9}, Landroid/view/ViewGroup;->setTag(Ljava/lang/Object;)V
    002e: if-eqz v10, 0059
    0030: invoke-virtual {v3}, Landroid/support/v4/app/Fragment;->getFragmentManager()Landroid/support/v4/app/FragmentManager;
    0033: move-result-object v1
    0034: invoke-virtual {v1}, Landroid/support/v4/app/FragmentManager;->beginTransaction()Landroid/support/v4/app/FragmentTransaction;
    0037: move-result-object v1
    0038: invoke-virtual {v1, v7, v10, v9}, Landroid/support/v4/app/FragmentTransaction;->add(ILandroid/support/v4/app/Fragment;Ljava/lang/String;)Landroid/support/v4/app/FragmentTransaction;
    003b: move-result-object v1
    003c: invoke-virtual {v1}, Landroid/support/v4/app/FragmentTransaction;->commit()I
    003f: move(op=07) v1, v10
    0040: instance-of v2, v1, Lcom/sec/chaton/ac;
    0042: if-eqz v2, 0049
    0044: check-cast v1, Lcom/sec/chaton/ac;
    0046: invoke-virtual {v6, v9, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    0049: invoke-virtual {v4, v9}, Landroid/widget/TabHost;->newTabSpec(Ljava/lang/String;)Landroid/widget/TabHost$TabSpec;
    004c: move-result-object v1
    004d: invoke-virtual {v1, v0}, Landroid/widget/TabHost$TabSpec;->setIndicator(Landroid/view/View;)Landroid/widget/TabHost$TabSpec;
    0050: move-result-object v0
    0051: invoke-virtual {v0, v7}, Landroid/widget/TabHost$TabSpec;->setContent(I)Landroid/widget/TabHost$TabSpec;
    0054: move-result-object v0
    0055: invoke-virtual {v4, v0}, Landroid/widget/TabHost;->addTab(Landroid/widget/TabHost$TabSpec;)V
    0058: return-void
    0059: invoke-virtual {v3}, Landroid/support/v4/app/Fragment;->getFragmentManager()Landroid/support/v4/app/FragmentManager;
    005c: move-result-object v1
    005d: invoke-virtual {v1, v9}, Landroid/support/v4/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    0060: move-result-object v1
    0061: goto 0040

  [Direct Method] a(Landroid/widget/TabWidget;, Ljava/lang/String;, I) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-static {v0, v1, v2}, Lcom/sec/chaton/HomeTabFragment;->b(Landroid/widget/TabWidget;Ljava/lang/String;I)V
    0003: return-void

  [Direct Method] a(Lcom/sec/chaton/HomeTabFragment;, Landroid/database/Cursor;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/sec/chaton/HomeTabFragment;->a(Landroid/database/Cursor;)V
    0003: return-void

  [Direct Method] a(Lcom/sec/chaton/HomeTabFragment;) -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/HomeTabFragment;->n:Z
    0002: return v0

  [Direct Method] a(Lcom/sec/chaton/HomeTabFragment;, Z) -> Z
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/HomeTabFragment;->j:Z
    0002: return v1

  [Direct Method] b(Lcom/sec/chaton/HomeTabFragment;, I) -> I
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/HomeTabFragment;->h:I
    0002: return v1

  [Direct Method] b(Lcom/sec/chaton/HomeTabFragment;) -> Landroid/widget/TabWidget;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/HomeTabFragment;->c:Landroid/widget/TabWidget;
    0002: return-object v0

  [Direct Method] b() -> V
    // registers=6, ins=1, outs=3, insns_size=87
    0000: const/4 v4, 0
    0001: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0004: move-result-object v0
    0005: const-string v1, 'new_post_on_count'
    0007: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    000a: move-result-object v2
    000b: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/Integer;)Ljava/lang/Integer;
    000e: move-result-object v0
    000f: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    0012: move-result v1
    0013: iget v0, v5.Lcom/sec/chaton/HomeTabFragment;->c:Landroid/widget/TabWidget;
    0015: const-string v2, 'My page'
    0017: invoke-virtual {v0, v2}, Landroid/widget/TabWidget;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;
    001a: move-result-object v0
    001b: if-nez v0, 001e
    001d: return-void
    001e: const v2, 2131232526 (0x7f08070e)
    0021: invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0024: move-result-object v0
    0025: check-cast v0, Landroid/widget/TextView;
    0027: new-instance v2, Ljava/lang/StringBuilder;
    0029: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    002c: const-string v3, 'My page totalNumBadge : '
    002e: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0031: move-result-object v2
    0032: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0035: move-result-object v2
    0036: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0039: move-result-object v2
    003a: invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    003d: move-result-object v3
    003e: invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0041: move-result-object v3
    0042: invoke-static {v2, v3}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0045: if-lez v1, 0051
    0047: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setVisibility(I)V
    004a: invoke-static {v0, v1}, Lcom/sec/chaton/util/cb;->a(Landroid/widget/TextView;I)V
    004d: invoke-virtual {v0}, Landroid/widget/TextView;->invalidate()V
    0050: goto 001d
    0051: const/16 v1, 8 (0x8)
    0053: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V
    0056: goto 004d

  [Direct Method] b(Landroid/widget/TabWidget;, Ljava/lang/String;, I) -> V
    // registers=7, ins=3, outs=3, insns_size=147
    0000: const/4 v3, 0
    0001: invoke-virtual {v4, v5}, Landroid/widget/TabWidget;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;
    0004: move-result-object v0
    0005: const v1, 2131232526 (0x7f08070e)
    0008: invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    000b: move-result-object v0
    000c: check-cast v0, Landroid/widget/TextView;
    000e: if-lez v6, 008d
    0010: invoke-virtual {v0, v3}, Landroid/widget/TextView;->setVisibility(I)V
    0013: const/16 v1, 100 (0x64)
    0015: if-lt v6, v1, 0064
    0017: const v1, 2131493008 (0x7f0c0090)
    001a: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V
    001d: invoke-virtual {v0}, Landroid/widget/TextView;->getResources()Landroid/content/res/Resources;
    0020: move-result-object v1
    0021: const v2, 2131427440 (0x7f0b0070)
    0024: invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimension(I)F
    0027: move-result v1
    0028: invoke-virtual {v0, v3, v1}, Landroid/widget/TextView;->setTextSize(IF)V
    002b: new-instance v0, Ljava/lang/StringBuilder;
    002d: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0030: const-string v1, 'badgeType : '
    0032: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0035: move-result-object v0
    0036: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0039: move-result-object v0
    003a: const-string v1, ', count : '
    003c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003f: move-result-object v0
    0040: invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0043: move-result-object v0
    0044: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0047: move-result-object v0
    0048: const-string v1, 'HomeTabFragment'
    004a: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    004d: const-string v0, 'Buddies'
    004f: if-ne v5, v0, 0063
    0051: new-instance v0, Landroid/content/Intent;
    0053: const-string v1, 'buddy_tab_badge_update'
    0055: invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    0058: invoke-static {}, Lcom/sec/chaton/global/GlobalApplication;->b()Landroid/content/Context;
    005b: move-result-object v1
    005c: invoke-static {v1}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    005f: move-result-object v1
    0060: invoke-virtual {v1, v0}, Landroid/support/v4/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z
    0063: return-void
    0064: invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;
    0067: move-result-object v1
    0068: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    006b: const/16 v1, 10 (0xa)
    006d: if-lt v6, v1, 007e
    006f: invoke-virtual {v0}, Landroid/widget/TextView;->getResources()Landroid/content/res/Resources;
    0072: move-result-object v1
    0073: const v2, 2131427441 (0x7f0b0071)
    0076: invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimension(I)F
    0079: move-result v1
    007a: invoke-virtual {v0, v3, v1}, Landroid/widget/TextView;->setTextSize(IF)V
    007d: goto 002b
    007e: invoke-virtual {v0}, Landroid/widget/TextView;->getResources()Landroid/content/res/Resources;
    0081: move-result-object v1
    0082: const v2, 2131427442 (0x7f0b0072)
    0085: invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimension(I)F
    0088: move-result v1
    0089: invoke-virtual {v0, v3, v1}, Landroid/widget/TextView;->setTextSize(IF)V
    008c: goto 002b
    008d: const/16 v1, 8 (0x8)
    008f: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V
    0092: goto 0063

  [Direct Method] b(Lcom/sec/chaton/HomeTabFragment;, Z) -> Z
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/HomeTabFragment;->k:Z
    0002: return v1

  [Direct Method] c(Lcom/sec/chaton/HomeTabFragment;) -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/HomeTabFragment;->g:I
    0002: return v0

  [Direct Method] c() -> V
    // registers=4, ins=1, outs=2, insns_size=43
    0000: invoke-static {}, Lcom/sec/chaton/MoreFragment;->e()I
    0003: move-result v1
    0004: iget v0, v3.Lcom/sec/chaton/HomeTabFragment;->c:Landroid/widget/TabWidget;
    0006: const-string v2, 'More'
    0008: invoke-virtual {v0, v2}, Landroid/widget/TabWidget;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;
    000b: move-result-object v0
    000c: if-nez v0, 000f
    000e: return-void
    000f: const v2, 2131232526 (0x7f08070e)
    0012: invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0015: move-result-object v0
    0016: check-cast v0, Landroid/widget/TextView;
    0018: if-lez v1, 0025
    001a: const/4 v2, 0
    001b: invoke-virtual {v0, v2}, Landroid/widget/TextView;->setVisibility(I)V
    001e: invoke-static {v0, v1}, Lcom/sec/chaton/util/cb;->a(Landroid/widget/TextView;I)V
    0021: invoke-virtual {v0}, Landroid/widget/TextView;->invalidate()V
    0024: goto 000e
    0025: const/16 v1, 8 (0x8)
    0027: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V
    002a: goto 0021

  [Direct Method] c(Lcom/sec/chaton/HomeTabFragment;, Z) -> Z
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/HomeTabFragment;->l:Z
    0002: return v1

  [Direct Method] d(Lcom/sec/chaton/HomeTabFragment;) -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/HomeTabFragment;->h:I
    0002: return v0

  [Direct Method] d() -> V
    // registers=10, ins=1, outs=8, insns_size=92
    0000: const/4 v8, 0
    0001: const/4 v2, 0
    0002: new-instance v0, Ljava/lang/StringBuilder;
    0004: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0007: const-string v1, 'badge need : '
    0009: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000c: move-result-object v0
    000d: iget v1, v9.Lcom/sec/chaton/HomeTabFragment;->j:Z
    000f: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0012: move-result-object v0
    0013: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0016: move-result-object v0
    0017: const-string v1, 'HomeTabFragment'
    0019: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->c(Ljava/lang/String;Ljava/lang/String;)V
    001c: iget v0, v9.Lcom/sec/chaton/HomeTabFragment;->j:Z
    001e: if-eqz v0, 005b
    0020: iput v8, v9.Lcom/sec/chaton/HomeTabFragment;->j:Z
    0022: iget v0, v9.Lcom/sec/chaton/HomeTabFragment;->k:Z
    0024: if-eqz v0, 0035
    0026: iput v8, v9.Lcom/sec/chaton/HomeTabFragment;->k:Z
    0028: iget v0, v9.Lcom/sec/chaton/HomeTabFragment;->i:Lcom/sec/chaton/e/a/r;
    002a: const/4 v1, 2
    002b: sget v3, Lcom/sec/chaton/e/m;->a:Landroid/net/Uri;
    002d: const-string v5, 'inbox_unread_count > 0'
    002f: move(op=07) v4, v2
    0030: move(op=07) v6, v2
    0031: move(op=07) v7, v2
    0032: invoke-virtual/range {v0..v7}, Lcom/sec/chaton/e/a/r;->startQuery(ILjava/lang/Object;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
    0035: iget v0, v9.Lcom/sec/chaton/HomeTabFragment;->l:Z
    0037: if-eqz v0, 0048
    0039: iput v8, v9.Lcom/sec/chaton/HomeTabFragment;->l:Z
    003b: iget v0, v9.Lcom/sec/chaton/HomeTabFragment;->i:Lcom/sec/chaton/e/a/r;
    003d: const/4 v1, 1
    003e: sget v3, Lcom/sec/chaton/e/f;->a:Landroid/net/Uri;
    0040: const-string v5, "buddy_is_new='Y'"
    0042: move(op=07) v4, v2
    0043: move(op=07) v6, v2
    0044: move(op=07) v7, v2
    0045: invoke-virtual/range {v0..v7}, Lcom/sec/chaton/e/a/r;->startQuery(ILjava/lang/Object;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
    0048: iget v0, v9.Lcom/sec/chaton/HomeTabFragment;->m:Z
    004a: if-eqz v0, 005b
    004c: iput v8, v9.Lcom/sec/chaton/HomeTabFragment;->m:Z
    004e: iget v0, v9.Lcom/sec/chaton/HomeTabFragment;->i:Lcom/sec/chaton/e/a/r;
    0050: const/4 v1, 3
    0051: sget v3, Lcom/sec/chaton/e/z;->a:Landroid/net/Uri;
    0053: const-string v5, "isNew='Y'"
    0055: move(op=07) v4, v2
    0056: move(op=07) v6, v2
    0057: move(op=07) v7, v2
    0058: invoke-virtual/range {v0..v7}, Lcom/sec/chaton/e/a/r;->startQuery(ILjava/lang/Object;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V
    005b: return-void

  [Direct Method] d(Lcom/sec/chaton/HomeTabFragment;, Z) -> Z
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/sec/chaton/HomeTabFragment;->m:Z
    0002: return v1

  [Direct Method] e(Lcom/sec/chaton/HomeTabFragment;) -> Lcom/sec/chaton/e/a/r;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/sec/chaton/HomeTabFragment;->i:Lcom/sec/chaton/e/a/r;
    0002: return-object v0

  [Direct Method] f(Lcom/sec/chaton/HomeTabFragment;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/HomeTabFragment;->b()V
    0003: return-void

  [Direct Method] g(Lcom/sec/chaton/HomeTabFragment;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/HomeTabFragment;->c()V
    0003: return-void

  [Virtual Method] a() -> I
    // registers=2, ins=1, outs=1, insns_size=13
    0000: iget v0, v1.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    0002: if-eqz v0, 000b
    0004: iget v0, v1.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    0006: invoke-virtual {v0}, Landroid/widget/TabHost;->getCurrentTab()I
    0009: move-result v0
    000a: return v0
    000b: const/4 v0, -1
    000c: goto 000a

  [Virtual Method] onActivityCreated(Landroid/os/Bundle;) -> V
    // registers=4, ins=2, outs=2, insns_size=52
    0000: invoke-super {v2, v3}, Landroid/support/v4/app/Fragment;->onActivityCreated(Landroid/os/Bundle;)V
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0008: const-string v1, 'onActivityCrated, MemoryAddress : '
    000a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000d: move-result-object v0
    000e: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0011: move-result-object v0
    0012: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0015: move-result-object v0
    0016: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0019: move-result-object v1
    001a: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    001d: move-result-object v1
    001e: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0021: if-eqz v3, 0033
    0023: const-string v0, 'current_position'
    0025: invoke-virtual {v3, v0}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z
    0028: move-result v0
    0029: if-eqz v0, 0033
    002b: const-string v0, 'current_position'
    002d: invoke-virtual {v3, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    0030: move-result-object v0
    0031: iput v0, v2.Lcom/sec/chaton/HomeTabFragment;->f:Ljava/lang/String;
    0033: return-void

  [Virtual Method] onAttach(Landroid/app/Activity;) -> V
    // registers=4, ins=2, outs=2, insns_size=34
    0000: invoke-super {v2, v3}, Landroid/support/v4/app/Fragment;->onAttach(Landroid/app/Activity;)V
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0008: const-string v1, 'onAttach, MemoryAddress : '
    000a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000d: move-result-object v0
    000e: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0011: move-result-object v0
    0012: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0015: move-result-object v0
    0016: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0019: move-result-object v1
    001a: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    001d: move-result-object v1
    001e: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0021: return-void

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=6, ins=2, outs=4, insns_size=117
    0000: const/4 v3, 1
    0001: invoke-super {v4, v5}, Landroid/support/v4/app/Fragment;->onCreate(Landroid/os/Bundle;)V
    0004: new-instance v0, Ljava/lang/StringBuilder;
    0006: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0009: const-string v1, 'onCreate, MemoryAddress : '
    000b: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000e: move-result-object v0
    000f: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0012: move-result-object v0
    0013: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0016: move-result-object v0
    0017: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    001a: move-result-object v1
    001b: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    001e: move-result-object v1
    001f: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0022: new-instance v0, Lcom/sec/chaton/e/a/r;
    0024: invoke-virtual {v4}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0027: move-result-object v1
    0028: invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getContentResolver()Landroid/content/ContentResolver;
    002b: move-result-object v1
    002c: iget v2, v4.Lcom/sec/chaton/HomeTabFragment;->a:Lcom/sec/chaton/e/a/s;
    002e: invoke-direct {v0, v1, v2}, Lcom/sec/chaton/e/a/r;-><init>(Landroid/content/ContentResolver;Lcom/sec/chaton/e/a/s;)V
    0031: iput v0, v4.Lcom/sec/chaton/HomeTabFragment;->i:Lcom/sec/chaton/e/a/r;
    0033: new-instance v0, Ljava/util/HashMap;
    0035: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    0038: iput v0, v4.Lcom/sec/chaton/HomeTabFragment;->d:Ljava/util/HashMap;
    003a: invoke-virtual {v4}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    003d: move-result-object v0
    003e: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getContentResolver()Landroid/content/ContentResolver;
    0041: move-result-object v0
    0042: sget v1, Lcom/sec/chaton/e/m;->a:Landroid/net/Uri;
    0044: iget v2, v4.Lcom/sec/chaton/HomeTabFragment;->q:Landroid/database/ContentObserver;
    0046: invoke-virtual {v0, v1, v3, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V
    0049: invoke-virtual {v4}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    004c: move-result-object v0
    004d: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getContentResolver()Landroid/content/ContentResolver;
    0050: move-result-object v0
    0051: sget v1, Lcom/sec/chaton/e/f;->a:Landroid/net/Uri;
    0053: iget v2, v4.Lcom/sec/chaton/HomeTabFragment;->o:Landroid/database/ContentObserver;
    0055: invoke-virtual {v0, v1, v3, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V
    0058: invoke-virtual {v4}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    005b: move-result-object v0
    005c: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getContentResolver()Landroid/content/ContentResolver;
    005f: move-result-object v0
    0060: sget v1, Lcom/sec/chaton/e/z;->a:Landroid/net/Uri;
    0062: iget v2, v4.Lcom/sec/chaton/HomeTabFragment;->p:Landroid/database/ContentObserver;
    0064: invoke-virtual {v0, v1, v3, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V
    0067: const-string v0, 'onCreate : regist Observer'
    0069: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    006c: move-result-object v1
    006d: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0070: move-result-object v1
    0071: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0074: return-void

  [Virtual Method] onCreateView(Landroid/view/LayoutInflater;, Landroid/view/ViewGroup;, Landroid/os/Bundle;) -> Landroid/view/View;
    // registers=15, ins=4, outs=8, insns_size=202
    0000: const/4 v8, 0
    0001: const/4 v10, 1
    0002: new-instance v0, Ljava/lang/StringBuilder;
    0004: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0007: const-string v1, 'onCreateView, MemoryAddress : '
    0009: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000c: move-result-object v0
    000d: invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0010: move-result-object v0
    0011: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0014: move-result-object v0
    0015: invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0018: move-result-object v1
    0019: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    001c: move-result-object v1
    001d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0020: const v0, 2130903223 (0x7f0300b7)
    0023: const/4 v1, 0
    0024: invoke-virtual {v12, v0, v13, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;
    0027: move-result-object v9
    0028: const v0, 16908306 (0x1020012)
    002b: invoke-virtual {v9, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    002e: move-result-object v0
    002f: check-cast v0, Landroid/widget/TabHost;
    0031: iput v0, v11.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    0033: const v0, 16908307 (0x1020013)
    0036: invoke-virtual {v9, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0039: move-result-object v0
    003a: check-cast v0, Landroid/widget/TabWidget;
    003c: iput v0, v11.Lcom/sec/chaton/HomeTabFragment;->c:Landroid/widget/TabWidget;
    003e: iget v0, v11.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    0040: invoke-virtual {v0}, Landroid/widget/TabHost;->setup()V
    0043: iget v0, v11.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    0045: invoke-virtual {v0, v11}, Landroid/widget/TabHost;->setOnTabChangedListener(Landroid/widget/TabHost$OnTabChangeListener;)V
    0048: iget v1, v11.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    004a: iget v2, v11.Lcom/sec/chaton/HomeTabFragment;->c:Landroid/widget/TabWidget;
    004c: iget v3, v11.Lcom/sec/chaton/HomeTabFragment;->d:Ljava/util/HashMap;
    004e: const v4, 2131230722 (0x7f080002)
    0051: const v5, 2130903430 (0x7f030186)
    0054: const-string v6, 'Buddies'
    0056: if-nez v14, 00c2
    0058: new-instance v7, Lcom/sec/chaton/buddy/BuddyFragment;
    005a: invoke-direct {v7}, Lcom/sec/chaton/buddy/BuddyFragment;-><init>()V
    005d: move(op=07) v0, v11
    005e: invoke-static/range {v0..v7}, Lcom/sec/chaton/HomeTabFragment;->a(Landroid/support/v4/app/Fragment;Landroid/widget/TabHost;Landroid/widget/TabWidget;Ljava/util/HashMap;IILjava/lang/String;Landroid/support/v4/app/Fragment;)V
    0061: iget v1, v11.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    0063: iget v2, v11.Lcom/sec/chaton/HomeTabFragment;->c:Landroid/widget/TabWidget;
    0065: iget v3, v11.Lcom/sec/chaton/HomeTabFragment;->d:Ljava/util/HashMap;
    0067: const v4, 2131230723 (0x7f080003)
    006a: const v5, 2130903431 (0x7f030187)
    006d: const-string v6, 'Chat'
    006f: if-nez v14, 00c4
    0071: new-instance v7, Lcom/sec/chaton/msgbox/MsgboxFragment;
    0073: invoke-direct {v7}, Lcom/sec/chaton/msgbox/MsgboxFragment;-><init>()V
    0076: move(op=07) v0, v11
    0077: invoke-static/range {v0..v7}, Lcom/sec/chaton/HomeTabFragment;->a(Landroid/support/v4/app/Fragment;Landroid/widget/TabHost;Landroid/widget/TabWidget;Ljava/util/HashMap;IILjava/lang/String;Landroid/support/v4/app/Fragment;)V
    007a: iget v1, v11.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    007c: iget v2, v11.Lcom/sec/chaton/HomeTabFragment;->c:Landroid/widget/TabWidget;
    007e: iget v3, v11.Lcom/sec/chaton/HomeTabFragment;->d:Ljava/util/HashMap;
    0080: const v4, 2131230724 (0x7f080004)
    0083: const v5, 2130903433 (0x7f030189)
    0086: const-string v6, 'My page'
    0088: if-nez v14, 00c6
    008a: new-instance v7, Lcom/sec/chaton/userprofile/MyPageFragment;
    008c: invoke-direct {v7}, Lcom/sec/chaton/userprofile/MyPageFragment;-><init>()V
    008f: move(op=07) v0, v11
    0090: invoke-static/range {v0..v7}, Lcom/sec/chaton/HomeTabFragment;->a(Landroid/support/v4/app/Fragment;Landroid/widget/TabHost;Landroid/widget/TabWidget;Ljava/util/HashMap;IILjava/lang/String;Landroid/support/v4/app/Fragment;)V
    0093: iget v1, v11.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    0095: iget v2, v11.Lcom/sec/chaton/HomeTabFragment;->c:Landroid/widget/TabWidget;
    0097: iget v3, v11.Lcom/sec/chaton/HomeTabFragment;->d:Ljava/util/HashMap;
    0099: const v4, 2131230726 (0x7f080006)
    009c: const v5, 2130903432 (0x7f030188)
    009f: const-string v6, 'More'
    00a1: if-nez v14, 00c8
    00a3: new-instance v7, Lcom/sec/chaton/MoreFragment;
    00a5: invoke-direct {v7}, Lcom/sec/chaton/MoreFragment;-><init>()V
    00a8: move(op=07) v0, v11
    00a9: invoke-static/range {v0..v7}, Lcom/sec/chaton/HomeTabFragment;->a(Landroid/support/v4/app/Fragment;Landroid/widget/TabHost;Landroid/widget/TabWidget;Ljava/util/HashMap;IILjava/lang/String;Landroid/support/v4/app/Fragment;)V
    00ac: iput v10, v11.Lcom/sec/chaton/HomeTabFragment;->j:Z
    00ae: iput v10, v11.Lcom/sec/chaton/HomeTabFragment;->k:Z
    00b0: iput v10, v11.Lcom/sec/chaton/HomeTabFragment;->l:Z
    00b2: iput v10, v11.Lcom/sec/chaton/HomeTabFragment;->m:Z
    00b4: const-string v0, 'onCreateView : need set true'
    00b6: invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    00b9: move-result-object v1
    00ba: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    00bd: move-result-object v1
    00be: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    00c1: return-object v9
    00c2: move(op=07) v7, v8
    00c3: goto 005d
    00c4: move(op=07) v7, v8
    00c5: goto 0076
    00c6: move(op=07) v7, v8
    00c7: goto 008f
    00c8: move(op=07) v7, v8
    00c9: goto 00a8

  [Virtual Method] onDestroy() -> V
    // registers=3, ins=1, outs=2, insns_size=56
    0000: invoke-super {v2}, Landroid/support/v4/app/Fragment;->onDestroy()V
    0003: invoke-virtual {v2}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0006: move-result-object v0
    0007: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getContentResolver()Landroid/content/ContentResolver;
    000a: move-result-object v0
    000b: iget v1, v2.Lcom/sec/chaton/HomeTabFragment;->q:Landroid/database/ContentObserver;
    000d: invoke-virtual {v0, v1}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V
    0010: invoke-virtual {v2}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0013: move-result-object v0
    0014: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getContentResolver()Landroid/content/ContentResolver;
    0017: move-result-object v0
    0018: iget v1, v2.Lcom/sec/chaton/HomeTabFragment;->o:Landroid/database/ContentObserver;
    001a: invoke-virtual {v0, v1}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V
    001d: invoke-virtual {v2}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0020: move-result-object v0
    0021: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getContentResolver()Landroid/content/ContentResolver;
    0024: move-result-object v0
    0025: iget v1, v2.Lcom/sec/chaton/HomeTabFragment;->p:Landroid/database/ContentObserver;
    0027: invoke-virtual {v0, v1}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V
    002a: const-string v0, 'onDestroy : unregist observer'
    002c: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    002f: move-result-object v1
    0030: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0033: move-result-object v1
    0034: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0037: return-void

  [Virtual Method] onPause() -> V
    // registers=3, ins=1, outs=2, insns_size=70
    0000: invoke-super {v2}, Landroid/support/v4/app/Fragment;->onPause()V
    0003: const/4 v0, 1
    0004: iput v0, v2.Lcom/sec/chaton/HomeTabFragment;->n:Z
    0006: new-instance v0, Ljava/lang/StringBuilder;
    0008: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v1, 'onPause, MemoryAddress : '
    000d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v0
    0011: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0014: move-result-object v0
    0015: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0018: move-result-object v0
    0019: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    001c: move-result-object v1
    001d: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0020: move-result-object v1
    0021: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0024: invoke-virtual {v2}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0027: move-result-object v0
    0028: invoke-static {v0}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    002b: move-result-object v0
    002c: iget v1, v2.Lcom/sec/chaton/HomeTabFragment;->r:Landroid/content/BroadcastReceiver;
    002e: invoke-virtual {v0, v1}, Landroid/support/v4/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    0031: invoke-virtual {v2}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0034: move-result-object v0
    0035: invoke-static {v0}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    0038: move-result-object v0
    0039: iget v1, v2.Lcom/sec/chaton/HomeTabFragment;->s:Landroid/content/BroadcastReceiver;
    003b: invoke-virtual {v0, v1}, Landroid/support/v4/content/LocalBroadcastManager;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    003e: const-string v0, 'preTab_position'
    0040: iget v1, v2.Lcom/sec/chaton/HomeTabFragment;->e:Ljava/lang/String;
    0042: invoke-static {v0, v1}, Lcom/sec/chaton/util/r;->a(Ljava/lang/String;Ljava/lang/String;)V
    0045: return-void

  [Virtual Method] onResume() -> V
    // registers=4, ins=1, outs=3, insns_size=214
    0000: invoke-super {v3}, Landroid/support/v4/app/Fragment;->onResume()V
    0003: const/4 v0, 0
    0004: iput v0, v3.Lcom/sec/chaton/HomeTabFragment;->n:Z
    0006: new-instance v0, Ljava/lang/StringBuilder;
    0008: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v1, 'onResume, MemoryAddress : '
    000d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v0
    0011: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0014: move-result-object v0
    0015: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0018: move-result-object v0
    0019: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    001c: move-result-object v1
    001d: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0020: move-result-object v1
    0021: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->e(Ljava/lang/String;Ljava/lang/String;)V
    0024: iget v0, v3.Lcom/sec/chaton/HomeTabFragment;->f:Ljava/lang/String;
    0026: invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z
    0029: move-result v0
    002a: if-nez v0, 0036
    002c: iget v0, v3.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    002e: iget v1, v3.Lcom/sec/chaton/HomeTabFragment;->f:Ljava/lang/String;
    0030: invoke-virtual {v0, v1}, Landroid/widget/TabHost;->setCurrentTabByTag(Ljava/lang/String;)V
    0033: const/4 v0, 0
    0034: iput v0, v3.Lcom/sec/chaton/HomeTabFragment;->f:Ljava/lang/String;
    0036: invoke-static {}, Lcom/sec/chaton/util/r;->a()Lcom/sec/chaton/util/s;
    0039: move-result-object v0
    003a: const-string v1, 'preTab_position'
    003c: const-string v2, ''
    003e: invoke-virtual {v0, v1, v2}, Lcom/sec/chaton/util/s;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    0041: move-result-object v0
    0042: invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z
    0045: move-result v1
    0046: if-nez v1, 004d
    0048: iget v1, v3.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    004a: invoke-virtual {v1, v0}, Landroid/widget/TabHost;->setCurrentTabByTag(Ljava/lang/String;)V
    004d: invoke-virtual {v3}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0050: move-result-object v0
    0051: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getIntent()Landroid/content/Intent;
    0054: move-result-object v0
    0055: if-eqz v0, 0090
    0057: sget v1, Lcom/sec/chaton/TabActivity;->a:Ljava/lang/String;
    0059: invoke-virtual {v0, v1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;
    005c: move-result-object v0
    005d: check-cast v0, Landroid/content/Intent;
    005f: if-eqz v0, 0090
    0061: invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    0064: move-result-object v1
    0065: if-eqz v1, 00c8
    0067: const-string v2, 'callChatTab'
    0069: invoke-virtual {v1, v2}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z
    006c: move-result v2
    006d: if-eqz v2, 00c8
    006f: const-string v2, 'callChatTab'
    0071: invoke-virtual {v1, v2}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;)Z
    0074: move-result v1
    0075: if-eqz v1, 00c8
    0077: const-string v1, 'callChatTab'
    0079: invoke-virtual {v0, v1}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V
    007c: invoke-virtual {v3}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    007f: move-result-object v1
    0080: invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getIntent()Landroid/content/Intent;
    0083: move-result-object v1
    0084: sget v2, Lcom/sec/chaton/TabActivity;->a:Ljava/lang/String;
    0086: invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    0089: iget v0, v3.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    008b: const-string v1, 'Chat'
    008d: invoke-virtual {v0, v1}, Landroid/widget/TabHost;->setCurrentTabByTag(Ljava/lang/String;)V
    0090: invoke-direct {v3}, Lcom/sec/chaton/HomeTabFragment;->d()V
    0093: invoke-direct {v3}, Lcom/sec/chaton/HomeTabFragment;->b()V
    0096: new-instance v0, Landroid/content/IntentFilter;
    0098: invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V
    009b: const-string v1, 'mypage_badge_update'
    009d: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    00a0: invoke-virtual {v3}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    00a3: move-result-object v1
    00a4: invoke-static {v1}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    00a7: move-result-object v1
    00a8: iget v2, v3.Lcom/sec/chaton/HomeTabFragment;->r:Landroid/content/BroadcastReceiver;
    00aa: invoke-virtual {v1, v2, v0}, Landroid/support/v4/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    00ad: invoke-direct {v3}, Lcom/sec/chaton/HomeTabFragment;->c()V
    00b0: new-instance v0, Landroid/content/IntentFilter;
    00b2: invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V
    00b5: const-string v1, 'more_tab_badge_update'
    00b7: invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V
    00ba: invoke-virtual {v3}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    00bd: move-result-object v1
    00be: invoke-static {v1}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;
    00c1: move-result-object v1
    00c2: iget v2, v3.Lcom/sec/chaton/HomeTabFragment;->s:Landroid/content/BroadcastReceiver;
    00c4: invoke-virtual {v1, v2, v0}, Landroid/support/v4/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V
    00c7: return-void
    00c8: invoke-static {}, Lcom/sec/chaton/settings/PhoneSettingFragment2;->c()Z
    00cb: move-result v0
    00cc: if-eqz v0, 0090
    00ce: iget v0, v3.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    00d0: const-string v1, 'More'
    00d2: invoke-virtual {v0, v1}, Landroid/widget/TabHost;->setCurrentTabByTag(Ljava/lang/String;)V
    00d5: goto 0090

  [Virtual Method] onSaveInstanceState(Landroid/os/Bundle;) -> V
    // registers=4, ins=2, outs=3, insns_size=15
    0000: invoke-super {v2, v3}, Landroid/support/v4/app/Fragment;->onSaveInstanceState(Landroid/os/Bundle;)V
    0003: const-string v0, 'current_position'
    0005: iget v1, v2.Lcom/sec/chaton/HomeTabFragment;->b:Landroid/widget/TabHost;
    0007: invoke-virtual {v1}, Landroid/widget/TabHost;->getCurrentTabTag()Ljava/lang/String;
    000a: move-result-object v1
    000b: invoke-virtual {v3, v0, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    000e: return-void

  [Virtual Method] onTabChanged(Ljava/lang/String;) -> V
    // registers=4, ins=2, outs=2, insns_size=62
    0000: iget v0, v2.Lcom/sec/chaton/HomeTabFragment;->e:Ljava/lang/String;
    0002: if-eqz v0, 001b
    0004: iget v0, v2.Lcom/sec/chaton/HomeTabFragment;->d:Ljava/util/HashMap;
    0006: iget v1, v2.Lcom/sec/chaton/HomeTabFragment;->e:Ljava/lang/String;
    0008: invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z
    000b: move-result v0
    000c: if-eqz v0, 001b
    000e: iget v0, v2.Lcom/sec/chaton/HomeTabFragment;->d:Ljava/util/HashMap;
    0010: iget v1, v2.Lcom/sec/chaton/HomeTabFragment;->e:Ljava/lang/String;
    0012: invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0015: move-result-object v0
    0016: check-cast v0, Lcom/sec/chaton/ac;
    0018: invoke-interface {v0}, Lcom/sec/chaton/ac;->b()V
    001b: invoke-virtual {v2}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    001e: move-result-object v0
    001f: if-eqz v0, 0028
    0021: invoke-virtual {v2}, Lcom/sec/chaton/HomeTabFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0024: move-result-object v0
    0025: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->closeOptionsMenu()V
    0028: iget v0, v2.Lcom/sec/chaton/HomeTabFragment;->d:Ljava/util/HashMap;
    002a: invoke-virtual {v0, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z
    002d: move-result v0
    002e: if-eqz v0, 003b
    0030: iget v0, v2.Lcom/sec/chaton/HomeTabFragment;->d:Ljava/util/HashMap;
    0032: invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0035: move-result-object v0
    0036: check-cast v0, Lcom/sec/chaton/ac;
    0038: invoke-interface {v0}, Lcom/sec/chaton/ac;->a()V
    003b: iput v3, v2.Lcom/sec/chaton/HomeTabFragment;->e:Ljava/lang/String;
    003d: return-void