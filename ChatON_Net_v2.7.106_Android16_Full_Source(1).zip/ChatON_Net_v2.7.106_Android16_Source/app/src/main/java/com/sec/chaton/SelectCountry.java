=== CLASS Lcom/sec/chaton/SelectCountry; (Source: SelectCountry.java) ===
  Super: Lcom/sec/chaton/base/BaseSinglePaneActivity;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/base/BaseSinglePaneActivity;-><init>()V
    0003: return-void

  [Virtual Method] a() -> Landroid/support/v4/app/Fragment;
    // registers=2, ins=1, outs=1, insns_size=6
    0000: new-instance v0, Lcom/sec/chaton/SelectCountry$RegisteFragment;
    0002: invoke-direct {v0}, Lcom/sec/chaton/SelectCountry$RegisteFragment;-><init>()V
    0005: return-object v0

  [Virtual Method] onWindowFocusChanged(Z) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-super {v0, v1}, Lcom/sec/chaton/base/BaseSinglePaneActivity;->onWindowFocusChanged(Z)V
    0003: return-void