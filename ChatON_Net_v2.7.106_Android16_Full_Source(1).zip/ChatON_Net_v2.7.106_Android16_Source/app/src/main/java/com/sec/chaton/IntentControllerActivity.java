=== CLASS Lcom/sec/chaton/IntentControllerActivity; (Source: IntentControllerActivity.java) ===
  Super: Lcom/sec/chaton/base/BaseActivity;
  [Static Field] a: Ljava/lang/Boolean;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=8
    0000: const/4 v0, 0
    0001: invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0004: move-result-object v0
    0005: sput v0, Lcom/sec/chaton/IntentControllerActivity;->a:Ljava/lang/Boolean;
    0007: return-void

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Lcom/sec/chaton/base/BaseActivity;-><init>()V
    0003: return-void

  [Direct Method] a(Landroid/content/Context;) -> Landroid/content/Intent;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-static {v1, v0}, Lcom/sec/chaton/IntentControllerActivity;->a(Landroid/content/Context;Z)Landroid/content/Intent;
    0004: move-result-object v0
    0005: return-object v0

  [Direct Method] a(Landroid/content/Context;, Z) -> Landroid/content/Intent;
    // registers=4, ins=2, outs=3, insns_size=13
    0000: new-instance v0, Landroid/content/Intent;
    0002: const-class v1, Lcom/sec/chaton/IntentControllerActivity;
    0004: invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0007: const-string v1, 'skipSplash'
    0009: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;
    000c: return-object v0

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=5, ins=2, outs=3, insns_size=86
    0000: const/4 v2, 0
    0001: invoke-super {v3, v4}, Lcom/sec/chaton/base/BaseActivity;->onCreate(Landroid/os/Bundle;)V
    0004: sget v0, Lcom/sec/chaton/IntentControllerActivity;->a:Ljava/lang/Boolean;
    0006: invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z
    0009: move-result v0
    000a: if-eqz v0, 0016
    000c: invoke-virtual {v3}, Lcom/sec/chaton/IntentControllerActivity;->isTaskRoot()Z
    000f: move-result v0
    0010: if-nez v0, 0016
    0012: invoke-virtual {v3}, Lcom/sec/chaton/IntentControllerActivity;->finish()V
    0015: return-void
    0016: invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0019: move-result-object v0
    001a: sput v0, Lcom/sec/chaton/IntentControllerActivity;->a:Ljava/lang/Boolean;
    001c: invoke-virtual {v3}, Lcom/sec/chaton/IntentControllerActivity;->getIntent()Landroid/content/Intent;
    001f: move-result-object v0
    0020: const/high16 v1, 1048576 (0x100000)
    0022: invoke-static {v0, v1}, Lcom/sec/common/b/j;->a(Landroid/content/Intent;I)Z
    0025: move-result v1
    0026: if-eqz v1, 0048
    0028: invoke-static {v3}, Lcom/sec/chaton/HomeActivity;->a(Landroid/content/Context;)Landroid/content/Intent;
    002b: move-result-object v0
    002c: const-string v1, 'android.intent.action.MAIN'
    002e: invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;
    0031: const-string v1, 'android.intent.category.LAUNCHER'
    0033: invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;
    0036: invoke-virtual {v3}, Lcom/sec/chaton/IntentControllerActivity;->isTaskRoot()Z
    0039: move-result v1
    003a: if-nez v1, 0041
    003c: const/high16 v1, 270532608 (0x10200000)
    003e: invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;
    0041: invoke-virtual {v3, v0}, Lcom/sec/chaton/IntentControllerActivity;->startActivity(Landroid/content/Intent;)V
    0044: invoke-virtual {v3}, Lcom/sec/chaton/IntentControllerActivity;->finish()V
    0047: goto 0015
    0048: const-string v1, 'skipSplash'
    004a: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z
    004d: move-result v1
    004e: invoke-static {v3, v0, v1}, Lcom/sec/chaton/HomeActivity;->a(Landroid/content/Context;Landroid/content/Intent;Z)Landroid/content/Intent;
    0051: move-result-object v0
    0052: invoke-virtual {v3, v0}, Lcom/sec/chaton/IntentControllerActivity;->startActivity(Landroid/content/Intent;)V
    0055: goto 0044