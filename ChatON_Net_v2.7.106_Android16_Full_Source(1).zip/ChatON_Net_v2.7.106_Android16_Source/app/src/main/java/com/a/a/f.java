=== CLASS Lcom/a/a/f; (Source: FacebookError.java) ===
  Super: Ljava/lang/Throwable;
  [Instance Field] a: I
  [Instance Field] b: Ljava/lang/String;

  [Direct Method] <init>(Ljava/lang/String;) -> V
    // registers=3, ins=2, outs=2, insns_size=7
    0000: invoke-direct {v1, v2}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V
    0003: const/4 v0, 0
    0004: iput v0, v1.Lcom/a/a/f;->a:I
    0006: return-void

  [Direct Method] <init>(Ljava/lang/String;, Ljava/lang/String;, I) -> V
    // registers=5, ins=4, outs=2, insns_size=11
    0000: invoke-direct {v1, v2}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V
    0003: const/4 v0, 0
    0004: iput v0, v1.Lcom/a/a/f;->a:I
    0006: iput v3, v1.Lcom/a/a/f;->b:Ljava/lang/String;
    0008: iput v4, v1.Lcom/a/a/f;->a:I
    000a: return-void