=== CLASS Lcom/a/a/g; (Source: FbDialog.java) ===
  Super: Landroid/app/Dialog;
  [Static Field] a: [F
  [Static Field] b: [F
  [Static Field] c: Landroid/widget/FrameLayout$LayoutParams;
  [Instance Field] d: Ljava/lang/String;
  [Instance Field] e: Lcom/a/a/e;
  [Instance Field] f: Lcom/sec/chaton/b/b;
  [Instance Field] g: Landroid/webkit/WebView;
  [Instance Field] h: Landroid/widget/LinearLayout;
  [Instance Field] i: Landroid/widget/TextView;

  [Direct Method] <clinit>() -> V
    // registers=3, ins=0, outs=3, insns_size=40
    0000: const/4 v2, 2
    0001: const/4 v1, -1
    0002: new-array v0, v2, [F
    0004: fill-array-data v0, +20 (-> 0018)
    0007: sput v0, Lcom/a/a/g;->a:[F
    0009: new-array v0, v2, [F
    000b: fill-array-data v0, +21 (-> 0020)
    000e: sput v0, Lcom/a/a/g;->b:[F
    0010: new-instance v0, Landroid/widget/FrameLayout$LayoutParams;
    0012: invoke-direct {v0, v1, v1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V
    0015: sput v0, Lcom/a/a/g;->c:Landroid/widget/FrameLayout$LayoutParams;
    0017: return-void
    0018: fill-array-data-payload width=4 size=2 data=0000f04100007042
    0020: fill-array-data-payload width=4 size=2 data=0000f04100007042

  [Direct Method] <init>(Landroid/content/Context;, Ljava/lang/String;, Lcom/a/a/e;) -> V
    // registers=5, ins=4, outs=3, insns_size=11
    0000: const v0, 2131623971 (0x7f0e0023)
    0003: invoke-direct {v1, v2, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V
    0006: iput v3, v1.Lcom/a/a/g;->d:Ljava/lang/String;
    0008: iput v4, v1.Lcom/a/a/g;->e:Lcom/a/a/e;
    000a: return-void

  [Direct Method] a(Lcom/a/a/g;) -> Lcom/a/a/e;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/a/a/g;->e:Lcom/a/a/e;
    0002: return-object v0

  [Direct Method] a() -> V
    // registers=7, ins=1, outs=5, insns_size=85
    0000: const/4 v5, 6
    0001: const/4 v4, 0
    0002: const/4 v3, 4
    0003: const/4 v0, 1
    0004: invoke-virtual {v6, v0}, Lcom/a/a/g;->requestWindowFeature(I)Z
    0007: invoke-virtual {v6}, Lcom/a/a/g;->getContext()Landroid/content/Context;
    000a: move-result-object v0
    000b: invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    000e: move-result-object v0
    000f: const v1, 2130838590 (0x7f02043e)
    0012: invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;
    0015: move-result-object v0
    0016: new-instance v1, Landroid/widget/TextView;
    0018: invoke-virtual {v6}, Lcom/a/a/g;->getContext()Landroid/content/Context;
    001b: move-result-object v2
    001c: invoke-direct {v1, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    001f: iput v1, v6.Lcom/a/a/g;->i:Landroid/widget/TextView;
    0021: iget v1, v6.Lcom/a/a/g;->i:Landroid/widget/TextView;
    0023: const v2, 2131493723 (0x7f0c035b)
    0026: invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(I)V
    0029: iget v1, v6.Lcom/a/a/g;->i:Landroid/widget/TextView;
    002b: const/4 v2, -1
    002c: invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V
    002f: iget v1, v6.Lcom/a/a/g;->i:Landroid/widget/TextView;
    0031: sget v2, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;
    0033: invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V
    0036: iget v1, v6.Lcom/a/a/g;->i:Landroid/widget/TextView;
    0038: const v2, -9599820 (-0x927b4c)
    003b: invoke-virtual {v1, v2}, Landroid/widget/TextView;->setBackgroundColor(I)V
    003e: iget v1, v6.Lcom/a/a/g;->i:Landroid/widget/TextView;
    0040: invoke-virtual {v1, v5, v3, v3, v3}, Landroid/widget/TextView;->setPadding(IIII)V
    0043: iget v1, v6.Lcom/a/a/g;->i:Landroid/widget/TextView;
    0045: invoke-virtual {v1, v5}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V
    0048: iget v1, v6.Lcom/a/a/g;->i:Landroid/widget/TextView;
    004a: invoke-virtual {v1, v0, v4, v4, v4}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V
    004d: iget v0, v6.Lcom/a/a/g;->h:Landroid/widget/LinearLayout;
    004f: iget v1, v6.Lcom/a/a/g;->i:Landroid/widget/TextView;
    0051: invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    0054: return-void

  [Direct Method] b(Lcom/a/a/g;) -> Lcom/sec/chaton/b/b;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/a/a/g;->f:Lcom/sec/chaton/b/b;
    0002: return-object v0

  [Direct Method] b() -> V
    // registers=5, ins=1, outs=3, insns_size=83
    0000: const/4 v3, 1
    0001: const/4 v2, 0
    0002: new-instance v0, Landroid/webkit/WebView;
    0004: invoke-virtual {v4}, Lcom/a/a/g;->getContext()Landroid/content/Context;
    0007: move-result-object v1
    0008: invoke-direct {v0, v1}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
    000b: iput v0, v4.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    000d: iget v0, v4.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    000f: invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    0012: move-result-object v0
    0013: invoke-virtual {v0, v2}, Landroid/webkit/WebSettings;->setSavePassword(Z)V
    0016: iget v0, v4.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    0018: invoke-virtual {v0, v3}, Landroid/webkit/WebView;->setVerticalScrollbarOverlay(Z)V
    001b: iget v0, v4.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    001d: invoke-virtual {v0, v2}, Landroid/webkit/WebView;->setHorizontalScrollBarEnabled(Z)V
    0020: iget v0, v4.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    0022: new-instance v1, Lcom/a/a/k;
    0024: const/4 v2, 0
    0025: invoke-direct {v1, v4, v2}, Lcom/a/a/k;-><init>(Lcom/a/a/g;Lcom/a/a/h;)V
    0028: invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V
    002b: iget v0, v4.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    002d: invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    0030: move-result-object v0
    0031: invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V
    0034: iget v0, v4.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    0036: iget v1, v4.Lcom/a/a/g;->d:Ljava/lang/String;
    0038: invoke-virtual {v0, v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    003b: iget v0, v4.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    003d: sget v1, Lcom/a/a/g;->c:Landroid/widget/FrameLayout$LayoutParams;
    003f: invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    0042: iget v0, v4.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    0044: invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    0047: move-result-object v0
    0048: invoke-virtual {v0}, Landroid/webkit/WebSettings;->getUserAgentString()Ljava/lang/String;
    004b: iget v0, v4.Lcom/a/a/g;->h:Landroid/widget/LinearLayout;
    004d: iget v1, v4.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    004f: invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V
    0052: return-void

  [Direct Method] c(Lcom/a/a/g;) -> Landroid/webkit/WebView;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    0002: return-object v0

  [Direct Method] d(Lcom/a/a/g;) -> Landroid/widget/TextView;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/a/a/g;->i:Landroid/widget/TextView;
    0002: return-object v0

  [Virtual Method] dismiss() -> V
    // registers=2, ins=1, outs=1, insns_size=31
    0000: iget v0, v1.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    0002: if-eqz v0, 000e
    0004: iget v0, v1.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    0006: invoke-virtual {v0}, Landroid/webkit/WebView;->stopLoading()V
    0009: iget v0, v1.Lcom/a/a/g;->g:Landroid/webkit/WebView;
    000b: invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V
    000e: iget v0, v1.Lcom/a/a/g;->f:Lcom/sec/chaton/b/b;
    0010: invoke-virtual {v0}, Lcom/sec/chaton/b/b;->isShowing()Z
    0013: move-result v0
    0014: if-eqz v0, 001b
    0016: iget v0, v1.Lcom/a/a/g;->f:Lcom/sec/chaton/b/b;
    0018: invoke-virtual {v0}, Lcom/sec/chaton/b/b;->dismiss()V
    001b: invoke-super {v1}, Landroid/app/Dialog;->dismiss()V
    001e: return-void

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=11, ins=2, outs=3, insns_size=164
    0000: const/4 v6, 0
    0001: const/high16 v8, 1056964608 (0x3f000000)
    0003: const/4 v7, 1
    0004: invoke-super {v9, v10}, Landroid/app/Dialog;->onCreate(Landroid/os/Bundle;)V
    0007: new-instance v0, Lcom/a/a/h;
    0009: invoke-direct {v0, v9}, Lcom/a/a/h;-><init>(Lcom/a/a/g;)V
    000c: invoke-virtual {v9, v0}, Lcom/a/a/g;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)V
    000f: new-instance v0, Lcom/sec/chaton/widget/e;
    0011: invoke-virtual {v9}, Lcom/a/a/g;->getContext()Landroid/content/Context;
    0014: move-result-object v1
    0015: invoke-direct {v0, v1}, Lcom/sec/chaton/widget/e;-><init>(Landroid/content/Context;)V
    0018: iput v0, v9.Lcom/a/a/g;->f:Lcom/sec/chaton/b/b;
    001a: iget v0, v9.Lcom/a/a/g;->f:Lcom/sec/chaton/b/b;
    001c: invoke-virtual {v0, v7}, Lcom/sec/chaton/b/b;->requestWindowFeature(I)Z
    001f: iget v0, v9.Lcom/a/a/g;->f:Lcom/sec/chaton/b/b;
    0021: invoke-virtual {v9}, Lcom/a/a/g;->getContext()Landroid/content/Context;
    0024: move-result-object v1
    0025: const v2, 2131492901 (0x7f0c0025)
    0028: invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;
    002b: move-result-object v1
    002c: invoke-virtual {v0, v1}, Lcom/sec/chaton/b/b;->setMessage(Ljava/lang/CharSequence;)V
    002f: iget v0, v9.Lcom/a/a/g;->f:Lcom/sec/chaton/b/b;
    0031: invoke-virtual {v0, v6}, Lcom/sec/chaton/b/b;->setCanceledOnTouchOutside(Z)V
    0034: iget v0, v9.Lcom/a/a/g;->f:Lcom/sec/chaton/b/b;
    0036: new-instance v1, Lcom/a/a/i;
    0038: invoke-direct {v1, v9}, Lcom/a/a/i;-><init>(Lcom/a/a/g;)V
    003b: invoke-virtual {v0, v1}, Lcom/sec/chaton/b/b;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)V
    003e: new-instance v0, Lcom/a/a/j;
    0040: invoke-virtual {v9}, Lcom/a/a/g;->getContext()Landroid/content/Context;
    0043: move-result-object v1
    0044: invoke-direct {v0, v1, v9}, Lcom/a/a/j;-><init>(Landroid/content/Context;Landroid/app/Dialog;)V
    0047: iput v0, v9.Lcom/a/a/g;->h:Landroid/widget/LinearLayout;
    0049: iget v0, v9.Lcom/a/a/g;->h:Landroid/widget/LinearLayout;
    004b: invoke-virtual {v0, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V
    004e: invoke-direct {v9}, Lcom/a/a/g;->a()V
    0051: invoke-direct {v9}, Lcom/a/a/g;->b()V
    0054: invoke-virtual {v9}, Lcom/a/a/g;->getWindow()Landroid/view/Window;
    0057: move-result-object v0
    0058: invoke-virtual {v0}, Landroid/view/Window;->getWindowManager()Landroid/view/WindowManager;
    005b: move-result-object v0
    005c: invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    005f: move-result-object v1
    0060: invoke-virtual {v9}, Lcom/a/a/g;->getContext()Landroid/content/Context;
    0063: move-result-object v0
    0064: invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    0067: move-result-object v0
    0068: invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    006b: move-result-object v0
    006c: iget v2, v0.Landroid/util/DisplayMetrics;->density:F
    006e: invoke-virtual {v9}, Lcom/a/a/g;->getContext()Landroid/content/Context;
    0071: move-result-object v0
    0072: invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    0075: move-result-object v0
    0076: invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;
    0079: move-result-object v0
    007a: iget v0, v0.Landroid/content/res/Configuration;->orientation:I
    007c: const/4 v3, 2
    007d: if-ne v0, v3, 00a1
    007f: sget v0, Lcom/a/a/g;->a:[F
    0081: iget v3, v9.Lcom/a/a/g;->h:Landroid/widget/LinearLayout;
    0083: new-instance v4, Landroid/widget/LinearLayout$LayoutParams;
    0085: invoke-virtual {v1}, Landroid/view/Display;->getWidth()I
    0088: move-result v5
    0089: aget(op=44) v6, v0[v6]
    008b: binop/2addr(op=c8) v6, v2
    008c: binop/2addr(op=c6) v6, v8
    008d: unop(op=87) v6, v6
    008e: binop/2addr(op=b1) v5, v6
    008f: invoke-virtual {v1}, Landroid/view/Display;->getHeight()I
    0092: move-result v1
    0093: aget(op=44) v0, v0[v7]
    0095: binop/2addr(op=c8) v0, v2
    0096: binop/2addr(op=c6) v0, v8
    0097: unop(op=87) v0, v0
    0098: binop(op=91) v0, v1, v0
    009a: invoke-direct {v4, v5, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V
    009d: invoke-virtual {v9, v3, v4}, Lcom/a/a/g;->addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    00a0: return-void
    00a1: sget v0, Lcom/a/a/g;->b:[F
    00a3: goto 0081