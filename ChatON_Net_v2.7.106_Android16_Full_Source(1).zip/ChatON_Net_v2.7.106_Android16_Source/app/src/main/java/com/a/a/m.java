=== CLASS Lcom/a/a/m; (Source: Util.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] a(Ljava/lang/String;) -> Landroid/os/Bundle;
    // registers=9, ins=1, outs=3, insns_size=75
    0000: const/4 v7, 1
    0001: const/4 v0, 0
    0002: new-instance v1, Landroid/os/Bundle;
    0004: invoke-direct {v1}, Landroid/os/Bundle;-><init>()V
    0007: if-eqz v8, 004a
    0009: const-string v2, '&'
    000b: invoke-virtual {v8, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;
    000e: move-result-object v2
    000f: move(op=21) v3, v2
    0010: if-ge v0, v3, 004a
    0012: aget(op=46) v4, v2[v0]
    0014: const-string v5, '='
    0016: invoke-virtual {v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;
    0019: move-result-object v4
    001a: move(op=21) v5, v4
    001b: const/4 v6, 2
    001c: if-ne v5, v6, 0036
    001e: const/4 v5, 0
    001f: aget(op=46) v5, v4[v5]
    0021: const-string v6, 'UTF-8'
    0023: invoke-static {v5, v6}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    0026: move-result-object v5
    0027: const/4 v6, 1
    0028: aget(op=46) v4, v4[v6]
    002a: const-string v6, 'UTF-8'
    002c: invoke-static {v4, v6}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    002f: move-result-object v4
    0030: invoke-virtual {v1, v5, v4}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    0033: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0035: goto 0010
    0036: move(op=21) v5, v4
    0037: if-ne v5, v7, 0033
    0039: const/4 v5, 0
    003a: aget(op=46) v4, v4[v5]
    003c: const-string v5, 'UTF-8'
    003e: invoke-static {v4, v5}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    0041: move-result-object v4
    0042: const-string v5, ''
    0044: invoke-virtual {v1, v4, v5}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    0047: goto 0033
    0048: move-exception v4
    0049: goto 0033
    004a: return-object v1

  [Direct Method] a(Landroid/os/Bundle;) -> Ljava/lang/String;
    // registers=7, ins=1, outs=2, insns_size=85
    0000: if-nez v6, 0005
    0002: const-string v0, ''
    0004: return-object v0
    0005: new-instance v2, Ljava/lang/StringBuilder;
    0007: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    000a: const/4 v0, 1
    000b: invoke-virtual {v6}, Landroid/os/Bundle;->keySet()Ljava/util/Set;
    000e: move-result-object v1
    000f: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    0012: move-result-object v3
    0013: move(op=01) v1, v0
    0014: invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z
    0017: move-result v0
    0018: if-eqz v0, 0050
    001a: invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    001d: move-result-object v0
    001e: check-cast v0, Ljava/lang/String;
    0020: if-eqz v1, 004a
    0022: const/4 v1, 0
    0023: new-instance v4, Ljava/lang/StringBuilder;
    0025: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    0028: invoke-static {v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;
    002b: move-result-object v5
    002c: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002f: move-result-object v4
    0030: const-string v5, '='
    0032: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0035: move-result-object v4
    0036: invoke-virtual {v6, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    0039: move-result-object v0
    003a: invoke-static {v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;
    003d: move-result-object v0
    003e: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0041: move-result-object v0
    0042: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0045: move-result-object v0
    0046: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0049: goto 0014
    004a: const-string v4, '&'
    004c: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004f: goto 0023
    0050: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0053: move-result-object v0
    0054: goto 0004

  [Direct Method] a(Landroid/os/Bundle;, Ljava/lang/String;) -> Ljava/lang/String;
    // registers=7, ins=2, outs=2, insns_size=106
    0000: if-nez v5, 0005
    0002: const-string v0, ''
    0004: return-object v0
    0005: new-instance v1, Ljava/lang/StringBuilder;
    0007: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000a: invoke-virtual {v5}, Landroid/os/Bundle;->keySet()Ljava/util/Set;
    000d: move-result-object v0
    000e: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    0011: move-result-object v2
    0012: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    0015: move-result v0
    0016: if-eqz v0, 0065
    0018: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    001b: move-result-object v0
    001c: check-cast v0, Ljava/lang/String;
    001e: invoke-virtual {v5, v0}, Landroid/os/Bundle;->getByteArray(Ljava/lang/String;)[B
    0021: move-result-object v3
    0022: if-nez v3, 0012
    0024: new-instance v3, Ljava/lang/StringBuilder;
    0026: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    0029: const-string v4, 'Content-Disposition: form-data; name="'
    002b: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002e: move-result-object v3
    002f: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0032: move-result-object v3
    0033: const-string v4, '"\r\n\r\n'
    0035: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0038: move-result-object v3
    0039: invoke-virtual {v5, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    003c: move-result-object v0
    003d: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0040: move-result-object v0
    0041: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0044: move-result-object v0
    0045: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0048: new-instance v0, Ljava/lang/StringBuilder;
    004a: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    004d: const-string v3, '\r\n--'
    004f: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0052: move-result-object v0
    0053: invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0056: move-result-object v0
    0057: const-string v3, '\r\n'
    0059: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    005c: move-result-object v0
    005d: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0060: move-result-object v0
    0061: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0064: goto 0012
    0065: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0068: move-result-object v0
    0069: goto 0004

  [Direct Method] a(Ljava/io/InputStream;) -> Ljava/lang/String;
    // registers=5, ins=1, outs=3, insns_size=42
    0000: new-instance v1, Ljava/lang/StringBuilder;
    0002: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0005: new-instance v2, Ljava/io/BufferedReader;
    0007: new-instance v0, Ljava/io/InputStreamReader;
    0009: invoke-direct {v0, v4}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V
    000c: const/16 v3, 1000 (0x3e8)
    000e: invoke-direct {v2, v0, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    0011: invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
    0014: move-result-object v0
    0015: if-eqz v0, 001f
    0017: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001a: invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;
    001d: move-result-object v0
    001e: goto 0015
    001f: invoke-virtual {v4}, Ljava/io/InputStream;->close()V
    0022: invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    0025: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0028: move-result-object v0
    0029: return-object v0

  [Direct Method] a(Ljava/lang/String;, Ljava/lang/String;, Landroid/os/Bundle;) -> Ljava/lang/String;
    // registers=12, ins=3, outs=3, insns_size=486
    0000: const/4 v7, 1
    0001: const-string v2, '3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f'
    0003: const-string v3, '\r\n'
    0005: const-string v0, 'GET'
    0007: invoke-virtual {v0, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    000a: move-result v0
    000b: if-eqz v0, 0028
    000d: new-instance v0, Ljava/lang/StringBuilder;
    000f: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0012: invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0015: move-result-object v0
    0016: const-string v1, '?'
    0018: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001b: move-result-object v0
    001c: invoke-static {v11}, Lcom/a/a/m;->a(Landroid/os/Bundle;)Ljava/lang/String;
    001f: move-result-object v1
    0020: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0023: move-result-object v0
    0024: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0027: move-result-object v9
    0028: const-string v0, 'Facebook-Util'
    002a: new-instance v1, Ljava/lang/StringBuilder;
    002c: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    002f: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0032: move-result-object v1
    0033: const-string v4, ' URL: '
    0035: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0038: move-result-object v1
    0039: invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003c: move-result-object v1
    003d: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0040: move-result-object v1
    0041: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0044: new-instance v0, Ljava/net/URL;
    0046: invoke-direct {v0, v9}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    0049: invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;
    004c: move-result-object v0
    004d: check-cast v0, Ljava/net/HttpURLConnection;
    004f: const-string v1, 'User-Agent'
    0051: new-instance v4, Ljava/lang/StringBuilder;
    0053: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    0056: invoke-static {}, Ljava/lang/System;->getProperties()Ljava/util/Properties;
    0059: move-result-object v5
    005a: const-string v6, 'http.agent'
    005c: invoke-virtual {v5, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;
    005f: move-result-object v5
    0060: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0063: move-result-object v4
    0064: const-string v5, ' FacebookAndroidSDK'
    0066: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0069: move-result-object v4
    006a: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    006d: move-result-object v4
    006e: invoke-virtual {v0, v1, v4}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    0071: const-string v1, 'GET'
    0073: invoke-virtual {v1, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0076: move-result v1
    0077: if-nez v1, 01d1
    0079: new-instance v4, Landroid/os/Bundle;
    007b: invoke-direct {v4}, Landroid/os/Bundle;-><init>()V
    007e: invoke-virtual {v11}, Landroid/os/Bundle;->keySet()Ljava/util/Set;
    0081: move-result-object v1
    0082: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    0085: move-result-object v5
    0086: invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z
    0089: move-result v1
    008a: if-eqz v1, 00a0
    008c: invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    008f: move-result-object v1
    0090: check-cast v1, Ljava/lang/String;
    0092: invoke-virtual {v11, v1}, Landroid/os/Bundle;->getByteArray(Ljava/lang/String;)[B
    0095: move-result-object v6
    0096: if-eqz v6, 0086
    0098: invoke-virtual {v11, v1}, Landroid/os/Bundle;->getByteArray(Ljava/lang/String;)[B
    009b: move-result-object v6
    009c: invoke-virtual {v4, v1, v6}, Landroid/os/Bundle;->putByteArray(Ljava/lang/String;[B)V
    009f: goto 0086
    00a0: const-string v1, 'method'
    00a2: invoke-virtual {v11, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z
    00a5: move-result v1
    00a6: if-nez v1, 00ad
    00a8: const-string v1, 'method'
    00aa: invoke-virtual {v11, v1, v10}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    00ad: const-string v1, 'access_token'
    00af: invoke-virtual {v11, v1}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z
    00b2: move-result v1
    00b3: if-eqz v1, 00c4
    00b5: const-string v1, 'access_token'
    00b7: invoke-virtual {v11, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    00ba: move-result-object v1
    00bb: invoke-static {v1}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;)Ljava/lang/String;
    00be: move-result-object v1
    00bf: const-string v5, 'access_token'
    00c1: invoke-virtual {v11, v5, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    00c4: const-string v1, 'POST'
    00c6: invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V
    00c9: const-string v1, 'Content-Type'
    00cb: new-instance v5, Ljava/lang/StringBuilder;
    00cd: invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V
    00d0: const-string v6, 'multipart/form-data;boundary='
    00d2: invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00d5: move-result-object v5
    00d6: invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00d9: move-result-object v5
    00da: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00dd: move-result-object v5
    00de: invoke-virtual {v0, v1, v5}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    00e1: invoke-virtual {v0, v7}, Ljava/net/HttpURLConnection;->setDoOutput(Z)V
    00e4: invoke-virtual {v0, v7}, Ljava/net/HttpURLConnection;->setDoInput(Z)V
    00e7: const-string v1, 'Connection'
    00e9: const-string v5, 'Keep-Alive'
    00eb: invoke-virtual {v0, v1, v5}, Ljava/net/HttpURLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V
    00ee: invoke-virtual {v0}, Ljava/net/HttpURLConnection;->connect()V
    00f1: new-instance v5, Ljava/io/BufferedOutputStream;
    00f3: invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getOutputStream()Ljava/io/OutputStream;
    00f6: move-result-object v1
    00f7: invoke-direct {v5, v1}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V
    00fa: new-instance v1, Ljava/lang/StringBuilder;
    00fc: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    00ff: const-string v6, '--'
    0101: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0104: move-result-object v1
    0105: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0108: move-result-object v1
    0109: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    010c: move-result-object v1
    010d: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0110: move-result-object v1
    0111: invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B
    0114: move-result-object v1
    0115: invoke-virtual {v5, v1}, Ljava/io/OutputStream;->write([B)V
    0118: invoke-static {v11, v2}, Lcom/a/a/m;->a(Landroid/os/Bundle;Ljava/lang/String;)Ljava/lang/String;
    011b: move-result-object v1
    011c: invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B
    011f: move-result-object v1
    0120: invoke-virtual {v5, v1}, Ljava/io/OutputStream;->write([B)V
    0123: new-instance v1, Ljava/lang/StringBuilder;
    0125: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0128: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    012b: move-result-object v1
    012c: const-string v6, '--'
    012e: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0131: move-result-object v1
    0132: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0135: move-result-object v1
    0136: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0139: move-result-object v1
    013a: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    013d: move-result-object v1
    013e: invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B
    0141: move-result-object v1
    0142: invoke-virtual {v5, v1}, Ljava/io/OutputStream;->write([B)V
    0145: invoke-virtual {v4}, Landroid/os/Bundle;->isEmpty()Z
    0148: move-result v1
    0149: if-nez v1, 01cb
    014b: invoke-virtual {v4}, Landroid/os/Bundle;->keySet()Ljava/util/Set;
    014e: move-result-object v1
    014f: invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    0152: move-result-object v6
    0153: invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z
    0156: move-result v1
    0157: if-eqz v1, 01cb
    0159: invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    015c: move-result-object v1
    015d: check-cast v1, Ljava/lang/String;
    015f: new-instance v7, Ljava/lang/StringBuilder;
    0161: invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V
    0164: const-string v8, 'Content-Disposition: form-data; filename="'
    0166: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0169: move-result-object v7
    016a: invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    016d: move-result-object v7
    016e: const-string v8, '"'
    0170: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0173: move-result-object v7
    0174: invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0177: move-result-object v7
    0178: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    017b: move-result-object v7
    017c: invoke-virtual {v7}, Ljava/lang/String;->getBytes()[B
    017f: move-result-object v7
    0180: invoke-virtual {v5, v7}, Ljava/io/OutputStream;->write([B)V
    0183: new-instance v7, Ljava/lang/StringBuilder;
    0185: invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V
    0188: const-string v8, 'Content-Type: content/unknown'
    018a: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    018d: move-result-object v7
    018e: invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0191: move-result-object v7
    0192: invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0195: move-result-object v7
    0196: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0199: move-result-object v7
    019a: invoke-virtual {v7}, Ljava/lang/String;->getBytes()[B
    019d: move-result-object v7
    019e: invoke-virtual {v5, v7}, Ljava/io/OutputStream;->write([B)V
    01a1: invoke-virtual {v4, v1}, Landroid/os/Bundle;->getByteArray(Ljava/lang/String;)[B
    01a4: move-result-object v1
    01a5: invoke-virtual {v5, v1}, Ljava/io/OutputStream;->write([B)V
    01a8: new-instance v1, Ljava/lang/StringBuilder;
    01aa: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    01ad: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01b0: move-result-object v1
    01b1: const-string v7, '--'
    01b3: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01b6: move-result-object v1
    01b7: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01ba: move-result-object v1
    01bb: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01be: move-result-object v1
    01bf: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    01c2: move-result-object v1
    01c3: invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B
    01c6: move-result-object v1
    01c7: invoke-virtual {v5, v1}, Ljava/io/OutputStream;->write([B)V
    01ca: goto 0153
    01cb: invoke-virtual {v5}, Ljava/io/OutputStream;->flush()V
    01ce: invoke-virtual {v5}, Ljava/io/OutputStream;->close()V
    01d1: const-string v1, ''
    01d3: invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;
    01d6: move-result-object v1
    01d7: invoke-static {v1}, Lcom/a/a/m;->a(Ljava/io/InputStream;)Ljava/lang/String;
    01da: move-result-object v0
    01db: return-object v0
    01dc: move-exception v1
    01dd: invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;
    01e0: move-result-object v0
    01e1: invoke-static {v0}, Lcom/a/a/m;->a(Ljava/io/InputStream;)Ljava/lang/String;
    01e4: move-result-object v0
    01e5: goto 01db

  [Direct Method] a(Landroid/content/Context;) -> V
    // registers=2, ins=1, outs=1, insns_size=11
    0000: invoke-static {v1}, Landroid/webkit/CookieSyncManager;->createInstance(Landroid/content/Context;)Landroid/webkit/CookieSyncManager;
    0003: invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;
    0006: move-result-object v0
    0007: invoke-virtual {v0}, Landroid/webkit/CookieManager;->removeAllCookie()V
    000a: return-void

  [Direct Method] a(Landroid/content/Context;, Ljava/lang/String;, Ljava/lang/String;) -> V
    // registers=4, ins=3, outs=2, insns_size=19
    0000: new-instance v0, Lcom/sec/widget/a;
    0002: invoke-direct {v0, v1}, Lcom/sec/widget/a;-><init>(Landroid/content/Context;)V
    0005: invoke-virtual {v0, v2}, Lcom/sec/widget/a;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    0008: invoke-virtual {v0, v3}, Lcom/sec/widget/a;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    000b: invoke-virtual {v0}, Lcom/sec/widget/a;->create()Landroid/app/AlertDialog;
    000e: move-result-object v0
    000f: invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V
    0012: return-void

  [Direct Method] b(Ljava/lang/String;) -> Landroid/os/Bundle;
    // registers=3, ins=1, outs=3, insns_size=40
    0000: const-string v0, 'fbconnect'
    0002: const-string v1, 'http'
    0004: invoke-virtual {v2, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    0007: move-result-object v0
    0008: new-instance v1, Ljava/net/URL;
    000a: invoke-direct {v1, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    000d: invoke-virtual {v1}, Ljava/net/URL;->getQuery()Ljava/lang/String;
    0010: move-result-object v0
    0011: invoke-static {v0}, Lcom/a/a/m;->a(Ljava/lang/String;)Landroid/os/Bundle;
    0014: move-result-object v0
    0015: invoke-virtual {v1}, Ljava/net/URL;->getRef()Ljava/lang/String;
    0018: move-result-object v1
    0019: invoke-static {v1}, Lcom/a/a/m;->a(Ljava/lang/String;)Landroid/os/Bundle;
    001c: move-result-object v1
    001d: invoke-virtual {v0, v1}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V
    0020: return-object v0
    0021: move-exception v0
    0022: new-instance v0, Landroid/os/Bundle;
    0024: invoke-direct {v0}, Landroid/os/Bundle;-><init>()V
    0027: goto 0020

  [Direct Method] c(Ljava/lang/String;) -> Lorg/json/JSONObject;
    // registers=6, ins=1, outs=4, insns_size=173
    0000: const-string v0, 'false'
    0002: invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0005: move-result v0
    0006: if-eqz v0, 0010
    0008: new-instance v0, Lcom/a/a/f;
    000a: const-string v1, 'request failed'
    000c: invoke-direct {v0, v1}, Lcom/a/a/f;-><init>(Ljava/lang/String;)V
    000f: throw v0
    0010: const-string v0, 'true'
    0012: invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0015: move-result v0
    0016: if-eqz v0, 001a
    0018: const-string v5, '{value : true}'
    001a: new-instance v0, Lorg/json/JSONObject;
    001c: invoke-direct {v0, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    001f: const-string v1, 'error'
    0021: invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    0024: move-result v1
    0025: if-eqz v1, 0040
    0027: const-string v1, 'error'
    0029: invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;
    002c: move-result-object v0
    002d: new-instance v1, Lcom/a/a/f;
    002f: const-string v2, 'message'
    0031: invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    0034: move-result-object v2
    0035: const-string v3, 'type'
    0037: invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    003a: move-result-object v0
    003b: const/4 v3, 0
    003c: invoke-direct {v1, v2, v0, v3}, Lcom/a/a/f;-><init>(Ljava/lang/String;Ljava/lang/String;I)V
    003f: throw v1
    0040: const-string v1, 'error_code'
    0042: invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    0045: move-result v1
    0046: if-eqz v1, 0068
    0048: const-string v1, 'error_msg'
    004a: invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    004d: move-result v1
    004e: if-eqz v1, 0068
    0050: new-instance v1, Lcom/a/a/f;
    0052: const-string v2, 'error_msg'
    0054: invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    0057: move-result-object v2
    0058: const-string v3, ''
    005a: const-string v4, 'error_code'
    005c: invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    005f: move-result-object v0
    0060: invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    0063: move-result v0
    0064: invoke-direct {v1, v2, v3, v0}, Lcom/a/a/f;-><init>(Ljava/lang/String;Ljava/lang/String;I)V
    0067: throw v1
    0068: const-string v1, 'error_code'
    006a: invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    006d: move-result v1
    006e: if-eqz v1, 0084
    0070: new-instance v1, Lcom/a/a/f;
    0072: const-string v2, 'request failed'
    0074: const-string v3, ''
    0076: const-string v4, 'error_code'
    0078: invoke-virtual {v0, v4}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    007b: move-result-object v0
    007c: invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    007f: move-result v0
    0080: invoke-direct {v1, v2, v3, v0}, Lcom/a/a/f;-><init>(Ljava/lang/String;Ljava/lang/String;I)V
    0083: throw v1
    0084: const-string v1, 'error_msg'
    0086: invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    0089: move-result v1
    008a: if-eqz v1, 0098
    008c: new-instance v1, Lcom/a/a/f;
    008e: const-string v2, 'error_msg'
    0090: invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    0093: move-result-object v0
    0094: invoke-direct {v1, v0}, Lcom/a/a/f;-><init>(Ljava/lang/String;)V
    0097: throw v1
    0098: const-string v1, 'error_reason'
    009a: invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z
    009d: move-result v1
    009e: if-eqz v1, 00ac
    00a0: new-instance v1, Lcom/a/a/f;
    00a2: const-string v2, 'error_reason'
    00a4: invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;
    00a7: move-result-object v0
    00a8: invoke-direct {v1, v0}, Lcom/a/a/f;-><init>(Ljava/lang/String;)V
    00ab: throw v1
    00ac: return-object v0