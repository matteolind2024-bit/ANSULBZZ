=== CLASS Lcom/a/a/h; (Source: FbDialog.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/content/DialogInterface$OnCancelListener;
  [Instance Field] a: Lcom/a/a/g;

  [Direct Method] <init>(Lcom/a/a/g;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/a/a/h;->a:Lcom/a/a/g;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onCancel(Landroid/content/DialogInterface;) -> V
    // registers=3, ins=2, outs=1, insns_size=10
    0000: iget v0, v1.Lcom/a/a/h;->a:Lcom/a/a/g;
    0002: invoke-static {v0}, Lcom/a/a/g;->a(Lcom/a/a/g;)Lcom/a/a/e;
    0005: move-result-object v0
    0006: invoke-interface {v0}, Lcom/a/a/e;->a()V
    0009: return-void