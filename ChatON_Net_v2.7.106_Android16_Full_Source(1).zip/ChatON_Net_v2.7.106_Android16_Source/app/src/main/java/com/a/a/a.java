=== CLASS Lcom/a/a/a; (Source: DialogError.java) ===
  Super: Ljava/lang/Throwable;
  [Instance Field] a: I
  [Instance Field] b: Ljava/lang/String;

  [Direct Method] <init>(Ljava/lang/String;, I, Ljava/lang/String;) -> V
    // registers=4, ins=4, outs=2, insns_size=8
    0000: invoke-direct {v0, v1}, Ljava/lang/Throwable;-><init>(Ljava/lang/String;)V
    0003: iput v2, v0.Lcom/a/a/a;->a:I
    0005: iput v3, v0.Lcom/a/a/a;->b:Ljava/lang/String;
    0007: return-void