=== CLASS Lcom/a/a/b; (Source: Facebook.java) ===
  Super: Ljava/lang/Object;
  [Static Field] a: Ljava/lang/String;
  [Static Field] b: Ljava/lang/String;
  [Static Field] c: Ljava/lang/String;
  [Instance Field] d: Ljava/lang/String;
  [Instance Field] e: J
  [Instance Field] f: Ljava/lang/String;
  [Instance Field] g: Landroid/app/Activity;
  [Instance Field] h: [Ljava/lang/String;
  [Instance Field] i: I
  [Instance Field] j: Lcom/a/a/e;
  [Instance Field] k: Landroid/support/v4/app/Fragment;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=0, insns_size=13
    0000: const-string v0, 'https://m.facebook.com/dialog/'
    0002: sput v0, Lcom/a/a/b;->a:Ljava/lang/String;
    0004: const-string v0, 'https://graph.facebook.com/'
    0006: sput v0, Lcom/a/a/b;->b:Ljava/lang/String;
    0008: const-string v0, 'https://api.facebook.com/restserver.php'
    000a: sput v0, Lcom/a/a/b;->c:Ljava/lang/String;
    000c: return-void

  [Direct Method] <init>(Ljava/lang/String;) -> V
    // registers=4, ins=2, outs=2, insns_size=23
    0000: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0003: const/4 v0, 0
    0004: iput v0, v2.Lcom/a/a/b;->d:Ljava/lang/String;
    0006: const-wide/16 v0, 0
    0008: iput v0, v2.Lcom/a/a/b;->e:J
    000a: if-nez v3, 0014
    000c: new-instance v0, Ljava/lang/IllegalArgumentException;
    000e: const-string v1, 'You must specify your application ID when instantiating a Facebook object. See README for details.'
    0010: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0013: throw v0
    0014: iput v3, v2.Lcom/a/a/b;->f:Ljava/lang/String;
    0016: return-void

  [Direct Method] a(Lcom/a/a/b;) -> Lcom/a/a/e;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/a/a/b;->j:Lcom/a/a/e;
    0002: return-object v0

  [Direct Method] a(Landroid/app/Activity;, [Ljava/lang/String;) -> V
    // registers=6, ins=3, outs=5, insns_size=33
    0000: new-instance v0, Landroid/os/Bundle;
    0002: invoke-direct {v0}, Landroid/os/Bundle;-><init>()V
    0005: move(op=21) v1, v5
    0006: if-lez v1, 0013
    0008: const-string v1, 'scope'
    000a: const-string v2, ','
    000c: invoke-static {v2, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;[Ljava/lang/Object;)Ljava/lang/String;
    000f: move-result-object v2
    0010: invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    0013: invoke-static {v4}, Landroid/webkit/CookieSyncManager;->createInstance(Landroid/content/Context;)Landroid/webkit/CookieSyncManager;
    0016: const-string v1, 'oauth'
    0018: new-instance v2, Lcom/a/a/d;
    001a: invoke-direct {v2, v3}, Lcom/a/a/d;-><init>(Lcom/a/a/b;)V
    001d: invoke-virtual {v3, v4, v1, v0, v2}, Lcom/a/a/b;->a(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;Lcom/a/a/e;)V
    0020: return-void

  [Direct Method] a(Lcom/a/a/b;, Landroid/app/Activity;, [Ljava/lang/String;) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-direct {v0, v1, v2}, Lcom/a/a/b;->a(Landroid/app/Activity;[Ljava/lang/String;)V
    0003: return-void

  [Direct Method] a(Landroid/app/Activity;, Landroid/content/Intent;) -> Z
    // registers=9, ins=3, outs=3, insns_size=53
    0000: const/4 v0, 0
    0001: invoke-virtual {v7}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;
    0004: move-result-object v1
    0005: invoke-virtual {v1, v8, v0}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;
    0008: move-result-object v1
    0009: if-nez v1, 000c
    000b: return v0
    000c: iget v1, v1.Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;
    000e: iget v1, v1.Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;
    0010: invoke-virtual {v7}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;
    0013: move-result-object v2
    0014: const/16 v3, 64 (0x40)
    0016: invoke-virtual {v2, v1, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    0019: move-result-object v1
    001a: iget v2, v1.Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;
    001c: move(op=21) v3, v2
    001d: move(op=01) v1, v0
    001e: if-ge v1, v3, 000b
    0020: aget(op=46) v4, v2[v1]
    0022: invoke-virtual {v4}, Landroid/content/pm/Signature;->toCharsString()Ljava/lang/String;
    0025: move-result-object v4
    0026: const-string v5, '30820268308201d1'
    0028: invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    002b: move-result v4
    002c: if-eqz v4, 0030
    002e: const/4 v0, 1
    002f: goto 000b
    0030: binop/lit8(op=d8) v1, v1, 1 (0x1)
    0032: goto 001e
    0033: move-exception v1
    0034: goto 000b

  [Direct Method] a(Landroid/app/Activity;, Ljava/lang/String;, [Ljava/lang/String;, I) -> Z
    // registers=10, ins=5, outs=3, insns_size=64
    0000: const/4 v1, 0
    0001: const/4 v0, 1
    0002: new-instance v2, Landroid/content/Intent;
    0004: invoke-direct {v2}, Landroid/content/Intent;-><init>()V
    0007: const-string v3, 'com.facebook.katana'
    0009: const-string v4, 'com.facebook.katana.ProxyAuth'
    000b: invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    000e: const-string v3, 'client_id'
    0010: invoke-virtual {v2, v3, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    0013: move(op=21) v3, v8
    0014: if-lez v3, 0021
    0016: const-string v3, 'scope'
    0018: const-string v4, ','
    001a: invoke-static {v4, v8}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;[Ljava/lang/Object;)Ljava/lang/String;
    001d: move-result-object v4
    001e: invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    0021: invoke-direct {v5, v6, v2}, Lcom/a/a/b;->a(Landroid/app/Activity;Landroid/content/Intent;)Z
    0024: move-result v3
    0025: if-nez v3, 0028
    0027: return v1
    0028: iput v6, v5.Lcom/a/a/b;->g:Landroid/app/Activity;
    002a: iput v8, v5.Lcom/a/a/b;->h:[Ljava/lang/String;
    002c: iput v9, v5.Lcom/a/a/b;->i:I
    002e: iget v3, v5.Lcom/a/a/b;->k:Landroid/support/v4/app/Fragment;
    0030: if-eqz v3, 0039
    0032: iget v3, v5.Lcom/a/a/b;->k:Landroid/support/v4/app/Fragment;
    0034: invoke-virtual {v3, v2, v9}, Landroid/support/v4/app/Fragment;->startActivityForResult(Landroid/content/Intent;I)V
    0037: move(op=01) v1, v0
    0038: goto 0027
    0039: invoke-virtual {v6, v2, v9}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    003c: goto 0037
    003d: move-exception v0
    003e: move(op=01) v0, v1
    003f: goto 0037

  [Virtual Method] a(Landroid/content/Context;) -> Ljava/lang/String;
    // registers=5, ins=2, outs=3, insns_size=29
    0000: invoke-static {v4}, Lcom/a/a/m;->a(Landroid/content/Context;)V
    0003: new-instance v0, Landroid/os/Bundle;
    0005: invoke-direct {v0}, Landroid/os/Bundle;-><init>()V
    0008: const-string v1, 'method'
    000a: const-string v2, 'auth.expireSession'
    000c: invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    000f: invoke-virtual {v3, v0}, Lcom/a/a/b;->a(Landroid/os/Bundle;)Ljava/lang/String;
    0012: move-result-object v0
    0013: const/4 v1, 0
    0014: invoke-virtual {v3, v1}, Lcom/a/a/b;->a(Ljava/lang/String;)V
    0017: const-wide/16 v1, 0
    0019: invoke-virtual {v3, v1, v2}, Lcom/a/a/b;->a(J)V
    001c: return-object v0

  [Virtual Method] a(Landroid/os/Bundle;) -> Ljava/lang/String;
    // registers=4, ins=2, outs=4, insns_size=24
    0000: const-string v0, 'method'
    0002: invoke-virtual {v3, v0}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z
    0005: move-result v0
    0006: if-nez v0, 0010
    0008: new-instance v0, Ljava/lang/IllegalArgumentException;
    000a: const-string v1, 'API method must be speci'
    000c: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    000f: throw v0
    0010: const/4 v0, 0
    0011: const-string v1, 'GET'
    0013: invoke-virtual {v2, v0, v3, v1}, Lcom/a/a/b;->a(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;)Ljava/lang/String;
    0016: move-result-object v0
    0017: return-object v0

  [Virtual Method] a(Ljava/lang/String;, Landroid/os/Bundle;, Ljava/lang/String;) -> Ljava/lang/String;
    // registers=6, ins=4, outs=3, insns_size=51
    0000: const-string v0, 'format'
    0002: const-string v1, 'json'
    0004: invoke-virtual {v4, v0, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    0007: invoke-virtual {v2}, Lcom/a/a/b;->a()Z
    000a: move-result v0
    000b: if-eqz v0, 0016
    000d: const-string v0, 'access_token'
    000f: invoke-virtual {v2}, Lcom/a/a/b;->b()Ljava/lang/String;
    0012: move-result-object v1
    0013: invoke-virtual {v4, v0, v1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    0016: if-eqz v3, 0030
    0018: new-instance v0, Ljava/lang/StringBuilder;
    001a: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    001d: sget v1, Lcom/a/a/b;->b:Ljava/lang/String;
    001f: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0022: move-result-object v0
    0023: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0026: move-result-object v0
    0027: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002a: move-result-object v0
    002b: invoke-static {v0, v5, v4}, Lcom/a/a/m;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Ljava/lang/String;
    002e: move-result-object v0
    002f: return-object v0
    0030: sget v0, Lcom/a/a/b;->c:Ljava/lang/String;
    0032: goto 002b

  [Virtual Method] a(I, I, Landroid/content/Intent;) -> V
    // registers=9, ins=4, outs=4, insns_size=287
    0000: const/4 v4, -1
    0001: iget v0, v5.Lcom/a/a/b;->i:I
    0003: if-ne v6, v0, 0035
    0005: if-ne v7, v4, 00d1
    0007: const-string v0, 'error'
    0009: invoke-virtual {v8, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    000c: move-result-object v0
    000d: if-nez v0, 0015
    000f: const-string v0, 'error_type'
    0011: invoke-virtual {v8, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    0014: move-result-object v0
    0015: if-eqz v0, 0076
    0017: const-string v1, 'service_disabled'
    0019: invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    001c: move-result v1
    001d: if-nez v1, 0027
    001f: const-string v1, 'AndroidAuthKillSwitchException'
    0021: invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0024: move-result v1
    0025: if-eqz v1, 0036
    0027: const-string v0, 'Facebook-authorize'
    0029: const-string v1, 'Hosted auth currently disabled. Retrying dialog auth...'
    002b: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    002e: iget v0, v5.Lcom/a/a/b;->g:Landroid/app/Activity;
    0030: iget v1, v5.Lcom/a/a/b;->h:[Ljava/lang/String;
    0032: invoke-direct {v5, v0, v1}, Lcom/a/a/b;->a(Landroid/app/Activity;[Ljava/lang/String;)V
    0035: return-void
    0036: const-string v1, 'access_denied'
    0038: invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    003b: move-result v1
    003c: if-nez v1, 0046
    003e: const-string v1, 'OAuthAccessDeniedException'
    0040: invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0043: move-result v1
    0044: if-eqz v1, 0053
    0046: const-string v0, 'Facebook-authorize'
    0048: const-string v1, 'Login canceled by user.'
    004a: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    004d: iget v0, v5.Lcom/a/a/b;->j:Lcom/a/a/e;
    004f: invoke-interface {v0}, Lcom/a/a/e;->a()V
    0052: goto 0035
    0053: const-string v1, 'Facebook-authorize'
    0055: new-instance v2, Ljava/lang/StringBuilder;
    0057: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    005a: const-string v3, 'Login failed: '
    005c: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    005f: move-result-object v2
    0060: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0063: move-result-object v2
    0064: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0067: move-result-object v2
    0068: invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    006b: iget v1, v5.Lcom/a/a/b;->j:Lcom/a/a/e;
    006d: new-instance v2, Lcom/a/a/f;
    006f: invoke-direct {v2, v0}, Lcom/a/a/f;-><init>(Ljava/lang/String;)V
    0072: invoke-interface {v1, v2}, Lcom/a/a/e;->a(Lcom/a/a/f;)V
    0075: goto 0035
    0076: const-string v0, 'access_token'
    0078: invoke-virtual {v8, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    007b: move-result-object v0
    007c: invoke-virtual {v5, v0}, Lcom/a/a/b;->a(Ljava/lang/String;)V
    007f: const-string v0, 'expires_in'
    0081: invoke-virtual {v8, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    0084: move-result-object v0
    0085: invoke-virtual {v5, v0}, Lcom/a/a/b;->b(Ljava/lang/String;)V
    0088: invoke-virtual {v5}, Lcom/a/a/b;->a()Z
    008b: move-result v0
    008c: if-eqz v0, 00c3
    008e: const-string v0, 'Facebook-authorize'
    0090: new-instance v1, Ljava/lang/StringBuilder;
    0092: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0095: const-string v2, 'Login Success! access_token='
    0097: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    009a: move-result-object v1
    009b: invoke-virtual {v5}, Lcom/a/a/b;->b()Ljava/lang/String;
    009e: move-result-object v2
    009f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a2: move-result-object v1
    00a3: const-string v2, ' expires='
    00a5: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a8: move-result-object v1
    00a9: invoke-virtual {v5}, Lcom/a/a/b;->c()J
    00ac: move-result-wide v2
    00ad: invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    00b0: move-result-object v1
    00b1: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00b4: move-result-object v1
    00b5: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    00b8: iget v0, v5.Lcom/a/a/b;->j:Lcom/a/a/e;
    00ba: invoke-virtual {v8}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;
    00bd: move-result-object v1
    00be: invoke-interface {v0, v1}, Lcom/a/a/e;->a(Landroid/os/Bundle;)V
    00c1: goto/16 0035
    00c3: iget v0, v5.Lcom/a/a/b;->j:Lcom/a/a/e;
    00c5: new-instance v1, Lcom/a/a/f;
    00c7: const-string v2, 'Failed to receive access token.'
    00c9: invoke-direct {v1, v2}, Lcom/a/a/f;-><init>(Ljava/lang/String;)V
    00cc: invoke-interface {v0, v1}, Lcom/a/a/e;->a(Lcom/a/a/f;)V
    00cf: goto/16 0035
    00d1: if-nez v7, 0035
    00d3: if-eqz v8, 0111
    00d5: const-string v0, 'Facebook-authorize'
    00d7: new-instance v1, Ljava/lang/StringBuilder;
    00d9: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    00dc: const-string v2, 'Login failed: '
    00de: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00e1: move-result-object v1
    00e2: const-string v2, 'error'
    00e4: invoke-virtual {v8, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    00e7: move-result-object v2
    00e8: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00eb: move-result-object v1
    00ec: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00ef: move-result-object v1
    00f0: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    00f3: iget v0, v5.Lcom/a/a/b;->j:Lcom/a/a/e;
    00f5: new-instance v1, Lcom/a/a/a;
    00f7: const-string v2, 'error'
    00f9: invoke-virtual {v8, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    00fc: move-result-object v2
    00fd: const-string v3, 'error_code'
    00ff: invoke-virtual {v8, v3, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I
    0102: move-result v3
    0103: const-string v4, 'failing_url'
    0105: invoke-virtual {v8, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    0108: move-result-object v4
    0109: invoke-direct {v1, v2, v3, v4}, Lcom/a/a/a;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    010c: invoke-interface {v0, v1}, Lcom/a/a/e;->a(Lcom/a/a/a;)V
    010f: goto/16 0035
    0111: const-string v0, 'Facebook-authorize'
    0113: const-string v1, 'Login canceled by user.'
    0115: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0118: iget v0, v5.Lcom/a/a/b;->j:Lcom/a/a/e;
    011a: invoke-interface {v0}, Lcom/a/a/e;->a()V
    011d: goto/16 0035

  [Virtual Method] a(J) -> V
    // registers=3, ins=3, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/a/a/b;->e:J
    0002: return-void

  [Virtual Method] a(Landroid/app/Activity;, [Ljava/lang/String;, I, Lcom/a/a/e;) -> V
    // registers=6, ins=5, outs=5, insns_size=22
    0000: const/4 v0, 0
    0001: iput v5, v1.Lcom/a/a/b;->j:Lcom/a/a/e;
    0003: if-ltz v4, 000b
    0005: iget v0, v1.Lcom/a/a/b;->f:Ljava/lang/String;
    0007: invoke-direct {v1, v2, v0, v3, v4}, Lcom/a/a/b;->a(Landroid/app/Activity;Ljava/lang/String;[Ljava/lang/String;I)Z
    000a: move-result v0
    000b: if-nez v0, 0015
    000d: new-instance v0, Lcom/a/a/c;
    000f: invoke-direct {v0, v1, v2, v3}, Lcom/a/a/c;-><init>(Lcom/a/a/b;Landroid/app/Activity;[Ljava/lang/String;)V
    0012: invoke-virtual {v2, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    0015: return-void

  [Virtual Method] a(Landroid/app/Activity;, [Ljava/lang/String;, Lcom/a/a/e;) -> V
    // registers=5, ins=4, outs=5, insns_size=6
    0000: const/16 v0, 32665 (0x7f99)
    0002: invoke-virtual {v1, v2, v3, v0, v4}, Lcom/a/a/b;->a(Landroid/app/Activity;[Ljava/lang/String;ILcom/a/a/e;)V
    0005: return-void

  [Virtual Method] a(Landroid/content/Context;, Ljava/lang/String;, Landroid/os/Bundle;, Lcom/a/a/e;) -> V
    // registers=8, ins=5, outs=4, insns_size=130
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0005: sget v1, Lcom/a/a/b;->a:Ljava/lang/String;
    0007: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000a: move-result-object v0
    000b: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000e: move-result-object v0
    000f: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0012: move-result-object v0
    0013: const-string v1, 'display'
    0015: const-string v2, 'touch'
    0017: invoke-virtual {v6, v1, v2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    001a: const-string v1, 'redirect_uri'
    001c: const-string v2, 'fbconnect://success'
    001e: invoke-virtual {v6, v1, v2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    0021: const-string v1, 'oauth'
    0023: invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0026: move-result v1
    0027: if-eqz v1, 0071
    0029: const-string v1, 'type'
    002b: const-string v2, 'user_agent'
    002d: invoke-virtual {v6, v1, v2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    0030: const-string v1, 'client_id'
    0032: iget v2, v3.Lcom/a/a/b;->f:Ljava/lang/String;
    0034: invoke-virtual {v6, v1, v2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    0037: invoke-virtual {v3}, Lcom/a/a/b;->a()Z
    003a: move-result v1
    003b: if-eqz v1, 0046
    003d: const-string v1, 'access_token'
    003f: invoke-virtual {v3}, Lcom/a/a/b;->b()Ljava/lang/String;
    0042: move-result-object v2
    0043: invoke-virtual {v6, v1, v2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    0046: new-instance v1, Ljava/lang/StringBuilder;
    0048: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    004b: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004e: move-result-object v0
    004f: const-string v1, '?'
    0051: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0054: move-result-object v0
    0055: invoke-static {v6}, Lcom/a/a/m;->a(Landroid/os/Bundle;)Ljava/lang/String;
    0058: move-result-object v1
    0059: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    005c: move-result-object v0
    005d: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0060: move-result-object v0
    0061: const-string v1, 'android.permission.INTERNET'
    0063: invoke-virtual {v4, v1}, Landroid/content/Context;->checkCallingOrSelfPermission(Ljava/lang/String;)I
    0066: move-result v1
    0067: if-eqz v1, 0079
    0069: const-string v0, 'Error'
    006b: const-string v1, 'Application requires permission to access the Internet'
    006d: invoke-static {v4, v0, v1}, Lcom/a/a/m;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    0070: return-void
    0071: const-string v1, 'app_id'
    0073: iget v2, v3.Lcom/a/a/b;->f:Ljava/lang/String;
    0075: invoke-virtual {v6, v1, v2}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V
    0078: goto 0037
    0079: new-instance v1, Lcom/a/a/g;
    007b: invoke-direct {v1, v4, v0, v7}, Lcom/a/a/g;-><init>(Landroid/content/Context;Ljava/lang/String;Lcom/a/a/e;)V
    007e: invoke-virtual {v1}, Lcom/a/a/g;->show()V
    0081: goto 0070

  [Virtual Method] a(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Lcom/a/a/b;->d:Ljava/lang/String;
    0002: return-void

  [Virtual Method] a() -> Z
    // registers=5, ins=1, outs=1, insns_size=32
    0000: invoke-virtual {v4}, Lcom/a/a/b;->b()Ljava/lang/String;
    0003: move-result-object v0
    0004: if-eqz v0, 001e
    0006: invoke-virtual {v4}, Lcom/a/a/b;->c()J
    0009: move-result-wide v0
    000a: const-wide/16 v2, 0
    000c: cmp(op=31) v0, v0, v2
    000e: if-eqz v0, 001c
    0010: invoke-static {}, Ljava/lang/System;->currentTimeMillis()J
    0013: move-result-wide v0
    0014: invoke-virtual {v4}, Lcom/a/a/b;->c()J
    0017: move-result-wide v2
    0018: cmp(op=31) v0, v0, v2
    001a: if-gez v0, 001e
    001c: const/4 v0, 1
    001d: return v0
    001e: const/4 v0, 0
    001f: goto 001d

  [Virtual Method] b() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Lcom/a/a/b;->d:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] b(Ljava/lang/String;) -> V
    // registers=6, ins=2, outs=3, insns_size=26
    0000: if-eqz v5, 0019
    0002: const-string v0, '0'
    0004: invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0007: move-result v0
    0008: if-nez v0, 0019
    000a: invoke-static {}, Ljava/lang/System;->currentTimeMillis()J
    000d: move-result-wide v0
    000e: invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    0011: move-result v2
    0012: binop/lit16(op=d2) v2, v2, 1000 (0x3e8)
    0014: unop(op=81) v2, v2
    0015: binop/2addr(op=bb) v0, v2
    0016: invoke-virtual {v4, v0, v1}, Lcom/a/a/b;->a(J)V
    0019: return-void

  [Virtual Method] c() -> J
    // registers=3, ins=1, outs=0, insns_size=3
    0000: iget v0, v2.Lcom/a/a/b;->e:J
    0002: return-wide v0