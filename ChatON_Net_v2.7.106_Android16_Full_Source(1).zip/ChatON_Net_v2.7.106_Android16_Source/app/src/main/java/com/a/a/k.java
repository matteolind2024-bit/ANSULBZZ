=== CLASS Lcom/a/a/k; (Source: FbDialog.java) ===
  Super: Landroid/webkit/WebViewClient;
  [Instance Field] a: Lcom/a/a/g;

  [Direct Method] <init>(Lcom/a/a/g;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/a/a/k;->a:Lcom/a/a/g;
    0002: invoke-direct {v0}, Landroid/webkit/WebViewClient;-><init>()V
    0005: return-void

  [Direct Method] <init>(Lcom/a/a/g;, Lcom/a/a/h;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Lcom/a/a/k;-><init>(Lcom/a/a/g;)V
    0003: return-void

  [Virtual Method] onPageFinished(Landroid/webkit/WebView;, Ljava/lang/String;) -> V
    // registers=6, ins=3, outs=3, insns_size=71
    0000: invoke-super {v3, v4, v5}, Landroid/webkit/WebViewClient;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
    0003: iget v0, v3.Lcom/a/a/k;->a:Lcom/a/a/g;
    0005: invoke-static {v0}, Lcom/a/a/g;->c(Lcom/a/a/g;)Landroid/webkit/WebView;
    0008: move-result-object v0
    0009: invoke-virtual {v0}, Landroid/webkit/WebView;->getTitle()Ljava/lang/String;
    000c: move-result-object v0
    000d: if-eqz v0, 001e
    000f: invoke-virtual {v0}, Ljava/lang/String;->length()I
    0012: move-result v1
    0013: if-lez v1, 001e
    0015: iget v1, v3.Lcom/a/a/k;->a:Lcom/a/a/g;
    0017: invoke-static {v1}, Lcom/a/a/g;->d(Lcom/a/a/g;)Landroid/widget/TextView;
    001a: move-result-object v1
    001b: invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    001e: const-string v0, 'onPageFinished() \t- mSpinner.dismiss()'
    0020: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0023: move-result-object v1
    0024: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0027: move-result-object v1
    0028: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    002b: iget v0, v3.Lcom/a/a/k;->a:Lcom/a/a/g;
    002d: invoke-static {v0}, Lcom/a/a/g;->b(Lcom/a/a/g;)Lcom/sec/chaton/b/b;
    0030: move-result-object v0
    0031: invoke-virtual {v0}, Lcom/sec/chaton/b/b;->dismiss()V
    0034: return-void
    0035: move-exception v0
    0036: const-string v1, 'onPageFinished() \t- Spinner warning'
    0038: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    003b: move-result-object v2
    003c: invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    003f: move-result-object v2
    0040: invoke-static {v1, v2}, Lcom/sec/chaton/util/p;->d(Ljava/lang/String;Ljava/lang/String;)V
    0043: invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V
    0046: goto 0034

  [Virtual Method] onPageStarted(Landroid/webkit/WebView;, Ljava/lang/String;, Landroid/graphics/Bitmap;) -> V
    // registers=7, ins=4, outs=4, insns_size=44
    0000: invoke-super {v3, v4, v5, v6}, Landroid/webkit/WebViewClient;->onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V
    0003: const-string v0, 'onPageStarted() \t- mSpinner.show()'
    0005: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0008: move-result-object v1
    0009: invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    000c: move-result-object v1
    000d: invoke-static {v0, v1}, Lcom/sec/chaton/util/p;->b(Ljava/lang/String;Ljava/lang/String;)V
    0010: iget v0, v3.Lcom/a/a/k;->a:Lcom/a/a/g;
    0012: invoke-static {v0}, Lcom/a/a/g;->b(Lcom/a/a/g;)Lcom/sec/chaton/b/b;
    0015: move-result-object v0
    0016: invoke-virtual {v0}, Lcom/sec/chaton/b/b;->show()V
    0019: return-void
    001a: move-exception v0
    001b: const-string v1, 'onPageStarted() \t- Spinner warning.'
    001d: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0020: move-result-object v2
    0021: invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    0024: move-result-object v2
    0025: invoke-static {v1, v2}, Lcom/sec/chaton/util/p;->d(Ljava/lang/String;Ljava/lang/String;)V
    0028: invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V
    002b: goto 0019

  [Virtual Method] onReceivedError(Landroid/webkit/WebView;, I, Ljava/lang/String;, Ljava/lang/String;) -> V
    // registers=7, ins=5, outs=5, insns_size=23
    0000: invoke-super {v2, v3, v4, v5, v6}, Landroid/webkit/WebViewClient;->onReceivedError(Landroid/webkit/WebView;ILjava/lang/String;Ljava/lang/String;)V
    0003: iget v0, v2.Lcom/a/a/k;->a:Lcom/a/a/g;
    0005: invoke-static {v0}, Lcom/a/a/g;->a(Lcom/a/a/g;)Lcom/a/a/e;
    0008: move-result-object v0
    0009: new-instance v1, Lcom/a/a/a;
    000b: invoke-direct {v1, v5, v4, v6}, Lcom/a/a/a;-><init>(Ljava/lang/String;ILjava/lang/String;)V
    000e: invoke-interface {v0, v1}, Lcom/a/a/e;->a(Lcom/a/a/a;)V
    0011: iget v0, v2.Lcom/a/a/k;->a:Lcom/a/a/g;
    0013: invoke-virtual {v0}, Lcom/a/a/g;->dismiss()V
    0016: return-void

  [Virtual Method] shouldOverrideUrlLoading(Landroid/webkit/WebView;, Ljava/lang/String;) -> Z
    // registers=8, ins=3, outs=3, insns_size=139
    0000: const/4 v0, 1
    0001: const-string v1, 'fbconnect://success'
    0003: invoke-virtual {v7, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    0006: move-result v1
    0007: if-eqz v1, 0055
    0009: invoke-static {v7}, Lcom/a/a/m;->b(Ljava/lang/String;)Landroid/os/Bundle;
    000c: move-result-object v2
    000d: const-string v1, 'error'
    000f: invoke-virtual {v2, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    0012: move-result-object v1
    0013: if-nez v1, 001b
    0015: const-string v1, 'error_type'
    0017: invoke-virtual {v2, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    001a: move-result-object v1
    001b: if-nez v1, 002c
    001d: iget v1, v5.Lcom/a/a/k;->a:Lcom/a/a/g;
    001f: invoke-static {v1}, Lcom/a/a/g;->a(Lcom/a/a/g;)Lcom/a/a/e;
    0022: move-result-object v1
    0023: invoke-interface {v1, v2}, Lcom/a/a/e;->a(Landroid/os/Bundle;)V
    0026: iget v1, v5.Lcom/a/a/k;->a:Lcom/a/a/g;
    0028: invoke-virtual {v1}, Lcom/a/a/g;->dismiss()V
    002b: return v0
    002c: const-string v2, 'access_denied'
    002e: invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0031: move-result v2
    0032: if-nez v2, 003c
    0034: const-string v2, 'OAuthAccessDeniedException'
    0036: invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0039: move-result v2
    003a: if-eqz v2, 0046
    003c: iget v1, v5.Lcom/a/a/k;->a:Lcom/a/a/g;
    003e: invoke-static {v1}, Lcom/a/a/g;->a(Lcom/a/a/g;)Lcom/a/a/e;
    0041: move-result-object v1
    0042: invoke-interface {v1}, Lcom/a/a/e;->a()V
    0045: goto 0026
    0046: iget v2, v5.Lcom/a/a/k;->a:Lcom/a/a/g;
    0048: invoke-static {v2}, Lcom/a/a/g;->a(Lcom/a/a/g;)Lcom/a/a/e;
    004b: move-result-object v2
    004c: new-instance v3, Lcom/a/a/f;
    004e: invoke-direct {v3, v1}, Lcom/a/a/f;-><init>(Ljava/lang/String;)V
    0051: invoke-interface {v2, v3}, Lcom/a/a/e;->a(Lcom/a/a/f;)V
    0054: goto 0026
    0055: const-string v1, 'fbconnect://cancel'
    0057: invoke-virtual {v7, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    005a: move-result v1
    005b: if-eqz v1, 006c
    005d: iget v1, v5.Lcom/a/a/k;->a:Lcom/a/a/g;
    005f: invoke-static {v1}, Lcom/a/a/g;->a(Lcom/a/a/g;)Lcom/a/a/e;
    0062: move-result-object v1
    0063: invoke-interface {v1}, Lcom/a/a/e;->a()V
    0066: iget v1, v5.Lcom/a/a/k;->a:Lcom/a/a/g;
    0068: invoke-virtual {v1}, Lcom/a/a/g;->dismiss()V
    006b: goto 002b
    006c: const-string v1, 'touch'
    006e: invoke-virtual {v7, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    0071: move-result v1
    0072: if-eqz v1, 0076
    0074: const/4 v0, 0
    0075: goto 002b
    0076: iget v1, v5.Lcom/a/a/k;->a:Lcom/a/a/g;
    0078: invoke-virtual {v1}, Lcom/a/a/g;->getContext()Landroid/content/Context;
    007b: move-result-object v1
    007c: new-instance v2, Landroid/content/Intent;
    007e: const-string v3, 'android.intent.action.VIEW'
    0080: invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    0083: move-result-object v4
    0084: invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V
    0087: invoke-virtual {v1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    008a: goto 002b