=== CLASS Lcom/a/a/d; (Source: Facebook.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Lcom/a/a/e;
  [Instance Field] a: Lcom/a/a/b;

  [Direct Method] <init>(Lcom/a/a/b;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Lcom/a/a/d;->a:Lcom/a/a/b;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] a() -> V
    // registers=3, ins=1, outs=2, insns_size=17
    0000: const-string v0, 'Facebook-authorize'
    0002: const-string v1, 'Login canceled'
    0004: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0007: iget v0, v2.Lcom/a/a/d;->a:Lcom/a/a/b;
    0009: invoke-static {v0}, Lcom/a/a/b;->a(Lcom/a/a/b;)Lcom/a/a/e;
    000c: move-result-object v0
    000d: invoke-interface {v0}, Lcom/a/a/e;->a()V
    0010: return-void

  [Virtual Method] a(Landroid/os/Bundle;) -> V
    // registers=6, ins=2, outs=3, insns_size=110
    0000: invoke-static {}, Landroid/webkit/CookieSyncManager;->getInstance()Landroid/webkit/CookieSyncManager;
    0003: move-result-object v0
    0004: invoke-virtual {v0}, Landroid/webkit/CookieSyncManager;->sync()V
    0007: iget v0, v4.Lcom/a/a/d;->a:Lcom/a/a/b;
    0009: const-string v1, 'access_token'
    000b: invoke-virtual {v5, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    000e: move-result-object v1
    000f: invoke-virtual {v0, v1}, Lcom/a/a/b;->a(Ljava/lang/String;)V
    0012: iget v0, v4.Lcom/a/a/d;->a:Lcom/a/a/b;
    0014: const-string v1, 'expires_in'
    0016: invoke-virtual {v5, v1}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    0019: move-result-object v1
    001a: invoke-virtual {v0, v1}, Lcom/a/a/b;->b(Ljava/lang/String;)V
    001d: iget v0, v4.Lcom/a/a/d;->a:Lcom/a/a/b;
    001f: invoke-virtual {v0}, Lcom/a/a/b;->a()Z
    0022: move-result v0
    0023: if-eqz v0, 005d
    0025: const-string v0, 'Facebook-authorize'
    0027: new-instance v1, Ljava/lang/StringBuilder;
    0029: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    002c: const-string v2, 'Login Success! access_token='
    002e: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0031: move-result-object v1
    0032: iget v2, v4.Lcom/a/a/d;->a:Lcom/a/a/b;
    0034: invoke-virtual {v2}, Lcom/a/a/b;->b()Ljava/lang/String;
    0037: move-result-object v2
    0038: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003b: move-result-object v1
    003c: const-string v2, ' expires='
    003e: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0041: move-result-object v1
    0042: iget v2, v4.Lcom/a/a/d;->a:Lcom/a/a/b;
    0044: invoke-virtual {v2}, Lcom/a/a/b;->c()J
    0047: move-result-wide v2
    0048: invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    004b: move-result-object v1
    004c: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    004f: move-result-object v1
    0050: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0053: iget v0, v4.Lcom/a/a/d;->a:Lcom/a/a/b;
    0055: invoke-static {v0}, Lcom/a/a/b;->a(Lcom/a/a/b;)Lcom/a/a/e;
    0058: move-result-object v0
    0059: invoke-interface {v0, v5}, Lcom/a/a/e;->a(Landroid/os/Bundle;)V
    005c: return-void
    005d: iget v0, v4.Lcom/a/a/d;->a:Lcom/a/a/b;
    005f: invoke-static {v0}, Lcom/a/a/b;->a(Lcom/a/a/b;)Lcom/a/a/e;
    0062: move-result-object v0
    0063: new-instance v1, Lcom/a/a/f;
    0065: const-string v2, 'Failed to receive access token.'
    0067: invoke-direct {v1, v2}, Lcom/a/a/f;-><init>(Ljava/lang/String;)V
    006a: invoke-interface {v0, v1}, Lcom/a/a/e;->a(Lcom/a/a/f;)V
    006d: goto 005c

  [Virtual Method] a(Lcom/a/a/a;) -> V
    // registers=5, ins=2, outs=2, insns_size=34
    0000: const-string v0, 'Facebook-authorize'
    0002: new-instance v1, Ljava/lang/StringBuilder;
    0004: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0007: const-string v2, 'Login failed: '
    0009: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000c: move-result-object v1
    000d: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0010: move-result-object v1
    0011: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0014: move-result-object v1
    0015: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0018: iget v0, v3.Lcom/a/a/d;->a:Lcom/a/a/b;
    001a: invoke-static {v0}, Lcom/a/a/b;->a(Lcom/a/a/b;)Lcom/a/a/e;
    001d: move-result-object v0
    001e: invoke-interface {v0, v4}, Lcom/a/a/e;->a(Lcom/a/a/a;)V
    0021: return-void

  [Virtual Method] a(Lcom/a/a/f;) -> V
    // registers=5, ins=2, outs=2, insns_size=34
    0000: const-string v0, 'Facebook-authorize'
    0002: new-instance v1, Ljava/lang/StringBuilder;
    0004: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0007: const-string v2, 'Login failed: '
    0009: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000c: move-result-object v1
    000d: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0010: move-result-object v1
    0011: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0014: move-result-object v1
    0015: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0018: iget v0, v3.Lcom/a/a/d;->a:Lcom/a/a/b;
    001a: invoke-static {v0}, Lcom/a/a/b;->a(Lcom/a/a/b;)Lcom/a/a/e;
    001d: move-result-object v0
    001e: invoke-interface {v0, v4}, Lcom/a/a/e;->a(Lcom/a/a/f;)V
    0021: return-void