=== CLASS Lcom/a/a/l; (Source: SessionStore.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] a(Landroid/content/Context;) -> V
    // registers=3, ins=1, outs=3, insns_size=18
    0000: const-string v0, 'facebook-session'
    0002: const/4 v1, 0
    0003: invoke-virtual {v2, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    0006: move-result-object v0
    0007: invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    000a: move-result-object v0
    000b: invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;
    000e: invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    0011: return-void

  [Direct Method] a(Landroid/content/Context;, Ljava/lang/String;) -> Z
    // registers=4, ins=2, outs=3, insns_size=21
    0000: const-string v0, 'facebook-session'
    0002: const/4 v1, 0
    0003: invoke-virtual {v2, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    0006: move-result-object v0
    0007: invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    000a: move-result-object v0
    000b: const-string v1, 'user_name'
    000d: invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    0010: invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    0013: move-result v0
    0014: return v0

  [Direct Method] a(Lcom/a/a/b;, Landroid/content/Context;) -> Z
    // registers=6, ins=2, outs=4, insns_size=34
    0000: const-string v0, 'facebook-session'
    0002: const/4 v1, 0
    0003: invoke-virtual {v5, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    0006: move-result-object v0
    0007: invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    000a: move-result-object v0
    000b: const-string v1, 'access_token'
    000d: invoke-virtual {v4}, Lcom/a/a/b;->b()Ljava/lang/String;
    0010: move-result-object v2
    0011: invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    0014: const-string v1, 'expires_in'
    0016: invoke-virtual {v4}, Lcom/a/a/b;->c()J
    0019: move-result-wide v2
    001a: invoke-interface {v0, v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    001d: invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    0020: move-result v0
    0021: return v0

  [Direct Method] b(Landroid/content/Context;) -> Ljava/lang/String;
    // registers=4, ins=1, outs=3, insns_size=15
    0000: const-string v0, 'facebook-session'
    0002: const/4 v1, 0
    0003: invoke-virtual {v3, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    0006: move-result-object v0
    0007: const-string v1, 'user_name'
    0009: const/4 v2, 0
    000a: invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    000d: move-result-object v0
    000e: return-object v0

  [Direct Method] b(Landroid/content/Context;, Ljava/lang/String;) -> Z
    // registers=4, ins=2, outs=3, insns_size=21
    0000: const-string v0, 'facebook-session'
    0002: const/4 v1, 0
    0003: invoke-virtual {v2, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    0006: move-result-object v0
    0007: invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    000a: move-result-object v0
    000b: const-string v1, 'user_email'
    000d: invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    0010: invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    0013: move-result v0
    0014: return v0

  [Direct Method] b(Lcom/a/a/b;, Landroid/content/Context;) -> Z
    // registers=6, ins=2, outs=4, insns_size=33
    0000: const-string v0, 'facebook-session'
    0002: const/4 v1, 0
    0003: invoke-virtual {v5, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    0006: move-result-object v0
    0007: const-string v1, 'access_token'
    0009: const/4 v2, 0
    000a: invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    000d: move-result-object v1
    000e: invoke-virtual {v4, v1}, Lcom/a/a/b;->a(Ljava/lang/String;)V
    0011: const-string v1, 'expires_in'
    0013: const-wide/16 v2, 0
    0015: invoke-interface {v0, v1, v2, v3}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J
    0018: move-result-wide v0
    0019: invoke-virtual {v4, v0, v1}, Lcom/a/a/b;->a(J)V
    001c: invoke-virtual {v4}, Lcom/a/a/b;->a()Z
    001f: move-result v0
    0020: return v0

  [Direct Method] c(Landroid/content/Context;) -> Ljava/lang/String;
    // registers=4, ins=1, outs=3, insns_size=15
    0000: const-string v0, 'facebook-session'
    0002: const/4 v1, 0
    0003: invoke-virtual {v3, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    0006: move-result-object v0
    0007: const-string v1, 'user_email'
    0009: const/4 v2, 0
    000a: invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    000d: move-result-object v0
    000e: return-object v0