=== CLASS Lcom/a/a/j; (Source: FbDialog.java) ===
  Super: Landroid/widget/LinearLayout;
  [Instance Field] a: Landroid/app/Dialog;

  [Direct Method] <init>(Landroid/content/Context;, Landroid/app/Dialog;) -> V
    // registers=3, ins=3, outs=2, insns_size=6
    0000: invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V
    0003: iput v2, v0.Lcom/a/a/j;->a:Landroid/app/Dialog;
    0005: return-void

  [Virtual Method] onConfigurationChanged(Landroid/content/res/Configuration;) -> V
    // registers=9, ins=2, outs=3, insns_size=75
    0000: const/high16 v6, 1056964608 (0x3f000000)
    0002: invoke-super {v7, v8}, Landroid/widget/LinearLayout;->onConfigurationChanged(Landroid/content/res/Configuration;)V
    0005: iget v0, v7.Lcom/a/a/j;->a:Landroid/app/Dialog;
    0007: invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;
    000a: move-result-object v0
    000b: invoke-virtual {v0}, Landroid/view/Window;->getWindowManager()Landroid/view/WindowManager;
    000e: move-result-object v0
    000f: invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    0012: move-result-object v1
    0013: invoke-virtual {v7}, Lcom/a/a/j;->getContext()Landroid/content/Context;
    0016: move-result-object v0
    0017: invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    001a: move-result-object v0
    001b: invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    001e: move-result-object v0
    001f: iget v2, v0.Landroid/util/DisplayMetrics;->density:F
    0021: iget v0, v8.Landroid/content/res/Configuration;->orientation:I
    0023: const/4 v3, 2
    0024: if-ne v0, v3, 0048
    0026: sget v0, Lcom/a/a/g;->a:[F
    0028: new-instance v3, Landroid/widget/FrameLayout$LayoutParams;
    002a: invoke-virtual {v1}, Landroid/view/Display;->getWidth()I
    002d: move-result v4
    002e: const/4 v5, 0
    002f: aget(op=44) v5, v0[v5]
    0031: binop/2addr(op=c8) v5, v2
    0032: binop/2addr(op=c6) v5, v6
    0033: unop(op=87) v5, v5
    0034: binop/2addr(op=b1) v4, v5
    0035: invoke-virtual {v1}, Landroid/view/Display;->getHeight()I
    0038: move-result v1
    0039: const/4 v5, 1
    003a: aget(op=44) v0, v0[v5]
    003c: binop/2addr(op=c8) v0, v2
    003d: binop/2addr(op=c6) v0, v6
    003e: unop(op=87) v0, v0
    003f: binop(op=91) v0, v1, v0
    0041: invoke-direct {v3, v4, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V
    0044: invoke-virtual {v7, v3}, Lcom/a/a/j;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    0047: return-void
    0048: sget v0, Lcom/a/a/g;->b:[F
    004a: goto 0028