=== CLASS Lcom/a/a/c; (Source: Facebook.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/lang/Runnable;
  [Instance Field] a: Landroid/app/Activity;
  [Instance Field] b: [Ljava/lang/String;
  [Instance Field] c: Lcom/a/a/b;

  [Direct Method] <init>(Lcom/a/a/b;, Landroid/app/Activity;, [Ljava/lang/String;) -> V
    // registers=4, ins=4, outs=1, insns_size=10
    0000: iput v1, v0.Lcom/a/a/c;->c:Lcom/a/a/b;
    0002: iput v2, v0.Lcom/a/a/c;->a:Landroid/app/Activity;
    0004: iput v3, v0.Lcom/a/a/c;->b:[Ljava/lang/String;
    0006: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0009: return-void

  [Virtual Method] run() -> V
    // registers=4, ins=1, outs=3, insns_size=10
    0000: iget v0, v3.Lcom/a/a/c;->c:Lcom/a/a/b;
    0002: iget v1, v3.Lcom/a/a/c;->a:Landroid/app/Activity;
    0004: iget v2, v3.Lcom/a/a/c;->b:[Ljava/lang/String;
    0006: invoke-static {v0, v1, v2}, Lcom/a/a/b;->a(Lcom/a/a/b;Landroid/app/Activity;[Ljava/lang/String;)V
    0009: return-void