=== CLASS Landroid/hardware/motion/MotionRecognitionManager; (Source: MotionRecognitionManager.java) ===
  Super: Ljava/lang/Object;
  [Static Field] ACTION_MOTION_RECOGNITION_EVENT: Ljava/lang/String; = 'android.hardware.motion.MOTION_RECOGNITION_EVENT'
  [Static Field] DEBUG_LEVEL_HIGH: I = 18760
  [Static Field] DEBUG_LEVEL_LOW: I = 20300
  [Static Field] DEBUG_LEVEL_MID: I = 18765
  [Static Field] EVENT_ALL: I = 1048575
  [Static Field] EVENT_CALL_POSE: I = 262144
  [Static Field] EVENT_DIRECT_CALLING: I = 1024
  [Static Field] EVENT_DOUBLE_TAP: I = 8
  [Static Field] EVENT_FLAT: I = 8192
  [Static Field] EVENT_LCD_UP_STEADY: I = 65536
  [Static Field] EVENT_LOCK_EXECUTE_L: I = 128
  [Static Field] EVENT_LOCK_EXECUTE_R: I = 256
  [Static Field] EVENT_NUM: I = 20
  [Static Field] EVENT_OVER_TURN: I = 1
  [Static Field] EVENT_OVER_TURN_LOW_POWER: I = 131072
  [Static Field] EVENT_PANNING_GALLERY: I = 32
  [Static Field] EVENT_PANNING_HOME: I = 64
  [Static Field] EVENT_REACTIVE_ALERT: I = 4
  [Static Field] EVENT_SHAKE: I = 2
  [Static Field] EVENT_SMART_ALERT_SETTING: I = 32768
  [Static Field] EVENT_SMART_SCROLL: I = 524288
  [Static Field] EVENT_TILT: I = 16
  [Static Field] EVENT_TILT_LEVEL_ZERO: I = 4096
  [Static Field] EVENT_TILT_LEVEL_ZERO_LAND: I = 16384
  [Static Field] EVENT_TILT_TO_UNLOCK: I = 2048
  [Static Field] EVENT_VOLUME_DOWN: I = 512
  [Static Field] MOTION_SENSOR_NUM: I = 4
  [Static Field] MOTION_USE_ACC: I = 1
  [Static Field] MOTION_USE_ALL: I = 31
  [Static Field] MOTION_USE_GYRO: I = 2
  [Static Field] MOTION_USE_LIGHT: I = 8
  [Static Field] MOTION_USE_MOVEMENT: I = 16
  [Static Field] MOTION_USE_PROX: I = 4
  [Static Field] TAG: Ljava/lang/String; = 'MotionRecognitionManager'
  [Static Field] localLOGV: Z = False
  [Static Field] mMotionVersion: I = 1
  [Instance Field] mMainLooper: Landroid/os/Looper;
  [Instance Field] mMovementCnt: I
  [Instance Field] mSContextManager: Landroid/hardware/scontext/SContextManager;
  [Instance Field] mSSPEnabled: Z
  [Instance Field] motionService: Landroid/hardware/motion/IMotionRecognitionService;
  [Instance Field] mySContextMotionListener: Landroid/hardware/scontext/SContextListener;
  [Instance Field] sListenerDelegates: Ljava/util/ArrayList;
  [Instance Field] sListenerwithSSP: Ljava/util/ArrayList;

  [Direct Method] <init>(Landroid/os/Looper;) -> V
    // registers=5, ins=2, outs=3, insns_size=68
    0000: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Ljava/util/ArrayList;
    0005: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0008: iput v0, v3.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    000a: new-instance v0, Ljava/util/ArrayList;
    000c: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    000f: iput v0, v3.Landroid/hardware/motion/MotionRecognitionManager;->sListenerwithSSP:Ljava/util/ArrayList;
    0011: new-instance v0, Landroid/hardware/motion/MotionRecognitionManager$1;
    0013: invoke-direct {v0, v3}, Landroid/hardware/motion/MotionRecognitionManager$1;-><init>(Landroid/hardware/motion/MotionRecognitionManager;)V
    0016: iput v0, v3.Landroid/hardware/motion/MotionRecognitionManager;->mySContextMotionListener:Landroid/hardware/scontext/SContextListener;
    0018: const-string v0, 'motion_recognition'
    001a: invoke-static {v0}, Landroid/os/ServiceManager;->getService(Ljava/lang/String;)Landroid/os/IBinder;
    001d: move-result-object v0
    001e: invoke-static {v0}, Landroid/hardware/motion/IMotionRecognitionService$Stub;->asInterface(Landroid/os/IBinder;)Landroid/hardware/motion/IMotionRecognitionService;
    0021: move-result-object v0
    0022: iput v0, v3.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    0024: iput v4, v3.Landroid/hardware/motion/MotionRecognitionManager;->mMainLooper:Landroid/os/Looper;
    0026: new-instance v0, Landroid/hardware/scontext/SContextManager;
    0028: iget v1, v3.Landroid/hardware/motion/MotionRecognitionManager;->mMainLooper:Landroid/os/Looper;
    002a: invoke-direct {v0, v1}, Landroid/hardware/scontext/SContextManager;-><init>(Landroid/os/Looper;)V
    002d: iput v0, v3.Landroid/hardware/motion/MotionRecognitionManager;->mSContextManager:Landroid/hardware/scontext/SContextManager;
    002f: const/4 v0, 0
    0030: iput v0, v3.Landroid/hardware/motion/MotionRecognitionManager;->mMovementCnt:I
    0032: iget v0, v3.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    0034: invoke-interface {v0}, Landroid/hardware/motion/IMotionRecognitionService;->getSSPstatus()Z
    0037: move-result v0
    0038: iput v0, v3.Landroid/hardware/motion/MotionRecognitionManager;->mSSPEnabled:Z
    003a: return-void
    003b: move-exception v0
    003c: const-string v1, 'MotionRecognitionManager'
    003e: const-string v2, 'RemoteException in getSSPstatus: '
    0040: invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    0043: goto 003a

  [Direct Method] EncodeLog(Ljava/lang/String;) -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=52
    0000: const-string v0, 'ro.debug_level'
    0002: const-string v1, 'Unknown'
    0004: invoke-static {v0, v1}, Landroid/os/SystemProperties;->get(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    0007: move-result-object v0
    0008: const-string v1, 'Unknown'
    000a: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    000d: move-result v1
    000e: if-eqz v1, 0013
    0010: const-string v2, ' '
    0012: return-object v2
    0013: const/4 v1, 2
    0014: invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    0017: move-result-object v0
    0018: const/16 v1, 16 (0x10)
    001a: invoke-static {v0, v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I
    001d: move-result v0
    001e: const/16 v1, 20300 (0x4f4c)
    0020: if-ne v0, v1, 0029
    0022: const-string v2, ' '
    0024: goto 0012
    0025: move-exception v0
    0026: const-string v2, ' '
    0028: goto 0012
    0029: const/16 v1, 18765 (0x494d)
    002b: if-eq v0, v1, 0012
    002d: const/16 v1, 18760 (0x4948)
    002f: if-eq v0, v1, 0012
    0031: const-string v2, ' '
    0033: goto 0012

  [Direct Method] access$000(Landroid/hardware/motion/MotionRecognitionManager;) -> Landroid/hardware/motion/IMotionRecognitionService;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    0002: return-object v0

  [Direct Method] access$100(Landroid/hardware/motion/MotionRecognitionManager;) -> Ljava/util/ArrayList;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    0002: return-object v0

  [Direct Method] getMotionVersion() -> I
    // registers=1, ins=0, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Direct Method] isValidMotionSensor(I) -> Z
    // registers=3, ins=1, outs=0, insns_size=16
    0000: const/4 v0, 1
    0001: if-eq v2, v0, 000d
    0003: const/4 v1, 2
    0004: if-eq v2, v1, 000d
    0006: const/4 v1, 4
    0007: if-eq v2, v1, 000d
    0009: const/16 v1, 8 (0x8)
    000b: if-ne v2, v1, 000e
    000d: return v0
    000e: const/4 v0, 0
    000f: goto 000d

  [Virtual Method] registerListener(Landroid/hardware/motion/MRListener;) -> V
    // registers=4, ins=2, outs=4, insns_size=6
    0000: const/4 v0, 0
    0001: const/4 v1, 0
    0002: invoke-virtual {v2, v3, v0, v1}, Landroid/hardware/motion/MotionRecognitionManager;->registerListener(Landroid/hardware/motion/MRListener;ILandroid/os/Handler;)V
    0005: return-void

  [Virtual Method] registerListener(Landroid/hardware/motion/MRListener;, I) -> V
    // registers=4, ins=3, outs=4, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v3, v0}, Landroid/hardware/motion/MotionRecognitionManager;->registerListener(Landroid/hardware/motion/MRListener;ILandroid/os/Handler;)V
    0004: return-void

  [Virtual Method] registerListener(Landroid/hardware/motion/MRListener;, I, Landroid/os/Handler;) -> V
    // registers=6, ins=4, outs=4, insns_size=24
    0000: const/4 v0, 0
    0001: binop/lit8(op=dd) v1, v4, 1 (0x1)
    0003: if-eqz v1, 0008
    0005: const v0, 237570 (0x3a002)
    0008: binop/lit8(op=dd) v1, v4, 2 (0x2)
    000a: if-eqz v1, 000e
    000c: binop/lit16(op=d6) v0, v0, 20985 (0x51f9)
    000e: binop/lit8(op=dd) v1, v4, 4 (0x4)
    0010: if-eqz v1, 0014
    0012: binop/lit16(op=d6) v0, v0, 3072 (0xc00)
    0014: invoke-virtual {v2, v3, v0, v5}, Landroid/hardware/motion/MotionRecognitionManager;->registerListenerEvent(Landroid/hardware/motion/MRListener;ILandroid/os/Handler;)V
    0017: return-void

  [Virtual Method] registerListener(Landroid/hardware/motion/MRListener;, Landroid/os/Handler;) -> V
    // registers=4, ins=3, outs=4, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0, v3}, Landroid/hardware/motion/MotionRecognitionManager;->registerListener(Landroid/hardware/motion/MRListener;ILandroid/os/Handler;)V
    0004: return-void

  [Virtual Method] registerListenerEvent(Landroid/hardware/motion/MRListener;, I) -> V
    // registers=4, ins=3, outs=4, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v3, v0}, Landroid/hardware/motion/MotionRecognitionManager;->registerListenerEvent(Landroid/hardware/motion/MRListener;ILandroid/os/Handler;)V
    0004: return-void

  [Virtual Method] registerListenerEvent(Landroid/hardware/motion/MRListener;, I, Landroid/os/Handler;) -> V
    // registers=10, ins=4, outs=5, insns_size=311
    0000: const/4 v0, 0
    0001: if-eqz v7, 005d
    0003: iget v2, v6.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    0005: monitor-enter v2
    0006: iget v1, v6.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    0008: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    000b: move-result v3
    000c: move(op=01) v1, v0
    000d: if-ge v1, v3, 0062
    000f: iget v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    0011: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0014: move-result-object v0
    0015: check-cast v0, Landroid/hardware/motion/MotionRecognitionManager$MRListenerDelegate;
    0017: invoke-virtual {v0}, Landroid/hardware/motion/MotionRecognitionManager$MRListenerDelegate;->getListener()Landroid/hardware/motion/MRListener;
    001a: move-result-object v0
    001b: if-ne v0, v7, 005e
    001d: new-instance v0, Ljava/lang/StringBuilder;
    001f: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0022: const-string v1, 'name :'
    0024: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0027: move-result-object v0
    0028: invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    002b: move-result-object v0
    002c: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002f: move-result-object v0
    0030: invoke-static {v0}, Landroid/hardware/motion/MotionRecognitionManager;->EncodeLog(Ljava/lang/String;)Ljava/lang/String;
    0033: move-result-object v0
    0034: const-string v1, 'MotionRecognitionManager'
    0036: new-instance v3, Ljava/lang/StringBuilder;
    0038: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    003b: const-string v4, '  .registerListenerEvent : fail. already registered / listener count = '
    003d: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0040: move-result-object v3
    0041: iget v4, v6.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    0043: invoke-virtual {v4}, Ljava/util/ArrayList;->size()I
    0046: move-result v4
    0047: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    004a: move-result-object v3
    004b: const-string v4, ', '
    004d: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0050: move-result-object v3
    0051: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0054: move-result-object v0
    0055: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0058: move-result-object v0
    0059: invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    005c: monitor-exit v2
    005d: return-void
    005e: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0060: move(op=01) v1, v0
    0061: goto 000d
    0062: new-instance v1, Landroid/hardware/motion/MotionRecognitionManager$MRListenerDelegate;
    0064: invoke-direct {v1, v6, v7, v8, v9}, Landroid/hardware/motion/MotionRecognitionManager$MRListenerDelegate;-><init>(Landroid/hardware/motion/MotionRecognitionManager;Landroid/hardware/motion/MRListener;ILandroid/os/Handler;)V
    0067: iget v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    0069: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    006c: binop/lit8(op=dd) v0, v8, 4 (0x4)
    006e: if-eqz v0, 012f
    0070: iget v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->mSSPEnabled:Z
    0072: const/4 v4, 1
    0073: if-ne v0, v4, 00fc
    0075: iget v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->mySContextMotionListener:Landroid/hardware/scontext/SContextListener;
    0077: if-eqz v0, 00eb
    0079: iget v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->mMovementCnt:I
    007b: if-nez v0, 00eb
    007d: const-string v0, 'MotionRecognitionManager'
    007f: const-string v1, ' [MOVEMENT_SERVICE] registerListener '
    0081: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0084: iget v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->mSContextManager:Landroid/hardware/scontext/SContextManager;
    0086: iget v1, v6.Landroid/hardware/motion/MotionRecognitionManager;->mySContextMotionListener:Landroid/hardware/scontext/SContextListener;
    0088: const/4 v4, 5
    0089: invoke-virtual {v0, v1, v4}, Landroid/hardware/scontext/SContextManager;->registerListener(Landroid/hardware/scontext/SContextListener;I)Z
    008c: iget v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->mMovementCnt:I
    008e: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0090: iput v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->mMovementCnt:I
    0092: new-instance v0, Ljava/lang/StringBuilder;
    0094: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0097: const-string v1, 'name :'
    0099: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    009c: move-result-object v0
    009d: invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00a0: move-result-object v0
    00a1: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00a4: move-result-object v0
    00a5: invoke-static {v0}, Landroid/hardware/motion/MotionRecognitionManager;->EncodeLog(Ljava/lang/String;)Ljava/lang/String;
    00a8: move-result-object v0
    00a9: const-string v1, 'MotionRecognitionManager'
    00ab: new-instance v4, Ljava/lang/StringBuilder;
    00ad: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    00b0: const-string v5, '  .registerListenerEvent : success. listener count = '
    00b2: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00b5: move-result-object v4
    00b6: invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    00b9: move-result-object v3
    00ba: const-string v4, '->'
    00bc: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00bf: move-result-object v3
    00c0: iget v4, v6.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    00c2: invoke-virtual {v4}, Ljava/util/ArrayList;->size()I
    00c5: move-result v4
    00c6: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    00c9: move-result-object v3
    00ca: const-string v4, ', motion_events='
    00cc: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00cf: move-result-object v3
    00d0: invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    00d3: move-result-object v3
    00d4: const-string v4, ', '
    00d6: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00d9: move-result-object v3
    00da: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00dd: move-result-object v0
    00de: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00e1: move-result-object v0
    00e2: invoke-static {v1, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00e5: monitor-exit v2
    00e6: goto/16 005d
    00e8: move-exception v0
    00e9: monitor-exit v2
    00ea: throw v0
    00eb: const-string v0, 'MotionRecognitionManager'
    00ed: const-string v1, ' [MOVEMENT_SERVICE] registerListener : fail. already registered '
    00ef: invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    00f2: goto 008c
    00f3: move-exception v0
    00f4: const-string v1, 'MotionRecognitionManager'
    00f6: const-string v4, 'RemoteException in registerListenerEvent: '
    00f8: invoke-static {v1, v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    00fb: goto 0092
    00fc: iget v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    00fe: invoke-interface {v0}, Landroid/hardware/motion/IMotionRecognitionService;->getSSPstatus()Z
    0101: move-result v0
    0102: iput v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->mSSPEnabled:Z
    0104: const-string v0, 'MotionRecognitionManager'
    0106: new-instance v4, Ljava/lang/StringBuilder;
    0108: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    010b: const-string v5, 'SSP disabled : '
    010d: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0110: move-result-object v4
    0111: iget v5, v6.Landroid/hardware/motion/MotionRecognitionManager;->mSSPEnabled:Z
    0113: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0116: move-result-object v4
    0117: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    011a: move-result-object v4
    011b: invoke-static {v0, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    011e: iget v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    0120: const/4 v4, 0
    0121: invoke-interface {v0, v1, v4, v8}, Landroid/hardware/motion/IMotionRecognitionService;->registerCallback(Landroid/os/IBinder;II)V
    0124: goto/16 0092
    0126: move-exception v0
    0127: const-string v4, 'MotionRecognitionManager'
    0129: const-string v5, 'RemoteException in getSSPstatus: '
    012b: invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    012e: goto 0104
    012f: iget v0, v6.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    0131: const/4 v4, 0
    0132: invoke-interface {v0, v1, v4, v8}, Landroid/hardware/motion/IMotionRecognitionService;->registerCallback(Landroid/os/IBinder;II)V
    0135: goto/16 0092

  [Virtual Method] resetMotionEngine() -> I
    // registers=4, ins=1, outs=3, insns_size=17
    0000: iget v0, v3.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    0002: invoke-interface {v0}, Landroid/hardware/motion/IMotionRecognitionService;->resetMotionEngine()I
    0005: move-result v0
    0006: return v0
    0007: move-exception v0
    0008: const-string v1, 'MotionRecognitionManager'
    000a: const-string v2, 'RemoteException in resetMotionEngine: '
    000c: invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    000f: const/4 v0, 0
    0010: goto 0006

  [Virtual Method] setLogPath(Ljava/lang/String;) -> V
    // registers=5, ins=2, outs=3, insns_size=15
    0000: iget v0, v3.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    0002: invoke-interface {v0, v4}, Landroid/hardware/motion/IMotionRecognitionService;->setLogPath(Ljava/lang/String;)V
    0005: return-void
    0006: move-exception v0
    0007: const-string v1, 'MotionRecognitionManager'
    0009: const-string v2, 'RemoteException in setLogPath: '
    000b: invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    000e: goto 0005

  [Virtual Method] setMotionAngle(Landroid/hardware/motion/MRListener;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setMotionTiltLevel(I, I, I, I, I, I) -> V
    // registers=14, ins=7, outs=7, insns_size=28
    0000: iget v0, v7.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    0002: move(op=01) v1, v8
    0003: move(op=01) v2, v9
    0004: move(op=01) v3, v10
    0005: move(op=01) v4, v11
    0006: move(op=01) v5, v12
    0007: move(op=01) v6, v13
    0008: invoke-interface/range {v0..v6}, Landroid/hardware/motion/IMotionRecognitionService;->setMotionTiltLevel(IIIIII)V
    000b: const-string v0, 'MotionRecognitionManager'
    000d: const-string v1, '  .setMotionTiltLevel : 1'
    000f: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0012: return-void
    0013: move-exception v0
    0014: const-string v1, 'MotionRecognitionManager'
    0016: const-string v2, 'RemoteException in setMotionTiltLevel: '
    0018: invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    001b: goto 000b

  [Virtual Method] setSmartMotionAngle(Landroid/hardware/motion/MRListener;, I) -> V
    // registers=8, ins=3, outs=3, insns_size=59
    0000: iget v2, v5.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    0002: monitor-enter v2
    0003: iget v0, v5.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    0005: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0008: move-result v3
    0009: const/4 v0, 0
    000a: move(op=01) v1, v0
    000b: if-ge v1, v3, 0032
    000d: iget v0, v5.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    000f: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0012: move-result-object v0
    0013: check-cast v0, Landroid/hardware/motion/MotionRecognitionManager$MRListenerDelegate;
    0015: invoke-virtual {v0}, Landroid/hardware/motion/MotionRecognitionManager$MRListenerDelegate;->getListener()Landroid/hardware/motion/MRListener;
    0018: move-result-object v4
    0019: if-ne v4, v6, 002e
    001b: iget v1, v5.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    001d: invoke-interface {v1, v0, v7}, Landroid/hardware/motion/IMotionRecognitionService;->setMotionAngle(Landroid/os/IBinder;I)V
    0020: monitor-exit v2
    0021: return-void
    0022: move-exception v0
    0023: const-string v1, 'MotionRecognitionManager'
    0025: const-string v3, 'RemoteException in setSmartMotionAngle: '
    0027: invoke-static {v1, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    002a: goto 0020
    002b: move-exception v0
    002c: monitor-exit v2
    002d: throw v0
    002e: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0030: move(op=01) v1, v0
    0031: goto 000b
    0032: const-string v0, 'MotionRecognitionManager'
    0034: const-string v1, '  .setSmartMotionAngle : listener has to be registered first'
    0036: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0039: monitor-exit v2
    003a: goto 0021

  [Virtual Method] unregisterListener(Landroid/hardware/motion/MRListener;) -> V
    // registers=10, ins=2, outs=3, insns_size=305
    0000: const/4 v1, 0
    0001: iget v3, v8.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    0003: monitor-enter v3
    0004: iget v0, v8.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    0006: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0009: move-result v4
    000a: move(op=01) v2, v1
    000b: if-ge v2, v4, 004a
    000d: iget v0, v8.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    000f: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0012: move-result-object v0
    0013: check-cast v0, Landroid/hardware/motion/MotionRecognitionManager$MRListenerDelegate;
    0015: invoke-virtual {v0}, Landroid/hardware/motion/MotionRecognitionManager$MRListenerDelegate;->getListener()Landroid/hardware/motion/MRListener;
    0018: move-result-object v0
    0019: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    001c: move-result-object v0
    001d: const-string v5, 'MotionRecognitionManager'
    001f: new-instance v6, Ljava/lang/StringBuilder;
    0021: invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V
    0024: const-string v7, '@benjamin@buzzz.local'
    0026: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0029: move-result-object v6
    002a: invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    002d: move-result-object v6
    002e: const-string v7, ' = '
    0030: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0033: move-result-object v6
    0034: invoke-static {v0}, Landroid/hardware/motion/MotionRecognitionManager;->EncodeLog(Ljava/lang/String;)Ljava/lang/String;
    0037: move-result-object v0
    0038: invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003b: move-result-object v0
    003c: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    003f: move-result-object v0
    0040: invoke-static {v5, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0043: binop/lit8(op=d8) v0, v2, 1 (0x1)
    0045: move(op=01) v2, v0
    0046: goto 000b
    0047: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0049: move(op=01) v1, v0
    004a: if-ge v1, v4, 00a2
    004c: iget v0, v8.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    004e: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0051: move-result-object v0
    0052: check-cast v0, Landroid/hardware/motion/MotionRecognitionManager$MRListenerDelegate;
    0054: invoke-virtual {v0}, Landroid/hardware/motion/MotionRecognitionManager$MRListenerDelegate;->getListener()Landroid/hardware/motion/MRListener;
    0057: move-result-object v2
    0058: if-ne v2, v9, 0047
    005a: iget v2, v8.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    005c: invoke-virtual {v2, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    005f: invoke-virtual {v0}, Landroid/hardware/motion/MotionRecognitionManager$MRListenerDelegate;->getMotionEvents()I
    0062: move-result v1
    0063: binop/lit8(op=dd) v1, v1, 4 (0x4)
    0065: if-eqz v1, 012a
    0067: iget v1, v8.Landroid/hardware/motion/MotionRecognitionManager;->mSSPEnabled:Z
    0069: const/4 v2, 1
    006a: if-ne v1, v2, 00ed
    006c: iget v0, v8.Landroid/hardware/motion/MotionRecognitionManager;->mMovementCnt:I
    006e: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0070: iput v0, v8.Landroid/hardware/motion/MotionRecognitionManager;->mMovementCnt:I
    0072: iget v0, v8.Landroid/hardware/motion/MotionRecognitionManager;->mMovementCnt:I
    0074: if-gtz v0, 0088
    0076: const-string v0, 'MotionRecognitionManager'
    0078: const-string v1, ' [MOVEMENT_SERVICE] unregisterListener '
    007a: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    007d: const/4 v0, 0
    007e: iput v0, v8.Landroid/hardware/motion/MotionRecognitionManager;->mMovementCnt:I
    0080: iget v0, v8.Landroid/hardware/motion/MotionRecognitionManager;->mSContextManager:Landroid/hardware/scontext/SContextManager;
    0082: iget v1, v8.Landroid/hardware/motion/MotionRecognitionManager;->mySContextMotionListener:Landroid/hardware/scontext/SContextListener;
    0084: const/4 v2, 5
    0085: invoke-virtual {v0, v1, v2}, Landroid/hardware/scontext/SContextManager;->unregisterListener(Landroid/hardware/scontext/SContextListener;I)V
    0088: const-string v0, 'MotionRecognitionManager'
    008a: new-instance v1, Ljava/lang/StringBuilder;
    008c: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    008f: const-string v2, 'unregisterListener - mMovementCnt : '
    0091: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0094: move-result-object v1
    0095: iget v2, v8.Landroid/hardware/motion/MotionRecognitionManager;->mMovementCnt:I
    0097: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    009a: move-result-object v1
    009b: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    009e: move-result-object v1
    009f: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    00a2: new-instance v0, Ljava/lang/StringBuilder;
    00a4: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    00a7: const-string v1, 'name :'
    00a9: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00ac: move-result-object v0
    00ad: invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00b0: move-result-object v0
    00b1: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00b4: move-result-object v0
    00b5: invoke-static {v0}, Landroid/hardware/motion/MotionRecognitionManager;->EncodeLog(Ljava/lang/String;)Ljava/lang/String;
    00b8: move-result-object v0
    00b9: const-string v1, 'MotionRecognitionManager'
    00bb: new-instance v2, Ljava/lang/StringBuilder;
    00bd: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    00c0: const-string v5, '  .unregisterListener : / listener count = '
    00c2: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00c5: move-result-object v2
    00c6: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    00c9: move-result-object v2
    00ca: const-string v4, '->'
    00cc: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00cf: move-result-object v2
    00d0: iget v4, v8.Landroid/hardware/motion/MotionRecognitionManager;->sListenerDelegates:Ljava/util/ArrayList;
    00d2: invoke-virtual {v4}, Ljava/util/ArrayList;->size()I
    00d5: move-result v4
    00d6: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    00d9: move-result-object v2
    00da: const-string v4, ', '
    00dc: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00df: move-result-object v2
    00e0: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00e3: move-result-object v0
    00e4: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00e7: move-result-object v0
    00e8: invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    00eb: monitor-exit v3
    00ec: return-void
    00ed: iget v1, v8.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    00ef: invoke-interface {v1}, Landroid/hardware/motion/IMotionRecognitionService;->getSSPstatus()Z
    00f2: move-result v1
    00f3: iput v1, v8.Landroid/hardware/motion/MotionRecognitionManager;->mSSPEnabled:Z
    00f5: const-string v1, 'MotionRecognitionManager'
    00f7: new-instance v2, Ljava/lang/StringBuilder;
    00f9: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    00fc: const-string v5, 'SSP disabled : '
    00fe: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0101: move-result-object v2
    0102: iget v5, v8.Landroid/hardware/motion/MotionRecognitionManager;->mSSPEnabled:Z
    0104: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;
    0107: move-result-object v2
    0108: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    010b: move-result-object v2
    010c: invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    010f: iget v1, v8.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    0111: invoke-interface {v1, v0}, Landroid/hardware/motion/IMotionRecognitionService;->unregisterCallback(Landroid/os/IBinder;)V
    0114: goto 00a2
    0115: move-exception v0
    0116: const-string v1, 'MotionRecognitionManager'
    0118: const-string v2, 'RemoteException in unregisterListener: '
    011a: invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    011d: goto 00a2
    011e: move-exception v0
    011f: monitor-exit v3
    0120: throw v0
    0121: move-exception v1
    0122: const-string v2, 'MotionRecognitionManager'
    0124: const-string v5, 'RemoteException in getSSPstatus: '
    0126: invoke-static {v2, v5, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    0129: goto 00f5
    012a: iget v1, v8.Landroid/hardware/motion/MotionRecognitionManager;->motionService:Landroid/hardware/motion/IMotionRecognitionService;
    012c: invoke-interface {v1, v0}, Landroid/hardware/motion/IMotionRecognitionService;->unregisterCallback(Landroid/os/IBinder;)V
    012f: goto/16 00a2

  [Virtual Method] useMotionAlways(Landroid/hardware/motion/MRListener;, Z) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void