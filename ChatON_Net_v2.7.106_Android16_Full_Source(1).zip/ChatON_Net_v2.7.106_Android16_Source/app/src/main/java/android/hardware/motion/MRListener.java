=== CLASS Landroid/hardware/motion/MRListener; (Source: MRListener.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] onMotionListener(Landroid/hardware/motion/MREvent;) -> V