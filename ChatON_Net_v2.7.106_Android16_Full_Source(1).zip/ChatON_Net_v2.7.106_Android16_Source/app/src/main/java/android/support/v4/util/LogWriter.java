=== CLASS Landroid/support/v4/util/LogWriter; (Source: LogWriter.java) ===
  Super: Ljava/io/Writer;
  [Instance Field] mBuilder: Ljava/lang/StringBuilder;
  [Instance Field] mTag: Ljava/lang/String;

  [Direct Method] <init>(Ljava/lang/String;) -> V
    // registers=4, ins=2, outs=2, insns_size=15
    0000: invoke-direct {v2}, Ljava/io/Writer;-><init>()V
    0003: new-instance v0, Ljava/lang/StringBuilder;
    0005: const/16 v1, 128 (0x80)
    0007: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V
    000a: iput v0, v2.Landroid/support/v4/util/LogWriter;->mBuilder:Ljava/lang/StringBuilder;
    000c: iput v3, v2.Landroid/support/v4/util/LogWriter;->mTag:Ljava/lang/String;
    000e: return-void

  [Direct Method] flushBuilder() -> V
    // registers=4, ins=1, outs=3, insns_size=32
    0000: iget v0, v3.Landroid/support/v4/util/LogWriter;->mBuilder:Ljava/lang/StringBuilder;
    0002: invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I
    0005: move-result v0
    0006: if-lez v0, 001f
    0008: iget v0, v3.Landroid/support/v4/util/LogWriter;->mTag:Ljava/lang/String;
    000a: iget v1, v3.Landroid/support/v4/util/LogWriter;->mBuilder:Ljava/lang/StringBuilder;
    000c: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    000f: move-result-object v1
    0010: invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    0013: iget v0, v3.Landroid/support/v4/util/LogWriter;->mBuilder:Ljava/lang/StringBuilder;
    0015: const/4 v1, 0
    0016: iget v2, v3.Landroid/support/v4/util/LogWriter;->mBuilder:Ljava/lang/StringBuilder;
    0018: invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I
    001b: move-result v2
    001c: invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->delete(II)Ljava/lang/StringBuilder;
    001f: return-void

  [Virtual Method] close() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/util/LogWriter;->flushBuilder()V
    0003: return-void

  [Virtual Method] flush() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/util/LogWriter;->flushBuilder()V
    0003: return-void

  [Virtual Method] write([C, I, I) -> V
    // registers=7, ins=4, outs=2, insns_size=24
    0000: const/4 v0, 0
    0001: if-ge v0, v6, 0017
    0003: binop(op=90) v1, v5, v0
    0005: aget(op=49) v1, v4[v1]
    0007: const/16 v2, 10 (0xa)
    0009: if-ne v1, v2, 0011
    000b: invoke-direct {v3}, Landroid/support/v4/util/LogWriter;->flushBuilder()V
    000e: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0010: goto 0001
    0011: iget v2, v3.Landroid/support/v4/util/LogWriter;->mBuilder:Ljava/lang/StringBuilder;
    0013: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    0016: goto 000e
    0017: return-void