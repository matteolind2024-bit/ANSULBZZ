=== CLASS Landroid/support/v4/app/FragmentPagerAdapter; (Source: FragmentPagerAdapter.java) ===
  Super: Landroid/support/v4/view/PagerAdapter;
  [Static Field] DEBUG: Z = False
  [Static Field] TAG: Ljava/lang/String; = 'FragmentPagerAdapter'
  [Instance Field] mCurTransaction: Landroid/support/v4/app/FragmentTransaction;
  [Instance Field] mCurrentPrimaryItem: Landroid/support/v4/app/Fragment;
  [Instance Field] mFragmentManager: Landroid/support/v4/app/FragmentManager;

  [Direct Method] <init>(Landroid/support/v4/app/FragmentManager;) -> V
    // registers=3, ins=2, outs=1, insns_size=11
    0000: const/4 v0, 0
    0001: invoke-direct {v1}, Landroid/support/v4/view/PagerAdapter;-><init>()V
    0004: iput v0, v1.Landroid/support/v4/app/FragmentPagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0006: iput v0, v1.Landroid/support/v4/app/FragmentPagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    0008: iput v2, v1.Landroid/support/v4/app/FragmentPagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    000a: return-void

  [Direct Method] makeFragmentName(I, J) -> Ljava/lang/String;
    // registers=5, ins=3, outs=3, insns_size=30
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0005: const-string v1, 'android:switcher:'
    0007: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000a: move-result-object v0
    000b: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    000e: move-result-object v0
    000f: const-string v1, ':'
    0011: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0014: move-result-object v0
    0015: invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    0018: move-result-object v0
    0019: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001c: move-result-object v0
    001d: return-object v0

  [Virtual Method] destroyItem(Landroid/view/ViewGroup;, I, Ljava/lang/Object;) -> V
    // registers=5, ins=4, outs=2, insns_size=20
    0000: iget v0, v1.Landroid/support/v4/app/FragmentPagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0002: if-nez v0, 000c
    0004: iget v0, v1.Landroid/support/v4/app/FragmentPagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    0006: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManager;->beginTransaction()Landroid/support/v4/app/FragmentTransaction;
    0009: move-result-object v0
    000a: iput v0, v1.Landroid/support/v4/app/FragmentPagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    000c: iget v0, v1.Landroid/support/v4/app/FragmentPagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    000e: check-cast v4, Landroid/support/v4/app/Fragment;
    0010: invoke-virtual {v0, v4}, Landroid/support/v4/app/FragmentTransaction;->detach(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/FragmentTransaction;
    0013: return-void

  [Virtual Method] finishUpdate(Landroid/view/ViewGroup;) -> V
    // registers=3, ins=2, outs=1, insns_size=18
    0000: iget v0, v1.Landroid/support/v4/app/FragmentPagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0002: if-eqz v0, 0011
    0004: iget v0, v1.Landroid/support/v4/app/FragmentPagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0006: invoke-virtual {v0}, Landroid/support/v4/app/FragmentTransaction;->commitAllowingStateLoss()I
    0009: const/4 v0, 0
    000a: iput v0, v1.Landroid/support/v4/app/FragmentPagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    000c: iget v0, v1.Landroid/support/v4/app/FragmentPagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    000e: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManager;->executePendingTransactions()Z
    0011: return-void

  [Virtual Method] getItem(I) -> Landroid/support/v4/app/Fragment;

  [Virtual Method] getItemId(I) -> J
    // registers=4, ins=2, outs=0, insns_size=2
    0000: unop(op=81) v0, v3
    0001: return-wide v0

  [Virtual Method] instantiateItem(Landroid/view/ViewGroup;, I) -> Ljava/lang/Object;
    // registers=10, ins=3, outs=4, insns_size=71
    0000: const/4 v6, 0
    0001: iget v0, v7.Landroid/support/v4/app/FragmentPagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0003: if-nez v0, 000d
    0005: iget v0, v7.Landroid/support/v4/app/FragmentPagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    0007: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManager;->beginTransaction()Landroid/support/v4/app/FragmentTransaction;
    000a: move-result-object v0
    000b: iput v0, v7.Landroid/support/v4/app/FragmentPagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    000d: invoke-virtual {v7, v9}, Landroid/support/v4/app/FragmentPagerAdapter;->getItemId(I)J
    0010: move-result-wide v1
    0011: invoke-virtual {v8}, Landroid/view/ViewGroup;->getId()I
    0014: move-result v0
    0015: invoke-static {v0, v1, v2}, Landroid/support/v4/app/FragmentPagerAdapter;->makeFragmentName(IJ)Ljava/lang/String;
    0018: move-result-object v0
    0019: iget v3, v7.Landroid/support/v4/app/FragmentPagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    001b: invoke-virtual {v3, v0}, Landroid/support/v4/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    001e: move-result-object v0
    001f: if-eqz v0, 0031
    0021: iget v1, v7.Landroid/support/v4/app/FragmentPagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0023: invoke-virtual {v1, v0}, Landroid/support/v4/app/FragmentTransaction;->attach(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/FragmentTransaction;
    0026: iget v1, v7.Landroid/support/v4/app/FragmentPagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    0028: if-eq v0, v1, 0030
    002a: invoke-virtual {v0, v6}, Landroid/support/v4/app/Fragment;->setMenuVisibility(Z)V
    002d: invoke-virtual {v0, v6}, Landroid/support/v4/app/Fragment;->setUserVisibleHint(Z)V
    0030: return-object v0
    0031: invoke-virtual {v7, v9}, Landroid/support/v4/app/FragmentPagerAdapter;->getItem(I)Landroid/support/v4/app/Fragment;
    0034: move-result-object v0
    0035: iget v3, v7.Landroid/support/v4/app/FragmentPagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0037: invoke-virtual {v8}, Landroid/view/ViewGroup;->getId()I
    003a: move-result v4
    003b: invoke-virtual {v8}, Landroid/view/ViewGroup;->getId()I
    003e: move-result v5
    003f: invoke-static {v5, v1, v2}, Landroid/support/v4/app/FragmentPagerAdapter;->makeFragmentName(IJ)Ljava/lang/String;
    0042: move-result-object v1
    0043: invoke-virtual {v3, v4, v0, v1}, Landroid/support/v4/app/FragmentTransaction;->add(ILandroid/support/v4/app/Fragment;Ljava/lang/String;)Landroid/support/v4/app/FragmentTransaction;
    0046: goto 0026

  [Virtual Method] isViewFromObject(Landroid/view/View;, Ljava/lang/Object;) -> Z
    // registers=4, ins=3, outs=1, insns_size=12
    0000: check-cast v3, Landroid/support/v4/app/Fragment;
    0002: invoke-virtual {v3}, Landroid/support/v4/app/Fragment;->getView()Landroid/view/View;
    0005: move-result-object v0
    0006: if-ne v0, v2, 000a
    0008: const/4 v0, 1
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] restoreState(Landroid/os/Parcelable;, Ljava/lang/ClassLoader;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] saveState() -> Landroid/os/Parcelable;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] setPrimaryItem(Landroid/view/ViewGroup;, I, Ljava/lang/Object;) -> V
    // registers=7, ins=4, outs=2, insns_size=33
    0000: const/4 v2, 1
    0001: const/4 v1, 0
    0002: check-cast v6, Landroid/support/v4/app/Fragment;
    0004: iget v0, v3.Landroid/support/v4/app/FragmentPagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    0006: if-eq v6, v0, 0020
    0008: iget v0, v3.Landroid/support/v4/app/FragmentPagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    000a: if-eqz v0, 0016
    000c: iget v0, v3.Landroid/support/v4/app/FragmentPagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    000e: invoke-virtual {v0, v1}, Landroid/support/v4/app/Fragment;->setMenuVisibility(Z)V
    0011: iget v0, v3.Landroid/support/v4/app/FragmentPagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    0013: invoke-virtual {v0, v1}, Landroid/support/v4/app/Fragment;->setUserVisibleHint(Z)V
    0016: if-eqz v6, 001e
    0018: invoke-virtual {v6, v2}, Landroid/support/v4/app/Fragment;->setMenuVisibility(Z)V
    001b: invoke-virtual {v6, v2}, Landroid/support/v4/app/Fragment;->setUserVisibleHint(Z)V
    001e: iput v6, v3.Landroid/support/v4/app/FragmentPagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    0020: return-void

  [Virtual Method] startUpdate(Landroid/view/ViewGroup;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void