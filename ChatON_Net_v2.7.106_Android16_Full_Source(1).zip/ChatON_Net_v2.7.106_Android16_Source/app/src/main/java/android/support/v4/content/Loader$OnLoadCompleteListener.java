=== CLASS Landroid/support/v4/content/Loader$OnLoadCompleteListener; (Source: Loader.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] onLoadComplete(Landroid/support/v4/content/Loader;, Ljava/lang/Object;) -> V