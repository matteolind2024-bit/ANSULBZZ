=== CLASS Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImplHoneycomb; (Source: TaskStackBuilder.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getPendingIntent(Landroid/content/Context;, [Landroid/content/Intent;, I, I, Landroid/os/Bundle;) -> Landroid/app/PendingIntent;
    // registers=8, ins=6, outs=4, insns_size=14
    0000: const/4 v0, 0
    0001: aget(op=46) v0, v4[v0]
    0003: const v1, 268468224 (0x10008000)
    0006: invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    0009: invoke-static {v3, v5, v4, v6}, Landroid/support/v4/app/TaskStackBuilderHoneycomb;->getActivitiesPendingIntent(Landroid/content/Context;I[Landroid/content/Intent;I)Landroid/app/PendingIntent;
    000c: move-result-object v0
    000d: return-object v0