=== CLASS Landroid/support/v4/app/NavUtils$NavUtilsImplJB; (Source: NavUtils.java) ===
  Super: Landroid/support/v4/app/NavUtils$NavUtilsImplBase;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/app/NavUtils$NavUtilsImplBase;-><init>()V
    0003: return-void

  [Virtual Method] getParentActivityIntent(Landroid/app/Activity;) -> Landroid/content/Intent;
    // registers=3, ins=2, outs=2, insns_size=11
    0000: invoke-static {v2}, Landroid/support/v4/app/NavUtilsJB;->getParentActivityIntent(Landroid/app/Activity;)Landroid/content/Intent;
    0003: move-result-object v0
    0004: if-nez v0, 000a
    0006: invoke-super {v1, v2}, Landroid/support/v4/app/NavUtils$NavUtilsImplBase;->getParentActivityIntent(Landroid/app/Activity;)Landroid/content/Intent;
    0009: move-result-object v0
    000a: return-object v0

  [Virtual Method] getParentActivityName(Landroid/content/Context;, Landroid/content/pm/ActivityInfo;) -> Ljava/lang/String;
    // registers=4, ins=3, outs=3, insns_size=11
    0000: invoke-static {v3}, Landroid/support/v4/app/NavUtilsJB;->getParentActivityName(Landroid/content/pm/ActivityInfo;)Ljava/lang/String;
    0003: move-result-object v0
    0004: if-nez v0, 000a
    0006: invoke-super {v1, v2, v3}, Landroid/support/v4/app/NavUtils$NavUtilsImplBase;->getParentActivityName(Landroid/content/Context;Landroid/content/pm/ActivityInfo;)Ljava/lang/String;
    0009: move-result-object v0
    000a: return-object v0

  [Virtual Method] navigateUpTo(Landroid/app/Activity;, Landroid/content/Intent;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/app/NavUtilsJB;->navigateUpTo(Landroid/app/Activity;Landroid/content/Intent;)V
    0003: return-void

  [Virtual Method] shouldUpRecreateTask(Landroid/app/Activity;, Landroid/content/Intent;) -> Z
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/app/NavUtilsJB;->shouldUpRecreateTask(Landroid/app/Activity;Landroid/content/Intent;)Z
    0003: move-result v0
    0004: return v0