=== CLASS Landroid/support/v4/view/KeyEventCompat; (Source: KeyEventCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] IMPL: Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=22
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 11 (0xb)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/view/KeyEventCompat$HoneycombKeyEventVersionImpl;
    0008: invoke-direct {v0}, Landroid/support/v4/view/KeyEventCompat$HoneycombKeyEventVersionImpl;-><init>()V
    000b: sput v0, Landroid/support/v4/view/KeyEventCompat;->IMPL:Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;
    000d: return-void
    000e: new-instance v0, Landroid/support/v4/view/KeyEventCompat$BaseKeyEventVersionImpl;
    0010: invoke-direct {v0}, Landroid/support/v4/view/KeyEventCompat$BaseKeyEventVersionImpl;-><init>()V
    0013: sput v0, Landroid/support/v4/view/KeyEventCompat;->IMPL:Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;
    0015: goto 000d

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] hasModifiers(Landroid/view/KeyEvent;, I) -> Z
    // registers=4, ins=2, outs=3, insns_size=11
    0000: sget v0, Landroid/support/v4/view/KeyEventCompat;->IMPL:Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;
    0002: invoke-virtual {v2}, Landroid/view/KeyEvent;->getMetaState()I
    0005: move-result v1
    0006: invoke-interface {v0, v1, v3}, Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;->metaStateHasModifiers(II)Z
    0009: move-result v0
    000a: return v0

  [Direct Method] hasNoModifiers(Landroid/view/KeyEvent;) -> Z
    // registers=3, ins=1, outs=2, insns_size=11
    0000: sget v0, Landroid/support/v4/view/KeyEventCompat;->IMPL:Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;
    0002: invoke-virtual {v2}, Landroid/view/KeyEvent;->getMetaState()I
    0005: move-result v1
    0006: invoke-interface {v0, v1}, Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;->metaStateHasNoModifiers(I)Z
    0009: move-result v0
    000a: return v0

  [Direct Method] metaStateHasModifiers(I, I) -> Z
    // registers=3, ins=2, outs=3, insns_size=7
    0000: sget v0, Landroid/support/v4/view/KeyEventCompat;->IMPL:Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;->metaStateHasModifiers(II)Z
    0005: move-result v0
    0006: return v0

  [Direct Method] metaStateHasNoModifiers(I) -> Z
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/view/KeyEventCompat;->IMPL:Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;->metaStateHasNoModifiers(I)Z
    0005: move-result v0
    0006: return v0

  [Direct Method] normalizeMetaState(I) -> I
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/view/KeyEventCompat;->IMPL:Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;->normalizeMetaState(I)I
    0005: move-result v0
    0006: return v0