=== CLASS Landroid/support/v4/content/LocalBroadcastManager$BroadcastRecord; (Source: LocalBroadcastManager.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] intent: Landroid/content/Intent;
  [Instance Field] receivers: Ljava/util/ArrayList;

  [Direct Method] <init>(Landroid/content/Intent;, Ljava/util/ArrayList;) -> V
    // registers=3, ins=3, outs=1, insns_size=8
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Landroid/support/v4/content/LocalBroadcastManager$BroadcastRecord;->intent:Landroid/content/Intent;
    0005: iput v2, v0.Landroid/support/v4/content/LocalBroadcastManager$BroadcastRecord;->receivers:Ljava/util/ArrayList;
    0007: return-void