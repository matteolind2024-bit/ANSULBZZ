=== CLASS Landroid/support/v4/view/ViewCompat$ViewCompatImpl; (Source: ViewCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] canScrollHorizontally(Landroid/view/View;, I) -> Z

  [Virtual Method] canScrollVertically(Landroid/view/View;, I) -> Z

  [Virtual Method] getAccessibilityNodeProvider(Landroid/view/View;) -> Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;

  [Virtual Method] getImportantForAccessibility(Landroid/view/View;) -> I

  [Virtual Method] getOverScrollMode(Landroid/view/View;) -> I

  [Virtual Method] hasTransientState(Landroid/view/View;) -> Z

  [Virtual Method] onInitializeAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V

  [Virtual Method] onInitializeAccessibilityNodeInfo(Landroid/view/View;, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;) -> V

  [Virtual Method] onPopulateAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V

  [Virtual Method] postInvalidateOnAnimation(Landroid/view/View;) -> V

  [Virtual Method] postInvalidateOnAnimation(Landroid/view/View;, I, I, I, I) -> V

  [Virtual Method] postOnAnimation(Landroid/view/View;, Ljava/lang/Runnable;) -> V

  [Virtual Method] postOnAnimationDelayed(Landroid/view/View;, Ljava/lang/Runnable;, J) -> V

  [Virtual Method] setAccessibilityDelegate(Landroid/view/View;, Landroid/support/v4/view/AccessibilityDelegateCompat;) -> V

  [Virtual Method] setHasTransientState(Landroid/view/View;, Z) -> V

  [Virtual Method] setImportantForAccessibility(Landroid/view/View;, I) -> V

  [Virtual Method] setOverScrollMode(Landroid/view/View;, I) -> V