=== CLASS Landroid/support/v4/app/SuperNotCalledException; (Source: SuperNotCalledException.java) ===
  Super: Landroid/util/AndroidRuntimeException;

  [Direct Method] <init>(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V
    0003: return-void