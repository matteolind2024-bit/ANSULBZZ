=== CLASS Landroid/support/v4/content/AsyncTaskLoader; (Source: AsyncTaskLoader.java) ===
  Super: Landroid/support/v4/content/Loader;
  [Static Field] DEBUG: Z = False
  [Static Field] TAG: Ljava/lang/String; = 'AsyncTaskLoader'
  [Instance Field] mCancellingTask: Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
  [Instance Field] mHandler: Landroid/os/Handler;
  [Instance Field] mLastLoadCompleteTime: J
  [Instance Field] mTask: Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
  [Instance Field] mUpdateThrottle: J

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=4, ins=2, outs=2, insns_size=8
    0000: invoke-direct {v2, v3}, Landroid/support/v4/content/Loader;-><init>(Landroid/content/Context;)V
    0003: const-wide/16 v0, -10000
    0005: iput v0, v2.Landroid/support/v4/content/AsyncTaskLoader;->mLastLoadCompleteTime:J
    0007: return-void

  [Virtual Method] cancelLoad() -> Z
    // registers=5, ins=1, outs=2, insns_size=65
    0000: const/4 v3, 0
    0001: const/4 v0, 0
    0002: iget v1, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0004: if-eqz v1, 001d
    0006: iget v1, v4.Landroid/support/v4/content/AsyncTaskLoader;->mCancellingTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0008: if-eqz v1, 001e
    000a: iget v1, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    000c: iget v1, v1.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->waiting:Z
    000e: if-eqz v1, 001b
    0010: iget v1, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0012: iput v0, v1.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->waiting:Z
    0014: iget v1, v4.Landroid/support/v4/content/AsyncTaskLoader;->mHandler:Landroid/os/Handler;
    0016: iget v2, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0018: invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    001b: iput v3, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    001d: return v0
    001e: iget v1, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0020: iget v1, v1.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->waiting:Z
    0022: if-eqz v1, 0032
    0024: iget v1, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0026: iput v0, v1.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->waiting:Z
    0028: iget v1, v4.Landroid/support/v4/content/AsyncTaskLoader;->mHandler:Landroid/os/Handler;
    002a: iget v2, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    002c: invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    002f: iput v3, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0031: goto 001d
    0032: iget v1, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0034: invoke-virtual {v1, v0}, Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->cancel(Z)Z
    0037: move-result v0
    0038: if-eqz v0, 003e
    003a: iget v1, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    003c: iput v1, v4.Landroid/support/v4/content/AsyncTaskLoader;->mCancellingTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    003e: iput v3, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0040: goto 001d

  [Virtual Method] dispatchOnCancelled(Landroid/support/v4/content/AsyncTaskLoader$LoadTask;, Ljava/lang/Object;) -> V
    // registers=5, ins=3, outs=2, insns_size=20
    0000: invoke-virtual {v2, v4}, Landroid/support/v4/content/AsyncTaskLoader;->onCanceled(Ljava/lang/Object;)V
    0003: iget v0, v2.Landroid/support/v4/content/AsyncTaskLoader;->mCancellingTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0005: if-ne v0, v3, 0013
    0007: invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    000a: move-result-wide v0
    000b: iput v0, v2.Landroid/support/v4/content/AsyncTaskLoader;->mLastLoadCompleteTime:J
    000d: const/4 v0, 0
    000e: iput v0, v2.Landroid/support/v4/content/AsyncTaskLoader;->mCancellingTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0010: invoke-virtual {v2}, Landroid/support/v4/content/AsyncTaskLoader;->executePendingTask()V
    0013: return-void

  [Virtual Method] dispatchOnLoadComplete(Landroid/support/v4/content/AsyncTaskLoader$LoadTask;, Ljava/lang/Object;) -> V
    // registers=5, ins=3, outs=3, insns_size=31
    0000: iget v0, v2.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0002: if-eq v0, v3, 0008
    0004: invoke-virtual {v2, v3, v4}, Landroid/support/v4/content/AsyncTaskLoader;->dispatchOnCancelled(Landroid/support/v4/content/AsyncTaskLoader$LoadTask;Ljava/lang/Object;)V
    0007: return-void
    0008: invoke-virtual {v2}, Landroid/support/v4/content/AsyncTaskLoader;->isAbandoned()Z
    000b: move-result v0
    000c: if-eqz v0, 0012
    000e: invoke-virtual {v2, v4}, Landroid/support/v4/content/AsyncTaskLoader;->onCanceled(Ljava/lang/Object;)V
    0011: goto 0007
    0012: invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    0015: move-result-wide v0
    0016: iput v0, v2.Landroid/support/v4/content/AsyncTaskLoader;->mLastLoadCompleteTime:J
    0018: const/4 v0, 0
    0019: iput v0, v2.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    001b: invoke-virtual {v2, v4}, Landroid/support/v4/content/AsyncTaskLoader;->deliverResult(Ljava/lang/Object;)V
    001e: goto 0007

  [Virtual Method] dump(Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V
    // registers=9, ins=5, outs=5, insns_size=100
    0000: invoke-super {v4, v5, v6, v7, v8}, Landroid/support/v4/content/Loader;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    0003: iget v0, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0005: if-eqz v0, 0020
    0007: invoke-virtual {v7, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    000a: const-string v0, 'mTask='
    000c: invoke-virtual {v7, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    000f: iget v0, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0011: invoke-virtual {v7, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/Object;)V
    0014: const-string v0, ' waiting='
    0016: invoke-virtual {v7, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0019: iget v0, v4.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    001b: iget v0, v0.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->waiting:Z
    001d: invoke-virtual {v7, v0}, Ljava/io/PrintWriter;->println(Z)V
    0020: iget v0, v4.Landroid/support/v4/content/AsyncTaskLoader;->mCancellingTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0022: if-eqz v0, 003d
    0024: invoke-virtual {v7, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0027: const-string v0, 'mCancellingTask='
    0029: invoke-virtual {v7, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    002c: iget v0, v4.Landroid/support/v4/content/AsyncTaskLoader;->mCancellingTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    002e: invoke-virtual {v7, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/Object;)V
    0031: const-string v0, ' waiting='
    0033: invoke-virtual {v7, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0036: iget v0, v4.Landroid/support/v4/content/AsyncTaskLoader;->mCancellingTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0038: iget v0, v0.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->waiting:Z
    003a: invoke-virtual {v7, v0}, Ljava/io/PrintWriter;->println(Z)V
    003d: iget v0, v4.Landroid/support/v4/content/AsyncTaskLoader;->mUpdateThrottle:J
    003f: const-wide/16 v2, 0
    0041: cmp(op=31) v0, v0, v2
    0043: if-eqz v0, 0063
    0045: invoke-virtual {v7, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0048: const-string v0, 'mUpdateThrottle='
    004a: invoke-virtual {v7, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    004d: iget v0, v4.Landroid/support/v4/content/AsyncTaskLoader;->mUpdateThrottle:J
    004f: invoke-static {v0, v1, v7}, Landroid/support/v4/util/TimeUtils;->formatDuration(JLjava/io/PrintWriter;)V
    0052: const-string v0, ' mLastLoadCompleteTime='
    0054: invoke-virtual {v7, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0057: iget v0, v4.Landroid/support/v4/content/AsyncTaskLoader;->mLastLoadCompleteTime:J
    0059: invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    005c: move-result-wide v2
    005d: invoke-static {v0, v1, v2, v3, v7}, Landroid/support/v4/util/TimeUtils;->formatDuration(JJLjava/io/PrintWriter;)V
    0060: invoke-virtual {v7}, Ljava/io/PrintWriter;->println()V
    0063: return-void

  [Virtual Method] executePendingTask() -> V
    // registers=7, ins=1, outs=4, insns_size=76
    0000: iget v0, v6.Landroid/support/v4/content/AsyncTaskLoader;->mCancellingTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0002: if-nez v0, 0040
    0004: iget v0, v6.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0006: if-eqz v0, 0040
    0008: iget v0, v6.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    000a: iget v0, v0.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->waiting:Z
    000c: if-eqz v0, 001a
    000e: iget v0, v6.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0010: const/4 v1, 0
    0011: iput v1, v0.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->waiting:Z
    0013: iget v0, v6.Landroid/support/v4/content/AsyncTaskLoader;->mHandler:Landroid/os/Handler;
    0015: iget v1, v6.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0017: invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    001a: iget v0, v6.Landroid/support/v4/content/AsyncTaskLoader;->mUpdateThrottle:J
    001c: const-wide/16 v2, 0
    001e: cmp(op=31) v0, v0, v2
    0020: if-lez v0, 0041
    0022: invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    0025: move-result-wide v0
    0026: iget v2, v6.Landroid/support/v4/content/AsyncTaskLoader;->mLastLoadCompleteTime:J
    0028: iget v4, v6.Landroid/support/v4/content/AsyncTaskLoader;->mUpdateThrottle:J
    002a: binop/2addr(op=bb) v2, v4
    002b: cmp(op=31) v0, v0, v2
    002d: if-gez v0, 0041
    002f: iget v0, v6.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0031: const/4 v1, 1
    0032: iput v1, v0.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->waiting:Z
    0034: iget v0, v6.Landroid/support/v4/content/AsyncTaskLoader;->mHandler:Landroid/os/Handler;
    0036: iget v1, v6.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0038: iget v2, v6.Landroid/support/v4/content/AsyncTaskLoader;->mLastLoadCompleteTime:J
    003a: iget v4, v6.Landroid/support/v4/content/AsyncTaskLoader;->mUpdateThrottle:J
    003c: binop/2addr(op=bb) v2, v4
    003d: invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postAtTime(Ljava/lang/Runnable;J)Z
    0040: return-void
    0041: iget v1, v6.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0043: sget v2, Landroid/support/v4/content/ModernAsyncTask;->THREAD_POOL_EXECUTOR:Ljava/util/concurrent/Executor;
    0045: const/4 v0, 0
    0046: check-cast v0, [Ljava/lang/Void;
    0048: invoke-virtual {v1, v2, v0}, Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->executeOnExecutor(Ljava/util/concurrent/Executor;[Ljava/lang/Object;)Landroid/support/v4/content/ModernAsyncTask;
    004b: goto 0040

  [Virtual Method] loadInBackground() -> Ljava/lang/Object;

  [Virtual Method] onCanceled(Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onForceLoad() -> V
    // registers=2, ins=1, outs=2, insns_size=17
    0000: invoke-super {v1}, Landroid/support/v4/content/Loader;->onForceLoad()V
    0003: invoke-virtual {v1}, Landroid/support/v4/content/AsyncTaskLoader;->cancelLoad()Z
    0006: new-instance v0, Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0008: invoke-direct {v0, v1}, Landroid/support/v4/content/AsyncTaskLoader$LoadTask;-><init>(Landroid/support/v4/content/AsyncTaskLoader;)V
    000b: iput v0, v1.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    000d: invoke-virtual {v1}, Landroid/support/v4/content/AsyncTaskLoader;->executePendingTask()V
    0010: return-void

  [Virtual Method] onLoadInBackground() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/support/v4/content/AsyncTaskLoader;->loadInBackground()Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] setUpdateThrottle(J) -> V
    // registers=5, ins=3, outs=1, insns_size=16
    0000: iput v3, v2.Landroid/support/v4/content/AsyncTaskLoader;->mUpdateThrottle:J
    0002: const-wide/16 v0, 0
    0004: cmp(op=31) v0, v3, v0
    0006: if-eqz v0, 000f
    0008: new-instance v0, Landroid/os/Handler;
    000a: invoke-direct {v0}, Landroid/os/Handler;-><init>()V
    000d: iput v0, v2.Landroid/support/v4/content/AsyncTaskLoader;->mHandler:Landroid/os/Handler;
    000f: return-void

  [Virtual Method] waitForLoader() -> V
    // registers=2, ins=1, outs=1, insns_size=14
    0000: iget v0, v1.Landroid/support/v4/content/AsyncTaskLoader;->mTask:Landroid/support/v4/content/AsyncTaskLoader$LoadTask;
    0002: if-eqz v0, 000b
    0004: invoke-static {v0}, Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->access$000(Landroid/support/v4/content/AsyncTaskLoader$LoadTask;)Ljava/util/concurrent/CountDownLatch;
    0007: move-result-object v0
    0008: invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->await()V
    000b: return-void
    000c: move-exception v0
    000d: goto 000b