=== CLASS Landroid/support/v4/view/VelocityTrackerCompat$VelocityTrackerVersionImpl; (Source: VelocityTrackerCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] getXVelocity(Landroid/view/VelocityTracker;, I) -> F

  [Virtual Method] getYVelocity(Landroid/view/VelocityTracker;, I) -> F