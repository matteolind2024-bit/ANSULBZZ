=== CLASS Landroid/support/v4/view/ViewCompatJB; (Source: ViewCompatJB.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getAccessibilityNodeProvider(Landroid/view/View;) -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/view/View;->getAccessibilityNodeProvider()Landroid/view/accessibility/AccessibilityNodeProvider;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] getImportantForAccessibility(Landroid/view/View;) -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/view/View;->getImportantForAccessibility()I
    0003: move-result v0
    0004: return v0

  [Direct Method] hasTransientState(Landroid/view/View;) -> Z
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/view/View;->hasTransientState()Z
    0003: move-result v0
    0004: return v0

  [Direct Method] postInvalidateOnAnimation(Landroid/view/View;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-virtual {v0}, Landroid/view/View;->postInvalidateOnAnimation()V
    0003: return-void

  [Direct Method] postInvalidateOnAnimation(Landroid/view/View;, I, I, I, I) -> V
    // registers=5, ins=5, outs=5, insns_size=4
    0000: invoke-virtual {v0, v1, v2, v3, v4}, Landroid/view/View;->postInvalidate(IIII)V
    0003: return-void

  [Direct Method] postOnAnimation(Landroid/view/View;, Ljava/lang/Runnable;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V
    0003: return-void

  [Direct Method] postOnAnimationDelayed(Landroid/view/View;, Ljava/lang/Runnable;, J) -> V
    // registers=4, ins=4, outs=4, insns_size=4
    0000: invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postOnAnimationDelayed(Ljava/lang/Runnable;J)V
    0003: return-void

  [Direct Method] setHasTransientState(Landroid/view/View;, Z) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/view/View;->setHasTransientState(Z)V
    0003: return-void

  [Direct Method] setImportantForAccessibility(Landroid/view/View;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/view/View;->setImportantForAccessibility(I)V
    0003: return-void