=== CLASS Landroid/support/v4/content/ModernAsyncTask$InternalHandler; (Source: ModernAsyncTask.java) ===
  Super: Landroid/os/Handler;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/os/Handler;-><init>()V
    0003: return-void

  [Direct Method] <init>(Landroid/support/v4/content/ModernAsyncTask$1;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/content/ModernAsyncTask$InternalHandler;-><init>()V
    0003: return-void

  [Virtual Method] handleMessage(Landroid/os/Message;) -> V
    // registers=5, ins=2, outs=2, insns_size=38
    0000: iget v0, v4.Landroid/os/Message;->obj:Ljava/lang/Object;
    0002: check-cast v0, Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;
    0004: iget v1, v4.Landroid/os/Message;->what:I
    0006: packed-switch v1, +24 (-> 001e)
    0009: return-void
    000a: iget v1, v0.Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;->mTask:Landroid/support/v4/content/ModernAsyncTask;
    000c: iget v0, v0.Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;->mData:[Ljava/lang/Object;
    000e: const/4 v2, 0
    000f: aget(op=46) v0, v0[v2]
    0011: invoke-static {v1, v0}, Landroid/support/v4/content/ModernAsyncTask;->access$500(Landroid/support/v4/content/ModernAsyncTask;Ljava/lang/Object;)V
    0014: goto 0009
    0015: iget v1, v0.Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;->mTask:Landroid/support/v4/content/ModernAsyncTask;
    0017: iget v0, v0.Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;->mData:[Ljava/lang/Object;
    0019: invoke-virtual {v1, v0}, Landroid/support/v4/content/ModernAsyncTask;->onProgressUpdate([Ljava/lang/Object;)V
    001c: goto 0009
    001d: nop
    001e: packed-switch-payload first=1 targets=[4, 15]