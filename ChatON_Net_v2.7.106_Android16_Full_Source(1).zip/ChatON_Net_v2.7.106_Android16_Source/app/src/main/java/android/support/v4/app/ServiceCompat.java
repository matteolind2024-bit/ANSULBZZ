=== CLASS Landroid/support/v4/app/ServiceCompat; (Source: ServiceCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] START_STICKY: I = 1

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void