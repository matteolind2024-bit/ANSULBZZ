=== CLASS Landroid/support/v4/view/accessibility/AccessibilityEventCompat; (Source: AccessibilityEventCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] IMPL: Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl; = None
  [Static Field] TYPES_ALL_MASK: I = -1
  [Static Field] TYPE_ANNOUNCEMENT: I = 16384
  [Static Field] TYPE_TOUCH_EXPLORATION_GESTURE_END: I = 1024
  [Static Field] TYPE_TOUCH_EXPLORATION_GESTURE_START: I = 512
  [Static Field] TYPE_VIEW_ACCESSIBILITY_FOCUSED: I = 32768
  [Static Field] TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED: I = 65536
  [Static Field] TYPE_VIEW_HOVER_ENTER: I = 128
  [Static Field] TYPE_VIEW_HOVER_EXIT: I = 256
  [Static Field] TYPE_VIEW_SCROLLED: I = 4096
  [Static Field] TYPE_VIEW_TEXT_SELECTION_CHANGED: I = 8192
  [Static Field] TYPE_VIEW_TEXT_TRAVERSED_AT_MOVEMENT_GRANULARITY: I = 131072
  [Static Field] TYPE_WINDOW_CONTENT_CHANGED: I = 2048

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=22
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 14 (0xe)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventIcsImpl;
    0008: invoke-direct {v0}, Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventIcsImpl;-><init>()V
    000b: sput v0, Landroid/support/v4/view/accessibility/AccessibilityEventCompat;->IMPL:Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl;
    000d: return-void
    000e: new-instance v0, Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventStubImpl;
    0010: invoke-direct {v0}, Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventStubImpl;-><init>()V
    0013: sput v0, Landroid/support/v4/view/accessibility/AccessibilityEventCompat;->IMPL:Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl;
    0015: goto 000d

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] appendRecord(Landroid/view/accessibility/AccessibilityEvent;, Landroid/support/v4/view/accessibility/AccessibilityRecordCompat;) -> V
    // registers=4, ins=2, outs=3, insns_size=10
    0000: sget v0, Landroid/support/v4/view/accessibility/AccessibilityEventCompat;->IMPL:Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl;
    0002: invoke-virtual {v3}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompat;->getImpl()Ljava/lang/Object;
    0005: move-result-object v1
    0006: invoke-interface {v0, v2, v1}, Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl;->appendRecord(Landroid/view/accessibility/AccessibilityEvent;Ljava/lang/Object;)V
    0009: return-void

  [Direct Method] getRecord(Landroid/view/accessibility/AccessibilityEvent;, I) -> Landroid/support/v4/view/accessibility/AccessibilityRecordCompat;
    // registers=4, ins=2, outs=3, insns_size=12
    0000: new-instance v0, Landroid/support/v4/view/accessibility/AccessibilityRecordCompat;
    0002: sget v1, Landroid/support/v4/view/accessibility/AccessibilityEventCompat;->IMPL:Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl;
    0004: invoke-interface {v1, v2, v3}, Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl;->getRecord(Landroid/view/accessibility/AccessibilityEvent;I)Ljava/lang/Object;
    0007: move-result-object v1
    0008: invoke-direct {v0, v1}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompat;-><init>(Ljava/lang/Object;)V
    000b: return-object v0

  [Direct Method] getRecordCount(Landroid/view/accessibility/AccessibilityEvent;) -> I
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/view/accessibility/AccessibilityEventCompat;->IMPL:Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl;->getRecordCount(Landroid/view/accessibility/AccessibilityEvent;)I
    0005: move-result v0
    0006: return v0