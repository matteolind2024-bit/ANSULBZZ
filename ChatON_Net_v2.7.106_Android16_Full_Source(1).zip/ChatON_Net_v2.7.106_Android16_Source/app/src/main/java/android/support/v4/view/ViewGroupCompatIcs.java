=== CLASS Landroid/support/v4/view/ViewGroupCompatIcs; (Source: ViewGroupCompatIcs.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> Z
    // registers=4, ins=3, outs=3, insns_size=5
    0000: invoke-virtual {v1, v2, v3}, Landroid/view/ViewGroup;->onRequestSendAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    0003: move-result v0
    0004: return v0