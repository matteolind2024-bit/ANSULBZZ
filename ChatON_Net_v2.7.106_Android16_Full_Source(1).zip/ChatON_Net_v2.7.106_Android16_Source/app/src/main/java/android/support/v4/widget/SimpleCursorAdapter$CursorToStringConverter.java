=== CLASS Landroid/support/v4/widget/SimpleCursorAdapter$CursorToStringConverter; (Source: SimpleCursorAdapter.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] convertToString(Landroid/database/Cursor;) -> Ljava/lang/CharSequence;