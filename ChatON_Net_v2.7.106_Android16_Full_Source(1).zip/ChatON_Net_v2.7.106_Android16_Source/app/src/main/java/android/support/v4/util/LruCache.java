=== CLASS Landroid/support/v4/util/LruCache; (Source: LruCache.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] createCount: I
  [Instance Field] evictionCount: I
  [Instance Field] hitCount: I
  [Instance Field] map: Ljava/util/LinkedHashMap;
  [Instance Field] maxSize: I
  [Instance Field] missCount: I
  [Instance Field] putCount: I
  [Instance Field] size: I

  [Direct Method] <init>(I) -> V
    // registers=6, ins=2, outs=4, insns_size=27
    0000: invoke-direct {v4}, Ljava/lang/Object;-><init>()V
    0003: if-gtz v5, 000d
    0005: new-instance v0, Ljava/lang/IllegalArgumentException;
    0007: const-string v1, 'maxSize <= 0'
    0009: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    000c: throw v0
    000d: iput v5, v4.Landroid/support/v4/util/LruCache;->maxSize:I
    000f: new-instance v0, Ljava/util/LinkedHashMap;
    0011: const/4 v1, 0
    0012: const/high16 v2, 1061158912 (0x3f400000)
    0014: const/4 v3, 1
    0015: invoke-direct {v0, v1, v2, v3}, Ljava/util/LinkedHashMap;-><init>(IFZ)V
    0018: iput v0, v4.Landroid/support/v4/util/LruCache;->map:Ljava/util/LinkedHashMap;
    001a: return-void

  [Direct Method] safeSizeOf(Ljava/lang/Object;, Ljava/lang/Object;) -> I
    // registers=6, ins=3, outs=3, insns_size=42
    0000: invoke-virtual {v3, v4, v5}, Landroid/support/v4/util/LruCache;->sizeOf(Ljava/lang/Object;Ljava/lang/Object;)I
    0003: move-result v0
    0004: if-gez v0, 0029
    0006: new-instance v0, Ljava/lang/IllegalStateException;
    0008: new-instance v1, Ljava/lang/StringBuilder;
    000a: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000d: const-string v2, 'Negative size: '
    000f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0016: move-result-object v1
    0017: const-string v2, '='
    0019: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: move-result-object v1
    001d: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0020: move-result-object v1
    0021: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0024: move-result-object v1
    0025: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0028: throw v0
    0029: return v0

  [Direct Method] trimToSize(I) -> V
    // registers=6, ins=2, outs=5, insns_size=118
    0000: monitor-enter v4
    0001: iget v0, v4.Landroid/support/v4/util/LruCache;->size:I
    0003: if-ltz v0, 0011
    0005: iget v0, v4.Landroid/support/v4/util/LruCache;->map:Ljava/util/LinkedHashMap;
    0007: invoke-virtual {v0}, Ljava/util/LinkedHashMap;->isEmpty()Z
    000a: move-result v0
    000b: if-eqz v0, 0035
    000d: iget v0, v4.Landroid/support/v4/util/LruCache;->size:I
    000f: if-eqz v0, 0035
    0011: new-instance v0, Ljava/lang/IllegalStateException;
    0013: new-instance v1, Ljava/lang/StringBuilder;
    0015: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0018: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    001b: move-result-object v2
    001c: invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;
    001f: move-result-object v2
    0020: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0023: move-result-object v1
    0024: const-string v2, '.sizeOf() is reporting inconsistent results!'
    0026: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0029: move-result-object v1
    002a: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002d: move-result-object v1
    002e: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0031: throw v0
    0032: move-exception v0
    0033: monitor-exit v4
    0034: throw v0
    0035: iget v0, v4.Landroid/support/v4/util/LruCache;->size:I
    0037: if-le v0, v5, 0041
    0039: iget v0, v4.Landroid/support/v4/util/LruCache;->map:Ljava/util/LinkedHashMap;
    003b: invoke-virtual {v0}, Ljava/util/LinkedHashMap;->isEmpty()Z
    003e: move-result v0
    003f: if-eqz v0, 0043
    0041: monitor-exit v4
    0042: return-void
    0043: iget v0, v4.Landroid/support/v4/util/LruCache;->map:Ljava/util/LinkedHashMap;
    0045: invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;
    0048: move-result-object v0
    0049: invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;
    004c: move-result-object v0
    004d: invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    0050: move-result-object v0
    0051: check-cast v0, Ljava/util/Map$Entry;
    0053: invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;
    0056: move-result-object v1
    0057: invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;
    005a: move-result-object v0
    005b: iget v2, v4.Landroid/support/v4/util/LruCache;->map:Ljava/util/LinkedHashMap;
    005d: invoke-virtual {v2, v1}, Ljava/util/LinkedHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    0060: iget v2, v4.Landroid/support/v4/util/LruCache;->size:I
    0062: invoke-direct {v4, v1, v0}, Landroid/support/v4/util/LruCache;->safeSizeOf(Ljava/lang/Object;Ljava/lang/Object;)I
    0065: move-result v3
    0066: binop/2addr(op=b1) v2, v3
    0067: iput v2, v4.Landroid/support/v4/util/LruCache;->size:I
    0069: iget v2, v4.Landroid/support/v4/util/LruCache;->evictionCount:I
    006b: binop/lit8(op=d8) v2, v2, 1 (0x1)
    006d: iput v2, v4.Landroid/support/v4/util/LruCache;->evictionCount:I
    006f: monitor-exit v4
    0070: const/4 v2, 1
    0071: const/4 v3, 0
    0072: invoke-virtual {v4, v2, v1, v0, v3}, Landroid/support/v4/util/LruCache;->entryRemoved(ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    0075: goto 0000

  [Virtual Method] create(Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] createCount() -> I
    // registers=2, ins=1, outs=0, insns_size=8
    0000: monitor-enter v1
    0001: iget v0, v1.Landroid/support/v4/util/LruCache;->createCount:I
    0003: monitor-exit v1
    0004: return v0
    0005: move-exception v0
    0006: monitor-exit v1
    0007: throw v0

  [Virtual Method] entryRemoved(Z, Ljava/lang/Object;, Ljava/lang/Object;, Ljava/lang/Object;) -> V
    // registers=5, ins=5, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] evictAll() -> V
    // registers=2, ins=1, outs=2, insns_size=5
    0000: const/4 v0, -1
    0001: invoke-direct {v1, v0}, Landroid/support/v4/util/LruCache;->trimToSize(I)V
    0004: return-void

  [Virtual Method] evictionCount() -> I
    // registers=2, ins=1, outs=0, insns_size=8
    0000: monitor-enter v1
    0001: iget v0, v1.Landroid/support/v4/util/LruCache;->evictionCount:I
    0003: monitor-exit v1
    0004: return v0
    0005: move-exception v0
    0006: monitor-exit v1
    0007: throw v0

  [Virtual Method] get(Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=6, ins=2, outs=5, insns_size=93
    0000: if-nez v5, 000a
    0002: new-instance v0, Ljava/lang/NullPointerException;
    0004: const-string v1, 'key == null'
    0006: invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    0009: throw v0
    000a: monitor-enter v4
    000b: iget v0, v4.Landroid/support/v4/util/LruCache;->map:Ljava/util/LinkedHashMap;
    000d: invoke-virtual {v0, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0010: move-result-object v0
    0011: if-eqz v0, 001b
    0013: iget v1, v4.Landroid/support/v4/util/LruCache;->hitCount:I
    0015: binop/lit8(op=d8) v1, v1, 1 (0x1)
    0017: iput v1, v4.Landroid/support/v4/util/LruCache;->hitCount:I
    0019: monitor-exit v4
    001a: return-object v0
    001b: iget v0, v4.Landroid/support/v4/util/LruCache;->missCount:I
    001d: binop/lit8(op=d8) v0, v0, 1 (0x1)
    001f: iput v0, v4.Landroid/support/v4/util/LruCache;->missCount:I
    0021: monitor-exit v4
    0022: invoke-virtual {v4, v5}, Landroid/support/v4/util/LruCache;->create(Ljava/lang/Object;)Ljava/lang/Object;
    0025: move-result-object v1
    0026: if-nez v1, 002d
    0028: const/4 v0, 0
    0029: goto 001a
    002a: move-exception v0
    002b: monitor-exit v4
    002c: throw v0
    002d: monitor-enter v4
    002e: iget v0, v4.Landroid/support/v4/util/LruCache;->createCount:I
    0030: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0032: iput v0, v4.Landroid/support/v4/util/LruCache;->createCount:I
    0034: iget v0, v4.Landroid/support/v4/util/LruCache;->map:Ljava/util/LinkedHashMap;
    0036: invoke-virtual {v0, v5, v1}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    0039: move-result-object v0
    003a: if-eqz v0, 0049
    003c: iget v2, v4.Landroid/support/v4/util/LruCache;->map:Ljava/util/LinkedHashMap;
    003e: invoke-virtual {v2, v5, v0}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    0041: monitor-exit v4
    0042: if-eqz v0, 0056
    0044: const/4 v2, 0
    0045: invoke-virtual {v4, v2, v5, v1, v0}, Landroid/support/v4/util/LruCache;->entryRemoved(ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    0048: goto 001a
    0049: iget v2, v4.Landroid/support/v4/util/LruCache;->size:I
    004b: invoke-direct {v4, v5, v1}, Landroid/support/v4/util/LruCache;->safeSizeOf(Ljava/lang/Object;Ljava/lang/Object;)I
    004e: move-result v3
    004f: binop/2addr(op=b0) v2, v3
    0050: iput v2, v4.Landroid/support/v4/util/LruCache;->size:I
    0052: goto 0041
    0053: move-exception v0
    0054: monitor-exit v4
    0055: throw v0
    0056: iget v0, v4.Landroid/support/v4/util/LruCache;->maxSize:I
    0058: invoke-direct {v4, v0}, Landroid/support/v4/util/LruCache;->trimToSize(I)V
    005b: move(op=07) v0, v1
    005c: goto 001a

  [Virtual Method] hitCount() -> I
    // registers=2, ins=1, outs=0, insns_size=8
    0000: monitor-enter v1
    0001: iget v0, v1.Landroid/support/v4/util/LruCache;->hitCount:I
    0003: monitor-exit v1
    0004: return v0
    0005: move-exception v0
    0006: monitor-exit v1
    0007: throw v0

  [Virtual Method] maxSize() -> I
    // registers=2, ins=1, outs=0, insns_size=8
    0000: monitor-enter v1
    0001: iget v0, v1.Landroid/support/v4/util/LruCache;->maxSize:I
    0003: monitor-exit v1
    0004: return v0
    0005: move-exception v0
    0006: monitor-exit v1
    0007: throw v0

  [Virtual Method] missCount() -> I
    // registers=2, ins=1, outs=0, insns_size=8
    0000: monitor-enter v1
    0001: iget v0, v1.Landroid/support/v4/util/LruCache;->missCount:I
    0003: monitor-exit v1
    0004: return v0
    0005: move-exception v0
    0006: monitor-exit v1
    0007: throw v0

  [Virtual Method] put(Ljava/lang/Object;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=6, ins=3, outs=5, insns_size=61
    0000: if-eqz v4, 0004
    0002: if-nez v5, 000c
    0004: new-instance v0, Ljava/lang/NullPointerException;
    0006: const-string v1, 'key == null || value == null'
    0008: invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: monitor-enter v3
    000d: iget v0, v3.Landroid/support/v4/util/LruCache;->putCount:I
    000f: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0011: iput v0, v3.Landroid/support/v4/util/LruCache;->putCount:I
    0013: iget v0, v3.Landroid/support/v4/util/LruCache;->size:I
    0015: invoke-direct {v3, v4, v5}, Landroid/support/v4/util/LruCache;->safeSizeOf(Ljava/lang/Object;Ljava/lang/Object;)I
    0018: move-result v1
    0019: binop/2addr(op=b0) v0, v1
    001a: iput v0, v3.Landroid/support/v4/util/LruCache;->size:I
    001c: iget v0, v3.Landroid/support/v4/util/LruCache;->map:Ljava/util/LinkedHashMap;
    001e: invoke-virtual {v0, v4, v5}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    0021: move-result-object v0
    0022: if-eqz v0, 002d
    0024: iget v1, v3.Landroid/support/v4/util/LruCache;->size:I
    0026: invoke-direct {v3, v4, v0}, Landroid/support/v4/util/LruCache;->safeSizeOf(Ljava/lang/Object;Ljava/lang/Object;)I
    0029: move-result v2
    002a: binop/2addr(op=b1) v1, v2
    002b: iput v1, v3.Landroid/support/v4/util/LruCache;->size:I
    002d: monitor-exit v3
    002e: if-eqz v0, 0034
    0030: const/4 v1, 0
    0031: invoke-virtual {v3, v1, v4, v0, v5}, Landroid/support/v4/util/LruCache;->entryRemoved(ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    0034: iget v1, v3.Landroid/support/v4/util/LruCache;->maxSize:I
    0036: invoke-direct {v3, v1}, Landroid/support/v4/util/LruCache;->trimToSize(I)V
    0039: return-object v0
    003a: move-exception v0
    003b: monitor-exit v3
    003c: throw v0

  [Virtual Method] putCount() -> I
    // registers=2, ins=1, outs=0, insns_size=8
    0000: monitor-enter v1
    0001: iget v0, v1.Landroid/support/v4/util/LruCache;->putCount:I
    0003: monitor-exit v1
    0004: return v0
    0005: move-exception v0
    0006: monitor-exit v1
    0007: throw v0

  [Virtual Method] remove(Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=5, ins=2, outs=5, insns_size=40
    0000: if-nez v4, 000a
    0002: new-instance v0, Ljava/lang/NullPointerException;
    0004: const-string v1, 'key == null'
    0006: invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V
    0009: throw v0
    000a: monitor-enter v3
    000b: iget v0, v3.Landroid/support/v4/util/LruCache;->map:Ljava/util/LinkedHashMap;
    000d: invoke-virtual {v0, v4}, Ljava/util/LinkedHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    0010: move-result-object v0
    0011: if-eqz v0, 001c
    0013: iget v1, v3.Landroid/support/v4/util/LruCache;->size:I
    0015: invoke-direct {v3, v4, v0}, Landroid/support/v4/util/LruCache;->safeSizeOf(Ljava/lang/Object;Ljava/lang/Object;)I
    0018: move-result v2
    0019: binop/2addr(op=b1) v1, v2
    001a: iput v1, v3.Landroid/support/v4/util/LruCache;->size:I
    001c: monitor-exit v3
    001d: if-eqz v0, 0024
    001f: const/4 v1, 0
    0020: const/4 v2, 0
    0021: invoke-virtual {v3, v1, v4, v0, v2}, Landroid/support/v4/util/LruCache;->entryRemoved(ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    0024: return-object v0
    0025: move-exception v0
    0026: monitor-exit v3
    0027: throw v0

  [Virtual Method] size() -> I
    // registers=2, ins=1, outs=0, insns_size=8
    0000: monitor-enter v1
    0001: iget v0, v1.Landroid/support/v4/util/LruCache;->size:I
    0003: monitor-exit v1
    0004: return v0
    0005: move-exception v0
    0006: monitor-exit v1
    0007: throw v0

  [Virtual Method] sizeOf(Ljava/lang/Object;, Ljava/lang/Object;) -> I
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Virtual Method] snapshot() -> Ljava/util/Map;
    // registers=3, ins=1, outs=2, insns_size=13
    0000: monitor-enter v2
    0001: new-instance v0, Ljava/util/LinkedHashMap;
    0003: iget v1, v2.Landroid/support/v4/util/LruCache;->map:Ljava/util/LinkedHashMap;
    0005: invoke-direct {v0, v1}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V
    0008: monitor-exit v2
    0009: return-object v0
    000a: move-exception v0
    000b: monitor-exit v2
    000c: throw v0

  [Virtual Method] toString() -> Ljava/lang/String;
    // registers=6, ins=1, outs=2, insns_size=62
    0000: const/4 v0, 0
    0001: monitor-enter v5
    0002: iget v1, v5.Landroid/support/v4/util/LruCache;->hitCount:I
    0004: iget v2, v5.Landroid/support/v4/util/LruCache;->missCount:I
    0006: binop/2addr(op=b0) v1, v2
    0007: if-eqz v1, 000e
    0009: iget v0, v5.Landroid/support/v4/util/LruCache;->hitCount:I
    000b: binop/lit8(op=da) v0, v0, 100 (0x64)
    000d: binop/2addr(op=b3) v0, v1
    000e: const-string v1, 'LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]'
    0010: const/4 v2, 4
    0011: new-array v2, v2, [Ljava/lang/Object;
    0013: const/4 v3, 0
    0014: iget v4, v5.Landroid/support/v4/util/LruCache;->maxSize:I
    0016: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0019: move-result-object v4
    001a: aput(op=4d) v4, v2[v3]
    001c: const/4 v3, 1
    001d: iget v4, v5.Landroid/support/v4/util/LruCache;->hitCount:I
    001f: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0022: move-result-object v4
    0023: aput(op=4d) v4, v2[v3]
    0025: const/4 v3, 2
    0026: iget v4, v5.Landroid/support/v4/util/LruCache;->missCount:I
    0028: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    002b: move-result-object v4
    002c: aput(op=4d) v4, v2[v3]
    002e: const/4 v3, 3
    002f: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0032: move-result-object v0
    0033: aput(op=4d) v0, v2[v3]
    0035: invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    0038: move-result-object v0
    0039: monitor-exit v5
    003a: return-object v0
    003b: move-exception v0
    003c: monitor-exit v5
    003d: throw v0