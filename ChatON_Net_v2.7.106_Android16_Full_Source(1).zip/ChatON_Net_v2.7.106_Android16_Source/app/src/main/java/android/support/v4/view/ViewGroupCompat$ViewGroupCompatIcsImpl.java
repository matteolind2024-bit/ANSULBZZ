=== CLASS Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatIcsImpl; (Source: ViewGroupCompat.java) ===
  Super: Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatStubImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatStubImpl;-><init>()V
    0003: return-void

  [Virtual Method] onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> Z
    // registers=5, ins=4, outs=3, insns_size=5
    0000: invoke-static {v2, v3, v4}, Landroid/support/v4/view/ViewGroupCompatIcs;->onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    0003: move-result v0
    0004: return v0