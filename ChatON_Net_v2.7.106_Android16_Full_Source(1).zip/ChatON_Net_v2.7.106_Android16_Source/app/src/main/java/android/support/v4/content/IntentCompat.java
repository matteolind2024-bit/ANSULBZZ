=== CLASS Landroid/support/v4/content/IntentCompat; (Source: IntentCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] ACTION_EXTERNAL_APPLICATIONS_AVAILABLE: Ljava/lang/String; = 'android.intent.action.EXTERNAL_APPLICATIONS_AVAILABLE'
  [Static Field] ACTION_EXTERNAL_APPLICATIONS_UNAVAILABLE: Ljava/lang/String; = 'android.intent.action.EXTERNAL_APPLICATIONS_UNAVAILABLE'
  [Static Field] EXTRA_CHANGED_PACKAGE_LIST: Ljava/lang/String; = 'android.intent.extra.changed_package_list'
  [Static Field] EXTRA_CHANGED_UID_LIST: Ljava/lang/String; = 'android.intent.extra.changed_uid_list'
  [Static Field] EXTRA_HTML_TEXT: Ljava/lang/String; = 'android.intent.extra.HTML_TEXT'
  [Static Field] FLAG_ACTIVITY_CLEAR_TASK: I = 32768
  [Static Field] FLAG_ACTIVITY_TASK_ON_HOME: I = 16384

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void