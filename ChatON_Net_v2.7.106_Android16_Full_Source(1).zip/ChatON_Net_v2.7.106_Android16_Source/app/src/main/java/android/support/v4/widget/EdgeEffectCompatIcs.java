=== CLASS Landroid/support/v4/widget/EdgeEffectCompatIcs; (Source: EdgeEffectCompatIcs.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] draw(Ljava/lang/Object;, Landroid/graphics/Canvas;) -> Z
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v1, Landroid/widget/EdgeEffect;
    0002: invoke-virtual {v1, v2}, Landroid/widget/EdgeEffect;->draw(Landroid/graphics/Canvas;)Z
    0005: move-result v0
    0006: return v0

  [Direct Method] finish(Ljava/lang/Object;) -> V
    // registers=1, ins=1, outs=1, insns_size=6
    0000: check-cast v0, Landroid/widget/EdgeEffect;
    0002: invoke-virtual {v0}, Landroid/widget/EdgeEffect;->finish()V
    0005: return-void

  [Direct Method] isFinished(Ljava/lang/Object;) -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/widget/EdgeEffect;
    0002: invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z
    0005: move-result v0
    0006: return v0

  [Direct Method] newEdgeEffect(Landroid/content/Context;) -> Ljava/lang/Object;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Landroid/widget/EdgeEffect;
    0002: invoke-direct {v0, v1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V
    0005: return-object v0

  [Direct Method] onAbsorb(Ljava/lang/Object;, I) -> Z
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v1, Landroid/widget/EdgeEffect;
    0002: invoke-virtual {v1, v2}, Landroid/widget/EdgeEffect;->onAbsorb(I)V
    0005: const/4 v0, 1
    0006: return v0

  [Direct Method] onPull(Ljava/lang/Object;, F) -> Z
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v1, Landroid/widget/EdgeEffect;
    0002: invoke-virtual {v1, v2}, Landroid/widget/EdgeEffect;->onPull(F)V
    0005: const/4 v0, 1
    0006: return v0

  [Direct Method] onRelease(Ljava/lang/Object;) -> Z
    // registers=2, ins=1, outs=1, insns_size=10
    0000: check-cast v1, Landroid/widget/EdgeEffect;
    0002: invoke-virtual {v1}, Landroid/widget/EdgeEffect;->onRelease()V
    0005: invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z
    0008: move-result v0
    0009: return v0

  [Direct Method] setSize(Ljava/lang/Object;, I, I) -> V
    // registers=3, ins=3, outs=3, insns_size=6
    0000: check-cast v0, Landroid/widget/EdgeEffect;
    0002: invoke-virtual {v0, v1, v2}, Landroid/widget/EdgeEffect;->setSize(II)V
    0005: return-void