=== CLASS Landroid/support/v4/app/NotificationCompat; (Source: NotificationCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] FLAG_HIGH_PRIORITY: I = 128
  [Static Field] IMPL: Landroid/support/v4/app/NotificationCompat$NotificationCompatImpl;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=22
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 11 (0xb)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/app/NotificationCompat$NotificationCompatImplHoneycomb;
    0008: invoke-direct {v0}, Landroid/support/v4/app/NotificationCompat$NotificationCompatImplHoneycomb;-><init>()V
    000b: sput v0, Landroid/support/v4/app/NotificationCompat;->IMPL:Landroid/support/v4/app/NotificationCompat$NotificationCompatImpl;
    000d: return-void
    000e: new-instance v0, Landroid/support/v4/app/NotificationCompat$NotificationCompatImplBase;
    0010: invoke-direct {v0}, Landroid/support/v4/app/NotificationCompat$NotificationCompatImplBase;-><init>()V
    0013: sput v0, Landroid/support/v4/app/NotificationCompat;->IMPL:Landroid/support/v4/app/NotificationCompat$NotificationCompatImpl;
    0015: goto 000d

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] access$000() -> Landroid/support/v4/app/NotificationCompat$NotificationCompatImpl;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Landroid/support/v4/app/NotificationCompat;->IMPL:Landroid/support/v4/app/NotificationCompat$NotificationCompatImpl;
    0002: return-object v0