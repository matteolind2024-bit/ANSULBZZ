=== CLASS Landroid/support/v4/view/MenuItemCompat$HoneycombMenuVersionImpl; (Source: MenuItemCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/MenuItemCompat$MenuVersionImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] setActionView(Landroid/view/MenuItem;, Landroid/view/View;) -> Landroid/view/MenuItem;
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/MenuItemCompatHoneycomb;->setActionView(Landroid/view/MenuItem;Landroid/view/View;)Landroid/view/MenuItem;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] setShowAsAction(Landroid/view/MenuItem;, I) -> Z
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/MenuItemCompatHoneycomb;->setShowAsAction(Landroid/view/MenuItem;I)V
    0003: const/4 v0, 1
    0004: return v0