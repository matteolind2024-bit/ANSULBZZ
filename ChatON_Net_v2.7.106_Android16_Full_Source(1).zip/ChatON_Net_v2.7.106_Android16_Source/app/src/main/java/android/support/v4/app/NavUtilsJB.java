=== CLASS Landroid/support/v4/app/NavUtilsJB; (Source: NavUtilsJB.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getParentActivityIntent(Landroid/app/Activity;) -> Landroid/content/Intent;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/app/Activity;->getParentActivityIntent()Landroid/content/Intent;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] getParentActivityName(Landroid/content/pm/ActivityInfo;) -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/content/pm/ActivityInfo;->parentActivityName:Ljava/lang/String;
    0002: return-object v0

  [Direct Method] navigateUpTo(Landroid/app/Activity;, Landroid/content/Intent;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/app/Activity;->navigateUpTo(Landroid/content/Intent;)Z
    0003: return-void

  [Direct Method] shouldUpRecreateTask(Landroid/app/Activity;, Landroid/content/Intent;) -> Z
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/app/Activity;->shouldUpRecreateTask(Landroid/content/Intent;)Z
    0003: move-result v0
    0004: return v0