=== CLASS Landroid/support/v4/view/MotionEventCompatEclair; (Source: MotionEventCompatEclair.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] findPointerIndex(Landroid/view/MotionEvent;, I) -> I
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/view/MotionEvent;->findPointerIndex(I)I
    0003: move-result v0
    0004: return v0

  [Direct Method] getPointerId(Landroid/view/MotionEvent;, I) -> I
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/view/MotionEvent;->getPointerId(I)I
    0003: move-result v0
    0004: return v0

  [Direct Method] getX(Landroid/view/MotionEvent;, I) -> F
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/view/MotionEvent;->getX(I)F
    0003: move-result v0
    0004: return v0

  [Direct Method] getY(Landroid/view/MotionEvent;, I) -> F
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/view/MotionEvent;->getY(I)F
    0003: move-result v0
    0004: return v0