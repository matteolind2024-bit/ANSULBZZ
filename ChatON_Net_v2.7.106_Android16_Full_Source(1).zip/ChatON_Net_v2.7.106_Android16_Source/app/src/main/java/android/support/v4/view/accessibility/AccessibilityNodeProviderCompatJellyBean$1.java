=== CLASS Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$1; (Source: AccessibilityNodeProviderCompatJellyBean.java) ===
  Super: Landroid/view/accessibility/AccessibilityNodeProvider;
  [Instance Field] val$bridge: Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;

  [Direct Method] <init>(Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$1;->val$bridge:Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;
    0002: invoke-direct {v0}, Landroid/view/accessibility/AccessibilityNodeProvider;-><init>()V
    0005: return-void

  [Virtual Method] createAccessibilityNodeInfo(I) -> Landroid/view/accessibility/AccessibilityNodeInfo;
    // registers=3, ins=2, outs=2, insns_size=9
    0000: iget v0, v1.Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$1;->val$bridge:Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;
    0002: invoke-interface {v0, v2}, Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;->createAccessibilityNodeInfo(I)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo;
    0008: return-object v0

  [Virtual Method] findAccessibilityNodeInfosByText(Ljava/lang/String;, I) -> Ljava/util/List;
    // registers=4, ins=3, outs=3, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$1;->val$bridge:Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;
    0002: invoke-interface {v0, v2, v3}, Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;->findAccessibilityNodeInfosByText(Ljava/lang/String;I)Ljava/util/List;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] performAction(I, I, Landroid/os/Bundle;) -> Z
    // registers=5, ins=4, outs=4, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$1;->val$bridge:Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;
    0002: invoke-interface {v0, v2, v3, v4}, Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;->performAction(IILandroid/os/Bundle;)Z
    0005: move-result v0
    0006: return v0