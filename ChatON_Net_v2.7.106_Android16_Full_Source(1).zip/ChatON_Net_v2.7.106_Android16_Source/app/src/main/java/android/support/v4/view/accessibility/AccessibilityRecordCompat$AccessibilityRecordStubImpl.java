=== CLASS Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordStubImpl; (Source: AccessibilityRecordCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getAddedCount(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getBeforeText(Ljava/lang/Object;) -> Ljava/lang/CharSequence;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getClassName(Ljava/lang/Object;) -> Ljava/lang/CharSequence;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getContentDescription(Ljava/lang/Object;) -> Ljava/lang/CharSequence;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getCurrentItemIndex(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getFromIndex(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getItemCount(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getMaxScrollX(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getMaxScrollY(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getParcelableData(Ljava/lang/Object;) -> Landroid/os/Parcelable;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getRemovedCount(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getScrollX(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getScrollY(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getSource(Ljava/lang/Object;) -> Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getText(Ljava/lang/Object;) -> Ljava/util/List;
    // registers=3, ins=2, outs=0, insns_size=5
    0000: invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getToIndex(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getWindowId(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isChecked(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isEnabled(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isFullScreen(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isPassword(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isScrollable(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] obtain() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] obtain(Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] recycle(Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setAddedCount(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setBeforeText(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setChecked(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setClassName(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setContentDescription(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setCurrentItemIndex(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setEnabled(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setFromIndex(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setFullScreen(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setItemCount(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setMaxScrollX(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setMaxScrollY(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setParcelableData(Ljava/lang/Object;, Landroid/os/Parcelable;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setPassword(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setRemovedCount(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setScrollX(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setScrollY(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setScrollable(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setSource(Ljava/lang/Object;, Landroid/view/View;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setSource(Ljava/lang/Object;, Landroid/view/View;, I) -> V
    // registers=4, ins=4, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setToIndex(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void