=== CLASS Landroid/support/v4/app/FragmentManager; (Source: FragmentManager.java) ===
  Super: Ljava/lang/Object;
  [Static Field] POP_BACK_STACK_INCLUSIVE: I = 1

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] enableDebugLogging(Z) -> V
    // registers=1, ins=1, outs=0, insns_size=3
    0000: sput v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0002: return-void

  [Virtual Method] addOnBackStackChangedListener(Landroid/support/v4/app/FragmentManager$OnBackStackChangedListener;) -> V

  [Virtual Method] beginTransaction() -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] dump(Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V

  [Virtual Method] executePendingTransactions() -> Z

  [Virtual Method] findFragmentById(I) -> Landroid/support/v4/app/Fragment;

  [Virtual Method] findFragmentByTag(Ljava/lang/String;) -> Landroid/support/v4/app/Fragment;

  [Virtual Method] getBackStackEntryAt(I) -> Landroid/support/v4/app/FragmentManager$BackStackEntry;

  [Virtual Method] getBackStackEntryCount() -> I

  [Virtual Method] getFragment(Landroid/os/Bundle;, Ljava/lang/String;) -> Landroid/support/v4/app/Fragment;

  [Virtual Method] openTransaction() -> Landroid/support/v4/app/FragmentTransaction;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/support/v4/app/FragmentManager;->beginTransaction()Landroid/support/v4/app/FragmentTransaction;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] popBackStack() -> V

  [Virtual Method] popBackStack(I, I) -> V

  [Virtual Method] popBackStack(Ljava/lang/String;, I) -> V

  [Virtual Method] popBackStackImmediate() -> Z

  [Virtual Method] popBackStackImmediate(I, I) -> Z

  [Virtual Method] popBackStackImmediate(Ljava/lang/String;, I) -> Z

  [Virtual Method] putFragment(Landroid/os/Bundle;, Ljava/lang/String;, Landroid/support/v4/app/Fragment;) -> V

  [Virtual Method] removeOnBackStackChangedListener(Landroid/support/v4/app/FragmentManager$OnBackStackChangedListener;) -> V

  [Virtual Method] saveFragmentInstanceState(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/Fragment$SavedState;