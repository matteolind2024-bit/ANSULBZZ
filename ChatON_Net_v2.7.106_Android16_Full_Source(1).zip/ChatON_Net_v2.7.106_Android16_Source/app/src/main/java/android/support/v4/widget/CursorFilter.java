=== CLASS Landroid/support/v4/widget/CursorFilter; (Source: CursorFilter.java) ===
  Super: Landroid/widget/Filter;
  [Instance Field] mClient: Landroid/support/v4/widget/CursorFilter$CursorFilterClient;

  [Direct Method] <init>(Landroid/support/v4/widget/CursorFilter$CursorFilterClient;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: invoke-direct {v0}, Landroid/widget/Filter;-><init>()V
    0003: iput v1, v0.Landroid/support/v4/widget/CursorFilter;->mClient:Landroid/support/v4/widget/CursorFilter$CursorFilterClient;
    0005: return-void

  [Virtual Method] convertResultToString(Ljava/lang/Object;) -> Ljava/lang/CharSequence;
    // registers=3, ins=2, outs=2, insns_size=9
    0000: iget v0, v1.Landroid/support/v4/widget/CursorFilter;->mClient:Landroid/support/v4/widget/CursorFilter$CursorFilterClient;
    0002: check-cast v2, Landroid/database/Cursor;
    0004: invoke-interface {v0, v2}, Landroid/support/v4/widget/CursorFilter$CursorFilterClient;->convertToString(Landroid/database/Cursor;)Ljava/lang/CharSequence;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] performFiltering(Ljava/lang/CharSequence;) -> Landroid/widget/Filter$FilterResults;
    // registers=5, ins=2, outs=2, insns_size=29
    0000: iget v0, v3.Landroid/support/v4/widget/CursorFilter;->mClient:Landroid/support/v4/widget/CursorFilter$CursorFilterClient;
    0002: invoke-interface {v0, v4}, Landroid/support/v4/widget/CursorFilter$CursorFilterClient;->runQueryOnBackgroundThread(Ljava/lang/CharSequence;)Landroid/database/Cursor;
    0005: move-result-object v0
    0006: new-instance v1, Landroid/widget/Filter$FilterResults;
    0008: invoke-direct {v1}, Landroid/widget/Filter$FilterResults;-><init>()V
    000b: if-eqz v0, 0016
    000d: invoke-interface {v0}, Landroid/database/Cursor;->getCount()I
    0010: move-result v2
    0011: iput v2, v1.Landroid/widget/Filter$FilterResults;->count:I
    0013: iput v0, v1.Landroid/widget/Filter$FilterResults;->values:Ljava/lang/Object;
    0015: return-object v1
    0016: const/4 v0, 0
    0017: iput v0, v1.Landroid/widget/Filter$FilterResults;->count:I
    0019: const/4 v0, 0
    001a: iput v0, v1.Landroid/widget/Filter$FilterResults;->values:Ljava/lang/Object;
    001c: goto 0015

  [Virtual Method] publishResults(Ljava/lang/CharSequence;, Landroid/widget/Filter$FilterResults;) -> V
    // registers=5, ins=3, outs=2, insns_size=24
    0000: iget v0, v2.Landroid/support/v4/widget/CursorFilter;->mClient:Landroid/support/v4/widget/CursorFilter$CursorFilterClient;
    0002: invoke-interface {v0}, Landroid/support/v4/widget/CursorFilter$CursorFilterClient;->getCursor()Landroid/database/Cursor;
    0005: move-result-object v0
    0006: iget v1, v4.Landroid/widget/Filter$FilterResults;->values:Ljava/lang/Object;
    0008: if-eqz v1, 0017
    000a: iget v1, v4.Landroid/widget/Filter$FilterResults;->values:Ljava/lang/Object;
    000c: if-eq v1, v0, 0017
    000e: iget v1, v2.Landroid/support/v4/widget/CursorFilter;->mClient:Landroid/support/v4/widget/CursorFilter$CursorFilterClient;
    0010: iget v0, v4.Landroid/widget/Filter$FilterResults;->values:Ljava/lang/Object;
    0012: check-cast v0, Landroid/database/Cursor;
    0014: invoke-interface {v1, v0}, Landroid/support/v4/widget/CursorFilter$CursorFilterClient;->changeCursor(Landroid/database/Cursor;)V
    0017: return-void