=== CLASS Landroid/support/v4/widget/ScrollerCompat; (Source: ScrollerCompat.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] mScroller: Landroid/widget/Scroller;

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=3, ins=2, outs=2, insns_size=11
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Landroid/widget/Scroller;
    0005: invoke-direct {v0, v2}, Landroid/widget/Scroller;-><init>(Landroid/content/Context;)V
    0008: iput v0, v1.Landroid/support/v4/widget/ScrollerCompat;->mScroller:Landroid/widget/Scroller;
    000a: return-void

  [Direct Method] from(Landroid/content/Context;) -> Landroid/support/v4/widget/ScrollerCompat;
    // registers=3, ins=1, outs=2, insns_size=18
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 14 (0xe)
    0004: if-lt v0, v1, 000c
    0006: new-instance v0, Landroid/support/v4/widget/ScrollerCompat$ScrollerCompatImplIcs;
    0008: invoke-direct {v0, v2}, Landroid/support/v4/widget/ScrollerCompat$ScrollerCompatImplIcs;-><init>(Landroid/content/Context;)V
    000b: return-object v0
    000c: new-instance v0, Landroid/support/v4/widget/ScrollerCompat;
    000e: invoke-direct {v0, v2}, Landroid/support/v4/widget/ScrollerCompat;-><init>(Landroid/content/Context;)V
    0011: goto 000b

  [Virtual Method] abortAnimation() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/widget/ScrollerCompat;->mScroller:Landroid/widget/Scroller;
    0002: invoke-virtual {v0}, Landroid/widget/Scroller;->abortAnimation()V
    0005: return-void

  [Virtual Method] computeScrollOffset() -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/widget/ScrollerCompat;->mScroller:Landroid/widget/Scroller;
    0002: invoke-virtual {v0}, Landroid/widget/Scroller;->computeScrollOffset()Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] fling(I, I, I, I, I, I, I, I) -> V
    // registers=18, ins=9, outs=9, insns_size=16
    0000: iget v0, v9.Landroid/support/v4/widget/ScrollerCompat;->mScroller:Landroid/widget/Scroller;
    0002: move(op=01) v1, v10
    0003: move(op=01) v2, v11
    0004: move(op=01) v3, v12
    0005: move(op=01) v4, v13
    0006: move(op=01) v5, v14
    0007: move(op=01) v6, v15
    0008: move/from16 v7, v16
    000a: move/from16 v8, v17
    000c: invoke-virtual/range {v0..v8}, Landroid/widget/Scroller;->fling(IIIIIIII)V
    000f: return-void

  [Virtual Method] getCurrVelocity() -> F
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getCurrX() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/widget/ScrollerCompat;->mScroller:Landroid/widget/Scroller;
    0002: invoke-virtual {v0}, Landroid/widget/Scroller;->getCurrX()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] getCurrY() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/widget/ScrollerCompat;->mScroller:Landroid/widget/Scroller;
    0002: invoke-virtual {v0}, Landroid/widget/Scroller;->getCurrY()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] getDuration() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/widget/ScrollerCompat;->mScroller:Landroid/widget/Scroller;
    0002: invoke-virtual {v0}, Landroid/widget/Scroller;->getDuration()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] isFinished() -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/widget/ScrollerCompat;->mScroller:Landroid/widget/Scroller;
    0002: invoke-virtual {v0}, Landroid/widget/Scroller;->isFinished()Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] startScroll(I, I, I, I) -> V
    // registers=6, ins=5, outs=5, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/widget/ScrollerCompat;->mScroller:Landroid/widget/Scroller;
    0002: invoke-virtual {v0, v2, v3, v4, v5}, Landroid/widget/Scroller;->startScroll(IIII)V
    0005: return-void

  [Virtual Method] startScroll(I, I, I, I, I) -> V
    // registers=12, ins=6, outs=6, insns_size=11
    0000: iget v0, v6.Landroid/support/v4/widget/ScrollerCompat;->mScroller:Landroid/widget/Scroller;
    0002: move(op=01) v1, v7
    0003: move(op=01) v2, v8
    0004: move(op=01) v3, v9
    0005: move(op=01) v4, v10
    0006: move(op=01) v5, v11
    0007: invoke-virtual/range {v0..v5}, Landroid/widget/Scroller;->startScroll(IIIII)V
    000a: return-void