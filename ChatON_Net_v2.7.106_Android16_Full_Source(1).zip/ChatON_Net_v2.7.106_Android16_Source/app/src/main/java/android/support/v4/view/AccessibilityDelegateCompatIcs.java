=== CLASS Landroid/support/v4/view/AccessibilityDelegateCompatIcs; (Source: AccessibilityDelegateCompatIcs.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] dispatchPopulateAccessibilityEvent(Ljava/lang/Object;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> Z
    // registers=4, ins=3, outs=3, insns_size=7
    0000: check-cast v1, Landroid/view/View$AccessibilityDelegate;
    0002: invoke-virtual {v1, v2, v3}, Landroid/view/View$AccessibilityDelegate;->dispatchPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    0005: move-result v0
    0006: return v0

  [Direct Method] newAccessibilityDelegateBridge(Landroid/support/v4/view/AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge;) -> Ljava/lang/Object;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Landroid/support/v4/view/AccessibilityDelegateCompatIcs$1;
    0002: invoke-direct {v0, v1}, Landroid/support/v4/view/AccessibilityDelegateCompatIcs$1;-><init>(Landroid/support/v4/view/AccessibilityDelegateCompatIcs$AccessibilityDelegateBridge;)V
    0005: return-object v0

  [Direct Method] newAccessibilityDelegateDefaultImpl() -> Ljava/lang/Object;
    // registers=1, ins=0, outs=1, insns_size=6
    0000: new-instance v0, Landroid/view/View$AccessibilityDelegate;
    0002: invoke-direct {v0}, Landroid/view/View$AccessibilityDelegate;-><init>()V
    0005: return-object v0

  [Direct Method] onInitializeAccessibilityEvent(Ljava/lang/Object;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=3, ins=3, outs=3, insns_size=6
    0000: check-cast v0, Landroid/view/View$AccessibilityDelegate;
    0002: invoke-virtual {v0, v1, v2}, Landroid/view/View$AccessibilityDelegate;->onInitializeAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    0005: return-void

  [Direct Method] onInitializeAccessibilityNodeInfo(Ljava/lang/Object;, Landroid/view/View;, Ljava/lang/Object;) -> V
    // registers=3, ins=3, outs=3, insns_size=8
    0000: check-cast v0, Landroid/view/View$AccessibilityDelegate;
    0002: check-cast v2, Landroid/view/accessibility/AccessibilityNodeInfo;
    0004: invoke-virtual {v0, v1, v2}, Landroid/view/View$AccessibilityDelegate;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    0007: return-void

  [Direct Method] onPopulateAccessibilityEvent(Ljava/lang/Object;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=3, ins=3, outs=3, insns_size=6
    0000: check-cast v0, Landroid/view/View$AccessibilityDelegate;
    0002: invoke-virtual {v0, v1, v2}, Landroid/view/View$AccessibilityDelegate;->onPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    0005: return-void

  [Direct Method] onRequestSendAccessibilityEvent(Ljava/lang/Object;, Landroid/view/ViewGroup;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> Z
    // registers=5, ins=4, outs=4, insns_size=7
    0000: check-cast v1, Landroid/view/View$AccessibilityDelegate;
    0002: invoke-virtual {v1, v2, v3, v4}, Landroid/view/View$AccessibilityDelegate;->onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    0005: move-result v0
    0006: return v0

  [Direct Method] sendAccessibilityEvent(Ljava/lang/Object;, Landroid/view/View;, I) -> V
    // registers=3, ins=3, outs=3, insns_size=6
    0000: check-cast v0, Landroid/view/View$AccessibilityDelegate;
    0002: invoke-virtual {v0, v1, v2}, Landroid/view/View$AccessibilityDelegate;->sendAccessibilityEvent(Landroid/view/View;I)V
    0005: return-void

  [Direct Method] sendAccessibilityEventUnchecked(Ljava/lang/Object;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=3, ins=3, outs=3, insns_size=6
    0000: check-cast v0, Landroid/view/View$AccessibilityDelegate;
    0002: invoke-virtual {v0, v1, v2}, Landroid/view/View$AccessibilityDelegate;->sendAccessibilityEventUnchecked(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    0005: return-void