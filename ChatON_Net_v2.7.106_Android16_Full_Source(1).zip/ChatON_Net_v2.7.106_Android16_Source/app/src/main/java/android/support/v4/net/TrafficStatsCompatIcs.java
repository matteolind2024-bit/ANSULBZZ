=== CLASS Landroid/support/v4/net/TrafficStatsCompatIcs; (Source: TrafficStatsCompatIcs.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] clearThreadStatsTag() -> V
    // registers=0, ins=0, outs=0, insns_size=4
    0000: invoke-static {}, Landroid/net/TrafficStats;->clearThreadStatsTag()V
    0003: return-void

  [Direct Method] getThreadStatsTag() -> I
    // registers=1, ins=0, outs=0, insns_size=5
    0000: invoke-static {}, Landroid/net/TrafficStats;->getThreadStatsTag()I
    0003: move-result v0
    0004: return v0

  [Direct Method] incrementOperationCount(I) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-static {v0}, Landroid/net/TrafficStats;->incrementOperationCount(I)V
    0003: return-void

  [Direct Method] incrementOperationCount(I, I) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-static {v0, v1}, Landroid/net/TrafficStats;->incrementOperationCount(II)V
    0003: return-void

  [Direct Method] setThreadStatsTag(I) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-static {v0}, Landroid/net/TrafficStats;->setThreadStatsTag(I)V
    0003: return-void

  [Direct Method] tagSocket(Ljava/net/Socket;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-static {v0}, Landroid/net/TrafficStats;->tagSocket(Ljava/net/Socket;)V
    0003: return-void

  [Direct Method] untagSocket(Ljava/net/Socket;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-static {v0}, Landroid/net/TrafficStats;->untagSocket(Ljava/net/Socket;)V
    0003: return-void