=== CLASS Landroid/support/v4/widget/SimpleCursorAdapter$ViewBinder; (Source: SimpleCursorAdapter.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] setViewValue(Landroid/view/View;, Landroid/database/Cursor;, I) -> Z