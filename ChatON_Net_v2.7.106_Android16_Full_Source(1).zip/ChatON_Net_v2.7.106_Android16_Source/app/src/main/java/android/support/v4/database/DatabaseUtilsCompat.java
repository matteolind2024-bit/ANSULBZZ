=== CLASS Landroid/support/v4/database/DatabaseUtilsCompat; (Source: DatabaseUtilsCompat.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] appendSelectionArgs([Ljava/lang/String;, [Ljava/lang/String;) -> [Ljava/lang/String;
    // registers=6, ins=2, outs=5, insns_size=23
    0000: const/4 v3, 0
    0001: if-eqz v4, 0006
    0003: move(op=21) v0, v4
    0004: if-nez v0, 0007
    0006: return-object v5
    0007: move(op=21) v0, v4
    0008: move(op=21) v1, v5
    0009: binop/2addr(op=b0) v0, v1
    000a: new-array v0, v0, [Ljava/lang/String;
    000c: move(op=21) v1, v4
    000d: invoke-static {v4, v3, v0, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0010: move(op=21) v1, v4
    0011: move(op=21) v2, v5
    0012: invoke-static {v5, v3, v0, v1, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0015: move(op=07) v5, v0
    0016: goto 0006

  [Direct Method] concatenateWhere(Ljava/lang/String;, Ljava/lang/String;) -> Ljava/lang/String;
    // registers=4, ins=2, outs=2, insns_size=51
    0000: invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z
    0003: move-result v0
    0004: if-eqz v0, 0007
    0006: return-object v3
    0007: invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z
    000a: move-result v0
    000b: if-eqz v0, 000f
    000d: move(op=07) v3, v2
    000e: goto 0006
    000f: new-instance v0, Ljava/lang/StringBuilder;
    0011: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0014: const-string v1, '('
    0016: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0019: move-result-object v0
    001a: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001d: move-result-object v0
    001e: const-string v1, ') AND ('
    0020: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0023: move-result-object v0
    0024: invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0027: move-result-object v0
    0028: const-string v1, ')'
    002a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002d: move-result-object v0
    002e: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0031: move-result-object v3
    0032: goto 0006