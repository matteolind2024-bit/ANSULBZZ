=== CLASS Landroid/support/v4/content/pm/ActivityInfoCompat; (Source: ActivityInfoCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] CONFIG_UI_MODE: I = 512

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void