=== CLASS Landroid/support/v4/view/ViewPager$SavedState$1; (Source: ViewPager.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] createFromParcel(Landroid/os/Parcel;, Ljava/lang/ClassLoader;) -> Landroid/support/v4/view/ViewPager$SavedState;
    // registers=4, ins=3, outs=3, insns_size=6
    0000: new-instance v0, Landroid/support/v4/view/ViewPager$SavedState;
    0002: invoke-direct {v0, v2, v3}, Landroid/support/v4/view/ViewPager$SavedState;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V
    0005: return-object v0

  [Virtual Method] createFromParcel(Landroid/os/Parcel;, Ljava/lang/ClassLoader;) -> Ljava/lang/Object;
    // registers=4, ins=3, outs=3, insns_size=5
    0000: invoke-virtual {v1, v2, v3}, Landroid/support/v4/view/ViewPager$SavedState$1;->createFromParcel(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Landroid/support/v4/view/ViewPager$SavedState;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] newArray(I) -> [Landroid/support/v4/view/ViewPager$SavedState;
    // registers=3, ins=2, outs=0, insns_size=3
    0000: new-array v0, v2, [Landroid/support/v4/view/ViewPager$SavedState;
    0002: return-object v0

  [Virtual Method] newArray(I) -> [Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/support/v4/view/ViewPager$SavedState$1;->newArray(I)[Landroid/support/v4/view/ViewPager$SavedState;
    0003: move-result-object v0
    0004: return-object v0