=== CLASS Landroid/support/v4/widget/ScrollerCompat$ScrollerCompatImplIcs; (Source: ScrollerCompat.java) ===
  Super: Landroid/support/v4/widget/ScrollerCompat;

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Landroid/support/v4/widget/ScrollerCompat;-><init>(Landroid/content/Context;)V
    0003: return-void

  [Virtual Method] getCurrVelocity() -> F
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/widget/ScrollerCompat$ScrollerCompatImplIcs;->mScroller:Landroid/widget/Scroller;
    0002: invoke-static {v0}, Landroid/support/v4/widget/ScrollerCompatIcs;->getCurrVelocity(Landroid/widget/Scroller;)F
    0005: move-result v0
    0006: return v0