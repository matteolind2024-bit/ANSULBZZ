=== CLASS Landroid/support/v4/app/FragmentActivity; (Source: FragmentActivity.java) ===
  Super: Landroid/app/Activity;
  [Static Field] FRAGMENTS_TAG: Ljava/lang/String; = 'android:support:fragments'
  [Static Field] HONEYCOMB: I = 11
  [Static Field] MSG_REALLY_STOPPED: I = 1
  [Static Field] MSG_RESUME_PENDING: I = 2
  [Static Field] TAG: Ljava/lang/String; = 'FragmentActivity'
  [Instance Field] mAllLoaderManagers: Landroid/support/v4/util/SparseArrayCompat;
  [Instance Field] mCheckedForLoaderManager: Z
  [Instance Field] mCreated: Z
  [Instance Field] mFragments: Landroid/support/v4/app/FragmentManagerImpl;
  [Instance Field] mHandler: Landroid/os/Handler;
  [Instance Field] mLoaderManager: Landroid/support/v4/app/LoaderManagerImpl;
  [Instance Field] mLoadersStarted: Z
  [Instance Field] mOptionsMenuInvalidated: Z
  [Instance Field] mReallyStopped: Z
  [Instance Field] mResumed: Z
  [Instance Field] mRetaining: Z
  [Instance Field] mStopped: Z

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=18
    0000: invoke-direct {v1}, Landroid/app/Activity;-><init>()V
    0003: new-instance v0, Landroid/support/v4/app/FragmentActivity$1;
    0005: invoke-direct {v0, v1}, Landroid/support/v4/app/FragmentActivity$1;-><init>(Landroid/support/v4/app/FragmentActivity;)V
    0008: iput v0, v1.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    000a: new-instance v0, Landroid/support/v4/app/FragmentManagerImpl;
    000c: invoke-direct {v0}, Landroid/support/v4/app/FragmentManagerImpl;-><init>()V
    000f: iput v0, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0011: return-void

  [Virtual Method] doReallyStop(Z) -> V
    // registers=4, ins=2, outs=2, insns_size=18
    0000: const/4 v1, 1
    0001: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mReallyStopped:Z
    0003: if-nez v0, 0011
    0005: iput v1, v2.Landroid/support/v4/app/FragmentActivity;->mReallyStopped:Z
    0007: iput v3, v2.Landroid/support/v4/app/FragmentActivity;->mRetaining:Z
    0009: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    000b: invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V
    000e: invoke-virtual {v2}, Landroid/support/v4/app/FragmentActivity;->onReallyStop()V
    0011: return-void

  [Virtual Method] dump(Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V
    // registers=8, ins=5, outs=5, insns_size=165
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 11 (0xb)
    0004: if-lt v0, v1, 0006
    0006: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0009: const-string v0, 'Local FragmentActivity '
    000b: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    000e: invoke-static {v3}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I
    0011: move-result v0
    0012: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0015: move-result-object v0
    0016: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0019: const-string v0, ' State:'
    001b: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    001e: new-instance v0, Ljava/lang/StringBuilder;
    0020: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0023: invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0026: move-result-object v0
    0027: const-string v1, '  '
    0029: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002c: move-result-object v0
    002d: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0030: move-result-object v0
    0031: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0034: const-string v1, 'mCreated='
    0036: invoke-virtual {v6, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0039: iget v1, v3.Landroid/support/v4/app/FragmentActivity;->mCreated:Z
    003b: invoke-virtual {v6, v1}, Ljava/io/PrintWriter;->print(Z)V
    003e: const-string v1, 'mResumed='
    0040: invoke-virtual {v6, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0043: iget v1, v3.Landroid/support/v4/app/FragmentActivity;->mResumed:Z
    0045: invoke-virtual {v6, v1}, Ljava/io/PrintWriter;->print(Z)V
    0048: const-string v1, ' mStopped='
    004a: invoke-virtual {v6, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    004d: iget v1, v3.Landroid/support/v4/app/FragmentActivity;->mStopped:Z
    004f: invoke-virtual {v6, v1}, Ljava/io/PrintWriter;->print(Z)V
    0052: const-string v1, ' mReallyStopped='
    0054: invoke-virtual {v6, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0057: iget v1, v3.Landroid/support/v4/app/FragmentActivity;->mReallyStopped:Z
    0059: invoke-virtual {v6, v1}, Ljava/io/PrintWriter;->println(Z)V
    005c: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    005f: const-string v0, 'mLoadersStarted='
    0061: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0064: iget v0, v3.Landroid/support/v4/app/FragmentActivity;->mLoadersStarted:Z
    0066: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Z)V
    0069: iget v0, v3.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    006b: if-eqz v0, 009f
    006d: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0070: const-string v0, 'Loader Manager '
    0072: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0075: iget v0, v3.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0077: invoke-static {v0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I
    007a: move-result v0
    007b: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    007e: move-result-object v0
    007f: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0082: const-string v0, ':'
    0084: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0087: iget v0, v3.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0089: new-instance v1, Ljava/lang/StringBuilder;
    008b: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    008e: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0091: move-result-object v1
    0092: const-string v2, '  '
    0094: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0097: move-result-object v1
    0098: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    009b: move-result-object v1
    009c: invoke-virtual {v0, v1, v5, v6, v7}, Landroid/support/v4/app/LoaderManagerImpl;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    009f: iget v0, v3.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    00a1: invoke-virtual {v0, v4, v5, v6, v7}, Landroid/support/v4/app/FragmentManagerImpl;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    00a4: return-void

  [Virtual Method] getLastCustomNonConfigurationInstance() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=13
    0000: invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->getLastNonConfigurationInstance()Ljava/lang/Object;
    0003: move-result-object v0
    0004: check-cast v0, Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;
    0006: if-eqz v0, 000b
    0008: iget v0, v0.Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;->custom:Ljava/lang/Object;
    000a: return-object v0
    000b: const/4 v0, 0
    000c: goto 000a

  [Virtual Method] getLoaderManager(I, Z, Z) -> Landroid/support/v4/app/LoaderManagerImpl;
    // registers=6, ins=4, outs=3, insns_size=38
    0000: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    0002: if-nez v0, 000b
    0004: new-instance v0, Landroid/support/v4/util/SparseArrayCompat;
    0006: invoke-direct {v0}, Landroid/support/v4/util/SparseArrayCompat;-><init>()V
    0009: iput v0, v2.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    000b: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    000d: invoke-virtual {v0, v3}, Landroid/support/v4/util/SparseArrayCompat;->get(I)Ljava/lang/Object;
    0010: move-result-object v0
    0011: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl;
    0013: if-nez v0, 0022
    0015: if-eqz v5, 0021
    0017: new-instance v0, Landroid/support/v4/app/LoaderManagerImpl;
    0019: invoke-direct {v0, v2, v4}, Landroid/support/v4/app/LoaderManagerImpl;-><init>(Landroid/support/v4/app/FragmentActivity;Z)V
    001c: iget v1, v2.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    001e: invoke-virtual {v1, v3, v0}, Landroid/support/v4/util/SparseArrayCompat;->put(ILjava/lang/Object;)V
    0021: return-object v0
    0022: invoke-virtual {v0, v2}, Landroid/support/v4/app/LoaderManagerImpl;->updateActivity(Landroid/support/v4/app/FragmentActivity;)V
    0025: goto 0021

  [Virtual Method] getSupportFragmentManager() -> Landroid/support/v4/app/FragmentManager;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0002: return-object v0

  [Virtual Method] getSupportLoaderManager() -> Landroid/support/v4/app/LoaderManager;
    // registers=4, ins=1, outs=4, insns_size=22
    0000: const/4 v2, 1
    0001: iget v0, v3.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0003: if-eqz v0, 0008
    0005: iget v0, v3.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0007: return-object v0
    0008: iput v2, v3.Landroid/support/v4/app/FragmentActivity;->mCheckedForLoaderManager:Z
    000a: const/4 v0, -1
    000b: iget v1, v3.Landroid/support/v4/app/FragmentActivity;->mLoadersStarted:Z
    000d: invoke-virtual {v3, v0, v1, v2}, Landroid/support/v4/app/FragmentActivity;->getLoaderManager(IZZ)Landroid/support/v4/app/LoaderManagerImpl;
    0010: move-result-object v0
    0011: iput v0, v3.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0013: iget v0, v3.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0015: goto 0007

  [Virtual Method] invalidateSupportFragmentIndex(I) -> V
    // registers=4, ins=2, outs=2, insns_size=27
    0000: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    0002: if-eqz v0, 001a
    0004: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    0006: invoke-virtual {v0, v3}, Landroid/support/v4/util/SparseArrayCompat;->get(I)Ljava/lang/Object;
    0009: move-result-object v0
    000a: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl;
    000c: if-eqz v0, 001a
    000e: iget v1, v0.Landroid/support/v4/app/LoaderManagerImpl;->mRetaining:Z
    0010: if-nez v1, 001a
    0012: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doDestroy()V
    0015: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    0017: invoke-virtual {v0, v3}, Landroid/support/v4/util/SparseArrayCompat;->remove(I)V
    001a: return-void

  [Virtual Method] onActivityResult(I, I, Landroid/content/Intent;) -> V
    // registers=7, ins=4, outs=4, insns_size=106
    0000: binop/lit8(op=e1) v0, v4, 16 (0x10)
    0002: if-eqz v0, 0066
    0004: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0006: iget v1, v3.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0008: iget v1, v1.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    000a: if-eqz v1, 0018
    000c: if-ltz v0, 0018
    000e: iget v1, v3.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0010: iget v1, v1.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0012: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0015: move-result v1
    0016: if-lt v0, v1, 0035
    0018: const-string v0, 'FragmentActivity'
    001a: new-instance v1, Ljava/lang/StringBuilder;
    001c: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    001f: const-string v2, 'Activity result fragment index out of range: 0x'
    0021: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0024: move-result-object v1
    0025: invoke-static {v4}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0028: move-result-object v2
    0029: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002c: move-result-object v1
    002d: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0030: move-result-object v1
    0031: invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    0034: return-void
    0035: iget v1, v3.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0037: iget v1, v1.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0039: invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    003c: move-result-object v0
    003d: check-cast v0, Landroid/support/v4/app/Fragment;
    003f: if-nez v0, 005e
    0041: const-string v0, 'FragmentActivity'
    0043: new-instance v1, Ljava/lang/StringBuilder;
    0045: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0048: const-string v2, 'Activity result no fragment exists for index: 0x'
    004a: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004d: move-result-object v1
    004e: invoke-static {v4}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0051: move-result-object v2
    0052: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0055: move-result-object v1
    0056: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0059: move-result-object v1
    005a: invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    005d: goto 0034
    005e: const v1, 65535 (0xffff)
    0061: binop/2addr(op=b5) v1, v4
    0062: invoke-virtual {v0, v1, v5, v6}, Landroid/support/v4/app/Fragment;->onActivityResult(IILandroid/content/Intent;)V
    0065: goto 0034
    0066: invoke-super {v3, v4, v5, v6}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V
    0069: goto 0034

  [Virtual Method] onAttachFragment(Landroid/support/v4/app/Fragment;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onBackPressed() -> V
    // registers=2, ins=1, outs=1, insns_size=12
    0000: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0002: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->popBackStackImmediate()Z
    0005: move-result v0
    0006: if-nez v0, 000b
    0008: invoke-virtual {v1}, Landroid/support/v4/app/FragmentActivity;->finish()V
    000b: return-void

  [Virtual Method] onConfigurationChanged(Landroid/content/res/Configuration;) -> V
    // registers=3, ins=2, outs=2, insns_size=9
    0000: invoke-super {v1, v2}, Landroid/app/Activity;->onConfigurationChanged(Landroid/content/res/Configuration;)V
    0003: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0005: invoke-virtual {v0, v2}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchConfigurationChanged(Landroid/content/res/Configuration;)V
    0008: return-void

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=5, ins=2, outs=3, insns_size=62
    0000: iget v0, v3.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0002: invoke-virtual {v0, v3}, Landroid/support/v4/app/FragmentManagerImpl;->attachActivity(Landroid/support/v4/app/FragmentActivity;)V
    0005: invoke-virtual {v3}, Landroid/support/v4/app/FragmentActivity;->getLayoutInflater()Landroid/view/LayoutInflater;
    0008: move-result-object v0
    0009: invoke-virtual {v0}, Landroid/view/LayoutInflater;->getFactory()Landroid/view/LayoutInflater$Factory;
    000c: move-result-object v0
    000d: if-nez v0, 0016
    000f: invoke-virtual {v3}, Landroid/support/v4/app/FragmentActivity;->getLayoutInflater()Landroid/view/LayoutInflater;
    0012: move-result-object v0
    0013: invoke-virtual {v0, v3}, Landroid/view/LayoutInflater;->setFactory(Landroid/view/LayoutInflater$Factory;)V
    0016: invoke-super {v3, v4}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V
    0019: invoke-virtual {v3}, Landroid/support/v4/app/FragmentActivity;->getLastNonConfigurationInstance()Ljava/lang/Object;
    001c: move-result-object v0
    001d: check-cast v0, Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;
    001f: if-eqz v0, 0025
    0021: iget v1, v0.Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;->loaders:Landroid/support/v4/util/SparseArrayCompat;
    0023: iput v1, v3.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    0025: if-eqz v4, 0036
    0027: const-string v1, 'android:support:fragments'
    0029: invoke-virtual {v4, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;
    002c: move-result-object v1
    002d: iget v2, v3.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    002f: if-eqz v0, 003c
    0031: iget v0, v0.Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;->fragments:Ljava/util/ArrayList;
    0033: invoke-virtual {v2, v1, v0}, Landroid/support/v4/app/FragmentManagerImpl;->restoreAllState(Landroid/os/Parcelable;Ljava/util/ArrayList;)V
    0036: iget v0, v3.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0038: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchCreate()V
    003b: return-void
    003c: const/4 v0, 0
    003d: goto 0033

  [Virtual Method] onCreatePanelMenu(I, Landroid/view/Menu;) -> Z
    // registers=6, ins=3, outs=3, insns_size=31
    0000: if-nez v4, 001a
    0002: invoke-super {v3, v4, v5}, Landroid/app/Activity;->onCreatePanelMenu(ILandroid/view/Menu;)Z
    0005: move-result v0
    0006: iget v1, v3.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0008: invoke-virtual {v3}, Landroid/support/v4/app/FragmentActivity;->getMenuInflater()Landroid/view/MenuInflater;
    000b: move-result-object v2
    000c: invoke-virtual {v1, v5, v2}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)Z
    000f: move-result v1
    0010: binop/2addr(op=b6) v0, v1
    0011: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    0013: const/16 v2, 11 (0xb)
    0015: if-lt v1, v2, 0018
    0017: return v0
    0018: const/4 v0, 1
    0019: goto 0017
    001a: invoke-super {v3, v4, v5}, Landroid/app/Activity;->onCreatePanelMenu(ILandroid/view/Menu;)Z
    001d: move-result v0
    001e: goto 0017

  [Virtual Method] onCreateView(Ljava/lang/String;, Landroid/content/Context;, Landroid/util/AttributeSet;) -> Landroid/view/View;
    // registers=13, ins=4, outs=4, insns_size=359
    0000: const/4 v3, 0
    0001: const/4 v1, 0
    0002: const/4 v8, 1
    0003: const/4 v6, -1
    0004: const-string v0, 'fragment'
    0006: invoke-virtual {v0, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0009: move-result v0
    000a: if-nez v0, 0011
    000c: invoke-super {v9, v10, v11, v12}, Landroid/app/Activity;->onCreateView(Ljava/lang/String;Landroid/content/Context;Landroid/util/AttributeSet;)Landroid/view/View;
    000f: move-result-object v0
    0010: return-object v0
    0011: const-string v0, 'class'
    0013: invoke-interface {v12, v1, v0}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    0016: move-result-object v0
    0017: sget v2, Landroid/support/v4/app/FragmentActivity$FragmentTag;->Fragment:[I
    0019: invoke-virtual {v11, v12, v2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    001c: move-result-object v4
    001d: if-nez v0, 0023
    001f: invoke-virtual {v4, v3}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    0022: move-result-object v0
    0023: invoke-virtual {v4, v8, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I
    0026: move-result v2
    0027: const/4 v5, 2
    0028: invoke-virtual {v4, v5}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;
    002b: move-result-object v5
    002c: invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V
    002f: if-eqz v1, 0035
    0031: invoke-virtual {v1}, Landroid/view/View;->getId()I
    0034: move-result v3
    0035: if-ne v3, v6, 005c
    0037: if-ne v2, v6, 005c
    0039: if-nez v5, 005c
    003b: new-instance v1, Ljava/lang/IllegalArgumentException;
    003d: new-instance v2, Ljava/lang/StringBuilder;
    003f: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0042: invoke-interface {v12}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;
    0045: move-result-object v3
    0046: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0049: move-result-object v2
    004a: const-string v3, ': Must specify unique android:id, android:tag, or have a parent with an id for '
    004c: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004f: move-result-object v2
    0050: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0053: move-result-object v0
    0054: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0057: move-result-object v0
    0058: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    005b: throw v1
    005c: if-eq v2, v6, 0064
    005e: iget v1, v9.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0060: invoke-virtual {v1, v2}, Landroid/support/v4/app/FragmentManagerImpl;->findFragmentById(I)Landroid/support/v4/app/Fragment;
    0063: move-result-object v1
    0064: if-nez v1, 006e
    0066: if-eqz v5, 006e
    0068: iget v1, v9.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    006a: invoke-virtual {v1, v5}, Landroid/support/v4/app/FragmentManagerImpl;->findFragmentByTag(Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    006d: move-result-object v1
    006e: if-nez v1, 0078
    0070: if-eq v3, v6, 0078
    0072: iget v1, v9.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0074: invoke-virtual {v1, v3}, Landroid/support/v4/app/FragmentManagerImpl;->findFragmentById(I)Landroid/support/v4/app/Fragment;
    0077: move-result-object v1
    0078: sget v4, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    007a: if-eqz v4, 00ac
    007c: const-string v4, 'FragmentActivity'
    007e: new-instance v6, Ljava/lang/StringBuilder;
    0080: invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V
    0083: const-string v7, 'onCreateView: id=0x'
    0085: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0088: move-result-object v6
    0089: invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    008c: move-result-object v7
    008d: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0090: move-result-object v6
    0091: const-string v7, ' fname='
    0093: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0096: move-result-object v6
    0097: invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    009a: move-result-object v6
    009b: const-string v7, ' existing='
    009d: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a0: move-result-object v6
    00a1: invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00a4: move-result-object v6
    00a5: invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00a8: move-result-object v6
    00a9: invoke-static {v4, v6}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00ac: if-nez v1, 00f3
    00ae: invoke-static {v9, v0}, Landroid/support/v4/app/Fragment;->instantiate(Landroid/content/Context;Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    00b1: move-result-object v4
    00b2: iput v8, v4.Landroid/support/v4/app/Fragment;->mFromLayout:Z
    00b4: if-eqz v2, 00f1
    00b6: move(op=01) v1, v2
    00b7: iput v1, v4.Landroid/support/v4/app/Fragment;->mFragmentId:I
    00b9: iput v3, v4.Landroid/support/v4/app/Fragment;->mContainerId:I
    00bb: iput v5, v4.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    00bd: iput v8, v4.Landroid/support/v4/app/Fragment;->mInLayout:Z
    00bf: iget v1, v9.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    00c1: iput v1, v4.Landroid/support/v4/app/Fragment;->mFragmentManager:Landroid/support/v4/app/FragmentManagerImpl;
    00c3: iget v1, v4.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    00c5: invoke-virtual {v4, v9, v12, v1}, Landroid/support/v4/app/Fragment;->onInflate(Landroid/app/Activity;Landroid/util/AttributeSet;Landroid/os/Bundle;)V
    00c8: iget v1, v9.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    00ca: invoke-virtual {v1, v4, v8}, Landroid/support/v4/app/FragmentManagerImpl;->addFragment(Landroid/support/v4/app/Fragment;Z)V
    00cd: move(op=07) v1, v4
    00ce: iget v3, v1.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    00d0: if-nez v3, 014f
    00d2: new-instance v1, Ljava/lang/IllegalStateException;
    00d4: new-instance v2, Ljava/lang/StringBuilder;
    00d6: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    00d9: const-string v3, 'Fragment '
    00db: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00de: move-result-object v2
    00df: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00e2: move-result-object v0
    00e3: const-string v2, ' did not create a view.'
    00e5: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00e8: move-result-object v0
    00e9: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00ec: move-result-object v0
    00ed: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    00f0: throw v1
    00f1: move(op=01) v1, v3
    00f2: goto 00b7
    00f3: iget v4, v1.Landroid/support/v4/app/Fragment;->mInLayout:Z
    00f5: if-eqz v4, 013e
    00f7: new-instance v1, Ljava/lang/IllegalArgumentException;
    00f9: new-instance v4, Ljava/lang/StringBuilder;
    00fb: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    00fe: invoke-interface {v12}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;
    0101: move-result-object v6
    0102: invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0105: move-result-object v4
    0106: const-string v6, ': Duplicate id 0x'
    0108: invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    010b: move-result-object v4
    010c: invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    010f: move-result-object v2
    0110: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0113: move-result-object v2
    0114: const-string v4, ', tag '
    0116: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0119: move-result-object v2
    011a: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    011d: move-result-object v2
    011e: const-string v4, ', or parent id 0x'
    0120: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0123: move-result-object v2
    0124: invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0127: move-result-object v3
    0128: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    012b: move-result-object v2
    012c: const-string v3, ' with another fragment for '
    012e: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0131: move-result-object v2
    0132: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0135: move-result-object v0
    0136: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0139: move-result-object v0
    013a: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    013d: throw v1
    013e: iput v8, v1.Landroid/support/v4/app/Fragment;->mInLayout:Z
    0140: iget v3, v1.Landroid/support/v4/app/Fragment;->mRetaining:Z
    0142: if-nez v3, 0149
    0144: iget v3, v1.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    0146: invoke-virtual {v1, v9, v12, v3}, Landroid/support/v4/app/Fragment;->onInflate(Landroid/app/Activity;Landroid/util/AttributeSet;Landroid/os/Bundle;)V
    0149: iget v3, v9.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    014b: invoke-virtual {v3, v1}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(Landroid/support/v4/app/Fragment;)V
    014e: goto 00ce
    014f: if-eqz v2, 0156
    0151: iget v0, v1.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0153: invoke-virtual {v0, v2}, Landroid/view/View;->setId(I)V
    0156: iget v0, v1.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0158: invoke-virtual {v0}, Landroid/view/View;->getTag()Ljava/lang/Object;
    015b: move-result-object v0
    015c: if-nez v0, 0163
    015e: iget v0, v1.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0160: invoke-virtual {v0, v5}, Landroid/view/View;->setTag(Ljava/lang/Object;)V
    0163: iget v0, v1.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0165: goto/16 0010

  [Virtual Method] onDestroy() -> V
    // registers=2, ins=1, outs=2, insns_size=22
    0000: invoke-super {v1}, Landroid/app/Activity;->onDestroy()V
    0003: const/4 v0, 0
    0004: invoke-virtual {v1, v0}, Landroid/support/v4/app/FragmentActivity;->doReallyStop(Z)V
    0007: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0009: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchDestroy()V
    000c: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    000e: if-eqz v0, 0015
    0010: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0012: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doDestroy()V
    0015: return-void

  [Virtual Method] onKeyDown(I, Landroid/view/KeyEvent;) -> Z
    // registers=5, ins=3, outs=3, insns_size=24
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/4 v1, 5
    0003: if-ge v0, v1, 0013
    0005: const/4 v0, 4
    0006: if-ne v3, v0, 0013
    0008: invoke-virtual {v4}, Landroid/view/KeyEvent;->getRepeatCount()I
    000b: move-result v0
    000c: if-nez v0, 0013
    000e: invoke-virtual {v2}, Landroid/support/v4/app/FragmentActivity;->onBackPressed()V
    0011: const/4 v0, 1
    0012: return v0
    0013: invoke-super {v2, v3, v4}, Landroid/app/Activity;->onKeyDown(ILandroid/view/KeyEvent;)Z
    0016: move-result v0
    0017: goto 0012

  [Virtual Method] onLowMemory() -> V
    // registers=2, ins=1, outs=1, insns_size=9
    0000: invoke-super {v1}, Landroid/app/Activity;->onLowMemory()V
    0003: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0005: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchLowMemory()V
    0008: return-void

  [Virtual Method] onMenuItemSelected(I, Landroid/view/MenuItem;) -> Z
    // registers=4, ins=3, outs=3, insns_size=38
    0000: invoke-super {v1, v2, v3}, Landroid/app/Activity;->onMenuItemSelected(ILandroid/view/MenuItem;)Z
    0003: move-result v0
    0004: if-eqz v0, 0008
    0006: const/4 v0, 1
    0007: return v0
    0008: sparse-switch v2, +20 (-> 001c)
    000b: const/4 v0, 0
    000c: goto 0007
    000d: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    000f: invoke-virtual {v0, v3}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchOptionsItemSelected(Landroid/view/MenuItem;)Z
    0012: move-result v0
    0013: goto 0007
    0014: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0016: invoke-virtual {v0, v3}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchContextItemSelected(Landroid/view/MenuItem;)Z
    0019: move-result v0
    001a: goto 0007
    001b: nop
    001c: sparse-switch-payload {0: 5, 6: 12}

  [Virtual Method] onPanelClosed(I, Landroid/view/Menu;) -> V
    // registers=4, ins=3, outs=3, insns_size=20
    0000: packed-switch v2, +14 (-> 000e)
    0003: invoke-super {v1, v2, v3}, Landroid/app/Activity;->onPanelClosed(ILandroid/view/Menu;)V
    0006: return-void
    0007: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0009: invoke-virtual {v0, v3}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchOptionsMenuClosed(Landroid/view/Menu;)V
    000c: goto 0003
    000d: nop
    000e: packed-switch-payload first=0 targets=[7]

  [Virtual Method] onPause() -> V
    // registers=3, ins=1, outs=2, insns_size=29
    0000: const/4 v1, 2
    0001: invoke-super {v2}, Landroid/app/Activity;->onPause()V
    0004: const/4 v0, 0
    0005: iput v0, v2.Landroid/support/v4/app/FragmentActivity;->mResumed:Z
    0007: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    0009: invoke-virtual {v0, v1}, Landroid/os/Handler;->hasMessages(I)Z
    000c: move-result v0
    000d: if-eqz v0, 0017
    000f: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    0011: invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V
    0014: invoke-virtual {v2}, Landroid/support/v4/app/FragmentActivity;->onResumeFragments()V
    0017: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0019: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchPause()V
    001c: return-void

  [Virtual Method] onPostResume() -> V
    // registers=3, ins=1, outs=2, insns_size=18
    0000: invoke-super {v2}, Landroid/app/Activity;->onPostResume()V
    0003: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    0005: const/4 v1, 2
    0006: invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V
    0009: invoke-virtual {v2}, Landroid/support/v4/app/FragmentActivity;->onResumeFragments()V
    000c: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    000e: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->execPendingActions()Z
    0011: return-void

  [Virtual Method] onPreparePanel(I, Landroid/view/View;, Landroid/view/Menu;) -> Z
    // registers=7, ins=4, outs=4, insns_size=43
    0000: const/4 v0, 0
    0001: if-nez v4, 0026
    0003: if-eqz v6, 0026
    0005: iget v1, v3.Landroid/support/v4/app/FragmentActivity;->mOptionsMenuInvalidated:Z
    0007: if-eqz v1, 0011
    0009: iput v0, v3.Landroid/support/v4/app/FragmentActivity;->mOptionsMenuInvalidated:Z
    000b: invoke-interface {v6}, Landroid/view/Menu;->clear()V
    000e: invoke-virtual {v3, v4, v6}, Landroid/support/v4/app/FragmentActivity;->onCreatePanelMenu(ILandroid/view/Menu;)Z
    0011: invoke-super {v3, v4, v5, v6}, Landroid/app/Activity;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z
    0014: move-result v1
    0015: iget v2, v3.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0017: invoke-virtual {v2, v6}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchPrepareOptionsMenu(Landroid/view/Menu;)Z
    001a: move-result v2
    001b: binop/2addr(op=b6) v1, v2
    001c: if-eqz v1, 0025
    001e: invoke-interface {v6}, Landroid/view/Menu;->hasVisibleItems()Z
    0021: move-result v1
    0022: if-eqz v1, 0025
    0024: const/4 v0, 1
    0025: return v0
    0026: invoke-super {v3, v4, v5, v6}, Landroid/app/Activity;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z
    0029: move-result v0
    002a: goto 0025

  [Virtual Method] onReallyStop() -> V
    // registers=2, ins=1, outs=1, insns_size=32
    0000: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mLoadersStarted:Z
    0002: if-eqz v0, 0014
    0004: const/4 v0, 0
    0005: iput v0, v1.Landroid/support/v4/app/FragmentActivity;->mLoadersStarted:Z
    0007: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0009: if-eqz v0, 0014
    000b: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mRetaining:Z
    000d: if-nez v0, 001a
    000f: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0011: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doStop()V
    0014: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0016: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchReallyStop()V
    0019: return-void
    001a: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    001c: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doRetain()V
    001f: goto 0014

  [Virtual Method] onResume() -> V
    // registers=3, ins=1, outs=2, insns_size=18
    0000: invoke-super {v2}, Landroid/app/Activity;->onResume()V
    0003: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    0005: const/4 v1, 2
    0006: invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z
    0009: const/4 v0, 1
    000a: iput v0, v2.Landroid/support/v4/app/FragmentActivity;->mResumed:Z
    000c: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    000e: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->execPendingActions()Z
    0011: return-void

  [Virtual Method] onResumeFragments() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0002: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchResume()V
    0005: return-void

  [Virtual Method] onRetainCustomNonConfigurationInstance() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] onRetainNonConfigurationInstance() -> Ljava/lang/Object;
    // registers=9, ins=1, outs=2, insns_size=89
    0000: const/4 v1, 1
    0001: const/4 v3, 0
    0002: iget v0, v8.Landroid/support/v4/app/FragmentActivity;->mStopped:Z
    0004: if-eqz v0, 0009
    0006: invoke-virtual {v8, v1}, Landroid/support/v4/app/FragmentActivity;->doReallyStop(Z)V
    0009: invoke-virtual {v8}, Landroid/support/v4/app/FragmentActivity;->onRetainCustomNonConfigurationInstance()Ljava/lang/Object;
    000c: move-result-object v5
    000d: iget v0, v8.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    000f: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->retainNonConfig()Ljava/util/ArrayList;
    0012: move-result-object v6
    0013: const/4 v2, 0
    0014: iget v0, v8.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    0016: if-eqz v0, 003f
    0018: iget v0, v8.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    001a: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    001d: move-result v0
    001e: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0020: move(op=01) v4, v0
    0021: if-ltz v4, 003f
    0023: iget v0, v8.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    0025: invoke-virtual {v0, v4}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0028: move-result-object v0
    0029: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl;
    002b: iget v7, v0.Landroid/support/v4/app/LoaderManagerImpl;->mRetaining:Z
    002d: if-eqz v7, 0035
    002f: move(op=01) v0, v1
    0030: binop/lit8(op=d8) v2, v4, -1 (-0x1)
    0032: move(op=01) v4, v2
    0033: move(op=01) v2, v0
    0034: goto 0021
    0035: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doDestroy()V
    0038: iget v0, v8.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    003a: invoke-virtual {v0, v4}, Landroid/support/v4/util/SparseArrayCompat;->removeAt(I)V
    003d: move(op=01) v0, v2
    003e: goto 0030
    003f: if-nez v6, 0047
    0041: if-nez v2, 0047
    0043: if-nez v5, 0047
    0045: move(op=07) v0, v3
    0046: return-object v0
    0047: new-instance v0, Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;
    0049: invoke-direct {v0}, Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;-><init>()V
    004c: iput v3, v0.Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;->activity:Ljava/lang/Object;
    004e: iput v5, v0.Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;->custom:Ljava/lang/Object;
    0050: iput v3, v0.Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;->children:Ljava/util/HashMap;
    0052: iput v6, v0.Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;->fragments:Ljava/util/ArrayList;
    0054: iget v1, v8.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    0056: iput v1, v0.Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances;->loaders:Landroid/support/v4/util/SparseArrayCompat;
    0058: goto 0046

  [Virtual Method] onSaveInstanceState(Landroid/os/Bundle;) -> V
    // registers=4, ins=2, outs=3, insns_size=17
    0000: invoke-super {v2, v3}, Landroid/app/Activity;->onSaveInstanceState(Landroid/os/Bundle;)V
    0003: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0005: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->saveAllState()Landroid/os/Parcelable;
    0008: move-result-object v0
    0009: if-eqz v0, 0010
    000b: const-string v1, 'android:support:fragments'
    000d: invoke-virtual {v3, v1, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V
    0010: return-void

  [Virtual Method] onStart() -> V
    // registers=5, ins=1, outs=4, insns_size=105
    0000: const/4 v3, 0
    0001: const/4 v2, 1
    0002: invoke-super {v4}, Landroid/app/Activity;->onStart()V
    0005: iput v3, v4.Landroid/support/v4/app/FragmentActivity;->mStopped:Z
    0007: iput v3, v4.Landroid/support/v4/app/FragmentActivity;->mReallyStopped:Z
    0009: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    000b: invoke-virtual {v0, v2}, Landroid/os/Handler;->removeMessages(I)V
    000e: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mCreated:Z
    0010: if-nez v0, 0019
    0012: iput v2, v4.Landroid/support/v4/app/FragmentActivity;->mCreated:Z
    0014: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0016: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchActivityCreated()V
    0019: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    001b: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->noteStateNotSaved()V
    001e: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0020: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->execPendingActions()Z
    0023: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mLoadersStarted:Z
    0025: if-nez v0, 0034
    0027: iput v2, v4.Landroid/support/v4/app/FragmentActivity;->mLoadersStarted:Z
    0029: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    002b: if-eqz v0, 005a
    002d: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    002f: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doStart()V
    0032: iput v2, v4.Landroid/support/v4/app/FragmentActivity;->mCheckedForLoaderManager:Z
    0034: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0036: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchStart()V
    0039: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    003b: if-eqz v0, 0068
    003d: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    003f: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    0042: move-result v0
    0043: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0045: move(op=01) v1, v0
    0046: if-ltz v1, 0068
    0048: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mAllLoaderManagers:Landroid/support/v4/util/SparseArrayCompat;
    004a: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    004d: move-result-object v0
    004e: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl;
    0050: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->finishRetain()V
    0053: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doReportStart()V
    0056: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    0058: move(op=01) v1, v0
    0059: goto 0046
    005a: iget v0, v4.Landroid/support/v4/app/FragmentActivity;->mCheckedForLoaderManager:Z
    005c: if-nez v0, 0032
    005e: const/4 v0, -1
    005f: iget v1, v4.Landroid/support/v4/app/FragmentActivity;->mLoadersStarted:Z
    0061: invoke-virtual {v4, v0, v1, v3}, Landroid/support/v4/app/FragmentActivity;->getLoaderManager(IZZ)Landroid/support/v4/app/LoaderManagerImpl;
    0064: move-result-object v0
    0065: iput v0, v4.Landroid/support/v4/app/FragmentActivity;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0067: goto 0032
    0068: return-void

  [Virtual Method] onStop() -> V
    // registers=3, ins=1, outs=2, insns_size=17
    0000: const/4 v1, 1
    0001: invoke-super {v2}, Landroid/app/Activity;->onStop()V
    0004: iput v1, v2.Landroid/support/v4/app/FragmentActivity;->mStopped:Z
    0006: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    0008: invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z
    000b: iget v0, v2.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    000d: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->dispatchStop()V
    0010: return-void

  [Virtual Method] startActivityForResult(Landroid/content/Intent;, I) -> V
    // registers=5, ins=3, outs=3, insns_size=20
    0000: const/4 v0, -1
    0001: if-eq v4, v0, 0010
    0003: const/high16 v0, -65536 (-0x10000)
    0005: binop/2addr(op=b5) v0, v4
    0006: if-eqz v0, 0010
    0008: new-instance v0, Ljava/lang/IllegalArgumentException;
    000a: const-string v1, 'Can only use lower 16 bits for requestCode'
    000c: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    000f: throw v0
    0010: invoke-super {v2, v3, v4}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    0013: return-void

  [Virtual Method] startActivityFromFragment(Landroid/support/v4/app/Fragment;, Landroid/content/Intent;, I) -> V
    // registers=6, ins=4, outs=3, insns_size=35
    0000: const/4 v0, -1
    0001: if-ne v5, v0, 0007
    0003: invoke-super {v2, v4, v0}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    0006: return-void
    0007: const/high16 v0, -65536 (-0x10000)
    0009: binop/2addr(op=b5) v0, v5
    000a: if-eqz v0, 0014
    000c: new-instance v0, Ljava/lang/IllegalArgumentException;
    000e: const-string v1, 'Can only use lower 16 bits for requestCode'
    0010: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0013: throw v0
    0014: iget v0, v3.Landroid/support/v4/app/Fragment;->mIndex:I
    0016: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0018: binop/lit8(op=e0) v0, v0, 16 (0x10)
    001a: const v1, 65535 (0xffff)
    001d: binop/2addr(op=b5) v1, v5
    001e: binop/2addr(op=b0) v0, v1
    001f: invoke-super {v2, v4, v0}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    0022: goto 0006

  [Virtual Method] supportInvalidateOptionsMenu() -> V
    // registers=3, ins=1, outs=1, insns_size=14
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 11 (0xb)
    0004: if-lt v0, v1, 000a
    0006: invoke-static {v2}, Landroid/support/v4/app/ActivityCompatHoneycomb;->invalidateOptionsMenu(Landroid/app/Activity;)V
    0009: return-void
    000a: const/4 v0, 1
    000b: iput v0, v2.Landroid/support/v4/app/FragmentActivity;->mOptionsMenuInvalidated:Z
    000d: goto 0009