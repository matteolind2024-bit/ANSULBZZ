=== CLASS Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerIcsImpl; (Source: AccessibilityManagerCompat.java) ===
  Super: Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerStubImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerStubImpl;-><init>()V
    0003: return-void

  [Virtual Method] addAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager;, Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;) -> Z
    // registers=4, ins=3, outs=2, insns_size=7
    0000: iget v0, v3.Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;->mListener:Ljava/lang/Object;
    0002: invoke-static {v2, v0}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs;->addAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager;Ljava/lang/Object;)Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] getEnabledAccessibilityServiceList(Landroid/view/accessibility/AccessibilityManager;, I) -> Ljava/util/List;
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs;->getEnabledAccessibilityServiceList(Landroid/view/accessibility/AccessibilityManager;I)Ljava/util/List;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getInstalledAccessibilityServiceList(Landroid/view/accessibility/AccessibilityManager;) -> Ljava/util/List;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs;->getInstalledAccessibilityServiceList(Landroid/view/accessibility/AccessibilityManager;)Ljava/util/List;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] isTouchExplorationEnabled(Landroid/view/accessibility/AccessibilityManager;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs;->isTouchExplorationEnabled(Landroid/view/accessibility/AccessibilityManager;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] newAccessiblityStateChangeListener(Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=3, insns_size=10
    0000: new-instance v0, Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1;
    0002: invoke-direct {v0, v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerIcsImpl$1;-><init>(Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerIcsImpl;Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;)V
    0005: invoke-static {v0}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs;->newAccessibilityStateChangeListener(Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge;)Ljava/lang/Object;
    0008: move-result-object v0
    0009: return-object v0

  [Virtual Method] removeAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager;, Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;) -> Z
    // registers=4, ins=3, outs=2, insns_size=7
    0000: iget v0, v3.Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;->mListener:Ljava/lang/Object;
    0002: invoke-static {v2, v0}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs;->removeAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager;Ljava/lang/Object;)Z
    0005: move-result v0
    0006: return v0