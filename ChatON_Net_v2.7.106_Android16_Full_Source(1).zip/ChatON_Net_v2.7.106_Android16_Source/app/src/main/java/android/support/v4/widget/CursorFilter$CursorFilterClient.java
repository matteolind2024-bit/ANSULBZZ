=== CLASS Landroid/support/v4/widget/CursorFilter$CursorFilterClient; (Source: CursorFilter.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] changeCursor(Landroid/database/Cursor;) -> V

  [Virtual Method] convertToString(Landroid/database/Cursor;) -> Ljava/lang/CharSequence;

  [Virtual Method] getCursor() -> Landroid/database/Cursor;

  [Virtual Method] runQueryOnBackgroundThread(Ljava/lang/CharSequence;) -> Landroid/database/Cursor;