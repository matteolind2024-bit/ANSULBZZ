=== CLASS Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImplIcs; (Source: PagerTitleStrip.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] setSingleLineAllCaps(Landroid/widget/TextView;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-static {v1}, Landroid/support/v4/view/PagerTitleStripIcs;->setSingleLineAllCaps(Landroid/widget/TextView;)V
    0003: return-void