=== CLASS Landroid/support/v4/view/ViewPager$SimpleOnPageChangeListener; (Source: ViewPager.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/ViewPager$OnPageChangeListener;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] onPageScrollStateChanged(I) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onPageScrolled(I, F, I) -> V
    // registers=4, ins=4, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onPageSelected(I) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void