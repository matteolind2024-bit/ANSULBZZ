=== CLASS Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompatIcs; (Source: AccessibilityServiceInfoCompatIcs.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getCanRetrieveWindowContent(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Z
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/accessibilityservice/AccessibilityServiceInfo;->getCanRetrieveWindowContent()Z
    0003: move-result v0
    0004: return v0

  [Direct Method] getDescription(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/accessibilityservice/AccessibilityServiceInfo;->getDescription()Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] getId(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/accessibilityservice/AccessibilityServiceInfo;->getId()Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] getResolveInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Landroid/content/pm/ResolveInfo;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/accessibilityservice/AccessibilityServiceInfo;->getResolveInfo()Landroid/content/pm/ResolveInfo;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] getSettingsActivityName(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/accessibilityservice/AccessibilityServiceInfo;->getSettingsActivityName()Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0