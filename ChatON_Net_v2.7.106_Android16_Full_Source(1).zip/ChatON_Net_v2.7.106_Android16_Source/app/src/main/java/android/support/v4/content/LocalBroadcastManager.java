=== CLASS Landroid/support/v4/content/LocalBroadcastManager; (Source: LocalBroadcastManager.java) ===
  Super: Ljava/lang/Object;
  [Static Field] DEBUG: Z = False
  [Static Field] MSG_EXEC_PENDING_BROADCASTS: I = 1
  [Static Field] TAG: Ljava/lang/String; = 'LocalBroadcastManager'
  [Static Field] mInstance: Landroid/support/v4/content/LocalBroadcastManager;
  [Static Field] mLock: Ljava/lang/Object;
  [Instance Field] mActions: Ljava/util/HashMap;
  [Instance Field] mAppContext: Landroid/content/Context;
  [Instance Field] mHandler: Landroid/os/Handler;
  [Instance Field] mPendingBroadcasts: Ljava/util/ArrayList;
  [Instance Field] mReceivers: Ljava/util/HashMap;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=8
    0000: new-instance v0, Ljava/lang/Object;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: sput v0, Landroid/support/v4/content/LocalBroadcastManager;->mLock:Ljava/lang/Object;
    0007: return-void

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=4, ins=2, outs=3, insns_size=38
    0000: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Ljava/util/HashMap;
    0005: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    0008: iput v0, v2.Landroid/support/v4/content/LocalBroadcastManager;->mReceivers:Ljava/util/HashMap;
    000a: new-instance v0, Ljava/util/HashMap;
    000c: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    000f: iput v0, v2.Landroid/support/v4/content/LocalBroadcastManager;->mActions:Ljava/util/HashMap;
    0011: new-instance v0, Ljava/util/ArrayList;
    0013: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0016: iput v0, v2.Landroid/support/v4/content/LocalBroadcastManager;->mPendingBroadcasts:Ljava/util/ArrayList;
    0018: iput v3, v2.Landroid/support/v4/content/LocalBroadcastManager;->mAppContext:Landroid/content/Context;
    001a: new-instance v0, Landroid/support/v4/content/LocalBroadcastManager$1;
    001c: invoke-virtual {v3}, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;
    001f: move-result-object v1
    0020: invoke-direct {v0, v2, v1}, Landroid/support/v4/content/LocalBroadcastManager$1;-><init>(Landroid/support/v4/content/LocalBroadcastManager;Landroid/os/Looper;)V
    0023: iput v0, v2.Landroid/support/v4/content/LocalBroadcastManager;->mHandler:Landroid/os/Handler;
    0025: return-void

  [Direct Method] access$000(Landroid/support/v4/content/LocalBroadcastManager;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/content/LocalBroadcastManager;->executePendingBroadcasts()V
    0003: return-void

  [Direct Method] executePendingBroadcasts() -> V
    // registers=9, ins=1, outs=3, insns_size=70
    0000: const/4 v2, 0
    0001: iget v1, v8.Landroid/support/v4/content/LocalBroadcastManager;->mReceivers:Ljava/util/HashMap;
    0003: monitor-enter v1
    0004: iget v0, v8.Landroid/support/v4/content/LocalBroadcastManager;->mPendingBroadcasts:Ljava/util/ArrayList;
    0006: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0009: move-result v0
    000a: if-gtz v0, 000e
    000c: monitor-exit v1
    000d: return-void
    000e: new-array v4, v0, [Landroid/support/v4/content/LocalBroadcastManager$BroadcastRecord;
    0010: iget v0, v8.Landroid/support/v4/content/LocalBroadcastManager;->mPendingBroadcasts:Ljava/util/ArrayList;
    0012: invoke-virtual {v0, v4}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    0015: iget v0, v8.Landroid/support/v4/content/LocalBroadcastManager;->mPendingBroadcasts:Ljava/util/ArrayList;
    0017: invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V
    001a: monitor-exit v1
    001b: move(op=01) v3, v2
    001c: move(op=21) v0, v4
    001d: if-ge v3, v0, 0001
    001f: aget(op=46) v5, v4[v3]
    0021: move(op=01) v1, v2
    0022: iget v0, v5.Landroid/support/v4/content/LocalBroadcastManager$BroadcastRecord;->receivers:Ljava/util/ArrayList;
    0024: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0027: move-result v0
    0028: if-ge v1, v0, 0042
    002a: iget v0, v5.Landroid/support/v4/content/LocalBroadcastManager$BroadcastRecord;->receivers:Ljava/util/ArrayList;
    002c: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    002f: move-result-object v0
    0030: check-cast v0, Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;
    0032: iget v0, v0.Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;->receiver:Landroid/content/BroadcastReceiver;
    0034: iget v6, v8.Landroid/support/v4/content/LocalBroadcastManager;->mAppContext:Landroid/content/Context;
    0036: iget v7, v5.Landroid/support/v4/content/LocalBroadcastManager$BroadcastRecord;->intent:Landroid/content/Intent;
    0038: invoke-virtual {v0, v6, v7}, Landroid/content/BroadcastReceiver;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    003b: binop/lit8(op=d8) v0, v1, 1 (0x1)
    003d: move(op=01) v1, v0
    003e: goto 0022
    003f: move-exception v0
    0040: monitor-exit v1
    0041: throw v0
    0042: binop/lit8(op=d8) v0, v3, 1 (0x1)
    0044: move(op=01) v3, v0
    0045: goto 001c

  [Direct Method] getInstance(Landroid/content/Context;) -> Landroid/support/v4/content/LocalBroadcastManager;
    // registers=4, ins=1, outs=2, insns_size=25
    0000: sget v1, Landroid/support/v4/content/LocalBroadcastManager;->mLock:Ljava/lang/Object;
    0002: monitor-enter v1
    0003: sget v0, Landroid/support/v4/content/LocalBroadcastManager;->mInstance:Landroid/support/v4/content/LocalBroadcastManager;
    0005: if-nez v0, 0012
    0007: new-instance v0, Landroid/support/v4/content/LocalBroadcastManager;
    0009: invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;
    000c: move-result-object v2
    000d: invoke-direct {v0, v2}, Landroid/support/v4/content/LocalBroadcastManager;-><init>(Landroid/content/Context;)V
    0010: sput v0, Landroid/support/v4/content/LocalBroadcastManager;->mInstance:Landroid/support/v4/content/LocalBroadcastManager;
    0012: sget v0, Landroid/support/v4/content/LocalBroadcastManager;->mInstance:Landroid/support/v4/content/LocalBroadcastManager;
    0014: monitor-exit v1
    0015: return-object v0
    0016: move-exception v0
    0017: monitor-exit v1
    0018: throw v0

  [Virtual Method] registerReceiver(Landroid/content/BroadcastReceiver;, Landroid/content/IntentFilter;) -> V
    // registers=9, ins=3, outs=3, insns_size=77
    0000: iget v2, v6.Landroid/support/v4/content/LocalBroadcastManager;->mReceivers:Ljava/util/HashMap;
    0002: monitor-enter v2
    0003: new-instance v3, Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;
    0005: invoke-direct {v3, v8, v7}, Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;-><init>(Landroid/content/IntentFilter;Landroid/content/BroadcastReceiver;)V
    0008: iget v0, v6.Landroid/support/v4/content/LocalBroadcastManager;->mReceivers:Ljava/util/HashMap;
    000a: invoke-virtual {v0, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    000d: move-result-object v0
    000e: check-cast v0, Ljava/util/ArrayList;
    0010: if-nez v0, 001d
    0012: new-instance v0, Ljava/util/ArrayList;
    0014: const/4 v1, 1
    0015: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V
    0018: iget v1, v6.Landroid/support/v4/content/LocalBroadcastManager;->mReceivers:Ljava/util/HashMap;
    001a: invoke-virtual {v1, v7, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    001d: invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0020: const/4 v0, 0
    0021: move(op=01) v1, v0
    0022: invoke-virtual {v8}, Landroid/content/IntentFilter;->countActions()I
    0025: move-result v0
    0026: if-ge v1, v0, 0048
    0028: invoke-virtual {v8, v1}, Landroid/content/IntentFilter;->getAction(I)Ljava/lang/String;
    002b: move-result-object v4
    002c: iget v0, v6.Landroid/support/v4/content/LocalBroadcastManager;->mActions:Ljava/util/HashMap;
    002e: invoke-virtual {v0, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0031: move-result-object v0
    0032: check-cast v0, Ljava/util/ArrayList;
    0034: if-nez v0, 0041
    0036: new-instance v0, Ljava/util/ArrayList;
    0038: const/4 v5, 1
    0039: invoke-direct {v0, v5}, Ljava/util/ArrayList;-><init>(I)V
    003c: iget v5, v6.Landroid/support/v4/content/LocalBroadcastManager;->mActions:Ljava/util/HashMap;
    003e: invoke-virtual {v5, v4, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    0041: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0044: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0046: move(op=01) v1, v0
    0047: goto 0022
    0048: monitor-exit v2
    0049: return-void
    004a: move-exception v0
    004b: monitor-exit v2
    004c: throw v0

  [Virtual Method] sendBroadcast(Landroid/content/Intent;) -> Z
    // registers=18, ins=2, outs=7, insns_size=384
    0000: move/from16 v0, v16
    0002: iget v13, v0.Landroid/support/v4/content/LocalBroadcastManager;->mReceivers:Ljava/util/HashMap;
    0004: monitor-enter v13
    0005: invoke-virtual/range {v17..v17}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0008: move-result-object v2
    0009: move/from16 v0, v16
    000b: iget v1, v0.Landroid/support/v4/content/LocalBroadcastManager;->mAppContext:Landroid/content/Context;
    000d: invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    0010: move-result-object v1
    0011: move/from16 v0, v17
    0013: invoke-virtual {v0, v1}, Landroid/content/Intent;->resolveTypeIfNeeded(Landroid/content/ContentResolver;)Ljava/lang/String;
    0016: move-result-object v3
    0017: invoke-virtual/range {v17..v17}, Landroid/content/Intent;->getData()Landroid/net/Uri;
    001a: move-result-object v5
    001b: invoke-virtual/range {v17..v17}, Landroid/content/Intent;->getScheme()Ljava/lang/String;
    001e: move-result-object v4
    001f: invoke-virtual/range {v17..v17}, Landroid/content/Intent;->getCategories()Ljava/util/Set;
    0022: move-result-object v6
    0023: invoke-virtual/range {v17..v17}, Landroid/content/Intent;->getFlags()I
    0026: move-result v1
    0027: binop/lit8(op=dd) v1, v1, 8 (0x8)
    0029: if-eqz v1, 00c9
    002b: const/4 v1, 1
    002c: move(op=01) v12, v1
    002d: if-eqz v12, 005d
    002f: const-string v1, 'LocalBroadcastManager'
    0031: new-instance v7, Ljava/lang/StringBuilder;
    0033: invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V
    0036: const-string v8, 'Resolving type '
    0038: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003b: move-result-object v7
    003c: invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003f: move-result-object v7
    0040: const-string v8, ' scheme '
    0042: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0045: move-result-object v7
    0046: invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0049: move-result-object v7
    004a: const-string v8, ' of intent '
    004c: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004f: move-result-object v7
    0050: move/from16 v0, v17
    0052: invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0055: move-result-object v7
    0056: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0059: move-result-object v7
    005a: invoke-static {v1, v7}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    005d: move/from16 v0, v16
    005f: iget v1, v0.Landroid/support/v4/content/LocalBroadcastManager;->mActions:Ljava/util/HashMap;
    0061: invoke-virtual/range {v17..v17}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0064: move-result-object v7
    0065: invoke-virtual {v1, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0068: move-result-object v1
    0069: move(op=07) v0, v1
    006a: check-cast v0, Ljava/util/ArrayList;
    006c: move(op=07) v8, v0
    006d: if-eqz v8, 016e
    006f: if-eqz v12, 0089
    0071: const-string v1, 'LocalBroadcastManager'
    0073: new-instance v7, Ljava/lang/StringBuilder;
    0075: invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V
    0078: const-string v9, 'Action list: '
    007a: invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    007d: move-result-object v7
    007e: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0081: move-result-object v7
    0082: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0085: move-result-object v7
    0086: invoke-static {v1, v7}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0089: const/4 v10, 0
    008a: const/4 v1, 0
    008b: move(op=01) v11, v1
    008c: invoke-virtual {v8}, Ljava/util/ArrayList;->size()I
    008f: move-result v1
    0090: if-ge v11, v1, 0133
    0092: invoke-virtual {v8, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0095: move-result-object v1
    0096: move(op=07) v0, v1
    0097: check-cast v0, Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;
    0099: move(op=07) v9, v0
    009a: if-eqz v12, 00b6
    009c: const-string v1, 'LocalBroadcastManager'
    009e: new-instance v7, Ljava/lang/StringBuilder;
    00a0: invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V
    00a3: const-string v14, 'Matching against filter '
    00a5: invoke-virtual {v7, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a8: move-result-object v7
    00a9: iget v14, v9.Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;->filter:Landroid/content/IntentFilter;
    00ab: invoke-virtual {v7, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00ae: move-result-object v7
    00af: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00b2: move-result-object v7
    00b3: invoke-static {v1, v7}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00b6: iget v1, v9.Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;->broadcasting:Z
    00b8: if-eqz v1, 00cd
    00ba: if-eqz v12, 0125
    00bc: const-string v1, 'LocalBroadcastManager'
    00be: const-string v7, "  Filter's target already added"
    00c0: invoke-static {v1, v7}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00c3: move(op=07) v1, v10
    00c4: binop/lit8(op=d8) v7, v11, 1 (0x1)
    00c6: move(op=01) v11, v7
    00c7: move(op=07) v10, v1
    00c8: goto 008c
    00c9: const/4 v1, 0
    00ca: move(op=01) v12, v1
    00cb: goto/16 002d
    00cd: iget v1, v9.Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;->filter:Landroid/content/IntentFilter;
    00cf: const-string v7, 'LocalBroadcastManager'
    00d1: invoke-virtual/range {v1..v7}, Landroid/content/IntentFilter;->match(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/net/Uri;Ljava/util/Set;Ljava/lang/String;)I
    00d4: move-result v1
    00d5: if-ltz v1, 0106
    00d7: if-eqz v12, 00f5
    00d9: const-string v7, 'LocalBroadcastManager'
    00db: new-instance v14, Ljava/lang/StringBuilder;
    00dd: invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V
    00e0: const-string v15, '  Filter matched!  match=0x'
    00e2: invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00e5: move-result-object v14
    00e6: invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    00e9: move-result-object v1
    00ea: invoke-virtual {v14, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00ed: move-result-object v1
    00ee: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00f1: move-result-object v1
    00f2: invoke-static {v7, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00f5: if-nez v10, 0171
    00f7: new-instance v1, Ljava/util/ArrayList;
    00f9: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    00fc: invoke-virtual {v1, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    00ff: const/4 v7, 1
    0100: iput v7, v9.Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;->broadcasting:Z
    0102: goto 00c4
    0103: move-exception v1
    0104: monitor-exit v13
    0105: throw v1
    0106: if-eqz v12, 0125
    0108: packed-switch v1, +108 (-> 0174)
    010b: const-string v1, 'unknown reason'
    010d: const-string v7, 'LocalBroadcastManager'
    010f: new-instance v9, Ljava/lang/StringBuilder;
    0111: invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V
    0114: const-string v14, '  Filter did not match: '
    0116: invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0119: move-result-object v9
    011a: invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    011d: move-result-object v1
    011e: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0121: move-result-object v1
    0122: invoke-static {v7, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0125: move(op=07) v1, v10
    0126: goto 00c4
    0127: const-string v1, 'action'
    0129: goto 010d
    012a: const-string v1, 'category'
    012c: goto 010d
    012d: const-string v1, 'data'
    012f: goto 010d
    0130: const-string v1, 'type'
    0132: goto 010d
    0133: if-eqz v10, 016e
    0135: const/4 v1, 0
    0136: move(op=01) v2, v1
    0137: invoke-virtual {v10}, Ljava/util/ArrayList;->size()I
    013a: move-result v1
    013b: if-ge v2, v1, 014a
    013d: invoke-virtual {v10, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0140: move-result-object v1
    0141: check-cast v1, Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;
    0143: const/4 v3, 0
    0144: iput v3, v1.Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;->broadcasting:Z
    0146: binop/lit8(op=d8) v1, v2, 1 (0x1)
    0148: move(op=01) v2, v1
    0149: goto 0137
    014a: move/from16 v0, v16
    014c: iget v1, v0.Landroid/support/v4/content/LocalBroadcastManager;->mPendingBroadcasts:Ljava/util/ArrayList;
    014e: new-instance v2, Landroid/support/v4/content/LocalBroadcastManager$BroadcastRecord;
    0150: move/from16 v0, v17
    0152: invoke-direct {v2, v0, v10}, Landroid/support/v4/content/LocalBroadcastManager$BroadcastRecord;-><init>(Landroid/content/Intent;Ljava/util/ArrayList;)V
    0155: invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0158: move/from16 v0, v16
    015a: iget v1, v0.Landroid/support/v4/content/LocalBroadcastManager;->mHandler:Landroid/os/Handler;
    015c: const/4 v2, 1
    015d: invoke-virtual {v1, v2}, Landroid/os/Handler;->hasMessages(I)Z
    0160: move-result v1
    0161: if-nez v1, 016b
    0163: move/from16 v0, v16
    0165: iget v1, v0.Landroid/support/v4/content/LocalBroadcastManager;->mHandler:Landroid/os/Handler;
    0167: const/4 v2, 1
    0168: invoke-virtual {v1, v2}, Landroid/os/Handler;->sendEmptyMessage(I)Z
    016b: const/4 v1, 1
    016c: monitor-exit v13
    016d: return v1
    016e: monitor-exit v13
    016f: const/4 v1, 0
    0170: goto 016d
    0171: move(op=07) v1, v10
    0172: goto 00fc
    0173: nop
    0174: packed-switch-payload first=-4 targets=[34, 31, 37, 40]

  [Virtual Method] sendBroadcastSync(Landroid/content/Intent;) -> V
    // registers=3, ins=2, outs=2, insns_size=10
    0000: invoke-virtual {v1, v2}, Landroid/support/v4/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z
    0003: move-result v0
    0004: if-eqz v0, 0009
    0006: invoke-direct {v1}, Landroid/support/v4/content/LocalBroadcastManager;->executePendingBroadcasts()V
    0009: return-void

  [Virtual Method] unregisterReceiver(Landroid/content/BroadcastReceiver;) -> V
    // registers=12, ins=2, outs=2, insns_size=101
    0000: const/4 v5, 0
    0001: iget v8, v10.Landroid/support/v4/content/LocalBroadcastManager;->mReceivers:Ljava/util/HashMap;
    0003: monitor-enter v8
    0004: iget v0, v10.Landroid/support/v4/content/LocalBroadcastManager;->mReceivers:Ljava/util/HashMap;
    0006: invoke-virtual {v0, v11}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    0009: move-result-object v0
    000a: check-cast v0, Ljava/util/ArrayList;
    000c: if-nez v0, 0010
    000e: monitor-exit v8
    000f: return-void
    0010: move(op=01) v7, v5
    0011: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0014: move-result v1
    0015: if-ge v7, v1, 005e
    0017: invoke-virtual {v0, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    001a: move-result-object v1
    001b: check-cast v1, Landroid/content/IntentFilter;
    001d: move(op=01) v6, v5
    001e: invoke-virtual {v1}, Landroid/content/IntentFilter;->countActions()I
    0021: move-result v2
    0022: if-ge v6, v2, 005a
    0024: invoke-virtual {v1, v6}, Landroid/content/IntentFilter;->getAction(I)Ljava/lang/String;
    0027: move-result-object v9
    0028: iget v2, v10.Landroid/support/v4/content/LocalBroadcastManager;->mActions:Ljava/util/HashMap;
    002a: invoke-virtual {v2, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    002d: move-result-object v2
    002e: check-cast v2, Ljava/util/ArrayList;
    0030: if-eqz v2, 0056
    0032: move(op=01) v4, v5
    0033: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    0036: move-result v3
    0037: if-ge v4, v3, 004b
    0039: invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    003c: move-result-object v3
    003d: check-cast v3, Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;
    003f: iget v3, v3.Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;->receiver:Landroid/content/BroadcastReceiver;
    0041: if-ne v3, v11, 0063
    0043: invoke-virtual {v2, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    0046: binop/lit8(op=d8) v3, v4, -1 (-0x1)
    0048: binop/lit8(op=d8) v4, v3, 1 (0x1)
    004a: goto 0033
    004b: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    004e: move-result v2
    004f: if-gtz v2, 0056
    0051: iget v2, v10.Landroid/support/v4/content/LocalBroadcastManager;->mActions:Ljava/util/HashMap;
    0053: invoke-virtual {v2, v9}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    0056: binop/lit8(op=d8) v2, v6, 1 (0x1)
    0058: move(op=01) v6, v2
    0059: goto 001e
    005a: binop/lit8(op=d8) v1, v7, 1 (0x1)
    005c: move(op=01) v7, v1
    005d: goto 0011
    005e: monitor-exit v8
    005f: goto 000f
    0060: move-exception v0
    0061: monitor-exit v8
    0062: throw v0
    0063: move(op=01) v3, v4
    0064: goto 0048