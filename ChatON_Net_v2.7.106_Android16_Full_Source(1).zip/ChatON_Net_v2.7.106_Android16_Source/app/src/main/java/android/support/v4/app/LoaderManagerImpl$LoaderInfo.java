=== CLASS Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo; (Source: LoaderManager.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/content/Loader$OnLoadCompleteListener;
  [Instance Field] mArgs: Landroid/os/Bundle;
  [Instance Field] mCallbacks: Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
  [Instance Field] mData: Ljava/lang/Object;
  [Instance Field] mDeliveredData: Z
  [Instance Field] mDestroyed: Z
  [Instance Field] mHaveData: Z
  [Instance Field] mId: I
  [Instance Field] mListenerRegistered: Z
  [Instance Field] mLoader: Landroid/support/v4/content/Loader;
  [Instance Field] mPendingLoader: Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
  [Instance Field] mReportNextStart: Z
  [Instance Field] mRetaining: Z
  [Instance Field] mRetainingStarted: Z
  [Instance Field] mStarted: Z
  [Instance Field] this$0: Landroid/support/v4/app/LoaderManagerImpl;

  [Direct Method] <init>(Landroid/support/v4/app/LoaderManagerImpl;, I, Landroid/os/Bundle;, Landroid/support/v4/app/LoaderManager$LoaderCallbacks;) -> V
    // registers=5, ins=5, outs=1, insns_size=12
    0000: iput v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: iput v2, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mId:I
    0007: iput v3, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mArgs:Landroid/os/Bundle;
    0009: iput v4, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mCallbacks:Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    000b: return-void

  [Virtual Method] callOnLoadFinished(Landroid/support/v4/content/Loader;, Ljava/lang/Object;) -> V
    // registers=7, ins=3, outs=3, insns_size=113
    0000: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mCallbacks:Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    0002: if-eqz v0, 005e
    0004: const/4 v0, 0
    0005: iget v1, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0007: iget v1, v1.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0009: if-eqz v1, 006f
    000b: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    000d: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    000f: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0011: iget v0, v0.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    0013: iget v1, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0015: iget v1, v1.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0017: iget v1, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0019: const-string v2, 'onLoadFinished'
    001b: iput v2, v1.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    001d: move(op=07) v1, v0
    001e: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0020: if-eqz v0, 0048
    0022: const-string v0, 'LoaderManager'
    0024: new-instance v2, Ljava/lang/StringBuilder;
    0026: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0029: const-string v3, '  onLoadFinished in '
    002b: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002e: move-result-object v2
    002f: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0032: move-result-object v2
    0033: const-string v3, ': '
    0035: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0038: move-result-object v2
    0039: invoke-virtual {v5, v6}, Landroid/support/v4/content/Loader;->dataToString(Ljava/lang/Object;)Ljava/lang/String;
    003c: move-result-object v3
    003d: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0040: move-result-object v2
    0041: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0044: move-result-object v2
    0045: invoke-static {v0, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0048: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mCallbacks:Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    004a: invoke-interface {v0, v5, v6}, Landroid/support/v4/app/LoaderManager$LoaderCallbacks;->onLoadFinished(Landroid/support/v4/content/Loader;Ljava/lang/Object;)V
    004d: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    004f: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0051: if-eqz v0, 005b
    0053: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0055: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0057: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0059: iput v1, v0.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    005b: const/4 v0, 1
    005c: iput v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mDeliveredData:Z
    005e: return-void
    005f: move-exception v0
    0060: iget v2, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0062: iget v2, v2.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0064: if-eqz v2, 006e
    0066: iget v2, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0068: iget v2, v2.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    006a: iget v2, v2.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    006c: iput v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    006e: throw v0
    006f: move(op=07) v1, v0
    0070: goto 001e

  [Virtual Method] destroy() -> V
    // registers=6, ins=1, outs=2, insns_size=179
    0000: const/4 v2, 0
    0001: const/4 v4, 0
    0002: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0004: if-eqz v0, 001e
    0006: const-string v0, 'LoaderManager'
    0008: new-instance v1, Ljava/lang/StringBuilder;
    000a: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000d: const-string v3, '  Destroying: '
    000f: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0016: move-result-object v1
    0017: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001a: move-result-object v1
    001b: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001e: const/4 v0, 1
    001f: iput v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mDestroyed:Z
    0021: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mDeliveredData:Z
    0023: iput v4, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mDeliveredData:Z
    0025: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mCallbacks:Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    0027: if-eqz v1, 007d
    0029: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    002b: if-eqz v1, 007d
    002d: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mHaveData:Z
    002f: if-eqz v1, 007d
    0031: if-eqz v0, 007d
    0033: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0035: if-eqz v0, 004f
    0037: const-string v0, 'LoaderManager'
    0039: new-instance v1, Ljava/lang/StringBuilder;
    003b: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    003e: const-string v3, '  Reseting: '
    0040: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0043: move-result-object v1
    0044: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0047: move-result-object v1
    0048: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    004b: move-result-object v1
    004c: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    004f: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0051: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0053: if-eqz v0, 00b1
    0055: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0057: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0059: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    005b: iget v0, v0.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    005d: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    005f: iget v1, v1.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0061: iget v1, v1.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0063: const-string v3, 'onLoaderReset'
    0065: iput v3, v1.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    0067: move(op=07) v1, v0
    0068: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mCallbacks:Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    006a: iget v3, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    006c: invoke-interface {v0, v3}, Landroid/support/v4/app/LoaderManager$LoaderCallbacks;->onLoaderReset(Landroid/support/v4/content/Loader;)V
    006f: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0071: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0073: if-eqz v0, 007d
    0075: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0077: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0079: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    007b: iput v1, v0.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    007d: iput v2, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mCallbacks:Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    007f: iput v2, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mData:Ljava/lang/Object;
    0081: iput v4, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mHaveData:Z
    0083: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0085: if-eqz v0, 0097
    0087: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mListenerRegistered:Z
    0089: if-eqz v0, 0092
    008b: iput v4, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mListenerRegistered:Z
    008d: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    008f: invoke-virtual {v0, v5}, Landroid/support/v4/content/Loader;->unregisterListener(Landroid/support/v4/content/Loader$OnLoadCompleteListener;)V
    0092: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0094: invoke-virtual {v0}, Landroid/support/v4/content/Loader;->reset()V
    0097: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0099: if-eqz v0, 00a0
    009b: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    009d: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->destroy()V
    00a0: return-void
    00a1: move-exception v0
    00a2: iget v2, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    00a4: iget v2, v2.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    00a6: if-eqz v2, 00b0
    00a8: iget v2, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    00aa: iget v2, v2.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    00ac: iget v2, v2.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    00ae: iput v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    00b0: throw v0
    00b1: move(op=07) v1, v2
    00b2: goto 0068

  [Virtual Method] dump(Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V
    // registers=8, ins=5, outs=5, insns_size=234
    0000: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0003: const-string v0, 'mId='
    0005: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0008: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mId:I
    000a: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(I)V
    000d: const-string v0, ' mArgs='
    000f: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0012: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mArgs:Landroid/os/Bundle;
    0014: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0017: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    001a: const-string v0, 'mCallbacks='
    001c: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    001f: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mCallbacks:Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    0021: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0024: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0027: const-string v0, 'mLoader='
    0029: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    002c: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    002e: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0031: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0033: if-eqz v0, 004d
    0035: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0037: new-instance v1, Ljava/lang/StringBuilder;
    0039: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    003c: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003f: move-result-object v1
    0040: const-string v2, '  '
    0042: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0045: move-result-object v1
    0046: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0049: move-result-object v1
    004a: invoke-virtual {v0, v1, v5, v6, v7}, Landroid/support/v4/content/Loader;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    004d: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mHaveData:Z
    004f: if-nez v0, 0055
    0051: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mDeliveredData:Z
    0053: if-eqz v0, 0079
    0055: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0058: const-string v0, 'mHaveData='
    005a: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    005d: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mHaveData:Z
    005f: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    0062: const-string v0, '  mDeliveredData='
    0064: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0067: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mDeliveredData:Z
    0069: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Z)V
    006c: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    006f: const-string v0, 'mData='
    0071: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0074: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mData:Ljava/lang/Object;
    0076: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0079: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    007c: const-string v0, 'mStarted='
    007e: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0081: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    0083: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    0086: const-string v0, ' mReportNextStart='
    0088: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    008b: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mReportNextStart:Z
    008d: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    0090: const-string v0, ' mDestroyed='
    0092: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0095: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mDestroyed:Z
    0097: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Z)V
    009a: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    009d: const-string v0, 'mRetaining='
    009f: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00a2: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mRetaining:Z
    00a4: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    00a7: const-string v0, ' mRetainingStarted='
    00a9: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00ac: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mRetainingStarted:Z
    00ae: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    00b1: const-string v0, ' mListenerRegistered='
    00b3: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00b6: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mListenerRegistered:Z
    00b8: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Z)V
    00bb: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    00bd: if-eqz v0, 00e9
    00bf: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00c2: const-string v0, 'Pending Loader '
    00c4: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    00c7: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    00c9: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/Object;)V
    00cc: const-string v0, ':'
    00ce: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    00d1: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    00d3: new-instance v1, Ljava/lang/StringBuilder;
    00d5: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    00d8: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00db: move-result-object v1
    00dc: const-string v2, '  '
    00de: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00e1: move-result-object v1
    00e2: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00e5: move-result-object v1
    00e6: invoke-virtual {v0, v1, v5, v6, v7}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    00e9: return-void

  [Virtual Method] finishRetain() -> V
    // registers=4, ins=1, outs=3, insns_size=68
    0000: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mRetaining:Z
    0002: if-eqz v0, 0030
    0004: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0006: if-eqz v0, 0020
    0008: const-string v0, 'LoaderManager'
    000a: new-instance v1, Ljava/lang/StringBuilder;
    000c: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000f: const-string v2, '  Finished Retaining: '
    0011: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0018: move-result-object v1
    0019: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001c: move-result-object v1
    001d: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0020: const/4 v0, 0
    0021: iput v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mRetaining:Z
    0023: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    0025: iget v1, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mRetainingStarted:Z
    0027: if-eq v0, v1, 0030
    0029: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    002b: if-nez v0, 0030
    002d: invoke-virtual {v3}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->stop()V
    0030: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    0032: if-eqz v0, 0043
    0034: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mHaveData:Z
    0036: if-eqz v0, 0043
    0038: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mReportNextStart:Z
    003a: if-nez v0, 0043
    003c: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    003e: iget v1, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mData:Ljava/lang/Object;
    0040: invoke-virtual {v3, v0, v1}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->callOnLoadFinished(Landroid/support/v4/content/Loader;Ljava/lang/Object;)V
    0043: return-void

  [Virtual Method] onLoadComplete(Landroid/support/v4/content/Loader;, Ljava/lang/Object;) -> V
    // registers=8, ins=3, outs=3, insns_size=197
    0000: const/4 v4, 0
    0001: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0003: if-eqz v0, 001d
    0005: const-string v0, 'LoaderManager'
    0007: new-instance v1, Ljava/lang/StringBuilder;
    0009: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000c: const-string v2, 'onLoadComplete: '
    000e: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0011: move-result-object v1
    0012: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0015: move-result-object v1
    0016: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0019: move-result-object v1
    001a: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001d: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mDestroyed:Z
    001f: if-eqz v0, 002d
    0021: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0023: if-eqz v0, 002c
    0025: const-string v0, 'LoaderManager'
    0027: const-string v1, '  Ignoring load complete -- destroyed'
    0029: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    002c: return-void
    002d: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    002f: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0031: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mId:I
    0033: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->get(I)Ljava/lang/Object;
    0036: move-result-object v0
    0037: if-eq v0, v5, 0045
    0039: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    003b: if-eqz v0, 002c
    003d: const-string v0, 'LoaderManager'
    003f: const-string v1, '  Ignoring load complete -- not active'
    0041: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0044: goto 002c
    0045: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0047: if-eqz v0, 0079
    0049: sget v1, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    004b: if-eqz v1, 0065
    004d: const-string v1, 'LoaderManager'
    004f: new-instance v2, Ljava/lang/StringBuilder;
    0051: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0054: const-string v3, '  Switching to pending loader: '
    0056: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0059: move-result-object v2
    005a: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    005d: move-result-object v2
    005e: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0061: move-result-object v2
    0062: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0065: iput v4, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0067: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0069: iget v1, v1.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    006b: iget v2, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mId:I
    006d: invoke-virtual {v1, v2, v4}, Landroid/support/v4/util/SparseArrayCompat;->put(ILjava/lang/Object;)V
    0070: invoke-virtual {v5}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->destroy()V
    0073: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    0075: invoke-virtual {v1, v0}, Landroid/support/v4/app/LoaderManagerImpl;->installLoader(Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;)V
    0078: goto 002c
    0079: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mData:Ljava/lang/Object;
    007b: if-ne v0, v7, 0081
    007d: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mHaveData:Z
    007f: if-nez v0, 008d
    0081: iput v7, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mData:Ljava/lang/Object;
    0083: const/4 v0, 1
    0084: iput v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mHaveData:Z
    0086: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    0088: if-eqz v0, 008d
    008a: invoke-virtual {v5, v6, v7}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->callOnLoadFinished(Landroid/support/v4/content/Loader;Ljava/lang/Object;)V
    008d: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    008f: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0091: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mId:I
    0093: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->get(I)Ljava/lang/Object;
    0096: move-result-object v0
    0097: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0099: if-eqz v0, 00ac
    009b: if-eq v0, v5, 00ac
    009d: const/4 v1, 0
    009e: iput v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mDeliveredData:Z
    00a0: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->destroy()V
    00a3: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    00a5: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    00a7: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mId:I
    00a9: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->remove(I)V
    00ac: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    00ae: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    00b0: if-eqz v0, 002c
    00b2: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    00b4: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->hasRunningLoaders()Z
    00b7: move-result v0
    00b8: if-nez v0, 002c
    00ba: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->this$0:Landroid/support/v4/app/LoaderManagerImpl;
    00bc: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    00be: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    00c0: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->startPendingDeferredFragments()V
    00c3: goto/16 002c

  [Virtual Method] reportStart() -> V
    // registers=3, ins=1, outs=3, insns_size=23
    0000: iget v0, v2.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    0002: if-eqz v0, 0016
    0004: iget v0, v2.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mReportNextStart:Z
    0006: if-eqz v0, 0016
    0008: const/4 v0, 0
    0009: iput v0, v2.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mReportNextStart:Z
    000b: iget v0, v2.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mHaveData:Z
    000d: if-eqz v0, 0016
    000f: iget v0, v2.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0011: iget v1, v2.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mData:Ljava/lang/Object;
    0013: invoke-virtual {v2, v0, v1}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->callOnLoadFinished(Landroid/support/v4/content/Loader;Ljava/lang/Object;)V
    0016: return-void

  [Virtual Method] retain() -> V
    // registers=4, ins=1, outs=2, insns_size=42
    0000: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0002: if-eqz v0, 001c
    0004: const-string v0, 'LoaderManager'
    0006: new-instance v1, Ljava/lang/StringBuilder;
    0008: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v2, '  Retaining: '
    000d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v1
    0011: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0018: move-result-object v1
    0019: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001c: const/4 v0, 1
    001d: iput v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mRetaining:Z
    001f: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    0021: iput v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mRetainingStarted:Z
    0023: const/4 v0, 0
    0024: iput v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    0026: const/4 v0, 0
    0027: iput v0, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mCallbacks:Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    0029: return-void

  [Virtual Method] start() -> V
    // registers=5, ins=1, outs=3, insns_size=145
    0000: const/4 v3, 1
    0001: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mRetaining:Z
    0003: if-eqz v0, 000c
    0005: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mRetainingStarted:Z
    0007: if-eqz v0, 000c
    0009: iput v3, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    000b: return-void
    000c: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    000e: if-nez v0, 000b
    0010: iput v3, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    0012: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0014: if-eqz v0, 002e
    0016: const-string v0, 'LoaderManager'
    0018: new-instance v1, Ljava/lang/StringBuilder;
    001a: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    001d: const-string v2, '  Starting: '
    001f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0022: move-result-object v1
    0023: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0026: move-result-object v1
    0027: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002a: move-result-object v1
    002b: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    002e: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0030: if-nez v0, 0042
    0032: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mCallbacks:Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    0034: if-eqz v0, 0042
    0036: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mCallbacks:Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    0038: iget v1, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mId:I
    003a: iget v2, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mArgs:Landroid/os/Bundle;
    003c: invoke-interface {v0, v1, v2}, Landroid/support/v4/app/LoaderManager$LoaderCallbacks;->onCreateLoader(ILandroid/os/Bundle;)Landroid/support/v4/content/Loader;
    003f: move-result-object v0
    0040: iput v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0042: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0044: if-eqz v0, 000b
    0046: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0048: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    004b: move-result-object v0
    004c: invoke-virtual {v0}, Ljava/lang/Class;->isMemberClass()Z
    004f: move-result v0
    0050: if-eqz v0, 007d
    0052: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0054: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0057: move-result-object v0
    0058: invoke-virtual {v0}, Ljava/lang/Class;->getModifiers()I
    005b: move-result v0
    005c: invoke-static {v0}, Ljava/lang/reflect/Modifier;->isStatic(I)Z
    005f: move-result v0
    0060: if-nez v0, 007d
    0062: new-instance v0, Ljava/lang/IllegalArgumentException;
    0064: new-instance v1, Ljava/lang/StringBuilder;
    0066: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0069: const-string v2, 'Object returned from onCreateLoader must not be a non-static inner member class: '
    006b: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    006e: move-result-object v1
    006f: iget v2, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0071: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0074: move-result-object v1
    0075: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0078: move-result-object v1
    0079: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    007c: throw v0
    007d: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mListenerRegistered:Z
    007f: if-nez v0, 008a
    0081: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0083: iget v1, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mId:I
    0085: invoke-virtual {v0, v1, v4}, Landroid/support/v4/content/Loader;->registerListener(ILandroid/support/v4/content/Loader$OnLoadCompleteListener;)V
    0088: iput v3, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mListenerRegistered:Z
    008a: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    008c: invoke-virtual {v0}, Landroid/support/v4/content/Loader;->startLoading()V
    008f: goto/16 000b

  [Virtual Method] stop() -> V
    // registers=5, ins=1, outs=2, insns_size=56
    0000: const/4 v3, 0
    0001: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0003: if-eqz v0, 001d
    0005: const-string v0, 'LoaderManager'
    0007: new-instance v1, Ljava/lang/StringBuilder;
    0009: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000c: const-string v2, '  Stopping: '
    000e: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0011: move-result-object v1
    0012: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0015: move-result-object v1
    0016: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0019: move-result-object v1
    001a: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001d: iput v3, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    001f: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mRetaining:Z
    0021: if-nez v0, 0037
    0023: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0025: if-eqz v0, 0037
    0027: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mListenerRegistered:Z
    0029: if-eqz v0, 0037
    002b: iput v3, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mListenerRegistered:Z
    002d: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    002f: invoke-virtual {v0, v4}, Landroid/support/v4/content/Loader;->unregisterListener(Landroid/support/v4/content/Loader$OnLoadCompleteListener;)V
    0032: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0034: invoke-virtual {v0}, Landroid/support/v4/content/Loader;->stopLoading()V
    0037: return-void

  [Virtual Method] toString() -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=53
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: const/16 v1, 64 (0x40)
    0004: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V
    0007: const-string v1, 'LoaderInfo{'
    0009: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000c: invoke-static {v2}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I
    000f: move-result v1
    0010: invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0013: move-result-object v1
    0014: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0017: const-string v1, ' #'
    0019: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: iget v1, v2.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mId:I
    001e: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0021: const-string v1, ' : '
    0023: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0026: iget v1, v2.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0028: invoke-static {v1, v0}, Landroid/support/v4/util/DebugUtils;->buildShortClassTag(Ljava/lang/Object;Ljava/lang/StringBuilder;)V
    002b: const-string v1, '}}'
    002d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0030: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0033: move-result-object v0
    0034: return-object v0