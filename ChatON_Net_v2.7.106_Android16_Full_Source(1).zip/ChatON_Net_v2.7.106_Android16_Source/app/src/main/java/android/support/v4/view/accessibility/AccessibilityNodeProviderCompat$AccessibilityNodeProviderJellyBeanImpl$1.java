=== CLASS Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1; (Source: AccessibilityNodeProviderCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge;
  [Instance Field] this$0: Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl;
  [Instance Field] val$compat: Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;

  [Direct Method] <init>(Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl;, Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;) -> V
    // registers=3, ins=3, outs=1, insns_size=8
    0000: iput v1, v0.Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1;->this$0:Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl;
    0002: iput v2, v0.Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1;->val$compat:Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    0004: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0007: return-void

  [Virtual Method] createAccessibilityNodeInfo(I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=15
    0000: iget v0, v1.Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1;->val$compat:Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    0002: invoke-virtual {v0, v2}, Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;->createAccessibilityNodeInfo(I)Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;
    0005: move-result-object v0
    0006: if-nez v0, 000a
    0008: const/4 v0, 0
    0009: return-object v0
    000a: invoke-virtual {v0}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;->getInfo()Ljava/lang/Object;
    000d: move-result-object v0
    000e: goto 0009

  [Virtual Method] findAccessibilityNodeInfosByText(Ljava/lang/String;, I) -> Ljava/util/List;
    // registers=8, ins=3, outs=3, insns_size=37
    0000: iget v0, v5.Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1;->val$compat:Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    0002: invoke-virtual {v0, v6, v7}, Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;->findAccessibilityNodeInfosByText(Ljava/lang/String;I)Ljava/util/List;
    0005: move-result-object v2
    0006: new-instance v3, Ljava/util/ArrayList;
    0008: invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V
    000b: invoke-interface {v2}, Ljava/util/List;->size()I
    000e: move-result v4
    000f: const/4 v0, 0
    0010: move(op=01) v1, v0
    0011: if-ge v1, v4, 0024
    0013: invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;
    0016: move-result-object v0
    0017: check-cast v0, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;
    0019: invoke-virtual {v0}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;->getInfo()Ljava/lang/Object;
    001c: move-result-object v0
    001d: invoke-interface {v3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    0020: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0022: move(op=01) v1, v0
    0023: goto 0011
    0024: return-object v3

  [Virtual Method] performAction(I, I, Landroid/os/Bundle;) -> Z
    // registers=5, ins=4, outs=4, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl$1;->val$compat:Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    0002: invoke-virtual {v0, v2, v3, v4}, Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;->performAction(IILandroid/os/Bundle;)Z
    0005: move-result v0
    0006: return v0