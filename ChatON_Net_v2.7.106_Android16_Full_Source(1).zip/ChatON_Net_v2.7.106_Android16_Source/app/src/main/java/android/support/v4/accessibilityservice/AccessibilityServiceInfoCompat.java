=== CLASS Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat; (Source: AccessibilityServiceInfoCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] FEEDBACK_ALL_MASK: I = -1
  [Static Field] IMPL: Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=22
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 14 (0xe)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoIcsImpl;
    0008: invoke-direct {v0}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoIcsImpl;-><init>()V
    000b: sput v0, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat;->IMPL:Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;
    000d: return-void
    000e: new-instance v0, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl;
    0010: invoke-direct {v0}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl;-><init>()V
    0013: sput v0, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat;->IMPL:Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;
    0015: goto 000d

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] feedbackTypeToString(I) -> Ljava/lang/String;
    // registers=5, ins=1, outs=2, insns_size=100
    0000: const/4 v3, 1
    0001: new-instance v0, Ljava/lang/StringBuilder;
    0003: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0006: const-string v1, '['
    0008: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000b: if-lez v4, 0043
    000d: invoke-static {v4}, Ljava/lang/Integer;->numberOfTrailingZeros(I)I
    0010: move-result v1
    0011: binop(op=98) v1, v3, v1
    0013: binop/lit8(op=df) v2, v1, -1 (-0x1)
    0015: binop/2addr(op=b5) v4, v2
    0016: invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I
    0019: move-result v2
    001a: if-le v2, v3, 0021
    001c: const-string v2, ', '
    001e: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0021: sparse-switch v1, +45 (-> 004e)
    0024: goto 000b
    0025: const-string v1, 'FEEDBACK_SPOKEN'
    0027: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002a: goto 000b
    002b: const-string v1, 'FEEDBACK_AUDIBLE'
    002d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0030: goto 000b
    0031: const-string v1, 'FEEDBACK_HAPTIC'
    0033: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0036: goto 000b
    0037: const-string v1, 'FEEDBACK_GENERIC'
    0039: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003c: goto 000b
    003d: const-string v1, 'FEEDBACK_VISUAL'
    003f: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0042: goto 000b
    0043: const-string v1, ']'
    0045: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0048: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    004b: move-result-object v0
    004c: return-object v0
    004d: nop
    004e: sparse-switch-payload {1: 4, 2: 16, 4: 10, 8: 28, 16: 22}

  [Direct Method] flagToString(I) -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=14
    0000: packed-switch v1, +8 (-> 0008)
    0003: const/4 v0, 0
    0004: return-object v0
    0005: const-string v0, 'DEFAULT'
    0007: goto 0004
    0008: packed-switch-payload first=1 targets=[5]

  [Direct Method] getCanRetrieveWindowContent(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Z
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat;->IMPL:Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;->getCanRetrieveWindowContent(Landroid/accessibilityservice/AccessibilityServiceInfo;)Z
    0005: move-result v0
    0006: return v0

  [Direct Method] getDescription(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat;->IMPL:Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;->getDescription(Landroid/accessibilityservice/AccessibilityServiceInfo;)Ljava/lang/String;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getId(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat;->IMPL:Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;->getId(Landroid/accessibilityservice/AccessibilityServiceInfo;)Ljava/lang/String;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getResolveInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Landroid/content/pm/ResolveInfo;
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat;->IMPL:Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;->getResolveInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;)Landroid/content/pm/ResolveInfo;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getSettingsActivityName(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat;->IMPL:Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;->getSettingsActivityName(Landroid/accessibilityservice/AccessibilityServiceInfo;)Ljava/lang/String;
    0005: move-result-object v0
    0006: return-object v0