=== CLASS Landroid/support/v4/view/KeyEventCompatHoneycomb; (Source: KeyEventCompatHoneycomb.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] metaStateHasModifiers(I, I) -> Z
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-static {v1, v2}, Landroid/view/KeyEvent;->metaStateHasModifiers(II)Z
    0003: move-result v0
    0004: return v0

  [Direct Method] metaStateHasNoModifiers(I) -> Z
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-static {v1}, Landroid/view/KeyEvent;->metaStateHasNoModifiers(I)Z
    0003: move-result v0
    0004: return v0

  [Direct Method] normalizeMetaState(I) -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-static {v1}, Landroid/view/KeyEvent;->normalizeMetaState(I)I
    0003: move-result v0
    0004: return v0