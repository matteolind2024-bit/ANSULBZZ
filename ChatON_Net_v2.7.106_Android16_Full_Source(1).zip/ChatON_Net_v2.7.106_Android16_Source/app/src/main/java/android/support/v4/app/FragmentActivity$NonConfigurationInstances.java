=== CLASS Landroid/support/v4/app/FragmentActivity$NonConfigurationInstances; (Source: FragmentActivity.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] activity: Ljava/lang/Object;
  [Instance Field] children: Ljava/util/HashMap;
  [Instance Field] custom: Ljava/lang/Object;
  [Instance Field] fragments: Ljava/util/ArrayList;
  [Instance Field] loaders: Landroid/support/v4/util/SparseArrayCompat;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void