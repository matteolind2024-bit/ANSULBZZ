=== CLASS Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl; (Source: AccessibilityServiceInfoCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getCanRetrieveWindowContent(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getDescription(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getId(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getResolveInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Landroid/content/pm/ResolveInfo;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getSettingsActivityName(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0