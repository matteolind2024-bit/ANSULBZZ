=== CLASS Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordJellyBeanImpl; (Source: AccessibilityRecordCompat.java) ===
  Super: Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordIcsMr1Impl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordIcsMr1Impl;-><init>()V
    0003: return-void

  [Virtual Method] setSource(Ljava/lang/Object;, Landroid/view/View;, I) -> V
    // registers=4, ins=4, outs=3, insns_size=4
    0000: invoke-static {v1, v2, v3}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatJellyBean;->setSource(Ljava/lang/Object;Landroid/view/View;I)V
    0003: return-void