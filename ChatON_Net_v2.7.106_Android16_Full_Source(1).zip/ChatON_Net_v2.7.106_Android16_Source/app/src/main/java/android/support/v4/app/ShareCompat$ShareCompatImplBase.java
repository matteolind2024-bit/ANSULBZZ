=== CLASS Landroid/support/v4/app/ShareCompat$ShareCompatImplBase; (Source: ShareCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/app/ShareCompat$ShareCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] withinStyle(Ljava/lang/StringBuilder;, Ljava/lang/CharSequence;, I, I) -> V
    // registers=9, ins=4, outs=2, insns_size=107
    0000: const/16 v4, 32 (0x20)
    0002: move(op=01) v0, v7
    0003: if-ge v0, v8, 006a
    0005: invoke-interface {v6, v0}, Ljava/lang/CharSequence;->charAt(I)C
    0008: move-result v1
    0009: const/16 v2, 60 (0x3c)
    000b: if-ne v1, v2, 0015
    000d: const-string v1, '&lt;'
    000f: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0014: goto 0003
    0015: const/16 v2, 62 (0x3e)
    0017: if-ne v1, v2, 001f
    0019: const-string v1, '&gt;'
    001b: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001e: goto 0012
    001f: const/16 v2, 38 (0x26)
    0021: if-ne v1, v2, 0029
    0023: const-string v1, '&amp;'
    0025: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0028: goto 0012
    0029: const/16 v2, 126 (0x7e)
    002b: if-gt v1, v2, 002f
    002d: if-ge v1, v4, 004c
    002f: new-instance v2, Ljava/lang/StringBuilder;
    0031: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0034: const-string v3, '&#'
    0036: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0039: move-result-object v2
    003a: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    003d: move-result-object v1
    003e: const-string v2, ';'
    0040: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0043: move-result-object v1
    0044: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0047: move-result-object v1
    0048: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004b: goto 0012
    004c: if-ne v1, v4, 0066
    004e: binop/lit8(op=d8) v1, v0, 1 (0x1)
    0050: if-ge v1, v8, 0062
    0052: binop/lit8(op=d8) v1, v0, 1 (0x1)
    0054: invoke-interface {v6, v1}, Ljava/lang/CharSequence;->charAt(I)C
    0057: move-result v1
    0058: if-ne v1, v4, 0062
    005a: const-string v1, '&nbsp;'
    005c: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    005f: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0061: goto 004e
    0062: invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    0065: goto 0012
    0066: invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    0069: goto 0012
    006a: return-void

  [Virtual Method] configureMenuItem(Landroid/view/MenuItem;, Landroid/support/v4/app/ShareCompat$IntentBuilder;) -> V
    // registers=4, ins=3, outs=2, insns_size=8
    0000: invoke-virtual {v3}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->createChooserIntent()Landroid/content/Intent;
    0003: move-result-object v0
    0004: invoke-interface {v2, v0}, Landroid/view/MenuItem;->setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;
    0007: return-void

  [Virtual Method] escapeHtml(Ljava/lang/CharSequence;) -> Ljava/lang/String;
    // registers=5, ins=2, outs=4, insns_size=18
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0005: const/4 v1, 0
    0006: invoke-interface {v4}, Ljava/lang/CharSequence;->length()I
    0009: move-result v2
    000a: invoke-static {v0, v4, v1, v2}, Landroid/support/v4/app/ShareCompat$ShareCompatImplBase;->withinStyle(Ljava/lang/StringBuilder;Ljava/lang/CharSequence;II)V
    000d: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0010: move-result-object v0
    0011: return-object v0