=== CLASS Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$1; (Source: AccessibilityManagerCompatIcs.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;
  [Instance Field] val$bridge: Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge;

  [Direct Method] <init>(Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$1;->val$bridge:Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onAccessibilityStateChanged(Z) -> V
    // registers=3, ins=2, outs=2, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$1;->val$bridge:Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge;
    0002: invoke-interface {v0, v2}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge;->onAccessibilityStateChanged(Z)V
    0005: return-void