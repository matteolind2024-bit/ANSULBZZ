=== CLASS Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs; (Source: AccessibilityRecordCompatIcs.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getAddedCount(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getAddedCount()I
    0005: move-result v0
    0006: return v0

  [Direct Method] getBeforeText(Ljava/lang/Object;) -> Ljava/lang/CharSequence;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getBeforeText()Ljava/lang/CharSequence;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getClassName(Ljava/lang/Object;) -> Ljava/lang/CharSequence;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getClassName()Ljava/lang/CharSequence;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getContentDescription(Ljava/lang/Object;) -> Ljava/lang/CharSequence;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getContentDescription()Ljava/lang/CharSequence;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getCurrentItemIndex(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getCurrentItemIndex()I
    0005: move-result v0
    0006: return v0

  [Direct Method] getFromIndex(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getFromIndex()I
    0005: move-result v0
    0006: return v0

  [Direct Method] getItemCount(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getItemCount()I
    0005: move-result v0
    0006: return v0

  [Direct Method] getParcelableData(Ljava/lang/Object;) -> Landroid/os/Parcelable;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getParcelableData()Landroid/os/Parcelable;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getRemovedCount(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getRemovedCount()I
    0005: move-result v0
    0006: return v0

  [Direct Method] getScrollX(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getScrollX()I
    0005: move-result v0
    0006: return v0

  [Direct Method] getScrollY(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getScrollY()I
    0005: move-result v0
    0006: return v0

  [Direct Method] getSource(Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getText(Ljava/lang/Object;) -> Ljava/util/List;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getText()Ljava/util/List;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getToIndex(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getToIndex()I
    0005: move-result v0
    0006: return v0

  [Direct Method] getWindowId(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getWindowId()I
    0005: move-result v0
    0006: return v0

  [Direct Method] isChecked(Ljava/lang/Object;) -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->isChecked()Z
    0005: move-result v0
    0006: return v0

  [Direct Method] isEnabled(Ljava/lang/Object;) -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->isEnabled()Z
    0005: move-result v0
    0006: return v0

  [Direct Method] isFullScreen(Ljava/lang/Object;) -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->isFullScreen()Z
    0005: move-result v0
    0006: return v0

  [Direct Method] isPassword(Ljava/lang/Object;) -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->isPassword()Z
    0005: move-result v0
    0006: return v0

  [Direct Method] isScrollable(Ljava/lang/Object;) -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->isScrollable()Z
    0005: move-result v0
    0006: return v0

  [Direct Method] obtain() -> Ljava/lang/Object;
    // registers=1, ins=0, outs=0, insns_size=5
    0000: invoke-static {}, Landroid/view/accessibility/AccessibilityRecord;->obtain()Landroid/view/accessibility/AccessibilityRecord;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] obtain(Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-static {v1}, Landroid/view/accessibility/AccessibilityRecord;->obtain(Landroid/view/accessibility/AccessibilityRecord;)Landroid/view/accessibility/AccessibilityRecord;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] recycle(Ljava/lang/Object;) -> V
    // registers=1, ins=1, outs=1, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityRecord;->recycle()V
    0005: return-void

  [Direct Method] setAddedCount(Ljava/lang/Object;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setAddedCount(I)V
    0005: return-void

  [Direct Method] setBeforeText(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setBeforeText(Ljava/lang/CharSequence;)V
    0005: return-void

  [Direct Method] setChecked(Ljava/lang/Object;, Z) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setChecked(Z)V
    0005: return-void

  [Direct Method] setClassName(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setClassName(Ljava/lang/CharSequence;)V
    0005: return-void

  [Direct Method] setContentDescription(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setContentDescription(Ljava/lang/CharSequence;)V
    0005: return-void

  [Direct Method] setCurrentItemIndex(Ljava/lang/Object;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setCurrentItemIndex(I)V
    0005: return-void

  [Direct Method] setEnabled(Ljava/lang/Object;, Z) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setEnabled(Z)V
    0005: return-void

  [Direct Method] setFromIndex(Ljava/lang/Object;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setFromIndex(I)V
    0005: return-void

  [Direct Method] setFullScreen(Ljava/lang/Object;, Z) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setFullScreen(Z)V
    0005: return-void

  [Direct Method] setItemCount(Ljava/lang/Object;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setItemCount(I)V
    0005: return-void

  [Direct Method] setParcelableData(Ljava/lang/Object;, Landroid/os/Parcelable;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setParcelableData(Landroid/os/Parcelable;)V
    0005: return-void

  [Direct Method] setPassword(Ljava/lang/Object;, Z) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setPassword(Z)V
    0005: return-void

  [Direct Method] setRemovedCount(Ljava/lang/Object;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setRemovedCount(I)V
    0005: return-void

  [Direct Method] setScrollX(Ljava/lang/Object;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setScrollX(I)V
    0005: return-void

  [Direct Method] setScrollY(Ljava/lang/Object;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setScrollY(I)V
    0005: return-void

  [Direct Method] setScrollable(Ljava/lang/Object;, Z) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setScrollable(Z)V
    0005: return-void

  [Direct Method] setSource(Ljava/lang/Object;, Landroid/view/View;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setSource(Landroid/view/View;)V
    0005: return-void

  [Direct Method] setToIndex(Ljava/lang/Object;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setToIndex(I)V
    0005: return-void