=== CLASS Landroid/support/v4/net/ConnectivityManagerCompatHoneycombMR2; (Source: ConnectivityManagerCompatHoneycombMR2.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] isActiveNetworkMetered(Landroid/net/ConnectivityManager;) -> Z
    // registers=3, ins=1, outs=1, insns_size=42
    0000: const/4 v0, 1
    0001: invoke-virtual {v2}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;
    0004: move-result-object v1
    0005: if-nez v1, 0008
    0007: return v0
    0008: invoke-virtual {v1}, Landroid/net/NetworkInfo;->getType()I
    000b: move-result v1
    000c: packed-switch v1, +6 (-> 0012)
    000f: goto 0007
    0010: const/4 v0, 0
    0011: goto 0007
    0012: packed-switch-payload first=0 targets=[-5, 4, -5, -5, -5, -5, -5, 4, 3, 4]