=== CLASS Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoVersionImpl; (Source: AccessibilityServiceInfoCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] getCanRetrieveWindowContent(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Z

  [Virtual Method] getDescription(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;

  [Virtual Method] getId(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;

  [Virtual Method] getResolveInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Landroid/content/pm/ResolveInfo;

  [Virtual Method] getSettingsActivityName(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;