=== CLASS Landroid/support/v4/view/KeyEventCompat$BaseKeyEventVersionImpl; (Source: KeyEventCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;
  [Static Field] META_ALL_MASK: I = 247
  [Static Field] META_MODIFIER_MASK: I = 247

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] metaStateFilterDirectionalModifiers(I, I, I, I, I) -> I
    // registers=10, ins=5, outs=2, insns_size=39
    0000: const/4 v0, 1
    0001: const/4 v1, 0
    0002: binop(op=95) v2, v6, v7
    0004: if-eqz v2, 0019
    0006: move(op=01) v2, v0
    0007: binop(op=96) v3, v8, v9
    0009: binop(op=95) v4, v6, v3
    000b: if-eqz v4, 001b
    000d: if-eqz v2, 0021
    000f: if-eqz v0, 001d
    0011: new-instance v0, Ljava/lang/IllegalArgumentException;
    0013: const-string v1, 'bad arguments'
    0015: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0018: throw v0
    0019: move(op=01) v2, v1
    001a: goto 0007
    001b: move(op=01) v0, v1
    001c: goto 000d
    001d: binop/lit8(op=df) v0, v3, -1 (-0x1)
    001f: binop/2addr(op=b5) v5, v0
    0020: return v5
    0021: if-eqz v0, 0020
    0023: binop/lit8(op=df) v0, v7, -1 (-0x1)
    0025: binop/2addr(op=b5) v5, v0
    0026: goto 0020

  [Virtual Method] metaStateHasModifiers(I, I) -> Z
    // registers=8, ins=3, outs=5, insns_size=29
    0000: const/4 v0, 1
    0001: invoke-virtual {v5, v6}, Landroid/support/v4/view/KeyEventCompat$BaseKeyEventVersionImpl;->normalizeMetaState(I)I
    0004: move-result v1
    0005: binop/lit16(op=d5) v1, v1, 247 (0xf7)
    0007: const/16 v2, 64 (0x40)
    0009: const/16 v3, 128 (0x80)
    000b: invoke-static {v1, v7, v0, v2, v3}, Landroid/support/v4/view/KeyEventCompat$BaseKeyEventVersionImpl;->metaStateFilterDirectionalModifiers(IIIII)I
    000e: move-result v1
    000f: const/4 v2, 2
    0010: const/16 v3, 16 (0x10)
    0012: const/16 v4, 32 (0x20)
    0014: invoke-static {v1, v7, v2, v3, v4}, Landroid/support/v4/view/KeyEventCompat$BaseKeyEventVersionImpl;->metaStateFilterDirectionalModifiers(IIIII)I
    0017: move-result v1
    0018: if-ne v1, v7, 001b
    001a: return v0
    001b: const/4 v0, 0
    001c: goto 001a

  [Virtual Method] metaStateHasNoModifiers(I) -> Z
    // registers=3, ins=2, outs=2, insns_size=12
    0000: invoke-virtual {v1, v2}, Landroid/support/v4/view/KeyEventCompat$BaseKeyEventVersionImpl;->normalizeMetaState(I)I
    0003: move-result v0
    0004: binop/lit16(op=d5) v0, v0, 247 (0xf7)
    0006: if-nez v0, 000a
    0008: const/4 v0, 1
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] normalizeMetaState(I) -> I
    // registers=4, ins=2, outs=0, insns_size=17
    0000: binop/lit16(op=d5) v0, v3, 192 (0xc0)
    0002: if-eqz v0, 000f
    0004: binop/lit8(op=de) v0, v3, 1 (0x1)
    0006: binop/lit8(op=dd) v1, v0, 48 (0x30)
    0008: if-eqz v1, 000c
    000a: binop/lit8(op=de) v0, v0, 2 (0x2)
    000c: binop/lit16(op=d5) v0, v0, 247 (0xf7)
    000e: return v0
    000f: move(op=01) v0, v3
    0010: goto 0006