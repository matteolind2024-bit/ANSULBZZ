=== CLASS Landroid/support/v4/widget/CursorAdapter$1; (Source: CursorAdapter.java) ===
  Super: Ljava/lang/Object;