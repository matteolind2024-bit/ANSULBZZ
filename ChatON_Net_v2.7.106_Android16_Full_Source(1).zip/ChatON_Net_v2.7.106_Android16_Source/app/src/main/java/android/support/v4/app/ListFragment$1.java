=== CLASS Landroid/support/v4/app/ListFragment$1; (Source: ListFragment.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/lang/Runnable;
  [Instance Field] this$0: Landroid/support/v4/app/ListFragment;

  [Direct Method] <init>(Landroid/support/v4/app/ListFragment;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/app/ListFragment$1;->this$0:Landroid/support/v4/app/ListFragment;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] run() -> V
    // registers=3, ins=1, outs=2, insns_size=12
    0000: iget v0, v2.Landroid/support/v4/app/ListFragment$1;->this$0:Landroid/support/v4/app/ListFragment;
    0002: iget v0, v0.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    0004: iget v1, v2.Landroid/support/v4/app/ListFragment$1;->this$0:Landroid/support/v4/app/ListFragment;
    0006: iget v1, v1.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    0008: invoke-virtual {v0, v1}, Landroid/widget/ListView;->focusableViewAvailable(Landroid/view/View;)V
    000b: return-void