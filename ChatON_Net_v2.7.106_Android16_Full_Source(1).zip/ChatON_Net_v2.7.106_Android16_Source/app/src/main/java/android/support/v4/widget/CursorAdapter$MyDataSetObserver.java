=== CLASS Landroid/support/v4/widget/CursorAdapter$MyDataSetObserver; (Source: CursorAdapter.java) ===
  Super: Landroid/database/DataSetObserver;
  [Instance Field] this$0: Landroid/support/v4/widget/CursorAdapter;

  [Direct Method] <init>(Landroid/support/v4/widget/CursorAdapter;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/widget/CursorAdapter$MyDataSetObserver;->this$0:Landroid/support/v4/widget/CursorAdapter;
    0002: invoke-direct {v0}, Landroid/database/DataSetObserver;-><init>()V
    0005: return-void

  [Direct Method] <init>(Landroid/support/v4/widget/CursorAdapter;, Landroid/support/v4/widget/CursorAdapter$1;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Landroid/support/v4/widget/CursorAdapter$MyDataSetObserver;-><init>(Landroid/support/v4/widget/CursorAdapter;)V
    0003: return-void

  [Virtual Method] onChanged() -> V
    // registers=3, ins=1, outs=1, insns_size=11
    0000: iget v0, v2.Landroid/support/v4/widget/CursorAdapter$MyDataSetObserver;->this$0:Landroid/support/v4/widget/CursorAdapter;
    0002: const/4 v1, 1
    0003: iput v1, v0.Landroid/support/v4/widget/CursorAdapter;->mDataValid:Z
    0005: iget v0, v2.Landroid/support/v4/widget/CursorAdapter$MyDataSetObserver;->this$0:Landroid/support/v4/widget/CursorAdapter;
    0007: invoke-virtual {v0}, Landroid/support/v4/widget/CursorAdapter;->notifyDataSetChanged()V
    000a: return-void

  [Virtual Method] onInvalidated() -> V
    // registers=3, ins=1, outs=1, insns_size=11
    0000: iget v0, v2.Landroid/support/v4/widget/CursorAdapter$MyDataSetObserver;->this$0:Landroid/support/v4/widget/CursorAdapter;
    0002: const/4 v1, 0
    0003: iput v1, v0.Landroid/support/v4/widget/CursorAdapter;->mDataValid:Z
    0005: iget v0, v2.Landroid/support/v4/widget/CursorAdapter$MyDataSetObserver;->this$0:Landroid/support/v4/widget/CursorAdapter;
    0007: invoke-virtual {v0}, Landroid/support/v4/widget/CursorAdapter;->notifyDataSetInvalidated()V
    000a: return-void