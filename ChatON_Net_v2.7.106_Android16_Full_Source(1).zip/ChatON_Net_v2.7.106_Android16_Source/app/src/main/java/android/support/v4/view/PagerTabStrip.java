=== CLASS Landroid/support/v4/view/PagerTabStrip; (Source: PagerTabStrip.java) ===
  Super: Landroid/support/v4/view/PagerTitleStrip;
  [Static Field] FULL_UNDERLINE_HEIGHT: I = 1
  [Static Field] INDICATOR_HEIGHT: I = 3
  [Static Field] MIN_PADDING_BOTTOM: I = 6
  [Static Field] MIN_STRIP_HEIGHT: I = 32
  [Static Field] MIN_TEXT_SPACING: I = 64
  [Static Field] TAB_PADDING: I = 16
  [Static Field] TAB_SPACING: I = 32
  [Static Field] TAG: Ljava/lang/String; = 'PagerTabStrip'
  [Instance Field] mDrawFullUnderline: Z
  [Instance Field] mDrawFullUnderlineSet: Z
  [Instance Field] mFullUnderlineHeight: I
  [Instance Field] mIgnoreTap: Z
  [Instance Field] mIndicatorColor: I
  [Instance Field] mIndicatorHeight: I
  [Instance Field] mInitialMotionX: F
  [Instance Field] mInitialMotionY: F
  [Instance Field] mMinPaddingBottom: I
  [Instance Field] mMinStripHeight: I
  [Instance Field] mMinTextSpacing: I
  [Instance Field] mTabAlpha: I
  [Instance Field] mTabPadding: I
  [Instance Field] mTabPaint: Landroid/graphics/Paint;
  [Instance Field] mTempRect: Landroid/graphics/Rect;
  [Instance Field] mTouchSlop: I

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=3, ins=2, outs=3, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-direct {v1, v2, v0}, Landroid/support/v4/view/PagerTabStrip;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    0004: return-void

  [Direct Method] <init>(Landroid/content/Context;, Landroid/util/AttributeSet;) -> V
    // registers=9, ins=3, outs=5, insns_size=169
    0000: const/4 v5, 1
    0001: const/4 v4, 0
    0002: const/high16 v2, 1056964608 (0x3f000000)
    0004: invoke-direct {v6, v7, v8}, Landroid/support/v4/view/PagerTitleStrip;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    0007: new-instance v0, Landroid/graphics/Paint;
    0009: invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V
    000c: iput v0, v6.Landroid/support/v4/view/PagerTabStrip;->mTabPaint:Landroid/graphics/Paint;
    000e: new-instance v0, Landroid/graphics/Rect;
    0010: invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V
    0013: iput v0, v6.Landroid/support/v4/view/PagerTabStrip;->mTempRect:Landroid/graphics/Rect;
    0015: const/16 v0, 255 (0xff)
    0017: iput v0, v6.Landroid/support/v4/view/PagerTabStrip;->mTabAlpha:I
    0019: iput v4, v6.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderline:Z
    001b: iput v4, v6.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderlineSet:Z
    001d: iget v0, v6.Landroid/support/v4/view/PagerTabStrip;->mTextColor:I
    001f: iput v0, v6.Landroid/support/v4/view/PagerTabStrip;->mIndicatorColor:I
    0021: iget v0, v6.Landroid/support/v4/view/PagerTabStrip;->mTabPaint:Landroid/graphics/Paint;
    0023: iget v1, v6.Landroid/support/v4/view/PagerTabStrip;->mIndicatorColor:I
    0025: invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V
    0028: invoke-virtual {v7}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    002b: move-result-object v0
    002c: invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    002f: move-result-object v0
    0030: iget v0, v0.Landroid/util/DisplayMetrics;->density:F
    0032: const/high16 v1, 1077936128 (0x40400000)
    0034: binop/2addr(op=c8) v1, v0
    0035: binop/2addr(op=c6) v1, v2
    0036: unop(op=87) v1, v1
    0037: iput v1, v6.Landroid/support/v4/view/PagerTabStrip;->mIndicatorHeight:I
    0039: const/high16 v1, 1086324736 (0x40c00000)
    003b: binop/2addr(op=c8) v1, v0
    003c: binop/2addr(op=c6) v1, v2
    003d: unop(op=87) v1, v1
    003e: iput v1, v6.Landroid/support/v4/view/PagerTabStrip;->mMinPaddingBottom:I
    0040: const/high16 v1, 1115684864 (0x42800000)
    0042: binop/2addr(op=c8) v1, v0
    0043: unop(op=87) v1, v1
    0044: iput v1, v6.Landroid/support/v4/view/PagerTabStrip;->mMinTextSpacing:I
    0046: const/high16 v1, 1098907648 (0x41800000)
    0048: binop/2addr(op=c8) v1, v0
    0049: binop/2addr(op=c6) v1, v2
    004a: unop(op=87) v1, v1
    004b: iput v1, v6.Landroid/support/v4/view/PagerTabStrip;->mTabPadding:I
    004d: const/high16 v1, 1065353216 (0x3f800000)
    004f: binop/2addr(op=c8) v1, v0
    0050: binop/2addr(op=c6) v1, v2
    0051: unop(op=87) v1, v1
    0052: iput v1, v6.Landroid/support/v4/view/PagerTabStrip;->mFullUnderlineHeight:I
    0054: const/high16 v1, 1107296256 (0x42000000)
    0056: binop/2addr(op=c8) v0, v1
    0057: binop/2addr(op=c6) v0, v2
    0058: unop(op=87) v0, v0
    0059: iput v0, v6.Landroid/support/v4/view/PagerTabStrip;->mMinStripHeight:I
    005b: invoke-static {v7}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;
    005e: move-result-object v0
    005f: invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I
    0062: move-result v0
    0063: iput v0, v6.Landroid/support/v4/view/PagerTabStrip;->mTouchSlop:I
    0065: invoke-virtual {v6}, Landroid/support/v4/view/PagerTabStrip;->getPaddingLeft()I
    0068: move-result v0
    0069: invoke-virtual {v6}, Landroid/support/v4/view/PagerTabStrip;->getPaddingTop()I
    006c: move-result v1
    006d: invoke-virtual {v6}, Landroid/support/v4/view/PagerTabStrip;->getPaddingRight()I
    0070: move-result v2
    0071: invoke-virtual {v6}, Landroid/support/v4/view/PagerTabStrip;->getPaddingBottom()I
    0074: move-result v3
    0075: invoke-virtual {v6, v0, v1, v2, v3}, Landroid/support/v4/view/PagerTabStrip;->setPadding(IIII)V
    0078: invoke-virtual {v6}, Landroid/support/v4/view/PagerTabStrip;->getTextSpacing()I
    007b: move-result v0
    007c: invoke-virtual {v6, v0}, Landroid/support/v4/view/PagerTabStrip;->setTextSpacing(I)V
    007f: invoke-virtual {v6, v4}, Landroid/support/v4/view/PagerTabStrip;->setWillNotDraw(Z)V
    0082: iget v0, v6.Landroid/support/v4/view/PagerTabStrip;->mPrevText:Landroid/widget/TextView;
    0084: invoke-virtual {v0, v5}, Landroid/widget/TextView;->setFocusable(Z)V
    0087: iget v0, v6.Landroid/support/v4/view/PagerTabStrip;->mPrevText:Landroid/widget/TextView;
    0089: new-instance v1, Landroid/support/v4/view/PagerTabStrip$1;
    008b: invoke-direct {v1, v6}, Landroid/support/v4/view/PagerTabStrip$1;-><init>(Landroid/support/v4/view/PagerTabStrip;)V
    008e: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    0091: iget v0, v6.Landroid/support/v4/view/PagerTabStrip;->mNextText:Landroid/widget/TextView;
    0093: invoke-virtual {v0, v5}, Landroid/widget/TextView;->setFocusable(Z)V
    0096: iget v0, v6.Landroid/support/v4/view/PagerTabStrip;->mNextText:Landroid/widget/TextView;
    0098: new-instance v1, Landroid/support/v4/view/PagerTabStrip$2;
    009a: invoke-direct {v1, v6}, Landroid/support/v4/view/PagerTabStrip$2;-><init>(Landroid/support/v4/view/PagerTabStrip;)V
    009d: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    00a0: invoke-virtual {v6}, Landroid/support/v4/view/PagerTabStrip;->getBackground()Landroid/graphics/drawable/Drawable;
    00a3: move-result-object v0
    00a4: if-nez v0, 00a8
    00a6: iput v5, v6.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderline:Z
    00a8: return-void

  [Virtual Method] getDrawFullUnderline() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderline:Z
    0002: return v0

  [Virtual Method] getMinHeight() -> I
    // registers=3, ins=1, outs=2, insns_size=11
    0000: invoke-super {v2}, Landroid/support/v4/view/PagerTitleStrip;->getMinHeight()I
    0003: move-result v0
    0004: iget v1, v2.Landroid/support/v4/view/PagerTabStrip;->mMinStripHeight:I
    0006: invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I
    0009: move-result v0
    000a: return v0

  [Virtual Method] getTabIndicatorColor() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/view/PagerTabStrip;->mIndicatorColor:I
    0002: return v0

  [Virtual Method] onDraw(Landroid/graphics/Canvas;) -> V
    // registers=10, ins=2, outs=6, insns_size=90
    0000: const v7, 16777215 (0xffffff)
    0003: invoke-super {v8, v9}, Landroid/support/v4/view/PagerTitleStrip;->onDraw(Landroid/graphics/Canvas;)V
    0006: invoke-virtual {v8}, Landroid/support/v4/view/PagerTabStrip;->getHeight()I
    0009: move-result v6
    000a: iget v0, v8.Landroid/support/v4/view/PagerTabStrip;->mCurrText:Landroid/widget/TextView;
    000c: invoke-virtual {v0}, Landroid/widget/TextView;->getLeft()I
    000f: move-result v0
    0010: iget v1, v8.Landroid/support/v4/view/PagerTabStrip;->mTabPadding:I
    0012: binop/2addr(op=b1) v0, v1
    0013: iget v1, v8.Landroid/support/v4/view/PagerTabStrip;->mCurrText:Landroid/widget/TextView;
    0015: invoke-virtual {v1}, Landroid/widget/TextView;->getRight()I
    0018: move-result v1
    0019: iget v2, v8.Landroid/support/v4/view/PagerTabStrip;->mTabPadding:I
    001b: binop(op=90) v3, v1, v2
    001d: iget v1, v8.Landroid/support/v4/view/PagerTabStrip;->mIndicatorHeight:I
    001f: binop(op=91) v2, v6, v1
    0021: iget v1, v8.Landroid/support/v4/view/PagerTabStrip;->mTabPaint:Landroid/graphics/Paint;
    0023: iget v4, v8.Landroid/support/v4/view/PagerTabStrip;->mTabAlpha:I
    0025: binop/lit8(op=e0) v4, v4, 24 (0x18)
    0027: iget v5, v8.Landroid/support/v4/view/PagerTabStrip;->mIndicatorColor:I
    0029: binop/2addr(op=b5) v5, v7
    002a: binop/2addr(op=b6) v4, v5
    002b: invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setColor(I)V
    002e: unop(op=82) v1, v0
    002f: unop(op=82) v2, v2
    0030: unop(op=82) v3, v3
    0031: unop(op=82) v4, v6
    0032: iget v5, v8.Landroid/support/v4/view/PagerTabStrip;->mTabPaint:Landroid/graphics/Paint;
    0034: move(op=07) v0, v9
    0035: invoke-virtual/range {v0..v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V
    0038: iget v0, v8.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderline:Z
    003a: if-eqz v0, 0059
    003c: iget v0, v8.Landroid/support/v4/view/PagerTabStrip;->mTabPaint:Landroid/graphics/Paint;
    003e: const/high16 v1, -16777216 (-0x1000000)
    0040: iget v2, v8.Landroid/support/v4/view/PagerTabStrip;->mIndicatorColor:I
    0042: binop/2addr(op=b5) v2, v7
    0043: binop/2addr(op=b6) v1, v2
    0044: invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V
    0047: const/4 v1, 0
    0048: iget v0, v8.Landroid/support/v4/view/PagerTabStrip;->mFullUnderlineHeight:I
    004a: binop(op=91) v0, v6, v0
    004c: unop(op=82) v2, v0
    004d: invoke-virtual {v8}, Landroid/support/v4/view/PagerTabStrip;->getWidth()I
    0050: move-result v0
    0051: unop(op=82) v3, v0
    0052: unop(op=82) v4, v6
    0053: iget v5, v8.Landroid/support/v4/view/PagerTabStrip;->mTabPaint:Landroid/graphics/Paint;
    0055: move(op=07) v0, v9
    0056: invoke-virtual/range {v0..v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V
    0059: return-void

  [Virtual Method] onTouchEvent(Landroid/view/MotionEvent;) -> Z
    // registers=7, ins=2, outs=2, insns_size=132
    0000: const/4 v1, 1
    0001: const/4 v0, 0
    0002: invoke-virtual {v6}, Landroid/view/MotionEvent;->getAction()I
    0005: move-result v2
    0006: if-eqz v2, 000d
    0008: iget v3, v5.Landroid/support/v4/view/PagerTabStrip;->mIgnoreTap:Z
    000a: if-eqz v3, 000d
    000c: return v0
    000d: invoke-virtual {v6}, Landroid/view/MotionEvent;->getX()F
    0010: move-result v3
    0011: invoke-virtual {v6}, Landroid/view/MotionEvent;->getY()F
    0014: move-result v4
    0015: packed-switch v2, +101 (-> 007a)
    0018: move(op=01) v0, v1
    0019: goto 000c
    001a: iput v3, v5.Landroid/support/v4/view/PagerTabStrip;->mInitialMotionX:F
    001c: iput v4, v5.Landroid/support/v4/view/PagerTabStrip;->mInitialMotionY:F
    001e: iput v0, v5.Landroid/support/v4/view/PagerTabStrip;->mIgnoreTap:Z
    0020: goto 0018
    0021: iget v0, v5.Landroid/support/v4/view/PagerTabStrip;->mInitialMotionX:F
    0023: binop(op=a7) v0, v3, v0
    0025: invoke-static {v0}, Ljava/lang/Math;->abs(F)F
    0028: move-result v0
    0029: iget v2, v5.Landroid/support/v4/view/PagerTabStrip;->mTouchSlop:I
    002b: unop(op=82) v2, v2
    002c: cmp(op=2d) v0, v0, v2
    002e: if-gtz v0, 003f
    0030: iget v0, v5.Landroid/support/v4/view/PagerTabStrip;->mInitialMotionY:F
    0032: binop(op=a7) v0, v4, v0
    0034: invoke-static {v0}, Ljava/lang/Math;->abs(F)F
    0037: move-result v0
    0038: iget v2, v5.Landroid/support/v4/view/PagerTabStrip;->mTouchSlop:I
    003a: unop(op=82) v2, v2
    003b: cmp(op=2d) v0, v0, v2
    003d: if-lez v0, 0018
    003f: iput v1, v5.Landroid/support/v4/view/PagerTabStrip;->mIgnoreTap:Z
    0041: goto 0018
    0042: iget v0, v5.Landroid/support/v4/view/PagerTabStrip;->mCurrText:Landroid/widget/TextView;
    0044: invoke-virtual {v0}, Landroid/widget/TextView;->getLeft()I
    0047: move-result v0
    0048: iget v2, v5.Landroid/support/v4/view/PagerTabStrip;->mTabPadding:I
    004a: binop/2addr(op=b1) v0, v2
    004b: unop(op=82) v0, v0
    004c: cmp(op=2e) v0, v3, v0
    004e: if-gez v0, 005e
    0050: iget v0, v5.Landroid/support/v4/view/PagerTabStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0052: iget v2, v5.Landroid/support/v4/view/PagerTabStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0054: invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->getCurrentItem()I
    0057: move-result v2
    0058: binop/lit8(op=d8) v2, v2, -1 (-0x1)
    005a: invoke-virtual {v0, v2}, Landroid/support/v4/view/ViewPager;->setCurrentItem(I)V
    005d: goto 0018
    005e: iget v0, v5.Landroid/support/v4/view/PagerTabStrip;->mCurrText:Landroid/widget/TextView;
    0060: invoke-virtual {v0}, Landroid/widget/TextView;->getRight()I
    0063: move-result v0
    0064: iget v2, v5.Landroid/support/v4/view/PagerTabStrip;->mTabPadding:I
    0066: binop/2addr(op=b0) v0, v2
    0067: unop(op=82) v0, v0
    0068: cmp(op=2d) v0, v3, v0
    006a: if-lez v0, 0018
    006c: iget v0, v5.Landroid/support/v4/view/PagerTabStrip;->mPager:Landroid/support/v4/view/ViewPager;
    006e: iget v2, v5.Landroid/support/v4/view/PagerTabStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0070: invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->getCurrentItem()I
    0073: move-result v2
    0074: binop/lit8(op=d8) v2, v2, 1 (0x1)
    0076: invoke-virtual {v0, v2}, Landroid/support/v4/view/ViewPager;->setCurrentItem(I)V
    0079: goto 0018
    007a: packed-switch-payload first=0 targets=[5, 45, 12]

  [Virtual Method] setBackgroundColor(I) -> V
    // registers=3, ins=2, outs=2, insns_size=18
    0000: invoke-super {v1, v2}, Landroid/support/v4/view/PagerTitleStrip;->setBackgroundColor(I)V
    0003: iget v0, v1.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderlineSet:Z
    0005: if-nez v0, 000f
    0007: const/high16 v0, -16777216 (-0x1000000)
    0009: binop/2addr(op=b5) v0, v2
    000a: if-nez v0, 0010
    000c: const/4 v0, 1
    000d: iput v0, v1.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderline:Z
    000f: return-void
    0010: const/4 v0, 0
    0011: goto 000d

  [Virtual Method] setBackgroundDrawable(Landroid/graphics/drawable/Drawable;) -> V
    // registers=3, ins=2, outs=2, insns_size=15
    0000: invoke-super {v1, v2}, Landroid/support/v4/view/PagerTitleStrip;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    0003: iget v0, v1.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderlineSet:Z
    0005: if-nez v0, 000c
    0007: if-nez v2, 000d
    0009: const/4 v0, 1
    000a: iput v0, v1.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderline:Z
    000c: return-void
    000d: const/4 v0, 0
    000e: goto 000a

  [Virtual Method] setBackgroundResource(I) -> V
    // registers=3, ins=2, outs=2, insns_size=15
    0000: invoke-super {v1, v2}, Landroid/support/v4/view/PagerTitleStrip;->setBackgroundResource(I)V
    0003: iget v0, v1.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderlineSet:Z
    0005: if-nez v0, 000c
    0007: if-nez v2, 000d
    0009: const/4 v0, 1
    000a: iput v0, v1.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderline:Z
    000c: return-void
    000d: const/4 v0, 0
    000e: goto 000a

  [Virtual Method] setDrawFullUnderline(Z) -> V
    // registers=3, ins=2, outs=1, insns_size=9
    0000: iput v2, v1.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderline:Z
    0002: const/4 v0, 1
    0003: iput v0, v1.Landroid/support/v4/view/PagerTabStrip;->mDrawFullUnderlineSet:Z
    0005: invoke-virtual {v1}, Landroid/support/v4/view/PagerTabStrip;->invalidate()V
    0008: return-void

  [Virtual Method] setPadding(I, I, I, I) -> V
    // registers=6, ins=5, outs=5, insns_size=10
    0000: iget v0, v1.Landroid/support/v4/view/PagerTabStrip;->mMinPaddingBottom:I
    0002: if-ge v5, v0, 0006
    0004: iget v5, v1.Landroid/support/v4/view/PagerTabStrip;->mMinPaddingBottom:I
    0006: invoke-super {v1, v2, v3, v4, v5}, Landroid/support/v4/view/PagerTitleStrip;->setPadding(IIII)V
    0009: return-void

  [Virtual Method] setTabIndicatorColor(I) -> V
    // registers=4, ins=2, outs=2, insns_size=13
    0000: iput v3, v2.Landroid/support/v4/view/PagerTabStrip;->mIndicatorColor:I
    0002: iget v0, v2.Landroid/support/v4/view/PagerTabStrip;->mTabPaint:Landroid/graphics/Paint;
    0004: iget v1, v2.Landroid/support/v4/view/PagerTabStrip;->mIndicatorColor:I
    0006: invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V
    0009: invoke-virtual {v2}, Landroid/support/v4/view/PagerTabStrip;->invalidate()V
    000c: return-void

  [Virtual Method] setTabIndicatorColorResource(I) -> V
    // registers=3, ins=2, outs=2, insns_size=16
    0000: invoke-virtual {v1}, Landroid/support/v4/view/PagerTabStrip;->getContext()Landroid/content/Context;
    0003: move-result-object v0
    0004: invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    0007: move-result-object v0
    0008: invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getColor(I)I
    000b: move-result v0
    000c: invoke-virtual {v1, v0}, Landroid/support/v4/view/PagerTabStrip;->setTabIndicatorColor(I)V
    000f: return-void

  [Virtual Method] setTextSpacing(I) -> V
    // registers=3, ins=2, outs=2, insns_size=10
    0000: iget v0, v1.Landroid/support/v4/view/PagerTabStrip;->mMinTextSpacing:I
    0002: if-ge v2, v0, 0006
    0004: iget v2, v1.Landroid/support/v4/view/PagerTabStrip;->mMinTextSpacing:I
    0006: invoke-super {v1, v2}, Landroid/support/v4/view/PagerTitleStrip;->setTextSpacing(I)V
    0009: return-void

  [Virtual Method] updateTextPositions(I, F, Z) -> V
    // registers=10, ins=4, outs=5, insns_size=76
    0000: iget v0, v6.Landroid/support/v4/view/PagerTabStrip;->mTempRect:Landroid/graphics/Rect;
    0002: invoke-virtual {v6}, Landroid/support/v4/view/PagerTabStrip;->getHeight()I
    0005: move-result v1
    0006: iget v2, v6.Landroid/support/v4/view/PagerTabStrip;->mCurrText:Landroid/widget/TextView;
    0008: invoke-virtual {v2}, Landroid/widget/TextView;->getLeft()I
    000b: move-result v2
    000c: iget v3, v6.Landroid/support/v4/view/PagerTabStrip;->mTabPadding:I
    000e: binop/2addr(op=b1) v2, v3
    000f: iget v3, v6.Landroid/support/v4/view/PagerTabStrip;->mCurrText:Landroid/widget/TextView;
    0011: invoke-virtual {v3}, Landroid/widget/TextView;->getRight()I
    0014: move-result v3
    0015: iget v4, v6.Landroid/support/v4/view/PagerTabStrip;->mTabPadding:I
    0017: binop/2addr(op=b0) v3, v4
    0018: iget v4, v6.Landroid/support/v4/view/PagerTabStrip;->mIndicatorHeight:I
    001a: binop(op=91) v4, v1, v4
    001c: invoke-virtual {v0, v2, v4, v3, v1}, Landroid/graphics/Rect;->set(IIII)V
    001f: invoke-super {v6, v7, v8, v9}, Landroid/support/v4/view/PagerTitleStrip;->updateTextPositions(IFZ)V
    0022: const/high16 v2, 1056964608 (0x3f000000)
    0024: binop(op=a7) v2, v8, v2
    0026: invoke-static {v2}, Ljava/lang/Math;->abs(F)F
    0029: move-result v2
    002a: const/high16 v3, 1073741824 (0x40000000)
    002c: binop/2addr(op=c8) v2, v3
    002d: const/high16 v3, 1132396544 (0x437f0000)
    002f: binop/2addr(op=c8) v2, v3
    0030: unop(op=87) v2, v2
    0031: iput v2, v6.Landroid/support/v4/view/PagerTabStrip;->mTabAlpha:I
    0033: iget v2, v6.Landroid/support/v4/view/PagerTabStrip;->mCurrText:Landroid/widget/TextView;
    0035: invoke-virtual {v2}, Landroid/widget/TextView;->getLeft()I
    0038: move-result v2
    0039: iget v3, v6.Landroid/support/v4/view/PagerTabStrip;->mTabPadding:I
    003b: binop/2addr(op=b1) v2, v3
    003c: iget v3, v6.Landroid/support/v4/view/PagerTabStrip;->mCurrText:Landroid/widget/TextView;
    003e: invoke-virtual {v3}, Landroid/widget/TextView;->getRight()I
    0041: move-result v3
    0042: iget v5, v6.Landroid/support/v4/view/PagerTabStrip;->mTabPadding:I
    0044: binop/2addr(op=b0) v3, v5
    0045: invoke-virtual {v0, v2, v4, v3, v1}, Landroid/graphics/Rect;->union(IIII)V
    0048: invoke-virtual {v6, v0}, Landroid/support/v4/view/PagerTabStrip;->invalidate(Landroid/graphics/Rect;)V
    004b: return-void