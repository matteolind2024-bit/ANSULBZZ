=== CLASS Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl; (Source: AccessibilityNodeProviderCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] newAccessibilityNodeProviderBridge(Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;) -> Ljava/lang/Object;