=== CLASS Landroid/support/v4/view/ViewPager$2; (Source: ViewPager.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/view/animation/Interpolator;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getInterpolation(F) -> F
    // registers=5, ins=2, outs=0, insns_size=11
    0000: const/high16 v2, 1065353216 (0x3f800000)
    0002: binop(op=a7) v0, v4, v2
    0004: binop(op=a8) v1, v0, v0
    0006: binop/2addr(op=c8) v1, v0
    0007: binop/2addr(op=c8) v1, v0
    0008: binop/2addr(op=c8) v0, v1
    0009: binop/2addr(op=c6) v0, v2
    000a: return v0