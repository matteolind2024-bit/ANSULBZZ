=== CLASS Landroid/support/v4/os/ParcelableCompatCreatorHoneycombMR2Stub; (Source: ParcelableCompatHoneycombMR2.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] instantiate(Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;) -> Landroid/os/Parcelable$Creator;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Landroid/support/v4/os/ParcelableCompatCreatorHoneycombMR2;
    0002: invoke-direct {v0, v1}, Landroid/support/v4/os/ParcelableCompatCreatorHoneycombMR2;-><init>(Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;)V
    0005: return-object v0