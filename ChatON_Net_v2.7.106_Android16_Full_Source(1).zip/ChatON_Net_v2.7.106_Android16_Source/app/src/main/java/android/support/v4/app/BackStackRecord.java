=== CLASS Landroid/support/v4/app/BackStackRecord; (Source: BackStackRecord.java) ===
  Super: Landroid/support/v4/app/FragmentTransaction;
  Interfaces: Landroid/support/v4/app/FragmentManager$BackStackEntry;, Ljava/lang/Runnable;
  [Static Field] OP_ADD: I = 1
  [Static Field] OP_ATTACH: I = 7
  [Static Field] OP_DETACH: I = 6
  [Static Field] OP_HIDE: I = 4
  [Static Field] OP_NULL: I = 0
  [Static Field] OP_REMOVE: I = 3
  [Static Field] OP_REPLACE: I = 2
  [Static Field] OP_SHOW: I = 5
  [Static Field] TAG: Ljava/lang/String; = 'BackStackEntry'
  [Instance Field] mAddToBackStack: Z
  [Instance Field] mAllowAddToBackStack: Z
  [Instance Field] mBreadCrumbShortTitleRes: I
  [Instance Field] mBreadCrumbShortTitleText: Ljava/lang/CharSequence;
  [Instance Field] mBreadCrumbTitleRes: I
  [Instance Field] mBreadCrumbTitleText: Ljava/lang/CharSequence;
  [Instance Field] mCommitted: Z
  [Instance Field] mEnterAnim: I
  [Instance Field] mExitAnim: I
  [Instance Field] mHead: Landroid/support/v4/app/BackStackRecord$Op;
  [Instance Field] mIndex: I
  [Instance Field] mManager: Landroid/support/v4/app/FragmentManagerImpl;
  [Instance Field] mName: Ljava/lang/String;
  [Instance Field] mNumOp: I
  [Instance Field] mPopEnterAnim: I
  [Instance Field] mPopExitAnim: I
  [Instance Field] mTail: Landroid/support/v4/app/BackStackRecord$Op;
  [Instance Field] mTransition: I
  [Instance Field] mTransitionStyle: I

  [Direct Method] <init>(Landroid/support/v4/app/FragmentManagerImpl;) -> V
    // registers=3, ins=2, outs=1, insns_size=9
    0000: invoke-direct {v1}, Landroid/support/v4/app/FragmentTransaction;-><init>()V
    0003: const/4 v0, 1
    0004: iput v0, v1.Landroid/support/v4/app/BackStackRecord;->mAllowAddToBackStack:Z
    0006: iput v2, v1.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0008: return-void

  [Direct Method] doAddOp(I, Landroid/support/v4/app/Fragment;, Ljava/lang/String;, I) -> V
    // registers=8, ins=5, outs=2, insns_size=141
    0000: iget v0, v3.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0002: iput v0, v5.Landroid/support/v4/app/Fragment;->mFragmentManager:Landroid/support/v4/app/FragmentManagerImpl;
    0004: if-eqz v6, 0043
    0006: iget v0, v5.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    0008: if-eqz v0, 0041
    000a: iget v0, v5.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    000c: invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    000f: move-result v0
    0010: if-nez v0, 0041
    0012: new-instance v0, Ljava/lang/IllegalStateException;
    0014: new-instance v1, Ljava/lang/StringBuilder;
    0016: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0019: const-string v2, "Can't change tag of fragment "
    001b: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001e: move-result-object v1
    001f: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0022: move-result-object v1
    0023: const-string v2, ': was '
    0025: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0028: move-result-object v1
    0029: iget v2, v5.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    002b: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002e: move-result-object v1
    002f: const-string v2, ' now '
    0031: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0034: move-result-object v1
    0035: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0038: move-result-object v1
    0039: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    003c: move-result-object v1
    003d: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0040: throw v0
    0041: iput v6, v5.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    0043: if-eqz v4, 0080
    0045: iget v0, v5.Landroid/support/v4/app/Fragment;->mFragmentId:I
    0047: if-eqz v0, 007c
    0049: iget v0, v5.Landroid/support/v4/app/Fragment;->mFragmentId:I
    004b: if-eq v0, v4, 007c
    004d: new-instance v0, Ljava/lang/IllegalStateException;
    004f: new-instance v1, Ljava/lang/StringBuilder;
    0051: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0054: const-string v2, "Can't change container ID of fragment "
    0056: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0059: move-result-object v1
    005a: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    005d: move-result-object v1
    005e: const-string v2, ': was '
    0060: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0063: move-result-object v1
    0064: iget v2, v5.Landroid/support/v4/app/Fragment;->mFragmentId:I
    0066: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0069: move-result-object v1
    006a: const-string v2, ' now '
    006c: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    006f: move-result-object v1
    0070: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0073: move-result-object v1
    0074: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0077: move-result-object v1
    0078: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    007b: throw v0
    007c: iput v4, v5.Landroid/support/v4/app/Fragment;->mFragmentId:I
    007e: iput v4, v5.Landroid/support/v4/app/Fragment;->mContainerId:I
    0080: new-instance v0, Landroid/support/v4/app/BackStackRecord$Op;
    0082: invoke-direct {v0}, Landroid/support/v4/app/BackStackRecord$Op;-><init>()V
    0085: iput v7, v0.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    0087: iput v5, v0.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    0089: invoke-virtual {v3, v0}, Landroid/support/v4/app/BackStackRecord;->addOp(Landroid/support/v4/app/BackStackRecord$Op;)V
    008c: return-void

  [Virtual Method] add(I, Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=5, ins=3, outs=5, insns_size=6
    0000: const/4 v0, 0
    0001: const/4 v1, 1
    0002: invoke-direct {v2, v3, v4, v0, v1}, Landroid/support/v4/app/BackStackRecord;->doAddOp(ILandroid/support/v4/app/Fragment;Ljava/lang/String;I)V
    0005: return-object v2

  [Virtual Method] add(I, Landroid/support/v4/app/Fragment;, Ljava/lang/String;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=5, ins=4, outs=5, insns_size=5
    0000: const/4 v0, 1
    0001: invoke-direct {v1, v2, v3, v4, v0}, Landroid/support/v4/app/BackStackRecord;->doAddOp(ILandroid/support/v4/app/Fragment;Ljava/lang/String;I)V
    0004: return-object v1

  [Virtual Method] add(Landroid/support/v4/app/Fragment;, Ljava/lang/String;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=5, ins=3, outs=5, insns_size=6
    0000: const/4 v0, 0
    0001: const/4 v1, 1
    0002: invoke-direct {v2, v0, v3, v4, v1}, Landroid/support/v4/app/BackStackRecord;->doAddOp(ILandroid/support/v4/app/Fragment;Ljava/lang/String;I)V
    0005: return-object v2

  [Virtual Method] addOp(Landroid/support/v4/app/BackStackRecord$Op;) -> V
    // registers=3, ins=2, outs=0, insns_size=42
    0000: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mHead:Landroid/support/v4/app/BackStackRecord$Op;
    0002: if-nez v0, 001f
    0004: iput v2, v1.Landroid/support/v4/app/BackStackRecord;->mTail:Landroid/support/v4/app/BackStackRecord$Op;
    0006: iput v2, v1.Landroid/support/v4/app/BackStackRecord;->mHead:Landroid/support/v4/app/BackStackRecord$Op;
    0008: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mEnterAnim:I
    000a: iput v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->enterAnim:I
    000c: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mExitAnim:I
    000e: iput v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->exitAnim:I
    0010: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mPopEnterAnim:I
    0012: iput v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->popEnterAnim:I
    0014: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mPopExitAnim:I
    0016: iput v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->popExitAnim:I
    0018: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mNumOp:I
    001a: binop/lit8(op=d8) v0, v0, 1 (0x1)
    001c: iput v0, v1.Landroid/support/v4/app/BackStackRecord;->mNumOp:I
    001e: return-void
    001f: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mTail:Landroid/support/v4/app/BackStackRecord$Op;
    0021: iput v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->prev:Landroid/support/v4/app/BackStackRecord$Op;
    0023: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mTail:Landroid/support/v4/app/BackStackRecord$Op;
    0025: iput v2, v0.Landroid/support/v4/app/BackStackRecord$Op;->next:Landroid/support/v4/app/BackStackRecord$Op;
    0027: iput v2, v1.Landroid/support/v4/app/BackStackRecord;->mTail:Landroid/support/v4/app/BackStackRecord$Op;
    0029: goto 0008

  [Virtual Method] addToBackStack(Ljava/lang/String;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=4, ins=2, outs=2, insns_size=18
    0000: iget v0, v2.Landroid/support/v4/app/BackStackRecord;->mAllowAddToBackStack:Z
    0002: if-nez v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'This FragmentTransaction is not allowed to be added to the back stack.'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: const/4 v0, 1
    000d: iput v0, v2.Landroid/support/v4/app/BackStackRecord;->mAddToBackStack:Z
    000f: iput v3, v2.Landroid/support/v4/app/BackStackRecord;->mName:Ljava/lang/String;
    0011: return-object v2

  [Virtual Method] attach(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=4, ins=2, outs=2, insns_size=14
    0000: new-instance v0, Landroid/support/v4/app/BackStackRecord$Op;
    0002: invoke-direct {v0}, Landroid/support/v4/app/BackStackRecord$Op;-><init>()V
    0005: const/4 v1, 7
    0006: iput v1, v0.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    0008: iput v3, v0.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    000a: invoke-virtual {v2, v0}, Landroid/support/v4/app/BackStackRecord;->addOp(Landroid/support/v4/app/BackStackRecord$Op;)V
    000d: return-object v2

  [Virtual Method] bumpBackStackNesting(I) -> V
    // registers=8, ins=2, outs=2, insns_size=180
    0000: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mAddToBackStack:Z
    0002: if-nez v0, 0005
    0004: return-void
    0005: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0007: if-eqz v0, 002b
    0009: const-string v0, 'BackStackEntry'
    000b: new-instance v1, Ljava/lang/StringBuilder;
    000d: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0010: const-string v2, 'Bump nesting in '
    0012: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0015: move-result-object v1
    0016: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0019: move-result-object v1
    001a: const-string v2, ' by '
    001c: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001f: move-result-object v1
    0020: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0023: move-result-object v1
    0024: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0027: move-result-object v1
    0028: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    002b: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mHead:Landroid/support/v4/app/BackStackRecord$Op;
    002d: move(op=07) v2, v0
    002e: if-eqz v2, 0004
    0030: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    0032: if-eqz v0, 0067
    0034: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    0036: iget v1, v0.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    0038: binop/2addr(op=b0) v1, v7
    0039: iput v1, v0.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    003b: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    003d: if-eqz v0, 0067
    003f: const-string v0, 'BackStackEntry'
    0041: new-instance v1, Ljava/lang/StringBuilder;
    0043: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0046: const-string v3, 'Bump nesting of '
    0048: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004b: move-result-object v1
    004c: iget v3, v2.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    004e: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0051: move-result-object v1
    0052: const-string v3, ' to '
    0054: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0057: move-result-object v1
    0058: iget v3, v2.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    005a: iget v3, v3.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    005c: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    005f: move-result-object v1
    0060: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0063: move-result-object v1
    0064: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0067: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    0069: if-eqz v0, 00af
    006b: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    006d: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0070: move-result v0
    0071: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0073: move(op=01) v1, v0
    0074: if-ltz v1, 00af
    0076: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    0078: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    007b: move-result-object v0
    007c: check-cast v0, Landroid/support/v4/app/Fragment;
    007e: iget v3, v0.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    0080: binop/2addr(op=b0) v3, v7
    0081: iput v3, v0.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    0083: sget v3, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0085: if-eqz v3, 00ab
    0087: const-string v3, 'BackStackEntry'
    0089: new-instance v4, Ljava/lang/StringBuilder;
    008b: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    008e: const-string v5, 'Bump nesting of '
    0090: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0093: move-result-object v4
    0094: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0097: move-result-object v4
    0098: const-string v5, ' to '
    009a: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    009d: move-result-object v4
    009e: iget v0, v0.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    00a0: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    00a3: move-result-object v0
    00a4: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00a7: move-result-object v0
    00a8: invoke-static {v3, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00ab: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    00ad: move(op=01) v1, v0
    00ae: goto 0074
    00af: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->next:Landroid/support/v4/app/BackStackRecord$Op;
    00b1: move(op=07) v2, v0
    00b2: goto/16 002e

  [Virtual Method] commit() -> I
    // registers=2, ins=1, outs=2, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v0}, Landroid/support/v4/app/BackStackRecord;->commitInternal(Z)I
    0004: move-result v0
    0005: return v0

  [Virtual Method] commitAllowingStateLoss() -> I
    // registers=2, ins=1, outs=2, insns_size=6
    0000: const/4 v0, 1
    0001: invoke-virtual {v1, v0}, Landroid/support/v4/app/BackStackRecord;->commitInternal(Z)I
    0004: move-result v0
    0005: return v0

  [Virtual Method] commitInternal(Z) -> I
    // registers=5, ins=2, outs=3, insns_size=67
    0000: iget v0, v3.Landroid/support/v4/app/BackStackRecord;->mCommitted:Z
    0002: if-eqz v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'commit already called'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    000e: if-eqz v0, 0028
    0010: const-string v0, 'BackStackEntry'
    0012: new-instance v1, Ljava/lang/StringBuilder;
    0014: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0017: const-string v2, 'Commit: '
    0019: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: move-result-object v1
    001d: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0020: move-result-object v1
    0021: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0024: move-result-object v1
    0025: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0028: const/4 v0, 1
    0029: iput v0, v3.Landroid/support/v4/app/BackStackRecord;->mCommitted:Z
    002b: iget v0, v3.Landroid/support/v4/app/BackStackRecord;->mAddToBackStack:Z
    002d: if-eqz v0, 003f
    002f: iget v0, v3.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0031: invoke-virtual {v0, v3}, Landroid/support/v4/app/FragmentManagerImpl;->allocBackStackIndex(Landroid/support/v4/app/BackStackRecord;)I
    0034: move-result v0
    0035: iput v0, v3.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    0037: iget v0, v3.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0039: invoke-virtual {v0, v3, v4}, Landroid/support/v4/app/FragmentManagerImpl;->enqueueAction(Ljava/lang/Runnable;Z)V
    003c: iget v0, v3.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    003e: return v0
    003f: const/4 v0, -1
    0040: iput v0, v3.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    0042: goto 0037

  [Virtual Method] detach(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=4, ins=2, outs=2, insns_size=14
    0000: new-instance v0, Landroid/support/v4/app/BackStackRecord$Op;
    0002: invoke-direct {v0}, Landroid/support/v4/app/BackStackRecord$Op;-><init>()V
    0005: const/4 v1, 6
    0006: iput v1, v0.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    0008: iput v3, v0.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    000a: invoke-virtual {v2, v0}, Landroid/support/v4/app/BackStackRecord;->addOp(Landroid/support/v4/app/BackStackRecord$Op;)V
    000d: return-object v2

  [Virtual Method] disallowAddToBackStack() -> Landroid/support/v4/app/FragmentTransaction;
    // registers=3, ins=1, outs=2, insns_size=16
    0000: iget v0, v2.Landroid/support/v4/app/BackStackRecord;->mAddToBackStack:Z
    0002: if-eqz v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'This transaction is already being added to the back stack'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: const/4 v0, 0
    000d: iput v0, v2.Landroid/support/v4/app/BackStackRecord;->mAllowAddToBackStack:Z
    000f: return-object v2

  [Virtual Method] dump(Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V
    // registers=11, ins=5, outs=2, insns_size=448
    0000: const/4 v1, 0
    0001: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0004: const-string v0, 'mName='
    0006: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0009: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mName:Ljava/lang/String;
    000b: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    000e: const-string v0, ' mIndex='
    0010: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0013: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    0015: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(I)V
    0018: const-string v0, ' mCommitted='
    001a: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    001d: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mCommitted:Z
    001f: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Z)V
    0022: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0024: if-eqz v0, 0045
    0026: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0029: const-string v0, 'mTransition=#'
    002b: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    002e: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0030: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0033: move-result-object v0
    0034: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0037: const-string v0, ' mTransitionStyle=#'
    0039: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    003c: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    003e: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0041: move-result-object v0
    0042: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0045: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mEnterAnim:I
    0047: if-nez v0, 004d
    0049: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mExitAnim:I
    004b: if-eqz v0, 006c
    004d: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0050: const-string v0, 'mEnterAnim=#'
    0052: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0055: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mEnterAnim:I
    0057: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    005a: move-result-object v0
    005b: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    005e: const-string v0, ' mExitAnim=#'
    0060: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0063: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mExitAnim:I
    0065: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0068: move-result-object v0
    0069: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    006c: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mPopEnterAnim:I
    006e: if-nez v0, 0074
    0070: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mPopExitAnim:I
    0072: if-eqz v0, 0093
    0074: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0077: const-string v0, 'mPopEnterAnim=#'
    0079: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    007c: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mPopEnterAnim:I
    007e: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0081: move-result-object v0
    0082: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0085: const-string v0, ' mPopExitAnim=#'
    0087: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    008a: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mPopExitAnim:I
    008c: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    008f: move-result-object v0
    0090: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0093: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleRes:I
    0095: if-nez v0, 009b
    0097: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleText:Ljava/lang/CharSequence;
    0099: if-eqz v0, 00b6
    009b: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    009e: const-string v0, 'mBreadCrumbTitleRes=#'
    00a0: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00a3: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleRes:I
    00a5: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    00a8: move-result-object v0
    00a9: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00ac: const-string v0, ' mBreadCrumbTitleText='
    00ae: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00b1: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleText:Ljava/lang/CharSequence;
    00b3: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    00b6: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleRes:I
    00b8: if-nez v0, 00be
    00ba: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;
    00bc: if-eqz v0, 00d9
    00be: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00c1: const-string v0, 'mBreadCrumbShortTitleRes=#'
    00c3: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00c6: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleRes:I
    00c8: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    00cb: move-result-object v0
    00cc: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00cf: const-string v0, ' mBreadCrumbShortTitleText='
    00d1: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00d4: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;
    00d6: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    00d9: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mHead:Landroid/support/v4/app/BackStackRecord$Op;
    00db: if-eqz v0, 01bf
    00dd: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00e0: const-string v0, 'Operations:'
    00e2: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    00e5: new-instance v0, Ljava/lang/StringBuilder;
    00e7: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    00ea: invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00ed: move-result-object v0
    00ee: const-string v2, '    '
    00f0: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00f3: move-result-object v0
    00f4: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00f7: move-result-object v3
    00f8: iget v0, v6.Landroid/support/v4/app/BackStackRecord;->mHead:Landroid/support/v4/app/BackStackRecord$Op;
    00fa: move(op=07) v2, v0
    00fb: if-eqz v2, 01bf
    00fd: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0100: const-string v0, '  Op #'
    0102: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0105: invoke-virtual {v9, v1}, Ljava/io/PrintWriter;->print(I)V
    0108: const-string v0, ':'
    010a: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    010d: invoke-virtual {v9, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0110: const-string v0, 'cmd='
    0112: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0115: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    0117: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(I)V
    011a: const-string v0, ' fragment='
    011c: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    011f: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    0121: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0124: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->enterAnim:I
    0126: if-nez v0, 012c
    0128: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->exitAnim:I
    012a: if-eqz v0, 014b
    012c: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    012f: const-string v0, 'enterAnim=#'
    0131: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0134: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->enterAnim:I
    0136: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0139: move-result-object v0
    013a: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    013d: const-string v0, ' exitAnim=#'
    013f: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0142: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->exitAnim:I
    0144: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0147: move-result-object v0
    0148: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    014b: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->popEnterAnim:I
    014d: if-nez v0, 0153
    014f: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->popExitAnim:I
    0151: if-eqz v0, 0172
    0153: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0156: const-string v0, 'popEnterAnim=#'
    0158: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    015b: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->popEnterAnim:I
    015d: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0160: move-result-object v0
    0161: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0164: const-string v0, ' popExitAnim=#'
    0166: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0169: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->popExitAnim:I
    016b: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    016e: move-result-object v0
    016f: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0172: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    0174: if-eqz v0, 01ba
    0176: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    0178: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    017b: move-result v0
    017c: if-lez v0, 01ba
    017e: move(op=01) v0, v1
    017f: iget v4, v2.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    0181: invoke-virtual {v4}, Ljava/util/ArrayList;->size()I
    0184: move-result v4
    0185: if-ge v0, v4, 01ba
    0187: invoke-virtual {v9, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    018a: iget v4, v2.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    018c: invoke-virtual {v4}, Ljava/util/ArrayList;->size()I
    018f: move-result v4
    0190: const/4 v5, 1
    0191: if-ne v4, v5, 01a4
    0193: const-string v4, 'Removed: '
    0195: invoke-virtual {v9, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0198: iget v4, v2.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    019a: invoke-virtual {v4, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    019d: move-result-object v4
    019e: invoke-virtual {v9, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    01a1: binop/lit8(op=d8) v0, v0, 1 (0x1)
    01a3: goto 017f
    01a4: const-string v4, 'Removed:'
    01a6: invoke-virtual {v9, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    01a9: invoke-virtual {v9, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01ac: const-string v4, '  #'
    01ae: invoke-virtual {v9, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01b1: invoke-virtual {v9, v1}, Ljava/io/PrintWriter;->print(I)V
    01b4: const-string v4, ': '
    01b6: invoke-virtual {v9, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01b9: goto 0198
    01ba: iget v0, v2.Landroid/support/v4/app/BackStackRecord$Op;->next:Landroid/support/v4/app/BackStackRecord$Op;
    01bc: move(op=07) v2, v0
    01bd: goto/16 00fb
    01bf: return-void

  [Virtual Method] getBreadCrumbShortTitle() -> Ljava/lang/CharSequence;
    // registers=3, ins=1, outs=2, insns_size=18
    0000: iget v0, v2.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleRes:I
    0002: if-eqz v0, 000f
    0004: iget v0, v2.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0006: iget v0, v0.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0008: iget v1, v2.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleRes:I
    000a: invoke-virtual {v0, v1}, Landroid/support/v4/app/FragmentActivity;->getText(I)Ljava/lang/CharSequence;
    000d: move-result-object v0
    000e: return-object v0
    000f: iget v0, v2.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;
    0011: goto 000e

  [Virtual Method] getBreadCrumbShortTitleRes() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleRes:I
    0002: return v0

  [Virtual Method] getBreadCrumbTitle() -> Ljava/lang/CharSequence;
    // registers=3, ins=1, outs=2, insns_size=18
    0000: iget v0, v2.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleRes:I
    0002: if-eqz v0, 000f
    0004: iget v0, v2.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0006: iget v0, v0.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0008: iget v1, v2.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleRes:I
    000a: invoke-virtual {v0, v1}, Landroid/support/v4/app/FragmentActivity;->getText(I)Ljava/lang/CharSequence;
    000d: move-result-object v0
    000e: return-object v0
    000f: iget v0, v2.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleText:Ljava/lang/CharSequence;
    0011: goto 000e

  [Virtual Method] getBreadCrumbTitleRes() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleRes:I
    0002: return v0

  [Virtual Method] getId() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    0002: return v0

  [Virtual Method] getName() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mName:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] getTransition() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0002: return v0

  [Virtual Method] getTransitionStyle() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    0002: return v0

  [Virtual Method] hide(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=4, ins=2, outs=2, insns_size=14
    0000: new-instance v0, Landroid/support/v4/app/BackStackRecord$Op;
    0002: invoke-direct {v0}, Landroid/support/v4/app/BackStackRecord$Op;-><init>()V
    0005: const/4 v1, 4
    0006: iput v1, v0.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    0008: iput v3, v0.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    000a: invoke-virtual {v2, v0}, Landroid/support/v4/app/BackStackRecord;->addOp(Landroid/support/v4/app/BackStackRecord$Op;)V
    000d: return-object v2

  [Virtual Method] isAddToBackStackAllowed() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mAllowAddToBackStack:Z
    0002: return v0

  [Virtual Method] isEmpty() -> Z
    // registers=2, ins=1, outs=0, insns_size=8
    0000: iget v0, v1.Landroid/support/v4/app/BackStackRecord;->mNumOp:I
    0002: if-nez v0, 0006
    0004: const/4 v0, 1
    0005: return v0
    0006: const/4 v0, 0
    0007: goto 0005

  [Virtual Method] popFromBackStack(Z) -> V
    // registers=9, ins=2, outs=5, insns_size=294
    0000: const/4 v6, -1
    0001: const/4 v2, 0
    0002: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0004: if-eqz v0, 001e
    0006: const-string v0, 'BackStackEntry'
    0008: new-instance v1, Ljava/lang/StringBuilder;
    000a: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000d: const-string v3, 'popFromBackStack: '
    000f: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0016: move-result-object v1
    0017: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001a: move-result-object v1
    001b: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001e: invoke-virtual {v7, v6}, Landroid/support/v4/app/BackStackRecord;->bumpBackStackNesting(I)V
    0021: iget v0, v7.Landroid/support/v4/app/BackStackRecord;->mTail:Landroid/support/v4/app/BackStackRecord$Op;
    0023: move(op=07) v3, v0
    0024: if-eqz v3, 00f2
    0026: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    0028: packed-switch v0, +236 (-> 0114)
    002b: new-instance v0, Ljava/lang/IllegalArgumentException;
    002d: new-instance v1, Ljava/lang/StringBuilder;
    002f: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0032: const-string v2, 'Unknown cmd: '
    0034: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0037: move-result-object v1
    0038: iget v2, v3.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    003a: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    003d: move-result-object v1
    003e: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0041: move-result-object v1
    0042: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0045: throw v0
    0046: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    0048: iget v1, v3.Landroid/support/v4/app/BackStackRecord$Op;->popExitAnim:I
    004a: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    004c: iget v1, v7.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    004e: iget v4, v7.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0050: invoke-static {v4}, Landroid/support/v4/app/FragmentManagerImpl;->reverseTransit(I)I
    0053: move-result v4
    0054: iget v5, v7.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    0056: invoke-virtual {v1, v0, v4, v5}, Landroid/support/v4/app/FragmentManagerImpl;->removeFragment(Landroid/support/v4/app/Fragment;II)V
    0059: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->prev:Landroid/support/v4/app/BackStackRecord$Op;
    005b: move(op=07) v3, v0
    005c: goto 0024
    005d: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    005f: if-eqz v0, 0072
    0061: iget v1, v3.Landroid/support/v4/app/BackStackRecord$Op;->popExitAnim:I
    0063: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    0065: iget v1, v7.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0067: iget v4, v7.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0069: invoke-static {v4}, Landroid/support/v4/app/FragmentManagerImpl;->reverseTransit(I)I
    006c: move-result v4
    006d: iget v5, v7.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    006f: invoke-virtual {v1, v0, v4, v5}, Landroid/support/v4/app/FragmentManagerImpl;->removeFragment(Landroid/support/v4/app/Fragment;II)V
    0072: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    0074: if-eqz v0, 0059
    0076: move(op=01) v1, v2
    0077: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    0079: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    007c: move-result v0
    007d: if-ge v1, v0, 0059
    007f: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    0081: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0084: move-result-object v0
    0085: check-cast v0, Landroid/support/v4/app/Fragment;
    0087: iget v4, v3.Landroid/support/v4/app/BackStackRecord$Op;->popEnterAnim:I
    0089: iput v4, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    008b: iget v4, v7.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    008d: invoke-virtual {v4, v0, v2}, Landroid/support/v4/app/FragmentManagerImpl;->addFragment(Landroid/support/v4/app/Fragment;Z)V
    0090: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0092: move(op=01) v1, v0
    0093: goto 0077
    0094: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    0096: iget v1, v3.Landroid/support/v4/app/BackStackRecord$Op;->popEnterAnim:I
    0098: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    009a: iget v1, v7.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    009c: invoke-virtual {v1, v0, v2}, Landroid/support/v4/app/FragmentManagerImpl;->addFragment(Landroid/support/v4/app/Fragment;Z)V
    009f: goto 0059
    00a0: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    00a2: iget v1, v3.Landroid/support/v4/app/BackStackRecord$Op;->popEnterAnim:I
    00a4: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    00a6: iget v1, v7.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    00a8: iget v4, v7.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    00aa: invoke-static {v4}, Landroid/support/v4/app/FragmentManagerImpl;->reverseTransit(I)I
    00ad: move-result v4
    00ae: iget v5, v7.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    00b0: invoke-virtual {v1, v0, v4, v5}, Landroid/support/v4/app/FragmentManagerImpl;->showFragment(Landroid/support/v4/app/Fragment;II)V
    00b3: goto 0059
    00b4: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    00b6: iget v1, v3.Landroid/support/v4/app/BackStackRecord$Op;->popExitAnim:I
    00b8: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    00ba: iget v1, v7.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    00bc: iget v4, v7.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    00be: invoke-static {v4}, Landroid/support/v4/app/FragmentManagerImpl;->reverseTransit(I)I
    00c1: move-result v4
    00c2: iget v5, v7.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    00c4: invoke-virtual {v1, v0, v4, v5}, Landroid/support/v4/app/FragmentManagerImpl;->hideFragment(Landroid/support/v4/app/Fragment;II)V
    00c7: goto 0059
    00c8: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    00ca: iget v1, v3.Landroid/support/v4/app/BackStackRecord$Op;->popEnterAnim:I
    00cc: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    00ce: iget v1, v7.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    00d0: iget v4, v7.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    00d2: invoke-static {v4}, Landroid/support/v4/app/FragmentManagerImpl;->reverseTransit(I)I
    00d5: move-result v4
    00d6: iget v5, v7.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    00d8: invoke-virtual {v1, v0, v4, v5}, Landroid/support/v4/app/FragmentManagerImpl;->attachFragment(Landroid/support/v4/app/Fragment;II)V
    00db: goto/16 0059
    00dd: iget v0, v3.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    00df: iget v1, v3.Landroid/support/v4/app/BackStackRecord$Op;->popEnterAnim:I
    00e1: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    00e3: iget v1, v7.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    00e5: iget v4, v7.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    00e7: invoke-static {v4}, Landroid/support/v4/app/FragmentManagerImpl;->reverseTransit(I)I
    00ea: move-result v4
    00eb: iget v5, v7.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    00ed: invoke-virtual {v1, v0, v4, v5}, Landroid/support/v4/app/FragmentManagerImpl;->detachFragment(Landroid/support/v4/app/Fragment;II)V
    00f0: goto/16 0059
    00f2: if-eqz v8, 0106
    00f4: iget v0, v7.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    00f6: iget v1, v7.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    00f8: iget v1, v1.Landroid/support/v4/app/FragmentManagerImpl;->mCurState:I
    00fa: iget v2, v7.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    00fc: invoke-static {v2}, Landroid/support/v4/app/FragmentManagerImpl;->reverseTransit(I)I
    00ff: move-result v2
    0100: iget v3, v7.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    0102: const/4 v4, 1
    0103: invoke-virtual {v0, v1, v2, v3, v4}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(IIIZ)V
    0106: iget v0, v7.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    0108: if-ltz v0, 0113
    010a: iget v0, v7.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    010c: iget v1, v7.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    010e: invoke-virtual {v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->freeBackStackIndex(I)V
    0111: iput v6, v7.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    0113: return-void
    0114: packed-switch-payload first=1 targets=[30, 53, 108, 120, 140, 160, 181]

  [Virtual Method] remove(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=4, ins=2, outs=2, insns_size=14
    0000: new-instance v0, Landroid/support/v4/app/BackStackRecord$Op;
    0002: invoke-direct {v0}, Landroid/support/v4/app/BackStackRecord$Op;-><init>()V
    0005: const/4 v1, 3
    0006: iput v1, v0.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    0008: iput v3, v0.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    000a: invoke-virtual {v2, v0}, Landroid/support/v4/app/BackStackRecord;->addOp(Landroid/support/v4/app/BackStackRecord$Op;)V
    000d: return-object v2

  [Virtual Method] replace(I, Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=4, ins=3, outs=4, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v3, v0}, Landroid/support/v4/app/BackStackRecord;->replace(ILandroid/support/v4/app/Fragment;Ljava/lang/String;)Landroid/support/v4/app/FragmentTransaction;
    0004: move-result-object v0
    0005: return-object v0

  [Virtual Method] replace(I, Landroid/support/v4/app/Fragment;, Ljava/lang/String;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=6, ins=4, outs=5, insns_size=15
    0000: if-nez v3, 000a
    0002: new-instance v0, Ljava/lang/IllegalArgumentException;
    0004: const-string v1, 'Must use non-zero containerViewId'
    0006: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0009: throw v0
    000a: const/4 v0, 2
    000b: invoke-direct {v2, v3, v4, v5, v0}, Landroid/support/v4/app/BackStackRecord;->doAddOp(ILandroid/support/v4/app/Fragment;Ljava/lang/String;I)V
    000e: return-object v2

  [Virtual Method] run() -> V
    // registers=10, ins=1, outs=5, insns_size=406
    0000: const/4 v8, 1
    0001: const/4 v2, 0
    0002: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0004: if-eqz v0, 001e
    0006: const-string v0, 'BackStackEntry'
    0008: new-instance v1, Ljava/lang/StringBuilder;
    000a: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000d: const-string v3, 'Run: '
    000f: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0016: move-result-object v1
    0017: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001a: move-result-object v1
    001b: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001e: iget v0, v9.Landroid/support/v4/app/BackStackRecord;->mAddToBackStack:Z
    0020: if-eqz v0, 002e
    0022: iget v0, v9.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    0024: if-gez v0, 002e
    0026: new-instance v0, Ljava/lang/IllegalStateException;
    0028: const-string v1, 'addToBackStack() called after commit()'
    002a: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    002d: throw v0
    002e: invoke-virtual {v9, v8}, Landroid/support/v4/app/BackStackRecord;->bumpBackStackNesting(I)V
    0031: iget v0, v9.Landroid/support/v4/app/BackStackRecord;->mHead:Landroid/support/v4/app/BackStackRecord$Op;
    0033: move(op=07) v4, v0
    0034: if-eqz v4, 016d
    0036: iget v0, v4.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    0038: packed-switch v0, +332 (-> 0184)
    003b: new-instance v0, Ljava/lang/IllegalArgumentException;
    003d: new-instance v1, Ljava/lang/StringBuilder;
    003f: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0042: const-string v2, 'Unknown cmd: '
    0044: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0047: move-result-object v1
    0048: iget v2, v4.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    004a: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    004d: move-result-object v1
    004e: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0051: move-result-object v1
    0052: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0055: throw v0
    0056: iget v0, v4.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    0058: iget v1, v4.Landroid/support/v4/app/BackStackRecord$Op;->enterAnim:I
    005a: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    005c: iget v1, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    005e: invoke-virtual {v1, v0, v2}, Landroid/support/v4/app/FragmentManagerImpl;->addFragment(Landroid/support/v4/app/Fragment;Z)V
    0061: iget v0, v4.Landroid/support/v4/app/BackStackRecord$Op;->next:Landroid/support/v4/app/BackStackRecord$Op;
    0063: move(op=07) v4, v0
    0064: goto 0034
    0065: iget v0, v4.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    0067: iget v1, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0069: iget v1, v1.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    006b: if-eqz v1, 010a
    006d: move(op=01) v1, v2
    006e: move(op=07) v3, v0
    006f: iget v0, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0071: iget v0, v0.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0073: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0076: move-result v0
    0077: if-ge v1, v0, 010b
    0079: iget v0, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    007b: iget v0, v0.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    007d: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0080: move-result-object v0
    0081: check-cast v0, Landroid/support/v4/app/Fragment;
    0083: sget v5, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0085: if-eqz v5, 00a9
    0087: const-string v5, 'BackStackEntry'
    0089: new-instance v6, Ljava/lang/StringBuilder;
    008b: invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V
    008e: const-string v7, 'OP_REPLACE: adding='
    0090: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0093: move-result-object v6
    0094: invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0097: move-result-object v6
    0098: const-string v7, ' old='
    009a: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    009d: move-result-object v6
    009e: invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00a1: move-result-object v6
    00a2: invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00a5: move-result-object v6
    00a6: invoke-static {v5, v6}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00a9: if-eqz v3, 00b1
    00ab: iget v5, v0.Landroid/support/v4/app/Fragment;->mContainerId:I
    00ad: iget v6, v3.Landroid/support/v4/app/Fragment;->mContainerId:I
    00af: if-ne v5, v6, 00b6
    00b1: if-ne v0, v3, 00ba
    00b3: const/4 v3, 0
    00b4: iput v3, v4.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    00b6: binop/lit8(op=d8) v0, v1, 1 (0x1)
    00b8: move(op=01) v1, v0
    00b9: goto 006f
    00ba: iget v5, v4.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    00bc: if-nez v5, 00c5
    00be: new-instance v5, Ljava/util/ArrayList;
    00c0: invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V
    00c3: iput v5, v4.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    00c5: iget v5, v4.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    00c7: invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    00ca: iget v5, v4.Landroid/support/v4/app/BackStackRecord$Op;->exitAnim:I
    00cc: iput v5, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    00ce: iget v5, v9.Landroid/support/v4/app/BackStackRecord;->mAddToBackStack:Z
    00d0: if-eqz v5, 0100
    00d2: iget v5, v0.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    00d4: binop/lit8(op=d8) v5, v5, 1 (0x1)
    00d6: iput v5, v0.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    00d8: sget v5, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    00da: if-eqz v5, 0100
    00dc: const-string v5, 'BackStackEntry'
    00de: new-instance v6, Ljava/lang/StringBuilder;
    00e0: invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V
    00e3: const-string v7, 'Bump nesting of '
    00e5: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00e8: move-result-object v6
    00e9: invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00ec: move-result-object v6
    00ed: const-string v7, ' to '
    00ef: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00f2: move-result-object v6
    00f3: iget v7, v0.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    00f5: invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    00f8: move-result-object v6
    00f9: invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00fc: move-result-object v6
    00fd: invoke-static {v5, v6}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0100: iget v5, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0102: iget v6, v9.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0104: iget v7, v9.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    0106: invoke-virtual {v5, v0, v6, v7}, Landroid/support/v4/app/FragmentManagerImpl;->removeFragment(Landroid/support/v4/app/Fragment;II)V
    0109: goto 00b6
    010a: move(op=07) v3, v0
    010b: if-eqz v3, 0061
    010d: iget v0, v4.Landroid/support/v4/app/BackStackRecord$Op;->enterAnim:I
    010f: iput v0, v3.Landroid/support/v4/app/Fragment;->mNextAnim:I
    0111: iget v0, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0113: invoke-virtual {v0, v3, v2}, Landroid/support/v4/app/FragmentManagerImpl;->addFragment(Landroid/support/v4/app/Fragment;Z)V
    0116: goto/16 0061
    0118: iget v0, v4.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    011a: iget v1, v4.Landroid/support/v4/app/BackStackRecord$Op;->exitAnim:I
    011c: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    011e: iget v1, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0120: iget v3, v9.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0122: iget v5, v9.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    0124: invoke-virtual {v1, v0, v3, v5}, Landroid/support/v4/app/FragmentManagerImpl;->removeFragment(Landroid/support/v4/app/Fragment;II)V
    0127: goto/16 0061
    0129: iget v0, v4.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    012b: iget v1, v4.Landroid/support/v4/app/BackStackRecord$Op;->exitAnim:I
    012d: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    012f: iget v1, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0131: iget v3, v9.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0133: iget v5, v9.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    0135: invoke-virtual {v1, v0, v3, v5}, Landroid/support/v4/app/FragmentManagerImpl;->hideFragment(Landroid/support/v4/app/Fragment;II)V
    0138: goto/16 0061
    013a: iget v0, v4.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    013c: iget v1, v4.Landroid/support/v4/app/BackStackRecord$Op;->enterAnim:I
    013e: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    0140: iget v1, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0142: iget v3, v9.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0144: iget v5, v9.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    0146: invoke-virtual {v1, v0, v3, v5}, Landroid/support/v4/app/FragmentManagerImpl;->showFragment(Landroid/support/v4/app/Fragment;II)V
    0149: goto/16 0061
    014b: iget v0, v4.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    014d: iget v1, v4.Landroid/support/v4/app/BackStackRecord$Op;->exitAnim:I
    014f: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    0151: iget v1, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0153: iget v3, v9.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0155: iget v5, v9.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    0157: invoke-virtual {v1, v0, v3, v5}, Landroid/support/v4/app/FragmentManagerImpl;->detachFragment(Landroid/support/v4/app/Fragment;II)V
    015a: goto/16 0061
    015c: iget v0, v4.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    015e: iget v1, v4.Landroid/support/v4/app/BackStackRecord$Op;->enterAnim:I
    0160: iput v1, v0.Landroid/support/v4/app/Fragment;->mNextAnim:I
    0162: iget v1, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0164: iget v3, v9.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0166: iget v5, v9.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    0168: invoke-virtual {v1, v0, v3, v5}, Landroid/support/v4/app/FragmentManagerImpl;->attachFragment(Landroid/support/v4/app/Fragment;II)V
    016b: goto/16 0061
    016d: iget v0, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    016f: iget v1, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0171: iget v1, v1.Landroid/support/v4/app/FragmentManagerImpl;->mCurState:I
    0173: iget v2, v9.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0175: iget v3, v9.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    0177: invoke-virtual {v0, v1, v2, v3, v8}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(IIIZ)V
    017a: iget v0, v9.Landroid/support/v4/app/BackStackRecord;->mAddToBackStack:Z
    017c: if-eqz v0, 0183
    017e: iget v0, v9.Landroid/support/v4/app/BackStackRecord;->mManager:Landroid/support/v4/app/FragmentManagerImpl;
    0180: invoke-virtual {v0, v9}, Landroid/support/v4/app/FragmentManagerImpl;->addBackStackState(Landroid/support/v4/app/BackStackRecord;)V
    0183: return-void
    0184: packed-switch-payload first=1 targets=[30, 45, 224, 241, 258, 275, 292]

  [Virtual Method] setBreadCrumbShortTitle(I) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=3, ins=2, outs=0, insns_size=6
    0000: iput v2, v1.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleRes:I
    0002: const/4 v0, 0
    0003: iput v0, v1.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;
    0005: return-object v1

  [Virtual Method] setBreadCrumbShortTitle(Ljava/lang/CharSequence;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=3, ins=2, outs=0, insns_size=6
    0000: const/4 v0, 0
    0001: iput v0, v1.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleRes:I
    0003: iput v2, v1.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;
    0005: return-object v1

  [Virtual Method] setBreadCrumbTitle(I) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=3, ins=2, outs=0, insns_size=6
    0000: iput v2, v1.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleRes:I
    0002: const/4 v0, 0
    0003: iput v0, v1.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleText:Ljava/lang/CharSequence;
    0005: return-object v1

  [Virtual Method] setBreadCrumbTitle(Ljava/lang/CharSequence;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=3, ins=2, outs=0, insns_size=6
    0000: const/4 v0, 0
    0001: iput v0, v1.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleRes:I
    0003: iput v2, v1.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleText:Ljava/lang/CharSequence;
    0005: return-object v1

  [Virtual Method] setCustomAnimations(I, I) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=4, ins=3, outs=5, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v3, v0, v0}, Landroid/support/v4/app/BackStackRecord;->setCustomAnimations(IIII)Landroid/support/v4/app/FragmentTransaction;
    0004: move-result-object v0
    0005: return-object v0

  [Virtual Method] setCustomAnimations(I, I, I, I) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=5, ins=5, outs=0, insns_size=9
    0000: iput v1, v0.Landroid/support/v4/app/BackStackRecord;->mEnterAnim:I
    0002: iput v2, v0.Landroid/support/v4/app/BackStackRecord;->mExitAnim:I
    0004: iput v3, v0.Landroid/support/v4/app/BackStackRecord;->mPopEnterAnim:I
    0006: iput v4, v0.Landroid/support/v4/app/BackStackRecord;->mPopExitAnim:I
    0008: return-object v0

  [Virtual Method] setTransition(I) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    0002: return-object v0

  [Virtual Method] setTransitionStyle(I) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    0002: return-object v0

  [Virtual Method] show(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;
    // registers=4, ins=2, outs=2, insns_size=14
    0000: new-instance v0, Landroid/support/v4/app/BackStackRecord$Op;
    0002: invoke-direct {v0}, Landroid/support/v4/app/BackStackRecord$Op;-><init>()V
    0005: const/4 v1, 5
    0006: iput v1, v0.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    0008: iput v3, v0.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    000a: invoke-virtual {v2, v0}, Landroid/support/v4/app/BackStackRecord;->addOp(Landroid/support/v4/app/BackStackRecord$Op;)V
    000d: return-object v2