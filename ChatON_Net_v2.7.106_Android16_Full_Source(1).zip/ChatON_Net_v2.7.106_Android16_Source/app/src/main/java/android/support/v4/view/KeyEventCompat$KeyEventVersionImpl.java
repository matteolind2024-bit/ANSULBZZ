=== CLASS Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl; (Source: KeyEventCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] metaStateHasModifiers(I, I) -> Z

  [Virtual Method] metaStateHasNoModifiers(I) -> Z

  [Virtual Method] normalizeMetaState(I) -> I