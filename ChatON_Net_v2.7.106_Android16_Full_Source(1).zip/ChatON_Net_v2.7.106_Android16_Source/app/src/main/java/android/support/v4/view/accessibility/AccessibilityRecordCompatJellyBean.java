=== CLASS Landroid/support/v4/view/accessibility/AccessibilityRecordCompatJellyBean; (Source: AccessibilityRecordCompatJellyBean.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] setSource(Ljava/lang/Object;, Landroid/view/View;, I) -> V
    // registers=3, ins=3, outs=3, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1, v2}, Landroid/view/accessibility/AccessibilityRecord;->setSource(Landroid/view/View;I)V
    0005: return-void