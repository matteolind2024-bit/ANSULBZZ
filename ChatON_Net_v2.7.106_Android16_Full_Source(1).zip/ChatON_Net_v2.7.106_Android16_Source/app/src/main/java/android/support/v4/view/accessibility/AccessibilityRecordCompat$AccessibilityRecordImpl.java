=== CLASS Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordImpl; (Source: AccessibilityRecordCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] getAddedCount(Ljava/lang/Object;) -> I

  [Virtual Method] getBeforeText(Ljava/lang/Object;) -> Ljava/lang/CharSequence;

  [Virtual Method] getClassName(Ljava/lang/Object;) -> Ljava/lang/CharSequence;

  [Virtual Method] getContentDescription(Ljava/lang/Object;) -> Ljava/lang/CharSequence;

  [Virtual Method] getCurrentItemIndex(Ljava/lang/Object;) -> I

  [Virtual Method] getFromIndex(Ljava/lang/Object;) -> I

  [Virtual Method] getItemCount(Ljava/lang/Object;) -> I

  [Virtual Method] getMaxScrollX(Ljava/lang/Object;) -> I

  [Virtual Method] getMaxScrollY(Ljava/lang/Object;) -> I

  [Virtual Method] getParcelableData(Ljava/lang/Object;) -> Landroid/os/Parcelable;

  [Virtual Method] getRemovedCount(Ljava/lang/Object;) -> I

  [Virtual Method] getScrollX(Ljava/lang/Object;) -> I

  [Virtual Method] getScrollY(Ljava/lang/Object;) -> I

  [Virtual Method] getSource(Ljava/lang/Object;) -> Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;

  [Virtual Method] getText(Ljava/lang/Object;) -> Ljava/util/List;

  [Virtual Method] getToIndex(Ljava/lang/Object;) -> I

  [Virtual Method] getWindowId(Ljava/lang/Object;) -> I

  [Virtual Method] isChecked(Ljava/lang/Object;) -> Z

  [Virtual Method] isEnabled(Ljava/lang/Object;) -> Z

  [Virtual Method] isFullScreen(Ljava/lang/Object;) -> Z

  [Virtual Method] isPassword(Ljava/lang/Object;) -> Z

  [Virtual Method] isScrollable(Ljava/lang/Object;) -> Z

  [Virtual Method] obtain() -> Ljava/lang/Object;

  [Virtual Method] obtain(Ljava/lang/Object;) -> Ljava/lang/Object;

  [Virtual Method] recycle(Ljava/lang/Object;) -> V

  [Virtual Method] setAddedCount(Ljava/lang/Object;, I) -> V

  [Virtual Method] setBeforeText(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V

  [Virtual Method] setChecked(Ljava/lang/Object;, Z) -> V

  [Virtual Method] setClassName(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V

  [Virtual Method] setContentDescription(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V

  [Virtual Method] setCurrentItemIndex(Ljava/lang/Object;, I) -> V

  [Virtual Method] setEnabled(Ljava/lang/Object;, Z) -> V

  [Virtual Method] setFromIndex(Ljava/lang/Object;, I) -> V

  [Virtual Method] setFullScreen(Ljava/lang/Object;, Z) -> V

  [Virtual Method] setItemCount(Ljava/lang/Object;, I) -> V

  [Virtual Method] setMaxScrollX(Ljava/lang/Object;, I) -> V

  [Virtual Method] setMaxScrollY(Ljava/lang/Object;, I) -> V

  [Virtual Method] setParcelableData(Ljava/lang/Object;, Landroid/os/Parcelable;) -> V

  [Virtual Method] setPassword(Ljava/lang/Object;, Z) -> V

  [Virtual Method] setRemovedCount(Ljava/lang/Object;, I) -> V

  [Virtual Method] setScrollX(Ljava/lang/Object;, I) -> V

  [Virtual Method] setScrollY(Ljava/lang/Object;, I) -> V

  [Virtual Method] setScrollable(Ljava/lang/Object;, Z) -> V

  [Virtual Method] setSource(Ljava/lang/Object;, Landroid/view/View;) -> V

  [Virtual Method] setSource(Ljava/lang/Object;, Landroid/view/View;, I) -> V

  [Virtual Method] setToIndex(Ljava/lang/Object;, I) -> V