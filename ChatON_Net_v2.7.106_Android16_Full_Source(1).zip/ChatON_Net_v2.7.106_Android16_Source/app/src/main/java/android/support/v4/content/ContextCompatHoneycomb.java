=== CLASS Landroid/support/v4/content/ContextCompatHoneycomb; (Source: ContextCompatHoneycomb.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] startActivities(Landroid/content/Context;, [Landroid/content/Intent;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/content/Context;->startActivities([Landroid/content/Intent;)V
    0003: return-void