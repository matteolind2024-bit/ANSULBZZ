=== CLASS Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl; (Source: MotionEventCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] findPointerIndex(Landroid/view/MotionEvent;, I) -> I

  [Virtual Method] getPointerId(Landroid/view/MotionEvent;, I) -> I

  [Virtual Method] getX(Landroid/view/MotionEvent;, I) -> F

  [Virtual Method] getY(Landroid/view/MotionEvent;, I) -> F