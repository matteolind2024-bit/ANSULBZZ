=== CLASS Landroid/support/v4/view/ViewGroupCompat; (Source: ViewGroupCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] IMPL: Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatImpl;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=22
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 14 (0xe)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatIcsImpl;
    0008: invoke-direct {v0}, Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatIcsImpl;-><init>()V
    000b: sput v0, Landroid/support/v4/view/ViewGroupCompat;->IMPL:Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatImpl;
    000d: return-void
    000e: new-instance v0, Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatStubImpl;
    0010: invoke-direct {v0}, Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatStubImpl;-><init>()V
    0013: sput v0, Landroid/support/v4/view/ViewGroupCompat;->IMPL:Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatImpl;
    0015: goto 000d

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> Z
    // registers=4, ins=3, outs=4, insns_size=7
    0000: sget v0, Landroid/support/v4/view/ViewGroupCompat;->IMPL:Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatImpl;
    0002: invoke-interface {v0, v1, v2, v3}, Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatImpl;->onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    0005: move-result v0
    0006: return v0