=== CLASS Landroid/support/v4/app/FragmentManagerImpl$4; (Source: FragmentManager.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/lang/Runnable;
  [Instance Field] this$0: Landroid/support/v4/app/FragmentManagerImpl;
  [Instance Field] val$flags: I
  [Instance Field] val$id: I

  [Direct Method] <init>(Landroid/support/v4/app/FragmentManagerImpl;, I, I) -> V
    // registers=4, ins=4, outs=1, insns_size=10
    0000: iput v1, v0.Landroid/support/v4/app/FragmentManagerImpl$4;->this$0:Landroid/support/v4/app/FragmentManagerImpl;
    0002: iput v2, v0.Landroid/support/v4/app/FragmentManagerImpl$4;->val$id:I
    0004: iput v3, v0.Landroid/support/v4/app/FragmentManagerImpl$4;->val$flags:I
    0006: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0009: return-void

  [Virtual Method] run() -> V
    // registers=6, ins=1, outs=5, insns_size=17
    0000: iget v0, v5.Landroid/support/v4/app/FragmentManagerImpl$4;->this$0:Landroid/support/v4/app/FragmentManagerImpl;
    0002: iget v1, v5.Landroid/support/v4/app/FragmentManagerImpl$4;->this$0:Landroid/support/v4/app/FragmentManagerImpl;
    0004: iget v1, v1.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0006: iget v1, v1.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    0008: const/4 v2, 0
    0009: iget v3, v5.Landroid/support/v4/app/FragmentManagerImpl$4;->val$id:I
    000b: iget v4, v5.Landroid/support/v4/app/FragmentManagerImpl$4;->val$flags:I
    000d: invoke-virtual {v0, v1, v2, v3, v4}, Landroid/support/v4/app/FragmentManagerImpl;->popBackStackState(Landroid/os/Handler;Ljava/lang/String;II)Z
    0010: return-void