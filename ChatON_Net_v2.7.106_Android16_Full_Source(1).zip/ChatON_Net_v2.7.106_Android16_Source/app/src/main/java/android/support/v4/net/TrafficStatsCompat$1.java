=== CLASS Landroid/support/v4/net/TrafficStatsCompat$1; (Source: TrafficStatsCompat.java) ===
  Super: Ljava/lang/Object;