=== CLASS Landroid/support/v4/widget/ResourceCursorAdapter; (Source: ResourceCursorAdapter.java) ===
  Super: Landroid/support/v4/widget/CursorAdapter;
  [Instance Field] mDropDownLayout: I
  [Instance Field] mInflater: Landroid/view/LayoutInflater;
  [Instance Field] mLayout: I

  [Direct Method] <init>(Landroid/content/Context;, I, Landroid/database/Cursor;) -> V
    // registers=5, ins=4, outs=3, insns_size=18
    0000: invoke-direct {v1, v2, v4}, Landroid/support/v4/widget/CursorAdapter;-><init>(Landroid/content/Context;Landroid/database/Cursor;)V
    0003: iput v3, v1.Landroid/support/v4/widget/ResourceCursorAdapter;->mDropDownLayout:I
    0005: iput v3, v1.Landroid/support/v4/widget/ResourceCursorAdapter;->mLayout:I
    0007: const-string v0, 'layout_inflater'
    0009: invoke-virtual {v2, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    000c: move-result-object v0
    000d: check-cast v0, Landroid/view/LayoutInflater;
    000f: iput v0, v1.Landroid/support/v4/widget/ResourceCursorAdapter;->mInflater:Landroid/view/LayoutInflater;
    0011: return-void

  [Direct Method] <init>(Landroid/content/Context;, I, Landroid/database/Cursor;, I) -> V
    // registers=6, ins=5, outs=4, insns_size=18
    0000: invoke-direct {v1, v2, v4, v5}, Landroid/support/v4/widget/CursorAdapter;-><init>(Landroid/content/Context;Landroid/database/Cursor;I)V
    0003: iput v3, v1.Landroid/support/v4/widget/ResourceCursorAdapter;->mDropDownLayout:I
    0005: iput v3, v1.Landroid/support/v4/widget/ResourceCursorAdapter;->mLayout:I
    0007: const-string v0, 'layout_inflater'
    0009: invoke-virtual {v2, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    000c: move-result-object v0
    000d: check-cast v0, Landroid/view/LayoutInflater;
    000f: iput v0, v1.Landroid/support/v4/widget/ResourceCursorAdapter;->mInflater:Landroid/view/LayoutInflater;
    0011: return-void

  [Direct Method] <init>(Landroid/content/Context;, I, Landroid/database/Cursor;, Z) -> V
    // registers=6, ins=5, outs=4, insns_size=18
    0000: invoke-direct {v1, v2, v4, v5}, Landroid/support/v4/widget/CursorAdapter;-><init>(Landroid/content/Context;Landroid/database/Cursor;Z)V
    0003: iput v3, v1.Landroid/support/v4/widget/ResourceCursorAdapter;->mDropDownLayout:I
    0005: iput v3, v1.Landroid/support/v4/widget/ResourceCursorAdapter;->mLayout:I
    0007: const-string v0, 'layout_inflater'
    0009: invoke-virtual {v2, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    000c: move-result-object v0
    000d: check-cast v0, Landroid/view/LayoutInflater;
    000f: iput v0, v1.Landroid/support/v4/widget/ResourceCursorAdapter;->mInflater:Landroid/view/LayoutInflater;
    0011: return-void

  [Virtual Method] newDropDownView(Landroid/content/Context;, Landroid/database/Cursor;, Landroid/view/ViewGroup;) -> Landroid/view/View;
    // registers=7, ins=4, outs=4, insns_size=10
    0000: iget v0, v3.Landroid/support/v4/widget/ResourceCursorAdapter;->mInflater:Landroid/view/LayoutInflater;
    0002: iget v1, v3.Landroid/support/v4/widget/ResourceCursorAdapter;->mDropDownLayout:I
    0004: const/4 v2, 0
    0005: invoke-virtual {v0, v1, v6, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;
    0008: move-result-object v0
    0009: return-object v0

  [Virtual Method] newView(Landroid/content/Context;, Landroid/database/Cursor;, Landroid/view/ViewGroup;) -> Landroid/view/View;
    // registers=7, ins=4, outs=4, insns_size=10
    0000: iget v0, v3.Landroid/support/v4/widget/ResourceCursorAdapter;->mInflater:Landroid/view/LayoutInflater;
    0002: iget v1, v3.Landroid/support/v4/widget/ResourceCursorAdapter;->mLayout:I
    0004: const/4 v2, 0
    0005: invoke-virtual {v0, v1, v6, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;
    0008: move-result-object v0
    0009: return-object v0

  [Virtual Method] setDropDownViewResource(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/widget/ResourceCursorAdapter;->mDropDownLayout:I
    0002: return-void

  [Virtual Method] setViewResource(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/widget/ResourceCursorAdapter;->mLayout:I
    0002: return-void