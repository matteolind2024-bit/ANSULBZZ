=== CLASS Landroid/support/v4/app/LoaderManager; (Source: LoaderManager.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] enableDebugLogging(Z) -> V
    // registers=1, ins=1, outs=0, insns_size=3
    0000: sput v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0002: return-void

  [Virtual Method] destroyLoader(I) -> V

  [Virtual Method] dump(Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V

  [Virtual Method] getLoader(I) -> Landroid/support/v4/content/Loader;

  [Virtual Method] hasRunningLoaders() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] initLoader(I, Landroid/os/Bundle;, Landroid/support/v4/app/LoaderManager$LoaderCallbacks;) -> Landroid/support/v4/content/Loader;

  [Virtual Method] restartLoader(I, Landroid/os/Bundle;, Landroid/support/v4/app/LoaderManager$LoaderCallbacks;) -> Landroid/support/v4/content/Loader;