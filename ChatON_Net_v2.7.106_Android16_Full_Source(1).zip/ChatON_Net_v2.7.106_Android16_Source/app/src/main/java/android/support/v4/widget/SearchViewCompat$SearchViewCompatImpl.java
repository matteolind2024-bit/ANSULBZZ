=== CLASS Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl; (Source: SearchViewCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] newOnQueryTextListener(Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;) -> Ljava/lang/Object;

  [Virtual Method] newSearchView(Landroid/content/Context;) -> Landroid/view/View;

  [Virtual Method] setOnQueryTextListener(Ljava/lang/Object;, Ljava/lang/Object;) -> V