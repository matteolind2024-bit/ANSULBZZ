=== CLASS Landroid/support/v4/app/NotificationCompat$Builder; (Source: NotificationCompat.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] mContentInfo: Ljava/lang/CharSequence;
  [Instance Field] mContentIntent: Landroid/app/PendingIntent;
  [Instance Field] mContentText: Ljava/lang/CharSequence;
  [Instance Field] mContentTitle: Ljava/lang/CharSequence;
  [Instance Field] mContext: Landroid/content/Context;
  [Instance Field] mFullScreenIntent: Landroid/app/PendingIntent;
  [Instance Field] mLargeIcon: Landroid/graphics/Bitmap;
  [Instance Field] mNotification: Landroid/app/Notification;
  [Instance Field] mNumber: I
  [Instance Field] mTickerView: Landroid/widget/RemoteViews;

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=5, ins=2, outs=1, insns_size=26
    0000: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Landroid/app/Notification;
    0005: invoke-direct {v0}, Landroid/app/Notification;-><init>()V
    0008: iput v0, v3.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    000a: iput v4, v3.Landroid/support/v4/app/NotificationCompat$Builder;->mContext:Landroid/content/Context;
    000c: iget v0, v3.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    000e: invoke-static {}, Ljava/lang/System;->currentTimeMillis()J
    0011: move-result-wide v1
    0012: iput v1, v0.Landroid/app/Notification;->when:J
    0014: iget v0, v3.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0016: const/4 v1, -1
    0017: iput v1, v0.Landroid/app/Notification;->audioStreamType:I
    0019: return-void

  [Direct Method] setFlag(I, Z) -> V
    // registers=6, ins=3, outs=0, insns_size=20
    0000: if-eqz v5, 000a
    0002: iget v0, v3.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0004: iget v1, v0.Landroid/app/Notification;->flags:I
    0006: binop/2addr(op=b6) v1, v4
    0007: iput v1, v0.Landroid/app/Notification;->flags:I
    0009: return-void
    000a: iget v0, v3.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    000c: iget v1, v0.Landroid/app/Notification;->flags:I
    000e: binop/lit8(op=df) v2, v4, -1 (-0x1)
    0010: binop/2addr(op=b5) v1, v2
    0011: iput v1, v0.Landroid/app/Notification;->flags:I
    0013: goto 0009

  [Virtual Method] getNotification() -> Landroid/app/Notification;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: invoke-static {}, Landroid/support/v4/app/NotificationCompat;->access$000()Landroid/support/v4/app/NotificationCompat$NotificationCompatImpl;
    0003: move-result-object v0
    0004: invoke-interface {v0, v1}, Landroid/support/v4/app/NotificationCompat$NotificationCompatImpl;->getNotification(Landroid/support/v4/app/NotificationCompat$Builder;)Landroid/app/Notification;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] setAutoCancel(Z) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=3, ins=2, outs=3, insns_size=6
    0000: const/16 v0, 16 (0x10)
    0002: invoke-direct {v1, v0, v2}, Landroid/support/v4/app/NotificationCompat$Builder;->setFlag(IZ)V
    0005: return-object v1

  [Virtual Method] setContent(Landroid/widget/RemoteViews;) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=3, ins=2, outs=0, insns_size=5
    0000: iget v0, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iput v2, v0.Landroid/app/Notification;->contentView:Landroid/widget/RemoteViews;
    0004: return-object v1

  [Virtual Method] setContentInfo(Ljava/lang/CharSequence;) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/NotificationCompat$Builder;->mContentInfo:Ljava/lang/CharSequence;
    0002: return-object v0

  [Virtual Method] setContentIntent(Landroid/app/PendingIntent;) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/NotificationCompat$Builder;->mContentIntent:Landroid/app/PendingIntent;
    0002: return-object v0

  [Virtual Method] setContentText(Ljava/lang/CharSequence;) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/NotificationCompat$Builder;->mContentText:Ljava/lang/CharSequence;
    0002: return-object v0

  [Virtual Method] setContentTitle(Ljava/lang/CharSequence;) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/NotificationCompat$Builder;->mContentTitle:Ljava/lang/CharSequence;
    0002: return-object v0

  [Virtual Method] setDefaults(I) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=4, ins=2, outs=0, insns_size=17
    0000: iget v0, v2.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iput v3, v0.Landroid/app/Notification;->defaults:I
    0004: binop/lit8(op=dd) v0, v3, 4 (0x4)
    0006: if-eqz v0, 0010
    0008: iget v0, v2.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    000a: iget v1, v0.Landroid/app/Notification;->flags:I
    000c: binop/lit8(op=de) v1, v1, 1 (0x1)
    000e: iput v1, v0.Landroid/app/Notification;->flags:I
    0010: return-object v2

  [Virtual Method] setDeleteIntent(Landroid/app/PendingIntent;) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=3, ins=2, outs=0, insns_size=5
    0000: iget v0, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iput v2, v0.Landroid/app/Notification;->deleteIntent:Landroid/app/PendingIntent;
    0004: return-object v1

  [Virtual Method] setFullScreenIntent(Landroid/app/PendingIntent;, Z) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=4, ins=3, outs=3, insns_size=8
    0000: iput v2, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mFullScreenIntent:Landroid/app/PendingIntent;
    0002: const/16 v0, 128 (0x80)
    0004: invoke-direct {v1, v0, v3}, Landroid/support/v4/app/NotificationCompat$Builder;->setFlag(IZ)V
    0007: return-object v1

  [Virtual Method] setLargeIcon(Landroid/graphics/Bitmap;) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/NotificationCompat$Builder;->mLargeIcon:Landroid/graphics/Bitmap;
    0002: return-object v0

  [Virtual Method] setLights(I, I, I) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=9, ins=4, outs=0, insns_size=46
    0000: const/4 v1, 1
    0001: const/4 v2, 0
    0002: iget v0, v5.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0004: iput v6, v0.Landroid/app/Notification;->ledARGB:I
    0006: iget v0, v5.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0008: iput v7, v0.Landroid/app/Notification;->ledOnMS:I
    000a: iget v0, v5.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    000c: iput v8, v0.Landroid/app/Notification;->ledOffMS:I
    000e: iget v0, v5.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0010: iget v0, v0.Landroid/app/Notification;->ledOnMS:I
    0012: if-eqz v0, 002a
    0014: iget v0, v5.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0016: iget v0, v0.Landroid/app/Notification;->ledOffMS:I
    0018: if-eqz v0, 002a
    001a: move(op=01) v0, v1
    001b: iget v3, v5.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    001d: iget v4, v5.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    001f: iget v4, v4.Landroid/app/Notification;->flags:I
    0021: binop/lit8(op=dd) v4, v4, -2 (-0x2)
    0023: if-eqz v0, 002c
    0025: binop(op=96) v0, v4, v1
    0027: iput v0, v3.Landroid/app/Notification;->flags:I
    0029: return-object v5
    002a: move(op=01) v0, v2
    002b: goto 001b
    002c: move(op=01) v1, v2
    002d: goto 0025

  [Virtual Method] setNumber(I) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/NotificationCompat$Builder;->mNumber:I
    0002: return-object v0

  [Virtual Method] setOngoing(Z) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=3, ins=2, outs=3, insns_size=5
    0000: const/4 v0, 2
    0001: invoke-direct {v1, v0, v2}, Landroid/support/v4/app/NotificationCompat$Builder;->setFlag(IZ)V
    0004: return-object v1

  [Virtual Method] setOnlyAlertOnce(Z) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=3, ins=2, outs=3, insns_size=6
    0000: const/16 v0, 8 (0x8)
    0002: invoke-direct {v1, v0, v2}, Landroid/support/v4/app/NotificationCompat$Builder;->setFlag(IZ)V
    0005: return-object v1

  [Virtual Method] setSmallIcon(I) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=3, ins=2, outs=0, insns_size=5
    0000: iget v0, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iput v2, v0.Landroid/app/Notification;->icon:I
    0004: return-object v1

  [Virtual Method] setSmallIcon(I, I) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=4, ins=3, outs=0, insns_size=9
    0000: iget v0, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iput v2, v0.Landroid/app/Notification;->icon:I
    0004: iget v0, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0006: iput v3, v0.Landroid/app/Notification;->iconLevel:I
    0008: return-object v1

  [Virtual Method] setSound(Landroid/net/Uri;) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=4, ins=2, outs=0, insns_size=10
    0000: iget v0, v2.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iput v3, v0.Landroid/app/Notification;->sound:Landroid/net/Uri;
    0004: iget v0, v2.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0006: const/4 v1, -1
    0007: iput v1, v0.Landroid/app/Notification;->audioStreamType:I
    0009: return-object v2

  [Virtual Method] setSound(Landroid/net/Uri;, I) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=4, ins=3, outs=0, insns_size=9
    0000: iget v0, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iput v2, v0.Landroid/app/Notification;->sound:Landroid/net/Uri;
    0004: iget v0, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0006: iput v3, v0.Landroid/app/Notification;->audioStreamType:I
    0008: return-object v1

  [Virtual Method] setTicker(Ljava/lang/CharSequence;) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=3, ins=2, outs=0, insns_size=5
    0000: iget v0, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iput v2, v0.Landroid/app/Notification;->tickerText:Ljava/lang/CharSequence;
    0004: return-object v1

  [Virtual Method] setTicker(Ljava/lang/CharSequence;, Landroid/widget/RemoteViews;) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=4, ins=3, outs=0, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iput v2, v0.Landroid/app/Notification;->tickerText:Ljava/lang/CharSequence;
    0004: iput v3, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mTickerView:Landroid/widget/RemoteViews;
    0006: return-object v1

  [Virtual Method] setVibrate([J) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=3, ins=2, outs=0, insns_size=5
    0000: iget v0, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iput v2, v0.Landroid/app/Notification;->vibrate:[J
    0004: return-object v1

  [Virtual Method] setWhen(J) -> Landroid/support/v4/app/NotificationCompat$Builder;
    // registers=4, ins=3, outs=0, insns_size=5
    0000: iget v0, v1.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iput v2, v0.Landroid/app/Notification;->when:J
    0004: return-object v1