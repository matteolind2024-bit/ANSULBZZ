=== CLASS Landroid/support/v4/app/TaskStackBuilder; (Source: TaskStackBuilder.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/lang/Iterable;
  [Static Field] IMPL: Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImpl; = None
  [Static Field] TAG: Ljava/lang/String; = 'TaskStackBuilder'
  [Instance Field] mIntents: Ljava/util/ArrayList;
  [Instance Field] mSourceContext: Landroid/content/Context;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=22
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 11 (0xb)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImplHoneycomb;
    0008: invoke-direct {v0}, Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImplHoneycomb;-><init>()V
    000b: sput v0, Landroid/support/v4/app/TaskStackBuilder;->IMPL:Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImpl;
    000d: return-void
    000e: new-instance v0, Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImplBase;
    0010: invoke-direct {v0}, Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImplBase;-><init>()V
    0013: sput v0, Landroid/support/v4/app/TaskStackBuilder;->IMPL:Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImpl;
    0015: goto 000d

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=3, ins=2, outs=1, insns_size=13
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Ljava/util/ArrayList;
    0005: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0008: iput v0, v1.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    000a: iput v2, v1.Landroid/support/v4/app/TaskStackBuilder;->mSourceContext:Landroid/content/Context;
    000c: return-void

  [Direct Method] create(Landroid/content/Context;) -> Landroid/support/v4/app/TaskStackBuilder;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Landroid/support/v4/app/TaskStackBuilder;
    0002: invoke-direct {v0, v1}, Landroid/support/v4/app/TaskStackBuilder;-><init>(Landroid/content/Context;)V
    0005: return-object v0

  [Direct Method] from(Landroid/content/Context;) -> Landroid/support/v4/app/TaskStackBuilder;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-static {v1}, Landroid/support/v4/app/TaskStackBuilder;->create(Landroid/content/Context;)Landroid/support/v4/app/TaskStackBuilder;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] addNextIntent(Landroid/content/Intent;) -> Landroid/support/v4/app/TaskStackBuilder;
    // registers=3, ins=2, outs=2, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0002: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0005: return-object v1

  [Virtual Method] addParentStack(Landroid/app/Activity;) -> Landroid/support/v4/app/TaskStackBuilder;
    // registers=5, ins=2, outs=3, insns_size=41
    0000: iget v0, v3.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0002: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0005: move-result v1
    0006: invoke-static {v4}, Landroid/support/v4/app/NavUtils;->getParentActivityIntent(Landroid/app/Activity;)Landroid/content/Intent;
    0009: move-result-object v0
    000a: if-eqz v0, 0028
    000c: iget v2, v3.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    000e: invoke-virtual {v2, v1, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V
    0011: invoke-virtual {v0}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;
    0014: move-result-object v0
    0015: invoke-static {v4, v0}, Landroid/support/v4/app/NavUtils;->getParentActivityIntent(Landroid/content/Context;Landroid/content/ComponentName;)Landroid/content/Intent;
    0018: move-result-object v0
    0019: goto 000a
    001a: move-exception v0
    001b: const-string v1, 'TaskStackBuilder'
    001d: const-string v2, 'Bad ComponentName while traversing activity parent metadata'
    001f: invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    0022: new-instance v1, Ljava/lang/IllegalArgumentException;
    0024: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V
    0027: throw v1
    0028: return-object v3

  [Virtual Method] addParentStack(Ljava/lang/Class;) -> Landroid/support/v4/app/TaskStackBuilder;
    // registers=5, ins=2, outs=3, insns_size=45
    0000: iget v0, v3.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0002: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0005: move-result v1
    0006: iget v0, v3.Landroid/support/v4/app/TaskStackBuilder;->mSourceContext:Landroid/content/Context;
    0008: invoke-static {v0, v4}, Landroid/support/v4/app/NavUtils;->getParentActivityIntent(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;
    000b: move-result-object v0
    000c: if-eqz v0, 002c
    000e: iget v2, v3.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0010: invoke-virtual {v2, v1, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V
    0013: iget v2, v3.Landroid/support/v4/app/TaskStackBuilder;->mSourceContext:Landroid/content/Context;
    0015: invoke-virtual {v0}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;
    0018: move-result-object v0
    0019: invoke-static {v2, v0}, Landroid/support/v4/app/NavUtils;->getParentActivityIntent(Landroid/content/Context;Landroid/content/ComponentName;)Landroid/content/Intent;
    001c: move-result-object v0
    001d: goto 000c
    001e: move-exception v0
    001f: const-string v1, 'TaskStackBuilder'
    0021: const-string v2, 'Bad ComponentName while traversing activity parent metadata'
    0023: invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    0026: new-instance v1, Ljava/lang/IllegalArgumentException;
    0028: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V
    002b: throw v1
    002c: return-object v3

  [Virtual Method] editIntentAt(I) -> Landroid/content/Intent;
    // registers=3, ins=2, outs=2, insns_size=9
    0000: iget v0, v1.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0002: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/content/Intent;
    0008: return-object v0

  [Virtual Method] getIntent(I) -> Landroid/content/Intent;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/support/v4/app/TaskStackBuilder;->editIntentAt(I)Landroid/content/Intent;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getIntentCount() -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0002: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0005: move-result v0
    0006: return v0

  [Virtual Method] getIntents() -> [Landroid/content/Intent;
    // registers=3, ins=1, outs=2, insns_size=17
    0000: iget v0, v2.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0002: iget v1, v2.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0004: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0007: move-result v1
    0008: new-array v1, v1, [Landroid/content/Intent;
    000a: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    000d: move-result-object v0
    000e: check-cast v0, [Landroid/content/Intent;
    0010: return-object v0

  [Virtual Method] getPendingIntent(I, I) -> Landroid/app/PendingIntent;
    // registers=4, ins=3, outs=4, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v3, v0}, Landroid/support/v4/app/TaskStackBuilder;->getPendingIntent(IILandroid/os/Bundle;)Landroid/app/PendingIntent;
    0004: move-result-object v0
    0005: return-object v0

  [Virtual Method] getPendingIntent(I, I, Landroid/os/Bundle;) -> Landroid/app/PendingIntent;
    // registers=10, ins=4, outs=6, insns_size=53
    0000: iget v0, v6.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0002: invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z
    0005: move-result v0
    0006: if-eqz v0, 0010
    0008: new-instance v0, Ljava/lang/IllegalStateException;
    000a: const-string v1, 'No intents added to TaskStackBuilder; cannot getPendingIntent'
    000c: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000f: throw v0
    0010: iget v0, v6.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0012: iget v1, v6.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0014: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0017: move-result v1
    0018: new-array v1, v1, [Landroid/content/Intent;
    001a: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    001d: move-result-object v2
    001e: check-cast v2, [Landroid/content/Intent;
    0020: const/4 v0, 0
    0021: aget(op=46) v0, v2[v0]
    0023: const v1, 268484608 (0x1000c000)
    0026: invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    0029: sget v0, Landroid/support/v4/app/TaskStackBuilder;->IMPL:Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImpl;
    002b: iget v1, v6.Landroid/support/v4/app/TaskStackBuilder;->mSourceContext:Landroid/content/Context;
    002d: move(op=01) v3, v7
    002e: move(op=01) v4, v8
    002f: move(op=07) v5, v9
    0030: invoke-interface/range {v0..v5}, Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImpl;->getPendingIntent(Landroid/content/Context;[Landroid/content/Intent;IILandroid/os/Bundle;)Landroid/app/PendingIntent;
    0033: move-result-object v0
    0034: return-object v0

  [Virtual Method] iterator() -> Ljava/util/Iterator;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0002: invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] startActivities() -> V
    // registers=2, ins=1, outs=2, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v0}, Landroid/support/v4/app/TaskStackBuilder;->startActivities(Landroid/os/Bundle;)V
    0004: return-void

  [Virtual Method] startActivities(Landroid/os/Bundle;) -> V
    // registers=5, ins=2, outs=3, insns_size=65
    0000: iget v0, v3.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0002: invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z
    0005: move-result v0
    0006: if-eqz v0, 0010
    0008: new-instance v0, Ljava/lang/IllegalStateException;
    000a: const-string v1, 'No intents added to TaskStackBuilder; cannot startActivities'
    000c: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000f: throw v0
    0010: iget v0, v3.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0012: iget v1, v3.Landroid/support/v4/app/TaskStackBuilder;->mIntents:Ljava/util/ArrayList;
    0014: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0017: move-result v1
    0018: new-array v1, v1, [Landroid/content/Intent;
    001a: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    001d: move-result-object v0
    001e: check-cast v0, [Landroid/content/Intent;
    0020: const/4 v1, 0
    0021: aget(op=46) v1, v0[v1]
    0023: const v2, 268484608 (0x1000c000)
    0026: invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    0029: iget v1, v3.Landroid/support/v4/app/TaskStackBuilder;->mSourceContext:Landroid/content/Context;
    002b: invoke-static {v1, v0, v4}, Landroid/support/v4/content/ContextCompat;->startActivities(Landroid/content/Context;[Landroid/content/Intent;Landroid/os/Bundle;)Z
    002e: move-result v1
    002f: if-nez v1, 0040
    0031: move(op=21) v1, v0
    0032: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0034: aget(op=46) v0, v0[v1]
    0036: const/high16 v1, 268435456 (0x10000000)
    0038: invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    003b: iget v1, v3.Landroid/support/v4/app/TaskStackBuilder;->mSourceContext:Landroid/content/Context;
    003d: invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    0040: return-void