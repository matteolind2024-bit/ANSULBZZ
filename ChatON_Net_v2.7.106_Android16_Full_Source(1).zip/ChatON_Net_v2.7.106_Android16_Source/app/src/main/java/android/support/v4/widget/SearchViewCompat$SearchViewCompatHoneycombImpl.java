=== CLASS Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl; (Source: SearchViewCompat.java) ===
  Super: Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatStubImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatStubImpl;-><init>()V
    0003: return-void

  [Virtual Method] newOnQueryTextListener(Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=3, insns_size=10
    0000: new-instance v0, Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl$1;
    0002: invoke-direct {v0, v1, v2}, Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl$1;-><init>(Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl;Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;)V
    0005: invoke-static {v0}, Landroid/support/v4/widget/SearchViewCompatHoneycomb;->newOnQueryTextListener(Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;)Ljava/lang/Object;
    0008: move-result-object v0
    0009: return-object v0

  [Virtual Method] newSearchView(Landroid/content/Context;) -> Landroid/view/View;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/widget/SearchViewCompatHoneycomb;->newSearchView(Landroid/content/Context;)Landroid/view/View;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] setOnQueryTextListener(Ljava/lang/Object;, Ljava/lang/Object;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/widget/SearchViewCompatHoneycomb;->setOnQueryTextListener(Ljava/lang/Object;Ljava/lang/Object;)V
    0003: return-void