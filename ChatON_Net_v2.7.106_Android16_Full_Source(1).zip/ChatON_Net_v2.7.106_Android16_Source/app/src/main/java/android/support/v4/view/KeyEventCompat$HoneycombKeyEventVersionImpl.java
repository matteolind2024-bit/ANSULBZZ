=== CLASS Landroid/support/v4/view/KeyEventCompat$HoneycombKeyEventVersionImpl; (Source: KeyEventCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/KeyEventCompat$KeyEventVersionImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] metaStateHasModifiers(I, I) -> Z
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/KeyEventCompatHoneycomb;->metaStateHasModifiers(II)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] metaStateHasNoModifiers(I) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/KeyEventCompatHoneycomb;->metaStateHasNoModifiers(I)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] normalizeMetaState(I) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/KeyEventCompatHoneycomb;->normalizeMetaState(I)I
    0003: move-result v0
    0004: return v0