=== CLASS Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult; (Source: ModernAsyncTask.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] mData: [Ljava/lang/Object;
  [Instance Field] mTask: Landroid/support/v4/content/ModernAsyncTask;

  [Direct Method] <init>(Landroid/support/v4/content/ModernAsyncTask;, [Ljava/lang/Object;) -> V
    // registers=3, ins=3, outs=1, insns_size=8
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;->mTask:Landroid/support/v4/content/ModernAsyncTask;
    0005: iput v2, v0.Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;->mData:[Ljava/lang/Object;
    0007: return-void