=== CLASS Landroid/support/v4/content/ContextCompat; (Source: ContextCompat.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] startActivities(Landroid/content/Context;, [Landroid/content/Intent;) -> Z
    // registers=3, ins=2, outs=3, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-static {v1, v2, v0}, Landroid/support/v4/content/ContextCompat;->startActivities(Landroid/content/Context;[Landroid/content/Intent;Landroid/os/Bundle;)Z
    0004: move-result v0
    0005: return v0

  [Direct Method] startActivities(Landroid/content/Context;, [Landroid/content/Intent;, Landroid/os/Bundle;) -> Z
    // registers=6, ins=3, outs=3, insns_size=21
    0000: const/4 v0, 1
    0001: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    0003: const/16 v2, 16 (0x10)
    0005: if-lt v1, v2, 000b
    0007: invoke-static {v3, v4, v5}, Landroid/support/v4/content/ContextCompatJellybean;->startActivities(Landroid/content/Context;[Landroid/content/Intent;Landroid/os/Bundle;)V
    000a: return v0
    000b: const/16 v2, 11 (0xb)
    000d: if-lt v1, v2, 0013
    000f: invoke-static {v3, v4}, Landroid/support/v4/content/ContextCompatHoneycomb;->startActivities(Landroid/content/Context;[Landroid/content/Intent;)V
    0012: goto 000a
    0013: const/4 v0, 0
    0014: goto 000a