=== CLASS Landroid/support/v4/net/TrafficStatsCompat; (Source: TrafficStatsCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] IMPL: Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=22
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 14 (0xe)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/net/TrafficStatsCompat$IcsTrafficStatsCompatImpl;
    0008: invoke-direct {v0}, Landroid/support/v4/net/TrafficStatsCompat$IcsTrafficStatsCompatImpl;-><init>()V
    000b: sput v0, Landroid/support/v4/net/TrafficStatsCompat;->IMPL:Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;
    000d: return-void
    000e: new-instance v0, Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl;
    0010: invoke-direct {v0}, Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl;-><init>()V
    0013: sput v0, Landroid/support/v4/net/TrafficStatsCompat;->IMPL:Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;
    0015: goto 000d

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] clearThreadStatsTag() -> V
    // registers=1, ins=0, outs=1, insns_size=6
    0000: sget v0, Landroid/support/v4/net/TrafficStatsCompat;->IMPL:Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;
    0002: invoke-interface {v0}, Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;->clearThreadStatsTag()V
    0005: return-void

  [Direct Method] getThreadStatsTag() -> I
    // registers=1, ins=0, outs=1, insns_size=7
    0000: sget v0, Landroid/support/v4/net/TrafficStatsCompat;->IMPL:Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;
    0002: invoke-interface {v0}, Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;->getThreadStatsTag()I
    0005: move-result v0
    0006: return v0

  [Direct Method] incrementOperationCount(I) -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: sget v0, Landroid/support/v4/net/TrafficStatsCompat;->IMPL:Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;->incrementOperationCount(I)V
    0005: return-void

  [Direct Method] incrementOperationCount(I, I) -> V
    // registers=3, ins=2, outs=3, insns_size=6
    0000: sget v0, Landroid/support/v4/net/TrafficStatsCompat;->IMPL:Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;->incrementOperationCount(II)V
    0005: return-void

  [Direct Method] setThreadStatsTag(I) -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: sget v0, Landroid/support/v4/net/TrafficStatsCompat;->IMPL:Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;->setThreadStatsTag(I)V
    0005: return-void

  [Direct Method] tagSocket(Ljava/net/Socket;) -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: sget v0, Landroid/support/v4/net/TrafficStatsCompat;->IMPL:Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;->tagSocket(Ljava/net/Socket;)V
    0005: return-void

  [Direct Method] untagSocket(Ljava/net/Socket;) -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: sget v0, Landroid/support/v4/net/TrafficStatsCompat;->IMPL:Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;->untagSocket(Ljava/net/Socket;)V
    0005: return-void