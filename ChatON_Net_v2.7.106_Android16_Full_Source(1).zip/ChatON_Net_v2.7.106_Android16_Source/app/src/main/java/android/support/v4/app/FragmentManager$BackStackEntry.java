=== CLASS Landroid/support/v4/app/FragmentManager$BackStackEntry; (Source: FragmentManager.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] getBreadCrumbShortTitle() -> Ljava/lang/CharSequence;

  [Virtual Method] getBreadCrumbShortTitleRes() -> I

  [Virtual Method] getBreadCrumbTitle() -> Ljava/lang/CharSequence;

  [Virtual Method] getBreadCrumbTitleRes() -> I

  [Virtual Method] getId() -> I

  [Virtual Method] getName() -> Ljava/lang/String;