=== CLASS Landroid/support/v4/app/FragmentActivity$1; (Source: FragmentActivity.java) ===
  Super: Landroid/os/Handler;
  [Instance Field] this$0: Landroid/support/v4/app/FragmentActivity;

  [Direct Method] <init>(Landroid/support/v4/app/FragmentActivity;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/app/FragmentActivity$1;->this$0:Landroid/support/v4/app/FragmentActivity;
    0002: invoke-direct {v0}, Landroid/os/Handler;-><init>()V
    0005: return-void

  [Virtual Method] handleMessage(Landroid/os/Message;) -> V
    // registers=4, ins=2, outs=2, insns_size=44
    0000: iget v0, v3.Landroid/os/Message;->what:I
    0002: packed-switch v0, +34 (-> 0024)
    0005: invoke-super {v2, v3}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V
    0008: return-void
    0009: iget v0, v2.Landroid/support/v4/app/FragmentActivity$1;->this$0:Landroid/support/v4/app/FragmentActivity;
    000b: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mStopped:Z
    000d: if-eqz v0, 0008
    000f: iget v0, v2.Landroid/support/v4/app/FragmentActivity$1;->this$0:Landroid/support/v4/app/FragmentActivity;
    0011: const/4 v1, 0
    0012: invoke-virtual {v0, v1}, Landroid/support/v4/app/FragmentActivity;->doReallyStop(Z)V
    0015: goto 0008
    0016: iget v0, v2.Landroid/support/v4/app/FragmentActivity$1;->this$0:Landroid/support/v4/app/FragmentActivity;
    0018: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->onResumeFragments()V
    001b: iget v0, v2.Landroid/support/v4/app/FragmentActivity$1;->this$0:Landroid/support/v4/app/FragmentActivity;
    001d: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    001f: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->execPendingActions()Z
    0022: goto 0008
    0023: nop
    0024: packed-switch-payload first=1 targets=[7, 20]