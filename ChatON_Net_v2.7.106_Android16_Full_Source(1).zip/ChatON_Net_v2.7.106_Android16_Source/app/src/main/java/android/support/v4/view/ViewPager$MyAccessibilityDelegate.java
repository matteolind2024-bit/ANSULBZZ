=== CLASS Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate; (Source: ViewPager.java) ===
  Super: Landroid/support/v4/view/AccessibilityDelegateCompat;
  [Instance Field] this$0: Landroid/support/v4/view/ViewPager;

  [Direct Method] <init>(Landroid/support/v4/view/ViewPager;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0002: invoke-direct {v0}, Landroid/support/v4/view/AccessibilityDelegateCompat;-><init>()V
    0005: return-void

  [Virtual Method] onInitializeAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=4, ins=3, outs=3, insns_size=13
    0000: invoke-super {v1, v2, v3}, Landroid/support/v4/view/AccessibilityDelegateCompat;->onInitializeAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    0003: const-class v0, Landroid/support/v4/view/ViewPager;
    0005: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    0008: move-result-object v0
    0009: invoke-virtual {v3, v0}, Landroid/view/accessibility/AccessibilityEvent;->setClassName(Ljava/lang/CharSequence;)V
    000c: return-void

  [Virtual Method] onInitializeAccessibilityNodeInfo(Landroid/view/View;, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;) -> V
    // registers=5, ins=3, outs=3, insns_size=119
    0000: const/4 v0, 1
    0001: invoke-super {v2, v3, v4}, Landroid/support/v4/view/AccessibilityDelegateCompat;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;)V
    0004: const-class v1, Landroid/support/v4/view/ViewPager;
    0006: invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;
    0009: move-result-object v1
    000a: invoke-virtual {v4, v1}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;->setClassName(Ljava/lang/CharSequence;)V
    000d: iget v1, v2.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    000f: invoke-static {v1}, Landroid/support/v4/view/ViewPager;->access$100(Landroid/support/v4/view/ViewPager;)Landroid/support/v4/view/PagerAdapter;
    0012: move-result-object v1
    0013: if-eqz v1, 0075
    0015: iget v1, v2.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0017: invoke-static {v1}, Landroid/support/v4/view/ViewPager;->access$100(Landroid/support/v4/view/ViewPager;)Landroid/support/v4/view/PagerAdapter;
    001a: move-result-object v1
    001b: invoke-virtual {v1}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    001e: move-result v1
    001f: if-le v1, v0, 0075
    0021: invoke-virtual {v4, v0}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;->setScrollable(Z)V
    0024: iget v0, v2.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0026: invoke-static {v0}, Landroid/support/v4/view/ViewPager;->access$100(Landroid/support/v4/view/ViewPager;)Landroid/support/v4/view/PagerAdapter;
    0029: move-result-object v0
    002a: if-eqz v0, 004d
    002c: iget v0, v2.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    002e: invoke-static {v0}, Landroid/support/v4/view/ViewPager;->access$200(Landroid/support/v4/view/ViewPager;)I
    0031: move-result v0
    0032: if-ltz v0, 004d
    0034: iget v0, v2.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0036: invoke-static {v0}, Landroid/support/v4/view/ViewPager;->access$200(Landroid/support/v4/view/ViewPager;)I
    0039: move-result v0
    003a: iget v1, v2.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    003c: invoke-static {v1}, Landroid/support/v4/view/ViewPager;->access$100(Landroid/support/v4/view/ViewPager;)Landroid/support/v4/view/PagerAdapter;
    003f: move-result-object v1
    0040: invoke-virtual {v1}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    0043: move-result v1
    0044: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0046: if-ge v0, v1, 004d
    0048: const/16 v0, 4096 (0x1000)
    004a: invoke-virtual {v4, v0}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;->addAction(I)V
    004d: iget v0, v2.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    004f: invoke-static {v0}, Landroid/support/v4/view/ViewPager;->access$100(Landroid/support/v4/view/ViewPager;)Landroid/support/v4/view/PagerAdapter;
    0052: move-result-object v0
    0053: if-eqz v0, 0074
    0055: iget v0, v2.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0057: invoke-static {v0}, Landroid/support/v4/view/ViewPager;->access$200(Landroid/support/v4/view/ViewPager;)I
    005a: move-result v0
    005b: if-lez v0, 0074
    005d: iget v0, v2.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    005f: invoke-static {v0}, Landroid/support/v4/view/ViewPager;->access$200(Landroid/support/v4/view/ViewPager;)I
    0062: move-result v0
    0063: iget v1, v2.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0065: invoke-static {v1}, Landroid/support/v4/view/ViewPager;->access$100(Landroid/support/v4/view/ViewPager;)Landroid/support/v4/view/PagerAdapter;
    0068: move-result-object v1
    0069: invoke-virtual {v1}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    006c: move-result v1
    006d: if-ge v0, v1, 0074
    006f: const/16 v0, 8192 (0x2000)
    0071: invoke-virtual {v4, v0}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;->addAction(I)V
    0074: return-void
    0075: const/4 v0, 0
    0076: goto 0021

  [Virtual Method] performAccessibilityAction(Landroid/view/View;, I, Landroid/os/Bundle;) -> Z
    // registers=8, ins=4, outs=4, insns_size=126
    0000: const/4 v0, 1
    0001: const/4 v1, 0
    0002: invoke-super {v4, v5, v6, v7}, Landroid/support/v4/view/AccessibilityDelegateCompat;->performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z
    0005: move-result v2
    0006: if-eqz v2, 0009
    0008: return v0
    0009: sparse-switch v6, +107 (-> 0074)
    000c: move(op=01) v0, v1
    000d: goto 0008
    000e: iget v2, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0010: invoke-static {v2}, Landroid/support/v4/view/ViewPager;->access$100(Landroid/support/v4/view/ViewPager;)Landroid/support/v4/view/PagerAdapter;
    0013: move-result-object v2
    0014: if-eqz v2, 0040
    0016: iget v2, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0018: invoke-static {v2}, Landroid/support/v4/view/ViewPager;->access$200(Landroid/support/v4/view/ViewPager;)I
    001b: move-result v2
    001c: if-ltz v2, 0040
    001e: iget v2, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0020: invoke-static {v2}, Landroid/support/v4/view/ViewPager;->access$200(Landroid/support/v4/view/ViewPager;)I
    0023: move-result v2
    0024: iget v3, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0026: invoke-static {v3}, Landroid/support/v4/view/ViewPager;->access$100(Landroid/support/v4/view/ViewPager;)Landroid/support/v4/view/PagerAdapter;
    0029: move-result-object v3
    002a: invoke-virtual {v3}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    002d: move-result v3
    002e: binop/lit8(op=d8) v3, v3, -1 (-0x1)
    0030: if-ge v2, v3, 0040
    0032: iget v1, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0034: iget v2, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0036: invoke-static {v2}, Landroid/support/v4/view/ViewPager;->access$200(Landroid/support/v4/view/ViewPager;)I
    0039: move-result v2
    003a: binop/lit8(op=d8) v2, v2, 1 (0x1)
    003c: invoke-virtual {v1, v2}, Landroid/support/v4/view/ViewPager;->setCurrentItem(I)V
    003f: goto 0008
    0040: move(op=01) v0, v1
    0041: goto 0008
    0042: iget v2, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0044: invoke-static {v2}, Landroid/support/v4/view/ViewPager;->access$100(Landroid/support/v4/view/ViewPager;)Landroid/support/v4/view/PagerAdapter;
    0047: move-result-object v2
    0048: if-eqz v2, 0072
    004a: iget v2, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    004c: invoke-static {v2}, Landroid/support/v4/view/ViewPager;->access$200(Landroid/support/v4/view/ViewPager;)I
    004f: move-result v2
    0050: if-lez v2, 0072
    0052: iget v2, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0054: invoke-static {v2}, Landroid/support/v4/view/ViewPager;->access$200(Landroid/support/v4/view/ViewPager;)I
    0057: move-result v2
    0058: iget v3, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    005a: invoke-static {v3}, Landroid/support/v4/view/ViewPager;->access$100(Landroid/support/v4/view/ViewPager;)Landroid/support/v4/view/PagerAdapter;
    005d: move-result-object v3
    005e: invoke-virtual {v3}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    0061: move-result v3
    0062: if-ge v2, v3, 0072
    0064: iget v1, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0066: iget v2, v4.Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;->this$0:Landroid/support/v4/view/ViewPager;
    0068: invoke-static {v2}, Landroid/support/v4/view/ViewPager;->access$200(Landroid/support/v4/view/ViewPager;)I
    006b: move-result v2
    006c: binop/lit8(op=d8) v2, v2, -1 (-0x1)
    006e: invoke-virtual {v1, v2}, Landroid/support/v4/view/ViewPager;->setCurrentItem(I)V
    0071: goto 0008
    0072: move(op=01) v0, v1
    0073: goto 0008
    0074: sparse-switch-payload {4096: 5, 8192: 57}