=== CLASS Landroid/support/v4/view/MenuItemCompat$BaseMenuVersionImpl; (Source: MenuItemCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/MenuItemCompat$MenuVersionImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] setActionView(Landroid/view/MenuItem;, Landroid/view/View;) -> Landroid/view/MenuItem;
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-object v1

  [Virtual Method] setShowAsAction(Landroid/view/MenuItem;, I) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0