=== CLASS Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatStubImpl; (Source: SearchViewCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] newOnQueryTextListener(Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] newSearchView(Landroid/content/Context;) -> Landroid/view/View;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] setOnQueryTextListener(Ljava/lang/Object;, Ljava/lang/Object;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void