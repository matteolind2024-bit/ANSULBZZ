=== CLASS Landroid/support/v4/widget/SearchViewCompatHoneycomb; (Source: SearchViewCompatHoneycomb.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] newOnQueryTextListener(Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;) -> Ljava/lang/Object;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Landroid/support/v4/widget/SearchViewCompatHoneycomb$1;
    0002: invoke-direct {v0, v1}, Landroid/support/v4/widget/SearchViewCompatHoneycomb$1;-><init>(Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;)V
    0005: return-object v0

  [Direct Method] newSearchView(Landroid/content/Context;) -> Landroid/view/View;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Landroid/widget/SearchView;
    0002: invoke-direct {v0, v1}, Landroid/widget/SearchView;-><init>(Landroid/content/Context;)V
    0005: return-object v0

  [Direct Method] setOnQueryTextListener(Ljava/lang/Object;, Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=2, insns_size=8
    0000: check-cast v0, Landroid/widget/SearchView;
    0002: check-cast v1, Landroid/widget/SearchView$OnQueryTextListener;
    0004: invoke-virtual {v0, v1}, Landroid/widget/SearchView;->setOnQueryTextListener(Landroid/widget/SearchView$OnQueryTextListener;)V
    0007: return-void