=== CLASS Landroid/support/v4/util/SparseArrayCompat; (Source: SparseArrayCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] DELETED: Ljava/lang/Object;
  [Instance Field] mGarbage: Z
  [Instance Field] mKeys: [I
  [Instance Field] mSize: I
  [Instance Field] mValues: [Ljava/lang/Object;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=8
    0000: new-instance v0, Ljava/lang/Object;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: sput v0, Landroid/support/v4/util/SparseArrayCompat;->DELETED:Ljava/lang/Object;
    0007: return-void

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: const/16 v0, 10 (0xa)
    0002: invoke-direct {v1, v0}, Landroid/support/v4/util/SparseArrayCompat;-><init>(I)V
    0005: return-void

  [Direct Method] <init>(I) -> V
    // registers=5, ins=2, outs=1, insns_size=21
    0000: const/4 v2, 0
    0001: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    0004: iput v2, v3.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0006: invoke-static {v4}, Landroid/support/v4/util/SparseArrayCompat;->idealIntArraySize(I)I
    0009: move-result v0
    000a: new-array v1, v0, [I
    000c: iput v1, v3.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    000e: new-array v0, v0, [Ljava/lang/Object;
    0010: iput v0, v3.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0012: iput v2, v3.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0014: return-void

  [Direct Method] binarySearch([I, I, I, I) -> I
    // registers=8, ins=4, outs=0, insns_size=39
    0000: binop(op=90) v2, v5, v6
    0002: binop/lit8(op=d8) v0, v5, -1 (-0x1)
    0004: move(op=01) v1, v0
    0005: move(op=01) v0, v2
    0006: binop(op=91) v2, v0, v1
    0008: const/4 v3, 1
    0009: if-le v2, v3, 0017
    000b: binop(op=90) v2, v0, v1
    000d: binop/lit8(op=db) v2, v2, 2 (0x2)
    000f: aget(op=44) v3, v4[v2]
    0011: if-ge v3, v7, 0015
    0013: move(op=01) v1, v2
    0014: goto 0006
    0015: move(op=01) v0, v2
    0016: goto 0006
    0017: binop(op=90) v1, v5, v6
    0019: if-ne v0, v1, 0020
    001b: binop(op=90) v0, v5, v6
    001d: binop/lit8(op=df) v0, v0, -1 (-0x1)
    001f: return v0
    0020: aget(op=44) v1, v4[v0]
    0022: if-eq v1, v7, 001f
    0024: binop/lit8(op=df) v0, v0, -1 (-0x1)
    0026: goto 001f

  [Direct Method] gc() -> V
    // registers=9, ins=1, outs=0, insns_size=35
    0000: const/4 v2, 0
    0001: iget v3, v8.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0003: iget v4, v8.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0005: iget v5, v8.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0007: move(op=01) v1, v2
    0008: move(op=01) v0, v2
    0009: if-ge v1, v3, 001e
    000b: aget(op=46) v6, v5[v1]
    000d: sget v7, Landroid/support/v4/util/SparseArrayCompat;->DELETED:Ljava/lang/Object;
    000f: if-eq v6, v7, 001b
    0011: if-eq v1, v0, 0019
    0013: aget(op=44) v7, v4[v1]
    0015: aput(op=4b) v7, v4[v0]
    0017: aput(op=4d) v6, v5[v0]
    0019: binop/lit8(op=d8) v0, v0, 1 (0x1)
    001b: binop/lit8(op=d8) v1, v1, 1 (0x1)
    001d: goto 0009
    001e: iput v2, v8.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0020: iput v0, v8.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0022: return-void

  [Direct Method] idealByteArraySize(I) -> I
    // registers=4, ins=1, outs=0, insns_size=20
    0000: const/4 v2, 1
    0001: const/4 v0, 4
    0002: const/16 v1, 32 (0x20)
    0004: if-ge v0, v1, 0010
    0006: binop(op=98) v1, v2, v0
    0008: binop/lit8(op=d8) v1, v1, -12 (-0xc)
    000a: if-gt v3, v1, 0011
    000c: binop(op=98) v0, v2, v0
    000e: binop/lit8(op=d8) v3, v0, -12 (-0xc)
    0010: return v3
    0011: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0013: goto 0002

  [Direct Method] idealIntArraySize(I) -> I
    // registers=2, ins=1, outs=1, insns_size=9
    0000: binop/lit8(op=da) v0, v1, 4 (0x4)
    0002: invoke-static {v0}, Landroid/support/v4/util/SparseArrayCompat;->idealByteArraySize(I)I
    0005: move-result v0
    0006: binop/lit8(op=db) v0, v0, 4 (0x4)
    0008: return v0

  [Virtual Method] append(I, Ljava/lang/Object;) -> V
    // registers=9, ins=3, outs=5, insns_size=83
    0000: const/4 v5, 0
    0001: iget v0, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0003: if-eqz v0, 0013
    0005: iget v0, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0007: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0009: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    000b: aget(op=44) v0, v0[v1]
    000d: if-gt v7, v0, 0013
    000f: invoke-virtual {v6, v7, v8}, Landroid/support/v4/util/SparseArrayCompat;->put(ILjava/lang/Object;)V
    0012: return-void
    0013: iget v0, v6.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0015: if-eqz v0, 0021
    0017: iget v0, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0019: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    001b: move(op=21) v1, v1
    001c: if-lt v0, v1, 0021
    001e: invoke-direct {v6}, Landroid/support/v4/util/SparseArrayCompat;->gc()V
    0021: iget v0, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0023: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0025: move(op=21) v1, v1
    0026: if-lt v0, v1, 0046
    0028: binop/lit8(op=d8) v1, v0, 1 (0x1)
    002a: invoke-static {v1}, Landroid/support/v4/util/SparseArrayCompat;->idealIntArraySize(I)I
    002d: move-result v1
    002e: new-array v2, v1, [I
    0030: new-array v1, v1, [Ljava/lang/Object;
    0032: iget v3, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0034: iget v4, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0036: move(op=21) v4, v4
    0037: invoke-static {v3, v5, v2, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    003a: iget v3, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    003c: iget v4, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    003e: move(op=21) v4, v4
    003f: invoke-static {v3, v5, v1, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0042: iput v2, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0044: iput v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0046: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0048: aput(op=4b) v7, v1[v0]
    004a: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    004c: aput(op=4d) v8, v1[v0]
    004e: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0050: iput v0, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0052: goto 0012

  [Virtual Method] clear() -> V
    // registers=6, ins=1, outs=0, insns_size=19
    0000: const/4 v1, 0
    0001: iget v2, v5.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0003: iget v3, v5.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0005: move(op=01) v0, v1
    0006: if-ge v0, v2, 000e
    0008: const/4 v4, 0
    0009: aput(op=4d) v4, v3[v0]
    000b: binop/lit8(op=d8) v0, v0, 1 (0x1)
    000d: goto 0006
    000e: iput v1, v5.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0010: iput v1, v5.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0012: return-void

  [Virtual Method] delete(I) -> V
    // registers=5, ins=2, outs=4, insns_size=29
    0000: iget v0, v3.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0002: const/4 v1, 0
    0003: iget v2, v3.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0005: invoke-static {v0, v1, v2, v4}, Landroid/support/v4/util/SparseArrayCompat;->binarySearch([IIII)I
    0008: move-result v0
    0009: if-ltz v0, 001c
    000b: iget v1, v3.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    000d: aget(op=46) v1, v1[v0]
    000f: sget v2, Landroid/support/v4/util/SparseArrayCompat;->DELETED:Ljava/lang/Object;
    0011: if-eq v1, v2, 001c
    0013: iget v1, v3.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0015: sget v2, Landroid/support/v4/util/SparseArrayCompat;->DELETED:Ljava/lang/Object;
    0017: aput(op=4d) v2, v1[v0]
    0019: const/4 v0, 1
    001a: iput v0, v3.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    001c: return-void

  [Virtual Method] get(I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=3, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0}, Landroid/support/v4/util/SparseArrayCompat;->get(ILjava/lang/Object;)Ljava/lang/Object;
    0004: move-result-object v0
    0005: return-object v0

  [Virtual Method] get(I, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=6, ins=3, outs=4, insns_size=25
    0000: iget v0, v3.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0002: const/4 v1, 0
    0003: iget v2, v3.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0005: invoke-static {v0, v1, v2, v4}, Landroid/support/v4/util/SparseArrayCompat;->binarySearch([IIII)I
    0008: move-result v0
    0009: if-ltz v0, 0013
    000b: iget v1, v3.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    000d: aget(op=46) v1, v1[v0]
    000f: sget v2, Landroid/support/v4/util/SparseArrayCompat;->DELETED:Ljava/lang/Object;
    0011: if-ne v1, v2, 0014
    0013: return-object v5
    0014: iget v1, v3.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0016: aget(op=46) v5, v1[v0]
    0018: goto 0013

  [Virtual Method] indexOfKey(I) -> I
    // registers=5, ins=2, outs=4, insns_size=17
    0000: iget v0, v3.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v3}, Landroid/support/v4/util/SparseArrayCompat;->gc()V
    0007: iget v0, v3.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0009: const/4 v1, 0
    000a: iget v2, v3.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    000c: invoke-static {v0, v1, v2, v4}, Landroid/support/v4/util/SparseArrayCompat;->binarySearch([IIII)I
    000f: move-result v0
    0010: return v0

  [Virtual Method] indexOfValue(Ljava/lang/Object;) -> I
    // registers=4, ins=2, outs=1, insns_size=24
    0000: iget v0, v2.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v2}, Landroid/support/v4/util/SparseArrayCompat;->gc()V
    0007: const/4 v0, 0
    0008: iget v1, v2.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    000a: if-ge v0, v1, 0016
    000c: iget v1, v2.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    000e: aget(op=46) v1, v1[v0]
    0010: if-ne v1, v3, 0013
    0012: return v0
    0013: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0015: goto 0008
    0016: const/4 v0, -1
    0017: goto 0012

  [Virtual Method] keyAt(I) -> I
    // registers=3, ins=2, outs=1, insns_size=12
    0000: iget v0, v1.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v1}, Landroid/support/v4/util/SparseArrayCompat;->gc()V
    0007: iget v0, v1.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0009: aget(op=44) v0, v0[v2]
    000b: return v0

  [Virtual Method] put(I, Ljava/lang/Object;) -> V
    // registers=9, ins=3, outs=5, insns_size=147
    0000: const/4 v5, 0
    0001: iget v0, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0003: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0005: invoke-static {v0, v5, v1, v7}, Landroid/support/v4/util/SparseArrayCompat;->binarySearch([IIII)I
    0008: move-result v0
    0009: if-ltz v0, 0010
    000b: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    000d: aput(op=4d) v8, v1[v0]
    000f: return-void
    0010: binop/lit8(op=df) v0, v0, -1 (-0x1)
    0012: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0014: if-ge v0, v1, 0027
    0016: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0018: aget(op=46) v1, v1[v0]
    001a: sget v2, Landroid/support/v4/util/SparseArrayCompat;->DELETED:Ljava/lang/Object;
    001c: if-ne v1, v2, 0027
    001e: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0020: aput(op=4b) v7, v1[v0]
    0022: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0024: aput(op=4d) v8, v1[v0]
    0026: goto 000f
    0027: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0029: if-eqz v1, 003f
    002b: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    002d: iget v2, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    002f: move(op=21) v2, v2
    0030: if-lt v1, v2, 003f
    0032: invoke-direct {v6}, Landroid/support/v4/util/SparseArrayCompat;->gc()V
    0035: iget v0, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0037: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0039: invoke-static {v0, v5, v1, v7}, Landroid/support/v4/util/SparseArrayCompat;->binarySearch([IIII)I
    003c: move-result v0
    003d: binop/lit8(op=df) v0, v0, -1 (-0x1)
    003f: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0041: iget v2, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0043: move(op=21) v2, v2
    0044: if-lt v1, v2, 0066
    0046: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0048: binop/lit8(op=d8) v1, v1, 1 (0x1)
    004a: invoke-static {v1}, Landroid/support/v4/util/SparseArrayCompat;->idealIntArraySize(I)I
    004d: move-result v1
    004e: new-array v2, v1, [I
    0050: new-array v1, v1, [Ljava/lang/Object;
    0052: iget v3, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0054: iget v4, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0056: move(op=21) v4, v4
    0057: invoke-static {v3, v5, v2, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    005a: iget v3, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    005c: iget v4, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    005e: move(op=21) v4, v4
    005f: invoke-static {v3, v5, v1, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0062: iput v2, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0064: iput v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0066: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0068: binop/2addr(op=b1) v1, v0
    0069: if-eqz v1, 0083
    006b: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    006d: iget v2, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    006f: binop/lit8(op=d8) v3, v0, 1 (0x1)
    0071: iget v4, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0073: binop/2addr(op=b1) v4, v0
    0074: invoke-static {v1, v0, v2, v3, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0077: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0079: iget v2, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    007b: binop/lit8(op=d8) v3, v0, 1 (0x1)
    007d: iget v4, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    007f: binop/2addr(op=b1) v4, v0
    0080: invoke-static {v1, v0, v2, v3, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0083: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mKeys:[I
    0085: aput(op=4b) v7, v1[v0]
    0087: iget v1, v6.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0089: aput(op=4d) v8, v1[v0]
    008b: iget v0, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    008d: binop/lit8(op=d8) v0, v0, 1 (0x1)
    008f: iput v0, v6.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0091: goto/16 000f

  [Virtual Method] remove(I) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->delete(I)V
    0003: return-void

  [Virtual Method] removeAt(I) -> V
    // registers=4, ins=2, outs=0, insns_size=18
    0000: iget v0, v2.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0002: aget(op=46) v0, v0[v3]
    0004: sget v1, Landroid/support/v4/util/SparseArrayCompat;->DELETED:Ljava/lang/Object;
    0006: if-eq v0, v1, 0011
    0008: iget v0, v2.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    000a: sget v1, Landroid/support/v4/util/SparseArrayCompat;->DELETED:Ljava/lang/Object;
    000c: aput(op=4d) v1, v0[v3]
    000e: const/4 v0, 1
    000f: iput v0, v2.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0011: return-void

  [Virtual Method] removeAtRange(I, I) -> V
    // registers=5, ins=3, outs=2, insns_size=17
    0000: iget v0, v2.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0002: binop(op=90) v1, v3, v4
    0004: invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I
    0007: move-result v0
    0008: if-ge v3, v0, 0010
    000a: invoke-virtual {v2, v3}, Landroid/support/v4/util/SparseArrayCompat;->removeAt(I)V
    000d: binop/lit8(op=d8) v3, v3, 1 (0x1)
    000f: goto 0008
    0010: return-void

  [Virtual Method] setValueAt(I, Ljava/lang/Object;) -> V
    // registers=4, ins=3, outs=1, insns_size=12
    0000: iget v0, v1.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v1}, Landroid/support/v4/util/SparseArrayCompat;->gc()V
    0007: iget v0, v1.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0009: aput(op=4d) v3, v0[v2]
    000b: return-void

  [Virtual Method] size() -> I
    // registers=2, ins=1, outs=1, insns_size=10
    0000: iget v0, v1.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v1}, Landroid/support/v4/util/SparseArrayCompat;->gc()V
    0007: iget v0, v1.Landroid/support/v4/util/SparseArrayCompat;->mSize:I
    0009: return v0

  [Virtual Method] valueAt(I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=1, insns_size=12
    0000: iget v0, v1.Landroid/support/v4/util/SparseArrayCompat;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v1}, Landroid/support/v4/util/SparseArrayCompat;->gc()V
    0007: iget v0, v1.Landroid/support/v4/util/SparseArrayCompat;->mValues:[Ljava/lang/Object;
    0009: aget(op=46) v0, v0[v2]
    000b: return-object v0