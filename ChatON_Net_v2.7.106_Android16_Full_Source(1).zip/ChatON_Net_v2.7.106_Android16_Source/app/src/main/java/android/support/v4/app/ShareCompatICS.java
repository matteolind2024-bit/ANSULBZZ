=== CLASS Landroid/support/v4/app/ShareCompatICS; (Source: ShareCompatICS.java) ===
  Super: Ljava/lang/Object;
  [Static Field] HISTORY_FILENAME_PREFIX: Ljava/lang/String; = '.sharecompat_'

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] configureMenuItem(Landroid/view/MenuItem;, Landroid/app/Activity;, Landroid/content/Intent;) -> V
    // registers=6, ins=3, outs=2, insns_size=53
    0000: invoke-interface {v3}, Landroid/view/MenuItem;->getActionProvider()Landroid/view/ActionProvider;
    0003: move-result-object v0
    0004: instance-of v1, v0, Landroid/widget/ShareActionProvider;
    0006: if-nez v1, 0032
    0008: new-instance v0, Landroid/widget/ShareActionProvider;
    000a: invoke-direct {v0, v4}, Landroid/widget/ShareActionProvider;-><init>(Landroid/content/Context;)V
    000d: new-instance v1, Ljava/lang/StringBuilder;
    000f: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0012: const-string v2, '.sharecompat_'
    0014: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0017: move-result-object v1
    0018: invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    001b: move-result-object v2
    001c: invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;
    001f: move-result-object v2
    0020: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0023: move-result-object v1
    0024: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0027: move-result-object v1
    0028: invoke-virtual {v0, v1}, Landroid/widget/ShareActionProvider;->setShareHistoryFileName(Ljava/lang/String;)V
    002b: invoke-virtual {v0, v5}, Landroid/widget/ShareActionProvider;->setShareIntent(Landroid/content/Intent;)V
    002e: invoke-interface {v3, v0}, Landroid/view/MenuItem;->setActionProvider(Landroid/view/ActionProvider;)Landroid/view/MenuItem;
    0031: return-void
    0032: check-cast v0, Landroid/widget/ShareActionProvider;
    0034: goto 000d