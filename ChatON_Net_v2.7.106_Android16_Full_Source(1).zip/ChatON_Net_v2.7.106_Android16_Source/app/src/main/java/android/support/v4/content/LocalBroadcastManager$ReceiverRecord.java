=== CLASS Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord; (Source: LocalBroadcastManager.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] broadcasting: Z
  [Instance Field] filter: Landroid/content/IntentFilter;
  [Instance Field] receiver: Landroid/content/BroadcastReceiver;

  [Direct Method] <init>(Landroid/content/IntentFilter;, Landroid/content/BroadcastReceiver;) -> V
    // registers=3, ins=3, outs=1, insns_size=8
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;->filter:Landroid/content/IntentFilter;
    0005: iput v2, v0.Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;->receiver:Landroid/content/BroadcastReceiver;
    0007: return-void

  [Virtual Method] toString() -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=37
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: const/16 v1, 128 (0x80)
    0004: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V
    0007: const-string v1, 'Receiver{'
    0009: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000c: iget v1, v2.Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;->receiver:Landroid/content/BroadcastReceiver;
    000e: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0011: const-string v1, ' filter='
    0013: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0016: iget v1, v2.Landroid/support/v4/content/LocalBroadcastManager$ReceiverRecord;->filter:Landroid/content/IntentFilter;
    0018: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    001b: const-string v1, '}'
    001d: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0020: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0023: move-result-object v0
    0024: return-object v0