=== CLASS Landroid/support/v4/view/ViewPager$LayoutParams; (Source: ViewPager.java) ===
  Super: Landroid/view/ViewGroup$LayoutParams;
  [Instance Field] gravity: I
  [Instance Field] isDecor: Z
  [Instance Field] needsMeasure: Z
  [Instance Field] widthFactor: F

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=3, insns_size=8
    0000: const/4 v0, -1
    0001: invoke-direct {v1, v0, v0}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V
    0004: const/4 v0, 0
    0005: iput v0, v1.Landroid/support/v4/view/ViewPager$LayoutParams;->widthFactor:F
    0007: return-void

  [Direct Method] <init>(Landroid/content/Context;, Landroid/util/AttributeSet;) -> V
    // registers=6, ins=3, outs=3, insns_size=27
    0000: invoke-direct {v3, v4, v5}, Landroid/view/ViewGroup$LayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    0003: const/4 v0, 0
    0004: iput v0, v3.Landroid/support/v4/view/ViewPager$LayoutParams;->widthFactor:F
    0006: invoke-static {}, Landroid/support/v4/view/ViewPager;->access$300()[I
    0009: move-result-object v0
    000a: invoke-virtual {v4, v5, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    000d: move-result-object v0
    000e: const/4 v1, 0
    000f: const/16 v2, 48 (0x30)
    0011: invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getInteger(II)I
    0014: move-result v1
    0015: iput v1, v3.Landroid/support/v4/view/ViewPager$LayoutParams;->gravity:I
    0017: invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V
    001a: return-void