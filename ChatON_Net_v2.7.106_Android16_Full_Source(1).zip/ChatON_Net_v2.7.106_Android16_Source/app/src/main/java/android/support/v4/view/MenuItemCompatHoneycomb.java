=== CLASS Landroid/support/v4/view/MenuItemCompatHoneycomb; (Source: MenuItemCompatHoneycomb.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] setActionView(Landroid/view/MenuItem;, Landroid/view/View;) -> Landroid/view/MenuItem;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-interface {v1, v2}, Landroid/view/MenuItem;->setActionView(Landroid/view/View;)Landroid/view/MenuItem;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] setShowAsAction(Landroid/view/MenuItem;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-interface {v0, v1}, Landroid/view/MenuItem;->setShowAsAction(I)V
    0003: return-void