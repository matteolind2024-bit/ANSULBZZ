=== CLASS Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs; (Source: AccessibilityManagerCompatIcs.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] addAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager;, Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v2, Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;
    0002: invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityManager;->addAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;)Z
    0005: move-result v0
    0006: return v0

  [Direct Method] getEnabledAccessibilityServiceList(Landroid/view/accessibility/AccessibilityManager;, I) -> Ljava/util/List;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityManager;->getEnabledAccessibilityServiceList(I)Ljava/util/List;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] getInstalledAccessibilityServiceList(Landroid/view/accessibility/AccessibilityManager;) -> Ljava/util/List;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityManager;->getInstalledAccessibilityServiceList()Ljava/util/List;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] isTouchExplorationEnabled(Landroid/view/accessibility/AccessibilityManager;) -> Z
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityManager;->isTouchExplorationEnabled()Z
    0003: move-result v0
    0004: return v0

  [Direct Method] newAccessibilityStateChangeListener(Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge;) -> Ljava/lang/Object;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$1;
    0002: invoke-direct {v0, v1}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$1;-><init>(Landroid/support/v4/view/accessibility/AccessibilityManagerCompatIcs$AccessibilityStateChangeListenerBridge;)V
    0005: return-object v0

  [Direct Method] removeAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager;, Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v2, Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;
    0002: invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityManager;->removeAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;)Z
    0005: move-result v0
    0006: return v0