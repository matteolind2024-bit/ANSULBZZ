=== CLASS Landroid/support/v4/content/ModernAsyncTask$WorkerRunnable; (Source: ModernAsyncTask.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/util/concurrent/Callable;
  [Instance Field] mParams: [Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] <init>(Landroid/support/v4/content/ModernAsyncTask$1;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/content/ModernAsyncTask$WorkerRunnable;-><init>()V
    0003: return-void