=== CLASS Landroid/support/v4/view/PagerTitleStripIcs$SingleLineAllCapsTransform; (Source: PagerTitleStripIcs.java) ===
  Super: Landroid/text/method/SingleLineTransformationMethod;
  [Static Field] TAG: Ljava/lang/String; = 'SingleLineAllCapsTransform'
  [Instance Field] mLocale: Ljava/util/Locale;

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=3, ins=2, outs=1, insns_size=16
    0000: invoke-direct {v1}, Landroid/text/method/SingleLineTransformationMethod;-><init>()V
    0003: invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    0006: move-result-object v0
    0007: invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;
    000a: move-result-object v0
    000b: iget v0, v0.Landroid/content/res/Configuration;->locale:Ljava/util/Locale;
    000d: iput v0, v1.Landroid/support/v4/view/PagerTitleStripIcs$SingleLineAllCapsTransform;->mLocale:Ljava/util/Locale;
    000f: return-void

  [Virtual Method] getTransformation(Ljava/lang/CharSequence;, Landroid/view/View;) -> Ljava/lang/CharSequence;
    // registers=5, ins=3, outs=3, insns_size=19
    0000: invoke-super {v2, v3, v4}, Landroid/text/method/SingleLineTransformationMethod;->getTransformation(Ljava/lang/CharSequence;Landroid/view/View;)Ljava/lang/CharSequence;
    0003: move-result-object v0
    0004: if-eqz v0, 0011
    0006: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0009: move-result-object v0
    000a: iget v1, v2.Landroid/support/v4/view/PagerTitleStripIcs$SingleLineAllCapsTransform;->mLocale:Ljava/util/Locale;
    000c: invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;
    000f: move-result-object v0
    0010: return-object v0
    0011: const/4 v0, 0
    0012: goto 0010