=== CLASS Landroid/support/v4/app/ShareCompat$IntentReader; (Source: ShareCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] TAG: Ljava/lang/String; = 'IntentReader'
  [Instance Field] mActivity: Landroid/app/Activity;
  [Instance Field] mCallingActivity: Landroid/content/ComponentName;
  [Instance Field] mCallingPackage: Ljava/lang/String;
  [Instance Field] mIntent: Landroid/content/Intent;
  [Instance Field] mStreams: Ljava/util/ArrayList;

  [Direct Method] <init>(Landroid/app/Activity;) -> V
    // registers=3, ins=2, outs=1, insns_size=24
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: iput v2, v1.Landroid/support/v4/app/ShareCompat$IntentReader;->mActivity:Landroid/app/Activity;
    0005: invoke-virtual {v2}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;
    0008: move-result-object v0
    0009: iput v0, v1.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    000b: invoke-static {v2}, Landroid/support/v4/app/ShareCompat;->getCallingPackage(Landroid/app/Activity;)Ljava/lang/String;
    000e: move-result-object v0
    000f: iput v0, v1.Landroid/support/v4/app/ShareCompat$IntentReader;->mCallingPackage:Ljava/lang/String;
    0011: invoke-static {v2}, Landroid/support/v4/app/ShareCompat;->getCallingActivity(Landroid/app/Activity;)Landroid/content/ComponentName;
    0014: move-result-object v0
    0015: iput v0, v1.Landroid/support/v4/app/ShareCompat$IntentReader;->mCallingActivity:Landroid/content/ComponentName;
    0017: return-void

  [Direct Method] from(Landroid/app/Activity;) -> Landroid/support/v4/app/ShareCompat$IntentReader;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Landroid/support/v4/app/ShareCompat$IntentReader;
    0002: invoke-direct {v0, v1}, Landroid/support/v4/app/ShareCompat$IntentReader;-><init>(Landroid/app/Activity;)V
    0005: return-object v0

  [Virtual Method] getCallingActivity() -> Landroid/content/ComponentName;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentReader;->mCallingActivity:Landroid/content/ComponentName;
    0002: return-object v0

  [Virtual Method] getCallingActivityIcon() -> Landroid/graphics/drawable/Drawable;
    // registers=5, ins=1, outs=3, insns_size=28
    0000: const/4 v0, 0
    0001: iget v1, v4.Landroid/support/v4/app/ShareCompat$IntentReader;->mCallingActivity:Landroid/content/ComponentName;
    0003: if-nez v1, 0006
    0005: return-object v0
    0006: iget v1, v4.Landroid/support/v4/app/ShareCompat$IntentReader;->mActivity:Landroid/app/Activity;
    0008: invoke-virtual {v1}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;
    000b: move-result-object v1
    000c: iget v2, v4.Landroid/support/v4/app/ShareCompat$IntentReader;->mCallingActivity:Landroid/content/ComponentName;
    000e: invoke-virtual {v1, v2}, Landroid/content/pm/PackageManager;->getActivityIcon(Landroid/content/ComponentName;)Landroid/graphics/drawable/Drawable;
    0011: move-result-object v0
    0012: goto 0005
    0013: move-exception v1
    0014: const-string v2, 'IntentReader'
    0016: const-string v3, 'Could not retrieve icon for calling activity'
    0018: invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    001b: goto 0005

  [Virtual Method] getCallingApplicationIcon() -> Landroid/graphics/drawable/Drawable;
    // registers=5, ins=1, outs=3, insns_size=28
    0000: const/4 v0, 0
    0001: iget v1, v4.Landroid/support/v4/app/ShareCompat$IntentReader;->mCallingPackage:Ljava/lang/String;
    0003: if-nez v1, 0006
    0005: return-object v0
    0006: iget v1, v4.Landroid/support/v4/app/ShareCompat$IntentReader;->mActivity:Landroid/app/Activity;
    0008: invoke-virtual {v1}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;
    000b: move-result-object v1
    000c: iget v2, v4.Landroid/support/v4/app/ShareCompat$IntentReader;->mCallingPackage:Ljava/lang/String;
    000e: invoke-virtual {v1, v2}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    0011: move-result-object v0
    0012: goto 0005
    0013: move-exception v1
    0014: const-string v2, 'IntentReader'
    0016: const-string v3, 'Could not retrieve icon for calling application'
    0018: invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    001b: goto 0005

  [Virtual Method] getCallingApplicationLabel() -> Ljava/lang/CharSequence;
    // registers=5, ins=1, outs=3, insns_size=33
    0000: const/4 v0, 0
    0001: iget v1, v4.Landroid/support/v4/app/ShareCompat$IntentReader;->mCallingPackage:Ljava/lang/String;
    0003: if-nez v1, 0006
    0005: return-object v0
    0006: iget v1, v4.Landroid/support/v4/app/ShareCompat$IntentReader;->mActivity:Landroid/app/Activity;
    0008: invoke-virtual {v1}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;
    000b: move-result-object v1
    000c: iget v2, v4.Landroid/support/v4/app/ShareCompat$IntentReader;->mCallingPackage:Ljava/lang/String;
    000e: const/4 v3, 0
    000f: invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    0012: move-result-object v2
    0013: invoke-virtual {v1, v2}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;
    0016: move-result-object v0
    0017: goto 0005
    0018: move-exception v1
    0019: const-string v2, 'IntentReader'
    001b: const-string v3, 'Could not retrieve label for calling application'
    001d: invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    0020: goto 0005

  [Virtual Method] getCallingPackage() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentReader;->mCallingPackage:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] getEmailBcc() -> [Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=9
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.BCC'
    0004: invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] getEmailCc() -> [Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=9
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.CC'
    0004: invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] getEmailTo() -> [Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=9
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.EMAIL'
    0004: invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] getHtmlText() -> Ljava/lang/String;
    // registers=4, ins=1, outs=2, insns_size=40
    0000: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.HTML_TEXT'
    0004: invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    0007: move-result-object v1
    0008: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    000a: if-nez v0, 0026
    000c: invoke-virtual {v3}, Landroid/support/v4/app/ShareCompat$IntentReader;->getText()Ljava/lang/CharSequence;
    000f: move-result-object v0
    0010: instance-of v2, v0, Landroid/text/Spanned;
    0012: if-eqz v2, 001b
    0014: check-cast v0, Landroid/text/Spanned;
    0016: invoke-static {v0}, Landroid/text/Html;->toHtml(Landroid/text/Spanned;)Ljava/lang/String;
    0019: move-result-object v0
    001a: return-object v0
    001b: if-eqz v0, 0026
    001d: invoke-static {}, Landroid/support/v4/app/ShareCompat;->access$000()Landroid/support/v4/app/ShareCompat$ShareCompatImpl;
    0020: move-result-object v1
    0021: invoke-interface {v1, v0}, Landroid/support/v4/app/ShareCompat$ShareCompatImpl;->escapeHtml(Ljava/lang/CharSequence;)Ljava/lang/String;
    0024: move-result-object v0
    0025: goto 001a
    0026: move(op=07) v0, v1
    0027: goto 001a

  [Virtual Method] getStream() -> Landroid/net/Uri;
    // registers=3, ins=1, outs=2, insns_size=11
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.STREAM'
    0004: invoke-virtual {v0, v1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;
    0007: move-result-object v0
    0008: check-cast v0, Landroid/net/Uri;
    000a: return-object v0

  [Virtual Method] getStream(I) -> Landroid/net/Uri;
    // registers=5, ins=2, outs=2, insns_size=85
    0000: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentReader;->mStreams:Ljava/util/ArrayList;
    0002: if-nez v0, 0014
    0004: invoke-virtual {v3}, Landroid/support/v4/app/ShareCompat$IntentReader;->isMultipleShare()Z
    0007: move-result v0
    0008: if-eqz v0, 0014
    000a: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    000c: const-string v1, 'android.intent.extra.STREAM'
    000e: invoke-virtual {v0, v1}, Landroid/content/Intent;->getParcelableArrayListExtra(Ljava/lang/String;)Ljava/util/ArrayList;
    0011: move-result-object v0
    0012: iput v0, v3.Landroid/support/v4/app/ShareCompat$IntentReader;->mStreams:Ljava/util/ArrayList;
    0014: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentReader;->mStreams:Ljava/util/ArrayList;
    0016: if-eqz v0, 0021
    0018: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentReader;->mStreams:Ljava/util/ArrayList;
    001a: invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    001d: move-result-object v0
    001e: check-cast v0, Landroid/net/Uri;
    0020: return-object v0
    0021: if-nez v4, 002e
    0023: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0025: const-string v1, 'android.intent.extra.STREAM'
    0027: invoke-virtual {v0, v1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;
    002a: move-result-object v0
    002b: check-cast v0, Landroid/net/Uri;
    002d: goto 0020
    002e: new-instance v0, Ljava/lang/IndexOutOfBoundsException;
    0030: new-instance v1, Ljava/lang/StringBuilder;
    0032: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0035: const-string v2, 'Stream items available: '
    0037: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003a: move-result-object v1
    003b: invoke-virtual {v3}, Landroid/support/v4/app/ShareCompat$IntentReader;->getStreamCount()I
    003e: move-result v2
    003f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0042: move-result-object v1
    0043: const-string v2, ' index requested: '
    0045: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0048: move-result-object v1
    0049: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    004c: move-result-object v1
    004d: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0050: move-result-object v1
    0051: invoke-direct {v0, v1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    0054: throw v0

  [Virtual Method] getStreamCount() -> I
    // registers=3, ins=1, outs=2, insns_size=45
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mStreams:Ljava/util/ArrayList;
    0002: if-nez v0, 0014
    0004: invoke-virtual {v2}, Landroid/support/v4/app/ShareCompat$IntentReader;->isMultipleShare()Z
    0007: move-result v0
    0008: if-eqz v0, 0014
    000a: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    000c: const-string v1, 'android.intent.extra.STREAM'
    000e: invoke-virtual {v0, v1}, Landroid/content/Intent;->getParcelableArrayListExtra(Ljava/lang/String;)Ljava/util/ArrayList;
    0011: move-result-object v0
    0012: iput v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mStreams:Ljava/util/ArrayList;
    0014: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mStreams:Ljava/util/ArrayList;
    0016: if-eqz v0, 001f
    0018: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mStreams:Ljava/util/ArrayList;
    001a: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    001d: move-result v0
    001e: return v0
    001f: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0021: const-string v1, 'android.intent.extra.STREAM'
    0023: invoke-virtual {v0, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z
    0026: move-result v0
    0027: if-eqz v0, 002b
    0029: const/4 v0, 1
    002a: goto 001e
    002b: const/4 v0, 0
    002c: goto 001e

  [Virtual Method] getSubject() -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=9
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.SUBJECT'
    0004: invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] getText() -> Ljava/lang/CharSequence;
    // registers=3, ins=1, outs=2, insns_size=9
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.TEXT'
    0004: invoke-virtual {v0, v1}, Landroid/content/Intent;->getCharSequenceExtra(Ljava/lang/String;)Ljava/lang/CharSequence;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] getType() -> Ljava/lang/String;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0002: invoke-virtual {v0}, Landroid/content/Intent;->getType()Ljava/lang/String;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] isMultipleShare() -> Z
    // registers=3, ins=1, outs=2, insns_size=13
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0002: invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0005: move-result-object v0
    0006: const-string v1, 'android.intent.action.SEND_MULTIPLE'
    0008: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    000b: move-result v0
    000c: return v0

  [Virtual Method] isShareIntent() -> Z
    // registers=3, ins=1, outs=2, insns_size=26
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0002: invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0005: move-result-object v0
    0006: const-string v1, 'android.intent.action.SEND'
    0008: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    000b: move-result v1
    000c: if-nez v1, 0016
    000e: const-string v1, 'android.intent.action.SEND_MULTIPLE'
    0010: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0013: move-result v0
    0014: if-eqz v0, 0018
    0016: const/4 v0, 1
    0017: return v0
    0018: const/4 v0, 0
    0019: goto 0017

  [Virtual Method] isSingleShare() -> Z
    // registers=3, ins=1, outs=2, insns_size=13
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentReader;->mIntent:Landroid/content/Intent;
    0002: invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0005: move-result-object v0
    0006: const-string v1, 'android.intent.action.SEND'
    0008: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    000b: move-result v0
    000c: return v0