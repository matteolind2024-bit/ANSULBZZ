=== CLASS Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatStubImpl; (Source: ViewGroupCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> Z
    // registers=5, ins=4, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0