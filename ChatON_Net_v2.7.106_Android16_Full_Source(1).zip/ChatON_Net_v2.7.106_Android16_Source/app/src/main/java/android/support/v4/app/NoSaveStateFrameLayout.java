=== CLASS Landroid/support/v4/app/NoSaveStateFrameLayout; (Source: NoSaveStateFrameLayout.java) ===
  Super: Landroid/widget/FrameLayout;

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V
    0003: return-void

  [Direct Method] wrap(Landroid/view/View;) -> Landroid/view/ViewGroup;
    // registers=4, ins=1, outs=3, insns_size=31
    0000: const/4 v2, -1
    0001: new-instance v0, Landroid/support/v4/app/NoSaveStateFrameLayout;
    0003: invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;
    0006: move-result-object v1
    0007: invoke-direct {v0, v1}, Landroid/support/v4/app/NoSaveStateFrameLayout;-><init>(Landroid/content/Context;)V
    000a: invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    000d: move-result-object v1
    000e: if-eqz v1, 0013
    0010: invoke-virtual {v0, v1}, Landroid/support/v4/app/NoSaveStateFrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    0013: new-instance v1, Landroid/widget/FrameLayout$LayoutParams;
    0015: invoke-direct {v1, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V
    0018: invoke-virtual {v3, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    001b: invoke-virtual {v0, v3}, Landroid/support/v4/app/NoSaveStateFrameLayout;->addView(Landroid/view/View;)V
    001e: return-object v0

  [Virtual Method] dispatchRestoreInstanceState(Landroid/util/SparseArray;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/support/v4/app/NoSaveStateFrameLayout;->dispatchThawSelfOnly(Landroid/util/SparseArray;)V
    0003: return-void

  [Virtual Method] dispatchSaveInstanceState(Landroid/util/SparseArray;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/support/v4/app/NoSaveStateFrameLayout;->dispatchFreezeSelfOnly(Landroid/util/SparseArray;)V
    0003: return-void