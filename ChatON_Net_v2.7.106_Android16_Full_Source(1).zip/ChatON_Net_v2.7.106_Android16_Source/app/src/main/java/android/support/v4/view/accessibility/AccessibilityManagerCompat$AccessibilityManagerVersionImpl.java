=== CLASS Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerVersionImpl; (Source: AccessibilityManagerCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] addAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager;, Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;) -> Z

  [Virtual Method] getEnabledAccessibilityServiceList(Landroid/view/accessibility/AccessibilityManager;, I) -> Ljava/util/List;

  [Virtual Method] getInstalledAccessibilityServiceList(Landroid/view/accessibility/AccessibilityManager;) -> Ljava/util/List;

  [Virtual Method] isTouchExplorationEnabled(Landroid/view/accessibility/AccessibilityManager;) -> Z

  [Virtual Method] newAccessiblityStateChangeListener(Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;) -> Ljava/lang/Object;

  [Virtual Method] removeAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager;, Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;) -> Z