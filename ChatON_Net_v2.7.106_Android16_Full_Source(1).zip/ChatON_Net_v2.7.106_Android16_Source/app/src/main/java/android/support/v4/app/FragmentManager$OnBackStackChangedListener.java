=== CLASS Landroid/support/v4/app/FragmentManager$OnBackStackChangedListener; (Source: FragmentManager.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] onBackStackChanged() -> V