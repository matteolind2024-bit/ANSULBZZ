=== CLASS Landroid/support/v4/app/FragmentManagerImpl; (Source: FragmentManager.java) ===
  Super: Landroid/support/v4/app/FragmentManager;
  [Static Field] ACCELERATE_CUBIC: Landroid/view/animation/Interpolator; = None
  [Static Field] ACCELERATE_QUINT: Landroid/view/animation/Interpolator; = None
  [Static Field] ANIM_DUR: I = 220
  [Static Field] ANIM_STYLE_CLOSE_ENTER: I = 3
  [Static Field] ANIM_STYLE_CLOSE_EXIT: I = 4
  [Static Field] ANIM_STYLE_FADE_ENTER: I = 5
  [Static Field] ANIM_STYLE_FADE_EXIT: I = 6
  [Static Field] ANIM_STYLE_OPEN_ENTER: I = 1
  [Static Field] ANIM_STYLE_OPEN_EXIT: I = 2
  [Static Field] DEBUG: Z = False
  [Static Field] DECELERATE_CUBIC: Landroid/view/animation/Interpolator; = None
  [Static Field] DECELERATE_QUINT: Landroid/view/animation/Interpolator; = None
  [Static Field] HONEYCOMB: Z = False
  [Static Field] TAG: Ljava/lang/String; = 'FragmentManager'
  [Static Field] TARGET_REQUEST_CODE_STATE_TAG: Ljava/lang/String; = 'android:target_req_state'
  [Static Field] TARGET_STATE_TAG: Ljava/lang/String; = 'android:target_state'
  [Static Field] USER_VISIBLE_HINT_TAG: Ljava/lang/String; = 'android:user_visible_hint'
  [Static Field] VIEW_STATE_TAG: Ljava/lang/String; = 'android:view_state'
  [Instance Field] mActive: Ljava/util/ArrayList;
  [Instance Field] mActivity: Landroid/support/v4/app/FragmentActivity;
  [Instance Field] mAdded: Ljava/util/ArrayList;
  [Instance Field] mAvailBackStackIndices: Ljava/util/ArrayList;
  [Instance Field] mAvailIndices: Ljava/util/ArrayList;
  [Instance Field] mBackStack: Ljava/util/ArrayList;
  [Instance Field] mBackStackChangeListeners: Ljava/util/ArrayList;
  [Instance Field] mBackStackIndices: Ljava/util/ArrayList;
  [Instance Field] mCreatedMenus: Ljava/util/ArrayList;
  [Instance Field] mCurState: I
  [Instance Field] mDestroyed: Z
  [Instance Field] mExecCommit: Ljava/lang/Runnable;
  [Instance Field] mExecutingActions: Z
  [Instance Field] mHavePendingDeferredStart: Z
  [Instance Field] mNeedMenuInvalidate: Z
  [Instance Field] mNoTransactionsBecause: Ljava/lang/String;
  [Instance Field] mPendingActions: Ljava/util/ArrayList;
  [Instance Field] mStateArray: Landroid/util/SparseArray;
  [Instance Field] mStateBundle: Landroid/os/Bundle;
  [Instance Field] mStateSaved: Z
  [Instance Field] mTmpActions: [Ljava/lang/Runnable;

  [Direct Method] <clinit>() -> V
    // registers=5, ins=0, outs=2, insns_size=45
    0000: const/4 v0, 0
    0001: const/high16 v4, 1075838976 (0x40200000)
    0003: const/high16 v3, 1069547520 (0x3fc00000)
    0005: sput v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0007: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    0009: const/16 v2, 11 (0xb)
    000b: if-lt v1, v2, 000e
    000d: const/4 v0, 1
    000e: sput v0, Landroid/support/v4/app/FragmentManagerImpl;->HONEYCOMB:Z
    0010: new-instance v0, Landroid/view/animation/DecelerateInterpolator;
    0012: invoke-direct {v0, v4}, Landroid/view/animation/DecelerateInterpolator;-><init>(F)V
    0015: sput v0, Landroid/support/v4/app/FragmentManagerImpl;->DECELERATE_QUINT:Landroid/view/animation/Interpolator;
    0017: new-instance v0, Landroid/view/animation/DecelerateInterpolator;
    0019: invoke-direct {v0, v3}, Landroid/view/animation/DecelerateInterpolator;-><init>(F)V
    001c: sput v0, Landroid/support/v4/app/FragmentManagerImpl;->DECELERATE_CUBIC:Landroid/view/animation/Interpolator;
    001e: new-instance v0, Landroid/view/animation/AccelerateInterpolator;
    0020: invoke-direct {v0, v4}, Landroid/view/animation/AccelerateInterpolator;-><init>(F)V
    0023: sput v0, Landroid/support/v4/app/FragmentManagerImpl;->ACCELERATE_QUINT:Landroid/view/animation/Interpolator;
    0025: new-instance v0, Landroid/view/animation/AccelerateInterpolator;
    0027: invoke-direct {v0, v3}, Landroid/view/animation/AccelerateInterpolator;-><init>(F)V
    002a: sput v0, Landroid/support/v4/app/FragmentManagerImpl;->ACCELERATE_CUBIC:Landroid/view/animation/Interpolator;
    002c: return-void

  [Direct Method] <init>() -> V
    // registers=3, ins=1, outs=2, insns_size=19
    0000: const/4 v1, 0
    0001: invoke-direct {v2}, Landroid/support/v4/app/FragmentManager;-><init>()V
    0004: const/4 v0, 0
    0005: iput v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mCurState:I
    0007: iput v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateBundle:Landroid/os/Bundle;
    0009: iput v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateArray:Landroid/util/SparseArray;
    000b: new-instance v0, Landroid/support/v4/app/FragmentManagerImpl$1;
    000d: invoke-direct {v0, v2}, Landroid/support/v4/app/FragmentManagerImpl$1;-><init>(Landroid/support/v4/app/FragmentManagerImpl;)V
    0010: iput v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mExecCommit:Ljava/lang/Runnable;
    0012: return-void

  [Direct Method] checkStateLoss() -> V
    // registers=4, ins=1, outs=2, insns_size=44
    0000: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mStateSaved:Z
    0002: if-eqz v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'Can not perform this action after onSaveInstanceState'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    000e: if-eqz v0, 002b
    0010: new-instance v0, Ljava/lang/IllegalStateException;
    0012: new-instance v1, Ljava/lang/StringBuilder;
    0014: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0017: const-string v2, 'Can not perform this action inside of '
    0019: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: move-result-object v1
    001d: iget v2, v3.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    001f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0022: move-result-object v1
    0023: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0026: move-result-object v1
    0027: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    002a: throw v0
    002b: return-void

  [Direct Method] makeFadeAnimation(Landroid/content/Context;, F, F) -> Landroid/view/animation/Animation;
    // registers=6, ins=3, outs=3, insns_size=16
    0000: new-instance v0, Landroid/view/animation/AlphaAnimation;
    0002: invoke-direct {v0, v4, v5}, Landroid/view/animation/AlphaAnimation;-><init>(FF)V
    0005: sget v1, Landroid/support/v4/app/FragmentManagerImpl;->DECELERATE_CUBIC:Landroid/view/animation/Interpolator;
    0007: invoke-virtual {v0, v1}, Landroid/view/animation/AlphaAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V
    000a: const-wide/16 v1, 220
    000c: invoke-virtual {v0, v1, v2}, Landroid/view/animation/AlphaAnimation;->setDuration(J)V
    000f: return-object v0

  [Direct Method] makeOpenCloseAnimation(Landroid/content/Context;, F, F, F, F) -> Landroid/view/animation/Animation;
    // registers=15, ins=5, outs=9, insns_size=53
    0000: new-instance v9, Landroid/view/animation/AnimationSet;
    0002: const/4 v0, 0
    0003: invoke-direct {v9, v0}, Landroid/view/animation/AnimationSet;-><init>(Z)V
    0006: new-instance v0, Landroid/view/animation/ScaleAnimation;
    0008: const/4 v5, 1
    0009: const/high16 v6, 1056964608 (0x3f000000)
    000b: const/4 v7, 1
    000c: const/high16 v8, 1056964608 (0x3f000000)
    000e: move(op=01) v1, v11
    000f: move(op=01) v2, v12
    0010: move(op=01) v3, v11
    0011: move(op=01) v4, v12
    0012: invoke-direct/range {v0..v8}, Landroid/view/animation/ScaleAnimation;-><init>(FFFFIFIF)V
    0015: sget v1, Landroid/support/v4/app/FragmentManagerImpl;->DECELERATE_QUINT:Landroid/view/animation/Interpolator;
    0017: invoke-virtual {v0, v1}, Landroid/view/animation/ScaleAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V
    001a: const-wide/16 v1, 220
    001c: invoke-virtual {v0, v1, v2}, Landroid/view/animation/ScaleAnimation;->setDuration(J)V
    001f: invoke-virtual {v9, v0}, Landroid/view/animation/AnimationSet;->addAnimation(Landroid/view/animation/Animation;)V
    0022: new-instance v0, Landroid/view/animation/AlphaAnimation;
    0024: invoke-direct {v0, v13, v14}, Landroid/view/animation/AlphaAnimation;-><init>(FF)V
    0027: sget v1, Landroid/support/v4/app/FragmentManagerImpl;->DECELERATE_CUBIC:Landroid/view/animation/Interpolator;
    0029: invoke-virtual {v0, v1}, Landroid/view/animation/AlphaAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V
    002c: const-wide/16 v1, 220
    002e: invoke-virtual {v0, v1, v2}, Landroid/view/animation/AlphaAnimation;->setDuration(J)V
    0031: invoke-virtual {v9, v0}, Landroid/view/animation/AnimationSet;->addAnimation(Landroid/view/animation/Animation;)V
    0034: return-object v9

  [Direct Method] reverseTransit(I) -> I
    // registers=2, ins=1, outs=0, insns_size=28
    0000: const/4 v0, 0
    0001: sparse-switch v1, +13 (-> 000e)
    0004: return v0
    0005: const/16 v0, 8194 (0x2002)
    0007: goto 0004
    0008: const/16 v0, 4097 (0x1001)
    000a: goto 0004
    000b: const/16 v0, 4099 (0x1003)
    000d: goto 0004
    000e: sparse-switch-payload {4097: 4, 4099: 10, 8194: 7}

  [Direct Method] transitToStyleIndex(I, Z) -> I
    // registers=3, ins=2, outs=0, insns_size=38
    0000: const/4 v0, -1
    0001: sparse-switch v1, +23 (-> 0018)
    0004: return v0
    0005: if-eqz v2, 0009
    0007: const/4 v0, 1
    0008: goto 0004
    0009: const/4 v0, 2
    000a: goto 0004
    000b: if-eqz v2, 000f
    000d: const/4 v0, 3
    000e: goto 0004
    000f: const/4 v0, 4
    0010: goto 0004
    0011: if-eqz v2, 0015
    0013: const/4 v0, 5
    0014: goto 0004
    0015: const/4 v0, 6
    0016: goto 0004
    0017: nop
    0018: sparse-switch-payload {4097: 4, 4099: 16, 8194: 10}

  [Virtual Method] addBackStackState(Landroid/support/v4/app/BackStackRecord;) -> V
    // registers=3, ins=2, outs=2, insns_size=20
    0000: iget v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0002: if-nez v0, 000b
    0004: new-instance v0, Ljava/util/ArrayList;
    0006: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0009: iput v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    000b: iget v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    000d: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0010: invoke-virtual {v1}, Landroid/support/v4/app/FragmentManagerImpl;->reportBackStackChanged()V
    0013: return-void

  [Virtual Method] addFragment(Landroid/support/v4/app/Fragment;, Z) -> V
    // registers=7, ins=3, outs=2, insns_size=73
    0000: const/4 v3, 1
    0001: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0003: if-nez v0, 000c
    0005: new-instance v0, Ljava/util/ArrayList;
    0007: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    000a: iput v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    000c: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    000e: if-eqz v0, 0028
    0010: const-string v0, 'FragmentManager'
    0012: new-instance v1, Ljava/lang/StringBuilder;
    0014: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0017: const-string v2, 'add: '
    0019: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: move-result-object v1
    001d: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0020: move-result-object v1
    0021: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0024: move-result-object v1
    0025: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0028: invoke-virtual {v4, v5}, Landroid/support/v4/app/FragmentManagerImpl;->makeActive(Landroid/support/v4/app/Fragment;)V
    002b: iget v0, v5.Landroid/support/v4/app/Fragment;->mDetached:Z
    002d: if-nez v0, 0048
    002f: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0031: invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0034: iput v3, v5.Landroid/support/v4/app/Fragment;->mAdded:Z
    0036: const/4 v0, 0
    0037: iput v0, v5.Landroid/support/v4/app/Fragment;->mRemoving:Z
    0039: iget v0, v5.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    003b: if-eqz v0, 0043
    003d: iget v0, v5.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    003f: if-eqz v0, 0043
    0041: iput v3, v4.Landroid/support/v4/app/FragmentManagerImpl;->mNeedMenuInvalidate:Z
    0043: if-eqz v6, 0048
    0045: invoke-virtual {v4, v5}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(Landroid/support/v4/app/Fragment;)V
    0048: return-void

  [Virtual Method] addOnBackStackChangedListener(Landroid/support/v4/app/FragmentManager$OnBackStackChangedListener;) -> V
    // registers=3, ins=2, outs=2, insns_size=17
    0000: iget v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackChangeListeners:Ljava/util/ArrayList;
    0002: if-nez v0, 000b
    0004: new-instance v0, Ljava/util/ArrayList;
    0006: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0009: iput v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackChangeListeners:Ljava/util/ArrayList;
    000b: iget v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackChangeListeners:Ljava/util/ArrayList;
    000d: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0010: return-void

  [Virtual Method] allocBackStackIndex(Landroid/support/v4/app/BackStackRecord;) -> I
    // registers=6, ins=2, outs=3, insns_size=143
    0000: monitor-enter v4
    0001: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    0003: if-eqz v0, 000d
    0005: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    0007: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000a: move-result v0
    000b: if-gtz v0, 004b
    000d: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    000f: if-nez v0, 0018
    0011: new-instance v0, Ljava/util/ArrayList;
    0013: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0016: iput v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    0018: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    001a: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    001d: move-result v0
    001e: sget v1, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0020: if-eqz v1, 0044
    0022: const-string v1, 'FragmentManager'
    0024: new-instance v2, Ljava/lang/StringBuilder;
    0026: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0029: const-string v3, 'Setting back stack index '
    002b: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002e: move-result-object v2
    002f: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0032: move-result-object v2
    0033: const-string v3, ' to '
    0035: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0038: move-result-object v2
    0039: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    003c: move-result-object v2
    003d: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0040: move-result-object v2
    0041: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0044: iget v1, v4.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    0046: invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0049: monitor-exit v4
    004a: return v0
    004b: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    004d: iget v1, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    004f: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0052: move-result v1
    0053: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0055: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    0058: move-result-object v0
    0059: check-cast v0, Ljava/lang/Integer;
    005b: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    005e: move-result v0
    005f: sget v1, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0061: if-eqz v1, 0085
    0063: const-string v1, 'FragmentManager'
    0065: new-instance v2, Ljava/lang/StringBuilder;
    0067: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    006a: const-string v3, 'Adding back stack index '
    006c: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    006f: move-result-object v2
    0070: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0073: move-result-object v2
    0074: const-string v3, ' with '
    0076: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0079: move-result-object v2
    007a: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    007d: move-result-object v2
    007e: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0081: move-result-object v2
    0082: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0085: iget v1, v4.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    0087: invoke-virtual {v1, v0, v5}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;
    008a: monitor-exit v4
    008b: goto 004a
    008c: move-exception v0
    008d: monitor-exit v4
    008e: throw v0

  [Virtual Method] attachActivity(Landroid/support/v4/app/FragmentActivity;) -> V
    // registers=3, ins=2, outs=1, insns_size=13
    0000: iget v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0002: if-eqz v0, 000a
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V
    0009: throw v0
    000a: iput v2, v1.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    000c: return-void

  [Virtual Method] attachFragment(Landroid/support/v4/app/Fragment;, I, I) -> V
    // registers=10, ins=4, outs=6, insns_size=78
    0000: const/4 v3, 1
    0001: const/4 v5, 0
    0002: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0004: if-eqz v0, 001e
    0006: const-string v0, 'FragmentManager'
    0008: new-instance v1, Ljava/lang/StringBuilder;
    000a: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000d: const-string v2, 'attach: '
    000f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0016: move-result-object v1
    0017: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001a: move-result-object v1
    001b: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001e: iget v0, v7.Landroid/support/v4/app/Fragment;->mDetached:Z
    0020: if-eqz v0, 004d
    0022: iput v5, v7.Landroid/support/v4/app/Fragment;->mDetached:Z
    0024: iget v0, v7.Landroid/support/v4/app/Fragment;->mAdded:Z
    0026: if-nez v0, 004d
    0028: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    002a: if-nez v0, 0033
    002c: new-instance v0, Ljava/util/ArrayList;
    002e: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0031: iput v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0033: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0035: invoke-virtual {v0, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0038: iput v3, v7.Landroid/support/v4/app/Fragment;->mAdded:Z
    003a: iget v0, v7.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    003c: if-eqz v0, 0044
    003e: iget v0, v7.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    0040: if-eqz v0, 0044
    0042: iput v3, v6.Landroid/support/v4/app/FragmentManagerImpl;->mNeedMenuInvalidate:Z
    0044: iget v2, v6.Landroid/support/v4/app/FragmentManagerImpl;->mCurState:I
    0046: move(op=07) v0, v6
    0047: move(op=07) v1, v7
    0048: move(op=01) v3, v8
    0049: move(op=01) v4, v9
    004a: invoke-virtual/range {v0..v5}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(Landroid/support/v4/app/Fragment;IIIZ)V
    004d: return-void

  [Virtual Method] beginTransaction() -> Landroid/support/v4/app/FragmentTransaction;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Landroid/support/v4/app/BackStackRecord;
    0002: invoke-direct {v0, v1}, Landroid/support/v4/app/BackStackRecord;-><init>(Landroid/support/v4/app/FragmentManagerImpl;)V
    0005: return-object v0

  [Virtual Method] detachFragment(Landroid/support/v4/app/Fragment;, I, I) -> V
    // registers=10, ins=4, outs=6, insns_size=69
    0000: const/4 v5, 0
    0001: const/4 v2, 1
    0002: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0004: if-eqz v0, 001e
    0006: const-string v0, 'FragmentManager'
    0008: new-instance v1, Ljava/lang/StringBuilder;
    000a: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000d: const-string v3, 'detach: '
    000f: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0016: move-result-object v1
    0017: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001a: move-result-object v1
    001b: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001e: iget v0, v7.Landroid/support/v4/app/Fragment;->mDetached:Z
    0020: if-nez v0, 0044
    0022: iput v2, v7.Landroid/support/v4/app/Fragment;->mDetached:Z
    0024: iget v0, v7.Landroid/support/v4/app/Fragment;->mAdded:Z
    0026: if-eqz v0, 0044
    0028: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    002a: if-eqz v0, 0031
    002c: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    002e: invoke-virtual {v0, v7}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    0031: iget v0, v7.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    0033: if-eqz v0, 003b
    0035: iget v0, v7.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    0037: if-eqz v0, 003b
    0039: iput v2, v6.Landroid/support/v4/app/FragmentManagerImpl;->mNeedMenuInvalidate:Z
    003b: iput v5, v7.Landroid/support/v4/app/Fragment;->mAdded:Z
    003d: move(op=07) v0, v6
    003e: move(op=07) v1, v7
    003f: move(op=01) v3, v8
    0040: move(op=01) v4, v9
    0041: invoke-virtual/range {v0..v5}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(Landroid/support/v4/app/Fragment;IIIZ)V
    0044: return-void

  [Virtual Method] dispatchActivityCreated() -> V
    // registers=3, ins=1, outs=3, insns_size=8
    0000: const/4 v1, 0
    0001: iput v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateSaved:Z
    0003: const/4 v0, 2
    0004: invoke-virtual {v2, v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(IZ)V
    0007: return-void

  [Virtual Method] dispatchConfigurationChanged(Landroid/content/res/Configuration;) -> V
    // registers=4, ins=2, outs=2, insns_size=32
    0000: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0002: if-eqz v0, 001f
    0004: const/4 v0, 0
    0005: move(op=01) v1, v0
    0006: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0008: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000b: move-result v0
    000c: if-ge v1, v0, 001f
    000e: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0010: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0013: move-result-object v0
    0014: check-cast v0, Landroid/support/v4/app/Fragment;
    0016: if-eqz v0, 001b
    0018: invoke-virtual {v0, v3}, Landroid/support/v4/app/Fragment;->onConfigurationChanged(Landroid/content/res/Configuration;)V
    001b: binop/lit8(op=d8) v0, v1, 1 (0x1)
    001d: move(op=01) v1, v0
    001e: goto 0006
    001f: return-void

  [Virtual Method] dispatchContextItemSelected(Landroid/view/MenuItem;) -> Z
    // registers=6, ins=2, outs=2, insns_size=44
    0000: const/4 v2, 0
    0001: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0003: if-eqz v0, 0027
    0005: move(op=01) v1, v2
    0006: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0008: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000b: move-result v0
    000c: if-ge v1, v0, 0027
    000e: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0010: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0013: move-result-object v0
    0014: check-cast v0, Landroid/support/v4/app/Fragment;
    0016: if-eqz v0, 0028
    0018: iget v3, v0.Landroid/support/v4/app/Fragment;->mHidden:Z
    001a: if-nez v3, 0028
    001c: iget v3, v0.Landroid/support/v4/app/Fragment;->mUserVisibleHint:Z
    001e: if-eqz v3, 0028
    0020: invoke-virtual {v0, v5}, Landroid/support/v4/app/Fragment;->onContextItemSelected(Landroid/view/MenuItem;)Z
    0023: move-result v0
    0024: if-eqz v0, 0028
    0026: const/4 v2, 1
    0027: return v2
    0028: binop/lit8(op=d8) v0, v1, 1 (0x1)
    002a: move(op=01) v1, v0
    002b: goto 0006

  [Virtual Method] dispatchCreate() -> V
    // registers=3, ins=1, outs=3, insns_size=8
    0000: const/4 v1, 0
    0001: iput v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateSaved:Z
    0003: const/4 v0, 1
    0004: invoke-virtual {v2, v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(IZ)V
    0007: return-void

  [Virtual Method] dispatchCreateOptionsMenu(Landroid/view/Menu;, Landroid/view/MenuInflater;) -> Z
    // registers=9, ins=3, outs=3, insns_size=96
    0000: const/4 v4, 0
    0001: const/4 v1, 0
    0002: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0004: if-eqz v0, 003a
    0006: move(op=01) v3, v4
    0007: move(op=01) v2, v4
    0008: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    000a: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000d: move-result v0
    000e: if-ge v3, v0, 003b
    0010: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0012: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0015: move-result-object v0
    0016: check-cast v0, Landroid/support/v4/app/Fragment;
    0018: if-eqz v0, 0034
    001a: iget v5, v0.Landroid/support/v4/app/Fragment;->mHidden:Z
    001c: if-nez v5, 0034
    001e: iget v5, v0.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    0020: if-eqz v5, 0034
    0022: iget v5, v0.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    0024: if-eqz v5, 0034
    0026: const/4 v2, 1
    0027: invoke-virtual {v0, v7, v8}, Landroid/support/v4/app/Fragment;->onCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)V
    002a: if-nez v1, 0031
    002c: new-instance v1, Ljava/util/ArrayList;
    002e: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    0031: invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0034: move(op=01) v0, v2
    0035: binop/lit8(op=d8) v2, v3, 1 (0x1)
    0037: move(op=01) v3, v2
    0038: move(op=01) v2, v0
    0039: goto 0008
    003a: move(op=01) v2, v4
    003b: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mCreatedMenus:Ljava/util/ArrayList;
    003d: if-eqz v0, 005d
    003f: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mCreatedMenus:Ljava/util/ArrayList;
    0041: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0044: move-result v0
    0045: if-ge v4, v0, 005d
    0047: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mCreatedMenus:Ljava/util/ArrayList;
    0049: invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    004c: move-result-object v0
    004d: check-cast v0, Landroid/support/v4/app/Fragment;
    004f: if-eqz v1, 0057
    0051: invoke-virtual {v1, v0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z
    0054: move-result v3
    0055: if-nez v3, 005a
    0057: invoke-virtual {v0}, Landroid/support/v4/app/Fragment;->onDestroyOptionsMenu()V
    005a: binop/lit8(op=d8) v4, v4, 1 (0x1)
    005c: goto 003f
    005d: iput v1, v6.Landroid/support/v4/app/FragmentManagerImpl;->mCreatedMenus:Ljava/util/ArrayList;
    005f: return v2

  [Virtual Method] dispatchDestroy() -> V
    // registers=3, ins=1, outs=3, insns_size=14
    0000: const/4 v1, 0
    0001: const/4 v0, 1
    0002: iput v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mDestroyed:Z
    0004: invoke-virtual {v2}, Landroid/support/v4/app/FragmentManagerImpl;->execPendingActions()Z
    0007: invoke-virtual {v2, v1, v1}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(IZ)V
    000a: const/4 v0, 0
    000b: iput v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    000d: return-void

  [Virtual Method] dispatchLowMemory() -> V
    // registers=3, ins=1, outs=2, insns_size=32
    0000: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0002: if-eqz v0, 001f
    0004: const/4 v0, 0
    0005: move(op=01) v1, v0
    0006: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0008: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000b: move-result v0
    000c: if-ge v1, v0, 001f
    000e: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0010: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0013: move-result-object v0
    0014: check-cast v0, Landroid/support/v4/app/Fragment;
    0016: if-eqz v0, 001b
    0018: invoke-virtual {v0}, Landroid/support/v4/app/Fragment;->onLowMemory()V
    001b: binop/lit8(op=d8) v0, v1, 1 (0x1)
    001d: move(op=01) v1, v0
    001e: goto 0006
    001f: return-void

  [Virtual Method] dispatchOptionsItemSelected(Landroid/view/MenuItem;) -> Z
    // registers=6, ins=2, outs=2, insns_size=48
    0000: const/4 v2, 0
    0001: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0003: if-eqz v0, 002b
    0005: move(op=01) v1, v2
    0006: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0008: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000b: move-result v0
    000c: if-ge v1, v0, 002b
    000e: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0010: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0013: move-result-object v0
    0014: check-cast v0, Landroid/support/v4/app/Fragment;
    0016: if-eqz v0, 002c
    0018: iget v3, v0.Landroid/support/v4/app/Fragment;->mHidden:Z
    001a: if-nez v3, 002c
    001c: iget v3, v0.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    001e: if-eqz v3, 002c
    0020: iget v3, v0.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    0022: if-eqz v3, 002c
    0024: invoke-virtual {v0, v5}, Landroid/support/v4/app/Fragment;->onOptionsItemSelected(Landroid/view/MenuItem;)Z
    0027: move-result v0
    0028: if-eqz v0, 002c
    002a: const/4 v2, 1
    002b: return v2
    002c: binop/lit8(op=d8) v0, v1, 1 (0x1)
    002e: move(op=01) v1, v0
    002f: goto 0006

  [Virtual Method] dispatchOptionsMenuClosed(Landroid/view/Menu;) -> V
    // registers=5, ins=2, outs=2, insns_size=44
    0000: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0002: if-eqz v0, 002b
    0004: const/4 v0, 0
    0005: move(op=01) v1, v0
    0006: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0008: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000b: move-result v0
    000c: if-ge v1, v0, 002b
    000e: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0010: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0013: move-result-object v0
    0014: check-cast v0, Landroid/support/v4/app/Fragment;
    0016: if-eqz v0, 0027
    0018: iget v2, v0.Landroid/support/v4/app/Fragment;->mHidden:Z
    001a: if-nez v2, 0027
    001c: iget v2, v0.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    001e: if-eqz v2, 0027
    0020: iget v2, v0.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    0022: if-eqz v2, 0027
    0024: invoke-virtual {v0, v4}, Landroid/support/v4/app/Fragment;->onOptionsMenuClosed(Landroid/view/Menu;)V
    0027: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0029: move(op=01) v1, v0
    002a: goto 0006
    002b: return-void

  [Virtual Method] dispatchPause() -> V
    // registers=3, ins=1, outs=3, insns_size=6
    0000: const/4 v0, 4
    0001: const/4 v1, 0
    0002: invoke-virtual {v2, v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(IZ)V
    0005: return-void

  [Virtual Method] dispatchPrepareOptionsMenu(Landroid/view/Menu;) -> Z
    // registers=6, ins=2, outs=2, insns_size=47
    0000: const/4 v0, 0
    0001: iget v1, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0003: if-eqz v1, 002d
    0005: move(op=01) v1, v0
    0006: move(op=01) v2, v0
    0007: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0009: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000c: move-result v0
    000d: if-ge v1, v0, 002e
    000f: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0011: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0014: move-result-object v0
    0015: check-cast v0, Landroid/support/v4/app/Fragment;
    0017: if-eqz v0, 0029
    0019: iget v3, v0.Landroid/support/v4/app/Fragment;->mHidden:Z
    001b: if-nez v3, 0029
    001d: iget v3, v0.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    001f: if-eqz v3, 0029
    0021: iget v3, v0.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    0023: if-eqz v3, 0029
    0025: const/4 v2, 1
    0026: invoke-virtual {v0, v5}, Landroid/support/v4/app/Fragment;->onPrepareOptionsMenu(Landroid/view/Menu;)V
    0029: binop/lit8(op=d8) v0, v1, 1 (0x1)
    002b: move(op=01) v1, v0
    002c: goto 0007
    002d: move(op=01) v2, v0
    002e: return v2

  [Virtual Method] dispatchReallyStop() -> V
    // registers=3, ins=1, outs=3, insns_size=6
    0000: const/4 v0, 2
    0001: const/4 v1, 0
    0002: invoke-virtual {v2, v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(IZ)V
    0005: return-void

  [Virtual Method] dispatchResume() -> V
    // registers=3, ins=1, outs=3, insns_size=8
    0000: const/4 v1, 0
    0001: iput v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateSaved:Z
    0003: const/4 v0, 5
    0004: invoke-virtual {v2, v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(IZ)V
    0007: return-void

  [Virtual Method] dispatchStart() -> V
    // registers=3, ins=1, outs=3, insns_size=8
    0000: const/4 v1, 0
    0001: iput v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateSaved:Z
    0003: const/4 v0, 4
    0004: invoke-virtual {v2, v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(IZ)V
    0007: return-void

  [Virtual Method] dispatchStop() -> V
    // registers=3, ins=1, outs=3, insns_size=9
    0000: const/4 v0, 1
    0001: iput v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateSaved:Z
    0003: const/4 v0, 3
    0004: const/4 v1, 0
    0005: invoke-virtual {v2, v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(IZ)V
    0008: return-void

  [Virtual Method] dump(Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V
    // registers=11, ins=5, outs=5, insns_size=526
    0000: const/4 v1, 0
    0001: new-instance v0, Ljava/lang/StringBuilder;
    0003: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0006: invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0009: move-result-object v0
    000a: const-string v2, '    '
    000c: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000f: move-result-object v0
    0010: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0013: move-result-object v3
    0014: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0016: if-eqz v0, 005f
    0018: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    001a: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    001d: move-result v4
    001e: if-lez v4, 005f
    0020: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0023: const-string v0, 'Active Fragments in '
    0025: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0028: invoke-static {v6}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I
    002b: move-result v0
    002c: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    002f: move-result-object v0
    0030: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0033: const-string v0, ':'
    0035: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0038: move(op=01) v2, v1
    0039: if-ge v2, v4, 005f
    003b: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    003d: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0040: move-result-object v0
    0041: check-cast v0, Landroid/support/v4/app/Fragment;
    0043: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0046: const-string v5, '  #'
    0048: invoke-virtual {v9, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    004b: invoke-virtual {v9, v2}, Ljava/io/PrintWriter;->print(I)V
    004e: const-string v5, ': '
    0050: invoke-virtual {v9, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0053: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0056: if-eqz v0, 005b
    0058: invoke-virtual {v0, v3, v8, v9, v10}, Landroid/support/v4/app/Fragment;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    005b: binop/lit8(op=d8) v0, v2, 1 (0x1)
    005d: move(op=01) v2, v0
    005e: goto 0039
    005f: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0061: if-eqz v0, 0099
    0063: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0065: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0068: move-result v4
    0069: if-lez v4, 0099
    006b: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    006e: const-string v0, 'Added Fragments:'
    0070: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0073: move(op=01) v2, v1
    0074: if-ge v2, v4, 0099
    0076: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0078: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    007b: move-result-object v0
    007c: check-cast v0, Landroid/support/v4/app/Fragment;
    007e: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0081: const-string v5, '  #'
    0083: invoke-virtual {v9, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0086: invoke-virtual {v9, v2}, Ljava/io/PrintWriter;->print(I)V
    0089: const-string v5, ': '
    008b: invoke-virtual {v9, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    008e: invoke-virtual {v0}, Landroid/support/v4/app/Fragment;->toString()Ljava/lang/String;
    0091: move-result-object v0
    0092: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0095: binop/lit8(op=d8) v0, v2, 1 (0x1)
    0097: move(op=01) v2, v0
    0098: goto 0074
    0099: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mCreatedMenus:Ljava/util/ArrayList;
    009b: if-eqz v0, 00d3
    009d: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mCreatedMenus:Ljava/util/ArrayList;
    009f: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    00a2: move-result v4
    00a3: if-lez v4, 00d3
    00a5: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00a8: const-string v0, 'Fragments Created Menus:'
    00aa: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    00ad: move(op=01) v2, v1
    00ae: if-ge v2, v4, 00d3
    00b0: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mCreatedMenus:Ljava/util/ArrayList;
    00b2: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    00b5: move-result-object v0
    00b6: check-cast v0, Landroid/support/v4/app/Fragment;
    00b8: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00bb: const-string v5, '  #'
    00bd: invoke-virtual {v9, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00c0: invoke-virtual {v9, v2}, Ljava/io/PrintWriter;->print(I)V
    00c3: const-string v5, ': '
    00c5: invoke-virtual {v9, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00c8: invoke-virtual {v0}, Landroid/support/v4/app/Fragment;->toString()Ljava/lang/String;
    00cb: move-result-object v0
    00cc: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    00cf: binop/lit8(op=d8) v0, v2, 1 (0x1)
    00d1: move(op=01) v2, v0
    00d2: goto 00ae
    00d3: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    00d5: if-eqz v0, 0110
    00d7: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    00d9: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    00dc: move-result v4
    00dd: if-lez v4, 0110
    00df: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00e2: const-string v0, 'Back Stack:'
    00e4: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    00e7: move(op=01) v2, v1
    00e8: if-ge v2, v4, 0110
    00ea: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    00ec: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    00ef: move-result-object v0
    00f0: check-cast v0, Landroid/support/v4/app/BackStackRecord;
    00f2: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00f5: const-string v5, '  #'
    00f7: invoke-virtual {v9, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00fa: invoke-virtual {v9, v2}, Ljava/io/PrintWriter;->print(I)V
    00fd: const-string v5, ': '
    00ff: invoke-virtual {v9, v5}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0102: invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0105: move-result-object v5
    0106: invoke-virtual {v9, v5}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0109: invoke-virtual {v0, v3, v8, v9, v10}, Landroid/support/v4/app/BackStackRecord;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    010c: binop/lit8(op=d8) v0, v2, 1 (0x1)
    010e: move(op=01) v2, v0
    010f: goto 00e8
    0110: monitor-enter v6
    0111: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    0113: if-eqz v0, 0147
    0115: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    0117: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    011a: move-result v3
    011b: if-lez v3, 0147
    011d: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0120: const-string v0, 'Back Stack Indices:'
    0122: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0125: move(op=01) v2, v1
    0126: if-ge v2, v3, 0147
    0128: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    012a: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    012d: move-result-object v0
    012e: check-cast v0, Landroid/support/v4/app/BackStackRecord;
    0130: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0133: const-string v4, '  #'
    0135: invoke-virtual {v9, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0138: invoke-virtual {v9, v2}, Ljava/io/PrintWriter;->print(I)V
    013b: const-string v4, ': '
    013d: invoke-virtual {v9, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0140: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0143: binop/lit8(op=d8) v0, v2, 1 (0x1)
    0145: move(op=01) v2, v0
    0146: goto 0126
    0147: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    0149: if-eqz v0, 0168
    014b: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    014d: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0150: move-result v0
    0151: if-lez v0, 0168
    0153: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0156: const-string v0, 'mAvailBackStackIndices: '
    0158: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    015b: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    015d: invoke-virtual {v0}, Ljava/util/ArrayList;->toArray()[Ljava/lang/Object;
    0160: move-result-object v0
    0161: invoke-static {v0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;
    0164: move-result-object v0
    0165: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0168: monitor-exit v6
    0169: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    016b: if-eqz v0, 01a1
    016d: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    016f: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0172: move-result v2
    0173: if-lez v2, 01a1
    0175: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0178: const-string v0, 'Pending Actions:'
    017a: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    017d: if-ge v1, v2, 01a1
    017f: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    0181: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0184: move-result-object v0
    0185: check-cast v0, Ljava/lang/Runnable;
    0187: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    018a: const-string v3, '  #'
    018c: invoke-virtual {v9, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    018f: invoke-virtual {v9, v1}, Ljava/io/PrintWriter;->print(I)V
    0192: const-string v3, ': '
    0194: invoke-virtual {v9, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0197: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    019a: binop/lit8(op=d8) v0, v1, 1 (0x1)
    019c: move(op=01) v1, v0
    019d: goto 017d
    019e: move-exception v0
    019f: monitor-exit v6
    01a0: throw v0
    01a1: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01a4: const-string v0, 'FragmentManager misc state:'
    01a6: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    01a9: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01ac: const-string v0, '  mCurState='
    01ae: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01b1: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mCurState:I
    01b3: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(I)V
    01b6: const-string v0, ' mStateSaved='
    01b8: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01bb: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mStateSaved:Z
    01bd: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Z)V
    01c0: const-string v0, ' mDestroyed='
    01c2: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01c5: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mDestroyed:Z
    01c7: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Z)V
    01ca: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mNeedMenuInvalidate:Z
    01cc: if-eqz v0, 01db
    01ce: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01d1: const-string v0, '  mNeedMenuInvalidate='
    01d3: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01d6: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mNeedMenuInvalidate:Z
    01d8: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Z)V
    01db: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    01dd: if-eqz v0, 01ec
    01df: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01e2: const-string v0, '  mNoTransactionsBecause='
    01e4: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01e7: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mNoTransactionsBecause:Ljava/lang/String;
    01e9: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    01ec: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    01ee: if-eqz v0, 020d
    01f0: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    01f2: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    01f5: move-result v0
    01f6: if-lez v0, 020d
    01f8: invoke-virtual {v9, v7}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01fb: const-string v0, '  mAvailIndices: '
    01fd: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0200: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    0202: invoke-virtual {v0}, Ljava/util/ArrayList;->toArray()[Ljava/lang/Object;
    0205: move-result-object v0
    0206: invoke-static {v0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;
    0209: move-result-object v0
    020a: invoke-virtual {v9, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    020d: return-void

  [Virtual Method] enqueueAction(Ljava/lang/Runnable;, Z) -> V
    // registers=5, ins=3, outs=2, insns_size=66
    0000: if-nez v4, 0005
    0002: invoke-direct {v2}, Landroid/support/v4/app/FragmentManagerImpl;->checkStateLoss()V
    0005: monitor-enter v2
    0006: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0008: if-nez v0, 0015
    000a: new-instance v0, Ljava/lang/IllegalStateException;
    000c: const-string v1, 'Activity has been destroyed'
    000e: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0011: throw v0
    0012: move-exception v0
    0013: monitor-exit v2
    0014: throw v0
    0015: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    0017: if-nez v0, 0020
    0019: new-instance v0, Ljava/util/ArrayList;
    001b: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    001e: iput v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    0020: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    0022: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0025: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    0027: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    002a: move-result v0
    002b: const/4 v1, 1
    002c: if-ne v0, v1, 0040
    002e: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0030: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    0032: iget v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mExecCommit:Ljava/lang/Runnable;
    0034: invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    0037: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0039: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    003b: iget v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mExecCommit:Ljava/lang/Runnable;
    003d: invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    0040: monitor-exit v2
    0041: return-void

  [Virtual Method] execPendingActions() -> Z
    // registers=7, ins=1, outs=2, insns_size=166
    0000: const/4 v0, 1
    0001: const/4 v2, 0
    0002: iget v1, v6.Landroid/support/v4/app/FragmentManagerImpl;->mExecutingActions:Z
    0004: if-eqz v1, 000e
    0006: new-instance v0, Ljava/lang/IllegalStateException;
    0008: const-string v1, 'Recursive entry to executePendingTransactions'
    000a: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000d: throw v0
    000e: invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;
    0011: move-result-object v1
    0012: iget v3, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0014: iget v3, v3.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    0016: invoke-virtual {v3}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;
    0019: move-result-object v3
    001a: if-eq v1, v3, 0024
    001c: new-instance v0, Ljava/lang/IllegalStateException;
    001e: const-string v1, 'Must be called from main thread of process'
    0020: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0023: throw v0
    0024: move(op=01) v1, v2
    0025: monitor-enter v6
    0026: iget v3, v6.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    0028: if-eqz v3, 0032
    002a: iget v3, v6.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    002c: invoke-virtual {v3}, Ljava/util/ArrayList;->size()I
    002f: move-result v3
    0030: if-nez v3, 005a
    0032: monitor-exit v6
    0033: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mHavePendingDeferredStart:Z
    0035: if-eqz v0, 00a5
    0037: move(op=01) v3, v2
    0038: move(op=01) v4, v2
    0039: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    003b: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    003e: move-result v0
    003f: if-ge v3, v0, 009e
    0041: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0043: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0046: move-result-object v0
    0047: check-cast v0, Landroid/support/v4/app/Fragment;
    0049: if-eqz v0, 0056
    004b: iget v5, v0.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    004d: if-eqz v5, 0056
    004f: iget v0, v0.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0051: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->hasRunningLoaders()Z
    0054: move-result v0
    0055: binop/2addr(op=b6) v4, v0
    0056: binop/lit8(op=d8) v0, v3, 1 (0x1)
    0058: move(op=01) v3, v0
    0059: goto 0039
    005a: iget v1, v6.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    005c: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    005f: move-result v3
    0060: iget v1, v6.Landroid/support/v4/app/FragmentManagerImpl;->mTmpActions:[Ljava/lang/Runnable;
    0062: if-eqz v1, 0069
    0064: iget v1, v6.Landroid/support/v4/app/FragmentManagerImpl;->mTmpActions:[Ljava/lang/Runnable;
    0066: move(op=21) v1, v1
    0067: if-ge v1, v3, 006d
    0069: new-array v1, v3, [Ljava/lang/Runnable;
    006b: iput v1, v6.Landroid/support/v4/app/FragmentManagerImpl;->mTmpActions:[Ljava/lang/Runnable;
    006d: iget v1, v6.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    006f: iget v4, v6.Landroid/support/v4/app/FragmentManagerImpl;->mTmpActions:[Ljava/lang/Runnable;
    0071: invoke-virtual {v1, v4}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    0074: iget v1, v6.Landroid/support/v4/app/FragmentManagerImpl;->mPendingActions:Ljava/util/ArrayList;
    0076: invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V
    0079: iget v1, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    007b: iget v1, v1.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    007d: iget v4, v6.Landroid/support/v4/app/FragmentManagerImpl;->mExecCommit:Ljava/lang/Runnable;
    007f: invoke-virtual {v1, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    0082: monitor-exit v6
    0083: iput v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mExecutingActions:Z
    0085: move(op=01) v1, v2
    0086: if-ge v1, v3, 009a
    0088: iget v4, v6.Landroid/support/v4/app/FragmentManagerImpl;->mTmpActions:[Ljava/lang/Runnable;
    008a: aget(op=46) v4, v4[v1]
    008c: invoke-interface {v4}, Ljava/lang/Runnable;->run()V
    008f: iget v4, v6.Landroid/support/v4/app/FragmentManagerImpl;->mTmpActions:[Ljava/lang/Runnable;
    0091: const/4 v5, 0
    0092: aput(op=4d) v5, v4[v1]
    0094: binop/lit8(op=d8) v1, v1, 1 (0x1)
    0096: goto 0086
    0097: move-exception v0
    0098: monitor-exit v6
    0099: throw v0
    009a: iput v2, v6.Landroid/support/v4/app/FragmentManagerImpl;->mExecutingActions:Z
    009c: move(op=01) v1, v0
    009d: goto 0025
    009e: if-nez v4, 00a5
    00a0: iput v2, v6.Landroid/support/v4/app/FragmentManagerImpl;->mHavePendingDeferredStart:Z
    00a2: invoke-virtual {v6}, Landroid/support/v4/app/FragmentManagerImpl;->startPendingDeferredFragments()V
    00a5: return v1

  [Virtual Method] executePendingTransactions() -> Z
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/support/v4/app/FragmentManagerImpl;->execPendingActions()Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] findFragmentById(I) -> Landroid/support/v4/app/Fragment;
    // registers=5, ins=2, outs=2, insns_size=69
    0000: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0002: if-eqz v0, 0022
    0004: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0006: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0009: move-result v0
    000a: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    000c: move(op=01) v1, v0
    000d: if-ltz v1, 0022
    000f: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0011: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0014: move-result-object v0
    0015: check-cast v0, Landroid/support/v4/app/Fragment;
    0017: if-eqz v0, 001e
    0019: iget v2, v0.Landroid/support/v4/app/Fragment;->mFragmentId:I
    001b: if-ne v2, v4, 001e
    001d: return-object v0
    001e: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    0020: move(op=01) v1, v0
    0021: goto 000d
    0022: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0024: if-eqz v0, 0043
    0026: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0028: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    002b: move-result v0
    002c: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    002e: move(op=01) v1, v0
    002f: if-ltz v1, 0043
    0031: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0033: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0036: move-result-object v0
    0037: check-cast v0, Landroid/support/v4/app/Fragment;
    0039: if-eqz v0, 003f
    003b: iget v2, v0.Landroid/support/v4/app/Fragment;->mFragmentId:I
    003d: if-eq v2, v4, 001d
    003f: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    0041: move(op=01) v1, v0
    0042: goto 002f
    0043: const/4 v0, 0
    0044: goto 001d

  [Virtual Method] findFragmentByTag(Ljava/lang/String;) -> Landroid/support/v4/app/Fragment;
    // registers=5, ins=2, outs=2, insns_size=81
    0000: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0002: if-eqz v0, 0028
    0004: if-eqz v4, 0028
    0006: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0008: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000b: move-result v0
    000c: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    000e: move(op=01) v1, v0
    000f: if-ltz v1, 0028
    0011: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0013: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0016: move-result-object v0
    0017: check-cast v0, Landroid/support/v4/app/Fragment;
    0019: if-eqz v0, 0024
    001b: iget v2, v0.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    001d: invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0020: move-result v2
    0021: if-eqz v2, 0024
    0023: return-object v0
    0024: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    0026: move(op=01) v1, v0
    0027: goto 000f
    0028: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    002a: if-eqz v0, 004f
    002c: if-eqz v4, 004f
    002e: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0030: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0033: move-result v0
    0034: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0036: move(op=01) v1, v0
    0037: if-ltz v1, 004f
    0039: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    003b: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    003e: move-result-object v0
    003f: check-cast v0, Landroid/support/v4/app/Fragment;
    0041: if-eqz v0, 004b
    0043: iget v2, v0.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    0045: invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0048: move-result v2
    0049: if-nez v2, 0023
    004b: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    004d: move(op=01) v1, v0
    004e: goto 0037
    004f: const/4 v0, 0
    0050: goto 0023

  [Virtual Method] findFragmentByWho(Ljava/lang/String;) -> Landroid/support/v4/app/Fragment;
    // registers=5, ins=2, outs=2, insns_size=42
    0000: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0002: if-eqz v0, 0028
    0004: if-eqz v4, 0028
    0006: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0008: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000b: move-result v0
    000c: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    000e: move(op=01) v1, v0
    000f: if-ltz v1, 0028
    0011: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0013: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0016: move-result-object v0
    0017: check-cast v0, Landroid/support/v4/app/Fragment;
    0019: if-eqz v0, 0024
    001b: iget v2, v0.Landroid/support/v4/app/Fragment;->mWho:Ljava/lang/String;
    001d: invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0020: move-result v2
    0021: if-eqz v2, 0024
    0023: return-object v0
    0024: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    0026: move(op=01) v1, v0
    0027: goto 000f
    0028: const/4 v0, 0
    0029: goto 0023

  [Virtual Method] freeBackStackIndex(I) -> V
    // registers=5, ins=2, outs=3, insns_size=60
    0000: monitor-enter v3
    0001: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    0003: const/4 v1, 0
    0004: invoke-virtual {v0, v4, v1}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;
    0007: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    0009: if-nez v0, 0012
    000b: new-instance v0, Ljava/util/ArrayList;
    000d: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0010: iput v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    0012: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0014: if-eqz v0, 002e
    0016: const-string v0, 'FragmentManager'
    0018: new-instance v1, Ljava/lang/StringBuilder;
    001a: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    001d: const-string v2, 'Freeing back stack index '
    001f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0022: move-result-object v1
    0023: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0026: move-result-object v1
    0027: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002a: move-result-object v1
    002b: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    002e: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    0030: invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0033: move-result-object v1
    0034: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0037: monitor-exit v3
    0038: return-void
    0039: move-exception v0
    003a: monitor-exit v3
    003b: throw v0

  [Virtual Method] getBackStackEntryAt(I) -> Landroid/support/v4/app/FragmentManager$BackStackEntry;
    // registers=3, ins=2, outs=2, insns_size=9
    0000: iget v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0002: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/support/v4/app/FragmentManager$BackStackEntry;
    0008: return-object v0

  [Virtual Method] getBackStackEntryCount() -> I
    // registers=2, ins=1, outs=1, insns_size=13
    0000: iget v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0002: if-eqz v0, 000b
    0004: iget v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0006: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0009: move-result v0
    000a: return v0
    000b: const/4 v0, 0
    000c: goto 000a

  [Virtual Method] getFragment(Landroid/os/Bundle;, Ljava/lang/String;) -> Landroid/support/v4/app/Fragment;
    // registers=7, ins=3, outs=3, insns_size=97
    0000: const/4 v0, -1
    0001: invoke-virtual {v5, v6, v0}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I
    0004: move-result v1
    0005: if-ne v1, v0, 0009
    0007: const/4 v0, 0
    0008: return-object v0
    0009: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    000b: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000e: move-result v0
    000f: if-lt v1, v0, 0034
    0011: new-instance v0, Ljava/lang/IllegalStateException;
    0013: new-instance v2, Ljava/lang/StringBuilder;
    0015: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0018: const-string v3, 'Fragement no longer exists for key '
    001a: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001d: move-result-object v2
    001e: invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0021: move-result-object v2
    0022: const-string v3, ': index '
    0024: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0027: move-result-object v2
    0028: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    002b: move-result-object v1
    002c: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002f: move-result-object v1
    0030: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0033: throw v0
    0034: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0036: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0039: move-result-object v0
    003a: check-cast v0, Landroid/support/v4/app/Fragment;
    003c: if-nez v0, 0008
    003e: new-instance v0, Ljava/lang/IllegalStateException;
    0040: new-instance v2, Ljava/lang/StringBuilder;
    0042: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0045: const-string v3, 'Fragement no longer exists for key '
    0047: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004a: move-result-object v2
    004b: invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004e: move-result-object v2
    004f: const-string v3, ': index '
    0051: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0054: move-result-object v2
    0055: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0058: move-result-object v1
    0059: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    005c: move-result-object v1
    005d: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0060: throw v0

  [Virtual Method] hideFragment(Landroid/support/v4/app/Fragment;, I, I) -> V
    // registers=8, ins=4, outs=5, insns_size=75
    0000: const/4 v3, 1
    0001: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0003: if-eqz v0, 001d
    0005: const-string v0, 'FragmentManager'
    0007: new-instance v1, Ljava/lang/StringBuilder;
    0009: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000c: const-string v2, 'hide: '
    000e: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0011: move-result-object v1
    0012: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0015: move-result-object v1
    0016: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0019: move-result-object v1
    001a: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001d: iget v0, v5.Landroid/support/v4/app/Fragment;->mHidden:Z
    001f: if-nez v0, 004a
    0021: iput v3, v5.Landroid/support/v4/app/Fragment;->mHidden:Z
    0023: iget v0, v5.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0025: if-eqz v0, 0039
    0027: invoke-virtual {v4, v5, v6, v3, v7}, Landroid/support/v4/app/FragmentManagerImpl;->loadAnimation(Landroid/support/v4/app/Fragment;IZI)Landroid/view/animation/Animation;
    002a: move-result-object v0
    002b: if-eqz v0, 0032
    002d: iget v1, v5.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    002f: invoke-virtual {v1, v0}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V
    0032: iget v0, v5.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0034: const/16 v1, 8 (0x8)
    0036: invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V
    0039: iget v0, v5.Landroid/support/v4/app/Fragment;->mAdded:Z
    003b: if-eqz v0, 0047
    003d: iget v0, v5.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    003f: if-eqz v0, 0047
    0041: iget v0, v5.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    0043: if-eqz v0, 0047
    0045: iput v3, v4.Landroid/support/v4/app/FragmentManagerImpl;->mNeedMenuInvalidate:Z
    0047: invoke-virtual {v5, v3}, Landroid/support/v4/app/Fragment;->onHiddenChanged(Z)V
    004a: return-void

  [Virtual Method] loadAnimation(Landroid/support/v4/app/Fragment;, I, Z, I) -> Landroid/view/animation/Animation;
    // registers=11, ins=5, outs=5, insns_size=136
    0000: const v5, 1064933786 (0x3f79999a)
    0003: const/4 v1, 0
    0004: const/4 v4, 0
    0005: const/high16 v3, 1065353216 (0x3f800000)
    0007: iget v0, v7.Landroid/support/v4/app/Fragment;->mNextAnim:I
    0009: invoke-virtual {v7, v8, v9, v0}, Landroid/support/v4/app/Fragment;->onCreateAnimation(IZI)Landroid/view/animation/Animation;
    000c: move-result-object v0
    000d: if-eqz v0, 0010
    000f: return-object v0
    0010: iget v0, v7.Landroid/support/v4/app/Fragment;->mNextAnim:I
    0012: if-eqz v0, 001e
    0014: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0016: iget v2, v7.Landroid/support/v4/app/Fragment;->mNextAnim:I
    0018: invoke-static {v0, v2}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;
    001b: move-result-object v0
    001c: if-nez v0, 000f
    001e: if-nez v8, 0022
    0020: move(op=07) v0, v1
    0021: goto 000f
    0022: invoke-static {v8, v9}, Landroid/support/v4/app/FragmentManagerImpl;->transitToStyleIndex(IZ)I
    0025: move-result v0
    0026: if-gez v0, 002a
    0028: move(op=07) v0, v1
    0029: goto 000f
    002a: packed-switch v0, +78 (-> 0078)
    002d: if-nez v10, 0043
    002f: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0031: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getWindow()Landroid/view/Window;
    0034: move-result-object v0
    0035: if-eqz v0, 0043
    0037: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0039: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getWindow()Landroid/view/Window;
    003c: move-result-object v0
    003d: invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;
    0040: move-result-object v0
    0041: iget v10, v0.Landroid/view/WindowManager$LayoutParams;->windowAnimations:I
    0043: if-nez v10, 0076
    0045: move(op=07) v0, v1
    0046: goto 000f
    0047: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0049: const/high16 v1, 1066401792 (0x3f900000)
    004b: invoke-static {v0, v1, v3, v4, v3}, Landroid/support/v4/app/FragmentManagerImpl;->makeOpenCloseAnimation(Landroid/content/Context;FFFF)Landroid/view/animation/Animation;
    004e: move-result-object v0
    004f: goto 000f
    0050: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0052: invoke-static {v0, v3, v5, v3, v4}, Landroid/support/v4/app/FragmentManagerImpl;->makeOpenCloseAnimation(Landroid/content/Context;FFFF)Landroid/view/animation/Animation;
    0055: move-result-object v0
    0056: goto 000f
    0057: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0059: invoke-static {v0, v5, v3, v4, v3}, Landroid/support/v4/app/FragmentManagerImpl;->makeOpenCloseAnimation(Landroid/content/Context;FFFF)Landroid/view/animation/Animation;
    005c: move-result-object v0
    005d: goto 000f
    005e: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0060: const v1, 1065982362 (0x3f89999a)
    0063: invoke-static {v0, v3, v1, v3, v4}, Landroid/support/v4/app/FragmentManagerImpl;->makeOpenCloseAnimation(Landroid/content/Context;FFFF)Landroid/view/animation/Animation;
    0066: move-result-object v0
    0067: goto 000f
    0068: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    006a: invoke-static {v0, v4, v3}, Landroid/support/v4/app/FragmentManagerImpl;->makeFadeAnimation(Landroid/content/Context;FF)Landroid/view/animation/Animation;
    006d: move-result-object v0
    006e: goto 000f
    006f: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0071: invoke-static {v0, v3, v4}, Landroid/support/v4/app/FragmentManagerImpl;->makeFadeAnimation(Landroid/content/Context;FF)Landroid/view/animation/Animation;
    0074: move-result-object v0
    0075: goto 000f
    0076: move(op=07) v0, v1
    0077: goto 000f
    0078: packed-switch-payload first=1 targets=[29, 38, 45, 52, 62, 69]

  [Virtual Method] makeActive(Landroid/support/v4/app/Fragment;) -> V
    // registers=5, ins=2, outs=3, insns_size=102
    0000: iget v0, v4.Landroid/support/v4/app/Fragment;->mIndex:I
    0002: if-ltz v0, 0005
    0004: return-void
    0005: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    0007: if-eqz v0, 0011
    0009: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    000b: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000e: move-result v0
    000f: if-gtz v0, 0047
    0011: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0013: if-nez v0, 001c
    0015: new-instance v0, Ljava/util/ArrayList;
    0017: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    001a: iput v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    001c: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    001e: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0021: move-result v0
    0022: invoke-virtual {v4, v0}, Landroid/support/v4/app/Fragment;->setIndex(I)V
    0025: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0027: invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    002a: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    002c: if-eqz v0, 0004
    002e: const-string v0, 'FragmentManager'
    0030: new-instance v1, Ljava/lang/StringBuilder;
    0032: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0035: const-string v2, 'Allocated fragment index '
    0037: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003a: move-result-object v1
    003b: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    003e: move-result-object v1
    003f: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0042: move-result-object v1
    0043: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0046: goto 0004
    0047: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    0049: iget v1, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    004b: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    004e: move-result v1
    004f: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0051: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    0054: move-result-object v0
    0055: check-cast v0, Ljava/lang/Integer;
    0057: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    005a: move-result v0
    005b: invoke-virtual {v4, v0}, Landroid/support/v4/app/Fragment;->setIndex(I)V
    005e: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0060: iget v1, v4.Landroid/support/v4/app/Fragment;->mIndex:I
    0062: invoke-virtual {v0, v1, v4}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;
    0065: goto 002a

  [Virtual Method] makeInactive(Landroid/support/v4/app/Fragment;) -> V
    // registers=5, ins=2, outs=3, insns_size=74
    0000: iget v0, v4.Landroid/support/v4/app/Fragment;->mIndex:I
    0002: if-gez v0, 0005
    0004: return-void
    0005: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0007: if-eqz v0, 0021
    0009: const-string v0, 'FragmentManager'
    000b: new-instance v1, Ljava/lang/StringBuilder;
    000d: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0010: const-string v2, 'Freeing fragment index '
    0012: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0015: move-result-object v1
    0016: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0019: move-result-object v1
    001a: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001d: move-result-object v1
    001e: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0021: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0023: iget v1, v4.Landroid/support/v4/app/Fragment;->mIndex:I
    0025: const/4 v2, 0
    0026: invoke-virtual {v0, v1, v2}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;
    0029: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    002b: if-nez v0, 0034
    002d: new-instance v0, Ljava/util/ArrayList;
    002f: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0032: iput v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    0034: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    0036: iget v1, v4.Landroid/support/v4/app/Fragment;->mIndex:I
    0038: invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    003b: move-result-object v1
    003c: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    003f: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0041: iget v1, v4.Landroid/support/v4/app/Fragment;->mIndex:I
    0043: invoke-virtual {v0, v1}, Landroid/support/v4/app/FragmentActivity;->invalidateSupportFragmentIndex(I)V
    0046: invoke-virtual {v4}, Landroid/support/v4/app/Fragment;->initState()V
    0049: goto 0004

  [Virtual Method] moveToState(I, I, I, Z) -> V
    // registers=13, ins=5, outs=6, insns_size=100
    0000: const/4 v5, 0
    0001: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0003: if-nez v0, 000f
    0005: if-eqz v9, 000f
    0007: new-instance v0, Ljava/lang/IllegalStateException;
    0009: const-string v1, 'No activity'
    000b: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000e: throw v0
    000f: if-nez v12, 0016
    0011: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mCurState:I
    0013: if-ne v0, v9, 0016
    0015: return-void
    0016: iput v9, v8.Landroid/support/v4/app/FragmentManagerImpl;->mCurState:I
    0018: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    001a: if-eqz v0, 0015
    001c: move(op=01) v6, v5
    001d: move(op=01) v7, v5
    001e: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0020: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0023: move-result v0
    0024: if-ge v6, v0, 0048
    0026: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0028: invoke-virtual {v0, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    002b: move-result-object v1
    002c: check-cast v1, Landroid/support/v4/app/Fragment;
    002e: if-eqz v1, 0062
    0030: move(op=07) v0, v8
    0031: move(op=01) v2, v9
    0032: move(op=01) v3, v10
    0033: move(op=01) v4, v11
    0034: invoke-virtual/range {v0..v5}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(Landroid/support/v4/app/Fragment;IIIZ)V
    0037: iget v0, v1.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0039: if-eqz v0, 0062
    003b: iget v0, v1.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    003d: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->hasRunningLoaders()Z
    0040: move-result v0
    0041: binop/2addr(op=b6) v7, v0
    0042: move(op=01) v1, v7
    0043: binop/lit8(op=d8) v0, v6, 1 (0x1)
    0045: move(op=01) v6, v0
    0046: move(op=01) v7, v1
    0047: goto 001e
    0048: if-nez v7, 004d
    004a: invoke-virtual {v8}, Landroid/support/v4/app/FragmentManagerImpl;->startPendingDeferredFragments()V
    004d: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mNeedMenuInvalidate:Z
    004f: if-eqz v0, 0015
    0051: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0053: if-eqz v0, 0015
    0055: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mCurState:I
    0057: const/4 v1, 5
    0058: if-ne v0, v1, 0015
    005a: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    005c: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->supportInvalidateOptionsMenu()V
    005f: iput v5, v8.Landroid/support/v4/app/FragmentManagerImpl;->mNeedMenuInvalidate:Z
    0061: goto 0015
    0062: move(op=01) v1, v7
    0063: goto 0043

  [Virtual Method] moveToState(I, Z) -> V
    // registers=4, ins=3, outs=5, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0, v0, v3}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(IIIZ)V
    0004: return-void

  [Virtual Method] moveToState(Landroid/support/v4/app/Fragment;) -> V
    // registers=8, ins=2, outs=6, insns_size=11
    0000: const/4 v3, 0
    0001: iget v2, v6.Landroid/support/v4/app/FragmentManagerImpl;->mCurState:I
    0003: move(op=07) v0, v6
    0004: move(op=07) v1, v7
    0005: move(op=01) v4, v3
    0006: move(op=01) v5, v3
    0007: invoke-virtual/range {v0..v5}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(Landroid/support/v4/app/Fragment;IIIZ)V
    000a: return-void

  [Virtual Method] moveToState(Landroid/support/v4/app/Fragment;, I, I, I, Z) -> V
    // registers=15, ins=6, outs=6, insns_size=1198
    0000: const/4 v8, 4
    0001: const/4 v6, 3
    0002: const/4 v5, 1
    0003: const/4 v7, 0
    0004: const/4 v3, 0
    0005: iget v0, v10.Landroid/support/v4/app/Fragment;->mAdded:Z
    0007: if-nez v0, 000c
    0009: if-le v11, v5, 000c
    000b: move(op=01) v11, v5
    000c: iget v0, v10.Landroid/support/v4/app/Fragment;->mRemoving:Z
    000e: if-eqz v0, 0016
    0010: iget v0, v10.Landroid/support/v4/app/Fragment;->mState:I
    0012: if-le v11, v0, 0016
    0014: iget v11, v10.Landroid/support/v4/app/Fragment;->mState:I
    0016: iget v0, v10.Landroid/support/v4/app/Fragment;->mDeferStart:Z
    0018: if-eqz v0, 0021
    001a: iget v0, v10.Landroid/support/v4/app/Fragment;->mState:I
    001c: if-ge v0, v8, 0021
    001e: if-le v11, v6, 0021
    0020: move(op=01) v11, v6
    0021: iget v0, v10.Landroid/support/v4/app/Fragment;->mState:I
    0023: if-ge v0, v11, 02a7
    0025: iget v0, v10.Landroid/support/v4/app/Fragment;->mFromLayout:Z
    0027: if-eqz v0, 002e
    0029: iget v0, v10.Landroid/support/v4/app/Fragment;->mInLayout:Z
    002b: if-nez v0, 002e
    002d: return-void
    002e: iget v0, v10.Landroid/support/v4/app/Fragment;->mAnimatingAway:Landroid/view/View;
    0030: if-eqz v0, 003c
    0032: iput v7, v10.Landroid/support/v4/app/Fragment;->mAnimatingAway:Landroid/view/View;
    0034: iget v2, v10.Landroid/support/v4/app/Fragment;->mStateAfterAnimating:I
    0036: move(op=07) v0, v9
    0037: move(op=07) v1, v10
    0038: move(op=01) v4, v3
    0039: invoke-virtual/range {v0..v5}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(Landroid/support/v4/app/Fragment;IIIZ)V
    003c: iget v0, v10.Landroid/support/v4/app/Fragment;->mState:I
    003e: packed-switch v0, +1108 (-> 0492)
    0041: iput v11, v10.Landroid/support/v4/app/Fragment;->mState:I
    0043: goto 002d
    0044: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0046: if-eqz v0, 0060
    0048: const-string v0, 'FragmentManager'
    004a: new-instance v1, Ljava/lang/StringBuilder;
    004c: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    004f: const-string v2, 'moveto CREATED: '
    0051: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0054: move-result-object v1
    0055: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0058: move-result-object v1
    0059: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    005c: move-result-object v1
    005d: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0060: iget v0, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    0062: if-eqz v0, 0099
    0064: iget v0, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    0066: const-string v1, 'android:view_state'
    0068: invoke-virtual {v0, v1}, Landroid/os/Bundle;->getSparseParcelableArray(Ljava/lang/String;)Landroid/util/SparseArray;
    006b: move-result-object v0
    006c: iput v0, v10.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    006e: iget v0, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    0070: const-string v1, 'android:target_state'
    0072: invoke-virtual {v9, v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->getFragment(Landroid/os/Bundle;Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    0075: move-result-object v0
    0076: iput v0, v10.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    0078: iget v0, v10.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    007a: if-eqz v0, 0086
    007c: iget v0, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    007e: const-string v1, 'android:target_req_state'
    0080: invoke-virtual {v0, v1, v3}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I
    0083: move-result v0
    0084: iput v0, v10.Landroid/support/v4/app/Fragment;->mTargetRequestCode:I
    0086: iget v0, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    0088: const-string v1, 'android:user_visible_hint'
    008a: invoke-virtual {v0, v1, v5}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z
    008d: move-result v0
    008e: iput v0, v10.Landroid/support/v4/app/Fragment;->mUserVisibleHint:Z
    0090: iget v0, v10.Landroid/support/v4/app/Fragment;->mUserVisibleHint:Z
    0092: if-nez v0, 0099
    0094: iput v5, v10.Landroid/support/v4/app/Fragment;->mDeferStart:Z
    0096: if-le v11, v6, 0099
    0098: move(op=01) v11, v6
    0099: iget v0, v9.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    009b: iput v0, v10.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    009d: iget v0, v9.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    009f: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    00a1: iput v0, v10.Landroid/support/v4/app/Fragment;->mFragmentManager:Landroid/support/v4/app/FragmentManagerImpl;
    00a3: iput v3, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    00a5: iget v0, v9.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    00a7: invoke-virtual {v10, v0}, Landroid/support/v4/app/Fragment;->onAttach(Landroid/app/Activity;)V
    00aa: iget v0, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    00ac: if-nez v0, 00cd
    00ae: new-instance v0, Landroid/support/v4/app/SuperNotCalledException;
    00b0: new-instance v1, Ljava/lang/StringBuilder;
    00b2: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    00b5: const-string v2, 'Fragment '
    00b7: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00ba: move-result-object v1
    00bb: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00be: move-result-object v1
    00bf: const-string v2, ' did not call through to super.onAttach()'
    00c1: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00c4: move-result-object v1
    00c5: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00c8: move-result-object v1
    00c9: invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V
    00cc: throw v0
    00cd: iget v0, v9.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    00cf: invoke-virtual {v0, v10}, Landroid/support/v4/app/FragmentActivity;->onAttachFragment(Landroid/support/v4/app/Fragment;)V
    00d2: iget v0, v10.Landroid/support/v4/app/Fragment;->mRetaining:Z
    00d4: if-nez v0, 0100
    00d6: iput v3, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    00d8: iget v0, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    00da: invoke-virtual {v10, v0}, Landroid/support/v4/app/Fragment;->onCreate(Landroid/os/Bundle;)V
    00dd: iget v0, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    00df: if-nez v0, 0100
    00e1: new-instance v0, Landroid/support/v4/app/SuperNotCalledException;
    00e3: new-instance v1, Ljava/lang/StringBuilder;
    00e5: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    00e8: const-string v2, 'Fragment '
    00ea: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00ed: move-result-object v1
    00ee: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00f1: move-result-object v1
    00f2: const-string v2, ' did not call through to super.onCreate()'
    00f4: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00f7: move-result-object v1
    00f8: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00fb: move-result-object v1
    00fc: invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V
    00ff: throw v0
    0100: iput v3, v10.Landroid/support/v4/app/Fragment;->mRetaining:Z
    0102: iget v0, v10.Landroid/support/v4/app/Fragment;->mFromLayout:Z
    0104: if-eqz v0, 0136
    0106: iget v0, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    0108: invoke-virtual {v10, v0}, Landroid/support/v4/app/Fragment;->getLayoutInflater(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    010b: move-result-object v0
    010c: iget v1, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    010e: invoke-virtual {v10, v0, v7, v1}, Landroid/support/v4/app/Fragment;->onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    0111: move-result-object v0
    0112: iput v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0114: iget v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0116: if-eqz v0, 0195
    0118: iget v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    011a: iput v0, v10.Landroid/support/v4/app/Fragment;->mInnerView:Landroid/view/View;
    011c: iget v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    011e: invoke-static {v0}, Landroid/support/v4/app/NoSaveStateFrameLayout;->wrap(Landroid/view/View;)Landroid/view/ViewGroup;
    0121: move-result-object v0
    0122: iput v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0124: iget v0, v10.Landroid/support/v4/app/Fragment;->mHidden:Z
    0126: if-eqz v0, 012f
    0128: iget v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    012a: const/16 v1, 8 (0x8)
    012c: invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V
    012f: iget v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0131: iget v1, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    0133: invoke-virtual {v10, v0, v1}, Landroid/support/v4/app/Fragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    0136: if-le v11, v5, 0213
    0138: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    013a: if-eqz v0, 0154
    013c: const-string v0, 'FragmentManager'
    013e: new-instance v1, Ljava/lang/StringBuilder;
    0140: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0143: const-string v2, 'moveto ACTIVITY_CREATED: '
    0145: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0148: move-result-object v1
    0149: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    014c: move-result-object v1
    014d: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0150: move-result-object v1
    0151: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0154: iget v0, v10.Landroid/support/v4/app/Fragment;->mFromLayout:Z
    0156: if-nez v0, 01dd
    0158: iget v0, v10.Landroid/support/v4/app/Fragment;->mContainerId:I
    015a: if-eqz v0, 0198
    015c: iget v0, v9.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    015e: iget v1, v10.Landroid/support/v4/app/Fragment;->mContainerId:I
    0160: invoke-virtual {v0, v1}, Landroid/support/v4/app/FragmentActivity;->findViewById(I)Landroid/view/View;
    0163: move-result-object v0
    0164: check-cast v0, Landroid/view/ViewGroup;
    0166: if-nez v0, 0199
    0168: iget v1, v10.Landroid/support/v4/app/Fragment;->mRestored:Z
    016a: if-nez v1, 0199
    016c: new-instance v0, Ljava/lang/IllegalArgumentException;
    016e: new-instance v1, Ljava/lang/StringBuilder;
    0170: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0173: const-string v2, 'No view found for id 0x'
    0175: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0178: move-result-object v1
    0179: iget v2, v10.Landroid/support/v4/app/Fragment;->mContainerId:I
    017b: invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    017e: move-result-object v2
    017f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0182: move-result-object v1
    0183: const-string v2, ' for fragment '
    0185: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0188: move-result-object v1
    0189: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    018c: move-result-object v1
    018d: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0190: move-result-object v1
    0191: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0194: throw v0
    0195: iput v7, v10.Landroid/support/v4/app/Fragment;->mInnerView:Landroid/view/View;
    0197: goto 0136
    0198: move(op=07) v0, v7
    0199: iput v0, v10.Landroid/support/v4/app/Fragment;->mContainer:Landroid/view/ViewGroup;
    019b: iget v1, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    019d: invoke-virtual {v10, v1}, Landroid/support/v4/app/Fragment;->getLayoutInflater(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    01a0: move-result-object v1
    01a1: iget v2, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    01a3: invoke-virtual {v10, v1, v0, v2}, Landroid/support/v4/app/Fragment;->onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    01a6: move-result-object v1
    01a7: iput v1, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    01a9: iget v1, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    01ab: if-eqz v1, 0207
    01ad: iget v1, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    01af: iput v1, v10.Landroid/support/v4/app/Fragment;->mInnerView:Landroid/view/View;
    01b1: iget v1, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    01b3: invoke-static {v1}, Landroid/support/v4/app/NoSaveStateFrameLayout;->wrap(Landroid/view/View;)Landroid/view/ViewGroup;
    01b6: move-result-object v1
    01b7: iput v1, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    01b9: if-eqz v0, 01cb
    01bb: invoke-virtual {v9, v10, v12, v5, v13}, Landroid/support/v4/app/FragmentManagerImpl;->loadAnimation(Landroid/support/v4/app/Fragment;IZI)Landroid/view/animation/Animation;
    01be: move-result-object v1
    01bf: if-eqz v1, 01c6
    01c1: iget v2, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    01c3: invoke-virtual {v2, v1}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V
    01c6: iget v1, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    01c8: invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    01cb: iget v0, v10.Landroid/support/v4/app/Fragment;->mHidden:Z
    01cd: if-eqz v0, 01d6
    01cf: iget v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    01d1: const/16 v1, 8 (0x8)
    01d3: invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V
    01d6: iget v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    01d8: iget v1, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    01da: invoke-virtual {v10, v0, v1}, Landroid/support/v4/app/Fragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    01dd: iput v3, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    01df: iget v0, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    01e1: invoke-virtual {v10, v0}, Landroid/support/v4/app/Fragment;->onActivityCreated(Landroid/os/Bundle;)V
    01e4: iget v0, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    01e6: if-nez v0, 020a
    01e8: new-instance v0, Landroid/support/v4/app/SuperNotCalledException;
    01ea: new-instance v1, Ljava/lang/StringBuilder;
    01ec: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    01ef: const-string v2, 'Fragment '
    01f1: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01f4: move-result-object v1
    01f5: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    01f8: move-result-object v1
    01f9: const-string v2, ' did not call through to super.onActivityCreated()'
    01fb: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01fe: move-result-object v1
    01ff: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0202: move-result-object v1
    0203: invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V
    0206: throw v0
    0207: iput v7, v10.Landroid/support/v4/app/Fragment;->mInnerView:Landroid/view/View;
    0209: goto 01dd
    020a: iget v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    020c: if-eqz v0, 0211
    020e: invoke-virtual {v10}, Landroid/support/v4/app/Fragment;->restoreViewState()V
    0211: iput v7, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    0213: if-le v11, v6, 0259
    0215: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0217: if-eqz v0, 0231
    0219: const-string v0, 'FragmentManager'
    021b: new-instance v1, Ljava/lang/StringBuilder;
    021d: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0220: const-string v2, 'moveto STARTED: '
    0222: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0225: move-result-object v1
    0226: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0229: move-result-object v1
    022a: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    022d: move-result-object v1
    022e: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0231: iput v3, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    0233: invoke-virtual {v10}, Landroid/support/v4/app/Fragment;->performStart()V
    0236: iget v0, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    0238: if-nez v0, 0259
    023a: new-instance v0, Landroid/support/v4/app/SuperNotCalledException;
    023c: new-instance v1, Ljava/lang/StringBuilder;
    023e: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0241: const-string v2, 'Fragment '
    0243: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0246: move-result-object v1
    0247: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    024a: move-result-object v1
    024b: const-string v2, ' did not call through to super.onStart()'
    024d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0250: move-result-object v1
    0251: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0254: move-result-object v1
    0255: invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V
    0258: throw v0
    0259: if-le v11, v8, 0041
    025b: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    025d: if-eqz v0, 0277
    025f: const-string v0, 'FragmentManager'
    0261: new-instance v1, Ljava/lang/StringBuilder;
    0263: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0266: const-string v2, 'moveto RESUMED: '
    0268: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    026b: move-result-object v1
    026c: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    026f: move-result-object v1
    0270: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0273: move-result-object v1
    0274: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0277: iput v3, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    0279: iput v5, v10.Landroid/support/v4/app/Fragment;->mResumed:Z
    027b: invoke-virtual {v10}, Landroid/support/v4/app/Fragment;->onResume()V
    027e: iget v0, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    0280: if-nez v0, 02a1
    0282: new-instance v0, Landroid/support/v4/app/SuperNotCalledException;
    0284: new-instance v1, Ljava/lang/StringBuilder;
    0286: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0289: const-string v2, 'Fragment '
    028b: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    028e: move-result-object v1
    028f: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0292: move-result-object v1
    0293: const-string v2, ' did not call through to super.onResume()'
    0295: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0298: move-result-object v1
    0299: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    029c: move-result-object v1
    029d: invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V
    02a0: throw v0
    02a1: iput v7, v10.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    02a3: iput v7, v10.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    02a5: goto/16 0041
    02a7: iget v0, v10.Landroid/support/v4/app/Fragment;->mState:I
    02a9: if-le v0, v11, 0041
    02ab: iget v0, v10.Landroid/support/v4/app/Fragment;->mState:I
    02ad: packed-switch v0, +499 (-> 04a0)
    02b0: goto/16 0041
    02b2: if-ge v11, v5, 0041
    02b4: iget v0, v9.Landroid/support/v4/app/FragmentManagerImpl;->mDestroyed:Z
    02b6: if-eqz v0, 02c3
    02b8: iget v0, v10.Landroid/support/v4/app/Fragment;->mAnimatingAway:Landroid/view/View;
    02ba: if-eqz v0, 02c3
    02bc: iget v0, v10.Landroid/support/v4/app/Fragment;->mAnimatingAway:Landroid/view/View;
    02be: iput v7, v10.Landroid/support/v4/app/Fragment;->mAnimatingAway:Landroid/view/View;
    02c0: invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V
    02c3: iget v0, v10.Landroid/support/v4/app/Fragment;->mAnimatingAway:Landroid/view/View;
    02c5: if-eqz v0, 040e
    02c7: iput v11, v10.Landroid/support/v4/app/Fragment;->mStateAfterAnimating:I
    02c9: move(op=01) v11, v5
    02ca: goto/16 0041
    02cc: const/4 v0, 5
    02cd: if-ge v11, v0, 0315
    02cf: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    02d1: if-eqz v0, 02eb
    02d3: const-string v0, 'FragmentManager'
    02d5: new-instance v1, Ljava/lang/StringBuilder;
    02d7: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    02da: const-string v2, 'movefrom RESUMED: '
    02dc: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    02df: move-result-object v1
    02e0: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    02e3: move-result-object v1
    02e4: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    02e7: move-result-object v1
    02e8: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    02eb: iput v3, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    02ed: invoke-virtual {v10}, Landroid/support/v4/app/Fragment;->onPause()V
    02f0: iget v0, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    02f2: if-nez v0, 0313
    02f4: new-instance v0, Landroid/support/v4/app/SuperNotCalledException;
    02f6: new-instance v1, Ljava/lang/StringBuilder;
    02f8: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    02fb: const-string v2, 'Fragment '
    02fd: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0300: move-result-object v1
    0301: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0304: move-result-object v1
    0305: const-string v2, ' did not call through to super.onPause()'
    0307: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    030a: move-result-object v1
    030b: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    030e: move-result-object v1
    030f: invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V
    0312: throw v0
    0313: iput v3, v10.Landroid/support/v4/app/Fragment;->mResumed:Z
    0315: if-ge v11, v8, 035b
    0317: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0319: if-eqz v0, 0333
    031b: const-string v0, 'FragmentManager'
    031d: new-instance v1, Ljava/lang/StringBuilder;
    031f: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0322: const-string v2, 'movefrom STARTED: '
    0324: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0327: move-result-object v1
    0328: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    032b: move-result-object v1
    032c: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    032f: move-result-object v1
    0330: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0333: iput v3, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    0335: invoke-virtual {v10}, Landroid/support/v4/app/Fragment;->performStop()V
    0338: iget v0, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    033a: if-nez v0, 035b
    033c: new-instance v0, Landroid/support/v4/app/SuperNotCalledException;
    033e: new-instance v1, Ljava/lang/StringBuilder;
    0340: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0343: const-string v2, 'Fragment '
    0345: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0348: move-result-object v1
    0349: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    034c: move-result-object v1
    034d: const-string v2, ' did not call through to super.onStop()'
    034f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0352: move-result-object v1
    0353: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0356: move-result-object v1
    0357: invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V
    035a: throw v0
    035b: if-ge v11, v6, 037c
    035d: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    035f: if-eqz v0, 0379
    0361: const-string v0, 'FragmentManager'
    0363: new-instance v1, Ljava/lang/StringBuilder;
    0365: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0368: const-string v2, 'movefrom STOPPED: '
    036a: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    036d: move-result-object v1
    036e: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0371: move-result-object v1
    0372: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0375: move-result-object v1
    0376: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0379: invoke-virtual {v10}, Landroid/support/v4/app/Fragment;->performReallyStop()V
    037c: const/4 v0, 2
    037d: if-ge v11, v0, 02b2
    037f: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0381: if-eqz v0, 039b
    0383: const-string v0, 'FragmentManager'
    0385: new-instance v1, Ljava/lang/StringBuilder;
    0387: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    038a: const-string v2, 'movefrom ACTIVITY_CREATED: '
    038c: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    038f: move-result-object v1
    0390: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0393: move-result-object v1
    0394: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0397: move-result-object v1
    0398: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    039b: iget v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    039d: if-eqz v0, 03ae
    039f: iget v0, v9.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    03a1: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->isFinishing()Z
    03a4: move-result v0
    03a5: if-nez v0, 03ae
    03a7: iget v0, v10.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    03a9: if-nez v0, 03ae
    03ab: invoke-virtual {v9, v10}, Landroid/support/v4/app/FragmentManagerImpl;->saveFragmentViewState(Landroid/support/v4/app/Fragment;)V
    03ae: iput v3, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    03b0: invoke-virtual {v10}, Landroid/support/v4/app/Fragment;->performDestroyView()V
    03b3: iget v0, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    03b5: if-nez v0, 03d6
    03b7: new-instance v0, Landroid/support/v4/app/SuperNotCalledException;
    03b9: new-instance v1, Ljava/lang/StringBuilder;
    03bb: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    03be: const-string v2, 'Fragment '
    03c0: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    03c3: move-result-object v1
    03c4: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    03c7: move-result-object v1
    03c8: const-string v2, ' did not call through to super.onDestroyView()'
    03ca: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    03cd: move-result-object v1
    03ce: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    03d1: move-result-object v1
    03d2: invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V
    03d5: throw v0
    03d6: iget v0, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    03d8: if-eqz v0, 0406
    03da: iget v0, v10.Landroid/support/v4/app/Fragment;->mContainer:Landroid/view/ViewGroup;
    03dc: if-eqz v0, 0406
    03de: iget v0, v9.Landroid/support/v4/app/FragmentManagerImpl;->mCurState:I
    03e0: if-lez v0, 048f
    03e2: iget v0, v9.Landroid/support/v4/app/FragmentManagerImpl;->mDestroyed:Z
    03e4: if-nez v0, 048f
    03e6: invoke-virtual {v9, v10, v12, v3, v13}, Landroid/support/v4/app/FragmentManagerImpl;->loadAnimation(Landroid/support/v4/app/Fragment;IZI)Landroid/view/animation/Animation;
    03e9: move-result-object v0
    03ea: if-eqz v0, 03ff
    03ec: iget v1, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    03ee: iput v1, v10.Landroid/support/v4/app/Fragment;->mAnimatingAway:Landroid/view/View;
    03f0: iput v11, v10.Landroid/support/v4/app/Fragment;->mStateAfterAnimating:I
    03f2: new-instance v1, Landroid/support/v4/app/FragmentManagerImpl$5;
    03f4: invoke-direct {v1, v9, v10}, Landroid/support/v4/app/FragmentManagerImpl$5;-><init>(Landroid/support/v4/app/FragmentManagerImpl;Landroid/support/v4/app/Fragment;)V
    03f7: invoke-virtual {v0, v1}, Landroid/view/animation/Animation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V
    03fa: iget v1, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    03fc: invoke-virtual {v1, v0}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V
    03ff: iget v0, v10.Landroid/support/v4/app/Fragment;->mContainer:Landroid/view/ViewGroup;
    0401: iget v1, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0403: invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V
    0406: iput v7, v10.Landroid/support/v4/app/Fragment;->mContainer:Landroid/view/ViewGroup;
    0408: iput v7, v10.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    040a: iput v7, v10.Landroid/support/v4/app/Fragment;->mInnerView:Landroid/view/View;
    040c: goto/16 02b2
    040e: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0410: if-eqz v0, 042a
    0412: const-string v0, 'FragmentManager'
    0414: new-instance v1, Ljava/lang/StringBuilder;
    0416: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0419: const-string v2, 'movefrom CREATED: '
    041b: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    041e: move-result-object v1
    041f: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0422: move-result-object v1
    0423: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0426: move-result-object v1
    0427: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    042a: iget v0, v10.Landroid/support/v4/app/Fragment;->mRetaining:Z
    042c: if-nez v0, 0456
    042e: iput v3, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    0430: invoke-virtual {v10}, Landroid/support/v4/app/Fragment;->onDestroy()V
    0433: iget v0, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    0435: if-nez v0, 0456
    0437: new-instance v0, Landroid/support/v4/app/SuperNotCalledException;
    0439: new-instance v1, Ljava/lang/StringBuilder;
    043b: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    043e: const-string v2, 'Fragment '
    0440: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0443: move-result-object v1
    0444: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0447: move-result-object v1
    0448: const-string v2, ' did not call through to super.onDestroy()'
    044a: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    044d: move-result-object v1
    044e: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0451: move-result-object v1
    0452: invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V
    0455: throw v0
    0456: iput v3, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    0458: invoke-virtual {v10}, Landroid/support/v4/app/Fragment;->onDetach()V
    045b: iget v0, v10.Landroid/support/v4/app/Fragment;->mCalled:Z
    045d: if-nez v0, 047e
    045f: new-instance v0, Landroid/support/v4/app/SuperNotCalledException;
    0461: new-instance v1, Ljava/lang/StringBuilder;
    0463: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0466: const-string v2, 'Fragment '
    0468: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    046b: move-result-object v1
    046c: invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    046f: move-result-object v1
    0470: const-string v2, ' did not call through to super.onDetach()'
    0472: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0475: move-result-object v1
    0476: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0479: move-result-object v1
    047a: invoke-direct {v0, v1}, Landroid/support/v4/app/SuperNotCalledException;-><init>(Ljava/lang/String;)V
    047d: throw v0
    047e: if-nez v14, 0041
    0480: iget v0, v10.Landroid/support/v4/app/Fragment;->mRetaining:Z
    0482: if-nez v0, 0489
    0484: invoke-virtual {v9, v10}, Landroid/support/v4/app/FragmentManagerImpl;->makeInactive(Landroid/support/v4/app/Fragment;)V
    0487: goto/16 0041
    0489: iput v7, v10.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    048b: iput v7, v10.Landroid/support/v4/app/Fragment;->mFragmentManager:Landroid/support/v4/app/FragmentManagerImpl;
    048d: goto/16 0041
    048f: move(op=07) v0, v7
    0490: goto/16 03ea
    0492: packed-switch-payload first=0 targets=[6, 248, 469, 469, 539]
    04a0: packed-switch-payload first=1 targets=[5, 207, 174, 104, 31]

  [Virtual Method] noteStateNotSaved() -> V
    // registers=2, ins=1, outs=0, insns_size=4
    0000: const/4 v0, 0
    0001: iput v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mStateSaved:Z
    0003: return-void

  [Virtual Method] performPendingDeferredStart(Landroid/support/v4/app/Fragment;) -> V
    // registers=8, ins=2, outs=6, insns_size=25
    0000: const/4 v3, 0
    0001: iget v0, v7.Landroid/support/v4/app/Fragment;->mDeferStart:Z
    0003: if-eqz v0, 000c
    0005: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mExecutingActions:Z
    0007: if-eqz v0, 000d
    0009: const/4 v0, 1
    000a: iput v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mHavePendingDeferredStart:Z
    000c: return-void
    000d: iput v3, v7.Landroid/support/v4/app/Fragment;->mDeferStart:Z
    000f: iget v2, v6.Landroid/support/v4/app/FragmentManagerImpl;->mCurState:I
    0011: move(op=07) v0, v6
    0012: move(op=07) v1, v7
    0013: move(op=01) v4, v3
    0014: move(op=01) v5, v3
    0015: invoke-virtual/range {v0..v5}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(Landroid/support/v4/app/Fragment;IIIZ)V
    0018: goto 000c

  [Virtual Method] popBackStack() -> V
    // registers=3, ins=1, outs=3, insns_size=10
    0000: new-instance v0, Landroid/support/v4/app/FragmentManagerImpl$2;
    0002: invoke-direct {v0, v2}, Landroid/support/v4/app/FragmentManagerImpl$2;-><init>(Landroid/support/v4/app/FragmentManagerImpl;)V
    0005: const/4 v1, 0
    0006: invoke-virtual {v2, v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->enqueueAction(Ljava/lang/Runnable;Z)V
    0009: return-void

  [Virtual Method] popBackStack(I, I) -> V
    // registers=6, ins=3, outs=4, insns_size=37
    0000: if-gez v4, 001b
    0002: new-instance v0, Ljava/lang/IllegalArgumentException;
    0004: new-instance v1, Ljava/lang/StringBuilder;
    0006: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0009: const-string v2, 'Bad id: '
    000b: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000e: move-result-object v1
    000f: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0016: move-result-object v1
    0017: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    001a: throw v0
    001b: new-instance v0, Landroid/support/v4/app/FragmentManagerImpl$4;
    001d: invoke-direct {v0, v3, v4, v5}, Landroid/support/v4/app/FragmentManagerImpl$4;-><init>(Landroid/support/v4/app/FragmentManagerImpl;II)V
    0020: const/4 v1, 0
    0021: invoke-virtual {v3, v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->enqueueAction(Ljava/lang/Runnable;Z)V
    0024: return-void

  [Virtual Method] popBackStack(Ljava/lang/String;, I) -> V
    // registers=5, ins=3, outs=4, insns_size=10
    0000: new-instance v0, Landroid/support/v4/app/FragmentManagerImpl$3;
    0002: invoke-direct {v0, v2, v3, v4}, Landroid/support/v4/app/FragmentManagerImpl$3;-><init>(Landroid/support/v4/app/FragmentManagerImpl;Ljava/lang/String;I)V
    0005: const/4 v1, 0
    0006: invoke-virtual {v2, v0, v1}, Landroid/support/v4/app/FragmentManagerImpl;->enqueueAction(Ljava/lang/Runnable;Z)V
    0009: return-void

  [Virtual Method] popBackStackImmediate() -> Z
    // registers=5, ins=1, outs=5, insns_size=18
    0000: invoke-direct {v4}, Landroid/support/v4/app/FragmentManagerImpl;->checkStateLoss()V
    0003: invoke-virtual {v4}, Landroid/support/v4/app/FragmentManagerImpl;->executePendingTransactions()Z
    0006: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0008: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    000a: const/4 v1, 0
    000b: const/4 v2, -1
    000c: const/4 v3, 0
    000d: invoke-virtual {v4, v0, v1, v2, v3}, Landroid/support/v4/app/FragmentManagerImpl;->popBackStackState(Landroid/os/Handler;Ljava/lang/String;II)Z
    0010: move-result v0
    0011: return v0

  [Virtual Method] popBackStackImmediate(I, I) -> Z
    // registers=6, ins=3, outs=5, insns_size=43
    0000: invoke-direct {v3}, Landroid/support/v4/app/FragmentManagerImpl;->checkStateLoss()V
    0003: invoke-virtual {v3}, Landroid/support/v4/app/FragmentManagerImpl;->executePendingTransactions()Z
    0006: if-gez v4, 0021
    0008: new-instance v0, Ljava/lang/IllegalArgumentException;
    000a: new-instance v1, Ljava/lang/StringBuilder;
    000c: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000f: const-string v2, 'Bad id: '
    0011: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0018: move-result-object v1
    0019: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001c: move-result-object v1
    001d: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0020: throw v0
    0021: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0023: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    0025: const/4 v1, 0
    0026: invoke-virtual {v3, v0, v1, v4, v5}, Landroid/support/v4/app/FragmentManagerImpl;->popBackStackState(Landroid/os/Handler;Ljava/lang/String;II)Z
    0029: move-result v0
    002a: return v0

  [Virtual Method] popBackStackImmediate(Ljava/lang/String;, I) -> Z
    // registers=5, ins=3, outs=5, insns_size=16
    0000: invoke-direct {v2}, Landroid/support/v4/app/FragmentManagerImpl;->checkStateLoss()V
    0003: invoke-virtual {v2}, Landroid/support/v4/app/FragmentManagerImpl;->executePendingTransactions()Z
    0006: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0008: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    000a: const/4 v1, -1
    000b: invoke-virtual {v2, v0, v3, v1, v4}, Landroid/support/v4/app/FragmentManagerImpl;->popBackStackState(Landroid/os/Handler;Ljava/lang/String;II)Z
    000e: move-result v0
    000f: return v0

  [Virtual Method] popBackStackState(Landroid/os/Handler;, Ljava/lang/String;, I, I) -> Z
    // registers=13, ins=5, outs=2, insns_size=226
    0000: const/4 v2, 1
    0001: const/4 v3, 0
    0002: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0004: if-nez v0, 0007
    0006: return v3
    0007: if-nez v10, 0029
    0009: if-gez v11, 0029
    000b: binop/lit8(op=dd) v0, v12, 1 (0x1)
    000d: if-nez v0, 0029
    000f: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0011: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0014: move-result v0
    0015: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0017: if-ltz v0, 0006
    0019: iget v1, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    001b: invoke-virtual {v1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    001e: move-result-object v0
    001f: check-cast v0, Landroid/support/v4/app/BackStackRecord;
    0021: invoke-virtual {v0, v2}, Landroid/support/v4/app/BackStackRecord;->popFromBackStack(Z)V
    0024: invoke-virtual {v8}, Landroid/support/v4/app/FragmentManagerImpl;->reportBackStackChanged()V
    0027: move(op=01) v3, v2
    0028: goto 0006
    0029: const/4 v0, -1
    002a: if-nez v10, 002e
    002c: if-ltz v11, 007d
    002e: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0030: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0033: move-result v0
    0034: binop/lit8(op=d8) v1, v0, -1 (-0x1)
    0036: if-ltz v1, 004c
    0038: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    003a: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    003d: move-result-object v0
    003e: check-cast v0, Landroid/support/v4/app/BackStackRecord;
    0040: if-eqz v10, 0073
    0042: invoke-virtual {v0}, Landroid/support/v4/app/BackStackRecord;->getName()Ljava/lang/String;
    0045: move-result-object v4
    0046: invoke-virtual {v10, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0049: move-result v4
    004a: if-eqz v4, 0073
    004c: if-ltz v1, 0006
    004e: binop/lit8(op=dd) v0, v12, 1 (0x1)
    0050: if-eqz v0, 007c
    0052: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0054: if-ltz v1, 007c
    0056: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0058: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    005b: move-result-object v0
    005c: check-cast v0, Landroid/support/v4/app/BackStackRecord;
    005e: if-eqz v10, 006a
    0060: invoke-virtual {v0}, Landroid/support/v4/app/BackStackRecord;->getName()Ljava/lang/String;
    0063: move-result-object v4
    0064: invoke-virtual {v10, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0067: move-result v4
    0068: if-nez v4, 0070
    006a: if-ltz v11, 007c
    006c: iget v0, v0.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    006e: if-ne v11, v0, 007c
    0070: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0072: goto 0054
    0073: if-ltz v11, 0079
    0075: iget v0, v0.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    0077: if-eq v11, v0, 004c
    0079: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    007b: goto 0036
    007c: move(op=01) v0, v1
    007d: iget v1, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    007f: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0082: move-result v1
    0083: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0085: if-eq v0, v1, 0006
    0087: new-instance v5, Ljava/util/ArrayList;
    0089: invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V
    008c: iget v1, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    008e: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0091: move-result v1
    0092: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0094: if-le v1, v0, 00a2
    0096: iget v4, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0098: invoke-virtual {v4, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    009b: move-result-object v4
    009c: invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    009f: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    00a1: goto 0094
    00a2: invoke-virtual {v5}, Ljava/util/ArrayList;->size()I
    00a5: move-result v0
    00a6: binop/lit8(op=d8) v6, v0, -1 (-0x1)
    00a8: move(op=01) v4, v3
    00a9: if-gt v4, v6, 00dd
    00ab: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    00ad: if-eqz v0, 00cb
    00af: const-string v0, 'FragmentManager'
    00b1: new-instance v1, Ljava/lang/StringBuilder;
    00b3: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    00b6: const-string v7, 'Popping back stack state: '
    00b8: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00bb: move-result-object v1
    00bc: invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    00bf: move-result-object v7
    00c0: invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00c3: move-result-object v1
    00c4: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00c7: move-result-object v1
    00c8: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00cb: invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    00ce: move-result-object v0
    00cf: check-cast v0, Landroid/support/v4/app/BackStackRecord;
    00d1: if-ne v4, v6, 00db
    00d3: move(op=01) v1, v2
    00d4: invoke-virtual {v0, v1}, Landroid/support/v4/app/BackStackRecord;->popFromBackStack(Z)V
    00d7: binop/lit8(op=d8) v0, v4, 1 (0x1)
    00d9: move(op=01) v4, v0
    00da: goto 00a9
    00db: move(op=01) v1, v3
    00dc: goto 00d4
    00dd: invoke-virtual {v8}, Landroid/support/v4/app/FragmentManagerImpl;->reportBackStackChanged()V
    00e0: goto/16 0027

  [Virtual Method] putFragment(Landroid/os/Bundle;, Ljava/lang/String;, Landroid/support/v4/app/Fragment;) -> V
    // registers=7, ins=4, outs=3, insns_size=41
    0000: iget v0, v6.Landroid/support/v4/app/Fragment;->mIndex:I
    0002: if-gez v0, 0023
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: new-instance v1, Ljava/lang/StringBuilder;
    0008: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v2, 'Fragment '
    000d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v1
    0011: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: const-string v2, ' is not currently in the FragmentManager'
    0017: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001a: move-result-object v1
    001b: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001e: move-result-object v1
    001f: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0022: throw v0
    0023: iget v0, v6.Landroid/support/v4/app/Fragment;->mIndex:I
    0025: invoke-virtual {v4, v5, v0}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V
    0028: return-void

  [Virtual Method] removeFragment(Landroid/support/v4/app/Fragment;, I, I) -> V
    // registers=10, ins=4, outs=6, insns_size=93
    0000: const/4 v1, 1
    0001: const/4 v5, 0
    0002: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0004: if-eqz v0, 002a
    0006: const-string v0, 'FragmentManager'
    0008: new-instance v2, Ljava/lang/StringBuilder;
    000a: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    000d: const-string v3, 'remove: '
    000f: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: move-result-object v2
    0013: invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0016: move-result-object v2
    0017: const-string v3, ' nesting='
    0019: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: move-result-object v2
    001d: iget v3, v7.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    001f: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0022: move-result-object v2
    0023: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0026: move-result-object v2
    0027: invoke-static {v0, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    002a: invoke-virtual {v7}, Landroid/support/v4/app/Fragment;->isInBackStack()Z
    002d: move-result v0
    002e: if-nez v0, 0059
    0030: move(op=01) v0, v1
    0031: iget v2, v7.Landroid/support/v4/app/Fragment;->mDetached:Z
    0033: if-eqz v2, 0037
    0035: if-eqz v0, 0058
    0037: iget v2, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0039: if-eqz v2, 0040
    003b: iget v2, v6.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    003d: invoke-virtual {v2, v7}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    0040: iget v2, v7.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    0042: if-eqz v2, 004a
    0044: iget v2, v7.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    0046: if-eqz v2, 004a
    0048: iput v1, v6.Landroid/support/v4/app/FragmentManagerImpl;->mNeedMenuInvalidate:Z
    004a: iput v5, v7.Landroid/support/v4/app/Fragment;->mAdded:Z
    004c: iput v1, v7.Landroid/support/v4/app/Fragment;->mRemoving:Z
    004e: if-eqz v0, 005b
    0050: move(op=01) v2, v5
    0051: move(op=07) v0, v6
    0052: move(op=07) v1, v7
    0053: move(op=01) v3, v8
    0054: move(op=01) v4, v9
    0055: invoke-virtual/range {v0..v5}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(Landroid/support/v4/app/Fragment;IIIZ)V
    0058: return-void
    0059: move(op=01) v0, v5
    005a: goto 0031
    005b: move(op=01) v2, v1
    005c: goto 0051

  [Virtual Method] removeOnBackStackChangedListener(Landroid/support/v4/app/FragmentManager$OnBackStackChangedListener;) -> V
    // registers=3, ins=2, outs=2, insns_size=10
    0000: iget v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackChangeListeners:Ljava/util/ArrayList;
    0002: if-eqz v0, 0009
    0004: iget v0, v1.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackChangeListeners:Ljava/util/ArrayList;
    0006: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    0009: return-void

  [Virtual Method] reportBackStackChanged() -> V
    // registers=3, ins=1, outs=2, insns_size=30
    0000: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackChangeListeners:Ljava/util/ArrayList;
    0002: if-eqz v0, 001d
    0004: const/4 v0, 0
    0005: move(op=01) v1, v0
    0006: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackChangeListeners:Ljava/util/ArrayList;
    0008: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000b: move-result v0
    000c: if-ge v1, v0, 001d
    000e: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackChangeListeners:Ljava/util/ArrayList;
    0010: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0013: move-result-object v0
    0014: check-cast v0, Landroid/support/v4/app/FragmentManager$OnBackStackChangedListener;
    0016: invoke-interface {v0}, Landroid/support/v4/app/FragmentManager$OnBackStackChangedListener;->onBackStackChanged()V
    0019: binop/lit8(op=d8) v0, v1, 1 (0x1)
    001b: move(op=01) v1, v0
    001c: goto 0006
    001d: return-void

  [Virtual Method] restoreAllState(Landroid/os/Parcelable;, Ljava/util/ArrayList;) -> V
    // registers=11, ins=3, outs=3, insns_size=571
    0000: const/4 v7, 0
    0001: const/4 v2, 0
    0002: if-nez v9, 0005
    0004: return-void
    0005: check-cast v9, Landroid/support/v4/app/FragmentManagerState;
    0007: iget v0, v9.Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;
    0009: if-eqz v0, 0004
    000b: if-eqz v10, 0065
    000d: move(op=01) v1, v2
    000e: invoke-virtual {v10}, Ljava/util/ArrayList;->size()I
    0011: move-result v0
    0012: if-ge v1, v0, 0065
    0014: invoke-virtual {v10, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0017: move-result-object v0
    0018: check-cast v0, Landroid/support/v4/app/Fragment;
    001a: sget v3, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    001c: if-eqz v3, 0036
    001e: const-string v3, 'FragmentManager'
    0020: new-instance v4, Ljava/lang/StringBuilder;
    0022: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    0025: const-string v5, 'restoreAllState: re-attaching retained '
    0027: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002a: move-result-object v4
    002b: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    002e: move-result-object v4
    002f: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0032: move-result-object v4
    0033: invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0036: iget v3, v9.Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;
    0038: iget v4, v0.Landroid/support/v4/app/Fragment;->mIndex:I
    003a: aget(op=46) v3, v3[v4]
    003c: iput v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    003e: iput v7, v0.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    0040: iput v2, v0.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    0042: iput v2, v0.Landroid/support/v4/app/Fragment;->mInLayout:Z
    0044: iput v2, v0.Landroid/support/v4/app/Fragment;->mAdded:Z
    0046: iput v7, v0.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    0048: iget v4, v3.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    004a: if-eqz v4, 0061
    004c: iget v4, v3.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    004e: iget v5, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0050: invoke-virtual {v5}, Landroid/support/v4/app/FragmentActivity;->getClassLoader()Ljava/lang/ClassLoader;
    0053: move-result-object v5
    0054: invoke-virtual {v4, v5}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V
    0057: iget v3, v3.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    0059: const-string v4, 'android:view_state'
    005b: invoke-virtual {v3, v4}, Landroid/os/Bundle;->getSparseParcelableArray(Ljava/lang/String;)Landroid/util/SparseArray;
    005e: move-result-object v3
    005f: iput v3, v0.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    0061: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0063: move(op=01) v1, v0
    0064: goto 000e
    0065: new-instance v0, Ljava/util/ArrayList;
    0067: iget v1, v9.Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;
    0069: move(op=21) v1, v1
    006a: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V
    006d: iput v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    006f: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    0071: if-eqz v0, 0078
    0073: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    0075: invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V
    0078: move(op=01) v0, v2
    0079: iget v1, v9.Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;
    007b: move(op=21) v1, v1
    007c: if-ge v0, v1, 0112
    007e: iget v1, v9.Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;
    0080: aget(op=46) v1, v1[v0]
    0082: if-eqz v1, 00ba
    0084: iget v3, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0086: invoke-virtual {v1, v3}, Landroid/support/v4/app/FragmentState;->instantiate(Landroid/support/v4/app/FragmentActivity;)Landroid/support/v4/app/Fragment;
    0089: move-result-object v3
    008a: sget v4, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    008c: if-eqz v4, 00b0
    008e: const-string v4, 'FragmentManager'
    0090: new-instance v5, Ljava/lang/StringBuilder;
    0092: invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V
    0095: const-string v6, 'restoreAllState: adding #'
    0097: invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    009a: move-result-object v5
    009b: invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    009e: move-result-object v5
    009f: const-string v6, ': '
    00a1: invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a4: move-result-object v5
    00a5: invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00a8: move-result-object v5
    00a9: invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00ac: move-result-object v5
    00ad: invoke-static {v4, v5}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00b0: iget v4, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    00b2: invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    00b5: iput v7, v1.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    00b7: binop/lit8(op=d8) v0, v0, 1 (0x1)
    00b9: goto 0079
    00ba: sget v1, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    00bc: if-eqz v1, 00dc
    00be: const-string v1, 'FragmentManager'
    00c0: new-instance v3, Ljava/lang/StringBuilder;
    00c2: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    00c5: const-string v4, 'restoreAllState: adding #'
    00c7: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00ca: move-result-object v3
    00cb: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    00ce: move-result-object v3
    00cf: const-string v4, ': (null)'
    00d1: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00d4: move-result-object v3
    00d5: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00d8: move-result-object v3
    00d9: invoke-static {v1, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00dc: iget v1, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    00de: invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    00e1: iget v1, v8.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    00e3: if-nez v1, 00ec
    00e5: new-instance v1, Ljava/util/ArrayList;
    00e7: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    00ea: iput v1, v8.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    00ec: sget v1, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    00ee: if-eqz v1, 0108
    00f0: const-string v1, 'FragmentManager'
    00f2: new-instance v3, Ljava/lang/StringBuilder;
    00f4: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    00f7: const-string v4, 'restoreAllState: adding avail #'
    00f9: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00fc: move-result-object v3
    00fd: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0100: move-result-object v3
    0101: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0104: move-result-object v3
    0105: invoke-static {v1, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0108: iget v1, v8.Landroid/support/v4/app/FragmentManagerImpl;->mAvailIndices:Ljava/util/ArrayList;
    010a: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    010d: move-result-object v3
    010e: invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0111: goto 00b7
    0112: if-eqz v10, 0166
    0114: move(op=01) v3, v2
    0115: invoke-virtual {v10}, Ljava/util/ArrayList;->size()I
    0118: move-result v0
    0119: if-ge v3, v0, 0166
    011b: invoke-virtual {v10, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    011e: move-result-object v0
    011f: check-cast v0, Landroid/support/v4/app/Fragment;
    0121: iget v1, v0.Landroid/support/v4/app/Fragment;->mTargetIndex:I
    0123: if-ltz v1, 013b
    0125: iget v1, v0.Landroid/support/v4/app/Fragment;->mTargetIndex:I
    0127: iget v4, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0129: invoke-virtual {v4}, Ljava/util/ArrayList;->size()I
    012c: move-result v4
    012d: if-ge v1, v4, 013f
    012f: iget v1, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0131: iget v4, v0.Landroid/support/v4/app/Fragment;->mTargetIndex:I
    0133: invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0136: move-result-object v1
    0137: check-cast v1, Landroid/support/v4/app/Fragment;
    0139: iput v1, v0.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    013b: binop/lit8(op=d8) v0, v3, 1 (0x1)
    013d: move(op=01) v3, v0
    013e: goto 0115
    013f: const-string v1, 'FragmentManager'
    0141: new-instance v4, Ljava/lang/StringBuilder;
    0143: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    0146: const-string v5, 'Re-attaching retained fragment '
    0148: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    014b: move-result-object v4
    014c: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    014f: move-result-object v4
    0150: const-string v5, ' target no longer exists: '
    0152: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0155: move-result-object v4
    0156: iget v5, v0.Landroid/support/v4/app/Fragment;->mTargetIndex:I
    0158: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    015b: move-result-object v4
    015c: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    015f: move-result-object v4
    0160: invoke-static {v1, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    0163: iput v7, v0.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    0165: goto 013b
    0166: iget v0, v9.Landroid/support/v4/app/FragmentManagerState;->mAdded:[I
    0168: if-eqz v0, 01d7
    016a: new-instance v0, Ljava/util/ArrayList;
    016c: iget v1, v9.Landroid/support/v4/app/FragmentManagerState;->mAdded:[I
    016e: move(op=21) v1, v1
    016f: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V
    0172: iput v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0174: move(op=01) v1, v2
    0175: iget v0, v9.Landroid/support/v4/app/FragmentManagerState;->mAdded:[I
    0177: move(op=21) v0, v0
    0178: if-ge v1, v0, 01d9
    017a: iget v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    017c: iget v3, v9.Landroid/support/v4/app/FragmentManagerState;->mAdded:[I
    017e: aget(op=44) v3, v3[v1]
    0180: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0183: move-result-object v0
    0184: check-cast v0, Landroid/support/v4/app/Fragment;
    0186: if-nez v0, 01a5
    0188: new-instance v0, Ljava/lang/IllegalStateException;
    018a: new-instance v2, Ljava/lang/StringBuilder;
    018c: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    018f: const-string v3, 'No instantiated fragment for index #'
    0191: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0194: move-result-object v2
    0195: iget v3, v9.Landroid/support/v4/app/FragmentManagerState;->mAdded:[I
    0197: aget(op=44) v1, v3[v1]
    0199: invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    019c: move-result-object v1
    019d: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    01a0: move-result-object v1
    01a1: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    01a4: throw v0
    01a5: const/4 v3, 1
    01a6: iput v3, v0.Landroid/support/v4/app/Fragment;->mAdded:Z
    01a8: sget v3, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    01aa: if-eqz v3, 01ce
    01ac: const-string v3, 'FragmentManager'
    01ae: new-instance v4, Ljava/lang/StringBuilder;
    01b0: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    01b3: const-string v5, 'restoreAllState: making added #'
    01b5: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01b8: move-result-object v4
    01b9: invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    01bc: move-result-object v4
    01bd: const-string v5, ': '
    01bf: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01c2: move-result-object v4
    01c3: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    01c6: move-result-object v4
    01c7: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    01ca: move-result-object v4
    01cb: invoke-static {v3, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    01ce: iget v3, v8.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    01d0: invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    01d3: binop/lit8(op=d8) v0, v1, 1 (0x1)
    01d5: move(op=01) v1, v0
    01d6: goto 0175
    01d7: iput v7, v8.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    01d9: iget v0, v9.Landroid/support/v4/app/FragmentManagerState;->mBackStack:[Landroid/support/v4/app/BackStackState;
    01db: if-eqz v0, 0237
    01dd: new-instance v0, Ljava/util/ArrayList;
    01df: iget v1, v9.Landroid/support/v4/app/FragmentManagerState;->mBackStack:[Landroid/support/v4/app/BackStackState;
    01e1: move(op=21) v1, v1
    01e2: invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V
    01e5: iput v0, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    01e7: iget v0, v9.Landroid/support/v4/app/FragmentManagerState;->mBackStack:[Landroid/support/v4/app/BackStackState;
    01e9: move(op=21) v0, v0
    01ea: if-ge v2, v0, 0004
    01ec: iget v0, v9.Landroid/support/v4/app/FragmentManagerState;->mBackStack:[Landroid/support/v4/app/BackStackState;
    01ee: aget(op=46) v0, v0[v2]
    01f0: invoke-virtual {v0, v8}, Landroid/support/v4/app/BackStackState;->instantiate(Landroid/support/v4/app/FragmentManagerImpl;)Landroid/support/v4/app/BackStackRecord;
    01f3: move-result-object v0
    01f4: sget v1, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    01f6: if-eqz v1, 0226
    01f8: const-string v1, 'FragmentManager'
    01fa: new-instance v3, Ljava/lang/StringBuilder;
    01fc: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    01ff: const-string v4, 'restoreAllState: adding bse #'
    0201: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0204: move-result-object v3
    0205: invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0208: move-result-object v3
    0209: const-string v4, ' (index '
    020b: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    020e: move-result-object v3
    020f: iget v4, v0.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    0211: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0214: move-result-object v3
    0215: const-string v4, '): '
    0217: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    021a: move-result-object v3
    021b: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    021e: move-result-object v3
    021f: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0222: move-result-object v3
    0223: invoke-static {v1, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0226: iget v1, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0228: invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    022b: iget v1, v0.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    022d: if-ltz v1, 0234
    022f: iget v1, v0.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    0231: invoke-virtual {v8, v1, v0}, Landroid/support/v4/app/FragmentManagerImpl;->setBackStackIndex(ILandroid/support/v4/app/BackStackRecord;)V
    0234: binop/lit8(op=d8) v2, v2, 1 (0x1)
    0236: goto 01e7
    0237: iput v7, v8.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0239: goto/16 0004

  [Virtual Method] retainNonConfig() -> Ljava/util/ArrayList;
    // registers=7, ins=1, outs=2, insns_size=87
    0000: const/4 v1, 0
    0001: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0003: if-eqz v0, 0056
    0005: const/4 v0, 0
    0006: move(op=01) v3, v0
    0007: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0009: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000c: move-result v0
    000d: if-ge v3, v0, 0056
    000f: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0011: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0014: move-result-object v0
    0015: check-cast v0, Landroid/support/v4/app/Fragment;
    0017: if-eqz v0, 0050
    0019: iget v2, v0.Landroid/support/v4/app/Fragment;->mRetainInstance:Z
    001b: if-eqz v2, 0050
    001d: if-nez v1, 0024
    001f: new-instance v1, Ljava/util/ArrayList;
    0021: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    0024: invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0027: const/4 v2, 1
    0028: iput v2, v0.Landroid/support/v4/app/Fragment;->mRetaining:Z
    002a: iget v2, v0.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    002c: if-eqz v2, 0054
    002e: iget v2, v0.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    0030: iget v2, v2.Landroid/support/v4/app/Fragment;->mIndex:I
    0032: iput v2, v0.Landroid/support/v4/app/Fragment;->mTargetIndex:I
    0034: sget v2, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0036: if-eqz v2, 0050
    0038: const-string v2, 'FragmentManager'
    003a: new-instance v4, Ljava/lang/StringBuilder;
    003c: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    003f: const-string v5, 'retainNonConfig: keeping retained '
    0041: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0044: move-result-object v4
    0045: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0048: move-result-object v0
    0049: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    004c: move-result-object v0
    004d: invoke-static {v2, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0050: binop/lit8(op=d8) v0, v3, 1 (0x1)
    0052: move(op=01) v3, v0
    0053: goto 0007
    0054: const/4 v2, -1
    0055: goto 0032
    0056: return-object v1

  [Virtual Method] saveAllState() -> Landroid/os/Parcelable;
    // registers=12, ins=1, outs=5, insns_size=551
    0000: const/4 v1, 1
    0001: const/4 v3, 0
    0002: const/4 v4, 0
    0003: invoke-virtual {v11}, Landroid/support/v4/app/FragmentManagerImpl;->execPendingActions()Z
    0006: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->HONEYCOMB:Z
    0008: if-eqz v0, 000c
    000a: iput v1, v11.Landroid/support/v4/app/FragmentManagerImpl;->mStateSaved:Z
    000c: iget v0, v11.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    000e: if-eqz v0, 0018
    0010: iget v0, v11.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0012: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0015: move-result v0
    0016: if-gtz v0, 0019
    0018: return-object v3
    0019: iget v0, v11.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    001b: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    001e: move-result v6
    001f: new-array v7, v6, [Landroid/support/v4/app/FragmentState;
    0021: move(op=01) v5, v4
    0022: move(op=01) v2, v4
    0023: if-ge v5, v6, 0121
    0025: iget v0, v11.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0027: invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    002a: move-result-object v0
    002b: check-cast v0, Landroid/support/v4/app/Fragment;
    002d: if-eqz v0, 0224
    002f: iget v2, v0.Landroid/support/v4/app/Fragment;->mIndex:I
    0031: if-gez v2, 0070
    0033: new-instance v1, Ljava/lang/StringBuilder;
    0035: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0038: const-string v2, 'Failure saving state: active '
    003a: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003d: move-result-object v1
    003e: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0041: move-result-object v1
    0042: const-string v2, ' has cleared index: '
    0044: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0047: move-result-object v1
    0048: iget v0, v0.Landroid/support/v4/app/Fragment;->mIndex:I
    004a: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    004d: move-result-object v0
    004e: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0051: move-result-object v0
    0052: const-string v1, 'FragmentManager'
    0054: invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    0057: const-string v1, '  '
    0059: new-instance v2, Ljava/io/PrintWriter;
    005b: new-instance v5, Landroid/support/v4/util/LogWriter;
    005d: const-string v6, 'FragmentManager'
    005f: invoke-direct {v5, v6}, Landroid/support/v4/util/LogWriter;-><init>(Ljava/lang/String;)V
    0062: invoke-direct {v2, v5}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V
    0065: new-array v4, v4, [Ljava/lang/String;
    0067: invoke-virtual {v11, v1, v3, v2, v4}, Landroid/support/v4/app/FragmentManagerImpl;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    006a: new-instance v1, Ljava/lang/IllegalStateException;
    006c: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    006f: throw v1
    0070: new-instance v2, Landroid/support/v4/app/FragmentState;
    0072: invoke-direct {v2, v0}, Landroid/support/v4/app/FragmentState;-><init>(Landroid/support/v4/app/Fragment;)V
    0075: aput(op=4d) v2, v7[v5]
    0077: iget v8, v0.Landroid/support/v4/app/Fragment;->mState:I
    0079: if-lez v8, 011c
    007b: iget v8, v2.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    007d: if-nez v8, 011c
    007f: invoke-virtual {v11, v0}, Landroid/support/v4/app/FragmentManagerImpl;->saveFragmentBasicState(Landroid/support/v4/app/Fragment;)Landroid/os/Bundle;
    0082: move-result-object v8
    0083: iput v8, v2.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    0085: iget v8, v0.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    0087: if-eqz v8, 00ed
    0089: iget v8, v0.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    008b: iget v8, v8.Landroid/support/v4/app/Fragment;->mIndex:I
    008d: if-gez v8, 00cc
    008f: new-instance v1, Ljava/lang/StringBuilder;
    0091: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0094: const-string v2, 'Failure saving state: '
    0096: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0099: move-result-object v1
    009a: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    009d: move-result-object v1
    009e: const-string v2, ' has target not in fragment manager: '
    00a0: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a3: move-result-object v1
    00a4: iget v0, v0.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    00a6: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00a9: move-result-object v0
    00aa: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00ad: move-result-object v0
    00ae: const-string v1, 'FragmentManager'
    00b0: invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    00b3: const-string v1, '  '
    00b5: new-instance v2, Ljava/io/PrintWriter;
    00b7: new-instance v5, Landroid/support/v4/util/LogWriter;
    00b9: const-string v6, 'FragmentManager'
    00bb: invoke-direct {v5, v6}, Landroid/support/v4/util/LogWriter;-><init>(Ljava/lang/String;)V
    00be: invoke-direct {v2, v5}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V
    00c1: new-array v4, v4, [Ljava/lang/String;
    00c3: invoke-virtual {v11, v1, v3, v2, v4}, Landroid/support/v4/app/FragmentManagerImpl;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    00c6: new-instance v1, Ljava/lang/IllegalStateException;
    00c8: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    00cb: throw v1
    00cc: iget v8, v2.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    00ce: if-nez v8, 00d7
    00d0: new-instance v8, Landroid/os/Bundle;
    00d2: invoke-direct {v8}, Landroid/os/Bundle;-><init>()V
    00d5: iput v8, v2.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    00d7: iget v8, v2.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    00d9: const-string v9, 'android:target_state'
    00db: iget v10, v0.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    00dd: invoke-virtual {v11, v8, v9, v10}, Landroid/support/v4/app/FragmentManagerImpl;->putFragment(Landroid/os/Bundle;Ljava/lang/String;Landroid/support/v4/app/Fragment;)V
    00e0: iget v8, v0.Landroid/support/v4/app/Fragment;->mTargetRequestCode:I
    00e2: if-eqz v8, 00ed
    00e4: iget v8, v2.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    00e6: const-string v9, 'android:target_req_state'
    00e8: iget v10, v0.Landroid/support/v4/app/Fragment;->mTargetRequestCode:I
    00ea: invoke-virtual {v8, v9, v10}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V
    00ed: sget v8, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    00ef: if-eqz v8, 0115
    00f1: const-string v8, 'FragmentManager'
    00f3: new-instance v9, Ljava/lang/StringBuilder;
    00f5: invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V
    00f8: const-string v10, 'Saved state of '
    00fa: invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00fd: move-result-object v9
    00fe: invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0101: move-result-object v0
    0102: const-string v9, ': '
    0104: invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0107: move-result-object v0
    0108: iget v2, v2.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    010a: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    010d: move-result-object v0
    010e: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0111: move-result-object v0
    0112: invoke-static {v8, v0}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0115: move(op=01) v0, v1
    0116: binop/lit8(op=d8) v2, v5, 1 (0x1)
    0118: move(op=01) v5, v2
    0119: move(op=01) v2, v0
    011a: goto/16 0023
    011c: iget v8, v0.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    011e: iput v8, v2.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    0120: goto 00ed
    0121: if-nez v2, 0130
    0123: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0125: if-eqz v0, 0018
    0127: const-string v0, 'FragmentManager'
    0129: const-string v1, 'saveAllState: no fragments!'
    012b: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    012e: goto/16 0018
    0130: iget v0, v11.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0132: if-eqz v0, 01c5
    0134: iget v0, v11.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0136: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0139: move-result v5
    013a: if-lez v5, 01c5
    013c: new-array v1, v5, [I
    013e: move(op=01) v2, v4
    013f: if-ge v2, v5, 01c6
    0141: iget v0, v11.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    0143: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0146: move-result-object v0
    0147: check-cast v0, Landroid/support/v4/app/Fragment;
    0149: iget v0, v0.Landroid/support/v4/app/Fragment;->mIndex:I
    014b: aput(op=4b) v0, v1[v2]
    014d: aget(op=44) v0, v1[v2]
    014f: if-gez v0, 0194
    0151: new-instance v0, Ljava/lang/StringBuilder;
    0153: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0156: const-string v5, 'Failure saving state: active '
    0158: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    015b: move-result-object v0
    015c: iget v5, v11.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    015e: invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0161: move-result-object v5
    0162: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0165: move-result-object v0
    0166: const-string v5, ' has cleared index: '
    0168: invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    016b: move-result-object v0
    016c: aget(op=44) v1, v1[v2]
    016e: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0171: move-result-object v0
    0172: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0175: move-result-object v0
    0176: const-string v1, 'FragmentManager'
    0178: invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    017b: const-string v1, '  '
    017d: new-instance v2, Ljava/io/PrintWriter;
    017f: new-instance v5, Landroid/support/v4/util/LogWriter;
    0181: const-string v6, 'FragmentManager'
    0183: invoke-direct {v5, v6}, Landroid/support/v4/util/LogWriter;-><init>(Ljava/lang/String;)V
    0186: invoke-direct {v2, v5}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V
    0189: new-array v4, v4, [Ljava/lang/String;
    018b: invoke-virtual {v11, v1, v3, v2, v4}, Landroid/support/v4/app/FragmentManagerImpl;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    018e: new-instance v1, Ljava/lang/IllegalStateException;
    0190: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0193: throw v1
    0194: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0196: if-eqz v0, 01c0
    0198: const-string v0, 'FragmentManager'
    019a: new-instance v6, Ljava/lang/StringBuilder;
    019c: invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V
    019f: const-string v8, 'saveAllState: adding fragment #'
    01a1: invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01a4: move-result-object v6
    01a5: invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    01a8: move-result-object v6
    01a9: const-string v8, ': '
    01ab: invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01ae: move-result-object v6
    01af: iget v8, v11.Landroid/support/v4/app/FragmentManagerImpl;->mAdded:Ljava/util/ArrayList;
    01b1: invoke-virtual {v8, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    01b4: move-result-object v8
    01b5: invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    01b8: move-result-object v6
    01b9: invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    01bc: move-result-object v6
    01bd: invoke-static {v0, v6}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    01c0: binop/lit8(op=d8) v0, v2, 1 (0x1)
    01c2: move(op=01) v2, v0
    01c3: goto/16 013f
    01c5: move(op=07) v1, v3
    01c6: iget v0, v11.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    01c8: if-eqz v0, 0216
    01ca: iget v0, v11.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    01cc: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    01cf: move-result v5
    01d0: if-lez v5, 0216
    01d2: new-array v3, v5, [Landroid/support/v4/app/BackStackState;
    01d4: move(op=01) v2, v4
    01d5: if-ge v2, v5, 0216
    01d7: new-instance v4, Landroid/support/v4/app/BackStackState;
    01d9: iget v0, v11.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    01db: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    01de: move-result-object v0
    01df: check-cast v0, Landroid/support/v4/app/BackStackRecord;
    01e1: invoke-direct {v4, v11, v0}, Landroid/support/v4/app/BackStackState;-><init>(Landroid/support/v4/app/FragmentManagerImpl;Landroid/support/v4/app/BackStackRecord;)V
    01e4: aput(op=4d) v4, v3[v2]
    01e6: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    01e8: if-eqz v0, 0212
    01ea: const-string v0, 'FragmentManager'
    01ec: new-instance v4, Ljava/lang/StringBuilder;
    01ee: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    01f1: const-string v6, 'saveAllState: adding back stack #'
    01f3: invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01f6: move-result-object v4
    01f7: invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    01fa: move-result-object v4
    01fb: const-string v6, ': '
    01fd: invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0200: move-result-object v4
    0201: iget v6, v11.Landroid/support/v4/app/FragmentManagerImpl;->mBackStack:Ljava/util/ArrayList;
    0203: invoke-virtual {v6, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0206: move-result-object v6
    0207: invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    020a: move-result-object v4
    020b: invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    020e: move-result-object v4
    020f: invoke-static {v0, v4}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0212: binop/lit8(op=d8) v0, v2, 1 (0x1)
    0214: move(op=01) v2, v0
    0215: goto 01d5
    0216: new-instance v0, Landroid/support/v4/app/FragmentManagerState;
    0218: invoke-direct {v0}, Landroid/support/v4/app/FragmentManagerState;-><init>()V
    021b: iput v7, v0.Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;
    021d: iput v1, v0.Landroid/support/v4/app/FragmentManagerState;->mAdded:[I
    021f: iput v3, v0.Landroid/support/v4/app/FragmentManagerState;->mBackStack:[Landroid/support/v4/app/BackStackState;
    0221: move(op=07) v3, v0
    0222: goto/16 0018
    0224: move(op=01) v0, v2
    0225: goto/16 0116

  [Virtual Method] saveFragmentBasicState(Landroid/support/v4/app/Fragment;) -> Landroid/os/Bundle;
    // registers=5, ins=2, outs=3, insns_size=75
    0000: const/4 v1, 0
    0001: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mStateBundle:Landroid/os/Bundle;
    0003: if-nez v0, 000c
    0005: new-instance v0, Landroid/os/Bundle;
    0007: invoke-direct {v0}, Landroid/os/Bundle;-><init>()V
    000a: iput v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mStateBundle:Landroid/os/Bundle;
    000c: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mStateBundle:Landroid/os/Bundle;
    000e: invoke-virtual {v4, v0}, Landroid/support/v4/app/Fragment;->onSaveInstanceState(Landroid/os/Bundle;)V
    0011: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mStateBundle:Landroid/os/Bundle;
    0013: invoke-virtual {v0}, Landroid/os/Bundle;->isEmpty()Z
    0016: move-result v0
    0017: if-nez v0, 0049
    0019: iget v0, v3.Landroid/support/v4/app/FragmentManagerImpl;->mStateBundle:Landroid/os/Bundle;
    001b: iput v1, v3.Landroid/support/v4/app/FragmentManagerImpl;->mStateBundle:Landroid/os/Bundle;
    001d: iget v1, v4.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    001f: if-eqz v1, 0024
    0021: invoke-virtual {v3, v4}, Landroid/support/v4/app/FragmentManagerImpl;->saveFragmentViewState(Landroid/support/v4/app/Fragment;)V
    0024: iget v1, v4.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    0026: if-eqz v1, 0036
    0028: if-nez v0, 002f
    002a: new-instance v0, Landroid/os/Bundle;
    002c: invoke-direct {v0}, Landroid/os/Bundle;-><init>()V
    002f: const-string v1, 'android:view_state'
    0031: iget v2, v4.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    0033: invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putSparseParcelableArray(Ljava/lang/String;Landroid/util/SparseArray;)V
    0036: iget v1, v4.Landroid/support/v4/app/Fragment;->mUserVisibleHint:Z
    0038: if-nez v1, 0048
    003a: if-nez v0, 0041
    003c: new-instance v0, Landroid/os/Bundle;
    003e: invoke-direct {v0}, Landroid/os/Bundle;-><init>()V
    0041: const-string v1, 'android:user_visible_hint'
    0043: iget v2, v4.Landroid/support/v4/app/Fragment;->mUserVisibleHint:Z
    0045: invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V
    0048: return-object v0
    0049: move(op=07) v0, v1
    004a: goto 001d

  [Virtual Method] saveFragmentInstanceState(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/Fragment$SavedState;
    // registers=5, ins=2, outs=2, insns_size=52
    0000: const/4 v0, 0
    0001: iget v1, v4.Landroid/support/v4/app/Fragment;->mIndex:I
    0003: if-gez v1, 0024
    0005: new-instance v0, Ljava/lang/IllegalStateException;
    0007: new-instance v1, Ljava/lang/StringBuilder;
    0009: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000c: const-string v2, 'Fragment '
    000e: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0011: move-result-object v1
    0012: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0015: move-result-object v1
    0016: const-string v2, ' is not currently in the FragmentManager'
    0018: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001b: move-result-object v1
    001c: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001f: move-result-object v1
    0020: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0023: throw v0
    0024: iget v1, v4.Landroid/support/v4/app/Fragment;->mState:I
    0026: if-lez v1, 0033
    0028: invoke-virtual {v3, v4}, Landroid/support/v4/app/FragmentManagerImpl;->saveFragmentBasicState(Landroid/support/v4/app/Fragment;)Landroid/os/Bundle;
    002b: move-result-object v1
    002c: if-eqz v1, 0033
    002e: new-instance v0, Landroid/support/v4/app/Fragment$SavedState;
    0030: invoke-direct {v0, v1}, Landroid/support/v4/app/Fragment$SavedState;-><init>(Landroid/os/Bundle;)V
    0033: return-object v0

  [Virtual Method] saveFragmentViewState(Landroid/support/v4/app/Fragment;) -> V
    // registers=4, ins=2, outs=2, insns_size=45
    0000: iget v0, v3.Landroid/support/v4/app/Fragment;->mInnerView:Landroid/view/View;
    0002: if-nez v0, 0005
    0004: return-void
    0005: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateArray:Landroid/util/SparseArray;
    0007: if-nez v0, 0027
    0009: new-instance v0, Landroid/util/SparseArray;
    000b: invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V
    000e: iput v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateArray:Landroid/util/SparseArray;
    0010: iget v0, v3.Landroid/support/v4/app/Fragment;->mInnerView:Landroid/view/View;
    0012: iget v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateArray:Landroid/util/SparseArray;
    0014: invoke-virtual {v0, v1}, Landroid/view/View;->saveHierarchyState(Landroid/util/SparseArray;)V
    0017: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateArray:Landroid/util/SparseArray;
    0019: invoke-virtual {v0}, Landroid/util/SparseArray;->size()I
    001c: move-result v0
    001d: if-lez v0, 0004
    001f: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateArray:Landroid/util/SparseArray;
    0021: iput v0, v3.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    0023: const/4 v0, 0
    0024: iput v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateArray:Landroid/util/SparseArray;
    0026: goto 0004
    0027: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mStateArray:Landroid/util/SparseArray;
    0029: invoke-virtual {v0}, Landroid/util/SparseArray;->clear()V
    002c: goto 0010

  [Virtual Method] setBackStackIndex(I, Landroid/support/v4/app/BackStackRecord;) -> V
    // registers=7, ins=3, outs=3, insns_size=171
    0000: monitor-enter v4
    0001: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    0003: if-nez v0, 000c
    0005: new-instance v0, Ljava/util/ArrayList;
    0007: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    000a: iput v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    000c: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    000e: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0011: move-result v0
    0012: if-ge v5, v0, 0041
    0014: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0016: if-eqz v0, 003a
    0018: const-string v0, 'FragmentManager'
    001a: new-instance v1, Ljava/lang/StringBuilder;
    001c: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    001f: const-string v2, 'Setting back stack index '
    0021: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0024: move-result-object v1
    0025: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0028: move-result-object v1
    0029: const-string v2, ' to '
    002b: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002e: move-result-object v1
    002f: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0032: move-result-object v1
    0033: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0036: move-result-object v1
    0037: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    003a: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    003c: invoke-virtual {v0, v5, v6}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;
    003f: monitor-exit v4
    0040: return-void
    0041: if-ge v0, v5, 007c
    0043: iget v1, v4.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    0045: const/4 v2, 0
    0046: invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0049: iget v1, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    004b: if-nez v1, 0054
    004d: new-instance v1, Ljava/util/ArrayList;
    004f: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    0052: iput v1, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    0054: sget v1, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0056: if-eqz v1, 0070
    0058: const-string v1, 'FragmentManager'
    005a: new-instance v2, Ljava/lang/StringBuilder;
    005c: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    005f: const-string v3, 'Adding available back stack index '
    0061: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0064: move-result-object v2
    0065: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0068: move-result-object v2
    0069: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    006c: move-result-object v2
    006d: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0070: iget v1, v4.Landroid/support/v4/app/FragmentManagerImpl;->mAvailBackStackIndices:Ljava/util/ArrayList;
    0072: invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0075: move-result-object v2
    0076: invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0079: binop/lit8(op=d8) v0, v0, 1 (0x1)
    007b: goto 0041
    007c: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    007e: if-eqz v0, 00a2
    0080: const-string v0, 'FragmentManager'
    0082: new-instance v1, Ljava/lang/StringBuilder;
    0084: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0087: const-string v2, 'Adding back stack index '
    0089: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    008c: move-result-object v1
    008d: invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0090: move-result-object v1
    0091: const-string v2, ' with '
    0093: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0096: move-result-object v1
    0097: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    009a: move-result-object v1
    009b: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    009e: move-result-object v1
    009f: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00a2: iget v0, v4.Landroid/support/v4/app/FragmentManagerImpl;->mBackStackIndices:Ljava/util/ArrayList;
    00a4: invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    00a7: goto 003f
    00a8: move-exception v0
    00a9: monitor-exit v4
    00aa: throw v0

  [Virtual Method] showFragment(Landroid/support/v4/app/Fragment;, I, I) -> V
    // registers=9, ins=4, outs=5, insns_size=74
    0000: const/4 v4, 1
    0001: const/4 v3, 0
    0002: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0004: if-eqz v0, 001e
    0006: const-string v0, 'FragmentManager'
    0008: new-instance v1, Ljava/lang/StringBuilder;
    000a: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000d: const-string v2, 'show: '
    000f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0016: move-result-object v1
    0017: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001a: move-result-object v1
    001b: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001e: iget v0, v6.Landroid/support/v4/app/Fragment;->mHidden:Z
    0020: if-eqz v0, 0049
    0022: iput v3, v6.Landroid/support/v4/app/Fragment;->mHidden:Z
    0024: iget v0, v6.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0026: if-eqz v0, 0038
    0028: invoke-virtual {v5, v6, v7, v4, v8}, Landroid/support/v4/app/FragmentManagerImpl;->loadAnimation(Landroid/support/v4/app/Fragment;IZI)Landroid/view/animation/Animation;
    002b: move-result-object v0
    002c: if-eqz v0, 0033
    002e: iget v1, v6.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0030: invoke-virtual {v1, v0}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V
    0033: iget v0, v6.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0035: invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V
    0038: iget v0, v6.Landroid/support/v4/app/Fragment;->mAdded:Z
    003a: if-eqz v0, 0046
    003c: iget v0, v6.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    003e: if-eqz v0, 0046
    0040: iget v0, v6.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    0042: if-eqz v0, 0046
    0044: iput v4, v5.Landroid/support/v4/app/FragmentManagerImpl;->mNeedMenuInvalidate:Z
    0046: invoke-virtual {v6, v3}, Landroid/support/v4/app/Fragment;->onHiddenChanged(Z)V
    0049: return-void

  [Virtual Method] startPendingDeferredFragments() -> V
    // registers=3, ins=1, outs=2, insns_size=32
    0000: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0002: if-nez v0, 0005
    0004: return-void
    0005: const/4 v0, 0
    0006: move(op=01) v1, v0
    0007: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0009: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    000c: move-result v0
    000d: if-ge v1, v0, 0004
    000f: iget v0, v2.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    0011: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0014: move-result-object v0
    0015: check-cast v0, Landroid/support/v4/app/Fragment;
    0017: if-eqz v0, 001c
    0019: invoke-virtual {v2, v0}, Landroid/support/v4/app/FragmentManagerImpl;->performPendingDeferredStart(Landroid/support/v4/app/Fragment;)V
    001c: binop/lit8(op=d8) v0, v1, 1 (0x1)
    001e: move(op=01) v1, v0
    001f: goto 0007

  [Virtual Method] toString() -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=43
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: const/16 v1, 128 (0x80)
    0004: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V
    0007: const-string v1, 'FragmentManager{'
    0009: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000c: invoke-static {v2}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I
    000f: move-result v1
    0010: invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0013: move-result-object v1
    0014: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0017: const-string v1, ' in '
    0019: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: iget v1, v2.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    001e: invoke-static {v1, v0}, Landroid/support/v4/util/DebugUtils;->buildShortClassTag(Ljava/lang/Object;Ljava/lang/StringBuilder;)V
    0021: const-string v1, '}}'
    0023: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0026: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0029: move-result-object v0
    002a: return-object v0