=== CLASS Landroid/support/v4/app/BackStackState; (Source: BackStackRecord.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/Parcelable;
  [Static Field] CREATOR: Landroid/os/Parcelable$Creator;
  [Instance Field] mBreadCrumbShortTitleRes: I
  [Instance Field] mBreadCrumbShortTitleText: Ljava/lang/CharSequence;
  [Instance Field] mBreadCrumbTitleRes: I
  [Instance Field] mBreadCrumbTitleText: Ljava/lang/CharSequence;
  [Instance Field] mIndex: I
  [Instance Field] mName: Ljava/lang/String;
  [Instance Field] mOps: [I
  [Instance Field] mTransition: I
  [Instance Field] mTransitionStyle: I

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=8
    0000: new-instance v0, Landroid/support/v4/app/BackStackState$1;
    0002: invoke-direct {v0}, Landroid/support/v4/app/BackStackState$1;-><init>()V
    0005: sput v0, Landroid/support/v4/app/BackStackState;->CREATOR:Landroid/os/Parcelable$Creator;
    0007: return-void

  [Direct Method] <init>(Landroid/os/Parcel;) -> V
    // registers=3, ins=2, outs=2, insns_size=66
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: invoke-virtual {v2}, Landroid/os/Parcel;->createIntArray()[I
    0006: move-result-object v0
    0007: iput v0, v1.Landroid/support/v4/app/BackStackState;->mOps:[I
    0009: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    000c: move-result v0
    000d: iput v0, v1.Landroid/support/v4/app/BackStackState;->mTransition:I
    000f: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    0012: move-result v0
    0013: iput v0, v1.Landroid/support/v4/app/BackStackState;->mTransitionStyle:I
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0018: move-result-object v0
    0019: iput v0, v1.Landroid/support/v4/app/BackStackState;->mName:Ljava/lang/String;
    001b: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001e: move-result v0
    001f: iput v0, v1.Landroid/support/v4/app/BackStackState;->mIndex:I
    0021: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    0024: move-result v0
    0025: iput v0, v1.Landroid/support/v4/app/BackStackState;->mBreadCrumbTitleRes:I
    0027: sget v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;
    0029: invoke-interface {v0, v2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    002c: move-result-object v0
    002d: check-cast v0, Ljava/lang/CharSequence;
    002f: iput v0, v1.Landroid/support/v4/app/BackStackState;->mBreadCrumbTitleText:Ljava/lang/CharSequence;
    0031: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    0034: move-result v0
    0035: iput v0, v1.Landroid/support/v4/app/BackStackState;->mBreadCrumbShortTitleRes:I
    0037: sget v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;
    0039: invoke-interface {v0, v2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    003c: move-result-object v0
    003d: check-cast v0, Ljava/lang/CharSequence;
    003f: iput v0, v1.Landroid/support/v4/app/BackStackState;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;
    0041: return-void

  [Direct Method] <init>(Landroid/support/v4/app/FragmentManagerImpl;, Landroid/support/v4/app/BackStackRecord;) -> V
    // registers=11, ins=3, outs=2, insns_size=192
    0000: const/4 v3, 0
    0001: invoke-direct {v8}, Ljava/lang/Object;-><init>()V
    0004: iget v0, v10.Landroid/support/v4/app/BackStackRecord;->mHead:Landroid/support/v4/app/BackStackRecord$Op;
    0006: move(op=07) v1, v0
    0007: move(op=01) v0, v3
    0008: if-eqz v1, 0018
    000a: iget v2, v1.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    000c: if-eqz v2, 0015
    000e: iget v2, v1.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    0010: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    0013: move-result v2
    0014: binop/2addr(op=b0) v0, v2
    0015: iget v1, v1.Landroid/support/v4/app/BackStackRecord$Op;->next:Landroid/support/v4/app/BackStackRecord$Op;
    0017: goto 0008
    0018: iget v1, v10.Landroid/support/v4/app/BackStackRecord;->mNumOp:I
    001a: binop/lit8(op=da) v1, v1, 7 (0x7)
    001c: binop/2addr(op=b0) v0, v1
    001d: new-array v0, v0, [I
    001f: iput v0, v8.Landroid/support/v4/app/BackStackState;->mOps:[I
    0021: iget v0, v10.Landroid/support/v4/app/BackStackRecord;->mAddToBackStack:Z
    0023: if-nez v0, 002d
    0025: new-instance v0, Ljava/lang/IllegalStateException;
    0027: const-string v1, 'Not on back stack'
    0029: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    002c: throw v0
    002d: iget v0, v10.Landroid/support/v4/app/BackStackRecord;->mHead:Landroid/support/v4/app/BackStackRecord$Op;
    002f: move(op=07) v5, v0
    0030: move(op=01) v0, v3
    0031: if-eqz v5, 009f
    0033: iget v1, v8.Landroid/support/v4/app/BackStackState;->mOps:[I
    0035: binop/lit8(op=d8) v2, v0, 1 (0x1)
    0037: iget v4, v5.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    0039: aput(op=4b) v4, v1[v0]
    003b: iget v1, v8.Landroid/support/v4/app/BackStackState;->mOps:[I
    003d: binop/lit8(op=d8) v4, v2, 1 (0x1)
    003f: iget v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    0041: if-eqz v0, 0091
    0043: iget v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    0045: iget v0, v0.Landroid/support/v4/app/Fragment;->mIndex:I
    0047: aput(op=4b) v0, v1[v2]
    0049: iget v0, v8.Landroid/support/v4/app/BackStackState;->mOps:[I
    004b: binop/lit8(op=d8) v1, v4, 1 (0x1)
    004d: iget v2, v5.Landroid/support/v4/app/BackStackRecord$Op;->enterAnim:I
    004f: aput(op=4b) v2, v0[v4]
    0051: iget v0, v8.Landroid/support/v4/app/BackStackState;->mOps:[I
    0053: binop/lit8(op=d8) v2, v1, 1 (0x1)
    0055: iget v4, v5.Landroid/support/v4/app/BackStackRecord$Op;->exitAnim:I
    0057: aput(op=4b) v4, v0[v1]
    0059: iget v0, v8.Landroid/support/v4/app/BackStackState;->mOps:[I
    005b: binop/lit8(op=d8) v1, v2, 1 (0x1)
    005d: iget v4, v5.Landroid/support/v4/app/BackStackRecord$Op;->popEnterAnim:I
    005f: aput(op=4b) v4, v0[v2]
    0061: iget v0, v8.Landroid/support/v4/app/BackStackState;->mOps:[I
    0063: binop/lit8(op=d8) v2, v1, 1 (0x1)
    0065: iget v4, v5.Landroid/support/v4/app/BackStackRecord$Op;->popExitAnim:I
    0067: aput(op=4b) v4, v0[v1]
    0069: iget v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    006b: if-eqz v0, 0098
    006d: iget v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    006f: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0072: move-result v6
    0073: iget v0, v8.Landroid/support/v4/app/BackStackState;->mOps:[I
    0075: binop/lit8(op=d8) v1, v2, 1 (0x1)
    0077: aput(op=4b) v6, v0[v2]
    0079: move(op=01) v2, v3
    007a: if-ge v2, v6, 0093
    007c: iget v7, v8.Landroid/support/v4/app/BackStackState;->mOps:[I
    007e: binop/lit8(op=d8) v4, v1, 1 (0x1)
    0080: iget v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    0082: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0085: move-result-object v0
    0086: check-cast v0, Landroid/support/v4/app/Fragment;
    0088: iget v0, v0.Landroid/support/v4/app/Fragment;->mIndex:I
    008a: aput(op=4b) v0, v7[v1]
    008c: binop/lit8(op=d8) v0, v2, 1 (0x1)
    008e: move(op=01) v2, v0
    008f: move(op=01) v1, v4
    0090: goto 007a
    0091: const/4 v0, -1
    0092: goto 0047
    0093: move(op=01) v0, v1
    0094: iget v1, v5.Landroid/support/v4/app/BackStackRecord$Op;->next:Landroid/support/v4/app/BackStackRecord$Op;
    0096: move(op=07) v5, v1
    0097: goto 0031
    0098: iget v1, v8.Landroid/support/v4/app/BackStackState;->mOps:[I
    009a: binop/lit8(op=d8) v0, v2, 1 (0x1)
    009c: aput(op=4b) v3, v1[v2]
    009e: goto 0094
    009f: iget v0, v10.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    00a1: iput v0, v8.Landroid/support/v4/app/BackStackState;->mTransition:I
    00a3: iget v0, v10.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    00a5: iput v0, v8.Landroid/support/v4/app/BackStackState;->mTransitionStyle:I
    00a7: iget v0, v10.Landroid/support/v4/app/BackStackRecord;->mName:Ljava/lang/String;
    00a9: iput v0, v8.Landroid/support/v4/app/BackStackState;->mName:Ljava/lang/String;
    00ab: iget v0, v10.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    00ad: iput v0, v8.Landroid/support/v4/app/BackStackState;->mIndex:I
    00af: iget v0, v10.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleRes:I
    00b1: iput v0, v8.Landroid/support/v4/app/BackStackState;->mBreadCrumbTitleRes:I
    00b3: iget v0, v10.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleText:Ljava/lang/CharSequence;
    00b5: iput v0, v8.Landroid/support/v4/app/BackStackState;->mBreadCrumbTitleText:Ljava/lang/CharSequence;
    00b7: iget v0, v10.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleRes:I
    00b9: iput v0, v8.Landroid/support/v4/app/BackStackState;->mBreadCrumbShortTitleRes:I
    00bb: iget v0, v10.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;
    00bd: iput v0, v8.Landroid/support/v4/app/BackStackState;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;
    00bf: return-void

  [Virtual Method] describeContents() -> I
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] instantiate(Landroid/support/v4/app/FragmentManagerImpl;) -> Landroid/support/v4/app/BackStackRecord;
    // registers=12, ins=2, outs=2, insns_size=249
    0000: const/4 v9, 1
    0001: const/4 v1, 0
    0002: new-instance v4, Landroid/support/v4/app/BackStackRecord;
    0004: invoke-direct {v4, v11}, Landroid/support/v4/app/BackStackRecord;-><init>(Landroid/support/v4/app/FragmentManagerImpl;)V
    0007: move(op=01) v0, v1
    0008: iget v2, v10.Landroid/support/v4/app/BackStackState;->mOps:[I
    000a: move(op=21) v2, v2
    000b: if-ge v0, v2, 00d3
    000d: new-instance v5, Landroid/support/v4/app/BackStackRecord$Op;
    000f: invoke-direct {v5}, Landroid/support/v4/app/BackStackRecord$Op;-><init>()V
    0012: iget v2, v10.Landroid/support/v4/app/BackStackState;->mOps:[I
    0014: binop/lit8(op=d8) v3, v0, 1 (0x1)
    0016: aget(op=44) v0, v2[v0]
    0018: iput v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->cmd:I
    001a: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    001c: if-eqz v0, 0044
    001e: const-string v0, 'FragmentManager'
    0020: new-instance v2, Ljava/lang/StringBuilder;
    0022: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0025: const-string v6, 'BSE '
    0027: invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002a: move-result-object v2
    002b: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    002e: move-result-object v2
    002f: const-string v6, ' set base fragment #'
    0031: invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0034: move-result-object v2
    0035: iget v6, v10.Landroid/support/v4/app/BackStackState;->mOps:[I
    0037: aget(op=44) v6, v6[v3]
    0039: invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    003c: move-result-object v2
    003d: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0040: move-result-object v2
    0041: invoke-static {v0, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0044: iget v0, v10.Landroid/support/v4/app/BackStackState;->mOps:[I
    0046: binop/lit8(op=d8) v2, v3, 1 (0x1)
    0048: aget(op=44) v0, v0[v3]
    004a: if-ltz v0, 00ca
    004c: iget v3, v11.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    004e: invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0051: move-result-object v0
    0052: check-cast v0, Landroid/support/v4/app/Fragment;
    0054: iput v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    0056: iget v0, v10.Landroid/support/v4/app/BackStackState;->mOps:[I
    0058: binop/lit8(op=d8) v3, v2, 1 (0x1)
    005a: aget(op=44) v0, v0[v2]
    005c: iput v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->enterAnim:I
    005e: iget v0, v10.Landroid/support/v4/app/BackStackState;->mOps:[I
    0060: binop/lit8(op=d8) v2, v3, 1 (0x1)
    0062: aget(op=44) v0, v0[v3]
    0064: iput v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->exitAnim:I
    0066: iget v0, v10.Landroid/support/v4/app/BackStackState;->mOps:[I
    0068: binop/lit8(op=d8) v3, v2, 1 (0x1)
    006a: aget(op=44) v0, v0[v2]
    006c: iput v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->popEnterAnim:I
    006e: iget v0, v10.Landroid/support/v4/app/BackStackState;->mOps:[I
    0070: binop/lit8(op=d8) v2, v3, 1 (0x1)
    0072: aget(op=44) v0, v0[v3]
    0074: iput v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->popExitAnim:I
    0076: iget v3, v10.Landroid/support/v4/app/BackStackState;->mOps:[I
    0078: binop/lit8(op=d8) v0, v2, 1 (0x1)
    007a: aget(op=44) v6, v3[v2]
    007c: if-lez v6, 00ce
    007e: new-instance v2, Ljava/util/ArrayList;
    0080: invoke-direct {v2, v6}, Ljava/util/ArrayList;-><init>(I)V
    0083: iput v2, v5.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    0085: move(op=01) v2, v1
    0086: if-ge v2, v6, 00ce
    0088: sget v3, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    008a: if-eqz v3, 00b2
    008c: const-string v3, 'FragmentManager'
    008e: new-instance v7, Ljava/lang/StringBuilder;
    0090: invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V
    0093: const-string v8, 'BSE '
    0095: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0098: move-result-object v7
    0099: invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    009c: move-result-object v7
    009d: const-string v8, ' set remove fragment #'
    009f: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00a2: move-result-object v7
    00a3: iget v8, v10.Landroid/support/v4/app/BackStackState;->mOps:[I
    00a5: aget(op=44) v8, v8[v0]
    00a7: invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    00aa: move-result-object v7
    00ab: invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00ae: move-result-object v7
    00af: invoke-static {v3, v7}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00b2: iget v7, v11.Landroid/support/v4/app/FragmentManagerImpl;->mActive:Ljava/util/ArrayList;
    00b4: iget v8, v10.Landroid/support/v4/app/BackStackState;->mOps:[I
    00b6: binop/lit8(op=d8) v3, v0, 1 (0x1)
    00b8: aget(op=44) v0, v8[v0]
    00ba: invoke-virtual {v7, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    00bd: move-result-object v0
    00be: check-cast v0, Landroid/support/v4/app/Fragment;
    00c0: iget v7, v5.Landroid/support/v4/app/BackStackRecord$Op;->removed:Ljava/util/ArrayList;
    00c2: invoke-virtual {v7, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    00c5: binop/lit8(op=d8) v0, v2, 1 (0x1)
    00c7: move(op=01) v2, v0
    00c8: move(op=01) v0, v3
    00c9: goto 0086
    00ca: const/4 v0, 0
    00cb: iput v0, v5.Landroid/support/v4/app/BackStackRecord$Op;->fragment:Landroid/support/v4/app/Fragment;
    00cd: goto 0056
    00ce: invoke-virtual {v4, v5}, Landroid/support/v4/app/BackStackRecord;->addOp(Landroid/support/v4/app/BackStackRecord$Op;)V
    00d1: goto/16 0008
    00d3: iget v0, v10.Landroid/support/v4/app/BackStackState;->mTransition:I
    00d5: iput v0, v4.Landroid/support/v4/app/BackStackRecord;->mTransition:I
    00d7: iget v0, v10.Landroid/support/v4/app/BackStackState;->mTransitionStyle:I
    00d9: iput v0, v4.Landroid/support/v4/app/BackStackRecord;->mTransitionStyle:I
    00db: iget v0, v10.Landroid/support/v4/app/BackStackState;->mName:Ljava/lang/String;
    00dd: iput v0, v4.Landroid/support/v4/app/BackStackRecord;->mName:Ljava/lang/String;
    00df: iget v0, v10.Landroid/support/v4/app/BackStackState;->mIndex:I
    00e1: iput v0, v4.Landroid/support/v4/app/BackStackRecord;->mIndex:I
    00e3: iput v9, v4.Landroid/support/v4/app/BackStackRecord;->mAddToBackStack:Z
    00e5: iget v0, v10.Landroid/support/v4/app/BackStackState;->mBreadCrumbTitleRes:I
    00e7: iput v0, v4.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleRes:I
    00e9: iget v0, v10.Landroid/support/v4/app/BackStackState;->mBreadCrumbTitleText:Ljava/lang/CharSequence;
    00eb: iput v0, v4.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbTitleText:Ljava/lang/CharSequence;
    00ed: iget v0, v10.Landroid/support/v4/app/BackStackState;->mBreadCrumbShortTitleRes:I
    00ef: iput v0, v4.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleRes:I
    00f1: iget v0, v10.Landroid/support/v4/app/BackStackState;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;
    00f3: iput v0, v4.Landroid/support/v4/app/BackStackRecord;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;
    00f5: invoke-virtual {v4, v9}, Landroid/support/v4/app/BackStackRecord;->bumpBackStackNesting(I)V
    00f8: return-object v4

  [Virtual Method] writeToParcel(Landroid/os/Parcel;, I) -> V
    // registers=5, ins=3, outs=3, insns_size=47
    0000: const/4 v1, 0
    0001: iget v0, v2.Landroid/support/v4/app/BackStackState;->mOps:[I
    0003: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeIntArray([I)V
    0006: iget v0, v2.Landroid/support/v4/app/BackStackState;->mTransition:I
    0008: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    000b: iget v0, v2.Landroid/support/v4/app/BackStackState;->mTransitionStyle:I
    000d: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    0010: iget v0, v2.Landroid/support/v4/app/BackStackState;->mName:Ljava/lang/String;
    0012: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0015: iget v0, v2.Landroid/support/v4/app/BackStackState;->mIndex:I
    0017: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    001a: iget v0, v2.Landroid/support/v4/app/BackStackState;->mBreadCrumbTitleRes:I
    001c: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    001f: iget v0, v2.Landroid/support/v4/app/BackStackState;->mBreadCrumbTitleText:Ljava/lang/CharSequence;
    0021: invoke-static {v0, v3, v1}, Landroid/text/TextUtils;->writeToParcel(Ljava/lang/CharSequence;Landroid/os/Parcel;I)V
    0024: iget v0, v2.Landroid/support/v4/app/BackStackState;->mBreadCrumbShortTitleRes:I
    0026: invoke-virtual {v3, v0}, Landroid/os/Parcel;->writeInt(I)V
    0029: iget v0, v2.Landroid/support/v4/app/BackStackState;->mBreadCrumbShortTitleText:Ljava/lang/CharSequence;
    002b: invoke-static {v0, v3, v1}, Landroid/text/TextUtils;->writeToParcel(Ljava/lang/CharSequence;Landroid/os/Parcel;I)V
    002e: return-void