=== CLASS Landroid/support/v4/widget/EdgeEffectCompat$BaseEdgeEffectImpl; (Source: EdgeEffectCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] draw(Ljava/lang/Object;, Landroid/graphics/Canvas;) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] finish(Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] isFinished(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Virtual Method] newEdgeEffect(Landroid/content/Context;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] onAbsorb(Ljava/lang/Object;, I) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] onPull(Ljava/lang/Object;, F) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] onRelease(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] setSize(Ljava/lang/Object;, I, I) -> V
    // registers=4, ins=4, outs=0, insns_size=1
    0000: return-void