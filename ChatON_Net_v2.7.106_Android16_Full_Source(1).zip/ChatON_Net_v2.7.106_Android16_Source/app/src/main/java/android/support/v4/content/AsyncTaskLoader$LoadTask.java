=== CLASS Landroid/support/v4/content/AsyncTaskLoader$LoadTask; (Source: AsyncTaskLoader.java) ===
  Super: Landroid/support/v4/content/ModernAsyncTask;
  Interfaces: Ljava/lang/Runnable;
  [Instance Field] done: Ljava/util/concurrent/CountDownLatch;
  [Instance Field] result: Ljava/lang/Object;
  [Instance Field] this$0: Landroid/support/v4/content/AsyncTaskLoader;
  [Instance Field] waiting: Z

  [Direct Method] <init>(Landroid/support/v4/content/AsyncTaskLoader;) -> V
    // registers=4, ins=2, outs=2, insns_size=14
    0000: iput v3, v2.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->this$0:Landroid/support/v4/content/AsyncTaskLoader;
    0002: invoke-direct {v2}, Landroid/support/v4/content/ModernAsyncTask;-><init>()V
    0005: new-instance v0, Ljava/util/concurrent/CountDownLatch;
    0007: const/4 v1, 1
    0008: invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V
    000b: iput v0, v2.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->done:Ljava/util/concurrent/CountDownLatch;
    000d: return-void

  [Direct Method] access$000(Landroid/support/v4/content/AsyncTaskLoader$LoadTask;) -> Ljava/util/concurrent/CountDownLatch;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->done:Ljava/util/concurrent/CountDownLatch;
    0002: return-object v0

  [Virtual Method] doInBackground([Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v2, [Ljava/lang/Void;
    0002: invoke-virtual {v1, v2}, Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->doInBackground([Ljava/lang/Void;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] doInBackground([Ljava/lang/Void;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=1, insns_size=11
    0000: iget v0, v1.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->this$0:Landroid/support/v4/content/AsyncTaskLoader;
    0002: invoke-virtual {v0}, Landroid/support/v4/content/AsyncTaskLoader;->onLoadInBackground()Ljava/lang/Object;
    0005: move-result-object v0
    0006: iput v0, v1.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->result:Ljava/lang/Object;
    0008: iget v0, v1.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->result:Ljava/lang/Object;
    000a: return-object v0

  [Virtual Method] onCancelled() -> V
    // registers=3, ins=1, outs=3, insns_size=20
    0000: iget v0, v2.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->this$0:Landroid/support/v4/content/AsyncTaskLoader;
    0002: iget v1, v2.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->result:Ljava/lang/Object;
    0004: invoke-virtual {v0, v2, v1}, Landroid/support/v4/content/AsyncTaskLoader;->dispatchOnCancelled(Landroid/support/v4/content/AsyncTaskLoader$LoadTask;Ljava/lang/Object;)V
    0007: iget v0, v2.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->done:Ljava/util/concurrent/CountDownLatch;
    0009: invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V
    000c: return-void
    000d: move-exception v0
    000e: iget v1, v2.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->done:Ljava/util/concurrent/CountDownLatch;
    0010: invoke-virtual {v1}, Ljava/util/concurrent/CountDownLatch;->countDown()V
    0013: throw v0

  [Virtual Method] onPostExecute(Ljava/lang/Object;) -> V
    // registers=4, ins=2, outs=3, insns_size=18
    0000: iget v0, v2.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->this$0:Landroid/support/v4/content/AsyncTaskLoader;
    0002: invoke-virtual {v0, v2, v3}, Landroid/support/v4/content/AsyncTaskLoader;->dispatchOnLoadComplete(Landroid/support/v4/content/AsyncTaskLoader$LoadTask;Ljava/lang/Object;)V
    0005: iget v0, v2.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->done:Ljava/util/concurrent/CountDownLatch;
    0007: invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V
    000a: return-void
    000b: move-exception v0
    000c: iget v1, v2.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->done:Ljava/util/concurrent/CountDownLatch;
    000e: invoke-virtual {v1}, Ljava/util/concurrent/CountDownLatch;->countDown()V
    0011: throw v0

  [Virtual Method] run() -> V
    // registers=2, ins=1, outs=1, insns_size=9
    0000: const/4 v0, 0
    0001: iput v0, v1.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->waiting:Z
    0003: iget v0, v1.Landroid/support/v4/content/AsyncTaskLoader$LoadTask;->this$0:Landroid/support/v4/content/AsyncTaskLoader;
    0005: invoke-virtual {v0}, Landroid/support/v4/content/AsyncTaskLoader;->executePendingTask()V
    0008: return-void