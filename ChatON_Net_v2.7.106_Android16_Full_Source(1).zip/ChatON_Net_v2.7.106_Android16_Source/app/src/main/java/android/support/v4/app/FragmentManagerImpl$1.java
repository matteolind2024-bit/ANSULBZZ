=== CLASS Landroid/support/v4/app/FragmentManagerImpl$1; (Source: FragmentManager.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/lang/Runnable;
  [Instance Field] this$0: Landroid/support/v4/app/FragmentManagerImpl;

  [Direct Method] <init>(Landroid/support/v4/app/FragmentManagerImpl;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/app/FragmentManagerImpl$1;->this$0:Landroid/support/v4/app/FragmentManagerImpl;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] run() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/app/FragmentManagerImpl$1;->this$0:Landroid/support/v4/app/FragmentManagerImpl;
    0002: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->execPendingActions()Z
    0005: return-void