=== CLASS Landroid/support/v4/view/PagerTitleStrip$1; (Source: PagerTitleStrip.java) ===
  Super: Ljava/lang/Object;