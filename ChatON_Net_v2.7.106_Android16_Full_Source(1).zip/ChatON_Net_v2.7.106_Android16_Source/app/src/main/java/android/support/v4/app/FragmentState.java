=== CLASS Landroid/support/v4/app/FragmentState; (Source: Fragment.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/Parcelable;
  [Static Field] CREATOR: Landroid/os/Parcelable$Creator;
  [Instance Field] mArguments: Landroid/os/Bundle;
  [Instance Field] mClassName: Ljava/lang/String;
  [Instance Field] mContainerId: I
  [Instance Field] mDetached: Z
  [Instance Field] mFragmentId: I
  [Instance Field] mFromLayout: Z
  [Instance Field] mIndex: I
  [Instance Field] mInstance: Landroid/support/v4/app/Fragment;
  [Instance Field] mRetainInstance: Z
  [Instance Field] mSavedFragmentState: Landroid/os/Bundle;
  [Instance Field] mTag: Ljava/lang/String;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=8
    0000: new-instance v0, Landroid/support/v4/app/FragmentState$1;
    0002: invoke-direct {v0}, Landroid/support/v4/app/FragmentState$1;-><init>()V
    0005: sput v0, Landroid/support/v4/app/FragmentState;->CREATOR:Landroid/os/Parcelable$Creator;
    0007: return-void

  [Direct Method] <init>(Landroid/os/Parcel;) -> V
    // registers=5, ins=2, outs=1, insns_size=80
    0000: const/4 v1, 1
    0001: const/4 v2, 0
    0002: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    0005: invoke-virtual {v4}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0008: move-result-object v0
    0009: iput v0, v3.Landroid/support/v4/app/FragmentState;->mClassName:Ljava/lang/String;
    000b: invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I
    000e: move-result v0
    000f: iput v0, v3.Landroid/support/v4/app/FragmentState;->mIndex:I
    0011: invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I
    0014: move-result v0
    0015: if-eqz v0, 004a
    0017: move(op=01) v0, v1
    0018: iput v0, v3.Landroid/support/v4/app/FragmentState;->mFromLayout:Z
    001a: invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I
    001d: move-result v0
    001e: iput v0, v3.Landroid/support/v4/app/FragmentState;->mFragmentId:I
    0020: invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I
    0023: move-result v0
    0024: iput v0, v3.Landroid/support/v4/app/FragmentState;->mContainerId:I
    0026: invoke-virtual {v4}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0029: move-result-object v0
    002a: iput v0, v3.Landroid/support/v4/app/FragmentState;->mTag:Ljava/lang/String;
    002c: invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I
    002f: move-result v0
    0030: if-eqz v0, 004c
    0032: move(op=01) v0, v1
    0033: iput v0, v3.Landroid/support/v4/app/FragmentState;->mRetainInstance:Z
    0035: invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I
    0038: move-result v0
    0039: if-eqz v0, 004e
    003b: iput v1, v3.Landroid/support/v4/app/FragmentState;->mDetached:Z
    003d: invoke-virtual {v4}, Landroid/os/Parcel;->readBundle()Landroid/os/Bundle;
    0040: move-result-object v0
    0041: iput v0, v3.Landroid/support/v4/app/FragmentState;->mArguments:Landroid/os/Bundle;
    0043: invoke-virtual {v4}, Landroid/os/Parcel;->readBundle()Landroid/os/Bundle;
    0046: move-result-object v0
    0047: iput v0, v3.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    0049: return-void
    004a: move(op=01) v0, v2
    004b: goto 0018
    004c: move(op=01) v0, v2
    004d: goto 0033
    004e: move(op=01) v1, v2
    004f: goto 003b

  [Direct Method] <init>(Landroid/support/v4/app/Fragment;) -> V
    // registers=3, ins=2, outs=1, insns_size=46
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0006: move-result-object v0
    0007: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    000a: move-result-object v0
    000b: iput v0, v1.Landroid/support/v4/app/FragmentState;->mClassName:Ljava/lang/String;
    000d: iget v0, v2.Landroid/support/v4/app/Fragment;->mIndex:I
    000f: iput v0, v1.Landroid/support/v4/app/FragmentState;->mIndex:I
    0011: iget v0, v2.Landroid/support/v4/app/Fragment;->mFromLayout:Z
    0013: iput v0, v1.Landroid/support/v4/app/FragmentState;->mFromLayout:Z
    0015: iget v0, v2.Landroid/support/v4/app/Fragment;->mFragmentId:I
    0017: iput v0, v1.Landroid/support/v4/app/FragmentState;->mFragmentId:I
    0019: iget v0, v2.Landroid/support/v4/app/Fragment;->mContainerId:I
    001b: iput v0, v1.Landroid/support/v4/app/FragmentState;->mContainerId:I
    001d: iget v0, v2.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    001f: iput v0, v1.Landroid/support/v4/app/FragmentState;->mTag:Ljava/lang/String;
    0021: iget v0, v2.Landroid/support/v4/app/Fragment;->mRetainInstance:Z
    0023: iput v0, v1.Landroid/support/v4/app/FragmentState;->mRetainInstance:Z
    0025: iget v0, v2.Landroid/support/v4/app/Fragment;->mDetached:Z
    0027: iput v0, v1.Landroid/support/v4/app/FragmentState;->mDetached:Z
    0029: iget v0, v2.Landroid/support/v4/app/Fragment;->mArguments:Landroid/os/Bundle;
    002b: iput v0, v1.Landroid/support/v4/app/FragmentState;->mArguments:Landroid/os/Bundle;
    002d: return-void

  [Virtual Method] describeContents() -> I
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] instantiate(Landroid/support/v4/app/FragmentActivity;) -> Landroid/support/v4/app/Fragment;
    // registers=5, ins=2, outs=3, insns_size=137
    0000: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    0002: if-eqz v0, 0007
    0004: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    0006: return-object v0
    0007: iget v0, v3.Landroid/support/v4/app/FragmentState;->mArguments:Landroid/os/Bundle;
    0009: if-eqz v0, 0014
    000b: iget v0, v3.Landroid/support/v4/app/FragmentState;->mArguments:Landroid/os/Bundle;
    000d: invoke-virtual {v4}, Landroid/support/v4/app/FragmentActivity;->getClassLoader()Ljava/lang/ClassLoader;
    0010: move-result-object v1
    0011: invoke-virtual {v0, v1}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V
    0014: iget v0, v3.Landroid/support/v4/app/FragmentState;->mClassName:Ljava/lang/String;
    0016: iget v1, v3.Landroid/support/v4/app/FragmentState;->mArguments:Landroid/os/Bundle;
    0018: invoke-static {v4, v0, v1}, Landroid/support/v4/app/Fragment;->instantiate(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;
    001b: move-result-object v0
    001c: iput v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    001e: iget v0, v3.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    0020: if-eqz v0, 0031
    0022: iget v0, v3.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    0024: invoke-virtual {v4}, Landroid/support/v4/app/FragmentActivity;->getClassLoader()Ljava/lang/ClassLoader;
    0027: move-result-object v1
    0028: invoke-virtual {v0, v1}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V
    002b: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    002d: iget v1, v3.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    002f: iput v1, v0.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    0031: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    0033: iget v1, v3.Landroid/support/v4/app/FragmentState;->mIndex:I
    0035: invoke-virtual {v0, v1}, Landroid/support/v4/app/Fragment;->setIndex(I)V
    0038: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    003a: iget v1, v3.Landroid/support/v4/app/FragmentState;->mFromLayout:Z
    003c: iput v1, v0.Landroid/support/v4/app/Fragment;->mFromLayout:Z
    003e: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    0040: const/4 v1, 1
    0041: iput v1, v0.Landroid/support/v4/app/Fragment;->mRestored:Z
    0043: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    0045: iget v1, v3.Landroid/support/v4/app/FragmentState;->mFragmentId:I
    0047: iput v1, v0.Landroid/support/v4/app/Fragment;->mFragmentId:I
    0049: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    004b: iget v1, v3.Landroid/support/v4/app/FragmentState;->mContainerId:I
    004d: iput v1, v0.Landroid/support/v4/app/Fragment;->mContainerId:I
    004f: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    0051: iget v1, v3.Landroid/support/v4/app/FragmentState;->mTag:Ljava/lang/String;
    0053: iput v1, v0.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    0055: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    0057: iget v1, v3.Landroid/support/v4/app/FragmentState;->mRetainInstance:Z
    0059: iput v1, v0.Landroid/support/v4/app/Fragment;->mRetainInstance:Z
    005b: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    005d: iget v1, v3.Landroid/support/v4/app/FragmentState;->mDetached:Z
    005f: iput v1, v0.Landroid/support/v4/app/Fragment;->mDetached:Z
    0061: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    0063: iget v1, v4.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0065: iput v1, v0.Landroid/support/v4/app/Fragment;->mFragmentManager:Landroid/support/v4/app/FragmentManagerImpl;
    0067: sget v0, Landroid/support/v4/app/FragmentManagerImpl;->DEBUG:Z
    0069: if-eqz v0, 0085
    006b: const-string v0, 'FragmentManager'
    006d: new-instance v1, Ljava/lang/StringBuilder;
    006f: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0072: const-string v2, 'Instantiated fragment '
    0074: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0077: move-result-object v1
    0078: iget v2, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    007a: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    007d: move-result-object v1
    007e: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0081: move-result-object v1
    0082: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0085: iget v0, v3.Landroid/support/v4/app/FragmentState;->mInstance:Landroid/support/v4/app/Fragment;
    0087: goto/16 0006

  [Virtual Method] writeToParcel(Landroid/os/Parcel;, I) -> V
    // registers=6, ins=3, outs=2, insns_size=67
    0000: const/4 v1, 1
    0001: const/4 v2, 0
    0002: iget v0, v3.Landroid/support/v4/app/FragmentState;->mClassName:Ljava/lang/String;
    0004: invoke-virtual {v4, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0007: iget v0, v3.Landroid/support/v4/app/FragmentState;->mIndex:I
    0009: invoke-virtual {v4, v0}, Landroid/os/Parcel;->writeInt(I)V
    000c: iget v0, v3.Landroid/support/v4/app/FragmentState;->mFromLayout:Z
    000e: if-eqz v0, 003d
    0010: move(op=01) v0, v1
    0011: invoke-virtual {v4, v0}, Landroid/os/Parcel;->writeInt(I)V
    0014: iget v0, v3.Landroid/support/v4/app/FragmentState;->mFragmentId:I
    0016: invoke-virtual {v4, v0}, Landroid/os/Parcel;->writeInt(I)V
    0019: iget v0, v3.Landroid/support/v4/app/FragmentState;->mContainerId:I
    001b: invoke-virtual {v4, v0}, Landroid/os/Parcel;->writeInt(I)V
    001e: iget v0, v3.Landroid/support/v4/app/FragmentState;->mTag:Ljava/lang/String;
    0020: invoke-virtual {v4, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0023: iget v0, v3.Landroid/support/v4/app/FragmentState;->mRetainInstance:Z
    0025: if-eqz v0, 003f
    0027: move(op=01) v0, v1
    0028: invoke-virtual {v4, v0}, Landroid/os/Parcel;->writeInt(I)V
    002b: iget v0, v3.Landroid/support/v4/app/FragmentState;->mDetached:Z
    002d: if-eqz v0, 0041
    002f: invoke-virtual {v4, v1}, Landroid/os/Parcel;->writeInt(I)V
    0032: iget v0, v3.Landroid/support/v4/app/FragmentState;->mArguments:Landroid/os/Bundle;
    0034: invoke-virtual {v4, v0}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V
    0037: iget v0, v3.Landroid/support/v4/app/FragmentState;->mSavedFragmentState:Landroid/os/Bundle;
    0039: invoke-virtual {v4, v0}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V
    003c: return-void
    003d: move(op=01) v0, v2
    003e: goto 0011
    003f: move(op=01) v0, v2
    0040: goto 0028
    0041: move(op=01) v1, v2
    0042: goto 002f