=== CLASS Landroid/support/v4/app/NavUtils$NavUtilsImplBase; (Source: NavUtils.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/app/NavUtils$NavUtilsImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getParentActivityIntent(Landroid/app/Activity;) -> Landroid/content/Intent;
    // registers=4, ins=2, outs=3, insns_size=18
    0000: invoke-static {v3}, Landroid/support/v4/app/NavUtils;->getParentActivityName(Landroid/app/Activity;)Ljava/lang/String;
    0003: move-result-object v0
    0004: if-nez v0, 0008
    0006: const/4 v0, 0
    0007: return-object v0
    0008: new-instance v1, Landroid/content/Intent;
    000a: invoke-direct {v1}, Landroid/content/Intent;-><init>()V
    000d: invoke-virtual {v1, v3, v0}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    0010: move-result-object v0
    0011: goto 0007

  [Virtual Method] getParentActivityName(Landroid/content/Context;, Landroid/content/pm/ActivityInfo;) -> Ljava/lang/String;
    // registers=6, ins=3, outs=2, insns_size=50
    0000: const/4 v1, 0
    0001: iget v0, v5.Landroid/content/pm/ActivityInfo;->metaData:Landroid/os/Bundle;
    0003: if-nez v0, 0007
    0005: move(op=07) v0, v1
    0006: return-object v0
    0007: iget v0, v5.Landroid/content/pm/ActivityInfo;->metaData:Landroid/os/Bundle;
    0009: const-string v2, 'android.support.PARENT_ACTIVITY'
    000b: invoke-virtual {v0, v2}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;
    000e: move-result-object v0
    000f: if-nez v0, 0013
    0011: move(op=07) v0, v1
    0012: goto 0006
    0013: const/4 v1, 0
    0014: invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C
    0017: move-result v1
    0018: const/16 v2, 46 (0x2e)
    001a: if-ne v1, v2, 0006
    001c: new-instance v1, Ljava/lang/StringBuilder;
    001e: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0021: invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;
    0024: move-result-object v2
    0025: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0028: move-result-object v1
    0029: invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002c: move-result-object v0
    002d: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0030: move-result-object v0
    0031: goto 0006

  [Virtual Method] navigateUpTo(Landroid/app/Activity;, Landroid/content/Intent;) -> V
    // registers=4, ins=3, outs=2, insns_size=12
    0000: const/high16 v0, 67108864 (0x4000000)
    0002: invoke-virtual {v3, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    0005: invoke-virtual {v2, v3}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    0008: invoke-virtual {v2}, Landroid/app/Activity;->finish()V
    000b: return-void

  [Virtual Method] shouldUpRecreateTask(Landroid/app/Activity;, Landroid/content/Intent;) -> Z
    // registers=5, ins=3, outs=2, insns_size=22
    0000: invoke-virtual {v3}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;
    0003: move-result-object v0
    0004: invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0007: move-result-object v0
    0008: if-eqz v0, 0014
    000a: const-string v1, 'android.intent.action.MAIN'
    000c: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    000f: move-result v0
    0010: if-nez v0, 0014
    0012: const/4 v0, 1
    0013: return v0
    0014: const/4 v0, 0
    0015: goto 0013