=== CLASS Landroid/support/v4/view/ViewCompatGingerbread; (Source: ViewCompatGingerbread.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getOverScrollMode(Landroid/view/View;) -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/view/View;->getOverScrollMode()I
    0003: move-result v0
    0004: return v0

  [Direct Method] setOverScrollMode(Landroid/view/View;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/view/View;->setOverScrollMode(I)V
    0003: return-void