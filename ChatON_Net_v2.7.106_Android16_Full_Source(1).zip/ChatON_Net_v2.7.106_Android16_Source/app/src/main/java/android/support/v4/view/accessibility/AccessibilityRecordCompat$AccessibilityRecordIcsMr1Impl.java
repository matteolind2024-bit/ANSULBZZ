=== CLASS Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordIcsMr1Impl; (Source: AccessibilityRecordCompat.java) ===
  Super: Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordIcsImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordIcsImpl;-><init>()V
    0003: return-void

  [Virtual Method] getMaxScrollX(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcsMr1;->getMaxScrollX(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] getMaxScrollY(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcsMr1;->getMaxScrollY(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] setMaxScrollX(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcsMr1;->setMaxScrollX(Ljava/lang/Object;I)V
    0003: return-void

  [Virtual Method] setMaxScrollY(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcsMr1;->setMaxScrollY(Ljava/lang/Object;I)V
    0003: return-void