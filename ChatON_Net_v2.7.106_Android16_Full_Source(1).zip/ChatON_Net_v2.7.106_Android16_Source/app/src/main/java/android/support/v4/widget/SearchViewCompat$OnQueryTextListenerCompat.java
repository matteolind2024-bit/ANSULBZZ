=== CLASS Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat; (Source: SearchViewCompat.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] mListener: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=14
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: invoke-static {}, Landroid/support/v4/widget/SearchViewCompat;->access$000()Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;
    0006: move-result-object v0
    0007: invoke-interface {v0, v1}, Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;->newOnQueryTextListener(Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;)Ljava/lang/Object;
    000a: move-result-object v0
    000b: iput v0, v1.Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;->mListener:Ljava/lang/Object;
    000d: return-void

  [Virtual Method] onQueryTextChange(Ljava/lang/String;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] onQueryTextSubmit(Ljava/lang/String;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0