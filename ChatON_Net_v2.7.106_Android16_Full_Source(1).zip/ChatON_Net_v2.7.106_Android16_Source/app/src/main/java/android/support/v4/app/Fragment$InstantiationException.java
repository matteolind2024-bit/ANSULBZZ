=== CLASS Landroid/support/v4/app/Fragment$InstantiationException; (Source: Fragment.java) ===
  Super: Ljava/lang/RuntimeException;

  [Direct Method] <init>(Ljava/lang/String;, Ljava/lang/Exception;) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-direct {v0, v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    0003: return-void