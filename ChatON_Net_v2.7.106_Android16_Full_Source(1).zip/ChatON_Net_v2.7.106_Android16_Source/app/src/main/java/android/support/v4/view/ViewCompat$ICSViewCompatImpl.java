=== CLASS Landroid/support/v4/view/ViewCompat$ICSViewCompatImpl; (Source: ViewCompat.java) ===
  Super: Landroid/support/v4/view/ViewCompat$HCViewCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/view/ViewCompat$HCViewCompatImpl;-><init>()V
    0003: return-void

  [Virtual Method] canScrollHorizontally(Landroid/view/View;, I) -> Z
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/ViewCompatICS;->canScrollHorizontally(Landroid/view/View;I)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] canScrollVertically(Landroid/view/View;, I) -> Z
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/ViewCompatICS;->canScrollVertically(Landroid/view/View;I)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] onInitializeAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/ViewCompatICS;->onInitializeAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    0003: return-void

  [Virtual Method] onInitializeAccessibilityNodeInfo(Landroid/view/View;, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;) -> V
    // registers=4, ins=3, outs=2, insns_size=8
    0000: invoke-virtual {v3}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;->getInfo()Ljava/lang/Object;
    0003: move-result-object v0
    0004: invoke-static {v2, v0}, Landroid/support/v4/view/ViewCompatICS;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Ljava/lang/Object;)V
    0007: return-void

  [Virtual Method] onPopulateAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/ViewCompatICS;->onPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    0003: return-void

  [Virtual Method] setAccessibilityDelegate(Landroid/view/View;, Landroid/support/v4/view/AccessibilityDelegateCompat;) -> V
    // registers=4, ins=3, outs=2, insns_size=8
    0000: invoke-virtual {v3}, Landroid/support/v4/view/AccessibilityDelegateCompat;->getBridge()Ljava/lang/Object;
    0003: move-result-object v0
    0004: invoke-static {v2, v0}, Landroid/support/v4/view/ViewCompatICS;->setAccessibilityDelegate(Landroid/view/View;Ljava/lang/Object;)V
    0007: return-void