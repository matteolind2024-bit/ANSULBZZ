=== CLASS Landroid/support/v4/view/ViewCompat$BaseViewCompatImpl; (Source: ViewCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/ViewCompat$ViewCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] canScrollHorizontally(Landroid/view/View;, I) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] canScrollVertically(Landroid/view/View;, I) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getAccessibilityNodeProvider(Landroid/view/View;) -> Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getFrameTime() -> J
    // registers=3, ins=1, outs=0, insns_size=3
    0000: const-wide/16 v0, 10
    0002: return-wide v0

  [Virtual Method] getImportantForAccessibility(Landroid/view/View;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getOverScrollMode(Landroid/view/View;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 2
    0001: return v0

  [Virtual Method] hasTransientState(Landroid/view/View;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] onInitializeAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onInitializeAccessibilityNodeInfo(Landroid/view/View;, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onPopulateAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] postInvalidateOnAnimation(Landroid/view/View;) -> V
    // registers=4, ins=2, outs=3, insns_size=8
    0000: invoke-virtual {v2}, Landroid/support/v4/view/ViewCompat$BaseViewCompatImpl;->getFrameTime()J
    0003: move-result-wide v0
    0004: invoke-virtual {v3, v0, v1}, Landroid/view/View;->postInvalidateDelayed(J)V
    0007: return-void

  [Virtual Method] postInvalidateOnAnimation(Landroid/view/View;, I, I, I, I) -> V
    // registers=13, ins=6, outs=7, insns_size=13
    0000: invoke-virtual {v7}, Landroid/support/v4/view/ViewCompat$BaseViewCompatImpl;->getFrameTime()J
    0003: move-result-wide v1
    0004: move(op=07) v0, v8
    0005: move(op=01) v3, v9
    0006: move(op=01) v4, v10
    0007: move(op=01) v5, v11
    0008: move(op=01) v6, v12
    0009: invoke-virtual/range {v0..v6}, Landroid/view/View;->postInvalidateDelayed(JIIII)V
    000c: return-void

  [Virtual Method] postOnAnimation(Landroid/view/View;, Ljava/lang/Runnable;) -> V
    // registers=5, ins=3, outs=4, insns_size=8
    0000: invoke-virtual {v2}, Landroid/support/v4/view/ViewCompat$BaseViewCompatImpl;->getFrameTime()J
    0003: move-result-wide v0
    0004: invoke-virtual {v3, v4, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z
    0007: return-void

  [Virtual Method] postOnAnimationDelayed(Landroid/view/View;, Ljava/lang/Runnable;, J) -> V
    // registers=7, ins=5, outs=4, insns_size=9
    0000: invoke-virtual {v2}, Landroid/support/v4/view/ViewCompat$BaseViewCompatImpl;->getFrameTime()J
    0003: move-result-wide v0
    0004: binop/2addr(op=bb) v0, v5
    0005: invoke-virtual {v3, v4, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z
    0008: return-void

  [Virtual Method] setAccessibilityDelegate(Landroid/view/View;, Landroid/support/v4/view/AccessibilityDelegateCompat;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setHasTransientState(Landroid/view/View;, Z) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setImportantForAccessibility(Landroid/view/View;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setOverScrollMode(Landroid/view/View;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void