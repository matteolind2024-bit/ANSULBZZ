=== CLASS Landroid/support/v4/util/TimeUtils; (Source: TimeUtils.java) ===
  Super: Ljava/lang/Object;
  [Static Field] HUNDRED_DAY_FIELD_LEN: I = 19
  [Static Field] SECONDS_PER_DAY: I = 86400
  [Static Field] SECONDS_PER_HOUR: I = 3600
  [Static Field] SECONDS_PER_MINUTE: I = 60
  [Static Field] sFormatStr: [C
  [Static Field] sFormatSync: Ljava/lang/Object;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=14
    0000: new-instance v0, Ljava/lang/Object;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: sput v0, Landroid/support/v4/util/TimeUtils;->sFormatSync:Ljava/lang/Object;
    0007: const/16 v0, 24 (0x18)
    0009: new-array v0, v0, [C
    000b: sput v0, Landroid/support/v4/util/TimeUtils;->sFormatStr:[C
    000d: return-void

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] accumField(I, I, Z, I) -> I
    // registers=5, ins=4, outs=0, insns_size=33
    0000: const/16 v0, 99 (0x63)
    0002: if-gt v1, v0, 0009
    0004: if-eqz v3, 000c
    0006: const/4 v0, 3
    0007: if-lt v4, v0, 000c
    0009: binop/lit8(op=d8) v0, v2, 3 (0x3)
    000b: return v0
    000c: const/16 v0, 9 (0x9)
    000e: if-gt v1, v0, 0015
    0010: if-eqz v3, 0018
    0012: const/4 v0, 2
    0013: if-lt v4, v0, 0018
    0015: binop/lit8(op=d8) v0, v2, 2 (0x2)
    0017: goto 000b
    0018: if-nez v3, 001c
    001a: if-lez v1, 001f
    001c: binop/lit8(op=d8) v0, v2, 1 (0x1)
    001e: goto 000b
    001f: const/4 v0, 0
    0020: goto 000b

  [Direct Method] formatDuration(J, J, Ljava/io/PrintWriter;) -> V
    // registers=8, ins=5, outs=4, insns_size=19
    0000: const-wide/16 v0, 0
    0002: cmp(op=31) v0, v3, v0
    0004: if-nez v0, 000c
    0006: const-string v0, '--'
    0008: invoke-virtual {v7, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    000b: return-void
    000c: binop(op=9c) v0, v3, v5
    000e: const/4 v2, 0
    000f: invoke-static {v0, v1, v7, v2}, Landroid/support/v4/util/TimeUtils;->formatDuration(JLjava/io/PrintWriter;I)V
    0012: goto 000b

  [Direct Method] formatDuration(J, Ljava/io/PrintWriter;) -> V
    // registers=4, ins=3, outs=4, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-static {v1, v2, v3, v0}, Landroid/support/v4/util/TimeUtils;->formatDuration(JLjava/io/PrintWriter;I)V
    0004: return-void

  [Direct Method] formatDuration(J, Ljava/io/PrintWriter;, I) -> V
    // registers=9, ins=4, outs=4, insns_size=23
    0000: sget v1, Landroid/support/v4/util/TimeUtils;->sFormatSync:Ljava/lang/Object;
    0002: monitor-enter v1
    0003: invoke-static {v5, v6, v8}, Landroid/support/v4/util/TimeUtils;->formatDurationLocked(JI)I
    0006: move-result v0
    0007: new-instance v2, Ljava/lang/String;
    0009: sget v3, Landroid/support/v4/util/TimeUtils;->sFormatStr:[C
    000b: const/4 v4, 0
    000c: invoke-direct {v2, v3, v4, v0}, Ljava/lang/String;-><init>([CII)V
    000f: invoke-virtual {v7, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0012: monitor-exit v1
    0013: return-void
    0014: move-exception v0
    0015: monitor-exit v1
    0016: throw v0

  [Direct Method] formatDuration(J, Ljava/lang/StringBuilder;) -> V
    // registers=7, ins=3, outs=4, insns_size=19
    0000: sget v1, Landroid/support/v4/util/TimeUtils;->sFormatSync:Ljava/lang/Object;
    0002: monitor-enter v1
    0003: const/4 v0, 0
    0004: invoke-static {v4, v5, v0}, Landroid/support/v4/util/TimeUtils;->formatDurationLocked(JI)I
    0007: move-result v0
    0008: sget v2, Landroid/support/v4/util/TimeUtils;->sFormatStr:[C
    000a: const/4 v3, 0
    000b: invoke-virtual {v6, v2, v3, v0}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;
    000e: monitor-exit v1
    000f: return-void
    0010: move-exception v0
    0011: monitor-exit v1
    0012: throw v0

  [Direct Method] formatDurationLocked(J, I) -> I
    // registers=21, ins=3, outs=6, insns_size=302
    0000: sget v2, Landroid/support/v4/util/TimeUtils;->sFormatStr:[C
    0002: move(op=21) v2, v2
    0003: move/from16 v0, v20
    0005: if-ge v2, v0, 000d
    0007: move/from16 v0, v20
    0009: new-array v2, v0, [C
    000b: sput v2, Landroid/support/v4/util/TimeUtils;->sFormatStr:[C
    000d: sget v2, Landroid/support/v4/util/TimeUtils;->sFormatStr:[C
    000f: const-wide/16 v3, 0
    0011: cmp(op=31) v3, v18, v3
    0013: if-nez v3, 0025
    0015: const/4 v3, 0
    0016: binop/lit8(op=d8) v4, v20, -1 (-0x1)
    0018: if-ge v3, v4, 001f
    001a: const/16 v5, 32 (0x20)
    001c: aput(op=50) v5, v2[v3]
    001e: goto 0018
    001f: const/16 v4, 48 (0x30)
    0021: aput(op=50) v4, v2[v3]
    0023: const/4 v2, 1
    0024: return v2
    0025: const-wide/16 v3, 0
    0027: cmp(op=31) v3, v18, v3
    0029: if-lez v3, 00b1
    002b: const/16 v3, 43 (0x2b)
    002d: move(op=01) v4, v3
    002e: const-wide/16 v5, 1000
    0030: binop(op=9f) v5, v18, v5
    0032: unop(op=84) v0, v5
    0033: move/from16 v16, v0
    0035: const-wide/16 v5, 1000
    0037: binop(op=9e) v5, v18, v5
    0039: unop(op=86) v5, v5
    003a: invoke-static {v5, v6}, Ljava/lang/Math;->floor(D)D
    003d: move-result-wide v5
    003e: unop(op=8a) v7, v5
    003f: const/4 v3, 0
    0040: const/4 v6, 0
    0041: const/4 v5, 0
    0042: const v8, 86400 (0x15180)
    0045: if-le v7, v8, 0051
    0047: const v3, 86400 (0x15180)
    004a: binop(op=93) v3, v7, v3
    004c: const v8, 86400 (0x15180)
    004f: binop/2addr(op=b2) v8, v3
    0050: binop/2addr(op=b1) v7, v8
    0051: const/16 v8, 3600 (0xe10)
    0053: if-le v7, v8, 012a
    0055: binop/lit16(op=d3) v6, v7, 3600 (0xe10)
    0057: binop/lit16(op=d2) v8, v6, 3600 (0xe10)
    0059: binop/2addr(op=b1) v7, v8
    005a: move(op=01) v15, v6
    005b: move(op=01) v6, v7
    005c: const/16 v7, 60 (0x3c)
    005e: if-le v6, v7, 0126
    0060: binop/lit8(op=db) v5, v6, 60 (0x3c)
    0062: binop/lit8(op=da) v7, v5, 60 (0x3c)
    0064: binop/2addr(op=b1) v6, v7
    0065: move(op=01) v13, v5
    0066: move(op=01) v14, v6
    0067: const/4 v6, 0
    0068: if-eqz v20, 00c3
    006a: const/4 v5, 1
    006b: const/4 v7, 0
    006c: const/4 v8, 0
    006d: invoke-static {v3, v5, v7, v8}, Landroid/support/v4/util/TimeUtils;->accumField(IIZI)I
    0070: move-result v7
    0071: const/4 v8, 1
    0072: if-lez v7, 00bb
    0074: const/4 v5, 1
    0075: const/4 v9, 2
    0076: invoke-static {v15, v8, v5, v9}, Landroid/support/v4/util/TimeUtils;->accumField(IIZI)I
    0079: move-result v5
    007a: binop/2addr(op=b0) v7, v5
    007b: const/4 v8, 1
    007c: if-lez v7, 00bd
    007e: const/4 v5, 1
    007f: const/4 v9, 2
    0080: invoke-static {v13, v8, v5, v9}, Landroid/support/v4/util/TimeUtils;->accumField(IIZI)I
    0083: move-result v5
    0084: binop/2addr(op=b0) v7, v5
    0085: const/4 v8, 1
    0086: if-lez v7, 00bf
    0088: const/4 v5, 1
    0089: const/4 v9, 2
    008a: invoke-static {v14, v8, v5, v9}, Landroid/support/v4/util/TimeUtils;->accumField(IIZI)I
    008d: move-result v5
    008e: binop/2addr(op=b0) v7, v5
    008f: const/4 v8, 2
    0090: const/4 v9, 1
    0091: if-lez v7, 00c1
    0093: const/4 v5, 3
    0094: move/from16 v0, v16
    0096: invoke-static {v0, v8, v9, v5}, Landroid/support/v4/util/TimeUtils;->accumField(IIZI)I
    0099: move-result v5
    009a: binop/lit8(op=d8) v5, v5, 1 (0x1)
    009c: binop/2addr(op=b0) v5, v7
    009d: move/from16 v17, v5
    009f: move(op=01) v5, v6
    00a0: move/from16 v6, v17
    00a2: move/from16 v0, v20
    00a4: if-ge v6, v0, 00c4
    00a6: const/16 v7, 32 (0x20)
    00a8: aput(op=50) v7, v2[v5]
    00aa: binop/lit8(op=d8) v7, v5, 1 (0x1)
    00ac: binop/lit8(op=d8) v5, v6, 1 (0x1)
    00ae: move(op=01) v6, v5
    00af: move(op=01) v5, v7
    00b0: goto 00a2
    00b1: const/16 v3, 45 (0x2d)
    00b3: move/from16 v0, v18
    00b5: unop(op=7d) v0, v0
    00b6: move/from16 v18, v0
    00b8: move(op=01) v4, v3
    00b9: goto/16 002e
    00bb: const/4 v5, 0
    00bc: goto 0075
    00bd: const/4 v5, 0
    00be: goto 007f
    00bf: const/4 v5, 0
    00c0: goto 0089
    00c1: const/4 v5, 0
    00c2: goto 0094
    00c3: move(op=01) v5, v6
    00c4: aput(op=50) v4, v2[v5]
    00c6: binop/lit8(op=d8) v5, v5, 1 (0x1)
    00c8: if-eqz v20, 0115
    00ca: const/4 v4, 1
    00cb: move(op=01) v12, v4
    00cc: const/16 v4, 100 (0x64)
    00ce: const/4 v6, 0
    00cf: const/4 v7, 0
    00d0: invoke-static/range {v2..v7}, Landroid/support/v4/util/TimeUtils;->printField([CICIZI)I
    00d3: move-result v9
    00d4: const/16 v8, 104 (0x68)
    00d6: if-eq v9, v5, 0118
    00d8: const/4 v10, 1
    00d9: if-eqz v12, 011a
    00db: const/4 v11, 2
    00dc: move(op=07) v6, v2
    00dd: move(op=01) v7, v15
    00de: invoke-static/range {v6..v11}, Landroid/support/v4/util/TimeUtils;->printField([CICIZI)I
    00e1: move-result v9
    00e2: const/16 v8, 109 (0x6d)
    00e4: if-eq v9, v5, 011c
    00e6: const/4 v10, 1
    00e7: if-eqz v12, 011e
    00e9: const/4 v11, 2
    00ea: move(op=07) v6, v2
    00eb: move(op=01) v7, v13
    00ec: invoke-static/range {v6..v11}, Landroid/support/v4/util/TimeUtils;->printField([CICIZI)I
    00ef: move-result v9
    00f0: const/16 v8, 115 (0x73)
    00f2: if-eq v9, v5, 0120
    00f4: const/4 v10, 1
    00f5: if-eqz v12, 0122
    00f7: const/4 v11, 2
    00f8: move(op=07) v6, v2
    00f9: move(op=01) v7, v14
    00fa: invoke-static/range {v6..v11}, Landroid/support/v4/util/TimeUtils;->printField([CICIZI)I
    00fd: move-result v8
    00fe: const/16 v4, 109 (0x6d)
    0100: const/4 v6, 1
    0101: if-eqz v12, 0124
    0103: if-eq v8, v5, 0124
    0105: const/4 v7, 3
    0106: move/from16 v3, v16
    0108: move(op=01) v5, v8
    0109: invoke-static/range {v2..v7}, Landroid/support/v4/util/TimeUtils;->printField([CICIZI)I
    010c: move-result v3
    010d: const/16 v4, 115 (0x73)
    010f: aput(op=50) v4, v2[v3]
    0111: binop/lit8(op=d8) v2, v3, 1 (0x1)
    0113: goto/16 0024
    0115: const/4 v4, 0
    0116: move(op=01) v12, v4
    0117: goto 00cc
    0118: const/4 v10, 0
    0119: goto 00d9
    011a: const/4 v11, 0
    011b: goto 00dc
    011c: const/4 v10, 0
    011d: goto 00e7
    011e: const/4 v11, 0
    011f: goto 00ea
    0120: const/4 v10, 0
    0121: goto 00f5
    0122: const/4 v11, 0
    0123: goto 00f8
    0124: const/4 v7, 0
    0125: goto 0106
    0126: move(op=01) v13, v5
    0127: move(op=01) v14, v6
    0128: goto/16 0067
    012a: move(op=01) v15, v6
    012b: move(op=01) v6, v7
    012c: goto/16 005c

  [Direct Method] printField([C, I, C, I, Z, I) -> I
    // registers=10, ins=6, outs=0, insns_size=64
    0000: if-nez v8, 0004
    0002: if-lez v5, 003c
    0004: if-eqz v8, 0009
    0006: const/4 v0, 3
    0007: if-ge v9, v0, 000d
    0009: const/16 v0, 99 (0x63)
    000b: if-le v5, v0, 003d
    000d: binop/lit8(op=db) v1, v5, 100 (0x64)
    000f: binop/lit8(op=d8) v0, v1, 48 (0x30)
    0011: unop(op=8e) v0, v0
    0012: aput(op=50) v0, v4[v7]
    0014: binop/lit8(op=d8) v0, v7, 1 (0x1)
    0016: binop/lit8(op=da) v1, v1, 100 (0x64)
    0018: binop(op=91) v1, v5, v1
    001a: if-eqz v8, 001f
    001c: const/4 v2, 2
    001d: if-ge v9, v2, 0025
    001f: const/16 v2, 9 (0x9)
    0021: if-gt v1, v2, 0025
    0023: if-eq v7, v0, 0031
    0025: binop/lit8(op=db) v2, v1, 10 (0xa)
    0027: binop/lit8(op=d8) v3, v2, 48 (0x30)
    0029: unop(op=8e) v3, v3
    002a: aput(op=50) v3, v4[v0]
    002c: binop/lit8(op=d8) v0, v0, 1 (0x1)
    002e: binop/lit8(op=da) v2, v2, 10 (0xa)
    0030: binop/2addr(op=b1) v1, v2
    0031: binop/lit8(op=d8) v1, v1, 48 (0x30)
    0033: unop(op=8e) v1, v1
    0034: aput(op=50) v1, v4[v0]
    0036: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0038: aput(op=50) v6, v4[v0]
    003a: binop/lit8(op=d8) v7, v0, 1 (0x1)
    003c: return v7
    003d: move(op=01) v0, v7
    003e: move(op=01) v1, v5
    003f: goto 001a