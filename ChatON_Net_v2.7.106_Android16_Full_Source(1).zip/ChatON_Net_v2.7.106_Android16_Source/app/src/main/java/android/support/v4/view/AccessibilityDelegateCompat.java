=== CLASS Landroid/support/v4/view/AccessibilityDelegateCompat; (Source: AccessibilityDelegateCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] DEFAULT_DELEGATE: Ljava/lang/Object;
  [Static Field] IMPL: Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
  [Instance Field] mBridge: Ljava/lang/Object;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=44
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 16 (0x10)
    0004: if-lt v0, v1, 0016
    0006: new-instance v0, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl;
    0008: invoke-direct {v0}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateJellyBeanImpl;-><init>()V
    000b: sput v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    000d: sget v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    000f: invoke-interface {v0}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;->newAccessiblityDelegateDefaultImpl()Ljava/lang/Object;
    0012: move-result-object v0
    0013: sput v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->DEFAULT_DELEGATE:Ljava/lang/Object;
    0015: return-void
    0016: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0018: const/16 v1, 14 (0xe)
    001a: if-lt v0, v1, 0024
    001c: new-instance v0, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateIcsImpl;
    001e: invoke-direct {v0}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateIcsImpl;-><init>()V
    0021: sput v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    0023: goto 000d
    0024: new-instance v0, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateStubImpl;
    0026: invoke-direct {v0}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateStubImpl;-><init>()V
    0029: sput v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    002b: goto 000d

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=12
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: sget v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    0005: invoke-interface {v0, v1}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;->newAccessiblityDelegateBridge(Landroid/support/v4/view/AccessibilityDelegateCompat;)Ljava/lang/Object;
    0008: move-result-object v0
    0009: iput v0, v1.Landroid/support/v4/view/AccessibilityDelegateCompat;->mBridge:Ljava/lang/Object;
    000b: return-void

  [Virtual Method] dispatchPopulateAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> Z
    // registers=5, ins=3, outs=4, insns_size=9
    0000: sget v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    0002: sget v1, Landroid/support/v4/view/AccessibilityDelegateCompat;->DEFAULT_DELEGATE:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3, v4}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;->dispatchPopulateAccessibilityEvent(Ljava/lang/Object;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    0007: move-result v0
    0008: return v0

  [Virtual Method] getAccessibilityNodeProvider(Landroid/view/View;) -> Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    // registers=4, ins=2, outs=3, insns_size=9
    0000: sget v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    0002: sget v1, Landroid/support/v4/view/AccessibilityDelegateCompat;->DEFAULT_DELEGATE:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;->getAccessibilityNodeProvider(Ljava/lang/Object;Landroid/view/View;)Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] getBridge() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/view/AccessibilityDelegateCompat;->mBridge:Ljava/lang/Object;
    0002: return-object v0

  [Virtual Method] onInitializeAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=5, ins=3, outs=4, insns_size=8
    0000: sget v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    0002: sget v1, Landroid/support/v4/view/AccessibilityDelegateCompat;->DEFAULT_DELEGATE:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3, v4}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;->onInitializeAccessibilityEvent(Ljava/lang/Object;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    0007: return-void

  [Virtual Method] onInitializeAccessibilityNodeInfo(Landroid/view/View;, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;) -> V
    // registers=5, ins=3, outs=4, insns_size=8
    0000: sget v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    0002: sget v1, Landroid/support/v4/view/AccessibilityDelegateCompat;->DEFAULT_DELEGATE:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3, v4}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;->onInitializeAccessibilityNodeInfo(Ljava/lang/Object;Landroid/view/View;Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;)V
    0007: return-void

  [Virtual Method] onPopulateAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=5, ins=3, outs=4, insns_size=8
    0000: sget v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    0002: sget v1, Landroid/support/v4/view/AccessibilityDelegateCompat;->DEFAULT_DELEGATE:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3, v4}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;->onPopulateAccessibilityEvent(Ljava/lang/Object;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    0007: return-void

  [Virtual Method] onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> Z
    // registers=6, ins=4, outs=5, insns_size=9
    0000: sget v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    0002: sget v1, Landroid/support/v4/view/AccessibilityDelegateCompat;->DEFAULT_DELEGATE:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3, v4, v5}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;->onRequestSendAccessibilityEvent(Ljava/lang/Object;Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    0007: move-result v0
    0008: return v0

  [Virtual Method] performAccessibilityAction(Landroid/view/View;, I, Landroid/os/Bundle;) -> Z
    // registers=6, ins=4, outs=5, insns_size=9
    0000: sget v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    0002: sget v1, Landroid/support/v4/view/AccessibilityDelegateCompat;->DEFAULT_DELEGATE:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3, v4, v5}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;->performAccessibilityAction(Ljava/lang/Object;Landroid/view/View;ILandroid/os/Bundle;)Z
    0007: move-result v0
    0008: return v0

  [Virtual Method] sendAccessibilityEvent(Landroid/view/View;, I) -> V
    // registers=5, ins=3, outs=4, insns_size=8
    0000: sget v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    0002: sget v1, Landroid/support/v4/view/AccessibilityDelegateCompat;->DEFAULT_DELEGATE:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3, v4}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;->sendAccessibilityEvent(Ljava/lang/Object;Landroid/view/View;I)V
    0007: return-void

  [Virtual Method] sendAccessibilityEventUnchecked(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=5, ins=3, outs=4, insns_size=8
    0000: sget v0, Landroid/support/v4/view/AccessibilityDelegateCompat;->IMPL:Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;
    0002: sget v1, Landroid/support/v4/view/AccessibilityDelegateCompat;->DEFAULT_DELEGATE:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3, v4}, Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;->sendAccessibilityEventUnchecked(Ljava/lang/Object;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    0007: return-void