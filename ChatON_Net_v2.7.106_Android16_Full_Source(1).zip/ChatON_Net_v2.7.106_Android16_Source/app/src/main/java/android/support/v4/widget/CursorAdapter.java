=== CLASS Landroid/support/v4/widget/CursorAdapter; (Source: CursorAdapter.java) ===
  Super: Landroid/widget/BaseAdapter;
  Interfaces: Landroid/support/v4/widget/CursorFilter$CursorFilterClient;, Landroid/widget/Filterable;
  [Static Field] FLAG_AUTO_REQUERY: I = 1
  [Static Field] FLAG_REGISTER_CONTENT_OBSERVER: I = 2
  [Instance Field] mAutoRequery: Z
  [Instance Field] mChangeObserver: Landroid/support/v4/widget/CursorAdapter$ChangeObserver;
  [Instance Field] mContext: Landroid/content/Context;
  [Instance Field] mCursor: Landroid/database/Cursor;
  [Instance Field] mCursorFilter: Landroid/support/v4/widget/CursorFilter;
  [Instance Field] mDataSetObserver: Landroid/database/DataSetObserver;
  [Instance Field] mDataValid: Z
  [Instance Field] mFilterQueryProvider: Landroid/widget/FilterQueryProvider;
  [Instance Field] mRowIDColumn: I

  [Direct Method] <init>(Landroid/content/Context;, Landroid/database/Cursor;) -> V
    // registers=4, ins=3, outs=4, insns_size=8
    0000: invoke-direct {v1}, Landroid/widget/BaseAdapter;-><init>()V
    0003: const/4 v0, 1
    0004: invoke-virtual {v1, v2, v3, v0}, Landroid/support/v4/widget/CursorAdapter;->init(Landroid/content/Context;Landroid/database/Cursor;I)V
    0007: return-void

  [Direct Method] <init>(Landroid/content/Context;, Landroid/database/Cursor;, I) -> V
    // registers=4, ins=4, outs=4, insns_size=7
    0000: invoke-direct {v0}, Landroid/widget/BaseAdapter;-><init>()V
    0003: invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/widget/CursorAdapter;->init(Landroid/content/Context;Landroid/database/Cursor;I)V
    0006: return-void

  [Direct Method] <init>(Landroid/content/Context;, Landroid/database/Cursor;, Z) -> V
    // registers=5, ins=4, outs=4, insns_size=12
    0000: invoke-direct {v1}, Landroid/widget/BaseAdapter;-><init>()V
    0003: if-eqz v4, 000a
    0005: const/4 v0, 1
    0006: invoke-virtual {v1, v2, v3, v0}, Landroid/support/v4/widget/CursorAdapter;->init(Landroid/content/Context;Landroid/database/Cursor;I)V
    0009: return-void
    000a: const/4 v0, 2
    000b: goto 0006

  [Virtual Method] bindView(Landroid/view/View;, Landroid/content/Context;, Landroid/database/Cursor;) -> V

  [Virtual Method] changeCursor(Landroid/database/Cursor;) -> V
    // registers=3, ins=2, outs=2, insns_size=10
    0000: invoke-virtual {v1, v2}, Landroid/support/v4/widget/CursorAdapter;->swapCursor(Landroid/database/Cursor;)Landroid/database/Cursor;
    0003: move-result-object v0
    0004: if-eqz v0, 0009
    0006: invoke-interface {v0}, Landroid/database/Cursor;->close()V
    0009: return-void

  [Virtual Method] convertToString(Landroid/database/Cursor;) -> Ljava/lang/CharSequence;
    // registers=3, ins=2, outs=1, insns_size=10
    0000: if-nez v2, 0005
    0002: const-string v0, ''
    0004: return-object v0
    0005: invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;
    0008: move-result-object v0
    0009: goto 0004

  [Virtual Method] getCount() -> I
    // registers=2, ins=1, outs=1, insns_size=17
    0000: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mDataValid:Z
    0002: if-eqz v0, 000f
    0004: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0006: if-eqz v0, 000f
    0008: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    000a: invoke-interface {v0}, Landroid/database/Cursor;->getCount()I
    000d: move-result v0
    000e: return v0
    000f: const/4 v0, 0
    0010: goto 000e

  [Virtual Method] getCursor() -> Landroid/database/Cursor;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0002: return-object v0

  [Virtual Method] getDropDownView(I, Landroid/view/View;, Landroid/view/ViewGroup;) -> Landroid/view/View;
    // registers=6, ins=4, outs=4, insns_size=29
    0000: iget v0, v2.Landroid/support/v4/widget/CursorAdapter;->mDataValid:Z
    0002: if-eqz v0, 001b
    0004: iget v0, v2.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0006: invoke-interface {v0, v3}, Landroid/database/Cursor;->moveToPosition(I)Z
    0009: if-nez v4, 0013
    000b: iget v0, v2.Landroid/support/v4/widget/CursorAdapter;->mContext:Landroid/content/Context;
    000d: iget v1, v2.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    000f: invoke-virtual {v2, v0, v1, v5}, Landroid/support/v4/widget/CursorAdapter;->newDropDownView(Landroid/content/Context;Landroid/database/Cursor;Landroid/view/ViewGroup;)Landroid/view/View;
    0012: move-result-object v4
    0013: iget v0, v2.Landroid/support/v4/widget/CursorAdapter;->mContext:Landroid/content/Context;
    0015: iget v1, v2.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0017: invoke-virtual {v2, v4, v0, v1}, Landroid/support/v4/widget/CursorAdapter;->bindView(Landroid/view/View;Landroid/content/Context;Landroid/database/Cursor;)V
    001a: return-object v4
    001b: const/4 v4, 0
    001c: goto 001a

  [Virtual Method] getFilter() -> Landroid/widget/Filter;
    // registers=2, ins=1, outs=2, insns_size=14
    0000: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursorFilter:Landroid/support/v4/widget/CursorFilter;
    0002: if-nez v0, 000b
    0004: new-instance v0, Landroid/support/v4/widget/CursorFilter;
    0006: invoke-direct {v0, v1}, Landroid/support/v4/widget/CursorFilter;-><init>(Landroid/support/v4/widget/CursorFilter$CursorFilterClient;)V
    0009: iput v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursorFilter:Landroid/support/v4/widget/CursorFilter;
    000b: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursorFilter:Landroid/support/v4/widget/CursorFilter;
    000d: return-object v0

  [Virtual Method] getFilterQueryProvider() -> Landroid/widget/FilterQueryProvider;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mFilterQueryProvider:Landroid/widget/FilterQueryProvider;
    0002: return-object v0

  [Virtual Method] getItem(I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=18
    0000: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mDataValid:Z
    0002: if-eqz v0, 0010
    0004: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0006: if-eqz v0, 0010
    0008: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    000a: invoke-interface {v0, v2}, Landroid/database/Cursor;->moveToPosition(I)Z
    000d: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    000f: return-object v0
    0010: const/4 v0, 0
    0011: goto 000f

  [Virtual Method] getItemId(I) -> J
    // registers=5, ins=2, outs=2, insns_size=27
    0000: const-wide/16 v0, 0
    0002: iget v2, v3.Landroid/support/v4/widget/CursorAdapter;->mDataValid:Z
    0004: if-eqz v2, 001a
    0006: iget v2, v3.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0008: if-eqz v2, 001a
    000a: iget v2, v3.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    000c: invoke-interface {v2, v4}, Landroid/database/Cursor;->moveToPosition(I)Z
    000f: move-result v2
    0010: if-eqz v2, 001a
    0012: iget v0, v3.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0014: iget v1, v3.Landroid/support/v4/widget/CursorAdapter;->mRowIDColumn:I
    0016: invoke-interface {v0, v1}, Landroid/database/Cursor;->getLong(I)J
    0019: move-result-wide v0
    001a: return-wide v0

  [Virtual Method] getView(I, Landroid/view/View;, Landroid/view/ViewGroup;) -> Landroid/view/View;
    // registers=7, ins=4, outs=4, insns_size=63
    0000: iget v0, v3.Landroid/support/v4/widget/CursorAdapter;->mDataValid:Z
    0002: if-nez v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'this should only be called when the cursor is valid'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: iget v0, v3.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    000e: invoke-interface {v0, v4}, Landroid/database/Cursor;->moveToPosition(I)Z
    0011: move-result v0
    0012: if-nez v0, 002d
    0014: new-instance v0, Ljava/lang/IllegalStateException;
    0016: new-instance v1, Ljava/lang/StringBuilder;
    0018: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    001b: const-string v2, "couldn't move cursor to position "
    001d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0020: move-result-object v1
    0021: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0024: move-result-object v1
    0025: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0028: move-result-object v1
    0029: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    002c: throw v0
    002d: if-nez v5, 0037
    002f: iget v0, v3.Landroid/support/v4/widget/CursorAdapter;->mContext:Landroid/content/Context;
    0031: iget v1, v3.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0033: invoke-virtual {v3, v0, v1, v6}, Landroid/support/v4/widget/CursorAdapter;->newView(Landroid/content/Context;Landroid/database/Cursor;Landroid/view/ViewGroup;)Landroid/view/View;
    0036: move-result-object v5
    0037: iget v0, v3.Landroid/support/v4/widget/CursorAdapter;->mContext:Landroid/content/Context;
    0039: iget v1, v3.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    003b: invoke-virtual {v3, v5, v0, v1}, Landroid/support/v4/widget/CursorAdapter;->bindView(Landroid/view/View;Landroid/content/Context;Landroid/database/Cursor;)V
    003e: return-object v5

  [Virtual Method] hasStableIds() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Virtual Method] init(Landroid/content/Context;, Landroid/database/Cursor;, I) -> V
    // registers=8, ins=4, outs=3, insns_size=81
    0000: const/4 v1, 0
    0001: const/4 v3, 0
    0002: const/4 v0, 1
    0003: binop/lit8(op=dd) v2, v7, 1 (0x1)
    0005: if-ne v2, v0, 0045
    0007: binop/lit8(op=de) v7, v7, 2 (0x2)
    0009: iput v0, v4.Landroid/support/v4/widget/CursorAdapter;->mAutoRequery:Z
    000b: if-eqz v6, 0048
    000d: iput v6, v4.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    000f: iput v0, v4.Landroid/support/v4/widget/CursorAdapter;->mDataValid:Z
    0011: iput v5, v4.Landroid/support/v4/widget/CursorAdapter;->mContext:Landroid/content/Context;
    0013: if-eqz v0, 004a
    0015: const-string v1, '_id'
    0017: invoke-interface {v6, v1}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I
    001a: move-result v1
    001b: iput v1, v4.Landroid/support/v4/widget/CursorAdapter;->mRowIDColumn:I
    001d: binop/lit8(op=dd) v1, v7, 2 (0x2)
    001f: const/4 v2, 2
    0020: if-ne v1, v2, 004c
    0022: new-instance v1, Landroid/support/v4/widget/CursorAdapter$ChangeObserver;
    0024: invoke-direct {v1, v4}, Landroid/support/v4/widget/CursorAdapter$ChangeObserver;-><init>(Landroid/support/v4/widget/CursorAdapter;)V
    0027: iput v1, v4.Landroid/support/v4/widget/CursorAdapter;->mChangeObserver:Landroid/support/v4/widget/CursorAdapter$ChangeObserver;
    0029: new-instance v1, Landroid/support/v4/widget/CursorAdapter$MyDataSetObserver;
    002b: invoke-direct {v1, v4, v3}, Landroid/support/v4/widget/CursorAdapter$MyDataSetObserver;-><init>(Landroid/support/v4/widget/CursorAdapter;Landroid/support/v4/widget/CursorAdapter$1;)V
    002e: iput v1, v4.Landroid/support/v4/widget/CursorAdapter;->mDataSetObserver:Landroid/database/DataSetObserver;
    0030: if-eqz v0, 0044
    0032: iget v0, v4.Landroid/support/v4/widget/CursorAdapter;->mChangeObserver:Landroid/support/v4/widget/CursorAdapter$ChangeObserver;
    0034: if-eqz v0, 003b
    0036: iget v0, v4.Landroid/support/v4/widget/CursorAdapter;->mChangeObserver:Landroid/support/v4/widget/CursorAdapter$ChangeObserver;
    0038: invoke-interface {v6, v0}, Landroid/database/Cursor;->registerContentObserver(Landroid/database/ContentObserver;)V
    003b: iget v0, v4.Landroid/support/v4/widget/CursorAdapter;->mDataSetObserver:Landroid/database/DataSetObserver;
    003d: if-eqz v0, 0044
    003f: iget v0, v4.Landroid/support/v4/widget/CursorAdapter;->mDataSetObserver:Landroid/database/DataSetObserver;
    0041: invoke-interface {v6, v0}, Landroid/database/Cursor;->registerDataSetObserver(Landroid/database/DataSetObserver;)V
    0044: return-void
    0045: iput v1, v4.Landroid/support/v4/widget/CursorAdapter;->mAutoRequery:Z
    0047: goto 000b
    0048: move(op=01) v0, v1
    0049: goto 000d
    004a: const/4 v1, -1
    004b: goto 001b
    004c: iput v3, v4.Landroid/support/v4/widget/CursorAdapter;->mChangeObserver:Landroid/support/v4/widget/CursorAdapter$ChangeObserver;
    004e: iput v3, v4.Landroid/support/v4/widget/CursorAdapter;->mDataSetObserver:Landroid/database/DataSetObserver;
    0050: goto 0030

  [Virtual Method] init(Landroid/content/Context;, Landroid/database/Cursor;, Z) -> V
    // registers=5, ins=4, outs=4, insns_size=9
    0000: if-eqz v4, 0007
    0002: const/4 v0, 1
    0003: invoke-virtual {v1, v2, v3, v0}, Landroid/support/v4/widget/CursorAdapter;->init(Landroid/content/Context;Landroid/database/Cursor;I)V
    0006: return-void
    0007: const/4 v0, 2
    0008: goto 0003

  [Virtual Method] newDropDownView(Landroid/content/Context;, Landroid/database/Cursor;, Landroid/view/ViewGroup;) -> Landroid/view/View;
    // registers=5, ins=4, outs=4, insns_size=5
    0000: invoke-virtual {v1, v2, v3, v4}, Landroid/support/v4/widget/CursorAdapter;->newView(Landroid/content/Context;Landroid/database/Cursor;Landroid/view/ViewGroup;)Landroid/view/View;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] newView(Landroid/content/Context;, Landroid/database/Cursor;, Landroid/view/ViewGroup;) -> Landroid/view/View;

  [Virtual Method] onContentChanged() -> V
    // registers=2, ins=1, outs=1, insns_size=25
    0000: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mAutoRequery:Z
    0002: if-eqz v0, 0018
    0004: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0006: if-eqz v0, 0018
    0008: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    000a: invoke-interface {v0}, Landroid/database/Cursor;->isClosed()Z
    000d: move-result v0
    000e: if-nez v0, 0018
    0010: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0012: invoke-interface {v0}, Landroid/database/Cursor;->requery()Z
    0015: move-result v0
    0016: iput v0, v1.Landroid/support/v4/widget/CursorAdapter;->mDataValid:Z
    0018: return-void

  [Virtual Method] runQueryOnBackgroundThread(Ljava/lang/CharSequence;) -> Landroid/database/Cursor;
    // registers=3, ins=2, outs=2, insns_size=14
    0000: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mFilterQueryProvider:Landroid/widget/FilterQueryProvider;
    0002: if-eqz v0, 000b
    0004: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mFilterQueryProvider:Landroid/widget/FilterQueryProvider;
    0006: invoke-interface {v0, v2}, Landroid/widget/FilterQueryProvider;->runQuery(Ljava/lang/CharSequence;)Landroid/database/Cursor;
    0009: move-result-object v0
    000a: return-object v0
    000b: iget v0, v1.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    000d: goto 000a

  [Virtual Method] setFilterQueryProvider(Landroid/widget/FilterQueryProvider;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/widget/CursorAdapter;->mFilterQueryProvider:Landroid/widget/FilterQueryProvider;
    0002: return-void

  [Virtual Method] swapCursor(Landroid/database/Cursor;) -> Landroid/database/Cursor;
    // registers=4, ins=2, outs=2, insns_size=75
    0000: iget v0, v2.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0002: if-ne v3, v0, 0006
    0004: const/4 v0, 0
    0005: return-object v0
    0006: iget v0, v2.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    0008: if-eqz v0, 001c
    000a: iget v1, v2.Landroid/support/v4/widget/CursorAdapter;->mChangeObserver:Landroid/support/v4/widget/CursorAdapter$ChangeObserver;
    000c: if-eqz v1, 0013
    000e: iget v1, v2.Landroid/support/v4/widget/CursorAdapter;->mChangeObserver:Landroid/support/v4/widget/CursorAdapter$ChangeObserver;
    0010: invoke-interface {v0, v1}, Landroid/database/Cursor;->unregisterContentObserver(Landroid/database/ContentObserver;)V
    0013: iget v1, v2.Landroid/support/v4/widget/CursorAdapter;->mDataSetObserver:Landroid/database/DataSetObserver;
    0015: if-eqz v1, 001c
    0017: iget v1, v2.Landroid/support/v4/widget/CursorAdapter;->mDataSetObserver:Landroid/database/DataSetObserver;
    0019: invoke-interface {v0, v1}, Landroid/database/Cursor;->unregisterDataSetObserver(Landroid/database/DataSetObserver;)V
    001c: iput v3, v2.Landroid/support/v4/widget/CursorAdapter;->mCursor:Landroid/database/Cursor;
    001e: if-eqz v3, 0041
    0020: iget v1, v2.Landroid/support/v4/widget/CursorAdapter;->mChangeObserver:Landroid/support/v4/widget/CursorAdapter$ChangeObserver;
    0022: if-eqz v1, 0029
    0024: iget v1, v2.Landroid/support/v4/widget/CursorAdapter;->mChangeObserver:Landroid/support/v4/widget/CursorAdapter$ChangeObserver;
    0026: invoke-interface {v3, v1}, Landroid/database/Cursor;->registerContentObserver(Landroid/database/ContentObserver;)V
    0029: iget v1, v2.Landroid/support/v4/widget/CursorAdapter;->mDataSetObserver:Landroid/database/DataSetObserver;
    002b: if-eqz v1, 0032
    002d: iget v1, v2.Landroid/support/v4/widget/CursorAdapter;->mDataSetObserver:Landroid/database/DataSetObserver;
    002f: invoke-interface {v3, v1}, Landroid/database/Cursor;->registerDataSetObserver(Landroid/database/DataSetObserver;)V
    0032: const-string v1, '_id'
    0034: invoke-interface {v3, v1}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I
    0037: move-result v1
    0038: iput v1, v2.Landroid/support/v4/widget/CursorAdapter;->mRowIDColumn:I
    003a: const/4 v1, 1
    003b: iput v1, v2.Landroid/support/v4/widget/CursorAdapter;->mDataValid:Z
    003d: invoke-virtual {v2}, Landroid/support/v4/widget/CursorAdapter;->notifyDataSetChanged()V
    0040: goto 0005
    0041: const/4 v1, -1
    0042: iput v1, v2.Landroid/support/v4/widget/CursorAdapter;->mRowIDColumn:I
    0044: const/4 v1, 0
    0045: iput v1, v2.Landroid/support/v4/widget/CursorAdapter;->mDataValid:Z
    0047: invoke-virtual {v2}, Landroid/support/v4/widget/CursorAdapter;->notifyDataSetInvalidated()V
    004a: goto 0005