=== CLASS Landroid/support/v4/net/ConnectivityManagerCompat$ConnectivityManagerCompatImpl; (Source: ConnectivityManagerCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] isActiveNetworkMetered(Landroid/net/ConnectivityManager;) -> Z