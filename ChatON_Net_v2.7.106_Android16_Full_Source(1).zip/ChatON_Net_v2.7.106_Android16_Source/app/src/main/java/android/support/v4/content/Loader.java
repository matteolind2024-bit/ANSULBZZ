=== CLASS Landroid/support/v4/content/Loader; (Source: Loader.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] mAbandoned: Z
  [Instance Field] mContentChanged: Z
  [Instance Field] mContext: Landroid/content/Context;
  [Instance Field] mId: I
  [Instance Field] mListener: Landroid/support/v4/content/Loader$OnLoadCompleteListener;
  [Instance Field] mReset: Z
  [Instance Field] mStarted: Z

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=4, ins=2, outs=1, insns_size=20
    0000: const/4 v1, 0
    0001: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0004: iput v1, v2.Landroid/support/v4/content/Loader;->mStarted:Z
    0006: iput v1, v2.Landroid/support/v4/content/Loader;->mAbandoned:Z
    0008: const/4 v0, 1
    0009: iput v0, v2.Landroid/support/v4/content/Loader;->mReset:Z
    000b: iput v1, v2.Landroid/support/v4/content/Loader;->mContentChanged:Z
    000d: invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;
    0010: move-result-object v0
    0011: iput v0, v2.Landroid/support/v4/content/Loader;->mContext:Landroid/content/Context;
    0013: return-void

  [Virtual Method] abandon() -> V
    // registers=2, ins=1, outs=1, insns_size=7
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/content/Loader;->mAbandoned:Z
    0003: invoke-virtual {v1}, Landroid/support/v4/content/Loader;->onAbandon()V
    0006: return-void

  [Virtual Method] dataToString(Ljava/lang/Object;) -> Ljava/lang/String;
    // registers=4, ins=2, outs=2, insns_size=20
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: const/16 v1, 64 (0x40)
    0004: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V
    0007: invoke-static {v3, v0}, Landroid/support/v4/util/DebugUtils;->buildShortClassTag(Ljava/lang/Object;Ljava/lang/StringBuilder;)V
    000a: const-string v1, '}'
    000c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000f: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0012: move-result-object v0
    0013: return-object v0

  [Virtual Method] deliverResult(Ljava/lang/Object;) -> V
    // registers=3, ins=2, outs=3, insns_size=10
    0000: iget v0, v1.Landroid/support/v4/content/Loader;->mListener:Landroid/support/v4/content/Loader$OnLoadCompleteListener;
    0002: if-eqz v0, 0009
    0004: iget v0, v1.Landroid/support/v4/content/Loader;->mListener:Landroid/support/v4/content/Loader$OnLoadCompleteListener;
    0006: invoke-interface {v0, v1, v2}, Landroid/support/v4/content/Loader$OnLoadCompleteListener;->onLoadComplete(Landroid/support/v4/content/Loader;Ljava/lang/Object;)V
    0009: return-void

  [Virtual Method] dump(Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V
    // registers=6, ins=5, outs=2, insns_size=67
    0000: invoke-virtual {v4, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0003: const-string v0, 'mId='
    0005: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0008: iget v0, v1.Landroid/support/v4/content/Loader;->mId:I
    000a: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(I)V
    000d: const-string v0, ' mListener='
    000f: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0012: iget v0, v1.Landroid/support/v4/content/Loader;->mListener:Landroid/support/v4/content/Loader$OnLoadCompleteListener;
    0014: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0017: invoke-virtual {v4, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    001a: const-string v0, 'mStarted='
    001c: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    001f: iget v0, v1.Landroid/support/v4/content/Loader;->mStarted:Z
    0021: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Z)V
    0024: const-string v0, ' mContentChanged='
    0026: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0029: iget v0, v1.Landroid/support/v4/content/Loader;->mContentChanged:Z
    002b: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Z)V
    002e: const-string v0, ' mAbandoned='
    0030: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0033: iget v0, v1.Landroid/support/v4/content/Loader;->mAbandoned:Z
    0035: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Z)V
    0038: const-string v0, ' mReset='
    003a: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    003d: iget v0, v1.Landroid/support/v4/content/Loader;->mReset:Z
    003f: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->println(Z)V
    0042: return-void

  [Virtual Method] forceLoad() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-virtual {v0}, Landroid/support/v4/content/Loader;->onForceLoad()V
    0003: return-void

  [Virtual Method] getContext() -> Landroid/content/Context;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/Loader;->mContext:Landroid/content/Context;
    0002: return-object v0

  [Virtual Method] getId() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/Loader;->mId:I
    0002: return v0

  [Virtual Method] isAbandoned() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/Loader;->mAbandoned:Z
    0002: return v0

  [Virtual Method] isReset() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/Loader;->mReset:Z
    0002: return v0

  [Virtual Method] isStarted() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/Loader;->mStarted:Z
    0002: return v0

  [Virtual Method] onAbandon() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onContentChanged() -> V
    // registers=2, ins=1, outs=1, insns_size=12
    0000: iget v0, v1.Landroid/support/v4/content/Loader;->mStarted:Z
    0002: if-eqz v0, 0008
    0004: invoke-virtual {v1}, Landroid/support/v4/content/Loader;->forceLoad()V
    0007: return-void
    0008: const/4 v0, 1
    0009: iput v0, v1.Landroid/support/v4/content/Loader;->mContentChanged:Z
    000b: goto 0007

  [Virtual Method] onForceLoad() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onReset() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onStartLoading() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onStopLoading() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] registerListener(I, Landroid/support/v4/content/Loader$OnLoadCompleteListener;) -> V
    // registers=5, ins=3, outs=2, insns_size=17
    0000: iget v0, v2.Landroid/support/v4/content/Loader;->mListener:Landroid/support/v4/content/Loader$OnLoadCompleteListener;
    0002: if-eqz v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'There is already a listener registered'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: iput v4, v2.Landroid/support/v4/content/Loader;->mListener:Landroid/support/v4/content/Loader$OnLoadCompleteListener;
    000e: iput v3, v2.Landroid/support/v4/content/Loader;->mId:I
    0010: return-void

  [Virtual Method] reset() -> V
    // registers=3, ins=1, outs=1, insns_size=14
    0000: const/4 v1, 0
    0001: invoke-virtual {v2}, Landroid/support/v4/content/Loader;->onReset()V
    0004: const/4 v0, 1
    0005: iput v0, v2.Landroid/support/v4/content/Loader;->mReset:Z
    0007: iput v1, v2.Landroid/support/v4/content/Loader;->mStarted:Z
    0009: iput v1, v2.Landroid/support/v4/content/Loader;->mAbandoned:Z
    000b: iput v1, v2.Landroid/support/v4/content/Loader;->mContentChanged:Z
    000d: return-void

  [Virtual Method] startLoading() -> V
    // registers=3, ins=1, outs=1, insns_size=12
    0000: const/4 v1, 0
    0001: const/4 v0, 1
    0002: iput v0, v2.Landroid/support/v4/content/Loader;->mStarted:Z
    0004: iput v1, v2.Landroid/support/v4/content/Loader;->mReset:Z
    0006: iput v1, v2.Landroid/support/v4/content/Loader;->mAbandoned:Z
    0008: invoke-virtual {v2}, Landroid/support/v4/content/Loader;->onStartLoading()V
    000b: return-void

  [Virtual Method] stopLoading() -> V
    // registers=2, ins=1, outs=1, insns_size=7
    0000: const/4 v0, 0
    0001: iput v0, v1.Landroid/support/v4/content/Loader;->mStarted:Z
    0003: invoke-virtual {v1}, Landroid/support/v4/content/Loader;->onStopLoading()V
    0006: return-void

  [Virtual Method] takeContentChanged() -> Z
    // registers=3, ins=1, outs=0, insns_size=6
    0000: iget v0, v2.Landroid/support/v4/content/Loader;->mContentChanged:Z
    0002: const/4 v1, 0
    0003: iput v1, v2.Landroid/support/v4/content/Loader;->mContentChanged:Z
    0005: return v0

  [Virtual Method] toString() -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=30
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: const/16 v1, 64 (0x40)
    0004: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V
    0007: invoke-static {v2, v0}, Landroid/support/v4/util/DebugUtils;->buildShortClassTag(Ljava/lang/Object;Ljava/lang/StringBuilder;)V
    000a: const-string v1, ' id='
    000c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000f: iget v1, v2.Landroid/support/v4/content/Loader;->mId:I
    0011: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0014: const-string v1, '}'
    0016: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0019: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001c: move-result-object v0
    001d: return-object v0

  [Virtual Method] unregisterListener(Landroid/support/v4/content/Loader$OnLoadCompleteListener;) -> V
    // registers=4, ins=2, outs=2, insns_size=28
    0000: iget v0, v2.Landroid/support/v4/content/Loader;->mListener:Landroid/support/v4/content/Loader$OnLoadCompleteListener;
    0002: if-nez v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'No listener register'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: iget v0, v2.Landroid/support/v4/content/Loader;->mListener:Landroid/support/v4/content/Loader$OnLoadCompleteListener;
    000e: if-eq v0, v3, 0018
    0010: new-instance v0, Ljava/lang/IllegalArgumentException;
    0012: const-string v1, 'Attempting to unregister the wrong listener'
    0014: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0017: throw v0
    0018: const/4 v0, 0
    0019: iput v0, v2.Landroid/support/v4/content/Loader;->mListener:Landroid/support/v4/content/Loader$OnLoadCompleteListener;
    001b: return-void