=== CLASS Landroid/support/v4/app/ShareCompat$ShareCompatImplICS; (Source: ShareCompat.java) ===
  Super: Landroid/support/v4/app/ShareCompat$ShareCompatImplBase;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/app/ShareCompat$ShareCompatImplBase;-><init>()V
    0003: return-void

  [Virtual Method] configureMenuItem(Landroid/view/MenuItem;, Landroid/support/v4/app/ShareCompat$IntentBuilder;) -> V
    // registers=5, ins=3, outs=3, insns_size=25
    0000: invoke-virtual {v4}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->getActivity()Landroid/app/Activity;
    0003: move-result-object v0
    0004: invoke-virtual {v4}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->getIntent()Landroid/content/Intent;
    0007: move-result-object v1
    0008: invoke-static {v3, v0, v1}, Landroid/support/v4/app/ShareCompatICS;->configureMenuItem(Landroid/view/MenuItem;Landroid/app/Activity;Landroid/content/Intent;)V
    000b: invoke-virtual {v2, v3}, Landroid/support/v4/app/ShareCompat$ShareCompatImplICS;->shouldAddChooserIntent(Landroid/view/MenuItem;)Z
    000e: move-result v0
    000f: if-eqz v0, 0018
    0011: invoke-virtual {v4}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->createChooserIntent()Landroid/content/Intent;
    0014: move-result-object v0
    0015: invoke-interface {v3, v0}, Landroid/view/MenuItem;->setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;
    0018: return-void

  [Virtual Method] shouldAddChooserIntent(Landroid/view/MenuItem;) -> Z
    // registers=3, ins=2, outs=1, insns_size=10
    0000: invoke-interface {v2}, Landroid/view/MenuItem;->hasSubMenu()Z
    0003: move-result v0
    0004: if-nez v0, 0008
    0006: const/4 v0, 1
    0007: return v0
    0008: const/4 v0, 0
    0009: goto 0007