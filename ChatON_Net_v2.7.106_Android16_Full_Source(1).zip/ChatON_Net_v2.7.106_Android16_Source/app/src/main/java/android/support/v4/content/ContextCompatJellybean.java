=== CLASS Landroid/support/v4/content/ContextCompatJellybean; (Source: ContextCompatJellybean.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] startActivities(Landroid/content/Context;, [Landroid/content/Intent;, Landroid/os/Bundle;) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-virtual {v0, v1, v2}, Landroid/content/Context;->startActivities([Landroid/content/Intent;Landroid/os/Bundle;)V
    0003: return-void