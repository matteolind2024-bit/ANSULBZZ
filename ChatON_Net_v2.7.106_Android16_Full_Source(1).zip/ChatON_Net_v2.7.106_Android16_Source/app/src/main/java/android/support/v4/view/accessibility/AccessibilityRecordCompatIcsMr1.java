=== CLASS Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcsMr1; (Source: AccessibilityRecordCompatIcsMr1.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getMaxScrollX(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getMaxScrollX()I
    0005: move-result v0
    0006: return v0

  [Direct Method] getMaxScrollY(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getMaxScrollY()I
    0005: move-result v0
    0006: return v0

  [Direct Method] setMaxScrollX(Ljava/lang/Object;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setMaxScrollX(I)V
    0005: return-void

  [Direct Method] setMaxScrollY(Ljava/lang/Object;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityRecord;->setMaxScrollY(I)V
    0005: return-void