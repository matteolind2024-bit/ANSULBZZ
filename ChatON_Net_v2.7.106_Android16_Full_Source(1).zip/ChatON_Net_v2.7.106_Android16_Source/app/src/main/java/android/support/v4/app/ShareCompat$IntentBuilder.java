=== CLASS Landroid/support/v4/app/ShareCompat$IntentBuilder; (Source: ShareCompat.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] mActivity: Landroid/app/Activity;
  [Instance Field] mBccAddresses: Ljava/util/ArrayList;
  [Instance Field] mCcAddresses: Ljava/util/ArrayList;
  [Instance Field] mChooserTitle: Ljava/lang/CharSequence;
  [Instance Field] mIntent: Landroid/content/Intent;
  [Instance Field] mStreams: Ljava/util/ArrayList;
  [Instance Field] mToAddresses: Ljava/util/ArrayList;

  [Direct Method] <init>(Landroid/app/Activity;) -> V
    // registers=5, ins=2, outs=3, insns_size=48
    0000: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    0003: iput v4, v3.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mActivity:Landroid/app/Activity;
    0005: new-instance v0, Landroid/content/Intent;
    0007: invoke-direct {v0}, Landroid/content/Intent;-><init>()V
    000a: const-string v1, 'android.intent.action.SEND'
    000c: invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;
    000f: move-result-object v0
    0010: iput v0, v3.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0012: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0014: const-string v1, 'android.support.v4.app.EXTRA_CALLING_PACKAGE'
    0016: invoke-virtual {v4}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;
    0019: move-result-object v2
    001a: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    001d: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    001f: const-string v1, 'android.support.v4.app.EXTRA_CALLING_ACTIVITY'
    0021: invoke-virtual {v4}, Landroid/app/Activity;->getComponentName()Landroid/content/ComponentName;
    0024: move-result-object v2
    0025: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    0028: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    002a: const/high16 v1, 524288 (0x80000)
    002c: invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    002f: return-void

  [Direct Method] combineArrayExtra(Ljava/lang/String;, Ljava/util/ArrayList;) -> V
    // registers=8, ins=3, outs=5, insns_size=37
    0000: const/4 v1, 0
    0001: iget v0, v5.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0003: invoke-virtual {v0, v6}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;
    0006: move-result-object v2
    0007: if-eqz v2, 0023
    0009: move(op=21) v0, v2
    000a: invoke-virtual {v7}, Ljava/util/ArrayList;->size()I
    000d: move-result v3
    000e: binop/2addr(op=b0) v3, v0
    000f: new-array v3, v3, [Ljava/lang/String;
    0011: invoke-virtual {v7, v3}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    0014: if-eqz v2, 001d
    0016: invoke-virtual {v7}, Ljava/util/ArrayList;->size()I
    0019: move-result v4
    001a: invoke-static {v2, v1, v3, v4, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    001d: iget v0, v5.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    001f: invoke-virtual {v0, v6, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;
    0022: return-void
    0023: move(op=01) v0, v1
    0024: goto 000a

  [Direct Method] combineArrayExtra(Ljava/lang/String;, [Ljava/lang/String;) -> V
    // registers=8, ins=3, outs=5, insns_size=31
    0000: const/4 v1, 0
    0001: invoke-virtual {v5}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->getIntent()Landroid/content/Intent;
    0004: move-result-object v2
    0005: invoke-virtual {v2, v6}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;
    0008: move-result-object v3
    0009: if-eqz v3, 001d
    000b: move(op=21) v0, v3
    000c: move(op=21) v4, v7
    000d: binop/2addr(op=b0) v4, v0
    000e: new-array v4, v4, [Ljava/lang/String;
    0010: if-eqz v3, 0015
    0012: invoke-static {v3, v1, v4, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0015: move(op=21) v3, v7
    0016: invoke-static {v7, v1, v4, v0, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0019: invoke-virtual {v2, v6, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;
    001c: return-void
    001d: move(op=01) v0, v1
    001e: goto 000c

  [Direct Method] from(Landroid/app/Activity;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Landroid/support/v4/app/ShareCompat$IntentBuilder;
    0002: invoke-direct {v0, v1}, Landroid/support/v4/app/ShareCompat$IntentBuilder;-><init>(Landroid/app/Activity;)V
    0005: return-object v0

  [Virtual Method] addEmailBcc(Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=3, ins=2, outs=2, insns_size=17
    0000: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mBccAddresses:Ljava/util/ArrayList;
    0002: if-nez v0, 000b
    0004: new-instance v0, Ljava/util/ArrayList;
    0006: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0009: iput v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mBccAddresses:Ljava/util/ArrayList;
    000b: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mBccAddresses:Ljava/util/ArrayList;
    000d: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0010: return-object v1

  [Virtual Method] addEmailBcc([Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=3, ins=2, outs=3, insns_size=6
    0000: const-string v0, 'android.intent.extra.BCC'
    0002: invoke-direct {v1, v0, v2}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->combineArrayExtra(Ljava/lang/String;[Ljava/lang/String;)V
    0005: return-object v1

  [Virtual Method] addEmailCc(Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=3, ins=2, outs=2, insns_size=17
    0000: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mCcAddresses:Ljava/util/ArrayList;
    0002: if-nez v0, 000b
    0004: new-instance v0, Ljava/util/ArrayList;
    0006: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0009: iput v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mCcAddresses:Ljava/util/ArrayList;
    000b: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mCcAddresses:Ljava/util/ArrayList;
    000d: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0010: return-object v1

  [Virtual Method] addEmailCc([Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=3, ins=2, outs=3, insns_size=6
    0000: const-string v0, 'android.intent.extra.CC'
    0002: invoke-direct {v1, v0, v2}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->combineArrayExtra(Ljava/lang/String;[Ljava/lang/String;)V
    0005: return-object v1

  [Virtual Method] addEmailTo(Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=3, ins=2, outs=2, insns_size=17
    0000: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mToAddresses:Ljava/util/ArrayList;
    0002: if-nez v0, 000b
    0004: new-instance v0, Ljava/util/ArrayList;
    0006: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0009: iput v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mToAddresses:Ljava/util/ArrayList;
    000b: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mToAddresses:Ljava/util/ArrayList;
    000d: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0010: return-object v1

  [Virtual Method] addEmailTo([Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=3, ins=2, outs=3, insns_size=6
    0000: const-string v0, 'android.intent.extra.EMAIL'
    0002: invoke-direct {v1, v0, v2}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->combineArrayExtra(Ljava/lang/String;[Ljava/lang/String;)V
    0005: return-object v1

  [Virtual Method] addStream(Landroid/net/Uri;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=5, ins=2, outs=2, insns_size=48
    0000: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.STREAM'
    0004: invoke-virtual {v0, v1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;
    0007: move-result-object v0
    0008: check-cast v0, Landroid/net/Uri;
    000a: if-nez v0, 0011
    000c: invoke-virtual {v3, v4}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->setStream(Landroid/net/Uri;)Landroid/support/v4/app/ShareCompat$IntentBuilder;
    000f: move-result-object v3
    0010: return-object v3
    0011: iget v1, v3.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    0013: if-nez v1, 001c
    0015: new-instance v1, Ljava/util/ArrayList;
    0017: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    001a: iput v1, v3.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    001c: if-eqz v0, 002a
    001e: iget v1, v3.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0020: const-string v2, 'android.intent.extra.STREAM'
    0022: invoke-virtual {v1, v2}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V
    0025: iget v1, v3.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    0027: invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    002a: iget v0, v3.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    002c: invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    002f: goto 0010

  [Virtual Method] createChooserIntent() -> Landroid/content/Intent;
    // registers=3, ins=1, outs=2, insns_size=11
    0000: invoke-virtual {v2}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->getIntent()Landroid/content/Intent;
    0003: move-result-object v0
    0004: iget v1, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mChooserTitle:Ljava/lang/CharSequence;
    0006: invoke-static {v0, v1}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;
    0009: move-result-object v0
    000a: return-object v0

  [Virtual Method] getActivity() -> Landroid/app/Activity;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mActivity:Landroid/app/Activity;
    0002: return-object v0

  [Virtual Method] getIntent() -> Landroid/content/Intent;
    // registers=8, ins=1, outs=3, insns_size=160
    0000: const/4 v0, 1
    0001: const/4 v2, 0
    0002: const/4 v6, 0
    0003: iget v1, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mToAddresses:Ljava/util/ArrayList;
    0005: if-eqz v1, 0010
    0007: const-string v1, 'android.intent.extra.EMAIL'
    0009: iget v3, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mToAddresses:Ljava/util/ArrayList;
    000b: invoke-direct {v7, v1, v3}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->combineArrayExtra(Ljava/lang/String;Ljava/util/ArrayList;)V
    000e: iput v6, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mToAddresses:Ljava/util/ArrayList;
    0010: iget v1, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mCcAddresses:Ljava/util/ArrayList;
    0012: if-eqz v1, 001d
    0014: const-string v1, 'android.intent.extra.CC'
    0016: iget v3, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mCcAddresses:Ljava/util/ArrayList;
    0018: invoke-direct {v7, v1, v3}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->combineArrayExtra(Ljava/lang/String;Ljava/util/ArrayList;)V
    001b: iput v6, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mCcAddresses:Ljava/util/ArrayList;
    001d: iget v1, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mBccAddresses:Ljava/util/ArrayList;
    001f: if-eqz v1, 002a
    0021: const-string v1, 'android.intent.extra.BCC'
    0023: iget v3, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mBccAddresses:Ljava/util/ArrayList;
    0025: invoke-direct {v7, v1, v3}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->combineArrayExtra(Ljava/lang/String;Ljava/util/ArrayList;)V
    0028: iput v6, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mBccAddresses:Ljava/util/ArrayList;
    002a: iget v1, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    002c: if-eqz v1, 008e
    002e: iget v1, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    0030: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0033: move-result v1
    0034: if-le v1, v0, 008e
    0036: move(op=01) v1, v0
    0037: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0039: invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    003c: move-result-object v0
    003d: const-string v3, 'android.intent.action.SEND_MULTIPLE'
    003f: invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    0042: move-result v3
    0043: if-nez v1, 006b
    0045: if-eqz v3, 006b
    0047: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0049: const-string v4, 'android.intent.action.SEND'
    004b: invoke-virtual {v0, v4}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;
    004e: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    0050: if-eqz v0, 0090
    0052: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    0054: invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z
    0057: move-result v0
    0058: if-nez v0, 0090
    005a: iget v4, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    005c: const-string v5, 'android.intent.extra.STREAM'
    005e: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    0060: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0063: move-result-object v0
    0064: check-cast v0, Landroid/os/Parcelable;
    0066: invoke-virtual {v4, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    0069: iput v6, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    006b: if-eqz v1, 008b
    006d: if-nez v3, 008b
    006f: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0071: const-string v1, 'android.intent.action.SEND_MULTIPLE'
    0073: invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;
    0076: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    0078: if-eqz v0, 0098
    007a: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    007c: invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z
    007f: move-result v0
    0080: if-nez v0, 0098
    0082: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0084: const-string v1, 'android.intent.extra.STREAM'
    0086: iget v2, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    0088: invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putParcelableArrayListExtra(Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;
    008b: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    008d: return-object v0
    008e: move(op=01) v1, v2
    008f: goto 0037
    0090: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0092: const-string v2, 'android.intent.extra.STREAM'
    0094: invoke-virtual {v0, v2}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V
    0097: goto 0069
    0098: iget v0, v7.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    009a: const-string v1, 'android.intent.extra.STREAM'
    009c: invoke-virtual {v0, v1}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V
    009f: goto 008b

  [Virtual Method] setChooserTitle(I) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=3, ins=2, outs=2, insns_size=11
    0000: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mActivity:Landroid/app/Activity;
    0002: invoke-virtual {v0, v2}, Landroid/app/Activity;->getText(I)Ljava/lang/CharSequence;
    0005: move-result-object v0
    0006: invoke-virtual {v1, v0}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->setChooserTitle(Ljava/lang/CharSequence;)Landroid/support/v4/app/ShareCompat$IntentBuilder;
    0009: move-result-object v0
    000a: return-object v0

  [Virtual Method] setChooserTitle(Ljava/lang/CharSequence;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mChooserTitle:Ljava/lang/CharSequence;
    0002: return-object v0

  [Virtual Method] setEmailBcc([Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=4, ins=2, outs=3, insns_size=8
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.BCC'
    0004: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;
    0007: return-object v2

  [Virtual Method] setEmailCc([Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=4, ins=2, outs=3, insns_size=8
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.CC'
    0004: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;
    0007: return-object v2

  [Virtual Method] setEmailTo([Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=4, ins=2, outs=3, insns_size=15
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mToAddresses:Ljava/util/ArrayList;
    0002: if-eqz v0, 0007
    0004: const/4 v0, 0
    0005: iput v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mToAddresses:Ljava/util/ArrayList;
    0007: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0009: const-string v1, 'android.intent.extra.EMAIL'
    000b: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;
    000e: return-object v2

  [Virtual Method] setHtmlText(Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=4, ins=2, outs=3, insns_size=25
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.HTML_TEXT'
    0004: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    0007: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0009: const-string v1, 'android.intent.extra.TEXT'
    000b: invoke-virtual {v0, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z
    000e: move-result v0
    000f: if-nez v0, 0018
    0011: invoke-static {v3}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;
    0014: move-result-object v0
    0015: invoke-virtual {v2, v0}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->setText(Ljava/lang/CharSequence;)Landroid/support/v4/app/ShareCompat$IntentBuilder;
    0018: return-object v2

  [Virtual Method] setStream(Landroid/net/Uri;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=4, ins=2, outs=3, insns_size=32
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0002: invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;
    0005: move-result-object v0
    0006: const-string v1, 'android.intent.action.SEND'
    0008: invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    000b: move-result v0
    000c: if-nez v0, 0015
    000e: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0010: const-string v1, 'android.intent.action.SEND'
    0012: invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;
    0015: const/4 v0, 0
    0016: iput v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mStreams:Ljava/util/ArrayList;
    0018: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    001a: const-string v1, 'android.intent.extra.STREAM'
    001c: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    001f: return-object v2

  [Virtual Method] setSubject(Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=4, ins=2, outs=3, insns_size=8
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.SUBJECT'
    0004: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    0007: return-object v2

  [Virtual Method] setText(Ljava/lang/CharSequence;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=4, ins=2, outs=3, insns_size=8
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0002: const-string v1, 'android.intent.extra.TEXT'
    0004: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/CharSequence;)Landroid/content/Intent;
    0007: return-object v2

  [Virtual Method] setType(Ljava/lang/String;) -> Landroid/support/v4/app/ShareCompat$IntentBuilder;
    // registers=3, ins=2, outs=2, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mIntent:Landroid/content/Intent;
    0002: invoke-virtual {v0, v2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;
    0005: return-object v1

  [Virtual Method] startChooser() -> V
    // registers=3, ins=1, outs=2, insns_size=10
    0000: iget v0, v2.Landroid/support/v4/app/ShareCompat$IntentBuilder;->mActivity:Landroid/app/Activity;
    0002: invoke-virtual {v2}, Landroid/support/v4/app/ShareCompat$IntentBuilder;->createChooserIntent()Landroid/content/Intent;
    0005: move-result-object v1
    0006: invoke-virtual {v0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    0009: return-void