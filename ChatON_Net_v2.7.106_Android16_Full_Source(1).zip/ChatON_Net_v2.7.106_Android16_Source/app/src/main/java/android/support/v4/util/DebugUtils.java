=== CLASS Landroid/support/v4/util/DebugUtils; (Source: DebugUtils.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] buildShortClassTag(Ljava/lang/Object;, Ljava/lang/StringBuilder;) -> V
    // registers=4, ins=2, outs=2, insns_size=66
    0000: if-nez v2, 0008
    0002: const-string v0, 'null'
    0004: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0007: return-void
    0008: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    000b: move-result-object v0
    000c: invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    000f: move-result-object v0
    0010: if-eqz v0, 0018
    0012: invoke-virtual {v0}, Ljava/lang/String;->length()I
    0015: move-result v1
    0016: if-gtz v1, 002e
    0018: invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    001b: move-result-object v0
    001c: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    001f: move-result-object v0
    0020: const/16 v1, 46 (0x2e)
    0022: invoke-virtual {v0, v1}, Ljava/lang/String;->lastIndexOf(I)I
    0025: move-result v1
    0026: if-lez v1, 002e
    0028: binop/lit8(op=d8) v1, v1, 1 (0x1)
    002a: invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    002d: move-result-object v0
    002e: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0031: const/16 v0, 123 (0x7b)
    0033: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    0036: invoke-static {v2}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I
    0039: move-result v0
    003a: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    003d: move-result-object v0
    003e: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0041: goto 0007