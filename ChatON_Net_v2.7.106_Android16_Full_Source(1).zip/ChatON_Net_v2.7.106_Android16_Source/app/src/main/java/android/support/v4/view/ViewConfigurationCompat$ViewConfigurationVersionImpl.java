=== CLASS Landroid/support/v4/view/ViewConfigurationCompat$ViewConfigurationVersionImpl; (Source: ViewConfigurationCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] getScaledPagingTouchSlop(Landroid/view/ViewConfiguration;) -> I