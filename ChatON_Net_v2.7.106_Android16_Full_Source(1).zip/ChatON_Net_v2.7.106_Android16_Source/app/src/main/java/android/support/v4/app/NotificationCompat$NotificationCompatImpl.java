=== CLASS Landroid/support/v4/app/NotificationCompat$NotificationCompatImpl; (Source: NotificationCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] getNotification(Landroid/support/v4/app/NotificationCompat$Builder;) -> Landroid/app/Notification;