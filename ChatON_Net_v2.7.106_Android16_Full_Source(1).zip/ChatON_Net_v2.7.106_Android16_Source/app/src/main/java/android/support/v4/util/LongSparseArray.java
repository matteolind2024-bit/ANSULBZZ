=== CLASS Landroid/support/v4/util/LongSparseArray; (Source: LongSparseArray.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/lang/Cloneable;
  [Static Field] DELETED: Ljava/lang/Object;
  [Instance Field] mGarbage: Z
  [Instance Field] mKeys: [J
  [Instance Field] mSize: I
  [Instance Field] mValues: [Ljava/lang/Object;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=8
    0000: new-instance v0, Ljava/lang/Object;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: sput v0, Landroid/support/v4/util/LongSparseArray;->DELETED:Ljava/lang/Object;
    0007: return-void

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: const/16 v0, 10 (0xa)
    0002: invoke-direct {v1, v0}, Landroid/support/v4/util/LongSparseArray;-><init>(I)V
    0005: return-void

  [Direct Method] <init>(I) -> V
    // registers=5, ins=2, outs=1, insns_size=21
    0000: const/4 v2, 0
    0001: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    0004: iput v2, v3.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0006: invoke-static {v4}, Landroid/support/v4/util/LongSparseArray;->idealLongArraySize(I)I
    0009: move-result v0
    000a: new-array v1, v0, [J
    000c: iput v1, v3.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    000e: new-array v0, v0, [Ljava/lang/Object;
    0010: iput v0, v3.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0012: iput v2, v3.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0014: return-void

  [Direct Method] binarySearch([J, I, I, J) -> I
    // registers=10, ins=5, outs=0, insns_size=43
    0000: binop(op=90) v2, v6, v7
    0002: binop/lit8(op=d8) v0, v6, -1 (-0x1)
    0004: move(op=01) v1, v0
    0005: move(op=01) v0, v2
    0006: binop(op=91) v2, v0, v1
    0008: const/4 v3, 1
    0009: if-le v2, v3, 0019
    000b: binop(op=90) v2, v0, v1
    000d: binop/lit8(op=db) v2, v2, 2 (0x2)
    000f: aget(op=45) v3, v5[v2]
    0011: cmp(op=31) v3, v3, v8
    0013: if-gez v3, 0017
    0015: move(op=01) v1, v2
    0016: goto 0006
    0017: move(op=01) v0, v2
    0018: goto 0006
    0019: binop(op=90) v1, v6, v7
    001b: if-ne v0, v1, 0022
    001d: binop(op=90) v0, v6, v7
    001f: binop/lit8(op=df) v0, v0, -1 (-0x1)
    0021: return v0
    0022: aget(op=45) v1, v5[v0]
    0024: cmp(op=31) v1, v1, v8
    0026: if-eqz v1, 0021
    0028: binop/lit8(op=df) v0, v0, -1 (-0x1)
    002a: goto 0021

  [Direct Method] gc() -> V
    // registers=10, ins=1, outs=0, insns_size=38
    0000: const/4 v2, 0
    0001: iget v3, v9.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0003: iget v4, v9.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0005: iget v5, v9.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0007: move(op=01) v1, v2
    0008: move(op=01) v0, v2
    0009: if-ge v1, v3, 0021
    000b: aget(op=46) v6, v5[v1]
    000d: sget v7, Landroid/support/v4/util/LongSparseArray;->DELETED:Ljava/lang/Object;
    000f: if-eq v6, v7, 001e
    0011: if-eq v1, v0, 001c
    0013: aget(op=45) v7, v4[v1]
    0015: aput(op=4c) v7, v4[v0]
    0017: aput(op=4d) v6, v5[v0]
    0019: const/4 v6, 0
    001a: aput(op=4d) v6, v5[v1]
    001c: binop/lit8(op=d8) v0, v0, 1 (0x1)
    001e: binop/lit8(op=d8) v1, v1, 1 (0x1)
    0020: goto 0009
    0021: iput v2, v9.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0023: iput v0, v9.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0025: return-void

  [Direct Method] idealByteArraySize(I) -> I
    // registers=4, ins=1, outs=0, insns_size=20
    0000: const/4 v2, 1
    0001: const/4 v0, 4
    0002: const/16 v1, 32 (0x20)
    0004: if-ge v0, v1, 0010
    0006: binop(op=98) v1, v2, v0
    0008: binop/lit8(op=d8) v1, v1, -12 (-0xc)
    000a: if-gt v3, v1, 0011
    000c: binop(op=98) v0, v2, v0
    000e: binop/lit8(op=d8) v3, v0, -12 (-0xc)
    0010: return v3
    0011: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0013: goto 0002

  [Direct Method] idealLongArraySize(I) -> I
    // registers=2, ins=1, outs=1, insns_size=9
    0000: binop/lit8(op=da) v0, v1, 8 (0x8)
    0002: invoke-static {v0}, Landroid/support/v4/util/LongSparseArray;->idealByteArraySize(I)I
    0005: move-result v0
    0006: binop/lit8(op=db) v0, v0, 8 (0x8)
    0008: return v0

  [Virtual Method] append(J, Ljava/lang/Object;) -> V
    // registers=10, ins=4, outs=5, insns_size=85
    0000: const/4 v5, 0
    0001: iget v0, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0003: if-eqz v0, 0015
    0005: iget v0, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0007: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0009: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    000b: aget(op=45) v0, v0[v1]
    000d: cmp(op=31) v0, v7, v0
    000f: if-gtz v0, 0015
    0011: invoke-virtual {v6, v7, v8, v9}, Landroid/support/v4/util/LongSparseArray;->put(JLjava/lang/Object;)V
    0014: return-void
    0015: iget v0, v6.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0017: if-eqz v0, 0023
    0019: iget v0, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    001b: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    001d: move(op=21) v1, v1
    001e: if-lt v0, v1, 0023
    0020: invoke-direct {v6}, Landroid/support/v4/util/LongSparseArray;->gc()V
    0023: iget v0, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0025: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0027: move(op=21) v1, v1
    0028: if-lt v0, v1, 0048
    002a: binop/lit8(op=d8) v1, v0, 1 (0x1)
    002c: invoke-static {v1}, Landroid/support/v4/util/LongSparseArray;->idealLongArraySize(I)I
    002f: move-result v1
    0030: new-array v2, v1, [J
    0032: new-array v1, v1, [Ljava/lang/Object;
    0034: iget v3, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0036: iget v4, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0038: move(op=21) v4, v4
    0039: invoke-static {v3, v5, v2, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    003c: iget v3, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    003e: iget v4, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0040: move(op=21) v4, v4
    0041: invoke-static {v3, v5, v1, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0044: iput v2, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0046: iput v1, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0048: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    004a: aput(op=4c) v7, v1[v0]
    004c: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    004e: aput(op=4d) v9, v1[v0]
    0050: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0052: iput v0, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0054: goto 0014

  [Virtual Method] clear() -> V
    // registers=6, ins=1, outs=0, insns_size=19
    0000: const/4 v1, 0
    0001: iget v2, v5.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0003: iget v3, v5.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0005: move(op=01) v0, v1
    0006: if-ge v0, v2, 000e
    0008: const/4 v4, 0
    0009: aput(op=4d) v4, v3[v0]
    000b: binop/lit8(op=d8) v0, v0, 1 (0x1)
    000d: goto 0006
    000e: iput v1, v5.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0010: iput v1, v5.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0012: return-void

  [Virtual Method] clone() -> Landroid/support/v4/util/LongSparseArray;
    // registers=3, ins=1, outs=1, insns_size=33
    0000: const/4 v1, 0
    0001: invoke-super {v2}, Ljava/lang/Object;->clone()Ljava/lang/Object;
    0004: move-result-object v0
    0005: check-cast v0, Landroid/support/v4/util/LongSparseArray;
    0007: iget v1, v2.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0009: invoke-virtual {v1}, [J->clone()Ljava/lang/Object;
    000c: move-result-object v1
    000d: check-cast v1, [J
    000f: iput v1, v0.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0011: iget v1, v2.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0013: invoke-virtual {v1}, [Ljava/lang/Object;->clone()Ljava/lang/Object;
    0016: move-result-object v1
    0017: check-cast v1, [Ljava/lang/Object;
    0019: iput v1, v0.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    001b: return-object v0
    001c: move-exception v0
    001d: move(op=07) v0, v1
    001e: goto 001b
    001f: move-exception v1
    0020: goto 001b

  [Virtual Method] clone() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/support/v4/util/LongSparseArray;->clone()Landroid/support/v4/util/LongSparseArray;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] delete(J) -> V
    // registers=6, ins=3, outs=5, insns_size=29
    0000: iget v0, v3.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0002: const/4 v1, 0
    0003: iget v2, v3.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0005: invoke-static {v0, v1, v2, v4, v5}, Landroid/support/v4/util/LongSparseArray;->binarySearch([JIIJ)I
    0008: move-result v0
    0009: if-ltz v0, 001c
    000b: iget v1, v3.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    000d: aget(op=46) v1, v1[v0]
    000f: sget v2, Landroid/support/v4/util/LongSparseArray;->DELETED:Ljava/lang/Object;
    0011: if-eq v1, v2, 001c
    0013: iget v1, v3.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0015: sget v2, Landroid/support/v4/util/LongSparseArray;->DELETED:Ljava/lang/Object;
    0017: aput(op=4d) v2, v1[v0]
    0019: const/4 v0, 1
    001a: iput v0, v3.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    001c: return-void

  [Virtual Method] get(J) -> Ljava/lang/Object;
    // registers=4, ins=3, outs=4, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v3, v0}, Landroid/support/v4/util/LongSparseArray;->get(JLjava/lang/Object;)Ljava/lang/Object;
    0004: move-result-object v0
    0005: return-object v0

  [Virtual Method] get(J, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=7, ins=4, outs=5, insns_size=25
    0000: iget v0, v3.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0002: const/4 v1, 0
    0003: iget v2, v3.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0005: invoke-static {v0, v1, v2, v4, v5}, Landroid/support/v4/util/LongSparseArray;->binarySearch([JIIJ)I
    0008: move-result v0
    0009: if-ltz v0, 0013
    000b: iget v1, v3.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    000d: aget(op=46) v1, v1[v0]
    000f: sget v2, Landroid/support/v4/util/LongSparseArray;->DELETED:Ljava/lang/Object;
    0011: if-ne v1, v2, 0014
    0013: return-object v6
    0014: iget v1, v3.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0016: aget(op=46) v6, v1[v0]
    0018: goto 0013

  [Virtual Method] indexOfKey(J) -> I
    // registers=6, ins=3, outs=5, insns_size=17
    0000: iget v0, v3.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v3}, Landroid/support/v4/util/LongSparseArray;->gc()V
    0007: iget v0, v3.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0009: const/4 v1, 0
    000a: iget v2, v3.Landroid/support/v4/util/LongSparseArray;->mSize:I
    000c: invoke-static {v0, v1, v2, v4, v5}, Landroid/support/v4/util/LongSparseArray;->binarySearch([JIIJ)I
    000f: move-result v0
    0010: return v0

  [Virtual Method] indexOfValue(Ljava/lang/Object;) -> I
    // registers=4, ins=2, outs=1, insns_size=24
    0000: iget v0, v2.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v2}, Landroid/support/v4/util/LongSparseArray;->gc()V
    0007: const/4 v0, 0
    0008: iget v1, v2.Landroid/support/v4/util/LongSparseArray;->mSize:I
    000a: if-ge v0, v1, 0016
    000c: iget v1, v2.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    000e: aget(op=46) v1, v1[v0]
    0010: if-ne v1, v3, 0013
    0012: return v0
    0013: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0015: goto 0008
    0016: const/4 v0, -1
    0017: goto 0012

  [Virtual Method] keyAt(I) -> J
    // registers=4, ins=2, outs=1, insns_size=12
    0000: iget v0, v2.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v2}, Landroid/support/v4/util/LongSparseArray;->gc()V
    0007: iget v0, v2.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0009: aget(op=45) v0, v0[v3]
    000b: return-wide v0

  [Virtual Method] put(J, Ljava/lang/Object;) -> V
    // registers=10, ins=4, outs=5, insns_size=147
    0000: const/4 v5, 0
    0001: iget v0, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0003: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0005: invoke-static {v0, v5, v1, v7, v8}, Landroid/support/v4/util/LongSparseArray;->binarySearch([JIIJ)I
    0008: move-result v0
    0009: if-ltz v0, 0010
    000b: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    000d: aput(op=4d) v9, v1[v0]
    000f: return-void
    0010: binop/lit8(op=df) v0, v0, -1 (-0x1)
    0012: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0014: if-ge v0, v1, 0027
    0016: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0018: aget(op=46) v1, v1[v0]
    001a: sget v2, Landroid/support/v4/util/LongSparseArray;->DELETED:Ljava/lang/Object;
    001c: if-ne v1, v2, 0027
    001e: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0020: aput(op=4c) v7, v1[v0]
    0022: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0024: aput(op=4d) v9, v1[v0]
    0026: goto 000f
    0027: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0029: if-eqz v1, 003f
    002b: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    002d: iget v2, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    002f: move(op=21) v2, v2
    0030: if-lt v1, v2, 003f
    0032: invoke-direct {v6}, Landroid/support/v4/util/LongSparseArray;->gc()V
    0035: iget v0, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0037: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0039: invoke-static {v0, v5, v1, v7, v8}, Landroid/support/v4/util/LongSparseArray;->binarySearch([JIIJ)I
    003c: move-result v0
    003d: binop/lit8(op=df) v0, v0, -1 (-0x1)
    003f: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0041: iget v2, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0043: move(op=21) v2, v2
    0044: if-lt v1, v2, 0066
    0046: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0048: binop/lit8(op=d8) v1, v1, 1 (0x1)
    004a: invoke-static {v1}, Landroid/support/v4/util/LongSparseArray;->idealLongArraySize(I)I
    004d: move-result v1
    004e: new-array v2, v1, [J
    0050: new-array v1, v1, [Ljava/lang/Object;
    0052: iget v3, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0054: iget v4, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0056: move(op=21) v4, v4
    0057: invoke-static {v3, v5, v2, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    005a: iget v3, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    005c: iget v4, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    005e: move(op=21) v4, v4
    005f: invoke-static {v3, v5, v1, v5, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0062: iput v2, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0064: iput v1, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0066: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0068: binop/2addr(op=b1) v1, v0
    0069: if-eqz v1, 0083
    006b: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    006d: iget v2, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    006f: binop/lit8(op=d8) v3, v0, 1 (0x1)
    0071: iget v4, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0073: binop/2addr(op=b1) v4, v0
    0074: invoke-static {v1, v0, v2, v3, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0077: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0079: iget v2, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    007b: binop/lit8(op=d8) v3, v0, 1 (0x1)
    007d: iget v4, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    007f: binop/2addr(op=b1) v4, v0
    0080: invoke-static {v1, v0, v2, v3, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
    0083: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mKeys:[J
    0085: aput(op=4c) v7, v1[v0]
    0087: iget v1, v6.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0089: aput(op=4d) v9, v1[v0]
    008b: iget v0, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    008d: binop/lit8(op=d8) v0, v0, 1 (0x1)
    008f: iput v0, v6.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0091: goto/16 000f

  [Virtual Method] remove(J) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-virtual {v0, v1, v2}, Landroid/support/v4/util/LongSparseArray;->delete(J)V
    0003: return-void

  [Virtual Method] removeAt(I) -> V
    // registers=4, ins=2, outs=0, insns_size=18
    0000: iget v0, v2.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0002: aget(op=46) v0, v0[v3]
    0004: sget v1, Landroid/support/v4/util/LongSparseArray;->DELETED:Ljava/lang/Object;
    0006: if-eq v0, v1, 0011
    0008: iget v0, v2.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    000a: sget v1, Landroid/support/v4/util/LongSparseArray;->DELETED:Ljava/lang/Object;
    000c: aput(op=4d) v1, v0[v3]
    000e: const/4 v0, 1
    000f: iput v0, v2.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0011: return-void

  [Virtual Method] setValueAt(I, Ljava/lang/Object;) -> V
    // registers=4, ins=3, outs=1, insns_size=12
    0000: iget v0, v1.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v1}, Landroid/support/v4/util/LongSparseArray;->gc()V
    0007: iget v0, v1.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0009: aput(op=4d) v3, v0[v2]
    000b: return-void

  [Virtual Method] size() -> I
    // registers=2, ins=1, outs=1, insns_size=10
    0000: iget v0, v1.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v1}, Landroid/support/v4/util/LongSparseArray;->gc()V
    0007: iget v0, v1.Landroid/support/v4/util/LongSparseArray;->mSize:I
    0009: return v0

  [Virtual Method] valueAt(I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=1, insns_size=12
    0000: iget v0, v1.Landroid/support/v4/util/LongSparseArray;->mGarbage:Z
    0002: if-eqz v0, 0007
    0004: invoke-direct {v1}, Landroid/support/v4/util/LongSparseArray;->gc()V
    0007: iget v0, v1.Landroid/support/v4/util/LongSparseArray;->mValues:[Ljava/lang/Object;
    0009: aget(op=46) v0, v0[v2]
    000b: return-object v0