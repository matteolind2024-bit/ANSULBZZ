=== CLASS Landroid/support/v4/app/ShareCompat$ShareCompatImpl; (Source: ShareCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] configureMenuItem(Landroid/view/MenuItem;, Landroid/support/v4/app/ShareCompat$IntentBuilder;) -> V

  [Virtual Method] escapeHtml(Ljava/lang/CharSequence;) -> Ljava/lang/String;