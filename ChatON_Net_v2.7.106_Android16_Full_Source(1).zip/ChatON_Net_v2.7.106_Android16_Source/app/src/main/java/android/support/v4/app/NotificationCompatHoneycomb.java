=== CLASS Landroid/support/v4/app/NotificationCompatHoneycomb; (Source: NotificationCompatHoneycomb.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] add(Landroid/content/Context;, Landroid/app/Notification;, Ljava/lang/CharSequence;, Ljava/lang/CharSequence;, Ljava/lang/CharSequence;, Landroid/widget/RemoteViews;, I, Landroid/app/PendingIntent;, Landroid/app/PendingIntent;, Landroid/graphics/Bitmap;) -> Landroid/app/Notification;
    // registers=16, ins=10, outs=4, insns_size=149
    0000: const/4 v1, 1
    0001: const/4 v2, 0
    0002: new-instance v0, Landroid/app/Notification$Builder;
    0004: invoke-direct {v0, v6}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V
    0007: iget v3, v7.Landroid/app/Notification;->when:J
    0009: invoke-virtual {v0, v3, v4}, Landroid/app/Notification$Builder;->setWhen(J)Landroid/app/Notification$Builder;
    000c: move-result-object v0
    000d: iget v3, v7.Landroid/app/Notification;->icon:I
    000f: iget v4, v7.Landroid/app/Notification;->iconLevel:I
    0011: invoke-virtual {v0, v3, v4}, Landroid/app/Notification$Builder;->setSmallIcon(II)Landroid/app/Notification$Builder;
    0014: move-result-object v0
    0015: iget v3, v7.Landroid/app/Notification;->contentView:Landroid/widget/RemoteViews;
    0017: invoke-virtual {v0, v3}, Landroid/app/Notification$Builder;->setContent(Landroid/widget/RemoteViews;)Landroid/app/Notification$Builder;
    001a: move-result-object v0
    001b: iget v3, v7.Landroid/app/Notification;->tickerText:Ljava/lang/CharSequence;
    001d: invoke-virtual {v0, v3, v11}, Landroid/app/Notification$Builder;->setTicker(Ljava/lang/CharSequence;Landroid/widget/RemoteViews;)Landroid/app/Notification$Builder;
    0020: move-result-object v0
    0021: iget v3, v7.Landroid/app/Notification;->sound:Landroid/net/Uri;
    0023: iget v4, v7.Landroid/app/Notification;->audioStreamType:I
    0025: invoke-virtual {v0, v3, v4}, Landroid/app/Notification$Builder;->setSound(Landroid/net/Uri;I)Landroid/app/Notification$Builder;
    0028: move-result-object v0
    0029: iget v3, v7.Landroid/app/Notification;->vibrate:[J
    002b: invoke-virtual {v0, v3}, Landroid/app/Notification$Builder;->setVibrate([J)Landroid/app/Notification$Builder;
    002e: move-result-object v0
    002f: iget v3, v7.Landroid/app/Notification;->ledARGB:I
    0031: iget v4, v7.Landroid/app/Notification;->ledOnMS:I
    0033: iget v5, v7.Landroid/app/Notification;->ledOffMS:I
    0035: invoke-virtual {v0, v3, v4, v5}, Landroid/app/Notification$Builder;->setLights(III)Landroid/app/Notification$Builder;
    0038: move-result-object v3
    0039: iget v0, v7.Landroid/app/Notification;->flags:I
    003b: binop/lit8(op=dd) v0, v0, 2 (0x2)
    003d: if-eqz v0, 008d
    003f: move(op=01) v0, v1
    0040: invoke-virtual {v3, v0}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;
    0043: move-result-object v3
    0044: iget v0, v7.Landroid/app/Notification;->flags:I
    0046: binop/lit8(op=dd) v0, v0, 8 (0x8)
    0048: if-eqz v0, 008f
    004a: move(op=01) v0, v1
    004b: invoke-virtual {v3, v0}, Landroid/app/Notification$Builder;->setOnlyAlertOnce(Z)Landroid/app/Notification$Builder;
    004e: move-result-object v3
    004f: iget v0, v7.Landroid/app/Notification;->flags:I
    0051: binop/lit8(op=dd) v0, v0, 16 (0x10)
    0053: if-eqz v0, 0091
    0055: move(op=01) v0, v1
    0056: invoke-virtual {v3, v0}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;
    0059: move-result-object v0
    005a: iget v3, v7.Landroid/app/Notification;->defaults:I
    005c: invoke-virtual {v0, v3}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;
    005f: move-result-object v0
    0060: invoke-virtual {v0, v8}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;
    0063: move-result-object v0
    0064: invoke-virtual {v0, v9}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;
    0067: move-result-object v0
    0068: invoke-virtual {v0, v10}, Landroid/app/Notification$Builder;->setContentInfo(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;
    006b: move-result-object v0
    006c: invoke-virtual {v0, v13}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;
    006f: move-result-object v0
    0070: iget v3, v7.Landroid/app/Notification;->deleteIntent:Landroid/app/PendingIntent;
    0072: invoke-virtual {v0, v3}, Landroid/app/Notification$Builder;->setDeleteIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;
    0075: move-result-object v0
    0076: iget v3, v7.Landroid/app/Notification;->flags:I
    0078: binop/lit16(op=d5) v3, v3, 128 (0x80)
    007a: if-eqz v3, 0093
    007c: invoke-virtual {v0, v14, v1}, Landroid/app/Notification$Builder;->setFullScreenIntent(Landroid/app/PendingIntent;Z)Landroid/app/Notification$Builder;
    007f: move-result-object v0
    0080: invoke-virtual {v0, v15}, Landroid/app/Notification$Builder;->setLargeIcon(Landroid/graphics/Bitmap;)Landroid/app/Notification$Builder;
    0083: move-result-object v0
    0084: invoke-virtual {v0, v12}, Landroid/app/Notification$Builder;->setNumber(I)Landroid/app/Notification$Builder;
    0087: move-result-object v0
    0088: invoke-virtual {v0}, Landroid/app/Notification$Builder;->getNotification()Landroid/app/Notification;
    008b: move-result-object v0
    008c: return-object v0
    008d: move(op=01) v0, v2
    008e: goto 0040
    008f: move(op=01) v0, v2
    0090: goto 004b
    0091: move(op=01) v0, v2
    0092: goto 0056
    0093: move(op=01) v1, v2
    0094: goto 007c