=== CLASS Landroid/support/v4/widget/CursorAdapter$ChangeObserver; (Source: CursorAdapter.java) ===
  Super: Landroid/database/ContentObserver;
  [Instance Field] this$0: Landroid/support/v4/widget/CursorAdapter;

  [Direct Method] <init>(Landroid/support/v4/widget/CursorAdapter;) -> V
    // registers=3, ins=2, outs=2, insns_size=11
    0000: iput v2, v1.Landroid/support/v4/widget/CursorAdapter$ChangeObserver;->this$0:Landroid/support/v4/widget/CursorAdapter;
    0002: new-instance v0, Landroid/os/Handler;
    0004: invoke-direct {v0}, Landroid/os/Handler;-><init>()V
    0007: invoke-direct {v1, v0}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V
    000a: return-void

  [Virtual Method] deliverSelfNotifications() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Virtual Method] onChange(Z) -> V
    // registers=3, ins=2, outs=1, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/widget/CursorAdapter$ChangeObserver;->this$0:Landroid/support/v4/widget/CursorAdapter;
    0002: invoke-virtual {v0}, Landroid/support/v4/widget/CursorAdapter;->onContentChanged()V
    0005: return-void