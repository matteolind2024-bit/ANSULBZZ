=== CLASS Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventStubImpl; (Source: AccessibilityEventCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] appendRecord(Landroid/view/accessibility/AccessibilityEvent;, Ljava/lang/Object;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] getRecord(Landroid/view/accessibility/AccessibilityEvent;, I) -> Ljava/lang/Object;
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getRecordCount(Landroid/view/accessibility/AccessibilityEvent;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0