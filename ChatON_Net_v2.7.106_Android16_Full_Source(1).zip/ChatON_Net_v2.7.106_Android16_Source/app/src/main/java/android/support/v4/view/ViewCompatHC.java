=== CLASS Landroid/support/v4/view/ViewCompatHC; (Source: ViewCompatHC.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getFrameTime() -> J
    // registers=2, ins=0, outs=0, insns_size=5
    0000: invoke-static {}, Landroid/animation/ValueAnimator;->getFrameDelay()J
    0003: move-result-wide v0
    0004: return-wide v0