=== CLASS Landroid/support/v4/app/Fragment$SavedState; (Source: Fragment.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/Parcelable;
  [Static Field] CREATOR: Landroid/os/Parcelable$Creator;
  [Instance Field] mState: Landroid/os/Bundle;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=8
    0000: new-instance v0, Landroid/support/v4/app/Fragment$SavedState$1;
    0002: invoke-direct {v0}, Landroid/support/v4/app/Fragment$SavedState$1;-><init>()V
    0005: sput v0, Landroid/support/v4/app/Fragment$SavedState;->CREATOR:Landroid/os/Parcelable$Creator;
    0007: return-void

  [Direct Method] <init>(Landroid/os/Bundle;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Landroid/support/v4/app/Fragment$SavedState;->mState:Landroid/os/Bundle;
    0005: return-void

  [Direct Method] <init>(Landroid/os/Parcel;, Ljava/lang/ClassLoader;) -> V
    // registers=4, ins=3, outs=2, insns_size=21
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: invoke-virtual {v2}, Landroid/os/Parcel;->readBundle()Landroid/os/Bundle;
    0006: move-result-object v0
    0007: iput v0, v1.Landroid/support/v4/app/Fragment$SavedState;->mState:Landroid/os/Bundle;
    0009: if-eqz v3, 0014
    000b: iget v0, v1.Landroid/support/v4/app/Fragment$SavedState;->mState:Landroid/os/Bundle;
    000d: if-eqz v0, 0014
    000f: iget v0, v1.Landroid/support/v4/app/Fragment$SavedState;->mState:Landroid/os/Bundle;
    0011: invoke-virtual {v0, v3}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V
    0014: return-void

  [Virtual Method] describeContents() -> I
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] writeToParcel(Landroid/os/Parcel;, I) -> V
    // registers=4, ins=3, outs=2, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/app/Fragment$SavedState;->mState:Landroid/os/Bundle;
    0002: invoke-virtual {v2, v0}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V
    0005: return-void