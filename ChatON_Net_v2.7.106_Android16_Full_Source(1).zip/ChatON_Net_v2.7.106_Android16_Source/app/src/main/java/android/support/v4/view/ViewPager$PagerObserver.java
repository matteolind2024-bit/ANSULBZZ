=== CLASS Landroid/support/v4/view/ViewPager$PagerObserver; (Source: ViewPager.java) ===
  Super: Landroid/database/DataSetObserver;
  [Instance Field] this$0: Landroid/support/v4/view/ViewPager;

  [Direct Method] <init>(Landroid/support/v4/view/ViewPager;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/view/ViewPager$PagerObserver;->this$0:Landroid/support/v4/view/ViewPager;
    0002: invoke-direct {v0}, Landroid/database/DataSetObserver;-><init>()V
    0005: return-void

  [Direct Method] <init>(Landroid/support/v4/view/ViewPager;, Landroid/support/v4/view/ViewPager$1;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Landroid/support/v4/view/ViewPager$PagerObserver;-><init>(Landroid/support/v4/view/ViewPager;)V
    0003: return-void

  [Virtual Method] onChanged() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager$PagerObserver;->this$0:Landroid/support/v4/view/ViewPager;
    0002: invoke-virtual {v0}, Landroid/support/v4/view/ViewPager;->dataSetChanged()V
    0005: return-void

  [Virtual Method] onInvalidated() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager$PagerObserver;->this$0:Landroid/support/v4/view/ViewPager;
    0002: invoke-virtual {v0}, Landroid/support/v4/view/ViewPager;->dataSetChanged()V
    0005: return-void