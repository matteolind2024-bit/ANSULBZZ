=== CLASS Landroid/support/v4/content/ModernAsyncTask$Status; (Source: ModernAsyncTask.java) ===
  Super: Ljava/lang/Enum;
  [Static Field] $VALUES: [Landroid/support/v4/content/ModernAsyncTask$Status;
  [Static Field] FINISHED: Landroid/support/v4/content/ModernAsyncTask$Status;
  [Static Field] PENDING: Landroid/support/v4/content/ModernAsyncTask$Status;
  [Static Field] RUNNING: Landroid/support/v4/content/ModernAsyncTask$Status;

  [Direct Method] <clinit>() -> V
    // registers=5, ins=0, outs=3, insns_size=48
    0000: const/4 v4, 2
    0001: const/4 v3, 1
    0002: const/4 v2, 0
    0003: new-instance v0, Landroid/support/v4/content/ModernAsyncTask$Status;
    0005: const-string v1, 'PENDING'
    0007: invoke-direct {v0, v1, v2}, Landroid/support/v4/content/ModernAsyncTask$Status;-><init>(Ljava/lang/String;I)V
    000a: sput v0, Landroid/support/v4/content/ModernAsyncTask$Status;->PENDING:Landroid/support/v4/content/ModernAsyncTask$Status;
    000c: new-instance v0, Landroid/support/v4/content/ModernAsyncTask$Status;
    000e: const-string v1, 'RUNNING'
    0010: invoke-direct {v0, v1, v3}, Landroid/support/v4/content/ModernAsyncTask$Status;-><init>(Ljava/lang/String;I)V
    0013: sput v0, Landroid/support/v4/content/ModernAsyncTask$Status;->RUNNING:Landroid/support/v4/content/ModernAsyncTask$Status;
    0015: new-instance v0, Landroid/support/v4/content/ModernAsyncTask$Status;
    0017: const-string v1, 'FINISHED'
    0019: invoke-direct {v0, v1, v4}, Landroid/support/v4/content/ModernAsyncTask$Status;-><init>(Ljava/lang/String;I)V
    001c: sput v0, Landroid/support/v4/content/ModernAsyncTask$Status;->FINISHED:Landroid/support/v4/content/ModernAsyncTask$Status;
    001e: const/4 v0, 3
    001f: new-array v0, v0, [Landroid/support/v4/content/ModernAsyncTask$Status;
    0021: sget v1, Landroid/support/v4/content/ModernAsyncTask$Status;->PENDING:Landroid/support/v4/content/ModernAsyncTask$Status;
    0023: aput(op=4d) v1, v0[v2]
    0025: sget v1, Landroid/support/v4/content/ModernAsyncTask$Status;->RUNNING:Landroid/support/v4/content/ModernAsyncTask$Status;
    0027: aput(op=4d) v1, v0[v3]
    0029: sget v1, Landroid/support/v4/content/ModernAsyncTask$Status;->FINISHED:Landroid/support/v4/content/ModernAsyncTask$Status;
    002b: aput(op=4d) v1, v0[v4]
    002d: sput v0, Landroid/support/v4/content/ModernAsyncTask$Status;->$VALUES:[Landroid/support/v4/content/ModernAsyncTask$Status;
    002f: return-void

  [Direct Method] <init>(Ljava/lang/String;, I) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    0003: return-void

  [Direct Method] valueOf(Ljava/lang/String;) -> Landroid/support/v4/content/ModernAsyncTask$Status;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: const-class v0, Landroid/support/v4/content/ModernAsyncTask$Status;
    0002: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/support/v4/content/ModernAsyncTask$Status;
    0008: return-object v0

  [Direct Method] values() -> [Landroid/support/v4/content/ModernAsyncTask$Status;
    // registers=1, ins=0, outs=1, insns_size=9
    0000: sget v0, Landroid/support/v4/content/ModernAsyncTask$Status;->$VALUES:[Landroid/support/v4/content/ModernAsyncTask$Status;
    0002: invoke-virtual {v0}, [Landroid/support/v4/content/ModernAsyncTask$Status;->clone()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, [Landroid/support/v4/content/ModernAsyncTask$Status;
    0008: return-object v0