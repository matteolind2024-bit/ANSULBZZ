=== CLASS Landroid/support/v4/view/ViewCompat$JBViewCompatImpl; (Source: ViewCompat.java) ===
  Super: Landroid/support/v4/view/ViewCompat$ICSViewCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/view/ViewCompat$ICSViewCompatImpl;-><init>()V
    0003: return-void

  [Virtual Method] getAccessibilityNodeProvider(Landroid/view/View;) -> Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    // registers=4, ins=2, outs=2, insns_size=14
    0000: invoke-static {v3}, Landroid/support/v4/view/ViewCompatJB;->getAccessibilityNodeProvider(Landroid/view/View;)Ljava/lang/Object;
    0003: move-result-object v1
    0004: if-eqz v1, 000c
    0006: new-instance v0, Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    0008: invoke-direct {v0, v1}, Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;-><init>(Ljava/lang/Object;)V
    000b: return-object v0
    000c: const/4 v0, 0
    000d: goto 000b

  [Virtual Method] getImportantForAccessibility(Landroid/view/View;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/ViewCompatJB;->getImportantForAccessibility(Landroid/view/View;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] hasTransientState(Landroid/view/View;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/ViewCompatJB;->hasTransientState(Landroid/view/View;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] postInvalidateOnAnimation(Landroid/view/View;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-static {v1}, Landroid/support/v4/view/ViewCompatJB;->postInvalidateOnAnimation(Landroid/view/View;)V
    0003: return-void

  [Virtual Method] postInvalidateOnAnimation(Landroid/view/View;, I, I, I, I) -> V
    // registers=6, ins=6, outs=5, insns_size=4
    0000: invoke-static {v1, v2, v3, v4, v5}, Landroid/support/v4/view/ViewCompatJB;->postInvalidateOnAnimation(Landroid/view/View;IIII)V
    0003: return-void

  [Virtual Method] postOnAnimation(Landroid/view/View;, Ljava/lang/Runnable;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/ViewCompatJB;->postOnAnimation(Landroid/view/View;Ljava/lang/Runnable;)V
    0003: return-void

  [Virtual Method] postOnAnimationDelayed(Landroid/view/View;, Ljava/lang/Runnable;, J) -> V
    // registers=5, ins=5, outs=4, insns_size=4
    0000: invoke-static {v1, v2, v3, v4}, Landroid/support/v4/view/ViewCompatJB;->postOnAnimationDelayed(Landroid/view/View;Ljava/lang/Runnable;J)V
    0003: return-void

  [Virtual Method] setHasTransientState(Landroid/view/View;, Z) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/ViewCompatJB;->setHasTransientState(Landroid/view/View;Z)V
    0003: return-void

  [Virtual Method] setImportantForAccessibility(Landroid/view/View;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/ViewCompatJB;->setImportantForAccessibility(Landroid/view/View;I)V
    0003: return-void