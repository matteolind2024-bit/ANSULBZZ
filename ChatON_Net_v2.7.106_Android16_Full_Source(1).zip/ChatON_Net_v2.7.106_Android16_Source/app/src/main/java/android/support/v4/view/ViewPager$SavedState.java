=== CLASS Landroid/support/v4/view/ViewPager$SavedState; (Source: ViewPager.java) ===
  Super: Landroid/view/View$BaseSavedState;
  [Static Field] CREATOR: Landroid/os/Parcelable$Creator;
  [Instance Field] adapterState: Landroid/os/Parcelable;
  [Instance Field] loader: Ljava/lang/ClassLoader;
  [Instance Field] position: I

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=12
    0000: new-instance v0, Landroid/support/v4/view/ViewPager$SavedState$1;
    0002: invoke-direct {v0}, Landroid/support/v4/view/ViewPager$SavedState$1;-><init>()V
    0005: invoke-static {v0}, Landroid/support/v4/os/ParcelableCompat;->newCreator(Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;)Landroid/os/Parcelable$Creator;
    0008: move-result-object v0
    0009: sput v0, Landroid/support/v4/view/ViewPager$SavedState;->CREATOR:Landroid/os/Parcelable$Creator;
    000b: return-void

  [Direct Method] <init>(Landroid/os/Parcel;, Ljava/lang/ClassLoader;) -> V
    // registers=4, ins=3, outs=2, insns_size=28
    0000: invoke-direct {v1, v2}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V
    0003: if-nez v3, 000d
    0005: invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0008: move-result-object v0
    0009: invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;
    000c: move-result-object v3
    000d: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    0010: move-result v0
    0011: iput v0, v1.Landroid/support/v4/view/ViewPager$SavedState;->position:I
    0013: invoke-virtual {v2, v3}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;
    0016: move-result-object v0
    0017: iput v0, v1.Landroid/support/v4/view/ViewPager$SavedState;->adapterState:Landroid/os/Parcelable;
    0019: iput v3, v1.Landroid/support/v4/view/ViewPager$SavedState;->loader:Ljava/lang/ClassLoader;
    001b: return-void

  [Direct Method] <init>(Landroid/os/Parcelable;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcelable;)V
    0003: return-void

  [Virtual Method] toString() -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=46
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0005: const-string v1, 'FragmentPager.SavedState{'
    0007: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000a: move-result-object v0
    000b: invoke-static {v2}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I
    000e: move-result v1
    000f: invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0012: move-result-object v1
    0013: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0016: move-result-object v0
    0017: const-string v1, ' position='
    0019: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: move-result-object v0
    001d: iget v1, v2.Landroid/support/v4/view/ViewPager$SavedState;->position:I
    001f: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0022: move-result-object v0
    0023: const-string v1, '}'
    0025: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0028: move-result-object v0
    0029: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002c: move-result-object v0
    002d: return-object v0

  [Virtual Method] writeToParcel(Landroid/os/Parcel;, I) -> V
    // registers=4, ins=3, outs=3, insns_size=14
    0000: invoke-super {v1, v2, v3}, Landroid/view/View$BaseSavedState;->writeToParcel(Landroid/os/Parcel;I)V
    0003: iget v0, v1.Landroid/support/v4/view/ViewPager$SavedState;->position:I
    0005: invoke-virtual {v2, v0}, Landroid/os/Parcel;->writeInt(I)V
    0008: iget v0, v1.Landroid/support/v4/view/ViewPager$SavedState;->adapterState:Landroid/os/Parcelable;
    000a: invoke-virtual {v2, v0, v3}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V
    000d: return-void