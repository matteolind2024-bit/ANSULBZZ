=== CLASS Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoIcsImpl; (Source: AccessibilityServiceInfoCompat.java) ===
  Super: Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompat$AccessibilityServiceInfoStubImpl;-><init>()V
    0003: return-void

  [Virtual Method] getCanRetrieveWindowContent(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompatIcs;->getCanRetrieveWindowContent(Landroid/accessibilityservice/AccessibilityServiceInfo;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] getDescription(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompatIcs;->getDescription(Landroid/accessibilityservice/AccessibilityServiceInfo;)Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getId(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompatIcs;->getId(Landroid/accessibilityservice/AccessibilityServiceInfo;)Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getResolveInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Landroid/content/pm/ResolveInfo;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompatIcs;->getResolveInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;)Landroid/content/pm/ResolveInfo;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getSettingsActivityName(Landroid/accessibilityservice/AccessibilityServiceInfo;) -> Ljava/lang/String;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/accessibilityservice/AccessibilityServiceInfoCompatIcs;->getSettingsActivityName(Landroid/accessibilityservice/AccessibilityServiceInfo;)Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0