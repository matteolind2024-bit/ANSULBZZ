=== CLASS Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean; (Source: AccessibilityNodeInfoCompatJellyBean.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] addChild(Ljava/lang/Object;, Landroid/view/View;, I) -> V
    // registers=3, ins=3, outs=3, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v0, v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V
    0005: return-void

  [Direct Method] findFocus(Ljava/lang/Object;, I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->findFocus(I)Landroid/view/accessibility/AccessibilityNodeInfo;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] focusSearch(Ljava/lang/Object;, I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->focusSearch(I)Landroid/view/accessibility/AccessibilityNodeInfo;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getMovementGranularities(Ljava/lang/Object;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getMovementGranularities()I
    0005: move-result v0
    0006: return v0

  [Direct Method] isAccessibilityFocused(Ljava/lang/Object;) -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->isAccessibilityFocused()Z
    0005: move-result v0
    0006: return v0

  [Direct Method] isVisibleToUser(Ljava/lang/Object;) -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z
    0005: move-result v0
    0006: return v0

  [Direct Method] obtain(Landroid/view/View;, I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-static {v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->obtain(Landroid/view/View;I)Landroid/view/accessibility/AccessibilityNodeInfo;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] performAction(Ljava/lang/Object;, I, Landroid/os/Bundle;) -> Z
    // registers=4, ins=3, outs=3, insns_size=7
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v1, v2, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(ILandroid/os/Bundle;)Z
    0005: move-result v0
    0006: return v0

  [Direct Method] setAccesibilityFocused(Ljava/lang/Object;, Z) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setAccessibilityFocused(Z)V
    0005: return-void

  [Direct Method] setMovementGranularities(Ljava/lang/Object;, I) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setMovementGranularities(I)V
    0005: return-void

  [Direct Method] setParent(Ljava/lang/Object;, Landroid/view/View;, I) -> V
    // registers=3, ins=3, outs=3, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v0, v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->setParent(Landroid/view/View;I)V
    0005: return-void

  [Direct Method] setSource(Ljava/lang/Object;, Landroid/view/View;, I) -> V
    // registers=3, ins=3, outs=3, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v0, v1, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->setSource(Landroid/view/View;I)V
    0005: return-void

  [Direct Method] setVisibleToUser(Ljava/lang/Object;, Z) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v0, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setVisibleToUser(Z)V
    0005: return-void