=== CLASS Landroid/support/v4/view/PagerTitleStrip$PageListener; (Source: PagerTitleStrip.java) ===
  Super: Landroid/database/DataSetObserver;
  Interfaces: Landroid/support/v4/view/ViewPager$OnAdapterChangeListener;, Landroid/support/v4/view/ViewPager$OnPageChangeListener;
  [Instance Field] mScrollState: I
  [Instance Field] this$0: Landroid/support/v4/view/PagerTitleStrip;

  [Direct Method] <init>(Landroid/support/v4/view/PagerTitleStrip;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/view/PagerTitleStrip$PageListener;->this$0:Landroid/support/v4/view/PagerTitleStrip;
    0002: invoke-direct {v0}, Landroid/database/DataSetObserver;-><init>()V
    0005: return-void

  [Direct Method] <init>(Landroid/support/v4/view/PagerTitleStrip;, Landroid/support/v4/view/PagerTitleStrip$1;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Landroid/support/v4/view/PagerTitleStrip$PageListener;-><init>(Landroid/support/v4/view/PagerTitleStrip;)V
    0003: return-void

  [Virtual Method] onAdapterChanged(Landroid/support/v4/view/PagerAdapter;, Landroid/support/v4/view/PagerAdapter;) -> V
    // registers=4, ins=3, outs=3, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/view/PagerTitleStrip$PageListener;->this$0:Landroid/support/v4/view/PagerTitleStrip;
    0002: invoke-virtual {v0, v2, v3}, Landroid/support/v4/view/PagerTitleStrip;->updateAdapter(Landroid/support/v4/view/PagerAdapter;Landroid/support/v4/view/PagerAdapter;)V
    0005: return-void

  [Virtual Method] onChanged() -> V
    // registers=4, ins=1, outs=3, insns_size=22
    0000: iget v0, v3.Landroid/support/v4/view/PagerTitleStrip$PageListener;->this$0:Landroid/support/v4/view/PagerTitleStrip;
    0002: iget v1, v3.Landroid/support/v4/view/PagerTitleStrip$PageListener;->this$0:Landroid/support/v4/view/PagerTitleStrip;
    0004: iget v1, v1.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0006: invoke-virtual {v1}, Landroid/support/v4/view/ViewPager;->getCurrentItem()I
    0009: move-result v1
    000a: iget v2, v3.Landroid/support/v4/view/PagerTitleStrip$PageListener;->this$0:Landroid/support/v4/view/PagerTitleStrip;
    000c: iget v2, v2.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    000e: invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->getAdapter()Landroid/support/v4/view/PagerAdapter;
    0011: move-result-object v2
    0012: invoke-virtual {v0, v1, v2}, Landroid/support/v4/view/PagerTitleStrip;->updateText(ILandroid/support/v4/view/PagerAdapter;)V
    0015: return-void

  [Virtual Method] onPageScrollStateChanged(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/view/PagerTitleStrip$PageListener;->mScrollState:I
    0002: return-void

  [Virtual Method] onPageScrolled(I, F, I) -> V
    // registers=6, ins=4, outs=4, insns_size=15
    0000: const/high16 v0, 1056964608 (0x3f000000)
    0002: cmp(op=2d) v0, v4, v0
    0004: if-lez v0, 0008
    0006: binop/lit8(op=d8) v3, v3, 1 (0x1)
    0008: iget v0, v2.Landroid/support/v4/view/PagerTitleStrip$PageListener;->this$0:Landroid/support/v4/view/PagerTitleStrip;
    000a: const/4 v1, 0
    000b: invoke-virtual {v0, v3, v4, v1}, Landroid/support/v4/view/PagerTitleStrip;->updateTextPositions(IFZ)V
    000e: return-void

  [Virtual Method] onPageSelected(I) -> V
    // registers=5, ins=2, outs=3, insns_size=26
    0000: iget v0, v3.Landroid/support/v4/view/PagerTitleStrip$PageListener;->mScrollState:I
    0002: if-nez v0, 0019
    0004: iget v0, v3.Landroid/support/v4/view/PagerTitleStrip$PageListener;->this$0:Landroid/support/v4/view/PagerTitleStrip;
    0006: iget v1, v3.Landroid/support/v4/view/PagerTitleStrip$PageListener;->this$0:Landroid/support/v4/view/PagerTitleStrip;
    0008: iget v1, v1.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    000a: invoke-virtual {v1}, Landroid/support/v4/view/ViewPager;->getCurrentItem()I
    000d: move-result v1
    000e: iget v2, v3.Landroid/support/v4/view/PagerTitleStrip$PageListener;->this$0:Landroid/support/v4/view/PagerTitleStrip;
    0010: iget v2, v2.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0012: invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->getAdapter()Landroid/support/v4/view/PagerAdapter;
    0015: move-result-object v2
    0016: invoke-virtual {v0, v1, v2}, Landroid/support/v4/view/PagerTitleStrip;->updateText(ILandroid/support/v4/view/PagerAdapter;)V
    0019: return-void