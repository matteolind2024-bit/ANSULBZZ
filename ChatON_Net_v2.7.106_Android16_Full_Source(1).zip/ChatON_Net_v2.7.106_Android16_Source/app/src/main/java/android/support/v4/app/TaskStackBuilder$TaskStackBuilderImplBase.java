=== CLASS Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImplBase; (Source: TaskStackBuilder.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getPendingIntent(Landroid/content/Context;, [Landroid/content/Intent;, I, I, Landroid/os/Bundle;) -> Landroid/app/PendingIntent;
    // registers=8, ins=6, outs=4, insns_size=15
    0000: move(op=21) v0, v4
    0001: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0003: aget(op=46) v0, v4[v0]
    0005: const/high16 v1, 268435456 (0x10000000)
    0007: invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    000a: invoke-static {v3, v5, v0, v6}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;
    000d: move-result-object v0
    000e: return-object v0