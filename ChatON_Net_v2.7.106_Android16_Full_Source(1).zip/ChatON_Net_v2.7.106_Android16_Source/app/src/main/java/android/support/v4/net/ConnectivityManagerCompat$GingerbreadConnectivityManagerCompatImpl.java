=== CLASS Landroid/support/v4/net/ConnectivityManagerCompat$GingerbreadConnectivityManagerCompatImpl; (Source: ConnectivityManagerCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/net/ConnectivityManagerCompat$ConnectivityManagerCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] isActiveNetworkMetered(Landroid/net/ConnectivityManager;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/net/ConnectivityManagerCompatGingerbread;->isActiveNetworkMetered(Landroid/net/ConnectivityManager;)Z
    0003: move-result v0
    0004: return v0