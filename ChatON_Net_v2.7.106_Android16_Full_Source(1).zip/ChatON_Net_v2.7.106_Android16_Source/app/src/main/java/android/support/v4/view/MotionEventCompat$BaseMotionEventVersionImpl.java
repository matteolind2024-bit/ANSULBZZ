=== CLASS Landroid/support/v4/view/MotionEventCompat$BaseMotionEventVersionImpl; (Source: MotionEventCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] findPointerIndex(Landroid/view/MotionEvent;, I) -> I
    // registers=4, ins=3, outs=0, insns_size=6
    0000: if-nez v3, 0004
    0002: const/4 v0, 0
    0003: return v0
    0004: const/4 v0, -1
    0005: goto 0003

  [Virtual Method] getPointerId(Landroid/view/MotionEvent;, I) -> I
    // registers=5, ins=3, outs=2, insns_size=12
    0000: if-nez v4, 0004
    0002: const/4 v0, 0
    0003: return v0
    0004: new-instance v0, Ljava/lang/IndexOutOfBoundsException;
    0006: const-string v1, 'Pre-Eclair does not support multiple pointers'
    0008: invoke-direct {v0, v1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    000b: throw v0

  [Virtual Method] getX(Landroid/view/MotionEvent;, I) -> F
    // registers=5, ins=3, outs=2, insns_size=15
    0000: if-nez v4, 0007
    0002: invoke-virtual {v3}, Landroid/view/MotionEvent;->getX()F
    0005: move-result v0
    0006: return v0
    0007: new-instance v0, Ljava/lang/IndexOutOfBoundsException;
    0009: const-string v1, 'Pre-Eclair does not support multiple pointers'
    000b: invoke-direct {v0, v1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    000e: throw v0

  [Virtual Method] getY(Landroid/view/MotionEvent;, I) -> F
    // registers=5, ins=3, outs=2, insns_size=15
    0000: if-nez v4, 0007
    0002: invoke-virtual {v3}, Landroid/view/MotionEvent;->getY()F
    0005: move-result v0
    0006: return v0
    0007: new-instance v0, Ljava/lang/IndexOutOfBoundsException;
    0009: const-string v1, 'Pre-Eclair does not support multiple pointers'
    000b: invoke-direct {v0, v1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V
    000e: throw v0