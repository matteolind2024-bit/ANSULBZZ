=== CLASS Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectIcsImpl; (Source: EdgeEffectCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] draw(Ljava/lang/Object;, Landroid/graphics/Canvas;) -> Z
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/widget/EdgeEffectCompatIcs;->draw(Ljava/lang/Object;Landroid/graphics/Canvas;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] finish(Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-static {v1}, Landroid/support/v4/widget/EdgeEffectCompatIcs;->finish(Ljava/lang/Object;)V
    0003: return-void

  [Virtual Method] isFinished(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/widget/EdgeEffectCompatIcs;->isFinished(Ljava/lang/Object;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] newEdgeEffect(Landroid/content/Context;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/widget/EdgeEffectCompatIcs;->newEdgeEffect(Landroid/content/Context;)Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] onAbsorb(Ljava/lang/Object;, I) -> Z
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/widget/EdgeEffectCompatIcs;->onAbsorb(Ljava/lang/Object;I)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] onPull(Ljava/lang/Object;, F) -> Z
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/widget/EdgeEffectCompatIcs;->onPull(Ljava/lang/Object;F)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] onRelease(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/widget/EdgeEffectCompatIcs;->onRelease(Ljava/lang/Object;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] setSize(Ljava/lang/Object;, I, I) -> V
    // registers=4, ins=4, outs=3, insns_size=4
    0000: invoke-static {v1, v2, v3}, Landroid/support/v4/widget/EdgeEffectCompatIcs;->setSize(Ljava/lang/Object;II)V
    0003: return-void