=== CLASS Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventIcsImpl; (Source: AccessibilityEventCompat.java) ===
  Super: Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventStubImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventStubImpl;-><init>()V
    0003: return-void

  [Virtual Method] appendRecord(Landroid/view/accessibility/AccessibilityEvent;, Ljava/lang/Object;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityEventCompatIcs;->appendRecord(Landroid/view/accessibility/AccessibilityEvent;Ljava/lang/Object;)V
    0003: return-void

  [Virtual Method] getRecord(Landroid/view/accessibility/AccessibilityEvent;, I) -> Ljava/lang/Object;
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/accessibility/AccessibilityEventCompatIcs;->getRecord(Landroid/view/accessibility/AccessibilityEvent;I)Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getRecordCount(Landroid/view/accessibility/AccessibilityEvent;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityEventCompatIcs;->getRecordCount(Landroid/view/accessibility/AccessibilityEvent;)I
    0003: move-result v0
    0004: return v0