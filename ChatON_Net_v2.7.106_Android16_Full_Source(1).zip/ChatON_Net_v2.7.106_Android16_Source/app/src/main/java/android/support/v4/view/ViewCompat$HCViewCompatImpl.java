=== CLASS Landroid/support/v4/view/ViewCompat$HCViewCompatImpl; (Source: ViewCompat.java) ===
  Super: Landroid/support/v4/view/ViewCompat$GBViewCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/view/ViewCompat$GBViewCompatImpl;-><init>()V
    0003: return-void

  [Virtual Method] getFrameTime() -> J
    // registers=3, ins=1, outs=0, insns_size=5
    0000: invoke-static {}, Landroid/support/v4/view/ViewCompatHC;->getFrameTime()J
    0003: move-result-wide v0
    0004: return-wide v0