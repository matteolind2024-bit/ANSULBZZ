=== CLASS Landroid/support/v4/content/ModernAsyncTask$2; (Source: ModernAsyncTask.java) ===
  Super: Landroid/support/v4/content/ModernAsyncTask$WorkerRunnable;
  [Instance Field] this$0: Landroid/support/v4/content/ModernAsyncTask;

  [Direct Method] <init>(Landroid/support/v4/content/ModernAsyncTask;) -> V
    // registers=3, ins=2, outs=2, insns_size=7
    0000: iput v2, v1.Landroid/support/v4/content/ModernAsyncTask$2;->this$0:Landroid/support/v4/content/ModernAsyncTask;
    0002: const/4 v0, 0
    0003: invoke-direct {v1, v0}, Landroid/support/v4/content/ModernAsyncTask$WorkerRunnable;-><init>(Landroid/support/v4/content/ModernAsyncTask$1;)V
    0006: return-void

  [Virtual Method] call() -> Ljava/lang/Object;
    // registers=4, ins=1, outs=2, insns_size=30
    0000: iget v0, v3.Landroid/support/v4/content/ModernAsyncTask$2;->this$0:Landroid/support/v4/content/ModernAsyncTask;
    0002: invoke-static {v0}, Landroid/support/v4/content/ModernAsyncTask;->access$200(Landroid/support/v4/content/ModernAsyncTask;)Ljava/util/concurrent/atomic/AtomicBoolean;
    0005: move-result-object v0
    0006: const/4 v1, 1
    0007: invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    000a: const/16 v0, 10 (0xa)
    000c: invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V
    000f: iget v0, v3.Landroid/support/v4/content/ModernAsyncTask$2;->this$0:Landroid/support/v4/content/ModernAsyncTask;
    0011: iget v1, v3.Landroid/support/v4/content/ModernAsyncTask$2;->this$0:Landroid/support/v4/content/ModernAsyncTask;
    0013: iget v2, v3.Landroid/support/v4/content/ModernAsyncTask$2;->mParams:[Ljava/lang/Object;
    0015: invoke-virtual {v1, v2}, Landroid/support/v4/content/ModernAsyncTask;->doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    0018: move-result-object v1
    0019: invoke-static {v0, v1}, Landroid/support/v4/content/ModernAsyncTask;->access$300(Landroid/support/v4/content/ModernAsyncTask;Ljava/lang/Object;)Ljava/lang/Object;
    001c: move-result-object v0
    001d: return-object v0