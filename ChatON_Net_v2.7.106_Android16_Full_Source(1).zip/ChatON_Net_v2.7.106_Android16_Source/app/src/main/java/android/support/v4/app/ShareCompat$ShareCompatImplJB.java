=== CLASS Landroid/support/v4/app/ShareCompat$ShareCompatImplJB; (Source: ShareCompat.java) ===
  Super: Landroid/support/v4/app/ShareCompat$ShareCompatImplICS;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/app/ShareCompat$ShareCompatImplICS;-><init>()V
    0003: return-void

  [Virtual Method] escapeHtml(Ljava/lang/CharSequence;) -> Ljava/lang/String;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/app/ShareCompatJB;->escapeHtml(Ljava/lang/CharSequence;)Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] shouldAddChooserIntent(Landroid/view/MenuItem;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0