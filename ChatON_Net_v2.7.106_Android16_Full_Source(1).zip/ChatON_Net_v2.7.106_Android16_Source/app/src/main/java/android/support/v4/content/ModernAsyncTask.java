=== CLASS Landroid/support/v4/content/ModernAsyncTask; (Source: ModernAsyncTask.java) ===
  Super: Ljava/lang/Object;
  [Static Field] CORE_POOL_SIZE: I = 5
  [Static Field] KEEP_ALIVE: I = 1
  [Static Field] LOG_TAG: Ljava/lang/String; = 'AsyncTask'
  [Static Field] MAXIMUM_POOL_SIZE: I = 128
  [Static Field] MESSAGE_POST_PROGRESS: I = 2
  [Static Field] MESSAGE_POST_RESULT: I = 1
  [Static Field] THREAD_POOL_EXECUTOR: Ljava/util/concurrent/Executor;
  [Static Field] sDefaultExecutor: Ljava/util/concurrent/Executor;
  [Static Field] sHandler: Landroid/support/v4/content/ModernAsyncTask$InternalHandler;
  [Static Field] sPoolWorkQueue: Ljava/util/concurrent/BlockingQueue;
  [Static Field] sThreadFactory: Ljava/util/concurrent/ThreadFactory;
  [Instance Field] mFuture: Ljava/util/concurrent/FutureTask;
  [Instance Field] mStatus: Landroid/support/v4/content/ModernAsyncTask$Status;
  [Instance Field] mTaskInvoked: Ljava/util/concurrent/atomic/AtomicBoolean;
  [Instance Field] mWorker: Landroid/support/v4/content/ModernAsyncTask$WorkerRunnable;

  [Direct Method] <clinit>() -> V
    // registers=8, ins=0, outs=8, insns_size=47
    0000: new-instance v0, Landroid/support/v4/content/ModernAsyncTask$1;
    0002: invoke-direct {v0}, Landroid/support/v4/content/ModernAsyncTask$1;-><init>()V
    0005: sput v0, Landroid/support/v4/content/ModernAsyncTask;->sThreadFactory:Ljava/util/concurrent/ThreadFactory;
    0007: new-instance v0, Ljava/util/concurrent/LinkedBlockingQueue;
    0009: const/16 v1, 10 (0xa)
    000b: invoke-direct {v0, v1}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>(I)V
    000e: sput v0, Landroid/support/v4/content/ModernAsyncTask;->sPoolWorkQueue:Ljava/util/concurrent/BlockingQueue;
    0010: new-instance v0, Ljava/util/concurrent/ThreadPoolExecutor;
    0012: const/4 v1, 5
    0013: const/16 v2, 128 (0x80)
    0015: const-wide/16 v3, 1
    0017: sget v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;
    0019: sget v6, Landroid/support/v4/content/ModernAsyncTask;->sPoolWorkQueue:Ljava/util/concurrent/BlockingQueue;
    001b: sget v7, Landroid/support/v4/content/ModernAsyncTask;->sThreadFactory:Ljava/util/concurrent/ThreadFactory;
    001d: invoke-direct/range {v0..v7}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V
    0020: sput v0, Landroid/support/v4/content/ModernAsyncTask;->THREAD_POOL_EXECUTOR:Ljava/util/concurrent/Executor;
    0022: new-instance v0, Landroid/support/v4/content/ModernAsyncTask$InternalHandler;
    0024: const/4 v1, 0
    0025: invoke-direct {v0, v1}, Landroid/support/v4/content/ModernAsyncTask$InternalHandler;-><init>(Landroid/support/v4/content/ModernAsyncTask$1;)V
    0028: sput v0, Landroid/support/v4/content/ModernAsyncTask;->sHandler:Landroid/support/v4/content/ModernAsyncTask$InternalHandler;
    002a: sget v0, Landroid/support/v4/content/ModernAsyncTask;->THREAD_POOL_EXECUTOR:Ljava/util/concurrent/Executor;
    002c: sput v0, Landroid/support/v4/content/ModernAsyncTask;->sDefaultExecutor:Ljava/util/concurrent/Executor;
    002e: return-void

  [Direct Method] <init>() -> V
    // registers=3, ins=1, outs=3, insns_size=31
    0000: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0003: sget v0, Landroid/support/v4/content/ModernAsyncTask$Status;->PENDING:Landroid/support/v4/content/ModernAsyncTask$Status;
    0005: iput v0, v2.Landroid/support/v4/content/ModernAsyncTask;->mStatus:Landroid/support/v4/content/ModernAsyncTask$Status;
    0007: new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;
    0009: invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V
    000c: iput v0, v2.Landroid/support/v4/content/ModernAsyncTask;->mTaskInvoked:Ljava/util/concurrent/atomic/AtomicBoolean;
    000e: new-instance v0, Landroid/support/v4/content/ModernAsyncTask$2;
    0010: invoke-direct {v0, v2}, Landroid/support/v4/content/ModernAsyncTask$2;-><init>(Landroid/support/v4/content/ModernAsyncTask;)V
    0013: iput v0, v2.Landroid/support/v4/content/ModernAsyncTask;->mWorker:Landroid/support/v4/content/ModernAsyncTask$WorkerRunnable;
    0015: new-instance v0, Landroid/support/v4/content/ModernAsyncTask$3;
    0017: iget v1, v2.Landroid/support/v4/content/ModernAsyncTask;->mWorker:Landroid/support/v4/content/ModernAsyncTask$WorkerRunnable;
    0019: invoke-direct {v0, v2, v1}, Landroid/support/v4/content/ModernAsyncTask$3;-><init>(Landroid/support/v4/content/ModernAsyncTask;Ljava/util/concurrent/Callable;)V
    001c: iput v0, v2.Landroid/support/v4/content/ModernAsyncTask;->mFuture:Ljava/util/concurrent/FutureTask;
    001e: return-void

  [Direct Method] access$200(Landroid/support/v4/content/ModernAsyncTask;) -> Ljava/util/concurrent/atomic/AtomicBoolean;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/ModernAsyncTask;->mTaskInvoked:Ljava/util/concurrent/atomic/AtomicBoolean;
    0002: return-object v0

  [Direct Method] access$300(Landroid/support/v4/content/ModernAsyncTask;, Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-direct {v1, v2}, Landroid/support/v4/content/ModernAsyncTask;->postResult(Ljava/lang/Object;)Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] access$400(Landroid/support/v4/content/ModernAsyncTask;, Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Landroid/support/v4/content/ModernAsyncTask;->postResultIfNotInvoked(Ljava/lang/Object;)V
    0003: return-void

  [Direct Method] access$500(Landroid/support/v4/content/ModernAsyncTask;, Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Landroid/support/v4/content/ModernAsyncTask;->finish(Ljava/lang/Object;)V
    0003: return-void

  [Direct Method] execute(Ljava/lang/Runnable;) -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: sget v0, Landroid/support/v4/content/ModernAsyncTask;->sDefaultExecutor:Ljava/util/concurrent/Executor;
    0002: invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    0005: return-void

  [Direct Method] finish(Ljava/lang/Object;) -> V
    // registers=3, ins=2, outs=2, insns_size=18
    0000: invoke-virtual {v1}, Landroid/support/v4/content/ModernAsyncTask;->isCancelled()Z
    0003: move-result v0
    0004: if-eqz v0, 000e
    0006: invoke-virtual {v1, v2}, Landroid/support/v4/content/ModernAsyncTask;->onCancelled(Ljava/lang/Object;)V
    0009: sget v0, Landroid/support/v4/content/ModernAsyncTask$Status;->FINISHED:Landroid/support/v4/content/ModernAsyncTask$Status;
    000b: iput v0, v1.Landroid/support/v4/content/ModernAsyncTask;->mStatus:Landroid/support/v4/content/ModernAsyncTask$Status;
    000d: return-void
    000e: invoke-virtual {v1, v2}, Landroid/support/v4/content/ModernAsyncTask;->onPostExecute(Ljava/lang/Object;)V
    0011: goto 0009

  [Direct Method] init() -> V
    // registers=1, ins=0, outs=1, insns_size=6
    0000: sget v0, Landroid/support/v4/content/ModernAsyncTask;->sHandler:Landroid/support/v4/content/ModernAsyncTask$InternalHandler;
    0002: invoke-virtual {v0}, Landroid/support/v4/content/ModernAsyncTask$InternalHandler;->getLooper()Landroid/os/Looper;
    0005: return-void

  [Direct Method] postResult(Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=7, ins=2, outs=3, insns_size=21
    0000: const/4 v4, 1
    0001: sget v0, Landroid/support/v4/content/ModernAsyncTask;->sHandler:Landroid/support/v4/content/ModernAsyncTask$InternalHandler;
    0003: new-instance v1, Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;
    0005: new-array v2, v4, [Ljava/lang/Object;
    0007: const/4 v3, 0
    0008: aput(op=4d) v6, v2[v3]
    000a: invoke-direct {v1, v5, v2}, Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;-><init>(Landroid/support/v4/content/ModernAsyncTask;[Ljava/lang/Object;)V
    000d: invoke-virtual {v0, v4, v1}, Landroid/support/v4/content/ModernAsyncTask$InternalHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;
    0010: move-result-object v0
    0011: invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V
    0014: return-object v6

  [Direct Method] postResultIfNotInvoked(Ljava/lang/Object;) -> V
    // registers=3, ins=2, outs=2, insns_size=12
    0000: iget v0, v1.Landroid/support/v4/content/ModernAsyncTask;->mTaskInvoked:Ljava/util/concurrent/atomic/AtomicBoolean;
    0002: invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z
    0005: move-result v0
    0006: if-nez v0, 000b
    0008: invoke-direct {v1, v2}, Landroid/support/v4/content/ModernAsyncTask;->postResult(Ljava/lang/Object;)Ljava/lang/Object;
    000b: return-void

  [Direct Method] setDefaultExecutor(Ljava/util/concurrent/Executor;) -> V
    // registers=1, ins=1, outs=0, insns_size=3
    0000: sput v0, Landroid/support/v4/content/ModernAsyncTask;->sDefaultExecutor:Ljava/util/concurrent/Executor;
    0002: return-void

  [Virtual Method] cancel(Z) -> Z
    // registers=3, ins=2, outs=2, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/content/ModernAsyncTask;->mFuture:Ljava/util/concurrent/FutureTask;
    0002: invoke-virtual {v0, v2}, Ljava/util/concurrent/FutureTask;->cancel(Z)Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] doInBackground([Ljava/lang/Object;) -> Ljava/lang/Object;

  [Virtual Method] execute([Ljava/lang/Object;) -> Landroid/support/v4/content/ModernAsyncTask;
    // registers=3, ins=2, outs=3, insns_size=7
    0000: sget v0, Landroid/support/v4/content/ModernAsyncTask;->sDefaultExecutor:Ljava/util/concurrent/Executor;
    0002: invoke-virtual {v1, v0, v2}, Landroid/support/v4/content/ModernAsyncTask;->executeOnExecutor(Ljava/util/concurrent/Executor;[Ljava/lang/Object;)Landroid/support/v4/content/ModernAsyncTask;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] executeOnExecutor(Ljava/util/concurrent/Executor;, [Ljava/lang/Object;) -> Landroid/support/v4/content/ModernAsyncTask;
    // registers=5, ins=3, outs=2, insns_size=60
    0000: iget v0, v2.Landroid/support/v4/content/ModernAsyncTask;->mStatus:Landroid/support/v4/content/ModernAsyncTask$Status;
    0002: sget v1, Landroid/support/v4/content/ModernAsyncTask$Status;->PENDING:Landroid/support/v4/content/ModernAsyncTask$Status;
    0004: if-eq v0, v1, 0013
    0006: sget v0, Landroid/support/v4/content/ModernAsyncTask$4;->$SwitchMap$android$support$v4$content$ModernAsyncTask$Status:[I
    0008: iget v1, v2.Landroid/support/v4/content/ModernAsyncTask;->mStatus:Landroid/support/v4/content/ModernAsyncTask$Status;
    000a: invoke-virtual {v1}, Landroid/support/v4/content/ModernAsyncTask$Status;->ordinal()I
    000d: move-result v1
    000e: aget(op=44) v0, v0[v1]
    0010: packed-switch v0, +36 (-> 0034)
    0013: sget v0, Landroid/support/v4/content/ModernAsyncTask$Status;->RUNNING:Landroid/support/v4/content/ModernAsyncTask$Status;
    0015: iput v0, v2.Landroid/support/v4/content/ModernAsyncTask;->mStatus:Landroid/support/v4/content/ModernAsyncTask$Status;
    0017: invoke-virtual {v2}, Landroid/support/v4/content/ModernAsyncTask;->onPreExecute()V
    001a: iget v0, v2.Landroid/support/v4/content/ModernAsyncTask;->mWorker:Landroid/support/v4/content/ModernAsyncTask$WorkerRunnable;
    001c: iput v4, v0.Landroid/support/v4/content/ModernAsyncTask$WorkerRunnable;->mParams:[Ljava/lang/Object;
    001e: iget v0, v2.Landroid/support/v4/content/ModernAsyncTask;->mFuture:Ljava/util/concurrent/FutureTask;
    0020: invoke-interface {v3, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    0023: return-object v2
    0024: new-instance v0, Ljava/lang/IllegalStateException;
    0026: const-string v1, 'Cannot execute task: the task is already running.'
    0028: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    002b: throw v0
    002c: new-instance v0, Ljava/lang/IllegalStateException;
    002e: const-string v1, 'Cannot execute task: the task has already been executed (a task can be executed only once)'
    0030: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0033: throw v0
    0034: packed-switch-payload first=1 targets=[20, 28]

  [Virtual Method] get() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/content/ModernAsyncTask;->mFuture:Ljava/util/concurrent/FutureTask;
    0002: invoke-virtual {v0}, Ljava/util/concurrent/FutureTask;->get()Ljava/lang/Object;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] get(J, Ljava/util/concurrent/TimeUnit;) -> Ljava/lang/Object;
    // registers=5, ins=4, outs=4, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/content/ModernAsyncTask;->mFuture:Ljava/util/concurrent/FutureTask;
    0002: invoke-virtual {v0, v2, v3, v4}, Ljava/util/concurrent/FutureTask;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] getStatus() -> Landroid/support/v4/content/ModernAsyncTask$Status;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/ModernAsyncTask;->mStatus:Landroid/support/v4/content/ModernAsyncTask$Status;
    0002: return-object v0

  [Virtual Method] isCancelled() -> Z
    // registers=2, ins=1, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/content/ModernAsyncTask;->mFuture:Ljava/util/concurrent/FutureTask;
    0002: invoke-virtual {v0}, Ljava/util/concurrent/FutureTask;->isCancelled()Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] onCancelled() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onCancelled(Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-virtual {v0}, Landroid/support/v4/content/ModernAsyncTask;->onCancelled()V
    0003: return-void

  [Virtual Method] onPostExecute(Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onPreExecute() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onProgressUpdate([Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] publishProgress([Ljava/lang/Object;) -> V
    // registers=5, ins=2, outs=3, insns_size=22
    0000: invoke-virtual {v3}, Landroid/support/v4/content/ModernAsyncTask;->isCancelled()Z
    0003: move-result v0
    0004: if-nez v0, 0015
    0006: sget v0, Landroid/support/v4/content/ModernAsyncTask;->sHandler:Landroid/support/v4/content/ModernAsyncTask$InternalHandler;
    0008: const/4 v1, 2
    0009: new-instance v2, Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;
    000b: invoke-direct {v2, v3, v4}, Landroid/support/v4/content/ModernAsyncTask$AsyncTaskResult;-><init>(Landroid/support/v4/content/ModernAsyncTask;[Ljava/lang/Object;)V
    000e: invoke-virtual {v0, v1, v2}, Landroid/support/v4/content/ModernAsyncTask$InternalHandler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;
    0011: move-result-object v0
    0012: invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V
    0015: return-void