=== CLASS Landroid/support/v4/app/NotificationCompat$NotificationCompatImplBase; (Source: NotificationCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/app/NotificationCompat$NotificationCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getNotification(Landroid/support/v4/app/NotificationCompat$Builder;) -> Landroid/app/Notification;
    // registers=7, ins=2, outs=5, insns_size=14
    0000: iget v0, v6.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0002: iget v1, v6.Landroid/support/v4/app/NotificationCompat$Builder;->mContext:Landroid/content/Context;
    0004: iget v2, v6.Landroid/support/v4/app/NotificationCompat$Builder;->mContentTitle:Ljava/lang/CharSequence;
    0006: iget v3, v6.Landroid/support/v4/app/NotificationCompat$Builder;->mContentText:Ljava/lang/CharSequence;
    0008: iget v4, v6.Landroid/support/v4/app/NotificationCompat$Builder;->mContentIntent:Landroid/app/PendingIntent;
    000a: invoke-virtual {v0, v1, v2, v3, v4}, Landroid/app/Notification;->setLatestEventInfo(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V
    000d: return-object v0