=== CLASS Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags; (Source: TrafficStatsCompat.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] statsTag: I

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=7
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: const/4 v0, -1
    0004: iput v0, v1.Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;->statsTag:I
    0006: return-void

  [Direct Method] <init>(Landroid/support/v4/net/TrafficStatsCompat$1;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;-><init>()V
    0003: return-void