=== CLASS Landroid/support/v4/widget/EdgeEffectCompat; (Source: EdgeEffectCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] IMPL: Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;
  [Instance Field] mEdgeEffect: Ljava/lang/Object;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=22
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 14 (0xe)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectIcsImpl;
    0008: invoke-direct {v0}, Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectIcsImpl;-><init>()V
    000b: sput v0, Landroid/support/v4/widget/EdgeEffectCompat;->IMPL:Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;
    000d: return-void
    000e: new-instance v0, Landroid/support/v4/widget/EdgeEffectCompat$BaseEdgeEffectImpl;
    0010: invoke-direct {v0}, Landroid/support/v4/widget/EdgeEffectCompat$BaseEdgeEffectImpl;-><init>()V
    0013: sput v0, Landroid/support/v4/widget/EdgeEffectCompat;->IMPL:Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;
    0015: goto 000d

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=3, ins=2, outs=2, insns_size=12
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: sget v0, Landroid/support/v4/widget/EdgeEffectCompat;->IMPL:Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;
    0005: invoke-interface {v0, v2}, Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;->newEdgeEffect(Landroid/content/Context;)Ljava/lang/Object;
    0008: move-result-object v0
    0009: iput v0, v1.Landroid/support/v4/widget/EdgeEffectCompat;->mEdgeEffect:Ljava/lang/Object;
    000b: return-void

  [Virtual Method] draw(Landroid/graphics/Canvas;) -> Z
    // registers=4, ins=2, outs=3, insns_size=9
    0000: sget v0, Landroid/support/v4/widget/EdgeEffectCompat;->IMPL:Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;
    0002: iget v1, v2.Landroid/support/v4/widget/EdgeEffectCompat;->mEdgeEffect:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3}, Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;->draw(Ljava/lang/Object;Landroid/graphics/Canvas;)Z
    0007: move-result v0
    0008: return v0

  [Virtual Method] finish() -> V
    // registers=3, ins=1, outs=2, insns_size=8
    0000: sget v0, Landroid/support/v4/widget/EdgeEffectCompat;->IMPL:Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;
    0002: iget v1, v2.Landroid/support/v4/widget/EdgeEffectCompat;->mEdgeEffect:Ljava/lang/Object;
    0004: invoke-interface {v0, v1}, Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;->finish(Ljava/lang/Object;)V
    0007: return-void

  [Virtual Method] isFinished() -> Z
    // registers=3, ins=1, outs=2, insns_size=9
    0000: sget v0, Landroid/support/v4/widget/EdgeEffectCompat;->IMPL:Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;
    0002: iget v1, v2.Landroid/support/v4/widget/EdgeEffectCompat;->mEdgeEffect:Ljava/lang/Object;
    0004: invoke-interface {v0, v1}, Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;->isFinished(Ljava/lang/Object;)Z
    0007: move-result v0
    0008: return v0

  [Virtual Method] onAbsorb(I) -> Z
    // registers=4, ins=2, outs=3, insns_size=9
    0000: sget v0, Landroid/support/v4/widget/EdgeEffectCompat;->IMPL:Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;
    0002: iget v1, v2.Landroid/support/v4/widget/EdgeEffectCompat;->mEdgeEffect:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3}, Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;->onAbsorb(Ljava/lang/Object;I)Z
    0007: move-result v0
    0008: return v0

  [Virtual Method] onPull(F) -> Z
    // registers=4, ins=2, outs=3, insns_size=9
    0000: sget v0, Landroid/support/v4/widget/EdgeEffectCompat;->IMPL:Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;
    0002: iget v1, v2.Landroid/support/v4/widget/EdgeEffectCompat;->mEdgeEffect:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3}, Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;->onPull(Ljava/lang/Object;F)Z
    0007: move-result v0
    0008: return v0

  [Virtual Method] onRelease() -> Z
    // registers=3, ins=1, outs=2, insns_size=9
    0000: sget v0, Landroid/support/v4/widget/EdgeEffectCompat;->IMPL:Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;
    0002: iget v1, v2.Landroid/support/v4/widget/EdgeEffectCompat;->mEdgeEffect:Ljava/lang/Object;
    0004: invoke-interface {v0, v1}, Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;->onRelease(Ljava/lang/Object;)Z
    0007: move-result v0
    0008: return v0

  [Virtual Method] setSize(I, I) -> V
    // registers=5, ins=3, outs=4, insns_size=8
    0000: sget v0, Landroid/support/v4/widget/EdgeEffectCompat;->IMPL:Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;
    0002: iget v1, v2.Landroid/support/v4/widget/EdgeEffectCompat;->mEdgeEffect:Ljava/lang/Object;
    0004: invoke-interface {v0, v1, v3, v4}, Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl;->setSize(Ljava/lang/Object;II)V
    0007: return-void