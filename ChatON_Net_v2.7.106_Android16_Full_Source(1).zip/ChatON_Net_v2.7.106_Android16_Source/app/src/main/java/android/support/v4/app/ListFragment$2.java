=== CLASS Landroid/support/v4/app/ListFragment$2; (Source: ListFragment.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/widget/AdapterView$OnItemClickListener;
  [Instance Field] this$0: Landroid/support/v4/app/ListFragment;

  [Direct Method] <init>(Landroid/support/v4/app/ListFragment;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/app/ListFragment$2;->this$0:Landroid/support/v4/app/ListFragment;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onItemClick(Landroid/widget/AdapterView;, Landroid/view/View;, I, J) -> V
    // registers=12, ins=6, outs=6, insns_size=12
    0000: iget v0, v6.Landroid/support/v4/app/ListFragment$2;->this$0:Landroid/support/v4/app/ListFragment;
    0002: move(op=07) v1, v7
    0003: check-cast v1, Landroid/widget/ListView;
    0005: move(op=07) v2, v8
    0006: move(op=01) v3, v9
    0007: move(op=04) v4, v10
    0008: invoke-virtual/range {v0..v5}, Landroid/support/v4/app/ListFragment;->onListItemClick(Landroid/widget/ListView;Landroid/view/View;IJ)V
    000b: return-void