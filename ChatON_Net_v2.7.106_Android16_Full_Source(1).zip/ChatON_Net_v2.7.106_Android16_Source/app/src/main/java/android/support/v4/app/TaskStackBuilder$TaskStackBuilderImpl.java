=== CLASS Landroid/support/v4/app/TaskStackBuilder$TaskStackBuilderImpl; (Source: TaskStackBuilder.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] getPendingIntent(Landroid/content/Context;, [Landroid/content/Intent;, I, I, Landroid/os/Bundle;) -> Landroid/app/PendingIntent;