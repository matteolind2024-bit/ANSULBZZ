=== CLASS Landroid/support/v4/app/FragmentManagerImpl$2; (Source: FragmentManager.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/lang/Runnable;
  [Instance Field] this$0: Landroid/support/v4/app/FragmentManagerImpl;

  [Direct Method] <init>(Landroid/support/v4/app/FragmentManagerImpl;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/app/FragmentManagerImpl$2;->this$0:Landroid/support/v4/app/FragmentManagerImpl;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] run() -> V
    // registers=6, ins=1, outs=5, insns_size=15
    0000: iget v0, v5.Landroid/support/v4/app/FragmentManagerImpl$2;->this$0:Landroid/support/v4/app/FragmentManagerImpl;
    0002: iget v1, v5.Landroid/support/v4/app/FragmentManagerImpl$2;->this$0:Landroid/support/v4/app/FragmentManagerImpl;
    0004: iget v1, v1.Landroid/support/v4/app/FragmentManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0006: iget v1, v1.Landroid/support/v4/app/FragmentActivity;->mHandler:Landroid/os/Handler;
    0008: const/4 v2, 0
    0009: const/4 v3, -1
    000a: const/4 v4, 0
    000b: invoke-virtual {v0, v1, v2, v3, v4}, Landroid/support/v4/app/FragmentManagerImpl;->popBackStackState(Landroid/os/Handler;Ljava/lang/String;II)Z
    000e: return-void