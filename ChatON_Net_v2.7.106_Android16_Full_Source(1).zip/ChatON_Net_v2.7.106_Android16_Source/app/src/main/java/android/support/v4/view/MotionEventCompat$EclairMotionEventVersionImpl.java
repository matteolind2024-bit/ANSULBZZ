=== CLASS Landroid/support/v4/view/MotionEventCompat$EclairMotionEventVersionImpl; (Source: MotionEventCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] findPointerIndex(Landroid/view/MotionEvent;, I) -> I
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/MotionEventCompatEclair;->findPointerIndex(Landroid/view/MotionEvent;I)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] getPointerId(Landroid/view/MotionEvent;, I) -> I
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/MotionEventCompatEclair;->getPointerId(Landroid/view/MotionEvent;I)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] getX(Landroid/view/MotionEvent;, I) -> F
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/MotionEventCompatEclair;->getX(Landroid/view/MotionEvent;I)F
    0003: move-result v0
    0004: return v0

  [Virtual Method] getY(Landroid/view/MotionEvent;, I) -> F
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/MotionEventCompatEclair;->getY(Landroid/view/MotionEvent;I)F
    0003: move-result v0
    0004: return v0