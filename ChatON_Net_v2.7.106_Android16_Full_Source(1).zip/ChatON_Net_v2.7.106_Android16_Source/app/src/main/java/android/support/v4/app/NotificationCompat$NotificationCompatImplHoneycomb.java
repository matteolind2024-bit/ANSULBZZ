=== CLASS Landroid/support/v4/app/NotificationCompat$NotificationCompatImplHoneycomb; (Source: NotificationCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/app/NotificationCompat$NotificationCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getNotification(Landroid/support/v4/app/NotificationCompat$Builder;) -> Landroid/app/Notification;
    // registers=12, ins=2, outs=10, insns_size=25
    0000: iget v0, v11.Landroid/support/v4/app/NotificationCompat$Builder;->mContext:Landroid/content/Context;
    0002: iget v1, v11.Landroid/support/v4/app/NotificationCompat$Builder;->mNotification:Landroid/app/Notification;
    0004: iget v2, v11.Landroid/support/v4/app/NotificationCompat$Builder;->mContentTitle:Ljava/lang/CharSequence;
    0006: iget v3, v11.Landroid/support/v4/app/NotificationCompat$Builder;->mContentText:Ljava/lang/CharSequence;
    0008: iget v4, v11.Landroid/support/v4/app/NotificationCompat$Builder;->mContentInfo:Ljava/lang/CharSequence;
    000a: iget v5, v11.Landroid/support/v4/app/NotificationCompat$Builder;->mTickerView:Landroid/widget/RemoteViews;
    000c: iget v6, v11.Landroid/support/v4/app/NotificationCompat$Builder;->mNumber:I
    000e: iget v7, v11.Landroid/support/v4/app/NotificationCompat$Builder;->mContentIntent:Landroid/app/PendingIntent;
    0010: iget v8, v11.Landroid/support/v4/app/NotificationCompat$Builder;->mFullScreenIntent:Landroid/app/PendingIntent;
    0012: iget v9, v11.Landroid/support/v4/app/NotificationCompat$Builder;->mLargeIcon:Landroid/graphics/Bitmap;
    0014: invoke-static/range {v0..v9}, Landroid/support/v4/app/NotificationCompatHoneycomb;->add(Landroid/content/Context;Landroid/app/Notification;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/widget/RemoteViews;ILandroid/app/PendingIntent;Landroid/app/PendingIntent;Landroid/graphics/Bitmap;)Landroid/app/Notification;
    0017: move-result-object v0
    0018: return-object v0