=== CLASS Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateStubImpl; (Source: AccessibilityDelegateCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/AccessibilityDelegateCompat$AccessibilityDelegateImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] dispatchPopulateAccessibilityEvent(Ljava/lang/Object;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> Z
    // registers=5, ins=4, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getAccessibilityNodeProvider(Ljava/lang/Object;, Landroid/view/View;) -> Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] newAccessiblityDelegateBridge(Landroid/support/v4/view/AccessibilityDelegateCompat;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] newAccessiblityDelegateDefaultImpl() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] onInitializeAccessibilityEvent(Ljava/lang/Object;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=4, ins=4, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onInitializeAccessibilityNodeInfo(Ljava/lang/Object;, Landroid/view/View;, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;) -> V
    // registers=4, ins=4, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onPopulateAccessibilityEvent(Ljava/lang/Object;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=4, ins=4, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onRequestSendAccessibilityEvent(Ljava/lang/Object;, Landroid/view/ViewGroup;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> Z
    // registers=6, ins=5, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Virtual Method] performAccessibilityAction(Ljava/lang/Object;, Landroid/view/View;, I, Landroid/os/Bundle;) -> Z
    // registers=6, ins=5, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] sendAccessibilityEvent(Ljava/lang/Object;, Landroid/view/View;, I) -> V
    // registers=4, ins=4, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] sendAccessibilityEventUnchecked(Ljava/lang/Object;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=4, ins=4, outs=0, insns_size=1
    0000: return-void