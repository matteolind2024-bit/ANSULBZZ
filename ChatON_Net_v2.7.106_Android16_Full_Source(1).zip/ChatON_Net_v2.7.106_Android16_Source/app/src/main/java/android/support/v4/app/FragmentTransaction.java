=== CLASS Landroid/support/v4/app/FragmentTransaction; (Source: FragmentTransaction.java) ===
  Super: Ljava/lang/Object;
  [Static Field] TRANSIT_ENTER_MASK: I = 4096
  [Static Field] TRANSIT_EXIT_MASK: I = 8192
  [Static Field] TRANSIT_FRAGMENT_CLOSE: I = 8194
  [Static Field] TRANSIT_FRAGMENT_FADE: I = 4099
  [Static Field] TRANSIT_FRAGMENT_OPEN: I = 4097
  [Static Field] TRANSIT_NONE: I = 0
  [Static Field] TRANSIT_UNSET: I = -1

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] add(I, Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] add(I, Landroid/support/v4/app/Fragment;, Ljava/lang/String;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] add(Landroid/support/v4/app/Fragment;, Ljava/lang/String;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] addToBackStack(Ljava/lang/String;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] attach(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] commit() -> I

  [Virtual Method] commitAllowingStateLoss() -> I

  [Virtual Method] detach(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] disallowAddToBackStack() -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] hide(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] isAddToBackStackAllowed() -> Z

  [Virtual Method] isEmpty() -> Z

  [Virtual Method] remove(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] replace(I, Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] replace(I, Landroid/support/v4/app/Fragment;, Ljava/lang/String;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] setBreadCrumbShortTitle(I) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] setBreadCrumbShortTitle(Ljava/lang/CharSequence;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] setBreadCrumbTitle(I) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] setBreadCrumbTitle(Ljava/lang/CharSequence;) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] setCustomAnimations(I, I) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] setCustomAnimations(I, I, I, I) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] setTransition(I) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] setTransitionStyle(I) -> Landroid/support/v4/app/FragmentTransaction;

  [Virtual Method] show(Landroid/support/v4/app/Fragment;) -> Landroid/support/v4/app/FragmentTransaction;