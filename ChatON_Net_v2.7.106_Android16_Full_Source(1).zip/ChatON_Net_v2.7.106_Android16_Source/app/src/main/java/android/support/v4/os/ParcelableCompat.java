=== CLASS Landroid/support/v4/os/ParcelableCompat; (Source: ParcelableCompat.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] newCreator(Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;) -> Landroid/os/Parcelable$Creator;
    // registers=3, ins=1, outs=2, insns_size=15
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 13 (0xd)
    0004: if-lt v0, v1, 0009
    0006: invoke-static {v2}, Landroid/support/v4/os/ParcelableCompatCreatorHoneycombMR2Stub;->instantiate(Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;)Landroid/os/Parcelable$Creator;
    0009: new-instance v0, Landroid/support/v4/os/ParcelableCompat$CompatCreator;
    000b: invoke-direct {v0, v2}, Landroid/support/v4/os/ParcelableCompat$CompatCreator;-><init>(Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;)V
    000e: return-object v0