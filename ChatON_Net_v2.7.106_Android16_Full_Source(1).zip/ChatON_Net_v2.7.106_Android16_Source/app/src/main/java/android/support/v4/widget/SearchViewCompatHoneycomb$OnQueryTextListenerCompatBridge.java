=== CLASS Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge; (Source: SearchViewCompatHoneycomb.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] onQueryTextChange(Ljava/lang/String;) -> Z

  [Virtual Method] onQueryTextSubmit(Ljava/lang/String;) -> Z