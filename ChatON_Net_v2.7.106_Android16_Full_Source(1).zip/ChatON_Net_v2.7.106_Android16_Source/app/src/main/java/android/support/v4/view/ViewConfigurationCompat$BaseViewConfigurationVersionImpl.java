=== CLASS Landroid/support/v4/view/ViewConfigurationCompat$BaseViewConfigurationVersionImpl; (Source: ViewConfigurationCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/ViewConfigurationCompat$ViewConfigurationVersionImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] getScaledPagingTouchSlop(Landroid/view/ViewConfiguration;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-virtual {v2}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I
    0003: move-result v0
    0004: return v0