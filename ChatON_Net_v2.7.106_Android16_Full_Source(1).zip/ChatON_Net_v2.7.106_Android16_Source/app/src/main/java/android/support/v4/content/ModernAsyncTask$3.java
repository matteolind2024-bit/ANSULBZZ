=== CLASS Landroid/support/v4/content/ModernAsyncTask$3; (Source: ModernAsyncTask.java) ===
  Super: Ljava/util/concurrent/FutureTask;
  [Instance Field] this$0: Landroid/support/v4/content/ModernAsyncTask;

  [Direct Method] <init>(Landroid/support/v4/content/ModernAsyncTask;, Ljava/util/concurrent/Callable;) -> V
    // registers=3, ins=3, outs=2, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/content/ModernAsyncTask$3;->this$0:Landroid/support/v4/content/ModernAsyncTask;
    0002: invoke-direct {v0, v2}, Ljava/util/concurrent/FutureTask;-><init>(Ljava/util/concurrent/Callable;)V
    0005: return-void

  [Virtual Method] done() -> V
    // registers=4, ins=1, outs=3, insns_size=47
    0000: invoke-virtual {v3}, Landroid/support/v4/content/ModernAsyncTask$3;->get()Ljava/lang/Object;
    0003: move-result-object v0
    0004: iget v1, v3.Landroid/support/v4/content/ModernAsyncTask$3;->this$0:Landroid/support/v4/content/ModernAsyncTask;
    0006: invoke-static {v1, v0}, Landroid/support/v4/content/ModernAsyncTask;->access$400(Landroid/support/v4/content/ModernAsyncTask;Ljava/lang/Object;)V
    0009: return-void
    000a: move-exception v0
    000b: const-string v1, 'AsyncTask'
    000d: invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I
    0010: goto 0009
    0011: move-exception v0
    0012: new-instance v1, Ljava/lang/RuntimeException;
    0014: const-string v2, 'An error occured while executing doInBackground()'
    0016: invoke-virtual {v0}, Ljava/util/concurrent/ExecutionException;->getCause()Ljava/lang/Throwable;
    0019: move-result-object v0
    001a: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    001d: throw v1
    001e: move-exception v0
    001f: iget v0, v3.Landroid/support/v4/content/ModernAsyncTask$3;->this$0:Landroid/support/v4/content/ModernAsyncTask;
    0021: const/4 v1, 0
    0022: invoke-static {v0, v1}, Landroid/support/v4/content/ModernAsyncTask;->access$400(Landroid/support/v4/content/ModernAsyncTask;Ljava/lang/Object;)V
    0025: goto 0009
    0026: move-exception v0
    0027: new-instance v1, Ljava/lang/RuntimeException;
    0029: const-string v2, 'An error occured while executing doInBackground()'
    002b: invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    002e: throw v1