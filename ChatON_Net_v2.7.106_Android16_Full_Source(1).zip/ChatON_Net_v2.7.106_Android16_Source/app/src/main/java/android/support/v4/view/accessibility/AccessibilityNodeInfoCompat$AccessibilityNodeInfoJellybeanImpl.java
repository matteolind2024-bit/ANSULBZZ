=== CLASS Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanImpl; (Source: AccessibilityNodeInfoCompat.java) ===
  Super: Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat$AccessibilityNodeInfoIcsImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat$AccessibilityNodeInfoIcsImpl;-><init>()V
    0003: return-void

  [Virtual Method] addChild(Ljava/lang/Object;, Landroid/view/View;, I) -> V
    // registers=4, ins=4, outs=3, insns_size=4
    0000: invoke-static {v1, v2, v3}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->addChild(Ljava/lang/Object;Landroid/view/View;I)V
    0003: return-void

  [Virtual Method] findFocus(Ljava/lang/Object;, I) -> Ljava/lang/Object;
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->findFocus(Ljava/lang/Object;I)Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] focusSearch(Ljava/lang/Object;, I) -> Ljava/lang/Object;
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->focusSearch(Ljava/lang/Object;I)Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getMovementGranularities(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->getMovementGranularities(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] isAccessibilityFocused(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->isAccessibilityFocused(Ljava/lang/Object;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] isVisibleToUser(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->isVisibleToUser(Ljava/lang/Object;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] obtain(Landroid/view/View;, I) -> Ljava/lang/Object;
    // registers=4, ins=3, outs=2, insns_size=5
    0000: invoke-static {v2, v3}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->obtain(Landroid/view/View;I)Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] performAction(Ljava/lang/Object;, I, Landroid/os/Bundle;) -> Z
    // registers=5, ins=4, outs=3, insns_size=5
    0000: invoke-static {v2, v3, v4}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->performAction(Ljava/lang/Object;ILandroid/os/Bundle;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] setAccessibilityFocused(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->setAccesibilityFocused(Ljava/lang/Object;Z)V
    0003: return-void

  [Virtual Method] setMovementGranularities(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->setMovementGranularities(Ljava/lang/Object;I)V
    0003: return-void

  [Virtual Method] setParent(Ljava/lang/Object;, Landroid/view/View;, I) -> V
    // registers=4, ins=4, outs=3, insns_size=4
    0000: invoke-static {v1, v2, v3}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->setParent(Ljava/lang/Object;Landroid/view/View;I)V
    0003: return-void

  [Virtual Method] setSource(Ljava/lang/Object;, Landroid/view/View;, I) -> V
    // registers=4, ins=4, outs=3, insns_size=4
    0000: invoke-static {v1, v2, v3}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->setSource(Ljava/lang/Object;Landroid/view/View;I)V
    0003: return-void

  [Virtual Method] setVisibleToUser(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompatJellyBean;->setVisibleToUser(Ljava/lang/Object;Z)V
    0003: return-void