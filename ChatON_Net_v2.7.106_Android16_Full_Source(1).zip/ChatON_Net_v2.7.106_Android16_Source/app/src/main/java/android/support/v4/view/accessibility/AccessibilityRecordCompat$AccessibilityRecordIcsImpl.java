=== CLASS Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordIcsImpl; (Source: AccessibilityRecordCompat.java) ===
  Super: Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordStubImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompat$AccessibilityRecordStubImpl;-><init>()V
    0003: return-void

  [Virtual Method] getAddedCount(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getAddedCount(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] getBeforeText(Ljava/lang/Object;) -> Ljava/lang/CharSequence;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getBeforeText(Ljava/lang/Object;)Ljava/lang/CharSequence;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getClassName(Ljava/lang/Object;) -> Ljava/lang/CharSequence;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getClassName(Ljava/lang/Object;)Ljava/lang/CharSequence;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getContentDescription(Ljava/lang/Object;) -> Ljava/lang/CharSequence;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getContentDescription(Ljava/lang/Object;)Ljava/lang/CharSequence;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getCurrentItemIndex(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getCurrentItemIndex(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] getFromIndex(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getFromIndex(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] getItemCount(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getItemCount(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] getParcelableData(Ljava/lang/Object;) -> Landroid/os/Parcelable;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getParcelableData(Ljava/lang/Object;)Landroid/os/Parcelable;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getRemovedCount(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getRemovedCount(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] getScrollX(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getScrollX(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] getScrollY(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getScrollY(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] getSource(Ljava/lang/Object;) -> Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;
    // registers=3, ins=2, outs=1, insns_size=9
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getSource(Ljava/lang/Object;)Ljava/lang/Object;
    0003: move-result-object v0
    0004: invoke-static {v0}, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;->wrapNonNullInstance(Ljava/lang/Object;)Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] getText(Ljava/lang/Object;) -> Ljava/util/List;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getText(Ljava/lang/Object;)Ljava/util/List;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getToIndex(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getToIndex(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] getWindowId(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->getWindowId(Ljava/lang/Object;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] isChecked(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->isChecked(Ljava/lang/Object;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] isEnabled(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->isEnabled(Ljava/lang/Object;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] isFullScreen(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->isFullScreen(Ljava/lang/Object;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] isPassword(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->isPassword(Ljava/lang/Object;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] isScrollable(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->isScrollable(Ljava/lang/Object;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] obtain() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=0, insns_size=5
    0000: invoke-static {}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->obtain()Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] obtain(Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->obtain(Ljava/lang/Object;)Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] recycle(Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-static {v1}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->recycle(Ljava/lang/Object;)V
    0003: return-void

  [Virtual Method] setAddedCount(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setAddedCount(Ljava/lang/Object;I)V
    0003: return-void

  [Virtual Method] setBeforeText(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setBeforeText(Ljava/lang/Object;Ljava/lang/CharSequence;)V
    0003: return-void

  [Virtual Method] setChecked(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setChecked(Ljava/lang/Object;Z)V
    0003: return-void

  [Virtual Method] setClassName(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setClassName(Ljava/lang/Object;Ljava/lang/CharSequence;)V
    0003: return-void

  [Virtual Method] setContentDescription(Ljava/lang/Object;, Ljava/lang/CharSequence;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setContentDescription(Ljava/lang/Object;Ljava/lang/CharSequence;)V
    0003: return-void

  [Virtual Method] setCurrentItemIndex(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setCurrentItemIndex(Ljava/lang/Object;I)V
    0003: return-void

  [Virtual Method] setEnabled(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setEnabled(Ljava/lang/Object;Z)V
    0003: return-void

  [Virtual Method] setFromIndex(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setFromIndex(Ljava/lang/Object;I)V
    0003: return-void

  [Virtual Method] setFullScreen(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setFullScreen(Ljava/lang/Object;Z)V
    0003: return-void

  [Virtual Method] setItemCount(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setItemCount(Ljava/lang/Object;I)V
    0003: return-void

  [Virtual Method] setParcelableData(Ljava/lang/Object;, Landroid/os/Parcelable;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setParcelableData(Ljava/lang/Object;Landroid/os/Parcelable;)V
    0003: return-void

  [Virtual Method] setPassword(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setPassword(Ljava/lang/Object;Z)V
    0003: return-void

  [Virtual Method] setRemovedCount(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setRemovedCount(Ljava/lang/Object;I)V
    0003: return-void

  [Virtual Method] setScrollX(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setScrollX(Ljava/lang/Object;I)V
    0003: return-void

  [Virtual Method] setScrollY(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setScrollY(Ljava/lang/Object;I)V
    0003: return-void

  [Virtual Method] setScrollable(Ljava/lang/Object;, Z) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setScrollable(Ljava/lang/Object;Z)V
    0003: return-void

  [Virtual Method] setSource(Ljava/lang/Object;, Landroid/view/View;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setSource(Ljava/lang/Object;Landroid/view/View;)V
    0003: return-void

  [Virtual Method] setToIndex(Ljava/lang/Object;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/accessibility/AccessibilityRecordCompatIcs;->setToIndex(Ljava/lang/Object;I)V
    0003: return-void