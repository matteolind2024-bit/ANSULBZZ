=== CLASS Landroid/support/v4/widget/SearchViewCompat; (Source: SearchViewCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] IMPL: Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=22
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 11 (0xb)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl;
    0008: invoke-direct {v0}, Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl;-><init>()V
    000b: sput v0, Landroid/support/v4/widget/SearchViewCompat;->IMPL:Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;
    000d: return-void
    000e: new-instance v0, Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatStubImpl;
    0010: invoke-direct {v0}, Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatStubImpl;-><init>()V
    0013: sput v0, Landroid/support/v4/widget/SearchViewCompat;->IMPL:Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;
    0015: goto 000d

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] access$000() -> Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Landroid/support/v4/widget/SearchViewCompat;->IMPL:Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;
    0002: return-object v0

  [Direct Method] newSearchView(Landroid/content/Context;) -> Landroid/view/View;
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/widget/SearchViewCompat;->IMPL:Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;->newSearchView(Landroid/content/Context;)Landroid/view/View;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] setOnQueryTextListener(Landroid/view/View;, Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;) -> V
    // registers=4, ins=2, outs=3, insns_size=8
    0000: sget v0, Landroid/support/v4/widget/SearchViewCompat;->IMPL:Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;
    0002: iget v1, v3.Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;->mListener:Ljava/lang/Object;
    0004: invoke-interface {v0, v2, v1}, Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatImpl;->setOnQueryTextListener(Ljava/lang/Object;Ljava/lang/Object;)V
    0007: return-void