=== CLASS Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerStubImpl; (Source: AccessibilityManagerCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerVersionImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] addAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager;, Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getEnabledAccessibilityServiceList(Landroid/view/accessibility/AccessibilityManager;, I) -> Ljava/util/List;
    // registers=4, ins=3, outs=0, insns_size=5
    0000: invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getInstalledAccessibilityServiceList(Landroid/view/accessibility/AccessibilityManager;) -> Ljava/util/List;
    // registers=3, ins=2, outs=0, insns_size=5
    0000: invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] isTouchExplorationEnabled(Landroid/view/accessibility/AccessibilityManager;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] newAccessiblityStateChangeListener(Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] removeAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager;, Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0