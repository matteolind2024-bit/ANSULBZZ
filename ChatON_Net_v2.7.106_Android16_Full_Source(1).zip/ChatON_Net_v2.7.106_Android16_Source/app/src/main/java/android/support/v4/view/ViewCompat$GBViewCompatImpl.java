=== CLASS Landroid/support/v4/view/ViewCompat$GBViewCompatImpl; (Source: ViewCompat.java) ===
  Super: Landroid/support/v4/view/ViewCompat$BaseViewCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/view/ViewCompat$BaseViewCompatImpl;-><init>()V
    0003: return-void

  [Virtual Method] getOverScrollMode(Landroid/view/View;) -> I
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-static {v2}, Landroid/support/v4/view/ViewCompatGingerbread;->getOverScrollMode(Landroid/view/View;)I
    0003: move-result v0
    0004: return v0

  [Virtual Method] setOverScrollMode(Landroid/view/View;, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/view/ViewCompatGingerbread;->setOverScrollMode(Landroid/view/View;I)V
    0003: return-void