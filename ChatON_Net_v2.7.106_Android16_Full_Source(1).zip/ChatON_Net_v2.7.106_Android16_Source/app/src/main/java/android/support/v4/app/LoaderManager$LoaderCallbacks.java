=== CLASS Landroid/support/v4/app/LoaderManager$LoaderCallbacks; (Source: LoaderManager.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] onCreateLoader(I, Landroid/os/Bundle;) -> Landroid/support/v4/content/Loader;

  [Virtual Method] onLoadFinished(Landroid/support/v4/content/Loader;, Ljava/lang/Object;) -> V

  [Virtual Method] onLoaderReset(Landroid/support/v4/content/Loader;) -> V