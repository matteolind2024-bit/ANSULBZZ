=== CLASS Landroid/support/v4/app/LoaderManagerImpl; (Source: LoaderManager.java) ===
  Super: Landroid/support/v4/app/LoaderManager;
  [Static Field] DEBUG: Z = False
  [Static Field] TAG: Ljava/lang/String; = 'LoaderManager'
  [Instance Field] mActivity: Landroid/support/v4/app/FragmentActivity;
  [Instance Field] mCreatingLoader: Z
  [Instance Field] mInactiveLoaders: Landroid/support/v4/util/SparseArrayCompat;
  [Instance Field] mLoaders: Landroid/support/v4/util/SparseArrayCompat;
  [Instance Field] mRetaining: Z
  [Instance Field] mRetainingStarted: Z
  [Instance Field] mStarted: Z

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=0, insns_size=4
    0000: const/4 v0, 0
    0001: sput v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0003: return-void

  [Direct Method] <init>(Landroid/support/v4/app/FragmentActivity;, Z) -> V
    // registers=4, ins=3, outs=1, insns_size=22
    0000: invoke-direct {v1}, Landroid/support/v4/app/LoaderManager;-><init>()V
    0003: new-instance v0, Landroid/support/v4/util/SparseArrayCompat;
    0005: invoke-direct {v0}, Landroid/support/v4/util/SparseArrayCompat;-><init>()V
    0008: iput v0, v1.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    000a: new-instance v0, Landroid/support/v4/util/SparseArrayCompat;
    000c: invoke-direct {v0}, Landroid/support/v4/util/SparseArrayCompat;-><init>()V
    000f: iput v0, v1.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0011: iput v2, v1.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0013: iput v3, v1.Landroid/support/v4/app/LoaderManagerImpl;->mStarted:Z
    0015: return-void

  [Direct Method] createAndInstallLoader(I, Landroid/os/Bundle;, Landroid/support/v4/app/LoaderManager$LoaderCallbacks;) -> Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    // registers=6, ins=4, outs=4, insns_size=18
    0000: const/4 v1, 0
    0001: const/4 v0, 1
    0002: iput v0, v2.Landroid/support/v4/app/LoaderManagerImpl;->mCreatingLoader:Z
    0004: invoke-direct {v2, v3, v4, v5}, Landroid/support/v4/app/LoaderManagerImpl;->createLoader(ILandroid/os/Bundle;Landroid/support/v4/app/LoaderManager$LoaderCallbacks;)Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0007: move-result-object v0
    0008: invoke-virtual {v2, v0}, Landroid/support/v4/app/LoaderManagerImpl;->installLoader(Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;)V
    000b: iput v1, v2.Landroid/support/v4/app/LoaderManagerImpl;->mCreatingLoader:Z
    000d: return-object v0
    000e: move-exception v0
    000f: iput v1, v2.Landroid/support/v4/app/LoaderManagerImpl;->mCreatingLoader:Z
    0011: throw v0

  [Direct Method] createLoader(I, Landroid/os/Bundle;, Landroid/support/v4/app/LoaderManager$LoaderCallbacks;) -> Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    // registers=6, ins=4, outs=5, insns_size=12
    0000: new-instance v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0002: invoke-direct {v0, v2, v3, v4, v5}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;-><init>(Landroid/support/v4/app/LoaderManagerImpl;ILandroid/os/Bundle;Landroid/support/v4/app/LoaderManager$LoaderCallbacks;)V
    0005: invoke-interface {v5, v3, v4}, Landroid/support/v4/app/LoaderManager$LoaderCallbacks;->onCreateLoader(ILandroid/os/Bundle;)Landroid/support/v4/content/Loader;
    0008: move-result-object v1
    0009: iput v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    000b: return-object v0

  [Virtual Method] destroyLoader(I) -> V
    // registers=5, ins=2, outs=2, insns_size=116
    0000: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mCreatingLoader:Z
    0002: if-eqz v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'Called while creating a loader'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    000e: if-eqz v0, 0032
    0010: const-string v0, 'LoaderManager'
    0012: new-instance v1, Ljava/lang/StringBuilder;
    0014: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0017: const-string v2, 'destroyLoader in '
    0019: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: move-result-object v1
    001d: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0020: move-result-object v1
    0021: const-string v2, ' of '
    0023: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0026: move-result-object v1
    0027: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    002a: move-result-object v1
    002b: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    002e: move-result-object v1
    002f: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0032: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0034: invoke-virtual {v0, v4}, Landroid/support/v4/util/SparseArrayCompat;->indexOfKey(I)I
    0037: move-result v1
    0038: if-ltz v1, 004a
    003a: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    003c: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    003f: move-result-object v0
    0040: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0042: iget v2, v3.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0044: invoke-virtual {v2, v1}, Landroid/support/v4/util/SparseArrayCompat;->removeAt(I)V
    0047: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->destroy()V
    004a: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    004c: invoke-virtual {v0, v4}, Landroid/support/v4/util/SparseArrayCompat;->indexOfKey(I)I
    004f: move-result v1
    0050: if-ltz v1, 0062
    0052: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0054: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0057: move-result-object v0
    0058: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    005a: iget v2, v3.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    005c: invoke-virtual {v2, v1}, Landroid/support/v4/util/SparseArrayCompat;->removeAt(I)V
    005f: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->destroy()V
    0062: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0064: if-eqz v0, 0073
    0066: invoke-virtual {v3}, Landroid/support/v4/app/LoaderManagerImpl;->hasRunningLoaders()Z
    0069: move-result v0
    006a: if-nez v0, 0073
    006c: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    006e: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mFragments:Landroid/support/v4/app/FragmentManagerImpl;
    0070: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManagerImpl;->startPendingDeferredFragments()V
    0073: return-void

  [Virtual Method] doDestroy() -> V
    // registers=4, ins=1, outs=2, insns_size=118
    0000: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mRetaining:Z
    0002: if-nez v0, 003a
    0004: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0006: if-eqz v0, 0020
    0008: const-string v0, 'LoaderManager'
    000a: new-instance v1, Ljava/lang/StringBuilder;
    000c: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000f: const-string v2, 'Destroying Active in '
    0011: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0018: move-result-object v1
    0019: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001c: move-result-object v1
    001d: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0020: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0022: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    0025: move-result v0
    0026: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0028: move(op=01) v1, v0
    0029: if-ltz v1, 003a
    002b: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    002d: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0030: move-result-object v0
    0031: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0033: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->destroy()V
    0036: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    0038: move(op=01) v1, v0
    0039: goto 0029
    003a: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    003c: if-eqz v0, 0056
    003e: const-string v0, 'LoaderManager'
    0040: new-instance v1, Ljava/lang/StringBuilder;
    0042: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0045: const-string v2, 'Destroying Inactive in '
    0047: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004a: move-result-object v1
    004b: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    004e: move-result-object v1
    004f: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0052: move-result-object v1
    0053: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0056: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0058: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    005b: move-result v0
    005c: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    005e: move(op=01) v1, v0
    005f: if-ltz v1, 0070
    0061: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0063: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0066: move-result-object v0
    0067: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0069: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->destroy()V
    006c: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    006e: move(op=01) v1, v0
    006f: goto 005f
    0070: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0072: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->clear()V
    0075: return-void

  [Virtual Method] doReportNextStart() -> V
    // registers=4, ins=1, outs=2, insns_size=27
    0000: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0002: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    0005: move-result v0
    0006: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0008: move(op=01) v1, v0
    0009: if-ltz v1, 001a
    000b: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    000d: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0010: move-result-object v0
    0011: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0013: const/4 v2, 1
    0014: iput v2, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mReportNextStart:Z
    0016: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    0018: move(op=01) v1, v0
    0019: goto 0009
    001a: return-void

  [Virtual Method] doReportStart() -> V
    // registers=3, ins=1, outs=2, insns_size=27
    0000: iget v0, v2.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0002: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    0005: move-result v0
    0006: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0008: move(op=01) v1, v0
    0009: if-ltz v1, 001a
    000b: iget v0, v2.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    000d: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0010: move-result-object v0
    0011: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0013: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->reportStart()V
    0016: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    0018: move(op=01) v1, v0
    0019: goto 0009
    001a: return-void

  [Virtual Method] doRetain() -> V
    // registers=5, ins=1, outs=3, insns_size=99
    0000: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0002: if-eqz v0, 001c
    0004: const-string v0, 'LoaderManager'
    0006: new-instance v1, Ljava/lang/StringBuilder;
    0008: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v2, 'Retaining in '
    000d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v1
    0011: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0018: move-result-object v1
    0019: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001c: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mStarted:Z
    001e: if-nez v0, 0043
    0020: new-instance v0, Ljava/lang/RuntimeException;
    0022: const-string v1, 'here'
    0024: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    0027: invoke-virtual {v0}, Ljava/lang/RuntimeException;->fillInStackTrace()Ljava/lang/Throwable;
    002a: const-string v1, 'LoaderManager'
    002c: new-instance v2, Ljava/lang/StringBuilder;
    002e: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0031: const-string v3, 'Called doRetain when not started: '
    0033: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0036: move-result-object v2
    0037: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    003a: move-result-object v2
    003b: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    003e: move-result-object v2
    003f: invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    0042: return-void
    0043: const/4 v0, 1
    0044: iput v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mRetaining:Z
    0046: const/4 v0, 0
    0047: iput v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mStarted:Z
    0049: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    004b: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    004e: move-result v0
    004f: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0051: move(op=01) v1, v0
    0052: if-ltz v1, 0042
    0054: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0056: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0059: move-result-object v0
    005a: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    005c: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->retain()V
    005f: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    0061: move(op=01) v1, v0
    0062: goto 0052

  [Virtual Method] doStart() -> V
    // registers=5, ins=1, outs=3, insns_size=96
    0000: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0002: if-eqz v0, 001c
    0004: const-string v0, 'LoaderManager'
    0006: new-instance v1, Ljava/lang/StringBuilder;
    0008: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v2, 'Starting in '
    000d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v1
    0011: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0018: move-result-object v1
    0019: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001c: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mStarted:Z
    001e: if-eqz v0, 0043
    0020: new-instance v0, Ljava/lang/RuntimeException;
    0022: const-string v1, 'here'
    0024: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    0027: invoke-virtual {v0}, Ljava/lang/RuntimeException;->fillInStackTrace()Ljava/lang/Throwable;
    002a: const-string v1, 'LoaderManager'
    002c: new-instance v2, Ljava/lang/StringBuilder;
    002e: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0031: const-string v3, 'Called doStart when already started: '
    0033: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0036: move-result-object v2
    0037: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    003a: move-result-object v2
    003b: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    003e: move-result-object v2
    003f: invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    0042: return-void
    0043: const/4 v0, 1
    0044: iput v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mStarted:Z
    0046: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0048: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    004b: move-result v0
    004c: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    004e: move(op=01) v1, v0
    004f: if-ltz v1, 0042
    0051: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0053: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0056: move-result-object v0
    0057: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0059: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->start()V
    005c: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    005e: move(op=01) v1, v0
    005f: goto 004f

  [Virtual Method] doStop() -> V
    // registers=5, ins=1, outs=3, insns_size=97
    0000: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0002: if-eqz v0, 001c
    0004: const-string v0, 'LoaderManager'
    0006: new-instance v1, Ljava/lang/StringBuilder;
    0008: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v2, 'Stopping in '
    000d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v1
    0011: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0018: move-result-object v1
    0019: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    001c: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mStarted:Z
    001e: if-nez v0, 0043
    0020: new-instance v0, Ljava/lang/RuntimeException;
    0022: const-string v1, 'here'
    0024: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    0027: invoke-virtual {v0}, Ljava/lang/RuntimeException;->fillInStackTrace()Ljava/lang/Throwable;
    002a: const-string v1, 'LoaderManager'
    002c: new-instance v2, Ljava/lang/StringBuilder;
    002e: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0031: const-string v3, 'Called doStop when not started: '
    0033: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0036: move-result-object v2
    0037: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    003a: move-result-object v2
    003b: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    003e: move-result-object v2
    003f: invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    0042: return-void
    0043: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0045: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    0048: move-result v0
    0049: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    004b: move(op=01) v1, v0
    004c: if-ltz v1, 005d
    004e: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0050: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0053: move-result-object v0
    0054: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0056: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->stop()V
    0059: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    005b: move(op=01) v1, v0
    005c: goto 004c
    005d: const/4 v0, 0
    005e: iput v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mStarted:Z
    0060: goto 0042

  [Virtual Method] dump(Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V
    // registers=10, ins=5, outs=5, insns_size=176
    0000: const/4 v2, 0
    0001: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0003: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    0006: move-result v0
    0007: if-lez v0, 0059
    0009: invoke-virtual {v8, v6}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    000c: const-string v0, 'Active Loaders:'
    000e: invoke-virtual {v8, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0011: new-instance v0, Ljava/lang/StringBuilder;
    0013: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0016: invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0019: move-result-object v0
    001a: const-string v1, '    '
    001c: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001f: move-result-object v0
    0020: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0023: move-result-object v3
    0024: move(op=01) v1, v2
    0025: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0027: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    002a: move-result v0
    002b: if-ge v1, v0, 0059
    002d: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    002f: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0032: move-result-object v0
    0033: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0035: invoke-virtual {v8, v6}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0038: const-string v4, '  #'
    003a: invoke-virtual {v8, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    003d: iget v4, v5.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    003f: invoke-virtual {v4, v1}, Landroid/support/v4/util/SparseArrayCompat;->keyAt(I)I
    0042: move-result v4
    0043: invoke-virtual {v8, v4}, Ljava/io/PrintWriter;->print(I)V
    0046: const-string v4, ': '
    0048: invoke-virtual {v8, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    004b: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->toString()Ljava/lang/String;
    004e: move-result-object v4
    004f: invoke-virtual {v8, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0052: invoke-virtual {v0, v3, v7, v8, v9}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    0055: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0057: move(op=01) v1, v0
    0058: goto 0025
    0059: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    005b: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    005e: move-result v0
    005f: if-lez v0, 00af
    0061: invoke-virtual {v8, v6}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0064: const-string v0, 'Inactive Loaders:'
    0066: invoke-virtual {v8, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0069: new-instance v0, Ljava/lang/StringBuilder;
    006b: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    006e: invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0071: move-result-object v0
    0072: const-string v1, '    '
    0074: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0077: move-result-object v0
    0078: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    007b: move-result-object v1
    007c: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    007e: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    0081: move-result v0
    0082: if-ge v2, v0, 00af
    0084: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0086: invoke-virtual {v0, v2}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0089: move-result-object v0
    008a: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    008c: invoke-virtual {v8, v6}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    008f: const-string v3, '  #'
    0091: invoke-virtual {v8, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0094: iget v3, v5.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0096: invoke-virtual {v3, v2}, Landroid/support/v4/util/SparseArrayCompat;->keyAt(I)I
    0099: move-result v3
    009a: invoke-virtual {v8, v3}, Ljava/io/PrintWriter;->print(I)V
    009d: const-string v3, ': '
    009f: invoke-virtual {v8, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00a2: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->toString()Ljava/lang/String;
    00a5: move-result-object v3
    00a6: invoke-virtual {v8, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    00a9: invoke-virtual {v0, v1, v7, v8, v9}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    00ac: binop/lit8(op=d8) v2, v2, 1 (0x1)
    00ae: goto 007c
    00af: return-void

  [Virtual Method] finishRetain() -> V
    // registers=4, ins=1, outs=2, insns_size=62
    0000: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mRetaining:Z
    0002: if-eqz v0, 003d
    0004: sget v0, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0006: if-eqz v0, 0020
    0008: const-string v0, 'LoaderManager'
    000a: new-instance v1, Ljava/lang/StringBuilder;
    000c: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000f: const-string v2, 'Finished Retaining in '
    0011: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0018: move-result-object v1
    0019: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001c: move-result-object v1
    001d: invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0020: const/4 v0, 0
    0021: iput v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mRetaining:Z
    0023: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0025: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    0028: move-result v0
    0029: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    002b: move(op=01) v1, v0
    002c: if-ltz v1, 003d
    002e: iget v0, v3.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0030: invoke-virtual {v0, v1}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0033: move-result-object v0
    0034: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0036: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->finishRetain()V
    0039: binop/lit8(op=d8) v0, v1, -1 (-0x1)
    003b: move(op=01) v1, v0
    003c: goto 002c
    003d: return-void

  [Virtual Method] getLoader(I) -> Landroid/support/v4/content/Loader;
    // registers=4, ins=2, outs=2, insns_size=36
    0000: iget v0, v2.Landroid/support/v4/app/LoaderManagerImpl;->mCreatingLoader:Z
    0002: if-eqz v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'Called while creating a loader'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: iget v0, v2.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    000e: invoke-virtual {v0, v3}, Landroid/support/v4/util/SparseArrayCompat;->get(I)Ljava/lang/Object;
    0011: move-result-object v0
    0012: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0014: if-eqz v0, 0022
    0016: iget v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0018: if-eqz v1, 001f
    001a: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    001c: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    001e: return-object v0
    001f: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0021: goto 001e
    0022: const/4 v0, 0
    0023: goto 001e

  [Virtual Method] hasRunningLoaders() -> Z
    // registers=7, ins=1, outs=2, insns_size=36
    0000: const/4 v1, 0
    0001: iget v0, v6.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0003: invoke-virtual {v0}, Landroid/support/v4/util/SparseArrayCompat;->size()I
    0006: move-result v4
    0007: move(op=01) v2, v1
    0008: move(op=01) v3, v1
    0009: if-ge v2, v4, 0023
    000b: iget v0, v6.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    000d: invoke-virtual {v0, v2}, Landroid/support/v4/util/SparseArrayCompat;->valueAt(I)Ljava/lang/Object;
    0010: move-result-object v0
    0011: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0013: iget v5, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    0015: if-eqz v5, 0021
    0017: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mDeliveredData:Z
    0019: if-nez v0, 0021
    001b: const/4 v0, 1
    001c: binop/2addr(op=b6) v3, v0
    001d: binop/lit8(op=d8) v0, v2, 1 (0x1)
    001f: move(op=01) v2, v0
    0020: goto 0009
    0021: move(op=01) v0, v1
    0022: goto 001c
    0023: return v3

  [Virtual Method] initLoader(I, Landroid/os/Bundle;, Landroid/support/v4/app/LoaderManager$LoaderCallbacks;) -> Landroid/support/v4/content/Loader;
    // registers=8, ins=4, outs=4, insns_size=141
    0000: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mCreatingLoader:Z
    0002: if-eqz v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'Called while creating a loader'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: iget v0, v4.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    000e: invoke-virtual {v0, v5}, Landroid/support/v4/util/SparseArrayCompat;->get(I)Ljava/lang/Object;
    0011: move-result-object v0
    0012: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0014: sget v1, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0016: if-eqz v1, 003a
    0018: const-string v1, 'LoaderManager'
    001a: new-instance v2, Ljava/lang/StringBuilder;
    001c: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    001f: const-string v3, 'initLoader in '
    0021: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0024: move-result-object v2
    0025: invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0028: move-result-object v2
    0029: const-string v3, ': args='
    002b: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002e: move-result-object v2
    002f: invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0032: move-result-object v2
    0033: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0036: move-result-object v2
    0037: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    003a: if-nez v0, 006e
    003c: invoke-direct {v4, v5, v6, v7}, Landroid/support/v4/app/LoaderManagerImpl;->createAndInstallLoader(ILandroid/os/Bundle;Landroid/support/v4/app/LoaderManager$LoaderCallbacks;)Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    003f: move-result-object v0
    0040: sget v1, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0042: if-eqz v1, 005c
    0044: const-string v1, 'LoaderManager'
    0046: new-instance v2, Ljava/lang/StringBuilder;
    0048: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    004b: const-string v3, '  Created new loader '
    004d: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0050: move-result-object v2
    0051: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0054: move-result-object v2
    0055: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0058: move-result-object v2
    0059: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    005c: iget v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mHaveData:Z
    005e: if-eqz v1, 006b
    0060: iget v1, v4.Landroid/support/v4/app/LoaderManagerImpl;->mStarted:Z
    0062: if-eqz v1, 006b
    0064: iget v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    0066: iget v2, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mData:Ljava/lang/Object;
    0068: invoke-virtual {v0, v1, v2}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->callOnLoadFinished(Landroid/support/v4/content/Loader;Ljava/lang/Object;)V
    006b: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    006d: return-object v0
    006e: sget v1, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0070: if-eqz v1, 008a
    0072: const-string v1, 'LoaderManager'
    0074: new-instance v2, Ljava/lang/StringBuilder;
    0076: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0079: const-string v3, '  Re-using existing loader '
    007b: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    007e: move-result-object v2
    007f: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0082: move-result-object v2
    0083: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0086: move-result-object v2
    0087: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    008a: iput v7, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mCallbacks:Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    008c: goto 005c

  [Virtual Method] installLoader(Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;) -> V
    // registers=4, ins=2, outs=3, insns_size=15
    0000: iget v0, v2.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0002: iget v1, v3.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mId:I
    0004: invoke-virtual {v0, v1, v3}, Landroid/support/v4/util/SparseArrayCompat;->put(ILjava/lang/Object;)V
    0007: iget v0, v2.Landroid/support/v4/app/LoaderManagerImpl;->mStarted:Z
    0009: if-eqz v0, 000e
    000b: invoke-virtual {v3}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->start()V
    000e: return-void

  [Virtual Method] restartLoader(I, Landroid/os/Bundle;, Landroid/support/v4/app/LoaderManager$LoaderCallbacks;) -> Landroid/support/v4/content/Loader;
    // registers=9, ins=4, outs=4, insns_size=253
    0000: const/4 v4, 0
    0001: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl;->mCreatingLoader:Z
    0003: if-eqz v0, 000d
    0005: new-instance v0, Ljava/lang/IllegalStateException;
    0007: const-string v1, 'Called while creating a loader'
    0009: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000c: throw v0
    000d: iget v0, v5.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    000f: invoke-virtual {v0, v6}, Landroid/support/v4/util/SparseArrayCompat;->get(I)Ljava/lang/Object;
    0012: move-result-object v0
    0013: check-cast v0, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0015: sget v1, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0017: if-eqz v1, 003b
    0019: const-string v1, 'LoaderManager'
    001b: new-instance v2, Ljava/lang/StringBuilder;
    001d: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0020: const-string v3, 'restartLoader in '
    0022: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0025: move-result-object v2
    0026: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0029: move-result-object v2
    002a: const-string v3, ': args='
    002c: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002f: move-result-object v2
    0030: invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0033: move-result-object v2
    0034: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0037: move-result-object v2
    0038: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    003b: if-eqz v0, 0077
    003d: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    003f: invoke-virtual {v1, v6}, Landroid/support/v4/util/SparseArrayCompat;->get(I)Ljava/lang/Object;
    0042: move-result-object v1
    0043: check-cast v1, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0045: if-eqz v1, 00d5
    0047: iget v2, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mHaveData:Z
    0049: if-eqz v2, 007e
    004b: sget v2, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    004d: if-eqz v2, 0067
    004f: const-string v2, 'LoaderManager'
    0051: new-instance v3, Ljava/lang/StringBuilder;
    0053: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    0056: const-string v4, '  Removing last inactive loader: '
    0058: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    005b: move-result-object v3
    005c: invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    005f: move-result-object v3
    0060: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0063: move-result-object v3
    0064: invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    0067: const/4 v2, 0
    0068: iput v2, v1.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mDeliveredData:Z
    006a: invoke-virtual {v1}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->destroy()V
    006d: iget v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    006f: invoke-virtual {v1}, Landroid/support/v4/content/Loader;->abandon()V
    0072: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    0074: invoke-virtual {v1, v6, v0}, Landroid/support/v4/util/SparseArrayCompat;->put(ILjava/lang/Object;)V
    0077: invoke-direct {v5, v6, v7, v8}, Landroid/support/v4/app/LoaderManagerImpl;->createAndInstallLoader(ILandroid/os/Bundle;Landroid/support/v4/app/LoaderManager$LoaderCallbacks;)Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    007a: move-result-object v0
    007b: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    007d: return-object v0
    007e: iget v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mStarted:Z
    0080: if-nez v1, 0096
    0082: sget v1, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    0084: if-eqz v1, 008d
    0086: const-string v1, 'LoaderManager'
    0088: const-string v2, '  Current loader is stopped; replacing'
    008a: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    008d: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl;->mLoaders:Landroid/support/v4/util/SparseArrayCompat;
    008f: invoke-virtual {v1, v6, v4}, Landroid/support/v4/util/SparseArrayCompat;->put(ILjava/lang/Object;)V
    0092: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->destroy()V
    0095: goto 0077
    0096: iget v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    0098: if-eqz v1, 00bf
    009a: sget v1, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    009c: if-eqz v1, 00b8
    009e: const-string v1, 'LoaderManager'
    00a0: new-instance v2, Ljava/lang/StringBuilder;
    00a2: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    00a5: const-string v3, '  Removing pending loader: '
    00a7: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00aa: move-result-object v2
    00ab: iget v3, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    00ad: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00b0: move-result-object v2
    00b1: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00b4: move-result-object v2
    00b5: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00b8: iget v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    00ba: invoke-virtual {v1}, Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->destroy()V
    00bd: iput v4, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    00bf: sget v1, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    00c1: if-eqz v1, 00ca
    00c3: const-string v1, 'LoaderManager'
    00c5: const-string v2, '  Enqueuing as new pending loader'
    00c7: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00ca: invoke-direct {v5, v6, v7, v8}, Landroid/support/v4/app/LoaderManagerImpl;->createLoader(ILandroid/os/Bundle;Landroid/support/v4/app/LoaderManager$LoaderCallbacks;)Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    00cd: move-result-object v1
    00ce: iput v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    00d0: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mPendingLoader:Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;
    00d2: iget v0, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    00d4: goto 007d
    00d5: sget v1, Landroid/support/v4/app/LoaderManagerImpl;->DEBUG:Z
    00d7: if-eqz v1, 00f1
    00d9: const-string v1, 'LoaderManager'
    00db: new-instance v2, Ljava/lang/StringBuilder;
    00dd: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    00e0: const-string v3, '  Making last loader inactive: '
    00e2: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    00e5: move-result-object v2
    00e6: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    00e9: move-result-object v2
    00ea: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    00ed: move-result-object v2
    00ee: invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I
    00f1: iget v1, v0.Landroid/support/v4/app/LoaderManagerImpl$LoaderInfo;->mLoader:Landroid/support/v4/content/Loader;
    00f3: invoke-virtual {v1}, Landroid/support/v4/content/Loader;->abandon()V
    00f6: iget v1, v5.Landroid/support/v4/app/LoaderManagerImpl;->mInactiveLoaders:Landroid/support/v4/util/SparseArrayCompat;
    00f8: invoke-virtual {v1, v6, v0}, Landroid/support/v4/util/SparseArrayCompat;->put(ILjava/lang/Object;)V
    00fb: goto/16 0077

  [Virtual Method] toString() -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=43
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: const/16 v1, 128 (0x80)
    0004: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V
    0007: const-string v1, 'LoaderManager{'
    0009: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000c: invoke-static {v2}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I
    000f: move-result v1
    0010: invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0013: move-result-object v1
    0014: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0017: const-string v1, ' in '
    0019: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: iget v1, v2.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    001e: invoke-static {v1, v0}, Landroid/support/v4/util/DebugUtils;->buildShortClassTag(Ljava/lang/Object;Ljava/lang/StringBuilder;)V
    0021: const-string v1, '}}'
    0023: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0026: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0029: move-result-object v0
    002a: return-object v0

  [Virtual Method] updateActivity(Landroid/support/v4/app/FragmentActivity;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/LoaderManagerImpl;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0002: return-void