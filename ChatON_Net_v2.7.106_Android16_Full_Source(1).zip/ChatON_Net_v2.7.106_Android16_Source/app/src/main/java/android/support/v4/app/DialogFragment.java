=== CLASS Landroid/support/v4/app/DialogFragment; (Source: DialogFragment.java) ===
  Super: Landroid/support/v4/app/Fragment;
  Interfaces: Landroid/content/DialogInterface$OnCancelListener;, Landroid/content/DialogInterface$OnDismissListener;
  [Static Field] SAVED_BACK_STACK_ID: Ljava/lang/String; = 'android:backStackId'
  [Static Field] SAVED_CANCELABLE: Ljava/lang/String; = 'android:cancelable'
  [Static Field] SAVED_DIALOG_STATE_TAG: Ljava/lang/String; = 'android:savedDialogState'
  [Static Field] SAVED_SHOWS_DIALOG: Ljava/lang/String; = 'android:showsDialog'
  [Static Field] SAVED_STYLE: Ljava/lang/String; = 'android:style'
  [Static Field] SAVED_THEME: Ljava/lang/String; = 'android:theme'
  [Static Field] STYLE_NORMAL: I = 0
  [Static Field] STYLE_NO_FRAME: I = 2
  [Static Field] STYLE_NO_INPUT: I = 3
  [Static Field] STYLE_NO_TITLE: I = 1
  [Instance Field] mBackStackId: I
  [Instance Field] mCancelable: Z
  [Instance Field] mDialog: Landroid/app/Dialog;
  [Instance Field] mDismissed: Z
  [Instance Field] mShownByMe: Z
  [Instance Field] mShowsDialog: Z
  [Instance Field] mStyle: I
  [Instance Field] mTheme: I
  [Instance Field] mViewDestroyed: Z

  [Direct Method] <init>() -> V
    // registers=3, ins=1, outs=1, insns_size=17
    0000: const/4 v1, 1
    0001: const/4 v0, 0
    0002: invoke-direct {v2}, Landroid/support/v4/app/Fragment;-><init>()V
    0005: iput v0, v2.Landroid/support/v4/app/DialogFragment;->mStyle:I
    0007: iput v0, v2.Landroid/support/v4/app/DialogFragment;->mTheme:I
    0009: iput v1, v2.Landroid/support/v4/app/DialogFragment;->mCancelable:Z
    000b: iput v1, v2.Landroid/support/v4/app/DialogFragment;->mShowsDialog:Z
    000d: const/4 v0, -1
    000e: iput v0, v2.Landroid/support/v4/app/DialogFragment;->mBackStackId:I
    0010: return-void

  [Virtual Method] dismiss() -> V
    // registers=2, ins=1, outs=2, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v0}, Landroid/support/v4/app/DialogFragment;->dismissInternal(Z)V
    0004: return-void

  [Virtual Method] dismissAllowingStateLoss() -> V
    // registers=2, ins=1, outs=2, insns_size=5
    0000: const/4 v0, 1
    0001: invoke-virtual {v1, v0}, Landroid/support/v4/app/DialogFragment;->dismissInternal(Z)V
    0004: return-void

  [Virtual Method] dismissInternal(Z) -> V
    // registers=5, ins=2, outs=3, insns_size=63
    0000: const/4 v2, 1
    0001: iget v0, v3.Landroid/support/v4/app/DialogFragment;->mDismissed:Z
    0003: if-eqz v0, 0006
    0005: return-void
    0006: iput v2, v3.Landroid/support/v4/app/DialogFragment;->mDismissed:Z
    0008: const/4 v0, 0
    0009: iput v0, v3.Landroid/support/v4/app/DialogFragment;->mShownByMe:Z
    000b: iget v0, v3.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    000d: if-eqz v0, 0017
    000f: iget v0, v3.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0011: invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V
    0014: const/4 v0, 0
    0015: iput v0, v3.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0017: iput v2, v3.Landroid/support/v4/app/DialogFragment;->mViewDestroyed:Z
    0019: iget v0, v3.Landroid/support/v4/app/DialogFragment;->mBackStackId:I
    001b: if-ltz v0, 002a
    001d: invoke-virtual {v3}, Landroid/support/v4/app/DialogFragment;->getFragmentManager()Landroid/support/v4/app/FragmentManager;
    0020: move-result-object v0
    0021: iget v1, v3.Landroid/support/v4/app/DialogFragment;->mBackStackId:I
    0023: invoke-virtual {v0, v1, v2}, Landroid/support/v4/app/FragmentManager;->popBackStack(II)V
    0026: const/4 v0, -1
    0027: iput v0, v3.Landroid/support/v4/app/DialogFragment;->mBackStackId:I
    0029: goto 0005
    002a: invoke-virtual {v3}, Landroid/support/v4/app/DialogFragment;->getFragmentManager()Landroid/support/v4/app/FragmentManager;
    002d: move-result-object v0
    002e: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManager;->beginTransaction()Landroid/support/v4/app/FragmentTransaction;
    0031: move-result-object v0
    0032: invoke-virtual {v0, v3}, Landroid/support/v4/app/FragmentTransaction;->remove(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/FragmentTransaction;
    0035: if-eqz v4, 003b
    0037: invoke-virtual {v0}, Landroid/support/v4/app/FragmentTransaction;->commitAllowingStateLoss()I
    003a: goto 0005
    003b: invoke-virtual {v0}, Landroid/support/v4/app/FragmentTransaction;->commit()I
    003e: goto 0005

  [Virtual Method] getDialog() -> Landroid/app/Dialog;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0002: return-object v0

  [Virtual Method] getLayoutInflater(Landroid/os/Bundle;) -> Landroid/view/LayoutInflater;
    // registers=4, ins=2, outs=2, insns_size=78
    0000: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mShowsDialog:Z
    0002: if-nez v0, 0009
    0004: invoke-super {v2, v3}, Landroid/support/v4/app/Fragment;->getLayoutInflater(Landroid/os/Bundle;)Landroid/view/LayoutInflater;
    0007: move-result-object v0
    0008: return-object v0
    0009: invoke-virtual {v2, v3}, Landroid/support/v4/app/DialogFragment;->onCreateDialog(Landroid/os/Bundle;)Landroid/app/Dialog;
    000c: move-result-object v0
    000d: iput v0, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    000f: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mStyle:I
    0011: packed-switch v0, +51 (-> 0044)
    0014: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0016: if-eqz v0, 0039
    0018: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    001a: invoke-virtual {v0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;
    001d: move-result-object v0
    001e: const-string v1, 'layout_inflater'
    0020: invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    0023: move-result-object v0
    0024: check-cast v0, Landroid/view/LayoutInflater;
    0026: goto 0008
    0027: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0029: invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;
    002c: move-result-object v0
    002d: const/16 v1, 24 (0x18)
    002f: invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V
    0032: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0034: const/4 v1, 1
    0035: invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z
    0038: goto 0014
    0039: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    003b: const-string v1, 'layout_inflater'
    003d: invoke-virtual {v0, v1}, Landroid/support/v4/app/FragmentActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    0040: move-result-object v0
    0041: check-cast v0, Landroid/view/LayoutInflater;
    0043: goto 0008
    0044: packed-switch-payload first=1 targets=[33, 33, 22]

  [Virtual Method] getShowsDialog() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mShowsDialog:Z
    0002: return v0

  [Virtual Method] getTheme() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mTheme:I
    0002: return v0

  [Virtual Method] isCancelable() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mCancelable:Z
    0002: return v0

  [Virtual Method] onActivityCreated(Landroid/os/Bundle;) -> V
    // registers=4, ins=2, outs=2, insns_size=75
    0000: invoke-super {v2, v3}, Landroid/support/v4/app/Fragment;->onActivityCreated(Landroid/os/Bundle;)V
    0003: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mShowsDialog:Z
    0005: if-nez v0, 0008
    0007: return-void
    0008: invoke-virtual {v2}, Landroid/support/v4/app/DialogFragment;->getView()Landroid/view/View;
    000b: move-result-object v0
    000c: if-eqz v0, 0021
    000e: invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    0011: move-result-object v1
    0012: if-eqz v1, 001c
    0014: new-instance v0, Ljava/lang/IllegalStateException;
    0016: const-string v1, 'DialogFragment can not be attached to a container view'
    0018: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    001b: throw v0
    001c: iget v1, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    001e: invoke-virtual {v1, v0}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V
    0021: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0023: invoke-virtual {v2}, Landroid/support/v4/app/DialogFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0026: move-result-object v1
    0027: invoke-virtual {v0, v1}, Landroid/app/Dialog;->setOwnerActivity(Landroid/app/Activity;)V
    002a: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    002c: iget v1, v2.Landroid/support/v4/app/DialogFragment;->mCancelable:Z
    002e: invoke-virtual {v0, v1}, Landroid/app/Dialog;->setCancelable(Z)V
    0031: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0033: invoke-virtual {v0, v2}, Landroid/app/Dialog;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)V
    0036: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0038: invoke-virtual {v0, v2}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V
    003b: if-eqz v3, 0007
    003d: const-string v0, 'android:savedDialogState'
    003f: invoke-virtual {v3, v0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;
    0042: move-result-object v0
    0043: if-eqz v0, 0007
    0045: iget v1, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0047: invoke-virtual {v1, v0}, Landroid/app/Dialog;->onRestoreInstanceState(Landroid/os/Bundle;)V
    004a: goto 0007

  [Virtual Method] onAttach(Landroid/app/Activity;) -> V
    // registers=3, ins=2, outs=2, insns_size=11
    0000: invoke-super {v1, v2}, Landroid/support/v4/app/Fragment;->onAttach(Landroid/app/Activity;)V
    0003: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mShownByMe:Z
    0005: if-nez v0, 000a
    0007: const/4 v0, 0
    0008: iput v0, v1.Landroid/support/v4/app/DialogFragment;->mDismissed:Z
    000a: return-void

  [Virtual Method] onCancel(Landroid/content/DialogInterface;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=5, ins=2, outs=3, insns_size=60
    0000: const/4 v1, 1
    0001: const/4 v2, 0
    0002: invoke-super {v3, v4}, Landroid/support/v4/app/Fragment;->onCreate(Landroid/os/Bundle;)V
    0005: iget v0, v3.Landroid/support/v4/app/DialogFragment;->mContainerId:I
    0007: if-nez v0, 003a
    0009: move(op=01) v0, v1
    000a: iput v0, v3.Landroid/support/v4/app/DialogFragment;->mShowsDialog:Z
    000c: if-eqz v4, 0039
    000e: const-string v0, 'android:style'
    0010: invoke-virtual {v4, v0, v2}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I
    0013: move-result v0
    0014: iput v0, v3.Landroid/support/v4/app/DialogFragment;->mStyle:I
    0016: const-string v0, 'android:theme'
    0018: invoke-virtual {v4, v0, v2}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I
    001b: move-result v0
    001c: iput v0, v3.Landroid/support/v4/app/DialogFragment;->mTheme:I
    001e: const-string v0, 'android:cancelable'
    0020: invoke-virtual {v4, v0, v1}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z
    0023: move-result v0
    0024: iput v0, v3.Landroid/support/v4/app/DialogFragment;->mCancelable:Z
    0026: const-string v0, 'android:showsDialog'
    0028: iget v1, v3.Landroid/support/v4/app/DialogFragment;->mShowsDialog:Z
    002a: invoke-virtual {v4, v0, v1}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z
    002d: move-result v0
    002e: iput v0, v3.Landroid/support/v4/app/DialogFragment;->mShowsDialog:Z
    0030: const-string v0, 'android:backStackId'
    0032: const/4 v1, -1
    0033: invoke-virtual {v4, v0, v1}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I
    0036: move-result v0
    0037: iput v0, v3.Landroid/support/v4/app/DialogFragment;->mBackStackId:I
    0039: return-void
    003a: move(op=01) v0, v2
    003b: goto 000a

  [Virtual Method] onCreateDialog(Landroid/os/Bundle;) -> Landroid/app/Dialog;
    // registers=5, ins=2, outs=3, insns_size=14
    0000: new-instance v0, Landroid/app/Dialog;
    0002: invoke-virtual {v3}, Landroid/support/v4/app/DialogFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0005: move-result-object v1
    0006: invoke-virtual {v3}, Landroid/support/v4/app/DialogFragment;->getTheme()I
    0009: move-result v2
    000a: invoke-direct {v0, v1, v2}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V
    000d: return-object v0

  [Virtual Method] onDestroyView() -> V
    // registers=2, ins=1, outs=1, insns_size=19
    0000: invoke-super {v1}, Landroid/support/v4/app/Fragment;->onDestroyView()V
    0003: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0005: if-eqz v0, 0012
    0007: const/4 v0, 1
    0008: iput v0, v1.Landroid/support/v4/app/DialogFragment;->mViewDestroyed:Z
    000a: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    000c: invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V
    000f: const/4 v0, 0
    0010: iput v0, v1.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0012: return-void

  [Virtual Method] onDetach() -> V
    // registers=2, ins=1, outs=1, insns_size=15
    0000: invoke-super {v1}, Landroid/support/v4/app/Fragment;->onDetach()V
    0003: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mShownByMe:Z
    0005: if-nez v0, 000e
    0007: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mDismissed:Z
    0009: if-nez v0, 000e
    000b: const/4 v0, 1
    000c: iput v0, v1.Landroid/support/v4/app/DialogFragment;->mDismissed:Z
    000e: return-void

  [Virtual Method] onDismiss(Landroid/content/DialogInterface;) -> V
    // registers=3, ins=2, outs=2, insns_size=9
    0000: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mViewDestroyed:Z
    0002: if-nez v0, 0008
    0004: const/4 v0, 1
    0005: invoke-virtual {v1, v0}, Landroid/support/v4/app/DialogFragment;->dismissInternal(Z)V
    0008: return-void

  [Virtual Method] onSaveInstanceState(Landroid/os/Bundle;) -> V
    // registers=4, ins=2, outs=3, insns_size=77
    0000: invoke-super {v2, v3}, Landroid/support/v4/app/Fragment;->onSaveInstanceState(Landroid/os/Bundle;)V
    0003: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0005: if-eqz v0, 0014
    0007: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0009: invoke-virtual {v0}, Landroid/app/Dialog;->onSaveInstanceState()Landroid/os/Bundle;
    000c: move-result-object v0
    000d: if-eqz v0, 0014
    000f: const-string v1, 'android:savedDialogState'
    0011: invoke-virtual {v3, v1, v0}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V
    0014: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mStyle:I
    0016: if-eqz v0, 001f
    0018: const-string v0, 'android:style'
    001a: iget v1, v2.Landroid/support/v4/app/DialogFragment;->mStyle:I
    001c: invoke-virtual {v3, v0, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V
    001f: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mTheme:I
    0021: if-eqz v0, 002a
    0023: const-string v0, 'android:theme'
    0025: iget v1, v2.Landroid/support/v4/app/DialogFragment;->mTheme:I
    0027: invoke-virtual {v3, v0, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V
    002a: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mCancelable:Z
    002c: if-nez v0, 0035
    002e: const-string v0, 'android:cancelable'
    0030: iget v1, v2.Landroid/support/v4/app/DialogFragment;->mCancelable:Z
    0032: invoke-virtual {v3, v0, v1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V
    0035: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mShowsDialog:Z
    0037: if-nez v0, 0040
    0039: const-string v0, 'android:showsDialog'
    003b: iget v1, v2.Landroid/support/v4/app/DialogFragment;->mShowsDialog:Z
    003d: invoke-virtual {v3, v0, v1}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V
    0040: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mBackStackId:I
    0042: const/4 v1, -1
    0043: if-eq v0, v1, 004c
    0045: const-string v0, 'android:backStackId'
    0047: iget v1, v2.Landroid/support/v4/app/DialogFragment;->mBackStackId:I
    0049: invoke-virtual {v3, v0, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V
    004c: return-void

  [Virtual Method] onStart() -> V
    // registers=2, ins=1, outs=1, insns_size=16
    0000: invoke-super {v1}, Landroid/support/v4/app/Fragment;->onStart()V
    0003: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0005: if-eqz v0, 000f
    0007: const/4 v0, 0
    0008: iput v0, v1.Landroid/support/v4/app/DialogFragment;->mViewDestroyed:Z
    000a: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    000c: invoke-virtual {v0}, Landroid/app/Dialog;->show()V
    000f: return-void

  [Virtual Method] onStop() -> V
    // registers=2, ins=1, outs=1, insns_size=13
    0000: invoke-super {v1}, Landroid/support/v4/app/Fragment;->onStop()V
    0003: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0005: if-eqz v0, 000c
    0007: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0009: invoke-virtual {v0}, Landroid/app/Dialog;->hide()V
    000c: return-void

  [Virtual Method] setCancelable(Z) -> V
    // registers=3, ins=2, outs=2, insns_size=12
    0000: iput v2, v1.Landroid/support/v4/app/DialogFragment;->mCancelable:Z
    0002: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0004: if-eqz v0, 000b
    0006: iget v0, v1.Landroid/support/v4/app/DialogFragment;->mDialog:Landroid/app/Dialog;
    0008: invoke-virtual {v0, v2}, Landroid/app/Dialog;->setCancelable(Z)V
    000b: return-void

  [Virtual Method] setShowsDialog(Z) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/DialogFragment;->mShowsDialog:Z
    0002: return-void

  [Virtual Method] setStyle(I, I) -> V
    // registers=5, ins=3, outs=0, insns_size=22
    0000: iput v3, v2.Landroid/support/v4/app/DialogFragment;->mStyle:I
    0002: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mStyle:I
    0004: const/4 v1, 2
    0005: if-eq v0, v1, 000c
    0007: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mStyle:I
    0009: const/4 v1, 3
    000a: if-ne v0, v1, 0011
    000c: const v0, 16973913 (0x1030059)
    000f: iput v0, v2.Landroid/support/v4/app/DialogFragment;->mTheme:I
    0011: if-eqz v4, 0015
    0013: iput v4, v2.Landroid/support/v4/app/DialogFragment;->mTheme:I
    0015: return-void

  [Virtual Method] show(Landroid/support/v4/app/FragmentTransaction;, Ljava/lang/String;) -> I
    // registers=5, ins=3, outs=3, insns_size=20
    0000: const/4 v1, 0
    0001: iput v1, v2.Landroid/support/v4/app/DialogFragment;->mDismissed:Z
    0003: const/4 v0, 1
    0004: iput v0, v2.Landroid/support/v4/app/DialogFragment;->mShownByMe:Z
    0006: invoke-virtual {v3, v2, v4}, Landroid/support/v4/app/FragmentTransaction;->add(Landroid/support/v4/app/Fragment;Ljava/lang/String;)Landroid/support/v4/app/FragmentTransaction;
    0009: iput v1, v2.Landroid/support/v4/app/DialogFragment;->mViewDestroyed:Z
    000b: invoke-virtual {v3}, Landroid/support/v4/app/FragmentTransaction;->commit()I
    000e: move-result v0
    000f: iput v0, v2.Landroid/support/v4/app/DialogFragment;->mBackStackId:I
    0011: iget v0, v2.Landroid/support/v4/app/DialogFragment;->mBackStackId:I
    0013: return v0

  [Virtual Method] show(Landroid/support/v4/app/FragmentManager;, Ljava/lang/String;) -> V
    // registers=4, ins=3, outs=3, insns_size=17
    0000: const/4 v0, 0
    0001: iput v0, v1.Landroid/support/v4/app/DialogFragment;->mDismissed:Z
    0003: const/4 v0, 1
    0004: iput v0, v1.Landroid/support/v4/app/DialogFragment;->mShownByMe:Z
    0006: invoke-virtual {v2}, Landroid/support/v4/app/FragmentManager;->beginTransaction()Landroid/support/v4/app/FragmentTransaction;
    0009: move-result-object v0
    000a: invoke-virtual {v0, v1, v3}, Landroid/support/v4/app/FragmentTransaction;->add(Landroid/support/v4/app/Fragment;Ljava/lang/String;)Landroid/support/v4/app/FragmentTransaction;
    000d: invoke-virtual {v0}, Landroid/support/v4/app/FragmentTransaction;->commit()I
    0010: return-void