=== CLASS Landroid/support/v4/view/MenuItemCompat; (Source: MenuItemCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] IMPL: Landroid/support/v4/view/MenuItemCompat$MenuVersionImpl; = None
  [Static Field] SHOW_AS_ACTION_ALWAYS: I = 2
  [Static Field] SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW: I = 8
  [Static Field] SHOW_AS_ACTION_IF_ROOM: I = 1
  [Static Field] SHOW_AS_ACTION_NEVER: I = 0
  [Static Field] SHOW_AS_ACTION_WITH_TEXT: I = 4

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=22
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 11 (0xb)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/view/MenuItemCompat$HoneycombMenuVersionImpl;
    0008: invoke-direct {v0}, Landroid/support/v4/view/MenuItemCompat$HoneycombMenuVersionImpl;-><init>()V
    000b: sput v0, Landroid/support/v4/view/MenuItemCompat;->IMPL:Landroid/support/v4/view/MenuItemCompat$MenuVersionImpl;
    000d: return-void
    000e: new-instance v0, Landroid/support/v4/view/MenuItemCompat$BaseMenuVersionImpl;
    0010: invoke-direct {v0}, Landroid/support/v4/view/MenuItemCompat$BaseMenuVersionImpl;-><init>()V
    0013: sput v0, Landroid/support/v4/view/MenuItemCompat;->IMPL:Landroid/support/v4/view/MenuItemCompat$MenuVersionImpl;
    0015: goto 000d

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] setActionView(Landroid/view/MenuItem;, Landroid/view/View;) -> Landroid/view/MenuItem;
    // registers=3, ins=2, outs=3, insns_size=7
    0000: sget v0, Landroid/support/v4/view/MenuItemCompat;->IMPL:Landroid/support/v4/view/MenuItemCompat$MenuVersionImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/MenuItemCompat$MenuVersionImpl;->setActionView(Landroid/view/MenuItem;Landroid/view/View;)Landroid/view/MenuItem;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] setShowAsAction(Landroid/view/MenuItem;, I) -> Z
    // registers=3, ins=2, outs=3, insns_size=7
    0000: sget v0, Landroid/support/v4/view/MenuItemCompat;->IMPL:Landroid/support/v4/view/MenuItemCompat$MenuVersionImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/MenuItemCompat$MenuVersionImpl;->setShowAsAction(Landroid/view/MenuItem;I)Z
    0005: move-result v0
    0006: return v0