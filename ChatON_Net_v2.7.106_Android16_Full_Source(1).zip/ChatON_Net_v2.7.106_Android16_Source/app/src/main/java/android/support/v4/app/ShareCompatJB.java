=== CLASS Landroid/support/v4/app/ShareCompatJB; (Source: ShareCompatJB.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] escapeHtml(Ljava/lang/CharSequence;) -> Ljava/lang/String;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-static {v1}, Landroid/text/Html;->escapeHtml(Ljava/lang/CharSequence;)Ljava/lang/String;
    0003: move-result-object v0
    0004: return-object v0