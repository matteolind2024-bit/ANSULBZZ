=== CLASS Landroid/support/v4/view/accessibility/AccessibilityEventCompat$AccessibilityEventVersionImpl; (Source: AccessibilityEventCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] appendRecord(Landroid/view/accessibility/AccessibilityEvent;, Ljava/lang/Object;) -> V

  [Virtual Method] getRecord(Landroid/view/accessibility/AccessibilityEvent;, I) -> Ljava/lang/Object;

  [Virtual Method] getRecordCount(Landroid/view/accessibility/AccessibilityEvent;) -> I