=== CLASS Landroid/support/v4/widget/SimpleCursorAdapter; (Source: SimpleCursorAdapter.java) ===
  Super: Landroid/support/v4/widget/ResourceCursorAdapter;
  [Instance Field] mCursorToStringConverter: Landroid/support/v4/widget/SimpleCursorAdapter$CursorToStringConverter;
  [Instance Field] mFrom: [I
  [Instance Field] mOriginalFrom: [Ljava/lang/String;
  [Instance Field] mStringConversionColumn: I
  [Instance Field] mTo: [I
  [Instance Field] mViewBinder: Landroid/support/v4/widget/SimpleCursorAdapter$ViewBinder;

  [Direct Method] <init>(Landroid/content/Context;, I, Landroid/database/Cursor;, [Ljava/lang/String;, [I) -> V
    // registers=7, ins=6, outs=4, insns_size=14
    0000: invoke-direct {v1, v2, v3, v4}, Landroid/support/v4/widget/ResourceCursorAdapter;-><init>(Landroid/content/Context;ILandroid/database/Cursor;)V
    0003: const/4 v0, -1
    0004: iput v0, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mStringConversionColumn:I
    0006: iput v6, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mTo:[I
    0008: iput v5, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mOriginalFrom:[Ljava/lang/String;
    000a: invoke-direct {v1, v5}, Landroid/support/v4/widget/SimpleCursorAdapter;->findColumns([Ljava/lang/String;)V
    000d: return-void

  [Direct Method] <init>(Landroid/content/Context;, I, Landroid/database/Cursor;, [Ljava/lang/String;, [I, I) -> V
    // registers=8, ins=7, outs=5, insns_size=14
    0000: invoke-direct {v1, v2, v3, v4, v7}, Landroid/support/v4/widget/ResourceCursorAdapter;-><init>(Landroid/content/Context;ILandroid/database/Cursor;I)V
    0003: const/4 v0, -1
    0004: iput v0, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mStringConversionColumn:I
    0006: iput v6, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mTo:[I
    0008: iput v5, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mOriginalFrom:[Ljava/lang/String;
    000a: invoke-direct {v1, v5}, Landroid/support/v4/widget/SimpleCursorAdapter;->findColumns([Ljava/lang/String;)V
    000d: return-void

  [Direct Method] findColumns([Ljava/lang/String;) -> V
    // registers=7, ins=2, outs=2, insns_size=40
    0000: iget v0, v5.Landroid/support/v4/widget/SimpleCursorAdapter;->mCursor:Landroid/database/Cursor;
    0002: if-eqz v0, 0024
    0004: move(op=21) v1, v6
    0005: iget v0, v5.Landroid/support/v4/widget/SimpleCursorAdapter;->mFrom:[I
    0007: if-eqz v0, 000e
    0009: iget v0, v5.Landroid/support/v4/widget/SimpleCursorAdapter;->mFrom:[I
    000b: move(op=21) v0, v0
    000c: if-eq v0, v1, 0012
    000e: new-array v0, v1, [I
    0010: iput v0, v5.Landroid/support/v4/widget/SimpleCursorAdapter;->mFrom:[I
    0012: const/4 v0, 0
    0013: if-ge v0, v1, 0027
    0015: iget v2, v5.Landroid/support/v4/widget/SimpleCursorAdapter;->mFrom:[I
    0017: iget v3, v5.Landroid/support/v4/widget/SimpleCursorAdapter;->mCursor:Landroid/database/Cursor;
    0019: aget(op=46) v4, v6[v0]
    001b: invoke-interface {v3, v4}, Landroid/database/Cursor;->getColumnIndexOrThrow(Ljava/lang/String;)I
    001e: move-result v3
    001f: aput(op=4b) v3, v2[v0]
    0021: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0023: goto 0013
    0024: const/4 v0, 0
    0025: iput v0, v5.Landroid/support/v4/widget/SimpleCursorAdapter;->mFrom:[I
    0027: return-void

  [Virtual Method] bindView(Landroid/view/View;, Landroid/content/Context;, Landroid/database/Cursor;) -> V
    // registers=13, ins=4, outs=4, insns_size=106
    0000: const/4 v2, 0
    0001: iget v4, v9.Landroid/support/v4/widget/SimpleCursorAdapter;->mViewBinder:Landroid/support/v4/widget/SimpleCursorAdapter$ViewBinder;
    0003: iget v0, v9.Landroid/support/v4/widget/SimpleCursorAdapter;->mTo:[I
    0005: move(op=21) v5, v0
    0006: iget v6, v9.Landroid/support/v4/widget/SimpleCursorAdapter;->mFrom:[I
    0008: iget v7, v9.Landroid/support/v4/widget/SimpleCursorAdapter;->mTo:[I
    000a: move(op=01) v3, v2
    000b: if-ge v3, v5, 0067
    000d: aget(op=44) v0, v7[v3]
    000f: invoke-virtual {v10, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0012: move-result-object v0
    0013: if-eqz v0, 0032
    0015: if-eqz v4, 0068
    0017: aget(op=44) v1, v6[v3]
    0019: invoke-interface {v4, v0, v12, v1}, Landroid/support/v4/widget/SimpleCursorAdapter$ViewBinder;->setViewValue(Landroid/view/View;Landroid/database/Cursor;I)Z
    001c: move-result v1
    001d: if-nez v1, 0032
    001f: aget(op=44) v1, v6[v3]
    0021: invoke-interface {v12, v1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;
    0024: move-result-object v1
    0025: if-nez v1, 0029
    0027: const-string v1, ''
    0029: instance-of v8, v0, Landroid/widget/TextView;
    002b: if-eqz v8, 0036
    002d: check-cast v0, Landroid/widget/TextView;
    002f: invoke-virtual {v9, v0, v1}, Landroid/support/v4/widget/SimpleCursorAdapter;->setViewText(Landroid/widget/TextView;Ljava/lang/String;)V
    0032: binop/lit8(op=d8) v0, v3, 1 (0x1)
    0034: move(op=01) v3, v0
    0035: goto 000b
    0036: instance-of v8, v0, Landroid/widget/ImageView;
    0038: if-eqz v8, 0040
    003a: check-cast v0, Landroid/widget/ImageView;
    003c: invoke-virtual {v9, v0, v1}, Landroid/support/v4/widget/SimpleCursorAdapter;->setViewImage(Landroid/widget/ImageView;Ljava/lang/String;)V
    003f: goto 0032
    0040: new-instance v1, Ljava/lang/IllegalStateException;
    0042: new-instance v2, Ljava/lang/StringBuilder;
    0044: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0047: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    004a: move-result-object v0
    004b: invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;
    004e: move-result-object v0
    004f: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0052: move-result-object v0
    0053: const-string v2, ' is not a '
    0055: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0058: move-result-object v0
    0059: const-string v2, ' view that can be bounds by this SimpleCursorAdapter'
    005b: invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    005e: move-result-object v0
    005f: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0062: move-result-object v0
    0063: invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0066: throw v1
    0067: return-void
    0068: move(op=01) v1, v2
    0069: goto 001d

  [Virtual Method] changeCursorAndColumns(Landroid/database/Cursor;, [Ljava/lang/String;, [I) -> V
    // registers=5, ins=4, outs=2, insns_size=13
    0000: iput v3, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mOriginalFrom:[Ljava/lang/String;
    0002: iput v4, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mTo:[I
    0004: invoke-super {v1, v2}, Landroid/support/v4/widget/ResourceCursorAdapter;->changeCursor(Landroid/database/Cursor;)V
    0007: iget v0, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mOriginalFrom:[Ljava/lang/String;
    0009: invoke-direct {v1, v0}, Landroid/support/v4/widget/SimpleCursorAdapter;->findColumns([Ljava/lang/String;)V
    000c: return-void

  [Virtual Method] convertToString(Landroid/database/Cursor;) -> Ljava/lang/CharSequence;
    // registers=4, ins=2, outs=2, insns_size=28
    0000: iget v0, v2.Landroid/support/v4/widget/SimpleCursorAdapter;->mCursorToStringConverter:Landroid/support/v4/widget/SimpleCursorAdapter$CursorToStringConverter;
    0002: if-eqz v0, 000b
    0004: iget v0, v2.Landroid/support/v4/widget/SimpleCursorAdapter;->mCursorToStringConverter:Landroid/support/v4/widget/SimpleCursorAdapter$CursorToStringConverter;
    0006: invoke-interface {v0, v3}, Landroid/support/v4/widget/SimpleCursorAdapter$CursorToStringConverter;->convertToString(Landroid/database/Cursor;)Ljava/lang/CharSequence;
    0009: move-result-object v0
    000a: return-object v0
    000b: iget v0, v2.Landroid/support/v4/widget/SimpleCursorAdapter;->mStringConversionColumn:I
    000d: const/4 v1, -1
    000e: if-le v0, v1, 0017
    0010: iget v0, v2.Landroid/support/v4/widget/SimpleCursorAdapter;->mStringConversionColumn:I
    0012: invoke-interface {v3, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;
    0015: move-result-object v0
    0016: goto 000a
    0017: invoke-super {v2, v3}, Landroid/support/v4/widget/ResourceCursorAdapter;->convertToString(Landroid/database/Cursor;)Ljava/lang/CharSequence;
    001a: move-result-object v0
    001b: goto 000a

  [Virtual Method] getCursorToStringConverter() -> Landroid/support/v4/widget/SimpleCursorAdapter$CursorToStringConverter;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mCursorToStringConverter:Landroid/support/v4/widget/SimpleCursorAdapter$CursorToStringConverter;
    0002: return-object v0

  [Virtual Method] getStringConversionColumn() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mStringConversionColumn:I
    0002: return v0

  [Virtual Method] getViewBinder() -> Landroid/support/v4/widget/SimpleCursorAdapter$ViewBinder;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/widget/SimpleCursorAdapter;->mViewBinder:Landroid/support/v4/widget/SimpleCursorAdapter$ViewBinder;
    0002: return-object v0

  [Virtual Method] setCursorToStringConverter(Landroid/support/v4/widget/SimpleCursorAdapter$CursorToStringConverter;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/widget/SimpleCursorAdapter;->mCursorToStringConverter:Landroid/support/v4/widget/SimpleCursorAdapter$CursorToStringConverter;
    0002: return-void

  [Virtual Method] setStringConversionColumn(I) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/widget/SimpleCursorAdapter;->mStringConversionColumn:I
    0002: return-void

  [Virtual Method] setViewBinder(Landroid/support/v4/widget/SimpleCursorAdapter$ViewBinder;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/widget/SimpleCursorAdapter;->mViewBinder:Landroid/support/v4/widget/SimpleCursorAdapter$ViewBinder;
    0002: return-void

  [Virtual Method] setViewImage(Landroid/widget/ImageView;, Ljava/lang/String;) -> V
    // registers=4, ins=3, outs=2, insns_size=17
    0000: invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    0003: move-result v0
    0004: invoke-virtual {v2, v0}, Landroid/widget/ImageView;->setImageResource(I)V
    0007: return-void
    0008: move-exception v0
    0009: invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;
    000c: move-result-object v0
    000d: invoke-virtual {v2, v0}, Landroid/widget/ImageView;->setImageURI(Landroid/net/Uri;)V
    0010: goto 0007

  [Virtual Method] setViewText(Landroid/widget/TextView;, Ljava/lang/String;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    0003: return-void

  [Virtual Method] swapCursor(Landroid/database/Cursor;) -> Landroid/database/Cursor;
    // registers=4, ins=2, outs=2, insns_size=10
    0000: invoke-super {v2, v3}, Landroid/support/v4/widget/ResourceCursorAdapter;->swapCursor(Landroid/database/Cursor;)Landroid/database/Cursor;
    0003: move-result-object v0
    0004: iget v1, v2.Landroid/support/v4/widget/SimpleCursorAdapter;->mOriginalFrom:[Ljava/lang/String;
    0006: invoke-direct {v2, v1}, Landroid/support/v4/widget/SimpleCursorAdapter;->findColumns([Ljava/lang/String;)V
    0009: return-object v0