=== CLASS Landroid/support/v4/app/ShareCompat; (Source: ShareCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] EXTRA_CALLING_ACTIVITY: Ljava/lang/String; = 'android.support.v4.app.EXTRA_CALLING_ACTIVITY'
  [Static Field] EXTRA_CALLING_PACKAGE: Ljava/lang/String; = 'android.support.v4.app.EXTRA_CALLING_PACKAGE'
  [Static Field] IMPL: Landroid/support/v4/app/ShareCompat$ShareCompatImpl;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=36
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 16 (0x10)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/app/ShareCompat$ShareCompatImplJB;
    0008: invoke-direct {v0}, Landroid/support/v4/app/ShareCompat$ShareCompatImplJB;-><init>()V
    000b: sput v0, Landroid/support/v4/app/ShareCompat;->IMPL:Landroid/support/v4/app/ShareCompat$ShareCompatImpl;
    000d: return-void
    000e: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0010: const/16 v1, 14 (0xe)
    0012: if-lt v0, v1, 001c
    0014: new-instance v0, Landroid/support/v4/app/ShareCompat$ShareCompatImplICS;
    0016: invoke-direct {v0}, Landroid/support/v4/app/ShareCompat$ShareCompatImplICS;-><init>()V
    0019: sput v0, Landroid/support/v4/app/ShareCompat;->IMPL:Landroid/support/v4/app/ShareCompat$ShareCompatImpl;
    001b: goto 000d
    001c: new-instance v0, Landroid/support/v4/app/ShareCompat$ShareCompatImplBase;
    001e: invoke-direct {v0}, Landroid/support/v4/app/ShareCompat$ShareCompatImplBase;-><init>()V
    0021: sput v0, Landroid/support/v4/app/ShareCompat;->IMPL:Landroid/support/v4/app/ShareCompat$ShareCompatImpl;
    0023: goto 000d

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] access$000() -> Landroid/support/v4/app/ShareCompat$ShareCompatImpl;
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Landroid/support/v4/app/ShareCompat;->IMPL:Landroid/support/v4/app/ShareCompat$ShareCompatImpl;
    0002: return-object v0

  [Direct Method] configureMenuItem(Landroid/view/Menu;, I, Landroid/support/v4/app/ShareCompat$IntentBuilder;) -> V
    // registers=6, ins=3, outs=2, insns_size=41
    0000: invoke-interface {v3, v4}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;
    0003: move-result-object v0
    0004: if-nez v0, 0025
    0006: new-instance v0, Ljava/lang/IllegalArgumentException;
    0008: new-instance v1, Ljava/lang/StringBuilder;
    000a: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000d: const-string v2, 'Could not find menu item with id '
    000f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0016: move-result-object v1
    0017: const-string v2, ' in the supplied menu'
    0019: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001c: move-result-object v1
    001d: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0020: move-result-object v1
    0021: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0024: throw v0
    0025: invoke-static {v0, v5}, Landroid/support/v4/app/ShareCompat;->configureMenuItem(Landroid/view/MenuItem;Landroid/support/v4/app/ShareCompat$IntentBuilder;)V
    0028: return-void

  [Direct Method] configureMenuItem(Landroid/view/MenuItem;, Landroid/support/v4/app/ShareCompat$IntentBuilder;) -> V
    // registers=3, ins=2, outs=3, insns_size=6
    0000: sget v0, Landroid/support/v4/app/ShareCompat;->IMPL:Landroid/support/v4/app/ShareCompat$ShareCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/app/ShareCompat$ShareCompatImpl;->configureMenuItem(Landroid/view/MenuItem;Landroid/support/v4/app/ShareCompat$IntentBuilder;)V
    0005: return-void

  [Direct Method] getCallingActivity(Landroid/app/Activity;) -> Landroid/content/ComponentName;
    // registers=3, ins=1, outs=2, insns_size=19
    0000: invoke-virtual {v2}, Landroid/app/Activity;->getCallingActivity()Landroid/content/ComponentName;
    0003: move-result-object v0
    0004: if-nez v0, 0012
    0006: invoke-virtual {v2}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;
    0009: move-result-object v0
    000a: const-string v1, 'android.support.v4.app.EXTRA_CALLING_ACTIVITY'
    000c: invoke-virtual {v0, v1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;
    000f: move-result-object v0
    0010: check-cast v0, Landroid/content/ComponentName;
    0012: return-object v0

  [Direct Method] getCallingPackage(Landroid/app/Activity;) -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=17
    0000: invoke-virtual {v2}, Landroid/app/Activity;->getCallingPackage()Ljava/lang/String;
    0003: move-result-object v0
    0004: if-nez v0, 0010
    0006: invoke-virtual {v2}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;
    0009: move-result-object v0
    000a: const-string v1, 'android.support.v4.app.EXTRA_CALLING_PACKAGE'
    000c: invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;
    000f: move-result-object v0
    0010: return-object v0