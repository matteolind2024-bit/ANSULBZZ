=== CLASS Landroid/support/v4/app/NavUtils; (Source: NavUtils.java) ===
  Super: Ljava/lang/Object;
  [Static Field] IMPL: Landroid/support/v4/app/NavUtils$NavUtilsImpl; = None
  [Static Field] PARENT_ACTIVITY: Ljava/lang/String; = 'android.support.PARENT_ACTIVITY'
  [Static Field] TAG: Ljava/lang/String; = 'NavUtils'

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=22
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 16 (0x10)
    0004: if-lt v0, v1, 000e
    0006: new-instance v0, Landroid/support/v4/app/NavUtils$NavUtilsImplJB;
    0008: invoke-direct {v0}, Landroid/support/v4/app/NavUtils$NavUtilsImplJB;-><init>()V
    000b: sput v0, Landroid/support/v4/app/NavUtils;->IMPL:Landroid/support/v4/app/NavUtils$NavUtilsImpl;
    000d: return-void
    000e: new-instance v0, Landroid/support/v4/app/NavUtils$NavUtilsImplBase;
    0010: invoke-direct {v0}, Landroid/support/v4/app/NavUtils$NavUtilsImplBase;-><init>()V
    0013: sput v0, Landroid/support/v4/app/NavUtils;->IMPL:Landroid/support/v4/app/NavUtils$NavUtilsImpl;
    0015: goto 000d

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getParentActivityIntent(Landroid/app/Activity;) -> Landroid/content/Intent;
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/app/NavUtils;->IMPL:Landroid/support/v4/app/NavUtils$NavUtilsImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/app/NavUtils$NavUtilsImpl;->getParentActivityIntent(Landroid/app/Activity;)Landroid/content/Intent;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getParentActivityIntent(Landroid/content/Context;, Landroid/content/ComponentName;) -> Landroid/content/Intent;
    // registers=5, ins=2, outs=3, insns_size=22
    0000: invoke-static {v3, v4}, Landroid/support/v4/app/NavUtils;->getParentActivityName(Landroid/content/Context;Landroid/content/ComponentName;)Ljava/lang/String;
    0003: move-result-object v0
    0004: if-nez v0, 0008
    0006: const/4 v0, 0
    0007: return-object v0
    0008: new-instance v1, Landroid/content/Intent;
    000a: invoke-direct {v1}, Landroid/content/Intent;-><init>()V
    000d: invoke-virtual {v4}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;
    0010: move-result-object v2
    0011: invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    0014: move-result-object v0
    0015: goto 0007

  [Direct Method] getParentActivityIntent(Landroid/content/Context;, Ljava/lang/Class;) -> Landroid/content/Intent;
    // registers=4, ins=2, outs=3, insns_size=23
    0000: new-instance v0, Landroid/content/ComponentName;
    0002: invoke-direct {v0, v2, v3}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V
    0005: invoke-static {v2, v0}, Landroid/support/v4/app/NavUtils;->getParentActivityName(Landroid/content/Context;Landroid/content/ComponentName;)Ljava/lang/String;
    0008: move-result-object v0
    0009: if-nez v0, 000d
    000b: const/4 v0, 0
    000c: return-object v0
    000d: new-instance v1, Landroid/content/Intent;
    000f: invoke-direct {v1}, Landroid/content/Intent;-><init>()V
    0012: invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    0015: move-result-object v0
    0016: goto 000c

  [Direct Method] getParentActivityName(Landroid/app/Activity;) -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=16
    0000: invoke-virtual {v2}, Landroid/app/Activity;->getComponentName()Landroid/content/ComponentName;
    0003: move-result-object v0
    0004: invoke-static {v2, v0}, Landroid/support/v4/app/NavUtils;->getParentActivityName(Landroid/content/Context;Landroid/content/ComponentName;)Ljava/lang/String;
    0007: move-result-object v0
    0008: return-object v0
    0009: move-exception v0
    000a: new-instance v1, Ljava/lang/IllegalArgumentException;
    000c: invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V
    000f: throw v1

  [Direct Method] getParentActivityName(Landroid/content/Context;, Landroid/content/ComponentName;) -> Ljava/lang/String;
    // registers=4, ins=2, outs=3, insns_size=17
    0000: invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    0003: move-result-object v0
    0004: const/16 v1, 128 (0x80)
    0006: invoke-virtual {v0, v3, v1}, Landroid/content/pm/PackageManager;->getActivityInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;
    0009: move-result-object v0
    000a: sget v1, Landroid/support/v4/app/NavUtils;->IMPL:Landroid/support/v4/app/NavUtils$NavUtilsImpl;
    000c: invoke-interface {v1, v2, v0}, Landroid/support/v4/app/NavUtils$NavUtilsImpl;->getParentActivityName(Landroid/content/Context;Landroid/content/pm/ActivityInfo;)Ljava/lang/String;
    000f: move-result-object v0
    0010: return-object v0

  [Direct Method] navigateUpFromSameTask(Landroid/app/Activity;) -> V
    // registers=4, ins=1, outs=2, insns_size=61
    0000: invoke-static {v3}, Landroid/support/v4/app/NavUtils;->getParentActivityIntent(Landroid/app/Activity;)Landroid/content/Intent;
    0003: move-result-object v0
    0004: if-nez v0, 0039
    0006: new-instance v0, Ljava/lang/IllegalArgumentException;
    0008: new-instance v1, Ljava/lang/StringBuilder;
    000a: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000d: const-string v2, 'Activity '
    000f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0012: move-result-object v1
    0013: invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0016: move-result-object v2
    0017: invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;
    001a: move-result-object v2
    001b: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001e: move-result-object v1
    001f: const-string v2, ' does not have a parent activity name specified.'
    0021: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0024: move-result-object v1
    0025: const-string v2, ' (Did you forget to add the android.support.PARENT_ACTIVITY <meta-data> '
    0027: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002a: move-result-object v1
    002b: const-string v2, ' element in your manifest?)'
    002d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0030: move-result-object v1
    0031: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0034: move-result-object v1
    0035: invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V
    0038: throw v0
    0039: invoke-static {v3, v0}, Landroid/support/v4/app/NavUtils;->navigateUpTo(Landroid/app/Activity;Landroid/content/Intent;)V
    003c: return-void

  [Direct Method] navigateUpTo(Landroid/app/Activity;, Landroid/content/Intent;) -> V
    // registers=3, ins=2, outs=3, insns_size=6
    0000: sget v0, Landroid/support/v4/app/NavUtils;->IMPL:Landroid/support/v4/app/NavUtils$NavUtilsImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/app/NavUtils$NavUtilsImpl;->navigateUpTo(Landroid/app/Activity;Landroid/content/Intent;)V
    0005: return-void

  [Direct Method] shouldUpRecreateTask(Landroid/app/Activity;, Landroid/content/Intent;) -> Z
    // registers=3, ins=2, outs=3, insns_size=7
    0000: sget v0, Landroid/support/v4/app/NavUtils;->IMPL:Landroid/support/v4/app/NavUtils$NavUtilsImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/app/NavUtils$NavUtilsImpl;->shouldUpRecreateTask(Landroid/app/Activity;Landroid/content/Intent;)Z
    0005: move-result v0
    0006: return v0