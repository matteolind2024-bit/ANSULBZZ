=== CLASS Landroid/support/v4/content/CursorLoader; (Source: CursorLoader.java) ===
  Super: Landroid/support/v4/content/AsyncTaskLoader;
  [Instance Field] mCursor: Landroid/database/Cursor;
  [Instance Field] mObserver: Landroid/support/v4/content/Loader$ForceLoadContentObserver;
  [Instance Field] mProjection: [Ljava/lang/String;
  [Instance Field] mSelection: Ljava/lang/String;
  [Instance Field] mSelectionArgs: [Ljava/lang/String;
  [Instance Field] mSortOrder: Ljava/lang/String;
  [Instance Field] mUri: Landroid/net/Uri;

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=3, ins=2, outs=2, insns_size=11
    0000: invoke-direct {v1, v2}, Landroid/support/v4/content/AsyncTaskLoader;-><init>(Landroid/content/Context;)V
    0003: new-instance v0, Landroid/support/v4/content/Loader$ForceLoadContentObserver;
    0005: invoke-direct {v0, v1}, Landroid/support/v4/content/Loader$ForceLoadContentObserver;-><init>(Landroid/support/v4/content/Loader;)V
    0008: iput v0, v1.Landroid/support/v4/content/CursorLoader;->mObserver:Landroid/support/v4/content/Loader$ForceLoadContentObserver;
    000a: return-void

  [Direct Method] <init>(Landroid/content/Context;, Landroid/net/Uri;, [Ljava/lang/String;, Ljava/lang/String;, [Ljava/lang/String;, Ljava/lang/String;) -> V
    // registers=8, ins=7, outs=2, insns_size=21
    0000: invoke-direct {v1, v2}, Landroid/support/v4/content/AsyncTaskLoader;-><init>(Landroid/content/Context;)V
    0003: new-instance v0, Landroid/support/v4/content/Loader$ForceLoadContentObserver;
    0005: invoke-direct {v0, v1}, Landroid/support/v4/content/Loader$ForceLoadContentObserver;-><init>(Landroid/support/v4/content/Loader;)V
    0008: iput v0, v1.Landroid/support/v4/content/CursorLoader;->mObserver:Landroid/support/v4/content/Loader$ForceLoadContentObserver;
    000a: iput v3, v1.Landroid/support/v4/content/CursorLoader;->mUri:Landroid/net/Uri;
    000c: iput v4, v1.Landroid/support/v4/content/CursorLoader;->mProjection:[Ljava/lang/String;
    000e: iput v5, v1.Landroid/support/v4/content/CursorLoader;->mSelection:Ljava/lang/String;
    0010: iput v6, v1.Landroid/support/v4/content/CursorLoader;->mSelectionArgs:[Ljava/lang/String;
    0012: iput v7, v1.Landroid/support/v4/content/CursorLoader;->mSortOrder:Ljava/lang/String;
    0014: return-void

  [Virtual Method] deliverResult(Landroid/database/Cursor;) -> V
    // registers=4, ins=2, outs=2, insns_size=39
    0000: invoke-virtual {v2}, Landroid/support/v4/content/CursorLoader;->isReset()Z
    0003: move-result v0
    0004: if-eqz v0, 000c
    0006: if-eqz v3, 000b
    0008: invoke-interface {v3}, Landroid/database/Cursor;->close()V
    000b: return-void
    000c: iget v0, v2.Landroid/support/v4/content/CursorLoader;->mCursor:Landroid/database/Cursor;
    000e: iput v3, v2.Landroid/support/v4/content/CursorLoader;->mCursor:Landroid/database/Cursor;
    0010: invoke-virtual {v2}, Landroid/support/v4/content/CursorLoader;->isStarted()Z
    0013: move-result v1
    0014: if-eqz v1, 0019
    0016: invoke-super {v2, v3}, Landroid/support/v4/content/AsyncTaskLoader;->deliverResult(Ljava/lang/Object;)V
    0019: if-eqz v0, 000b
    001b: if-eq v0, v3, 000b
    001d: invoke-interface {v0}, Landroid/database/Cursor;->isClosed()Z
    0020: move-result v1
    0021: if-nez v1, 000b
    0023: invoke-interface {v0}, Landroid/database/Cursor;->close()V
    0026: goto 000b

  [Virtual Method] deliverResult(Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v1, Landroid/database/Cursor;
    0002: invoke-virtual {v0, v1}, Landroid/support/v4/content/CursorLoader;->deliverResult(Landroid/database/Cursor;)V
    0005: return-void

  [Virtual Method] dump(Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V
    // registers=6, ins=5, outs=5, insns_size=103
    0000: invoke-super {v1, v2, v3, v4, v5}, Landroid/support/v4/content/AsyncTaskLoader;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    0003: invoke-virtual {v4, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0006: const-string v0, 'mUri='
    0008: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    000b: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mUri:Landroid/net/Uri;
    000d: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0010: invoke-virtual {v4, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0013: const-string v0, 'mProjection='
    0015: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0018: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mProjection:[Ljava/lang/String;
    001a: invoke-static {v0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;
    001d: move-result-object v0
    001e: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0021: invoke-virtual {v4, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0024: const-string v0, 'mSelection='
    0026: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0029: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mSelection:Ljava/lang/String;
    002b: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    002e: invoke-virtual {v4, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0031: const-string v0, 'mSelectionArgs='
    0033: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0036: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mSelectionArgs:[Ljava/lang/String;
    0038: invoke-static {v0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;
    003b: move-result-object v0
    003c: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    003f: invoke-virtual {v4, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0042: const-string v0, 'mSortOrder='
    0044: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0047: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mSortOrder:Ljava/lang/String;
    0049: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    004c: invoke-virtual {v4, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    004f: const-string v0, 'mCursor='
    0051: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0054: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mCursor:Landroid/database/Cursor;
    0056: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0059: invoke-virtual {v4, v2}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    005c: const-string v0, 'mContentChanged='
    005e: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0061: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mContentChanged:Z
    0063: invoke-virtual {v4, v0}, Ljava/io/PrintWriter;->println(Z)V
    0066: return-void

  [Virtual Method] getProjection() -> [Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mProjection:[Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] getSelection() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mSelection:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] getSelectionArgs() -> [Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mSelectionArgs:[Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] getSortOrder() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mSortOrder:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] getUri() -> Landroid/net/Uri;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mUri:Landroid/net/Uri;
    0002: return-object v0

  [Virtual Method] loadInBackground() -> Landroid/database/Cursor;
    // registers=7, ins=1, outs=6, insns_size=33
    0000: invoke-virtual {v6}, Landroid/support/v4/content/CursorLoader;->getContext()Landroid/content/Context;
    0003: move-result-object v0
    0004: invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;
    0007: move-result-object v0
    0008: iget v1, v6.Landroid/support/v4/content/CursorLoader;->mUri:Landroid/net/Uri;
    000a: iget v2, v6.Landroid/support/v4/content/CursorLoader;->mProjection:[Ljava/lang/String;
    000c: iget v3, v6.Landroid/support/v4/content/CursorLoader;->mSelection:Ljava/lang/String;
    000e: iget v4, v6.Landroid/support/v4/content/CursorLoader;->mSelectionArgs:[Ljava/lang/String;
    0010: iget v5, v6.Landroid/support/v4/content/CursorLoader;->mSortOrder:Ljava/lang/String;
    0012: invoke-virtual/range {v0..v5}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    0015: move-result-object v0
    0016: if-eqz v0, 0020
    0018: invoke-interface {v0}, Landroid/database/Cursor;->getCount()I
    001b: iget v1, v6.Landroid/support/v4/content/CursorLoader;->mObserver:Landroid/support/v4/content/Loader$ForceLoadContentObserver;
    001d: invoke-virtual {v6, v0, v1}, Landroid/support/v4/content/CursorLoader;->registerContentObserver(Landroid/database/Cursor;Landroid/database/ContentObserver;)V
    0020: return-object v0

  [Virtual Method] loadInBackground() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/support/v4/content/CursorLoader;->loadInBackground()Landroid/database/Cursor;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] onCanceled(Landroid/database/Cursor;) -> V
    // registers=3, ins=2, outs=1, insns_size=12
    0000: if-eqz v2, 000b
    0002: invoke-interface {v2}, Landroid/database/Cursor;->isClosed()Z
    0005: move-result v0
    0006: if-nez v0, 000b
    0008: invoke-interface {v2}, Landroid/database/Cursor;->close()V
    000b: return-void

  [Virtual Method] onCanceled(Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v1, Landroid/database/Cursor;
    0002: invoke-virtual {v0, v1}, Landroid/support/v4/content/CursorLoader;->onCanceled(Landroid/database/Cursor;)V
    0005: return-void

  [Virtual Method] onReset() -> V
    // registers=2, ins=1, outs=1, insns_size=27
    0000: invoke-super {v1}, Landroid/support/v4/content/AsyncTaskLoader;->onReset()V
    0003: invoke-virtual {v1}, Landroid/support/v4/content/CursorLoader;->onStopLoading()V
    0006: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mCursor:Landroid/database/Cursor;
    0008: if-eqz v0, 0017
    000a: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mCursor:Landroid/database/Cursor;
    000c: invoke-interface {v0}, Landroid/database/Cursor;->isClosed()Z
    000f: move-result v0
    0010: if-nez v0, 0017
    0012: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mCursor:Landroid/database/Cursor;
    0014: invoke-interface {v0}, Landroid/database/Cursor;->close()V
    0017: const/4 v0, 0
    0018: iput v0, v1.Landroid/support/v4/content/CursorLoader;->mCursor:Landroid/database/Cursor;
    001a: return-void

  [Virtual Method] onStartLoading() -> V
    // registers=2, ins=1, outs=2, insns_size=23
    0000: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mCursor:Landroid/database/Cursor;
    0002: if-eqz v0, 0009
    0004: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mCursor:Landroid/database/Cursor;
    0006: invoke-virtual {v1, v0}, Landroid/support/v4/content/CursorLoader;->deliverResult(Landroid/database/Cursor;)V
    0009: invoke-virtual {v1}, Landroid/support/v4/content/CursorLoader;->takeContentChanged()Z
    000c: move-result v0
    000d: if-nez v0, 0013
    000f: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mCursor:Landroid/database/Cursor;
    0011: if-nez v0, 0016
    0013: invoke-virtual {v1}, Landroid/support/v4/content/CursorLoader;->forceLoad()V
    0016: return-void

  [Virtual Method] onStopLoading() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-virtual {v0}, Landroid/support/v4/content/CursorLoader;->cancelLoad()Z
    0003: return-void

  [Virtual Method] registerContentObserver(Landroid/database/Cursor;, Landroid/database/ContentObserver;) -> V
    // registers=4, ins=3, outs=2, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/content/CursorLoader;->mObserver:Landroid/support/v4/content/Loader$ForceLoadContentObserver;
    0002: invoke-interface {v2, v0}, Landroid/database/Cursor;->registerContentObserver(Landroid/database/ContentObserver;)V
    0005: return-void

  [Virtual Method] setProjection([Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/content/CursorLoader;->mProjection:[Ljava/lang/String;
    0002: return-void

  [Virtual Method] setSelection(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/content/CursorLoader;->mSelection:Ljava/lang/String;
    0002: return-void

  [Virtual Method] setSelectionArgs([Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/content/CursorLoader;->mSelectionArgs:[Ljava/lang/String;
    0002: return-void

  [Virtual Method] setSortOrder(Ljava/lang/String;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/content/CursorLoader;->mSortOrder:Ljava/lang/String;
    0002: return-void

  [Virtual Method] setUri(Landroid/net/Uri;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/content/CursorLoader;->mUri:Landroid/net/Uri;
    0002: return-void