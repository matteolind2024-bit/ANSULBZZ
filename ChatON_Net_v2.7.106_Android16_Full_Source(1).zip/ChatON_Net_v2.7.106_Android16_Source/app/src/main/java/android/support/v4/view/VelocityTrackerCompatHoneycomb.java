=== CLASS Landroid/support/v4/view/VelocityTrackerCompatHoneycomb; (Source: VelocityTrackerCompatHoneycomb.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getXVelocity(Landroid/view/VelocityTracker;, I) -> F
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/view/VelocityTracker;->getXVelocity(I)F
    0003: move-result v0
    0004: return v0

  [Direct Method] getYVelocity(Landroid/view/VelocityTracker;, I) -> F
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/view/VelocityTracker;->getYVelocity(I)F
    0003: move-result v0
    0004: return v0