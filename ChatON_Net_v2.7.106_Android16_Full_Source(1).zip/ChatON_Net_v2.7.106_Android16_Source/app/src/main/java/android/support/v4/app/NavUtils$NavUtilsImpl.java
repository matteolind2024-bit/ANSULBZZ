=== CLASS Landroid/support/v4/app/NavUtils$NavUtilsImpl; (Source: NavUtils.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] getParentActivityIntent(Landroid/app/Activity;) -> Landroid/content/Intent;

  [Virtual Method] getParentActivityName(Landroid/content/Context;, Landroid/content/pm/ActivityInfo;) -> Ljava/lang/String;

  [Virtual Method] navigateUpTo(Landroid/app/Activity;, Landroid/content/Intent;) -> V

  [Virtual Method] shouldUpRecreateTask(Landroid/app/Activity;, Landroid/content/Intent;) -> Z