=== CLASS Landroid/support/v4/view/accessibility/AccessibilityEventCompatIcs; (Source: AccessibilityEventCompatIcs.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] appendRecord(Landroid/view/accessibility/AccessibilityEvent;, Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityRecord;
    0002: invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityEvent;->appendRecord(Landroid/view/accessibility/AccessibilityRecord;)V
    0005: return-void

  [Direct Method] getRecord(Landroid/view/accessibility/AccessibilityEvent;, I) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/view/accessibility/AccessibilityEvent;->getRecord(I)Landroid/view/accessibility/AccessibilityRecord;
    0003: move-result-object v0
    0004: return-object v0

  [Direct Method] getRecordCount(Landroid/view/accessibility/AccessibilityEvent;) -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityEvent;->getRecordCount()I
    0003: move-result v0
    0004: return v0