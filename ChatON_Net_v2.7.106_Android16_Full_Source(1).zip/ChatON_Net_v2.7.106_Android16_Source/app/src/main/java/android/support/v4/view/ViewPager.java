=== CLASS Landroid/support/v4/view/ViewPager; (Source: ViewPager.java) ===
  Super: Landroid/view/ViewGroup;
  [Static Field] CLOSE_ENOUGH: I = 2
  [Static Field] COMPARATOR: Ljava/util/Comparator; = None
  [Static Field] DEBUG: Z = False
  [Static Field] DEFAULT_GUTTER_SIZE: I = 16
  [Static Field] DEFAULT_OFFSCREEN_PAGES: I = 1
  [Static Field] INVALID_POINTER: I = -1
  [Static Field] LAYOUT_ATTRS: [I = None
  [Static Field] MAX_SETTLE_DURATION: I = 600
  [Static Field] MIN_DISTANCE_FOR_FLING: I = 25
  [Static Field] SCROLL_STATE_DRAGGING: I = 1
  [Static Field] SCROLL_STATE_IDLE: I = 0
  [Static Field] SCROLL_STATE_SETTLING: I = 2
  [Static Field] TAG: Ljava/lang/String; = 'ViewPager'
  [Static Field] USE_CACHE: Z
  [Static Field] sInterpolator: Landroid/view/animation/Interpolator;
  [Instance Field] mActivePointerId: I
  [Instance Field] mAdapter: Landroid/support/v4/view/PagerAdapter;
  [Instance Field] mAdapterChangeListener: Landroid/support/v4/view/ViewPager$OnAdapterChangeListener;
  [Instance Field] mBottomPageBounds: I
  [Instance Field] mCalledSuper: Z
  [Instance Field] mChildHeightMeasureSpec: I
  [Instance Field] mChildWidthMeasureSpec: I
  [Instance Field] mCloseEnough: I
  [Instance Field] mCurItem: I
  [Instance Field] mDecorChildCount: I
  [Instance Field] mDefaultGutterSize: I
  [Instance Field] mFakeDragBeginTime: J
  [Instance Field] mFakeDragging: Z
  [Instance Field] mFirstLayout: Z
  [Instance Field] mFirstOffset: F
  [Instance Field] mFlingDistance: I
  [Instance Field] mGutterSize: I
  [Instance Field] mIgnoreGutter: Z
  [Instance Field] mInLayout: Z
  [Instance Field] mInitialMotionX: F
  [Instance Field] mInternalPageChangeListener: Landroid/support/v4/view/ViewPager$OnPageChangeListener;
  [Instance Field] mIsBeingDragged: Z
  [Instance Field] mIsUnableToDrag: Z
  [Instance Field] mItems: Ljava/util/ArrayList;
  [Instance Field] mLastMotionX: F
  [Instance Field] mLastMotionY: F
  [Instance Field] mLastOffset: F
  [Instance Field] mLeftEdge: Landroid/support/v4/widget/EdgeEffectCompat;
  [Instance Field] mMarginDrawable: Landroid/graphics/drawable/Drawable;
  [Instance Field] mMaximumVelocity: I
  [Instance Field] mMinimumVelocity: I
  [Instance Field] mNeedCalculatePageOffsets: Z
  [Instance Field] mObserver: Landroid/support/v4/view/ViewPager$PagerObserver;
  [Instance Field] mOffscreenPageLimit: I
  [Instance Field] mOnPageChangeListener: Landroid/support/v4/view/ViewPager$OnPageChangeListener;
  [Instance Field] mPageMargin: I
  [Instance Field] mPopulatePending: Z
  [Instance Field] mRestoredAdapterState: Landroid/os/Parcelable;
  [Instance Field] mRestoredClassLoader: Ljava/lang/ClassLoader;
  [Instance Field] mRestoredCurItem: I
  [Instance Field] mRightEdge: Landroid/support/v4/widget/EdgeEffectCompat;
  [Instance Field] mScrollState: I
  [Instance Field] mScroller: Landroid/widget/Scroller;
  [Instance Field] mScrollingCacheEnabled: Z
  [Instance Field] mTempItem: Landroid/support/v4/view/ViewPager$ItemInfo;
  [Instance Field] mTempRect: Landroid/graphics/Rect;
  [Instance Field] mTopPageBounds: I
  [Instance Field] mTouchSlop: I
  [Instance Field] mVelocityTracker: Landroid/view/VelocityTracker;

  [Direct Method] <clinit>() -> V
    // registers=3, ins=0, outs=1, insns_size=26
    0000: const/4 v0, 1
    0001: new-array v0, v0, [I
    0003: const/4 v1, 0
    0004: const v2, 16842931 (0x10100b3)
    0007: aput(op=4b) v2, v0[v1]
    0009: sput v0, Landroid/support/v4/view/ViewPager;->LAYOUT_ATTRS:[I
    000b: new-instance v0, Landroid/support/v4/view/ViewPager$1;
    000d: invoke-direct {v0}, Landroid/support/v4/view/ViewPager$1;-><init>()V
    0010: sput v0, Landroid/support/v4/view/ViewPager;->COMPARATOR:Ljava/util/Comparator;
    0012: new-instance v0, Landroid/support/v4/view/ViewPager$2;
    0014: invoke-direct {v0}, Landroid/support/v4/view/ViewPager$2;-><init>()V
    0017: sput v0, Landroid/support/v4/view/ViewPager;->sInterpolator:Landroid/view/animation/Interpolator;
    0019: return-void

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=7, ins=2, outs=2, insns_size=58
    0000: const/4 v4, 0
    0001: const/4 v3, 1
    0002: const/4 v2, 0
    0003: const/4 v1, -1
    0004: invoke-direct {v5, v6}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;)V
    0007: new-instance v0, Ljava/util/ArrayList;
    0009: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    000c: iput v0, v5.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    000e: new-instance v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0010: invoke-direct {v0}, Landroid/support/v4/view/ViewPager$ItemInfo;-><init>()V
    0013: iput v0, v5.Landroid/support/v4/view/ViewPager;->mTempItem:Landroid/support/v4/view/ViewPager$ItemInfo;
    0015: new-instance v0, Landroid/graphics/Rect;
    0017: invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V
    001a: iput v0, v5.Landroid/support/v4/view/ViewPager;->mTempRect:Landroid/graphics/Rect;
    001c: iput v1, v5.Landroid/support/v4/view/ViewPager;->mRestoredCurItem:I
    001e: iput v4, v5.Landroid/support/v4/view/ViewPager;->mRestoredAdapterState:Landroid/os/Parcelable;
    0020: iput v4, v5.Landroid/support/v4/view/ViewPager;->mRestoredClassLoader:Ljava/lang/ClassLoader;
    0022: const v0, -8388609 (-0x800001)
    0025: iput v0, v5.Landroid/support/v4/view/ViewPager;->mFirstOffset:F
    0027: const v0, 2139095039 (0x7f7fffff)
    002a: iput v0, v5.Landroid/support/v4/view/ViewPager;->mLastOffset:F
    002c: iput v3, v5.Landroid/support/v4/view/ViewPager;->mOffscreenPageLimit:I
    002e: iput v1, v5.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    0030: iput v3, v5.Landroid/support/v4/view/ViewPager;->mFirstLayout:Z
    0032: iput v2, v5.Landroid/support/v4/view/ViewPager;->mNeedCalculatePageOffsets:Z
    0034: iput v2, v5.Landroid/support/v4/view/ViewPager;->mScrollState:I
    0036: invoke-virtual {v5}, Landroid/support/v4/view/ViewPager;->initViewPager()V
    0039: return-void

  [Direct Method] <init>(Landroid/content/Context;, Landroid/util/AttributeSet;) -> V
    // registers=8, ins=3, outs=3, insns_size=58
    0000: const/4 v4, 0
    0001: const/4 v3, 1
    0002: const/4 v2, 0
    0003: const/4 v1, -1
    0004: invoke-direct {v5, v6, v7}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    0007: new-instance v0, Ljava/util/ArrayList;
    0009: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    000c: iput v0, v5.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    000e: new-instance v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0010: invoke-direct {v0}, Landroid/support/v4/view/ViewPager$ItemInfo;-><init>()V
    0013: iput v0, v5.Landroid/support/v4/view/ViewPager;->mTempItem:Landroid/support/v4/view/ViewPager$ItemInfo;
    0015: new-instance v0, Landroid/graphics/Rect;
    0017: invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V
    001a: iput v0, v5.Landroid/support/v4/view/ViewPager;->mTempRect:Landroid/graphics/Rect;
    001c: iput v1, v5.Landroid/support/v4/view/ViewPager;->mRestoredCurItem:I
    001e: iput v4, v5.Landroid/support/v4/view/ViewPager;->mRestoredAdapterState:Landroid/os/Parcelable;
    0020: iput v4, v5.Landroid/support/v4/view/ViewPager;->mRestoredClassLoader:Ljava/lang/ClassLoader;
    0022: const v0, -8388609 (-0x800001)
    0025: iput v0, v5.Landroid/support/v4/view/ViewPager;->mFirstOffset:F
    0027: const v0, 2139095039 (0x7f7fffff)
    002a: iput v0, v5.Landroid/support/v4/view/ViewPager;->mLastOffset:F
    002c: iput v3, v5.Landroid/support/v4/view/ViewPager;->mOffscreenPageLimit:I
    002e: iput v1, v5.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    0030: iput v3, v5.Landroid/support/v4/view/ViewPager;->mFirstLayout:Z
    0032: iput v2, v5.Landroid/support/v4/view/ViewPager;->mNeedCalculatePageOffsets:Z
    0034: iput v2, v5.Landroid/support/v4/view/ViewPager;->mScrollState:I
    0036: invoke-virtual {v5}, Landroid/support/v4/view/ViewPager;->initViewPager()V
    0039: return-void

  [Direct Method] access$100(Landroid/support/v4/view/ViewPager;) -> Landroid/support/v4/view/PagerAdapter;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0002: return-object v0

  [Direct Method] access$200(Landroid/support/v4/view/ViewPager;) -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0002: return v0

  [Direct Method] access$300() -> [I
    // registers=1, ins=0, outs=0, insns_size=3
    0000: sget v0, Landroid/support/v4/view/ViewPager;->LAYOUT_ATTRS:[I
    0002: return-object v0

  [Direct Method] calculatePageOffsets(Landroid/support/v4/view/ViewPager$ItemInfo;, I, Landroid/support/v4/view/ViewPager$ItemInfo;) -> V
    // registers=15, ins=4, outs=2, insns_size=346
    0000: const/4 v4, 0
    0001: const/high16 v10, 1065353216 (0x3f800000)
    0003: iget v0, v11.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0005: invoke-virtual {v0}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    0008: move-result v7
    0009: invoke-virtual {v11}, Landroid/support/v4/view/ViewPager;->getWidth()I
    000c: move-result v0
    000d: if-lez v0, 0055
    000f: iget v1, v11.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0011: unop(op=82) v1, v1
    0012: unop(op=82) v0, v0
    0013: binop(op=a9) v0, v1, v0
    0015: move(op=01) v6, v0
    0016: if-eqz v14, 00b7
    0018: iget v0, v14.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    001a: iget v1, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    001c: if-ge v0, v1, 0070
    001e: iget v1, v14.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0020: iget v2, v14.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0022: binop/2addr(op=c6) v1, v2
    0023: binop(op=a6) v3, v1, v6
    0025: binop/lit8(op=d8) v2, v0, 1 (0x1)
    0027: move(op=01) v1, v4
    0028: iget v0, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    002a: if-gt v2, v0, 00b7
    002c: iget v0, v11.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    002e: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0031: move-result v0
    0032: if-ge v1, v0, 00b7
    0034: iget v0, v11.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0036: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0039: move-result-object v0
    003a: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    003c: iget v5, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    003e: if-le v2, v5, 0058
    0040: iget v5, v11.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0042: invoke-virtual {v5}, Ljava/util/ArrayList;->size()I
    0045: move-result v5
    0046: binop/lit8(op=d8) v5, v5, -1 (-0x1)
    0048: if-ge v1, v5, 0058
    004a: binop/lit8(op=d8) v1, v1, 1 (0x1)
    004c: iget v0, v11.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    004e: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0051: move-result-object v0
    0052: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0054: goto 003c
    0055: const/4 v0, 0
    0056: move(op=01) v6, v0
    0057: goto 0016
    0058: iget v5, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    005a: if-ge v2, v5, 0067
    005c: iget v5, v11.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    005e: invoke-virtual {v5, v2}, Landroid/support/v4/view/PagerAdapter;->getPageWidth(I)F
    0061: move-result v5
    0062: binop/2addr(op=c6) v5, v6
    0063: binop/2addr(op=c6) v3, v5
    0064: binop/lit8(op=d8) v2, v2, 1 (0x1)
    0066: goto 0058
    0067: iput v3, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0069: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    006b: binop/2addr(op=c6) v0, v6
    006c: binop/2addr(op=c6) v3, v0
    006d: binop/lit8(op=d8) v2, v2, 1 (0x1)
    006f: goto 0028
    0070: iget v1, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0072: if-le v0, v1, 00b7
    0074: iget v1, v11.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0076: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0079: move-result v1
    007a: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    007c: iget v3, v14.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    007e: binop/lit8(op=d8) v2, v0, -1 (-0x1)
    0080: iget v0, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0082: if-lt v2, v0, 00b7
    0084: if-ltz v1, 00b7
    0086: iget v0, v11.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0088: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    008b: move-result-object v0
    008c: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    008e: iget v5, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0090: if-ge v2, v5, 009f
    0092: if-lez v1, 009f
    0094: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0096: iget v0, v11.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0098: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    009b: move-result-object v0
    009c: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    009e: goto 008e
    009f: iget v5, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    00a1: if-le v2, v5, 00ae
    00a3: iget v5, v11.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    00a5: invoke-virtual {v5, v2}, Landroid/support/v4/view/PagerAdapter;->getPageWidth(I)F
    00a8: move-result v5
    00a9: binop/2addr(op=c6) v5, v6
    00aa: binop/2addr(op=c7) v3, v5
    00ab: binop/lit8(op=d8) v2, v2, -1 (-0x1)
    00ad: goto 009f
    00ae: iget v5, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    00b0: binop/2addr(op=c6) v5, v6
    00b1: binop/2addr(op=c7) v3, v5
    00b2: iput v3, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    00b4: binop/lit8(op=d8) v2, v2, -1 (-0x1)
    00b6: goto 0080
    00b7: iget v0, v11.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    00b9: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    00bc: move-result v8
    00bd: iget v2, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    00bf: iget v0, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    00c1: binop/lit8(op=d8) v1, v0, -1 (-0x1)
    00c3: iget v0, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    00c5: if-nez v0, 00f9
    00c7: iget v0, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    00c9: iput v0, v11.Landroid/support/v4/view/ViewPager;->mFirstOffset:F
    00cb: iget v0, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    00cd: binop/lit8(op=d8) v3, v7, -1 (-0x1)
    00cf: if-ne v0, v3, 00fd
    00d1: iget v0, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    00d3: iget v3, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    00d5: binop/2addr(op=c6) v0, v3
    00d6: binop/2addr(op=c7) v0, v10
    00d7: iput v0, v11.Landroid/support/v4/view/ViewPager;->mLastOffset:F
    00d9: binop/lit8(op=d8) v0, v13, -1 (-0x1)
    00db: move(op=01) v5, v0
    00dc: if-ltz v5, 0114
    00de: iget v0, v11.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    00e0: invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    00e3: move-result-object v0
    00e4: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    00e6: move(op=01) v3, v2
    00e7: iget v2, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    00e9: if-le v1, v2, 0101
    00eb: iget v9, v11.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    00ed: binop/lit8(op=d8) v2, v1, -1 (-0x1)
    00ef: invoke-virtual {v9, v1}, Landroid/support/v4/view/PagerAdapter;->getPageWidth(I)F
    00f2: move-result v1
    00f3: binop/2addr(op=c6) v1, v6
    00f4: binop(op=a7) v1, v3, v1
    00f6: move(op=01) v3, v1
    00f7: move(op=01) v1, v2
    00f8: goto 00e7
    00f9: const v0, -8388609 (-0x800001)
    00fc: goto 00c9
    00fd: const v0, 2139095039 (0x7f7fffff)
    0100: goto 00d7
    0101: iget v2, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0103: binop/2addr(op=c6) v2, v6
    0104: binop(op=a7) v2, v3, v2
    0106: iput v2, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0108: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    010a: if-nez v0, 010e
    010c: iput v2, v11.Landroid/support/v4/view/ViewPager;->mFirstOffset:F
    010e: binop/lit8(op=d8) v0, v5, -1 (-0x1)
    0110: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0112: move(op=01) v5, v0
    0113: goto 00dc
    0114: iget v0, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0116: iget v1, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0118: binop/2addr(op=c6) v0, v1
    0119: binop(op=a6) v2, v0, v6
    011b: iget v0, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    011d: binop/lit8(op=d8) v1, v0, 1 (0x1)
    011f: binop/lit8(op=d8) v0, v13, 1 (0x1)
    0121: move(op=01) v5, v0
    0122: if-ge v5, v8, 0157
    0124: iget v0, v11.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0126: invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0129: move-result-object v0
    012a: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    012c: move(op=01) v3, v2
    012d: iget v2, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    012f: if-ge v1, v2, 013e
    0131: iget v9, v11.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0133: binop/lit8(op=d8) v2, v1, 1 (0x1)
    0135: invoke-virtual {v9, v1}, Landroid/support/v4/view/PagerAdapter;->getPageWidth(I)F
    0138: move-result v1
    0139: binop/2addr(op=c6) v1, v6
    013a: binop/2addr(op=c6) v1, v3
    013b: move(op=01) v3, v1
    013c: move(op=01) v1, v2
    013d: goto 012d
    013e: iget v2, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0140: binop/lit8(op=d8) v9, v7, -1 (-0x1)
    0142: if-ne v2, v9, 014a
    0144: iget v2, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0146: binop/2addr(op=c6) v2, v3
    0147: binop/2addr(op=c7) v2, v10
    0148: iput v2, v11.Landroid/support/v4/view/ViewPager;->mLastOffset:F
    014a: iput v3, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    014c: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    014e: binop/2addr(op=c6) v0, v6
    014f: binop(op=a6) v2, v3, v0
    0151: binop/lit8(op=d8) v0, v5, 1 (0x1)
    0153: binop/lit8(op=d8) v1, v1, 1 (0x1)
    0155: move(op=01) v5, v0
    0156: goto 0122
    0157: iput v4, v11.Landroid/support/v4/view/ViewPager;->mNeedCalculatePageOffsets:Z
    0159: return-void

  [Direct Method] completeScroll() -> V
    // registers=8, ins=1, outs=3, insns_size=87
    0000: const/4 v4, 1
    0001: const/4 v2, 0
    0002: iget v0, v7.Landroid/support/v4/view/ViewPager;->mScrollState:I
    0004: const/4 v1, 2
    0005: if-ne v0, v1, 004f
    0007: move(op=01) v0, v4
    0008: if-eqz v0, 0030
    000a: invoke-direct {v7, v2}, Landroid/support/v4/view/ViewPager;->setScrollingCacheEnabled(Z)V
    000d: iget v1, v7.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    000f: invoke-virtual {v1}, Landroid/widget/Scroller;->abortAnimation()V
    0012: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    0015: move-result v1
    0016: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getScrollY()I
    0019: move-result v3
    001a: iget v5, v7.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    001c: invoke-virtual {v5}, Landroid/widget/Scroller;->getCurrX()I
    001f: move-result v5
    0020: iget v6, v7.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    0022: invoke-virtual {v6}, Landroid/widget/Scroller;->getCurrY()I
    0025: move-result v6
    0026: if-ne v1, v5, 002a
    0028: if-eq v3, v6, 002d
    002a: invoke-virtual {v7, v5, v6}, Landroid/support/v4/view/ViewPager;->scrollTo(II)V
    002d: invoke-direct {v7, v2}, Landroid/support/v4/view/ViewPager;->setScrollState(I)V
    0030: iput v2, v7.Landroid/support/v4/view/ViewPager;->mPopulatePending:Z
    0032: move(op=01) v1, v2
    0033: move(op=01) v3, v0
    0034: iget v0, v7.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0036: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0039: move-result v0
    003a: if-ge v1, v0, 0051
    003c: iget v0, v7.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    003e: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0041: move-result-object v0
    0042: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0044: iget v5, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->scrolling:Z
    0046: if-eqz v5, 004b
    0048: iput v2, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->scrolling:Z
    004a: move(op=01) v3, v4
    004b: binop/lit8(op=d8) v0, v1, 1 (0x1)
    004d: move(op=01) v1, v0
    004e: goto 0034
    004f: move(op=01) v0, v2
    0050: goto 0008
    0051: if-eqz v3, 0056
    0053: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->populate()V
    0056: return-void

  [Direct Method] determineTargetPage(I, F, I, I) -> I
    // registers=8, ins=5, outs=2, insns_size=74
    0000: invoke-static {v7}, Ljava/lang/Math;->abs(I)I
    0003: move-result v0
    0004: iget v1, v3.Landroid/support/v4/view/ViewPager;->mFlingDistance:I
    0006: if-le v0, v1, 0043
    0008: invoke-static {v6}, Ljava/lang/Math;->abs(I)I
    000b: move-result v0
    000c: iget v1, v3.Landroid/support/v4/view/ViewPager;->mMinimumVelocity:I
    000e: if-le v0, v1, 0043
    0010: if-lez v6, 0040
    0012: iget v0, v3.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0014: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0017: move-result v0
    0018: if-lez v0, 003f
    001a: iget v0, v3.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    001c: const/4 v1, 0
    001d: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0020: move-result-object v0
    0021: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0023: iget v1, v3.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0025: iget v2, v3.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0027: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    002a: move-result v2
    002b: binop/lit8(op=d8) v2, v2, -1 (-0x1)
    002d: invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0030: move-result-object v1
    0031: check-cast v1, Landroid/support/v4/view/ViewPager$ItemInfo;
    0033: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0035: iget v1, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0037: invoke-static {v4, v1}, Ljava/lang/Math;->min(II)I
    003a: move-result v1
    003b: invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I
    003e: move-result v4
    003f: return v4
    0040: binop/lit8(op=d8) v4, v4, 1 (0x1)
    0042: goto 0012
    0043: unop(op=82) v0, v4
    0044: binop/2addr(op=c6) v0, v5
    0045: const/high16 v1, 1056964608 (0x3f000000)
    0047: binop/2addr(op=c6) v0, v1
    0048: unop(op=87) v4, v0
    0049: goto 0012

  [Direct Method] endDrag() -> V
    // registers=2, ins=1, outs=1, insns_size=18
    0000: const/4 v0, 0
    0001: iput v0, v1.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    0003: iput v0, v1.Landroid/support/v4/view/ViewPager;->mIsUnableToDrag:Z
    0005: iget v0, v1.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0007: if-eqz v0, 0011
    0009: iget v0, v1.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    000b: invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V
    000e: const/4 v0, 0
    000f: iput v0, v1.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0011: return-void

  [Direct Method] getChildRectInPagerCoordinates(Landroid/graphics/Rect;, Landroid/view/View;) -> Landroid/graphics/Rect;
    // registers=7, ins=3, outs=5, insns_size=96
    0000: const/4 v0, 0
    0001: if-nez v5, 005e
    0003: new-instance v1, Landroid/graphics/Rect;
    0005: invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V
    0008: if-nez v6, 000f
    000a: invoke-virtual {v1, v0, v0, v0, v0}, Landroid/graphics/Rect;->set(IIII)V
    000d: move(op=07) v0, v1
    000e: return-object v0
    000f: invoke-virtual {v6}, Landroid/view/View;->getLeft()I
    0012: move-result v0
    0013: iput v0, v1.Landroid/graphics/Rect;->left:I
    0015: invoke-virtual {v6}, Landroid/view/View;->getRight()I
    0018: move-result v0
    0019: iput v0, v1.Landroid/graphics/Rect;->right:I
    001b: invoke-virtual {v6}, Landroid/view/View;->getTop()I
    001e: move-result v0
    001f: iput v0, v1.Landroid/graphics/Rect;->top:I
    0021: invoke-virtual {v6}, Landroid/view/View;->getBottom()I
    0024: move-result v0
    0025: iput v0, v1.Landroid/graphics/Rect;->bottom:I
    0027: invoke-virtual {v6}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    002a: move-result-object v0
    002b: instance-of v2, v0, Landroid/view/ViewGroup;
    002d: if-eqz v2, 005c
    002f: if-eq v0, v4, 005c
    0031: check-cast v0, Landroid/view/ViewGroup;
    0033: iget v2, v1.Landroid/graphics/Rect;->left:I
    0035: invoke-virtual {v0}, Landroid/view/ViewGroup;->getLeft()I
    0038: move-result v3
    0039: binop/2addr(op=b0) v2, v3
    003a: iput v2, v1.Landroid/graphics/Rect;->left:I
    003c: iget v2, v1.Landroid/graphics/Rect;->right:I
    003e: invoke-virtual {v0}, Landroid/view/ViewGroup;->getRight()I
    0041: move-result v3
    0042: binop/2addr(op=b0) v2, v3
    0043: iput v2, v1.Landroid/graphics/Rect;->right:I
    0045: iget v2, v1.Landroid/graphics/Rect;->top:I
    0047: invoke-virtual {v0}, Landroid/view/ViewGroup;->getTop()I
    004a: move-result v3
    004b: binop/2addr(op=b0) v2, v3
    004c: iput v2, v1.Landroid/graphics/Rect;->top:I
    004e: iget v2, v1.Landroid/graphics/Rect;->bottom:I
    0050: invoke-virtual {v0}, Landroid/view/ViewGroup;->getBottom()I
    0053: move-result v3
    0054: binop/2addr(op=b0) v2, v3
    0055: iput v2, v1.Landroid/graphics/Rect;->bottom:I
    0057: invoke-virtual {v0}, Landroid/view/ViewGroup;->getParent()Landroid/view/ViewParent;
    005a: move-result-object v0
    005b: goto 002b
    005c: move(op=07) v0, v1
    005d: goto 000e
    005e: move(op=07) v1, v5
    005f: goto 0008

  [Direct Method] infoForCurrentScrollPosition() -> Landroid/support/v4/view/ViewPager$ItemInfo;
    // registers=14, ins=1, outs=2, insns_size=131
    0000: const/4 v3, 0
    0001: const/4 v2, 0
    0002: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->getWidth()I
    0005: move-result v1
    0006: if-lez v1, 006e
    0008: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    000b: move-result v0
    000c: unop(op=82) v0, v0
    000d: unop(op=82) v4, v1
    000e: binop/2addr(op=c9) v0, v4
    000f: move(op=01) v9, v0
    0010: if-lez v1, 0070
    0012: iget v0, v13.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0014: unop(op=82) v0, v0
    0015: unop(op=82) v1, v1
    0016: binop/2addr(op=c9) v0, v1
    0017: move(op=01) v1, v0
    0018: const/4 v5, -1
    0019: const/4 v4, 1
    001a: const/4 v0, 0
    001b: move(op=01) v6, v2
    001c: move(op=01) v7, v2
    001d: move(op=01) v8, v5
    001e: move(op=01) v2, v3
    001f: move(op=01) v5, v4
    0020: move(op=07) v4, v0
    0021: iget v0, v13.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0023: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0026: move-result v0
    0027: if-ge v2, v0, 006d
    0029: iget v0, v13.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    002b: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    002e: move-result-object v0
    002f: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0031: if-nez v5, 007f
    0033: iget v10, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0035: binop/lit8(op=d8) v11, v8, 1 (0x1)
    0037: if-eq v10, v11, 007f
    0039: iget v0, v13.Landroid/support/v4/view/ViewPager;->mTempItem:Landroid/support/v4/view/ViewPager$ItemInfo;
    003b: binop/2addr(op=c6) v6, v7
    003c: binop/2addr(op=c6) v6, v1
    003d: iput v6, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    003f: binop/lit8(op=d8) v6, v8, 1 (0x1)
    0041: iput v6, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0043: iget v6, v13.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0045: iget v7, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0047: invoke-virtual {v6, v7}, Landroid/support/v4/view/PagerAdapter;->getPageWidth(I)F
    004a: move-result v6
    004b: iput v6, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    004d: binop/lit8(op=d8) v2, v2, -1 (-0x1)
    004f: move(op=07) v12, v0
    0050: move(op=01) v0, v2
    0051: move(op=07) v2, v12
    0052: iget v6, v2.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0054: iget v7, v2.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0056: binop/2addr(op=c6) v7, v6
    0057: binop/2addr(op=c6) v7, v1
    0058: if-nez v5, 005e
    005a: cmp(op=2d) v5, v9, v6
    005c: if-ltz v5, 006d
    005e: cmp(op=2e) v4, v9, v7
    0060: if-ltz v4, 006c
    0062: iget v4, v13.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0064: invoke-virtual {v4}, Ljava/util/ArrayList;->size()I
    0067: move-result v4
    0068: binop/lit8(op=d8) v4, v4, -1 (-0x1)
    006a: if-ne v0, v4, 0072
    006c: move(op=07) v4, v2
    006d: return-object v4
    006e: move(op=01) v9, v2
    006f: goto 0010
    0070: move(op=01) v1, v2
    0071: goto 0018
    0072: iget v5, v2.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0074: iget v4, v2.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0076: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0078: move(op=01) v7, v6
    0079: move(op=01) v8, v5
    007a: move(op=01) v5, v3
    007b: move(op=01) v6, v4
    007c: move(op=07) v4, v2
    007d: move(op=01) v2, v0
    007e: goto 0021
    007f: move(op=07) v12, v0
    0080: move(op=01) v0, v2
    0081: move(op=07) v2, v12
    0082: goto 0052

  [Direct Method] isGutterDrag(F, F) -> Z
    // registers=6, ins=3, outs=1, insns_size=32
    0000: const/4 v2, 0
    0001: iget v0, v3.Landroid/support/v4/view/ViewPager;->mGutterSize:I
    0003: unop(op=82) v0, v0
    0004: cmp(op=2e) v0, v4, v0
    0006: if-gez v0, 000c
    0008: cmp(op=2d) v0, v5, v2
    000a: if-gtz v0, 001c
    000c: invoke-virtual {v3}, Landroid/support/v4/view/ViewPager;->getWidth()I
    000f: move-result v0
    0010: iget v1, v3.Landroid/support/v4/view/ViewPager;->mGutterSize:I
    0012: binop/2addr(op=b1) v0, v1
    0013: unop(op=82) v0, v0
    0014: cmp(op=2d) v0, v4, v0
    0016: if-lez v0, 001e
    0018: cmp(op=2e) v0, v5, v2
    001a: if-gez v0, 001e
    001c: const/4 v0, 1
    001d: return v0
    001e: const/4 v0, 0
    001f: goto 001d

  [Direct Method] onSecondaryPointerUp(Landroid/view/MotionEvent;) -> V
    // registers=5, ins=2, outs=2, insns_size=39
    0000: invoke-static {v4}, Landroid/support/v4/view/MotionEventCompat;->getActionIndex(Landroid/view/MotionEvent;)I
    0003: move-result v0
    0004: invoke-static {v4, v0}, Landroid/support/v4/view/MotionEventCompat;->getPointerId(Landroid/view/MotionEvent;I)I
    0007: move-result v1
    0008: iget v2, v3.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    000a: if-ne v1, v2, 0024
    000c: if-nez v0, 0025
    000e: const/4 v0, 1
    000f: invoke-static {v4, v0}, Landroid/support/v4/view/MotionEventCompat;->getX(Landroid/view/MotionEvent;I)F
    0012: move-result v1
    0013: iput v1, v3.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0015: invoke-static {v4, v0}, Landroid/support/v4/view/MotionEventCompat;->getPointerId(Landroid/view/MotionEvent;I)I
    0018: move-result v0
    0019: iput v0, v3.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    001b: iget v0, v3.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    001d: if-eqz v0, 0024
    001f: iget v0, v3.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0021: invoke-virtual {v0}, Landroid/view/VelocityTracker;->clear()V
    0024: return-void
    0025: const/4 v0, 0
    0026: goto 000f

  [Direct Method] pageScrolled(I) -> Z
    // registers=9, ins=2, outs=4, insns_size=79
    0000: const/4 v0, 0
    0001: iget v1, v7.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0003: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0006: move-result v1
    0007: if-nez v1, 001b
    0009: iput v0, v7.Landroid/support/v4/view/ViewPager;->mCalledSuper:Z
    000b: const/4 v1, 0
    000c: invoke-virtual {v7, v0, v1, v0}, Landroid/support/v4/view/ViewPager;->onPageScrolled(IFI)V
    000f: iget v1, v7.Landroid/support/v4/view/ViewPager;->mCalledSuper:Z
    0011: if-nez v1, 004e
    0013: new-instance v0, Ljava/lang/IllegalStateException;
    0015: const-string v1, 'onPageScrolled did not call superclass implementation'
    0017: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    001a: throw v0
    001b: invoke-direct {v7}, Landroid/support/v4/view/ViewPager;->infoForCurrentScrollPosition()Landroid/support/v4/view/ViewPager$ItemInfo;
    001e: move-result-object v1
    001f: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getWidth()I
    0022: move-result v2
    0023: iget v3, v7.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0025: binop/2addr(op=b0) v3, v2
    0026: iget v4, v7.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0028: unop(op=82) v4, v4
    0029: unop(op=82) v5, v2
    002a: binop/2addr(op=c9) v4, v5
    002b: iget v5, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    002d: unop(op=82) v6, v8
    002e: unop(op=82) v2, v2
    002f: binop(op=a9) v2, v6, v2
    0031: iget v6, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0033: binop/2addr(op=c7) v2, v6
    0034: iget v1, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0036: binop/2addr(op=c6) v1, v4
    0037: binop(op=a9) v1, v2, v1
    0039: unop(op=82) v2, v3
    003a: binop/2addr(op=c8) v2, v1
    003b: unop(op=87) v2, v2
    003c: iput v0, v7.Landroid/support/v4/view/ViewPager;->mCalledSuper:Z
    003e: invoke-virtual {v7, v5, v1, v2}, Landroid/support/v4/view/ViewPager;->onPageScrolled(IFI)V
    0041: iget v0, v7.Landroid/support/v4/view/ViewPager;->mCalledSuper:Z
    0043: if-nez v0, 004d
    0045: new-instance v0, Ljava/lang/IllegalStateException;
    0047: const-string v1, 'onPageScrolled did not call superclass implementation'
    0049: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    004c: throw v0
    004d: const/4 v0, 1
    004e: return v0

  [Direct Method] performDrag(F) -> Z
    // registers=12, ins=2, outs=3, insns_size=149
    0000: const/4 v3, 1
    0001: const/4 v2, 0
    0002: iget v0, v10.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0004: binop/2addr(op=c7) v0, v11
    0005: iput v11, v10.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0007: invoke-virtual {v10}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    000a: move-result v1
    000b: unop(op=82) v1, v1
    000c: binop(op=a6) v5, v1, v0
    000e: invoke-virtual {v10}, Landroid/support/v4/view/ViewPager;->getWidth()I
    0011: move-result v7
    0012: unop(op=82) v0, v7
    0013: iget v1, v10.Landroid/support/v4/view/ViewPager;->mFirstOffset:F
    0015: binop(op=a8) v4, v0, v1
    0017: unop(op=82) v0, v7
    0018: iget v1, v10.Landroid/support/v4/view/ViewPager;->mLastOffset:F
    001a: binop(op=a8) v6, v0, v1
    001c: iget v0, v10.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    001e: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0021: move-result-object v0
    0022: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0024: iget v1, v10.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0026: iget v8, v10.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0028: invoke-virtual {v8}, Ljava/util/ArrayList;->size()I
    002b: move-result v8
    002c: binop/lit8(op=d8) v8, v8, -1 (-0x1)
    002e: invoke-virtual {v1, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0031: move-result-object v1
    0032: check-cast v1, Landroid/support/v4/view/ViewPager$ItemInfo;
    0034: iget v8, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0036: if-eqz v8, 0093
    0038: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    003a: unop(op=82) v4, v7
    003b: binop/2addr(op=c8) v0, v4
    003c: move(op=01) v4, v0
    003d: move(op=01) v0, v2
    003e: iget v8, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0040: iget v9, v10.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0042: invoke-virtual {v9}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    0045: move-result v9
    0046: binop/lit8(op=d8) v9, v9, -1 (-0x1)
    0048: if-eq v8, v9, 0091
    004a: iget v1, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    004c: unop(op=82) v3, v7
    004d: binop/2addr(op=c8) v1, v3
    004e: move(op=01) v3, v2
    004f: cmp(op=2e) v6, v5, v4
    0051: if-gez v6, 0079
    0053: if-eqz v0, 0063
    0055: binop(op=a7) v0, v4, v5
    0057: iget v1, v10.Landroid/support/v4/view/ViewPager;->mLeftEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    0059: invoke-static {v0}, Ljava/lang/Math;->abs(F)F
    005c: move-result v0
    005d: unop(op=82) v2, v7
    005e: binop/2addr(op=c9) v0, v2
    005f: invoke-virtual {v1, v0}, Landroid/support/v4/widget/EdgeEffectCompat;->onPull(F)Z
    0062: move-result v2
    0063: iget v0, v10.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0065: unop(op=87) v1, v4
    0066: unop(op=82) v1, v1
    0067: binop(op=a7) v1, v4, v1
    0069: binop/2addr(op=c6) v0, v1
    006a: iput v0, v10.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    006c: unop(op=87) v0, v4
    006d: invoke-virtual {v10}, Landroid/support/v4/view/ViewPager;->getScrollY()I
    0070: move-result v1
    0071: invoke-virtual {v10, v0, v1}, Landroid/support/v4/view/ViewPager;->scrollTo(II)V
    0074: unop(op=87) v0, v4
    0075: invoke-direct {v10, v0}, Landroid/support/v4/view/ViewPager;->pageScrolled(I)Z
    0078: return v2
    0079: cmp(op=2d) v0, v5, v1
    007b: if-lez v0, 008f
    007d: if-eqz v3, 008d
    007f: binop(op=a7) v0, v5, v1
    0081: iget v2, v10.Landroid/support/v4/view/ViewPager;->mRightEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    0083: invoke-static {v0}, Ljava/lang/Math;->abs(F)F
    0086: move-result v0
    0087: unop(op=82) v3, v7
    0088: binop/2addr(op=c9) v0, v3
    0089: invoke-virtual {v2, v0}, Landroid/support/v4/widget/EdgeEffectCompat;->onPull(F)Z
    008c: move-result v2
    008d: move(op=01) v4, v1
    008e: goto 0063
    008f: move(op=01) v4, v5
    0090: goto 0063
    0091: move(op=01) v1, v6
    0092: goto 004f
    0093: move(op=01) v0, v3
    0094: goto 003e

  [Direct Method] recomputeScrollPosition(I, I, I, I) -> V
    // registers=11, ins=5, outs=6, insns_size=111
    0000: const/4 v2, 0
    0001: if-lez v8, 0049
    0003: iget v0, v6.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0005: invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z
    0008: move-result v0
    0009: if-nez v0, 0049
    000b: binop(op=90) v0, v7, v9
    000d: binop(op=90) v1, v8, v10
    000f: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    0012: move-result v3
    0013: unop(op=82) v3, v3
    0014: unop(op=82) v1, v1
    0015: binop(op=a9) v1, v3, v1
    0017: unop(op=82) v0, v0
    0018: binop/2addr(op=c8) v0, v1
    0019: unop(op=87) v1, v0
    001a: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->getScrollY()I
    001d: move-result v0
    001e: invoke-virtual {v6, v1, v0}, Landroid/support/v4/view/ViewPager;->scrollTo(II)V
    0021: iget v0, v6.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    0023: invoke-virtual {v0}, Landroid/widget/Scroller;->isFinished()Z
    0026: move-result v0
    0027: if-nez v0, 0048
    0029: iget v0, v6.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    002b: invoke-virtual {v0}, Landroid/widget/Scroller;->getDuration()I
    002e: move-result v0
    002f: iget v3, v6.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    0031: invoke-virtual {v3}, Landroid/widget/Scroller;->timePassed()I
    0034: move-result v3
    0035: binop(op=91) v5, v0, v3
    0037: iget v0, v6.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0039: invoke-virtual {v6, v0}, Landroid/support/v4/view/ViewPager;->infoForPosition(I)Landroid/support/v4/view/ViewPager$ItemInfo;
    003c: move-result-object v3
    003d: iget v0, v6.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    003f: iget v3, v3.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0041: unop(op=82) v4, v7
    0042: binop/2addr(op=c8) v3, v4
    0043: unop(op=87) v3, v3
    0044: move(op=01) v4, v2
    0045: invoke-virtual/range {v0..v5}, Landroid/widget/Scroller;->startScroll(IIIII)V
    0048: return-void
    0049: iget v0, v6.Landroid/support/v4/view/ViewPager;->mCurItem:I
    004b: invoke-virtual {v6, v0}, Landroid/support/v4/view/ViewPager;->infoForPosition(I)Landroid/support/v4/view/ViewPager$ItemInfo;
    004e: move-result-object v0
    004f: if-eqz v0, 006d
    0051: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0053: iget v1, v6.Landroid/support/v4/view/ViewPager;->mLastOffset:F
    0055: invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F
    0058: move-result v0
    0059: unop(op=82) v1, v7
    005a: binop/2addr(op=c8) v0, v1
    005b: unop(op=87) v0, v0
    005c: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    005f: move-result v1
    0060: if-eq v0, v1, 0048
    0062: invoke-direct {v6}, Landroid/support/v4/view/ViewPager;->completeScroll()V
    0065: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->getScrollY()I
    0068: move-result v1
    0069: invoke-virtual {v6, v0, v1}, Landroid/support/v4/view/ViewPager;->scrollTo(II)V
    006c: goto 0048
    006d: const/4 v0, 0
    006e: goto 0059

  [Direct Method] removeNonDecorViews() -> V
    // registers=3, ins=1, outs=2, insns_size=32
    0000: const/4 v0, 0
    0001: move(op=01) v1, v0
    0002: invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    0005: move-result v0
    0006: if-ge v1, v0, 001f
    0008: invoke-virtual {v2, v1}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    000b: move-result-object v0
    000c: invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    000f: move-result-object v0
    0010: check-cast v0, Landroid/support/v4/view/ViewPager$LayoutParams;
    0012: iget v0, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->isDecor:Z
    0014: if-nez v0, 001b
    0016: invoke-virtual {v2, v1}, Landroid/support/v4/view/ViewPager;->removeViewAt(I)V
    0019: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    001b: binop/lit8(op=d8) v0, v1, 1 (0x1)
    001d: move(op=01) v1, v0
    001e: goto 0002
    001f: return-void

  [Direct Method] setScrollState(I) -> V
    // registers=3, ins=2, outs=2, insns_size=17
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager;->mScrollState:I
    0002: if-ne v0, v2, 0005
    0004: return-void
    0005: iput v2, v1.Landroid/support/v4/view/ViewPager;->mScrollState:I
    0007: iget v0, v1.Landroid/support/v4/view/ViewPager;->mOnPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    0009: if-eqz v0, 0004
    000b: iget v0, v1.Landroid/support/v4/view/ViewPager;->mOnPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    000d: invoke-interface {v0, v2}, Landroid/support/v4/view/ViewPager$OnPageChangeListener;->onPageScrollStateChanged(I)V
    0010: goto 0004

  [Direct Method] setScrollingCacheEnabled(Z) -> V
    // registers=3, ins=2, outs=0, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager;->mScrollingCacheEnabled:Z
    0002: if-eq v0, v2, 0006
    0004: iput v2, v1.Landroid/support/v4/view/ViewPager;->mScrollingCacheEnabled:Z
    0006: return-void

  [Virtual Method] addFocusables(Ljava/util/ArrayList;, I, I) -> V
    // registers=10, ins=4, outs=4, insns_size=87
    0000: invoke-virtual {v7}, Ljava/util/ArrayList;->size()I
    0003: move-result v1
    0004: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->getDescendantFocusability()I
    0007: move-result v2
    0008: const/high16 v0, 393216 (0x60000)
    000a: if-eq v2, v0, 002f
    000c: const/4 v0, 0
    000d: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    0010: move-result v3
    0011: if-ge v0, v3, 002f
    0013: invoke-virtual {v6, v0}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    0016: move-result-object v3
    0017: invoke-virtual {v3}, Landroid/view/View;->getVisibility()I
    001a: move-result v4
    001b: if-nez v4, 002c
    001d: invoke-virtual {v6, v3}, Landroid/support/v4/view/ViewPager;->infoForChild(Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    0020: move-result-object v4
    0021: if-eqz v4, 002c
    0023: iget v4, v4.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0025: iget v5, v6.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0027: if-ne v4, v5, 002c
    0029: invoke-virtual {v3, v7, v8, v9}, Landroid/view/View;->addFocusables(Ljava/util/ArrayList;II)V
    002c: binop/lit8(op=d8) v0, v0, 1 (0x1)
    002e: goto 000d
    002f: const/high16 v0, 262144 (0x40000)
    0031: if-ne v2, v0, 0039
    0033: invoke-virtual {v7}, Ljava/util/ArrayList;->size()I
    0036: move-result v0
    0037: if-ne v1, v0, 003f
    0039: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->isFocusable()Z
    003c: move-result v0
    003d: if-nez v0, 0040
    003f: return-void
    0040: binop/lit8(op=dd) v0, v9, 1 (0x1)
    0042: const/4 v1, 1
    0043: if-ne v0, v1, 0051
    0045: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->isInTouchMode()Z
    0048: move-result v0
    0049: if-eqz v0, 0051
    004b: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->isFocusableInTouchMode()Z
    004e: move-result v0
    004f: if-eqz v0, 003f
    0051: if-eqz v7, 003f
    0053: invoke-virtual {v7, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0056: goto 003f

  [Virtual Method] addNewItem(I, I) -> Landroid/support/v4/view/ViewPager$ItemInfo;
    // registers=5, ins=3, outs=3, insns_size=45
    0000: new-instance v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0002: invoke-direct {v0}, Landroid/support/v4/view/ViewPager$ItemInfo;-><init>()V
    0005: iput v3, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0007: iget v1, v2.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0009: invoke-virtual {v1, v2, v3}, Landroid/support/v4/view/PagerAdapter;->instantiateItem(Landroid/view/ViewGroup;I)Ljava/lang/Object;
    000c: move-result-object v1
    000d: iput v1, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->object:Ljava/lang/Object;
    000f: iget v1, v2.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0011: invoke-virtual {v1, v3}, Landroid/support/v4/view/PagerAdapter;->getPageWidth(I)F
    0014: move-result v1
    0015: iput v1, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0017: if-ltz v4, 0021
    0019: iget v1, v2.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    001b: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    001e: move-result v1
    001f: if-lt v4, v1, 0027
    0021: iget v1, v2.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0023: invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0026: return-object v0
    0027: iget v1, v2.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0029: invoke-virtual {v1, v4, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V
    002c: goto 0026

  [Virtual Method] addTouchables(Ljava/util/ArrayList;) -> V
    // registers=6, ins=2, outs=2, insns_size=36
    0000: const/4 v0, 0
    0001: invoke-virtual {v4}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    0004: move-result v1
    0005: if-ge v0, v1, 0023
    0007: invoke-virtual {v4, v0}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    000a: move-result-object v1
    000b: invoke-virtual {v1}, Landroid/view/View;->getVisibility()I
    000e: move-result v2
    000f: if-nez v2, 0020
    0011: invoke-virtual {v4, v1}, Landroid/support/v4/view/ViewPager;->infoForChild(Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    0014: move-result-object v2
    0015: if-eqz v2, 0020
    0017: iget v2, v2.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0019: iget v3, v4.Landroid/support/v4/view/ViewPager;->mCurItem:I
    001b: if-ne v2, v3, 0020
    001d: invoke-virtual {v1, v5}, Landroid/view/View;->addTouchables(Ljava/util/ArrayList;)V
    0020: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0022: goto 0001
    0023: return-void

  [Virtual Method] addView(Landroid/view/View;, I, Landroid/view/ViewGroup$LayoutParams;) -> V
    // registers=8, ins=4, outs=4, insns_size=51
    0000: invoke-virtual {v4, v7}, Landroid/support/v4/view/ViewPager;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    0003: move-result v0
    0004: if-nez v0, 0031
    0006: invoke-virtual {v4, v7}, Landroid/support/v4/view/ViewPager;->generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    0009: move-result-object v1
    000a: move(op=07) v0, v1
    000b: check-cast v0, Landroid/support/v4/view/ViewPager$LayoutParams;
    000d: iget v2, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->isDecor:Z
    000f: instance-of v3, v5, Landroid/support/v4/view/ViewPager$Decor;
    0011: binop/2addr(op=b6) v2, v3
    0012: iput v2, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->isDecor:Z
    0014: iget v2, v4.Landroid/support/v4/view/ViewPager;->mInLayout:Z
    0016: if-eqz v2, 002d
    0018: if-eqz v0, 0026
    001a: iget v2, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->isDecor:Z
    001c: if-eqz v2, 0026
    001e: new-instance v0, Ljava/lang/IllegalStateException;
    0020: const-string v1, 'Cannot add pager decor view during layout'
    0022: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0025: throw v0
    0026: const/4 v2, 1
    0027: iput v2, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->needsMeasure:Z
    0029: invoke-virtual {v4, v5, v6, v1}, Landroid/support/v4/view/ViewPager;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)Z
    002c: return-void
    002d: invoke-super {v4, v5, v6, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    0030: goto 002c
    0031: move(op=07) v1, v7
    0032: goto 000a

  [Virtual Method] arrowScroll(I) -> Z
    // registers=7, ins=2, outs=4, insns_size=119
    0000: const/16 v4, 66 (0x42)
    0002: const/16 v3, 17 (0x11)
    0004: invoke-virtual {v5}, Landroid/support/v4/view/ViewPager;->findFocus()Landroid/view/View;
    0007: move-result-object v0
    0008: if-ne v0, v5, 000b
    000a: const/4 v0, 0
    000b: const/4 v1, 0
    000c: invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;
    000f: move-result-object v2
    0010: invoke-virtual {v2, v5, v0, v6}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    0013: move-result-object v2
    0014: if-eqz v2, 0061
    0016: if-eq v2, v0, 0061
    0018: if-ne v6, v3, 0041
    001a: iget v1, v5.Landroid/support/v4/view/ViewPager;->mTempRect:Landroid/graphics/Rect;
    001c: invoke-direct {v5, v1, v2}, Landroid/support/v4/view/ViewPager;->getChildRectInPagerCoordinates(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    001f: move-result-object v1
    0020: iget v1, v1.Landroid/graphics/Rect;->left:I
    0022: iget v3, v5.Landroid/support/v4/view/ViewPager;->mTempRect:Landroid/graphics/Rect;
    0024: invoke-direct {v5, v3, v0}, Landroid/support/v4/view/ViewPager;->getChildRectInPagerCoordinates(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    0027: move-result-object v3
    0028: iget v3, v3.Landroid/graphics/Rect;->left:I
    002a: if-eqz v0, 003c
    002c: if-lt v1, v3, 003c
    002e: invoke-virtual {v5}, Landroid/support/v4/view/ViewPager;->pageLeft()Z
    0031: move-result v0
    0032: if-eqz v0, 003b
    0034: invoke-static {v6}, Landroid/view/SoundEffectConstants;->getContantForFocusDirection(I)I
    0037: move-result v1
    0038: invoke-virtual {v5, v1}, Landroid/support/v4/view/ViewPager;->playSoundEffect(I)V
    003b: return v0
    003c: invoke-virtual {v2}, Landroid/view/View;->requestFocus()Z
    003f: move-result v0
    0040: goto 0032
    0041: if-ne v6, v4, 0075
    0043: iget v1, v5.Landroid/support/v4/view/ViewPager;->mTempRect:Landroid/graphics/Rect;
    0045: invoke-direct {v5, v1, v2}, Landroid/support/v4/view/ViewPager;->getChildRectInPagerCoordinates(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    0048: move-result-object v1
    0049: iget v1, v1.Landroid/graphics/Rect;->left:I
    004b: iget v3, v5.Landroid/support/v4/view/ViewPager;->mTempRect:Landroid/graphics/Rect;
    004d: invoke-direct {v5, v3, v0}, Landroid/support/v4/view/ViewPager;->getChildRectInPagerCoordinates(Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    0050: move-result-object v3
    0051: iget v3, v3.Landroid/graphics/Rect;->left:I
    0053: if-eqz v0, 005c
    0055: if-gt v1, v3, 005c
    0057: invoke-virtual {v5}, Landroid/support/v4/view/ViewPager;->pageRight()Z
    005a: move-result v0
    005b: goto 0032
    005c: invoke-virtual {v2}, Landroid/view/View;->requestFocus()Z
    005f: move-result v0
    0060: goto 0032
    0061: if-eq v6, v3, 0066
    0063: const/4 v0, 1
    0064: if-ne v6, v0, 006b
    0066: invoke-virtual {v5}, Landroid/support/v4/view/ViewPager;->pageLeft()Z
    0069: move-result v0
    006a: goto 0032
    006b: if-eq v6, v4, 0070
    006d: const/4 v0, 2
    006e: if-ne v6, v0, 0075
    0070: invoke-virtual {v5}, Landroid/support/v4/view/ViewPager;->pageRight()Z
    0073: move-result v0
    0074: goto 0032
    0075: move(op=01) v0, v1
    0076: goto 0032

  [Virtual Method] beginFakeDrag() -> Z
    // registers=10, ins=1, outs=8, insns_size=56
    0000: const/4 v8, 1
    0001: const/4 v4, 0
    0002: const/4 v5, 0
    0003: iget v0, v9.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    0005: if-eqz v0, 0008
    0007: return v4
    0008: iput v8, v9.Landroid/support/v4/view/ViewPager;->mFakeDragging:Z
    000a: invoke-direct {v9, v8}, Landroid/support/v4/view/ViewPager;->setScrollState(I)V
    000d: iput v5, v9.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    000f: iput v5, v9.Landroid/support/v4/view/ViewPager;->mInitialMotionX:F
    0011: iget v0, v9.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0013: if-nez v0, 0032
    0015: invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;
    0018: move-result-object v0
    0019: iput v0, v9.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    001b: invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    001e: move-result-wide v0
    001f: move(op=04) v2, v0
    0020: move(op=01) v6, v5
    0021: move(op=01) v7, v4
    0022: invoke-static/range {v0..v7}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;
    0025: move-result-object v2
    0026: iget v3, v9.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0028: invoke-virtual {v3, v2}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V
    002b: invoke-virtual {v2}, Landroid/view/MotionEvent;->recycle()V
    002e: iput v0, v9.Landroid/support/v4/view/ViewPager;->mFakeDragBeginTime:J
    0030: move(op=01) v4, v8
    0031: goto 0007
    0032: iget v0, v9.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0034: invoke-virtual {v0}, Landroid/view/VelocityTracker;->clear()V
    0037: goto 001b

  [Virtual Method] canScroll(Landroid/view/View;, Z, I, I, I) -> Z
    // registers=16, ins=6, outs=6, insns_size=101
    0000: const/4 v2, 1
    0001: instance-of v0, v11, Landroid/view/ViewGroup;
    0003: if-eqz v0, 005a
    0005: move(op=07) v6, v11
    0006: check-cast v6, Landroid/view/ViewGroup;
    0008: invoke-virtual {v11}, Landroid/view/View;->getScrollX()I
    000b: move-result v8
    000c: invoke-virtual {v11}, Landroid/view/View;->getScrollY()I
    000f: move-result v9
    0010: invoke-virtual {v6}, Landroid/view/ViewGroup;->getChildCount()I
    0013: move-result v0
    0014: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    0016: move(op=01) v7, v0
    0017: if-ltz v7, 005a
    0019: invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;
    001c: move-result-object v1
    001d: binop(op=90) v0, v14, v8
    001f: invoke-virtual {v1}, Landroid/view/View;->getLeft()I
    0022: move-result v3
    0023: if-lt v0, v3, 0056
    0025: binop(op=90) v0, v14, v8
    0027: invoke-virtual {v1}, Landroid/view/View;->getRight()I
    002a: move-result v3
    002b: if-ge v0, v3, 0056
    002d: binop(op=90) v0, v15, v9
    002f: invoke-virtual {v1}, Landroid/view/View;->getTop()I
    0032: move-result v3
    0033: if-lt v0, v3, 0056
    0035: binop(op=90) v0, v15, v9
    0037: invoke-virtual {v1}, Landroid/view/View;->getBottom()I
    003a: move-result v3
    003b: if-ge v0, v3, 0056
    003d: binop(op=90) v0, v14, v8
    003f: invoke-virtual {v1}, Landroid/view/View;->getLeft()I
    0042: move-result v3
    0043: binop(op=91) v4, v0, v3
    0045: binop(op=90) v0, v15, v9
    0047: invoke-virtual {v1}, Landroid/view/View;->getTop()I
    004a: move-result v3
    004b: binop(op=91) v5, v0, v3
    004d: move(op=07) v0, v10
    004e: move(op=01) v3, v13
    004f: invoke-virtual/range {v0..v5}, Landroid/support/v4/view/ViewPager;->canScroll(Landroid/view/View;ZIII)Z
    0052: move-result v0
    0053: if-eqz v0, 0056
    0055: return v2
    0056: binop/lit8(op=d8) v0, v7, -1 (-0x1)
    0058: move(op=01) v7, v0
    0059: goto 0017
    005a: if-eqz v12, 0063
    005c: unop(op=7b) v0, v13
    005d: invoke-static {v11, v0}, Landroid/support/v4/view/ViewCompat;->canScrollHorizontally(Landroid/view/View;I)Z
    0060: move-result v0
    0061: if-nez v0, 0055
    0063: const/4 v2, 0
    0064: goto 0055

  [Virtual Method] checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;) -> Z
    // registers=3, ins=2, outs=2, insns_size=14
    0000: instance-of v0, v2, Landroid/support/v4/view/ViewPager$LayoutParams;
    0002: if-eqz v0, 000c
    0004: invoke-super {v1, v2}, Landroid/view/ViewGroup;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    0007: move-result v0
    0008: if-eqz v0, 000c
    000a: const/4 v0, 1
    000b: return v0
    000c: const/4 v0, 0
    000d: goto 000b

  [Virtual Method] computeScroll() -> V
    // registers=5, ins=1, outs=3, insns_size=66
    0000: iget v0, v4.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    0002: invoke-virtual {v0}, Landroid/widget/Scroller;->isFinished()Z
    0005: move-result v0
    0006: if-nez v0, 003e
    0008: iget v0, v4.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    000a: invoke-virtual {v0}, Landroid/widget/Scroller;->computeScrollOffset()Z
    000d: move-result v0
    000e: if-eqz v0, 003e
    0010: invoke-virtual {v4}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    0013: move-result v0
    0014: invoke-virtual {v4}, Landroid/support/v4/view/ViewPager;->getScrollY()I
    0017: move-result v1
    0018: iget v2, v4.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    001a: invoke-virtual {v2}, Landroid/widget/Scroller;->getCurrX()I
    001d: move-result v2
    001e: iget v3, v4.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    0020: invoke-virtual {v3}, Landroid/widget/Scroller;->getCurrY()I
    0023: move-result v3
    0024: if-ne v0, v2, 0028
    0026: if-eq v1, v3, 003a
    0028: invoke-virtual {v4, v2, v3}, Landroid/support/v4/view/ViewPager;->scrollTo(II)V
    002b: invoke-direct {v4, v2}, Landroid/support/v4/view/ViewPager;->pageScrolled(I)Z
    002e: move-result v0
    002f: if-nez v0, 003a
    0031: iget v0, v4.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    0033: invoke-virtual {v0}, Landroid/widget/Scroller;->abortAnimation()V
    0036: const/4 v0, 0
    0037: invoke-virtual {v4, v0, v3}, Landroid/support/v4/view/ViewPager;->scrollTo(II)V
    003a: invoke-static {v4}, Landroid/support/v4/view/ViewCompat;->postInvalidateOnAnimation(Landroid/view/View;)V
    003d: return-void
    003e: invoke-direct {v4}, Landroid/support/v4/view/ViewPager;->completeScroll()V
    0041: goto 003d

  [Virtual Method] dataSetChanged() -> V
    // registers=10, ins=1, outs=4, insns_size=214
    0000: const/4 v1, 1
    0001: const/4 v2, 0
    0002: iget v0, v9.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0004: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0007: move-result v0
    0008: iget v3, v9.Landroid/support/v4/view/ViewPager;->mOffscreenPageLimit:I
    000a: binop/lit8(op=da) v3, v3, 2 (0x2)
    000c: binop/lit8(op=d8) v3, v3, 1 (0x1)
    000e: if-ge v0, v3, 004b
    0010: iget v0, v9.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0012: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0015: move-result v0
    0016: iget v3, v9.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0018: invoke-virtual {v3}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    001b: move-result v3
    001c: if-ge v0, v3, 004b
    001e: move(op=01) v0, v1
    001f: iget v3, v9.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0021: move(op=01) v4, v2
    0022: move(op=01) v5, v3
    0023: move(op=01) v6, v0
    0024: move(op=01) v3, v2
    0025: iget v0, v9.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0027: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    002a: move-result v0
    002b: if-ge v3, v0, 0097
    002d: iget v0, v9.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    002f: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0032: move-result-object v0
    0033: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0035: iget v7, v9.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0037: iget v8, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->object:Ljava/lang/Object;
    0039: invoke-virtual {v7, v8}, Landroid/support/v4/view/PagerAdapter;->getItemPosition(Ljava/lang/Object;)I
    003c: move-result v7
    003d: const/4 v8, -1
    003e: if-ne v7, v8, 004d
    0040: move(op=01) v0, v3
    0041: move(op=01) v3, v4
    0042: move(op=01) v4, v5
    0043: move(op=01) v5, v6
    0044: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0046: move(op=01) v6, v5
    0047: move(op=01) v5, v4
    0048: move(op=01) v4, v3
    0049: move(op=01) v3, v0
    004a: goto 0025
    004b: move(op=01) v0, v2
    004c: goto 001f
    004d: const/4 v8, -2
    004e: if-ne v7, v8, 0085
    0050: iget v6, v9.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0052: invoke-virtual {v6, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    0055: binop/lit8(op=d8) v3, v3, -1 (-0x1)
    0057: if-nez v4, 005f
    0059: iget v4, v9.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    005b: invoke-virtual {v4, v9}, Landroid/support/v4/view/PagerAdapter;->startUpdate(Landroid/view/ViewGroup;)V
    005e: move(op=01) v4, v1
    005f: iget v6, v9.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0061: iget v7, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0063: iget v8, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->object:Ljava/lang/Object;
    0065: invoke-virtual {v6, v9, v7, v8}, Landroid/support/v4/view/PagerAdapter;->destroyItem(Landroid/view/ViewGroup;ILjava/lang/Object;)V
    0068: iget v6, v9.Landroid/support/v4/view/ViewPager;->mCurItem:I
    006a: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    006c: if-ne v6, v0, 00d0
    006e: iget v0, v9.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0070: iget v5, v9.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0072: invoke-virtual {v5}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    0075: move-result v5
    0076: binop/lit8(op=d8) v5, v5, -1 (-0x1)
    0078: invoke-static {v0, v5}, Ljava/lang/Math;->min(II)I
    007b: move-result v0
    007c: invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I
    007f: move-result v5
    0080: move(op=01) v0, v3
    0081: move(op=01) v3, v4
    0082: move(op=01) v4, v5
    0083: move(op=01) v5, v1
    0084: goto 0044
    0085: iget v8, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0087: if-eq v8, v7, 00ca
    0089: iget v6, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    008b: iget v8, v9.Landroid/support/v4/view/ViewPager;->mCurItem:I
    008d: if-ne v6, v8, 0090
    008f: move(op=01) v5, v7
    0090: iput v7, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0092: move(op=01) v0, v3
    0093: move(op=01) v3, v4
    0094: move(op=01) v4, v5
    0095: move(op=01) v5, v1
    0096: goto 0044
    0097: if-eqz v4, 009e
    0099: iget v0, v9.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    009b: invoke-virtual {v0, v9}, Landroid/support/v4/view/PagerAdapter;->finishUpdate(Landroid/view/ViewGroup;)V
    009e: iget v0, v9.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    00a0: sget v3, Landroid/support/v4/view/ViewPager;->COMPARATOR:Ljava/util/Comparator;
    00a2: invoke-static {v0, v3}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V
    00a5: if-eqz v6, 00c9
    00a7: invoke-virtual {v9}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    00aa: move-result v4
    00ab: move(op=01) v3, v2
    00ac: if-ge v3, v4, 00c3
    00ae: invoke-virtual {v9, v3}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    00b1: move-result-object v0
    00b2: invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    00b5: move-result-object v0
    00b6: check-cast v0, Landroid/support/v4/view/ViewPager$LayoutParams;
    00b8: iget v6, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->isDecor:Z
    00ba: if-nez v6, 00bf
    00bc: const/4 v6, 0
    00bd: iput v6, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->widthFactor:F
    00bf: binop/lit8(op=d8) v0, v3, 1 (0x1)
    00c1: move(op=01) v3, v0
    00c2: goto 00ac
    00c3: invoke-virtual {v9, v5, v2, v1}, Landroid/support/v4/view/ViewPager;->setCurrentItemInternal(IZZ)V
    00c6: invoke-virtual {v9}, Landroid/support/v4/view/ViewPager;->requestLayout()V
    00c9: return-void
    00ca: move(op=01) v0, v3
    00cb: move(op=01) v3, v4
    00cc: move(op=01) v4, v5
    00cd: move(op=01) v5, v6
    00ce: goto/16 0044
    00d0: move(op=01) v0, v3
    00d1: move(op=01) v3, v4
    00d2: move(op=01) v4, v5
    00d3: move(op=01) v5, v1
    00d4: goto/16 0044

  [Virtual Method] dispatchKeyEvent(Landroid/view/KeyEvent;) -> Z
    // registers=3, ins=2, outs=2, insns_size=16
    0000: invoke-super {v1, v2}, Landroid/view/ViewGroup;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    0003: move-result v0
    0004: if-nez v0, 000c
    0006: invoke-virtual {v1, v2}, Landroid/support/v4/view/ViewPager;->executeKeyEvent(Landroid/view/KeyEvent;)Z
    0009: move-result v0
    000a: if-eqz v0, 000e
    000c: const/4 v0, 1
    000d: return v0
    000e: const/4 v0, 0
    000f: goto 000d

  [Virtual Method] dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;) -> Z
    // registers=8, ins=2, outs=2, insns_size=41
    0000: const/4 v0, 0
    0001: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    0004: move-result v2
    0005: move(op=01) v1, v0
    0006: if-ge v1, v2, 0025
    0008: invoke-virtual {v6, v1}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    000b: move-result-object v3
    000c: invoke-virtual {v3}, Landroid/view/View;->getVisibility()I
    000f: move-result v4
    0010: if-nez v4, 0026
    0012: invoke-virtual {v6, v3}, Landroid/support/v4/view/ViewPager;->infoForChild(Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    0015: move-result-object v4
    0016: if-eqz v4, 0026
    0018: iget v4, v4.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    001a: iget v5, v6.Landroid/support/v4/view/ViewPager;->mCurItem:I
    001c: if-ne v4, v5, 0026
    001e: invoke-virtual {v3, v7}, Landroid/view/View;->dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z
    0021: move-result v3
    0022: if-eqz v3, 0026
    0024: const/4 v0, 1
    0025: return v0
    0026: binop/lit8(op=d8) v1, v1, 1 (0x1)
    0028: goto 0006

  [Virtual Method] distanceInfluenceForSnapDuration(F) -> F
    // registers=6, ins=2, outs=2, insns_size=19
    0000: const/high16 v0, 1056964608 (0x3f000000)
    0002: binop(op=a7) v0, v5, v0
    0004: unop(op=89) v0, v0
    0005: const-wide v2, 4602160705557665991 (0x3fde28c7460698c7)
    000a: binop/2addr(op=cd) v0, v2
    000b: unop(op=8c) v0, v0
    000c: unop(op=89) v0, v0
    000d: invoke-static {v0, v1}, Ljava/lang/Math;->sin(D)D
    0010: move-result-wide v0
    0011: unop(op=8c) v0, v0
    0012: return v0

  [Virtual Method] draw(Landroid/graphics/Canvas;) -> V
    // registers=9, ins=2, outs=3, insns_size=173
    0000: const/4 v2, 1
    0001: invoke-super {v7, v8}, Landroid/view/ViewGroup;->draw(Landroid/graphics/Canvas;)V
    0004: const/4 v0, 0
    0005: invoke-static {v7}, Landroid/support/v4/view/ViewCompat;->getOverScrollMode(Landroid/view/View;)I
    0008: move-result v1
    0009: if-eqz v1, 0019
    000b: if-ne v1, v2, 00a2
    000d: iget v1, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    000f: if-eqz v1, 00a2
    0011: iget v1, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0013: invoke-virtual {v1}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    0016: move-result v1
    0017: if-le v1, v2, 00a2
    0019: iget v1, v7.Landroid/support/v4/view/ViewPager;->mLeftEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    001b: invoke-virtual {v1}, Landroid/support/v4/widget/EdgeEffectCompat;->isFinished()Z
    001e: move-result v1
    001f: if-nez v1, 0059
    0021: invoke-virtual {v8}, Landroid/graphics/Canvas;->save()I
    0024: move-result v1
    0025: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getHeight()I
    0028: move-result v2
    0029: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getPaddingTop()I
    002c: move-result v3
    002d: binop/2addr(op=b1) v2, v3
    002e: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getPaddingBottom()I
    0031: move-result v3
    0032: binop/2addr(op=b1) v2, v3
    0033: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getWidth()I
    0036: move-result v3
    0037: const/high16 v4, 1132920832 (0x43870000)
    0039: invoke-virtual {v8, v4}, Landroid/graphics/Canvas;->rotate(F)V
    003c: unop(op=7b) v4, v2
    003d: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getPaddingTop()I
    0040: move-result v5
    0041: binop/2addr(op=b0) v4, v5
    0042: unop(op=82) v4, v4
    0043: iget v5, v7.Landroid/support/v4/view/ViewPager;->mFirstOffset:F
    0045: unop(op=82) v6, v3
    0046: binop/2addr(op=c8) v5, v6
    0047: invoke-virtual {v8, v4, v5}, Landroid/graphics/Canvas;->translate(FF)V
    004a: iget v4, v7.Landroid/support/v4/view/ViewPager;->mLeftEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    004c: invoke-virtual {v4, v2, v3}, Landroid/support/v4/widget/EdgeEffectCompat;->setSize(II)V
    004f: iget v2, v7.Landroid/support/v4/view/ViewPager;->mLeftEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    0051: invoke-virtual {v2, v8}, Landroid/support/v4/widget/EdgeEffectCompat;->draw(Landroid/graphics/Canvas;)Z
    0054: move-result v2
    0055: binop/2addr(op=b6) v0, v2
    0056: invoke-virtual {v8, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V
    0059: iget v1, v7.Landroid/support/v4/view/ViewPager;->mRightEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    005b: invoke-virtual {v1}, Landroid/support/v4/widget/EdgeEffectCompat;->isFinished()Z
    005e: move-result v1
    005f: if-nez v1, 009c
    0061: invoke-virtual {v8}, Landroid/graphics/Canvas;->save()I
    0064: move-result v1
    0065: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getWidth()I
    0068: move-result v2
    0069: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getHeight()I
    006c: move-result v3
    006d: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getPaddingTop()I
    0070: move-result v4
    0071: binop/2addr(op=b1) v3, v4
    0072: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getPaddingBottom()I
    0075: move-result v4
    0076: binop/2addr(op=b1) v3, v4
    0077: const/high16 v4, 1119092736 (0x42b40000)
    0079: invoke-virtual {v8, v4}, Landroid/graphics/Canvas;->rotate(F)V
    007c: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getPaddingTop()I
    007f: move-result v4
    0080: unop(op=7b) v4, v4
    0081: unop(op=82) v4, v4
    0082: iget v5, v7.Landroid/support/v4/view/ViewPager;->mLastOffset:F
    0084: const/high16 v6, 1065353216 (0x3f800000)
    0086: binop/2addr(op=c6) v5, v6
    0087: unop(op=7f) v5, v5
    0088: unop(op=82) v6, v2
    0089: binop/2addr(op=c8) v5, v6
    008a: invoke-virtual {v8, v4, v5}, Landroid/graphics/Canvas;->translate(FF)V
    008d: iget v4, v7.Landroid/support/v4/view/ViewPager;->mRightEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    008f: invoke-virtual {v4, v3, v2}, Landroid/support/v4/widget/EdgeEffectCompat;->setSize(II)V
    0092: iget v2, v7.Landroid/support/v4/view/ViewPager;->mRightEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    0094: invoke-virtual {v2, v8}, Landroid/support/v4/widget/EdgeEffectCompat;->draw(Landroid/graphics/Canvas;)Z
    0097: move-result v2
    0098: binop/2addr(op=b6) v0, v2
    0099: invoke-virtual {v8, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V
    009c: if-eqz v0, 00a1
    009e: invoke-static {v7}, Landroid/support/v4/view/ViewCompat;->postInvalidateOnAnimation(Landroid/view/View;)V
    00a1: return-void
    00a2: iget v1, v7.Landroid/support/v4/view/ViewPager;->mLeftEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    00a4: invoke-virtual {v1}, Landroid/support/v4/widget/EdgeEffectCompat;->finish()V
    00a7: iget v1, v7.Landroid/support/v4/view/ViewPager;->mRightEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    00a9: invoke-virtual {v1}, Landroid/support/v4/widget/EdgeEffectCompat;->finish()V
    00ac: goto 009c

  [Virtual Method] drawableStateChanged() -> V
    // registers=3, ins=1, outs=2, insns_size=21
    0000: invoke-super {v2}, Landroid/view/ViewGroup;->drawableStateChanged()V
    0003: iget v0, v2.Landroid/support/v4/view/ViewPager;->mMarginDrawable:Landroid/graphics/drawable/Drawable;
    0005: if-eqz v0, 0014
    0007: invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isStateful()Z
    000a: move-result v1
    000b: if-eqz v1, 0014
    000d: invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->getDrawableState()[I
    0010: move-result-object v1
    0011: invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setState([I)Z
    0014: return-void

  [Virtual Method] endFakeDrag() -> V
    // registers=7, ins=1, outs=5, insns_size=76
    0000: const/4 v5, 1
    0001: iget v0, v6.Landroid/support/v4/view/ViewPager;->mFakeDragging:Z
    0003: if-nez v0, 000d
    0005: new-instance v0, Ljava/lang/IllegalStateException;
    0007: const-string v1, 'No fake drag in progress. Call beginFakeDrag first.'
    0009: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000c: throw v0
    000d: iget v0, v6.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    000f: const/16 v1, 1000 (0x3e8)
    0011: iget v2, v6.Landroid/support/v4/view/ViewPager;->mMaximumVelocity:I
    0013: unop(op=82) v2, v2
    0014: invoke-virtual {v0, v1, v2}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V
    0017: iget v1, v6.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    0019: invoke-static {v0, v1}, Landroid/support/v4/view/VelocityTrackerCompat;->getXVelocity(Landroid/view/VelocityTracker;I)F
    001c: move-result v0
    001d: unop(op=87) v0, v0
    001e: iput v5, v6.Landroid/support/v4/view/ViewPager;->mPopulatePending:Z
    0020: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->getWidth()I
    0023: move-result v1
    0024: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    0027: move-result v2
    0028: invoke-direct {v6}, Landroid/support/v4/view/ViewPager;->infoForCurrentScrollPosition()Landroid/support/v4/view/ViewPager$ItemInfo;
    002b: move-result-object v3
    002c: iget v4, v3.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    002e: unop(op=82) v2, v2
    002f: unop(op=82) v1, v1
    0030: binop(op=a9) v1, v2, v1
    0032: iget v2, v3.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0034: binop/2addr(op=c7) v1, v2
    0035: iget v2, v3.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0037: binop/2addr(op=c9) v1, v2
    0038: iget v2, v6.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    003a: iget v3, v6.Landroid/support/v4/view/ViewPager;->mInitialMotionX:F
    003c: binop/2addr(op=c7) v2, v3
    003d: unop(op=87) v2, v2
    003e: invoke-direct {v6, v4, v1, v0, v2}, Landroid/support/v4/view/ViewPager;->determineTargetPage(IFII)I
    0041: move-result v1
    0042: invoke-virtual {v6, v1, v5, v5, v0}, Landroid/support/v4/view/ViewPager;->setCurrentItemInternal(IZZI)V
    0045: invoke-direct {v6}, Landroid/support/v4/view/ViewPager;->endDrag()V
    0048: const/4 v0, 0
    0049: iput v0, v6.Landroid/support/v4/view/ViewPager;->mFakeDragging:Z
    004b: return-void

  [Virtual Method] executeKeyEvent(Landroid/view/KeyEvent;) -> Z
    // registers=6, ins=2, outs=2, insns_size=74
    0000: const/4 v3, 1
    0001: const/4 v0, 0
    0002: invoke-virtual {v5}, Landroid/view/KeyEvent;->getAction()I
    0005: move-result v1
    0006: if-nez v1, 000f
    0008: invoke-virtual {v5}, Landroid/view/KeyEvent;->getKeyCode()I
    000b: move-result v1
    000c: sparse-switch v1, +48 (-> 003c)
    000f: return v0
    0010: const/16 v0, 17 (0x11)
    0012: invoke-virtual {v4, v0}, Landroid/support/v4/view/ViewPager;->arrowScroll(I)Z
    0015: move-result v0
    0016: goto 000f
    0017: const/16 v0, 66 (0x42)
    0019: invoke-virtual {v4, v0}, Landroid/support/v4/view/ViewPager;->arrowScroll(I)Z
    001c: move-result v0
    001d: goto 000f
    001e: sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    0020: const/16 v2, 11 (0xb)
    0022: if-lt v1, v2, 000f
    0024: invoke-static {v5}, Landroid/support/v4/view/KeyEventCompat;->hasNoModifiers(Landroid/view/KeyEvent;)Z
    0027: move-result v1
    0028: if-eqz v1, 0030
    002a: const/4 v0, 2
    002b: invoke-virtual {v4, v0}, Landroid/support/v4/view/ViewPager;->arrowScroll(I)Z
    002e: move-result v0
    002f: goto 000f
    0030: invoke-static {v5, v3}, Landroid/support/v4/view/KeyEventCompat;->hasModifiers(Landroid/view/KeyEvent;I)Z
    0033: move-result v1
    0034: if-eqz v1, 000f
    0036: invoke-virtual {v4, v3}, Landroid/support/v4/view/ViewPager;->arrowScroll(I)Z
    0039: move-result v0
    003a: goto 000f
    003b: nop
    003c: sparse-switch-payload {21: 4, 22: 11, 61: 18}

  [Virtual Method] fakeDragBy(F) -> V
    // registers=10, ins=2, outs=8, insns_size=147
    0000: const/4 v7, 0
    0001: iget v0, v8.Landroid/support/v4/view/ViewPager;->mFakeDragging:Z
    0003: if-nez v0, 000d
    0005: new-instance v0, Ljava/lang/IllegalStateException;
    0007: const-string v1, 'No fake drag in progress. Call beginFakeDrag first.'
    0009: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000c: throw v0
    000d: iget v0, v8.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    000f: binop/2addr(op=c6) v0, v9
    0010: iput v0, v8.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0012: invoke-virtual {v8}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    0015: move-result v0
    0016: unop(op=82) v0, v0
    0017: binop(op=a7) v3, v0, v9
    0019: invoke-virtual {v8}, Landroid/support/v4/view/ViewPager;->getWidth()I
    001c: move-result v5
    001d: unop(op=82) v0, v5
    001e: iget v1, v8.Landroid/support/v4/view/ViewPager;->mFirstOffset:F
    0020: binop(op=a8) v2, v0, v1
    0022: unop(op=82) v0, v5
    0023: iget v1, v8.Landroid/support/v4/view/ViewPager;->mLastOffset:F
    0025: binop(op=a8) v4, v0, v1
    0027: iget v0, v8.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0029: invoke-virtual {v0, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    002c: move-result-object v0
    002d: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    002f: iget v1, v8.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0031: iget v6, v8.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0033: invoke-virtual {v6}, Ljava/util/ArrayList;->size()I
    0036: move-result v6
    0037: binop/lit8(op=d8) v6, v6, -1 (-0x1)
    0039: invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    003c: move-result-object v1
    003d: check-cast v1, Landroid/support/v4/view/ViewPager$ItemInfo;
    003f: iget v6, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0041: if-eqz v6, 0091
    0043: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0045: unop(op=82) v2, v5
    0046: binop/2addr(op=c8) v0, v2
    0047: iget v2, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0049: iget v6, v8.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    004b: invoke-virtual {v6}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    004e: move-result v6
    004f: binop/lit8(op=d8) v6, v6, -1 (-0x1)
    0051: if-eq v2, v6, 008f
    0053: iget v1, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0055: unop(op=82) v2, v5
    0056: binop/2addr(op=c8) v1, v2
    0057: cmp(op=2e) v2, v3, v0
    0059: if-gez v2, 0087
    005b: iget v1, v8.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    005d: unop(op=87) v2, v0
    005e: unop(op=82) v2, v2
    005f: binop(op=a7) v2, v0, v2
    0061: binop/2addr(op=c6) v1, v2
    0062: iput v1, v8.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0064: unop(op=87) v1, v0
    0065: invoke-virtual {v8}, Landroid/support/v4/view/ViewPager;->getScrollY()I
    0068: move-result v2
    0069: invoke-virtual {v8, v1, v2}, Landroid/support/v4/view/ViewPager;->scrollTo(II)V
    006c: unop(op=87) v0, v0
    006d: invoke-direct {v8, v0}, Landroid/support/v4/view/ViewPager;->pageScrolled(I)Z
    0070: invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    0073: move-result-wide v2
    0074: iget v0, v8.Landroid/support/v4/view/ViewPager;->mFakeDragBeginTime:J
    0076: const/4 v4, 2
    0077: iget v5, v8.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0079: const/4 v6, 0
    007a: invoke-static/range {v0..v7}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;
    007d: move-result-object v0
    007e: iget v1, v8.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0080: invoke-virtual {v1, v0}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V
    0083: invoke-virtual {v0}, Landroid/view/MotionEvent;->recycle()V
    0086: return-void
    0087: cmp(op=2d) v0, v3, v1
    0089: if-lez v0, 008d
    008b: move(op=01) v0, v1
    008c: goto 005b
    008d: move(op=01) v0, v3
    008e: goto 005b
    008f: move(op=01) v1, v4
    0090: goto 0057
    0091: move(op=01) v0, v2
    0092: goto 0047

  [Virtual Method] generateDefaultLayoutParams() -> Landroid/view/ViewGroup$LayoutParams;
    // registers=2, ins=1, outs=1, insns_size=6
    0000: new-instance v0, Landroid/support/v4/view/ViewPager$LayoutParams;
    0002: invoke-direct {v0}, Landroid/support/v4/view/ViewPager$LayoutParams;-><init>()V
    0005: return-object v0

  [Virtual Method] generateLayoutParams(Landroid/util/AttributeSet;) -> Landroid/view/ViewGroup$LayoutParams;
    // registers=4, ins=2, outs=3, insns_size=10
    0000: new-instance v0, Landroid/support/v4/view/ViewPager$LayoutParams;
    0002: invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->getContext()Landroid/content/Context;
    0005: move-result-object v1
    0006: invoke-direct {v0, v1, v3}, Landroid/support/v4/view/ViewPager$LayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    0009: return-object v0

  [Virtual Method] generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;) -> Landroid/view/ViewGroup$LayoutParams;
    // registers=3, ins=2, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/support/v4/view/ViewPager;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] getAdapter() -> Landroid/support/v4/view/PagerAdapter;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0002: return-object v0

  [Virtual Method] getCurrentItem() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0002: return v0

  [Virtual Method] getOffscreenPageLimit() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager;->mOffscreenPageLimit:I
    0002: return v0

  [Virtual Method] getPageMargin() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0002: return v0

  [Virtual Method] infoForAnyChild(Landroid/view/View;) -> Landroid/support/v4/view/ViewPager$ItemInfo;
    // registers=4, ins=2, outs=2, insns_size=23
    0000: invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;
    0003: move-result-object v0
    0004: if-eq v0, v2, 0012
    0006: if-eqz v0, 000c
    0008: instance-of v1, v0, Landroid/view/View;
    000a: if-nez v1, 000e
    000c: const/4 v0, 0
    000d: return-object v0
    000e: check-cast v0, Landroid/view/View;
    0010: move(op=07) v3, v0
    0011: goto 0000
    0012: invoke-virtual {v2, v3}, Landroid/support/v4/view/ViewPager;->infoForChild(Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    0015: move-result-object v0
    0016: goto 000d

  [Virtual Method] infoForChild(Landroid/view/View;) -> Landroid/support/v4/view/ViewPager$ItemInfo;
    // registers=6, ins=2, outs=3, insns_size=35
    0000: const/4 v0, 0
    0001: move(op=01) v1, v0
    0002: iget v0, v4.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0004: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0007: move-result v0
    0008: if-ge v1, v0, 0021
    000a: iget v0, v4.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    000c: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    000f: move-result-object v0
    0010: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0012: iget v2, v4.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0014: iget v3, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->object:Ljava/lang/Object;
    0016: invoke-virtual {v2, v5, v3}, Landroid/support/v4/view/PagerAdapter;->isViewFromObject(Landroid/view/View;Ljava/lang/Object;)Z
    0019: move-result v2
    001a: if-eqz v2, 001d
    001c: return-object v0
    001d: binop/lit8(op=d8) v0, v1, 1 (0x1)
    001f: move(op=01) v1, v0
    0020: goto 0002
    0021: const/4 v0, 0
    0022: goto 001c

  [Virtual Method] infoForPosition(I) -> Landroid/support/v4/view/ViewPager$ItemInfo;
    // registers=5, ins=2, outs=2, insns_size=29
    0000: const/4 v0, 0
    0001: move(op=01) v1, v0
    0002: iget v0, v3.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0004: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0007: move-result v0
    0008: if-ge v1, v0, 001b
    000a: iget v0, v3.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    000c: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    000f: move-result-object v0
    0010: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0012: iget v2, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0014: if-ne v2, v4, 0017
    0016: return-object v0
    0017: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0019: move(op=01) v1, v0
    001a: goto 0002
    001b: const/4 v0, 0
    001c: goto 0016

  [Virtual Method] initViewPager() -> V
    // registers=5, ins=1, outs=3, insns_size=108
    0000: const/4 v3, 1
    0001: const/4 v0, 0
    0002: invoke-virtual {v4, v0}, Landroid/support/v4/view/ViewPager;->setWillNotDraw(Z)V
    0005: const/high16 v0, 262144 (0x40000)
    0007: invoke-virtual {v4, v0}, Landroid/support/v4/view/ViewPager;->setDescendantFocusability(I)V
    000a: invoke-virtual {v4, v3}, Landroid/support/v4/view/ViewPager;->setFocusable(Z)V
    000d: invoke-virtual {v4}, Landroid/support/v4/view/ViewPager;->getContext()Landroid/content/Context;
    0010: move-result-object v0
    0011: new-instance v1, Landroid/widget/Scroller;
    0013: sget v2, Landroid/support/v4/view/ViewPager;->sInterpolator:Landroid/view/animation/Interpolator;
    0015: invoke-direct {v1, v0, v2}, Landroid/widget/Scroller;-><init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V
    0018: iput v1, v4.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    001a: invoke-static {v0}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;
    001d: move-result-object v1
    001e: invoke-static {v1}, Landroid/support/v4/view/ViewConfigurationCompat;->getScaledPagingTouchSlop(Landroid/view/ViewConfiguration;)I
    0021: move-result v2
    0022: iput v2, v4.Landroid/support/v4/view/ViewPager;->mTouchSlop:I
    0024: invoke-virtual {v1}, Landroid/view/ViewConfiguration;->getScaledMinimumFlingVelocity()I
    0027: move-result v2
    0028: iput v2, v4.Landroid/support/v4/view/ViewPager;->mMinimumVelocity:I
    002a: invoke-virtual {v1}, Landroid/view/ViewConfiguration;->getScaledMaximumFlingVelocity()I
    002d: move-result v1
    002e: iput v1, v4.Landroid/support/v4/view/ViewPager;->mMaximumVelocity:I
    0030: new-instance v1, Landroid/support/v4/widget/EdgeEffectCompat;
    0032: invoke-direct {v1, v0}, Landroid/support/v4/widget/EdgeEffectCompat;-><init>(Landroid/content/Context;)V
    0035: iput v1, v4.Landroid/support/v4/view/ViewPager;->mLeftEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    0037: new-instance v1, Landroid/support/v4/widget/EdgeEffectCompat;
    0039: invoke-direct {v1, v0}, Landroid/support/v4/widget/EdgeEffectCompat;-><init>(Landroid/content/Context;)V
    003c: iput v1, v4.Landroid/support/v4/view/ViewPager;->mRightEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    003e: invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    0041: move-result-object v0
    0042: invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    0045: move-result-object v0
    0046: iget v0, v0.Landroid/util/DisplayMetrics;->density:F
    0048: const/high16 v1, 1103626240 (0x41c80000)
    004a: binop/2addr(op=c8) v1, v0
    004b: unop(op=87) v1, v1
    004c: iput v1, v4.Landroid/support/v4/view/ViewPager;->mFlingDistance:I
    004e: const/high16 v1, 1073741824 (0x40000000)
    0050: binop/2addr(op=c8) v1, v0
    0051: unop(op=87) v1, v1
    0052: iput v1, v4.Landroid/support/v4/view/ViewPager;->mCloseEnough:I
    0054: const/high16 v1, 1098907648 (0x41800000)
    0056: binop/2addr(op=c8) v0, v1
    0057: unop(op=87) v0, v0
    0058: iput v0, v4.Landroid/support/v4/view/ViewPager;->mDefaultGutterSize:I
    005a: new-instance v0, Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;
    005c: invoke-direct {v0, v4}, Landroid/support/v4/view/ViewPager$MyAccessibilityDelegate;-><init>(Landroid/support/v4/view/ViewPager;)V
    005f: invoke-static {v4, v0}, Landroid/support/v4/view/ViewCompat;->setAccessibilityDelegate(Landroid/view/View;Landroid/support/v4/view/AccessibilityDelegateCompat;)V
    0062: invoke-static {v4}, Landroid/support/v4/view/ViewCompat;->getImportantForAccessibility(Landroid/view/View;)I
    0065: move-result v0
    0066: if-nez v0, 006b
    0068: invoke-static {v4, v3}, Landroid/support/v4/view/ViewCompat;->setImportantForAccessibility(Landroid/view/View;I)V
    006b: return-void

  [Virtual Method] isFakeDragging() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager;->mFakeDragging:Z
    0002: return v0

  [Virtual Method] onAttachedToWindow() -> V
    // registers=2, ins=1, outs=1, insns_size=7
    0000: invoke-super {v1}, Landroid/view/ViewGroup;->onAttachedToWindow()V
    0003: const/4 v0, 1
    0004: iput v0, v1.Landroid/support/v4/view/ViewPager;->mFirstLayout:Z
    0006: return-void

  [Virtual Method] onDraw(Landroid/graphics/Canvas;) -> V
    // registers=18, ins=2, outs=5, insns_size=198
    0000: invoke-super/range {v16..v17}, Landroid/view/ViewGroup;->onDraw(Landroid/graphics/Canvas;)V
    0003: move/from16 v0, v16
    0005: iget v1, v0.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0007: if-lez v1, 00b2
    0009: move/from16 v0, v16
    000b: iget v1, v0.Landroid/support/v4/view/ViewPager;->mMarginDrawable:Landroid/graphics/drawable/Drawable;
    000d: if-eqz v1, 00b2
    000f: move/from16 v0, v16
    0011: iget v1, v0.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0013: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0016: move-result v1
    0017: if-lez v1, 00b2
    0019: move/from16 v0, v16
    001b: iget v1, v0.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    001d: if-eqz v1, 00b2
    001f: invoke-virtual/range {v16..v16}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    0022: move-result v6
    0023: invoke-virtual/range {v16..v16}, Landroid/support/v4/view/ViewPager;->getWidth()I
    0026: move-result v7
    0027: move/from16 v0, v16
    0029: iget v1, v0.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    002b: unop(op=82) v1, v1
    002c: unop(op=82) v2, v7
    002d: binop(op=a9) v8, v1, v2
    002f: const/4 v5, 0
    0030: move/from16 v0, v16
    0032: iget v1, v0.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0034: const/4 v2, 0
    0035: invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0038: move-result-object v1
    0039: check-cast v1, Landroid/support/v4/view/ViewPager$ItemInfo;
    003b: iget v4, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    003d: move/from16 v0, v16
    003f: iget v2, v0.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0041: invoke-virtual {v2}, Ljava/util/ArrayList;->size()I
    0044: move-result v9
    0045: iget v3, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0047: move/from16 v0, v16
    0049: iget v2, v0.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    004b: binop/lit8(op=d8) v10, v9, -1 (-0x1)
    004d: invoke-virtual {v2, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0050: move-result-object v2
    0051: check-cast v2, Landroid/support/v4/view/ViewPager$ItemInfo;
    0053: iget v10, v2.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0055: move(op=01) v2, v5
    0056: move(op=01) v5, v3
    0057: if-ge v5, v10, 00b2
    0059: iget v3, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    005b: if-le v5, v3, 006c
    005d: if-ge v2, v9, 006c
    005f: move/from16 v0, v16
    0061: iget v1, v0.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0063: binop/lit8(op=d8) v2, v2, 1 (0x1)
    0065: invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0068: move-result-object v1
    0069: check-cast v1, Landroid/support/v4/view/ViewPager$ItemInfo;
    006b: goto 0059
    006c: iget v3, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    006e: if-ne v5, v3, 00b3
    0070: iget v3, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0072: iget v4, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0074: binop/2addr(op=c6) v3, v4
    0075: unop(op=82) v4, v7
    0076: binop/2addr(op=c8) v3, v4
    0077: iget v4, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0079: iget v11, v1.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    007b: binop/2addr(op=c6) v4, v11
    007c: binop/2addr(op=c6) v4, v8
    007d: move/from16 v0, v16
    007f: iget v11, v0.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0081: unop(op=82) v11, v11
    0082: binop/2addr(op=c6) v11, v3
    0083: unop(op=82) v12, v6
    0084: cmp(op=2d) v11, v11, v12
    0086: if-lez v11, 00ab
    0088: move/from16 v0, v16
    008a: iget v11, v0.Landroid/support/v4/view/ViewPager;->mMarginDrawable:Landroid/graphics/drawable/Drawable;
    008c: unop(op=87) v12, v3
    008d: move/from16 v0, v16
    008f: iget v13, v0.Landroid/support/v4/view/ViewPager;->mTopPageBounds:I
    0091: move/from16 v0, v16
    0093: iget v14, v0.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0095: unop(op=82) v14, v14
    0096: binop/2addr(op=c6) v14, v3
    0097: const/high16 v15, 1056964608 (0x3f000000)
    0099: binop/2addr(op=c6) v14, v15
    009a: unop(op=87) v14, v14
    009b: move/from16 v0, v16
    009d: iget v15, v0.Landroid/support/v4/view/ViewPager;->mBottomPageBounds:I
    009f: invoke-virtual {v11, v12, v13, v14, v15}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V
    00a2: move/from16 v0, v16
    00a4: iget v11, v0.Landroid/support/v4/view/ViewPager;->mMarginDrawable:Landroid/graphics/drawable/Drawable;
    00a6: move/from16 v0, v17
    00a8: invoke-virtual {v11, v0}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V
    00ab: binop(op=90) v11, v6, v7
    00ad: unop(op=82) v11, v11
    00ae: cmp(op=2d) v3, v3, v11
    00b0: if-lez v3, 00c2
    00b2: return-void
    00b3: move/from16 v0, v16
    00b5: iget v3, v0.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    00b7: invoke-virtual {v3, v5}, Landroid/support/v4/view/PagerAdapter;->getPageWidth(I)F
    00ba: move-result v11
    00bb: binop(op=a6) v3, v4, v11
    00bd: unop(op=82) v12, v7
    00be: binop/2addr(op=c8) v3, v12
    00bf: binop/2addr(op=c6) v11, v8
    00c0: binop/2addr(op=c6) v4, v11
    00c1: goto 007d
    00c2: binop/lit8(op=d8) v3, v5, 1 (0x1)
    00c4: move(op=01) v5, v3
    00c5: goto 0057

  [Virtual Method] onInterceptTouchEvent(Landroid/view/MotionEvent;) -> Z
    // registers=15, ins=2, outs=6, insns_size=290
    0000: const/4 v3, -1
    0001: const/4 v12, 0
    0002: const/4 v6, 1
    0003: const/4 v2, 0
    0004: invoke-virtual {v14}, Landroid/view/MotionEvent;->getAction()I
    0007: move-result v0
    0008: binop/lit16(op=d5) v0, v0, 255 (0xff)
    000a: const/4 v1, 3
    000b: if-eq v0, v1, 000f
    000d: if-ne v0, v6, 0022
    000f: iput v2, v13.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    0011: iput v2, v13.Landroid/support/v4/view/ViewPager;->mIsUnableToDrag:Z
    0013: iput v3, v13.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    0015: iget v0, v13.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0017: if-eqz v0, 0021
    0019: iget v0, v13.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    001b: invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V
    001e: const/4 v0, 0
    001f: iput v0, v13.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0021: return v2
    0022: if-eqz v0, 002e
    0024: iget v1, v13.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    0026: if-eqz v1, 002a
    0028: move(op=01) v2, v6
    0029: goto 0021
    002a: iget v1, v13.Landroid/support/v4/view/ViewPager;->mIsUnableToDrag:Z
    002c: if-nez v1, 0021
    002e: sparse-switch v0, +230 (-> 0114)
    0031: iget v0, v13.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0033: if-nez v0, 003b
    0035: invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;
    0038: move-result-object v0
    0039: iput v0, v13.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    003b: iget v0, v13.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    003d: invoke-virtual {v0, v14}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V
    0040: iget v2, v13.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    0042: goto 0021
    0043: iget v0, v13.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    0045: if-eq v0, v3, 0031
    0047: invoke-static {v14, v0}, Landroid/support/v4/view/MotionEventCompat;->findPointerIndex(Landroid/view/MotionEvent;I)I
    004a: move-result v0
    004b: invoke-static {v14, v0}, Landroid/support/v4/view/MotionEventCompat;->getX(Landroid/view/MotionEvent;I)F
    004e: move-result v7
    004f: iget v1, v13.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0051: binop(op=a7) v8, v7, v1
    0053: invoke-static {v8}, Ljava/lang/Math;->abs(F)F
    0056: move-result v9
    0057: invoke-static {v14, v0}, Landroid/support/v4/view/MotionEventCompat;->getY(Landroid/view/MotionEvent;I)F
    005a: move-result v10
    005b: iget v0, v13.Landroid/support/v4/view/ViewPager;->mLastMotionY:F
    005d: binop(op=a7) v0, v10, v0
    005f: invoke-static {v0}, Ljava/lang/Math;->abs(F)F
    0062: move-result v11
    0063: cmp(op=2d) v0, v8, v12
    0065: if-eqz v0, 0083
    0067: iget v0, v13.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0069: invoke-direct {v13, v0, v8}, Landroid/support/v4/view/ViewPager;->isGutterDrag(FF)Z
    006c: move-result v0
    006d: if-nez v0, 0083
    006f: unop(op=87) v3, v8
    0070: unop(op=87) v4, v7
    0071: unop(op=87) v5, v10
    0072: move(op=07) v0, v13
    0073: move(op=07) v1, v13
    0074: invoke-virtual/range {v0..v5}, Landroid/support/v4/view/ViewPager;->canScroll(Landroid/view/View;ZIII)Z
    0077: move-result v0
    0078: if-eqz v0, 0083
    007a: iput v7, v13.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    007c: iput v7, v13.Landroid/support/v4/view/ViewPager;->mInitialMotionX:F
    007e: iput v10, v13.Landroid/support/v4/view/ViewPager;->mLastMotionY:F
    0080: iput v6, v13.Landroid/support/v4/view/ViewPager;->mIsUnableToDrag:Z
    0082: goto 0021
    0083: iget v0, v13.Landroid/support/v4/view/ViewPager;->mTouchSlop:I
    0085: unop(op=82) v0, v0
    0086: cmp(op=2d) v0, v9, v0
    0088: if-lez v0, 00b7
    008a: cmp(op=2d) v0, v9, v11
    008c: if-lez v0, 00b7
    008e: iput v6, v13.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    0090: invoke-direct {v13, v6}, Landroid/support/v4/view/ViewPager;->setScrollState(I)V
    0093: cmp(op=2d) v0, v8, v12
    0095: if-lez v0, 00b0
    0097: iget v0, v13.Landroid/support/v4/view/ViewPager;->mInitialMotionX:F
    0099: iget v1, v13.Landroid/support/v4/view/ViewPager;->mTouchSlop:I
    009b: unop(op=82) v1, v1
    009c: binop/2addr(op=c6) v0, v1
    009d: iput v0, v13.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    009f: invoke-direct {v13, v6}, Landroid/support/v4/view/ViewPager;->setScrollingCacheEnabled(Z)V
    00a2: iget v0, v13.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    00a4: if-eqz v0, 0031
    00a6: invoke-direct {v13, v7}, Landroid/support/v4/view/ViewPager;->performDrag(F)Z
    00a9: move-result v0
    00aa: if-eqz v0, 0031
    00ac: invoke-static {v13}, Landroid/support/v4/view/ViewCompat;->postInvalidateOnAnimation(Landroid/view/View;)V
    00af: goto 0031
    00b0: iget v0, v13.Landroid/support/v4/view/ViewPager;->mInitialMotionX:F
    00b2: iget v1, v13.Landroid/support/v4/view/ViewPager;->mTouchSlop:I
    00b4: unop(op=82) v1, v1
    00b5: binop/2addr(op=c7) v0, v1
    00b6: goto 009d
    00b7: iget v0, v13.Landroid/support/v4/view/ViewPager;->mTouchSlop:I
    00b9: unop(op=82) v0, v0
    00ba: cmp(op=2d) v0, v11, v0
    00bc: if-lez v0, 00a2
    00be: iput v6, v13.Landroid/support/v4/view/ViewPager;->mIsUnableToDrag:Z
    00c0: goto 00a2
    00c1: invoke-virtual {v14}, Landroid/view/MotionEvent;->getX()F
    00c4: move-result v0
    00c5: iput v0, v13.Landroid/support/v4/view/ViewPager;->mInitialMotionX:F
    00c7: iput v0, v13.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    00c9: invoke-virtual {v14}, Landroid/view/MotionEvent;->getY()F
    00cc: move-result v0
    00cd: iput v0, v13.Landroid/support/v4/view/ViewPager;->mLastMotionY:F
    00cf: invoke-static {v14, v2}, Landroid/support/v4/view/MotionEventCompat;->getPointerId(Landroid/view/MotionEvent;I)I
    00d2: move-result v0
    00d3: iput v0, v13.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    00d5: iput v2, v13.Landroid/support/v4/view/ViewPager;->mIsUnableToDrag:Z
    00d7: iget v0, v13.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    00d9: invoke-virtual {v0}, Landroid/widget/Scroller;->computeScrollOffset()Z
    00dc: iget v0, v13.Landroid/support/v4/view/ViewPager;->mScrollState:I
    00de: const/4 v1, 2
    00df: if-ne v0, v1, 0107
    00e1: iget v0, v13.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    00e3: invoke-virtual {v0}, Landroid/widget/Scroller;->getFinalX()I
    00e6: move-result v0
    00e7: iget v1, v13.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    00e9: invoke-virtual {v1}, Landroid/widget/Scroller;->getCurrX()I
    00ec: move-result v1
    00ed: binop/2addr(op=b1) v0, v1
    00ee: invoke-static {v0}, Ljava/lang/Math;->abs(I)I
    00f1: move-result v0
    00f2: iget v1, v13.Landroid/support/v4/view/ViewPager;->mCloseEnough:I
    00f4: if-le v0, v1, 0107
    00f6: iget v0, v13.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    00f8: invoke-virtual {v0}, Landroid/widget/Scroller;->abortAnimation()V
    00fb: iput v2, v13.Landroid/support/v4/view/ViewPager;->mPopulatePending:Z
    00fd: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->populate()V
    0100: iput v6, v13.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    0102: invoke-direct {v13, v6}, Landroid/support/v4/view/ViewPager;->setScrollState(I)V
    0105: goto/16 0031
    0107: invoke-direct {v13}, Landroid/support/v4/view/ViewPager;->completeScroll()V
    010a: iput v2, v13.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    010c: goto/16 0031
    010e: invoke-direct {v13, v14}, Landroid/support/v4/view/ViewPager;->onSecondaryPointerUp(Landroid/view/MotionEvent;)V
    0111: goto/16 0031
    0113: nop
    0114: sparse-switch-payload {0: 147, 2: 21, 6: 224}

  [Virtual Method] onLayout(Z, I, I, I, I) -> V
    // registers=23, ins=6, outs=5, insns_size=350
    0000: const/4 v1, 1
    0001: move/from16 v0, v17
    0003: iput v1, v0.Landroid/support/v4/view/ViewPager;->mInLayout:Z
    0005: invoke-virtual/range {v17..v17}, Landroid/support/v4/view/ViewPager;->populate()V
    0008: const/4 v1, 0
    0009: move/from16 v0, v17
    000b: iput v1, v0.Landroid/support/v4/view/ViewPager;->mInLayout:Z
    000d: invoke-virtual/range {v17..v17}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    0010: move-result v9
    0011: binop(op=91) v10, v21, v19
    0013: binop(op=91) v11, v22, v20
    0015: invoke-virtual/range {v17..v17}, Landroid/support/v4/view/ViewPager;->getPaddingLeft()I
    0018: move-result v6
    0019: invoke-virtual/range {v17..v17}, Landroid/support/v4/view/ViewPager;->getPaddingTop()I
    001c: move-result v2
    001d: invoke-virtual/range {v17..v17}, Landroid/support/v4/view/ViewPager;->getPaddingRight()I
    0020: move-result v5
    0021: invoke-virtual/range {v17..v17}, Landroid/support/v4/view/ViewPager;->getPaddingBottom()I
    0024: move-result v3
    0025: invoke-virtual/range {v17..v17}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    0028: move-result v12
    0029: const/4 v4, 0
    002a: const/4 v1, 0
    002b: move(op=01) v8, v1
    002c: if-ge v8, v9, 00cb
    002e: move/from16 v0, v17
    0030: invoke-virtual {v0, v8}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    0033: move-result-object v13
    0034: invoke-virtual {v13}, Landroid/view/View;->getVisibility()I
    0037: move-result v1
    0038: const/16 v7, 8 (0x8)
    003a: if-eq v1, v7, 013b
    003c: invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    003f: move-result-object v1
    0040: check-cast v1, Landroid/support/v4/view/ViewPager$LayoutParams;
    0042: iget v7, v1.Landroid/support/v4/view/ViewPager$LayoutParams;->isDecor:Z
    0044: if-eqz v7, 013b
    0046: iget v7, v1.Landroid/support/v4/view/ViewPager$LayoutParams;->gravity:I
    0048: binop/lit8(op=dd) v7, v7, 7 (0x7)
    004a: iget v1, v1.Landroid/support/v4/view/ViewPager$LayoutParams;->gravity:I
    004c: binop/lit8(op=dd) v14, v1, 112 (0x70)
    004e: packed-switch v7, +244 (-> 0142)
    0051: move(op=01) v7, v6
    0052: sparse-switch v14, +254 (-> 0150)
    0055: move(op=01) v1, v2
    0056: move/from16 v16, v3
    0058: move(op=01) v3, v2
    0059: move/from16 v2, v16
    005b: binop/2addr(op=b0) v7, v12
    005c: invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I
    005f: move-result v14
    0060: binop/2addr(op=b0) v14, v7
    0061: invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I
    0064: move-result v15
    0065: binop/2addr(op=b0) v15, v1
    0066: invoke-virtual {v13, v7, v1, v14, v15}, Landroid/view/View;->layout(IIII)V
    0069: binop/lit8(op=d8) v1, v4, 1 (0x1)
    006b: move(op=01) v4, v3
    006c: move(op=01) v3, v2
    006d: move(op=01) v2, v5
    006e: move(op=01) v5, v6
    006f: binop/lit8(op=d8) v6, v8, 1 (0x1)
    0071: move(op=01) v8, v6
    0072: move(op=01) v6, v5
    0073: move(op=01) v5, v2
    0074: move(op=01) v2, v4
    0075: move(op=01) v4, v1
    0076: goto 002c
    0077: invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I
    007a: move-result v1
    007b: binop/2addr(op=b0) v1, v6
    007c: move(op=01) v7, v6
    007d: move(op=01) v6, v1
    007e: goto 0052
    007f: invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I
    0082: move-result v1
    0083: binop(op=91) v1, v10, v1
    0085: binop/lit8(op=db) v1, v1, 2 (0x2)
    0087: invoke-static {v1, v6}, Ljava/lang/Math;->max(II)I
    008a: move-result v1
    008b: move(op=01) v7, v1
    008c: goto 0052
    008d: binop(op=91) v1, v10, v5
    008f: invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I
    0092: move-result v7
    0093: binop/2addr(op=b1) v1, v7
    0094: invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I
    0097: move-result v7
    0098: binop/2addr(op=b0) v5, v7
    0099: move(op=01) v7, v1
    009a: goto 0052
    009b: invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I
    009e: move-result v1
    009f: binop/2addr(op=b0) v1, v2
    00a0: move/from16 v16, v2
    00a2: move(op=01) v2, v3
    00a3: move(op=01) v3, v1
    00a4: move/from16 v1, v16
    00a6: goto 005b
    00a7: invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I
    00aa: move-result v1
    00ab: binop(op=91) v1, v11, v1
    00ad: binop/lit8(op=db) v1, v1, 2 (0x2)
    00af: invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I
    00b2: move-result v1
    00b3: move/from16 v16, v3
    00b5: move(op=01) v3, v2
    00b6: move/from16 v2, v16
    00b8: goto 005b
    00b9: binop(op=91) v1, v11, v3
    00bb: invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I
    00be: move-result v14
    00bf: binop/2addr(op=b1) v1, v14
    00c0: invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I
    00c3: move-result v14
    00c4: binop/2addr(op=b0) v3, v14
    00c5: move/from16 v16, v3
    00c7: move(op=01) v3, v2
    00c8: move/from16 v2, v16
    00ca: goto 005b
    00cb: const/4 v1, 0
    00cc: move(op=01) v7, v1
    00cd: if-ge v7, v9, 0127
    00cf: move/from16 v0, v17
    00d1: invoke-virtual {v0, v7}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    00d4: move-result-object v8
    00d5: invoke-virtual {v8}, Landroid/view/View;->getVisibility()I
    00d8: move-result v1
    00d9: const/16 v12, 8 (0x8)
    00db: if-eq v1, v12, 0123
    00dd: invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    00e0: move-result-object v1
    00e1: check-cast v1, Landroid/support/v4/view/ViewPager$LayoutParams;
    00e3: iget v12, v1.Landroid/support/v4/view/ViewPager$LayoutParams;->isDecor:Z
    00e5: if-nez v12, 0123
    00e7: move/from16 v0, v17
    00e9: invoke-virtual {v0, v8}, Landroid/support/v4/view/ViewPager;->infoForChild(Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    00ec: move-result-object v12
    00ed: if-eqz v12, 0123
    00ef: unop(op=82) v13, v10
    00f0: iget v12, v12.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    00f2: binop/2addr(op=c8) v12, v13
    00f3: unop(op=87) v12, v12
    00f4: binop/2addr(op=b0) v12, v6
    00f5: iget v13, v1.Landroid/support/v4/view/ViewPager$LayoutParams;->needsMeasure:Z
    00f7: if-eqz v13, 0116
    00f9: const/4 v13, 0
    00fa: iput v13, v1.Landroid/support/v4/view/ViewPager$LayoutParams;->needsMeasure:Z
    00fc: binop(op=91) v13, v10, v6
    00fe: binop/2addr(op=b1) v13, v5
    00ff: unop(op=82) v13, v13
    0100: iget v1, v1.Landroid/support/v4/view/ViewPager$LayoutParams;->widthFactor:F
    0102: binop/2addr(op=c8) v1, v13
    0103: unop(op=87) v1, v1
    0104: const/high16 v13, 1073741824 (0x40000000)
    0106: invoke-static {v1, v13}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    0109: move-result v1
    010a: binop(op=91) v13, v11, v2
    010c: binop/2addr(op=b1) v13, v3
    010d: const/high16 v14, 1073741824 (0x40000000)
    010f: invoke-static {v13, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    0112: move-result v13
    0113: invoke-virtual {v8, v1, v13}, Landroid/view/View;->measure(II)V
    0116: invoke-virtual {v8}, Landroid/view/View;->getMeasuredWidth()I
    0119: move-result v1
    011a: binop/2addr(op=b0) v1, v12
    011b: invoke-virtual {v8}, Landroid/view/View;->getMeasuredHeight()I
    011e: move-result v13
    011f: binop/2addr(op=b0) v13, v2
    0120: invoke-virtual {v8, v12, v2, v1, v13}, Landroid/view/View;->layout(IIII)V
    0123: binop/lit8(op=d8) v1, v7, 1 (0x1)
    0125: move(op=01) v7, v1
    0126: goto 00cd
    0127: move/from16 v0, v17
    0129: iput v2, v0.Landroid/support/v4/view/ViewPager;->mTopPageBounds:I
    012b: binop(op=91) v1, v11, v3
    012d: move/from16 v0, v17
    012f: iput v1, v0.Landroid/support/v4/view/ViewPager;->mBottomPageBounds:I
    0131: move/from16 v0, v17
    0133: iput v4, v0.Landroid/support/v4/view/ViewPager;->mDecorChildCount:I
    0135: const/4 v1, 0
    0136: move/from16 v0, v17
    0138: iput v1, v0.Landroid/support/v4/view/ViewPager;->mFirstLayout:Z
    013a: return-void
    013b: move(op=01) v1, v4
    013c: move(op=01) v4, v2
    013d: move(op=01) v2, v5
    013e: move(op=01) v5, v6
    013f: goto/16 006f
    0141: nop
    0142: packed-switch-payload first=1 targets=[49, 3, 41, 3, 63]
    0150: sparse-switch-payload {16: 85, 48: 73, 80: 103}

  [Virtual Method] onMeasure(I, I) -> V
    // registers=16, ins=3, outs=3, insns_size=275
    0000: const/4 v0, 0
    0001: invoke-static {v0, v14}, Landroid/support/v4/view/ViewPager;->getDefaultSize(II)I
    0004: move-result v0
    0005: const/4 v1, 0
    0006: invoke-static {v1, v15}, Landroid/support/v4/view/ViewPager;->getDefaultSize(II)I
    0009: move-result v1
    000a: invoke-virtual {v13, v0, v1}, Landroid/support/v4/view/ViewPager;->setMeasuredDimension(II)V
    000d: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->getMeasuredWidth()I
    0010: move-result v0
    0011: binop/lit8(op=db) v1, v0, 10 (0xa)
    0013: iget v2, v13.Landroid/support/v4/view/ViewPager;->mDefaultGutterSize:I
    0015: invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I
    0018: move-result v1
    0019: iput v1, v13.Landroid/support/v4/view/ViewPager;->mGutterSize:I
    001b: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->getPaddingLeft()I
    001e: move-result v1
    001f: binop/2addr(op=b1) v0, v1
    0020: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->getPaddingRight()I
    0023: move-result v1
    0024: binop(op=91) v3, v0, v1
    0026: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->getMeasuredHeight()I
    0029: move-result v0
    002a: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->getPaddingTop()I
    002d: move-result v1
    002e: binop/2addr(op=b1) v0, v1
    002f: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->getPaddingBottom()I
    0032: move-result v1
    0033: binop(op=91) v5, v0, v1
    0035: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    0038: move-result v9
    0039: const/4 v0, 0
    003a: move(op=01) v8, v0
    003b: if-ge v8, v9, 00bc
    003d: invoke-virtual {v13, v8}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    0040: move-result-object v10
    0041: invoke-virtual {v10}, Landroid/view/View;->getVisibility()I
    0044: move-result v0
    0045: const/16 v1, 8 (0x8)
    0047: if-eq v0, v1, 00a5
    0049: invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    004c: move-result-object v0
    004d: check-cast v0, Landroid/support/v4/view/ViewPager$LayoutParams;
    004f: if-eqz v0, 00a5
    0051: iget v1, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->isDecor:Z
    0053: if-eqz v1, 00a5
    0055: iget v1, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->gravity:I
    0057: binop/lit8(op=dd) v6, v1, 7 (0x7)
    0059: iget v1, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->gravity:I
    005b: binop/lit8(op=dd) v4, v1, 112 (0x70)
    005d: const/high16 v2, -2147483648 (-0x80000000)
    005f: const/high16 v1, -2147483648 (-0x80000000)
    0061: const/16 v7, 48 (0x30)
    0063: if-eq v4, v7, 0069
    0065: const/16 v7, 80 (0x50)
    0067: if-ne v4, v7, 00a9
    0069: const/4 v4, 1
    006a: move(op=01) v7, v4
    006b: const/4 v4, 3
    006c: if-eq v6, v4, 0071
    006e: const/4 v4, 5
    006f: if-ne v6, v4, 00ac
    0071: const/4 v4, 1
    0072: move(op=01) v6, v4
    0073: if-eqz v7, 00af
    0075: const/high16 v2, 1073741824 (0x40000000)
    0077: iget v4, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->width:I
    0079: const/4 v11, -2
    007a: if-eq v4, v11, 010f
    007c: const/high16 v4, 1073741824 (0x40000000)
    007e: iget v2, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->width:I
    0080: const/4 v11, -1
    0081: if-eq v2, v11, 010c
    0083: iget v2, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->width:I
    0085: iget v11, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->height:I
    0087: const/4 v12, -2
    0088: if-eq v11, v12, 010a
    008a: const/high16 v1, 1073741824 (0x40000000)
    008c: iget v11, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->height:I
    008e: const/4 v12, -1
    008f: if-eq v11, v12, 010a
    0091: iget v0, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->height:I
    0093: invoke-static {v2, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    0096: move-result v2
    0097: invoke-static {v0, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    009a: move-result v0
    009b: invoke-virtual {v10, v2, v0}, Landroid/view/View;->measure(II)V
    009e: if-eqz v7, 00b4
    00a0: invoke-virtual {v10}, Landroid/view/View;->getMeasuredHeight()I
    00a3: move-result v0
    00a4: binop/2addr(op=b1) v5, v0
    00a5: binop/lit8(op=d8) v0, v8, 1 (0x1)
    00a7: move(op=01) v8, v0
    00a8: goto 003b
    00a9: const/4 v4, 0
    00aa: move(op=01) v7, v4
    00ab: goto 006b
    00ac: const/4 v4, 0
    00ad: move(op=01) v6, v4
    00ae: goto 0073
    00af: if-eqz v6, 0077
    00b1: const/high16 v1, 1073741824 (0x40000000)
    00b3: goto 0077
    00b4: if-eqz v6, 00a5
    00b6: invoke-virtual {v10}, Landroid/view/View;->getMeasuredWidth()I
    00b9: move-result v0
    00ba: binop/2addr(op=b1) v3, v0
    00bb: goto 00a5
    00bc: const/high16 v0, 1073741824 (0x40000000)
    00be: invoke-static {v3, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    00c1: move-result v0
    00c2: iput v0, v13.Landroid/support/v4/view/ViewPager;->mChildWidthMeasureSpec:I
    00c4: const/high16 v0, 1073741824 (0x40000000)
    00c6: invoke-static {v5, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    00c9: move-result v0
    00ca: iput v0, v13.Landroid/support/v4/view/ViewPager;->mChildHeightMeasureSpec:I
    00cc: const/4 v0, 1
    00cd: iput v0, v13.Landroid/support/v4/view/ViewPager;->mInLayout:Z
    00cf: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->populate()V
    00d2: const/4 v0, 0
    00d3: iput v0, v13.Landroid/support/v4/view/ViewPager;->mInLayout:Z
    00d5: invoke-virtual {v13}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    00d8: move-result v2
    00d9: const/4 v0, 0
    00da: move(op=01) v1, v0
    00db: if-ge v1, v2, 0109
    00dd: invoke-virtual {v13, v1}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    00e0: move-result-object v4
    00e1: invoke-virtual {v4}, Landroid/view/View;->getVisibility()I
    00e4: move-result v0
    00e5: const/16 v5, 8 (0x8)
    00e7: if-eq v0, v5, 0105
    00e9: invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    00ec: move-result-object v0
    00ed: check-cast v0, Landroid/support/v4/view/ViewPager$LayoutParams;
    00ef: if-eqz v0, 00f5
    00f1: iget v5, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->isDecor:Z
    00f3: if-nez v5, 0105
    00f5: unop(op=82) v5, v3
    00f6: iget v0, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->widthFactor:F
    00f8: binop/2addr(op=c8) v0, v5
    00f9: unop(op=87) v0, v0
    00fa: const/high16 v5, 1073741824 (0x40000000)
    00fc: invoke-static {v0, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    00ff: move-result v0
    0100: iget v5, v13.Landroid/support/v4/view/ViewPager;->mChildHeightMeasureSpec:I
    0102: invoke-virtual {v4, v0, v5}, Landroid/view/View;->measure(II)V
    0105: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0107: move(op=01) v1, v0
    0108: goto 00db
    0109: return-void
    010a: move(op=01) v0, v5
    010b: goto 0093
    010c: move(op=01) v2, v3
    010d: goto/16 0085
    010f: move(op=01) v4, v2
    0110: move(op=01) v2, v3
    0111: goto/16 0085

  [Virtual Method] onPageScrolled(I, F, I) -> V
    // registers=14, ins=4, outs=4, insns_size=154
    0000: iget v0, v10.Landroid/support/v4/view/ViewPager;->mDecorChildCount:I
    0002: if-lez v0, 0075
    0004: invoke-virtual {v10}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    0007: move-result v4
    0008: invoke-virtual {v10}, Landroid/support/v4/view/ViewPager;->getPaddingLeft()I
    000b: move-result v1
    000c: invoke-virtual {v10}, Landroid/support/v4/view/ViewPager;->getPaddingRight()I
    000f: move-result v2
    0010: invoke-virtual {v10}, Landroid/support/v4/view/ViewPager;->getWidth()I
    0013: move-result v5
    0014: invoke-virtual {v10}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    0017: move-result v6
    0018: const/4 v0, 0
    0019: move(op=01) v3, v0
    001a: if-ge v3, v6, 0075
    001c: invoke-virtual {v10, v3}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    001f: move-result-object v7
    0020: invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    0023: move-result-object v0
    0024: check-cast v0, Landroid/support/v4/view/ViewPager$LayoutParams;
    0026: iget v8, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->isDecor:Z
    0028: if-nez v8, 0034
    002a: move(op=01) v9, v2
    002b: move(op=01) v2, v1
    002c: move(op=01) v1, v9
    002d: binop/lit8(op=d8) v0, v3, 1 (0x1)
    002f: move(op=01) v3, v0
    0030: move(op=01) v9, v1
    0031: move(op=01) v1, v2
    0032: move(op=01) v2, v9
    0033: goto 001a
    0034: iget v0, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->gravity:I
    0036: binop/lit8(op=dd) v0, v0, 7 (0x7)
    0038: packed-switch v0, +84 (-> 008c)
    003b: move(op=01) v0, v1
    003c: move(op=01) v9, v2
    003d: move(op=01) v2, v1
    003e: move(op=01) v1, v9
    003f: binop/2addr(op=b0) v0, v4
    0040: invoke-virtual {v7}, Landroid/view/View;->getLeft()I
    0043: move-result v8
    0044: binop/2addr(op=b1) v0, v8
    0045: if-eqz v0, 002d
    0047: invoke-virtual {v7, v0}, Landroid/view/View;->offsetLeftAndRight(I)V
    004a: goto 002d
    004b: invoke-virtual {v7}, Landroid/view/View;->getWidth()I
    004e: move-result v0
    004f: binop/2addr(op=b0) v0, v1
    0050: move(op=01) v9, v1
    0051: move(op=01) v1, v2
    0052: move(op=01) v2, v0
    0053: move(op=01) v0, v9
    0054: goto 003f
    0055: invoke-virtual {v7}, Landroid/view/View;->getMeasuredWidth()I
    0058: move-result v0
    0059: binop(op=91) v0, v5, v0
    005b: binop/lit8(op=db) v0, v0, 2 (0x2)
    005d: invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I
    0060: move-result v0
    0061: move(op=01) v9, v2
    0062: move(op=01) v2, v1
    0063: move(op=01) v1, v9
    0064: goto 003f
    0065: binop(op=91) v0, v5, v2
    0067: invoke-virtual {v7}, Landroid/view/View;->getMeasuredWidth()I
    006a: move-result v8
    006b: binop/2addr(op=b1) v0, v8
    006c: invoke-virtual {v7}, Landroid/view/View;->getMeasuredWidth()I
    006f: move-result v8
    0070: binop/2addr(op=b0) v2, v8
    0071: move(op=01) v9, v2
    0072: move(op=01) v2, v1
    0073: move(op=01) v1, v9
    0074: goto 003f
    0075: iget v0, v10.Landroid/support/v4/view/ViewPager;->mOnPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    0077: if-eqz v0, 007e
    0079: iget v0, v10.Landroid/support/v4/view/ViewPager;->mOnPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    007b: invoke-interface {v0, v11, v12, v13}, Landroid/support/v4/view/ViewPager$OnPageChangeListener;->onPageScrolled(IFI)V
    007e: iget v0, v10.Landroid/support/v4/view/ViewPager;->mInternalPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    0080: if-eqz v0, 0087
    0082: iget v0, v10.Landroid/support/v4/view/ViewPager;->mInternalPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    0084: invoke-interface {v0, v11, v12, v13}, Landroid/support/v4/view/ViewPager$OnPageChangeListener;->onPageScrolled(IFI)V
    0087: const/4 v0, 1
    0088: iput v0, v10.Landroid/support/v4/view/ViewPager;->mCalledSuper:Z
    008a: return-void
    008b: nop
    008c: packed-switch-payload first=1 targets=[29, 3, 19, 3, 45]

  [Virtual Method] onRequestFocusInDescendants(I, Landroid/graphics/Rect;) -> Z
    // registers=11, ins=3, outs=3, insns_size=53
    0000: const/4 v2, 1
    0001: const/4 v4, 0
    0002: const/4 v1, -1
    0003: invoke-virtual {v8}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    0006: move-result v0
    0007: binop/lit8(op=dd) v3, v9, 2 (0x2)
    0009: if-eqz v3, 002c
    000b: move(op=01) v1, v2
    000c: move(op=01) v3, v4
    000d: if-eq v3, v0, 0033
    000f: invoke-virtual {v8, v3}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    0012: move-result-object v5
    0013: invoke-virtual {v5}, Landroid/view/View;->getVisibility()I
    0016: move-result v6
    0017: if-nez v6, 0031
    0019: invoke-virtual {v8, v5}, Landroid/support/v4/view/ViewPager;->infoForChild(Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    001c: move-result-object v6
    001d: if-eqz v6, 0031
    001f: iget v6, v6.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0021: iget v7, v8.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0023: if-ne v6, v7, 0031
    0025: invoke-virtual {v5, v9, v10}, Landroid/view/View;->requestFocus(ILandroid/graphics/Rect;)Z
    0028: move-result v5
    0029: if-eqz v5, 0031
    002b: return v2
    002c: binop/lit8(op=d8) v0, v0, -1 (-0x1)
    002e: move(op=01) v3, v0
    002f: move(op=01) v0, v1
    0030: goto 000d
    0031: binop/2addr(op=b0) v3, v1
    0032: goto 000d
    0033: move(op=01) v2, v4
    0034: goto 002b

  [Virtual Method] onRestoreInstanceState(Landroid/os/Parcelable;) -> V
    // registers=5, ins=2, outs=4, insns_size=51
    0000: instance-of v0, v4, Landroid/support/v4/view/ViewPager$SavedState;
    0002: if-nez v0, 0008
    0004: invoke-super {v3, v4}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V
    0007: return-void
    0008: check-cast v4, Landroid/support/v4/view/ViewPager$SavedState;
    000a: invoke-virtual {v4}, Landroid/support/v4/view/ViewPager$SavedState;->getSuperState()Landroid/os/Parcelable;
    000d: move-result-object v0
    000e: invoke-super {v3, v0}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V
    0011: iget v0, v3.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0013: if-eqz v0, 0026
    0015: iget v0, v3.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0017: iget v1, v4.Landroid/support/v4/view/ViewPager$SavedState;->adapterState:Landroid/os/Parcelable;
    0019: iget v2, v4.Landroid/support/v4/view/ViewPager$SavedState;->loader:Ljava/lang/ClassLoader;
    001b: invoke-virtual {v0, v1, v2}, Landroid/support/v4/view/PagerAdapter;->restoreState(Landroid/os/Parcelable;Ljava/lang/ClassLoader;)V
    001e: iget v0, v4.Landroid/support/v4/view/ViewPager$SavedState;->position:I
    0020: const/4 v1, 0
    0021: const/4 v2, 1
    0022: invoke-virtual {v3, v0, v1, v2}, Landroid/support/v4/view/ViewPager;->setCurrentItemInternal(IZZ)V
    0025: goto 0007
    0026: iget v0, v4.Landroid/support/v4/view/ViewPager$SavedState;->position:I
    0028: iput v0, v3.Landroid/support/v4/view/ViewPager;->mRestoredCurItem:I
    002a: iget v0, v4.Landroid/support/v4/view/ViewPager$SavedState;->adapterState:Landroid/os/Parcelable;
    002c: iput v0, v3.Landroid/support/v4/view/ViewPager;->mRestoredAdapterState:Landroid/os/Parcelable;
    002e: iget v0, v4.Landroid/support/v4/view/ViewPager$SavedState;->loader:Ljava/lang/ClassLoader;
    0030: iput v0, v3.Landroid/support/v4/view/ViewPager;->mRestoredClassLoader:Ljava/lang/ClassLoader;
    0032: goto 0007

  [Virtual Method] onSaveInstanceState() -> Landroid/os/Parcelable;
    // registers=3, ins=1, outs=2, insns_size=26
    0000: invoke-super {v2}, Landroid/view/ViewGroup;->onSaveInstanceState()Landroid/os/Parcelable;
    0003: move-result-object v0
    0004: new-instance v1, Landroid/support/v4/view/ViewPager$SavedState;
    0006: invoke-direct {v1, v0}, Landroid/support/v4/view/ViewPager$SavedState;-><init>(Landroid/os/Parcelable;)V
    0009: iget v0, v2.Landroid/support/v4/view/ViewPager;->mCurItem:I
    000b: iput v0, v1.Landroid/support/v4/view/ViewPager$SavedState;->position:I
    000d: iget v0, v2.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    000f: if-eqz v0, 0019
    0011: iget v0, v2.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0013: invoke-virtual {v0}, Landroid/support/v4/view/PagerAdapter;->saveState()Landroid/os/Parcelable;
    0016: move-result-object v0
    0017: iput v0, v1.Landroid/support/v4/view/ViewPager$SavedState;->adapterState:Landroid/os/Parcelable;
    0019: return-object v1

  [Virtual Method] onSizeChanged(I, I, I, I) -> V
    // registers=7, ins=5, outs=5, insns_size=13
    0000: invoke-super {v2, v3, v4, v5, v6}, Landroid/view/ViewGroup;->onSizeChanged(IIII)V
    0003: if-eq v3, v5, 000c
    0005: iget v0, v2.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0007: iget v1, v2.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0009: invoke-direct {v2, v3, v5, v0, v1}, Landroid/support/v4/view/ViewPager;->recomputeScrollPosition(IIII)V
    000c: return-void

  [Virtual Method] onTouchEvent(Landroid/view/MotionEvent;) -> Z
    // registers=9, ins=2, outs=5, insns_size=364
    0000: const/4 v6, -1
    0001: const/4 v2, 0
    0002: const/4 v1, 1
    0003: iget v0, v7.Landroid/support/v4/view/ViewPager;->mFakeDragging:Z
    0005: if-eqz v0, 0009
    0007: move(op=01) v0, v1
    0008: return v0
    0009: invoke-virtual {v8}, Landroid/view/MotionEvent;->getAction()I
    000c: move-result v0
    000d: if-nez v0, 0017
    000f: invoke-virtual {v8}, Landroid/view/MotionEvent;->getEdgeFlags()I
    0012: move-result v0
    0013: if-eqz v0, 0017
    0015: move(op=01) v0, v2
    0016: goto 0008
    0017: iget v0, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0019: if-eqz v0, 0023
    001b: iget v0, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    001d: invoke-virtual {v0}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    0020: move-result v0
    0021: if-nez v0, 0025
    0023: move(op=01) v0, v2
    0024: goto 0008
    0025: iget v0, v7.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0027: if-nez v0, 002f
    0029: invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;
    002c: move-result-object v0
    002d: iput v0, v7.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    002f: iget v0, v7.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    0031: invoke-virtual {v0, v8}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V
    0034: invoke-virtual {v8}, Landroid/view/MotionEvent;->getAction()I
    0037: move-result v0
    0038: binop/lit16(op=d5) v0, v0, 255 (0xff)
    003a: packed-switch v0, +288 (-> 015a)
    003d: if-eqz v2, 0042
    003f: invoke-static {v7}, Landroid/support/v4/view/ViewCompat;->postInvalidateOnAnimation(Landroid/view/View;)V
    0042: move(op=01) v0, v1
    0043: goto 0008
    0044: iget v0, v7.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    0046: invoke-virtual {v0}, Landroid/widget/Scroller;->abortAnimation()V
    0049: iput v2, v7.Landroid/support/v4/view/ViewPager;->mPopulatePending:Z
    004b: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->populate()V
    004e: iput v1, v7.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    0050: invoke-direct {v7, v1}, Landroid/support/v4/view/ViewPager;->setScrollState(I)V
    0053: invoke-virtual {v8}, Landroid/view/MotionEvent;->getX()F
    0056: move-result v0
    0057: iput v0, v7.Landroid/support/v4/view/ViewPager;->mInitialMotionX:F
    0059: iput v0, v7.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    005b: invoke-static {v8, v2}, Landroid/support/v4/view/MotionEventCompat;->getPointerId(Landroid/view/MotionEvent;I)I
    005e: move-result v0
    005f: iput v0, v7.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    0061: goto 003d
    0062: iget v0, v7.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    0064: if-nez v0, 00a7
    0066: iget v0, v7.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    0068: invoke-static {v8, v0}, Landroid/support/v4/view/MotionEventCompat;->findPointerIndex(Landroid/view/MotionEvent;I)I
    006b: move-result v0
    006c: invoke-static {v8, v0}, Landroid/support/v4/view/MotionEventCompat;->getX(Landroid/view/MotionEvent;I)F
    006f: move-result v3
    0070: iget v4, v7.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0072: binop(op=a7) v4, v3, v4
    0074: invoke-static {v4}, Ljava/lang/Math;->abs(F)F
    0077: move-result v4
    0078: invoke-static {v8, v0}, Landroid/support/v4/view/MotionEventCompat;->getY(Landroid/view/MotionEvent;I)F
    007b: move-result v0
    007c: iget v5, v7.Landroid/support/v4/view/ViewPager;->mLastMotionY:F
    007e: binop/2addr(op=c7) v0, v5
    007f: invoke-static {v0}, Ljava/lang/Math;->abs(F)F
    0082: move-result v0
    0083: iget v5, v7.Landroid/support/v4/view/ViewPager;->mTouchSlop:I
    0085: unop(op=82) v5, v5
    0086: cmp(op=2d) v5, v4, v5
    0088: if-lez v5, 00a7
    008a: cmp(op=2d) v0, v4, v0
    008c: if-lez v0, 00a7
    008e: iput v1, v7.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    0090: iget v0, v7.Landroid/support/v4/view/ViewPager;->mInitialMotionX:F
    0092: binop(op=a7) v0, v3, v0
    0094: const/4 v3, 0
    0095: cmp(op=2d) v0, v0, v3
    0097: if-lez v0, 00bb
    0099: iget v0, v7.Landroid/support/v4/view/ViewPager;->mInitialMotionX:F
    009b: iget v3, v7.Landroid/support/v4/view/ViewPager;->mTouchSlop:I
    009d: unop(op=82) v3, v3
    009e: binop/2addr(op=c6) v0, v3
    009f: iput v0, v7.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    00a1: invoke-direct {v7, v1}, Landroid/support/v4/view/ViewPager;->setScrollState(I)V
    00a4: invoke-direct {v7, v1}, Landroid/support/v4/view/ViewPager;->setScrollingCacheEnabled(Z)V
    00a7: iget v0, v7.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    00a9: if-eqz v0, 003d
    00ab: iget v0, v7.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    00ad: invoke-static {v8, v0}, Landroid/support/v4/view/MotionEventCompat;->findPointerIndex(Landroid/view/MotionEvent;I)I
    00b0: move-result v0
    00b1: invoke-static {v8, v0}, Landroid/support/v4/view/MotionEventCompat;->getX(Landroid/view/MotionEvent;I)F
    00b4: move-result v0
    00b5: invoke-direct {v7, v0}, Landroid/support/v4/view/ViewPager;->performDrag(F)Z
    00b8: move-result v0
    00b9: binop/2addr(op=b6) v2, v0
    00ba: goto 003d
    00bb: iget v0, v7.Landroid/support/v4/view/ViewPager;->mInitialMotionX:F
    00bd: iget v3, v7.Landroid/support/v4/view/ViewPager;->mTouchSlop:I
    00bf: unop(op=82) v3, v3
    00c0: binop/2addr(op=c7) v0, v3
    00c1: goto 009f
    00c2: iget v0, v7.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    00c4: if-eqz v0, 003d
    00c6: iget v0, v7.Landroid/support/v4/view/ViewPager;->mVelocityTracker:Landroid/view/VelocityTracker;
    00c8: const/16 v2, 1000 (0x3e8)
    00ca: iget v3, v7.Landroid/support/v4/view/ViewPager;->mMaximumVelocity:I
    00cc: unop(op=82) v3, v3
    00cd: invoke-virtual {v0, v2, v3}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V
    00d0: iget v2, v7.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    00d2: invoke-static {v0, v2}, Landroid/support/v4/view/VelocityTrackerCompat;->getXVelocity(Landroid/view/VelocityTracker;I)F
    00d5: move-result v0
    00d6: unop(op=87) v0, v0
    00d7: iput v1, v7.Landroid/support/v4/view/ViewPager;->mPopulatePending:Z
    00d9: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getWidth()I
    00dc: move-result v2
    00dd: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    00e0: move-result v3
    00e1: invoke-direct {v7}, Landroid/support/v4/view/ViewPager;->infoForCurrentScrollPosition()Landroid/support/v4/view/ViewPager$ItemInfo;
    00e4: move-result-object v4
    00e5: iget v5, v4.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    00e7: unop(op=82) v3, v3
    00e8: unop(op=82) v2, v2
    00e9: binop(op=a9) v2, v3, v2
    00eb: iget v3, v4.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    00ed: binop/2addr(op=c7) v2, v3
    00ee: iget v3, v4.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    00f0: binop/2addr(op=c9) v2, v3
    00f1: iget v3, v7.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    00f3: invoke-static {v8, v3}, Landroid/support/v4/view/MotionEventCompat;->findPointerIndex(Landroid/view/MotionEvent;I)I
    00f6: move-result v3
    00f7: invoke-static {v8, v3}, Landroid/support/v4/view/MotionEventCompat;->getX(Landroid/view/MotionEvent;I)F
    00fa: move-result v3
    00fb: iget v4, v7.Landroid/support/v4/view/ViewPager;->mInitialMotionX:F
    00fd: binop/2addr(op=c7) v3, v4
    00fe: unop(op=87) v3, v3
    00ff: invoke-direct {v7, v5, v2, v0, v3}, Landroid/support/v4/view/ViewPager;->determineTargetPage(IFII)I
    0102: move-result v2
    0103: invoke-virtual {v7, v2, v1, v1, v0}, Landroid/support/v4/view/ViewPager;->setCurrentItemInternal(IZZI)V
    0106: iput v6, v7.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    0108: invoke-direct {v7}, Landroid/support/v4/view/ViewPager;->endDrag()V
    010b: iget v0, v7.Landroid/support/v4/view/ViewPager;->mLeftEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    010d: invoke-virtual {v0}, Landroid/support/v4/widget/EdgeEffectCompat;->onRelease()Z
    0110: move-result v0
    0111: iget v2, v7.Landroid/support/v4/view/ViewPager;->mRightEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    0113: invoke-virtual {v2}, Landroid/support/v4/widget/EdgeEffectCompat;->onRelease()Z
    0116: move-result v2
    0117: binop/2addr(op=b6) v2, v0
    0118: goto/16 003d
    011a: iget v0, v7.Landroid/support/v4/view/ViewPager;->mIsBeingDragged:Z
    011c: if-eqz v0, 003d
    011e: iget v0, v7.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0120: invoke-virtual {v7, v0, v1, v1}, Landroid/support/v4/view/ViewPager;->setCurrentItemInternal(IZZ)V
    0123: iput v6, v7.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    0125: invoke-direct {v7}, Landroid/support/v4/view/ViewPager;->endDrag()V
    0128: iget v0, v7.Landroid/support/v4/view/ViewPager;->mLeftEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    012a: invoke-virtual {v0}, Landroid/support/v4/widget/EdgeEffectCompat;->onRelease()Z
    012d: move-result v0
    012e: iget v2, v7.Landroid/support/v4/view/ViewPager;->mRightEdge:Landroid/support/v4/widget/EdgeEffectCompat;
    0130: invoke-virtual {v2}, Landroid/support/v4/widget/EdgeEffectCompat;->onRelease()Z
    0133: move-result v2
    0134: binop/2addr(op=b6) v2, v0
    0135: goto/16 003d
    0137: invoke-static {v8}, Landroid/support/v4/view/MotionEventCompat;->getActionIndex(Landroid/view/MotionEvent;)I
    013a: move-result v0
    013b: invoke-static {v8, v0}, Landroid/support/v4/view/MotionEventCompat;->getX(Landroid/view/MotionEvent;I)F
    013e: move-result v3
    013f: iput v3, v7.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0141: invoke-static {v8, v0}, Landroid/support/v4/view/MotionEventCompat;->getPointerId(Landroid/view/MotionEvent;I)I
    0144: move-result v0
    0145: iput v0, v7.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    0147: goto/16 003d
    0149: invoke-direct {v7, v8}, Landroid/support/v4/view/ViewPager;->onSecondaryPointerUp(Landroid/view/MotionEvent;)V
    014c: iget v0, v7.Landroid/support/v4/view/ViewPager;->mActivePointerId:I
    014e: invoke-static {v8, v0}, Landroid/support/v4/view/MotionEventCompat;->findPointerIndex(Landroid/view/MotionEvent;I)I
    0151: move-result v0
    0152: invoke-static {v8, v0}, Landroid/support/v4/view/MotionEventCompat;->getX(Landroid/view/MotionEvent;I)F
    0155: move-result v0
    0156: iput v0, v7.Landroid/support/v4/view/ViewPager;->mLastMotionX:F
    0158: goto/16 003d
    015a: packed-switch-payload first=0 targets=[10, 136, 40, 224, 3, 253, 271]

  [Virtual Method] pageLeft() -> Z
    // registers=3, ins=1, outs=3, insns_size=15
    0000: const/4 v0, 1
    0001: iget v1, v2.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0003: if-lez v1, 000d
    0005: iget v1, v2.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0007: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    0009: invoke-virtual {v2, v1, v0}, Landroid/support/v4/view/ViewPager;->setCurrentItem(IZ)V
    000c: return v0
    000d: const/4 v0, 0
    000e: goto 000c

  [Virtual Method] pageRight() -> Z
    // registers=4, ins=1, outs=3, insns_size=27
    0000: const/4 v0, 1
    0001: iget v1, v3.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0003: if-eqz v1, 0019
    0005: iget v1, v3.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0007: iget v2, v3.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0009: invoke-virtual {v2}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    000c: move-result v2
    000d: binop/lit8(op=d8) v2, v2, -1 (-0x1)
    000f: if-ge v1, v2, 0019
    0011: iget v1, v3.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0013: binop/lit8(op=d8) v1, v1, 1 (0x1)
    0015: invoke-virtual {v3, v1, v0}, Landroid/support/v4/view/ViewPager;->setCurrentItem(IZ)V
    0018: return v0
    0019: const/4 v0, 0
    001a: goto 0018

  [Virtual Method] populate() -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0002: invoke-virtual {v1, v0}, Landroid/support/v4/view/ViewPager;->populate(I)V
    0005: return-void

  [Virtual Method] populate(I) -> V
    // registers=16, ins=2, outs=4, insns_size=537
    0000: const/4 v0, 0
    0001: iget v1, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0003: if-eq v1, v15, 0216
    0005: iget v0, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0007: invoke-virtual {v14, v0}, Landroid/support/v4/view/ViewPager;->infoForPosition(I)Landroid/support/v4/view/ViewPager$ItemInfo;
    000a: move-result-object v0
    000b: iput v15, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    000d: move(op=07) v1, v0
    000e: iget v0, v14.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0010: if-nez v0, 0013
    0012: return-void
    0013: iget v0, v14.Landroid/support/v4/view/ViewPager;->mPopulatePending:Z
    0015: if-nez v0, 0012
    0017: invoke-virtual {v14}, Landroid/support/v4/view/ViewPager;->getWindowToken()Landroid/os/IBinder;
    001a: move-result-object v0
    001b: if-eqz v0, 0012
    001d: iget v0, v14.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    001f: invoke-virtual {v0, v14}, Landroid/support/v4/view/PagerAdapter;->startUpdate(Landroid/view/ViewGroup;)V
    0022: iget v0, v14.Landroid/support/v4/view/ViewPager;->mOffscreenPageLimit:I
    0024: const/4 v2, 0
    0025: iget v3, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0027: binop/2addr(op=b1) v3, v0
    0028: invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I
    002b: move-result v7
    002c: iget v2, v14.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    002e: invoke-virtual {v2}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    0031: move-result v8
    0032: binop/lit8(op=d8) v2, v8, -1 (-0x1)
    0034: iget v3, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0036: binop/2addr(op=b0) v0, v3
    0037: invoke-static {v2, v0}, Ljava/lang/Math;->min(II)I
    003a: move-result v9
    003b: const/4 v3, 0
    003c: const/4 v0, 0
    003d: move(op=01) v2, v0
    003e: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0040: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0043: move-result v0
    0044: if-ge v2, v0, 0213
    0046: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0048: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    004b: move-result-object v0
    004c: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    004e: iget v4, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0050: iget v5, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0052: if-lt v4, v5, 00fa
    0054: iget v4, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0056: iget v5, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0058: if-ne v4, v5, 0213
    005a: if-nez v0, 0210
    005c: if-lez v8, 0210
    005e: iget v0, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0060: invoke-virtual {v14, v0, v2}, Landroid/support/v4/view/ViewPager;->addNewItem(II)Landroid/support/v4/view/ViewPager$ItemInfo;
    0063: move-result-object v0
    0064: move(op=07) v6, v0
    0065: if-eqz v6, 00bf
    0067: const/4 v5, 0
    0068: binop/lit8(op=d8) v4, v2, -1 (-0x1)
    006a: if-ltz v4, 00ff
    006c: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    006e: invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0071: move-result-object v0
    0072: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0074: const/high16 v3, 1073741824 (0x40000000)
    0076: iget v10, v6.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0078: binop(op=a7) v10, v3, v10
    007a: iget v3, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    007c: binop/lit8(op=d8) v3, v3, -1 (-0x1)
    007e: move(op=01) v12, v3
    007f: move(op=01) v3, v5
    0080: move(op=01) v5, v12
    0081: move(op=01) v13, v4
    0082: move(op=01) v4, v2
    0083: move(op=01) v2, v13
    0084: if-ltz v5, 008e
    0086: cmp(op=2d) v11, v3, v10
    0088: if-ltz v11, 012a
    008a: if-ge v5, v7, 012a
    008c: if-nez v0, 0102
    008e: iget v3, v6.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0090: binop/lit8(op=d8) v5, v4, 1 (0x1)
    0092: const/high16 v0, 1073741824 (0x40000000)
    0094: cmp(op=2e) v0, v3, v0
    0096: if-gez v0, 00bc
    0098: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    009a: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    009d: move-result v0
    009e: if-ge v5, v0, 015a
    00a0: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    00a2: invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    00a5: move-result-object v0
    00a6: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    00a8: iget v2, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    00aa: binop/lit8(op=d8) v2, v2, 1 (0x1)
    00ac: move(op=01) v12, v2
    00ad: move(op=01) v2, v3
    00ae: move(op=01) v3, v5
    00af: move(op=01) v5, v12
    00b0: if-ge v5, v8, 00bc
    00b2: const/high16 v7, 1073741824 (0x40000000)
    00b4: cmp(op=2d) v7, v2, v7
    00b6: if-ltz v7, 018d
    00b8: if-le v5, v9, 018d
    00ba: if-nez v0, 015d
    00bc: invoke-direct {v14, v6, v4, v1}, Landroid/support/v4/view/ViewPager;->calculatePageOffsets(Landroid/support/v4/view/ViewPager$ItemInfo;ILandroid/support/v4/view/ViewPager$ItemInfo;)V
    00bf: iget v1, v14.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    00c1: iget v2, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    00c3: if-eqz v6, 01cd
    00c5: iget v0, v6.Landroid/support/v4/view/ViewPager$ItemInfo;->object:Ljava/lang/Object;
    00c7: invoke-virtual {v1, v14, v2, v0}, Landroid/support/v4/view/PagerAdapter;->setPrimaryItem(Landroid/view/ViewGroup;ILjava/lang/Object;)V
    00ca: iget v0, v14.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    00cc: invoke-virtual {v0, v14}, Landroid/support/v4/view/PagerAdapter;->finishUpdate(Landroid/view/ViewGroup;)V
    00cf: invoke-virtual {v14}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    00d2: move-result v2
    00d3: const/4 v0, 0
    00d4: move(op=01) v1, v0
    00d5: if-ge v1, v2, 01d0
    00d7: invoke-virtual {v14, v1}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    00da: move-result-object v3
    00db: invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    00de: move-result-object v0
    00df: check-cast v0, Landroid/support/v4/view/ViewPager$LayoutParams;
    00e1: iget v4, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->isDecor:Z
    00e3: if-nez v4, 00f6
    00e5: iget v4, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->widthFactor:F
    00e7: const/4 v5, 0
    00e8: cmp(op=2d) v4, v4, v5
    00ea: if-nez v4, 00f6
    00ec: invoke-virtual {v14, v3}, Landroid/support/v4/view/ViewPager;->infoForChild(Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    00ef: move-result-object v3
    00f0: if-eqz v3, 00f6
    00f2: iget v3, v3.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    00f4: iput v3, v0.Landroid/support/v4/view/ViewPager$LayoutParams;->widthFactor:F
    00f6: binop/lit8(op=d8) v0, v1, 1 (0x1)
    00f8: move(op=01) v1, v0
    00f9: goto 00d5
    00fa: binop/lit8(op=d8) v0, v2, 1 (0x1)
    00fc: move(op=01) v2, v0
    00fd: goto/16 003e
    00ff: const/4 v0, 0
    0100: goto/16 0074
    0102: iget v11, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0104: if-ne v5, v11, 0124
    0106: iget v11, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->scrolling:Z
    0108: if-nez v11, 0124
    010a: iget v11, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    010c: invoke-virtual {v11, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    010f: iget v11, v14.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0111: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->object:Ljava/lang/Object;
    0113: invoke-virtual {v11, v14, v5, v0}, Landroid/support/v4/view/PagerAdapter;->destroyItem(Landroid/view/ViewGroup;ILjava/lang/Object;)V
    0116: binop/lit8(op=d8) v2, v2, -1 (-0x1)
    0118: binop/lit8(op=d8) v4, v4, -1 (-0x1)
    011a: if-ltz v2, 0128
    011c: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    011e: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0121: move-result-object v0
    0122: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0124: binop/lit8(op=d8) v5, v5, -1 (-0x1)
    0126: goto/16 0084
    0128: const/4 v0, 0
    0129: goto 0124
    012a: if-eqz v0, 0142
    012c: iget v11, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    012e: if-ne v5, v11, 0142
    0130: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0132: binop/2addr(op=c6) v3, v0
    0133: binop/lit8(op=d8) v2, v2, -1 (-0x1)
    0135: if-ltz v2, 0140
    0137: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0139: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    013c: move-result-object v0
    013d: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    013f: goto 0124
    0140: const/4 v0, 0
    0141: goto 0124
    0142: binop/lit8(op=d8) v0, v2, 1 (0x1)
    0144: invoke-virtual {v14, v5, v0}, Landroid/support/v4/view/ViewPager;->addNewItem(II)Landroid/support/v4/view/ViewPager$ItemInfo;
    0147: move-result-object v0
    0148: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    014a: binop/2addr(op=c6) v3, v0
    014b: binop/lit8(op=d8) v4, v4, 1 (0x1)
    014d: if-ltz v2, 0158
    014f: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0151: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0154: move-result-object v0
    0155: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0157: goto 0124
    0158: const/4 v0, 0
    0159: goto 0124
    015a: const/4 v0, 0
    015b: goto/16 00a8
    015d: iget v7, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    015f: if-ne v5, v7, 020b
    0161: iget v7, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->scrolling:Z
    0163: if-nez v7, 020b
    0165: iget v7, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0167: invoke-virtual {v7, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    016a: iget v7, v14.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    016c: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->object:Ljava/lang/Object;
    016e: invoke-virtual {v7, v14, v5, v0}, Landroid/support/v4/view/PagerAdapter;->destroyItem(Landroid/view/ViewGroup;ILjava/lang/Object;)V
    0171: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0173: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0176: move-result v0
    0177: if-ge v3, v0, 018b
    0179: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    017b: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    017e: move-result-object v0
    017f: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0181: move(op=01) v12, v2
    0182: move(op=07) v2, v0
    0183: move(op=01) v0, v12
    0184: binop/lit8(op=d8) v5, v5, 1 (0x1)
    0186: move(op=01) v12, v0
    0187: move(op=07) v0, v2
    0188: move(op=01) v2, v12
    0189: goto/16 00b0
    018b: const/4 v0, 0
    018c: goto 0181
    018d: if-eqz v0, 01ae
    018f: iget v7, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0191: if-ne v5, v7, 01ae
    0193: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    0195: binop/2addr(op=c6) v2, v0
    0196: binop/lit8(op=d8) v3, v3, 1 (0x1)
    0198: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    019a: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    019d: move-result v0
    019e: if-ge v3, v0, 01ac
    01a0: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    01a2: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    01a5: move-result-object v0
    01a6: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    01a8: move(op=01) v12, v2
    01a9: move(op=07) v2, v0
    01aa: move(op=01) v0, v12
    01ab: goto 0184
    01ac: const/4 v0, 0
    01ad: goto 01a8
    01ae: invoke-virtual {v14, v5, v3}, Landroid/support/v4/view/ViewPager;->addNewItem(II)Landroid/support/v4/view/ViewPager$ItemInfo;
    01b1: move-result-object v0
    01b2: binop/lit8(op=d8) v3, v3, 1 (0x1)
    01b4: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->widthFactor:F
    01b6: binop/2addr(op=c6) v2, v0
    01b7: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    01b9: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    01bc: move-result v0
    01bd: if-ge v3, v0, 01cb
    01bf: iget v0, v14.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    01c1: invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    01c4: move-result-object v0
    01c5: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    01c7: move(op=01) v12, v2
    01c8: move(op=07) v2, v0
    01c9: move(op=01) v0, v12
    01ca: goto 0184
    01cb: const/4 v0, 0
    01cc: goto 01c7
    01cd: const/4 v0, 0
    01ce: goto/16 00c7
    01d0: invoke-virtual {v14}, Landroid/support/v4/view/ViewPager;->hasFocus()Z
    01d3: move-result v0
    01d4: if-eqz v0, 0012
    01d6: invoke-virtual {v14}, Landroid/support/v4/view/ViewPager;->findFocus()Landroid/view/View;
    01d9: move-result-object v0
    01da: if-eqz v0, 0209
    01dc: invoke-virtual {v14, v0}, Landroid/support/v4/view/ViewPager;->infoForAnyChild(Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    01df: move-result-object v0
    01e0: if-eqz v0, 01e8
    01e2: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    01e4: iget v1, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    01e6: if-eq v0, v1, 0012
    01e8: const/4 v0, 0
    01e9: invoke-virtual {v14}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    01ec: move-result v1
    01ed: if-ge v0, v1, 0012
    01ef: invoke-virtual {v14, v0}, Landroid/support/v4/view/ViewPager;->getChildAt(I)Landroid/view/View;
    01f2: move-result-object v1
    01f3: invoke-virtual {v14, v1}, Landroid/support/v4/view/ViewPager;->infoForChild(Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    01f6: move-result-object v2
    01f7: if-eqz v2, 0206
    01f9: iget v2, v2.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    01fb: iget v3, v14.Landroid/support/v4/view/ViewPager;->mCurItem:I
    01fd: if-ne v2, v3, 0206
    01ff: const/4 v2, 2
    0200: invoke-virtual {v1, v2}, Landroid/view/View;->requestFocus(I)Z
    0203: move-result v1
    0204: if-nez v1, 0012
    0206: binop/lit8(op=d8) v0, v0, 1 (0x1)
    0208: goto 01e9
    0209: const/4 v0, 0
    020a: goto 01e0
    020b: move(op=01) v12, v2
    020c: move(op=07) v2, v0
    020d: move(op=01) v0, v12
    020e: goto/16 0184
    0210: move(op=07) v6, v0
    0211: goto/16 0065
    0213: move(op=07) v0, v3
    0214: goto/16 005a
    0216: move(op=07) v1, v0
    0217: goto/16 000e

  [Virtual Method] setAdapter(Landroid/support/v4/view/PagerAdapter;) -> V
    // registers=9, ins=2, outs=4, insns_size=138
    0000: const/4 v6, 1
    0001: const/4 v5, 0
    0002: const/4 v2, 0
    0003: iget v0, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0005: if-eqz v0, 0043
    0007: iget v0, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0009: iget v1, v7.Landroid/support/v4/view/ViewPager;->mObserver:Landroid/support/v4/view/ViewPager$PagerObserver;
    000b: invoke-virtual {v0, v1}, Landroid/support/v4/view/PagerAdapter;->unregisterDataSetObserver(Landroid/database/DataSetObserver;)V
    000e: iget v0, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0010: invoke-virtual {v0, v7}, Landroid/support/v4/view/PagerAdapter;->startUpdate(Landroid/view/ViewGroup;)V
    0013: move(op=01) v1, v2
    0014: iget v0, v7.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0016: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0019: move-result v0
    001a: if-ge v1, v0, 0031
    001c: iget v0, v7.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    001e: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0021: move-result-object v0
    0022: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0024: iget v3, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0026: iget v4, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0028: iget v0, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->object:Ljava/lang/Object;
    002a: invoke-virtual {v3, v7, v4, v0}, Landroid/support/v4/view/PagerAdapter;->destroyItem(Landroid/view/ViewGroup;ILjava/lang/Object;)V
    002d: binop/lit8(op=d8) v0, v1, 1 (0x1)
    002f: move(op=01) v1, v0
    0030: goto 0014
    0031: iget v0, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0033: invoke-virtual {v0, v7}, Landroid/support/v4/view/PagerAdapter;->finishUpdate(Landroid/view/ViewGroup;)V
    0036: iget v0, v7.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0038: invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V
    003b: invoke-direct {v7}, Landroid/support/v4/view/ViewPager;->removeNonDecorViews()V
    003e: iput v2, v7.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0040: invoke-virtual {v7, v2, v2}, Landroid/support/v4/view/ViewPager;->scrollTo(II)V
    0043: iget v0, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0045: iput v8, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0047: iget v1, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0049: if-eqz v1, 007a
    004b: iget v1, v7.Landroid/support/v4/view/ViewPager;->mObserver:Landroid/support/v4/view/ViewPager$PagerObserver;
    004d: if-nez v1, 0056
    004f: new-instance v1, Landroid/support/v4/view/ViewPager$PagerObserver;
    0051: invoke-direct {v1, v7, v5}, Landroid/support/v4/view/ViewPager$PagerObserver;-><init>(Landroid/support/v4/view/ViewPager;Landroid/support/v4/view/ViewPager$1;)V
    0054: iput v1, v7.Landroid/support/v4/view/ViewPager;->mObserver:Landroid/support/v4/view/ViewPager$PagerObserver;
    0056: iget v1, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0058: iget v3, v7.Landroid/support/v4/view/ViewPager;->mObserver:Landroid/support/v4/view/ViewPager$PagerObserver;
    005a: invoke-virtual {v1, v3}, Landroid/support/v4/view/PagerAdapter;->registerDataSetObserver(Landroid/database/DataSetObserver;)V
    005d: iput v2, v7.Landroid/support/v4/view/ViewPager;->mPopulatePending:Z
    005f: iput v6, v7.Landroid/support/v4/view/ViewPager;->mFirstLayout:Z
    0061: iget v1, v7.Landroid/support/v4/view/ViewPager;->mRestoredCurItem:I
    0063: if-ltz v1, 0086
    0065: iget v1, v7.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0067: iget v3, v7.Landroid/support/v4/view/ViewPager;->mRestoredAdapterState:Landroid/os/Parcelable;
    0069: iget v4, v7.Landroid/support/v4/view/ViewPager;->mRestoredClassLoader:Ljava/lang/ClassLoader;
    006b: invoke-virtual {v1, v3, v4}, Landroid/support/v4/view/PagerAdapter;->restoreState(Landroid/os/Parcelable;Ljava/lang/ClassLoader;)V
    006e: iget v1, v7.Landroid/support/v4/view/ViewPager;->mRestoredCurItem:I
    0070: invoke-virtual {v7, v1, v2, v6}, Landroid/support/v4/view/ViewPager;->setCurrentItemInternal(IZZ)V
    0073: const/4 v1, -1
    0074: iput v1, v7.Landroid/support/v4/view/ViewPager;->mRestoredCurItem:I
    0076: iput v5, v7.Landroid/support/v4/view/ViewPager;->mRestoredAdapterState:Landroid/os/Parcelable;
    0078: iput v5, v7.Landroid/support/v4/view/ViewPager;->mRestoredClassLoader:Ljava/lang/ClassLoader;
    007a: iget v1, v7.Landroid/support/v4/view/ViewPager;->mAdapterChangeListener:Landroid/support/v4/view/ViewPager$OnAdapterChangeListener;
    007c: if-eqz v1, 0085
    007e: if-eq v0, v8, 0085
    0080: iget v1, v7.Landroid/support/v4/view/ViewPager;->mAdapterChangeListener:Landroid/support/v4/view/ViewPager$OnAdapterChangeListener;
    0082: invoke-interface {v1, v0, v8}, Landroid/support/v4/view/ViewPager$OnAdapterChangeListener;->onAdapterChanged(Landroid/support/v4/view/PagerAdapter;Landroid/support/v4/view/PagerAdapter;)V
    0085: return-void
    0086: invoke-virtual {v7}, Landroid/support/v4/view/ViewPager;->populate()V
    0089: goto 007a

  [Virtual Method] setCurrentItem(I) -> V
    // registers=4, ins=2, outs=4, insns_size=14
    0000: const/4 v1, 0
    0001: iput v1, v2.Landroid/support/v4/view/ViewPager;->mPopulatePending:Z
    0003: iget v0, v2.Landroid/support/v4/view/ViewPager;->mFirstLayout:Z
    0005: if-nez v0, 000c
    0007: const/4 v0, 1
    0008: invoke-virtual {v2, v3, v0, v1}, Landroid/support/v4/view/ViewPager;->setCurrentItemInternal(IZZ)V
    000b: return-void
    000c: move(op=01) v0, v1
    000d: goto 0008

  [Virtual Method] setCurrentItem(I, Z) -> V
    // registers=4, ins=3, outs=4, insns_size=7
    0000: const/4 v0, 0
    0001: iput v0, v1.Landroid/support/v4/view/ViewPager;->mPopulatePending:Z
    0003: invoke-virtual {v1, v2, v3, v0}, Landroid/support/v4/view/ViewPager;->setCurrentItemInternal(IZZ)V
    0006: return-void

  [Virtual Method] setCurrentItemInternal(I, Z, Z) -> V
    // registers=5, ins=4, outs=5, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v3, v4, v0}, Landroid/support/v4/view/ViewPager;->setCurrentItemInternal(IZZI)V
    0004: return-void

  [Virtual Method] setCurrentItemInternal(I, Z, Z, I) -> V
    // registers=11, ins=5, outs=4, insns_size=190
    0000: const/4 v3, 1
    0001: const/4 v1, 0
    0002: iget v0, v6.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0004: if-eqz v0, 000e
    0006: iget v0, v6.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0008: invoke-virtual {v0}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    000b: move-result v0
    000c: if-gtz v0, 0012
    000e: invoke-direct {v6, v1}, Landroid/support/v4/view/ViewPager;->setScrollingCacheEnabled(Z)V
    0011: return-void
    0012: if-nez v9, 0024
    0014: iget v0, v6.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0016: if-ne v0, v7, 0024
    0018: iget v0, v6.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    001a: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    001d: move-result v0
    001e: if-eqz v0, 0024
    0020: invoke-direct {v6, v1}, Landroid/support/v4/view/ViewPager;->setScrollingCacheEnabled(Z)V
    0023: goto 0011
    0024: if-gez v7, 004b
    0026: move(op=01) v7, v1
    0027: iget v0, v6.Landroid/support/v4/view/ViewPager;->mOffscreenPageLimit:I
    0029: iget v2, v6.Landroid/support/v4/view/ViewPager;->mCurItem:I
    002b: binop/2addr(op=b0) v2, v0
    002c: if-gt v7, v2, 0034
    002e: iget v2, v6.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0030: binop(op=91) v0, v2, v0
    0032: if-ge v7, v0, 005c
    0034: move(op=01) v2, v1
    0035: iget v0, v6.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    0037: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    003a: move-result v0
    003b: if-ge v2, v0, 005c
    003d: iget v0, v6.Landroid/support/v4/view/ViewPager;->mItems:Ljava/util/ArrayList;
    003f: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0042: move-result-object v0
    0043: check-cast v0, Landroid/support/v4/view/ViewPager$ItemInfo;
    0045: iput v3, v0.Landroid/support/v4/view/ViewPager$ItemInfo;->scrolling:Z
    0047: binop/lit8(op=d8) v0, v2, 1 (0x1)
    0049: move(op=01) v2, v0
    004a: goto 0035
    004b: iget v0, v6.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    004d: invoke-virtual {v0}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    0050: move-result v0
    0051: if-lt v7, v0, 0027
    0053: iget v0, v6.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0055: invoke-virtual {v0}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    0058: move-result v0
    0059: binop/lit8(op=d8) v7, v0, -1 (-0x1)
    005b: goto 0027
    005c: iget v0, v6.Landroid/support/v4/view/ViewPager;->mCurItem:I
    005e: if-eq v0, v7, 009c
    0060: move(op=01) v0, v3
    0061: invoke-virtual {v6, v7}, Landroid/support/v4/view/ViewPager;->populate(I)V
    0064: invoke-virtual {v6, v7}, Landroid/support/v4/view/ViewPager;->infoForPosition(I)Landroid/support/v4/view/ViewPager$ItemInfo;
    0067: move-result-object v2
    0068: if-eqz v2, 00bc
    006a: invoke-virtual {v6}, Landroid/support/v4/view/ViewPager;->getWidth()I
    006d: move-result v3
    006e: unop(op=82) v3, v3
    006f: iget v4, v6.Landroid/support/v4/view/ViewPager;->mFirstOffset:F
    0071: iget v2, v2.Landroid/support/v4/view/ViewPager$ItemInfo;->offset:F
    0073: iget v5, v6.Landroid/support/v4/view/ViewPager;->mLastOffset:F
    0075: invoke-static {v2, v5}, Ljava/lang/Math;->min(FF)F
    0078: move-result v2
    0079: invoke-static {v4, v2}, Ljava/lang/Math;->max(FF)F
    007c: move-result v2
    007d: binop/2addr(op=c8) v2, v3
    007e: unop(op=87) v2, v2
    007f: if-eqz v8, 009e
    0081: invoke-virtual {v6, v2, v1, v10}, Landroid/support/v4/view/ViewPager;->smoothScrollTo(III)V
    0084: if-eqz v0, 008f
    0086: iget v1, v6.Landroid/support/v4/view/ViewPager;->mOnPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    0088: if-eqz v1, 008f
    008a: iget v1, v6.Landroid/support/v4/view/ViewPager;->mOnPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    008c: invoke-interface {v1, v7}, Landroid/support/v4/view/ViewPager$OnPageChangeListener;->onPageSelected(I)V
    008f: if-eqz v0, 0011
    0091: iget v0, v6.Landroid/support/v4/view/ViewPager;->mInternalPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    0093: if-eqz v0, 0011
    0095: iget v0, v6.Landroid/support/v4/view/ViewPager;->mInternalPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    0097: invoke-interface {v0, v7}, Landroid/support/v4/view/ViewPager$OnPageChangeListener;->onPageSelected(I)V
    009a: goto/16 0011
    009c: move(op=01) v0, v1
    009d: goto 0061
    009e: if-eqz v0, 00a9
    00a0: iget v3, v6.Landroid/support/v4/view/ViewPager;->mOnPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    00a2: if-eqz v3, 00a9
    00a4: iget v3, v6.Landroid/support/v4/view/ViewPager;->mOnPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    00a6: invoke-interface {v3, v7}, Landroid/support/v4/view/ViewPager$OnPageChangeListener;->onPageSelected(I)V
    00a9: if-eqz v0, 00b4
    00ab: iget v0, v6.Landroid/support/v4/view/ViewPager;->mInternalPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    00ad: if-eqz v0, 00b4
    00af: iget v0, v6.Landroid/support/v4/view/ViewPager;->mInternalPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    00b1: invoke-interface {v0, v7}, Landroid/support/v4/view/ViewPager$OnPageChangeListener;->onPageSelected(I)V
    00b4: invoke-direct {v6}, Landroid/support/v4/view/ViewPager;->completeScroll()V
    00b7: invoke-virtual {v6, v2, v1}, Landroid/support/v4/view/ViewPager;->scrollTo(II)V
    00ba: goto/16 0011
    00bc: move(op=01) v2, v1
    00bd: goto 007f

  [Virtual Method] setInternalPageChangeListener(Landroid/support/v4/view/ViewPager$OnPageChangeListener;) -> Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    // registers=3, ins=2, outs=0, insns_size=5
    0000: iget v0, v1.Landroid/support/v4/view/ViewPager;->mInternalPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    0002: iput v2, v1.Landroid/support/v4/view/ViewPager;->mInternalPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    0004: return-object v0

  [Virtual Method] setOffscreenPageLimit(I) -> V
    // registers=6, ins=2, outs=2, insns_size=48
    0000: const/4 v0, 1
    0001: if-ge v5, v0, 0026
    0003: const-string v1, 'ViewPager'
    0005: new-instance v2, Ljava/lang/StringBuilder;
    0007: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    000a: const-string v3, 'Requested offscreen page limit '
    000c: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000f: move-result-object v2
    0010: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0013: move-result-object v2
    0014: const-string v3, ' too small; defaulting to '
    0016: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0019: move-result-object v2
    001a: invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    001d: move-result-object v2
    001e: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0021: move-result-object v2
    0022: invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    0025: move(op=01) v5, v0
    0026: iget v0, v4.Landroid/support/v4/view/ViewPager;->mOffscreenPageLimit:I
    0028: if-eq v5, v0, 002f
    002a: iput v5, v4.Landroid/support/v4/view/ViewPager;->mOffscreenPageLimit:I
    002c: invoke-virtual {v4}, Landroid/support/v4/view/ViewPager;->populate()V
    002f: return-void

  [Virtual Method] setOnAdapterChangeListener(Landroid/support/v4/view/ViewPager$OnAdapterChangeListener;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/view/ViewPager;->mAdapterChangeListener:Landroid/support/v4/view/ViewPager$OnAdapterChangeListener;
    0002: return-void

  [Virtual Method] setOnPageChangeListener(Landroid/support/v4/view/ViewPager$OnPageChangeListener;) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/view/ViewPager;->mOnPageChangeListener:Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    0002: return-void

  [Virtual Method] setPageMargin(I) -> V
    // registers=4, ins=2, outs=5, insns_size=15
    0000: iget v0, v2.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0002: iput v3, v2.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    0004: invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->getWidth()I
    0007: move-result v1
    0008: invoke-direct {v2, v1, v1, v3, v0}, Landroid/support/v4/view/ViewPager;->recomputeScrollPosition(IIII)V
    000b: invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->requestLayout()V
    000e: return-void

  [Virtual Method] setPageMarginDrawable(I) -> V
    // registers=3, ins=2, outs=2, insns_size=16
    0000: invoke-virtual {v1}, Landroid/support/v4/view/ViewPager;->getContext()Landroid/content/Context;
    0003: move-result-object v0
    0004: invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    0007: move-result-object v0
    0008: invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;
    000b: move-result-object v0
    000c: invoke-virtual {v1, v0}, Landroid/support/v4/view/ViewPager;->setPageMarginDrawable(Landroid/graphics/drawable/Drawable;)V
    000f: return-void

  [Virtual Method] setPageMarginDrawable(Landroid/graphics/drawable/Drawable;) -> V
    // registers=3, ins=2, outs=2, insns_size=19
    0000: iput v2, v1.Landroid/support/v4/view/ViewPager;->mMarginDrawable:Landroid/graphics/drawable/Drawable;
    0002: if-eqz v2, 0007
    0004: invoke-virtual {v1}, Landroid/support/v4/view/ViewPager;->refreshDrawableState()V
    0007: if-nez v2, 0011
    0009: const/4 v0, 1
    000a: invoke-virtual {v1, v0}, Landroid/support/v4/view/ViewPager;->setWillNotDraw(Z)V
    000d: invoke-virtual {v1}, Landroid/support/v4/view/ViewPager;->invalidate()V
    0010: return-void
    0011: const/4 v0, 0
    0012: goto 000a

  [Virtual Method] smoothScrollTo(I, I) -> V
    // registers=4, ins=3, outs=4, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v3, v0}, Landroid/support/v4/view/ViewPager;->smoothScrollTo(III)V
    0004: return-void

  [Virtual Method] smoothScrollTo(I, I, I) -> V
    // registers=13, ins=4, outs=6, insns_size=136
    0000: const/4 v5, 0
    0001: const/high16 v8, 1065353216 (0x3f800000)
    0003: invoke-virtual {v9}, Landroid/support/v4/view/ViewPager;->getChildCount()I
    0006: move-result v0
    0007: if-nez v0, 000d
    0009: invoke-direct {v9, v5}, Landroid/support/v4/view/ViewPager;->setScrollingCacheEnabled(Z)V
    000c: return-void
    000d: invoke-virtual {v9}, Landroid/support/v4/view/ViewPager;->getScrollX()I
    0010: move-result v1
    0011: invoke-virtual {v9}, Landroid/support/v4/view/ViewPager;->getScrollY()I
    0014: move-result v2
    0015: binop(op=91) v3, v10, v1
    0017: binop(op=91) v4, v11, v2
    0019: if-nez v3, 0027
    001b: if-nez v4, 0027
    001d: invoke-direct {v9}, Landroid/support/v4/view/ViewPager;->completeScroll()V
    0020: invoke-virtual {v9}, Landroid/support/v4/view/ViewPager;->populate()V
    0023: invoke-direct {v9, v5}, Landroid/support/v4/view/ViewPager;->setScrollState(I)V
    0026: goto 000c
    0027: const/4 v0, 1
    0028: invoke-direct {v9, v0}, Landroid/support/v4/view/ViewPager;->setScrollingCacheEnabled(Z)V
    002b: const/4 v0, 2
    002c: invoke-direct {v9, v0}, Landroid/support/v4/view/ViewPager;->setScrollState(I)V
    002f: invoke-virtual {v9}, Landroid/support/v4/view/ViewPager;->getWidth()I
    0032: move-result v0
    0033: binop/lit8(op=db) v5, v0, 2 (0x2)
    0035: invoke-static {v3}, Ljava/lang/Math;->abs(I)I
    0038: move-result v6
    0039: unop(op=82) v6, v6
    003a: binop/2addr(op=c8) v6, v8
    003b: unop(op=82) v7, v0
    003c: binop/2addr(op=c9) v6, v7
    003d: invoke-static {v8, v6}, Ljava/lang/Math;->min(FF)F
    0040: move-result v6
    0041: unop(op=82) v7, v5
    0042: unop(op=82) v5, v5
    0043: invoke-virtual {v9, v6}, Landroid/support/v4/view/ViewPager;->distanceInfluenceForSnapDuration(F)F
    0046: move-result v6
    0047: binop/2addr(op=c8) v5, v6
    0048: binop/2addr(op=c6) v5, v7
    0049: invoke-static {v12}, Ljava/lang/Math;->abs(I)I
    004c: move-result v6
    004d: if-lez v6, 006d
    004f: const/high16 v0, 1148846080 (0x447a0000)
    0051: unop(op=82) v6, v6
    0052: binop/2addr(op=c9) v5, v6
    0053: invoke-static {v5}, Ljava/lang/Math;->abs(F)F
    0056: move-result v5
    0057: binop/2addr(op=c8) v0, v5
    0058: invoke-static {v0}, Ljava/lang/Math;->round(F)I
    005b: move-result v0
    005c: binop/lit8(op=da) v0, v0, 4 (0x4)
    005e: const/16 v5, 600 (0x258)
    0060: invoke-static {v0, v5}, Ljava/lang/Math;->min(II)I
    0063: move-result v5
    0064: iget v0, v9.Landroid/support/v4/view/ViewPager;->mScroller:Landroid/widget/Scroller;
    0066: invoke-virtual/range {v0..v5}, Landroid/widget/Scroller;->startScroll(IIIII)V
    0069: invoke-static {v9}, Landroid/support/v4/view/ViewCompat;->postInvalidateOnAnimation(Landroid/view/View;)V
    006c: goto 000c
    006d: unop(op=82) v0, v0
    006e: iget v5, v9.Landroid/support/v4/view/ViewPager;->mAdapter:Landroid/support/v4/view/PagerAdapter;
    0070: iget v6, v9.Landroid/support/v4/view/ViewPager;->mCurItem:I
    0072: invoke-virtual {v5, v6}, Landroid/support/v4/view/PagerAdapter;->getPageWidth(I)F
    0075: move-result v5
    0076: binop/2addr(op=c8) v0, v5
    0077: invoke-static {v3}, Ljava/lang/Math;->abs(I)I
    007a: move-result v5
    007b: unop(op=82) v5, v5
    007c: iget v6, v9.Landroid/support/v4/view/ViewPager;->mPageMargin:I
    007e: unop(op=82) v6, v6
    007f: binop/2addr(op=c6) v0, v6
    0080: binop(op=a9) v0, v5, v0
    0082: binop/2addr(op=c6) v0, v8
    0083: const/high16 v5, 1120403456 (0x42c80000)
    0085: binop/2addr(op=c8) v0, v5
    0086: unop(op=87) v0, v0
    0087: goto 005e

  [Virtual Method] verifyDrawable(Landroid/graphics/drawable/Drawable;) -> Z
    // registers=3, ins=2, outs=2, insns_size=14
    0000: invoke-super {v1, v2}, Landroid/view/ViewGroup;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    0003: move-result v0
    0004: if-nez v0, 000a
    0006: iget v0, v1.Landroid/support/v4/view/ViewPager;->mMarginDrawable:Landroid/graphics/drawable/Drawable;
    0008: if-ne v2, v0, 000c
    000a: const/4 v0, 1
    000b: return v0
    000c: const/4 v0, 0
    000d: goto 000b