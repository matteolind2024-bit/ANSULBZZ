=== CLASS Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl$1; (Source: SearchViewCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;
  [Instance Field] this$0: Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl;
  [Instance Field] val$listener: Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;

  [Direct Method] <init>(Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl;, Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;) -> V
    // registers=3, ins=3, outs=1, insns_size=8
    0000: iput v1, v0.Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl$1;->this$0:Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl;
    0002: iput v2, v0.Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl$1;->val$listener:Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;
    0004: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0007: return-void

  [Virtual Method] onQueryTextChange(Ljava/lang/String;) -> Z
    // registers=3, ins=2, outs=2, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl$1;->val$listener:Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;
    0002: invoke-virtual {v0, v2}, Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;->onQueryTextChange(Ljava/lang/String;)Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] onQueryTextSubmit(Ljava/lang/String;) -> Z
    // registers=3, ins=2, outs=2, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/widget/SearchViewCompat$SearchViewCompatHoneycombImpl$1;->val$listener:Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;
    0002: invoke-virtual {v0, v2}, Landroid/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat;->onQueryTextSubmit(Ljava/lang/String;)Z
    0005: move-result v0
    0006: return v0