=== CLASS Landroid/support/v4/app/TaskStackBuilderJellybean; (Source: TaskStackBuilderJellybean.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getActivitiesPendingIntent(Landroid/content/Context;, I, [Landroid/content/Intent;, I, Landroid/os/Bundle;) -> Landroid/app/PendingIntent;
    // registers=6, ins=5, outs=5, insns_size=5
    0000: invoke-static {v1, v2, v3, v4, v5}, Landroid/app/PendingIntent;->getActivities(Landroid/content/Context;I[Landroid/content/Intent;ILandroid/os/Bundle;)Landroid/app/PendingIntent;
    0003: move-result-object v0
    0004: return-object v0