=== CLASS Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImpl; (Source: PagerTitleStrip.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] setSingleLineAllCaps(Landroid/widget/TextView;) -> V