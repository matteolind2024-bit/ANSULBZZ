=== CLASS Landroid/support/v4/view/AccessibilityDelegateCompatJellyBean; (Source: AccessibilityDelegateCompatJellyBean.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getAccessibilityNodeProvider(Ljava/lang/Object;, Landroid/view/View;) -> Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=7
    0000: check-cast v1, Landroid/view/View$AccessibilityDelegate;
    0002: invoke-virtual {v1, v2}, Landroid/view/View$AccessibilityDelegate;->getAccessibilityNodeProvider(Landroid/view/View;)Landroid/view/accessibility/AccessibilityNodeProvider;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] newAccessibilityDelegateBridge(Landroid/support/v4/view/AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean;) -> Ljava/lang/Object;
    // registers=2, ins=1, outs=2, insns_size=6
    0000: new-instance v0, Landroid/support/v4/view/AccessibilityDelegateCompatJellyBean$1;
    0002: invoke-direct {v0, v1}, Landroid/support/v4/view/AccessibilityDelegateCompatJellyBean$1;-><init>(Landroid/support/v4/view/AccessibilityDelegateCompatJellyBean$AccessibilityDelegateBridgeJellyBean;)V
    0005: return-object v0

  [Direct Method] performAccessibilityAction(Ljava/lang/Object;, Landroid/view/View;, I, Landroid/os/Bundle;) -> Z
    // registers=5, ins=4, outs=4, insns_size=7
    0000: check-cast v1, Landroid/view/View$AccessibilityDelegate;
    0002: invoke-virtual {v1, v2, v3, v4}, Landroid/view/View$AccessibilityDelegate;->performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z
    0005: move-result v0
    0006: return v0