=== CLASS Landroid/support/v4/view/ViewPager$ItemInfo; (Source: ViewPager.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] object: Ljava/lang/Object;
  [Instance Field] offset: F
  [Instance Field] position: I
  [Instance Field] scrolling: Z
  [Instance Field] widthFactor: F

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void