=== CLASS Landroid/support/v4/view/PagerTitleStrip; (Source: PagerTitleStrip.java) ===
  Super: Landroid/view/ViewGroup;
  Interfaces: Landroid/support/v4/view/ViewPager$Decor;
  [Static Field] ATTRS: [I = None
  [Static Field] IMPL: Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImpl; = None
  [Static Field] SIDE_ALPHA: F = 0.6000000238418579
  [Static Field] TAG: Ljava/lang/String; = 'PagerTitleStrip'
  [Static Field] TEXT_ATTRS: [I = None
  [Static Field] TEXT_SPACING: I = 16
  [Instance Field] mCurrText: Landroid/widget/TextView;
  [Instance Field] mGravity: I
  [Instance Field] mLastKnownCurrentPage: I
  [Instance Field] mLastKnownPositionOffset: F
  [Instance Field] mNextText: Landroid/widget/TextView;
  [Instance Field] mNonPrimaryAlpha: I
  [Instance Field] mPageListener: Landroid/support/v4/view/PagerTitleStrip$PageListener;
  [Instance Field] mPager: Landroid/support/v4/view/ViewPager;
  [Instance Field] mPrevText: Landroid/widget/TextView;
  [Instance Field] mScaledTextSpacing: I
  [Instance Field] mTextColor: I
  [Instance Field] mUpdatingPositions: Z
  [Instance Field] mUpdatingText: Z

  [Direct Method] <clinit>() -> V
    // registers=3, ins=0, outs=1, insns_size=54
    0000: const/4 v0, 4
    0001: new-array v0, v0, [I
    0003: fill-array-data v0, +39 (-> 002a)
    0006: sput v0, Landroid/support/v4/view/PagerTitleStrip;->ATTRS:[I
    0008: const/4 v0, 1
    0009: new-array v0, v0, [I
    000b: const/4 v1, 0
    000c: const v2, 16843660 (0x101038c)
    000f: aput(op=4b) v2, v0[v1]
    0011: sput v0, Landroid/support/v4/view/PagerTitleStrip;->TEXT_ATTRS:[I
    0013: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0015: const/16 v1, 14 (0xe)
    0017: if-lt v0, v1, 0021
    0019: new-instance v0, Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImplIcs;
    001b: invoke-direct {v0}, Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImplIcs;-><init>()V
    001e: sput v0, Landroid/support/v4/view/PagerTitleStrip;->IMPL:Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImpl;
    0020: return-void
    0021: new-instance v0, Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImplBase;
    0023: invoke-direct {v0}, Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImplBase;-><init>()V
    0026: sput v0, Landroid/support/v4/view/PagerTitleStrip;->IMPL:Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImpl;
    0028: goto 0020
    0029: nop
    002a: fill-array-data-payload width=4 size=4 data=340001019500010198000101af000101

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=3, ins=2, outs=3, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-direct {v1, v2, v0}, Landroid/support/v4/view/PagerTitleStrip;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    0004: return-void

  [Direct Method] <init>(Landroid/content/Context;, Landroid/util/AttributeSet;) -> V
    // registers=8, ins=3, outs=3, insns_size=229
    0000: const/4 v4, 2
    0001: const/4 v0, 0
    0002: invoke-direct {v5, v6, v7}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    0005: const/4 v1, -1
    0006: iput v1, v5.Landroid/support/v4/view/PagerTitleStrip;->mLastKnownCurrentPage:I
    0008: const/high16 v1, -1082130432 (-0x40800000)
    000a: iput v1, v5.Landroid/support/v4/view/PagerTitleStrip;->mLastKnownPositionOffset:F
    000c: new-instance v1, Landroid/support/v4/view/PagerTitleStrip$PageListener;
    000e: const/4 v2, 0
    000f: invoke-direct {v1, v5, v2}, Landroid/support/v4/view/PagerTitleStrip$PageListener;-><init>(Landroid/support/v4/view/PagerTitleStrip;Landroid/support/v4/view/PagerTitleStrip$1;)V
    0012: iput v1, v5.Landroid/support/v4/view/PagerTitleStrip;->mPageListener:Landroid/support/v4/view/PagerTitleStrip$PageListener;
    0014: new-instance v1, Landroid/widget/TextView;
    0016: invoke-direct {v1, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    0019: iput v1, v5.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    001b: invoke-virtual {v5, v1}, Landroid/support/v4/view/PagerTitleStrip;->addView(Landroid/view/View;)V
    001e: new-instance v1, Landroid/widget/TextView;
    0020: invoke-direct {v1, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    0023: iput v1, v5.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    0025: invoke-virtual {v5, v1}, Landroid/support/v4/view/PagerTitleStrip;->addView(Landroid/view/View;)V
    0028: new-instance v1, Landroid/widget/TextView;
    002a: invoke-direct {v1, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    002d: iput v1, v5.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    002f: invoke-virtual {v5, v1}, Landroid/support/v4/view/PagerTitleStrip;->addView(Landroid/view/View;)V
    0032: sget v1, Landroid/support/v4/view/PagerTitleStrip;->ATTRS:[I
    0034: invoke-virtual {v6, v7, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    0037: move-result-object v1
    0038: invoke-virtual {v1, v0, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I
    003b: move-result v2
    003c: if-eqz v2, 004d
    003e: iget v3, v5.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    0040: invoke-virtual {v3, v6, v2}, Landroid/widget/TextView;->setTextAppearance(Landroid/content/Context;I)V
    0043: iget v3, v5.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    0045: invoke-virtual {v3, v6, v2}, Landroid/widget/TextView;->setTextAppearance(Landroid/content/Context;I)V
    0048: iget v3, v5.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    004a: invoke-virtual {v3, v6, v2}, Landroid/widget/TextView;->setTextAppearance(Landroid/content/Context;I)V
    004d: const/4 v3, 1
    004e: invoke-virtual {v1, v3, v0}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I
    0051: move-result v3
    0052: if-eqz v3, 0058
    0054: unop(op=82) v3, v3
    0055: invoke-virtual {v5, v0, v3}, Landroid/support/v4/view/PagerTitleStrip;->setTextSize(IF)V
    0058: invoke-virtual {v1, v4}, Landroid/content/res/TypedArray;->hasValue(I)Z
    005b: move-result v3
    005c: if-eqz v3, 0071
    005e: invoke-virtual {v1, v4, v0}, Landroid/content/res/TypedArray;->getColor(II)I
    0061: move-result v3
    0062: iget v4, v5.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    0064: invoke-virtual {v4, v3}, Landroid/widget/TextView;->setTextColor(I)V
    0067: iget v4, v5.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    0069: invoke-virtual {v4, v3}, Landroid/widget/TextView;->setTextColor(I)V
    006c: iget v4, v5.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    006e: invoke-virtual {v4, v3}, Landroid/widget/TextView;->setTextColor(I)V
    0071: const/4 v3, 3
    0072: const/16 v4, 80 (0x50)
    0074: invoke-virtual {v1, v3, v4}, Landroid/content/res/TypedArray;->getInteger(II)I
    0077: move-result v3
    0078: iput v3, v5.Landroid/support/v4/view/PagerTitleStrip;->mGravity:I
    007a: invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V
    007d: iget v1, v5.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    007f: invoke-virtual {v1}, Landroid/widget/TextView;->getTextColors()Landroid/content/res/ColorStateList;
    0082: move-result-object v1
    0083: invoke-virtual {v1}, Landroid/content/res/ColorStateList;->getDefaultColor()I
    0086: move-result v1
    0087: iput v1, v5.Landroid/support/v4/view/PagerTitleStrip;->mTextColor:I
    0089: const v1, 1058642330 (0x3f19999a)
    008c: invoke-virtual {v5, v1}, Landroid/support/v4/view/PagerTitleStrip;->setNonPrimaryAlpha(F)V
    008f: iget v1, v5.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    0091: sget v3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;
    0093: invoke-virtual {v1, v3}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V
    0096: iget v1, v5.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    0098: sget v3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;
    009a: invoke-virtual {v1, v3}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V
    009d: iget v1, v5.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    009f: sget v3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;
    00a1: invoke-virtual {v1, v3}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V
    00a4: if-eqz v2, 00b3
    00a6: sget v1, Landroid/support/v4/view/PagerTitleStrip;->TEXT_ATTRS:[I
    00a8: invoke-virtual {v6, v2, v1}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;
    00ab: move-result-object v1
    00ac: invoke-virtual {v1, v0, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z
    00af: move-result v0
    00b0: invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V
    00b3: if-eqz v0, 00d5
    00b5: iget v0, v5.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    00b7: invoke-static {v0}, Landroid/support/v4/view/PagerTitleStrip;->setSingleLineAllCaps(Landroid/widget/TextView;)V
    00ba: iget v0, v5.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    00bc: invoke-static {v0}, Landroid/support/v4/view/PagerTitleStrip;->setSingleLineAllCaps(Landroid/widget/TextView;)V
    00bf: iget v0, v5.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    00c1: invoke-static {v0}, Landroid/support/v4/view/PagerTitleStrip;->setSingleLineAllCaps(Landroid/widget/TextView;)V
    00c4: invoke-virtual {v6}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;
    00c7: move-result-object v0
    00c8: invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;
    00cb: move-result-object v0
    00cc: iget v0, v0.Landroid/util/DisplayMetrics;->density:F
    00ce: const/high16 v1, 1098907648 (0x41800000)
    00d0: binop/2addr(op=c8) v0, v1
    00d1: unop(op=87) v0, v0
    00d2: iput v0, v5.Landroid/support/v4/view/PagerTitleStrip;->mScaledTextSpacing:I
    00d4: return-void
    00d5: iget v0, v5.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    00d7: invoke-virtual {v0}, Landroid/widget/TextView;->setSingleLine()V
    00da: iget v0, v5.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    00dc: invoke-virtual {v0}, Landroid/widget/TextView;->setSingleLine()V
    00df: iget v0, v5.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    00e1: invoke-virtual {v0}, Landroid/widget/TextView;->setSingleLine()V
    00e4: goto 00c4

  [Direct Method] setSingleLineAllCaps(Landroid/widget/TextView;) -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: sget v0, Landroid/support/v4/view/PagerTitleStrip;->IMPL:Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/view/PagerTitleStrip$PagerTitleStripImpl;->setSingleLineAllCaps(Landroid/widget/TextView;)V
    0005: return-void

  [Virtual Method] getMinHeight() -> I
    // registers=3, ins=1, outs=1, insns_size=12
    0000: const/4 v0, 0
    0001: invoke-virtual {v2}, Landroid/support/v4/view/PagerTitleStrip;->getBackground()Landroid/graphics/drawable/Drawable;
    0004: move-result-object v1
    0005: if-eqz v1, 000b
    0007: invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I
    000a: move-result v0
    000b: return v0

  [Virtual Method] getTextSpacing() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mScaledTextSpacing:I
    0002: return v0

  [Virtual Method] onAttachedToWindow() -> V
    // registers=4, ins=1, outs=3, insns_size=42
    0000: invoke-super {v3}, Landroid/view/ViewGroup;->onAttachedToWindow()V
    0003: invoke-virtual {v3}, Landroid/support/v4/view/PagerTitleStrip;->getParent()Landroid/view/ViewParent;
    0006: move-result-object v0
    0007: instance-of v1, v0, Landroid/support/v4/view/ViewPager;
    0009: if-nez v1, 0013
    000b: new-instance v0, Ljava/lang/IllegalStateException;
    000d: const-string v1, 'PagerTitleStrip must be a direct child of a ViewPager.'
    000f: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0012: throw v0
    0013: check-cast v0, Landroid/support/v4/view/ViewPager;
    0015: invoke-virtual {v0}, Landroid/support/v4/view/ViewPager;->getAdapter()Landroid/support/v4/view/PagerAdapter;
    0018: move-result-object v1
    0019: iget v2, v3.Landroid/support/v4/view/PagerTitleStrip;->mPageListener:Landroid/support/v4/view/PagerTitleStrip$PageListener;
    001b: invoke-virtual {v0, v2}, Landroid/support/v4/view/ViewPager;->setInternalPageChangeListener(Landroid/support/v4/view/ViewPager$OnPageChangeListener;)Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    001e: iget v2, v3.Landroid/support/v4/view/PagerTitleStrip;->mPageListener:Landroid/support/v4/view/PagerTitleStrip$PageListener;
    0020: invoke-virtual {v0, v2}, Landroid/support/v4/view/ViewPager;->setOnAdapterChangeListener(Landroid/support/v4/view/ViewPager$OnAdapterChangeListener;)V
    0023: iput v0, v3.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0025: const/4 v0, 0
    0026: invoke-virtual {v3, v0, v1}, Landroid/support/v4/view/PagerTitleStrip;->updateAdapter(Landroid/support/v4/view/PagerAdapter;Landroid/support/v4/view/PagerAdapter;)V
    0029: return-void

  [Virtual Method] onDetachedFromWindow() -> V
    // registers=3, ins=1, outs=3, insns_size=30
    0000: const/4 v1, 0
    0001: invoke-super {v2}, Landroid/view/ViewGroup;->onDetachedFromWindow()V
    0004: iget v0, v2.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0006: if-eqz v0, 001d
    0008: iget v0, v2.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    000a: invoke-virtual {v0}, Landroid/support/v4/view/ViewPager;->getAdapter()Landroid/support/v4/view/PagerAdapter;
    000d: move-result-object v0
    000e: invoke-virtual {v2, v0, v1}, Landroid/support/v4/view/PagerTitleStrip;->updateAdapter(Landroid/support/v4/view/PagerAdapter;Landroid/support/v4/view/PagerAdapter;)V
    0011: iget v0, v2.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0013: invoke-virtual {v0, v1}, Landroid/support/v4/view/ViewPager;->setInternalPageChangeListener(Landroid/support/v4/view/ViewPager$OnPageChangeListener;)Landroid/support/v4/view/ViewPager$OnPageChangeListener;
    0016: iget v0, v2.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0018: invoke-virtual {v0, v1}, Landroid/support/v4/view/ViewPager;->setOnAdapterChangeListener(Landroid/support/v4/view/ViewPager$OnAdapterChangeListener;)V
    001b: iput v1, v2.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    001d: return-void

  [Virtual Method] onLayout(Z, I, I, I, I) -> V
    // registers=9, ins=6, outs=4, insns_size=24
    0000: const/4 v0, 0
    0001: iget v1, v3.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0003: if-eqz v1, 0017
    0005: iget v1, v3.Landroid/support/v4/view/PagerTitleStrip;->mLastKnownPositionOffset:F
    0007: cmp(op=2d) v1, v1, v0
    0009: if-ltz v1, 000d
    000b: iget v0, v3.Landroid/support/v4/view/PagerTitleStrip;->mLastKnownPositionOffset:F
    000d: iget v1, v3.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    000f: invoke-virtual {v1}, Landroid/support/v4/view/ViewPager;->getCurrentItem()I
    0012: move-result v1
    0013: const/4 v2, 1
    0014: invoke-virtual {v3, v1, v0, v2}, Landroid/support/v4/view/PagerTitleStrip;->updateTextPositions(IFZ)V
    0017: return-void

  [Virtual Method] onMeasure(I, I) -> V
    // registers=13, ins=3, outs=3, insns_size=95
    0000: const/high16 v9, 1073741824 (0x40000000)
    0002: const/high16 v8, -2147483648 (-0x80000000)
    0004: invoke-static {v11}, Landroid/view/View$MeasureSpec;->getMode(I)I
    0007: move-result v0
    0008: invoke-static {v12}, Landroid/view/View$MeasureSpec;->getMode(I)I
    000b: move-result v1
    000c: invoke-static {v11}, Landroid/view/View$MeasureSpec;->getSize(I)I
    000f: move-result v2
    0010: invoke-static {v12}, Landroid/view/View$MeasureSpec;->getSize(I)I
    0013: move-result v3
    0014: if-eq v0, v9, 001e
    0016: new-instance v0, Ljava/lang/IllegalStateException;
    0018: const-string v1, 'Must measure with an exact width'
    001a: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    001d: throw v0
    001e: invoke-virtual {v10}, Landroid/support/v4/view/PagerTitleStrip;->getMinHeight()I
    0021: move-result v0
    0022: invoke-virtual {v10}, Landroid/support/v4/view/PagerTitleStrip;->getPaddingTop()I
    0025: move-result v4
    0026: invoke-virtual {v10}, Landroid/support/v4/view/PagerTitleStrip;->getPaddingBottom()I
    0029: move-result v5
    002a: binop/2addr(op=b0) v4, v5
    002b: binop(op=91) v5, v3, v4
    002d: unop(op=82) v6, v2
    002e: const v7, 1061997773 (0x3f4ccccd)
    0031: binop/2addr(op=c8) v6, v7
    0032: unop(op=87) v6, v6
    0033: invoke-static {v6, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    0036: move-result v6
    0037: invoke-static {v5, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    003a: move-result v5
    003b: iget v7, v10.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    003d: invoke-virtual {v7, v6, v5}, Landroid/widget/TextView;->measure(II)V
    0040: iget v7, v10.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    0042: invoke-virtual {v7, v6, v5}, Landroid/widget/TextView;->measure(II)V
    0045: iget v7, v10.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    0047: invoke-virtual {v7, v6, v5}, Landroid/widget/TextView;->measure(II)V
    004a: if-ne v1, v9, 0050
    004c: invoke-virtual {v10, v2, v3}, Landroid/support/v4/view/PagerTitleStrip;->setMeasuredDimension(II)V
    004f: return-void
    0050: iget v1, v10.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    0052: invoke-virtual {v1}, Landroid/widget/TextView;->getMeasuredHeight()I
    0055: move-result v1
    0056: binop/2addr(op=b0) v1, v4
    0057: invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I
    005a: move-result v0
    005b: invoke-virtual {v10, v2, v0}, Landroid/support/v4/view/PagerTitleStrip;->setMeasuredDimension(II)V
    005e: goto 004f

  [Virtual Method] requestLayout() -> V
    // registers=2, ins=1, outs=1, insns_size=8
    0000: iget v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mUpdatingText:Z
    0002: if-nez v0, 0007
    0004: invoke-super {v1}, Landroid/view/ViewGroup;->requestLayout()V
    0007: return-void

  [Virtual Method] setGravity(I) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/view/PagerTitleStrip;->mGravity:I
    0002: invoke-virtual {v0}, Landroid/support/v4/view/PagerTitleStrip;->requestLayout()V
    0005: return-void

  [Virtual Method] setNonPrimaryAlpha(F) -> V
    // registers=5, ins=2, outs=2, insns_size=30
    0000: const/high16 v0, 1132396544 (0x437f0000)
    0002: binop/2addr(op=c8) v0, v4
    0003: unop(op=87) v0, v0
    0004: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0006: iput v0, v3.Landroid/support/v4/view/PagerTitleStrip;->mNonPrimaryAlpha:I
    0008: iget v0, v3.Landroid/support/v4/view/PagerTitleStrip;->mNonPrimaryAlpha:I
    000a: binop/lit8(op=e0) v0, v0, 24 (0x18)
    000c: iget v1, v3.Landroid/support/v4/view/PagerTitleStrip;->mTextColor:I
    000e: const v2, 16777215 (0xffffff)
    0011: binop/2addr(op=b5) v1, v2
    0012: binop/2addr(op=b6) v0, v1
    0013: iget v1, v3.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    0015: invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V
    0018: iget v1, v3.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    001a: invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V
    001d: return-void

  [Virtual Method] setTextColor(I) -> V
    // registers=5, ins=2, outs=2, insns_size=29
    0000: iput v4, v3.Landroid/support/v4/view/PagerTitleStrip;->mTextColor:I
    0002: iget v0, v3.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    0004: invoke-virtual {v0, v4}, Landroid/widget/TextView;->setTextColor(I)V
    0007: iget v0, v3.Landroid/support/v4/view/PagerTitleStrip;->mNonPrimaryAlpha:I
    0009: binop/lit8(op=e0) v0, v0, 24 (0x18)
    000b: iget v1, v3.Landroid/support/v4/view/PagerTitleStrip;->mTextColor:I
    000d: const v2, 16777215 (0xffffff)
    0010: binop/2addr(op=b5) v1, v2
    0011: binop/2addr(op=b6) v0, v1
    0012: iget v1, v3.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    0014: invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V
    0017: iget v1, v3.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    0019: invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V
    001c: return-void

  [Virtual Method] setTextSize(I, F) -> V
    // registers=4, ins=3, outs=3, insns_size=16
    0000: iget v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    0002: invoke-virtual {v0, v2, v3}, Landroid/widget/TextView;->setTextSize(IF)V
    0005: iget v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    0007: invoke-virtual {v0, v2, v3}, Landroid/widget/TextView;->setTextSize(IF)V
    000a: iget v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    000c: invoke-virtual {v0, v2, v3}, Landroid/widget/TextView;->setTextSize(IF)V
    000f: return-void

  [Virtual Method] setTextSpacing(I) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/view/PagerTitleStrip;->mScaledTextSpacing:I
    0002: invoke-virtual {v0}, Landroid/support/v4/view/PagerTitleStrip;->requestLayout()V
    0005: return-void

  [Virtual Method] updateAdapter(Landroid/support/v4/view/PagerAdapter;, Landroid/support/v4/view/PagerAdapter;) -> V
    // registers=4, ins=3, outs=3, insns_size=38
    0000: if-eqz v2, 0007
    0002: iget v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mPageListener:Landroid/support/v4/view/PagerTitleStrip$PageListener;
    0004: invoke-virtual {v2, v0}, Landroid/support/v4/view/PagerAdapter;->unregisterDataSetObserver(Landroid/database/DataSetObserver;)V
    0007: if-eqz v3, 000e
    0009: iget v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mPageListener:Landroid/support/v4/view/PagerTitleStrip$PageListener;
    000b: invoke-virtual {v3, v0}, Landroid/support/v4/view/PagerAdapter;->registerDataSetObserver(Landroid/database/DataSetObserver;)V
    000e: iget v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0010: if-eqz v0, 0025
    0012: const/4 v0, -1
    0013: iput v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mLastKnownCurrentPage:I
    0015: const/high16 v0, -1082130432 (-0x40800000)
    0017: iput v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mLastKnownPositionOffset:F
    0019: iget v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    001b: invoke-virtual {v0}, Landroid/support/v4/view/ViewPager;->getCurrentItem()I
    001e: move-result v0
    001f: invoke-virtual {v1, v0, v3}, Landroid/support/v4/view/PagerTitleStrip;->updateText(ILandroid/support/v4/view/PagerAdapter;)V
    0022: invoke-virtual {v1}, Landroid/support/v4/view/PagerTitleStrip;->requestLayout()V
    0025: return-void

  [Virtual Method] updateText(I, Landroid/support/v4/view/PagerAdapter;) -> V
    // registers=9, ins=3, outs=4, insns_size=135
    0000: const/4 v2, 1
    0001: const/high16 v5, -2147483648 (-0x80000000)
    0003: const/4 v3, 0
    0004: const/4 v1, 0
    0005: if-eqz v8, 0081
    0007: invoke-virtual {v8}, Landroid/support/v4/view/PagerAdapter;->getCount()I
    000a: move-result v0
    000b: iput v2, v6.Landroid/support/v4/view/PagerTitleStrip;->mUpdatingText:Z
    000d: if-lt v7, v2, 0085
    000f: if-eqz v8, 0085
    0011: binop/lit8(op=d8) v2, v7, -1 (-0x1)
    0013: invoke-virtual {v8, v2}, Landroid/support/v4/view/PagerAdapter;->getPageTitle(I)Ljava/lang/CharSequence;
    0016: move-result-object v2
    0017: iget v4, v6.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    0019: invoke-virtual {v4, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    001c: iget v4, v6.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    001e: if-eqz v8, 0083
    0020: if-ge v7, v0, 0083
    0022: invoke-virtual {v8, v7}, Landroid/support/v4/view/PagerAdapter;->getPageTitle(I)Ljava/lang/CharSequence;
    0025: move-result-object v2
    0026: invoke-virtual {v4, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    0029: binop/lit8(op=d8) v2, v7, 1 (0x1)
    002b: if-ge v2, v0, 0035
    002d: if-eqz v8, 0035
    002f: binop/lit8(op=d8) v0, v7, 1 (0x1)
    0031: invoke-virtual {v8, v0}, Landroid/support/v4/view/PagerAdapter;->getPageTitle(I)Ljava/lang/CharSequence;
    0034: move-result-object v3
    0035: iget v0, v6.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    0037: invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    003a: invoke-virtual {v6}, Landroid/support/v4/view/PagerTitleStrip;->getWidth()I
    003d: move-result v0
    003e: invoke-virtual {v6}, Landroid/support/v4/view/PagerTitleStrip;->getPaddingLeft()I
    0041: move-result v2
    0042: binop/2addr(op=b1) v0, v2
    0043: invoke-virtual {v6}, Landroid/support/v4/view/PagerTitleStrip;->getPaddingRight()I
    0046: move-result v2
    0047: binop/2addr(op=b1) v0, v2
    0048: invoke-virtual {v6}, Landroid/support/v4/view/PagerTitleStrip;->getHeight()I
    004b: move-result v2
    004c: invoke-virtual {v6}, Landroid/support/v4/view/PagerTitleStrip;->getPaddingTop()I
    004f: move-result v3
    0050: binop/2addr(op=b1) v2, v3
    0051: invoke-virtual {v6}, Landroid/support/v4/view/PagerTitleStrip;->getPaddingBottom()I
    0054: move-result v3
    0055: binop/2addr(op=b1) v2, v3
    0056: unop(op=82) v0, v0
    0057: const v3, 1061997773 (0x3f4ccccd)
    005a: binop/2addr(op=c8) v0, v3
    005b: unop(op=87) v0, v0
    005c: invoke-static {v0, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    005f: move-result v0
    0060: invoke-static {v2, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I
    0063: move-result v2
    0064: iget v3, v6.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    0066: invoke-virtual {v3, v0, v2}, Landroid/widget/TextView;->measure(II)V
    0069: iget v3, v6.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    006b: invoke-virtual {v3, v0, v2}, Landroid/widget/TextView;->measure(II)V
    006e: iget v3, v6.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    0070: invoke-virtual {v3, v0, v2}, Landroid/widget/TextView;->measure(II)V
    0073: iput v7, v6.Landroid/support/v4/view/PagerTitleStrip;->mLastKnownCurrentPage:I
    0075: iget v0, v6.Landroid/support/v4/view/PagerTitleStrip;->mUpdatingPositions:Z
    0077: if-nez v0, 007e
    0079: iget v0, v6.Landroid/support/v4/view/PagerTitleStrip;->mLastKnownPositionOffset:F
    007b: invoke-virtual {v6, v7, v0, v1}, Landroid/support/v4/view/PagerTitleStrip;->updateTextPositions(IFZ)V
    007e: iput v1, v6.Landroid/support/v4/view/PagerTitleStrip;->mUpdatingText:Z
    0080: return-void
    0081: move(op=01) v0, v1
    0082: goto 000b
    0083: move(op=07) v2, v3
    0084: goto 0026
    0085: move(op=07) v2, v3
    0086: goto 0017

  [Virtual Method] updateTextPositions(I, F, Z) -> V
    // registers=22, ins=4, outs=5, insns_size=336
    0000: move/from16 v0, v18
    0002: iget v2, v0.Landroid/support/v4/view/PagerTitleStrip;->mLastKnownCurrentPage:I
    0004: move/from16 v0, v19
    0006: if-eq v0, v2, 0127
    0008: move/from16 v0, v18
    000a: iget v2, v0.Landroid/support/v4/view/PagerTitleStrip;->mPager:Landroid/support/v4/view/ViewPager;
    000c: invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->getAdapter()Landroid/support/v4/view/PagerAdapter;
    000f: move-result-object v2
    0010: move/from16 v0, v18
    0012: move/from16 v1, v19
    0014: invoke-virtual {v0, v1, v2}, Landroid/support/v4/view/PagerTitleStrip;->updateText(ILandroid/support/v4/view/PagerAdapter;)V
    0017: const/4 v2, 1
    0018: move/from16 v0, v18
    001a: iput v2, v0.Landroid/support/v4/view/PagerTitleStrip;->mUpdatingPositions:Z
    001c: move/from16 v0, v18
    001e: iget v2, v0.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    0020: invoke-virtual {v2}, Landroid/widget/TextView;->getMeasuredWidth()I
    0023: move-result v5
    0024: move/from16 v0, v18
    0026: iget v2, v0.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    0028: invoke-virtual {v2}, Landroid/widget/TextView;->getMeasuredWidth()I
    002b: move-result v3
    002c: move/from16 v0, v18
    002e: iget v2, v0.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    0030: invoke-virtual {v2}, Landroid/widget/TextView;->getMeasuredWidth()I
    0033: move-result v6
    0034: binop/lit8(op=db) v2, v3, 2 (0x2)
    0036: invoke-virtual/range {v18..v18}, Landroid/support/v4/view/PagerTitleStrip;->getWidth()I
    0039: move-result v7
    003a: invoke-virtual/range {v18..v18}, Landroid/support/v4/view/PagerTitleStrip;->getHeight()I
    003d: move-result v4
    003e: invoke-virtual/range {v18..v18}, Landroid/support/v4/view/PagerTitleStrip;->getPaddingLeft()I
    0041: move-result v8
    0042: invoke-virtual/range {v18..v18}, Landroid/support/v4/view/PagerTitleStrip;->getPaddingRight()I
    0045: move-result v9
    0046: invoke-virtual/range {v18..v18}, Landroid/support/v4/view/PagerTitleStrip;->getPaddingTop()I
    0049: move-result v10
    004a: invoke-virtual/range {v18..v18}, Landroid/support/v4/view/PagerTitleStrip;->getPaddingBottom()I
    004d: move-result v11
    004e: binop(op=90) v12, v8, v2
    0050: binop(op=90) v13, v9, v2
    0052: binop(op=91) v2, v7, v12
    0054: binop(op=91) v12, v2, v13
    0056: const/high16 v2, 1056964608 (0x3f000000)
    0058: binop(op=a6) v2, v2, v20
    005a: const/high16 v14, 1065353216 (0x3f800000)
    005c: cmp(op=2d) v14, v2, v14
    005e: if-lez v14, 0063
    0060: const/high16 v14, 1065353216 (0x3f800000)
    0062: binop/2addr(op=c7) v2, v14
    0063: binop(op=91) v13, v7, v13
    0065: unop(op=82) v12, v12
    0066: binop/2addr(op=c8) v2, v12
    0067: unop(op=87) v2, v2
    0068: binop(op=91) v2, v13, v2
    006a: binop/lit8(op=db) v12, v3, 2 (0x2)
    006c: binop(op=91) v12, v2, v12
    006e: binop(op=90) v13, v12, v3
    0070: move/from16 v0, v18
    0072: iget v2, v0.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    0074: invoke-virtual {v2}, Landroid/widget/TextView;->getBaseline()I
    0077: move-result v2
    0078: move/from16 v0, v18
    007a: iget v3, v0.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    007c: invoke-virtual {v3}, Landroid/widget/TextView;->getBaseline()I
    007f: move-result v3
    0080: move/from16 v0, v18
    0082: iget v14, v0.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    0084: invoke-virtual {v14}, Landroid/widget/TextView;->getBaseline()I
    0087: move-result v14
    0088: invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I
    008b: move-result v15
    008c: invoke-static {v15, v14}, Ljava/lang/Math;->max(II)I
    008f: move-result v15
    0090: binop(op=91) v2, v15, v2
    0092: binop(op=91) v3, v15, v3
    0094: binop(op=91) v14, v15, v14
    0096: move/from16 v0, v18
    0098: iget v15, v0.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    009a: invoke-virtual {v15}, Landroid/widget/TextView;->getMeasuredHeight()I
    009d: move-result v15
    009e: binop/2addr(op=b0) v15, v2
    009f: move/from16 v0, v18
    00a1: iget v0, v0.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    00a3: move/from16 v16, v0
    00a5: invoke-virtual/range {v16..v16}, Landroid/widget/TextView;->getMeasuredHeight()I
    00a8: move-result v16
    00a9: binop(op=90) v16, v16, v3
    00ab: move/from16 v0, v18
    00ad: iget v0, v0.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    00af: move/from16 v17, v0
    00b1: invoke-virtual/range {v17..v17}, Landroid/widget/TextView;->getMeasuredHeight()I
    00b4: move-result v17
    00b5: binop(op=90) v17, v17, v14
    00b7: invoke-static/range {v15..v16}, Ljava/lang/Math;->max(II)I
    00ba: move-result v15
    00bb: move/from16 v0, v17
    00bd: invoke-static {v15, v0}, Ljava/lang/Math;->max(II)I
    00c0: move-result v15
    00c1: move/from16 v0, v18
    00c3: iget v0, v0.Landroid/support/v4/view/PagerTitleStrip;->mGravity:I
    00c5: move/from16 v16, v0
    00c7: binop/lit8(op=dd) v16, v16, 112 (0x70)
    00c9: sparse-switch v16, +125 (-> 0146)
    00cc: binop(op=90) v4, v10, v2
    00ce: binop/2addr(op=b0) v3, v10
    00cf: binop(op=90) v2, v10, v14
    00d1: move/from16 v0, v18
    00d3: iget v10, v0.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    00d5: move/from16 v0, v18
    00d7: iget v11, v0.Landroid/support/v4/view/PagerTitleStrip;->mCurrText:Landroid/widget/TextView;
    00d9: invoke-virtual {v11}, Landroid/widget/TextView;->getMeasuredHeight()I
    00dc: move-result v11
    00dd: binop/2addr(op=b0) v11, v3
    00de: invoke-virtual {v10, v12, v3, v13, v11}, Landroid/widget/TextView;->layout(IIII)V
    00e1: move/from16 v0, v18
    00e3: iget v3, v0.Landroid/support/v4/view/PagerTitleStrip;->mScaledTextSpacing:I
    00e5: binop(op=91) v3, v12, v3
    00e7: binop/2addr(op=b1) v3, v5
    00e8: invoke-static {v8, v3}, Ljava/lang/Math;->min(II)I
    00eb: move-result v3
    00ec: move/from16 v0, v18
    00ee: iget v8, v0.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    00f0: binop/2addr(op=b0) v5, v3
    00f1: move/from16 v0, v18
    00f3: iget v10, v0.Landroid/support/v4/view/PagerTitleStrip;->mPrevText:Landroid/widget/TextView;
    00f5: invoke-virtual {v10}, Landroid/widget/TextView;->getMeasuredHeight()I
    00f8: move-result v10
    00f9: binop/2addr(op=b0) v10, v4
    00fa: invoke-virtual {v8, v3, v4, v5, v10}, Landroid/widget/TextView;->layout(IIII)V
    00fd: binop(op=91) v3, v7, v9
    00ff: binop/2addr(op=b1) v3, v6
    0100: move/from16 v0, v18
    0102: iget v4, v0.Landroid/support/v4/view/PagerTitleStrip;->mScaledTextSpacing:I
    0104: binop/2addr(op=b0) v4, v13
    0105: invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I
    0108: move-result v3
    0109: move/from16 v0, v18
    010b: iget v4, v0.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    010d: binop(op=90) v5, v3, v6
    010f: move/from16 v0, v18
    0111: iget v6, v0.Landroid/support/v4/view/PagerTitleStrip;->mNextText:Landroid/widget/TextView;
    0113: invoke-virtual {v6}, Landroid/widget/TextView;->getMeasuredHeight()I
    0116: move-result v6
    0117: binop/2addr(op=b0) v6, v2
    0118: invoke-virtual {v4, v3, v2, v5, v6}, Landroid/widget/TextView;->layout(IIII)V
    011b: move/from16 v0, v20
    011d: move/from16 v1, v18
    011f: iput v0, v1.Landroid/support/v4/view/PagerTitleStrip;->mLastKnownPositionOffset:F
    0121: const/4 v2, 0
    0122: move/from16 v0, v18
    0124: iput v2, v0.Landroid/support/v4/view/PagerTitleStrip;->mUpdatingPositions:Z
    0126: return-void
    0127: if-nez v21, 0017
    0129: move/from16 v0, v18
    012b: iget v2, v0.Landroid/support/v4/view/PagerTitleStrip;->mLastKnownPositionOffset:F
    012d: cmp(op=2d) v2, v20, v2
    012f: if-nez v2, 0017
    0131: goto 0126
    0132: binop/2addr(op=b1) v4, v10
    0133: binop/2addr(op=b1) v4, v11
    0134: binop/2addr(op=b1) v4, v15
    0135: binop/lit8(op=db) v10, v4, 2 (0x2)
    0137: binop(op=90) v4, v10, v2
    0139: binop/2addr(op=b0) v3, v10
    013a: binop(op=90) v2, v10, v14
    013c: goto 00d1
    013d: binop/2addr(op=b1) v4, v11
    013e: binop(op=91) v10, v4, v15
    0140: binop(op=90) v4, v10, v2
    0142: binop/2addr(op=b0) v3, v10
    0143: binop(op=90) v2, v10, v14
    0145: goto 00d1
    0146: sparse-switch-payload {16: 105, 80: 116}