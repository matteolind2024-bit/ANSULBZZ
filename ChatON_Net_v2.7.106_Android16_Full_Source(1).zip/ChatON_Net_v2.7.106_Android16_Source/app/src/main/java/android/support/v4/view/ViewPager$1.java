=== CLASS Landroid/support/v4/view/ViewPager$1; (Source: ViewPager.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/util/Comparator;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] compare(Landroid/support/v4/view/ViewPager$ItemInfo;, Landroid/support/v4/view/ViewPager$ItemInfo;) -> I
    // registers=5, ins=3, outs=0, insns_size=6
    0000: iget v0, v3.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0002: iget v1, v4.Landroid/support/v4/view/ViewPager$ItemInfo;->position:I
    0004: binop/2addr(op=b1) v0, v1
    0005: return v0

  [Virtual Method] compare(Ljava/lang/Object;, Ljava/lang/Object;) -> I
    // registers=4, ins=3, outs=3, insns_size=9
    0000: check-cast v2, Landroid/support/v4/view/ViewPager$ItemInfo;
    0002: check-cast v3, Landroid/support/v4/view/ViewPager$ItemInfo;
    0004: invoke-virtual {v1, v2, v3}, Landroid/support/v4/view/ViewPager$1;->compare(Landroid/support/v4/view/ViewPager$ItemInfo;Landroid/support/v4/view/ViewPager$ItemInfo;)I
    0007: move-result v0
    0008: return v0