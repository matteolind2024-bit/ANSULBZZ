=== CLASS Landroid/support/v4/app/FragmentStatePagerAdapter; (Source: FragmentStatePagerAdapter.java) ===
  Super: Landroid/support/v4/view/PagerAdapter;
  [Static Field] DEBUG: Z = False
  [Static Field] TAG: Ljava/lang/String; = 'FragmentStatePagerAdapter'
  [Instance Field] mCurTransaction: Landroid/support/v4/app/FragmentTransaction;
  [Instance Field] mCurrentPrimaryItem: Landroid/support/v4/app/Fragment;
  [Instance Field] mFragmentManager: Landroid/support/v4/app/FragmentManager;
  [Instance Field] mFragments: Ljava/util/ArrayList;
  [Instance Field] mSavedState: Ljava/util/ArrayList;

  [Direct Method] <init>(Landroid/support/v4/app/FragmentManager;) -> V
    // registers=4, ins=2, outs=1, insns_size=25
    0000: const/4 v1, 0
    0001: invoke-direct {v2}, Landroid/support/v4/view/PagerAdapter;-><init>()V
    0004: iput v1, v2.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0006: new-instance v0, Ljava/util/ArrayList;
    0008: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    000b: iput v0, v2.Landroid/support/v4/app/FragmentStatePagerAdapter;->mSavedState:Ljava/util/ArrayList;
    000d: new-instance v0, Ljava/util/ArrayList;
    000f: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0012: iput v0, v2.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    0014: iput v1, v2.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    0016: iput v3, v2.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    0018: return-void

  [Virtual Method] destroyItem(Landroid/view/ViewGroup;, I, Ljava/lang/Object;) -> V
    // registers=7, ins=4, outs=3, insns_size=51
    0000: const/4 v2, 0
    0001: check-cast v6, Landroid/support/v4/app/Fragment;
    0003: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0005: if-nez v0, 000f
    0007: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    0009: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManager;->beginTransaction()Landroid/support/v4/app/FragmentTransaction;
    000c: move-result-object v0
    000d: iput v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    000f: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mSavedState:Ljava/util/ArrayList;
    0011: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0014: move-result v0
    0015: if-gt v0, v5, 001d
    0017: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mSavedState:Ljava/util/ArrayList;
    0019: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    001c: goto 000f
    001d: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mSavedState:Ljava/util/ArrayList;
    001f: iget v1, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    0021: invoke-virtual {v1, v6}, Landroid/support/v4/app/FragmentManager;->saveFragmentInstanceState(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/Fragment$SavedState;
    0024: move-result-object v1
    0025: invoke-virtual {v0, v5, v1}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;
    0028: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    002a: invoke-virtual {v0, v5, v2}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;
    002d: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    002f: invoke-virtual {v0, v6}, Landroid/support/v4/app/FragmentTransaction;->remove(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/FragmentTransaction;
    0032: return-void

  [Virtual Method] finishUpdate(Landroid/view/ViewGroup;) -> V
    // registers=3, ins=2, outs=1, insns_size=18
    0000: iget v0, v1.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0002: if-eqz v0, 0011
    0004: iget v0, v1.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0006: invoke-virtual {v0}, Landroid/support/v4/app/FragmentTransaction;->commitAllowingStateLoss()I
    0009: const/4 v0, 0
    000a: iput v0, v1.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    000c: iget v0, v1.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    000e: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManager;->executePendingTransactions()Z
    0011: return-void

  [Virtual Method] getItem(I) -> Landroid/support/v4/app/Fragment;

  [Virtual Method] instantiateItem(Landroid/view/ViewGroup;, I) -> Ljava/lang/Object;
    // registers=6, ins=3, outs=3, insns_size=91
    0000: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    0002: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0005: move-result v0
    0006: if-le v0, v5, 0013
    0008: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    000a: invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    000d: move-result-object v0
    000e: check-cast v0, Landroid/support/v4/app/Fragment;
    0010: if-eqz v0, 0013
    0012: return-object v0
    0013: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0015: if-nez v0, 001f
    0017: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    0019: invoke-virtual {v0}, Landroid/support/v4/app/FragmentManager;->beginTransaction()Landroid/support/v4/app/FragmentTransaction;
    001c: move-result-object v0
    001d: iput v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    001f: invoke-virtual {v3, v5}, Landroid/support/v4/app/FragmentStatePagerAdapter;->getItem(I)Landroid/support/v4/app/Fragment;
    0022: move-result-object v1
    0023: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mSavedState:Ljava/util/ArrayList;
    0025: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0028: move-result v0
    0029: if-le v0, v5, 0038
    002b: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mSavedState:Ljava/util/ArrayList;
    002d: invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    0030: move-result-object v0
    0031: check-cast v0, Landroid/support/v4/app/Fragment$SavedState;
    0033: if-eqz v0, 0038
    0035: invoke-virtual {v1, v0}, Landroid/support/v4/app/Fragment;->setInitialSavedState(Landroid/support/v4/app/Fragment$SavedState;)V
    0038: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    003a: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    003d: move-result v0
    003e: if-gt v0, v5, 0047
    0040: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    0042: const/4 v2, 0
    0043: invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0046: goto 0038
    0047: const/4 v0, 0
    0048: invoke-virtual {v1, v0}, Landroid/support/v4/app/Fragment;->setMenuVisibility(Z)V
    004b: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    004d: invoke-virtual {v0, v5, v1}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;
    0050: iget v0, v3.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurTransaction:Landroid/support/v4/app/FragmentTransaction;
    0052: invoke-virtual {v4}, Landroid/view/ViewGroup;->getId()I
    0055: move-result v2
    0056: invoke-virtual {v0, v2, v1}, Landroid/support/v4/app/FragmentTransaction;->add(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/FragmentTransaction;
    0059: move(op=07) v0, v1
    005a: goto 0012

  [Virtual Method] isViewFromObject(Landroid/view/View;, Ljava/lang/Object;) -> Z
    // registers=4, ins=3, outs=1, insns_size=12
    0000: check-cast v3, Landroid/support/v4/app/Fragment;
    0002: invoke-virtual {v3}, Landroid/support/v4/app/Fragment;->getView()Landroid/view/View;
    0005: move-result-object v0
    0006: if-ne v0, v2, 000a
    0008: const/4 v0, 1
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] restoreState(Landroid/os/Parcelable;, Ljava/lang/ClassLoader;) -> V
    // registers=9, ins=3, outs=3, insns_size=138
    0000: const/4 v2, 0
    0001: if-eqz v7, 0089
    0003: check-cast v7, Landroid/os/Bundle;
    0005: invoke-virtual {v7, v8}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V
    0008: const-string v0, 'states'
    000a: invoke-virtual {v7, v0}, Landroid/os/Bundle;->getParcelableArray(Ljava/lang/String;)[Landroid/os/Parcelable;
    000d: move-result-object v3
    000e: iget v0, v6.Landroid/support/v4/app/FragmentStatePagerAdapter;->mSavedState:Ljava/util/ArrayList;
    0010: invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V
    0013: iget v0, v6.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    0015: invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V
    0018: if-eqz v3, 002b
    001a: move(op=01) v1, v2
    001b: move(op=21) v0, v3
    001c: if-ge v1, v0, 002b
    001e: iget v4, v6.Landroid/support/v4/app/FragmentStatePagerAdapter;->mSavedState:Ljava/util/ArrayList;
    0020: aget(op=46) v0, v3[v1]
    0022: check-cast v0, Landroid/support/v4/app/Fragment$SavedState;
    0024: invoke-virtual {v4, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0027: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0029: move(op=01) v1, v0
    002a: goto 001b
    002b: invoke-virtual {v7}, Landroid/os/Bundle;->keySet()Ljava/util/Set;
    002e: move-result-object v0
    002f: invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;
    0032: move-result-object v1
    0033: invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z
    0036: move-result v0
    0037: if-eqz v0, 0089
    0039: invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    003c: move-result-object v0
    003d: check-cast v0, Ljava/lang/String;
    003f: const-string v3, 'f'
    0041: invoke-virtual {v0, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z
    0044: move-result v3
    0045: if-eqz v3, 0033
    0047: const/4 v3, 1
    0048: invoke-virtual {v0, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;
    004b: move-result-object v3
    004c: invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    004f: move-result v3
    0050: iget v4, v6.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    0052: invoke-virtual {v4, v7, v0}, Landroid/support/v4/app/FragmentManager;->getFragment(Landroid/os/Bundle;Ljava/lang/String;)Landroid/support/v4/app/Fragment;
    0055: move-result-object v4
    0056: if-eqz v4, 0070
    0058: iget v0, v6.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    005a: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    005d: move-result v0
    005e: if-gt v0, v3, 0067
    0060: iget v0, v6.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    0062: const/4 v5, 0
    0063: invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    0066: goto 0058
    0067: invoke-virtual {v4, v2}, Landroid/support/v4/app/Fragment;->setMenuVisibility(Z)V
    006a: iget v0, v6.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    006c: invoke-virtual {v0, v3, v4}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;
    006f: goto 0033
    0070: const-string v3, 'FragmentStatePagerAdapter'
    0072: new-instance v4, Ljava/lang/StringBuilder;
    0074: invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V
    0077: const-string v5, 'Bad fragment at key '
    0079: invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    007c: move-result-object v4
    007d: invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0080: move-result-object v0
    0081: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0084: move-result-object v0
    0085: invoke-static {v3, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    0088: goto 0033
    0089: return-void

  [Virtual Method] saveState() -> Landroid/os/Parcelable;
    // registers=6, ins=1, outs=4, insns_size=88
    0000: const/4 v0, 0
    0001: iget v1, v5.Landroid/support/v4/app/FragmentStatePagerAdapter;->mSavedState:Ljava/util/ArrayList;
    0003: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0006: move-result v1
    0007: if-lez v1, 0020
    0009: new-instance v0, Landroid/os/Bundle;
    000b: invoke-direct {v0}, Landroid/os/Bundle;-><init>()V
    000e: iget v1, v5.Landroid/support/v4/app/FragmentStatePagerAdapter;->mSavedState:Ljava/util/ArrayList;
    0010: invoke-virtual {v1}, Ljava/util/ArrayList;->size()I
    0013: move-result v1
    0014: new-array v1, v1, [Landroid/support/v4/app/Fragment$SavedState;
    0016: iget v2, v5.Landroid/support/v4/app/FragmentStatePagerAdapter;->mSavedState:Ljava/util/ArrayList;
    0018: invoke-virtual {v2, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    001b: const-string v2, 'states'
    001d: invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V
    0020: const/4 v1, 0
    0021: move(op=07) v2, v0
    0022: iget v0, v5.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    0024: invoke-virtual {v0}, Ljava/util/ArrayList;->size()I
    0027: move-result v0
    0028: if-ge v1, v0, 0057
    002a: iget v0, v5.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragments:Ljava/util/ArrayList;
    002c: invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;
    002f: move-result-object v0
    0030: check-cast v0, Landroid/support/v4/app/Fragment;
    0032: if-eqz v0, 0053
    0034: if-nez v2, 003b
    0036: new-instance v2, Landroid/os/Bundle;
    0038: invoke-direct {v2}, Landroid/os/Bundle;-><init>()V
    003b: new-instance v3, Ljava/lang/StringBuilder;
    003d: invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V
    0040: const-string v4, 'f'
    0042: invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0045: move-result-object v3
    0046: invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0049: move-result-object v3
    004a: invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    004d: move-result-object v3
    004e: iget v4, v5.Landroid/support/v4/app/FragmentStatePagerAdapter;->mFragmentManager:Landroid/support/v4/app/FragmentManager;
    0050: invoke-virtual {v4, v2, v3, v0}, Landroid/support/v4/app/FragmentManager;->putFragment(Landroid/os/Bundle;Ljava/lang/String;Landroid/support/v4/app/Fragment;)V
    0053: binop/lit8(op=d8) v0, v1, 1 (0x1)
    0055: move(op=01) v1, v0
    0056: goto 0022
    0057: return-object v2

  [Virtual Method] setPrimaryItem(Landroid/view/ViewGroup;, I, Ljava/lang/Object;) -> V
    // registers=6, ins=4, outs=2, insns_size=25
    0000: check-cast v5, Landroid/support/v4/app/Fragment;
    0002: iget v0, v2.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    0004: if-eq v5, v0, 0018
    0006: iget v0, v2.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    0008: if-eqz v0, 0010
    000a: iget v0, v2.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    000c: const/4 v1, 0
    000d: invoke-virtual {v0, v1}, Landroid/support/v4/app/Fragment;->setMenuVisibility(Z)V
    0010: if-eqz v5, 0016
    0012: const/4 v0, 1
    0013: invoke-virtual {v5, v0}, Landroid/support/v4/app/Fragment;->setMenuVisibility(Z)V
    0016: iput v5, v2.Landroid/support/v4/app/FragmentStatePagerAdapter;->mCurrentPrimaryItem:Landroid/support/v4/app/Fragment;
    0018: return-void

  [Virtual Method] startUpdate(Landroid/view/ViewGroup;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void