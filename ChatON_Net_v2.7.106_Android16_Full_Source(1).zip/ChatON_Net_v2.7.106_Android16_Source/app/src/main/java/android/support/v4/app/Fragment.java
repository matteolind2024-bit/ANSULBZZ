=== CLASS Landroid/support/v4/app/Fragment; (Source: Fragment.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/content/ComponentCallbacks;, Landroid/view/View$OnCreateContextMenuListener;
  [Static Field] ACTIVITY_CREATED: I = 2
  [Static Field] CREATED: I = 1
  [Static Field] INITIALIZING: I = 0
  [Static Field] RESUMED: I = 5
  [Static Field] STARTED: I = 4
  [Static Field] STOPPED: I = 3
  [Static Field] sClassMap: Ljava/util/HashMap;
  [Instance Field] mActivity: Landroid/support/v4/app/FragmentActivity;
  [Instance Field] mAdded: Z
  [Instance Field] mAnimatingAway: Landroid/view/View;
  [Instance Field] mArguments: Landroid/os/Bundle;
  [Instance Field] mBackStackNesting: I
  [Instance Field] mCalled: Z
  [Instance Field] mCheckedForLoaderManager: Z
  [Instance Field] mContainer: Landroid/view/ViewGroup;
  [Instance Field] mContainerId: I
  [Instance Field] mDeferStart: Z
  [Instance Field] mDetached: Z
  [Instance Field] mFragmentId: I
  [Instance Field] mFragmentManager: Landroid/support/v4/app/FragmentManagerImpl;
  [Instance Field] mFromLayout: Z
  [Instance Field] mHasMenu: Z
  [Instance Field] mHidden: Z
  [Instance Field] mInLayout: Z
  [Instance Field] mIndex: I
  [Instance Field] mInnerView: Landroid/view/View;
  [Instance Field] mLoaderManager: Landroid/support/v4/app/LoaderManagerImpl;
  [Instance Field] mLoadersStarted: Z
  [Instance Field] mMenuVisible: Z
  [Instance Field] mNextAnim: I
  [Instance Field] mRemoving: Z
  [Instance Field] mRestored: Z
  [Instance Field] mResumed: Z
  [Instance Field] mRetainInstance: Z
  [Instance Field] mRetaining: Z
  [Instance Field] mSavedFragmentState: Landroid/os/Bundle;
  [Instance Field] mSavedViewState: Landroid/util/SparseArray;
  [Instance Field] mState: I
  [Instance Field] mStateAfterAnimating: I
  [Instance Field] mTag: Ljava/lang/String;
  [Instance Field] mTarget: Landroid/support/v4/app/Fragment;
  [Instance Field] mTargetIndex: I
  [Instance Field] mTargetRequestCode: I
  [Instance Field] mUserVisibleHint: Z
  [Instance Field] mView: Landroid/view/View;
  [Instance Field] mWho: Ljava/lang/String;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=8
    0000: new-instance v0, Ljava/util/HashMap;
    0002: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    0005: sput v0, Landroid/support/v4/app/Fragment;->sClassMap:Ljava/util/HashMap;
    0007: return-void

  [Direct Method] <init>() -> V
    // registers=4, ins=1, outs=1, insns_size=17
    0000: const/4 v2, 1
    0001: const/4 v1, -1
    0002: invoke-direct {v3}, Ljava/lang/Object;-><init>()V
    0005: const/4 v0, 0
    0006: iput v0, v3.Landroid/support/v4/app/Fragment;->mState:I
    0008: iput v1, v3.Landroid/support/v4/app/Fragment;->mIndex:I
    000a: iput v1, v3.Landroid/support/v4/app/Fragment;->mTargetIndex:I
    000c: iput v2, v3.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    000e: iput v2, v3.Landroid/support/v4/app/Fragment;->mUserVisibleHint:Z
    0010: return-void

  [Direct Method] instantiate(Landroid/content/Context;, Ljava/lang/String;) -> Landroid/support/v4/app/Fragment;
    // registers=3, ins=2, outs=3, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-static {v1, v2, v0}, Landroid/support/v4/app/Fragment;->instantiate(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)Landroid/support/v4/app/Fragment;
    0004: move-result-object v0
    0005: return-object v0

  [Direct Method] instantiate(Landroid/content/Context;, Ljava/lang/String;, Landroid/os/Bundle;) -> Landroid/support/v4/app/Fragment;
    // registers=7, ins=3, outs=3, insns_size=159
    0000: sget v0, Landroid/support/v4/app/Fragment;->sClassMap:Ljava/util/HashMap;
    0002: invoke-virtual {v0, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Ljava/lang/Class;
    0008: if-nez v0, 0017
    000a: invoke-virtual {v4}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;
    000d: move-result-object v0
    000e: invoke-virtual {v0, v5}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;
    0011: move-result-object v0
    0012: sget v1, Landroid/support/v4/app/Fragment;->sClassMap:Ljava/util/HashMap;
    0014: invoke-virtual {v1, v5, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    0017: invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;
    001a: move-result-object v0
    001b: check-cast v0, Landroid/support/v4/app/Fragment;
    001d: if-eqz v6, 002c
    001f: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    0022: move-result-object v1
    0023: invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;
    0026: move-result-object v1
    0027: invoke-virtual {v6, v1}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V
    002a: iput v6, v0.Landroid/support/v4/app/Fragment;->mArguments:Landroid/os/Bundle;
    002c: return-object v0
    002d: move-exception v0
    002e: new-instance v1, Landroid/support/v4/app/Fragment$InstantiationException;
    0030: new-instance v2, Ljava/lang/StringBuilder;
    0032: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0035: const-string v3, 'Unable to instantiate fragment '
    0037: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003a: move-result-object v2
    003b: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    003e: move-result-object v2
    003f: const-string v3, ': make sure class name exists, is public, and has an'
    0041: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0044: move-result-object v2
    0045: const-string v3, ' empty constructor that is public'
    0047: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    004a: move-result-object v2
    004b: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    004e: move-result-object v2
    004f: invoke-direct {v1, v2, v0}, Landroid/support/v4/app/Fragment$InstantiationException;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V
    0052: throw v1
    0053: move-exception v0
    0054: new-instance v1, Landroid/support/v4/app/Fragment$InstantiationException;
    0056: new-instance v2, Ljava/lang/StringBuilder;
    0058: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    005b: const-string v3, 'Unable to instantiate fragment '
    005d: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0060: move-result-object v2
    0061: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0064: move-result-object v2
    0065: const-string v3, ': make sure class name exists, is public, and has an'
    0067: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    006a: move-result-object v2
    006b: const-string v3, ' empty constructor that is public'
    006d: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0070: move-result-object v2
    0071: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0074: move-result-object v2
    0075: invoke-direct {v1, v2, v0}, Landroid/support/v4/app/Fragment$InstantiationException;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V
    0078: throw v1
    0079: move-exception v0
    007a: new-instance v1, Landroid/support/v4/app/Fragment$InstantiationException;
    007c: new-instance v2, Ljava/lang/StringBuilder;
    007e: invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    0081: const-string v3, 'Unable to instantiate fragment '
    0083: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0086: move-result-object v2
    0087: invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    008a: move-result-object v2
    008b: const-string v3, ': make sure class name exists, is public, and has an'
    008d: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0090: move-result-object v2
    0091: const-string v3, ' empty constructor that is public'
    0093: invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0096: move-result-object v2
    0097: invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    009a: move-result-object v2
    009b: invoke-direct {v1, v2, v0}, Landroid/support/v4/app/Fragment$InstantiationException;-><init>(Ljava/lang/String;Ljava/lang/Exception;)V
    009e: throw v1

  [Virtual Method] dump(Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V
    // registers=8, ins=5, outs=5, insns_size=460
    0000: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0003: const-string v0, 'mFragmentId=#'
    0005: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0008: iget v0, v3.Landroid/support/v4/app/Fragment;->mFragmentId:I
    000a: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    000d: move-result-object v0
    000e: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0011: const-string v0, ' mContainerId=#'
    0013: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0016: iget v0, v3.Landroid/support/v4/app/Fragment;->mContainerId:I
    0018: invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    001b: move-result-object v0
    001c: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    001f: const-string v0, ' mTag='
    0021: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0024: iget v0, v3.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    0026: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    0029: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    002c: const-string v0, 'mState='
    002e: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0031: iget v0, v3.Landroid/support/v4/app/Fragment;->mState:I
    0033: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(I)V
    0036: const-string v0, ' mIndex='
    0038: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    003b: iget v0, v3.Landroid/support/v4/app/Fragment;->mIndex:I
    003d: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(I)V
    0040: const-string v0, ' mWho='
    0042: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0045: iget v0, v3.Landroid/support/v4/app/Fragment;->mWho:Ljava/lang/String;
    0047: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    004a: const-string v0, ' mBackStackNesting='
    004c: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    004f: iget v0, v3.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    0051: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(I)V
    0054: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0057: const-string v0, 'mAdded='
    0059: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    005c: iget v0, v3.Landroid/support/v4/app/Fragment;->mAdded:Z
    005e: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    0061: const-string v0, ' mRemoving='
    0063: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0066: iget v0, v3.Landroid/support/v4/app/Fragment;->mRemoving:Z
    0068: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    006b: const-string v0, ' mResumed='
    006d: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0070: iget v0, v3.Landroid/support/v4/app/Fragment;->mResumed:Z
    0072: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    0075: const-string v0, ' mFromLayout='
    0077: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    007a: iget v0, v3.Landroid/support/v4/app/Fragment;->mFromLayout:Z
    007c: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    007f: const-string v0, ' mInLayout='
    0081: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0084: iget v0, v3.Landroid/support/v4/app/Fragment;->mInLayout:Z
    0086: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Z)V
    0089: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    008c: const-string v0, 'mHidden='
    008e: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0091: iget v0, v3.Landroid/support/v4/app/Fragment;->mHidden:Z
    0093: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    0096: const-string v0, ' mDetached='
    0098: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    009b: iget v0, v3.Landroid/support/v4/app/Fragment;->mDetached:Z
    009d: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    00a0: const-string v0, ' mMenuVisible='
    00a2: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00a5: iget v0, v3.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    00a7: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    00aa: const-string v0, ' mHasMenu='
    00ac: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00af: iget v0, v3.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    00b1: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Z)V
    00b4: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00b7: const-string v0, 'mRetainInstance='
    00b9: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00bc: iget v0, v3.Landroid/support/v4/app/Fragment;->mRetainInstance:Z
    00be: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    00c1: const-string v0, ' mRetaining='
    00c3: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00c6: iget v0, v3.Landroid/support/v4/app/Fragment;->mRetaining:Z
    00c8: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Z)V
    00cb: const-string v0, ' mUserVisibleHint='
    00cd: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00d0: iget v0, v3.Landroid/support/v4/app/Fragment;->mUserVisibleHint:Z
    00d2: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Z)V
    00d5: iget v0, v3.Landroid/support/v4/app/Fragment;->mFragmentManager:Landroid/support/v4/app/FragmentManagerImpl;
    00d7: if-eqz v0, 00e6
    00d9: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00dc: const-string v0, 'mFragmentManager='
    00de: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00e1: iget v0, v3.Landroid/support/v4/app/Fragment;->mFragmentManager:Landroid/support/v4/app/FragmentManagerImpl;
    00e3: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    00e6: iget v0, v3.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    00e8: if-eqz v0, 00f7
    00ea: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00ed: const-string v0, 'mActivity='
    00ef: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00f2: iget v0, v3.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    00f4: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    00f7: iget v0, v3.Landroid/support/v4/app/Fragment;->mArguments:Landroid/os/Bundle;
    00f9: if-eqz v0, 0108
    00fb: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    00fe: const-string v0, 'mArguments='
    0100: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0103: iget v0, v3.Landroid/support/v4/app/Fragment;->mArguments:Landroid/os/Bundle;
    0105: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0108: iget v0, v3.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    010a: if-eqz v0, 0119
    010c: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    010f: const-string v0, 'mSavedFragmentState='
    0111: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0114: iget v0, v3.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    0116: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0119: iget v0, v3.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    011b: if-eqz v0, 012a
    011d: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0120: const-string v0, 'mSavedViewState='
    0122: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0125: iget v0, v3.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    0127: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    012a: iget v0, v3.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    012c: if-eqz v0, 0145
    012e: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0131: const-string v0, 'mTarget='
    0133: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0136: iget v0, v3.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    0138: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/Object;)V
    013b: const-string v0, ' mTargetRequestCode='
    013d: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0140: iget v0, v3.Landroid/support/v4/app/Fragment;->mTargetRequestCode:I
    0142: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(I)V
    0145: iget v0, v3.Landroid/support/v4/app/Fragment;->mNextAnim:I
    0147: if-eqz v0, 0156
    0149: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    014c: const-string v0, 'mNextAnim='
    014e: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0151: iget v0, v3.Landroid/support/v4/app/Fragment;->mNextAnim:I
    0153: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(I)V
    0156: iget v0, v3.Landroid/support/v4/app/Fragment;->mContainer:Landroid/view/ViewGroup;
    0158: if-eqz v0, 0167
    015a: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    015d: const-string v0, 'mContainer='
    015f: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0162: iget v0, v3.Landroid/support/v4/app/Fragment;->mContainer:Landroid/view/ViewGroup;
    0164: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0167: iget v0, v3.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0169: if-eqz v0, 0178
    016b: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    016e: const-string v0, 'mView='
    0170: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0173: iget v0, v3.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0175: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0178: iget v0, v3.Landroid/support/v4/app/Fragment;->mInnerView:Landroid/view/View;
    017a: if-eqz v0, 0189
    017c: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    017f: const-string v0, 'mInnerView='
    0181: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0184: iget v0, v3.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0186: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    0189: iget v0, v3.Landroid/support/v4/app/Fragment;->mAnimatingAway:Landroid/view/View;
    018b: if-eqz v0, 01a7
    018d: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0190: const-string v0, 'mAnimatingAway='
    0192: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    0195: iget v0, v3.Landroid/support/v4/app/Fragment;->mAnimatingAway:Landroid/view/View;
    0197: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V
    019a: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    019d: const-string v0, 'mStateAfterAnimating='
    019f: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01a2: iget v0, v3.Landroid/support/v4/app/Fragment;->mStateAfterAnimating:I
    01a4: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(I)V
    01a7: iget v0, v3.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    01a9: if-eqz v0, 01cb
    01ab: invoke-virtual {v6, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V
    01ae: const-string v0, 'Loader Manager:'
    01b0: invoke-virtual {v6, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V
    01b3: iget v0, v3.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    01b5: new-instance v1, Ljava/lang/StringBuilder;
    01b7: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    01ba: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01bd: move-result-object v1
    01be: const-string v2, '  '
    01c0: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    01c3: move-result-object v1
    01c4: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    01c7: move-result-object v1
    01c8: invoke-virtual {v0, v1, v5, v6, v7}, Landroid/support/v4/app/LoaderManagerImpl;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    01cb: return-void

  [Virtual Method] equals(Ljava/lang/Object;) -> Z
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-super {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z
    0003: move-result v0
    0004: return v0

  [Virtual Method] getActivity() -> Landroid/support/v4/app/FragmentActivity;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0002: return-object v0

  [Virtual Method] getArguments() -> Landroid/os/Bundle;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mArguments:Landroid/os/Bundle;
    0002: return-object v0

  [Virtual Method] getFragmentManager() -> Landroid/support/v4/app/FragmentManager;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mFragmentManager:Landroid/support/v4/app/FragmentManagerImpl;
    0002: return-object v0

  [Virtual Method] getId() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mFragmentId:I
    0002: return v0

  [Virtual Method] getLayoutInflater(Landroid/os/Bundle;) -> Landroid/view/LayoutInflater;
    // registers=3, ins=2, outs=1, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0002: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getLayoutInflater()Landroid/view/LayoutInflater;
    0005: move-result-object v0
    0006: return-object v0

  [Virtual Method] getLoaderManager() -> Landroid/support/v4/app/LoaderManager;
    // registers=5, ins=1, outs=4, insns_size=60
    0000: const/4 v3, 1
    0001: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0003: if-eqz v0, 0008
    0005: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0007: return-object v0
    0008: iget v0, v4.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    000a: if-nez v0, 002b
    000c: new-instance v0, Ljava/lang/IllegalStateException;
    000e: new-instance v1, Ljava/lang/StringBuilder;
    0010: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0013: const-string v2, 'Fragment '
    0015: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0018: move-result-object v1
    0019: invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    001c: move-result-object v1
    001d: const-string v2, ' not attached to Activity'
    001f: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0022: move-result-object v1
    0023: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0026: move-result-object v1
    0027: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    002a: throw v0
    002b: iput v3, v4.Landroid/support/v4/app/Fragment;->mCheckedForLoaderManager:Z
    002d: iget v0, v4.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    002f: iget v1, v4.Landroid/support/v4/app/Fragment;->mIndex:I
    0031: iget v2, v4.Landroid/support/v4/app/Fragment;->mLoadersStarted:Z
    0033: invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/app/FragmentActivity;->getLoaderManager(IZZ)Landroid/support/v4/app/LoaderManagerImpl;
    0036: move-result-object v0
    0037: iput v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0039: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    003b: goto 0007

  [Virtual Method] getResources() -> Landroid/content/res/Resources;
    // registers=4, ins=1, outs=2, insns_size=42
    0000: iget v0, v3.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0002: if-nez v0, 0023
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: new-instance v1, Ljava/lang/StringBuilder;
    0008: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v2, 'Fragment '
    000d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v1
    0011: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: const-string v2, ' not attached to Activity'
    0017: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001a: move-result-object v1
    001b: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001e: move-result-object v1
    001f: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0022: throw v0
    0023: iget v0, v3.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0025: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->getResources()Landroid/content/res/Resources;
    0028: move-result-object v0
    0029: return-object v0

  [Virtual Method] getRetainInstance() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mRetainInstance:Z
    0002: return v0

  [Virtual Method] getString(I) -> Ljava/lang/String;
    // registers=3, ins=2, outs=2, insns_size=9
    0000: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->getResources()Landroid/content/res/Resources;
    0003: move-result-object v0
    0004: invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] getString(I, [Ljava/lang/Object;) -> Ljava/lang/String;
    // registers=4, ins=3, outs=3, insns_size=9
    0000: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->getResources()Landroid/content/res/Resources;
    0003: move-result-object v0
    0004: invoke-virtual {v0, v2, v3}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] getTag() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    0002: return-object v0

  [Virtual Method] getTargetFragment() -> Landroid/support/v4/app/Fragment;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    0002: return-object v0

  [Virtual Method] getTargetRequestCode() -> I
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mTargetRequestCode:I
    0002: return v0

  [Virtual Method] getText(I) -> Ljava/lang/CharSequence;
    // registers=3, ins=2, outs=2, insns_size=9
    0000: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->getResources()Landroid/content/res/Resources;
    0003: move-result-object v0
    0004: invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;
    0007: move-result-object v0
    0008: return-object v0

  [Virtual Method] getUserVisibleHint() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mUserVisibleHint:Z
    0002: return v0

  [Virtual Method] getView() -> Landroid/view/View;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0002: return-object v0

  [Virtual Method] hashCode() -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-super {v1}, Ljava/lang/Object;->hashCode()I
    0003: move-result v0
    0004: return v0

  [Virtual Method] initState() -> V
    // registers=4, ins=1, outs=0, insns_size=44
    0000: const/4 v2, 0
    0001: const/4 v1, 0
    0002: const/4 v0, -1
    0003: iput v0, v3.Landroid/support/v4/app/Fragment;->mIndex:I
    0005: iput v2, v3.Landroid/support/v4/app/Fragment;->mWho:Ljava/lang/String;
    0007: iput v1, v3.Landroid/support/v4/app/Fragment;->mAdded:Z
    0009: iput v1, v3.Landroid/support/v4/app/Fragment;->mRemoving:Z
    000b: iput v1, v3.Landroid/support/v4/app/Fragment;->mResumed:Z
    000d: iput v1, v3.Landroid/support/v4/app/Fragment;->mFromLayout:Z
    000f: iput v1, v3.Landroid/support/v4/app/Fragment;->mInLayout:Z
    0011: iput v1, v3.Landroid/support/v4/app/Fragment;->mRestored:Z
    0013: iput v1, v3.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    0015: iput v2, v3.Landroid/support/v4/app/Fragment;->mFragmentManager:Landroid/support/v4/app/FragmentManagerImpl;
    0017: iput v2, v3.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0019: iput v1, v3.Landroid/support/v4/app/Fragment;->mFragmentId:I
    001b: iput v1, v3.Landroid/support/v4/app/Fragment;->mContainerId:I
    001d: iput v2, v3.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    001f: iput v1, v3.Landroid/support/v4/app/Fragment;->mHidden:Z
    0021: iput v1, v3.Landroid/support/v4/app/Fragment;->mDetached:Z
    0023: iput v1, v3.Landroid/support/v4/app/Fragment;->mRetaining:Z
    0025: iput v2, v3.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0027: iput v1, v3.Landroid/support/v4/app/Fragment;->mLoadersStarted:Z
    0029: iput v1, v3.Landroid/support/v4/app/Fragment;->mCheckedForLoaderManager:Z
    002b: return-void

  [Virtual Method] isAdded() -> Z
    // registers=2, ins=1, outs=0, insns_size=12
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0002: if-eqz v0, 000a
    0004: iget v0, v1.Landroid/support/v4/app/Fragment;->mAdded:Z
    0006: if-eqz v0, 000a
    0008: const/4 v0, 1
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Virtual Method] isDetached() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mDetached:Z
    0002: return v0

  [Virtual Method] isHidden() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mHidden:Z
    0002: return v0

  [Virtual Method] isInBackStack() -> Z
    // registers=2, ins=1, outs=0, insns_size=8
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mBackStackNesting:I
    0002: if-lez v0, 0006
    0004: const/4 v0, 1
    0005: return v0
    0006: const/4 v0, 0
    0007: goto 0005

  [Virtual Method] isInLayout() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mInLayout:Z
    0002: return v0

  [Virtual Method] isRemoving() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mRemoving:Z
    0002: return v0

  [Virtual Method] isResumed() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mResumed:Z
    0002: return v0

  [Virtual Method] isVisible() -> Z
    // registers=2, ins=1, outs=1, insns_size=36
    0000: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->isAdded()Z
    0003: move-result v0
    0004: if-eqz v0, 0022
    0006: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->isHidden()Z
    0009: move-result v0
    000a: if-nez v0, 0022
    000c: iget v0, v1.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    000e: if-eqz v0, 0022
    0010: iget v0, v1.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    0012: invoke-virtual {v0}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;
    0015: move-result-object v0
    0016: if-eqz v0, 0022
    0018: iget v0, v1.Landroid/support/v4/app/Fragment;->mView:Landroid/view/View;
    001a: invoke-virtual {v0}, Landroid/view/View;->getVisibility()I
    001d: move-result v0
    001e: if-nez v0, 0022
    0020: const/4 v0, 1
    0021: return v0
    0022: const/4 v0, 0
    0023: goto 0021

  [Virtual Method] onActivityCreated(Landroid/os/Bundle;) -> V
    // registers=3, ins=2, outs=0, insns_size=4
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: return-void

  [Virtual Method] onActivityResult(I, I, Landroid/content/Intent;) -> V
    // registers=4, ins=4, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onAttach(Landroid/app/Activity;) -> V
    // registers=3, ins=2, outs=0, insns_size=4
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: return-void

  [Virtual Method] onConfigurationChanged(Landroid/content/res/Configuration;) -> V
    // registers=3, ins=2, outs=0, insns_size=4
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: return-void

  [Virtual Method] onContextItemSelected(Landroid/view/MenuItem;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] onCreate(Landroid/os/Bundle;) -> V
    // registers=3, ins=2, outs=0, insns_size=4
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: return-void

  [Virtual Method] onCreateAnimation(I, Z, I) -> Landroid/view/animation/Animation;
    // registers=5, ins=4, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] onCreateContextMenu(Landroid/view/ContextMenu;, Landroid/view/View;, Landroid/view/ContextMenu$ContextMenuInfo;) -> V
    // registers=5, ins=4, outs=4, insns_size=8
    0000: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0003: move-result-object v0
    0004: invoke-virtual {v0, v2, v3, v4}, Landroid/support/v4/app/FragmentActivity;->onCreateContextMenu(Landroid/view/ContextMenu;Landroid/view/View;Landroid/view/ContextMenu$ContextMenuInfo;)V
    0007: return-void

  [Virtual Method] onCreateOptionsMenu(Landroid/view/Menu;, Landroid/view/MenuInflater;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onCreateView(Landroid/view/LayoutInflater;, Landroid/view/ViewGroup;, Landroid/os/Bundle;) -> Landroid/view/View;
    // registers=5, ins=4, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] onDestroy() -> V
    // registers=5, ins=1, outs=4, insns_size=32
    0000: const/4 v1, 1
    0001: iput v1, v4.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: iget v0, v4.Landroid/support/v4/app/Fragment;->mCheckedForLoaderManager:Z
    0005: if-nez v0, 0016
    0007: iput v1, v4.Landroid/support/v4/app/Fragment;->mCheckedForLoaderManager:Z
    0009: iget v0, v4.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    000b: iget v1, v4.Landroid/support/v4/app/Fragment;->mIndex:I
    000d: iget v2, v4.Landroid/support/v4/app/Fragment;->mLoadersStarted:Z
    000f: const/4 v3, 0
    0010: invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/app/FragmentActivity;->getLoaderManager(IZZ)Landroid/support/v4/app/LoaderManagerImpl;
    0013: move-result-object v0
    0014: iput v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0016: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0018: if-eqz v0, 001f
    001a: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    001c: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doDestroy()V
    001f: return-void

  [Virtual Method] onDestroyOptionsMenu() -> V
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onDestroyView() -> V
    // registers=2, ins=1, outs=0, insns_size=4
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: return-void

  [Virtual Method] onDetach() -> V
    // registers=2, ins=1, outs=0, insns_size=4
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: return-void

  [Virtual Method] onHiddenChanged(Z) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onInflate(Landroid/app/Activity;, Landroid/util/AttributeSet;, Landroid/os/Bundle;) -> V
    // registers=5, ins=4, outs=0, insns_size=4
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: return-void

  [Virtual Method] onLowMemory() -> V
    // registers=2, ins=1, outs=0, insns_size=4
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: return-void

  [Virtual Method] onOptionsItemSelected(Landroid/view/MenuItem;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] onOptionsMenuClosed(Landroid/view/Menu;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onPause() -> V
    // registers=2, ins=1, outs=0, insns_size=4
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: return-void

  [Virtual Method] onPrepareOptionsMenu(Landroid/view/Menu;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onResume() -> V
    // registers=2, ins=1, outs=0, insns_size=4
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: return-void

  [Virtual Method] onSaveInstanceState(Landroid/os/Bundle;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onStart() -> V
    // registers=5, ins=1, outs=4, insns_size=38
    0000: const/4 v1, 1
    0001: iput v1, v4.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoadersStarted:Z
    0005: if-nez v0, 0025
    0007: iput v1, v4.Landroid/support/v4/app/Fragment;->mLoadersStarted:Z
    0009: iget v0, v4.Landroid/support/v4/app/Fragment;->mCheckedForLoaderManager:Z
    000b: if-nez v0, 001c
    000d: iput v1, v4.Landroid/support/v4/app/Fragment;->mCheckedForLoaderManager:Z
    000f: iget v0, v4.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0011: iget v1, v4.Landroid/support/v4/app/Fragment;->mIndex:I
    0013: iget v2, v4.Landroid/support/v4/app/Fragment;->mLoadersStarted:Z
    0015: const/4 v3, 0
    0016: invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/app/FragmentActivity;->getLoaderManager(IZZ)Landroid/support/v4/app/LoaderManagerImpl;
    0019: move-result-object v0
    001a: iput v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    001c: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    001e: if-eqz v0, 0025
    0020: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0022: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doStart()V
    0025: return-void

  [Virtual Method] onStop() -> V
    // registers=2, ins=1, outs=0, insns_size=4
    0000: const/4 v0, 1
    0001: iput v0, v1.Landroid/support/v4/app/Fragment;->mCalled:Z
    0003: return-void

  [Virtual Method] onViewCreated(Landroid/view/View;, Landroid/os/Bundle;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] performDestroyView() -> V
    // registers=2, ins=1, outs=1, insns_size=13
    0000: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->onDestroyView()V
    0003: iget v0, v1.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0005: if-eqz v0, 000c
    0007: iget v0, v1.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0009: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doReportNextStart()V
    000c: return-void

  [Virtual Method] performReallyStop() -> V
    // registers=5, ins=1, outs=4, insns_size=48
    0000: const/4 v3, 0
    0001: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoadersStarted:Z
    0003: if-eqz v0, 0029
    0005: iput v3, v4.Landroid/support/v4/app/Fragment;->mLoadersStarted:Z
    0007: iget v0, v4.Landroid/support/v4/app/Fragment;->mCheckedForLoaderManager:Z
    0009: if-nez v0, 001a
    000b: const/4 v0, 1
    000c: iput v0, v4.Landroid/support/v4/app/Fragment;->mCheckedForLoaderManager:Z
    000e: iget v0, v4.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0010: iget v1, v4.Landroid/support/v4/app/Fragment;->mIndex:I
    0012: iget v2, v4.Landroid/support/v4/app/Fragment;->mLoadersStarted:Z
    0014: invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/app/FragmentActivity;->getLoaderManager(IZZ)Landroid/support/v4/app/LoaderManagerImpl;
    0017: move-result-object v0
    0018: iput v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    001a: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    001c: if-eqz v0, 0029
    001e: iget v0, v4.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0020: iget v0, v0.Landroid/support/v4/app/FragmentActivity;->mRetaining:Z
    0022: if-nez v0, 002a
    0024: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0026: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doStop()V
    0029: return-void
    002a: iget v0, v4.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    002c: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doRetain()V
    002f: goto 0029

  [Virtual Method] performStart() -> V
    // registers=2, ins=1, outs=1, insns_size=13
    0000: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->onStart()V
    0003: iget v0, v1.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0005: if-eqz v0, 000c
    0007: iget v0, v1.Landroid/support/v4/app/Fragment;->mLoaderManager:Landroid/support/v4/app/LoaderManagerImpl;
    0009: invoke-virtual {v0}, Landroid/support/v4/app/LoaderManagerImpl;->doReportStart()V
    000c: return-void

  [Virtual Method] performStop() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-virtual {v0}, Landroid/support/v4/app/Fragment;->onStop()V
    0003: return-void

  [Virtual Method] registerForContextMenu(Landroid/view/View;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v1, v0}, Landroid/view/View;->setOnCreateContextMenuListener(Landroid/view/View$OnCreateContextMenuListener;)V
    0003: return-void

  [Virtual Method] restoreViewState() -> V
    // registers=3, ins=1, outs=2, insns_size=15
    0000: iget v0, v2.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    0002: if-eqz v0, 000e
    0004: iget v0, v2.Landroid/support/v4/app/Fragment;->mInnerView:Landroid/view/View;
    0006: iget v1, v2.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    0008: invoke-virtual {v0, v1}, Landroid/view/View;->restoreHierarchyState(Landroid/util/SparseArray;)V
    000b: const/4 v0, 0
    000c: iput v0, v2.Landroid/support/v4/app/Fragment;->mSavedViewState:Landroid/util/SparseArray;
    000e: return-void

  [Virtual Method] setArguments(Landroid/os/Bundle;) -> V
    // registers=4, ins=2, outs=2, insns_size=15
    0000: iget v0, v2.Landroid/support/v4/app/Fragment;->mIndex:I
    0002: if-ltz v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'Fragment already active'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: iput v3, v2.Landroid/support/v4/app/Fragment;->mArguments:Landroid/os/Bundle;
    000e: return-void

  [Virtual Method] setHasOptionsMenu(Z) -> V
    // registers=3, ins=2, outs=1, insns_size=24
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    0002: if-eq v0, v2, 0017
    0004: iput v2, v1.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    0006: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->isAdded()Z
    0009: move-result v0
    000a: if-eqz v0, 0017
    000c: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->isHidden()Z
    000f: move-result v0
    0010: if-nez v0, 0017
    0012: iget v0, v1.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0014: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->supportInvalidateOptionsMenu()V
    0017: return-void

  [Virtual Method] setIndex(I) -> V
    // registers=4, ins=2, outs=2, insns_size=26
    0000: iput v3, v2.Landroid/support/v4/app/Fragment;->mIndex:I
    0002: new-instance v0, Ljava/lang/StringBuilder;
    0004: invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    0007: const-string v1, 'android:fragment:'
    0009: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000c: move-result-object v0
    000d: iget v1, v2.Landroid/support/v4/app/Fragment;->mIndex:I
    000f: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0012: move-result-object v0
    0013: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0016: move-result-object v0
    0017: iput v0, v2.Landroid/support/v4/app/Fragment;->mWho:Ljava/lang/String;
    0019: return-void

  [Virtual Method] setInitialSavedState(Landroid/support/v4/app/Fragment$SavedState;) -> V
    // registers=4, ins=2, outs=2, insns_size=25
    0000: iget v0, v2.Landroid/support/v4/app/Fragment;->mIndex:I
    0002: if-ltz v0, 000c
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: const-string v1, 'Fragment already active'
    0008: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000b: throw v0
    000c: if-eqz v3, 0017
    000e: iget v0, v3.Landroid/support/v4/app/Fragment$SavedState;->mState:Landroid/os/Bundle;
    0010: if-eqz v0, 0017
    0012: iget v0, v3.Landroid/support/v4/app/Fragment$SavedState;->mState:Landroid/os/Bundle;
    0014: iput v0, v2.Landroid/support/v4/app/Fragment;->mSavedFragmentState:Landroid/os/Bundle;
    0016: return-void
    0017: const/4 v0, 0
    0018: goto 0014

  [Virtual Method] setMenuVisibility(Z) -> V
    // registers=3, ins=2, outs=1, insns_size=28
    0000: iget v0, v1.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    0002: if-eq v0, v2, 001b
    0004: iput v2, v1.Landroid/support/v4/app/Fragment;->mMenuVisible:Z
    0006: iget v0, v1.Landroid/support/v4/app/Fragment;->mHasMenu:Z
    0008: if-eqz v0, 001b
    000a: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->isAdded()Z
    000d: move-result v0
    000e: if-eqz v0, 001b
    0010: invoke-virtual {v1}, Landroid/support/v4/app/Fragment;->isHidden()Z
    0013: move-result v0
    0014: if-nez v0, 001b
    0016: iget v0, v1.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0018: invoke-virtual {v0}, Landroid/support/v4/app/FragmentActivity;->supportInvalidateOptionsMenu()V
    001b: return-void

  [Virtual Method] setRetainInstance(Z) -> V
    // registers=2, ins=2, outs=0, insns_size=3
    0000: iput v1, v0.Landroid/support/v4/app/Fragment;->mRetainInstance:Z
    0002: return-void

  [Virtual Method] setTargetFragment(Landroid/support/v4/app/Fragment;, I) -> V
    // registers=3, ins=3, outs=0, insns_size=5
    0000: iput v1, v0.Landroid/support/v4/app/Fragment;->mTarget:Landroid/support/v4/app/Fragment;
    0002: iput v2, v0.Landroid/support/v4/app/Fragment;->mTargetRequestCode:I
    0004: return-void

  [Virtual Method] setUserVisibleHint(Z) -> V
    // registers=4, ins=2, outs=2, insns_size=26
    0000: iget v0, v2.Landroid/support/v4/app/Fragment;->mUserVisibleHint:Z
    0002: if-nez v0, 0010
    0004: if-eqz v3, 0010
    0006: iget v0, v2.Landroid/support/v4/app/Fragment;->mState:I
    0008: const/4 v1, 4
    0009: if-ge v0, v1, 0010
    000b: iget v0, v2.Landroid/support/v4/app/Fragment;->mFragmentManager:Landroid/support/v4/app/FragmentManagerImpl;
    000d: invoke-virtual {v0, v2}, Landroid/support/v4/app/FragmentManagerImpl;->performPendingDeferredStart(Landroid/support/v4/app/Fragment;)V
    0010: iput v3, v2.Landroid/support/v4/app/Fragment;->mUserVisibleHint:Z
    0012: if-nez v3, 0018
    0014: const/4 v0, 1
    0015: iput v0, v2.Landroid/support/v4/app/Fragment;->mDeferStart:Z
    0017: return-void
    0018: const/4 v0, 0
    0019: goto 0015

  [Virtual Method] startActivity(Landroid/content/Intent;) -> V
    // registers=5, ins=2, outs=4, insns_size=42
    0000: iget v0, v3.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0002: if-nez v0, 0023
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: new-instance v1, Ljava/lang/StringBuilder;
    0008: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v2, 'Fragment '
    000d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v1
    0011: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: const-string v2, ' not attached to Activity'
    0017: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001a: move-result-object v1
    001b: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001e: move-result-object v1
    001f: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0022: throw v0
    0023: iget v0, v3.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0025: const/4 v1, -1
    0026: invoke-virtual {v0, v3, v4, v1}, Landroid/support/v4/app/FragmentActivity;->startActivityFromFragment(Landroid/support/v4/app/Fragment;Landroid/content/Intent;I)V
    0029: return-void

  [Virtual Method] startActivityForResult(Landroid/content/Intent;, I) -> V
    // registers=6, ins=3, outs=4, insns_size=41
    0000: iget v0, v3.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0002: if-nez v0, 0023
    0004: new-instance v0, Ljava/lang/IllegalStateException;
    0006: new-instance v1, Ljava/lang/StringBuilder;
    0008: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    000b: const-string v2, 'Fragment '
    000d: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0010: move-result-object v1
    0011: invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    0014: move-result-object v1
    0015: const-string v2, ' not attached to Activity'
    0017: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    001a: move-result-object v1
    001b: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001e: move-result-object v1
    001f: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0022: throw v0
    0023: iget v0, v3.Landroid/support/v4/app/Fragment;->mActivity:Landroid/support/v4/app/FragmentActivity;
    0025: invoke-virtual {v0, v3, v4, v5}, Landroid/support/v4/app/FragmentActivity;->startActivityFromFragment(Landroid/support/v4/app/Fragment;Landroid/content/Intent;I)V
    0028: return-void

  [Virtual Method] toString() -> Ljava/lang/String;
    // registers=3, ins=1, outs=2, insns_size=66
    0000: new-instance v0, Ljava/lang/StringBuilder;
    0002: const/16 v1, 128 (0x80)
    0004: invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V
    0007: invoke-static {v2, v0}, Landroid/support/v4/util/DebugUtils;->buildShortClassTag(Ljava/lang/Object;Ljava/lang/StringBuilder;)V
    000a: iget v1, v2.Landroid/support/v4/app/Fragment;->mIndex:I
    000c: if-ltz v1, 0018
    000e: const-string v1, ' #'
    0010: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0013: iget v1, v2.Landroid/support/v4/app/Fragment;->mIndex:I
    0015: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0018: iget v1, v2.Landroid/support/v4/app/Fragment;->mFragmentId:I
    001a: if-eqz v1, 002a
    001c: const-string v1, ' id=0x'
    001e: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0021: iget v1, v2.Landroid/support/v4/app/Fragment;->mFragmentId:I
    0023: invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;
    0026: move-result-object v1
    0027: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    002a: iget v1, v2.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    002c: if-eqz v1, 0038
    002e: const-string v1, ' '
    0030: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0033: iget v1, v2.Landroid/support/v4/app/Fragment;->mTag:Ljava/lang/String;
    0035: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    0038: const/16 v1, 125 (0x7d)
    003a: invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;
    003d: invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    0040: move-result-object v0
    0041: return-object v0

  [Virtual Method] unregisterForContextMenu(Landroid/view/View;) -> V
    // registers=3, ins=2, outs=2, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-virtual {v2, v0}, Landroid/view/View;->setOnCreateContextMenuListener(Landroid/view/View$OnCreateContextMenuListener;)V
    0004: return-void