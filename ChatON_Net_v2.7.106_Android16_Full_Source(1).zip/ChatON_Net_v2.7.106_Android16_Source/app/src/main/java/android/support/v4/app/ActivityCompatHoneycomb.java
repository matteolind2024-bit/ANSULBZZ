=== CLASS Landroid/support/v4/app/ActivityCompatHoneycomb; (Source: ActivityCompatHoneycomb.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] dump(Landroid/app/Activity;, Ljava/lang/String;, Ljava/io/FileDescriptor;, Ljava/io/PrintWriter;, [Ljava/lang/String;) -> V
    // registers=5, ins=5, outs=5, insns_size=4
    0000: invoke-virtual {v0, v1, v2, v3, v4}, Landroid/app/Activity;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    0003: return-void

  [Direct Method] invalidateOptionsMenu(Landroid/app/Activity;) -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-virtual {v0}, Landroid/app/Activity;->invalidateOptionsMenu()V
    0003: return-void