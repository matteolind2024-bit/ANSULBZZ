=== CLASS Landroid/support/v4/app/BackStackRecord$Op; (Source: BackStackRecord.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] cmd: I
  [Instance Field] enterAnim: I
  [Instance Field] exitAnim: I
  [Instance Field] fragment: Landroid/support/v4/app/Fragment;
  [Instance Field] next: Landroid/support/v4/app/BackStackRecord$Op;
  [Instance Field] popEnterAnim: I
  [Instance Field] popExitAnim: I
  [Instance Field] prev: Landroid/support/v4/app/BackStackRecord$Op;
  [Instance Field] removed: Ljava/util/ArrayList;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void