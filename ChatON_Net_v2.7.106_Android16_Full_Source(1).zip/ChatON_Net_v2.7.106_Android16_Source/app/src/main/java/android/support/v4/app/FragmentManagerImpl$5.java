=== CLASS Landroid/support/v4/app/FragmentManagerImpl$5; (Source: FragmentManager.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/view/animation/Animation$AnimationListener;
  [Instance Field] this$0: Landroid/support/v4/app/FragmentManagerImpl;
  [Instance Field] val$fragment: Landroid/support/v4/app/Fragment;

  [Direct Method] <init>(Landroid/support/v4/app/FragmentManagerImpl;, Landroid/support/v4/app/Fragment;) -> V
    // registers=3, ins=3, outs=1, insns_size=8
    0000: iput v1, v0.Landroid/support/v4/app/FragmentManagerImpl$5;->this$0:Landroid/support/v4/app/FragmentManagerImpl;
    0002: iput v2, v0.Landroid/support/v4/app/FragmentManagerImpl$5;->val$fragment:Landroid/support/v4/app/Fragment;
    0004: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0007: return-void

  [Virtual Method] onAnimationEnd(Landroid/view/animation/Animation;) -> V
    // registers=8, ins=2, outs=6, insns_size=26
    0000: const/4 v3, 0
    0001: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl$5;->val$fragment:Landroid/support/v4/app/Fragment;
    0003: iget v0, v0.Landroid/support/v4/app/Fragment;->mAnimatingAway:Landroid/view/View;
    0005: if-eqz v0, 0019
    0007: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl$5;->val$fragment:Landroid/support/v4/app/Fragment;
    0009: const/4 v1, 0
    000a: iput v1, v0.Landroid/support/v4/app/Fragment;->mAnimatingAway:Landroid/view/View;
    000c: iget v0, v6.Landroid/support/v4/app/FragmentManagerImpl$5;->this$0:Landroid/support/v4/app/FragmentManagerImpl;
    000e: iget v1, v6.Landroid/support/v4/app/FragmentManagerImpl$5;->val$fragment:Landroid/support/v4/app/Fragment;
    0010: iget v2, v6.Landroid/support/v4/app/FragmentManagerImpl$5;->val$fragment:Landroid/support/v4/app/Fragment;
    0012: iget v2, v2.Landroid/support/v4/app/Fragment;->mStateAfterAnimating:I
    0014: move(op=01) v4, v3
    0015: move(op=01) v5, v3
    0016: invoke-virtual/range {v0..v5}, Landroid/support/v4/app/FragmentManagerImpl;->moveToState(Landroid/support/v4/app/Fragment;IIIZ)V
    0019: return-void

  [Virtual Method] onAnimationRepeat(Landroid/view/animation/Animation;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onAnimationStart(Landroid/view/animation/Animation;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void