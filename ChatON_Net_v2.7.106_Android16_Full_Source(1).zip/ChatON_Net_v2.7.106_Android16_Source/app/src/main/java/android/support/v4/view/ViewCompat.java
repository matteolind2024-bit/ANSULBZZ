=== CLASS Landroid/support/v4/view/ViewCompat; (Source: ViewCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] FAKE_FRAME_TIME: J = 10
  [Static Field] IMPL: Landroid/support/v4/view/ViewCompat$ViewCompatImpl; = None
  [Static Field] IMPORTANT_FOR_ACCESSIBILITY_AUTO: I = 0
  [Static Field] IMPORTANT_FOR_ACCESSIBILITY_NO: I = 2
  [Static Field] IMPORTANT_FOR_ACCESSIBILITY_YES: I = 1
  [Static Field] OVER_SCROLL_ALWAYS: I = 0
  [Static Field] OVER_SCROLL_IF_CONTENT_SCROLLS: I = 1
  [Static Field] OVER_SCROLL_NEVER: I = 2

  [Direct Method] <clinit>() -> V
    // registers=3, ins=0, outs=2, insns_size=68
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 16 (0x10)
    0004: if-ge v0, v1, 0010
    0006: sget v1, Landroid/os/Build$VERSION;->CODENAME:Ljava/lang/String;
    0008: const-string v2, 'JellyBean'
    000a: invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    000d: move-result v1
    000e: if-eqz v1, 0018
    0010: new-instance v0, Landroid/support/v4/view/ViewCompat$JBViewCompatImpl;
    0012: invoke-direct {v0}, Landroid/support/v4/view/ViewCompat$JBViewCompatImpl;-><init>()V
    0015: sput v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0017: return-void
    0018: const/16 v1, 14 (0xe)
    001a: if-lt v0, v1, 0024
    001c: new-instance v0, Landroid/support/v4/view/ViewCompat$ICSViewCompatImpl;
    001e: invoke-direct {v0}, Landroid/support/v4/view/ViewCompat$ICSViewCompatImpl;-><init>()V
    0021: sput v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0023: goto 0017
    0024: const/16 v1, 11 (0xb)
    0026: if-lt v0, v1, 0030
    0028: new-instance v0, Landroid/support/v4/view/ViewCompat$HCViewCompatImpl;
    002a: invoke-direct {v0}, Landroid/support/v4/view/ViewCompat$HCViewCompatImpl;-><init>()V
    002d: sput v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    002f: goto 0017
    0030: const/16 v1, 9 (0x9)
    0032: if-lt v0, v1, 003c
    0034: new-instance v0, Landroid/support/v4/view/ViewCompat$GBViewCompatImpl;
    0036: invoke-direct {v0}, Landroid/support/v4/view/ViewCompat$GBViewCompatImpl;-><init>()V
    0039: sput v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    003b: goto 0017
    003c: new-instance v0, Landroid/support/v4/view/ViewCompat$BaseViewCompatImpl;
    003e: invoke-direct {v0}, Landroid/support/v4/view/ViewCompat$BaseViewCompatImpl;-><init>()V
    0041: sput v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0043: goto 0017

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] canScrollHorizontally(Landroid/view/View;, I) -> Z
    // registers=3, ins=2, outs=3, insns_size=7
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->canScrollHorizontally(Landroid/view/View;I)Z
    0005: move-result v0
    0006: return v0

  [Direct Method] canScrollVertically(Landroid/view/View;, I) -> Z
    // registers=3, ins=2, outs=3, insns_size=7
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->canScrollVertically(Landroid/view/View;I)Z
    0005: move-result v0
    0006: return v0

  [Direct Method] getAccessibilityNodeProvider(Landroid/view/View;) -> Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->getAccessibilityNodeProvider(Landroid/view/View;)Landroid/support/v4/view/accessibility/AccessibilityNodeProviderCompat;
    0005: move-result-object v0
    0006: return-object v0

  [Direct Method] getImportantForAccessibility(Landroid/view/View;) -> I
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->getImportantForAccessibility(Landroid/view/View;)I
    0005: move-result v0
    0006: return v0

  [Direct Method] getOverScrollMode(Landroid/view/View;) -> I
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->getOverScrollMode(Landroid/view/View;)I
    0005: move-result v0
    0006: return v0

  [Direct Method] hasTransientState(Landroid/view/View;) -> Z
    // registers=2, ins=1, outs=2, insns_size=7
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->hasTransientState(Landroid/view/View;)Z
    0005: move-result v0
    0006: return v0

  [Direct Method] onInitializeAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=3, ins=2, outs=3, insns_size=6
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->onInitializeAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    0005: return-void

  [Direct Method] onInitializeAccessibilityNodeInfo(Landroid/view/View;, Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;) -> V
    // registers=3, ins=2, outs=3, insns_size=6
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/support/v4/view/accessibility/AccessibilityNodeInfoCompat;)V
    0005: return-void

  [Direct Method] onPopulateAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=3, ins=2, outs=3, insns_size=6
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->onPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    0005: return-void

  [Direct Method] postInvalidateOnAnimation(Landroid/view/View;) -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->postInvalidateOnAnimation(Landroid/view/View;)V
    0005: return-void

  [Direct Method] postInvalidateOnAnimation(Landroid/view/View;, I, I, I, I) -> V
    // registers=11, ins=5, outs=6, insns_size=11
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: move(op=07) v1, v6
    0003: move(op=01) v2, v7
    0004: move(op=01) v3, v8
    0005: move(op=01) v4, v9
    0006: move(op=01) v5, v10
    0007: invoke-interface/range {v0..v5}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->postInvalidateOnAnimation(Landroid/view/View;IIII)V
    000a: return-void

  [Direct Method] postOnAnimation(Landroid/view/View;, Ljava/lang/Runnable;) -> V
    // registers=3, ins=2, outs=3, insns_size=6
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->postOnAnimation(Landroid/view/View;Ljava/lang/Runnable;)V
    0005: return-void

  [Direct Method] postOnAnimationDelayed(Landroid/view/View;, Ljava/lang/Runnable;, J) -> V
    // registers=5, ins=4, outs=5, insns_size=6
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1, v2, v3, v4}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->postOnAnimationDelayed(Landroid/view/View;Ljava/lang/Runnable;J)V
    0005: return-void

  [Direct Method] setAccessibilityDelegate(Landroid/view/View;, Landroid/support/v4/view/AccessibilityDelegateCompat;) -> V
    // registers=3, ins=2, outs=3, insns_size=6
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->setAccessibilityDelegate(Landroid/view/View;Landroid/support/v4/view/AccessibilityDelegateCompat;)V
    0005: return-void

  [Direct Method] setHasTransientState(Landroid/view/View;, Z) -> V
    // registers=3, ins=2, outs=3, insns_size=6
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->setHasTransientState(Landroid/view/View;Z)V
    0005: return-void

  [Direct Method] setImportantForAccessibility(Landroid/view/View;, I) -> V
    // registers=3, ins=2, outs=3, insns_size=6
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->setImportantForAccessibility(Landroid/view/View;I)V
    0005: return-void

  [Direct Method] setOverScrollMode(Landroid/view/View;, I) -> V
    // registers=3, ins=2, outs=3, insns_size=6
    0000: sget v0, Landroid/support/v4/view/ViewCompat;->IMPL:Landroid/support/v4/view/ViewCompat$ViewCompatImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/ViewCompat$ViewCompatImpl;->setOverScrollMode(Landroid/view/View;I)V
    0005: return-void