=== CLASS Landroid/support/v4/view/ViewPager$OnPageChangeListener; (Source: ViewPager.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] onPageScrollStateChanged(I) -> V

  [Virtual Method] onPageScrolled(I, F, I) -> V

  [Virtual Method] onPageSelected(I) -> V