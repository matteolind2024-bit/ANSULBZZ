=== CLASS Landroid/support/v4/app/ActivityCompat; (Source: ActivityCompat.java) ===
  Super: Landroid/support/v4/content/ContextCompat;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Landroid/support/v4/content/ContextCompat;-><init>()V
    0003: return-void

  [Direct Method] invalidateOptionsMenu(Landroid/app/Activity;) -> Z
    // registers=3, ins=1, outs=1, insns_size=13
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/16 v1, 11 (0xb)
    0004: if-lt v0, v1, 000b
    0006: invoke-static {v2}, Landroid/support/v4/app/ActivityCompatHoneycomb;->invalidateOptionsMenu(Landroid/app/Activity;)V
    0009: const/4 v0, 1
    000a: return v0
    000b: const/4 v0, 0
    000c: goto 000a