=== CLASS Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl; (Source: TrafficStatsCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;
  [Instance Field] mThreadSocketTags: Ljava/lang/ThreadLocal;

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=11
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$1;
    0005: invoke-direct {v0, v1}, Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$1;-><init>(Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl;)V
    0008: iput v0, v1.Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl;->mThreadSocketTags:Ljava/lang/ThreadLocal;
    000a: return-void

  [Virtual Method] clearThreadStatsTag() -> V
    // registers=3, ins=1, outs=1, insns_size=12
    0000: iget v0, v2.Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl;->mThreadSocketTags:Ljava/lang/ThreadLocal;
    0002: invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;
    0008: const/4 v1, -1
    0009: iput v1, v0.Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;->statsTag:I
    000b: return-void

  [Virtual Method] getThreadStatsTag() -> I
    // registers=2, ins=1, outs=1, insns_size=11
    0000: iget v0, v1.Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl;->mThreadSocketTags:Ljava/lang/ThreadLocal;
    0002: invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;
    0008: iget v0, v0.Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;->statsTag:I
    000a: return v0

  [Virtual Method] incrementOperationCount(I) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] incrementOperationCount(I, I) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setThreadStatsTag(I) -> V
    // registers=3, ins=2, outs=1, insns_size=11
    0000: iget v0, v1.Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl;->mThreadSocketTags:Ljava/lang/ThreadLocal;
    0002: invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;
    0008: iput v2, v0.Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;->statsTag:I
    000a: return-void

  [Virtual Method] tagSocket(Ljava/net/Socket;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] untagSocket(Ljava/net/Socket;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void