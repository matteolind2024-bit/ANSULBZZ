=== CLASS Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$1; (Source: TrafficStatsCompat.java) ===
  Super: Ljava/lang/ThreadLocal;
  [Instance Field] this$0: Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl;

  [Direct Method] <init>(Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$1;->this$0:Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl;
    0002: invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V
    0005: return-void

  [Virtual Method] initialValue() -> Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;
    // registers=3, ins=1, outs=2, insns_size=7
    0000: new-instance v0, Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;
    0002: const/4 v1, 0
    0003: invoke-direct {v0, v1}, Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;-><init>(Landroid/support/v4/net/TrafficStatsCompat$1;)V
    0006: return-object v0

  [Virtual Method] initialValue() -> Ljava/lang/Object;
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$1;->initialValue()Landroid/support/v4/net/TrafficStatsCompat$BaseTrafficStatsCompatImpl$SocketTags;
    0003: move-result-object v0
    0004: return-object v0