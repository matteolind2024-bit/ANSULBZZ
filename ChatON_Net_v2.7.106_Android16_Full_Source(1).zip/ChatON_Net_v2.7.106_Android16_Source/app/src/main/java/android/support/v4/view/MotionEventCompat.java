=== CLASS Landroid/support/v4/view/MotionEventCompat; (Source: MotionEventCompat.java) ===
  Super: Ljava/lang/Object;
  [Static Field] ACTION_HOVER_ENTER: I = 9
  [Static Field] ACTION_HOVER_EXIT: I = 10
  [Static Field] ACTION_HOVER_MOVE: I = 7
  [Static Field] ACTION_MASK: I = 255
  [Static Field] ACTION_POINTER_DOWN: I = 5
  [Static Field] ACTION_POINTER_INDEX_MASK: I = 65280
  [Static Field] ACTION_POINTER_INDEX_SHIFT: I = 8
  [Static Field] ACTION_POINTER_UP: I = 6
  [Static Field] ACTION_SCROLL: I = 8
  [Static Field] IMPL: Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=1, insns_size=21
    0000: sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    0002: const/4 v1, 5
    0003: if-lt v0, v1, 000d
    0005: new-instance v0, Landroid/support/v4/view/MotionEventCompat$EclairMotionEventVersionImpl;
    0007: invoke-direct {v0}, Landroid/support/v4/view/MotionEventCompat$EclairMotionEventVersionImpl;-><init>()V
    000a: sput v0, Landroid/support/v4/view/MotionEventCompat;->IMPL:Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;
    000c: return-void
    000d: new-instance v0, Landroid/support/v4/view/MotionEventCompat$BaseMotionEventVersionImpl;
    000f: invoke-direct {v0}, Landroid/support/v4/view/MotionEventCompat$BaseMotionEventVersionImpl;-><init>()V
    0012: sput v0, Landroid/support/v4/view/MotionEventCompat;->IMPL:Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;
    0014: goto 000c

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] findPointerIndex(Landroid/view/MotionEvent;, I) -> I
    // registers=3, ins=2, outs=3, insns_size=7
    0000: sget v0, Landroid/support/v4/view/MotionEventCompat;->IMPL:Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;->findPointerIndex(Landroid/view/MotionEvent;I)I
    0005: move-result v0
    0006: return v0

  [Direct Method] getActionIndex(Landroid/view/MotionEvent;) -> I
    // registers=3, ins=1, outs=1, insns_size=11
    0000: invoke-virtual {v2}, Landroid/view/MotionEvent;->getAction()I
    0003: move-result v0
    0004: const v1, 65280 (0xff00)
    0007: binop/2addr(op=b5) v0, v1
    0008: binop/lit8(op=e1) v0, v0, 8 (0x8)
    000a: return v0

  [Direct Method] getActionMasked(Landroid/view/MotionEvent;) -> I
    // registers=2, ins=1, outs=1, insns_size=7
    0000: invoke-virtual {v1}, Landroid/view/MotionEvent;->getAction()I
    0003: move-result v0
    0004: binop/lit16(op=d5) v0, v0, 255 (0xff)
    0006: return v0

  [Direct Method] getPointerId(Landroid/view/MotionEvent;, I) -> I
    // registers=3, ins=2, outs=3, insns_size=7
    0000: sget v0, Landroid/support/v4/view/MotionEventCompat;->IMPL:Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;->getPointerId(Landroid/view/MotionEvent;I)I
    0005: move-result v0
    0006: return v0

  [Direct Method] getX(Landroid/view/MotionEvent;, I) -> F
    // registers=3, ins=2, outs=3, insns_size=7
    0000: sget v0, Landroid/support/v4/view/MotionEventCompat;->IMPL:Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;->getX(Landroid/view/MotionEvent;I)F
    0005: move-result v0
    0006: return v0

  [Direct Method] getY(Landroid/view/MotionEvent;, I) -> F
    // registers=3, ins=2, outs=3, insns_size=7
    0000: sget v0, Landroid/support/v4/view/MotionEventCompat;->IMPL:Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;
    0002: invoke-interface {v0, v1, v2}, Landroid/support/v4/view/MotionEventCompat$MotionEventVersionImpl;->getY(Landroid/view/MotionEvent;I)F
    0005: move-result v0
    0006: return v0