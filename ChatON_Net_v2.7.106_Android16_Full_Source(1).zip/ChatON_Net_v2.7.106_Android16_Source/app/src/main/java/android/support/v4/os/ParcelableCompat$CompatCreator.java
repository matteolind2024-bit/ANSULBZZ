=== CLASS Landroid/support/v4/os/ParcelableCompat$CompatCreator; (Source: ParcelableCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/Parcelable$Creator;
  [Instance Field] mCallbacks: Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;

  [Direct Method] <init>(Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Landroid/support/v4/os/ParcelableCompat$CompatCreator;->mCallbacks:Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;
    0005: return-void

  [Virtual Method] createFromParcel(Landroid/os/Parcel;) -> Ljava/lang/Object;
    // registers=4, ins=2, outs=3, insns_size=8
    0000: iget v0, v2.Landroid/support/v4/os/ParcelableCompat$CompatCreator;->mCallbacks:Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;
    0002: const/4 v1, 0
    0003: invoke-interface {v0, v3, v1}, Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;->createFromParcel(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Ljava/lang/Object;
    0006: move-result-object v0
    0007: return-object v0

  [Virtual Method] newArray(I) -> [Ljava/lang/Object;
    // registers=3, ins=2, outs=2, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/os/ParcelableCompat$CompatCreator;->mCallbacks:Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;
    0002: invoke-interface {v0, v2}, Landroid/support/v4/os/ParcelableCompatCreatorCallbacks;->newArray(I)[Ljava/lang/Object;
    0005: move-result-object v0
    0006: return-object v0