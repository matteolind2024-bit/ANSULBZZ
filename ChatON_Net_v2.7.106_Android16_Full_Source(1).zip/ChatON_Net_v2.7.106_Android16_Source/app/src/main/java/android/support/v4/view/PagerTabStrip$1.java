=== CLASS Landroid/support/v4/view/PagerTabStrip$1; (Source: PagerTabStrip.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/view/View$OnClickListener;
  [Instance Field] this$0: Landroid/support/v4/view/PagerTabStrip;

  [Direct Method] <init>(Landroid/support/v4/view/PagerTabStrip;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/view/PagerTabStrip$1;->this$0:Landroid/support/v4/view/PagerTabStrip;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onClick(Landroid/view/View;) -> V
    // registers=4, ins=2, outs=2, insns_size=18
    0000: iget v0, v2.Landroid/support/v4/view/PagerTabStrip$1;->this$0:Landroid/support/v4/view/PagerTabStrip;
    0002: iget v0, v0.Landroid/support/v4/view/PagerTabStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0004: iget v1, v2.Landroid/support/v4/view/PagerTabStrip$1;->this$0:Landroid/support/v4/view/PagerTabStrip;
    0006: iget v1, v1.Landroid/support/v4/view/PagerTabStrip;->mPager:Landroid/support/v4/view/ViewPager;
    0008: invoke-virtual {v1}, Landroid/support/v4/view/ViewPager;->getCurrentItem()I
    000b: move-result v1
    000c: binop/lit8(op=d8) v1, v1, -1 (-0x1)
    000e: invoke-virtual {v0, v1}, Landroid/support/v4/view/ViewPager;->setCurrentItem(I)V
    0011: return-void