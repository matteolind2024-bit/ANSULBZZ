=== CLASS Landroid/support/v4/view/ViewPager$OnAdapterChangeListener; (Source: ViewPager.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] onAdapterChanged(Landroid/support/v4/view/PagerAdapter;, Landroid/support/v4/view/PagerAdapter;) -> V