=== CLASS Landroid/support/v4/view/MenuCompat$MenuVersionImpl; (Source: MenuCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] setShowAsAction(Landroid/view/MenuItem;, I) -> Z