=== CLASS Landroid/support/v4/widget/EdgeEffectCompat$EdgeEffectImpl; (Source: EdgeEffectCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] draw(Ljava/lang/Object;, Landroid/graphics/Canvas;) -> Z

  [Virtual Method] finish(Ljava/lang/Object;) -> V

  [Virtual Method] isFinished(Ljava/lang/Object;) -> Z

  [Virtual Method] newEdgeEffect(Landroid/content/Context;) -> Ljava/lang/Object;

  [Virtual Method] onAbsorb(Ljava/lang/Object;, I) -> Z

  [Virtual Method] onPull(Ljava/lang/Object;, F) -> Z

  [Virtual Method] onRelease(Ljava/lang/Object;) -> Z

  [Virtual Method] setSize(Ljava/lang/Object;, I, I) -> V