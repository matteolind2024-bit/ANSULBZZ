=== CLASS Landroid/support/v4/view/MenuItemCompat$MenuVersionImpl; (Source: MenuItemCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] setActionView(Landroid/view/MenuItem;, Landroid/view/View;) -> Landroid/view/MenuItem;

  [Virtual Method] setShowAsAction(Landroid/view/MenuItem;, I) -> Z