=== CLASS Landroid/support/v4/view/ViewConfigurationCompatFroyo; (Source: ViewConfigurationCompatFroyo.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] getScaledPagingTouchSlop(Landroid/view/ViewConfiguration;) -> I
    // registers=2, ins=1, outs=1, insns_size=5
    0000: invoke-virtual {v1}, Landroid/view/ViewConfiguration;->getScaledPagingTouchSlop()I
    0003: move-result v0
    0004: return v0