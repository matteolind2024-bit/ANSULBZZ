=== CLASS Landroid/support/v4/view/ViewCompatICS; (Source: ViewCompatICS.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] canScrollHorizontally(Landroid/view/View;, I) -> Z
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/view/View;->canScrollHorizontally(I)Z
    0003: move-result v0
    0004: return v0

  [Direct Method] canScrollVertically(Landroid/view/View;, I) -> Z
    // registers=3, ins=2, outs=2, insns_size=5
    0000: invoke-virtual {v1, v2}, Landroid/view/View;->canScrollVertically(I)Z
    0003: move-result v0
    0004: return v0

  [Direct Method] onInitializeAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/view/View;->onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    0003: return-void

  [Direct Method] onInitializeAccessibilityNodeInfo(Landroid/view/View;, Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v1, Landroid/view/accessibility/AccessibilityNodeInfo;
    0002: invoke-virtual {v0, v1}, Landroid/view/View;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    0005: return-void

  [Direct Method] onPopulateAccessibilityEvent(Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/view/View;->onPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    0003: return-void

  [Direct Method] setAccessibilityDelegate(Landroid/view/View;, Ljava/lang/Object;) -> V
    // registers=2, ins=2, outs=2, insns_size=6
    0000: check-cast v1, Landroid/view/View$AccessibilityDelegate;
    0002: invoke-virtual {v0, v1}, Landroid/view/View;->setAccessibilityDelegate(Landroid/view/View$AccessibilityDelegate;)V
    0005: return-void