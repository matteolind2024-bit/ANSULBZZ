=== CLASS Landroid/support/v4/content/ModernAsyncTask$1; (Source: ModernAsyncTask.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Ljava/util/concurrent/ThreadFactory;
  [Instance Field] mCount: Ljava/util/concurrent/atomic/AtomicInteger;

  [Direct Method] <init>() -> V
    // registers=3, ins=1, outs=2, insns_size=12
    0000: invoke-direct {v2}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;
    0005: const/4 v1, 1
    0006: invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V
    0009: iput v0, v2.Landroid/support/v4/content/ModernAsyncTask$1;->mCount:Ljava/util/concurrent/atomic/AtomicInteger;
    000b: return-void

  [Virtual Method] newThread(Ljava/lang/Runnable;) -> Ljava/lang/Thread;
    // registers=5, ins=2, outs=3, insns_size=31
    0000: new-instance v0, Ljava/lang/Thread;
    0002: new-instance v1, Ljava/lang/StringBuilder;
    0004: invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V
    0007: const-string v2, 'ModernAsyncTask #'
    0009: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    000c: move-result-object v1
    000d: iget v2, v3.Landroid/support/v4/content/ModernAsyncTask$1;->mCount:Ljava/util/concurrent/atomic/AtomicInteger;
    000f: invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I
    0012: move-result v2
    0013: invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    0016: move-result-object v1
    0017: invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    001a: move-result-object v1
    001b: invoke-direct {v0, v4, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V
    001e: return-object v0