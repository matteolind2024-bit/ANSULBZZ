=== CLASS Landroid/support/v4/net/TrafficStatsCompat$IcsTrafficStatsCompatImpl; (Source: TrafficStatsCompat.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] clearThreadStatsTag() -> V
    // registers=1, ins=1, outs=0, insns_size=4
    0000: invoke-static {}, Landroid/support/v4/net/TrafficStatsCompatIcs;->clearThreadStatsTag()V
    0003: return-void

  [Virtual Method] getThreadStatsTag() -> I
    // registers=2, ins=1, outs=0, insns_size=5
    0000: invoke-static {}, Landroid/support/v4/net/TrafficStatsCompatIcs;->getThreadStatsTag()I
    0003: move-result v0
    0004: return v0

  [Virtual Method] incrementOperationCount(I) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-static {v1}, Landroid/support/v4/net/TrafficStatsCompatIcs;->incrementOperationCount(I)V
    0003: return-void

  [Virtual Method] incrementOperationCount(I, I) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-static {v1, v2}, Landroid/support/v4/net/TrafficStatsCompatIcs;->incrementOperationCount(II)V
    0003: return-void

  [Virtual Method] setThreadStatsTag(I) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-static {v1}, Landroid/support/v4/net/TrafficStatsCompatIcs;->setThreadStatsTag(I)V
    0003: return-void

  [Virtual Method] tagSocket(Ljava/net/Socket;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-static {v1}, Landroid/support/v4/net/TrafficStatsCompatIcs;->tagSocket(Ljava/net/Socket;)V
    0003: return-void

  [Virtual Method] untagSocket(Ljava/net/Socket;) -> V
    // registers=2, ins=2, outs=1, insns_size=4
    0000: invoke-static {v1}, Landroid/support/v4/net/TrafficStatsCompatIcs;->untagSocket(Ljava/net/Socket;)V
    0003: return-void