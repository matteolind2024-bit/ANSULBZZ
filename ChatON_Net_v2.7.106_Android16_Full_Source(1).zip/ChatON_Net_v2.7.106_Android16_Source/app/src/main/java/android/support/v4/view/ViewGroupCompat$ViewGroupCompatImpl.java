=== CLASS Landroid/support/v4/view/ViewGroupCompat$ViewGroupCompatImpl; (Source: ViewGroupCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;, Landroid/view/View;, Landroid/view/accessibility/AccessibilityEvent;) -> Z