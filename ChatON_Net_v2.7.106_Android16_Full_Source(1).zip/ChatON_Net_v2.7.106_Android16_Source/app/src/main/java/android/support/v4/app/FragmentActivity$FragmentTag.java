=== CLASS Landroid/support/v4/app/FragmentActivity$FragmentTag; (Source: FragmentActivity.java) ===
  Super: Ljava/lang/Object;
  [Static Field] Fragment: [I = None
  [Static Field] Fragment_id: I = 1
  [Static Field] Fragment_name: I = 0
  [Static Field] Fragment_tag: I = 2

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=0, insns_size=20
    0000: const/4 v0, 3
    0001: new-array v0, v0, [I
    0003: fill-array-data v0, +7 (-> 000a)
    0006: sput v0, Landroid/support/v4/app/FragmentActivity$FragmentTag;->Fragment:[I
    0008: return-void
    0009: nop
    000a: fill-array-data-payload width=4 size=3 data=03000101d0000101d1000101

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void