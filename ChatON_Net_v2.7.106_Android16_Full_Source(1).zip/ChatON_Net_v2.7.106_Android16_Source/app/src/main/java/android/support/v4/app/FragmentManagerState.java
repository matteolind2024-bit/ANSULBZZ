=== CLASS Landroid/support/v4/app/FragmentManagerState; (Source: FragmentManager.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/Parcelable;
  [Static Field] CREATOR: Landroid/os/Parcelable$Creator;
  [Instance Field] mActive: [Landroid/support/v4/app/FragmentState;
  [Instance Field] mAdded: [I
  [Instance Field] mBackStack: [Landroid/support/v4/app/BackStackState;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=8
    0000: new-instance v0, Landroid/support/v4/app/FragmentManagerState$1;
    0002: invoke-direct {v0}, Landroid/support/v4/app/FragmentManagerState$1;-><init>()V
    0005: sput v0, Landroid/support/v4/app/FragmentManagerState;->CREATOR:Landroid/os/Parcelable$Creator;
    0007: return-void

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] <init>(Landroid/os/Parcel;) -> V
    // registers=3, ins=2, outs=2, insns_size=30
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: sget v0, Landroid/support/v4/app/FragmentState;->CREATOR:Landroid/os/Parcelable$Creator;
    0005: invoke-virtual {v2, v0}, Landroid/os/Parcel;->createTypedArray(Landroid/os/Parcelable$Creator;)[Ljava/lang/Object;
    0008: move-result-object v0
    0009: check-cast v0, [Landroid/support/v4/app/FragmentState;
    000b: iput v0, v1.Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;
    000d: invoke-virtual {v2}, Landroid/os/Parcel;->createIntArray()[I
    0010: move-result-object v0
    0011: iput v0, v1.Landroid/support/v4/app/FragmentManagerState;->mAdded:[I
    0013: sget v0, Landroid/support/v4/app/BackStackState;->CREATOR:Landroid/os/Parcelable$Creator;
    0015: invoke-virtual {v2, v0}, Landroid/os/Parcel;->createTypedArray(Landroid/os/Parcelable$Creator;)[Ljava/lang/Object;
    0018: move-result-object v0
    0019: check-cast v0, [Landroid/support/v4/app/BackStackState;
    001b: iput v0, v1.Landroid/support/v4/app/FragmentManagerState;->mBackStack:[Landroid/support/v4/app/BackStackState;
    001d: return-void

  [Virtual Method] describeContents() -> I
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] writeToParcel(Landroid/os/Parcel;, I) -> V
    // registers=4, ins=3, outs=3, insns_size=16
    0000: iget v0, v1.Landroid/support/v4/app/FragmentManagerState;->mActive:[Landroid/support/v4/app/FragmentState;
    0002: invoke-virtual {v2, v0, v3}, Landroid/os/Parcel;->writeTypedArray([Landroid/os/Parcelable;I)V
    0005: iget v0, v1.Landroid/support/v4/app/FragmentManagerState;->mAdded:[I
    0007: invoke-virtual {v2, v0}, Landroid/os/Parcel;->writeIntArray([I)V
    000a: iget v0, v1.Landroid/support/v4/app/FragmentManagerState;->mBackStack:[Landroid/support/v4/app/BackStackState;
    000c: invoke-virtual {v2, v0, v3}, Landroid/os/Parcel;->writeTypedArray([Landroid/os/Parcelable;I)V
    000f: return-void