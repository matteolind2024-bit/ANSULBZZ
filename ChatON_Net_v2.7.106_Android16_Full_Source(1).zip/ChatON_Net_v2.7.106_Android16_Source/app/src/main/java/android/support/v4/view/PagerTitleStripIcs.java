=== CLASS Landroid/support/v4/view/PagerTitleStripIcs; (Source: PagerTitleStripIcs.java) ===
  Super: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] setSingleLineAllCaps(Landroid/widget/TextView;) -> V
    // registers=3, ins=1, outs=2, insns_size=13
    0000: new-instance v0, Landroid/support/v4/view/PagerTitleStripIcs$SingleLineAllCapsTransform;
    0002: invoke-virtual {v2}, Landroid/widget/TextView;->getContext()Landroid/content/Context;
    0005: move-result-object v1
    0006: invoke-direct {v0, v1}, Landroid/support/v4/view/PagerTitleStripIcs$SingleLineAllCapsTransform;-><init>(Landroid/content/Context;)V
    0009: invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTransformationMethod(Landroid/text/method/TransformationMethod;)V
    000c: return-void