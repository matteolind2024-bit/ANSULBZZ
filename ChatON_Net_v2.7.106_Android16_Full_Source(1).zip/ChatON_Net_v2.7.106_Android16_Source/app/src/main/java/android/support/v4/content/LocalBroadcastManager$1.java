=== CLASS Landroid/support/v4/content/LocalBroadcastManager$1; (Source: LocalBroadcastManager.java) ===
  Super: Landroid/os/Handler;
  [Instance Field] this$0: Landroid/support/v4/content/LocalBroadcastManager;

  [Direct Method] <init>(Landroid/support/v4/content/LocalBroadcastManager;, Landroid/os/Looper;) -> V
    // registers=3, ins=3, outs=2, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/content/LocalBroadcastManager$1;->this$0:Landroid/support/v4/content/LocalBroadcastManager;
    0002: invoke-direct {v0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V
    0005: return-void

  [Virtual Method] handleMessage(Landroid/os/Message;) -> V
    // registers=3, ins=2, outs=2, insns_size=22
    0000: iget v0, v2.Landroid/os/Message;->what:I
    0002: packed-switch v0, +14 (-> 0010)
    0005: invoke-super {v1, v2}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V
    0008: return-void
    0009: iget v0, v1.Landroid/support/v4/content/LocalBroadcastManager$1;->this$0:Landroid/support/v4/content/LocalBroadcastManager;
    000b: invoke-static {v0}, Landroid/support/v4/content/LocalBroadcastManager;->access$000(Landroid/support/v4/content/LocalBroadcastManager;)V
    000e: goto 0008
    000f: nop
    0010: packed-switch-payload first=1 targets=[7]