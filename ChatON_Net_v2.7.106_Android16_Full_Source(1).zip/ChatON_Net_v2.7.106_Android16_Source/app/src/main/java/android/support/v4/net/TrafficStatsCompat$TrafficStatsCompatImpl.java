=== CLASS Landroid/support/v4/net/TrafficStatsCompat$TrafficStatsCompatImpl; (Source: TrafficStatsCompat.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] clearThreadStatsTag() -> V

  [Virtual Method] getThreadStatsTag() -> I

  [Virtual Method] incrementOperationCount(I) -> V

  [Virtual Method] incrementOperationCount(I, I) -> V

  [Virtual Method] setThreadStatsTag(I) -> V

  [Virtual Method] tagSocket(Ljava/net/Socket;) -> V

  [Virtual Method] untagSocket(Ljava/net/Socket;) -> V