=== CLASS Landroid/support/v4/app/ListFragment; (Source: ListFragment.java) ===
  Super: Landroid/support/v4/app/Fragment;
  [Static Field] INTERNAL_EMPTY_ID: I = 16711681
  [Static Field] INTERNAL_LIST_CONTAINER_ID: I = 16711683
  [Static Field] INTERNAL_PROGRESS_CONTAINER_ID: I = 16711682
  [Instance Field] mAdapter: Landroid/widget/ListAdapter;
  [Instance Field] mEmptyText: Ljava/lang/CharSequence;
  [Instance Field] mEmptyView: Landroid/view/View;
  [Instance Field] mHandler: Landroid/os/Handler;
  [Instance Field] mList: Landroid/widget/ListView;
  [Instance Field] mListContainer: Landroid/view/View;
  [Instance Field] mListShown: Z
  [Instance Field] mOnClickListener: Landroid/widget/AdapterView$OnItemClickListener;
  [Instance Field] mProgressContainer: Landroid/view/View;
  [Instance Field] mRequestFocus: Ljava/lang/Runnable;
  [Instance Field] mStandardEmptyView: Landroid/widget/TextView;

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=25
    0000: invoke-direct {v1}, Landroid/support/v4/app/Fragment;-><init>()V
    0003: new-instance v0, Landroid/os/Handler;
    0005: invoke-direct {v0}, Landroid/os/Handler;-><init>()V
    0008: iput v0, v1.Landroid/support/v4/app/ListFragment;->mHandler:Landroid/os/Handler;
    000a: new-instance v0, Landroid/support/v4/app/ListFragment$1;
    000c: invoke-direct {v0, v1}, Landroid/support/v4/app/ListFragment$1;-><init>(Landroid/support/v4/app/ListFragment;)V
    000f: iput v0, v1.Landroid/support/v4/app/ListFragment;->mRequestFocus:Ljava/lang/Runnable;
    0011: new-instance v0, Landroid/support/v4/app/ListFragment$2;
    0013: invoke-direct {v0, v1}, Landroid/support/v4/app/ListFragment$2;-><init>(Landroid/support/v4/app/ListFragment;)V
    0016: iput v0, v1.Landroid/support/v4/app/ListFragment;->mOnClickListener:Landroid/widget/AdapterView$OnItemClickListener;
    0018: return-void

  [Direct Method] ensureList() -> V
    // registers=5, ins=1, outs=3, insns_size=182
    0000: const/4 v3, 0
    0001: iget v0, v4.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    0003: if-eqz v0, 0006
    0005: return-void
    0006: invoke-virtual {v4}, Landroid/support/v4/app/ListFragment;->getView()Landroid/view/View;
    0009: move-result-object v0
    000a: if-nez v0, 0014
    000c: new-instance v0, Ljava/lang/IllegalStateException;
    000e: const-string v1, 'Content view not yet created'
    0010: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0013: throw v0
    0014: instance-of v1, v0, Landroid/widget/ListView;
    0016: if-eqz v1, 003a
    0018: check-cast v0, Landroid/widget/ListView;
    001a: iput v0, v4.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    001c: const/4 v0, 1
    001d: iput v0, v4.Landroid/support/v4/app/ListFragment;->mListShown:Z
    001f: iget v0, v4.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    0021: iget v1, v4.Landroid/support/v4/app/ListFragment;->mOnClickListener:Landroid/widget/AdapterView$OnItemClickListener;
    0023: invoke-virtual {v0, v1}, Landroid/widget/ListView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V
    0026: iget v0, v4.Landroid/support/v4/app/ListFragment;->mAdapter:Landroid/widget/ListAdapter;
    0028: if-eqz v0, 00ad
    002a: iget v0, v4.Landroid/support/v4/app/ListFragment;->mAdapter:Landroid/widget/ListAdapter;
    002c: const/4 v1, 0
    002d: iput v1, v4.Landroid/support/v4/app/ListFragment;->mAdapter:Landroid/widget/ListAdapter;
    002f: invoke-virtual {v4, v0}, Landroid/support/v4/app/ListFragment;->setListAdapter(Landroid/widget/ListAdapter;)V
    0032: iget v0, v4.Landroid/support/v4/app/ListFragment;->mHandler:Landroid/os/Handler;
    0034: iget v1, v4.Landroid/support/v4/app/ListFragment;->mRequestFocus:Ljava/lang/Runnable;
    0036: invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    0039: goto 0005
    003a: const v1, 16711681 (0xff0001)
    003d: invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0040: move-result-object v1
    0041: check-cast v1, Landroid/widget/TextView;
    0043: iput v1, v4.Landroid/support/v4/app/ListFragment;->mStandardEmptyView:Landroid/widget/TextView;
    0045: iget v1, v4.Landroid/support/v4/app/ListFragment;->mStandardEmptyView:Landroid/widget/TextView;
    0047: if-nez v1, 0079
    0049: const v1, 16908292 (0x1020004)
    004c: invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    004f: move-result-object v1
    0050: iput v1, v4.Landroid/support/v4/app/ListFragment;->mEmptyView:Landroid/view/View;
    0052: const v1, 16711682 (0xff0002)
    0055: invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0058: move-result-object v1
    0059: iput v1, v4.Landroid/support/v4/app/ListFragment;->mProgressContainer:Landroid/view/View;
    005b: const v1, 16711683 (0xff0003)
    005e: invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    0061: move-result-object v1
    0062: iput v1, v4.Landroid/support/v4/app/ListFragment;->mListContainer:Landroid/view/View;
    0064: const v1, 16908298 (0x102000a)
    0067: invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;
    006a: move-result-object v0
    006b: instance-of v1, v0, Landroid/widget/ListView;
    006d: if-nez v1, 0089
    006f: if-nez v0, 0081
    0071: new-instance v0, Ljava/lang/RuntimeException;
    0073: const-string v1, "Your content must have a ListView whose id attribute is 'android.R.id.list'"
    0075: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    0078: throw v0
    0079: iget v1, v4.Landroid/support/v4/app/ListFragment;->mStandardEmptyView:Landroid/widget/TextView;
    007b: const/16 v2, 8 (0x8)
    007d: invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V
    0080: goto 0052
    0081: new-instance v0, Ljava/lang/RuntimeException;
    0083: const-string v1, "Content has view with id attribute 'android.R.id.list' that is not a ListView class"
    0085: invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V
    0088: throw v0
    0089: check-cast v0, Landroid/widget/ListView;
    008b: iput v0, v4.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    008d: iget v0, v4.Landroid/support/v4/app/ListFragment;->mEmptyView:Landroid/view/View;
    008f: if-eqz v0, 0099
    0091: iget v0, v4.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    0093: iget v1, v4.Landroid/support/v4/app/ListFragment;->mEmptyView:Landroid/view/View;
    0095: invoke-virtual {v0, v1}, Landroid/widget/ListView;->setEmptyView(Landroid/view/View;)V
    0098: goto 001c
    0099: iget v0, v4.Landroid/support/v4/app/ListFragment;->mEmptyText:Ljava/lang/CharSequence;
    009b: if-eqz v0, 001c
    009d: iget v0, v4.Landroid/support/v4/app/ListFragment;->mStandardEmptyView:Landroid/widget/TextView;
    009f: iget v1, v4.Landroid/support/v4/app/ListFragment;->mEmptyText:Ljava/lang/CharSequence;
    00a1: invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    00a4: iget v0, v4.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    00a6: iget v1, v4.Landroid/support/v4/app/ListFragment;->mStandardEmptyView:Landroid/widget/TextView;
    00a8: invoke-virtual {v0, v1}, Landroid/widget/ListView;->setEmptyView(Landroid/view/View;)V
    00ab: goto/16 001c
    00ad: iget v0, v4.Landroid/support/v4/app/ListFragment;->mProgressContainer:Landroid/view/View;
    00af: if-eqz v0, 0032
    00b1: invoke-direct {v4, v3, v3}, Landroid/support/v4/app/ListFragment;->setListShown(ZZ)V
    00b4: goto/16 0032

  [Direct Method] setListShown(Z, Z) -> V
    // registers=9, ins=3, outs=2, insns_size=132
    0000: const v5, 17432577 (0x10a0001)
    0003: const/high16 v4, 17432576 (0x10a0000)
    0005: const/16 v3, 8 (0x8)
    0007: const/4 v2, 0
    0008: invoke-direct {v6}, Landroid/support/v4/app/ListFragment;->ensureList()V
    000b: iget v0, v6.Landroid/support/v4/app/ListFragment;->mProgressContainer:Landroid/view/View;
    000d: if-nez v0, 0017
    000f: new-instance v0, Ljava/lang/IllegalStateException;
    0011: const-string v1, "Can't be used with a custom content view"
    0013: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0016: throw v0
    0017: iget v0, v6.Landroid/support/v4/app/ListFragment;->mListShown:Z
    0019: if-ne v0, v7, 001c
    001b: return-void
    001c: iput v7, v6.Landroid/support/v4/app/ListFragment;->mListShown:Z
    001e: if-eqz v7, 0052
    0020: if-eqz v8, 0047
    0022: iget v0, v6.Landroid/support/v4/app/ListFragment;->mProgressContainer:Landroid/view/View;
    0024: invoke-virtual {v6}, Landroid/support/v4/app/ListFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0027: move-result-object v1
    0028: invoke-static {v1, v5}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;
    002b: move-result-object v1
    002c: invoke-virtual {v0, v1}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V
    002f: iget v0, v6.Landroid/support/v4/app/ListFragment;->mListContainer:Landroid/view/View;
    0031: invoke-virtual {v6}, Landroid/support/v4/app/ListFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0034: move-result-object v1
    0035: invoke-static {v1, v4}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;
    0038: move-result-object v1
    0039: invoke-virtual {v0, v1}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V
    003c: iget v0, v6.Landroid/support/v4/app/ListFragment;->mProgressContainer:Landroid/view/View;
    003e: invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V
    0041: iget v0, v6.Landroid/support/v4/app/ListFragment;->mListContainer:Landroid/view/View;
    0043: invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V
    0046: goto 001b
    0047: iget v0, v6.Landroid/support/v4/app/ListFragment;->mProgressContainer:Landroid/view/View;
    0049: invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V
    004c: iget v0, v6.Landroid/support/v4/app/ListFragment;->mListContainer:Landroid/view/View;
    004e: invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V
    0051: goto 003c
    0052: if-eqz v8, 0079
    0054: iget v0, v6.Landroid/support/v4/app/ListFragment;->mProgressContainer:Landroid/view/View;
    0056: invoke-virtual {v6}, Landroid/support/v4/app/ListFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0059: move-result-object v1
    005a: invoke-static {v1, v4}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;
    005d: move-result-object v1
    005e: invoke-virtual {v0, v1}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V
    0061: iget v0, v6.Landroid/support/v4/app/ListFragment;->mListContainer:Landroid/view/View;
    0063: invoke-virtual {v6}, Landroid/support/v4/app/ListFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0066: move-result-object v1
    0067: invoke-static {v1, v5}, Landroid/view/animation/AnimationUtils;->loadAnimation(Landroid/content/Context;I)Landroid/view/animation/Animation;
    006a: move-result-object v1
    006b: invoke-virtual {v0, v1}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V
    006e: iget v0, v6.Landroid/support/v4/app/ListFragment;->mProgressContainer:Landroid/view/View;
    0070: invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V
    0073: iget v0, v6.Landroid/support/v4/app/ListFragment;->mListContainer:Landroid/view/View;
    0075: invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V
    0078: goto 001b
    0079: iget v0, v6.Landroid/support/v4/app/ListFragment;->mProgressContainer:Landroid/view/View;
    007b: invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V
    007e: iget v0, v6.Landroid/support/v4/app/ListFragment;->mListContainer:Landroid/view/View;
    0080: invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V
    0083: goto 006e

  [Virtual Method] getListAdapter() -> Landroid/widget/ListAdapter;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/support/v4/app/ListFragment;->mAdapter:Landroid/widget/ListAdapter;
    0002: return-object v0

  [Virtual Method] getListView() -> Landroid/widget/ListView;
    // registers=2, ins=1, outs=1, insns_size=6
    0000: invoke-direct {v1}, Landroid/support/v4/app/ListFragment;->ensureList()V
    0003: iget v0, v1.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    0005: return-object v0

  [Virtual Method] getSelectedItemId() -> J
    // registers=3, ins=1, outs=1, insns_size=10
    0000: invoke-direct {v2}, Landroid/support/v4/app/ListFragment;->ensureList()V
    0003: iget v0, v2.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    0005: invoke-virtual {v0}, Landroid/widget/ListView;->getSelectedItemId()J
    0008: move-result-wide v0
    0009: return-wide v0

  [Virtual Method] getSelectedItemPosition() -> I
    // registers=2, ins=1, outs=1, insns_size=10
    0000: invoke-direct {v1}, Landroid/support/v4/app/ListFragment;->ensureList()V
    0003: iget v0, v1.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    0005: invoke-virtual {v0}, Landroid/widget/ListView;->getSelectedItemPosition()I
    0008: move-result v0
    0009: return v0

  [Virtual Method] onCreateView(Landroid/view/LayoutInflater;, Landroid/view/ViewGroup;, Landroid/os/Bundle;) -> Landroid/view/View;
    // registers=13, ins=4, outs=4, insns_size=142
    0000: const/16 v8, 17 (0x11)
    0002: const/4 v7, -2
    0003: const/4 v6, -1
    0004: invoke-virtual {v9}, Landroid/support/v4/app/ListFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0007: move-result-object v0
    0008: new-instance v1, Landroid/widget/FrameLayout;
    000a: invoke-direct {v1, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V
    000d: new-instance v2, Landroid/widget/LinearLayout;
    000f: invoke-direct {v2, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V
    0012: const v3, 16711682 (0xff0002)
    0015: invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setId(I)V
    0018: const/4 v3, 1
    0019: invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V
    001c: const/16 v3, 8 (0x8)
    001e: invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V
    0021: invoke-virtual {v2, v8}, Landroid/widget/LinearLayout;->setGravity(I)V
    0024: new-instance v3, Landroid/widget/ProgressBar;
    0026: const/4 v4, 0
    0027: const v5, 16842874 (0x101007a)
    002a: invoke-direct {v3, v0, v4, v5}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    002d: new-instance v4, Landroid/widget/FrameLayout$LayoutParams;
    002f: invoke-direct {v4, v7, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V
    0032: invoke-virtual {v2, v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    0035: new-instance v3, Landroid/widget/FrameLayout$LayoutParams;
    0037: invoke-direct {v3, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V
    003a: invoke-virtual {v1, v2, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    003d: new-instance v2, Landroid/widget/FrameLayout;
    003f: invoke-direct {v2, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V
    0042: const v0, 16711683 (0xff0003)
    0045: invoke-virtual {v2, v0}, Landroid/widget/FrameLayout;->setId(I)V
    0048: new-instance v0, Landroid/widget/TextView;
    004a: invoke-virtual {v9}, Landroid/support/v4/app/ListFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    004d: move-result-object v3
    004e: invoke-direct {v0, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V
    0051: const v3, 16711681 (0xff0001)
    0054: invoke-virtual {v0, v3}, Landroid/widget/TextView;->setId(I)V
    0057: invoke-virtual {v0, v8}, Landroid/widget/TextView;->setGravity(I)V
    005a: new-instance v3, Landroid/widget/FrameLayout$LayoutParams;
    005c: invoke-direct {v3, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V
    005f: invoke-virtual {v2, v0, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    0062: new-instance v0, Landroid/widget/ListView;
    0064: invoke-virtual {v9}, Landroid/support/v4/app/ListFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;
    0067: move-result-object v3
    0068: invoke-direct {v0, v3}, Landroid/widget/ListView;-><init>(Landroid/content/Context;)V
    006b: const v3, 16908298 (0x102000a)
    006e: invoke-virtual {v0, v3}, Landroid/widget/ListView;->setId(I)V
    0071: const/4 v3, 0
    0072: invoke-virtual {v0, v3}, Landroid/widget/ListView;->setDrawSelectorOnTop(Z)V
    0075: new-instance v3, Landroid/widget/FrameLayout$LayoutParams;
    0077: invoke-direct {v3, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V
    007a: invoke-virtual {v2, v0, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    007d: new-instance v0, Landroid/widget/FrameLayout$LayoutParams;
    007f: invoke-direct {v0, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V
    0082: invoke-virtual {v1, v2, v0}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    0085: new-instance v0, Landroid/widget/FrameLayout$LayoutParams;
    0087: invoke-direct {v0, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V
    008a: invoke-virtual {v1, v0}, Landroid/widget/FrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    008d: return-object v1

  [Virtual Method] onDestroyView() -> V
    // registers=4, ins=1, outs=2, insns_size=25
    0000: const/4 v2, 0
    0001: iget v0, v3.Landroid/support/v4/app/ListFragment;->mHandler:Landroid/os/Handler;
    0003: iget v1, v3.Landroid/support/v4/app/ListFragment;->mRequestFocus:Ljava/lang/Runnable;
    0005: invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    0008: iput v2, v3.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    000a: const/4 v0, 0
    000b: iput v0, v3.Landroid/support/v4/app/ListFragment;->mListShown:Z
    000d: iput v2, v3.Landroid/support/v4/app/ListFragment;->mListContainer:Landroid/view/View;
    000f: iput v2, v3.Landroid/support/v4/app/ListFragment;->mProgressContainer:Landroid/view/View;
    0011: iput v2, v3.Landroid/support/v4/app/ListFragment;->mEmptyView:Landroid/view/View;
    0013: iput v2, v3.Landroid/support/v4/app/ListFragment;->mStandardEmptyView:Landroid/widget/TextView;
    0015: invoke-super {v3}, Landroid/support/v4/app/Fragment;->onDestroyView()V
    0018: return-void

  [Virtual Method] onListItemClick(Landroid/widget/ListView;, Landroid/view/View;, I, J) -> V
    // registers=6, ins=6, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] onViewCreated(Landroid/view/View;, Landroid/os/Bundle;) -> V
    // registers=3, ins=3, outs=3, insns_size=7
    0000: invoke-super {v0, v1, v2}, Landroid/support/v4/app/Fragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    0003: invoke-direct {v0}, Landroid/support/v4/app/ListFragment;->ensureList()V
    0006: return-void

  [Virtual Method] setEmptyText(Ljava/lang/CharSequence;) -> V
    // registers=4, ins=2, outs=2, insns_size=34
    0000: invoke-direct {v2}, Landroid/support/v4/app/ListFragment;->ensureList()V
    0003: iget v0, v2.Landroid/support/v4/app/ListFragment;->mStandardEmptyView:Landroid/widget/TextView;
    0005: if-nez v0, 000f
    0007: new-instance v0, Ljava/lang/IllegalStateException;
    0009: const-string v1, "Can't be used with a custom content view"
    000b: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    000e: throw v0
    000f: iget v0, v2.Landroid/support/v4/app/ListFragment;->mStandardEmptyView:Landroid/widget/TextView;
    0011: invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    0014: iget v0, v2.Landroid/support/v4/app/ListFragment;->mEmptyText:Ljava/lang/CharSequence;
    0016: if-nez v0, 001f
    0018: iget v0, v2.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    001a: iget v1, v2.Landroid/support/v4/app/ListFragment;->mStandardEmptyView:Landroid/widget/TextView;
    001c: invoke-virtual {v0, v1}, Landroid/widget/ListView;->setEmptyView(Landroid/view/View;)V
    001f: iput v3, v2.Landroid/support/v4/app/ListFragment;->mEmptyText:Ljava/lang/CharSequence;
    0021: return-void

  [Virtual Method] setListAdapter(Landroid/widget/ListAdapter;) -> V
    // registers=6, ins=2, outs=3, insns_size=41
    0000: const/4 v2, 0
    0001: const/4 v1, 1
    0002: iget v0, v4.Landroid/support/v4/app/ListFragment;->mAdapter:Landroid/widget/ListAdapter;
    0004: if-eqz v0, 0027
    0006: move(op=01) v0, v1
    0007: iput v5, v4.Landroid/support/v4/app/ListFragment;->mAdapter:Landroid/widget/ListAdapter;
    0009: iget v3, v4.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    000b: if-eqz v3, 0026
    000d: iget v3, v4.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    000f: invoke-virtual {v3, v5}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V
    0012: iget v3, v4.Landroid/support/v4/app/ListFragment;->mListShown:Z
    0014: if-nez v3, 0026
    0016: if-nez v0, 0026
    0018: invoke-virtual {v4}, Landroid/support/v4/app/ListFragment;->getView()Landroid/view/View;
    001b: move-result-object v0
    001c: invoke-virtual {v0}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;
    001f: move-result-object v0
    0020: if-eqz v0, 0023
    0022: move(op=01) v2, v1
    0023: invoke-direct {v4, v1, v2}, Landroid/support/v4/app/ListFragment;->setListShown(ZZ)V
    0026: return-void
    0027: move(op=01) v0, v2
    0028: goto 0007

  [Virtual Method] setListShown(Z) -> V
    // registers=3, ins=2, outs=3, insns_size=5
    0000: const/4 v0, 1
    0001: invoke-direct {v1, v2, v0}, Landroid/support/v4/app/ListFragment;->setListShown(ZZ)V
    0004: return-void

  [Virtual Method] setListShownNoAnimation(Z) -> V
    // registers=3, ins=2, outs=3, insns_size=5
    0000: const/4 v0, 0
    0001: invoke-direct {v1, v2, v0}, Landroid/support/v4/app/ListFragment;->setListShown(ZZ)V
    0004: return-void

  [Virtual Method] setSelection(I) -> V
    // registers=3, ins=2, outs=2, insns_size=9
    0000: invoke-direct {v1}, Landroid/support/v4/app/ListFragment;->ensureList()V
    0003: iget v0, v1.Landroid/support/v4/app/ListFragment;->mList:Landroid/widget/ListView;
    0005: invoke-virtual {v0, v2}, Landroid/widget/ListView;->setSelection(I)V
    0008: return-void