=== CLASS Landroid/support/v4/view/PagerAdapter; (Source: PagerAdapter.java) ===
  Super: Ljava/lang/Object;
  [Static Field] POSITION_NONE: I = -2
  [Static Field] POSITION_UNCHANGED: I = -1
  [Instance Field] mObservable: Landroid/database/DataSetObservable;

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=1, insns_size=11
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: new-instance v0, Landroid/database/DataSetObservable;
    0005: invoke-direct {v0}, Landroid/database/DataSetObservable;-><init>()V
    0008: iput v0, v1.Landroid/support/v4/view/PagerAdapter;->mObservable:Landroid/database/DataSetObservable;
    000a: return-void

  [Virtual Method] destroyItem(Landroid/view/View;, I, Ljava/lang/Object;) -> V
    // registers=6, ins=4, outs=2, insns_size=8
    0000: new-instance v0, Ljava/lang/UnsupportedOperationException;
    0002: const-string v1, 'Required method destroyItem was not overridden'
    0004: invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    0007: throw v0

  [Virtual Method] destroyItem(Landroid/view/ViewGroup;, I, Ljava/lang/Object;) -> V
    // registers=4, ins=4, outs=4, insns_size=4
    0000: invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/view/PagerAdapter;->destroyItem(Landroid/view/View;ILjava/lang/Object;)V
    0003: return-void

  [Virtual Method] finishUpdate(Landroid/view/View;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] finishUpdate(Landroid/view/ViewGroup;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/support/v4/view/PagerAdapter;->finishUpdate(Landroid/view/View;)V
    0003: return-void

  [Virtual Method] getCount() -> I

  [Virtual Method] getItemPosition(Ljava/lang/Object;) -> I
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, -1
    0001: return v0

  [Virtual Method] getPageTitle(I) -> Ljava/lang/CharSequence;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getPageWidth(I) -> F
    // registers=3, ins=2, outs=0, insns_size=3
    0000: const/high16 v0, 1065353216 (0x3f800000)
    0002: return v0

  [Virtual Method] instantiateItem(Landroid/view/View;, I) -> Ljava/lang/Object;
    // registers=5, ins=3, outs=2, insns_size=8
    0000: new-instance v0, Ljava/lang/UnsupportedOperationException;
    0002: const-string v1, 'Required method instantiateItem was not overridden'
    0004: invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V
    0007: throw v0

  [Virtual Method] instantiateItem(Landroid/view/ViewGroup;, I) -> Ljava/lang/Object;
    // registers=4, ins=3, outs=3, insns_size=5
    0000: invoke-virtual {v1, v2, v3}, Landroid/support/v4/view/PagerAdapter;->instantiateItem(Landroid/view/View;I)Ljava/lang/Object;
    0003: move-result-object v0
    0004: return-object v0

  [Virtual Method] isViewFromObject(Landroid/view/View;, Ljava/lang/Object;) -> Z

  [Virtual Method] notifyDataSetChanged() -> V
    // registers=2, ins=1, outs=1, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/view/PagerAdapter;->mObservable:Landroid/database/DataSetObservable;
    0002: invoke-virtual {v0}, Landroid/database/DataSetObservable;->notifyChanged()V
    0005: return-void

  [Virtual Method] registerDataSetObserver(Landroid/database/DataSetObserver;) -> V
    // registers=3, ins=2, outs=2, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/view/PagerAdapter;->mObservable:Landroid/database/DataSetObservable;
    0002: invoke-virtual {v0, v2}, Landroid/database/DataSetObservable;->registerObserver(Ljava/lang/Object;)V
    0005: return-void

  [Virtual Method] restoreState(Landroid/os/Parcelable;, Ljava/lang/ClassLoader;) -> V
    // registers=3, ins=3, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] saveState() -> Landroid/os/Parcelable;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] setPrimaryItem(Landroid/view/View;, I, Ljava/lang/Object;) -> V
    // registers=4, ins=4, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] setPrimaryItem(Landroid/view/ViewGroup;, I, Ljava/lang/Object;) -> V
    // registers=4, ins=4, outs=4, insns_size=4
    0000: invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/view/PagerAdapter;->setPrimaryItem(Landroid/view/View;ILjava/lang/Object;)V
    0003: return-void

  [Virtual Method] startUpdate(Landroid/view/View;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] startUpdate(Landroid/view/ViewGroup;) -> V
    // registers=2, ins=2, outs=2, insns_size=4
    0000: invoke-virtual {v0, v1}, Landroid/support/v4/view/PagerAdapter;->startUpdate(Landroid/view/View;)V
    0003: return-void

  [Virtual Method] unregisterDataSetObserver(Landroid/database/DataSetObserver;) -> V
    // registers=3, ins=2, outs=2, insns_size=6
    0000: iget v0, v1.Landroid/support/v4/view/PagerAdapter;->mObservable:Landroid/database/DataSetObservable;
    0002: invoke-virtual {v0, v2}, Landroid/database/DataSetObservable;->unregisterObserver(Ljava/lang/Object;)V
    0005: return-void