=== CLASS Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat; (Source: AccessibilityManagerCompat.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] mListener: Ljava/lang/Object;

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=2, insns_size=14
    0000: invoke-direct {v1}, Ljava/lang/Object;-><init>()V
    0003: invoke-static {}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompat;->access$000()Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerVersionImpl;
    0006: move-result-object v0
    0007: invoke-interface {v0, v1}, Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityManagerVersionImpl;->newAccessiblityStateChangeListener(Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;)Ljava/lang/Object;
    000a: move-result-object v0
    000b: iput v0, v1.Landroid/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat;->mListener:Ljava/lang/Object;
    000d: return-void

  [Virtual Method] onAccessibilityStateChanged(Z) -> V