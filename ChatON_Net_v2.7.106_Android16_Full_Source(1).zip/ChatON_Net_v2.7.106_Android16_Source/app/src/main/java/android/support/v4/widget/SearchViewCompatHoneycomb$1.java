=== CLASS Landroid/support/v4/widget/SearchViewCompatHoneycomb$1; (Source: SearchViewCompatHoneycomb.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/widget/SearchView$OnQueryTextListener;
  [Instance Field] val$listener: Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;

  [Direct Method] <init>(Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: iput v1, v0.Landroid/support/v4/widget/SearchViewCompatHoneycomb$1;->val$listener:Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;
    0002: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0005: return-void

  [Virtual Method] onQueryTextChange(Ljava/lang/String;) -> Z
    // registers=3, ins=2, outs=2, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/widget/SearchViewCompatHoneycomb$1;->val$listener:Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;
    0002: invoke-interface {v0, v2}, Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;->onQueryTextChange(Ljava/lang/String;)Z
    0005: move-result v0
    0006: return v0

  [Virtual Method] onQueryTextSubmit(Ljava/lang/String;) -> Z
    // registers=3, ins=2, outs=2, insns_size=7
    0000: iget v0, v1.Landroid/support/v4/widget/SearchViewCompatHoneycomb$1;->val$listener:Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;
    0002: invoke-interface {v0, v2}, Landroid/support/v4/widget/SearchViewCompatHoneycomb$OnQueryTextListenerCompatBridge;->onQueryTextSubmit(Ljava/lang/String;)Z
    0005: move-result v0
    0006: return v0