=== CLASS Landroid/os/IVoIPCallbackInterface$Stub$Proxy; (Source: IVoIPCallbackInterface.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/IVoIPCallbackInterface;
  [Instance Field] mRemote: Landroid/os/IBinder;

  [Direct Method] <init>(Landroid/os/IBinder;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Landroid/os/IVoIPCallbackInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0005: return-void

  [Virtual Method] answerVoIPCall() -> Z
    // registers=8, ins=1, outs=5, insns_size=48
    0000: const/4 v0, 1
    0001: const/4 v1, 0
    0002: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0005: move-result-object v2
    0006: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0009: move-result-object v3
    000a: const-string v4, 'android.os.IVoIPCallbackInterface'
    000c: invoke-virtual {v2, v4}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000f: iget v4, v7.Landroid/os/IVoIPCallbackInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0011: const/4 v5, 1
    0012: const/4 v6, 0
    0013: invoke-interface {v4, v5, v2, v3, v6}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0016: invoke-virtual {v3}, Landroid/os/Parcel;->readException()V
    0019: invoke-virtual {v3}, Landroid/os/Parcel;->readInt()I
    001c: move-result v4
    001d: if-eqz v4, 0026
    001f: invoke-virtual {v3}, Landroid/os/Parcel;->recycle()V
    0022: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0025: return v0
    0026: move(op=01) v0, v1
    0027: goto 001f
    0028: move-exception v0
    0029: invoke-virtual {v3}, Landroid/os/Parcel;->recycle()V
    002c: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002f: throw v0

  [Virtual Method] asBinder() -> Landroid/os/IBinder;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/os/IVoIPCallbackInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0002: return-object v0

  [Virtual Method] getInterfaceDescriptor() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: const-string v0, 'android.os.IVoIPCallbackInterface'
    0002: return-object v0

  [Virtual Method] hangupVoIPCall() -> Z
    // registers=7, ins=1, outs=5, insns_size=46
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPCallbackInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPCallbackInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/4 v4, 2
    0011: const/4 v5, 0
    0012: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001b: move-result v3
    001c: if-eqz v3, 001f
    001e: const/4 v0, 1
    001f: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0022: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0025: return v0
    0026: move-exception v0
    0027: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002a: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002d: throw v0

  [Virtual Method] holdVoIPCall() -> Z
    // registers=7, ins=1, outs=5, insns_size=46
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPCallbackInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPCallbackInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/4 v4, 4
    0011: const/4 v5, 0
    0012: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001b: move-result v3
    001c: if-eqz v3, 001f
    001e: const/4 v0, 1
    001f: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0022: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0025: return v0
    0026: move-exception v0
    0027: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002a: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002d: throw v0

  [Virtual Method] moveVoIPToTop() -> Z
    // registers=7, ins=1, outs=5, insns_size=46
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPCallbackInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPCallbackInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/4 v4, 3
    0011: const/4 v5, 0
    0012: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001b: move-result v3
    001c: if-eqz v3, 001f
    001e: const/4 v0, 1
    001f: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0022: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0025: return v0
    0026: move-exception v0
    0027: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002a: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002d: throw v0

  [Virtual Method] resumeVoIPCall() -> Z
    // registers=7, ins=1, outs=5, insns_size=46
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPCallbackInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPCallbackInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/4 v4, 5
    0011: const/4 v5, 0
    0012: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001b: move-result v3
    001c: if-eqz v3, 001f
    001e: const/4 v0, 1
    001f: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0022: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0025: return v0
    0026: move-exception v0
    0027: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002a: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002d: throw v0