=== CLASS Landroid/os/ServiceManagerProxy; (Source: ServiceManagerNative.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/IServiceManager;
  [Instance Field] mRemote: Landroid/os/IBinder;

  [Direct Method] <init>(Landroid/os/IBinder;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Landroid/os/ServiceManagerProxy;->mRemote:Landroid/os/IBinder;
    0005: return-void

  [Virtual Method] addService(Ljava/lang/String;, Landroid/os/IBinder;) -> V
    // registers=8, ins=3, outs=5, insns_size=33
    0000: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0003: move-result-object v0
    0004: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0007: move-result-object v1
    0008: const-string v2, 'android.os.IServiceManager'
    000a: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000d: invoke-virtual {v0, v6}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0010: invoke-virtual {v0, v7}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V
    0013: iget v2, v5.Landroid/os/ServiceManagerProxy;->mRemote:Landroid/os/IBinder;
    0015: const/4 v3, 3
    0016: const/4 v4, 0
    0017: invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    001a: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    001d: invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V
    0020: return-void

  [Virtual Method] asBinder() -> Landroid/os/IBinder;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/os/ServiceManagerProxy;->mRemote:Landroid/os/IBinder;
    0002: return-object v0

  [Virtual Method] checkService(Ljava/lang/String;) -> Landroid/os/IBinder;
    // registers=7, ins=2, outs=5, insns_size=34
    0000: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0003: move-result-object v0
    0004: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0007: move-result-object v1
    0008: const-string v2, 'android.os.IServiceManager'
    000a: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000d: invoke-virtual {v0, v6}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0010: iget v2, v5.Landroid/os/ServiceManagerProxy;->mRemote:Landroid/os/IBinder;
    0012: const/4 v3, 2
    0013: const/4 v4, 0
    0014: invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0017: invoke-virtual {v1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;
    001a: move-result-object v2
    001b: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    001e: invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V
    0021: return-object v2

  [Virtual Method] getService(Ljava/lang/String;) -> Landroid/os/IBinder;
    // registers=7, ins=2, outs=5, insns_size=34
    0000: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0003: move-result-object v0
    0004: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0007: move-result-object v1
    0008: const-string v2, 'android.os.IServiceManager'
    000a: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000d: invoke-virtual {v0, v6}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0010: iget v2, v5.Landroid/os/ServiceManagerProxy;->mRemote:Landroid/os/IBinder;
    0012: const/4 v3, 1
    0013: const/4 v4, 0
    0014: invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0017: invoke-virtual {v1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;
    001a: move-result-object v2
    001b: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    001e: invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V
    0021: return-object v2

  [Virtual Method] listServices() -> [Ljava/lang/String;
    // registers=6, ins=1, outs=5, insns_size=31
    0000: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0003: move-result-object v0
    0004: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0007: move-result-object v1
    0008: const-string v2, 'android.os.IServiceManager'
    000a: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000d: iget v2, v5.Landroid/os/ServiceManagerProxy;->mRemote:Landroid/os/IBinder;
    000f: const/4 v3, 4
    0010: const/4 v4, 0
    0011: invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0014: invoke-virtual {v1}, Landroid/os/Parcel;->readStringArray()[Ljava/lang/String;
    0017: move-result-object v2
    0018: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    001b: invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V
    001e: return-object v2

  [Virtual Method] setPermissionController(Landroid/os/IPermissionController;) -> V
    // registers=7, ins=2, outs=5, insns_size=34
    0000: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0003: move-result-object v0
    0004: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0007: move-result-object v1
    0008: const-string v2, 'android.os.IServiceManager'
    000a: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000d: invoke-interface {v6}, Landroid/os/IPermissionController;->asBinder()Landroid/os/IBinder;
    0010: move-result-object v2
    0011: invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V
    0014: iget v2, v5.Landroid/os/ServiceManagerProxy;->mRemote:Landroid/os/IBinder;
    0016: const/4 v3, 6
    0017: const/4 v4, 0
    0018: invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    001b: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    001e: invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V
    0021: return-void