=== CLASS Landroid/os/ServiceManager; (Source: ServiceManager.java) ===
  Super: Ljava/lang/Object;
  [Static Field] TAG: Ljava/lang/String; = 'ServiceManager'
  [Static Field] sCache: Ljava/util/HashMap;
  [Static Field] sServiceManager: Landroid/os/IServiceManager;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=1, insns_size=8
    0000: new-instance v0, Ljava/util/HashMap;
    0002: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    0005: sput v0, Landroid/os/ServiceManager;->sCache:Ljava/util/HashMap;
    0007: return-void

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Direct Method] addService(Ljava/lang/String;, Landroid/os/IBinder;) -> V
    // registers=5, ins=2, outs=3, insns_size=17
    0000: invoke-static {}, Landroid/os/ServiceManager;->getIServiceManager()Landroid/os/IServiceManager;
    0003: move-result-object v0
    0004: invoke-interface {v0, v3, v4}, Landroid/os/IServiceManager;->addService(Ljava/lang/String;Landroid/os/IBinder;)V
    0007: return-void
    0008: move-exception v0
    0009: const-string v1, 'ServiceManager'
    000b: const-string v2, 'error in addService'
    000d: invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    0010: goto 0007

  [Direct Method] checkService(Ljava/lang/String;) -> Landroid/os/IBinder;
    // registers=4, ins=1, outs=3, insns_size=30
    0000: sget v0, Landroid/os/ServiceManager;->sCache:Ljava/util/HashMap;
    0002: invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/os/IBinder;
    0008: if-eqz v0, 000b
    000a: return-object v0
    000b: invoke-static {}, Landroid/os/ServiceManager;->getIServiceManager()Landroid/os/IServiceManager;
    000e: move-result-object v0
    000f: invoke-interface {v0, v3}, Landroid/os/IServiceManager;->checkService(Ljava/lang/String;)Landroid/os/IBinder;
    0012: move-result-object v0
    0013: goto 000a
    0014: move-exception v0
    0015: const-string v1, 'ServiceManager'
    0017: const-string v2, 'error in checkService'
    0019: invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    001c: const/4 v0, 0
    001d: goto 000a

  [Direct Method] getIServiceManager() -> Landroid/os/IServiceManager;
    // registers=1, ins=0, outs=1, insns_size=20
    0000: sget v0, Landroid/os/ServiceManager;->sServiceManager:Landroid/os/IServiceManager;
    0002: if-eqz v0, 0007
    0004: sget v0, Landroid/os/ServiceManager;->sServiceManager:Landroid/os/IServiceManager;
    0006: return-object v0
    0007: invoke-static {}, Lcom/android/internal/os/BinderInternal;->getContextObject()Landroid/os/IBinder;
    000a: move-result-object v0
    000b: invoke-static {v0}, Landroid/os/ServiceManagerNative;->asInterface(Landroid/os/IBinder;)Landroid/os/IServiceManager;
    000e: move-result-object v0
    000f: sput v0, Landroid/os/ServiceManager;->sServiceManager:Landroid/os/IServiceManager;
    0011: sget v0, Landroid/os/ServiceManager;->sServiceManager:Landroid/os/IServiceManager;
    0013: goto 0006

  [Direct Method] getService(Ljava/lang/String;) -> Landroid/os/IBinder;
    // registers=4, ins=1, outs=3, insns_size=30
    0000: sget v0, Landroid/os/ServiceManager;->sCache:Ljava/util/HashMap;
    0002: invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/os/IBinder;
    0008: if-eqz v0, 000b
    000a: return-object v0
    000b: invoke-static {}, Landroid/os/ServiceManager;->getIServiceManager()Landroid/os/IServiceManager;
    000e: move-result-object v0
    000f: invoke-interface {v0, v3}, Landroid/os/IServiceManager;->getService(Ljava/lang/String;)Landroid/os/IBinder;
    0012: move-result-object v0
    0013: goto 000a
    0014: move-exception v0
    0015: const-string v1, 'ServiceManager'
    0017: const-string v2, 'error in getService'
    0019: invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    001c: const/4 v0, 0
    001d: goto 000a

  [Direct Method] initServiceCache(Ljava/util/Map;) -> V
    // registers=3, ins=1, outs=2, insns_size=28
    0000: sget v0, Landroid/os/ServiceManager;->sCache:Ljava/util/HashMap;
    0002: invoke-virtual {v0}, Ljava/util/HashMap;->size()I
    0005: move-result v0
    0006: if-eqz v0, 0016
    0008: invoke-static {}, Landroid/os/Process;->supportsProcesses()Z
    000b: move-result v0
    000c: if-eqz v0, 0016
    000e: new-instance v0, Ljava/lang/IllegalStateException;
    0010: const-string v1, 'setServiceCache may only be called once'
    0012: invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V
    0015: throw v0
    0016: sget v0, Landroid/os/ServiceManager;->sCache:Ljava/util/HashMap;
    0018: invoke-virtual {v0, v2}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V
    001b: return-void

  [Direct Method] listServices() -> [Ljava/lang/String;
    // registers=3, ins=0, outs=3, insns_size=19
    0000: invoke-static {}, Landroid/os/ServiceManager;->getIServiceManager()Landroid/os/IServiceManager;
    0003: move-result-object v0
    0004: invoke-interface {v0}, Landroid/os/IServiceManager;->listServices()[Ljava/lang/String;
    0007: move-result-object v0
    0008: return-object v0
    0009: move-exception v0
    000a: const-string v1, 'ServiceManager'
    000c: const-string v2, 'error in listServices'
    000e: invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    0011: const/4 v0, 0
    0012: goto 0008