=== CLASS Landroid/os/IVoIPInterface$Stub; (Source: IVoIPInterface.java) ===
  Super: Landroid/os/Binder;
  Interfaces: Landroid/os/IVoIPInterface;
  [Static Field] DESCRIPTOR: Ljava/lang/String; = 'android.os.IVoIPInterface'
  [Static Field] TRANSACTION_answerVoIPCall: I = 4
  [Static Field] TRANSACTION_callInVoIP: I = 26
  [Static Field] TRANSACTION_canUseBTInVoIP: I = 18
  [Static Field] TRANSACTION_createCallSession: I = 1
  [Static Field] TRANSACTION_destroyCallSession: I = 2
  [Static Field] TRANSACTION_dumpCallSessionInfoDB: I = 28
  [Static Field] TRANSACTION_getCurrentVoIPNumber: I = 25
  [Static Field] TRANSACTION_getSessionCount: I = 27
  [Static Field] TRANSACTION_getVoIPCallCount: I = 9
  [Static Field] TRANSACTION_hangupVoIPCall: I = 5
  [Static Field] TRANSACTION_holdVoIPCall: I = 6
  [Static Field] TRANSACTION_isVoIPActivated: I = 24
  [Static Field] TRANSACTION_isVoIPDialing: I = 23
  [Static Field] TRANSACTION_isVoIPIdle: I = 20
  [Static Field] TRANSACTION_isVoIPRingOrDialing: I = 21
  [Static Field] TRANSACTION_isVoIPRinging: I = 22
  [Static Field] TRANSACTION_moveVoIPToTop: I = 3
  [Static Field] TRANSACTION_resumeVoIPCall: I = 7
  [Static Field] TRANSACTION_setBTUserWantsAudioOn: I = 19
  [Static Field] TRANSACTION_setEngMode: I = 29
  [Static Field] TRANSACTION_setUseBTInVoIP: I = 17
  [Static Field] TRANSACTION_setVoIPActive: I = 13
  [Static Field] TRANSACTION_setVoIPCallCount: I = 8
  [Static Field] TRANSACTION_setVoIPDialing: I = 12
  [Static Field] TRANSACTION_setVoIPDisconnected: I = 16
  [Static Field] TRANSACTION_setVoIPDisconnecting: I = 15
  [Static Field] TRANSACTION_setVoIPHolding: I = 14
  [Static Field] TRANSACTION_setVoIPIdle: I = 10
  [Static Field] TRANSACTION_setVoIPRinging: I = 11

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=3, insns_size=9
    0000: invoke-direct {v1}, Landroid/os/Binder;-><init>()V
    0003: const-string v0, 'android.os.IVoIPInterface'
    0005: invoke-virtual {v1, v1, v0}, Landroid/os/IVoIPInterface$Stub;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V
    0008: return-void

  [Direct Method] asInterface(Landroid/os/IBinder;) -> Landroid/os/IVoIPInterface;
    // registers=3, ins=1, outs=2, insns_size=25
    0000: if-nez v2, 0004
    0002: const/4 v0, 0
    0003: return-object v0
    0004: const-string v0, 'android.os.IVoIPInterface'
    0006: invoke-interface {v2, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;
    0009: move-result-object v0
    000a: if-eqz v0, 0013
    000c: instance-of v1, v0, Landroid/os/IVoIPInterface;
    000e: if-eqz v1, 0013
    0010: check-cast v0, Landroid/os/IVoIPInterface;
    0012: goto 0003
    0013: new-instance v0, Landroid/os/IVoIPInterface$Stub$Proxy;
    0015: invoke-direct {v0, v2}, Landroid/os/IVoIPInterface$Stub$Proxy;-><init>(Landroid/os/IBinder;)V
    0018: goto 0003

  [Virtual Method] asBinder() -> Landroid/os/IBinder;
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-object v0

  [Virtual Method] onTransact(I, Landroid/os/Parcel;, Landroid/os/Parcel;, I) -> Z
    // registers=11, ins=5, outs=5, insns_size=790
    0000: const/4 v0, 0
    0001: const/4 v1, 1
    0002: sparse-switch v7, +666 (-> 029c)
    0005: invoke-super {v6, v7, v8, v9, v10}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0008: move-result v1
    0009: return v1
    000a: const-string v0, 'android.os.IVoIPInterface'
    000c: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    000f: goto 0009
    0010: const-string v2, 'android.os.IVoIPInterface'
    0012: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0015: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0018: move-result-object v2
    0019: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    001c: move-result-object v3
    001d: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0020: move-result-object v4
    0021: invoke-virtual {v8}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;
    0024: move-result-object v5
    0025: invoke-static {v5}, Landroid/os/IVoIPCallbackInterface$Stub;->asInterface(Landroid/os/IBinder;)Landroid/os/IVoIPCallbackInterface;
    0028: move-result-object v5
    0029: invoke-virtual {v6, v2, v3, v4, v5}, Landroid/os/IVoIPInterface$Stub;->createCallSession(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/IVoIPCallbackInterface;)Z
    002c: move-result v2
    002d: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0030: if-eqz v2, 0033
    0032: move(op=01) v0, v1
    0033: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0036: goto 0009
    0037: const-string v2, 'android.os.IVoIPInterface'
    0039: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    003c: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    003f: move-result-object v2
    0040: invoke-virtual {v6, v2}, Landroid/os/IVoIPInterface$Stub;->destroyCallSession(Ljava/lang/String;)Z
    0043: move-result v2
    0044: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0047: if-eqz v2, 004a
    0049: move(op=01) v0, v1
    004a: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    004d: goto 0009
    004e: const-string v2, 'android.os.IVoIPInterface'
    0050: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0053: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->moveVoIPToTop()Z
    0056: move-result v2
    0057: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    005a: if-eqz v2, 005d
    005c: move(op=01) v0, v1
    005d: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0060: goto 0009
    0061: const-string v2, 'android.os.IVoIPInterface'
    0063: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0066: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->answerVoIPCall()Z
    0069: move-result v2
    006a: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    006d: if-eqz v2, 0070
    006f: move(op=01) v0, v1
    0070: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0073: goto 0009
    0074: const-string v2, 'android.os.IVoIPInterface'
    0076: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0079: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->hangupVoIPCall()Z
    007c: move-result v2
    007d: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0080: if-eqz v2, 0083
    0082: move(op=01) v0, v1
    0083: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0086: goto 0009
    0087: const-string v2, 'android.os.IVoIPInterface'
    0089: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    008c: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->holdVoIPCall()Z
    008f: move-result v2
    0090: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0093: if-eqz v2, 0096
    0095: move(op=01) v0, v1
    0096: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0099: goto/16 0009
    009b: const-string v2, 'android.os.IVoIPInterface'
    009d: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    00a0: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->resumeVoIPCall()Z
    00a3: move-result v2
    00a4: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    00a7: if-eqz v2, 00aa
    00a9: move(op=01) v0, v1
    00aa: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    00ad: goto/16 0009
    00af: const-string v2, 'android.os.IVoIPInterface'
    00b1: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    00b4: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    00b7: move-result-object v2
    00b8: invoke-virtual {v8}, Landroid/os/Parcel;->readInt()I
    00bb: move-result v3
    00bc: invoke-virtual {v6, v2, v3}, Landroid/os/IVoIPInterface$Stub;->setVoIPCallCount(Ljava/lang/String;I)Z
    00bf: move-result v2
    00c0: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    00c3: if-eqz v2, 00c6
    00c5: move(op=01) v0, v1
    00c6: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    00c9: goto/16 0009
    00cb: const-string v0, 'android.os.IVoIPInterface'
    00cd: invoke-virtual {v8, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    00d0: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    00d3: move-result-object v0
    00d4: invoke-virtual {v6, v0}, Landroid/os/IVoIPInterface$Stub;->getVoIPCallCount(Ljava/lang/String;)I
    00d7: move-result v0
    00d8: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    00db: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    00de: goto/16 0009
    00e0: const-string v2, 'android.os.IVoIPInterface'
    00e2: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    00e5: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    00e8: move-result-object v2
    00e9: invoke-virtual {v6, v2}, Landroid/os/IVoIPInterface$Stub;->setVoIPIdle(Ljava/lang/String;)Z
    00ec: move-result v2
    00ed: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    00f0: if-eqz v2, 00f3
    00f2: move(op=01) v0, v1
    00f3: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    00f6: goto/16 0009
    00f8: const-string v2, 'android.os.IVoIPInterface'
    00fa: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    00fd: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0100: move-result-object v2
    0101: invoke-virtual {v6, v2}, Landroid/os/IVoIPInterface$Stub;->setVoIPRinging(Ljava/lang/String;)Z
    0104: move-result v2
    0105: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0108: if-eqz v2, 010b
    010a: move(op=01) v0, v1
    010b: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    010e: goto/16 0009
    0110: const-string v2, 'android.os.IVoIPInterface'
    0112: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0115: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0118: move-result-object v2
    0119: invoke-virtual {v6, v2}, Landroid/os/IVoIPInterface$Stub;->setVoIPDialing(Ljava/lang/String;)Z
    011c: move-result v2
    011d: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0120: if-eqz v2, 0123
    0122: move(op=01) v0, v1
    0123: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0126: goto/16 0009
    0128: const-string v2, 'android.os.IVoIPInterface'
    012a: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    012d: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0130: move-result-object v2
    0131: invoke-virtual {v6, v2}, Landroid/os/IVoIPInterface$Stub;->setVoIPActive(Ljava/lang/String;)Z
    0134: move-result v2
    0135: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0138: if-eqz v2, 013b
    013a: move(op=01) v0, v1
    013b: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    013e: goto/16 0009
    0140: const-string v2, 'android.os.IVoIPInterface'
    0142: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0145: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0148: move-result-object v2
    0149: invoke-virtual {v6, v2}, Landroid/os/IVoIPInterface$Stub;->setVoIPHolding(Ljava/lang/String;)Z
    014c: move-result v2
    014d: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0150: if-eqz v2, 0153
    0152: move(op=01) v0, v1
    0153: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0156: goto/16 0009
    0158: const-string v2, 'android.os.IVoIPInterface'
    015a: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    015d: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0160: move-result-object v2
    0161: invoke-virtual {v6, v2}, Landroid/os/IVoIPInterface$Stub;->setVoIPDisconnecting(Ljava/lang/String;)Z
    0164: move-result v2
    0165: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0168: if-eqz v2, 016b
    016a: move(op=01) v0, v1
    016b: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    016e: goto/16 0009
    0170: const-string v2, 'android.os.IVoIPInterface'
    0172: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0175: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0178: move-result-object v2
    0179: invoke-virtual {v6, v2}, Landroid/os/IVoIPInterface$Stub;->setVoIPDisconnected(Ljava/lang/String;)Z
    017c: move-result v2
    017d: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0180: if-eqz v2, 0183
    0182: move(op=01) v0, v1
    0183: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0186: goto/16 0009
    0188: const-string v2, 'android.os.IVoIPInterface'
    018a: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    018d: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0190: move-result-object v3
    0191: invoke-virtual {v8}, Landroid/os/Parcel;->readInt()I
    0194: move-result v2
    0195: if-eqz v2, 01a7
    0197: move(op=01) v2, v1
    0198: invoke-virtual {v6, v3, v2}, Landroid/os/IVoIPInterface$Stub;->setUseBTInVoIP(Ljava/lang/String;Z)Z
    019b: move-result v2
    019c: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    019f: if-eqz v2, 01a2
    01a1: move(op=01) v0, v1
    01a2: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    01a5: goto/16 0009
    01a7: move(op=01) v2, v0
    01a8: goto 0198
    01a9: const-string v2, 'android.os.IVoIPInterface'
    01ab: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    01ae: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    01b1: move-result-object v2
    01b2: invoke-virtual {v6, v2}, Landroid/os/IVoIPInterface$Stub;->canUseBTInVoIP(Ljava/lang/String;)Z
    01b5: move-result v2
    01b6: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    01b9: if-eqz v2, 01bc
    01bb: move(op=01) v0, v1
    01bc: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    01bf: goto/16 0009
    01c1: const-string v2, 'android.os.IVoIPInterface'
    01c3: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    01c6: invoke-virtual {v8}, Landroid/os/Parcel;->readInt()I
    01c9: move-result v2
    01ca: if-eqz v2, 01dc
    01cc: move(op=01) v2, v1
    01cd: invoke-virtual {v6, v2}, Landroid/os/IVoIPInterface$Stub;->setBTUserWantsAudioOn(Z)Z
    01d0: move-result v2
    01d1: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    01d4: if-eqz v2, 01d7
    01d6: move(op=01) v0, v1
    01d7: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    01da: goto/16 0009
    01dc: move(op=01) v2, v0
    01dd: goto 01cd
    01de: const-string v2, 'android.os.IVoIPInterface'
    01e0: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    01e3: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->isVoIPIdle()Z
    01e6: move-result v2
    01e7: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    01ea: if-eqz v2, 01ed
    01ec: move(op=01) v0, v1
    01ed: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    01f0: goto/16 0009
    01f2: const-string v2, 'android.os.IVoIPInterface'
    01f4: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    01f7: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->isVoIPRingOrDialing()Z
    01fa: move-result v2
    01fb: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    01fe: if-eqz v2, 0201
    0200: move(op=01) v0, v1
    0201: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0204: goto/16 0009
    0206: const-string v2, 'android.os.IVoIPInterface'
    0208: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    020b: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->isVoIPRinging()Z
    020e: move-result v2
    020f: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0212: if-eqz v2, 0215
    0214: move(op=01) v0, v1
    0215: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0218: goto/16 0009
    021a: const-string v2, 'android.os.IVoIPInterface'
    021c: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    021f: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->isVoIPDialing()Z
    0222: move-result v2
    0223: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0226: if-eqz v2, 0229
    0228: move(op=01) v0, v1
    0229: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    022c: goto/16 0009
    022e: const-string v2, 'android.os.IVoIPInterface'
    0230: invoke-virtual {v8, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0233: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->isVoIPActivated()Z
    0236: move-result v2
    0237: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    023a: if-eqz v2, 023d
    023c: move(op=01) v0, v1
    023d: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0240: goto/16 0009
    0242: const-string v0, 'android.os.IVoIPInterface'
    0244: invoke-virtual {v8, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0247: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->getCurrentVoIPNumber()Ljava/lang/String;
    024a: move-result-object v0
    024b: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    024e: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0251: goto/16 0009
    0253: const-string v0, 'android.os.IVoIPInterface'
    0255: invoke-virtual {v8, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0258: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    025b: move-result-object v0
    025c: invoke-virtual {v6, v0}, Landroid/os/IVoIPInterface$Stub;->callInVoIP(Ljava/lang/String;)V
    025f: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0262: goto/16 0009
    0264: const-string v0, 'android.os.IVoIPInterface'
    0266: invoke-virtual {v8, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0269: invoke-virtual {v6}, Landroid/os/IVoIPInterface$Stub;->getSessionCount()I
    026c: move-result v0
    026d: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0270: invoke-virtual {v9, v0}, Landroid/os/Parcel;->writeInt(I)V
    0273: goto/16 0009
    0275: const-string v0, 'android.os.IVoIPInterface'
    0277: invoke-virtual {v8, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    027a: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    027d: move-result-object v0
    027e: invoke-virtual {v6, v0}, Landroid/os/IVoIPInterface$Stub;->dumpCallSessionInfoDB(Ljava/lang/String;)V
    0281: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0284: goto/16 0009
    0286: const-string v0, 'android.os.IVoIPInterface'
    0288: invoke-virtual {v8, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    028b: invoke-virtual {v8}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    028e: move-result-object v0
    028f: invoke-virtual {v8}, Landroid/os/Parcel;->readInt()I
    0292: move-result v2
    0293: invoke-virtual {v6, v0, v2}, Landroid/os/IVoIPInterface$Stub;->setEngMode(Ljava/lang/String;I)V
    0296: invoke-virtual {v9}, Landroid/os/Parcel;->writeNoException()V
    0299: goto/16 0009
    029b: nop
    029c: sparse-switch-payload {1: 14, 2: 53, 3: 76, 4: 95, 5: 114, 6: 133, 7: 153, 8: 173, 9: 201, 10: 222, 11: 246, 12: 270, 13: 294, 14: 318, 15: 342, 16: 366, 17: 390, 18: 423, 19: 447, 20: 476, 21: 496, 22: 516, 23: 536, 24: 556, 25: 576, 26: 593, 27: 610, 28: 627, 29: 644, 1598968902: 8}