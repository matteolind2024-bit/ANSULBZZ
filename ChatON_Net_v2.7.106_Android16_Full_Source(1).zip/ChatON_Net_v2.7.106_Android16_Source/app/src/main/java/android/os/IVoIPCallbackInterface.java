=== CLASS Landroid/os/IVoIPCallbackInterface; (Source: IVoIPCallbackInterface.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/IInterface;

  [Virtual Method] answerVoIPCall() -> Z

  [Virtual Method] hangupVoIPCall() -> Z

  [Virtual Method] holdVoIPCall() -> Z

  [Virtual Method] moveVoIPToTop() -> Z

  [Virtual Method] resumeVoIPCall() -> Z