=== CLASS Landroid/os/ServiceManagerNative; (Source: ServiceManagerNative.java) ===
  Super: Landroid/os/Binder;
  Interfaces: Landroid/os/IServiceManager;

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=3, insns_size=9
    0000: invoke-direct {v1}, Landroid/os/Binder;-><init>()V
    0003: const-string v0, 'android.os.IServiceManager'
    0005: invoke-virtual {v1, v1, v0}, Landroid/os/ServiceManagerNative;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V
    0008: return-void

  [Direct Method] asInterface(Landroid/os/IBinder;) -> Landroid/os/IServiceManager;
    // registers=2, ins=1, outs=2, insns_size=20
    0000: if-nez v1, 0004
    0002: const/4 v0, 0
    0003: return-object v0
    0004: const-string v0, 'android.os.IServiceManager'
    0006: invoke-interface {v1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;
    0009: move-result-object v0
    000a: check-cast v0, Landroid/os/IServiceManager;
    000c: if-nez v0, 0003
    000e: new-instance v0, Landroid/os/ServiceManagerProxy;
    0010: invoke-direct {v0, v1}, Landroid/os/ServiceManagerProxy;-><init>(Landroid/os/IBinder;)V
    0013: goto 0003

  [Virtual Method] asBinder() -> Landroid/os/IBinder;
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-object v0

  [Virtual Method] onTransact(I, Landroid/os/Parcel;, Landroid/os/Parcel;, I) -> Z
    // registers=8, ins=5, outs=3, insns_size=106
    0000: const/4 v0, 1
    0001: packed-switch v4, +89 (-> 005a)
    0004: const/4 v0, 0
    0005: return v0
    0006: const-string v1, 'android.os.IServiceManager'
    0008: invoke-virtual {v5, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    000b: invoke-virtual {v5}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    000e: move-result-object v1
    000f: invoke-virtual {v3, v1}, Landroid/os/ServiceManagerNative;->getService(Ljava/lang/String;)Landroid/os/IBinder;
    0012: move-result-object v1
    0013: invoke-virtual {v6, v1}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V
    0016: goto 0005
    0017: move-exception v0
    0018: goto 0004
    0019: const-string v1, 'android.os.IServiceManager'
    001b: invoke-virtual {v5, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    001e: invoke-virtual {v5}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0021: move-result-object v1
    0022: invoke-virtual {v3, v1}, Landroid/os/ServiceManagerNative;->checkService(Ljava/lang/String;)Landroid/os/IBinder;
    0025: move-result-object v1
    0026: invoke-virtual {v6, v1}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V
    0029: goto 0005
    002a: const-string v1, 'android.os.IServiceManager'
    002c: invoke-virtual {v5, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    002f: invoke-virtual {v5}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    0032: move-result-object v1
    0033: invoke-virtual {v5}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;
    0036: move-result-object v2
    0037: invoke-virtual {v3, v1, v2}, Landroid/os/ServiceManagerNative;->addService(Ljava/lang/String;Landroid/os/IBinder;)V
    003a: goto 0005
    003b: const-string v1, 'android.os.IServiceManager'
    003d: invoke-virtual {v5, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0040: invoke-virtual {v3}, Landroid/os/ServiceManagerNative;->listServices()[Ljava/lang/String;
    0043: move-result-object v1
    0044: invoke-virtual {v6, v1}, Landroid/os/Parcel;->writeStringArray([Ljava/lang/String;)V
    0047: goto 0005
    0048: const-string v1, 'android.os.IServiceManager'
    004a: invoke-virtual {v5, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    004d: invoke-virtual {v5}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;
    0050: move-result-object v1
    0051: invoke-static {v1}, Landroid/os/IPermissionController$Stub;->asInterface(Landroid/os/IBinder;)Landroid/os/IPermissionController;
    0054: move-result-object v1
    0055: invoke-virtual {v3, v1}, Landroid/os/ServiceManagerNative;->setPermissionController(Landroid/os/IPermissionController;)V
    0058: goto 0005
    0059: nop
    005a: packed-switch-payload first=1 targets=[5, 24, 41, 58, 3, 71]