=== CLASS Landroid/os/IVoIPCallbackInterface$Stub; (Source: IVoIPCallbackInterface.java) ===
  Super: Landroid/os/Binder;
  Interfaces: Landroid/os/IVoIPCallbackInterface;
  [Static Field] DESCRIPTOR: Ljava/lang/String; = 'android.os.IVoIPCallbackInterface'
  [Static Field] TRANSACTION_answerVoIPCall: I = 1
  [Static Field] TRANSACTION_hangupVoIPCall: I = 2
  [Static Field] TRANSACTION_holdVoIPCall: I = 4
  [Static Field] TRANSACTION_moveVoIPToTop: I = 3
  [Static Field] TRANSACTION_resumeVoIPCall: I = 5

  [Direct Method] <init>() -> V
    // registers=2, ins=1, outs=3, insns_size=9
    0000: invoke-direct {v1}, Landroid/os/Binder;-><init>()V
    0003: const-string v0, 'android.os.IVoIPCallbackInterface'
    0005: invoke-virtual {v1, v1, v0}, Landroid/os/IVoIPCallbackInterface$Stub;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V
    0008: return-void

  [Direct Method] asInterface(Landroid/os/IBinder;) -> Landroid/os/IVoIPCallbackInterface;
    // registers=3, ins=1, outs=2, insns_size=25
    0000: if-nez v2, 0004
    0002: const/4 v0, 0
    0003: return-object v0
    0004: const-string v0, 'android.os.IVoIPCallbackInterface'
    0006: invoke-interface {v2, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;
    0009: move-result-object v0
    000a: if-eqz v0, 0013
    000c: instance-of v1, v0, Landroid/os/IVoIPCallbackInterface;
    000e: if-eqz v1, 0013
    0010: check-cast v0, Landroid/os/IVoIPCallbackInterface;
    0012: goto 0003
    0013: new-instance v0, Landroid/os/IVoIPCallbackInterface$Stub$Proxy;
    0015: invoke-direct {v0, v2}, Landroid/os/IVoIPCallbackInterface$Stub$Proxy;-><init>(Landroid/os/IBinder;)V
    0018: goto 0003

  [Virtual Method] asBinder() -> Landroid/os/IBinder;
    // registers=1, ins=1, outs=0, insns_size=1
    0000: return-object v0

  [Virtual Method] onTransact(I, Landroid/os/Parcel;, Landroid/os/Parcel;, I) -> Z
    // registers=8, ins=5, outs=5, insns_size=138
    0000: const/4 v0, 0
    0001: const/4 v1, 1
    0002: sparse-switch v4, +110 (-> 0070)
    0005: invoke-super {v3, v4, v5, v6, v7}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0008: move-result v1
    0009: return v1
    000a: const-string v0, 'android.os.IVoIPCallbackInterface'
    000c: invoke-virtual {v6, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    000f: goto 0009
    0010: const-string v2, 'android.os.IVoIPCallbackInterface'
    0012: invoke-virtual {v5, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0015: invoke-virtual {v3}, Landroid/os/IVoIPCallbackInterface$Stub;->answerVoIPCall()Z
    0018: move-result v2
    0019: invoke-virtual {v6}, Landroid/os/Parcel;->writeNoException()V
    001c: if-eqz v2, 001f
    001e: move(op=01) v0, v1
    001f: invoke-virtual {v6, v0}, Landroid/os/Parcel;->writeInt(I)V
    0022: goto 0009
    0023: const-string v2, 'android.os.IVoIPCallbackInterface'
    0025: invoke-virtual {v5, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0028: invoke-virtual {v3}, Landroid/os/IVoIPCallbackInterface$Stub;->hangupVoIPCall()Z
    002b: move-result v2
    002c: invoke-virtual {v6}, Landroid/os/Parcel;->writeNoException()V
    002f: if-eqz v2, 0032
    0031: move(op=01) v0, v1
    0032: invoke-virtual {v6, v0}, Landroid/os/Parcel;->writeInt(I)V
    0035: goto 0009
    0036: const-string v2, 'android.os.IVoIPCallbackInterface'
    0038: invoke-virtual {v5, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    003b: invoke-virtual {v3}, Landroid/os/IVoIPCallbackInterface$Stub;->moveVoIPToTop()Z
    003e: move-result v2
    003f: invoke-virtual {v6}, Landroid/os/Parcel;->writeNoException()V
    0042: if-eqz v2, 0045
    0044: move(op=01) v0, v1
    0045: invoke-virtual {v6, v0}, Landroid/os/Parcel;->writeInt(I)V
    0048: goto 0009
    0049: const-string v2, 'android.os.IVoIPCallbackInterface'
    004b: invoke-virtual {v5, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    004e: invoke-virtual {v3}, Landroid/os/IVoIPCallbackInterface$Stub;->holdVoIPCall()Z
    0051: move-result v2
    0052: invoke-virtual {v6}, Landroid/os/Parcel;->writeNoException()V
    0055: if-eqz v2, 0058
    0057: move(op=01) v0, v1
    0058: invoke-virtual {v6, v0}, Landroid/os/Parcel;->writeInt(I)V
    005b: goto 0009
    005c: const-string v2, 'android.os.IVoIPCallbackInterface'
    005e: invoke-virtual {v5, v2}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V
    0061: invoke-virtual {v3}, Landroid/os/IVoIPCallbackInterface$Stub;->resumeVoIPCall()Z
    0064: move-result v2
    0065: invoke-virtual {v6}, Landroid/os/Parcel;->writeNoException()V
    0068: if-eqz v2, 006b
    006a: move(op=01) v0, v1
    006b: invoke-virtual {v6, v0}, Landroid/os/Parcel;->writeInt(I)V
    006e: goto 0009
    006f: nop
    0070: sparse-switch-payload {1: 14, 2: 33, 3: 52, 4: 71, 5: 90, 1598968902: 8}