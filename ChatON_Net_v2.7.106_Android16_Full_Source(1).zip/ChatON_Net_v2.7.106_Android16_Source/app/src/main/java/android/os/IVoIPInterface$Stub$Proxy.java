=== CLASS Landroid/os/IVoIPInterface$Stub$Proxy; (Source: IVoIPInterface.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/IVoIPInterface;
  [Instance Field] mRemote: Landroid/os/IBinder;

  [Direct Method] <init>(Landroid/os/IBinder;) -> V
    // registers=2, ins=2, outs=1, insns_size=6
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: iput v1, v0.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0005: return-void

  [Virtual Method] answerVoIPCall() -> Z
    // registers=7, ins=1, outs=5, insns_size=46
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/4 v4, 4
    0011: const/4 v5, 0
    0012: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001b: move-result v3
    001c: if-eqz v3, 001f
    001e: const/4 v0, 1
    001f: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0022: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0025: return v0
    0026: move-exception v0
    0027: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002a: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002d: throw v0

  [Virtual Method] asBinder() -> Landroid/os/IBinder;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0002: return-object v0

  [Virtual Method] callInVoIP(Ljava/lang/String;) -> V
    // registers=7, ins=2, outs=5, insns_size=42
    0000: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0003: move-result-object v1
    0004: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0007: move-result-object v2
    0008: const-string v0, 'android.os.IVoIPInterface'
    000a: invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000d: invoke-virtual {v1, v6}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0010: iget v0, v5.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0012: const/16 v3, 26 (0x1a)
    0014: const/4 v4, 0
    0015: invoke-interface {v0, v3, v1, v2, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001b: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    001e: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0021: return-void
    0022: move-exception v0
    0023: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0026: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0029: throw v0

  [Virtual Method] canUseBTInVoIP(Ljava/lang/String;) -> Z
    // registers=8, ins=2, outs=5, insns_size=50
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0011: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0013: const/16 v4, 18 (0x12)
    0015: const/4 v5, 0
    0016: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001c: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001f: move-result v3
    0020: if-eqz v3, 0023
    0022: const/4 v0, 1
    0023: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0026: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0029: return v0
    002a: move-exception v0
    002b: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002e: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0031: throw v0

  [Virtual Method] createCallSession(Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;, Landroid/os/IVoIPCallbackInterface;) -> Z
    // registers=12, ins=5, outs=5, insns_size=68
    0000: const/4 v0, 1
    0001: const/4 v1, 0
    0002: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0005: move-result-object v3
    0006: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0009: move-result-object v4
    000a: const-string v2, 'android.os.IVoIPInterface'
    000c: invoke-virtual {v3, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000f: invoke-virtual {v3, v8}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0012: invoke-virtual {v3, v9}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0015: invoke-virtual {v3, v10}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0018: if-eqz v11, 0038
    001a: invoke-interface {v11}, Landroid/os/IVoIPCallbackInterface;->asBinder()Landroid/os/IBinder;
    001d: move-result-object v2
    001e: invoke-virtual {v3, v2}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V
    0021: iget v2, v7.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0023: const/4 v5, 1
    0024: const/4 v6, 0
    0025: invoke-interface {v2, v5, v3, v4, v6}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0028: invoke-virtual {v4}, Landroid/os/Parcel;->readException()V
    002b: invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I
    002e: move-result v2
    002f: if-eqz v2, 003a
    0031: invoke-virtual {v4}, Landroid/os/Parcel;->recycle()V
    0034: invoke-virtual {v3}, Landroid/os/Parcel;->recycle()V
    0037: return v0
    0038: const/4 v2, 0
    0039: goto 001e
    003a: move(op=01) v0, v1
    003b: goto 0031
    003c: move-exception v0
    003d: invoke-virtual {v4}, Landroid/os/Parcel;->recycle()V
    0040: invoke-virtual {v3}, Landroid/os/Parcel;->recycle()V
    0043: throw v0

  [Virtual Method] destroyCallSession(Ljava/lang/String;) -> Z
    // registers=8, ins=2, outs=5, insns_size=49
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0011: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0013: const/4 v4, 2
    0014: const/4 v5, 0
    0015: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001b: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001e: move-result v3
    001f: if-eqz v3, 0022
    0021: const/4 v0, 1
    0022: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0025: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0028: return v0
    0029: move-exception v0
    002a: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002d: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0030: throw v0

  [Virtual Method] dumpCallSessionInfoDB(Ljava/lang/String;) -> V
    // registers=7, ins=2, outs=5, insns_size=42
    0000: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0003: move-result-object v1
    0004: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0007: move-result-object v2
    0008: const-string v0, 'android.os.IVoIPInterface'
    000a: invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000d: invoke-virtual {v1, v6}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0010: iget v0, v5.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0012: const/16 v3, 28 (0x1c)
    0014: const/4 v4, 0
    0015: invoke-interface {v0, v3, v1, v2, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001b: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    001e: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0021: return-void
    0022: move-exception v0
    0023: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0026: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0029: throw v0

  [Virtual Method] getCurrentVoIPNumber() -> Ljava/lang/String;
    // registers=6, ins=1, outs=5, insns_size=43
    0000: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0003: move-result-object v1
    0004: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0007: move-result-object v2
    0008: const-string v0, 'android.os.IVoIPInterface'
    000a: invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000d: iget v0, v5.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    000f: const/16 v3, 25 (0x19)
    0011: const/4 v4, 0
    0012: invoke-interface {v0, v3, v1, v2, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readString()Ljava/lang/String;
    001b: move-result-object v0
    001c: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    001f: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0022: return-object v0
    0023: move-exception v0
    0024: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0027: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002a: throw v0

  [Virtual Method] getInterfaceDescriptor() -> Ljava/lang/String;
    // registers=2, ins=1, outs=0, insns_size=3
    0000: const-string v0, 'android.os.IVoIPInterface'
    0002: return-object v0

  [Virtual Method] getSessionCount() -> I
    // registers=6, ins=1, outs=5, insns_size=43
    0000: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0003: move-result-object v1
    0004: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0007: move-result-object v2
    0008: const-string v0, 'android.os.IVoIPInterface'
    000a: invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000d: iget v0, v5.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    000f: const/16 v3, 27 (0x1b)
    0011: const/4 v4, 0
    0012: invoke-interface {v0, v3, v1, v2, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001b: move-result v0
    001c: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    001f: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0022: return v0
    0023: move-exception v0
    0024: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0027: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002a: throw v0

  [Virtual Method] getVoIPCallCount(Ljava/lang/String;) -> I
    // registers=7, ins=2, outs=5, insns_size=46
    0000: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0003: move-result-object v1
    0004: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0007: move-result-object v2
    0008: const-string v0, 'android.os.IVoIPInterface'
    000a: invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000d: invoke-virtual {v1, v6}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0010: iget v0, v5.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0012: const/16 v3, 9 (0x9)
    0014: const/4 v4, 0
    0015: invoke-interface {v0, v3, v1, v2, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001b: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001e: move-result v0
    001f: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0022: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0025: return v0
    0026: move-exception v0
    0027: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002a: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002d: throw v0

  [Virtual Method] hangupVoIPCall() -> Z
    // registers=7, ins=1, outs=5, insns_size=46
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/4 v4, 5
    0011: const/4 v5, 0
    0012: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001b: move-result v3
    001c: if-eqz v3, 001f
    001e: const/4 v0, 1
    001f: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0022: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0025: return v0
    0026: move-exception v0
    0027: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002a: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002d: throw v0

  [Virtual Method] holdVoIPCall() -> Z
    // registers=7, ins=1, outs=5, insns_size=46
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/4 v4, 6
    0011: const/4 v5, 0
    0012: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001b: move-result v3
    001c: if-eqz v3, 001f
    001e: const/4 v0, 1
    001f: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0022: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0025: return v0
    0026: move-exception v0
    0027: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002a: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002d: throw v0

  [Virtual Method] isVoIPActivated() -> Z
    // registers=7, ins=1, outs=5, insns_size=47
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/16 v4, 24 (0x18)
    0012: const/4 v5, 0
    0013: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0016: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001c: move-result v3
    001d: if-eqz v3, 0020
    001f: const/4 v0, 1
    0020: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0023: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0026: return v0
    0027: move-exception v0
    0028: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002b: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002e: throw v0

  [Virtual Method] isVoIPDialing() -> Z
    // registers=7, ins=1, outs=5, insns_size=47
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/16 v4, 23 (0x17)
    0012: const/4 v5, 0
    0013: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0016: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001c: move-result v3
    001d: if-eqz v3, 0020
    001f: const/4 v0, 1
    0020: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0023: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0026: return v0
    0027: move-exception v0
    0028: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002b: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002e: throw v0

  [Virtual Method] isVoIPIdle() -> Z
    // registers=7, ins=1, outs=5, insns_size=47
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/16 v4, 20 (0x14)
    0012: const/4 v5, 0
    0013: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0016: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001c: move-result v3
    001d: if-eqz v3, 0020
    001f: const/4 v0, 1
    0020: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0023: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0026: return v0
    0027: move-exception v0
    0028: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002b: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002e: throw v0

  [Virtual Method] isVoIPRingOrDialing() -> Z
    // registers=7, ins=1, outs=5, insns_size=47
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/16 v4, 21 (0x15)
    0012: const/4 v5, 0
    0013: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0016: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001c: move-result v3
    001d: if-eqz v3, 0020
    001f: const/4 v0, 1
    0020: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0023: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0026: return v0
    0027: move-exception v0
    0028: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002b: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002e: throw v0

  [Virtual Method] isVoIPRinging() -> Z
    // registers=7, ins=1, outs=5, insns_size=47
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/16 v4, 22 (0x16)
    0012: const/4 v5, 0
    0013: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0016: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001c: move-result v3
    001d: if-eqz v3, 0020
    001f: const/4 v0, 1
    0020: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0023: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0026: return v0
    0027: move-exception v0
    0028: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002b: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002e: throw v0

  [Virtual Method] moveVoIPToTop() -> Z
    // registers=7, ins=1, outs=5, insns_size=46
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/4 v4, 3
    0011: const/4 v5, 0
    0012: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001b: move-result v3
    001c: if-eqz v3, 001f
    001e: const/4 v0, 1
    001f: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0022: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0025: return v0
    0026: move-exception v0
    0027: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002a: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002d: throw v0

  [Virtual Method] resumeVoIPCall() -> Z
    // registers=7, ins=1, outs=5, insns_size=46
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0010: const/4 v4, 7
    0011: const/4 v5, 0
    0012: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0015: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    0018: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001b: move-result v3
    001c: if-eqz v3, 001f
    001e: const/4 v0, 1
    001f: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0022: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0025: return v0
    0026: move-exception v0
    0027: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002a: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002d: throw v0

  [Virtual Method] setBTUserWantsAudioOn(Z) -> Z
    // registers=9, ins=2, outs=5, insns_size=57
    0000: const/4 v0, 1
    0001: const/4 v1, 0
    0002: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0005: move-result-object v3
    0006: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0009: move-result-object v4
    000a: const-string v2, 'android.os.IVoIPInterface'
    000c: invoke-virtual {v3, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000f: if-eqz v8, 002d
    0011: move(op=01) v2, v0
    0012: invoke-virtual {v3, v2}, Landroid/os/Parcel;->writeInt(I)V
    0015: iget v2, v7.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0017: const/16 v5, 19 (0x13)
    0019: const/4 v6, 0
    001a: invoke-interface {v2, v5, v3, v4, v6}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    001d: invoke-virtual {v4}, Landroid/os/Parcel;->readException()V
    0020: invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I
    0023: move-result v2
    0024: if-eqz v2, 002f
    0026: invoke-virtual {v4}, Landroid/os/Parcel;->recycle()V
    0029: invoke-virtual {v3}, Landroid/os/Parcel;->recycle()V
    002c: return v0
    002d: move(op=01) v2, v1
    002e: goto 0012
    002f: move(op=01) v0, v1
    0030: goto 0026
    0031: move-exception v0
    0032: invoke-virtual {v4}, Landroid/os/Parcel;->recycle()V
    0035: invoke-virtual {v3}, Landroid/os/Parcel;->recycle()V
    0038: throw v0

  [Virtual Method] setEngMode(Ljava/lang/String;, I) -> V
    // registers=8, ins=3, outs=5, insns_size=45
    0000: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0003: move-result-object v1
    0004: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0007: move-result-object v2
    0008: const-string v0, 'android.os.IVoIPInterface'
    000a: invoke-virtual {v1, v0}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000d: invoke-virtual {v1, v6}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0010: invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeInt(I)V
    0013: iget v0, v5.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0015: const/16 v3, 29 (0x1d)
    0017: const/4 v4, 0
    0018: invoke-interface {v0, v3, v1, v2, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    001b: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001e: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0021: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0024: return-void
    0025: move-exception v0
    0026: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0029: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002c: throw v0

  [Virtual Method] setUseBTInVoIP(Ljava/lang/String;, Z) -> Z
    // registers=10, ins=3, outs=5, insns_size=60
    0000: const/4 v0, 1
    0001: const/4 v1, 0
    0002: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0005: move-result-object v3
    0006: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0009: move-result-object v4
    000a: const-string v2, 'android.os.IVoIPInterface'
    000c: invoke-virtual {v3, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000f: invoke-virtual {v3, v8}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0012: if-eqz v9, 0030
    0014: move(op=01) v2, v0
    0015: invoke-virtual {v3, v2}, Landroid/os/Parcel;->writeInt(I)V
    0018: iget v2, v7.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    001a: const/16 v5, 17 (0x11)
    001c: const/4 v6, 0
    001d: invoke-interface {v2, v5, v3, v4, v6}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0020: invoke-virtual {v4}, Landroid/os/Parcel;->readException()V
    0023: invoke-virtual {v4}, Landroid/os/Parcel;->readInt()I
    0026: move-result v2
    0027: if-eqz v2, 0032
    0029: invoke-virtual {v4}, Landroid/os/Parcel;->recycle()V
    002c: invoke-virtual {v3}, Landroid/os/Parcel;->recycle()V
    002f: return v0
    0030: move(op=01) v2, v1
    0031: goto 0015
    0032: move(op=01) v0, v1
    0033: goto 0029
    0034: move-exception v0
    0035: invoke-virtual {v4}, Landroid/os/Parcel;->recycle()V
    0038: invoke-virtual {v3}, Landroid/os/Parcel;->recycle()V
    003b: throw v0

  [Virtual Method] setVoIPActive(Ljava/lang/String;) -> Z
    // registers=8, ins=2, outs=5, insns_size=50
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0011: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0013: const/16 v4, 13 (0xd)
    0015: const/4 v5, 0
    0016: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001c: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001f: move-result v3
    0020: if-eqz v3, 0023
    0022: const/4 v0, 1
    0023: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0026: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0029: return v0
    002a: move-exception v0
    002b: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002e: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0031: throw v0

  [Virtual Method] setVoIPCallCount(Ljava/lang/String;, I) -> Z
    // registers=9, ins=3, outs=5, insns_size=53
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0011: invoke-virtual {v1, v8}, Landroid/os/Parcel;->writeInt(I)V
    0014: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0016: const/16 v4, 8 (0x8)
    0018: const/4 v5, 0
    0019: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    001c: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001f: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    0022: move-result v3
    0023: if-eqz v3, 0026
    0025: const/4 v0, 1
    0026: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0029: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    002c: return v0
    002d: move-exception v0
    002e: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0031: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0034: throw v0

  [Virtual Method] setVoIPDialing(Ljava/lang/String;) -> Z
    // registers=8, ins=2, outs=5, insns_size=50
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0011: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0013: const/16 v4, 12 (0xc)
    0015: const/4 v5, 0
    0016: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001c: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001f: move-result v3
    0020: if-eqz v3, 0023
    0022: const/4 v0, 1
    0023: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0026: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0029: return v0
    002a: move-exception v0
    002b: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002e: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0031: throw v0

  [Virtual Method] setVoIPDisconnected(Ljava/lang/String;) -> Z
    // registers=8, ins=2, outs=5, insns_size=50
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0011: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0013: const/16 v4, 16 (0x10)
    0015: const/4 v5, 0
    0016: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001c: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001f: move-result v3
    0020: if-eqz v3, 0023
    0022: const/4 v0, 1
    0023: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0026: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0029: return v0
    002a: move-exception v0
    002b: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002e: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0031: throw v0

  [Virtual Method] setVoIPDisconnecting(Ljava/lang/String;) -> Z
    // registers=8, ins=2, outs=5, insns_size=50
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0011: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0013: const/16 v4, 15 (0xf)
    0015: const/4 v5, 0
    0016: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001c: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001f: move-result v3
    0020: if-eqz v3, 0023
    0022: const/4 v0, 1
    0023: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0026: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0029: return v0
    002a: move-exception v0
    002b: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002e: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0031: throw v0

  [Virtual Method] setVoIPHolding(Ljava/lang/String;) -> Z
    // registers=8, ins=2, outs=5, insns_size=50
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0011: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0013: const/16 v4, 14 (0xe)
    0015: const/4 v5, 0
    0016: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001c: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001f: move-result v3
    0020: if-eqz v3, 0023
    0022: const/4 v0, 1
    0023: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0026: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0029: return v0
    002a: move-exception v0
    002b: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002e: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0031: throw v0

  [Virtual Method] setVoIPIdle(Ljava/lang/String;) -> Z
    // registers=8, ins=2, outs=5, insns_size=50
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0011: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0013: const/16 v4, 10 (0xa)
    0015: const/4 v5, 0
    0016: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001c: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001f: move-result v3
    0020: if-eqz v3, 0023
    0022: const/4 v0, 1
    0023: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0026: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0029: return v0
    002a: move-exception v0
    002b: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002e: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0031: throw v0

  [Virtual Method] setVoIPRinging(Ljava/lang/String;) -> Z
    // registers=8, ins=2, outs=5, insns_size=50
    0000: const/4 v0, 0
    0001: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0004: move-result-object v1
    0005: invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;
    0008: move-result-object v2
    0009: const-string v3, 'android.os.IVoIPInterface'
    000b: invoke-virtual {v1, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V
    000e: invoke-virtual {v1, v7}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V
    0011: iget v3, v6.Landroid/os/IVoIPInterface$Stub$Proxy;->mRemote:Landroid/os/IBinder;
    0013: const/16 v4, 11 (0xb)
    0015: const/4 v5, 0
    0016: invoke-interface {v3, v4, v1, v2, v5}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    0019: invoke-virtual {v2}, Landroid/os/Parcel;->readException()V
    001c: invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I
    001f: move-result v3
    0020: if-eqz v3, 0023
    0022: const/4 v0, 1
    0023: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    0026: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0029: return v0
    002a: move-exception v0
    002b: invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V
    002e: invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V
    0031: throw v0