=== CLASS Landroid/os/IServiceManager; (Source: IServiceManager.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/IInterface;
  [Static Field] ADD_SERVICE_TRANSACTION: I = 3
  [Static Field] CHECK_SERVICES_TRANSACTION: I = 5
  [Static Field] CHECK_SERVICE_TRANSACTION: I = 2
  [Static Field] GET_SERVICE_TRANSACTION: I = 1
  [Static Field] LIST_SERVICES_TRANSACTION: I = 4
  [Static Field] SET_PERMISSION_CONTROLLER_TRANSACTION: I = 6
  [Static Field] descriptor: Ljava/lang/String; = 'android.os.IServiceManager'

  [Virtual Method] addService(Ljava/lang/String;, Landroid/os/IBinder;) -> V

  [Virtual Method] checkService(Ljava/lang/String;) -> Landroid/os/IBinder;

  [Virtual Method] getService(Ljava/lang/String;) -> Landroid/os/IBinder;

  [Virtual Method] listServices() -> [Ljava/lang/String;

  [Virtual Method] setPermissionController(Landroid/os/IPermissionController;) -> V