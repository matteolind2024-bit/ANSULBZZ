=== CLASS Landroid/os/IVoIPInterface; (Source: IVoIPInterface.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/os/IInterface;

  [Virtual Method] answerVoIPCall() -> Z

  [Virtual Method] callInVoIP(Ljava/lang/String;) -> V

  [Virtual Method] canUseBTInVoIP(Ljava/lang/String;) -> Z

  [Virtual Method] createCallSession(Ljava/lang/String;, Ljava/lang/String;, Ljava/lang/String;, Landroid/os/IVoIPCallbackInterface;) -> Z

  [Virtual Method] destroyCallSession(Ljava/lang/String;) -> Z

  [Virtual Method] dumpCallSessionInfoDB(Ljava/lang/String;) -> V

  [Virtual Method] getCurrentVoIPNumber() -> Ljava/lang/String;

  [Virtual Method] getSessionCount() -> I

  [Virtual Method] getVoIPCallCount(Ljava/lang/String;) -> I

  [Virtual Method] hangupVoIPCall() -> Z

  [Virtual Method] holdVoIPCall() -> Z

  [Virtual Method] isVoIPActivated() -> Z

  [Virtual Method] isVoIPDialing() -> Z

  [Virtual Method] isVoIPIdle() -> Z

  [Virtual Method] isVoIPRingOrDialing() -> Z

  [Virtual Method] isVoIPRinging() -> Z

  [Virtual Method] moveVoIPToTop() -> Z

  [Virtual Method] resumeVoIPCall() -> Z

  [Virtual Method] setBTUserWantsAudioOn(Z) -> Z

  [Virtual Method] setEngMode(Ljava/lang/String;, I) -> V

  [Virtual Method] setUseBTInVoIP(Ljava/lang/String;, Z) -> Z

  [Virtual Method] setVoIPActive(Ljava/lang/String;) -> Z

  [Virtual Method] setVoIPCallCount(Ljava/lang/String;, I) -> Z

  [Virtual Method] setVoIPDialing(Ljava/lang/String;) -> Z

  [Virtual Method] setVoIPDisconnected(Ljava/lang/String;) -> Z

  [Virtual Method] setVoIPDisconnecting(Ljava/lang/String;) -> Z

  [Virtual Method] setVoIPHolding(Ljava/lang/String;) -> Z

  [Virtual Method] setVoIPIdle(Ljava/lang/String;) -> Z

  [Virtual Method] setVoIPRinging(Ljava/lang/String;) -> Z