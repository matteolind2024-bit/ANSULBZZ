=== CLASS Landroid/sec/multiwindow/IMultiWindow; (Source: IMultiWindow.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] finish() -> Z

  [Virtual Method] finish(I) -> Z

  [Virtual Method] fitToHalf(I) -> Z

  [Virtual Method] getHeight() -> I

  [Virtual Method] getMinimumSize() -> Landroid/graphics/Point;

  [Virtual Method] getRect() -> Landroid/graphics/Rect;

  [Virtual Method] getRect(I) -> Landroid/graphics/Rect;

  [Virtual Method] getWidth() -> I

  [Virtual Method] isMaximized() -> Z

  [Virtual Method] isMaximized(I) -> Z

  [Virtual Method] isStartingSplitScreen(Landroid/content/ComponentName;) -> Z

  [Virtual Method] maximize() -> Z

  [Virtual Method] minimize() -> Z

  [Virtual Method] minimize(I) -> Z

  [Virtual Method] pinUp(Z) -> Z

  [Virtual Method] pinUp(Z, I) -> Z

  [Virtual Method] relayout(Landroid/graphics/Rect;) -> Z

  [Virtual Method] restore() -> Z

  [Virtual Method] restore(I) -> Z

  [Virtual Method] setMinimumSize(I, I) -> Z

  [Virtual Method] start() -> Z