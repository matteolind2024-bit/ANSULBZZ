=== CLASS Landroid/sec/multiwindow/MultiWindowManager; (Source: MultiWindowManager.java) ===
  Super: Landroid/sec/multiwindow/MultiWindowImpl;
  Interfaces: Landroid/sec/multiwindow/IMultiWindowManager;
  [Static Field] ARRANGE_MODE_CASCADE: I = 0
  [Static Field] ARRANGE_MODE_SPLIT: I = 0
  [Static Field] FLAG_STYLE_FREE: I = 0
  [Static Field] FLAG_STYLE_MINIMIZE: I = 0
  [Static Field] FLAG_STYLE_PINUP: I = 0
  [Static Field] FLAG_STYLE_POPUP: I = 0
  [Static Field] MAX_RUNNING_TASK: I = 1000
  [Static Field] TAG: Ljava/lang/String; = 'MultiWindowManager'
  [Static Field] mSelf: Landroid/sec/multiwindow/MultiWindowManager;
  [Static Field] sIsMultiWindowEnabled: Z
  [Static Field] sQueried: Z

  [Direct Method] <clinit>() -> V
    // registers=2, ins=0, outs=0, insns_size=33
    0000: const/4 v1, 0
    0001: sget v0, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_FREESTYLE:I
    0003: sput v0, Landroid/sec/multiwindow/MultiWindowManager;->FLAG_STYLE_FREE:I
    0005: sget v0, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_PINUP:I
    0007: sput v0, Landroid/sec/multiwindow/MultiWindowManager;->FLAG_STYLE_PINUP:I
    0009: sget v0, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_MINIMIZED:I
    000b: sput v0, Landroid/sec/multiwindow/MultiWindowManager;->FLAG_STYLE_MINIMIZE:I
    000d: sget v0, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_NO_DECORATION:I
    000f: sput v0, Landroid/sec/multiwindow/MultiWindowManager;->FLAG_STYLE_POPUP:I
    0011: sget v0, Landroid/sec/multiwindow/Constants$Configuration;->ARRANGE_SPLITED:I
    0013: sput v0, Landroid/sec/multiwindow/MultiWindowManager;->ARRANGE_MODE_SPLIT:I
    0015: sget v0, Landroid/sec/multiwindow/Constants$Configuration;->ARRANGE_CASCADE:I
    0017: sput v0, Landroid/sec/multiwindow/MultiWindowManager;->ARRANGE_MODE_CASCADE:I
    0019: const/4 v0, 0
    001a: sput v0, Landroid/sec/multiwindow/MultiWindowManager;->mSelf:Landroid/sec/multiwindow/MultiWindowManager;
    001c: sput v1, Landroid/sec/multiwindow/MultiWindowManager;->sQueried:Z
    001e: sput v1, Landroid/sec/multiwindow/MultiWindowManager;->sIsMultiWindowEnabled:Z
    0020: return-void

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=6, ins=2, outs=5, insns_size=24
    0000: invoke-direct {v4, v5}, Landroid/sec/multiwindow/MultiWindowImpl;-><init>(Landroid/content/Context;)V
    0003: const-string v0, 'activity'
    0005: invoke-virtual {v5, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    0008: move-result-object v0
    0009: check-cast v0, Landroid/app/ActivityManager;
    000b: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    000e: move-result-object v2
    000f: const-string v3, 'getFrontActivityPosition'
    0011: const/4 v1, 0
    0012: check-cast v1, [Ljava/lang/Class;
    0014: invoke-virtual {v4, v2, v0, v3, v1}, Landroid/sec/multiwindow/MultiWindowManager;->putMethod(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;)V
    0017: return-void

  [Direct Method] <init>(Landroid/content/Context;, Landroid/os/Handler;) -> V
    // registers=3, ins=3, outs=2, insns_size=4
    0000: invoke-direct {v0, v1}, Landroid/sec/multiwindow/MultiWindowManager;-><init>(Landroid/content/Context;)V
    0003: return-void

  [Direct Method] getInstance(Landroid/content/Context;) -> Landroid/sec/multiwindow/IMultiWindowManager;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Direct Method] getMultiWindowInfos(I) -> Ljava/util/List;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Direct Method] getSelf(Landroid/content/Context;) -> Landroid/sec/multiwindow/MultiWindowManager;
    // registers=2, ins=1, outs=2, insns_size=14
    0000: sget v0, Landroid/sec/multiwindow/MultiWindowManager;->mSelf:Landroid/sec/multiwindow/MultiWindowManager;
    0002: if-nez v0, 000b
    0004: new-instance v0, Landroid/sec/multiwindow/MultiWindowManager;
    0006: invoke-direct {v0, v1}, Landroid/sec/multiwindow/MultiWindowManager;-><init>(Landroid/content/Context;)V
    0009: sput v0, Landroid/sec/multiwindow/MultiWindowManager;->mSelf:Landroid/sec/multiwindow/MultiWindowManager;
    000b: sget v0, Landroid/sec/multiwindow/MultiWindowManager;->mSelf:Landroid/sec/multiwindow/MultiWindowManager;
    000d: return-object v0

  [Direct Method] getService() -> Landroid/sec/multiwindow/IMultiWindowService;
    // registers=1, ins=0, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Direct Method] isMultiWindowServiceEnabled(Landroid/content/Context;) -> Z
    // registers=3, ins=1, outs=2, insns_size=24
    0000: sget v0, Landroid/sec/multiwindow/MultiWindowManager;->sQueried:Z
    0002: if-nez v0, 0015
    0004: const/4 v0, 1
    0005: sput v0, Landroid/sec/multiwindow/MultiWindowManager;->sQueried:Z
    0007: invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    000a: move-result-object v0
    000b: if-eqz v0, 0015
    000d: sget v1, Landroid/sec/multiwindow/Constants$PackageManager;->FEATURE_MULTIWINDOW:Ljava/lang/String;
    000f: invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z
    0012: move-result v0
    0013: sput v0, Landroid/sec/multiwindow/MultiWindowManager;->sIsMultiWindowEnabled:Z
    0015: sget v0, Landroid/sec/multiwindow/MultiWindowManager;->sIsMultiWindowEnabled:Z
    0017: return v0

  [Virtual Method] arrange(I) -> V
    // registers=4, ins=2, outs=3, insns_size=18
    0000: new-instance v0, Landroid/content/Intent;
    0002: sget v1, Landroid/sec/multiwindow/Constants$Intent;->ACTION_ARRANGE_WINDOWS:Ljava/lang/String;
    0004: invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    0007: sget v1, Landroid/sec/multiwindow/Constants$Intent;->EXTRA_ARRANGE_MODE:Ljava/lang/String;
    0009: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    000c: iget v1, v2.Landroid/sec/multiwindow/MultiWindowManager;->mContext:Landroid/content/Context;
    000e: invoke-virtual {v1, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V
    0011: return-void

  [Virtual Method] arrangeCascade() -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: sget v0, Landroid/sec/multiwindow/Constants$Configuration;->ARRANGE_CASCADE:I
    0002: invoke-virtual {v1, v0}, Landroid/sec/multiwindow/MultiWindowManager;->arrange(I)V
    0005: return-void

  [Virtual Method] arrangeSplit() -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: sget v0, Landroid/sec/multiwindow/Constants$Configuration;->ARRANGE_SPLITED:I
    0002: invoke-virtual {v1, v0}, Landroid/sec/multiwindow/MultiWindowManager;->arrange(I)V
    0005: return-void

  [Virtual Method] arrangeTemplate(I) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] arrangeWindows(I) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] capture(Landroid/content/ComponentName;) -> Landroid/graphics/Bitmap;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] exchangeSplitScreens() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] finishAllWindow() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] finishAppPid(I) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getFrontActivityPosition() -> Landroid/graphics/Rect;
    // registers=3, ins=1, outs=3, insns_size=12
    0000: const-string v0, 'getFrontActivityPosition'
    0002: const/4 v1, 0
    0003: new-array v1, v1, [Ljava/lang/Object;
    0005: invoke-virtual {v2, v0, v1}, Landroid/sec/multiwindow/MultiWindowManager;->invoke(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    0008: move-result-object v0
    0009: check-cast v0, Landroid/graphics/Rect;
    000b: return-object v0

  [Virtual Method] getMultiLayout() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Virtual Method] getMultiWindowInfos() -> Ljava/util/List;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getMultiWindowList() -> Ljava/util/List;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getMultiWindowList(Landroid/content/ComponentName;) -> Ljava/util/List;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getMultiWindowListOwnerList() -> Ljava/util/List;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getMultiWindowMode() -> Landroid/sec/multiwindow/MultiWindowType;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getPinupWindow() -> Landroid/content/ComponentName;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getPinupWindowList() -> Ljava/util/List;
    // registers=2, ins=1, outs=1, insns_size=6
    0000: new-instance v0, Ljava/util/ArrayList;
    0002: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0005: return-object v0

  [Virtual Method] getRegisteredList() -> Ljava/util/List;
    // registers=5, ins=1, outs=3, insns_size=54
    0000: new-instance v1, Ljava/util/ArrayList;
    0002: invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V
    0005: new-instance v0, Landroid/content/Intent;
    0007: const-string v2, 'android.intent.action.MAIN'
    0009: invoke-direct {v0, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    000c: sget v2, Landroid/sec/multiwindow/Constants$Intent;->CATEGORY_MULTIWINDOW_LAUNCHER:Ljava/lang/String;
    000e: invoke-virtual {v0, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;
    0011: iget v2, v4.Landroid/sec/multiwindow/MultiWindowManager;->mContext:Landroid/content/Context;
    0013: invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;
    0016: move-result-object v2
    0017: const/16 v3, 128 (0x80)
    0019: invoke-virtual {v2, v0, v3}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;
    001c: move-result-object v0
    001d: invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    0020: move-result-object v2
    0021: invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z
    0024: move-result v0
    0025: if-eqz v0, 0035
    0027: invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    002a: move-result-object v0
    002b: check-cast v0, Landroid/content/pm/ResolveInfo;
    002d: if-eqz v0, 0021
    002f: iget v0, v0.Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;
    0031: invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    0034: goto 0021
    0035: return-object v1

  [Virtual Method] getResumedWindow() -> Landroid/content/ComponentName;
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getRunningList(I) -> Ljava/util/List;
    // registers=5, ins=2, outs=4, insns_size=18
    0000: iget v0, v3.Landroid/sec/multiwindow/MultiWindowManager;->mContext:Landroid/content/Context;
    0002: const-string v1, 'activity'
    0004: invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    0007: move-result-object v0
    0008: check-cast v0, Landroid/app/ActivityManager;
    000a: const/16 v1, 1000 (0x3e8)
    000c: const/4 v2, 0
    000d: invoke-virtual {v0, v1, v4, v2}, Landroid/app/ActivityManager;->getRunningTasks(IILandroid/app/IThumbnailReceiver;)Ljava/util/List;
    0010: move-result-object v0
    0011: return-object v0

  [Virtual Method] getRunningWindowList() -> Ljava/util/List;
    // registers=2, ins=1, outs=1, insns_size=6
    0000: new-instance v0, Ljava/util/ArrayList;
    0002: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0005: return-object v0

  [Virtual Method] getSplitList() -> Ljava/util/List;
    // registers=2, ins=1, outs=1, insns_size=6
    0000: new-instance v0, Ljava/util/ArrayList;
    0002: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0005: return-object v0

  [Virtual Method] getVisibleWindowList() -> Ljava/util/List;
    // registers=2, ins=1, outs=1, insns_size=6
    0000: new-instance v0, Ljava/util/ArrayList;
    0002: invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V
    0005: return-object v0

  [Virtual Method] getWindowInstance(Landroid/content/ComponentName;) -> Landroid/sec/multiwindow/IMultiWindow;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] getWindowInstance(Landroid/content/Intent;) -> Landroid/sec/multiwindow/IMultiWindow;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] isMultiWindow(Landroid/content/ComponentName;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isMultiWindow(Landroid/content/ComponentName;, Landroid/content/ComponentName;) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isPermissionOff() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isPinup(Landroid/content/ComponentName;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isPinup(Landroid/content/ComponentName;, I) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isRunning(Landroid/content/ComponentName;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isVisible(Landroid/content/ComponentName;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] makeIntent(I, Landroid/graphics/Rect;) -> Landroid/content/Intent;
    // registers=5, ins=3, outs=3, insns_size=18
    0000: new-instance v0, Landroid/content/Intent;
    0002: invoke-direct {v0}, Landroid/content/Intent;-><init>()V
    0005: sget v1, Landroid/sec/multiwindow/Constants$Intent;->EXTRA_WINDOW_MODE:Ljava/lang/String;
    0007: invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;
    000a: if-eqz v4, 0011
    000c: sget v1, Landroid/sec/multiwindow/Constants$Intent;->EXTRA_WINDOW_POSITION:Ljava/lang/String;
    000e: invoke-virtual {v0, v1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    0011: return-object v0

  [Virtual Method] minimizeAll() -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: sget v0, Landroid/sec/multiwindow/Constants$Configuration;->ARRANGE_MINIMIZED_ALL:I
    0002: invoke-virtual {v1, v0}, Landroid/sec/multiwindow/MultiWindowManager;->arrange(I)V
    0005: return-void

  [Virtual Method] notifyFinished(Landroid/app/Activity;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] notifyForceFinished(Landroid/content/ComponentName;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] notifySIP(I) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Virtual Method] notifyStarted(Landroid/app/Activity;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] orientationChangeRestore(Landroid/content/ComponentName;, I) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] postResume(Landroid/app/Activity;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] registerMultiWindow(Landroid/content/ComponentName;) -> Landroid/sec/multiwindow/IMultiWindow;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] registerMultiWindow(Landroid/content/ComponentName;, I, I) -> Landroid/sec/multiwindow/IMultiWindow;
    // registers=5, ins=4, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] registerMultiWindow(Landroid/content/ComponentName;, I, I, Z) -> Landroid/sec/multiwindow/IMultiWindow;
    // registers=6, ins=5, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] registerMultiWindow(Landroid/content/ComponentName;, Ljava/util/List;) -> Landroid/sec/multiwindow/IMultiWindow;
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] registerMultiWindowPair(Landroid/content/ComponentName;, Landroid/content/ComponentName;) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] removeMultiWindow(Landroid/content/ComponentName;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] removeMultiWindowOwnerItem(Landroid/content/ComponentName;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] removeMultiWindowPair(Landroid/content/ComponentName;, Landroid/content/ComponentName;) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] restoreAll() -> V
    // registers=2, ins=1, outs=2, insns_size=6
    0000: sget v0, Landroid/sec/multiwindow/Constants$Configuration;->ARRANGE_RESTORED_ALL:I
    0002: invoke-virtual {v1, v0}, Landroid/sec/multiwindow/MultiWindowManager;->arrange(I)V
    0005: return-void

  [Virtual Method] screenShot(Landroid/content/ComponentName;) -> Landroid/graphics/Bitmap;
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return-object v0

  [Virtual Method] sendCreateAction(Landroid/app/Activity;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] sendDestroyAction(Landroid/app/Activity;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] sendFinishAction(Landroid/app/Activity;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] sendPauseAction(Landroid/app/Activity;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] sendResumeAction(Landroid/app/Activity;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] sendStartAction(Landroid/app/Activity;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] setMultiLayout(Z) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Virtual Method] setMultiWindowMode(Landroid/sec/multiwindow/MultiWindowType;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] setPreferenceValue(Z) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] showSwitchWindowGuideDialog(Landroid/content/Context;) -> V
    // registers=2, ins=2, outs=0, insns_size=1
    0000: return-void

  [Virtual Method] startLauncher() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] startLauncher(Landroid/content/ComponentName;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] startLauncher(Landroid/content/Context;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] startLauncher(Landroid/content/Context;, Landroid/content/ComponentName;) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] startSplitScreens(Landroid/content/ComponentName;, Landroid/content/ComponentName;) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] startSplitScreens(Landroid/content/ComponentName;, Landroid/content/Intent;) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] startSplitScreens(Landroid/content/Intent;, Landroid/content/ComponentName;) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] startSplitScreensForLauncher(Landroid/content/ComponentName;, Landroid/content/ComponentName;) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] unRegisterMultiWindow(Landroid/content/ComponentName;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0