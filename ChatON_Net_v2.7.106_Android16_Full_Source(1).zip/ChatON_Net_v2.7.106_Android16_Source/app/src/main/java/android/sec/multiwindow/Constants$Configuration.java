=== CLASS Landroid/sec/multiwindow/Constants$Configuration; (Source: Constants.java) ===
  Super: Ljava/lang/Object;
  [Static Field] ARRANGE_CASCADE: I
  [Static Field] ARRANGE_MINIMIZED_ALL: I
  [Static Field] ARRANGE_RESTORED_ALL: I
  [Static Field] ARRANGE_SPLITED: I
  [Static Field] ARRANGE_TILED: I
  [Static Field] ARRANGE_TOGGLE_MASK: I
  [Static Field] ARRANGE_UNDEFINED: I
  [Static Field] FIELD_NAMES: [Ljava/lang/String;

  [Direct Method] <clinit>() -> V
    // registers=5, ins=0, outs=3, insns_size=82
    0000: const/4 v0, 0
    0001: const/4 v1, 7
    0002: new-array v1, v1, [Ljava/lang/String;
    0004: const-string v2, 'ARRANGE_UNDEFINED'
    0006: aput(op=4d) v2, v1[v0]
    0008: const/4 v2, 1
    0009: const-string v3, 'ARRANGE_TILED'
    000b: aput(op=4d) v3, v1[v2]
    000d: const/4 v2, 2
    000e: const-string v3, 'ARRANGE_CASCADE'
    0010: aput(op=4d) v3, v1[v2]
    0012: const/4 v2, 3
    0013: const-string v3, 'ARRANGE_SPLITED'
    0015: aput(op=4d) v3, v1[v2]
    0017: const/4 v2, 4
    0018: const-string v3, 'ARRANGE_MINIMIZED_ALL'
    001a: aput(op=4d) v3, v1[v2]
    001c: const/4 v2, 5
    001d: const-string v3, 'ARRANGE_RESTORED_ALL'
    001f: aput(op=4d) v3, v1[v2]
    0021: const/4 v2, 6
    0022: const-string v3, 'ARRANGE_TOGGLE_MASK'
    0024: aput(op=4d) v3, v1[v2]
    0026: sput v1, Landroid/sec/multiwindow/Constants$Configuration;->FIELD_NAMES:[Ljava/lang/String;
    0028: sget v1, Landroid/sec/multiwindow/Constants$Configuration;->FIELD_NAMES:[Ljava/lang/String;
    002a: move(op=21) v1, v1
    002b: if-ge v0, v1, 004b
    002d: const-class v2, Landroid/content/res/Configuration;
    002f: sget v3, Landroid/sec/multiwindow/Constants$Configuration;->FIELD_NAMES:[Ljava/lang/String;
    0031: aget(op=46) v3, v3[v0]
    0033: invoke-virtual {v2, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    0036: move-result-object v2
    0037: const-class v3, Landroid/sec/multiwindow/Constants$Configuration;
    0039: sget v4, Landroid/sec/multiwindow/Constants$Configuration;->FIELD_NAMES:[Ljava/lang/String;
    003b: aget(op=46) v4, v4[v0]
    003d: invoke-virtual {v3, v4}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    0040: move-result-object v3
    0041: invoke-virtual {v2, v2}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I
    0044: move-result v2
    0045: invoke-virtual {v3, v3, v2}, Ljava/lang/reflect/Field;->setInt(Ljava/lang/Object;I)V
    0048: binop/lit8(op=d8) v0, v0, 1 (0x1)
    004a: goto 002b
    004b: return-void
    004c: move-exception v2
    004d: goto 0048
    004e: move-exception v2
    004f: goto 0048
    0050: move-exception v2
    0051: goto 0048

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void