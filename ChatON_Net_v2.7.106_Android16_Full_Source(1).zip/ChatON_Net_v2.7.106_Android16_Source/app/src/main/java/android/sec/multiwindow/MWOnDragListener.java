=== CLASS Landroid/sec/multiwindow/MWOnDragListener; (Source: MWOnDragListener.java) ===
  Super: Ljava/lang/Object;
  Interfaces: Landroid/view/View$OnDragListener;
  [Static Field] TAG: Ljava/lang/String; = 'MWOnDragListener'

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void

  [Virtual Method] onDrag(Landroid/view/View;, Landroid/view/DragEvent;) -> Z
    // registers=5, ins=3, outs=2, insns_size=44
    0000: const/4 v0, 1
    0001: invoke-virtual {v4}, Landroid/view/DragEvent;->getAction()I
    0004: move-result v1
    0005: packed-switch v1, +23 (-> 001c)
    0008: const-string v0, 'MWOnDragListener'
    000a: const-string v1, 'Unknown action type received by OnDragListener.'
    000c: invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    000f: const/4 v0, 0
    0010: return v0
    0011: invoke-virtual {v2, v4}, Landroid/sec/multiwindow/MWOnDragListener;->onDrop(Landroid/view/DragEvent;)V
    0014: invoke-virtual {v3}, Landroid/view/View;->invalidate()V
    0017: goto 0010
    0018: invoke-virtual {v3}, Landroid/view/View;->invalidate()V
    001b: goto 0010
    001c: packed-switch-payload first=1 targets=[11, 11, 12, 19, 11, 11]

  [Virtual Method] onDrop(Landroid/view/DragEvent;) -> V