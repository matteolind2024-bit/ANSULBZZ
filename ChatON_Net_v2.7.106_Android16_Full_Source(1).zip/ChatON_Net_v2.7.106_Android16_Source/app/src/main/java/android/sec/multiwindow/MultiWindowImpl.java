=== CLASS Landroid/sec/multiwindow/MultiWindowImpl; (Source: MultiWindowImpl.java) ===
  Super: Ljava/lang/Object;
  [Instance Field] mContext: Landroid/content/Context;
  [Instance Field] mMethodMap: Ljava/util/HashMap;

  [Direct Method] <init>(Landroid/content/Context;) -> V
    // registers=9, ins=2, outs=5, insns_size=44
    0000: const/4 v6, 0
    0001: const/4 v5, 1
    0002: const/4 v4, 0
    0003: invoke-direct {v7}, Ljava/lang/Object;-><init>()V
    0006: iput v8, v7.Landroid/sec/multiwindow/MultiWindowImpl;->mContext:Landroid/content/Context;
    0008: new-instance v0, Ljava/util/HashMap;
    000a: invoke-direct {v0}, Ljava/util/HashMap;-><init>()V
    000d: iput v0, v7.Landroid/sec/multiwindow/MultiWindowImpl;->mMethodMap:Ljava/util/HashMap;
    000f: const-string v0, 'android.view.WindowManagerPolicy$WindowModeHelper'
    0011: invoke-virtual {v7, v0}, Landroid/sec/multiwindow/MultiWindowImpl;->findClass(Ljava/lang/String;)Ljava/lang/Class;
    0014: move-result-object v0
    0015: const-string v1, 'mode'
    0017: new-array v2, v5, [Ljava/lang/Class;
    0019: sget v3, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;
    001b: aput(op=4d) v3, v2[v4]
    001d: invoke-virtual {v7, v0, v6, v1, v2}, Landroid/sec/multiwindow/MultiWindowImpl;->putMethod(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;)V
    0020: const-string v1, 'option'
    0022: new-array v2, v5, [Ljava/lang/Class;
    0024: sget v3, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;
    0026: aput(op=4d) v3, v2[v4]
    0028: invoke-virtual {v7, v0, v6, v1, v2}, Landroid/sec/multiwindow/MultiWindowImpl;->putMethod(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;)V
    002b: return-void

  [Virtual Method] findClass(Ljava/lang/String;) -> Ljava/lang/Class;
    // registers=3, ins=2, outs=1, insns_size=8
    0000: invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    0003: move-result-object v0
    0004: return-object v0
    0005: move-exception v0
    0006: const/4 v0, 0
    0007: goto 0004

  [Virtual Method] invoke(Ljava/lang/String;, [Ljava/lang/Object;) -> Ljava/lang/Object;
    // registers=5, ins=3, outs=3, insns_size=25
    0000: iget v0, v2.Landroid/sec/multiwindow/MultiWindowImpl;->mMethodMap:Ljava/util/HashMap;
    0002: invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/util/Pair;
    0008: iget v1, v0.Landroid/util/Pair;->second:Ljava/lang/Object;
    000a: check-cast v1, Ljava/lang/reflect/Method;
    000c: iget v0, v0.Landroid/util/Pair;->first:Ljava/lang/Object;
    000e: invoke-virtual {v1, v0, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    0011: move-result-object v0
    0012: return-object v0
    0013: move-exception v0
    0014: invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V
    0017: const/4 v0, 0
    0018: goto 0012

  [Virtual Method] mode(I) -> I
    // registers=6, ins=2, outs=3, insns_size=23
    0000: const-string v0, 'mode'
    0002: const/4 v1, 1
    0003: new-array v1, v1, [Ljava/lang/Object;
    0005: const/4 v2, 0
    0006: invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0009: move-result-object v3
    000a: aput(op=4d) v3, v1[v2]
    000c: invoke-virtual {v4, v0, v1}, Landroid/sec/multiwindow/MultiWindowImpl;->invoke(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    000f: move-result-object v0
    0010: check-cast v0, Ljava/lang/Integer;
    0012: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    0015: move-result v0
    0016: return v0

  [Virtual Method] option(I) -> I
    // registers=6, ins=2, outs=3, insns_size=23
    0000: const-string v0, 'option'
    0002: const/4 v1, 1
    0003: new-array v1, v1, [Ljava/lang/Object;
    0005: const/4 v2, 0
    0006: invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    0009: move-result-object v3
    000a: aput(op=4d) v3, v1[v2]
    000c: invoke-virtual {v4, v0, v1}, Landroid/sec/multiwindow/MultiWindowImpl;->invoke(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    000f: move-result-object v0
    0010: check-cast v0, Ljava/lang/Integer;
    0012: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    0015: move-result v0
    0016: return v0

  [Virtual Method] putMethod(Ljava/lang/Class;, Ljava/lang/Object;, Ljava/lang/String;, [Ljava/lang/Class;) -> V
    // registers=8, ins=5, outs=3, insns_size=17
    0000: invoke-virtual {v4, v6, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    0003: move-result-object v0
    0004: iget v1, v3.Landroid/sec/multiwindow/MultiWindowImpl;->mMethodMap:Ljava/util/HashMap;
    0006: new-instance v2, Landroid/util/Pair;
    0008: invoke-direct {v2, v5, v0}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V
    000b: invoke-virtual {v1, v6, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    000e: return-void
    000f: move-exception v0
    0010: goto 000e