=== CLASS Landroid/sec/multiwindow/MultiWindow; (Source: MultiWindow.java) ===
  Super: Landroid/sec/multiwindow/MultiWindowImpl;
  Interfaces: Landroid/sec/multiwindow/IMultiWindow;
  [Static Field] TAG: Ljava/lang/String; = 'MultiWindow'
  [Instance Field] mActivity: Landroid/app/Activity;
  [Instance Field] mArrangeable: Z
  [Instance Field] mDefaultSize: Landroid/graphics/Rect;
  [Instance Field] mMaximumSize: Landroid/graphics/Rect;
  [Instance Field] mMinimumSize: Landroid/graphics/Rect;
  [Instance Field] mWindowMode: I

  [Direct Method] <init>(Landroid/app/Activity;) -> V
    // registers=10, ins=2, outs=5, insns_size=120
    0000: const/4 v1, 0
    0001: const/4 v7, 1
    0002: const/4 v6, 0
    0003: invoke-direct {v8, v9}, Landroid/sec/multiwindow/MultiWindowImpl;-><init>(Landroid/content/Context;)V
    0006: iput v7, v8.Landroid/sec/multiwindow/MultiWindow;->mArrangeable:Z
    0008: iput v9, v8.Landroid/sec/multiwindow/MultiWindow;->mActivity:Landroid/app/Activity;
    000a: iget v0, v8.Landroid/sec/multiwindow/MultiWindow;->mActivity:Landroid/app/Activity;
    000c: invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    000f: move-result-object v2
    0010: iget v3, v8.Landroid/sec/multiwindow/MultiWindow;->mActivity:Landroid/app/Activity;
    0012: const-string v4, 'getWindowMode'
    0014: move(op=07) v0, v1
    0015: check-cast v0, [Ljava/lang/Class;
    0017: invoke-virtual {v8, v2, v3, v4, v0}, Landroid/sec/multiwindow/MultiWindow;->putMethod(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;)V
    001a: iget v0, v8.Landroid/sec/multiwindow/MultiWindow;->mActivity:Landroid/app/Activity;
    001c: const-string v3, 'setWindowMode'
    001e: const/4 v4, 2
    001f: new-array v4, v4, [Ljava/lang/Class;
    0021: sget v5, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;
    0023: aput(op=4d) v5, v4[v6]
    0025: sget v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;
    0027: aput(op=4d) v5, v4[v7]
    0029: invoke-virtual {v8, v2, v0, v3, v4}, Landroid/sec/multiwindow/MultiWindow;->putMethod(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;)V
    002c: iget v0, v8.Landroid/sec/multiwindow/MultiWindow;->mActivity:Landroid/app/Activity;
    002e: const-string v3, 'getWindowInfo'
    0030: check-cast v1, [Ljava/lang/Class;
    0032: invoke-virtual {v8, v2, v0, v3, v1}, Landroid/sec/multiwindow/MultiWindow;->putMethod(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;)V
    0035: iget v0, v8.Landroid/sec/multiwindow/MultiWindow;->mActivity:Landroid/app/Activity;
    0037: const-string v1, 'setWindowInfo'
    0039: new-array v3, v7, [Ljava/lang/Class;
    003b: const-class v4, Landroid/os/Bundle;
    003d: aput(op=4d) v4, v3[v6]
    003f: invoke-virtual {v8, v2, v0, v1, v3}, Landroid/sec/multiwindow/MultiWindow;->putMethod(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Class;)V
    0042: invoke-direct {v8}, Landroid/sec/multiwindow/MultiWindow;->getWindowInfo()Landroid/os/Bundle;
    0045: move-result-object v1
    0046: sget v0, Landroid/sec/multiwindow/Constants$Intent;->EXTRA_WINDOW_DEFAULT_SIZE:Ljava/lang/String;
    0048: invoke-virtual {v1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;
    004b: move-result-object v0
    004c: check-cast v0, Landroid/graphics/Rect;
    004e: iput v0, v8.Landroid/sec/multiwindow/MultiWindow;->mDefaultSize:Landroid/graphics/Rect;
    0050: sget v0, Landroid/sec/multiwindow/Constants$Intent;->EXTRA_WINDOW_MINIMUM_SIZE:Ljava/lang/String;
    0052: invoke-virtual {v1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;
    0055: move-result-object v0
    0056: check-cast v0, Landroid/graphics/Rect;
    0058: iput v0, v8.Landroid/sec/multiwindow/MultiWindow;->mMinimumSize:Landroid/graphics/Rect;
    005a: new-instance v0, Landroid/graphics/Point;
    005c: invoke-direct {v0}, Landroid/graphics/Point;-><init>()V
    005f: iget v1, v8.Landroid/sec/multiwindow/MultiWindow;->mActivity:Landroid/app/Activity;
    0061: invoke-virtual {v1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;
    0064: move-result-object v1
    0065: invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;
    0068: move-result-object v1
    0069: invoke-virtual {v1, v0}, Landroid/view/Display;->getSize(Landroid/graphics/Point;)V
    006c: new-instance v1, Landroid/graphics/Rect;
    006e: iget v2, v0.Landroid/graphics/Point;->x:I
    0070: iget v0, v0.Landroid/graphics/Point;->y:I
    0072: invoke-direct {v1, v6, v6, v2, v0}, Landroid/graphics/Rect;-><init>(IIII)V
    0075: iput v1, v8.Landroid/sec/multiwindow/MultiWindow;->mMaximumSize:Landroid/graphics/Rect;
    0077: return-void

  [Direct Method] <init>(Landroid/content/Context;, Landroid/sec/multiwindow/IMultiWindowService;, Landroid/content/ComponentName;) -> V
    // registers=5, ins=4, outs=2, insns_size=7
    0000: invoke-direct {v1, v2}, Landroid/sec/multiwindow/MultiWindowImpl;-><init>(Landroid/content/Context;)V
    0003: const/4 v0, 1
    0004: iput v0, v1.Landroid/sec/multiwindow/MultiWindow;->mArrangeable:Z
    0006: return-void

  [Direct Method] <init>(Landroid/content/Context;, Landroid/sec/multiwindow/IMultiWindowService;, Landroid/content/Intent;) -> V
    // registers=5, ins=4, outs=2, insns_size=7
    0000: invoke-direct {v1, v2}, Landroid/sec/multiwindow/MultiWindowImpl;-><init>(Landroid/content/Context;)V
    0003: const/4 v0, 1
    0004: iput v0, v1.Landroid/sec/multiwindow/MultiWindow;->mArrangeable:Z
    0006: return-void

  [Direct Method] checkMode(I) -> Z
    // registers=3, ins=2, outs=2, insns_size=12
    0000: iget v0, v1.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0002: invoke-virtual {v1, v0}, Landroid/sec/multiwindow/MultiWindow;->mode(I)I
    0005: move-result v0
    0006: if-ne v0, v2, 000a
    0008: const/4 v0, 1
    0009: return v0
    000a: const/4 v0, 0
    000b: goto 0009

  [Direct Method] checkOption(I) -> Z
    // registers=3, ins=2, outs=2, insns_size=13
    0000: iget v0, v1.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0002: invoke-virtual {v1, v0}, Landroid/sec/multiwindow/MultiWindow;->option(I)I
    0005: move-result v0
    0006: binop/2addr(op=b5) v0, v2
    0007: if-eqz v0, 000b
    0009: const/4 v0, 1
    000a: return v0
    000b: const/4 v0, 0
    000c: goto 000a

  [Direct Method] createInstance(Landroid/app/Activity;) -> Landroid/sec/multiwindow/MultiWindow;
    // registers=4, ins=1, outs=2, insns_size=22
    0000: const/4 v0, 0
    0001: if-nez v3, 0004
    0003: return-object v0
    0004: invoke-virtual {v3}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;
    0007: move-result-object v1
    0008: sget v2, Landroid/sec/multiwindow/Constants$PackageManager;->FEATURE_MULTIWINDOW:Ljava/lang/String;
    000a: invoke-virtual {v1, v2}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z
    000d: move-result v1
    000e: if-eqz v1, 0003
    0010: new-instance v0, Landroid/sec/multiwindow/MultiWindow;
    0012: invoke-direct {v0, v3}, Landroid/sec/multiwindow/MultiWindow;-><init>(Landroid/app/Activity;)V
    0015: goto 0003

  [Direct Method] getLastSize() -> Landroid/graphics/Rect;
    // registers=3, ins=1, outs=2, insns_size=18
    0000: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->getWindowInfo()Landroid/os/Bundle;
    0003: move-result-object v0
    0004: sget v1, Landroid/sec/multiwindow/Constants$Intent;->EXTRA_WINDOW_LAST_SIZE:Ljava/lang/String;
    0006: invoke-virtual {v0, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;
    0009: move-result-object v0
    000a: check-cast v0, Landroid/graphics/Rect;
    000c: if-eqz v0, 000f
    000e: return-object v0
    000f: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mDefaultSize:Landroid/graphics/Rect;
    0011: goto 000e

  [Direct Method] getWindowInfo() -> Landroid/os/Bundle;
    // registers=3, ins=1, outs=3, insns_size=12
    0000: const-string v1, 'getWindowInfo'
    0002: const/4 v0, 0
    0003: check-cast v0, [Ljava/lang/Object;
    0005: invoke-virtual {v2, v1, v0}, Landroid/sec/multiwindow/MultiWindow;->invoke(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    0008: move-result-object v0
    0009: check-cast v0, Landroid/os/Bundle;
    000b: return-object v0

  [Direct Method] isEnabledComponentName(Landroid/content/Context;, Landroid/content/ComponentName;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Direct Method] setLastSize(Landroid/graphics/Rect;) -> V
    // registers=4, ins=2, outs=3, insns_size=13
    0000: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->getWindowInfo()Landroid/os/Bundle;
    0003: move-result-object v0
    0004: sget v1, Landroid/sec/multiwindow/Constants$Intent;->EXTRA_WINDOW_LAST_SIZE:Ljava/lang/String;
    0006: invoke-virtual {v0, v1, v3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V
    0009: invoke-direct {v2, v0}, Landroid/sec/multiwindow/MultiWindow;->setWindowInfo(Landroid/os/Bundle;)V
    000c: return-void

  [Direct Method] setWindowInfo(Landroid/os/Bundle;) -> V
    // registers=5, ins=2, outs=3, insns_size=12
    0000: const-string v0, 'setWindowInfo'
    0002: const/4 v1, 1
    0003: new-array v1, v1, [Ljava/lang/Object;
    0005: const/4 v2, 0
    0006: aput(op=4d) v4, v1[v2]
    0008: invoke-virtual {v3, v0, v1}, Landroid/sec/multiwindow/MultiWindow;->invoke(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    000b: return-void

  [Direct Method] setWindowMode(I) -> V
    // registers=7, ins=2, outs=3, insns_size=23
    0000: const/4 v4, 1
    0001: const-string v0, 'setWindowMode'
    0003: const/4 v1, 2
    0004: new-array v1, v1, [Ljava/lang/Object;
    0006: const/4 v2, 0
    0007: invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;
    000a: move-result-object v3
    000b: aput(op=4d) v3, v1[v2]
    000d: invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;
    0010: move-result-object v2
    0011: aput(op=4d) v2, v1[v4]
    0013: invoke-virtual {v5, v0, v1}, Landroid/sec/multiwindow/MultiWindow;->invoke(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    0016: return-void

  [Direct Method] setWindowParams() -> V
    // registers=6, ins=1, outs=2, insns_size=71
    0000: const/4 v4, -1
    0001: const/4 v3, 0
    0002: iget v0, v5.Landroid/sec/multiwindow/MultiWindow;->mActivity:Landroid/app/Activity;
    0004: invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;
    0007: move-result-object v0
    0008: invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;
    000b: move-result-object v0
    000c: iget v1, v5.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    000e: invoke-virtual {v5, v1}, Landroid/sec/multiwindow/MultiWindow;->mode(I)I
    0011: move-result v1
    0012: sget v2, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_FREESTYLE:I
    0014: if-ne v1, v2, 003c
    0016: invoke-direct {v5}, Landroid/sec/multiwindow/MultiWindow;->getLastSize()Landroid/graphics/Rect;
    0019: move-result-object v1
    001a: iget v2, v1.Landroid/graphics/Rect;->left:I
    001c: iput v2, v0.Landroid/view/WindowManager$LayoutParams;->x:I
    001e: iget v2, v1.Landroid/graphics/Rect;->top:I
    0020: iput v2, v0.Landroid/view/WindowManager$LayoutParams;->y:I
    0022: invoke-virtual {v1}, Landroid/graphics/Rect;->width()I
    0025: move-result v2
    0026: iput v2, v0.Landroid/view/WindowManager$LayoutParams;->width:I
    0028: invoke-virtual {v1}, Landroid/graphics/Rect;->height()I
    002b: move-result v1
    002c: iput v1, v0.Landroid/view/WindowManager$LayoutParams;->height:I
    002e: const/16 v1, 51 (0x33)
    0030: iput v1, v0.Landroid/view/WindowManager$LayoutParams;->gravity:I
    0032: iget v1, v5.Landroid/sec/multiwindow/MultiWindow;->mActivity:Landroid/app/Activity;
    0034: invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;
    0037: move-result-object v1
    0038: invoke-virtual {v1, v0}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V
    003b: return-void
    003c: iput v3, v0.Landroid/view/WindowManager$LayoutParams;->x:I
    003e: iput v3, v0.Landroid/view/WindowManager$LayoutParams;->y:I
    0040: iput v4, v0.Landroid/view/WindowManager$LayoutParams;->width:I
    0042: iput v4, v0.Landroid/view/WindowManager$LayoutParams;->height:I
    0044: iput v3, v0.Landroid/view/WindowManager$LayoutParams;->gravity:I
    0046: goto 0032

  [Direct Method] updateWindowMode() -> V
    // registers=3, ins=1, outs=3, insns_size=18
    0000: const-string v1, 'getWindowMode'
    0002: const/4 v0, 0
    0003: check-cast v0, [Ljava/lang/Object;
    0005: invoke-virtual {v2, v1, v0}, Landroid/sec/multiwindow/MultiWindow;->invoke(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    0008: move-result-object v0
    0009: check-cast v0, Ljava/lang/Integer;
    000b: invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
    000e: move-result v0
    000f: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0011: return-void

  [Virtual Method] finish() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] finish(I) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] fitToHalf(I) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] getArrangeable() -> Z
    // registers=2, ins=1, outs=0, insns_size=3
    0000: iget v0, v1.Landroid/sec/multiwindow/MultiWindow;->mArrangeable:Z
    0002: return v0

  [Virtual Method] getHeight() -> I
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, -1
    0001: return v0

  [Virtual Method] getMinimumSize() -> Landroid/graphics/Point;
    // registers=3, ins=1, outs=3, insns_size=7
    0000: const/4 v1, -1
    0001: new-instance v0, Landroid/graphics/Point;
    0003: invoke-direct {v0, v1, v1}, Landroid/graphics/Point;-><init>(II)V
    0006: return-object v0

  [Virtual Method] getMultiWindowEnabled() -> Z
    // registers=2, ins=1, outs=2, insns_size=10
    0000: invoke-direct {v1}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    0003: sget v0, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_RESIZE:I
    0005: invoke-direct {v1, v0}, Landroid/sec/multiwindow/MultiWindow;->checkOption(I)Z
    0008: move-result v0
    0009: return v0

  [Virtual Method] getRect() -> Landroid/graphics/Rect;
    // registers=2, ins=1, outs=1, insns_size=17
    0000: invoke-virtual {v1}, Landroid/sec/multiwindow/MultiWindow;->isMultiWindow()Z
    0003: move-result v0
    0004: if-eqz v0, 000e
    0006: invoke-direct {v1}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    0009: invoke-direct {v1}, Landroid/sec/multiwindow/MultiWindow;->getLastSize()Landroid/graphics/Rect;
    000c: move-result-object v0
    000d: return-object v0
    000e: iget v0, v1.Landroid/sec/multiwindow/MultiWindow;->mMaximumSize:Landroid/graphics/Rect;
    0010: goto 000d

  [Virtual Method] getRect(I) -> Landroid/graphics/Rect;
    // registers=3, ins=2, outs=1, insns_size=6
    0000: new-instance v0, Landroid/graphics/Rect;
    0002: invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V
    0005: return-object v0

  [Virtual Method] getWidth() -> I
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, -1
    0001: return v0

  [Virtual Method] isMaximized() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isMaximized(I) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isMinimized() -> Z
    // registers=2, ins=1, outs=2, insns_size=23
    0000: invoke-direct {v1}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    0003: sget v0, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_FREESTYLE:I
    0005: invoke-direct {v1, v0}, Landroid/sec/multiwindow/MultiWindow;->checkMode(I)Z
    0008: move-result v0
    0009: if-eqz v0, 0015
    000b: sget v0, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_MINIMIZED:I
    000d: invoke-direct {v1, v0}, Landroid/sec/multiwindow/MultiWindow;->checkOption(I)Z
    0010: move-result v0
    0011: if-eqz v0, 0015
    0013: const/4 v0, 1
    0014: return v0
    0015: const/4 v0, 0
    0016: goto 0014

  [Virtual Method] isMultiWindow() -> Z
    // registers=2, ins=1, outs=2, insns_size=10
    0000: invoke-direct {v1}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    0003: sget v0, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_FREESTYLE:I
    0005: invoke-direct {v1, v0}, Landroid/sec/multiwindow/MultiWindow;->checkMode(I)Z
    0008: move-result v0
    0009: return v0

  [Virtual Method] isNormalWindow() -> Z
    // registers=2, ins=1, outs=2, insns_size=10
    0000: invoke-direct {v1}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    0003: sget v0, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_NORMAL:I
    0005: invoke-direct {v1, v0}, Landroid/sec/multiwindow/MultiWindow;->checkMode(I)Z
    0008: move-result v0
    0009: return v0

  [Virtual Method] isPinup() -> Z
    // registers=2, ins=1, outs=2, insns_size=23
    0000: invoke-direct {v1}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    0003: sget v0, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_FREESTYLE:I
    0005: invoke-direct {v1, v0}, Landroid/sec/multiwindow/MultiWindow;->checkMode(I)Z
    0008: move-result v0
    0009: if-eqz v0, 0015
    000b: sget v0, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_PINUP:I
    000d: invoke-direct {v1, v0}, Landroid/sec/multiwindow/MultiWindow;->checkOption(I)Z
    0010: move-result v0
    0011: if-eqz v0, 0015
    0013: const/4 v0, 1
    0014: return v0
    0015: const/4 v0, 0
    0016: goto 0014

  [Virtual Method] isStartedAsPinup() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] isStartingSplitScreen(Landroid/content/ComponentName;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] maximize() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] minimize() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] minimize(I) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] minimize(Z) -> Z
    // registers=5, ins=2, outs=2, insns_size=62
    0000: const/4 v1, 1
    0001: const/4 v0, 0
    0002: invoke-virtual {v3}, Landroid/sec/multiwindow/MultiWindow;->isMultiWindow()Z
    0005: move-result v2
    0006: if-nez v2, 0009
    0008: return v0
    0009: invoke-direct {v3}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    000c: invoke-virtual {v3}, Landroid/sec/multiwindow/MultiWindow;->getMultiWindowEnabled()Z
    000f: move-result v2
    0010: if-eqz v2, 0008
    0012: invoke-virtual {v3}, Landroid/sec/multiwindow/MultiWindow;->isMinimized()Z
    0015: move-result v0
    0016: if-ne v4, v0, 001a
    0018: move(op=01) v0, v1
    0019: goto 0008
    001a: if-eqz v4, 0034
    001c: iget v0, v3.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    001e: sget v2, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_MINIMIZED:I
    0020: binop/2addr(op=b6) v0, v2
    0021: iput v0, v3.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0023: iget v0, v3.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0025: sget v2, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_PINUP:I
    0027: binop/2addr(op=b6) v0, v2
    0028: iput v0, v3.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    002a: iget v0, v3.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    002c: invoke-direct {v3, v0}, Landroid/sec/multiwindow/MultiWindow;->setWindowMode(I)V
    002f: invoke-direct {v3}, Landroid/sec/multiwindow/MultiWindow;->setWindowParams()V
    0032: move(op=01) v0, v1
    0033: goto 0008
    0034: iget v0, v3.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0036: sget v2, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_MINIMIZED:I
    0038: binop/lit8(op=df) v2, v2, -1 (-0x1)
    003a: binop/2addr(op=b5) v0, v2
    003b: iput v0, v3.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    003d: goto 002a

  [Virtual Method] multiWindow() -> Z
    // registers=2, ins=1, outs=3, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v0, v0}, Landroid/sec/multiwindow/MultiWindow;->multiWindow(ZZ)Z
    0004: move-result v0
    0005: return v0

  [Virtual Method] multiWindow(Z) -> Z
    // registers=3, ins=2, outs=3, insns_size=6
    0000: const/4 v0, 0
    0001: invoke-virtual {v1, v2, v0}, Landroid/sec/multiwindow/MultiWindow;->multiWindow(ZZ)Z
    0004: move-result v0
    0005: return v0

  [Virtual Method] multiWindow(Z, Z) -> Z
    // registers=5, ins=3, outs=2, insns_size=81
    0000: const/4 v0, 0
    0001: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    0004: invoke-virtual {v2}, Landroid/sec/multiwindow/MultiWindow;->getMultiWindowEnabled()Z
    0007: move-result v1
    0008: if-nez v1, 000b
    000a: return v0
    000b: invoke-virtual {v2}, Landroid/sec/multiwindow/MultiWindow;->isMultiWindow()Z
    000e: move-result v1
    000f: if-nez v1, 000a
    0011: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0013: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_MASK:I
    0015: binop/lit8(op=df) v1, v1, -1 (-0x1)
    0017: binop/2addr(op=b5) v0, v1
    0018: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    001a: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    001c: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_FREESTYLE:I
    001e: binop/2addr(op=b6) v0, v1
    001f: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0021: if-eqz v3, 003d
    0023: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0025: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_PINUP:I
    0027: binop/2addr(op=b6) v0, v1
    0028: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    002a: if-eqz v4, 0047
    002c: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    002e: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_MINIMIZED:I
    0030: binop/2addr(op=b6) v0, v1
    0031: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0033: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->setWindowParams()V
    0036: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0038: invoke-direct {v2, v0}, Landroid/sec/multiwindow/MultiWindow;->setWindowMode(I)V
    003b: const/4 v0, 1
    003c: goto 000a
    003d: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    003f: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_PINUP:I
    0041: binop/lit8(op=df) v1, v1, -1 (-0x1)
    0043: binop/2addr(op=b5) v0, v1
    0044: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0046: goto 002a
    0047: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0049: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_MINIMIZED:I
    004b: binop/lit8(op=df) v1, v1, -1 (-0x1)
    004d: binop/2addr(op=b5) v0, v1
    004e: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0050: goto 0033

  [Virtual Method] normalWindow() -> Z
    // registers=3, ins=1, outs=2, insns_size=47
    0000: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    0003: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0005: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_MASK:I
    0007: binop/lit8(op=df) v1, v1, -1 (-0x1)
    0009: binop/2addr(op=b5) v0, v1
    000a: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    000c: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    000e: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_NORMAL:I
    0010: binop/2addr(op=b6) v0, v1
    0011: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0013: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0015: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_PINUP:I
    0017: binop/lit8(op=df) v1, v1, -1 (-0x1)
    0019: binop/2addr(op=b5) v0, v1
    001a: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    001c: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    001e: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_MINIMIZED:I
    0020: binop/lit8(op=df) v1, v1, -1 (-0x1)
    0022: binop/2addr(op=b5) v0, v1
    0023: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0025: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0027: invoke-direct {v2, v0}, Landroid/sec/multiwindow/MultiWindow;->setWindowMode(I)V
    002a: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->setWindowParams()V
    002d: const/4 v0, 1
    002e: return v0

  [Virtual Method] pinUp(Z) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] pinUp(Z, I) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] pinup(Z) -> Z
    // registers=4, ins=2, outs=2, insns_size=46
    0000: const/4 v0, 0
    0001: invoke-virtual {v2}, Landroid/sec/multiwindow/MultiWindow;->isMultiWindow()Z
    0004: move-result v1
    0005: if-nez v1, 0008
    0007: return v0
    0008: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    000b: invoke-virtual {v2}, Landroid/sec/multiwindow/MultiWindow;->getMultiWindowEnabled()Z
    000e: move-result v1
    000f: if-eqz v1, 0007
    0011: if-eqz v3, 0024
    0013: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0015: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_PINUP:I
    0017: binop/2addr(op=b6) v0, v1
    0018: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    001a: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    001c: invoke-direct {v2, v0}, Landroid/sec/multiwindow/MultiWindow;->setWindowMode(I)V
    001f: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->setWindowParams()V
    0022: const/4 v0, 1
    0023: goto 0007
    0024: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0026: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_PINUP:I
    0028: binop/lit8(op=df) v1, v1, -1 (-0x1)
    002a: binop/2addr(op=b5) v0, v1
    002b: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    002d: goto 001a

  [Virtual Method] relayout(Landroid/graphics/Rect;) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] restore() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] restore(I) -> Z
    // registers=3, ins=2, outs=0, insns_size=2
    0000: const/4 v0, 1
    0001: return v0

  [Virtual Method] setArrangeable(Z) -> Z
    // registers=3, ins=2, outs=0, insns_size=4
    0000: iput v2, v1.Landroid/sec/multiwindow/MultiWindow;->mArrangeable:Z
    0002: const/4 v0, 1
    0003: return v0

  [Virtual Method] setMinimumSize(I, I) -> Z
    // registers=4, ins=3, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0

  [Virtual Method] setMultiWindowEnabled(Z) -> Z
    // registers=4, ins=2, outs=2, insns_size=66
    0000: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    0003: if-eqz v3, 0016
    0005: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0007: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_RESIZE:I
    0009: binop/2addr(op=b6) v0, v1
    000a: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    000c: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    000e: invoke-direct {v2, v0}, Landroid/sec/multiwindow/MultiWindow;->setWindowMode(I)V
    0011: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->setWindowParams()V
    0014: const/4 v0, 1
    0015: return v0
    0016: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0018: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_MASK:I
    001a: binop/lit8(op=df) v1, v1, -1 (-0x1)
    001c: binop/2addr(op=b5) v0, v1
    001d: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    001f: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0021: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_NORMAL:I
    0023: binop/2addr(op=b6) v0, v1
    0024: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0026: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0028: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_PINUP:I
    002a: binop/lit8(op=df) v1, v1, -1 (-0x1)
    002c: binop/2addr(op=b5) v0, v1
    002d: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    002f: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0031: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_MINIMIZED:I
    0033: binop/lit8(op=df) v1, v1, -1 (-0x1)
    0035: binop/2addr(op=b5) v0, v1
    0036: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0038: iget v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    003a: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->WINDOW_MODE_OPTION_COMMON_RESIZE:I
    003c: binop/lit8(op=df) v1, v1, -1 (-0x1)
    003e: binop/2addr(op=b5) v0, v1
    003f: iput v0, v2.Landroid/sec/multiwindow/MultiWindow;->mWindowMode:I
    0041: goto 000c

  [Virtual Method] setRect(Landroid/graphics/Rect;) -> Z
    // registers=4, ins=2, outs=2, insns_size=63
    0000: if-eqz v3, 003d
    0002: invoke-virtual {v3}, Landroid/graphics/Rect;->height()I
    0005: move-result v0
    0006: iget v1, v2.Landroid/sec/multiwindow/MultiWindow;->mMinimumSize:Landroid/graphics/Rect;
    0008: invoke-virtual {v1}, Landroid/graphics/Rect;->height()I
    000b: move-result v1
    000c: if-lt v0, v1, 003d
    000e: invoke-virtual {v3}, Landroid/graphics/Rect;->width()I
    0011: move-result v0
    0012: iget v1, v2.Landroid/sec/multiwindow/MultiWindow;->mMinimumSize:Landroid/graphics/Rect;
    0014: invoke-virtual {v1}, Landroid/graphics/Rect;->width()I
    0017: move-result v1
    0018: if-lt v0, v1, 003d
    001a: invoke-virtual {v3}, Landroid/graphics/Rect;->height()I
    001d: move-result v0
    001e: iget v1, v2.Landroid/sec/multiwindow/MultiWindow;->mMaximumSize:Landroid/graphics/Rect;
    0020: invoke-virtual {v1}, Landroid/graphics/Rect;->height()I
    0023: move-result v1
    0024: if-gt v0, v1, 003d
    0026: invoke-virtual {v3}, Landroid/graphics/Rect;->width()I
    0029: move-result v0
    002a: iget v1, v2.Landroid/sec/multiwindow/MultiWindow;->mMaximumSize:Landroid/graphics/Rect;
    002c: invoke-virtual {v1}, Landroid/graphics/Rect;->width()I
    002f: move-result v1
    0030: if-gt v0, v1, 003d
    0032: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->updateWindowMode()V
    0035: invoke-direct {v2, v3}, Landroid/sec/multiwindow/MultiWindow;->setLastSize(Landroid/graphics/Rect;)V
    0038: invoke-direct {v2}, Landroid/sec/multiwindow/MultiWindow;->setWindowParams()V
    003b: const/4 v0, 1
    003c: return v0
    003d: const/4 v0, 0
    003e: goto 003c

  [Virtual Method] start() -> Z
    // registers=2, ins=1, outs=0, insns_size=2
    0000: const/4 v0, 0
    0001: return v0