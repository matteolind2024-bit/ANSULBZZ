=== CLASS Landroid/sec/multiwindow/IMultiWindowManager; (Source: IMultiWindowManager.java) ===
  Super: Ljava/lang/Object;
  [Static Field] LEFT: I = 0
  [Static Field] RIGHT: I = 1
  [Static Field] SERVICE_NAME: Ljava/lang/String; = 'multiwindow'

  [Virtual Method] arrangeWindows(I) -> Z

  [Virtual Method] capture(Landroid/content/ComponentName;) -> Landroid/graphics/Bitmap;

  [Virtual Method] exchangeSplitScreens() -> Z

  [Virtual Method] finishAllWindow() -> Z

  [Virtual Method] finishAppPid(I) -> Z

  [Virtual Method] getMultiLayout() -> Z

  [Virtual Method] getMultiWindowList() -> Ljava/util/List;

  [Virtual Method] getMultiWindowList(Landroid/content/ComponentName;) -> Ljava/util/List;

  [Virtual Method] getMultiWindowMode() -> Landroid/sec/multiwindow/MultiWindowType;

  [Virtual Method] getPinupWindow() -> Landroid/content/ComponentName;

  [Virtual Method] getPinupWindowList() -> Ljava/util/List;

  [Virtual Method] getResumedWindow() -> Landroid/content/ComponentName;

  [Virtual Method] getRunningWindowList() -> Ljava/util/List;

  [Virtual Method] getSplitList() -> Ljava/util/List;

  [Virtual Method] getVisibleWindowList() -> Ljava/util/List;

  [Virtual Method] getWindowInstance(Landroid/content/ComponentName;) -> Landroid/sec/multiwindow/IMultiWindow;

  [Virtual Method] getWindowInstance(Landroid/content/Intent;) -> Landroid/sec/multiwindow/IMultiWindow;

  [Virtual Method] isMultiWindow(Landroid/content/ComponentName;) -> Z

  [Virtual Method] isPermissionOff() -> Z

  [Virtual Method] isPinup(Landroid/content/ComponentName;) -> Z

  [Virtual Method] isPinup(Landroid/content/ComponentName;, I) -> Z

  [Virtual Method] isRunning(Landroid/content/ComponentName;) -> Z

  [Virtual Method] isVisible(Landroid/content/ComponentName;) -> Z

  [Virtual Method] notifyFinished(Landroid/app/Activity;) -> Z

  [Virtual Method] notifyForceFinished(Landroid/content/ComponentName;) -> Z

  [Virtual Method] notifySIP(I) -> Z

  [Virtual Method] notifyStarted(Landroid/app/Activity;) -> Z

  [Virtual Method] orientationChangeRestore(Landroid/content/ComponentName;, I) -> Z

  [Virtual Method] postResume(Landroid/app/Activity;) -> Z

  [Virtual Method] registerMultiWindow(Landroid/content/ComponentName;) -> Landroid/sec/multiwindow/IMultiWindow;

  [Virtual Method] registerMultiWindow(Landroid/content/ComponentName;, I, I) -> Landroid/sec/multiwindow/IMultiWindow;

  [Virtual Method] registerMultiWindow(Landroid/content/ComponentName;, I, I, Z) -> Landroid/sec/multiwindow/IMultiWindow;

  [Virtual Method] registerMultiWindow(Landroid/content/ComponentName;, Ljava/util/List;) -> Landroid/sec/multiwindow/IMultiWindow;

  [Virtual Method] registerMultiWindowPair(Landroid/content/ComponentName;, Landroid/content/ComponentName;) -> Z

  [Virtual Method] removeMultiWindow(Landroid/content/ComponentName;) -> Z

  [Virtual Method] removeMultiWindowPair(Landroid/content/ComponentName;, Landroid/content/ComponentName;) -> Z

  [Virtual Method] screenShot(Landroid/content/ComponentName;) -> Landroid/graphics/Bitmap;

  [Virtual Method] sendCreateAction(Landroid/app/Activity;) -> Z

  [Virtual Method] sendDestroyAction(Landroid/app/Activity;) -> Z

  [Virtual Method] sendFinishAction(Landroid/app/Activity;) -> Z

  [Virtual Method] sendPauseAction(Landroid/app/Activity;) -> Z

  [Virtual Method] sendResumeAction(Landroid/app/Activity;) -> Z

  [Virtual Method] sendStartAction(Landroid/app/Activity;) -> Z

  [Virtual Method] setMultiLayout(Z) -> Z

  [Virtual Method] setMultiWindowMode(Landroid/sec/multiwindow/MultiWindowType;) -> Z

  [Virtual Method] setPreferenceValue(Z) -> V

  [Virtual Method] showSwitchWindowGuideDialog(Landroid/content/Context;) -> V

  [Virtual Method] startLauncher() -> Z

  [Virtual Method] startLauncher(Landroid/content/ComponentName;) -> Z

  [Virtual Method] startLauncher(Landroid/content/Context;) -> Z

  [Virtual Method] startLauncher(Landroid/content/Context;, Landroid/content/ComponentName;) -> Z

  [Virtual Method] startSplitScreens(Landroid/content/ComponentName;, Landroid/content/ComponentName;) -> Z

  [Virtual Method] startSplitScreens(Landroid/content/ComponentName;, Landroid/content/Intent;) -> Z

  [Virtual Method] startSplitScreens(Landroid/content/Intent;, Landroid/content/ComponentName;) -> Z

  [Virtual Method] startSplitScreensForLauncher(Landroid/content/ComponentName;, Landroid/content/ComponentName;) -> Z

  [Virtual Method] unRegisterMultiWindow(Landroid/content/ComponentName;) -> Z