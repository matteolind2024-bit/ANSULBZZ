=== CLASS Landroid/sec/multiwindow/MultiWindowType; (Source: MultiWindowType.java) ===
  Super: Ljava/lang/Enum;
  [Static Field] $VALUES: [Landroid/sec/multiwindow/MultiWindowType;

  [Direct Method] <clinit>() -> V
    // registers=1, ins=0, outs=0, insns_size=6
    0000: const/4 v0, 0
    0001: new-array v0, v0, [Landroid/sec/multiwindow/MultiWindowType;
    0003: sput v0, Landroid/sec/multiwindow/MultiWindowType;->$VALUES:[Landroid/sec/multiwindow/MultiWindowType;
    0005: return-void

  [Direct Method] <init>(Ljava/lang/String;, I) -> V
    // registers=3, ins=3, outs=3, insns_size=4
    0000: invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V
    0003: return-void

  [Direct Method] valueOf(Ljava/lang/String;) -> Landroid/sec/multiwindow/MultiWindowType;
    // registers=2, ins=1, outs=2, insns_size=9
    0000: const-class v0, Landroid/sec/multiwindow/MultiWindowType;
    0002: invoke-static {v0, v1}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
    0005: move-result-object v0
    0006: check-cast v0, Landroid/sec/multiwindow/MultiWindowType;
    0008: return-object v0

  [Direct Method] values() -> [Landroid/sec/multiwindow/MultiWindowType;
    // registers=1, ins=0, outs=1, insns_size=9
    0000: sget v0, Landroid/sec/multiwindow/MultiWindowType;->$VALUES:[Landroid/sec/multiwindow/MultiWindowType;
    0002: invoke-virtual {v0}, [Landroid/sec/multiwindow/MultiWindowType;->clone()Ljava/lang/Object;
    0005: move-result-object v0
    0006: check-cast v0, [Landroid/sec/multiwindow/MultiWindowType;
    0008: return-object v0