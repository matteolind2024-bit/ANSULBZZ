=== CLASS Landroid/sec/multiwindow/Constants$WindowManagerPolicy; (Source: Constants.java) ===
  Super: Ljava/lang/Object;
  [Static Field] FIELD_NAMES: [Ljava/lang/String;
  [Static Field] WINDOW_INFO_NOTHING_CHANGED: I
  [Static Field] WINDOW_INFO_SIZE_CHANGED: I
  [Static Field] WINDOW_MODE_FREESTYLE: I
  [Static Field] WINDOW_MODE_MASK: I
  [Static Field] WINDOW_MODE_NORMAL: I
  [Static Field] WINDOW_MODE_OPTION_COMMON_FIXED_RATIO: I
  [Static Field] WINDOW_MODE_OPTION_COMMON_FIXED_SIZE: I
  [Static Field] WINDOW_MODE_OPTION_COMMON_HIDDEN: I
  [Static Field] WINDOW_MODE_OPTION_COMMON_INHERIT: I
  [Static Field] WINDOW_MODE_OPTION_COMMON_MINIMIZED: I
  [Static Field] WINDOW_MODE_OPTION_COMMON_NO_DECORATION: I
  [Static Field] WINDOW_MODE_OPTION_COMMON_PINUP: I
  [Static Field] WINDOW_MODE_OPTION_COMMON_RESIZE: I

  [Direct Method] <clinit>() -> V
    // registers=5, ins=0, outs=3, insns_size=118
    0000: const/4 v0, 0
    0001: const/16 v1, 13 (0xd)
    0003: new-array v1, v1, [Ljava/lang/String;
    0005: const-string v2, 'WINDOW_MODE_MASK'
    0007: aput(op=4d) v2, v1[v0]
    0009: const/4 v2, 1
    000a: const-string v3, 'WINDOW_MODE_NORMAL'
    000c: aput(op=4d) v3, v1[v2]
    000e: const/4 v2, 2
    000f: const-string v3, 'WINDOW_MODE_FREESTYLE'
    0011: aput(op=4d) v3, v1[v2]
    0013: const/4 v2, 3
    0014: const-string v3, 'WINDOW_MODE_OPTION_COMMON_PINUP'
    0016: aput(op=4d) v3, v1[v2]
    0018: const/4 v2, 4
    0019: const-string v3, 'WINDOW_MODE_OPTION_COMMON_INHERIT'
    001b: aput(op=4d) v3, v1[v2]
    001d: const/4 v2, 5
    001e: const-string v3, 'WINDOW_MODE_OPTION_COMMON_RESIZE'
    0020: aput(op=4d) v3, v1[v2]
    0022: const/4 v2, 6
    0023: const-string v3, 'WINDOW_MODE_OPTION_COMMON_MINIMIZED'
    0025: aput(op=4d) v3, v1[v2]
    0027: const/4 v2, 7
    0028: const-string v3, 'WINDOW_MODE_OPTION_COMMON_HIDDEN'
    002a: aput(op=4d) v3, v1[v2]
    002c: const/16 v2, 8 (0x8)
    002e: const-string v3, 'WINDOW_MODE_OPTION_COMMON_FIXED_SIZE'
    0030: aput(op=4d) v3, v1[v2]
    0032: const/16 v2, 9 (0x9)
    0034: const-string v3, 'WINDOW_MODE_OPTION_COMMON_FIXED_RATIO'
    0036: aput(op=4d) v3, v1[v2]
    0038: const/16 v2, 10 (0xa)
    003a: const-string v3, 'WINDOW_INFO_NOTHING_CHANGED'
    003c: aput(op=4d) v3, v1[v2]
    003e: const/16 v2, 11 (0xb)
    0040: const-string v3, 'WINDOW_INFO_SIZE_CHANGED'
    0042: aput(op=4d) v3, v1[v2]
    0044: const/16 v2, 12 (0xc)
    0046: const-string v3, 'WINDOW_MODE_OPTION_COMMON_NO_DECORATION'
    0048: aput(op=4d) v3, v1[v2]
    004a: sput v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->FIELD_NAMES:[Ljava/lang/String;
    004c: sget v1, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->FIELD_NAMES:[Ljava/lang/String;
    004e: move(op=21) v1, v1
    004f: if-ge v0, v1, 006f
    0051: const-class v2, Landroid/view/WindowManagerPolicy;
    0053: sget v3, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->FIELD_NAMES:[Ljava/lang/String;
    0055: aget(op=46) v3, v3[v0]
    0057: invoke-virtual {v2, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    005a: move-result-object v2
    005b: const-class v3, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;
    005d: sget v4, Landroid/sec/multiwindow/Constants$WindowManagerPolicy;->FIELD_NAMES:[Ljava/lang/String;
    005f: aget(op=46) v4, v4[v0]
    0061: invoke-virtual {v3, v4}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    0064: move-result-object v3
    0065: invoke-virtual {v2, v2}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I
    0068: move-result v2
    0069: invoke-virtual {v3, v3, v2}, Ljava/lang/reflect/Field;->setInt(Ljava/lang/Object;I)V
    006c: binop/lit8(op=d8) v0, v0, 1 (0x1)
    006e: goto 004f
    006f: return-void
    0070: move-exception v2
    0071: goto 006c
    0072: move-exception v2
    0073: goto 006c
    0074: move-exception v2
    0075: goto 006c

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void