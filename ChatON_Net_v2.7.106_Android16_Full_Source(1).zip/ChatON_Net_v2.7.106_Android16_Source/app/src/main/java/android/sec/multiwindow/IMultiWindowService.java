=== CLASS Landroid/sec/multiwindow/IMultiWindowService; (Source: IMultiWindowService.java) ===
  Super: Ljava/lang/Object;

  [Virtual Method] getOptionMap(I) -> Z

  [Virtual Method] setOptionMap(I, Z) -> V