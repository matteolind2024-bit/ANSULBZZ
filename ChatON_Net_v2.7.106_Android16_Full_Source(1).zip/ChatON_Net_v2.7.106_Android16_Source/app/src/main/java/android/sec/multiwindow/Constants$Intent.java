=== CLASS Landroid/sec/multiwindow/Constants$Intent; (Source: Constants.java) ===
  Super: Ljava/lang/Object;
  [Static Field] ACTION_ARRANGE_WINDOWS: Ljava/lang/String;
  [Static Field] CATEGORY_MULTIWINDOW_LAUNCHER: Ljava/lang/String;
  [Static Field] EXTRA_ARRANGE_MODE: Ljava/lang/String;
  [Static Field] EXTRA_WINDOW_ARRANGED_SIZE: Ljava/lang/String;
  [Static Field] EXTRA_WINDOW_DEFAULT_SIZE: Ljava/lang/String;
  [Static Field] EXTRA_WINDOW_LAST_SIZE: Ljava/lang/String;
  [Static Field] EXTRA_WINDOW_MINIMIZED_SIZE: Ljava/lang/String;
  [Static Field] EXTRA_WINDOW_MINIMIZED_SLOT: Ljava/lang/String;
  [Static Field] EXTRA_WINDOW_MINIMUM_SIZE: Ljava/lang/String;
  [Static Field] EXTRA_WINDOW_MODE: Ljava/lang/String;
  [Static Field] EXTRA_WINDOW_OUT_OF_ARRANGE: Ljava/lang/String;
  [Static Field] EXTRA_WINDOW_POSITION: Ljava/lang/String;
  [Static Field] FIELD_NAMES: [Ljava/lang/String;
  [Static Field] METADATA_MULTIWINDOW_DEF_HEIGHT: Ljava/lang/String;
  [Static Field] METADATA_MULTIWINDOW_DEF_WIDTH: Ljava/lang/String;
  [Static Field] METADATA_MULTIWINDOW_MIN_HEIGHT: Ljava/lang/String;
  [Static Field] METADATA_MULTIWINDOW_MIN_WIDTH: Ljava/lang/String;
  [Static Field] METADATA_MULTIWINDOW_STYLE: Ljava/lang/String;
  [Static Field] METADATA_SUPPORT_MULTIWINDOW: Ljava/lang/String;

  [Direct Method] <clinit>() -> V
    // registers=5, ins=0, outs=3, insns_size=148
    0000: const/4 v0, 0
    0001: const/16 v1, 18 (0x12)
    0003: new-array v1, v1, [Ljava/lang/String;
    0005: const-string v2, 'EXTRA_WINDOW_MODE'
    0007: aput(op=4d) v2, v1[v0]
    0009: const/4 v2, 1
    000a: const-string v3, 'EXTRA_WINDOW_POSITION'
    000c: aput(op=4d) v3, v1[v2]
    000e: const/4 v2, 2
    000f: const-string v3, 'EXTRA_WINDOW_MINIMUM_SIZE'
    0011: aput(op=4d) v3, v1[v2]
    0013: const/4 v2, 3
    0014: const-string v3, 'EXTRA_WINDOW_MINIMIZED_SIZE'
    0016: aput(op=4d) v3, v1[v2]
    0018: const/4 v2, 4
    0019: const-string v3, 'EXTRA_WINDOW_MINIMIZED_SLOT'
    001b: aput(op=4d) v3, v1[v2]
    001d: const/4 v2, 5
    001e: const-string v3, 'EXTRA_WINDOW_DEFAULT_SIZE'
    0020: aput(op=4d) v3, v1[v2]
    0022: const/4 v2, 6
    0023: const-string v3, 'EXTRA_WINDOW_LAST_SIZE'
    0025: aput(op=4d) v3, v1[v2]
    0027: const/4 v2, 7
    0028: const-string v3, 'EXTRA_WINDOW_ARRANGED_SIZE'
    002a: aput(op=4d) v3, v1[v2]
    002c: const/16 v2, 8 (0x8)
    002e: const-string v3, 'EXTRA_WINDOW_OUT_OF_ARRANGE'
    0030: aput(op=4d) v3, v1[v2]
    0032: const/16 v2, 9 (0x9)
    0034: const-string v3, 'CATEGORY_MULTIWINDOW_LAUNCHER'
    0036: aput(op=4d) v3, v1[v2]
    0038: const/16 v2, 10 (0xa)
    003a: const-string v3, 'METADATA_SUPPORT_MULTIWINDOW'
    003c: aput(op=4d) v3, v1[v2]
    003e: const/16 v2, 11 (0xb)
    0040: const-string v3, 'METADATA_MULTIWINDOW_STYLE'
    0042: aput(op=4d) v3, v1[v2]
    0044: const/16 v2, 12 (0xc)
    0046: const-string v3, 'METADATA_MULTIWINDOW_MIN_WIDTH'
    0048: aput(op=4d) v3, v1[v2]
    004a: const/16 v2, 13 (0xd)
    004c: const-string v3, 'METADATA_MULTIWINDOW_MIN_HEIGHT'
    004e: aput(op=4d) v3, v1[v2]
    0050: const/16 v2, 14 (0xe)
    0052: const-string v3, 'METADATA_MULTIWINDOW_DEF_WIDTH'
    0054: aput(op=4d) v3, v1[v2]
    0056: const/16 v2, 15 (0xf)
    0058: const-string v3, 'METADATA_MULTIWINDOW_DEF_HEIGHT'
    005a: aput(op=4d) v3, v1[v2]
    005c: const/16 v2, 16 (0x10)
    005e: const-string v3, 'ACTION_ARRANGE_WINDOWS'
    0060: aput(op=4d) v3, v1[v2]
    0062: const/16 v2, 17 (0x11)
    0064: const-string v3, 'EXTRA_ARRANGE_MODE'
    0066: aput(op=4d) v3, v1[v2]
    0068: sput v1, Landroid/sec/multiwindow/Constants$Intent;->FIELD_NAMES:[Ljava/lang/String;
    006a: sget v1, Landroid/sec/multiwindow/Constants$Intent;->FIELD_NAMES:[Ljava/lang/String;
    006c: move(op=21) v1, v1
    006d: if-ge v0, v1, 008d
    006f: const-class v2, Landroid/content/Intent;
    0071: sget v3, Landroid/sec/multiwindow/Constants$Intent;->FIELD_NAMES:[Ljava/lang/String;
    0073: aget(op=46) v3, v3[v0]
    0075: invoke-virtual {v2, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    0078: move-result-object v2
    0079: const-class v3, Landroid/sec/multiwindow/Constants$Intent;
    007b: sget v4, Landroid/sec/multiwindow/Constants$Intent;->FIELD_NAMES:[Ljava/lang/String;
    007d: aget(op=46) v4, v4[v0]
    007f: invoke-virtual {v3, v4}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    0082: move-result-object v3
    0083: invoke-virtual {v2, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0086: move-result-object v2
    0087: invoke-virtual {v3, v3, v2}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    008a: binop/lit8(op=d8) v0, v0, 1 (0x1)
    008c: goto 006d
    008d: return-void
    008e: move-exception v2
    008f: goto 008a
    0090: move-exception v2
    0091: goto 008a
    0092: move-exception v2
    0093: goto 008a

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void