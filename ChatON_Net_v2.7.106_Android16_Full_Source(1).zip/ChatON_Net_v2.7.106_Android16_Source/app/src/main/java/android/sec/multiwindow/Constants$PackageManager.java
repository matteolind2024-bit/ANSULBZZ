=== CLASS Landroid/sec/multiwindow/Constants$PackageManager; (Source: Constants.java) ===
  Super: Ljava/lang/Object;
  [Static Field] FEATURE_MULTIWINDOW: Ljava/lang/String;
  [Static Field] FIELD_NAMES: [Ljava/lang/String;

  [Direct Method] <clinit>() -> V
    // registers=5, ins=0, outs=3, insns_size=52
    0000: const/4 v0, 0
    0001: const/4 v1, 1
    0002: new-array v1, v1, [Ljava/lang/String;
    0004: const-string v2, 'FEATURE_MULTIWINDOW'
    0006: aput(op=4d) v2, v1[v0]
    0008: sput v1, Landroid/sec/multiwindow/Constants$PackageManager;->FIELD_NAMES:[Ljava/lang/String;
    000a: sget v1, Landroid/sec/multiwindow/Constants$PackageManager;->FIELD_NAMES:[Ljava/lang/String;
    000c: move(op=21) v1, v1
    000d: if-ge v0, v1, 002d
    000f: const-class v2, Landroid/content/pm/PackageManager;
    0011: sget v3, Landroid/sec/multiwindow/Constants$PackageManager;->FIELD_NAMES:[Ljava/lang/String;
    0013: aget(op=46) v3, v3[v0]
    0015: invoke-virtual {v2, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    0018: move-result-object v2
    0019: const-class v3, Landroid/sec/multiwindow/Constants$PackageManager;
    001b: sget v4, Landroid/sec/multiwindow/Constants$PackageManager;->FIELD_NAMES:[Ljava/lang/String;
    001d: aget(op=46) v4, v4[v0]
    001f: invoke-virtual {v3, v4}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;
    0022: move-result-object v3
    0023: invoke-virtual {v2, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;
    0026: move-result-object v2
    0027: invoke-virtual {v3, v3, v2}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    002a: binop/lit8(op=d8) v0, v0, 1 (0x1)
    002c: goto 000d
    002d: return-void
    002e: move-exception v2
    002f: goto 002a
    0030: move-exception v2
    0031: goto 002a
    0032: move-exception v2
    0033: goto 002a

  [Direct Method] <init>() -> V
    // registers=1, ins=1, outs=1, insns_size=4
    0000: invoke-direct {v0}, Ljava/lang/Object;-><init>()V
    0003: return-void