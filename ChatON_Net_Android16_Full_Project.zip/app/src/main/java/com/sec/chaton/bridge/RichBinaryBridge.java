package com.sec.chaton.bridge;

import android.content.Context;
import com.sec.chaton.a.a.b;
import com.sec.chaton.d.a.a;
import com.sec.chaton.j.ak;
import com.sec.chaton.j.ao;

/**
 * ============================================================================
 * RichBinaryBridge — Unified Contract for BuzZz! Rich Binary (PC5/ProSe & r-RSS)
 * ============================================================================
 * All network and messaging operations in ChatON-Net are routed through this
 * single interface instead of Samsung's legacy GLD/REST/Netty servers:
 *   - ChatON Chats       <--> BuzZz! Hangouts (PC5 Sidelink / Local Socket)
 *   - ChatON Buddies     <--> BuzZz! Circles  (Presence & Mesh Peers)
 *   - ChatON Trunk       <--> BuzZz! Photos / Leftovers
 *   - @web@r-rss Channel <--> BuzZz! r-RSS Decentralized Web Crawler
 */
public interface RichBinaryBridge {

    /** Initialize the bridge (and seed local database in Mock mode). */
    void initialize(Context context);

    /**
     * Intercepts any Netty TCP Protobuf envelope (GpbTypeValue 0..52) from
     * AbstractNetTask / TcpClient and processes it locally or via Rich Binary.
     */
    void dispatchTcpEnvelope(ak tcpContext, ao requestEnvelope);

    /**
     * Intercepts any HTTP/REST request from AbstractChatONHttpTextTask / ChatONHttpClient2
     * and returns an immediate local HttpResultEntry (ResultEntry.SUCCESS).
     */
    b dispatchHttpRequest(a httpTask);

    /**
     * Sends a chat message to BuzZz! Hangouts (and triggers the 1-second Live Echo
     * in Mock mode).
     */
    long sendHangoutMessage(
            Context context,
            String inboxNo,
            String sessionId,
            int chatType,
            int contentType,
            String messageText,
            String[] receivers,
            long clientMsgId
    );

    /** Synchronizes Circles (Buddies & Groups) and Peer Presence from Rich Binary. */
    void syncCirclesAndPresence(Context context);

    /** Synchronizes Shared Leftovers / Photos for a Chat Room Trunk. */
    void syncTrunkLeftovers(Context context, String sessionId);
}
