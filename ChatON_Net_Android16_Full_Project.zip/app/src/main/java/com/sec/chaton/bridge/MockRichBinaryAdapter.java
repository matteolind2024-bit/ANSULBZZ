package com.sec.chaton.bridge;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.google.protobuf.GeneratedMessageLite;
import com.sec.chaton.a.a.b;
import com.sec.chaton.a.aa;
import com.sec.chaton.a.am;
import com.sec.chaton.a.aw;
import com.sec.chaton.a.ax;
import com.sec.chaton.a.az;
import com.sec.chaton.a.bj;
import com.sec.chaton.a.bk;
import com.sec.chaton.a.br;
import com.sec.chaton.a.bz;
import com.sec.chaton.a.ci;
import com.sec.chaton.a.co;
import com.sec.chaton.a.cx;
import com.sec.chaton.a.cy;
import com.sec.chaton.a.da;
import com.sec.chaton.a.dd;
import com.sec.chaton.a.dm;
import com.sec.chaton.a.dv;
import com.sec.chaton.a.ee;
import com.sec.chaton.a.em;
import com.sec.chaton.a.f;
import com.sec.chaton.a.fb;
import com.sec.chaton.a.fh;
import com.sec.chaton.a.fi;
import com.sec.chaton.a.fk;
import com.sec.chaton.a.fq;
import com.sec.chaton.a.fr;
import com.sec.chaton.a.ft;
import com.sec.chaton.a.fw;
import com.sec.chaton.a.gc;
import com.sec.chaton.a.gd;
import com.sec.chaton.a.go;
import com.sec.chaton.a.o;
import com.sec.chaton.a.u;
import com.sec.chaton.d.a.a;
import com.sec.chaton.global.GlobalApplication;
import com.sec.chaton.j.ak;
import com.sec.chaton.j.ao;
import com.sec.chaton.j.ap;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

/**
 * ============================================================================
 * MockRichBinaryAdapter — Local Zero-Latency Implementation of RichBinaryBridge
 * ============================================================================
 * 1. Short-circuits all TCP Protobuf (SSMGPB) and HTTP REST tasks locally with
 *    ResultCode = 1000 ("SUCCESS") and HttpResultCode.SUCCESS (200 OK).
 * 2. Marks outgoing chat messages in SQLite as delivered (message_type = 1).
 * 3. Provides Live Echo interactivity: 1,000 ms after the user sends any message
 *    in ChatFragment, a context-aware reply bubble from the peer (or r-RSS Bot)
 *    is inserted into SQLite and pushed to the UI CursorLoader in real time.
 */
public final class MockRichBinaryAdapter implements RichBinaryBridge {
    private static final String TAG = "ChatON_MockBridge";
    private static final MockRichBinaryAdapter INSTANCE = new MockRichBinaryAdapter();
    private static final AtomicLong SERVER_MSG_SEQ = new AtomicLong(900000000L);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public static MockRichBinaryAdapter getInstance() {
        return INSTANCE;
    }

    private MockRichBinaryAdapter() {}

    @Override
    public void initialize(Context context) {
        AutoProvisioner.ensureProvisioned(context);
        MockEnvironmentSeeder.seedAllIfNeeded(context);
    }

    /** Builds a standard SSMGPB Result message with result_code = 1000 (SUCCESS). */
    private static fh buildSuccessResult() {
        fi builder = fh.newBuilder();
        builder.a(1000);
        builder.a("SUCCESS (BuzZz! RichBinary Local Bridge)");
        return builder.c();
    }

    /** Builds a standard SSMGPB ServerInfo pointing to 127.0.0.1:5223. */
    private static gc buildLocalServerInfo() {
        gd builder = gc.newBuilder();
        builder.a("127.0.0.1");
        builder.a(5223);
        return builder.c();
    }

    @Override
    public void dispatchTcpEnvelope(ak tcpContext, final ao requestEnvelope) {
        if (requestEnvelope == null) {
            return;
        }
        final int reqType = requestEnvelope.b();
        final GeneratedMessageLite reqPb = requestEnvelope.c();
        final long reqMsgId = requestEnvelope.d();
        final long now = System.currentTimeMillis();

        Log.i(TAG, "Intercepted TCP Envelope: type=" + reqType + ", msgId=" + reqMsgId);

        int replyType = reqType + 1;
        GeneratedMessageLite replyPb = null;

        try {
            switch (reqType) {
                case 0: { // InitChatRequest (da) -> InitChatReply (cx, type 1)
                    da initReq = (da) reqPb;
                    String sessionId = (initReq != null && initReq.l() != null && !initReq.l().isEmpty())
                            ? initReq.l()
                            : ("buzzz_session_" + now);
                    cy repBuilder = cx.newBuilder();
                    repBuilder.a(reqMsgId);
                    repBuilder.a(sessionId);
                    repBuilder.b(now);
                    repBuilder.a(buildLocalServerInfo());
                    repBuilder.a(buildSuccessResult());
                    repBuilder.c(now);
                    replyPb = repBuilder.c();

                    if (initReq != null && initReq.s() != null && !initReq.s().isEmpty()) {
                        String peer = (initReq.q() != null && !initReq.q().isEmpty())
                                ? (String) initReq.q().get(0)
                                : "@ara@buzzz.local";
                        scheduleLiveEchoReply(sessionId, peer, initReq.s(), reqMsgId);
                    }
                    break;
                }
                case 2: { // AllowChatRequest (i) -> AllowChatReply (f, type 3)
                    com.sec.chaton.a.g repBuilder = f.newBuilder();
                    repBuilder.a(reqMsgId);
                    repBuilder.a(buildSuccessResult());
                    repBuilder.b(now);
                    replyPb = repBuilder.c();
                    break;
                }
                case 4: { // ChatRequest (az) -> ChatReply (aw, type 5)
                    az chatReq = (az) reqPb;
                    String sessionId = (chatReq != null && chatReq.j() != null) ? chatReq.j() : ("buzzz_session_" + now);
                    ax repBuilder = aw.newBuilder();
                    repBuilder.a(reqMsgId);
                    repBuilder.a(sessionId);
                    repBuilder.a(buildLocalServerInfo());
                    repBuilder.b(now);
                    repBuilder.a(buildSuccessResult());
                    repBuilder.c(now);
                    replyPb = repBuilder.c();

                    if (chatReq != null) {
                        String peer = (chatReq.m() != null && !chatReq.m().isEmpty())
                                ? (String) chatReq.m().get(0)
                                : "@ara@buzzz.local";
                        scheduleLiveEchoReply(sessionId, peer, chatReq.s(), reqMsgId);
                    }
                    break;
                }
                case 6: { // DeliveryChat (bg) -> DeliveryChatReply (bj, type 7)
                    bk repBuilder = bj.newBuilder();
                    repBuilder.a(AutoProvisioner.LOCAL_UID);
                    repBuilder.a(buildSuccessResult());
                    repBuilder.a(0);
                    repBuilder.a(now);
                    replyPb = repBuilder.c();
                    break;
                }
                case 27: { // SerialChatRequest (ft) -> SerialChatReply (fq, type 28)
                    ft serReq = (ft) reqPb;
                    String sessionId = (serReq != null && serReq.h() != null) ? serReq.h() : ("buzzz_session_" + now);
                    fr repBuilder = fq.newBuilder();
                    repBuilder.a(reqMsgId);
                    repBuilder.a(sessionId);
                    repBuilder.a(buildLocalServerInfo());
                    repBuilder.b(now);
                    replyPb = repBuilder.c();

                    if (serReq != null && serReq.r() != null && !serReq.r().isEmpty()) {
                        fw item = (fw) serReq.r().get(0);
                        String peer = (serReq.k() != null && !serReq.k().isEmpty())
                                ? (String) serReq.k().get(0)
                                : "@ara@buzzz.local";
                        scheduleLiveEchoReply(sessionId, peer, item.h(), item.d());
                    }
                    break;
                }
                default: {
                    // For all other request types (EndChat, InviteChat, ReadMessage, etc.)
                    // dispatch a generic success callback
                    break;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "Fallback handling for TCP type " + reqType + ": " + t.getMessage());
        }

        final int finalReplyType = replyType;
        final GeneratedMessageLite finalReplyPb = replyPb;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    ap envBuilder = new ap();
                    envBuilder.a(AutoProvisioner.LOCAL_UID);
                    envBuilder.a(finalReplyType);
                    if (finalReplyPb != null) {
                        envBuilder.a(finalReplyPb);
                    }
                    ao replyEnvelope = envBuilder.b();
                    requestEnvelope.a(requestEnvelope, replyEnvelope);
                } catch (Throwable t) {
                    Log.w(TAG, "Error delivering local TCP reply: " + t.getMessage());
                }
            }
        });
    }

    @Override
    public b dispatchHttpRequest(a httpTask) {
        try {
            com.sec.chaton.j.e reqEntry = (com.sec.chaton.j.e) httpTask.h();
            b result = new b(reqEntry);
            result.a(true); // connectionSuccess = true
            result.a(200);  // HTTP 200 OK
            result.a(com.sec.chaton.j.o.a); // HttpResultCode.SUCCESS
            return result;
        } catch (Throwable t) {
            Log.w(TAG, "dispatchHttpRequest stub error: " + t.getMessage());
            return null;
        }
    }

    @Override
    public long sendHangoutMessage(
            final Context context,
            final String inboxNo,
            final String sessionId,
            final int chatType,
            final int contentType,
            final String messageText,
            final String[] receivers,
            final long clientMsgId) {
        final String peer = (receivers != null && receivers.length > 0) ? receivers[0] : "@ara@buzzz.local";
        scheduleLiveEchoReply(sessionId != null ? sessionId : inboxNo, peer, messageText, clientMsgId);
        return SERVER_MSG_SEQ.incrementAndGet();
    }

    /**
     * Marks the user's outgoing message as ACK_DONE (message_type = 1) immediately
     * and inserts a realistic Live Echo reply bubble 1,000 ms later.
     */
    public void scheduleLiveEchoReply(
            final String sessionOrInboxId,
            final String peerBuddyNo,
            final String userText,
            final long clientMsgId) {
        final Context ctx = GlobalApplication.r();
        if (ctx == null) return;

        // 1. Immediately mark the user's outgoing bubble as delivered (message_type = 1, message_is_failed = 0)
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    ContentResolver cr = ctx.getContentResolver();
                    ContentValues ackValues = new ContentValues();
                    ackValues.put("message_type", Integer.valueOf(1)); // ACK_DONE / Sent
                    ackValues.put("message_is_failed", Integer.valueOf(0));
                    ackValues.put("message_sever_id", Long.valueOf(SERVER_MSG_SEQ.incrementAndGet()));
                    if (clientMsgId > 0) {
                        cr.update(
                                Uri.parse("content://com.sec.chaton.provider/message"),
                                ackValues,
                                "_id=?",
                                new String[]{String.valueOf(clientMsgId)}
                        );
                    }
                    cr.update(
                            Uri.parse("content://com.sec.chaton.provider/message"),
                            ackValues,
                            "message_type=0",
                            null
                    );
                    cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/message"), null);
                    cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/inbox"), null);
                } catch (Throwable t) {
                    Log.w(TAG, "Error updating outgoing message ACK: " + t.getMessage());
                }
            }
        });

        // 2. Schedule the 1-second Simulated Echo Reply bubble
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    MockEnvironmentSeeder.insertLiveEchoMessage(ctx, sessionOrInboxId, peerBuddyNo, userText);
                } catch (Throwable t) {
                    Log.w(TAG, "Error inserting Live Echo message: " + t.getMessage());
                }
            }
        }, 1000L);
    }

    @Override
    public void syncCirclesAndPresence(Context context) {
        MockEnvironmentSeeder.seedAllIfNeeded(context);
    }

    @Override
    public void syncTrunkLeftovers(Context context, String sessionId) {
        MockEnvironmentSeeder.seedAllIfNeeded(context);
    }
}
