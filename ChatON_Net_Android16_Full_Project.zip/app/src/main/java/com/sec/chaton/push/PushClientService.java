package com.sec.chaton.push;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

/**
 * ============================================================================
 * PushClientService — Safe Idle Stub Service for Android 16 (API 36)
 * ============================================================================
 * Replaces Samsung's legacy SPP TLS push socket service so that no background
 * connections are attempted to gld.push.samsungosp.com:5223.
 * Incoming events will be pushed directly by BuzZz! RichBinaryBridge (PC5/r-RSS).
 */
public class PushClientService extends Service {
    private static final String TAG = "ChatON_PushStub";

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "PushClientService initialized in local BuzZz! RichBinary stub mode (idle).");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Stay idle without opening external sockets or triggering ForegroundService timeouts
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
