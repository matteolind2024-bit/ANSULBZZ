package com.sec.chaton;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.sec.chaton.base.BaseActivity;
import com.sec.chaton.bridge.AutoProvisioner;
import com.sec.chaton.bridge.MockEnvironmentSeeder;
import com.sec.chaton.util.cn;

/**
 * ============================================================================
 * HomeActivity — Auto-Provisioned Direct Entry into TabActivity
 * ============================================================================
 * Ensures that the user is never redirected to ActivityRegist,
 * ActivityProvisioning, or Samsung Account login screens. Seeds the local
 * database and transitions directly into TabActivity (Buddies / Chats / MyPage).
 */
public class HomeActivity extends BaseActivity implements cn {
    public static final String n = HomeActivity.class.getSimpleName();

    public static Intent a(Context context) {
        return a(context, false);
    }

    public static Intent a(Context context, boolean skipSplash) {
        return a(context, skipSplash ? 1 : 0);
    }

    public static Intent a(Context context, int skipSplash) {
        Intent intent = new Intent(context, HomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        intent.putExtra("skipSplash", skipSplash);
        return intent;
    }

    public static Intent a(Context context, Intent intent, int skipSplash) {
        intent.setClass(context, HomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        intent.putExtra("skipSplash", skipSplash);
        return intent;
    }

    private boolean g() {
        AutoProvisioner.ensureProvisioned(this);
        return true;
    }

    @Override
    public int getBlackTheme() {
        return R.style.AppTheme_NoTitleBar;
    }

    @Override
    public int getDefaultTheme() {
        return R.style.AppTheme_NoTitleBar;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_home);

        AutoProvisioner.ensureProvisioned(this);
        MockEnvironmentSeeder.seedAllIfNeeded(this);

        Intent baseIntent = getIntent();
        if (baseIntent != null && baseIntent.getBooleanExtra("finish", false)) {
            finish();
            return;
        }

        // Launch TabActivity directly with full mock environment ready
        Intent tabIntent = TabActivity.a(this, baseIntent != null ? baseIntent : new Intent());
        startActivity(tabIntent);
        finish();
    }
}
