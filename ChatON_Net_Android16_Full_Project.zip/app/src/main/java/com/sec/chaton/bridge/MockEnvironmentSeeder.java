package com.sec.chaton.bridge;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

import com.sec.chaton.e.bn;
import com.sec.chaton.trunk.database.a.b;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

/**
 * ============================================================================
 * MockEnvironmentSeeder — Rich Interactive SQLite Seeder for ChatON-Net
 * ============================================================================
 * Populates both chaton.db (com.sec.chaton.e.bn) and trunk.db
 * (com.sec.chaton.trunk.database.a.b) with:
 *   - 10 Buddies in @name@node format with statuses, emails, and interaction ranks
 *   - 4 Buddy Groups (Favorites + 3 BuzZz! Circles)
 *   - 5 Active Chat Rooms (1:1, Group Chats, and @web@r-rss Free Web Proxy Channel)
 *   - Rich message history (Incoming, Outgoing, System Notifications, Multimedia)
 *   - Trunk shared items & comments (mapped to BuzZz! Photos / Leftovers)
 *   - PostON profile wall entries & Anicon sticker packages
 */
public final class MockEnvironmentSeeder {
    private static final String TAG = "ChatON_MockSeeder";
    private static volatile boolean sSeeded = false;
    private static final AtomicLong MSG_ID_GEN = new AtomicLong(500000L);

    private MockEnvironmentSeeder() {}

    public static synchronized void seedAllIfNeeded(Context context) {
        if (sSeeded || context == null) {
            return;
        }
        sSeeded = true;
        try {
            SQLiteDatabase chatDb = bn.a(context).getWritableDatabase();
            seedBuddiesAndCircles(chatDb);
            seedChatRoomsAndMessages(context, chatDb);
            seedPostONAndAnicons(chatDb);

            SQLiteDatabase trunkDb = b.a(context).getWritableDatabase();
            seedTrunkItems(context, trunkDb);

            notifyAllProviders(context);
            Log.i(TAG, "Successfully seeded ChatON-Net interactive mock environment.");
        } catch (Throwable t) {
            Log.e(TAG, "Error seeding mock environment: " + t.getMessage(), t);
        }
    }

    private static void seedBuddiesAndCircles(SQLiteDatabase db) {
        long now = System.currentTimeMillis();
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(now));

        Object[][] buddies = new Object[][]{
            {"@ara@buzzz.local",     "Ara Rostami",             "[PC5 Mesh Online] Signal -62dBm | Hop 1",          "+989121110001", 45, 52, 1},
            {"@navid@pc5.mesh",      "Navid Kiani",             "ProSe Direct Relay Active | Teh-North",             "+989121110002", 38, 41, 2},
            {"@sara@buzzz.local",    "Sara Moradi",             "Syncing Leftovers via BuzZz! Rich Binary",          "+989121110003", 30, 35, 3},
            {"@kiarash@pc5.mesh",    "Kiarash Awan",            "eBPF Packet Filter + Netty 5223 Bridge",            "+989121110004", 28, 29, 4},
            {"@mahsa@buzzz.local",   "Mahsa Tehrani",           "Circles Crypto Key Verified [Ed25519]",             "+989121110005", 22, 26, 5},
            {"@reza@pc5.mesh",       "Reza Pahlevan",           "LTE-Direct / Sidelink PC5 Band 47",                 "+989121110006", 19, 20, 6},
            {"@nima@buzzz.local",    "Nima Farhadi",            "r-RSS Feed Aggregator Node #4",                     "+989121110007", 15, 18, 7},
            {"@taraneh@buzzz.local", "Taraneh Alavi",           "Sharing Photos in Trunk [Offline Mode]",            "+989121110008", 12, 14, 8},
            {"@parsa@pc5.mesh",      "ParsaV",                  "Android 16 Baklava 16KB Kernel Tester",             "+989121110009", 10, 11, 9},
            {"@web@r-rss",           "r-RSS Free Web Proxy",    "[BOT] Send any URL or topic to crawl via r-RSS",    "+989120009999", 60, 65, 1}
        };

        db.beginTransaction();
        try {
            for (Object[] b : buddies) {
                String buddyNo = (String) b[0];
                String name = (String) b[1];
                String status = (String) b[2];
                String phone = (String) b[3];
                int sent = (Integer) b[4];
                int recv = (Integer) b[5];
                int rank = (Integer) b[6];

                ContentValues cv = new ContentValues();
                cv.put("buddy_no", buddyNo);
                cv.put("buddy_name", name);
                cv.put("buddy_status_message", status);
                cv.put("buddy_email", buddyNo.substring(1));
                cv.put("buddy_samsung_email", buddyNo.substring(1));
                cv.put("buddy_orginal_number", phone);
                cv.put("buddy_birthday", "1995-05-14");
                cv.put("buddy_msg_send", Integer.valueOf(sent));
                cv.put("buddy_msg_received", Integer.valueOf(recv));
                cv.put("buddy_relation_hide", "N");
                cv.put("buddy_raw_contact_id", Integer.valueOf(0));
                cv.put("buddy_push_name", name);
                cv.put("buddy_is_new", "N");
                cv.put("buddy_profile_status", Integer.valueOf(0));
                cv.put("buddy_is_profile_updated", "N");
                cv.put("buddy_is_status_updated", "N");
                cv.put("buddy_show_phone_number", Integer.valueOf(1));
                cv.put("buddy_extra_info", "BuzZz! RichBinary v1.0");
                cv.put("buddy_is_name_updated", "N");
                cv.put("buddy_updated_timestamp", String.valueOf(now));
                cv.put("buddy_multidevice", "Y");
                cv.put("buddy_sainfo", "buzzz_mesh_verified");
                cv.put("buddy_account_info", Integer.valueOf(1));
                cv.put("buddy_original_name", name);
                cv.put("buddy_using_contact_name", "N");
                cv.put("buddy_is_hide", "N");
                db.insertWithOnConflict("buddy", null, cv, SQLiteDatabase.CONFLICT_REPLACE);

                // Seed Interaction Rank (relation table)
                ContentValues rel = new ContentValues();
                rel.put("relation_buddy_id", buddyNo);
                rel.put("relation_date", today);
                rel.put("relation_send", Integer.valueOf(sent));
                rel.put("relation_received", Integer.valueOf(recv));
                rel.put("relation_point", Integer.valueOf(sent + recv));
                rel.put("relation_icon", Integer.valueOf(rank <= 3 ? 3 : 2));
                rel.put("relation_increase", Integer.valueOf(5));
                rel.put("relation_rank", Integer.valueOf(rank));
                rel.put("relation_last_msg_time", String.valueOf(now));
                db.insertWithOnConflict("relation", null, rel, SQLiteDatabase.CONFLICT_REPLACE);
            }

            // Seed Circles (buddy_group) & Favorites (_id = 1 is Favorites with group_type = 1)
            Object[][] groups = new Object[][]{
                {Integer.valueOf(1), "Favorites",                    Integer.valueOf(1)},
                {Integer.valueOf(2), "Circle: BuzZz! Core Devs",     Integer.valueOf(2)},
                {Integer.valueOf(3), "Circle: PC5 Sidelink Mesh",    Integer.valueOf(2)},
                {Integer.valueOf(4), "Circle: r-RSS & Leftovers",    Integer.valueOf(2)}
            };
            for (Object[] g : groups) {
                ContentValues gcv = new ContentValues();
                gcv.put("_id", (Integer) g[0]);
                gcv.put("group_name", (String) g[1]);
                gcv.put("group_type", (Integer) g[2]);
                gcv.put("group_is_new", "N");
                db.insertWithOnConflict("buddy_group", null, gcv, SQLiteDatabase.CONFLICT_REPLACE);
            }

            String[][] groupMembers = new String[][]{
                {"1", "@ara@buzzz.local"}, {"1", "@navid@pc5.mesh"}, {"1", "@sara@buzzz.local"}, {"1", "@web@r-rss"},
                {"2", "@ara@buzzz.local"}, {"2", "@kiarash@pc5.mesh"}, {"2", "@parsa@pc5.mesh"},
                {"3", "@navid@pc5.mesh"}, {"3", "@reza@pc5.mesh"}, {"3", "@mahsa@buzzz.local"},
                {"4", "@web@r-rss"}, {"4", "@nima@buzzz.local"}, {"4", "@taraneh@buzzz.local"}, {"4", "@sara@buzzz.local"}
            };
            for (String[] gm : groupMembers) {
                ContentValues gr = new ContentValues();
                gr.put("group_relation_group", gm[0]);
                gr.put("group_relation_buddy", gm[1]);
                db.insertWithOnConflict("grouprelation", null, gr, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private static void seedChatRoomsAndMessages(Context context, SQLiteDatabase db) {
        long now = System.currentTimeMillis();
        String pkg = context.getPackageName();
        String sampleImageUri = "android.resource://" + pkg + "/drawable/icon";

        db.beginTransaction();
        try {
            // Room 1: 1:1 Chat with @ara@buzzz.local
            createRoom(
                    db,
                    "inbox_buzzz_ara",
                    "sess_buzzz_ara",
                    0, // ONETOONE
                    "Ara Rostami",
                    "پروتکل ۴۲ بایتی ChatON روی سوکت محلی PC5 تست شد، پینگ زیر ۴ میلی‌ثانیه است!",
                    now - 60000L,
                    0,
                    new String[][]{{"@ara@buzzz.local", "Ara Rostami"}}
            );
            insertMsg(db, 1001L, "inbox_buzzz_ara", "sess_buzzz_ara", -1, 4, "@ara@buzzz.local", "BuzZz! PC5 Direct Sidelink Session Established [AES-128-CBC]", now - 300000L, null);
            insertMsg(db, 1002L, "inbox_buzzz_ara", "sess_buzzz_ara", 0, 2, "@ara@buzzz.local", "سلام مارتین! کلاینت ChatON-Net روی اندروید ۱۶ بدون نیاز به سرور سامسونگ بالا اومد؟", now - 180000L, null);
            insertMsg(db, 1003L, "inbox_buzzz_ara", "sess_buzzz_ara", 0, 1, AutoProvisioner.LOCAL_CHATON_ID, "آره! کل ۶,۵۴۱ کلاس پچ شدن و الان لایه RichBinaryBridge مستقیماً به دیتابیس وصله.", now - 120000L, null);
            insertMsg(db, 1004L, "inbox_buzzz_ara", "sess_buzzz_ara", 0, 2, "@ara@buzzz.local", "پروتکل ۴۲ بایتی ChatON روی سوکت محلی PC5 تست شد، پینگ زیر ۴ میلی‌ثانیه است!", now - 60000L, null);

            // Room 2: Group Chat — BuzZz! Core Architecture
            createRoom(
                    db,
                    "inbox_buzzz_core_group",
                    "sess_buzzz_core_group",
                    1, // GROUPCHAT
                    "BuzZz! Core Architecture",
                    "Kiarash: ماژول Hangouts و Circles کاملاً با جداول SQLite چت‌آن مپ شدن.",
                    now - 120000L,
                    2,
                    new String[][]{
                        {"@ara@buzzz.local", "Ara Rostami"},
                        {"@kiarash@pc5.mesh", "Kiarash Awan"},
                        {"@parsa@pc5.mesh", "ParsaV"}
                    }
            );
            insertMsg(db, 2001L, "inbox_buzzz_core_group", "sess_buzzz_core_group", -1, 4, "@ara@buzzz.local", "ENTER,@ara@buzzz.local,Ara Rostami
ENTER,@kiarash@pc5.mesh,Kiarash Awan
ENTER,@parsa@pc5.mesh,ParsaV
", now - 500000L, null);
            insertMsg(db, 2002L, "inbox_buzzz_core_group", "sess_buzzz_core_group", 0, 2, "@parsa@pc5.mesh", "تراز حافظه 16KB برای هر دو کتابخونه JNI روی کرنل اندروید ۱۶ تست شد و بدون خطا لود میشن.", now - 240000L, null);
            insertMsg(db, 2003L, "inbox_buzzz_core_group", "sess_buzzz_core_group", 0, 1, AutoProvisioner.LOCAL_CHATON_ID, "عالیه، الان هر پیامی اینجا بفرستیم بعد از ۱ ثانیه پاسخ زنده (Live Echo) میده.", now - 180000L, null);
            insertMsg(db, 2004L, "inbox_buzzz_core_group", "sess_buzzz_core_group", 0, 2, "@kiarash@pc5.mesh", "ماژول Hangouts و Circles کاملاً با جداول SQLite چت‌آن مپ شدن.", now - 120000L, null);

            // Room 3: Special Channel @web@r-rss (Decentralized Web Crawler & RSS Proxy)
            createRoom(
                    db,
                    "inbox_rrss_channel",
                    "sess_rrss_channel",
                    0, // ONETOONE Bot Channel
                    "@web@r-rss (Free Web Proxy)",
                    "[r-RSS Digest] هر آدرس وب یا کلیدواژه‌ای را بفرستید تا از طریق مش آفلاین واکشی شود.",
                    now - 30000L,
                    1,
                    new String[][]{{"@web@r-rss", "r-RSS Free Web Proxy"}}
            );
            insertMsg(db, 3001L, "inbox_rrss_channel", "sess_rrss_channel", -1, 4, "@web@r-rss", "r-RSS Decentralized Web Crawler Tunnel Connected [Zero-Censorship Mode]", now - 400000L, null);
            insertMsg(db, 3002L, "inbox_rrss_channel", "sess_rrss_channel", 0, 1, AutoProvisioner.LOCAL_CHATON_ID, "fetch https://news.ycombinator.com/rss", now - 90000L, null);
            insertMsg(db, 3003L, "inbox_rrss_channel", "sess_rrss_channel", 0, 2, "@web@r-rss", "[r-RSS Digest #402]
1. Mesh Networking over LTE/NR PC5 Sidelink (184 pts)
2. Rebuilding Classic Android Messengers for API 36 (142 pts)
[r-RSS Digest] هر آدرس وب یا کلیدواژه‌ای را بفرستید تا از طریق مش آفلاین واکشی شود.", now - 30000L, null);

            // Room 4: 1:1 Chat with @sara@buzzz.local (Trunk & Leftovers Media)
            createRoom(
                    db,
                    "inbox_buzzz_sara",
                    "sess_buzzz_sara",
                    0,
                    "Sara Moradi",
                    "فایل‌های گرافیکی و اسکرین‌شات‌ها رو توی صندوق Trunk همین چت گذاشتم، چک کن!",
                    now - 200000L,
                    0,
                    new String[][]{{"@sara@buzzz.local", "Sara Moradi"}}
            );
            insertMsg(db, 4001L, "inbox_buzzz_sara", "sess_buzzz_sara", 0, 2, "@sara@buzzz.local", "سلام! اتصال Trunk به مخزن Photos / Leftovers انجام شد.", now - 260000L, null);
            insertMsg(db, 4002L, "inbox_buzzz_sara", "sess_buzzz_sara", 1, 2, "@sara@buzzz.local", "image
jpg
" + sampleImageUri + "
buzzz_leftovers_preview.jpg
" + AutoProvisioner.LOCAL_UID + "
", now - 230000L, sampleImageUri);
            insertMsg(db, 4003L, "inbox_buzzz_sara", "sess_buzzz_sara", 0, 2, "@sara@buzzz.local", "فایل‌های گرافیکی و اسکرین‌شات‌ها رو توی صندوق Trunk همین چت گذاشتم، چک کن!", now - 200000L, null);

            // Room 5: Group Chat — PC5 Sidelink Field Test
            createRoom(
                    db,
                    "inbox_pc5_mesh_ops",
                    "sess_pc5_mesh_ops",
                    1,
                    "PC5 Field Test Node",
                    "Navid: رله‌ی رادیویی نود نیاوران به ولیعصر بدون اینترنت برقرار شد.",
                    now - 360000L,
                    0,
                    new String[][]{
                        {"@navid@pc5.mesh", "Navid Kiani"},
                        {"@reza@pc5.mesh", "Reza Pahlevan"},
                        {"@mahsa@buzzz.local", "Mahsa Tehrani"}
                    }
            );
            insertMsg(db, 5001L, "inbox_pc5_mesh_ops", "sess_pc5_mesh_ops", 0, 2, "@reza@pc5.mesh", "فرکانس 5.9GHz ITS/PC5 بدون تداخل فعاله. توان مصرفی سرویس پس‌زمینه بهینه شد.", now - 420000L, null);
            insertMsg(db, 5002L, "inbox_pc5_mesh_ops", "sess_pc5_mesh_ops", 0, 2, "@navid@pc5.mesh", "رله‌ی رادیویی نود نیاوران به ولیعصر بدون اینترنت برقرار شد.", now - 360000L, null);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private static void createRoom(
            SQLiteDatabase db,
            String inboxNo,
            String sessionId,
            int chatType,
            String title,
            String lastMsg,
            long lastTime,
            int unreadCount,
            String[][] members) {
        ContentValues icv = new ContentValues();
        icv.put("inbox_no", inboxNo);
        icv.put("inbox_chat_type", Integer.valueOf(chatType));
        icv.put("inbox_unread_count", Integer.valueOf(unreadCount));
        icv.put("inbox_last_message", lastMsg);
        icv.put("inbox_title", title);
        icv.put("inbox_last_time", Long.valueOf(lastTime));
        icv.put("inbox_translated", "N");
        icv.put("inbox_server_ip", "127.0.0.1");
        icv.put("inbox_server_port", Integer.valueOf(5223));
        icv.put("inbox_participants", String.valueOf(members.length));
        icv.put("inbox_session_id", sessionId);
        icv.put("inbox_last_msg_no", Long.valueOf(lastTime));
        icv.put("inbox_last_msg_sender", members[0][0]);
        icv.put("inbox_title_fixed", "Y");
        icv.put("inbox_last_chat_type", Integer.valueOf(11));
        icv.put("inbox_last_temp_msg", "");
        icv.put("inbox_is_new", "N");
        icv.put("inbox_trunk_unread_count", Integer.valueOf(2));
        icv.put("inbox_valid", "Y");
        icv.put("inbox_enable_noti", "Y");
        icv.put("inbox_last_timestamp", Long.valueOf(lastTime));
        icv.put("profile_url", "NA");
        icv.put("lasst_session_merge_time", Long.valueOf(lastTime - 600000L));
        db.insertWithOnConflict("inbox", null, icv, SQLiteDatabase.CONFLICT_REPLACE);

        for (String[] m : members) {
            ContentValues pcv = new ContentValues();
            pcv.put("participants_inbox_no", inboxNo);
            pcv.put("participants_buddy_no", m[0]);
            pcv.put("participants_buddy_name", m[1]);
            pcv.put("participants_country_code", "IR");
            pcv.put("participants_is_auth", "Y");
            pcv.put("participants_status", Integer.valueOf(0));
            db.insertWithOnConflict("participant", null, pcv, SQLiteDatabase.CONFLICT_REPLACE);

            ContentValues ib = new ContentValues();
            ib.put("inbox_no", inboxNo);
            ib.put("buddy_no", m[0]);
            ib.put("chat_type", Integer.valueOf(chatType));
            db.insertWithOnConflict("inbox_buddy_relation", null, ib, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    private static void insertMsg(
            SQLiteDatabase db,
            long id,
            String inboxNo,
            String sessionId,
            int contentType,
            int msgType,
            String sender,
            String content,
            long timestamp,
            String downloadUri) {
        String timeText = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(timestamp));
        ContentValues mcv = new ContentValues();
        mcv.put("_id", Long.valueOf(id));
        mcv.put("message_sever_id", Long.valueOf(id));
        mcv.put("message_inbox_no", inboxNo);
        mcv.put("message_session_id", sessionId);
        mcv.put("message_read_status", Integer.valueOf(1));
        mcv.put("message_content_type", Integer.valueOf(contentType));
        mcv.put("message_time", Long.valueOf(timestamp));
        mcv.put("message_content", content);
        mcv.put("message_type", Integer.valueOf(msgType));
        mcv.put("message_sender", sender);
        if (downloadUri != null) {
            mcv.put("message_download_uri", downloadUri);
        }
        mcv.put("message_tid", String.valueOf(id));
        mcv.put("message_time_text", timeText);
        mcv.put("message_stored_ext", Integer.valueOf(1));
        mcv.put("message_need_update", "N");
        mcv.put("message_is_failed", Integer.valueOf(0));
        mcv.put("message_is_read", Integer.valueOf(1));
        db.insertWithOnConflict("message", null, mcv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    private static void seedTrunkItems(Context context, SQLiteDatabase trunkDb) {
        long now = System.currentTimeMillis();
        String pkg = context.getPackageName();
        String thumbUri = "android.resource://" + pkg + "/drawable/icon";

        String[] sessions = new String[]{
            "sess_buzzz_ara",
            "sess_buzzz_core_group",
            "sess_rrss_channel",
            "sess_buzzz_sara",
            "sess_pc5_mesh_ops"
        };

        trunkDb.beginTransaction();
        try {
            int idx = 1;
            for (String sess : sessions) {
                ContentValues tcv = new ContentValues();
                tcv.put("session_id", sess);
                tcv.put("last_update_time", Long.valueOf(now - 60000L));
                tcv.put("last_comment_time", Long.valueOf(now - 30000L));
                tcv.put("total_item_count", Integer.valueOf(2));
                tcv.put("unread_item_count", Integer.valueOf(0));
                tcv.put("unread_comment_count", Integer.valueOf(0));
                trunkDb.insertWithOnConflict("trunk", null, tcv, SQLiteDatabase.CONFLICT_REPLACE);

                for (int k = 1; k <= 2; k++) {
                    String itemId = "leftover_item_" + idx + "_" + k;
                    ContentValues icv = new ContentValues();
                    icv.put("item_id", itemId);
                    icv.put("session_id", sess);
                    icv.put("sender_uid", "@sara@buzzz.local");
                    icv.put("sender_name", "Sara Moradi");
                    icv.put("sender_number", "+989121110003");
                    icv.put("registration_time", Long.valueOf(now - (k * 120000L)));
                    icv.put("last_comment_time", Long.valueOf(now - 30000L));
                    icv.put("total_comment_count", Integer.valueOf(1));
                    icv.put("unread_comment_count", Integer.valueOf(0));
                    icv.put("item_description", "[BuzZz! Leftovers #" + k + "] Shared offline media in " + sess);
                    icv.put("thumbnail", thumbUri);
                    icv.put("down_url", thumbUri);
                    icv.put("content_type", "image/jpeg");
                    icv.put("isams", "false");
                    icv.put("item_type", Integer.valueOf(1));
                    trunkDb.insertWithOnConflict("trunk_item", null, icv, SQLiteDatabase.CONFLICT_REPLACE);

                    ContentValues ccv = new ContentValues();
                    ccv.put("item_id", itemId);
                    ccv.put("comment_id", "cmt_" + itemId);
                    ccv.put("registration_time", Long.valueOf(now - 30000L));
                    ccv.put("writer_uid", "@ara@buzzz.local");
                    ccv.put("writer_name", "Ara Rostami");
                    ccv.put("writer_number", "+989121110001");
                    ccv.put("content", "دریافت شد روی مخزن لوکال Leftovers بدون نیاز به اینترنت!");
                    trunkDb.insertWithOnConflict("trunk_comment", null, ccv, SQLiteDatabase.CONFLICT_REPLACE);
                }
                idx++;
            }
            trunkDb.setTransactionSuccessful();
        } finally {
            trunkDb.endTransaction();
        }
    }

    private static void seedPostONAndAnicons(SQLiteDatabase db) {
        long now = System.currentTimeMillis();
        db.beginTransaction();
        try {
            ContentValues mp = new ContentValues();
            mp.put("buddy_no", AutoProvisioner.LOCAL_CHATON_ID);
            mp.put("buddy_name", AutoProvisioner.LOCAL_PUSH_NAME);
            mp.put("image_status", "0");
            mp.put("poston_id", "poston_local_1");
            mp.put("isread", "Y");
            mp.put("read_comment_count", "2");
            mp.put("unread_comment_count", "0");
            mp.put("timestamp", String.valueOf(now - 100000L));
            mp.put("unread_mood_count", "0");
            mp.put("total_mood_count", "5");
            mp.put("poston", "نود ChatON-Net روی Android 16 (API 36) فعال شد! متصل به BuzZz! Rich Binary.");
            mp.put("multimedia_list", "");
            db.insertWithOnConflict("my_poston", null, mp, SQLiteDatabase.CONFLICT_REPLACE);

            ContentValues bp = new ContentValues();
            bp.put("buddy_no", "@ara@buzzz.local");
            bp.put("buddy_name", "Ara Rostami");
            bp.put("image_status", "0");
            bp.put("poston_id", "poston_ara_1");
            bp.put("isread", "Y");
            bp.put("read_comment_count", "1");
            bp.put("unread_comment_count", "0");
            bp.put("timestamp", String.valueOf(now - 50000L));
            bp.put("unread_mood_count", "0");
            bp.put("total_mood_count", "8");
            bp.put("poston", "تست مش رادیویی PC5 بین ۳ نود با موفقیت انجام شد.");
            bp.put("multimedia_list", "");
            db.insertWithOnConflict("buddy_poston", null, bp, SQLiteDatabase.CONFLICT_REPLACE);
            db.setTransactionSuccessful();
        } catch (Throwable ignored) {
        } finally {
            db.endTransaction();
        }
    }

    /**
     * Inserts a real-time Live Echo reply message into the active chat room
     * 1 second after the user hits Send in ChatFragment.
     */
    public static void insertLiveEchoMessage(Context context, String sessionOrInboxId, String peerBuddyNo, String userText) {
        if (context == null) return;
        SQLiteDatabase db = bn.a(context).getWritableDatabase();
        String inboxNo = sessionOrInboxId;
        String sessionId = sessionOrInboxId;
        String senderNo = (peerBuddyNo != null && !peerBuddyNo.isEmpty()) ? peerBuddyNo : "@ara@buzzz.local";

        // Resolve inbox_no and session_id from inbox table
        Cursor c = null;
        try {
            c = db.query("inbox", new String[]{"inbox_no", "inbox_session_id", "inbox_last_msg_sender"},
                    "inbox_no=? OR inbox_session_id=?", new String[]{sessionOrInboxId, sessionOrInboxId},
                    null, null, null);
            if (c != null && c.moveToFirst()) {
                inboxNo = c.getString(0);
                if (c.getString(1) != null && !c.getString(1).isEmpty()) {
                    sessionId = c.getString(1);
                }
                if (c.getString(2) != null && c.getString(2).startsWith("@") && !c.getString(2).equals(AutoProvisioner.LOCAL_CHATON_ID)) {
                    senderNo = c.getString(2);
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.close();
        }

        String echoReply;
        if ("@web@r-rss".equals(senderNo) || (inboxNo != null && inboxNo.contains("rrss"))) {
            senderNo = "@web@r-rss";
            echoReply = "[r-RSS Live Crawl] نتیجه واکشی آفلاین برای «" + (userText != null ? userText : "query") + "»:
"
                    + "• وضعیت تانل: PC5 Sidelink + RichBinary OK
"
                    + "• خلاصه محتوا: بسته داده با موفقیت از گره r-RSS دریافت و کش شد.";
        } else {
            echoReply = "[BuzZz! Live Echo from " + senderNo + "]
"
                    + "پیام شما («" + (userText != null ? userText : "") + "») روی لایه RichBinary دریافت شد! (RTT: 3.4ms)";
        }

        long now = System.currentTimeMillis();
        long msgId = MSG_ID_GEN.incrementAndGet();

        db.beginTransaction();
        try {
            insertMsg(db, msgId, inboxNo, sessionId, 0, 2, senderNo, echoReply, now, null);

            ContentValues icv = new ContentValues();
            icv.put("inbox_last_message", echoReply);
            icv.put("inbox_last_time", Long.valueOf(now));
            icv.put("inbox_last_timestamp", Long.valueOf(now));
            icv.put("inbox_last_msg_no", Long.valueOf(msgId));
            icv.put("inbox_last_msg_sender", senderNo);
            db.update("inbox", icv, "inbox_no=?", new String[]{inboxNo});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }

        notifyAllProviders(context);
    }

    public static void notifyAllProviders(Context context) {
        if (context == null) return;
        ContentResolver cr = context.getContentResolver();
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/buddy"), null);
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/buddy_group"), null);
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/grouprelation"), null);
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/inbox"), null);
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/message"), null);
        cr.notifyChange(Uri.parse("content://com.sec.chaton.provider/participant"), null);
        cr.notifyChange(Uri.parse("content://com.develop.sec.chaton.provider/trunk"), null);
        cr.notifyChange(Uri.parse("content://com.develop.sec.chaton.provider/trunk_item"), null);
    }
}
