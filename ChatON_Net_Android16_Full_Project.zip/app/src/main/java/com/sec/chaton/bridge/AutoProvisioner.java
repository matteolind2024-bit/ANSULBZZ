package com.sec.chaton.bridge;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import com.sec.chaton.util.aa;
import com.sec.chaton.util.ab;

/**
 * ============================================================================
 * AutoProvisioner — Complete Registration & Samsung Account (SSO) Bypass
 * ============================================================================
 * Pre-populates ChatON's internal preference store (com.sec.chaton.util.ab)
 * so that HomeActivity.g() and SplashActivity.j() immediately recognize the
 * client as a fully registered node (@benjamin@buzzz.local) and launch
 * TabActivity directly without ever showing ActivityRegist, ActivityProvisioning,
 * or Samsung Account login screens.
 */
public final class AutoProvisioner {
    private static final String TAG = "ChatON_AutoProv";

    public static final String LOCAL_UID       = "b7e6d5c4-a3b2-4109-8f7e-6d5c4b3a2109"; // 36-byte UUID for Envelope header
    public static final String LOCAL_CHATON_ID = "@benjamin@buzzz.local";
    public static final String LOCAL_MSISDN    = "+989120001337";
    public static final String LOCAL_PUSH_NAME = "Benjamin (BuzZz! Node)";
    // 64-hex-char (32-byte) AES-128 Key (bytes 0..15) + CBC IV (bytes 16..31)
    public static final String LOCAL_AES_HEX   = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f";

    private AutoProvisioner() {}

    public static synchronized void ensureProvisioned(Context context) {
        try {
            ab pref = aa.a();
            if (pref != null) {
                pref.b("uid", LOCAL_UID);
                pref.b("chaton_id", LOCAL_CHATON_ID);
                pref.b("msisdn", LOCAL_MSISDN);
                pref.b("Push Name", LOCAL_PUSH_NAME);
                pref.b("agree_disclaimer", Boolean.TRUE);
                pref.b("skip_sms_register_now", Boolean.TRUE);
                pref.b("need_to_update_gld_feature", Boolean.FALSE);
                pref.b("back_deregi_fail", Boolean.FALSE);
                pref.b("country_ISO", "IR");
                pref.b("country_name", "Iran");
                pref.b("country_code", "98");
                pref.b("primary_message_addrss", "127.0.0.1");
                pref.a("primary_message_port", Integer.valueOf(5223));
                pref.b("secondary_message_addrss", "127.0.0.1");
                pref.a("secondary_message_port", Integer.valueOf(5223));
                pref.b("primary_contact_addrss", "127.0.0.1");
                pref.a("primary_contact_port", Integer.valueOf(443));
                pref.b("primary_file_addrss", "127.0.0.1");
                pref.a("primary_file_port", Integer.valueOf(443));
                pref.b("key", LOCAL_AES_HEX);
                pref.b("account_country_matrix", "DONE");
                pref.b("update_disclaimer_status", "DONE");
            }
            if (context != null) {
                SharedPreferences sp = context.getSharedPreferences("ChatON", Context.MODE_PRIVATE);
                sp.edit()
                        .putString("uid", LOCAL_UID)
                        .putString("chaton_id", LOCAL_CHATON_ID)
                        .putString("msisdn", LOCAL_MSISDN)
                        .putString("Push Name", LOCAL_PUSH_NAME)
                        .putBoolean("agree_disclaimer", true)
                        .putBoolean("skip_sms_register_now", true)
                        .putBoolean("need_to_update_gld_feature", false)
                        .putString("key", LOCAL_AES_HEX)
                        .apply();
            }
            Log.i(TAG, "Auto-provisioned ChatON-Net identity: " + LOCAL_CHATON_ID + " (UID=" + LOCAL_UID + ")");
        } catch (Throwable t) {
            Log.e(TAG, "AutoProvisioner error: " + t.getMessage(), t);
        }
    }
}
