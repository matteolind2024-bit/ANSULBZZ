package com.sec.chaton.global;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.os.Debug;
import android.os.Handler;
import android.provider.SearchRecentSuggestions;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.sec.chaton.bridge.Android16Compat;
import com.sec.chaton.bridge.AutoProvisioner;
import com.sec.chaton.bridge.MockEnvironmentSeeder;
import com.sec.chaton.bridge.MockRichBinaryAdapter;
import com.sec.chaton.d.a.du;
import com.sec.chaton.d.q;
import com.sec.chaton.d.w;
import com.sec.chaton.j.ao;
import com.sec.chaton.push.PushClientApplication;
import com.sec.chaton.push.PushClientService;
import com.sec.chaton.push.e;
import com.sec.chaton.receiver.AlarmReceiver;
import com.sec.chaton.t;
import com.sec.chaton.util.n;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * ============================================================================
 * GlobalApplication — Android 16 (API 36) & BuzZz! RichBinary Patched Entry Point
 * ============================================================================
 * Key Fixes Applied:
 *   1. Neutralized 0x7f0202c2 icon tamper check.
 *   2. Replaced registerReceiver with Android16Compat.registerReceiverSafe (RECEIVER_NOT_EXPORTED).
 *   3. Converted PushClientService implicit intent to explicit Intent wrapped in try-catch.
 *   4. Removed blacklisted android.location.CountryDetector / CountryListener hidden APIs.
 *   5. Auto-provisions @benjamin@buzzz.local and seeds SQLite mock data on startup.
 */
public class GlobalApplication extends PushClientApplication {
    public static String a = null;
    public static String b = null;
    public static String c = null;
    public static boolean d = false;
    public static String e = null;
    public static t f = null;
    public static boolean h = false;
    public static int i = 1080;
    public static int j = 2400;
    public static GlobalApplication k = null;
    private static n l = null;
    private static boolean u = false;

    public Lock g = new ReentrantLock();
    private int m = 0;
    private e n = null;
    private SearchRecentSuggestions o;
    private TelephonyManager p;
    private String s;
    private ServiceConnection v;
    private Handler w;
    private Debug.MemoryInfo x = new Debug.MemoryInfo();

    public static GlobalApplication a() {
        return k;
    }

    public static GlobalApplication m() {
        return k;
    }

    public static Resources b() {
        return k.getResources();
    }

    public static n c() {
        if (l == null) {
            l = new n();
        }
        return l;
    }

    public static void d() {
        // Short-circuited SPP broadcast registration (isolated from Samsung servers)
    }

    public static boolean e() {
        return false;
    }

    public static boolean f() {
        return false;
    }

    public static boolean g() {
        return false;
    }

    public static boolean h() {
        return true;
    }

    public static boolean i() {
        return false;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        k = this;

        // 1. Auto-provision local BuzZz! identity (@benjamin@buzzz.local) & AES key
        AutoProvisioner.ensureProvisioned(this);

        // 2. Display dimensions (safe on Android 16)
        try {
            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                i = dm.widthPixels;
                j = dm.heightPixels;
            }
        } catch (Throwable ignored) {}

        // 3. Explicit Service start with Android 16 background restriction guard
        Intent pushIntent = new Intent(this, PushClientService.class);
        pushIntent.setAction("com.sec.chaton.push.PUSH_CLIENT_SERVICE_ACTION");
        Android16Compat.startServiceSafe(this, pushIntent);

        // 4. Safe BroadcastReceiver registration with ContextCompat.RECEIVER_NOT_EXPORTED
        IntentFilter alarmFilter = new IntentFilter();
        if (AlarmReceiver.a != null) alarmFilter.addAction(AlarmReceiver.a);
        if (AlarmReceiver.b != null) alarmFilter.addAction(AlarmReceiver.b);
        Android16Compat.registerReceiverSafe(this, new AlarmReceiver(), alarmFilter);

        // 5. Initialize core task queues & local SQLite Mock Environment
        ao.f();
        du.a();
        w.a();
        q.a();

        // 6. Replace hidden API CountryDetector with standard TelephonyManager / Locale ISO
        this.s = Android16Compat.resolveCountryIso(this);

        // 7. Seed Buddies (Circles), Chats (Hangouts), @web@r-rss, and Trunk (Leftovers)
        MockRichBinaryAdapter.getInstance().initialize(this);
    }

    @Override
    public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter) {
        return Android16Compat.registerReceiverSafe(super.getBaseContext(), receiver, filter);
    }

    @Override
    public ComponentName startService(Intent service) {
        return Android16Compat.startServiceSafe(super.getBaseContext(), service);
    }
}
