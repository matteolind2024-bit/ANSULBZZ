package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/an;
 */
class an {
    final com.android.ex.editstyledtext.EditStyledText a;
    private com.android.ex.editstyledtext.EditStyledText b;
    private com.android.ex.editstyledtext.bb c;

    public an(com.android.ex.editstyledtext.EditStyledText p0, com.android.ex.editstyledtext.EditStyledText p1, com.android.ex.editstyledtext.bb p2) {
        // Registers (4 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.EditStyledText), v2 = p1 (com.android.ex.editstyledtext.EditStyledText), v3 = p2 (com.android.ex.editstyledtext.bb)
        v0.a = v1; // com.android.ex.editstyledtext.an.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.b = v2; // com.android.ex.editstyledtext.an.b:com.android.ex.editstyledtext.EditStyledText
        v0.c = v3; // com.android.ex.editstyledtext.an.c:com.android.ex.editstyledtext.bb
        return;
    }

    static com.android.ex.editstyledtext.EditStyledText a(com.android.ex.editstyledtext.an p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.an)
        v0 = v1.b; // com.android.ex.editstyledtext.an.b:com.android.ex.editstyledtext.EditStyledText
        return v0;
    }

    public void a(com.android.ex.editstyledtext.bb p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.bb)
        v0.c = v1; // com.android.ex.editstyledtext.an.c:com.android.ex.editstyledtext.bb
        return;
    }

    public void a(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        v0 = v3.c; // com.android.ex.editstyledtext.an.c:com.android.ex.editstyledtext.bb
        v1 = new com.android.ex.editstyledtext.ao;
        _result = v1.<init>(v3); // com.android.ex.editstyledtext.ao.<init> -> void
        v2 = 0;
        _result = com.android.ex.editstyledtext.bb.a(v0, v4, v1, v2); // -> android.text.Spanned
        v0 = _result;
        v1 = v3.b; // com.android.ex.editstyledtext.an.b:com.android.ex.editstyledtext.EditStyledText
        _result = v1.setText(v0); // com.android.ex.editstyledtext.EditStyledText.setText -> void
        return;
    }

}