package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/EditStyledText$SavedStyledTextState;
 */
public class EditStyledText$SavedStyledTextState extends android.view.View$BaseSavedState {
    public int mBackgroundColor;

    EditStyledText$SavedStyledTextState(android.os.Parcelable p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.Parcelable)
        _result = v0.<init>(v1); // android.view.View$BaseSavedState.<init> -> void
        return;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "EditStyledText.SavedState{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.identityHashCode(); // java.lang.System.identityHashCode -> int
        v1 = _result;
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " bgcolor=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.mBackgroundColor; // com.android.ex.editstyledtext.EditStyledText$SavedStyledTextState.mBackgroundColor:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (int)
        _result = v1.writeToParcel(v2, v3); // android.view.View$BaseSavedState.writeToParcel -> void
        v0 = v1.mBackgroundColor; // com.android.ex.editstyledtext.EditStyledText$SavedStyledTextState.mBackgroundColor:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        return;
    }

}