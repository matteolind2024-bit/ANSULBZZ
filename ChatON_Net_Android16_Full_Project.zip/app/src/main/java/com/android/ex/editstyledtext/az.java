package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/az;
 */
class az implements android.content.DialogInterface$OnCancelListener {
    final com.android.ex.editstyledtext.ap a;

    az(com.android.ex.editstyledtext.ap p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.ap)
        v0.a = v1; // com.android.ex.editstyledtext.az.a:com.android.ex.editstyledtext.ap
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onCancel(android.content.DialogInterface p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.DialogInterface)
        v0 = v1.a; // com.android.ex.editstyledtext.az.a:com.android.ex.editstyledtext.ap
        _result = v0.a(); // com.android.ex.editstyledtext.ap.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        _result = v0.b(); // com.android.ex.editstyledtext.EditStyledText.b -> void
        return;
    }

}