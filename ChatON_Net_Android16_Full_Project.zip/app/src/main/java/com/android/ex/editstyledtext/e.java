package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/e;
 */
public class e extends com.android.ex.editstyledtext.k {
    final com.android.ex.editstyledtext.c a;

    public e(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.c)
        v0.a = v1; // com.android.ex.editstyledtext.e.a:com.android.ex.editstyledtext.c
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.k.<init> -> void
        return;
    }

    protected boolean b() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // com.android.ex.editstyledtext.e.a:com.android.ex.editstyledtext.c
        _result = v0.d(); // com.android.ex.editstyledtext.c.d -> com.android.ex.editstyledtext.ap
        v0 = _result;
        _result = v0.d(); // com.android.ex.editstyledtext.ap.d -> void
        v0 = 1;
        return v0;
    }

}