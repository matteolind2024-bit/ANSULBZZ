package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/am;
 */
class am extends android.text.method.ArrowKeyMovementMethod {
     com.android.ex.editstyledtext.ak a;
     java.lang.String b;

    am(com.android.ex.editstyledtext.ak p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.android.ex.editstyledtext.ak)
        _result = v1.<init>(); // android.text.method.ArrowKeyMovementMethod.<init> -> void
        v0 = "StyledTextArrowKeyMethod";
        v1.b = v0; // com.android.ex.editstyledtext.am.b:java.lang.String
        v1.a = v2; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        return;
    }

    private int a(android.widget.TextView p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.widget.TextView)
        _result = v3.getSelectionStart(); // android.widget.TextView.getSelectionStart -> int
        v0 = _result;
        v1 = v2.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v1.p(); // com.android.ex.editstyledtext.ak.p -> int
        v1 = _result;
        if (v0 != v1) /* goto L_0011 */;
        _result = v3.getSelectionEnd(); // android.widget.TextView.getSelectionEnd -> int
        v0 = _result;
        return v0;
        _result = v3.getSelectionStart(); // android.widget.TextView.getSelectionStart -> int
        v0 = _result;
        // goto L_0010
    }

    private boolean a(android.widget.TextView p0, android.text.Spannable p1, int p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.widget.TextView), v5 = p1 (android.text.Spannable), v6 = p2 (int)
        v0 = v3.b; // com.android.ex.editstyledtext.am.b:java.lang.String
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "--- executeDown: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = 0;
        // switch(v6)
        return v0;
        _result = v3.up(v4, v5); // com.android.ex.editstyledtext.am.up -> boolean
        v1 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        // goto L_001d
        _result = v3.down(v4, v5); // com.android.ex.editstyledtext.am.down -> boolean
        v1 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        // goto L_001d
        _result = v3.left(v4, v5); // com.android.ex.editstyledtext.am.left -> boolean
        v1 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        // goto L_001d
        _result = v3.right(v4, v5); // com.android.ex.editstyledtext.am.right -> boolean
        v1 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        // goto L_001d
        v0 = v3.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v0.b(); // com.android.ex.editstyledtext.ak.b -> void
        v0 = 1;
        // goto L_001d
    }

    protected boolean down(android.widget.TextView p0, android.text.Spannable p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.widget.TextView), v7 = p1 (android.text.Spannable)
        v0 = v5.b; // com.android.ex.editstyledtext.am.b:java.lang.String
        v1 = "--- down:";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v6.getLayout(); // android.widget.TextView.getLayout -> android.text.Layout
        v0 = _result;
        _result = v5.a(v6); // com.android.ex.editstyledtext.am.a -> int
        v1 = _result;
        _result = v0.getLineForOffset(v1); // android.text.Layout.getLineForOffset -> int
        v2 = _result;
        _result = v0.getLineCount(); // android.text.Layout.getLineCount -> int
        v3 = _result;
        v3 = binOpLit8_0xd8(v3, -1);
        if (v2 >= v3) /* goto L_003c */;
        _result = v0.getParagraphDirection(v2); // android.text.Layout.getParagraphDirection -> int
        v3 = _result;
        v4 = binOpLit8_0xd8(v2, 1);
        _result = v0.getParagraphDirection(v4); // android.text.Layout.getParagraphDirection -> int
        v4 = _result;
        if (v3 != v4) /* goto L_003e */;
        _result = v0.getPrimaryHorizontal(v1); // android.text.Layout.getPrimaryHorizontal -> float
        v1 = _result;
        v2 = binOpLit8_0xd8(v2, 1);
        _result = v0.getOffsetForHorizontal(v2, v1); // android.text.Layout.getOffsetForHorizontal -> int
        v0 = _result;
        v1 = v5.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v1.d(v0); // com.android.ex.editstyledtext.ak.d -> void
        v0 = v5.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v0.a(); // com.android.ex.editstyledtext.ak.a -> void
        v0 = 1;
        return v0;
        v1 = binOpLit8_0xd8(v2, 1);
        _result = v0.getLineStart(v1); // android.text.Layout.getLineStart -> int
        v0 = _result;
        // goto L_0032
    }

    protected boolean left(android.widget.TextView p0, android.text.Spannable p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.widget.TextView), v4 = p1 (android.text.Spannable)
        v0 = v2.b; // com.android.ex.editstyledtext.am.b:java.lang.String
        v1 = "--- left:";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v3.getLayout(); // android.widget.TextView.getLayout -> android.text.Layout
        v0 = _result;
        _result = v2.a(v3); // com.android.ex.editstyledtext.am.a -> int
        v1 = _result;
        _result = v0.getOffsetToLeftOf(v1); // android.text.Layout.getOffsetToLeftOf -> int
        v0 = _result;
        v1 = v2.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v1.d(v0); // com.android.ex.editstyledtext.ak.d -> void
        v0 = v2.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v0.a(); // com.android.ex.editstyledtext.ak.a -> void
        v0 = 1;
        return v0;
    }

    public boolean onKeyDown(android.widget.TextView p0, android.text.Spannable p1, int p2, android.view.KeyEvent p3) {
        // Registers (8 total): v3 = this, v4 = p0 (android.widget.TextView), v5 = p1 (android.text.Spannable), v6 = p2 (int), v7 = p3 (android.view.KeyEvent)
        v0 = v3.b; // com.android.ex.editstyledtext.am.b:java.lang.String
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "---onkeydown:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v3.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v0.h(); // com.android.ex.editstyledtext.ak.h -> void
        v0 = v3.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v0.o(); // com.android.ex.editstyledtext.ak.o -> int
        v0 = _result;
        v1 = 1;
        if (v0 == v1) /* goto L_0030 */;
        v0 = v3.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v0.o(); // com.android.ex.editstyledtext.ak.o -> int
        v0 = _result;
        v1 = 2;
        if (v0 != v1) /* goto L_0035 */;
        _result = v3.a(v4, v5, v6); // com.android.ex.editstyledtext.am.a -> boolean
        v0 = _result;
        return v0;
        _result = v3.onKeyDown(v4, v5, v6, v7); // android.text.method.ArrowKeyMovementMethod.onKeyDown -> boolean
        v0 = _result;
        // goto L_0034
    }

    protected boolean right(android.widget.TextView p0, android.text.Spannable p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.widget.TextView), v4 = p1 (android.text.Spannable)
        v0 = v2.b; // com.android.ex.editstyledtext.am.b:java.lang.String
        v1 = "--- right:";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v3.getLayout(); // android.widget.TextView.getLayout -> android.text.Layout
        v0 = _result;
        _result = v2.a(v3); // com.android.ex.editstyledtext.am.a -> int
        v1 = _result;
        _result = v0.getOffsetToRightOf(v1); // android.text.Layout.getOffsetToRightOf -> int
        v0 = _result;
        v1 = v2.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v1.d(v0); // com.android.ex.editstyledtext.ak.d -> void
        v0 = v2.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v0.a(); // com.android.ex.editstyledtext.ak.a -> void
        v0 = 1;
        return v0;
    }

    protected boolean up(android.widget.TextView p0, android.text.Spannable p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.widget.TextView), v7 = p1 (android.text.Spannable)
        v0 = v5.b; // com.android.ex.editstyledtext.am.b:java.lang.String
        v1 = "--- up:";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v6.getLayout(); // android.widget.TextView.getLayout -> android.text.Layout
        v0 = _result;
        _result = v5.a(v6); // com.android.ex.editstyledtext.am.a -> int
        v1 = _result;
        _result = v0.getLineForOffset(v1); // android.text.Layout.getLineForOffset -> int
        v2 = _result;
        if (v2 <= 0) /* goto L_0036 */;
        _result = v0.getParagraphDirection(v2); // android.text.Layout.getParagraphDirection -> int
        v3 = _result;
        v4 = binOpLit8_0xd8(v2, -1);
        _result = v0.getParagraphDirection(v4); // android.text.Layout.getParagraphDirection -> int
        v4 = _result;
        if (v3 != v4) /* goto L_0038 */;
        _result = v0.getPrimaryHorizontal(v1); // android.text.Layout.getPrimaryHorizontal -> float
        v1 = _result;
        v2 = binOpLit8_0xd8(v2, -1);
        _result = v0.getOffsetForHorizontal(v2, v1); // android.text.Layout.getOffsetForHorizontal -> int
        v0 = _result;
        v1 = v5.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v1.d(v0); // com.android.ex.editstyledtext.ak.d -> void
        v0 = v5.a; // com.android.ex.editstyledtext.am.a:com.android.ex.editstyledtext.ak
        _result = v0.a(); // com.android.ex.editstyledtext.ak.a -> void
        v0 = 1;
        return v0;
        v1 = binOpLit8_0xd8(v2, -1);
        _result = v0.getLineStart(v1); // android.text.Layout.getLineStart -> int
        v0 = _result;
        // goto L_002c
    }

}