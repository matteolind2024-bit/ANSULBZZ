package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/q;
 */
public class q extends com.android.ex.editstyledtext.k {
    final com.android.ex.editstyledtext.c a;

    public q(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.c)
        v0.a = v1; // com.android.ex.editstyledtext.q.a:com.android.ex.editstyledtext.c
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.k.<init> -> void
        return;
    }

    protected boolean b() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // com.android.ex.editstyledtext.q.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.h(); // com.android.ex.editstyledtext.ak.h -> void
        v0 = v1.a; // com.android.ex.editstyledtext.q.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.b(); // com.android.ex.editstyledtext.ak.b -> void
        v0 = 1;
        return v0;
    }

}