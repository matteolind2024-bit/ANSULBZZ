package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ag;
 */
public class ag extends android.graphics.drawable.ShapeDrawable {
    private static boolean c;
    private android.text.Spannable a;
    private int b;

    static {
        v0 = 0;
        com.android.ex.editstyledtext.ag.c = v0; // :boolean
        return;
    }

    public ag(int p0, int p1, android.text.Spannable p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (int), v4 = p2 (android.text.Spannable)
        v0 = new android.graphics.drawable.shapes.RectShape;
        _result = v0.<init>(); // android.graphics.drawable.shapes.RectShape.<init> -> void
        _result = v1.<init>(v0); // android.graphics.drawable.ShapeDrawable.<init> -> void
        v1.a = v4; // com.android.ex.editstyledtext.ag.a:android.text.Spannable
        v1.b = v3; // com.android.ex.editstyledtext.ag.b:int
        _result = v1.b(v2); // com.android.ex.editstyledtext.ag.b -> void
        _result = v1.a(v3); // com.android.ex.editstyledtext.ag.a -> void
        return;
    }

    private void a() {
        // Registers (5 total): v4 = this
        _result = v4.b(); // com.android.ex.editstyledtext.ag.b -> com.android.ex.editstyledtext.ah
        v0 = _result;
        v1 = v4.a; // com.android.ex.editstyledtext.ag.a:android.text.Spannable
        _result = android.text.Spannable.getSpanStart(v1, v0); // -> int
        v2 = _result;
        _result = android.text.Spannable.getSpanEnd(v1, v0); // -> int
        v0 = _result;
        v3 = android.text.style.ForegroundColorSpan.class;
        _result = android.text.Spannable.getSpans(v1, v2, v0, v3); // -> java.lang.Object[]
        v0 = _result;
        v0 = (android.text.style.ForegroundColorSpan[]) v0;
        v1 = com.android.ex.editstyledtext.ag.c; // :boolean
        if (v1 == 0) /* goto L_0035 */;
        v1 = "EditStyledTextSpan";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "--- renewColor:";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v0.length;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.d(v2); // android.util.Log.d -> int
        v1 = v0.length;
        if (v1 <= 0) /* goto L_0044 */;
        v1 = v0.length;
        v1 = binOpLit8_0xd8(v1, -1);
        v0 = v0[v1];
        _result = v0.getForegroundColor(); // android.text.style.ForegroundColorSpan.getForegroundColor -> int
        v0 = _result;
        _result = v4.b(v0); // com.android.ex.editstyledtext.ag.b -> void
        return;
    }

    private com.android.ex.editstyledtext.ah b() {
        // Registers (6 total): v5 = this
        v1 = 0;
        v0 = v5.a; // com.android.ex.editstyledtext.ag.a:android.text.Spannable
        _result = android.text.Spannable.length(v0); // -> int
        v2 = _result;
        v3 = com.android.ex.editstyledtext.ah.class;
        _result = android.text.Spannable.getSpans(v0, v1, v2, v3); // -> java.lang.Object[]
        v0 = _result;
        v0 = (com.android.ex.editstyledtext.ah[]) v0;
        v2 = v0.length;
        if (v2 <= 0) /* goto L_0024 */;
        v3 = v0.length;
        v2 = v1;
        if (v2 >= v3) /* goto L_0024 */;
        v1 = v0[v2];
        _result = v1.getDrawable(); // com.android.ex.editstyledtext.ah.getDrawable -> android.graphics.drawable.Drawable
        v4 = _result;
        if (v4 != v5) /* goto L_0020 */;
        v0 = v1;
        return v0;
        v1 = binOpLit8_0xd8(v2, 1);
        v2 = v1;
        // goto L_0014
        v0 = "EditStyledTextSpan";
        v1 = "---renewBounds: Couldn't find";
        _result = v0.e(v1); // android.util.Log.e -> int
        v0 = 0;
        // goto L_001f
    }

    private void b(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = com.android.ex.editstyledtext.ag.c; // :boolean
        if (v0 == 0) /* goto L_001e */;
        v0 = "EditStyledTextSpan";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "--- renewColor:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v3.getPaint(); // com.android.ex.editstyledtext.ag.getPaint -> android.graphics.Paint
        v0 = _result;
        _result = v0.setColor(v4); // android.graphics.Paint.setColor -> void
        return;
    }

    public void a(int p0) {
        // Registers (7 total): v5 = this, v6 = p0 (int)
        v4 = 20;
        v3 = 0;
        v0 = com.android.ex.editstyledtext.ag.c; // :boolean
        if (v0 == 0) /* goto L_0021 */;
        v0 = "EditStyledTextSpan";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "--- renewBounds:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        if (v6 <= v4) /* goto L_0024 */;
        v6 = binOp2addr_0xb1(v6, v4);
        v5.b = v6; // com.android.ex.editstyledtext.ag.b:int
        _result = v5.setBounds(v3, v3, v6, v4); // com.android.ex.editstyledtext.ag.setBounds -> void
        return;
    }

    public void draw(android.graphics.Canvas p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.graphics.Canvas)
        _result = v5.a(); // com.android.ex.editstyledtext.ag.a -> void
        v0 = new android.graphics.Rect;
        v1 = 0;
        v2 = 9;
        v3 = v5.b; // com.android.ex.editstyledtext.ag.b:int
        v4 = 11;
        _result = v0.<init>(v1, v2, v3, v4); // android.graphics.Rect.<init> -> void
        _result = v5.getPaint(); // com.android.ex.editstyledtext.ag.getPaint -> android.graphics.Paint
        v1 = _result;
        _result = v6.drawRect(v0, v1); // android.graphics.Canvas.drawRect -> void
        return;
    }

}