package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/k;
 */
public class k {
    private java.lang.Object[] a;
    final com.android.ex.editstyledtext.c b;

    public k(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.c)
        v0.b = v1; // com.android.ex.editstyledtext.k.b:com.android.ex.editstyledtext.c
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    protected java.lang.Object a(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.a; // com.android.ex.editstyledtext.k.a:java.lang.Object[]
        if (v0 == 0) /* goto L_0009 */;
        v0 = v2.a; // com.android.ex.editstyledtext.k.a:java.lang.Object[]
        v0 = v0.length;
        if (v3 <= v0) /* goto L_0014 */;
        v0 = "EditModeActions";
        v1 = "--- Number of the parameter is out of bound.";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = 0;
        return v0;
        v0 = v2.a; // com.android.ex.editstyledtext.k.a:java.lang.Object[]
        v0 = v0[v3];
        // goto L_0013
    }

    protected void a(java.lang.Object[] p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object[])
        v0.a = v1; // com.android.ex.editstyledtext.k.a:java.lang.Object[]
        return;
    }

    protected boolean a() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.android.ex.editstyledtext.k.d -> boolean
        v0 = _result;
        return v0;
    }

    protected boolean b() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    protected boolean c() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // com.android.ex.editstyledtext.k.d -> boolean
        v0 = _result;
        return v0;
    }

    protected boolean d() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // com.android.ex.editstyledtext.k.e -> boolean
        v0 = _result;
        return v0;
    }

    protected boolean e() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // com.android.ex.editstyledtext.k.b -> boolean
        v0 = _result;
        return v0;
    }

    protected boolean f() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.android.ex.editstyledtext.k.b:com.android.ex.editstyledtext.c
        _result = v0.a(); // com.android.ex.editstyledtext.c.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        _result = v0.e(); // com.android.ex.editstyledtext.EditStyledText.e -> void
        v0 = v2.b; // com.android.ex.editstyledtext.k.b:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        v1 = 3;
        _result = v0.a(v1); // com.android.ex.editstyledtext.ak.a -> void
        v0 = 1;
        return v0;
    }

}