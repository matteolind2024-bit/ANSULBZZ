package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ab;
 */
public class ab extends com.android.ex.editstyledtext.v {
    final com.android.ex.editstyledtext.c a;

    public ab(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.c)
        v0.a = v1; // com.android.ex.editstyledtext.ab.a:com.android.ex.editstyledtext.c
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.v.<init> -> void
        return;
    }

    protected boolean a() {
        // Registers (3 total): v2 = this
        v1 = 1;
        _result = v2.a(); // com.android.ex.editstyledtext.v.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0008 */;
        return v1;
        v0 = v2.a; // com.android.ex.editstyledtext.ab.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.f(); // com.android.ex.editstyledtext.ak.f -> void
        // goto L_0007
    }

}