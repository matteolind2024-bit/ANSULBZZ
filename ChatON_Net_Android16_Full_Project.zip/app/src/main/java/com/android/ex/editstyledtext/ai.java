package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ai;
 */
public class ai extends android.text.style.CharacterStyle {
    private int a;
    private int b;

    public ai(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        _result = v1.<init>(); // android.text.style.CharacterStyle.<init> -> void
        v1.a = v2; // com.android.ex.editstyledtext.ai.a:int
        _result = v1.b(v2); // com.android.ex.editstyledtext.ai.b -> boolean
        _result = v1.a(v2, v3); // com.android.ex.editstyledtext.ai.a -> int
        v0 = _result;
        v1.b = v0; // com.android.ex.editstyledtext.ai.b:int
        return;
    }

    private int a(int p0, int p1) {
        // Registers (9 total): v6 = this, v7 = p0 (int), v8 = p1 (int)
        v2 = 16777215; // 0x00ffffff
        v4 = 128;
        _result = v8.alpha(); // android.graphics.Color.alpha -> int
        v3 = _result;
        _result = v8.red(); // android.graphics.Color.red -> int
        v1 = _result;
        _result = v8.green(); // android.graphics.Color.green -> int
        v0 = _result;
        _result = v8.blue(); // android.graphics.Color.blue -> int
        v5 = _result;
        if (v3 != 0) /* goto L_0018 */;
        v3 = v4;
        // switch(v7)
        v0 = "EditStyledText";
        v1 = "--- getMarqueeColor: got illigal marquee ID.";
        _result = v0.e(v1); // android.util.Log.e -> int
        v0 = v2;
        return v0;
        if (v1 <= v4) /* goto L_002f */;
        v1 = binOpLit8_0xdb(v1, 2);
        _result = v3.argb(v1, v0, v5); // android.graphics.Color.argb -> int
        v0 = _result;
        // goto L_0025
        v1 = binOpLit16_0xd1(v1, 255);
        v1 = binOpLit8_0xdb(v1, 2);
        // goto L_002a
        if (v0 <= v4) /* goto L_0039 */;
        v0 = binOpLit8_0xdb(v0, 2);
        // goto L_002a
        v0 = binOpLit16_0xd1(v0, 255);
        v0 = binOpLit8_0xdb(v0, 2);
        // goto L_002a
        v0 = v2;
        // goto L_0025
    }

    private boolean b(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = 1;
        if (v3 == 0) /* goto L_0005 */;
        if (v3 != v0) /* goto L_0006 */;
        return v0;
        v0 = "EditStyledTextSpan";
        v1 = "--- Invalid type of MarqueeSpan";
        _result = v0.e(v1); // android.util.Log.e -> int
        v0 = 0;
        // goto L_0005
    }

    public void a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.android.ex.editstyledtext.ai.a:int
        _result = v1.a(v0, v2); // com.android.ex.editstyledtext.ai.a -> int
        v0 = _result;
        v1.b = v0; // com.android.ex.editstyledtext.ai.b:int
        return;
    }

    public void updateDrawState(android.text.TextPaint p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.text.TextPaint)
        v0 = v1.b; // com.android.ex.editstyledtext.ai.b:int
        v2.bgColor = v0; // android.text.TextPaint.bgColor:int
        return;
    }

}