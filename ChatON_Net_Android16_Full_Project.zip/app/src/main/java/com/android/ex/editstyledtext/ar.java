package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ar;
 */
class ar implements android.content.DialogInterface$OnClickListener {
    final com.android.ex.editstyledtext.ap a;

    ar(com.android.ex.editstyledtext.ap p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.ap)
        v0.a = v1; // com.android.ex.editstyledtext.ar.a:com.android.ex.editstyledtext.ap
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onClick(android.content.DialogInterface p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.DialogInterface), v5 = p1 (int)
        v0 = android.text.Layout$Alignment.ALIGN_NORMAL; // :android.text.Layout$Alignment
        // switch(v5)
        v1 = "EditStyledText";
        v2 = "--- onShowAlignAlertDialog: got illigal align.";
        _result = v1.e(v2); // android.util.Log.e -> int
        v1 = v3.a; // com.android.ex.editstyledtext.ar.a:com.android.ex.editstyledtext.ap
        _result = v1.a(); // com.android.ex.editstyledtext.ap.a -> com.android.ex.editstyledtext.EditStyledText
        v1 = _result;
        _result = v1.setAlignment(v0); // com.android.ex.editstyledtext.EditStyledText.setAlignment -> void
        return;
        v0 = android.text.Layout$Alignment.ALIGN_NORMAL; // :android.text.Layout$Alignment
        // goto L_000e
        v0 = android.text.Layout$Alignment.ALIGN_CENTER; // :android.text.Layout$Alignment
        // goto L_000e
        v0 = android.text.Layout$Alignment.ALIGN_OPPOSITE; // :android.text.Layout$Alignment
        // goto L_000e
    }

}