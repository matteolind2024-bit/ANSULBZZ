package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ao;
 */
class ao implements android.text.Html$ImageGetter {
    final com.android.ex.editstyledtext.an a;

    ao(com.android.ex.editstyledtext.an p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.an)
        v0.a = v1; // com.android.ex.editstyledtext.ao.a:com.android.ex.editstyledtext.an
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.graphics.drawable.Drawable getDrawable(java.lang.String p0) {
        // Registers (10 total): v8 = this, v9 = p0 (java.lang.String)
        v1 = 0;
        v0 = "EditStyledText";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "--- sethtml: src=";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v0.d(v2); // android.util.Log.d -> int
        v0 = "content://";
        _result = v9.startsWith(v0); // java.lang.String.startsWith -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00e8 */;
        _result = v9.parse(); // android.net.Uri.parse -> android.net.Uri
        v5 = _result;
        _result = this.gc(); // java.lang.System.gc -> void
        v0 = v8.a; // com.android.ex.editstyledtext.ao.a:com.android.ex.editstyledtext.an
        _result = v0.a(); // com.android.ex.editstyledtext.an.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        _result = v0.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        _result = v0.openInputStream(v5); // android.content.ContentResolver.openInputStream -> java.io.InputStream
        v0 = _result;
        v3 = new android.graphics.BitmapFactory$Options;
        _result = v3.<init>(); // android.graphics.BitmapFactory$Options.<init> -> void
        v2 = 1;
        v3.inJustDecodeBounds = v2; // android.graphics.BitmapFactory$Options.inJustDecodeBounds:boolean
        v2 = 0;
        _result = v0.decodeStream(v2, v3); // android.graphics.BitmapFactory.decodeStream -> android.graphics.Bitmap
        _result = v0.close(); // java.io.InputStream.close -> void
        v0 = v8.a; // com.android.ex.editstyledtext.ao.a:com.android.ex.editstyledtext.an
        _result = v0.a(); // com.android.ex.editstyledtext.an.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        _result = v0.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        _result = v0.openInputStream(v5); // android.content.ContentResolver.openInputStream -> java.io.InputStream
        v6 = _result;
        v2 = v3.outWidth; // android.graphics.BitmapFactory$Options.outWidth:int
        v0 = v3.outHeight; // android.graphics.BitmapFactory$Options.outHeight:int
        v4 = v3.outWidth; // android.graphics.BitmapFactory$Options.outWidth:int
        v7 = v8.a; // com.android.ex.editstyledtext.ao.a:com.android.ex.editstyledtext.an
        v7 = v7.a; // com.android.ex.editstyledtext.an.a:com.android.ex.editstyledtext.EditStyledText
        _result = v7.a(); // com.android.ex.editstyledtext.EditStyledText.a -> int
        v7 = _result;
        if (v4 <= v7) /* goto L_00ad */;
        v2 = v8.a; // com.android.ex.editstyledtext.ao.a:com.android.ex.editstyledtext.an
        v2 = v2.a; // com.android.ex.editstyledtext.an.a:com.android.ex.editstyledtext.EditStyledText
        _result = v2.a(); // com.android.ex.editstyledtext.EditStyledText.a -> int
        v2 = _result;
        v4 = v8.a; // com.android.ex.editstyledtext.ao.a:com.android.ex.editstyledtext.an
        v4 = v4.a; // com.android.ex.editstyledtext.an.a:com.android.ex.editstyledtext.EditStyledText
        _result = v4.a(); // com.android.ex.editstyledtext.EditStyledText.a -> int
        v4 = _result;
        v0 = binOp2addr_0xb2(v0, v4);
        v3 = v3.outWidth; // android.graphics.BitmapFactory$Options.outWidth:int
        v0 = binOp2addr_0xb3(v0, v3);
        v3 = new android.graphics.Rect;
        v4 = 0;
        v7 = 0;
        _result = v3.<init>(v4, v7, v2, v0); // android.graphics.Rect.<init> -> void
        v4 = 0;
        _result = v6.decodeStream(v3, v4); // android.graphics.BitmapFactory.decodeStream -> android.graphics.Bitmap
        v3 = _result;
        v4 = v3;
        v3 = v2;
        v2 = v0;
        v0 = new android.graphics.drawable.BitmapDrawable;
        v7 = v8.a; // com.android.ex.editstyledtext.ao.a:com.android.ex.editstyledtext.an
        _result = v7.a(); // com.android.ex.editstyledtext.an.a -> com.android.ex.editstyledtext.EditStyledText
        v7 = _result;
        _result = v7.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v7 = _result;
        _result = v7.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v7 = _result;
        _result = v0.<init>(v7, v4); // android.graphics.drawable.BitmapDrawable.<init> -> void
        v4 = 0;
        v7 = 0;
        _result = v0.setBounds(v4, v7, v3, v2); // android.graphics.drawable.Drawable.setBounds -> void
        _result = v6.close(); // java.io.InputStream.close -> void
        return v0;
        _result = v6.decodeStream(); // android.graphics.BitmapFactory.decodeStream -> android.graphics.Bitmap
        v3 = _result;
        v4 = v3;
        v3 = v2;
        v2 = v0;
        // goto L_0091
        v0 = _exception;
        v2 = "EditStyledText";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "--- set html: Failed to loaded content ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v2.e(v3, v0); // android.util.Log.e -> int
        v0 = v1;
        // goto L_00ac
        v0 = _exception;
        v0 = "EditStyledText";
        v2 = "OutOfMemoryError";
        _result = v0.e(v2); // android.util.Log.e -> int
        v0 = v8.a; // com.android.ex.editstyledtext.ao.a:com.android.ex.editstyledtext.an
        _result = v0.a(); // com.android.ex.editstyledtext.an.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        v2 = 5;
        _result = v0.setHint(v2); // com.android.ex.editstyledtext.EditStyledText.setHint -> void
        v0 = v1;
        // goto L_00ac
        v0 = v1;
        // goto L_00ac
    }

}