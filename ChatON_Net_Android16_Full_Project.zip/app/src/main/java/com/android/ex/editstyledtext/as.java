package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/as;
 */
class as implements android.content.DialogInterface$OnClickListener {
    final com.android.ex.editstyledtext.ap a;

    as(com.android.ex.editstyledtext.ap p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.ap)
        v0.a = v1; // com.android.ex.editstyledtext.as.a:com.android.ex.editstyledtext.ap
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onClick(android.content.DialogInterface p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.DialogInterface), v5 = p1 (int)
        v0 = "EditStyledText";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "mBuilder.onclick:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v3.a; // com.android.ex.editstyledtext.as.a:com.android.ex.editstyledtext.ap
        _result = v0.a(); // com.android.ex.editstyledtext.ap.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        _result = v0.setMarquee(v5); // com.android.ex.editstyledtext.EditStyledText.setMarquee -> void
        return;
    }

}