package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/bb;
 */
public interface bb {
    public abstract android.text.Spanned a(java.lang.String p0, android.text.Html$ImageGetter p1, android.text.Html$TagHandler p2);
}