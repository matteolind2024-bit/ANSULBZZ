package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/al;
 */
class al implements android.view.MenuItem$OnMenuItemClickListener {
    final com.android.ex.editstyledtext.EditStyledText a;

    private al(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.EditStyledText)
        v0.a = v1; // com.android.ex.editstyledtext.al.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    al(com.android.ex.editstyledtext.EditStyledText p0, com.android.ex.editstyledtext.a p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.EditStyledText), v2 = p1 (com.android.ex.editstyledtext.a)
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.al.<init> -> void
        return;
    }

    public boolean onMenuItemClick(android.view.MenuItem p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.MenuItem)
        v0 = v2.a; // com.android.ex.editstyledtext.al.a:com.android.ex.editstyledtext.EditStyledText
        _result = android.view.MenuItem.getItemId(v3); // -> int
        v1 = _result;
        _result = v0.onTextContextMenuItem(v1); // com.android.ex.editstyledtext.EditStyledText.onTextContextMenuItem -> boolean
        v0 = _result;
        return v0;
    }

}