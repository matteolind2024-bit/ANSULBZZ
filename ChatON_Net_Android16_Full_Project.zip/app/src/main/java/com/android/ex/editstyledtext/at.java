package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/at;
 */
class at implements android.content.DialogInterface$OnCancelListener {
    final com.android.ex.editstyledtext.ap a;

    at(com.android.ex.editstyledtext.ap p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.ap)
        v0.a = v1; // com.android.ex.editstyledtext.at.a:com.android.ex.editstyledtext.ap
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onCancel(android.content.DialogInterface p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.DialogInterface)
        v0 = "EditStyledText";
        v1 = "--- oncancel";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v2.a; // com.android.ex.editstyledtext.at.a:com.android.ex.editstyledtext.ap
        _result = v0.a(); // com.android.ex.editstyledtext.ap.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        _result = v0.b(); // com.android.ex.editstyledtext.EditStyledText.b -> void
        return;
    }

}