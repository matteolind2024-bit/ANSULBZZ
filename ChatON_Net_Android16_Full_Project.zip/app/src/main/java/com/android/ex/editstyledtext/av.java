package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/av;
 */
class av implements android.view.View$OnClickListener {
    final com.android.ex.editstyledtext.ap a;

    av(com.android.ex.editstyledtext.ap p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.ap)
        v0.a = v1; // com.android.ex.editstyledtext.av.a:com.android.ex.editstyledtext.ap
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onClick(android.view.View p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.View)
        v2 = 0;
        v0 = v3.a; // com.android.ex.editstyledtext.av.a:com.android.ex.editstyledtext.ap
        _result = v0.a(); // com.android.ex.editstyledtext.ap.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        _result = v4.getDrawingCacheBackgroundColor(); // android.view.View.getDrawingCacheBackgroundColor -> int
        v1 = _result;
        _result = v0.setItemColor(v1); // com.android.ex.editstyledtext.EditStyledText.setItemColor -> void
        v0 = v3.a; // com.android.ex.editstyledtext.av.a:com.android.ex.editstyledtext.ap
        _result = v0.b(); // com.android.ex.editstyledtext.ap.b -> android.app.AlertDialog
        v0 = _result;
        if (v0 == 0) /* goto L_002e */;
        v0 = v3.a; // com.android.ex.editstyledtext.av.a:com.android.ex.editstyledtext.ap
        _result = v0.b(); // com.android.ex.editstyledtext.ap.b -> android.app.AlertDialog
        v0 = _result;
        _result = v0.setView(v2); // android.app.AlertDialog.setView -> void
        v0 = v3.a; // com.android.ex.editstyledtext.av.a:com.android.ex.editstyledtext.ap
        _result = v0.b(); // com.android.ex.editstyledtext.ap.b -> android.app.AlertDialog
        v0 = _result;
        _result = v0.dismiss(); // android.app.AlertDialog.dismiss -> void
        v0 = v3.a; // com.android.ex.editstyledtext.av.a:com.android.ex.editstyledtext.ap
        _result = v0.a(v2); // com.android.ex.editstyledtext.ap.a -> android.app.AlertDialog
        return;
        v0 = "EditStyledText";
        v1 = "--- buildAndShowColorDialogue: can't find alertDialog";
        _result = v0.e(v1); // android.util.Log.e -> int
        // goto L_002d
    }

}