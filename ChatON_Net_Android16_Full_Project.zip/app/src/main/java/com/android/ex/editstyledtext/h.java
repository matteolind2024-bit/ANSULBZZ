package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/h;
 */
public class h extends com.android.ex.editstyledtext.v {
    final com.android.ex.editstyledtext.c a;

    public h(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.c)
        v0.a = v1; // com.android.ex.editstyledtext.h.a:com.android.ex.editstyledtext.c
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.v.<init> -> void
        return;
    }

    protected boolean a() {
        // Registers (3 total): v2 = this
        v1 = 1;
        _result = v2.a(); // com.android.ex.editstyledtext.v.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0008 */;
        return v1;
        v0 = v2.a; // com.android.ex.editstyledtext.h.a:com.android.ex.editstyledtext.c
        _result = v0.d(); // com.android.ex.editstyledtext.c.d -> com.android.ex.editstyledtext.ap
        v0 = _result;
        _result = v0.g(); // com.android.ex.editstyledtext.ap.g -> void
        // goto L_0007
    }

    protected boolean c() {
        // Registers (6 total): v5 = this
        v4 = 1;
        v3 = 0;
        _result = v5.c(); // com.android.ex.editstyledtext.v.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0009 */;
        return v4;
        v0 = v5.a; // com.android.ex.editstyledtext.h.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.r(); // com.android.ex.editstyledtext.ak.r -> int
        v0 = _result;
        v1 = v5.a; // com.android.ex.editstyledtext.h.a:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        v2 = v5.a; // com.android.ex.editstyledtext.h.a:com.android.ex.editstyledtext.c
        _result = v2.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v2 = _result;
        _result = v2.s(); // com.android.ex.editstyledtext.ak.s -> int
        v2 = _result;
        _result = v1.c(v2, v3); // com.android.ex.editstyledtext.ak.c -> void
        v1 = v5.a; // com.android.ex.editstyledtext.h.a:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        _result = v1.l(); // com.android.ex.editstyledtext.ak.l -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0045 */;
        v1 = v5.a; // com.android.ex.editstyledtext.h.a:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        _result = v1.b(v0, v3); // com.android.ex.editstyledtext.ak.b -> void
        v0 = v5.a; // com.android.ex.editstyledtext.h.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.b(); // com.android.ex.editstyledtext.ak.b -> void
        // goto L_0008
        _result = v5.f(); // com.android.ex.editstyledtext.h.f -> boolean
        v0 = v5.a; // com.android.ex.editstyledtext.h.a:com.android.ex.editstyledtext.c
        _result = v0.d(); // com.android.ex.editstyledtext.c.d -> com.android.ex.editstyledtext.ap
        v0 = _result;
        _result = v0.g(); // com.android.ex.editstyledtext.ap.g -> void
        // goto L_0008
    }

}