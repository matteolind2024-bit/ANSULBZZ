package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/EditStyledText$SoftKeyReceiver;
 */
class EditStyledText$SoftKeyReceiver extends android.os.ResultReceiver {
     com.android.ex.editstyledtext.EditStyledText mEST;
     int mNewEnd;
     int mNewStart;

    EditStyledText$SoftKeyReceiver(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.android.ex.editstyledtext.EditStyledText)
        _result = v2.getHandler(); // com.android.ex.editstyledtext.EditStyledText.getHandler -> android.os.Handler
        v0 = _result;
        _result = v1.<init>(v0); // android.os.ResultReceiver.<init> -> void
        v1.mEST = v2; // com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver.mEST:com.android.ex.editstyledtext.EditStyledText
        return;
    }

    protected void onReceiveResult(int p0, android.os.Bundle p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (android.os.Bundle)
        v0 = 2;
        if (v4 == v0) /* goto L_0010 */;
        v0 = v3.mEST; // com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver.mEST:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        v1 = v3.mNewStart; // com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver.mNewStart:int
        v2 = v3.mNewEnd; // com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver.mNewEnd:int
        _result = v0.setSelection(v1, v2); // android.text.Selection.setSelection -> void
        return;
    }

}