package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ad;
 */
public class ad extends com.android.ex.editstyledtext.k {
    final com.android.ex.editstyledtext.c c;

    public ad(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.c)
        v0.c = v1; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.k.<init> -> void
        return;
    }

    protected boolean b() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.n(); // com.android.ex.editstyledtext.ak.n -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0019 */;
        v0 = v2.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.n(); // com.android.ex.editstyledtext.ak.n -> int
        v0 = _result;
        v1 = 5;
        if (v0 != v1) /* goto L_002f */;
        v0 = v2.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        v1 = v2.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v1.c(); // com.android.ex.editstyledtext.c.c -> int
        v1 = _result;
        _result = v0.b(v1); // com.android.ex.editstyledtext.ak.b -> void
        v0 = v2.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v0.a(); // com.android.ex.editstyledtext.c.a -> void
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_002e
    }

    protected boolean d() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        _result = v1.n(); // com.android.ex.editstyledtext.ak.n -> int
        v1 = _result;
        if (v1 == 0) /* goto L_001a */;
        v1 = v3.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        _result = v1.n(); // com.android.ex.editstyledtext.ak.n -> int
        v1 = _result;
        v2 = 5;
        if (v1 != v2) /* goto L_0032 */;
        v1 = v3.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        v2 = v3.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v2.c(); // com.android.ex.editstyledtext.c.c -> int
        v2 = _result;
        _result = v1.b(v2); // com.android.ex.editstyledtext.ak.b -> void
        _result = v3.f(); // com.android.ex.editstyledtext.ad.f -> boolean
        v1 = v3.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> boolean
        return v0;
        v1 = v3.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        _result = v1.n(); // com.android.ex.editstyledtext.ak.n -> int
        v1 = _result;
        v2 = v3.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v2.c(); // com.android.ex.editstyledtext.c.c -> int
        v2 = _result;
        if (v1 == v2) /* goto L_0062 */;
        v1 = v3.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        _result = v1.b(); // com.android.ex.editstyledtext.ak.b -> void
        v1 = v3.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        v2 = v3.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v2.c(); // com.android.ex.editstyledtext.c.c -> int
        v2 = _result;
        _result = v1.b(v2); // com.android.ex.editstyledtext.ak.b -> void
        v1 = v3.c; // com.android.ex.editstyledtext.ad.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> boolean
        // goto L_0031
        v0 = 0;
        // goto L_0031
    }

}