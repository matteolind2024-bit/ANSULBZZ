package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/b;
 */
public class b extends android.graphics.drawable.ShapeDrawable {
    private android.graphics.Rect a;

    public b(int p0, int p1, int p2, int p3) {
        // Registers (8 total): v3 = this, v4 = p0 (int), v5 = p1 (int), v6 = p2 (int), v7 = p3 (int)
        v0 = new android.graphics.drawable.shapes.RectShape;
        _result = v0.<init>(); // android.graphics.drawable.shapes.RectShape.<init> -> void
        _result = v3.<init>(v0); // android.graphics.drawable.ShapeDrawable.<init> -> void
        v0 = new android.graphics.Rect;
        v1 = binOp_0x91(v5, v7);
        v2 = binOp_0x91(v6, v7);
        _result = v0.<init>(v7, v7, v1, v2); // android.graphics.Rect.<init> -> void
        v3.a = v0; // com.android.ex.editstyledtext.b.a:android.graphics.Rect
        _result = v3.getPaint(); // com.android.ex.editstyledtext.b.getPaint -> android.graphics.Paint
        v0 = _result;
        _result = v0.setColor(v4); // android.graphics.Paint.setColor -> void
        return;
    }

    public void draw(android.graphics.Canvas p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Canvas)
        v0 = v2.a; // com.android.ex.editstyledtext.b.a:android.graphics.Rect
        _result = v2.getPaint(); // com.android.ex.editstyledtext.b.getPaint -> android.graphics.Paint
        v1 = _result;
        _result = v3.drawRect(v0, v1); // android.graphics.Canvas.drawRect -> void
        return;
    }

}