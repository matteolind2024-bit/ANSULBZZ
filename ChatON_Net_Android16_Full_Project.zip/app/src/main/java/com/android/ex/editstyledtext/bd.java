package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/bd;
 */
public class bd extends android.view.inputmethod.InputConnectionWrapper {
     com.android.ex.editstyledtext.EditStyledText a;

    public bd(android.view.inputmethod.InputConnection p0, com.android.ex.editstyledtext.EditStyledText p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.inputmethod.InputConnection), v3 = p1 (com.android.ex.editstyledtext.EditStyledText)
        v0 = 1;
        _result = v1.<init>(v2, v0); // android.view.inputmethod.InputConnectionWrapper.<init> -> void
        v1.a = v3; // com.android.ex.editstyledtext.bd.a:com.android.ex.editstyledtext.EditStyledText
        return;
    }

    public boolean commitText(java.lang.CharSequence p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.CharSequence), v4 = p1 (int)
        v0 = "EditStyledText";
        v1 = "--- commitText:";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v2.a; // com.android.ex.editstyledtext.bd.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.d(); // com.android.ex.editstyledtext.EditStyledText.d -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.h(); // com.android.ex.editstyledtext.ak.h -> void
        _result = v2.commitText(v3, v4); // android.view.inputmethod.InputConnectionWrapper.commitText -> boolean
        v0 = _result;
        return v0;
    }

    public boolean finishComposingText() {
        // Registers (3 total): v2 = this
        v0 = "EditStyledText";
        v1 = "--- finishcomposing:";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v2.a; // com.android.ex.editstyledtext.bd.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.n(); // com.android.ex.editstyledtext.EditStyledText.n -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0026 */;
        v0 = v2.a; // com.android.ex.editstyledtext.bd.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.a(); // com.android.ex.editstyledtext.EditStyledText.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0026 */;
        v0 = v2.a; // com.android.ex.editstyledtext.bd.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.l(); // com.android.ex.editstyledtext.EditStyledText.l -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0026 */;
        v0 = v2.a; // com.android.ex.editstyledtext.bd.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.c(); // com.android.ex.editstyledtext.EditStyledText.c -> void
        _result = v2.finishComposingText(); // android.view.inputmethod.InputConnectionWrapper.finishComposingText -> boolean
        v0 = _result;
        return v0;
    }

}