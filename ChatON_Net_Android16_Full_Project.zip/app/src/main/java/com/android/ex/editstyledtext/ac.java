package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ac;
 */
public class ac extends com.android.ex.editstyledtext.ad {
    final com.android.ex.editstyledtext.c a;

    public ac(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.c)
        v0.a = v1; // com.android.ex.editstyledtext.ac.a:com.android.ex.editstyledtext.c
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.ad.<init> -> void
        return;
    }

    protected boolean d() {
        // Registers (4 total): v3 = this
        v2 = 1;
        _result = v3.d(); // com.android.ex.editstyledtext.ad.d -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0008 */;
        return v2;
        v0 = 0;
        _result = v3.a(v0); // com.android.ex.editstyledtext.ac.a -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_0022 */;
        v1 = (v0 instanceof java.lang.Integer);
        if (v1 == 0) /* goto L_0022 */;
        v1 = v3.a; // com.android.ex.editstyledtext.ac.a:com.android.ex.editstyledtext.c
        _result = v1.a(); // com.android.ex.editstyledtext.c.a -> com.android.ex.editstyledtext.EditStyledText
        v1 = _result;
        v0 = (java.lang.Integer) v0;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v1.onTextContextMenuItem(v0); // com.android.ex.editstyledtext.EditStyledText.onTextContextMenuItem -> boolean
        v0 = v3.a; // com.android.ex.editstyledtext.ac.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.b(); // com.android.ex.editstyledtext.ak.b -> void
        // goto L_0007
    }

}