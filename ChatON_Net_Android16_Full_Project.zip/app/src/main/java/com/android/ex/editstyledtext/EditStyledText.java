package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/EditStyledText;
 */
public class EditStyledText extends android.widget.EditText {
    private static java.lang.CharSequence a;
    private static java.lang.CharSequence b;
    private static java.lang.CharSequence c;
    private static final android.text.NoCopySpan$Concrete k;
    private float d;
    private java.util.ArrayList e;
    private android.graphics.drawable.Drawable f;
    private com.android.ex.editstyledtext.ak g;
    private android.view.inputmethod.InputConnection h;
    private com.android.ex.editstyledtext.an i;
    private com.android.ex.editstyledtext.ap j;

    static {
        v0 = new android.text.NoCopySpan$Concrete;
        _result = v0.<init>(); // android.text.NoCopySpan$Concrete.<init> -> void
        com.android.ex.editstyledtext.EditStyledText.k = v0; // :android.text.NoCopySpan$Concrete
        return;
    }

    public EditStyledText(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        _result = v1.<init>(v2); // android.widget.EditText.<init> -> void
        v0 = 0;
        v1.d = v0; // com.android.ex.editstyledtext.EditStyledText.d:float
        _result = v1.q(); // com.android.ex.editstyledtext.EditStyledText.q -> void
        return;
    }

    public EditStyledText(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.util.AttributeSet)
        _result = v1.<init>(v2, v3); // android.widget.EditText.<init> -> void
        v0 = 0;
        v1.d = v0; // com.android.ex.editstyledtext.EditStyledText.d:float
        _result = v1.q(); // com.android.ex.editstyledtext.EditStyledText.q -> void
        return;
    }

    public EditStyledText(android.content.Context p0, android.util.AttributeSet p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.util.AttributeSet), v4 = p2 (int)
        _result = v1.<init>(v2, v3, v4); // android.widget.EditText.<init> -> void
        v0 = 0;
        v1.d = v0; // com.android.ex.editstyledtext.EditStyledText.d:float
        _result = v1.q(); // com.android.ex.editstyledtext.EditStyledText.q -> void
        return;
    }

    static int a(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.EditStyledText)
        _result = v1.z(); // com.android.ex.editstyledtext.EditStyledText.z -> int
        v0 = _result;
        return v0;
    }

    private void a(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        if (v0 == 0) /* goto L_001a */;
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        _result = v0.iterator(); // java.util.ArrayList.iterator -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001a */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.android.ex.editstyledtext.ae) v0;
        _result = com.android.ex.editstyledtext.ae.a(v0, v3, v4); // -> void
        // goto L_000a
        return;
    }

    private void a(android.view.MotionEvent p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.MotionEvent)
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        if (v0 == 0) /* goto L_001a */;
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        _result = v0.iterator(); // java.util.ArrayList.iterator -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001a */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.android.ex.editstyledtext.ae) v0;
        _result = com.android.ex.editstyledtext.ae.a(v0, v3); // -> boolean
        // goto L_000a
        return;
    }

    static void a(android.view.View p0, android.text.Spannable p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (android.text.Spannable)
        _result = v0.d(v1); // com.android.ex.editstyledtext.EditStyledText.d -> void
        return;
    }

    static void a(com.android.ex.editstyledtext.EditStyledText p0, int p1) {
        // Registers (2 total): v0 = p0 (com.android.ex.editstyledtext.EditStyledText), v1 = p1 (int)
        _result = v0.b(v1); // com.android.ex.editstyledtext.EditStyledText.b -> void
        return;
    }

    static void a(com.android.ex.editstyledtext.EditStyledText p0, int p1, int p2) {
        // Registers (3 total): v0 = p0 (com.android.ex.editstyledtext.EditStyledText), v1 = p1 (int), v2 = p2 (int)
        _result = v0.a(v1, v2); // com.android.ex.editstyledtext.EditStyledText.a -> void
        return;
    }

    static int b(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.EditStyledText)
        _result = v1.y(); // com.android.ex.editstyledtext.EditStyledText.y -> int
        v0 = _result;
        return v0;
    }

    static int b(com.android.ex.editstyledtext.EditStyledText p0, int p1) {
        // Registers (3 total): v1 = p0 (com.android.ex.editstyledtext.EditStyledText), v2 = p1 (int)
        _result = v1.c(v2); // com.android.ex.editstyledtext.EditStyledText.c -> int
        v0 = _result;
        return v0;
    }

    private void b(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        if (v0 == 0) /* goto L_001a */;
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        _result = v0.iterator(); // java.util.ArrayList.iterator -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001a */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.android.ex.editstyledtext.ae) v0;
        _result = com.android.ex.editstyledtext.ae.a(v0, v3); // -> void
        // goto L_000a
        return;
    }

    static void b(android.view.View p0, android.text.Spannable p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (android.text.Spannable)
        _result = v0.c(v1); // com.android.ex.editstyledtext.EditStyledText.c -> void
        return;
    }

    private int c(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        v0 = v4.d; // com.android.ex.editstyledtext.EditStyledText.d:float
        v1 = 0;
        v0 = cmp(v0, v1);
        if (v0 > 0) /* goto L_0017 */;
        _result = v4.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v0 = _result;
        v0 = v0.density; // android.util.DisplayMetrics.density:float
        v4.d = v0; // com.android.ex.editstyledtext.EditStyledText.d:float
        v0 = unaryOp_0x82(v5);
        _result = v4.x(); // com.android.ex.editstyledtext.EditStyledText.x -> float
        v1 = _result;
        v0 = binOp2addr_0xc8(v0, v1);
        v0 = unaryOp_0x89(v0);
        v2 = 0x3fe0000000000000L;
        v0 = binOp2addr_0xcb(v0, v2);
        v0 = unaryOp_0x8a(v0);
        return v0;
    }

    static android.graphics.drawable.Drawable c(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.EditStyledText)
        v0 = v1.f; // com.android.ex.editstyledtext.EditStyledText.f:android.graphics.drawable.Drawable
        return v0;
    }

    private static void c(android.view.View p0, android.text.Spannable p1) {
        // Registers (5 total): v3 = p0 (android.view.View), v4 = p1 (android.text.Spannable)
        v2 = 0;
        v0 = com.android.ex.editstyledtext.EditStyledText.k; // :android.text.NoCopySpan$Concrete
        v1 = 16777233; // 0x01000011
        _result = android.text.Spannable.setSpan(v4, v0, v2, v2, v1); // -> void
        return;
    }

    static com.android.ex.editstyledtext.ak d(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.EditStyledText)
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        return v0;
    }

    private static void d(android.view.View p0, android.text.Spannable p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (android.text.Spannable)
        v0 = com.android.ex.editstyledtext.EditStyledText.k; // :android.text.NoCopySpan$Concrete
        _result = android.text.Spannable.removeSpan(v2, v0); // -> void
        return;
    }

    static void e(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.EditStyledText)
        _result = v0.w(); // com.android.ex.editstyledtext.EditStyledText.w -> void
        return;
    }

    static void f(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.EditStyledText)
        _result = v0.s(); // com.android.ex.editstyledtext.EditStyledText.s -> void
        return;
    }

    static void g(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.EditStyledText)
        _result = v0.t(); // com.android.ex.editstyledtext.EditStyledText.t -> void
        return;
    }

    static void h(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.EditStyledText)
        _result = v0.r(); // com.android.ex.editstyledtext.EditStyledText.r -> void
        return;
    }

    static void i(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.EditStyledText)
        _result = v0.u(); // com.android.ex.editstyledtext.EditStyledText.u -> void
        return;
    }

    private void q() {
        // Registers (4 total): v3 = this
        v0 = new com.android.ex.editstyledtext.an;
        v1 = new com.android.ex.editstyledtext.bc;
        v2 = 0;
        _result = v1.<init>(v3, v2); // com.android.ex.editstyledtext.bc.<init> -> void
        _result = v0.<init>(v3, v3, v1); // com.android.ex.editstyledtext.an.<init> -> void
        v3.i = v0; // com.android.ex.editstyledtext.EditStyledText.i:com.android.ex.editstyledtext.an
        v0 = new com.android.ex.editstyledtext.ap;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.ap.<init> -> void
        v3.j = v0; // com.android.ex.editstyledtext.EditStyledText.j:com.android.ex.editstyledtext.ap
        v0 = new com.android.ex.editstyledtext.ak;
        v1 = v3.j; // com.android.ex.editstyledtext.EditStyledText.j:com.android.ex.editstyledtext.ap
        _result = v0.<init>(v3, v3, v1); // com.android.ex.editstyledtext.ak.<init> -> void
        v3.g = v0; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v0 = new com.android.ex.editstyledtext.am;
        v1 = v3.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.am.<init> -> void
        _result = v3.setMovementMethod(v0); // com.android.ex.editstyledtext.EditStyledText.setMovementMethod -> void
        _result = v3.getBackground(); // com.android.ex.editstyledtext.EditStyledText.getBackground -> android.graphics.drawable.Drawable
        v0 = _result;
        v3.f = v0; // com.android.ex.editstyledtext.EditStyledText.f:android.graphics.drawable.Drawable
        _result = v3.requestFocus(); // com.android.ex.editstyledtext.EditStyledText.requestFocus -> boolean
        return;
    }

    private void r() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        if (v0 == 0) /* goto L_001c */;
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        _result = v0.iterator(); // java.util.ArrayList.iterator -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001c */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.android.ex.editstyledtext.ae) v0;
        _result = com.android.ex.editstyledtext.ae.b(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000a */;
        return;
    }

    private void s() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        if (v0 == 0) /* goto L_001a */;
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        _result = v0.iterator(); // java.util.ArrayList.iterator -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001a */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.android.ex.editstyledtext.ae) v0;
        _result = com.android.ex.editstyledtext.ae.c(v0); // -> void
        // goto L_000a
        return;
    }

    private void t() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        if (v0 == 0) /* goto L_001c */;
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        _result = v0.iterator(); // java.util.ArrayList.iterator -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001c */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.android.ex.editstyledtext.ae) v0;
        _result = com.android.ex.editstyledtext.ae.d(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000a */;
        return;
    }

    private void u() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        if (v0 == 0) /* goto L_001c */;
        v0 = v2.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        _result = v0.iterator(); // java.util.ArrayList.iterator -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001c */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (com.android.ex.editstyledtext.ae) v0;
        _result = com.android.ex.editstyledtext.ae.e(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000a */;
        return;
    }

    private void v() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.e(); // com.android.ex.editstyledtext.ak.e -> void
        return;
    }

    private void w() {
        // Registers (3 total): v2 = this
        v0 = v2.h; // com.android.ex.editstyledtext.EditStyledText.h:android.view.inputmethod.InputConnection
        if (v0 == 0) /* goto L_0017 */;
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.a(); // com.android.ex.editstyledtext.ak.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        v0 = v2.h; // com.android.ex.editstyledtext.EditStyledText.h:android.view.inputmethod.InputConnection
        _result = android.view.inputmethod.InputConnection.finishComposingText(v0); // -> boolean
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 1;
        _result = v0.a(v1); // com.android.ex.editstyledtext.ak.a -> boolean
        return;
    }

    private float x() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // com.android.ex.editstyledtext.EditStyledText.d:float
        v1 = 0;
        v0 = cmp(v0, v1);
        if (v0 > 0) /* goto L_0017 */;
        _result = v2.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v0 = _result;
        v0 = v0.density; // android.util.DisplayMetrics.density:float
        v2.d = v0; // com.android.ex.editstyledtext.EditStyledText.d:float
        v0 = v2.d; // com.android.ex.editstyledtext.EditStyledText.d:float
        return v0;
    }

    private int y() {
        // Registers (2 total): v1 = this
        v0 = 300;
        return v0;
    }

    private int z() {
        // Registers (2 total): v1 = this
        v0 = 300;
        _result = v1.c(v0); // com.android.ex.editstyledtext.EditStyledText.c -> int
        v0 = _result;
        return v0;
    }

    public int a(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v1 = 0xff000000;
        if (v4 < 0) /* goto L_000e */;
        _result = v3.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = android.text.Editable.length(v0); // -> int
        v0 = _result;
        if (v4 <= v0) /* goto L_0010 */;
        v0 = v1;
        return v0;
        _result = v3.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        v2 = android.text.style.ForegroundColorSpan.class;
        _result = android.text.Editable.getSpans(v0, v4, v4, v2); // -> java.lang.Object[]
        v0 = _result;
        v0 = (android.text.style.ForegroundColorSpan[]) v0;
        v2 = v0.length;
        if (v2 <= 0) /* goto L_0027 */;
        v1 = 0;
        v0 = v0[v1];
        _result = v0.getForegroundColor(); // android.text.style.ForegroundColorSpan.getForegroundColor -> int
        v0 = _result;
        // goto L_000f
        v0 = v1;
        // goto L_000f
    }

    public boolean a() {
        // Registers (4 total): v3 = this
        v0 = 0;
        v1 = v3.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        if (v1 == 0) /* goto L_001f */;
        v1 = v3.e; // com.android.ex.editstyledtext.EditStyledText.e:java.util.ArrayList
        _result = v1.iterator(); // java.util.ArrayList.iterator -> java.util.Iterator
        v2 = _result;
        v1 = v0;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0020 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (com.android.ex.editstyledtext.ae) v0;
        _result = com.android.ex.editstyledtext.ae.a(v0); // -> boolean
        v0 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        v1 = v0;
        // goto L_000c
        v1 = v0;
        return v1;
    }

    public void b() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 20;
        _result = v0.a(v1); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    public void c() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 21;
        _result = v0.a(v1); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    public void d() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 1;
        _result = v0.a(v1); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    protected void drawableStateChanged() {
        // Registers (2 total): v1 = this
        _result = v1.drawableStateChanged(); // android.widget.EditText.drawableStateChanged -> void
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        if (v0 == 0) /* goto L_000c */;
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.e(); // com.android.ex.editstyledtext.ak.e -> void
        return;
    }

    public void e() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 7;
        _result = v0.a(v1); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    public void f() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 2;
        _result = v0.a(v1); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    public void g() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 1;
        _result = v0.a(v1); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    public void h() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 1;
        _result = v0.b(v1); // com.android.ex.editstyledtext.ak.b -> void
        return;
    }

    public void i() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.b(); // com.android.ex.editstyledtext.ak.b -> void
        return;
    }

    public void j() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 12;
        _result = v0.a(v1); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    public void k() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.c(); // com.android.ex.editstyledtext.ak.c -> void
        return;
    }

    public boolean l() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.i(); // com.android.ex.editstyledtext.ak.i -> boolean
        v0 = _result;
        return v0;
    }

    public boolean m() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.j(); // com.android.ex.editstyledtext.ak.j -> boolean
        v0 = _result;
        return v0;
    }

    public boolean n() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.k(); // com.android.ex.editstyledtext.ak.k -> boolean
        v0 = _result;
        return v0;
    }

    public int o() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.o(); // com.android.ex.editstyledtext.ak.o -> int
        v0 = _result;
        return v0;
    }

    protected void onCreateContextMenu(android.view.ContextMenu p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.view.ContextMenu)
        v3 = 0;
        _result = v4.onCreateContextMenu(v5); // android.widget.EditText.onCreateContextMenu -> void
        v0 = new com.android.ex.editstyledtext.al;
        v1 = 0;
        _result = v0.<init>(v4, v1); // com.android.ex.editstyledtext.al.<init> -> void
        v1 = com.android.ex.editstyledtext.EditStyledText.a; // :java.lang.CharSequence
        if (v1 == 0) /* goto L_001a */;
        v1 = 16776961; // 0x00ffff01
        v2 = com.android.ex.editstyledtext.EditStyledText.a; // :java.lang.CharSequence
        _result = android.view.ContextMenu.add(v5, v3, v1, v3, v2); // -> android.view.MenuItem
        v1 = _result;
        _result = android.view.MenuItem.setOnMenuItemClickListener(v1, v0); // -> android.view.MenuItem
        _result = v4.m(); // com.android.ex.editstyledtext.EditStyledText.m -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0030 */;
        v1 = com.android.ex.editstyledtext.EditStyledText.b; // :java.lang.CharSequence
        if (v1 == 0) /* goto L_0030 */;
        v1 = 16776962; // 0x00ffff02
        v2 = com.android.ex.editstyledtext.EditStyledText.b; // :java.lang.CharSequence
        _result = android.view.ContextMenu.add(v5, v3, v1, v3, v2); // -> android.view.MenuItem
        v1 = _result;
        _result = android.view.MenuItem.setOnMenuItemClickListener(v1, v0); // -> android.view.MenuItem
        v1 = v4.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v1.t(); // com.android.ex.editstyledtext.ak.t -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_004a */;
        v1 = 16908322; // 0x01020022
        v2 = com.android.ex.editstyledtext.EditStyledText.c; // :java.lang.CharSequence
        _result = android.view.ContextMenu.add(v5, v3, v1, v3, v2); // -> android.view.MenuItem
        v1 = _result;
        _result = android.view.MenuItem.setOnMenuItemClickListener(v1, v0); // -> android.view.MenuItem
        v0 = _result;
        v1 = 118;
        _result = android.view.MenuItem.setAlphabeticShortcut(v0, v1); // -> android.view.MenuItem
        return;
    }

    public android.view.inputmethod.InputConnection onCreateInputConnection(android.view.inputmethod.EditorInfo p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.inputmethod.EditorInfo)
        v0 = new com.android.ex.editstyledtext.bd;
        _result = v2.onCreateInputConnection(v3); // android.widget.EditText.onCreateInputConnection -> android.view.inputmethod.InputConnection
        v1 = _result;
        _result = v0.<init>(v1, v2); // com.android.ex.editstyledtext.bd.<init> -> void
        v2.h = v0; // com.android.ex.editstyledtext.EditStyledText.h:android.view.inputmethod.InputConnection
        v0 = v2.h; // com.android.ex.editstyledtext.EditStyledText.h:android.view.inputmethod.InputConnection
        return v0;
    }

    protected void onFocusChanged(boolean p0, int p1, android.graphics.Rect p2) {
        // Registers (5 total): v1 = this, v2 = p0 (boolean), v3 = p1 (int), v4 = p2 (android.graphics.Rect)
        _result = v1.onFocusChanged(v2, v3, v4); // android.widget.EditText.onFocusChanged -> void
        if (v2 == 0) /* goto L_0009 */;
        _result = v1.b(); // com.android.ex.editstyledtext.EditStyledText.b -> void
        return;
        _result = v1.a(); // com.android.ex.editstyledtext.EditStyledText.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0008 */;
        _result = v1.c(); // com.android.ex.editstyledtext.EditStyledText.c -> void
        // goto L_0008
    }

    public void onRestoreInstanceState(android.os.Parcelable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcelable)
        v0 = (v2 instanceof com.android.ex.editstyledtext.EditStyledText$SavedStyledTextState);
        if (v0 != 0) /* goto L_0008 */;
        _result = v1.onRestoreInstanceState(v2); // android.widget.EditText.onRestoreInstanceState -> void
        return;
        v2 = (com.android.ex.editstyledtext.EditStyledText$SavedStyledTextState) v2;
        _result = v2.getSuperState(); // com.android.ex.editstyledtext.EditStyledText$SavedStyledTextState.getSuperState -> android.os.Parcelable
        v0 = _result;
        _result = v1.onRestoreInstanceState(v0); // android.widget.EditText.onRestoreInstanceState -> void
        v0 = v2.mBackgroundColor; // com.android.ex.editstyledtext.EditStyledText$SavedStyledTextState.mBackgroundColor:int
        _result = v1.setBackgroundColor(v0); // com.android.ex.editstyledtext.EditStyledText.setBackgroundColor -> void
        // goto L_0007
    }

    public android.os.Parcelable onSaveInstanceState() {
        // Registers (3 total): v2 = this
        _result = v2.onSaveInstanceState(); // android.widget.EditText.onSaveInstanceState -> android.os.Parcelable
        v0 = _result;
        v1 = new com.android.ex.editstyledtext.EditStyledText$SavedStyledTextState;
        _result = v1.<init>(v0); // com.android.ex.editstyledtext.EditStyledText$SavedStyledTextState.<init> -> void
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.m(); // com.android.ex.editstyledtext.ak.m -> int
        v0 = _result;
        v1.mBackgroundColor = v0; // com.android.ex.editstyledtext.EditStyledText$SavedStyledTextState.mBackgroundColor:int
        return v1;
    }

    protected void onTextChanged(java.lang.CharSequence p0, int p1, int p2, int p3) {
        // Registers (7 total): v2 = this, v3 = p0 (java.lang.CharSequence), v4 = p1 (int), v5 = p2 (int), v6 = p3 (int)
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        if (v0 == 0) /* goto L_0031 */;
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v2.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = v0.b(v1, v4, v5, v6); // com.android.ex.editstyledtext.ak.b -> void
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v2.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = v0.a(v1, v4, v5, v6); // com.android.ex.editstyledtext.ak.a -> void
        if (v6 <= v5) /* goto L_0035 */;
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = binOp_0x90(v4, v6);
        _result = v0.a(v4, v1); // com.android.ex.editstyledtext.ak.a -> void
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.l(); // com.android.ex.editstyledtext.ak.l -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0031 */;
        if (v6 <= v5) /* goto L_003d */;
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.a(); // com.android.ex.editstyledtext.ak.a -> void
        _result = v2.i(); // com.android.ex.editstyledtext.EditStyledText.i -> void
        _result = v2.onTextChanged(v3, v4, v5, v6); // android.widget.EditText.onTextChanged -> void
        return;
        if (v5 >= v6) /* goto L_001f */;
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.h(); // com.android.ex.editstyledtext.ak.h -> void
        // goto L_001f
        if (v6 >= v5) /* goto L_0031 */;
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 22;
        _result = v0.a(v1); // com.android.ex.editstyledtext.ak.a -> void
        // goto L_0031
    }

    public boolean onTextContextMenuItem(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        v2 = 0;
        v0 = 1;
        _result = v4.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v1 = _result;
        _result = v4.getSelectionEnd(); // com.android.ex.editstyledtext.EditStyledText.getSelectionEnd -> int
        v3 = _result;
        if (v1 == v3) /* goto L_0015 */;
        v1 = v0;
        // switch(v5)
        _result = v4.onTextContextMenuItem(v5); // android.widget.EditText.onTextContextMenuItem -> boolean
        v0 = _result;
        return v0;
        v1 = v2;
        // goto L_000d
        _result = v4.h(); // com.android.ex.editstyledtext.EditStyledText.h -> void
        // goto L_0014
        _result = v4.g(); // com.android.ex.editstyledtext.EditStyledText.g -> void
        v0 = v4.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.w(); // com.android.ex.editstyledtext.ak.w -> void
        // goto L_0010
        _result = v4.i(); // com.android.ex.editstyledtext.EditStyledText.i -> void
        // goto L_0010
        _result = v4.f(); // com.android.ex.editstyledtext.EditStyledText.f -> void
        // goto L_0014
        if (v1 == 0) /* goto L_0032 */;
        _result = v4.d(); // com.android.ex.editstyledtext.EditStyledText.d -> void
        // goto L_0014
        v1 = v4.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v1.b(v2); // com.android.ex.editstyledtext.ak.b -> void
        _result = v4.d(); // com.android.ex.editstyledtext.EditStyledText.d -> void
        // goto L_0014
        if (v1 == 0) /* goto L_0041 */;
        _result = v4.e(); // com.android.ex.editstyledtext.EditStyledText.e -> void
        // goto L_0014
        v1 = v4.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v1.b(v2); // com.android.ex.editstyledtext.ak.b -> void
        _result = v4.e(); // com.android.ex.editstyledtext.EditStyledText.e -> void
        // goto L_0014
        _result = v4.j(); // com.android.ex.editstyledtext.EditStyledText.j -> void
        // goto L_0014
        _result = v4.k(); // com.android.ex.editstyledtext.EditStyledText.k -> void
        // goto L_0014
        _result = v4.b(); // com.android.ex.editstyledtext.EditStyledText.b -> void
        // goto L_0014
        _result = v4.c(); // com.android.ex.editstyledtext.EditStyledText.c -> void
        // goto L_0014
    }

    public boolean onTouchEvent(android.view.MotionEvent p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.view.MotionEvent)
        _result = v6.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        v1 = 1;
        if (v0 != v1) /* goto L_005e */;
        _result = v5.cancelLongPress(); // com.android.ex.editstyledtext.EditStyledText.cancelLongPress -> void
        _result = v5.l(); // com.android.ex.editstyledtext.EditStyledText.l -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        _result = v5.b(); // com.android.ex.editstyledtext.EditStyledText.b -> void
        _result = v5.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = v0.getSelectionStart(); // android.text.Selection.getSelectionStart -> int
        v2 = _result;
        _result = v5.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = v0.getSelectionEnd(); // android.text.Selection.getSelectionEnd -> int
        v3 = _result;
        _result = v5.onTouchEvent(v6); // android.widget.EditText.onTouchEvent -> boolean
        v0 = _result;
        _result = v5.isFocused(); // com.android.ex.editstyledtext.EditStyledText.isFocused -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_004a */;
        _result = v5.o(); // com.android.ex.editstyledtext.EditStyledText.o -> int
        v4 = _result;
        if (v4 != 0) /* goto L_004a */;
        if (v1 == 0) /* goto L_0058 */;
        v1 = v5.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v5.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v2 = _result;
        _result = v2.getSelectionStart(); // android.text.Selection.getSelectionStart -> int
        v2 = _result;
        _result = v5.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v3 = _result;
        _result = v3.getSelectionEnd(); // android.text.Selection.getSelectionEnd -> int
        v3 = _result;
        _result = v1.b(v2, v3); // com.android.ex.editstyledtext.ak.b -> void
        v1 = v5.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v1.a(); // com.android.ex.editstyledtext.ak.a -> void
        v1 = v5.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v1.h(); // com.android.ex.editstyledtext.ak.h -> void
        _result = v5.a(v6); // com.android.ex.editstyledtext.EditStyledText.a -> void
        return v0;
        v1 = v5.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v1.b(v2, v3); // com.android.ex.editstyledtext.ak.b -> void
        // goto L_004a
        _result = v5.onTouchEvent(v6); // android.widget.EditText.onTouchEvent -> boolean
        v0 = _result;
        // goto L_0054
    }

    public int p() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.m(); // com.android.ex.editstyledtext.ak.m -> int
        v0 = _result;
        return v0;
    }

    public void setAlignAlertParams(java.lang.CharSequence p0, java.lang.CharSequence[] p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.CharSequence), v3 = p1 (java.lang.CharSequence[])
        v0 = v1.j; // com.android.ex.editstyledtext.EditStyledText.j:com.android.ex.editstyledtext.ap
        _result = v0.a(v2, v3); // com.android.ex.editstyledtext.ap.a -> void
        return;
    }

    public void setAlignment(android.text.Layout$Alignment p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.text.Layout$Alignment)
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.a(v2); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    public void setBackgroundColor(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 16777215; // 0x00ffffff
        if (v2 == v0) /* goto L_0011 */;
        _result = v1.setBackgroundColor(v2); // android.widget.EditText.setBackgroundColor -> void
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.b(v2); // com.android.ex.editstyledtext.ak.b -> void
        _result = v1.v(); // com.android.ex.editstyledtext.EditStyledText.v -> void
        return;
        v0 = v1.f; // com.android.ex.editstyledtext.EditStyledText.f:android.graphics.drawable.Drawable
        _result = v1.setBackgroundDrawable(v0); // com.android.ex.editstyledtext.EditStyledText.setBackgroundDrawable -> void
        // goto L_0008
    }

    public void setBuilder(android.app.AlertDialog$Builder p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.AlertDialog$Builder)
        v0 = v1.j; // com.android.ex.editstyledtext.EditStyledText.j:com.android.ex.editstyledtext.ap
        _result = v0.a(v2); // com.android.ex.editstyledtext.ap.a -> void
        return;
    }

    public void setColorAlertParams(java.lang.CharSequence p0, java.lang.CharSequence[] p1, java.lang.CharSequence[] p2, java.lang.CharSequence p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.CharSequence), v3 = p1 (java.lang.CharSequence[]), v4 = p2 (java.lang.CharSequence[]), v5 = p3 (java.lang.CharSequence)
        v0 = v1.j; // com.android.ex.editstyledtext.EditStyledText.j:com.android.ex.editstyledtext.ap
        _result = v0.a(v2, v3, v4, v5); // com.android.ex.editstyledtext.ap.a -> void
        return;
    }

    public void setContextMenuStrings(java.lang.CharSequence p0, java.lang.CharSequence p1, java.lang.CharSequence p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.CharSequence), v2 = p1 (java.lang.CharSequence), v3 = p2 (java.lang.CharSequence)
        com.android.ex.editstyledtext.EditStyledText.a = v1; // :java.lang.CharSequence
        com.android.ex.editstyledtext.EditStyledText.b = v2; // :java.lang.CharSequence
        com.android.ex.editstyledtext.EditStyledText.c = v3; // :java.lang.CharSequence
        return;
    }

    public void setHtml(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.i; // com.android.ex.editstyledtext.EditStyledText.i:com.android.ex.editstyledtext.an
        _result = v0.a(v2); // com.android.ex.editstyledtext.an.a -> void
        return;
    }

    public void setItemColor(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 1;
        _result = v0.c(v3, v1); // com.android.ex.editstyledtext.ak.c -> void
        return;
    }

    public void setItemSize(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        v1 = 1;
        _result = v0.b(v3, v1); // com.android.ex.editstyledtext.ak.b -> void
        return;
    }

    public void setMarquee(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.g; // com.android.ex.editstyledtext.EditStyledText.g:com.android.ex.editstyledtext.ak
        _result = v0.c(v2); // com.android.ex.editstyledtext.ak.c -> void
        return;
    }

    public void setMarqueeAlertParams(java.lang.CharSequence p0, java.lang.CharSequence[] p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.CharSequence), v3 = p1 (java.lang.CharSequence[])
        v0 = v1.j; // com.android.ex.editstyledtext.EditStyledText.j:com.android.ex.editstyledtext.ap
        _result = v0.b(v2, v3); // com.android.ex.editstyledtext.ap.b -> void
        return;
    }

    public void setSizeAlertParams(java.lang.CharSequence p0, java.lang.CharSequence[] p1, java.lang.CharSequence[] p2, java.lang.CharSequence[] p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.CharSequence), v3 = p1 (java.lang.CharSequence[]), v4 = p2 (java.lang.CharSequence[]), v5 = p3 (java.lang.CharSequence[])
        v0 = v1.j; // com.android.ex.editstyledtext.EditStyledText.j:com.android.ex.editstyledtext.ap
        _result = v0.a(v2, v3, v4, v5); // com.android.ex.editstyledtext.ap.a -> void
        return;
    }

    public void setStyledTextHtmlConverter(com.android.ex.editstyledtext.bb p0) {
        // Registers (3 total): v1 = this, v2 = p0 (com.android.ex.editstyledtext.bb)
        v0 = v1.i; // com.android.ex.editstyledtext.EditStyledText.i:com.android.ex.editstyledtext.an
        _result = v0.a(v2); // com.android.ex.editstyledtext.an.a -> void
        return;
    }

}