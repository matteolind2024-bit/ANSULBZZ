package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/au;
 */
class au implements android.content.DialogInterface$OnClickListener {
    final com.android.ex.editstyledtext.ap a;

    au(com.android.ex.editstyledtext.ap p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.ap)
        v0.a = v1; // com.android.ex.editstyledtext.au.a:com.android.ex.editstyledtext.ap
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onClick(android.content.DialogInterface p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.DialogInterface), v3 = p1 (int)
        v0 = v1.a; // com.android.ex.editstyledtext.au.a:com.android.ex.editstyledtext.ap
        _result = v0.a(); // com.android.ex.editstyledtext.ap.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        _result = v0.b(); // com.android.ex.editstyledtext.EditStyledText.b -> void
        return;
    }

}