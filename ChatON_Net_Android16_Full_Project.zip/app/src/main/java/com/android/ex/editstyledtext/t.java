package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/t;
 */
public class t extends com.android.ex.editstyledtext.k {
    final com.android.ex.editstyledtext.c a;

    public t(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.c)
        v0.a = v1; // com.android.ex.editstyledtext.t.a:com.android.ex.editstyledtext.c
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.k.<init> -> void
        return;
    }

    protected boolean a() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    protected boolean b() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // com.android.ex.editstyledtext.t.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.e(); // com.android.ex.editstyledtext.ak.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0015 */;
        v0 = "EditModeActions";
        v1 = "Selection is off, but selected";
        _result = v0.e(v1); // android.util.Log.e -> int
        v0 = v2.a; // com.android.ex.editstyledtext.t.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.f(); // com.android.ex.editstyledtext.ak.f -> void
        v0 = v2.a; // com.android.ex.editstyledtext.t.a:com.android.ex.editstyledtext.c
        _result = v0.a(); // com.android.ex.editstyledtext.c.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        v1 = 3;
        _result = v0.a(v1); // com.android.ex.editstyledtext.EditStyledText.a -> void
        v0 = 1;
        return v0;
    }

    protected boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // com.android.ex.editstyledtext.t.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.e(); // com.android.ex.editstyledtext.ak.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0015 */;
        v0 = "EditModeActions";
        v1 = "Selection now start, but selected";
        _result = v0.e(v1); // android.util.Log.e -> int
        v0 = v2.a; // com.android.ex.editstyledtext.t.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.g(); // com.android.ex.editstyledtext.ak.g -> void
        v0 = v2.a; // com.android.ex.editstyledtext.t.a:com.android.ex.editstyledtext.c
        _result = v0.a(); // com.android.ex.editstyledtext.c.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        v1 = 4;
        _result = v0.a(v1); // com.android.ex.editstyledtext.EditStyledText.a -> void
        v0 = v2.a; // com.android.ex.editstyledtext.t.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.n(); // com.android.ex.editstyledtext.ak.n -> int
        v0 = _result;
        v1 = 5;
        if (v0 == v1) /* goto L_0044 */;
        v0 = v2.a; // com.android.ex.editstyledtext.t.a:com.android.ex.editstyledtext.c
        v1 = v2.a; // com.android.ex.editstyledtext.t.a:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        _result = v1.n(); // com.android.ex.editstyledtext.ak.n -> int
        v1 = _result;
        _result = v0.b(v1); // com.android.ex.editstyledtext.c.b -> boolean
        v0 = 1;
        return v0;
    }

}