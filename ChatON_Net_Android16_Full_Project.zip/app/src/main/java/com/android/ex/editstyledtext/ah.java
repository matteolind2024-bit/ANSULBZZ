package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ah;
 */
public class ah extends android.text.style.DynamicDrawableSpan {
     com.android.ex.editstyledtext.ag a;

    public ah(int p0, int p1, android.text.Spannable p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (int), v4 = p2 (android.text.Spannable)
        v0 = 0;
        _result = v1.<init>(v0); // android.text.style.DynamicDrawableSpan.<init> -> void
        v0 = new com.android.ex.editstyledtext.ag;
        _result = v0.<init>(v2, v3, v4); // com.android.ex.editstyledtext.ag.<init> -> void
        v1.a = v0; // com.android.ex.editstyledtext.ah.a:com.android.ex.editstyledtext.ag
        return;
    }

    public void a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // com.android.ex.editstyledtext.ah.a:com.android.ex.editstyledtext.ag
        _result = v0.a(v2); // com.android.ex.editstyledtext.ag.a -> void
        return;
    }

    public android.graphics.drawable.Drawable getDrawable() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // com.android.ex.editstyledtext.ah.a:com.android.ex.editstyledtext.ag
        return v0;
    }

}