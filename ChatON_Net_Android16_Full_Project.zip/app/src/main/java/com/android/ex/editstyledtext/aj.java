package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/aj;
 */
public class aj extends android.text.style.ImageSpan {
     android.net.Uri a;
    public int b;
    public int c;
    private android.graphics.drawable.Drawable d;
    private android.content.Context e;
    private final int f;

    public aj(android.content.Context p0, int p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (int), v4 = p2 (int)
        v0 = -1;
        _result = v1.<init>(v2, v3); // android.text.style.ImageSpan.<init> -> void
        v1.b = v0; // com.android.ex.editstyledtext.aj.b:int
        v1.c = v0; // com.android.ex.editstyledtext.aj.c:int
        v1.e = v2; // com.android.ex.editstyledtext.aj.e:android.content.Context
        v1.f = v4; // com.android.ex.editstyledtext.aj.f:int
        return;
    }

    public aj(android.content.Context p0, android.net.Uri p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.net.Uri), v4 = p2 (int)
        v0 = -1;
        _result = v1.<init>(v2, v3); // android.text.style.ImageSpan.<init> -> void
        v1.b = v0; // com.android.ex.editstyledtext.aj.b:int
        v1.c = v0; // com.android.ex.editstyledtext.aj.c:int
        v1.e = v2; // com.android.ex.editstyledtext.aj.e:android.content.Context
        v1.a = v3; // com.android.ex.editstyledtext.aj.a:android.net.Uri
        v1.f = v4; // com.android.ex.editstyledtext.aj.f:int
        return;
    }

    private void a(android.graphics.drawable.Drawable p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.graphics.drawable.Drawable)
        v5 = 0;
        v0 = "EditStyledTextSpan";
        v1 = "--- rescaleBigImage:";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v6.f; // com.android.ex.editstyledtext.aj.f:int
        if (v0 >= 0) /* goto L_000f */;
        return;
        _result = v7.getIntrinsicWidth(); // android.graphics.drawable.Drawable.getIntrinsicWidth -> int
        v1 = _result;
        _result = v7.getIntrinsicHeight(); // android.graphics.drawable.Drawable.getIntrinsicHeight -> int
        v0 = _result;
        v2 = "EditStyledTextSpan";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "--- rescaleBigImage:";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ",";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ",";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = v6.f; // com.android.ex.editstyledtext.aj.f:int
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v2.d(v3); // android.util.Log.d -> int
        v2 = v6.f; // com.android.ex.editstyledtext.aj.f:int
        if (v1 <= v2) /* goto L_0053 */;
        v1 = v6.f; // com.android.ex.editstyledtext.aj.f:int
        v2 = v6.f; // com.android.ex.editstyledtext.aj.f:int
        v0 = binOp2addr_0xb2(v0, v2);
        v0 = binOp2addr_0xb3(v0, v1);
        _result = v7.setBounds(v5, v5, v1, v0); // android.graphics.drawable.Drawable.setBounds -> void
        // goto L_000e
    }

    public android.net.Uri a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // com.android.ex.editstyledtext.aj.a:android.net.Uri
        return v0;
    }

    public android.graphics.drawable.Drawable getDrawable() {
        // Registers (8 total): v7 = this
        v0 = 0;
        v1 = v7.d; // com.android.ex.editstyledtext.aj.d:android.graphics.drawable.Drawable
        if (v1 == 0) /* goto L_0008 */;
        v0 = v7.d; // com.android.ex.editstyledtext.aj.d:android.graphics.drawable.Drawable
        return v0;
        v1 = v7.a; // com.android.ex.editstyledtext.aj.a:android.net.Uri
        if (v1 == 0) /* goto L_00a2 */;
        _result = this.gc(); // java.lang.System.gc -> void
        v1 = v7.e; // com.android.ex.editstyledtext.aj.e:android.content.Context
        _result = v1.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v1 = _result;
        v2 = v7.a; // com.android.ex.editstyledtext.aj.a:android.net.Uri
        _result = v1.openInputStream(v2); // android.content.ContentResolver.openInputStream -> java.io.InputStream
        v1 = _result;
        v3 = new android.graphics.BitmapFactory$Options;
        _result = v3.<init>(); // android.graphics.BitmapFactory$Options.<init> -> void
        v2 = 1;
        v3.inJustDecodeBounds = v2; // android.graphics.BitmapFactory$Options.inJustDecodeBounds:boolean
        v2 = 0;
        _result = v1.decodeStream(v2, v3); // android.graphics.BitmapFactory.decodeStream -> android.graphics.Bitmap
        _result = v1.close(); // java.io.InputStream.close -> void
        v1 = v7.e; // com.android.ex.editstyledtext.aj.e:android.content.Context
        _result = v1.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v1 = _result;
        v2 = v7.a; // com.android.ex.editstyledtext.aj.a:android.net.Uri
        _result = v1.openInputStream(v2); // android.content.ContentResolver.openInputStream -> java.io.InputStream
        v4 = _result;
        v2 = v3.outWidth; // android.graphics.BitmapFactory$Options.outWidth:int
        v1 = v3.outHeight; // android.graphics.BitmapFactory$Options.outHeight:int
        v7.b = v2; // com.android.ex.editstyledtext.aj.b:int
        v7.c = v1; // com.android.ex.editstyledtext.aj.c:int
        v5 = v3.outWidth; // android.graphics.BitmapFactory$Options.outWidth:int
        v6 = v7.f; // com.android.ex.editstyledtext.aj.f:int
        if (v5 <= v6) /* goto L_0072 */;
        v2 = v7.f; // com.android.ex.editstyledtext.aj.f:int
        v5 = v7.f; // com.android.ex.editstyledtext.aj.f:int
        v1 = binOp2addr_0xb2(v1, v5);
        v3 = v3.outWidth; // android.graphics.BitmapFactory$Options.outWidth:int
        v1 = binOp2addr_0xb3(v1, v3);
        v3 = new android.graphics.Rect;
        v5 = 0;
        v6 = 0;
        _result = v3.<init>(v5, v6, v2, v1); // android.graphics.Rect.<init> -> void
        v5 = 0;
        _result = v4.decodeStream(v3, v5); // android.graphics.BitmapFactory.decodeStream -> android.graphics.Bitmap
        v3 = _result;
        v5 = new android.graphics.drawable.BitmapDrawable;
        v6 = v7.e; // com.android.ex.editstyledtext.aj.e:android.content.Context
        _result = v6.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v6 = _result;
        _result = v5.<init>(v6, v3); // android.graphics.drawable.BitmapDrawable.<init> -> void
        v7.d = v5; // com.android.ex.editstyledtext.aj.d:android.graphics.drawable.Drawable
        v3 = v7.d; // com.android.ex.editstyledtext.aj.d:android.graphics.drawable.Drawable
        v5 = 0;
        v6 = 0;
        _result = v3.setBounds(v5, v6, v2, v1); // android.graphics.drawable.Drawable.setBounds -> void
        _result = v4.close(); // java.io.InputStream.close -> void
        v0 = v7.d; // com.android.ex.editstyledtext.aj.d:android.graphics.drawable.Drawable
        // goto L_0007
        _result = v4.decodeStream(); // android.graphics.BitmapFactory.decodeStream -> android.graphics.Bitmap
        v3 = _result;
        // goto L_0058
        v1 = _exception;
        v2 = "EditStyledTextSpan";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "Failed to loaded content ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = v7.a; // com.android.ex.editstyledtext.aj.a:android.net.Uri
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v2.e(v3, v1); // android.util.Log.e -> int
        // goto L_0007
        v1 = _exception;
        v1 = "EditStyledTextSpan";
        v2 = "OutOfMemoryError";
        _result = v1.e(v2); // android.util.Log.e -> int
        // goto L_0007
        _result = v7.getDrawable(); // android.text.style.ImageSpan.getDrawable -> android.graphics.drawable.Drawable
        v0 = _result;
        v7.d = v0; // com.android.ex.editstyledtext.aj.d:android.graphics.drawable.Drawable
        v0 = v7.d; // com.android.ex.editstyledtext.aj.d:android.graphics.drawable.Drawable
        _result = v7.a(v0); // com.android.ex.editstyledtext.aj.a -> void
        v0 = v7.d; // com.android.ex.editstyledtext.aj.d:android.graphics.drawable.Drawable
        _result = v0.getIntrinsicWidth(); // android.graphics.drawable.Drawable.getIntrinsicWidth -> int
        v0 = _result;
        v7.b = v0; // com.android.ex.editstyledtext.aj.b:int
        v0 = v7.d; // com.android.ex.editstyledtext.aj.d:android.graphics.drawable.Drawable
        _result = v0.getIntrinsicHeight(); // android.graphics.drawable.Drawable.getIntrinsicHeight -> int
        v0 = _result;
        v7.c = v0; // com.android.ex.editstyledtext.aj.c:int
        // goto L_006f
    }

}