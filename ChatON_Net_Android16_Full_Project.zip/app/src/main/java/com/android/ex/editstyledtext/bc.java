package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/bc;
 */
class bc implements com.android.ex.editstyledtext.bb {
    final com.android.ex.editstyledtext.EditStyledText a;

    private bc(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.EditStyledText)
        v0.a = v1; // com.android.ex.editstyledtext.bc.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    bc(com.android.ex.editstyledtext.EditStyledText p0, com.android.ex.editstyledtext.a p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.EditStyledText), v2 = p1 (com.android.ex.editstyledtext.a)
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.bc.<init> -> void
        return;
    }

    public android.text.Spanned a(java.lang.String p0, android.text.Html$ImageGetter p1, android.text.Html$TagHandler p2) {
        // Registers (5 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (android.text.Html$ImageGetter), v4 = p2 (android.text.Html$TagHandler)
        _result = v2.fromHtml(v3, v4); // android.text.Html.fromHtml -> android.text.Spanned
        v0 = _result;
        return v0;
    }

}