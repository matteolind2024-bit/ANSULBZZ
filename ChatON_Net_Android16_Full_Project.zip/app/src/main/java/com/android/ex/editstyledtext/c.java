package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/c;
 */
public class c {
    private com.android.ex.editstyledtext.aa A;
    private com.android.ex.editstyledtext.o B;
    private com.android.ex.editstyledtext.h C;
    private com.android.ex.editstyledtext.x D;
    final com.android.ex.editstyledtext.EditStyledText a;
    private com.android.ex.editstyledtext.EditStyledText b;
    private com.android.ex.editstyledtext.ak c;
    private com.android.ex.editstyledtext.ap d;
    private int e;
    private java.util.HashMap f;
    private com.android.ex.editstyledtext.p g;
    private com.android.ex.editstyledtext.i h;
    private com.android.ex.editstyledtext.q i;
    private com.android.ex.editstyledtext.t j;
    private com.android.ex.editstyledtext.j k;
    private com.android.ex.editstyledtext.u l;
    private com.android.ex.editstyledtext.m m;
    private com.android.ex.editstyledtext.z n;
    private com.android.ex.editstyledtext.g o;
    private com.android.ex.editstyledtext.n p;
    private com.android.ex.editstyledtext.e q;
    private com.android.ex.editstyledtext.r r;
    private com.android.ex.editstyledtext.f s;
    private com.android.ex.editstyledtext.ac t;
    private com.android.ex.editstyledtext.y u;
    private com.android.ex.editstyledtext.l v;
    private com.android.ex.editstyledtext.s w;
    private com.android.ex.editstyledtext.w x;
    private com.android.ex.editstyledtext.d y;
    private com.android.ex.editstyledtext.ab z;

    c(com.android.ex.editstyledtext.EditStyledText p0, com.android.ex.editstyledtext.EditStyledText p1, com.android.ex.editstyledtext.ak p2, com.android.ex.editstyledtext.ap p3) {
        // Registers (8 total): v3 = this, v4 = p0 (com.android.ex.editstyledtext.EditStyledText), v5 = p1 (com.android.ex.editstyledtext.EditStyledText), v6 = p2 (com.android.ex.editstyledtext.ak), v7 = p3 (com.android.ex.editstyledtext.ap)
        v1 = 0;
        v3.a = v4; // com.android.ex.editstyledtext.c.a:com.android.ex.editstyledtext.EditStyledText
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v3.e = v1; // com.android.ex.editstyledtext.c.e:int
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        v3.f = v0; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v0 = new com.android.ex.editstyledtext.p;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.p.<init> -> void
        v3.g = v0; // com.android.ex.editstyledtext.c.g:com.android.ex.editstyledtext.p
        v0 = new com.android.ex.editstyledtext.i;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.i.<init> -> void
        v3.h = v0; // com.android.ex.editstyledtext.c.h:com.android.ex.editstyledtext.i
        v0 = new com.android.ex.editstyledtext.q;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.q.<init> -> void
        v3.i = v0; // com.android.ex.editstyledtext.c.i:com.android.ex.editstyledtext.q
        v0 = new com.android.ex.editstyledtext.t;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.t.<init> -> void
        v3.j = v0; // com.android.ex.editstyledtext.c.j:com.android.ex.editstyledtext.t
        v0 = new com.android.ex.editstyledtext.j;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.j.<init> -> void
        v3.k = v0; // com.android.ex.editstyledtext.c.k:com.android.ex.editstyledtext.j
        v0 = new com.android.ex.editstyledtext.u;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.u.<init> -> void
        v3.l = v0; // com.android.ex.editstyledtext.c.l:com.android.ex.editstyledtext.u
        v0 = new com.android.ex.editstyledtext.m;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.m.<init> -> void
        v3.m = v0; // com.android.ex.editstyledtext.c.m:com.android.ex.editstyledtext.m
        v0 = new com.android.ex.editstyledtext.z;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.z.<init> -> void
        v3.n = v0; // com.android.ex.editstyledtext.c.n:com.android.ex.editstyledtext.z
        v0 = new com.android.ex.editstyledtext.g;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.g.<init> -> void
        v3.o = v0; // com.android.ex.editstyledtext.c.o:com.android.ex.editstyledtext.g
        v0 = new com.android.ex.editstyledtext.n;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.n.<init> -> void
        v3.p = v0; // com.android.ex.editstyledtext.c.p:com.android.ex.editstyledtext.n
        v0 = new com.android.ex.editstyledtext.e;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.e.<init> -> void
        v3.q = v0; // com.android.ex.editstyledtext.c.q:com.android.ex.editstyledtext.e
        v0 = new com.android.ex.editstyledtext.r;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.r.<init> -> void
        v3.r = v0; // com.android.ex.editstyledtext.c.r:com.android.ex.editstyledtext.r
        v0 = new com.android.ex.editstyledtext.f;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.f.<init> -> void
        v3.s = v0; // com.android.ex.editstyledtext.c.s:com.android.ex.editstyledtext.f
        v0 = new com.android.ex.editstyledtext.ac;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.ac.<init> -> void
        v3.t = v0; // com.android.ex.editstyledtext.c.t:com.android.ex.editstyledtext.ac
        v0 = new com.android.ex.editstyledtext.y;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.y.<init> -> void
        v3.u = v0; // com.android.ex.editstyledtext.c.u:com.android.ex.editstyledtext.y
        v0 = new com.android.ex.editstyledtext.l;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.l.<init> -> void
        v3.v = v0; // com.android.ex.editstyledtext.c.v:com.android.ex.editstyledtext.l
        v0 = new com.android.ex.editstyledtext.s;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.s.<init> -> void
        v3.w = v0; // com.android.ex.editstyledtext.c.w:com.android.ex.editstyledtext.s
        v0 = new com.android.ex.editstyledtext.w;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.w.<init> -> void
        v3.x = v0; // com.android.ex.editstyledtext.c.x:com.android.ex.editstyledtext.w
        v0 = new com.android.ex.editstyledtext.d;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.d.<init> -> void
        v3.y = v0; // com.android.ex.editstyledtext.c.y:com.android.ex.editstyledtext.d
        v0 = new com.android.ex.editstyledtext.ab;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.ab.<init> -> void
        v3.z = v0; // com.android.ex.editstyledtext.c.z:com.android.ex.editstyledtext.ab
        v0 = new com.android.ex.editstyledtext.aa;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.aa.<init> -> void
        v3.A = v0; // com.android.ex.editstyledtext.c.A:com.android.ex.editstyledtext.aa
        v0 = new com.android.ex.editstyledtext.o;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.o.<init> -> void
        v3.B = v0; // com.android.ex.editstyledtext.c.B:com.android.ex.editstyledtext.o
        v0 = new com.android.ex.editstyledtext.h;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.h.<init> -> void
        v3.C = v0; // com.android.ex.editstyledtext.c.C:com.android.ex.editstyledtext.h
        v0 = new com.android.ex.editstyledtext.x;
        _result = v0.<init>(v3); // com.android.ex.editstyledtext.x.<init> -> void
        v3.D = v0; // com.android.ex.editstyledtext.c.D:com.android.ex.editstyledtext.x
        v3.b = v5; // com.android.ex.editstyledtext.c.b:com.android.ex.editstyledtext.EditStyledText
        v3.c = v6; // com.android.ex.editstyledtext.c.c:com.android.ex.editstyledtext.ak
        v3.d = v7; // com.android.ex.editstyledtext.c.d:com.android.ex.editstyledtext.ap
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.g; // com.android.ex.editstyledtext.c.g:com.android.ex.editstyledtext.p
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 1;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.h; // com.android.ex.editstyledtext.c.h:com.android.ex.editstyledtext.i
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 2;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.i; // com.android.ex.editstyledtext.c.i:com.android.ex.editstyledtext.q
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 5;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.j; // com.android.ex.editstyledtext.c.j:com.android.ex.editstyledtext.t
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 7;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.k; // com.android.ex.editstyledtext.c.k:com.android.ex.editstyledtext.j
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 11;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.l; // com.android.ex.editstyledtext.c.l:com.android.ex.editstyledtext.u
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 12;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.m; // com.android.ex.editstyledtext.c.m:com.android.ex.editstyledtext.m
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 13;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.n; // com.android.ex.editstyledtext.c.n:com.android.ex.editstyledtext.z
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 14;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.o; // com.android.ex.editstyledtext.c.o:com.android.ex.editstyledtext.g
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 15;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.p; // com.android.ex.editstyledtext.c.p:com.android.ex.editstyledtext.n
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 16;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.q; // com.android.ex.editstyledtext.c.q:com.android.ex.editstyledtext.e
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 17;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.r; // com.android.ex.editstyledtext.c.r:com.android.ex.editstyledtext.r
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 18;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.s; // com.android.ex.editstyledtext.c.s:com.android.ex.editstyledtext.f
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 19;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.t; // com.android.ex.editstyledtext.c.t:com.android.ex.editstyledtext.ac
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 20;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.u; // com.android.ex.editstyledtext.c.u:com.android.ex.editstyledtext.y
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 21;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.v; // com.android.ex.editstyledtext.c.v:com.android.ex.editstyledtext.l
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 22;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.w; // com.android.ex.editstyledtext.c.w:com.android.ex.editstyledtext.s
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 23;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.x; // com.android.ex.editstyledtext.c.x:com.android.ex.editstyledtext.w
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 6;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.y; // com.android.ex.editstyledtext.c.y:com.android.ex.editstyledtext.d
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 8;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.z; // com.android.ex.editstyledtext.c.z:com.android.ex.editstyledtext.ab
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 9;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.A; // com.android.ex.editstyledtext.c.A:com.android.ex.editstyledtext.aa
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 10;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.B; // com.android.ex.editstyledtext.c.B:com.android.ex.editstyledtext.o
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 4;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.C; // com.android.ex.editstyledtext.c.C:com.android.ex.editstyledtext.h
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        v0 = v3.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        v1 = 3;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        v2 = v3.D; // com.android.ex.editstyledtext.c.D:com.android.ex.editstyledtext.x
        _result = v0.put(v1, v2); // java.util.HashMap.put -> java.lang.Object
        return;
    }

    static com.android.ex.editstyledtext.EditStyledText a(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.c)
        v0 = v1.b; // com.android.ex.editstyledtext.c.b:com.android.ex.editstyledtext.EditStyledText
        return v0;
    }

    static com.android.ex.editstyledtext.ak b(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.c)
        v0 = v1.c; // com.android.ex.editstyledtext.c.c:com.android.ex.editstyledtext.ak
        return v0;
    }

    static int c(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.c)
        v0 = v1.e; // com.android.ex.editstyledtext.c.e:int
        return v0;
    }

    private com.android.ex.editstyledtext.k c(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        _result = v3.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v0.containsKey(v1); // java.util.HashMap.containsKey -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0019 */;
        v0 = v2.f; // com.android.ex.editstyledtext.c.f:java.util.HashMap
        _result = v3.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v0.get(v1); // java.util.HashMap.get -> java.lang.Object
        v0 = _result;
        v0 = (com.android.ex.editstyledtext.k) v0;
        return v0;
        v0 = 0;
        // goto L_0018
    }

    static com.android.ex.editstyledtext.ap d(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.c)
        v0 = v1.d; // com.android.ex.editstyledtext.c.d:com.android.ex.editstyledtext.ap
        return v0;
    }

    public void a() {
        // Registers (2 total): v1 = this
        v0 = 5;
        _result = v1.b(v0); // com.android.ex.editstyledtext.c.b -> boolean
        return;
    }

    public void a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        _result = v1.a(v2, v0); // com.android.ex.editstyledtext.c.a -> void
        return;
    }

    public void a(int p0, java.lang.Object[] p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (java.lang.Object[])
        _result = v1.c(v2); // com.android.ex.editstyledtext.c.c -> com.android.ex.editstyledtext.k
        v0 = _result;
        _result = v0.a(v3); // com.android.ex.editstyledtext.k.a -> void
        v1.e = v2; // com.android.ex.editstyledtext.c.e:int
        _result = v1.b(v2); // com.android.ex.editstyledtext.c.b -> boolean
        return;
    }

    public boolean b() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.android.ex.editstyledtext.c.e:int
        _result = v1.b(v0); // com.android.ex.editstyledtext.c.b -> boolean
        v0 = _result;
        return v0;
    }

    public boolean b(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        v0 = 0;
        v1 = "EditModeActions";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "--- do the next action: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ",";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v4.c; // com.android.ex.editstyledtext.c.c:com.android.ex.editstyledtext.ak
        _result = v3.o(); // com.android.ex.editstyledtext.ak.o -> int
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.d(v2); // android.util.Log.d -> int
        _result = v4.c(v5); // com.android.ex.editstyledtext.c.c -> com.android.ex.editstyledtext.k
        v1 = _result;
        if (v1 != 0) /* goto L_003c */;
        v1 = "EditModeActions";
        v2 = "--- invalid action error.";
        _result = v1.e(v2); // android.util.Log.e -> int
        return v0;
        v2 = v4.c; // com.android.ex.editstyledtext.c.c:com.android.ex.editstyledtext.ak
        _result = v2.o(); // com.android.ex.editstyledtext.ak.o -> int
        v2 = _result;
        // switch(v2)
        // goto L_003b
        _result = v1.b(); // com.android.ex.editstyledtext.k.b -> boolean
        v0 = _result;
        // goto L_003b
        _result = v1.e(); // com.android.ex.editstyledtext.k.e -> boolean
        v0 = _result;
        // goto L_003b
        _result = v1.d(); // com.android.ex.editstyledtext.k.d -> boolean
        v0 = _result;
        // goto L_003b
        v0 = v4.c; // com.android.ex.editstyledtext.c.c:com.android.ex.editstyledtext.ak
        _result = v0.l(); // com.android.ex.editstyledtext.ak.l -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0062 */;
        _result = v1.c(); // com.android.ex.editstyledtext.k.c -> boolean
        v0 = _result;
        // goto L_003b
        _result = v1.a(); // com.android.ex.editstyledtext.k.a -> boolean
        v0 = _result;
        // goto L_003b
    }

}