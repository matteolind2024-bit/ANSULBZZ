package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/n;
 */
public class n extends com.android.ex.editstyledtext.k {
    final com.android.ex.editstyledtext.c a;

    public n(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.c)
        v0.a = v1; // com.android.ex.editstyledtext.n.a:com.android.ex.editstyledtext.c
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.k.<init> -> void
        return;
    }

    protected boolean b() {
        // Registers (3 total): v2 = this
        v0 = 0;
        _result = v2.a(v0); // com.android.ex.editstyledtext.n.a -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_002c */;
        v1 = (v0 instanceof android.net.Uri);
        if (v1 == 0) /* goto L_0018 */;
        v1 = v2.a; // com.android.ex.editstyledtext.n.a:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        v0 = (android.net.Uri) v0;
        _result = v1.a(v0); // com.android.ex.editstyledtext.ak.a -> void
        v0 = 1;
        return v0;
        v1 = (v0 instanceof java.lang.Integer);
        if (v1 == 0) /* goto L_0016 */;
        v1 = v2.a; // com.android.ex.editstyledtext.n.a:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        v0 = (java.lang.Integer) v0;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        _result = v1.c(v0); // com.android.ex.editstyledtext.ak.c -> void
        // goto L_0016
        v0 = v2.a; // com.android.ex.editstyledtext.n.a:com.android.ex.editstyledtext.c
        _result = v0.a(); // com.android.ex.editstyledtext.c.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        _result = v0.g(); // com.android.ex.editstyledtext.EditStyledText.g -> void
        // goto L_0016
    }

}