package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/v;
 */
public class v extends com.android.ex.editstyledtext.k {
    final com.android.ex.editstyledtext.c c;

    public v(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.c)
        v0.c = v1; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.k.<init> -> void
        return;
    }

    protected boolean a() {
        // Registers (3 total): v2 = this
        v0 = 0;
        _result = v2.d(); // com.android.ex.editstyledtext.v.d -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v1 = v2.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v1.a(); // com.android.ex.editstyledtext.c.a -> com.android.ex.editstyledtext.EditStyledText
        v1 = _result;
        _result = v1.a(v0); // com.android.ex.editstyledtext.EditStyledText.a -> void
        // goto L_0008
    }

    protected boolean b() {
        // Registers (6 total): v5 = this
        v0 = 1;
        v1 = 0;
        v2 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v2.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v2 = _result;
        _result = v2.n(); // com.android.ex.editstyledtext.ak.n -> int
        v2 = _result;
        if (v2 == 0) /* goto L_001b */;
        v2 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v2.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v2 = _result;
        _result = v2.n(); // com.android.ex.editstyledtext.ak.n -> int
        v2 = _result;
        v3 = 5;
        if (v2 != v3) /* goto L_0050 */;
        v1 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        v2 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v2.c(); // com.android.ex.editstyledtext.c.c -> int
        v2 = _result;
        _result = v1.b(v2); // com.android.ex.editstyledtext.ak.b -> void
        v1 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        v2 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v2.a(); // com.android.ex.editstyledtext.c.a -> com.android.ex.editstyledtext.EditStyledText
        v2 = _result;
        _result = v2.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v2 = _result;
        v3 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v3.a(); // com.android.ex.editstyledtext.c.a -> com.android.ex.editstyledtext.EditStyledText
        v3 = _result;
        _result = v3.getSelectionEnd(); // com.android.ex.editstyledtext.EditStyledText.getSelectionEnd -> int
        v3 = _result;
        _result = v1.a(v2, v3); // com.android.ex.editstyledtext.ak.a -> void
        _result = v5.f(); // com.android.ex.editstyledtext.v.f -> boolean
        v1 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> boolean
        return v0;
        v2 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v2.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v2 = _result;
        _result = v2.n(); // com.android.ex.editstyledtext.ak.n -> int
        v2 = _result;
        v3 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v3.c(); // com.android.ex.editstyledtext.c.c -> int
        v3 = _result;
        if (v2 == v3) /* goto L_00d4 */;
        v2 = "EditModeActions";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "--- setspanactionbase";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v4.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v4 = _result;
        _result = v4.n(); // com.android.ex.editstyledtext.ak.n -> int
        v4 = _result;
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ",";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v4.c(); // com.android.ex.editstyledtext.c.c -> int
        v4 = _result;
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v2.d(v3); // android.util.Log.d -> int
        v2 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v2.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v2 = _result;
        _result = v2.l(); // com.android.ex.editstyledtext.ak.l -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_00c1 */;
        v1 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        _result = v1.b(); // com.android.ex.editstyledtext.ak.b -> void
        v1 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v1 = _result;
        v2 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v2.c(); // com.android.ex.editstyledtext.c.c -> int
        v2 = _result;
        _result = v1.b(v2); // com.android.ex.editstyledtext.ak.b -> void
        v1 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v1.b(); // com.android.ex.editstyledtext.c.b -> boolean
        // goto L_004f
        v2 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v2.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v2 = _result;
        _result = v2.b(v1); // com.android.ex.editstyledtext.ak.b -> void
        v2 = v5.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v2.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v2 = _result;
        _result = v2.a(v1); // com.android.ex.editstyledtext.ak.a -> void
        // goto L_00bb
        v0 = v1;
        // goto L_004f
    }

    protected boolean d() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.n(); // com.android.ex.editstyledtext.ak.n -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0019 */;
        v0 = v2.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.n(); // com.android.ex.editstyledtext.ak.n -> int
        v0 = _result;
        v1 = 5;
        if (v0 != v1) /* goto L_0032 */;
        v0 = v2.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        v1 = v2.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v1.c(); // com.android.ex.editstyledtext.c.c -> int
        v1 = _result;
        _result = v0.b(v1); // com.android.ex.editstyledtext.ak.b -> void
        _result = v2.f(); // com.android.ex.editstyledtext.v.f -> boolean
        v0 = v2.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> boolean
        v0 = 1;
        return v0;
        _result = v2.e(); // com.android.ex.editstyledtext.v.e -> boolean
        v0 = _result;
        // goto L_0031
    }

    protected boolean e() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.n(); // com.android.ex.editstyledtext.ak.n -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0019 */;
        v0 = v2.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.n(); // com.android.ex.editstyledtext.ak.n -> int
        v0 = _result;
        v1 = 5;
        if (v0 != v1) /* goto L_002f */;
        v0 = v2.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        v1 = v2.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v1.c(); // com.android.ex.editstyledtext.c.c -> int
        v1 = _result;
        _result = v0.b(v1); // com.android.ex.editstyledtext.ak.b -> void
        v0 = v2.c; // com.android.ex.editstyledtext.v.c:com.android.ex.editstyledtext.c
        _result = v0.a(); // com.android.ex.editstyledtext.c.a -> void
        v0 = 1;
        return v0;
        _result = v2.b(); // com.android.ex.editstyledtext.v.b -> boolean
        v0 = _result;
        // goto L_002e
    }

}