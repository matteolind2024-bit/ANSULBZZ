package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ae;
 */
public interface ae {
    public abstract void a(int p0);
    public abstract void a(int p0, int p1);
    public abstract boolean a();
    public abstract boolean a(android.view.MotionEvent p0);
    public abstract boolean b();
    public abstract void c();
    public abstract boolean d();
    public abstract boolean e();
}