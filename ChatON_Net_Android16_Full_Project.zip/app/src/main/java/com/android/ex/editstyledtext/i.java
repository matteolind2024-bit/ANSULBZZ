package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/i;
 */
public class i extends com.android.ex.editstyledtext.ad {
    final com.android.ex.editstyledtext.c a;

    public i(com.android.ex.editstyledtext.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.c)
        v0.a = v1; // com.android.ex.editstyledtext.i.a:com.android.ex.editstyledtext.c
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.ad.<init> -> void
        return;
    }

    protected boolean d() {
        // Registers (3 total): v2 = this
        v1 = 1;
        _result = v2.d(); // com.android.ex.editstyledtext.ad.d -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0008 */;
        return v1;
        v0 = v2.a; // com.android.ex.editstyledtext.i.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.c(); // com.android.ex.editstyledtext.ak.c -> void
        v0 = v2.a; // com.android.ex.editstyledtext.i.a:com.android.ex.editstyledtext.c
        _result = v0.b(); // com.android.ex.editstyledtext.c.b -> com.android.ex.editstyledtext.ak
        v0 = _result;
        _result = v0.b(); // com.android.ex.editstyledtext.ak.b -> void
        // goto L_0007
    }

}