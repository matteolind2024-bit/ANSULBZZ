package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ba;
 */
class ba implements android.content.DialogInterface$OnClickListener {
    final com.android.ex.editstyledtext.ap a;

    ba(com.android.ex.editstyledtext.ap p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.ap)
        v0.a = v1; // com.android.ex.editstyledtext.ba.a:com.android.ex.editstyledtext.ap
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onClick(android.content.DialogInterface p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.DialogInterface), v5 = p1 (int)
        v0 = "EditStyledText";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "mBuilder.onclick:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v3.a; // com.android.ex.editstyledtext.ba.a:com.android.ex.editstyledtext.ap
        _result = v0.a(); // com.android.ex.editstyledtext.ap.a -> com.android.ex.editstyledtext.EditStyledText
        v1 = _result;
        v0 = v3.a; // com.android.ex.editstyledtext.ba.a:com.android.ex.editstyledtext.ap
        _result = v0.c(); // com.android.ex.editstyledtext.ap.c -> java.lang.CharSequence[]
        v0 = _result;
        v0 = v0[v5];
        v0 = (java.lang.String) v0;
        _result = v0.parseInt(); // java.lang.Integer.parseInt -> int
        v0 = _result;
        _result = v1.b(v0); // com.android.ex.editstyledtext.EditStyledText.b -> int
        v0 = _result;
        v1 = v3.a; // com.android.ex.editstyledtext.ba.a:com.android.ex.editstyledtext.ap
        _result = v1.a(); // com.android.ex.editstyledtext.ap.a -> com.android.ex.editstyledtext.EditStyledText
        v1 = _result;
        _result = v1.setItemSize(v0); // com.android.ex.editstyledtext.EditStyledText.setItemSize -> void
        return;
    }

}