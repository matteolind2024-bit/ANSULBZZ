package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ax;
 */
class ax implements android.content.DialogInterface$OnClickListener {
    final com.android.ex.editstyledtext.ap a;

    ax(com.android.ex.editstyledtext.ap p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.ap)
        v0.a = v1; // com.android.ex.editstyledtext.ax.a:com.android.ex.editstyledtext.ap
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onClick(android.content.DialogInterface p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.content.DialogInterface), v4 = p1 (int)
        v0 = v2.a; // com.android.ex.editstyledtext.ax.a:com.android.ex.editstyledtext.ap
        _result = v0.a(); // com.android.ex.editstyledtext.ap.a -> com.android.ex.editstyledtext.EditStyledText
        v0 = _result;
        v1 = 16777215; // 0x00ffffff
        _result = v0.setBackgroundColor(v1); // com.android.ex.editstyledtext.EditStyledText.setBackgroundColor -> void
        return;
    }

}