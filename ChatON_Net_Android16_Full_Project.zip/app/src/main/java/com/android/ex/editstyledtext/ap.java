package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ap;
 */
class ap {
    private android.app.AlertDialog$Builder a;
    private android.app.AlertDialog b;
    private java.lang.CharSequence c;
    private java.lang.CharSequence d;
    private java.lang.CharSequence e;
    private java.lang.CharSequence f;
    private java.lang.CharSequence[] g;
    private java.lang.CharSequence[] h;
    private java.lang.CharSequence[] i;
    private java.lang.CharSequence[] j;
    private java.lang.CharSequence[] k;
    private java.lang.CharSequence[] l;
    private java.lang.CharSequence[] m;
    private java.lang.CharSequence n;
    private com.android.ex.editstyledtext.EditStyledText o;

    public ap(com.android.ex.editstyledtext.EditStyledText p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.android.ex.editstyledtext.EditStyledText)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.o = v1; // com.android.ex.editstyledtext.ap.o:com.android.ex.editstyledtext.EditStyledText
        return;
    }

    static android.app.AlertDialog a(com.android.ex.editstyledtext.ap p0, android.app.AlertDialog p1) {
        // Registers (2 total): v0 = p0 (com.android.ex.editstyledtext.ap), v1 = p1 (android.app.AlertDialog)
        v0.b = v1; // com.android.ex.editstyledtext.ap.b:android.app.AlertDialog
        return v1;
    }

    static com.android.ex.editstyledtext.EditStyledText a(com.android.ex.editstyledtext.ap p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.ap)
        v0 = v1.o; // com.android.ex.editstyledtext.ap.o:com.android.ex.editstyledtext.EditStyledText
        return v0;
    }

    private void a(int p0, java.lang.CharSequence p1, int[] p2) {
        // Registers (14 total): v10 = this, v11 = p0 (int), v12 = p1 (java.lang.CharSequence), v13 = p2 (int[])
        v0 = 0;
        v1 = 0;
        v8 = 1;
        v2 = v10.o; // com.android.ex.editstyledtext.ap.o:com.android.ex.editstyledtext.EditStyledText
        v3 = 50;
        _result = v2.b(v3); // com.android.ex.editstyledtext.EditStyledText.b -> int
        v2 = _result;
        v3 = v10.o; // com.android.ex.editstyledtext.ap.o:com.android.ex.editstyledtext.EditStyledText
        v4 = 2;
        _result = v3.b(v4); // com.android.ex.editstyledtext.EditStyledText.b -> int
        v3 = _result;
        v4 = v10.o; // com.android.ex.editstyledtext.ap.o:com.android.ex.editstyledtext.EditStyledText
        v5 = 15;
        _result = v4.b(v5); // com.android.ex.editstyledtext.EditStyledText.b -> int
        v4 = _result;
        v5 = v10.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v5.setTitle(v12); // android.app.AlertDialog$Builder.setTitle -> android.app.AlertDialog$Builder
        v5 = v10.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v5.setIcon(v0); // android.app.AlertDialog$Builder.setIcon -> android.app.AlertDialog$Builder
        v5 = v10.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v5.setPositiveButton(v1, v1); // android.app.AlertDialog$Builder.setPositiveButton -> android.app.AlertDialog$Builder
        v5 = v10.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        v6 = 0x01040000;
        v7 = new com.android.ex.editstyledtext.au;
        _result = v7.<init>(v10); // com.android.ex.editstyledtext.au.<init> -> void
        _result = v5.setNegativeButton(v6, v7); // android.app.AlertDialog$Builder.setNegativeButton -> android.app.AlertDialog$Builder
        v5 = v10.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v5.setItems(v1, v1); // android.app.AlertDialog$Builder.setItems -> android.app.AlertDialog$Builder
        v5 = new android.widget.LinearLayout;
        v6 = v10.o; // com.android.ex.editstyledtext.ap.o:com.android.ex.editstyledtext.EditStyledText
        _result = v6.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v6 = _result;
        _result = v5.<init>(v6); // android.widget.LinearLayout.<init> -> void
        _result = v5.setOrientation(v8); // android.widget.LinearLayout.setOrientation -> void
        _result = v5.setGravity(v8); // android.widget.LinearLayout.setGravity -> void
        _result = v5.setPadding(v4, v4, v4, v4); // android.widget.LinearLayout.setPadding -> void
        v9 = v0;
        v0 = v1;
        v1 = v9;
        v4 = v13.length;
        if (v1 >= v4) /* goto L_00a1 */;
        v4 = binOpLit8_0xdc(v1, 5);
        if (v4 != 0) /* goto L_0066 */;
        v0 = new android.widget.LinearLayout;
        v4 = v10.o; // com.android.ex.editstyledtext.ap.o:com.android.ex.editstyledtext.EditStyledText
        _result = v4.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v4 = _result;
        _result = v0.<init>(v4); // android.widget.LinearLayout.<init> -> void
        _result = v5.addView(v0); // android.widget.LinearLayout.addView -> void
        v4 = new android.widget.Button;
        v6 = v10.o; // com.android.ex.editstyledtext.ap.o:com.android.ex.editstyledtext.EditStyledText
        _result = v6.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v6 = _result;
        _result = v4.<init>(v6); // android.widget.Button.<init> -> void
        _result = v4.setHeight(v2); // android.widget.Button.setHeight -> void
        _result = v4.setWidth(v2); // android.widget.Button.setWidth -> void
        v6 = new com.android.ex.editstyledtext.b;
        v7 = v13[v1];
        _result = v6.<init>(v7, v2, v2, v3); // com.android.ex.editstyledtext.b.<init> -> void
        _result = v4.setBackgroundDrawable(v6); // android.widget.Button.setBackgroundDrawable -> void
        v6 = v13[v1];
        _result = v4.setDrawingCacheBackgroundColor(v6); // android.widget.Button.setDrawingCacheBackgroundColor -> void
        if (v11 != 0) /* goto L_0096 */;
        v6 = new com.android.ex.editstyledtext.av;
        _result = v6.<init>(v10); // com.android.ex.editstyledtext.av.<init> -> void
        _result = v4.setOnClickListener(v6); // android.widget.Button.setOnClickListener -> void
        _result = v0.addView(v4); // android.widget.LinearLayout.addView -> void
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0051
        if (v11 != v8) /* goto L_0090 */;
        v6 = new com.android.ex.editstyledtext.aw;
        _result = v6.<init>(v10); // com.android.ex.editstyledtext.aw.<init> -> void
        _result = v4.setOnClickListener(v6); // android.widget.Button.setOnClickListener -> void
        // goto L_0090
        if (v11 != v8) /* goto L_00cc */;
        v0 = v10.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        v1 = v10.n; // com.android.ex.editstyledtext.ap.n:java.lang.CharSequence
        v2 = new com.android.ex.editstyledtext.ax;
        _result = v2.<init>(v10); // com.android.ex.editstyledtext.ax.<init> -> void
        _result = v0.setPositiveButton(v1, v2); // android.app.AlertDialog$Builder.setPositiveButton -> android.app.AlertDialog$Builder
        v0 = v10.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v0.setView(v5); // android.app.AlertDialog$Builder.setView -> android.app.AlertDialog$Builder
        v0 = v10.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v0.setCancelable(v8); // android.app.AlertDialog$Builder.setCancelable -> android.app.AlertDialog$Builder
        v0 = v10.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        v1 = new com.android.ex.editstyledtext.az;
        _result = v1.<init>(v10); // com.android.ex.editstyledtext.az.<init> -> void
        _result = v0.setOnCancelListener(v1); // android.app.AlertDialog$Builder.setOnCancelListener -> android.app.AlertDialog$Builder
        v0 = v10.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v0.show(); // android.app.AlertDialog$Builder.show -> android.app.AlertDialog
        v0 = _result;
        v10.b = v0; // com.android.ex.editstyledtext.ap.b:android.app.AlertDialog
        return;
        if (v11 != 0) /* goto L_00af */;
        v0 = v10.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        v1 = v10.n; // com.android.ex.editstyledtext.ap.n:java.lang.CharSequence
        v2 = new com.android.ex.editstyledtext.ay;
        _result = v2.<init>(v10); // com.android.ex.editstyledtext.ay.<init> -> void
        _result = v0.setPositiveButton(v1, v2); // android.app.AlertDialog$Builder.setPositiveButton -> android.app.AlertDialog$Builder
        // goto L_00af
    }

    private void a(java.lang.CharSequence p0, java.lang.CharSequence[] p1, android.content.DialogInterface$OnClickListener p2) {
        // Registers (8 total): v4 = this, v5 = p0 (java.lang.CharSequence), v6 = p1 (java.lang.CharSequence[]), v7 = p2 (android.content.DialogInterface$OnClickListener)
        v3 = 0;
        v0 = v4.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v0.setTitle(v5); // android.app.AlertDialog$Builder.setTitle -> android.app.AlertDialog$Builder
        v0 = v4.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        v1 = 0;
        _result = v0.setIcon(v1); // android.app.AlertDialog$Builder.setIcon -> android.app.AlertDialog$Builder
        v0 = v4.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v0.setPositiveButton(v3, v3); // android.app.AlertDialog$Builder.setPositiveButton -> android.app.AlertDialog$Builder
        v0 = v4.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        v1 = 0x01040000;
        v2 = new com.android.ex.editstyledtext.aq;
        _result = v2.<init>(v4); // com.android.ex.editstyledtext.aq.<init> -> void
        _result = v0.setNegativeButton(v1, v2); // android.app.AlertDialog$Builder.setNegativeButton -> android.app.AlertDialog$Builder
        v0 = v4.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v0.setItems(v6, v7); // android.app.AlertDialog$Builder.setItems -> android.app.AlertDialog$Builder
        v0 = v4.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v0.setView(v3); // android.app.AlertDialog$Builder.setView -> android.app.AlertDialog$Builder
        v0 = v4.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        v1 = 1;
        _result = v0.setCancelable(v1); // android.app.AlertDialog$Builder.setCancelable -> android.app.AlertDialog$Builder
        v0 = v4.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        v1 = new com.android.ex.editstyledtext.at;
        _result = v1.<init>(v4); // com.android.ex.editstyledtext.at.<init> -> void
        _result = v0.setOnCancelListener(v1); // android.app.AlertDialog$Builder.setOnCancelListener -> android.app.AlertDialog$Builder
        v0 = v4.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        _result = v0.show(); // android.app.AlertDialog$Builder.show -> android.app.AlertDialog
        return;
    }

    private boolean a() {
        // Registers (4 total): v3 = this
        v0 = 0;
        v1 = "EditStyledText";
        v2 = "--- checkParams";
        _result = v1.d(v2); // android.util.Log.d -> int
        v1 = v3.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        if (v1 != 0) /* goto L_0018 */;
        v1 = "EditStyledText";
        v2 = "--- builder is null.";
        _result = v1.e(v2); // android.util.Log.e -> int
        return v0;
        v1 = v3.c; // com.android.ex.editstyledtext.ap.c:java.lang.CharSequence
        if (v1 == 0) /* goto L_0024 */;
        v1 = v3.g; // com.android.ex.editstyledtext.ap.g:java.lang.CharSequence[]
        if (v1 == 0) /* goto L_0024 */;
        v1 = v3.h; // com.android.ex.editstyledtext.ap.h:java.lang.CharSequence[]
        if (v1 != 0) /* goto L_002e */;
        v1 = "EditStyledText";
        v2 = "--- color alert params are null.";
        _result = v1.e(v2); // android.util.Log.e -> int
        // goto L_0017
        v1 = v3.g; // com.android.ex.editstyledtext.ap.g:java.lang.CharSequence[]
        v1 = v1.length;
        v2 = v3.h; // com.android.ex.editstyledtext.ap.h:java.lang.CharSequence[]
        v2 = v2.length;
        if (v1 == v2) /* goto L_0040 */;
        v1 = "EditStyledText";
        v2 = "--- the length of color alert params are different.";
        _result = v1.e(v2); // android.util.Log.e -> int
        // goto L_0017
        v0 = 1;
        // goto L_0017
    }

    static android.app.AlertDialog b(com.android.ex.editstyledtext.ap p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.ap)
        v0 = v1.b; // com.android.ex.editstyledtext.ap.b:android.app.AlertDialog
        return v0;
    }

    private boolean b() {
        // Registers (4 total): v3 = this
        v0 = 0;
        v1 = "EditStyledText";
        v2 = "--- checkParams";
        _result = v1.d(v2); // android.util.Log.d -> int
        v1 = v3.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        if (v1 != 0) /* goto L_0018 */;
        v1 = "EditStyledText";
        v2 = "--- builder is null.";
        _result = v1.e(v2); // android.util.Log.e -> int
        return v0;
        v1 = v3.d; // com.android.ex.editstyledtext.ap.d:java.lang.CharSequence
        if (v1 == 0) /* goto L_0028 */;
        v1 = v3.i; // com.android.ex.editstyledtext.ap.i:java.lang.CharSequence[]
        if (v1 == 0) /* goto L_0028 */;
        v1 = v3.j; // com.android.ex.editstyledtext.ap.j:java.lang.CharSequence[]
        if (v1 == 0) /* goto L_0028 */;
        v1 = v3.k; // com.android.ex.editstyledtext.ap.k:java.lang.CharSequence[]
        if (v1 != 0) /* goto L_0032 */;
        v1 = "EditStyledText";
        v2 = "--- size alert params are null.";
        _result = v1.e(v2); // android.util.Log.e -> int
        // goto L_0017
        v1 = v3.i; // com.android.ex.editstyledtext.ap.i:java.lang.CharSequence[]
        v1 = v1.length;
        v2 = v3.j; // com.android.ex.editstyledtext.ap.j:java.lang.CharSequence[]
        v2 = v2.length;
        if (v1 == v2) /* goto L_004c */;
        v1 = v3.k; // com.android.ex.editstyledtext.ap.k:java.lang.CharSequence[]
        v1 = v1.length;
        v2 = v3.j; // com.android.ex.editstyledtext.ap.j:java.lang.CharSequence[]
        v2 = v2.length;
        if (v1 == v2) /* goto L_004c */;
        v1 = "EditStyledText";
        v2 = "--- the length of size alert params are different.";
        _result = v1.e(v2); // android.util.Log.e -> int
        // goto L_0017
        v0 = 1;
        // goto L_0017
    }

    private boolean c() {
        // Registers (4 total): v3 = this
        v0 = 0;
        v1 = "EditStyledText";
        v2 = "--- checkAlignAlertParams";
        _result = v1.d(v2); // android.util.Log.d -> int
        v1 = v3.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        if (v1 != 0) /* goto L_0018 */;
        v1 = "EditStyledText";
        v2 = "--- builder is null.";
        _result = v1.e(v2); // android.util.Log.e -> int
        return v0;
        v1 = v3.e; // com.android.ex.editstyledtext.ap.e:java.lang.CharSequence
        if (v1 != 0) /* goto L_0026 */;
        v1 = "EditStyledText";
        v2 = "--- align alert params are null.";
        _result = v1.e(v2); // android.util.Log.e -> int
        // goto L_0017
        v0 = 1;
        // goto L_0017
    }

    static java.lang.CharSequence[] c(com.android.ex.editstyledtext.ap p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.ap)
        v0 = v1.j; // com.android.ex.editstyledtext.ap.j:java.lang.CharSequence[]
        return v0;
    }

    static void d(com.android.ex.editstyledtext.ap p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ap)
        _result = v0.f(); // com.android.ex.editstyledtext.ap.f -> void
        return;
    }

    private boolean d() {
        // Registers (4 total): v3 = this
        v0 = 0;
        v1 = "EditStyledText";
        v2 = "--- checkMarqueeAlertParams";
        _result = v1.d(v2); // android.util.Log.d -> int
        v1 = v3.a; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        if (v1 != 0) /* goto L_0018 */;
        v1 = "EditStyledText";
        v2 = "--- builder is null.";
        _result = v1.e(v2); // android.util.Log.e -> int
        return v0;
        v1 = v3.f; // com.android.ex.editstyledtext.ap.f:java.lang.CharSequence
        if (v1 != 0) /* goto L_0026 */;
        v1 = "EditStyledText";
        v2 = "--- Marquee alert params are null.";
        _result = v1.e(v2); // android.util.Log.e -> int
        // goto L_0017
        v0 = 1;
        // goto L_0017
    }

    private void e() {
        // Registers (6 total): v5 = this
        v2 = 0;
        v0 = "EditStyledText";
        v1 = "--- onShowForegroundColorAlertDialog";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v5.a(); // com.android.ex.editstyledtext.ap.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0011 */;
        return;
        v0 = v5.h; // com.android.ex.editstyledtext.ap.h:java.lang.CharSequence[]
        v0 = v0.length;
        v3 = new int[][size=v0];
        v1 = v2;
        v0 = v3.length;
        if (v1 >= v0) /* goto L_002f */;
        v0 = v5.h; // com.android.ex.editstyledtext.ap.h:java.lang.CharSequence[]
        v0 = v0[v1];
        v0 = (java.lang.String) v0;
        v4 = 16;
        _result = v0.parseInt(v4); // java.lang.Integer.parseInt -> int
        v0 = _result;
        v4 = 0x01000000;
        v0 = binOp2addr_0xb1(v0, v4);
        v3[v1] = v0;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0017
        v0 = v5.c; // com.android.ex.editstyledtext.ap.c:java.lang.CharSequence
        _result = v5.a(v2, v0, v3); // com.android.ex.editstyledtext.ap.a -> void
        // goto L_0010
    }

    static void e(com.android.ex.editstyledtext.ap p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ap)
        _result = v0.h(); // com.android.ex.editstyledtext.ap.h -> void
        return;
    }

    private void f() {
        // Registers (5 total): v4 = this
        v0 = "EditStyledText";
        v1 = "--- onShowBackgroundColorAlertDialog";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v4.a(); // com.android.ex.editstyledtext.ap.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0010 */;
        return;
        v0 = v4.h; // com.android.ex.editstyledtext.ap.h:java.lang.CharSequence[]
        v0 = v0.length;
        v2 = new int[][size=v0];
        v0 = 0;
        v1 = v0;
        v0 = v2.length;
        if (v1 >= v0) /* goto L_002f */;
        v0 = v4.h; // com.android.ex.editstyledtext.ap.h:java.lang.CharSequence[]
        v0 = v0[v1];
        v0 = (java.lang.String) v0;
        v3 = 16;
        _result = v0.parseInt(v3); // java.lang.Integer.parseInt -> int
        v0 = _result;
        v3 = 0x01000000;
        v0 = binOp2addr_0xb1(v0, v3);
        v2[v1] = v0;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0017
        v0 = 1;
        v1 = v4.c; // com.android.ex.editstyledtext.ap.c:java.lang.CharSequence
        _result = v4.a(v0, v1, v2); // com.android.ex.editstyledtext.ap.a -> void
        // goto L_000f
    }

    static void f(com.android.ex.editstyledtext.ap p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ap)
        _result = v0.i(); // com.android.ex.editstyledtext.ap.i -> void
        return;
    }

    private void g() {
        // Registers (4 total): v3 = this
        v0 = "EditStyledText";
        v1 = "--- onShowSizeAlertDialog";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v3.b(); // com.android.ex.editstyledtext.ap.b -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0010 */;
        return;
        v0 = v3.d; // com.android.ex.editstyledtext.ap.d:java.lang.CharSequence
        v1 = v3.i; // com.android.ex.editstyledtext.ap.i:java.lang.CharSequence[]
        v2 = new com.android.ex.editstyledtext.ba;
        _result = v2.<init>(v3); // com.android.ex.editstyledtext.ba.<init> -> void
        _result = v3.a(v0, v1, v2); // com.android.ex.editstyledtext.ap.a -> void
        // goto L_000f
    }

    static void g(com.android.ex.editstyledtext.ap p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ap)
        _result = v0.e(); // com.android.ex.editstyledtext.ap.e -> void
        return;
    }

    private void h() {
        // Registers (4 total): v3 = this
        v0 = "EditStyledText";
        v1 = "--- onShowAlignAlertDialog";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v3.c(); // com.android.ex.editstyledtext.ap.c -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0010 */;
        return;
        v0 = v3.e; // com.android.ex.editstyledtext.ap.e:java.lang.CharSequence
        v1 = v3.l; // com.android.ex.editstyledtext.ap.l:java.lang.CharSequence[]
        v2 = new com.android.ex.editstyledtext.ar;
        _result = v2.<init>(v3); // com.android.ex.editstyledtext.ar.<init> -> void
        _result = v3.a(v0, v1, v2); // com.android.ex.editstyledtext.ap.a -> void
        // goto L_000f
    }

    static void h(com.android.ex.editstyledtext.ap p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ap)
        _result = v0.g(); // com.android.ex.editstyledtext.ap.g -> void
        return;
    }

    private void i() {
        // Registers (4 total): v3 = this
        v0 = "EditStyledText";
        v1 = "--- onShowMarqueeAlertDialog";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v3.d(); // com.android.ex.editstyledtext.ap.d -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0010 */;
        return;
        v0 = v3.f; // com.android.ex.editstyledtext.ap.f:java.lang.CharSequence
        v1 = v3.m; // com.android.ex.editstyledtext.ap.m:java.lang.CharSequence[]
        v2 = new com.android.ex.editstyledtext.as;
        _result = v2.<init>(v3); // com.android.ex.editstyledtext.as.<init> -> void
        _result = v3.a(v0, v1, v2); // com.android.ex.editstyledtext.ap.a -> void
        // goto L_000f
    }

    public void a(android.app.AlertDialog$Builder p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.app.AlertDialog$Builder)
        v0.a = v1; // com.android.ex.editstyledtext.ap.a:android.app.AlertDialog$Builder
        return;
    }

    public void a(java.lang.CharSequence p0, java.lang.CharSequence[] p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.CharSequence), v2 = p1 (java.lang.CharSequence[])
        v0.e = v1; // com.android.ex.editstyledtext.ap.e:java.lang.CharSequence
        v0.l = v2; // com.android.ex.editstyledtext.ap.l:java.lang.CharSequence[]
        return;
    }

    public void a(java.lang.CharSequence p0, java.lang.CharSequence[] p1, java.lang.CharSequence[] p2, java.lang.CharSequence p3) {
        // Registers (5 total): v0 = this, v1 = p0 (java.lang.CharSequence), v2 = p1 (java.lang.CharSequence[]), v3 = p2 (java.lang.CharSequence[]), v4 = p3 (java.lang.CharSequence)
        v0.c = v1; // com.android.ex.editstyledtext.ap.c:java.lang.CharSequence
        v0.g = v2; // com.android.ex.editstyledtext.ap.g:java.lang.CharSequence[]
        v0.h = v3; // com.android.ex.editstyledtext.ap.h:java.lang.CharSequence[]
        v0.n = v4; // com.android.ex.editstyledtext.ap.n:java.lang.CharSequence
        return;
    }

    public void a(java.lang.CharSequence p0, java.lang.CharSequence[] p1, java.lang.CharSequence[] p2, java.lang.CharSequence[] p3) {
        // Registers (5 total): v0 = this, v1 = p0 (java.lang.CharSequence), v2 = p1 (java.lang.CharSequence[]), v3 = p2 (java.lang.CharSequence[]), v4 = p3 (java.lang.CharSequence[])
        v0.d = v1; // com.android.ex.editstyledtext.ap.d:java.lang.CharSequence
        v0.i = v2; // com.android.ex.editstyledtext.ap.i:java.lang.CharSequence[]
        v0.j = v3; // com.android.ex.editstyledtext.ap.j:java.lang.CharSequence[]
        v0.k = v4; // com.android.ex.editstyledtext.ap.k:java.lang.CharSequence[]
        return;
    }

    public void b(java.lang.CharSequence p0, java.lang.CharSequence[] p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.CharSequence), v2 = p1 (java.lang.CharSequence[])
        v0.f = v1; // com.android.ex.editstyledtext.ap.f:java.lang.CharSequence
        v0.m = v2; // com.android.ex.editstyledtext.ap.m:java.lang.CharSequence[]
        return;
    }

}