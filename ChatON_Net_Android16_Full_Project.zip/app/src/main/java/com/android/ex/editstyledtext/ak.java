package com.android.ex.editstyledtext;

/**
 * Original SourceFile: EditStyledText.java
 * Descriptor: Lcom/android/ex/editstyledtext/ak;
 */
class ak {
    final com.android.ex.editstyledtext.EditStyledText a;
    private boolean b;
    private boolean c;
    private boolean d;
    private boolean e;
    private boolean f;
    private int g;
    private int h;
    private int i;
    private int j;
    private int k;
    private int l;
    private int m;
    private android.text.style.BackgroundColorSpan n;
    private com.android.ex.editstyledtext.EditStyledText o;
    private com.android.ex.editstyledtext.c p;
    private com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver q;
    private android.text.SpannableStringBuilder r;

    ak(com.android.ex.editstyledtext.EditStyledText p0, com.android.ex.editstyledtext.EditStyledText p1, com.android.ex.editstyledtext.ap p2) {
        // Registers (6 total): v2 = this, v3 = p0 (com.android.ex.editstyledtext.EditStyledText), v4 = p1 (com.android.ex.editstyledtext.EditStyledText), v5 = p2 (com.android.ex.editstyledtext.ap)
        v1 = 16777215; // 0x00ffffff
        v0 = 0;
        v2.a = v3; // com.android.ex.editstyledtext.ak.a:com.android.ex.editstyledtext.EditStyledText
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.b = v0; // com.android.ex.editstyledtext.ak.b:boolean
        v2.c = v0; // com.android.ex.editstyledtext.ak.c:boolean
        v2.d = v0; // com.android.ex.editstyledtext.ak.d:boolean
        v2.e = v0; // com.android.ex.editstyledtext.ak.e:boolean
        v2.f = v0; // com.android.ex.editstyledtext.ak.f:boolean
        v2.g = v0; // com.android.ex.editstyledtext.ak.g:int
        v2.h = v0; // com.android.ex.editstyledtext.ak.h:int
        v2.i = v0; // com.android.ex.editstyledtext.ak.i:int
        v2.j = v0; // com.android.ex.editstyledtext.ak.j:int
        v2.k = v1; // com.android.ex.editstyledtext.ak.k:int
        v2.l = v0; // com.android.ex.editstyledtext.ak.l:int
        v2.m = v1; // com.android.ex.editstyledtext.ak.m:int
        v2.o = v4; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v0 = new com.android.ex.editstyledtext.c;
        v1 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.<init>(v3, v1, v2, v5); // com.android.ex.editstyledtext.c.<init> -> void
        v2.p = v0; // com.android.ex.editstyledtext.ak.p:com.android.ex.editstyledtext.c
        v0 = new com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver;
        v1 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.<init>(v1); // com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver.<init> -> void
        v2.q = v0; // com.android.ex.editstyledtext.ak.q:com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver
        return;
    }

    private void A() {
        // Registers (3 total): v2 = this
        v0 = "EditStyledText.EditorManager";
        v1 = "--- onClearStyles";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = v2.a(v0); // com.android.ex.editstyledtext.ak.a -> void
        v0 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.c(); // com.android.ex.editstyledtext.EditStyledText.c -> android.graphics.drawable.Drawable
        v1 = _result;
        _result = v0.setBackgroundDrawable(v1); // com.android.ex.editstyledtext.EditStyledText.setBackgroundDrawable -> void
        v0 = 16777215; // 0x00ffffff
        v2.m = v0; // com.android.ex.editstyledtext.ak.m:int
        _result = v2.d(); // com.android.ex.editstyledtext.ak.d -> void
        return;
    }

    private void B() {
        // Registers (4 total): v3 = this
        v2 = 0;
        v0 = "EditStyledText.EditorManager";
        v1 = "--- handleCancel";
        _result = v0.d(v1); // android.util.Log.d -> int
        v3.g = v2; // com.android.ex.editstyledtext.ak.g:int
        v3.h = v2; // com.android.ex.editstyledtext.ak.h:int
        v3.b = v2; // com.android.ex.editstyledtext.ak.b:boolean
        v0 = 16777215; // 0x00ffffff
        v3.k = v0; // com.android.ex.editstyledtext.ak.k:int
        v3.l = v2; // com.android.ex.editstyledtext.ak.l:int
        v3.e = v2; // com.android.ex.editstyledtext.ak.e:boolean
        v3.c = v2; // com.android.ex.editstyledtext.ak.c:boolean
        v3.d = v2; // com.android.ex.editstyledtext.ak.d:boolean
        v3.f = v2; // com.android.ex.editstyledtext.ak.f:boolean
        _result = v3.K(); // com.android.ex.editstyledtext.ak.K -> void
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = 0;
        _result = v0.setOnClickListener(v1); // com.android.ex.editstyledtext.EditStyledText.setOnClickListener -> void
        _result = v3.x(); // com.android.ex.editstyledtext.ak.x -> void
        return;
    }

    private void C() {
        // Registers (4 total): v3 = this
        v0 = "EditStyledText.EditorManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "--- handleComplete:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.i; // com.android.ex.editstyledtext.ak.i:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.j; // com.android.ex.editstyledtext.ak.j:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v3.b; // com.android.ex.editstyledtext.ak.b:boolean
        if (v0 != 0) /* goto L_002e */;
        return;
        v0 = v3.i; // com.android.ex.editstyledtext.ak.i:int
        v1 = v3.j; // com.android.ex.editstyledtext.ak.j:int
        if (v0 != v1) /* goto L_0054 */;
        v0 = "EditStyledText.EditorManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "--- cancel handle complete:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.i; // com.android.ex.editstyledtext.ak.i:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v3.I(); // com.android.ex.editstyledtext.ak.I -> void
        // goto L_002d
        v0 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 2;
        if (v0 != v1) /* goto L_005c */;
        v0 = 3;
        v3.h = v0; // com.android.ex.editstyledtext.ak.h:int
        v0 = v3.p; // com.android.ex.editstyledtext.ak.p:com.android.ex.editstyledtext.c
        v1 = v3.g; // com.android.ex.editstyledtext.ak.g:int
        _result = v0.b(v1); // com.android.ex.editstyledtext.c.b -> boolean
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = v0.a(v1); // com.android.ex.editstyledtext.EditStyledText.a -> void
        // goto L_002d
    }

    private void D() {
        // Registers (4 total): v3 = this
        _result = v3.p(); // com.android.ex.editstyledtext.ak.p -> int
        v0 = _result;
        _result = v3.q(); // com.android.ex.editstyledtext.ak.q -> int
        v1 = _result;
        _result = v0.min(v1); // java.lang.Math.min -> int
        v0 = _result;
        _result = v3.p(); // com.android.ex.editstyledtext.ak.p -> int
        v1 = _result;
        _result = v3.q(); // com.android.ex.editstyledtext.ak.q -> int
        v2 = _result;
        _result = v1.max(v2); // java.lang.Math.max -> int
        v1 = _result;
        v2 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v2.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v2 = _result;
        _result = android.text.Editable.subSequence(v2, v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        v0 = (android.text.SpannableStringBuilder) v0;
        v3.r = v0; // com.android.ex.editstyledtext.ak.r:android.text.SpannableStringBuilder
        v0 = v3.r; // com.android.ex.editstyledtext.ak.r:android.text.SpannableStringBuilder
        _result = v3.a(v0); // com.android.ex.editstyledtext.ak.a -> android.text.SpannableStringBuilder
        v1 = _result;
        v0 = v3.a; // com.android.ex.editstyledtext.ak.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v0 = _result;
        v2 = "clipboard";
        _result = v0.getSystemService(v2); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.text.ClipboardManager) v0;
        _result = v0.setText(v1); // android.text.ClipboardManager.setText -> void
        _result = v3.c(v1); // com.android.ex.editstyledtext.ak.c -> void
        v0 = v3.r; // com.android.ex.editstyledtext.ak.r:android.text.SpannableStringBuilder
        _result = v3.c(v0); // com.android.ex.editstyledtext.ak.c -> void
        return;
    }

    private void E() {
        // Registers (4 total): v3 = this
        _result = v3.D(); // com.android.ex.editstyledtext.ak.D -> void
        _result = v3.p(); // com.android.ex.editstyledtext.ak.p -> int
        v0 = _result;
        _result = v3.q(); // com.android.ex.editstyledtext.ak.q -> int
        v1 = _result;
        _result = v0.min(v1); // java.lang.Math.min -> int
        v0 = _result;
        _result = v3.p(); // com.android.ex.editstyledtext.ak.p -> int
        v1 = _result;
        _result = v3.q(); // com.android.ex.editstyledtext.ak.q -> int
        v2 = _result;
        _result = v1.max(v2); // java.lang.Math.max -> int
        v1 = _result;
        v2 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v2.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v2 = _result;
        _result = android.text.Editable.delete(v2, v0, v1); // -> android.text.Editable
        return;
    }

    private void F() {
        // Registers (10 total): v9 = this
        v1 = 0;
        v0 = v9.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v0 = _result;
        v2 = v9.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v2.getSelectionEnd(); // com.android.ex.editstyledtext.EditStyledText.getSelectionEnd -> int
        v2 = _result;
        _result = v0.min(v2); // java.lang.Math.min -> int
        v3 = _result;
        v0 = v9.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v0 = _result;
        v2 = v9.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v2.getSelectionEnd(); // com.android.ex.editstyledtext.EditStyledText.getSelectionEnd -> int
        v2 = _result;
        _result = v0.max(v2); // java.lang.Math.max -> int
        v2 = _result;
        v0 = v9.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = v0.setSelection(v2); // android.text.Selection.setSelection -> void
        v0 = v9.a; // com.android.ex.editstyledtext.ak.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v0 = _result;
        v4 = "clipboard";
        _result = v0.getSystemService(v4); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.text.ClipboardManager) v0;
        v4 = 1;
        v9.d = v4; // com.android.ex.editstyledtext.ak.d:boolean
        v4 = v9.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v4.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v4 = _result;
        _result = v0.getText(); // android.text.ClipboardManager.getText -> java.lang.CharSequence
        v5 = _result;
        _result = android.text.Editable.replace(v4, v3, v2, v5); // -> android.text.Editable
        _result = v0.getText(); // android.text.ClipboardManager.getText -> java.lang.CharSequence
        v0 = _result;
        _result = v9.b(v0); // com.android.ex.editstyledtext.ak.b -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_00b8 */;
        v0 = "EditStyledText";
        v2 = "--- handlePaste: startPasteImage";
        _result = v0.d(v2); // android.util.Log.d -> int
        v0 = v9.r; // com.android.ex.editstyledtext.ak.r:android.text.SpannableStringBuilder
        v2 = v9.r; // com.android.ex.editstyledtext.ak.r:android.text.SpannableStringBuilder
        _result = v2.length(); // android.text.SpannableStringBuilder.length -> int
        v2 = _result;
        v4 = android.text.style.DynamicDrawableSpan.class;
        _result = v0.getSpans(v1, v2, v4); // android.text.SpannableStringBuilder.getSpans -> java.lang.Object[]
        v0 = _result;
        v0 = (android.text.style.DynamicDrawableSpan[]) v0;
        v4 = v0.length;
        v2 = v1;
        if (v2 >= v4) /* goto L_00b8 */;
        v1 = v0[v2];
        v5 = v9.r; // com.android.ex.editstyledtext.ak.r:android.text.SpannableStringBuilder
        _result = v5.getSpanStart(v1); // android.text.SpannableStringBuilder.getSpanStart -> int
        v5 = _result;
        v6 = (v1 instanceof com.android.ex.editstyledtext.ah);
        if (v6 == 0) /* goto L_0097 */;
        v1 = new com.android.ex.editstyledtext.ah;
        v6 = 0xff000000;
        v7 = v9.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v7.getWidth(); // com.android.ex.editstyledtext.EditStyledText.getWidth -> int
        v7 = _result;
        v8 = v9.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v8.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v8 = _result;
        _result = v1.<init>(v6, v7, v8); // com.android.ex.editstyledtext.ah.<init> -> void
        v5 = binOp2addr_0xb0(v5, v3);
        _result = v9.a(v1, v5); // com.android.ex.editstyledtext.ak.a -> void
        v1 = binOpLit8_0xd8(v2, 1);
        v2 = v1;
        // goto L_006e
        v6 = (v1 instanceof com.android.ex.editstyledtext.aj);
        if (v6 == 0) /* goto L_0093 */;
        v6 = new com.android.ex.editstyledtext.aj;
        v7 = v9.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v7.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v7 = _result;
        v1 = (com.android.ex.editstyledtext.aj) v1;
        _result = v1.a(); // com.android.ex.editstyledtext.aj.a -> android.net.Uri
        v1 = _result;
        v8 = v9.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v8.a(); // com.android.ex.editstyledtext.EditStyledText.a -> int
        v8 = _result;
        _result = v6.<init>(v7, v1, v8); // com.android.ex.editstyledtext.aj.<init> -> void
        v1 = binOp_0x90(v3, v5);
        _result = v9.a(v6, v1); // com.android.ex.editstyledtext.ak.a -> void
        // goto L_0093
        return;
    }

    private void G() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // com.android.ex.editstyledtext.ak.b:boolean
        if (v0 != 0) /* goto L_0005 */;
        return;
        v0 = v2.p; // com.android.ex.editstyledtext.ak.p:com.android.ex.editstyledtext.c
        v1 = 11;
        _result = v0.a(v1); // com.android.ex.editstyledtext.c.a -> void
        // goto L_0004
    }

    private void H() {
        // Registers (2 total): v1 = this
        v0 = v1.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = v0.selectAll(); // android.text.Selection.selectAll -> void
        v0 = v1.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v0 = _result;
        v1.i = v0; // com.android.ex.editstyledtext.ak.i:int
        v0 = v1.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getSelectionEnd(); // com.android.ex.editstyledtext.EditStyledText.getSelectionEnd -> int
        v0 = _result;
        v1.j = v0; // com.android.ex.editstyledtext.ak.j:int
        v0 = 5;
        v1.g = v0; // com.android.ex.editstyledtext.ak.g:int
        v0 = 3;
        v1.h = v0; // com.android.ex.editstyledtext.ak.h:int
        return;
    }

    private void I() {
        // Registers (4 total): v3 = this
        _result = v3.B(); // com.android.ex.editstyledtext.ak.B -> void
        v0 = 1;
        v3.b = v0; // com.android.ex.editstyledtext.ak.b:boolean
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v3.g; // com.android.ex.editstyledtext.ak.g:int
        v2 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        _result = v0.a(v1, v2); // com.android.ex.editstyledtext.EditStyledText.a -> void
        return;
    }

    private void J() {
        // Registers (5 total): v4 = this
        v3 = 2;
        v0 = "EditStyledText.EditorManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "--- onSelect:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.i; // com.android.ex.editstyledtext.ak.i:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.j; // com.android.ex.editstyledtext.ak.j:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v4.i; // com.android.ex.editstyledtext.ak.i:int
        if (v0 < 0) /* goto L_0076 */;
        v0 = v4.i; // com.android.ex.editstyledtext.ak.i:int
        v1 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = android.text.Editable.length(v1); // -> int
        v1 = _result;
        if (v0 > v1) /* goto L_0076 */;
        v0 = v4.j; // com.android.ex.editstyledtext.ak.j:int
        if (v0 < 0) /* goto L_0076 */;
        v0 = v4.j; // com.android.ex.editstyledtext.ak.j:int
        v1 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = android.text.Editable.length(v1); // -> int
        v1 = _result;
        if (v0 > v1) /* goto L_0076 */;
        v0 = v4.i; // com.android.ex.editstyledtext.ak.i:int
        v1 = v4.j; // com.android.ex.editstyledtext.ak.j:int
        if (v0 >= v1) /* goto L_0060 */;
        v0 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v4.i; // com.android.ex.editstyledtext.ak.i:int
        v2 = v4.j; // com.android.ex.editstyledtext.ak.j:int
        _result = v0.setSelection(v1, v2); // com.android.ex.editstyledtext.EditStyledText.setSelection -> void
        v4.h = v3; // com.android.ex.editstyledtext.ak.h:int
        return;
        v0 = v4.i; // com.android.ex.editstyledtext.ak.i:int
        v1 = v4.j; // com.android.ex.editstyledtext.ak.j:int
        if (v0 <= v1) /* goto L_0072 */;
        v0 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v4.j; // com.android.ex.editstyledtext.ak.j:int
        v2 = v4.i; // com.android.ex.editstyledtext.ak.i:int
        _result = v0.setSelection(v1, v2); // com.android.ex.editstyledtext.EditStyledText.setSelection -> void
        v4.h = v3; // com.android.ex.editstyledtext.ak.h:int
        // goto L_005f
        v0 = 1;
        v4.h = v0; // com.android.ex.editstyledtext.ak.h:int
        // goto L_005f
        v0 = "EditStyledText.EditorManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Select is on, but cursor positions are illigal.:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v2.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v2 = _result;
        _result = android.text.Editable.length(v2); // -> int
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.i; // com.android.ex.editstyledtext.ak.i:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.j; // com.android.ex.editstyledtext.ak.j:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // android.util.Log.e -> int
        // goto L_005f
    }

    private void K() {
        // Registers (3 total): v2 = this
        v0 = "EditStyledText.EditorManager";
        v1 = "--- offSelect";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = v0.a(v1); // com.android.ex.editstyledtext.EditStyledText.a -> void
        v0 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v0 = _result;
        v1 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.setSelection(v0, v0); // com.android.ex.editstyledtext.EditStyledText.setSelection -> void
        v0 = 0;
        v2.h = v0; // com.android.ex.editstyledtext.ak.h:int
        return;
    }

    private void L() {
        // Registers (3 total): v2 = this
        v0 = "EditStyledText.EditorManager";
        v1 = "--- setSelectStartPos";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v0 = _result;
        v2.i = v0; // com.android.ex.editstyledtext.ak.i:int
        v0 = 1;
        v2.h = v0; // com.android.ex.editstyledtext.ak.h:int
        return;
    }

    private void M() {
        // Registers (3 total): v2 = this
        v0 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getSelectionEnd(); // com.android.ex.editstyledtext.EditStyledText.getSelectionEnd -> int
        v0 = _result;
        v1 = v2.i; // com.android.ex.editstyledtext.ak.i:int
        if (v0 != v1) /* goto L_0014 */;
        v0 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v0 = _result;
        _result = v2.d(v0); // com.android.ex.editstyledtext.ak.d -> void
        return;
        v0 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getSelectionEnd(); // com.android.ex.editstyledtext.EditStyledText.getSelectionEnd -> int
        v0 = _result;
        _result = v2.d(v0); // com.android.ex.editstyledtext.ak.d -> void
        // goto L_0013
    }

    private boolean N() {
        // Registers (4 total): v3 = this
        v0 = "EditStyledText.EditorManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "--- waitingNext:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.i; // com.android.ex.editstyledtext.ak.i:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.j; // com.android.ex.editstyledtext.ak.j:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v3.i; // com.android.ex.editstyledtext.ak.i:int
        v1 = v3.j; // com.android.ex.editstyledtext.ak.j:int
        if (v0 != v1) /* goto L_0046 */;
        v0 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 3;
        if (v0 != v1) /* goto L_0046 */;
        _result = v3.O(); // com.android.ex.editstyledtext.ak.O -> void
        v0 = 1;
        return v0;
        _result = v3.P(); // com.android.ex.editstyledtext.ak.P -> void
        v0 = 0;
        // goto L_0045
    }

    private void O() {
        // Registers (4 total): v3 = this
        v2 = 1;
        v0 = "EditStyledText.EditorManager";
        v1 = "--- waitSelection";
        _result = v0.d(v1); // android.util.Log.d -> int
        v3.e = v2; // com.android.ex.editstyledtext.ak.e:boolean
        v0 = v3.i; // com.android.ex.editstyledtext.ak.i:int
        v1 = v3.j; // com.android.ex.editstyledtext.ak.j:int
        if (v0 != v1) /* goto L_0020 */;
        v3.h = v2; // com.android.ex.editstyledtext.ak.h:int
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = v0.b(v1); // com.android.ex.editstyledtext.EditStyledText.b -> void
        return;
        v0 = 2;
        v3.h = v0; // com.android.ex.editstyledtext.ak.h:int
        // goto L_0014
    }

    private void P() {
        // Registers (3 total): v2 = this
        v0 = "EditStyledText.EditorManager";
        v1 = "--- resumeSelection";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = 0;
        v2.e = v0; // com.android.ex.editstyledtext.ak.e:boolean
        v0 = 3;
        v2.h = v0; // com.android.ex.editstyledtext.ak.h:int
        v0 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = v0.a(v1); // com.android.ex.editstyledtext.EditStyledText.a -> void
        return;
    }

    private boolean Q() {
        // Registers (3 total): v2 = this
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 2;
        if (v0 == v1) /* goto L_000a */;
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 3;
        if (v0 != v1) /* goto L_000c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000b
    }

    private void R() {
        // Registers (2 total): v1 = this
        v0 = 1;
        _result = v1.j(v0); // com.android.ex.editstyledtext.ak.j -> void
        return;
    }

    private void S() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.j(v0); // com.android.ex.editstyledtext.ak.j -> void
        return;
    }

    private int a(android.text.Editable p0, int p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.text.Editable), v6 = p1 (int)
        v0 = v6;
        if (v0 <= 0) /* goto L_000d */;
        v1 = binOpLit8_0xd8(v0, -1);
        _result = android.text.Editable.charAt(v5, v1); // -> char
        v1 = _result;
        v2 = 10;
        if (v1 != v2) /* goto L_0042 */;
        v1 = "EditStyledText.EditorManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "--- findLineStart:";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ",";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = android.text.Editable.length(v5); // -> int
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ",";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.d(v2); // android.util.Log.d -> int
        return v0;
        v0 = binOpLit8_0xd8(v0, -1);
        // goto L_0001
    }

    private android.text.SpannableStringBuilder a(android.text.SpannableStringBuilder p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.text.SpannableStringBuilder)
        v1 = 0;
        v2 = new android.text.SpannableStringBuilder;
        _result = v2.<init>(v8); // android.text.SpannableStringBuilder.<init> -> void
        _result = v2.length(); // android.text.SpannableStringBuilder.length -> int
        v0 = _result;
        v3 = android.text.style.DynamicDrawableSpan.class;
        _result = v2.getSpans(v1, v0, v3); // android.text.SpannableStringBuilder.getSpans -> java.lang.Object[]
        v0 = _result;
        v0 = (android.text.style.DynamicDrawableSpan[]) v0;
        v3 = v0.length;
        if (v1 >= v3) /* goto L_0030 */;
        v4 = v0[v1];
        v5 = (v4 instanceof com.android.ex.editstyledtext.ah);
        if (v5 != 0) /* goto L_001f */;
        v5 = (v4 instanceof com.android.ex.editstyledtext.aj);
        if (v5 == 0) /* goto L_002d */;
        _result = v2.getSpanStart(v4); // android.text.SpannableStringBuilder.getSpanStart -> int
        v5 = _result;
        _result = v2.getSpanEnd(v4); // android.text.SpannableStringBuilder.getSpanEnd -> int
        v4 = _result;
        v6 = "";
        _result = v2.replace(v5, v4, v6); // android.text.SpannableStringBuilder.replace -> android.text.SpannableStringBuilder
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0013
        return v2;
    }

    private void a(android.net.Uri p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.net.Uri)
        v0 = new com.android.ex.editstyledtext.aj;
        v1 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v1 = _result;
        v2 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v2.a(); // com.android.ex.editstyledtext.EditStyledText.a -> int
        v2 = _result;
        _result = v0.<init>(v1, v4, v2); // com.android.ex.editstyledtext.aj.<init> -> void
        v1 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v1 = _result;
        _result = v3.a(v0, v1); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    private void a(android.text.style.DynamicDrawableSpan p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.text.style.DynamicDrawableSpan), v5 = p1 (int)
        v0 = "EditStyledText.EditorManager";
        v1 = "--- insertImageSpan:";
        _result = v0.d(v1); // android.util.Log.d -> int
        if (v4 == 0) /* goto L_0034 */;
        _result = v4.getDrawable(); // android.text.style.DynamicDrawableSpan.getDrawable -> android.graphics.drawable.Drawable
        v0 = _result;
        if (v0 == 0) /* goto L_0034 */;
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        v1 = "￼";
        _result = android.text.Editable.insert(v0, v5, v1); // -> android.text.Editable
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        v1 = binOpLit8_0xd8(v5, 1);
        v2 = 33;
        _result = android.text.Editable.setSpan(v0, v4, v5, v1, v2); // -> void
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v3.g; // com.android.ex.editstyledtext.ak.g:int
        v2 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        _result = v0.a(v1, v2); // com.android.ex.editstyledtext.EditStyledText.a -> void
        return;
        v0 = "EditStyledText.EditorManager";
        v1 = "--- insertImageSpan: null span was inserted";
        _result = v0.e(v1); // android.util.Log.e -> int
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = 5;
        _result = v0.a(v1); // com.android.ex.editstyledtext.EditStyledText.a -> void
        // goto L_0033
    }

    static void a(com.android.ex.editstyledtext.ak p0, int p1) {
        // Registers (2 total): v0 = p0 (com.android.ex.editstyledtext.ak), v1 = p1 (int)
        _result = v0.g(v1); // com.android.ex.editstyledtext.ak.g -> void
        return;
    }

    static void a(com.android.ex.editstyledtext.ak p0, int p1, int p2) {
        // Registers (3 total): v0 = p0 (com.android.ex.editstyledtext.ak), v1 = p1 (int), v2 = p2 (int)
        _result = v0.c(v1, v2); // com.android.ex.editstyledtext.ak.c -> void
        return;
    }

    static void a(com.android.ex.editstyledtext.ak p0, android.net.Uri p1) {
        // Registers (2 total): v0 = p0 (com.android.ex.editstyledtext.ak), v1 = p1 (android.net.Uri)
        _result = v0.a(v1); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    private void a(java.lang.CharSequence p0) {
        // Registers (9 total): v7 = this, v8 = p0 (java.lang.CharSequence)
        v0 = 0;
        v1 = "EditStyledText";
        v2 = "--- onClearStyles";
        _result = v1.d(v2); // android.util.Log.d -> int
        _result = java.lang.CharSequence.length(v8); // -> int
        v1 = _result;
        v2 = (v8 instanceof android.text.Editable);
        if (v2 == 0) /* goto L_004b */;
        v8 = (android.text.Editable) v8;
        v2 = java.lang.Object.class;
        _result = android.text.Editable.getSpans(v8, v0, v1, v2); // -> java.lang.Object[]
        v1 = _result;
        v2 = v1.length;
        if (v0 >= v2) /* goto L_004b */;
        v3 = v1[v0];
        v4 = (v3 instanceof android.text.style.ParagraphStyle);
        if (v4 != 0) /* goto L_002f */;
        v4 = (v3 instanceof android.text.style.QuoteSpan);
        if (v4 != 0) /* goto L_002f */;
        v4 = (v3 instanceof android.text.style.CharacterStyle);
        if (v4 == 0) /* goto L_0048 */;
        v4 = (v3 instanceof android.text.style.UnderlineSpan);
        if (v4 != 0) /* goto L_0048 */;
        v4 = (v3 instanceof android.text.style.ImageSpan);
        if (v4 != 0) /* goto L_0037 */;
        v4 = (v3 instanceof com.android.ex.editstyledtext.ah);
        if (v4 == 0) /* goto L_0045 */;
        _result = android.text.Editable.getSpanStart(v8, v3); // -> int
        v4 = _result;
        _result = android.text.Editable.getSpanEnd(v8, v3); // -> int
        v5 = _result;
        v6 = "";
        _result = android.text.Editable.replace(v8, v4, v5, v6); // -> android.text.Editable
        _result = android.text.Editable.removeSpan(v8, v3); // -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_001b
        return;
    }

    private void a(java.lang.Object p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.Object)
        v0 = v5.i; // com.android.ex.editstyledtext.ak.i:int
        v1 = v5.j; // com.android.ex.editstyledtext.ak.j:int
        _result = v0.min(v1); // java.lang.Math.min -> int
        v0 = _result;
        v1 = v5.i; // com.android.ex.editstyledtext.ak.i:int
        v2 = v5.j; // com.android.ex.editstyledtext.ak.j:int
        _result = v1.max(v2); // java.lang.Math.max -> int
        v1 = _result;
        v2 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v2.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v2 = _result;
        v3 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v3.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v3 = _result;
        _result = v5.a(v3, v0); // com.android.ex.editstyledtext.ak.a -> int
        v0 = _result;
        v3 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v3.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v3 = _result;
        _result = v5.b(v3, v1); // com.android.ex.editstyledtext.ak.b -> int
        v1 = _result;
        if (v0 != v1) /* goto L_0047 */;
        v3 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v3.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v3 = _result;
        v4 = "\n";
        _result = android.text.Editable.insert(v3, v1, v4); // -> android.text.Editable
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v5.a(v6, v0, v1); // com.android.ex.editstyledtext.ak.a -> void
        v0 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = v0.setSelection(v2); // android.text.Selection.setSelection -> void
        return;
        _result = v5.a(v6, v0, v1); // com.android.ex.editstyledtext.ak.a -> void
        // goto L_003d
    }

    private void a(java.lang.Object p0, int p1, int p2) {
        // Registers (8 total): v4 = this, v5 = p0 (java.lang.Object), v6 = p1 (int), v7 = p2 (int)
        v0 = "EditStyledText.EditorManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "--- setStyledTextSpan:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.g; // com.android.ex.editstyledtext.ak.g:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v6.min(v7); // java.lang.Math.min -> int
        v0 = _result;
        _result = v6.max(v7); // java.lang.Math.max -> int
        v1 = _result;
        v2 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v2.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v2 = _result;
        v3 = 33;
        _result = android.text.Editable.setSpan(v2, v5, v0, v1, v3); // -> void
        v0 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = v0.setSelection(v1); // android.text.Selection.setSelection -> void
        return;
    }

    static boolean a(com.android.ex.editstyledtext.ak p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.ak)
        v0 = v1.f; // com.android.ex.editstyledtext.ak.f:boolean
        return v0;
    }

    static boolean a(com.android.ex.editstyledtext.ak p0, boolean p1) {
        // Registers (2 total): v0 = p0 (com.android.ex.editstyledtext.ak), v1 = p1 (boolean)
        v0.f = v1; // com.android.ex.editstyledtext.ak.f:boolean
        return v1;
    }

    private int b(android.text.Editable p0, int p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.text.Editable), v6 = p1 (int)
        v0 = v6;
        _result = android.text.Editable.length(v5); // -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_0011 */;
        _result = android.text.Editable.charAt(v5, v0); // -> char
        v1 = _result;
        v2 = 10;
        if (v1 != v2) /* goto L_0046 */;
        v0 = binOpLit8_0xd8(v0, 1);
        v1 = "EditStyledText.EditorManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "--- findLineEnd:";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ",";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = android.text.Editable.length(v5); // -> int
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ",";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.d(v2); // android.util.Log.d -> int
        return v0;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0001
    }

    private void b(android.text.Layout$Alignment p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.text.Layout$Alignment)
        v0 = new android.text.style.AlignmentSpan$Standard;
        _result = v0.<init>(v2); // android.text.style.AlignmentSpan$Standard.<init> -> void
        _result = v1.a(v0); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    static void b(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.I(); // com.android.ex.editstyledtext.ak.I -> void
        return;
    }

    static void b(com.android.ex.editstyledtext.ak p0, int p1) {
        // Registers (2 total): v0 = p0 (com.android.ex.editstyledtext.ak), v1 = p1 (int)
        _result = v0.f(v1); // com.android.ex.editstyledtext.ak.f -> void
        return;
    }

    private boolean b(java.lang.CharSequence p0) {
        // Registers (9 total): v7 = this, v8 = p0 (java.lang.CharSequence)
        v1 = 0;
        v0 = 1;
        v2 = "EditStyledText";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "--- isClipBoardChanged:";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v2.d(v3); // android.util.Log.d -> int
        v2 = v7.r; // com.android.ex.editstyledtext.ak.r:android.text.SpannableStringBuilder
        if (v2 != 0) /* goto L_0021 */;
        return v0;
        _result = java.lang.CharSequence.length(v8); // -> int
        v3 = _result;
        v2 = v7.r; // com.android.ex.editstyledtext.ak.r:android.text.SpannableStringBuilder
        _result = v7.a(v2); // com.android.ex.editstyledtext.ak.a -> android.text.SpannableStringBuilder
        v4 = _result;
        v2 = "EditStyledText";
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "--- clipBoard:";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = ",";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v5 = _result;
        _result = v2.d(v5); // android.util.Log.d -> int
        _result = java.lang.CharSequence.length(v4); // -> int
        v2 = _result;
        if (v3 != v2) /* goto L_0020 */;
        v2 = v1;
        if (v2 >= v3) /* goto L_006a */;
        _result = java.lang.CharSequence.charAt(v8, v2); // -> char
        v5 = _result;
        _result = java.lang.CharSequence.charAt(v4, v2); // -> char
        v6 = _result;
        if (v5 != v6) /* goto L_0020 */;
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_005b
        v0 = v1;
        // goto L_0020
    }

    private void c(int p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (int), v2 = p1 (int)
        v0.i = v1; // com.android.ex.editstyledtext.ak.i:int
        v0.j = v2; // com.android.ex.editstyledtext.ak.j:int
        return;
    }

    static void c(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.D(); // com.android.ex.editstyledtext.ak.D -> void
        return;
    }

    static void c(com.android.ex.editstyledtext.ak p0, int p1) {
        // Registers (2 total): v0 = p0 (com.android.ex.editstyledtext.ak), v1 = p1 (int)
        _result = v0.e(v1); // com.android.ex.editstyledtext.ak.e -> void
        return;
    }

    private void c(java.lang.CharSequence p0) {
        // Registers (9 total): v7 = this, v8 = p0 (java.lang.CharSequence)
        v0 = 0;
        v1 = (v8 instanceof android.text.Spannable);
        if (v1 == 0) /* goto L_0085 */;
        v8 = (android.text.Spannable) v8;
        _result = android.text.Spannable.length(v8); // -> int
        v1 = _result;
        v2 = "EditStyledText";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "--- dumpSpannableString, txt:";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ", len:";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v2.d(v3); // android.util.Log.d -> int
        v2 = java.lang.Object.class;
        _result = android.text.Spannable.getSpans(v8, v0, v1, v2); // -> java.lang.Object[]
        v1 = _result;
        v2 = v1.length;
        if (v0 >= v2) /* goto L_0085 */;
        v3 = v1[v0];
        v4 = "EditStyledText";
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "--- dumpSpannableString, class:";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = ",";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = android.text.Spannable.getSpanStart(v8, v3); // -> int
        v6 = _result;
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = ",";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = android.text.Spannable.getSpanEnd(v8, v3); // -> int
        v6 = _result;
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = ",";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = android.text.Spannable.getSpanFlags(v8, v3); // -> int
        v3 = _result;
        _result = v5.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v4.d(v3); // android.util.Log.d -> int
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0037
        return;
    }

    static void d(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.E(); // com.android.ex.editstyledtext.ak.E -> void
        return;
    }

    private void e(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = new com.android.ex.editstyledtext.aj;
        v1 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v1 = _result;
        v2 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v2.b(); // com.android.ex.editstyledtext.EditStyledText.b -> int
        v2 = _result;
        _result = v0.<init>(v1, v4, v2); // com.android.ex.editstyledtext.aj.<init> -> void
        v1 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v1 = _result;
        _result = v3.a(v0, v1); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    static boolean e(com.android.ex.editstyledtext.ak p0) {
        // Registers (2 total): v1 = p0 (com.android.ex.editstyledtext.ak)
        _result = v1.Q(); // com.android.ex.editstyledtext.ak.Q -> boolean
        v0 = _result;
        return v0;
    }

    private void f(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.g = v1; // com.android.ex.editstyledtext.ak.g:int
        return;
    }

    static void f(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.L(); // com.android.ex.editstyledtext.ak.L -> void
        return;
    }

    private void g(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.h = v1; // com.android.ex.editstyledtext.ak.h:int
        return;
    }

    static void g(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.M(); // com.android.ex.editstyledtext.ak.M -> void
        return;
    }

    private void h(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.i; // com.android.ex.editstyledtext.ak.i:int
        v1 = v3.j; // com.android.ex.editstyledtext.ak.j:int
        if (v0 == v1) /* goto L_0013 */;
        v0 = new android.text.style.AbsoluteSizeSpan;
        _result = v0.<init>(v4); // android.text.style.AbsoluteSizeSpan.<init> -> void
        v1 = v3.i; // com.android.ex.editstyledtext.ak.i:int
        v2 = v3.j; // com.android.ex.editstyledtext.ak.j:int
        _result = v3.a(v0, v1, v2); // com.android.ex.editstyledtext.ak.a -> void
        return;
        v0 = "EditStyledText.EditorManager";
        v1 = "---changeSize: Size of the span is zero";
        _result = v0.e(v1); // android.util.Log.e -> int
        // goto L_0012
    }

    static void h(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.F(); // com.android.ex.editstyledtext.ak.F -> void
        return;
    }

    private void i(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.i; // com.android.ex.editstyledtext.ak.i:int
        v1 = v3.j; // com.android.ex.editstyledtext.ak.j:int
        if (v0 == v1) /* goto L_0013 */;
        v0 = new android.text.style.ForegroundColorSpan;
        _result = v0.<init>(v4); // android.text.style.ForegroundColorSpan.<init> -> void
        v1 = v3.i; // com.android.ex.editstyledtext.ak.i:int
        v2 = v3.j; // com.android.ex.editstyledtext.ak.j:int
        _result = v3.a(v0, v1, v2); // com.android.ex.editstyledtext.ak.a -> void
        return;
        v0 = "EditStyledText.EditorManager";
        v1 = "---changeColor: Size of the span is zero";
        _result = v0.e(v1); // android.util.Log.e -> int
        // goto L_0012
    }

    static void i(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.H(); // com.android.ex.editstyledtext.ak.H -> void
        return;
    }

    private void j(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = "EditStyledText.EditorManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "--- addMarquee:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = new com.android.ex.editstyledtext.ai;
        v1 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.p(); // com.android.ex.editstyledtext.EditStyledText.p -> int
        v1 = _result;
        _result = v0.<init>(v4, v1); // com.android.ex.editstyledtext.ai.<init> -> void
        _result = v3.a(v0); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    static void j(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.z(); // com.android.ex.editstyledtext.ak.z -> void
        return;
    }

    static void k(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.A(); // com.android.ex.editstyledtext.ak.A -> void
        return;
    }

    static void l(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.C(); // com.android.ex.editstyledtext.ak.C -> void
        return;
    }

    static void m(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.y(); // com.android.ex.editstyledtext.ak.y -> void
        return;
    }

    static void n(com.android.ex.editstyledtext.ak p0) {
        // Registers (1 total): v0 = p0 (com.android.ex.editstyledtext.ak)
        _result = v0.B(); // com.android.ex.editstyledtext.ak.B -> void
        return;
    }

    private void y() {
        // Registers (1 total): v0 = this
        _result = v0.I(); // com.android.ex.editstyledtext.ak.I -> void
        _result = v0.u(); // com.android.ex.editstyledtext.ak.u -> void
        return;
    }

    private void z() {
        // Registers (6 total): v5 = this
        v0 = "EditStyledText.EditorManager";
        v1 = "--- onInsertHorizontalLine:";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_0064 */;
        v0 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        v2 = binOpLit8_0xd8(v1, -1);
        _result = android.text.Editable.charAt(v0, v2); // -> char
        v0 = _result;
        v2 = 10;
        if (v0 == v2) /* goto L_0064 */;
        v0 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v2 = _result;
        v0 = binOpLit8_0xd8(v1, 1);
        v3 = "\n";
        _result = android.text.Editable.insert(v2, v1, v3); // -> android.text.Editable
        v1 = new com.android.ex.editstyledtext.ah;
        v2 = 0xff000000;
        v3 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v3.getWidth(); // com.android.ex.editstyledtext.EditStyledText.getWidth -> int
        v3 = _result;
        v4 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v4.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v4 = _result;
        _result = v1.<init>(v2, v3, v4); // com.android.ex.editstyledtext.ah.<init> -> void
        v2 = binOpLit8_0xd8(v0, 1);
        _result = v5.a(v1, v0); // com.android.ex.editstyledtext.ak.a -> void
        v0 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        v1 = binOpLit8_0xd8(v2, 1);
        v3 = "\n";
        _result = android.text.Editable.insert(v0, v2, v3); // -> android.text.Editable
        v0 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.setSelection(v1); // com.android.ex.editstyledtext.EditStyledText.setSelection -> void
        v0 = v5.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v5.g; // com.android.ex.editstyledtext.ak.g:int
        v2 = v5.h; // com.android.ex.editstyledtext.ak.h:int
        _result = v0.a(v1, v2); // com.android.ex.editstyledtext.EditStyledText.a -> void
        return;
        v0 = v1;
        // goto L_002f
    }

    public void a() {
        // Registers (4 total): v3 = this
        v0 = "EditStyledText.EditorManager";
        v1 = "--- onClickView";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 1;
        if (v0 == v1) /* goto L_0013 */;
        v0 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 2;
        if (v0 != v1) /* goto L_0021 */;
        v0 = v3.p; // com.android.ex.editstyledtext.ak.p:com.android.ex.editstyledtext.c
        _result = v0.a(); // com.android.ex.editstyledtext.c.a -> void
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v3.g; // com.android.ex.editstyledtext.ak.g:int
        v2 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        _result = v0.a(v1, v2); // com.android.ex.editstyledtext.EditStyledText.a -> void
        return;
    }

    public void a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 1;
        _result = v1.a(v2, v0); // com.android.ex.editstyledtext.ak.a -> void
        return;
    }

    public void a(int p0, int p1) {
        // Registers (10 total): v7 = this, v8 = p0 (int), v9 = p1 (int)
        v0 = "EditStyledText";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "--- setTextComposingMask:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v8.min(v9); // java.lang.Math.min -> int
        v1 = _result;
        _result = v8.max(v9); // java.lang.Math.max -> int
        v2 = _result;
        _result = v7.l(); // com.android.ex.editstyledtext.ak.l -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00bd */;
        v0 = v7.k; // com.android.ex.editstyledtext.ak.k:int
        v3 = 16777215; // 0x00ffffff
        if (v0 == v3) /* goto L_00bd */;
        v0 = v7.k; // com.android.ex.editstyledtext.ak.k:int
        v3 = v7.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v3.p(); // com.android.ex.editstyledtext.EditStyledText.p -> int
        v3 = _result;
        v4 = "EditStyledText";
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "--- fg:";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v6 = _result;
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = ",bg:";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v3.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v6 = _result;
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = ",";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v7.l(); // com.android.ex.editstyledtext.ak.l -> boolean
        v6 = _result;
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = ",";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = ",";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = v7.g; // com.android.ex.editstyledtext.ak.g:int
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v5 = _result;
        _result = v4.d(v5); // android.util.Log.d -> int
        if (v0 != v3) /* goto L_00bc */;
        v0 = 0x80000000;
        v4 = 0xff000000;
        v3 = binOp2addr_0xb6(v3, v4);
        v3 = binOpLit8_0xdf(v3, -1);
        v0 = binOp2addr_0xb6(v0, v3);
        v3 = v7.n; // com.android.ex.editstyledtext.ak.n:android.text.style.BackgroundColorSpan
        if (v3 == 0) /* goto L_00a8 */;
        v3 = v7.n; // com.android.ex.editstyledtext.ak.n:android.text.style.BackgroundColorSpan
        _result = v3.getBackgroundColor(); // android.text.style.BackgroundColorSpan.getBackgroundColor -> int
        v3 = _result;
        if (v3 == v0) /* goto L_00af */;
        v3 = new android.text.style.BackgroundColorSpan;
        _result = v3.<init>(v0); // android.text.style.BackgroundColorSpan.<init> -> void
        v7.n = v3; // com.android.ex.editstyledtext.ak.n:android.text.style.BackgroundColorSpan
        v0 = v7.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        v3 = v7.n; // com.android.ex.editstyledtext.ak.n:android.text.style.BackgroundColorSpan
        v4 = 33;
        _result = android.text.Editable.setSpan(v0, v3, v1, v2, v4); // -> void
        return;
        v0 = v7.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.a(v1); // com.android.ex.editstyledtext.EditStyledText.a -> int
        v0 = _result;
        // goto L_003c
    }

    public void a(int p0, boolean p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (boolean)
        v0 = v3.p; // com.android.ex.editstyledtext.ak.p:com.android.ex.editstyledtext.c
        _result = v0.a(v4); // com.android.ex.editstyledtext.c.a -> void
        if (v5 == 0) /* goto L_0010 */;
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v3.g; // com.android.ex.editstyledtext.ak.g:int
        v2 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        _result = v0.a(v1, v2); // com.android.ex.editstyledtext.EditStyledText.a -> void
        return;
    }

    public void a(android.text.Editable p0, int p1, int p2, int p3) {
        // Registers (16 total): v11 = this, v12 = p0 (android.text.Editable), v13 = p1 (int), v14 = p2 (int), v15 = p3 (int)
        v0 = "EditStyledText.EditorManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "updateSpanPrevious:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v13); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v14); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v4 = binOp_0x90(v13, v15);
        _result = v13.min(v4); // java.lang.Math.min -> int
        v0 = _result;
        _result = v13.max(v4); // java.lang.Math.max -> int
        v2 = _result;
        v1 = java.lang.Object.class;
        _result = android.text.Editable.getSpans(v12, v0, v0, v1); // -> java.lang.Object[]
        v5 = _result;
        v6 = v5.length;
        v0 = 0;
        v3 = v0;
        if (v3 >= v6) /* goto L_00ef */;
        v7 = v5[v3];
        v0 = (v7 instanceof android.text.style.ForegroundColorSpan);
        if (v0 != 0) /* goto L_0057 */;
        v0 = (v7 instanceof android.text.style.AbsoluteSizeSpan);
        if (v0 != 0) /* goto L_0057 */;
        v0 = (v7 instanceof com.android.ex.editstyledtext.ai);
        if (v0 != 0) /* goto L_0057 */;
        v0 = (v7 instanceof android.text.style.AlignmentSpan);
        if (v0 == 0) /* goto L_00b4 */;
        _result = android.text.Editable.getSpanStart(v12, v7); // -> int
        v8 = _result;
        _result = android.text.Editable.getSpanEnd(v12, v7); // -> int
        v1 = _result;
        v0 = "EditStyledText.EditorManager";
        v9 = new java.lang.StringBuilder;
        _result = v9.<init>(); // java.lang.StringBuilder.<init> -> void
        v10 = "spantype:";
        _result = v9.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        _result = v7.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v10 = _result;
        _result = v9.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        v10 = ",";
        _result = v9.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        _result = v9.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        _result = v9.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v9 = _result;
        _result = v0.d(v9); // android.util.Log.d -> int
        v0 = (v7 instanceof com.android.ex.editstyledtext.ai);
        if (v0 != 0) /* goto L_0090 */;
        v0 = (v7 instanceof android.text.style.AlignmentSpan);
        if (v0 == 0) /* goto L_00ae */;
        v0 = v11.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = v11.b(v0, v2); // com.android.ex.editstyledtext.ak.b -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_00aa */;
        v1 = "EditStyledText.EditorManager";
        v9 = "updateSpanPrevious: extend span";
        _result = v1.d(v9); // android.util.Log.d -> int
        v1 = 33;
        _result = android.text.Editable.setSpan(v12, v7, v8, v0, v1); // -> void
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_0043
        v0 = v11.d; // com.android.ex.editstyledtext.ak.d:boolean
        if (v0 == 0) /* goto L_00f0 */;
        v0 = v1;
        // goto L_009a
        v0 = (v7 instanceof com.android.ex.editstyledtext.ah);
        if (v0 == 0) /* goto L_00aa */;
        _result = android.text.Editable.getSpanStart(v12, v7); // -> int
        v0 = _result;
        _result = android.text.Editable.getSpanEnd(v12, v7); // -> int
        v1 = _result;
        if (v14 <= v15) /* goto L_00cc */;
        v8 = "";
        _result = android.text.Editable.replace(v12, v0, v1, v8); // -> android.text.Editable
        _result = android.text.Editable.removeSpan(v12, v7); // -> void
        // goto L_00aa
        if (v1 != v4) /* goto L_00aa */;
        _result = android.text.Editable.length(v12); // -> int
        v0 = _result;
        if (v4 >= v0) /* goto L_00aa */;
        v0 = v11.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = android.text.Editable.charAt(v0, v4); // -> char
        v0 = _result;
        v1 = 10;
        if (v0 == v1) /* goto L_00aa */;
        v0 = v11.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        v1 = "\n";
        _result = android.text.Editable.insert(v0, v4, v1); // -> android.text.Editable
        // goto L_00aa
        return;
        v0 = v2;
        // goto L_009a
    }

    public void a(android.text.Layout$Alignment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.text.Layout$Alignment)
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 2;
        if (v0 == v1) /* goto L_000a */;
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 3;
        if (v0 != v1) /* goto L_0010 */;
        _result = v2.b(v3); // com.android.ex.editstyledtext.ak.b -> void
        _result = v2.I(); // com.android.ex.editstyledtext.ak.I -> void
        return;
    }

    public void a(boolean p0) {
        // Registers (5 total): v3 = this, v4 = p0 (boolean)
        v0 = "EditStyledText.EditorManager";
        v1 = "--- onClickSelect";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = 5;
        v3.g = v0; // com.android.ex.editstyledtext.ak.g:int
        v0 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        if (v0 != 0) /* goto L_0021 */;
        v0 = v3.p; // com.android.ex.editstyledtext.ak.p:com.android.ex.editstyledtext.c
        _result = v0.a(); // com.android.ex.editstyledtext.c.a -> void
        if (v4 == 0) /* goto L_0020 */;
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v3.g; // com.android.ex.editstyledtext.ak.g:int
        v2 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        _result = v0.a(v1, v2); // com.android.ex.editstyledtext.EditStyledText.a -> void
        return;
        _result = v3.K(); // com.android.ex.editstyledtext.ak.K -> void
        v0 = v3.p; // com.android.ex.editstyledtext.ak.p:com.android.ex.editstyledtext.c
        _result = v0.a(); // com.android.ex.editstyledtext.c.a -> void
        // goto L_0015
    }

    public void b() {
        // Registers (4 total): v3 = this
        v0 = "EditStyledText.EditorManager";
        v1 = "--- onFixSelectedItem";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v3.C(); // com.android.ex.editstyledtext.ak.C -> void
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v3.g; // com.android.ex.editstyledtext.ak.g:int
        v2 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        _result = v0.a(v1, v2); // com.android.ex.editstyledtext.EditStyledText.a -> void
        return;
    }

    public void b(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.m = v1; // com.android.ex.editstyledtext.ak.m:int
        return;
    }

    public void b(int p0, int p1) {
        // Registers (7 total): v4 = this, v5 = p0 (int), v6 = p1 (int)
        v0 = "EditStyledText.EditorManager";
        v1 = "--- showsoftkey";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.isFocused(); // com.android.ex.editstyledtext.EditStyledText.isFocused -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        _result = v4.k(); // com.android.ex.editstyledtext.ak.k -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0018 */;
        return;
        v0 = v4.q; // com.android.ex.editstyledtext.ak.q:com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver
        v1 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = v1.getSelectionStart(); // android.text.Selection.getSelectionStart -> int
        v1 = _result;
        v0.mNewStart = v1; // com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver.mNewStart:int
        v0 = v4.q; // com.android.ex.editstyledtext.ak.q:com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver
        v1 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = v1.getSelectionEnd(); // android.text.Selection.getSelectionEnd -> int
        v1 = _result;
        v0.mNewEnd = v1; // com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver.mNewEnd:int
        v0 = v4.a; // com.android.ex.editstyledtext.ak.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v0 = _result;
        v1 = "input_method";
        _result = v0.getSystemService(v1); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.inputmethod.InputMethodManager) v0;
        v1 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v2 = 0;
        v3 = v4.q; // com.android.ex.editstyledtext.ak.q:com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver
        _result = v0.showSoftInput(v1, v2, v3); // android.view.inputmethod.InputMethodManager.showSoftInput -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v0 = v4.q; // com.android.ex.editstyledtext.ak.q:com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver
        if (v0 == 0) /* goto L_0017 */;
        v0 = v4.a; // com.android.ex.editstyledtext.ak.a:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = v0.setSelection(v5, v6); // android.text.Selection.setSelection -> void
        // goto L_0017
    }

    public void b(int p0, boolean p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (boolean)
        v0 = "EditStyledText.EditorManager";
        v1 = "--- setItemSize";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v2.N(); // com.android.ex.editstyledtext.ak.N -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0012 */;
        v2.l = v3; // com.android.ex.editstyledtext.ak.l:int
        return;
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 2;
        if (v0 == v1) /* goto L_001c */;
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 3;
        if (v0 != v1) /* goto L_0011 */;
        if (v3 <= 0) /* goto L_0021 */;
        _result = v2.h(v3); // com.android.ex.editstyledtext.ak.h -> void
        if (v4 == 0) /* goto L_0011 */;
        _result = v2.I(); // com.android.ex.editstyledtext.ak.I -> void
        // goto L_0011
    }

    public void b(android.text.Editable p0, int p1, int p2, int p3) {
        // Registers (16 total): v11 = this, v12 = p0 (android.text.Editable), v13 = p1 (int), v14 = p2 (int), v15 = p3 (int)
        v0 = "EditStyledText.EditorManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "updateSpanNext:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v13); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v14); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v3 = binOp_0x90(v13, v15);
        _result = v13.min(v3); // java.lang.Math.min -> int
        v1 = _result;
        _result = v13.max(v3); // java.lang.Math.max -> int
        v0 = _result;
        v2 = java.lang.Object.class;
        _result = android.text.Editable.getSpans(v12, v0, v0, v2); // -> java.lang.Object[]
        v4 = _result;
        v5 = v4.length;
        v0 = 0;
        v2 = v0;
        if (v2 >= v5) /* goto L_00d3 */;
        v6 = v4[v2];
        v0 = (v6 instanceof com.android.ex.editstyledtext.ai);
        if (v0 != 0) /* goto L_004f */;
        v0 = (v6 instanceof android.text.style.AlignmentSpan);
        if (v0 == 0) /* goto L_00a5 */;
        _result = android.text.Editable.getSpanStart(v12, v6); // -> int
        v7 = _result;
        _result = android.text.Editable.getSpanEnd(v12, v6); // -> int
        v8 = _result;
        v0 = "EditStyledText.EditorManager";
        v9 = new java.lang.StringBuilder;
        _result = v9.<init>(); // java.lang.StringBuilder.<init> -> void
        v10 = "spantype:";
        _result = v9.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        _result = v6.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v10 = _result;
        _result = v9.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        v10 = ",";
        _result = v9.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        _result = v9.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        _result = v9.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v9 = _result;
        _result = v0.d(v9); // android.util.Log.d -> int
        v0 = (v6 instanceof com.android.ex.editstyledtext.ai);
        if (v0 != 0) /* goto L_0088 */;
        v0 = (v6 instanceof android.text.style.AlignmentSpan);
        if (v0 == 0) /* goto L_00d4 */;
        v0 = v11.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        _result = v11.a(v0, v1); // com.android.ex.editstyledtext.ak.a -> int
        v0 = _result;
        if (v0 >= v7) /* goto L_009d */;
        if (v14 <= v15) /* goto L_009d */;
        _result = android.text.Editable.removeSpan(v12, v6); // -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0043
        if (v7 <= v1) /* goto L_0099 */;
        v0 = 33;
        _result = android.text.Editable.setSpan(v12, v6, v1, v8, v0); // -> void
        // goto L_0099
        v0 = (v6 instanceof com.android.ex.editstyledtext.ah);
        if (v0 == 0) /* goto L_0099 */;
        _result = android.text.Editable.getSpanStart(v12, v6); // -> int
        v0 = _result;
        if (v0 != v3) /* goto L_0099 */;
        if (v3 <= 0) /* goto L_0099 */;
        v0 = v11.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        v6 = binOpLit8_0xd8(v3, -1);
        _result = android.text.Editable.charAt(v0, v6); // -> char
        v0 = _result;
        v6 = 10;
        if (v0 == v6) /* goto L_0099 */;
        v0 = v11.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        v6 = "\n";
        _result = android.text.Editable.insert(v0, v3, v6); // -> android.text.Editable
        v0 = v11.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.setSelection(v3); // com.android.ex.editstyledtext.EditStyledText.setSelection -> void
        // goto L_0099
        return;
        v0 = v1;
        // goto L_0092
    }

    public void b(boolean p0) {
        // Registers (5 total): v3 = this, v4 = p0 (boolean)
        v0 = "EditStyledText.EditorManager";
        v1 = "--- onClickSelectAll";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v3.G(); // com.android.ex.editstyledtext.ak.G -> void
        if (v4 == 0) /* goto L_0017 */;
        v0 = v3.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        v1 = v3.g; // com.android.ex.editstyledtext.ak.g:int
        v2 = v3.h; // com.android.ex.editstyledtext.ak.h:int
        _result = v0.a(v1, v2); // com.android.ex.editstyledtext.EditStyledText.a -> void
        return;
    }

    public void c() {
        // Registers (3 total): v2 = this
        v0 = v2.p; // com.android.ex.editstyledtext.ak.p:com.android.ex.editstyledtext.c
        v1 = 14;
        _result = v0.a(v1); // com.android.ex.editstyledtext.c.a -> void
        return;
    }

    public void c(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 2;
        if (v0 == v1) /* goto L_000a */;
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 3;
        if (v0 != v1) /* goto L_0010 */;
        _result = v2.j(v3); // com.android.ex.editstyledtext.ak.j -> void
        _result = v2.I(); // com.android.ex.editstyledtext.ak.I -> void
        return;
    }

    public void c(int p0, boolean p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (boolean)
        v0 = "EditStyledText.EditorManager";
        v1 = "--- setItemColor";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v2.N(); // com.android.ex.editstyledtext.ak.N -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0012 */;
        v2.k = v3; // com.android.ex.editstyledtext.ak.k:int
        return;
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 2;
        if (v0 == v1) /* goto L_001c */;
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 3;
        if (v0 != v1) /* goto L_0011 */;
        v0 = 16777215; // 0x00ffffff
        if (v3 == v0) /* goto L_0024 */;
        _result = v2.i(v3); // com.android.ex.editstyledtext.ak.i -> void
        if (v4 == 0) /* goto L_0011 */;
        _result = v2.I(); // com.android.ex.editstyledtext.ak.I -> void
        // goto L_0011
    }

    public void d() {
        // Registers (5 total): v4 = this
        v0 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        v0 = 0;
        _result = android.text.Editable.length(v1); // -> int
        v2 = _result;
        if (v0 >= v2) /* goto L_0022 */;
        _result = android.text.Editable.charAt(v1, v0); // -> char
        v2 = _result;
        v3 = 8288;
        if (v2 != v3) /* goto L_001f */;
        v2 = binOpLit8_0xd8(v0, 1);
        v3 = "";
        _result = android.text.Editable.replace(v1, v0, v2, v3); // -> android.text.Editable
        v0 = binOpLit8_0xd8(v0, -1);
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0007
        return;
    }

    public void d(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = "EditStyledText.EditorManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "--- setSelectedEndPos:";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v3.j = v4; // com.android.ex.editstyledtext.ak.j:int
        _result = v3.J(); // com.android.ex.editstyledtext.ak.J -> void
        return;
    }

    public void e() {
        // Registers (9 total): v8 = this
        v3 = 0;
        v0 = "EditStyledText.EditorManager";
        v1 = "--- onRefreshStyles";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v8.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v4 = _result;
        _result = android.text.Editable.length(v4); // -> int
        v2 = _result;
        v0 = v8.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getWidth(); // com.android.ex.editstyledtext.EditStyledText.getWidth -> int
        v5 = _result;
        v0 = com.android.ex.editstyledtext.ah.class;
        _result = android.text.Editable.getSpans(v4, v3, v2, v0); // -> java.lang.Object[]
        v0 = _result;
        v0 = (com.android.ex.editstyledtext.ah[]) v0;
        v6 = v0.length;
        v1 = v3;
        if (v1 >= v6) /* goto L_002e */;
        v7 = v0[v1];
        _result = v7.a(v5); // com.android.ex.editstyledtext.ah.a -> void
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0024
        v1 = com.android.ex.editstyledtext.ai.class;
        _result = android.text.Editable.getSpans(v4, v3, v2, v1); // -> java.lang.Object[]
        v1 = _result;
        v1 = (com.android.ex.editstyledtext.ai[]) v1;
        v5 = v1.length;
        v2 = v3;
        if (v2 >= v5) /* goto L_0048 */;
        v6 = v1[v2];
        v7 = v8.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v7.p(); // com.android.ex.editstyledtext.EditStyledText.p -> int
        v7 = _result;
        _result = v6.a(v7); // com.android.ex.editstyledtext.ai.a -> void
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_0038
        v0 = v0.length;
        if (v0 <= 0) /* goto L_0067 */;
        v0 = 1;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = android.text.Editable.charAt(v4, v3); // -> char
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = android.text.Editable.replace(v4, v3, v0, v1); // -> android.text.Editable
        return;
    }

    public void f() {
        // Registers (3 total): v2 = this
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 2;
        if (v0 == v1) /* goto L_000a */;
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 3;
        if (v0 != v1) /* goto L_0010 */;
        _result = v2.R(); // com.android.ex.editstyledtext.ak.R -> void
        _result = v2.I(); // com.android.ex.editstyledtext.ak.I -> void
        return;
    }

    public void g() {
        // Registers (3 total): v2 = this
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 2;
        if (v0 == v1) /* goto L_000a */;
        v0 = v2.h; // com.android.ex.editstyledtext.ak.h:int
        v1 = 3;
        if (v0 != v1) /* goto L_0010 */;
        _result = v2.S(); // com.android.ex.editstyledtext.ak.S -> void
        _result = v2.I(); // com.android.ex.editstyledtext.ak.I -> void
        return;
    }

    public void h() {
        // Registers (3 total): v2 = this
        v0 = "EditStyledText";
        v1 = "--- unsetTextComposingMask";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v2.n; // com.android.ex.editstyledtext.ak.n:android.text.style.BackgroundColorSpan
        if (v0 == 0) /* goto L_001b */;
        v0 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v0 = _result;
        v1 = v2.n; // com.android.ex.editstyledtext.ak.n:android.text.style.BackgroundColorSpan
        _result = android.text.Editable.removeSpan(v0, v1); // -> void
        v0 = 0;
        v2.n = v0; // com.android.ex.editstyledtext.ak.n:android.text.style.BackgroundColorSpan
        return;
    }

    public boolean i() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // com.android.ex.editstyledtext.ak.b:boolean
        return v0;
    }

    public boolean j() {
        // Registers (5 total): v4 = this
        v1 = 0;
        v0 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v2 = _result;
        _result = android.text.Editable.length(v2); // -> int
        v3 = _result;
        v0 = android.text.style.ParagraphStyle.class;
        _result = android.text.Editable.getSpans(v2, v1, v3, v0); // -> java.lang.Object[]
        v0 = _result;
        v0 = (android.text.style.ParagraphStyle[]) v0;
        v0 = v0.length;
        if (v0 > 0) /* goto L_0033 */;
        v0 = android.text.style.QuoteSpan.class;
        _result = android.text.Editable.getSpans(v2, v1, v3, v0); // -> java.lang.Object[]
        v0 = _result;
        v0 = (android.text.style.QuoteSpan[]) v0;
        v0 = v0.length;
        if (v0 > 0) /* goto L_0033 */;
        v0 = android.text.style.CharacterStyle.class;
        _result = android.text.Editable.getSpans(v2, v1, v3, v0); // -> java.lang.Object[]
        v0 = _result;
        v0 = (android.text.style.CharacterStyle[]) v0;
        v0 = v0.length;
        if (v0 > 0) /* goto L_0033 */;
        v0 = v4.m; // com.android.ex.editstyledtext.ak.m:int
        v2 = 16777215; // 0x00ffffff
        if (v0 == v2) /* goto L_0035 */;
        v0 = 1;
        return v0;
        v0 = v1;
        // goto L_0034
    }

    public boolean k() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.android.ex.editstyledtext.ak.c:boolean
        return v0;
    }

    public boolean l() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.android.ex.editstyledtext.ak.e:boolean
        return v0;
    }

    public int m() {
        // Registers (2 total): v1 = this
        v0 = v1.m; // com.android.ex.editstyledtext.ak.m:int
        return v0;
    }

    public int n() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.android.ex.editstyledtext.ak.g:int
        return v0;
    }

    public int o() {
        // Registers (2 total): v1 = this
        v0 = v1.h; // com.android.ex.editstyledtext.ak.h:int
        return v0;
    }

    public int p() {
        // Registers (2 total): v1 = this
        v0 = v1.i; // com.android.ex.editstyledtext.ak.i:int
        return v0;
    }

    public int q() {
        // Registers (2 total): v1 = this
        v0 = v1.j; // com.android.ex.editstyledtext.ak.j:int
        return v0;
    }

    public int r() {
        // Registers (2 total): v1 = this
        v0 = v1.l; // com.android.ex.editstyledtext.ak.l:int
        return v0;
    }

    public int s() {
        // Registers (2 total): v1 = this
        v0 = v1.k; // com.android.ex.editstyledtext.ak.k:int
        return v0;
    }

    public boolean t() {
        // Registers (2 total): v1 = this
        v0 = v1.r; // com.android.ex.editstyledtext.ak.r:android.text.SpannableStringBuilder
        if (v0 == 0) /* goto L_001a */;
        v0 = v1.r; // com.android.ex.editstyledtext.ak.r:android.text.SpannableStringBuilder
        _result = v0.length(); // android.text.SpannableStringBuilder.length -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_001a */;
        v0 = v1.r; // com.android.ex.editstyledtext.ak.r:android.text.SpannableStringBuilder
        _result = v1.a(v0); // com.android.ex.editstyledtext.ak.a -> android.text.SpannableStringBuilder
        v0 = _result;
        _result = v0.length(); // android.text.SpannableStringBuilder.length -> int
        v0 = _result;
        if (v0 != 0) /* goto L_001a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0019
    }

    public void u() {
        // Registers (3 total): v2 = this
        v0 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getSelectionStart(); // com.android.ex.editstyledtext.EditStyledText.getSelectionStart -> int
        v0 = _result;
        v1 = v2.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getSelectionEnd(); // com.android.ex.editstyledtext.EditStyledText.getSelectionEnd -> int
        v1 = _result;
        _result = v2.b(v0, v1); // com.android.ex.editstyledtext.ak.b -> void
        return;
    }

    public void v() {
        // Registers (5 total): v4 = this
        v0 = "EditStyledText.EditorManager";
        v1 = "--- hidesoftkey";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.isFocused(); // com.android.ex.editstyledtext.EditStyledText.isFocused -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0012 */;
        return;
        v0 = v4.q; // com.android.ex.editstyledtext.ak.q:com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver
        v1 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = v1.getSelectionStart(); // android.text.Selection.getSelectionStart -> int
        v1 = _result;
        v0.mNewStart = v1; // com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver.mNewStart:int
        v0 = v4.q; // com.android.ex.editstyledtext.ak.q:com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver
        v1 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getText(); // com.android.ex.editstyledtext.EditStyledText.getText -> android.text.Editable
        v1 = _result;
        _result = v1.getSelectionEnd(); // android.text.Selection.getSelectionEnd -> int
        v1 = _result;
        v0.mNewEnd = v1; // com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver.mNewEnd:int
        v0 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v0.getContext(); // com.android.ex.editstyledtext.EditStyledText.getContext -> android.content.Context
        v0 = _result;
        v1 = "input_method";
        _result = v0.getSystemService(v1); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.inputmethod.InputMethodManager) v0;
        v1 = v4.o; // com.android.ex.editstyledtext.ak.o:com.android.ex.editstyledtext.EditStyledText
        _result = v1.getWindowToken(); // com.android.ex.editstyledtext.EditStyledText.getWindowToken -> android.os.IBinder
        v1 = _result;
        v2 = 0;
        v3 = v4.q; // com.android.ex.editstyledtext.ak.q:com.android.ex.editstyledtext.EditStyledText$SoftKeyReceiver
        _result = v0.hideSoftInputFromWindow(v1, v2, v3); // android.view.inputmethod.InputMethodManager.hideSoftInputFromWindow -> boolean
        // goto L_0011
    }

    public void w() {
        // Registers (3 total): v2 = this
        v0 = "EditStyledText.EditorManager";
        v1 = "--- blockSoftKey:";
        _result = v0.d(v1); // android.util.Log.d -> int
        _result = v2.v(); // com.android.ex.editstyledtext.ak.v -> void
        v0 = 1;
        v2.c = v0; // com.android.ex.editstyledtext.ak.c:boolean
        return;
    }

    public void x() {
        // Registers (3 total): v2 = this
        v0 = "EditStyledText.EditorManager";
        v1 = "--- unblockSoftKey:";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = 0;
        v2.c = v0; // com.android.ex.editstyledtext.ak.c:boolean
        return;
    }

}