package com.android.common.content;

/**
 * Original SourceFile: SQLiteContentProvider.java
 * Descriptor: Lcom/android/common/content/SQLiteContentProvider;
 */
public abstract class SQLiteContentProvider extends android.content.ContentProvider implements android.database.sqlite.SQLiteTransactionListener {
    private final java.lang.ThreadLocal a;

    public SQLiteContentProvider() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // android.content.ContentProvider.<init> -> void
        v0 = new java.lang.ThreadLocal;
        _result = v0.<init>(); // java.lang.ThreadLocal.<init> -> void
        v1.a = v0; // com.android.common.content.SQLiteContentProvider.a:java.lang.ThreadLocal
        return;
    }

}