package com.android.common.a;

/**
 * Original SourceFile: DataUsageStatUpdater.java
 * Descriptor: Lcom/android/common/a/b;
 */
public final class b {
    static final android.net.Uri a;

    static {
        v0 = android.provider.ContactsContract$Data.CONTENT_URI; // :android.net.Uri
        v1 = "usagefeedback";
        _result = v0.withAppendedPath(v1); // android.net.Uri.withAppendedPath -> android.net.Uri
        v0 = _result;
        com.android.common.a.b.a = v0; // :android.net.Uri
        return;
    }

}