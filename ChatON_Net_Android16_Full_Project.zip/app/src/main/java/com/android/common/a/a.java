package com.android.common.a;

/**
 * Original SourceFile: DataUsageStatUpdater.java
 * Descriptor: Lcom/android/common/a/a;
 */
public class a {
    private static final java.lang.String a;
    private final android.content.ContentResolver b;

    static {
        v0 = com.android.common.a.a.class;
        _result = v0.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v0 = _result;
        com.android.common.a.a.a = v0; // :java.lang.String
        return;
    }

    public a(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        _result = v2.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        v1.b = v0; // com.android.common.a.a.b:android.content.ContentResolver
        return;
    }

    private boolean a(java.util.Collection p0, java.util.Collection p1, java.lang.String p2) {
        // Registers (16 total): v12 = this, v13 = p0 (java.util.Collection), v14 = p1 (java.util.Collection), v15 = p2 (java.lang.String)
        v6 = 0;
        v1 = 1;
        v2 = 0;
        v11 = 3;
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v3 = _result;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v5 = 14;
        if (v0 < v5) /* goto L_007b */;
        _result = java.util.Collection.isEmpty(v14); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0025 */;
        v0 = com.android.common.a.a.a; // :java.lang.String
        _result = v0.isLoggable(v11); // android.util.Log.isLoggable -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0024 */;
        v0 = com.android.common.a.a.a; // :java.lang.String
        v1 = "Given list for data IDs is null. Ignoring.";
        _result = v0.d(v1); // android.util.Log.d -> int
        return v2;
        v0 = com.android.common.a.b.a; // :android.net.Uri
        _result = v0.buildUpon(); // android.net.Uri.buildUpon -> android.net.Uri$Builder
        v0 = _result;
        v3 = ",";
        _result = v3.join(v14); // android.text.TextUtils.join -> java.lang.String
        v3 = _result;
        _result = v0.appendPath(v3); // android.net.Uri$Builder.appendPath -> android.net.Uri$Builder
        v0 = _result;
        v3 = "type";
        _result = v0.appendQueryParameter(v3, v15); // android.net.Uri$Builder.appendQueryParameter -> android.net.Uri$Builder
        v0 = _result;
        _result = v0.build(); // android.net.Uri$Builder.build -> android.net.Uri
        v0 = _result;
        v3 = v12.b; // com.android.common.a.a.b:android.content.ContentResolver
        v4 = new android.content.ContentValues;
        _result = v4.<init>(); // android.content.ContentValues.<init> -> void
        _result = v3.update(v0, v4, v6, v6); // android.content.ContentResolver.update -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0051 */;
        v0 = v1;
        v2 = v0;
        // goto L_0024
        v0 = com.android.common.a.a.a; // :java.lang.String
        _result = v0.isLoggable(v11); // android.util.Log.isLoggable -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0079 */;
        v0 = com.android.common.a.a.a; // :java.lang.String
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "update toward data rows ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v14); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v3 = " failed";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v2;
        // goto L_004f
        _result = java.util.Collection.isEmpty(v13); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0092 */;
        v0 = com.android.common.a.a.a; // :java.lang.String
        _result = v0.isLoggable(v11); // android.util.Log.isLoggable -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0024 */;
        v0 = com.android.common.a.a.a; // :java.lang.String
        v1 = "Given list for contact IDs is null. Ignoring.";
        _result = v0.d(v1); // android.util.Log.d -> int
        // goto L_0024
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = new java.util.ArrayList;
        _result = v6.<init>(); // java.util.ArrayList.<init> -> void
        _result = java.util.Collection.size(v13); // -> int
        v0 = _result;
        v7 = new java.lang.String[][size=v0];
        _result = java.util.Collection.iterator(v13); // -> java.util.Iterator
        v8 = _result;
        _result = java.util.Iterator.hasNext(v8); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00be */;
        _result = java.util.Iterator.next(v8); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Long) v0;
        _result = v0.longValue(); // java.lang.Long.longValue -> long
        v9 = _result;
        _result = v9.valueOf(v10); // java.lang.String.valueOf -> java.lang.String
        v0 = _result;
        _result = v6.add(v0); // java.util.ArrayList.add -> boolean
        // goto L_00a6
        v0 = "?";
        _result = v7.fill(v0); // java.util.Arrays.fill -> void
        v0 = "_id IN (";
        _result = v5.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v8 = ",";
        _result = v8.join(v7); // android.text.TextUtils.join -> java.lang.String
        v7 = _result;
        _result = v0.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v7 = ")";
        _result = v0.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = com.android.common.a.a.a; // :java.lang.String
        _result = v0.isLoggable(v11); // android.util.Log.isLoggable -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_011a */;
        v0 = com.android.common.a.a.a; // :java.lang.String
        v7 = new java.lang.StringBuilder;
        _result = v7.<init>(); // java.lang.StringBuilder.<init> -> void
        v8 = "contactId where: ";
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v5.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v8 = _result;
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v7 = _result;
        _result = v0.d(v7); // android.util.Log.d -> int
        v0 = com.android.common.a.a.a; // :java.lang.String
        v7 = new java.lang.StringBuilder;
        _result = v7.<init>(); // java.lang.StringBuilder.<init> -> void
        v8 = "contactId selection: ";
        _result = v7.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v7 = _result;
        _result = v7.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v7 = _result;
        _result = v0.d(v7); // android.util.Log.d -> int
        v7 = new android.content.ContentValues;
        _result = v7.<init>(); // android.content.ContentValues.<init> -> void
        v0 = "last_time_contacted";
        _result = v3.valueOf(v4); // java.lang.Long.valueOf -> java.lang.Long
        v3 = _result;
        _result = v7.put(v0, v3); // android.content.ContentValues.put -> void
        v3 = v12.b; // com.android.common.a.a.b:android.content.ContentResolver
        v4 = android.provider.ContactsContract$Contacts.CONTENT_URI; // :android.net.Uri
        _result = v5.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v5 = _result;
        v0 = new java.lang.String[][size=v2];
        _result = v6.toArray(v0); // java.util.ArrayList.toArray -> java.lang.Object[]
        v0 = _result;
        v0 = (java.lang.String[]) v0;
        _result = v3.update(v4, v7, v5, v0); // android.content.ContentResolver.update -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0142 */;
        v2 = v1;
        // goto L_0024
        v0 = com.android.common.a.a.a; // :java.lang.String
        _result = v0.isLoggable(v11); // android.util.Log.isLoggable -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0024 */;
        v0 = com.android.common.a.a.a; // :java.lang.String
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "update toward raw contacts ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v13); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v3 = " failed";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        // goto L_0024
    }

    public boolean a(java.util.Collection p0) {
        // Registers (10 total): v8 = this, v9 = p0 (java.util.Collection)
        v7 = 1;
        v6 = 0;
        v0 = com.android.common.a.a.a; // :java.lang.String
        v1 = 3;
        _result = v0.isLoggable(v1); // android.util.Log.isLoggable -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002c */;
        v0 = com.android.common.a.a.a; // :java.lang.String
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "updateWithPhoneNumber: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = java.util.Collection.toArray(v9); // -> java.lang.Object[]
        v2 = _result;
        _result = v2.toString(); // java.util.Arrays.toString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        if (v9 == 0) /* goto L_0091 */;
        _result = java.util.Collection.isEmpty(v9); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0091 */;
        v4 = new java.util.ArrayList;
        _result = v4.<init>(); // java.util.ArrayList.<init> -> void
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = java.util.Collection.size(v9); // -> int
        v0 = _result;
        v0 = new java.lang.String[][size=v0];
        _result = v4.addAll(v9); // java.util.ArrayList.addAll -> boolean
        v1 = "?";
        _result = v0.fill(v1); // java.util.Arrays.fill -> void
        v1 = "data1 IN (";
        _result = v3.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        _result = v2.join(v0); // android.text.TextUtils.join -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ")";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = v8.b; // com.android.common.a.a.b:android.content.ContentResolver
        v1 = android.provider.ContactsContract$CommonDataKinds$Phone.CONTENT_URI; // :android.net.Uri
        v2 = 2;
        v2 = new java.lang.String[][size=v2];
        v5 = "contact_id";
        v2[v6] = v5;
        v5 = "_id";
        v2[v7] = v5;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v5 = new java.lang.String[][size=v6];
        _result = v4.toArray(v5); // java.util.ArrayList.toArray -> java.lang.Object[]
        v4 = _result;
        v4 = (java.lang.String[]) v4;
        v5 = 0;
        _result = v0.query(v0..v5); // android.content.ContentResolver.query -> android.database.Cursor
        v1 = _result;
        if (v1 != 0) /* goto L_0093 */;
        v0 = com.android.common.a.a.a; // :java.lang.String
        v1 = "Cursor for Phone.CONTENT_URI became null.";
        _result = v0.w(v1); // android.util.Log.w -> int
        v0 = v6;
        return v0;
        v0 = new java.util.HashSet;
        _result = android.database.Cursor.getCount(v1); // -> int
        v2 = _result;
        _result = v0.<init>(v2); // java.util.HashSet.<init> -> void
        v2 = new java.util.HashSet;
        _result = android.database.Cursor.getCount(v1); // -> int
        v3 = _result;
        _result = v2.<init>(v3); // java.util.HashSet.<init> -> void
        v3 = -1;
        _result = android.database.Cursor.move(v1, v3); // -> boolean
        _result = android.database.Cursor.moveToNext(v1); // -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_00cd */;
        v3 = 0;
        _result = android.database.Cursor.getLong(v1, v3); // -> long
        v3 = _result;
        _result = v3.valueOf(v4); // java.lang.Long.valueOf -> java.lang.Long
        v3 = _result;
        _result = java.util.Set.add(v0, v3); // -> boolean
        v3 = 1;
        _result = android.database.Cursor.getLong(v1, v3); // -> long
        v3 = _result;
        _result = v3.valueOf(v4); // java.lang.Long.valueOf -> java.lang.Long
        v3 = _result;
        _result = java.util.Set.add(v2, v3); // -> boolean
        // goto L_00a9
        v0 = _exception;
        _result = android.database.Cursor.close(v1); // -> void
        throw v0;
        _result = android.database.Cursor.close(v1); // -> void
        v1 = "short_text";
        _result = v8.a(v0, v2, v1); // com.android.common.a.a.a -> boolean
        v0 = _result;
        // goto L_0092
    }

}