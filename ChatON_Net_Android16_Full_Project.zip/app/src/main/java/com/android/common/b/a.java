package com.android.common.b;

/**
 * Original SourceFile: UserHappinessSignals.java
 * Descriptor: Lcom/android/common/b/a;
 */
public class a {
    private static boolean a;

    static {
        v0 = 0;
        com.android.common.b.a.a = v0; // :boolean
        return;
    }

    public static void a(android.content.Context p0) {
        // Registers (5 total): v4 = p0 (android.content.Context)
        v0 = com.android.common.b.a.a; // :boolean
        if (v0 == 0) /* goto L_0038 */;
        v0 = new android.content.Intent;
        v1 = "com.android.common.speech.LOG_EVENT";
        _result = v0.<init>(v1); // android.content.Intent.<init> -> void
        v1 = "app_name";
        v2 = "voiceime";
        _result = v0.putExtra(v1, v2); // android.content.Intent.putExtra -> android.content.Intent
        v1 = "extra_event";
        v2 = 21;
        _result = v0.putExtra(v1, v2); // android.content.Intent.putExtra -> android.content.Intent
        v1 = "";
        _result = v4.getPackageName(); // android.content.Context.getPackageName -> java.lang.String
        v2 = _result;
        _result = v0.putExtra(v1, v2); // android.content.Intent.putExtra -> android.content.Intent
        v1 = "timestamp";
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v2 = _result;
        _result = v0.putExtra(v1, v2, v3); // android.content.Intent.putExtra -> android.content.Intent
        _result = v4.sendBroadcast(v0); // android.content.Context.sendBroadcast -> void
        v0 = 0;
        _result = v0.a(); // com.android.common.b.a.a -> void
        return;
    }

    public static void a(boolean p0) {
        // Registers (1 total): v0 = p0 (boolean)
        com.android.common.b.a.a = v0; // :boolean
        return;
    }

}