package com.android.a.a;

/**
 * Original SourceFile: IInAppBillingService.java
 * Descriptor: Lcom/android/a/a/c;
 */
class c implements com.android.a.a.a {
    private android.os.IBinder a;

    c(android.os.IBinder p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.IBinder)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // com.android.a.a.c.a:android.os.IBinder
        return;
    }

    public int a(int p0, java.lang.String p1, java.lang.String p2) {
        // Registers (9 total): v5 = this, v6 = p0 (int), v7 = p1 (java.lang.String), v8 = p2 (java.lang.String)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = v1.writeInterfaceToken(v0); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeInt(v6); // android.os.Parcel.writeInt -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        _result = v1.writeString(v8); // android.os.Parcel.writeString -> void
        v0 = v5.a; // com.android.a.a.c.a:android.os.IBinder
        v3 = 1;
        v4 = 0;
        _result = android.os.IBinder.transact(v0, v3, v1, v2, v4); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public android.os.Bundle a(int p0, java.lang.String p1, java.lang.String p2, android.os.Bundle p3) {
        // Registers (10 total): v5 = this, v6 = p0 (int), v7 = p1 (java.lang.String), v8 = p2 (java.lang.String), v9 = p3 (android.os.Bundle)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = v1.writeInterfaceToken(v0); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeInt(v6); // android.os.Parcel.writeInt -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        _result = v1.writeString(v8); // android.os.Parcel.writeString -> void
        if (v9 == 0) /* goto L_0040 */;
        v0 = 1;
        _result = v1.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = 0;
        _result = v9.writeToParcel(v1, v0); // android.os.Bundle.writeToParcel -> void
        v0 = v5.a; // com.android.a.a.c.a:android.os.IBinder
        v3 = 2;
        v4 = 0;
        _result = android.os.IBinder.transact(v0, v3, v1, v2, v4); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 == 0) /* goto L_004d */;
        v0 = android.os.Bundle.CREATOR; // :android.os.Parcelable$Creator
        _result = android.os.Parcelable$Creator.createFromParcel(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (android.os.Bundle) v0;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = 0;
        _result = v1.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0021
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
        v0 = 0;
        // goto L_0039
    }

    public android.os.Bundle a(int p0, java.lang.String p1, java.lang.String p2, java.lang.String p3) {
        // Registers (10 total): v5 = this, v6 = p0 (int), v7 = p1 (java.lang.String), v8 = p2 (java.lang.String), v9 = p3 (java.lang.String)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = v1.writeInterfaceToken(v0); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeInt(v6); // android.os.Parcel.writeInt -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        _result = v1.writeString(v8); // android.os.Parcel.writeString -> void
        _result = v1.writeString(v9); // android.os.Parcel.writeString -> void
        v0 = v5.a; // com.android.a.a.c.a:android.os.IBinder
        v3 = 4;
        v4 = 0;
        _result = android.os.IBinder.transact(v0, v3, v1, v2, v4); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0039 */;
        v0 = android.os.Bundle.CREATOR; // :android.os.Parcelable$Creator
        _result = android.os.Parcelable$Creator.createFromParcel(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (android.os.Bundle) v0;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = 0;
        // goto L_0032
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public android.os.Bundle a(int p0, java.lang.String p1, java.lang.String p2, java.lang.String p3, java.lang.String p4) {
        // Registers (11 total): v5 = this, v6 = p0 (int), v7 = p1 (java.lang.String), v8 = p2 (java.lang.String), v9 = p3 (java.lang.String), v10 = p4 (java.lang.String)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = v1.writeInterfaceToken(v0); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeInt(v6); // android.os.Parcel.writeInt -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        _result = v1.writeString(v8); // android.os.Parcel.writeString -> void
        _result = v1.writeString(v9); // android.os.Parcel.writeString -> void
        _result = v1.writeString(v10); // android.os.Parcel.writeString -> void
        v0 = v5.a; // com.android.a.a.c.a:android.os.IBinder
        v3 = 3;
        v4 = 0;
        _result = android.os.IBinder.transact(v0, v3, v1, v2, v4); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 == 0) /* goto L_003c */;
        v0 = android.os.Bundle.CREATOR; // :android.os.Parcelable$Creator
        _result = android.os.Parcelable$Creator.createFromParcel(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (android.os.Bundle) v0;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = 0;
        // goto L_0035
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public android.os.IBinder asBinder() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // com.android.a.a.c.a:android.os.IBinder
        return v0;
    }

    public int b(int p0, java.lang.String p1, java.lang.String p2) {
        // Registers (9 total): v5 = this, v6 = p0 (int), v7 = p1 (java.lang.String), v8 = p2 (java.lang.String)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = v1.writeInterfaceToken(v0); // android.os.Parcel.writeInterfaceToken -> void
        _result = v1.writeInt(v6); // android.os.Parcel.writeInt -> void
        _result = v1.writeString(v7); // android.os.Parcel.writeString -> void
        _result = v1.writeString(v8); // android.os.Parcel.writeString -> void
        v0 = v5.a; // com.android.a.a.c.a:android.os.IBinder
        v3 = 5;
        v4 = 0;
        _result = android.os.IBinder.transact(v0, v3, v1, v2, v4); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

}