package com.android.a.a;

/**
 * Original SourceFile: IInAppBillingService.java
 * Descriptor: Lcom/android/a/a/a;
 */
public interface a extends android.os.IInterface {
    public abstract int a(int p0, java.lang.String p1, java.lang.String p2);
    public abstract android.os.Bundle a(int p0, java.lang.String p1, java.lang.String p2, android.os.Bundle p3);
    public abstract android.os.Bundle a(int p0, java.lang.String p1, java.lang.String p2, java.lang.String p3);
    public abstract android.os.Bundle a(int p0, java.lang.String p1, java.lang.String p2, java.lang.String p3, java.lang.String p4);
    public abstract int b(int p0, java.lang.String p1, java.lang.String p2);
}