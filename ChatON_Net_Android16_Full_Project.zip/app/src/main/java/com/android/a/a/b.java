package com.android.a.a;

/**
 * Original SourceFile: IInAppBillingService.java
 * Descriptor: Lcom/android/a/a/b;
 */
public abstract class b extends android.os.Binder implements com.android.a.a.a {
    public static com.android.a.a.a a(android.os.IBinder p0) {
        // Registers (3 total): v2 = p0 (android.os.IBinder)
        if (v2 != 0) /* goto L_0004 */;
        v0 = 0;
        return v0;
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = android.os.IBinder.queryLocalInterface(v2, v0); // -> android.os.IInterface
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        v1 = (v0 instanceof com.android.a.a.a);
        if (v1 == 0) /* goto L_0014 */;
        v0 = (com.android.a.a.a) v0;
        // goto L_0003
        v0 = new com.android.a.a.c;
        _result = v0.<init>(v2); // com.android.a.a.c.<init> -> void
        // goto L_0003
    }

    public boolean onTransact(int p0, android.os.Parcel p1, android.os.Parcel p2, int p3) {
        // Registers (13 total): v8 = this, v9 = p0 (int), v10 = p1 (android.os.Parcel), v11 = p2 (android.os.Parcel), v12 = p3 (int)
        v7 = 0;
        v6 = 1;
        // switch(v9)
        _result = v8.onTransact(v9, v10, v11, v12); // android.os.Binder.onTransact -> boolean
        v0 = _result;
        return v0;
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = v11.writeString(v0); // android.os.Parcel.writeString -> void
        v0 = v6;
        // goto L_0009
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = v10.enforceInterface(v0); // android.os.Parcel.enforceInterface -> void
        _result = v10.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v1 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v8.a(v0, v1, v2); // com.android.a.a.b.a -> int
        v0 = _result;
        _result = v11.writeNoException(); // android.os.Parcel.writeNoException -> void
        _result = v11.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v6;
        // goto L_0009
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = v10.enforceInterface(v0); // android.os.Parcel.enforceInterface -> void
        _result = v10.readInt(); // android.os.Parcel.readInt -> int
        v1 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v3 = _result;
        _result = v10.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0061 */;
        v0 = android.os.Bundle.CREATOR; // :android.os.Parcelable$Creator
        _result = android.os.Parcelable$Creator.createFromParcel(v0, v10); // -> java.lang.Object
        v0 = _result;
        v0 = (android.os.Bundle) v0;
        _result = v8.a(v1, v2, v3, v0); // com.android.a.a.b.a -> android.os.Bundle
        v0 = _result;
        _result = v11.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v0 == 0) /* goto L_0063 */;
        _result = v11.writeInt(v6); // android.os.Parcel.writeInt -> void
        _result = v0.writeToParcel(v11, v6); // android.os.Bundle.writeToParcel -> void
        v0 = v6;
        // goto L_0009
        v0 = 0;
        // goto L_0050
        _result = v11.writeInt(v7); // android.os.Parcel.writeInt -> void
        // goto L_005f
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = v10.enforceInterface(v0); // android.os.Parcel.enforceInterface -> void
        _result = v10.readInt(); // android.os.Parcel.readInt -> int
        v1 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v3 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v4 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v5 = _result;
        v0 = v8;
        _result = v0.a(v0..v5); // com.android.a.a.b.a -> android.os.Bundle
        v0 = _result;
        _result = v11.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v0 == 0) /* goto L_0094 */;
        _result = v11.writeInt(v6); // android.os.Parcel.writeInt -> void
        _result = v0.writeToParcel(v11, v6); // android.os.Bundle.writeToParcel -> void
        v0 = v6;
        // goto L_0009
        _result = v11.writeInt(v7); // android.os.Parcel.writeInt -> void
        // goto L_0091
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = v10.enforceInterface(v0); // android.os.Parcel.enforceInterface -> void
        _result = v10.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v1 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v3 = _result;
        _result = v8.a(v0, v1, v2, v3); // com.android.a.a.b.a -> android.os.Bundle
        v0 = _result;
        _result = v11.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v0 == 0) /* goto L_00c0 */;
        _result = v11.writeInt(v6); // android.os.Parcel.writeInt -> void
        _result = v0.writeToParcel(v11, v6); // android.os.Bundle.writeToParcel -> void
        v0 = v6;
        // goto L_0009
        _result = v11.writeInt(v7); // android.os.Parcel.writeInt -> void
        // goto L_00bd
        v0 = "com.android.vending.billing.IInAppBillingService";
        _result = v10.enforceInterface(v0); // android.os.Parcel.enforceInterface -> void
        _result = v10.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v1 = _result;
        _result = v10.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v8.b(v0, v1, v2); // com.android.a.a.b.b -> int
        v0 = _result;
        _result = v11.writeNoException(); // android.os.Parcel.writeNoException -> void
        _result = v11.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v6;
        // goto L_0009
    }

}