package com.coolots.sso.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/coolots/sso/a/d;
 */
public interface d {
    public abstract void a(java.lang.String p0, java.lang.String p1, int p2);
}