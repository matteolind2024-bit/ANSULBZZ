package com.coolots.sso.calllog;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/coolots/sso/calllog/ChatONCallLogData;
 */
public class ChatONCallLogData implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
    private java.lang.String a;
    private int b;
    private int c;
    private int d;
    private java.lang.String e;
    private java.lang.String f;
    private int g;
    private java.lang.String h;

    static {
        v0 = new com.coolots.sso.calllog.a;
        _result = v0.<init>(); // com.coolots.sso.calllog.a.<init> -> void
        com.coolots.sso.calllog.ChatONCallLogData.CREATOR = v0; // :android.os.Parcelable$Creator
        return;
    }

    public ChatONCallLogData() {
        // Registers (3 total): v2 = this
        v1 = -1;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v0 = "";
        v2.a = v0; // com.coolots.sso.calllog.ChatONCallLogData.a:java.lang.String
        v0 = 0;
        v2.b = v0; // com.coolots.sso.calllog.ChatONCallLogData.b:int
        v2.c = v1; // com.coolots.sso.calllog.ChatONCallLogData.c:int
        v2.d = v1; // com.coolots.sso.calllog.ChatONCallLogData.d:int
        v0 = "";
        v2.e = v0; // com.coolots.sso.calllog.ChatONCallLogData.e:java.lang.String
        v0 = "";
        v2.f = v0; // com.coolots.sso.calllog.ChatONCallLogData.f:java.lang.String
        v2.g = v1; // com.coolots.sso.calllog.ChatONCallLogData.g:int
        v0 = "";
        v2.h = v0; // com.coolots.sso.calllog.ChatONCallLogData.h:java.lang.String
        return;
    }

    public ChatONCallLogData(android.os.Parcel p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Parcel)
        v1 = -1;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v0 = "";
        v2.a = v0; // com.coolots.sso.calllog.ChatONCallLogData.a:java.lang.String
        v0 = 0;
        v2.b = v0; // com.coolots.sso.calllog.ChatONCallLogData.b:int
        v2.c = v1; // com.coolots.sso.calllog.ChatONCallLogData.c:int
        v2.d = v1; // com.coolots.sso.calllog.ChatONCallLogData.d:int
        v0 = "";
        v2.e = v0; // com.coolots.sso.calllog.ChatONCallLogData.e:java.lang.String
        v0 = "";
        v2.f = v0; // com.coolots.sso.calllog.ChatONCallLogData.f:java.lang.String
        v2.g = v1; // com.coolots.sso.calllog.ChatONCallLogData.g:int
        v0 = "";
        v2.h = v0; // com.coolots.sso.calllog.ChatONCallLogData.h:java.lang.String
        _result = v2.a(v3); // com.coolots.sso.calllog.ChatONCallLogData.a -> void
        return;
    }

    private void a(android.os.Parcel p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Parcel)
        v1 = 0;
        _result = v3.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 != 0) /* goto L_003a */;
        v2.a = v1; // com.coolots.sso.calllog.ChatONCallLogData.a:java.lang.String
        _result = v3.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v2.b = v0; // com.coolots.sso.calllog.ChatONCallLogData.b:int
        _result = v3.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v2.c = v0; // com.coolots.sso.calllog.ChatONCallLogData.c:int
        _result = v3.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v2.d = v0; // com.coolots.sso.calllog.ChatONCallLogData.d:int
        _result = v3.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0041 */;
        v2.e = v1; // com.coolots.sso.calllog.ChatONCallLogData.e:java.lang.String
        _result = v3.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0048 */;
        v2.f = v1; // com.coolots.sso.calllog.ChatONCallLogData.f:java.lang.String
        _result = v3.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v2.g = v0; // com.coolots.sso.calllog.ChatONCallLogData.g:int
        _result = v3.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 != 0) /* goto L_004f */;
        v2.h = v1; // com.coolots.sso.calllog.ChatONCallLogData.h:java.lang.String
        return;
        _result = v3.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        v2.a = v0; // com.coolots.sso.calllog.ChatONCallLogData.a:java.lang.String
        // goto L_0009
        _result = v3.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        v2.e = v0; // com.coolots.sso.calllog.ChatONCallLogData.e:java.lang.String
        // goto L_0023
        _result = v3.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        v2.f = v0; // com.coolots.sso.calllog.ChatONCallLogData.f:java.lang.String
        // goto L_002b
        _result = v3.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        v2.h = v0; // com.coolots.sso.calllog.ChatONCallLogData.h:java.lang.String
        // goto L_0039
    }

    public java.lang.String a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // com.coolots.sso.calllog.ChatONCallLogData.a:java.lang.String
        return v0;
    }

    public void a(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.g = v1; // com.coolots.sso.calllog.ChatONCallLogData.g:int
        return;
    }

    public int b() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // com.coolots.sso.calllog.ChatONCallLogData.b:int
        return v0;
    }

    public int c() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // com.coolots.sso.calllog.ChatONCallLogData.c:int
        return v0;
    }

    public int d() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // com.coolots.sso.calllog.ChatONCallLogData.d:int
        return v0;
    }

    public int describeContents() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public java.lang.String e() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // com.coolots.sso.calllog.ChatONCallLogData.e:java.lang.String
        return v0;
    }

    public java.lang.String f() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // com.coolots.sso.calllog.ChatONCallLogData.f:java.lang.String
        return v0;
    }

    public int g() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // com.coolots.sso.calllog.ChatONCallLogData.g:int
        return v0;
    }

    public java.lang.String h() {
        // Registers (2 total): v1 = this
        v0 = v1.h; // com.coolots.sso.calllog.ChatONCallLogData.h:java.lang.String
        return v0;
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.os.Parcel), v4 = p1 (int)
        v1 = 0;
        v0 = v2.a; // com.coolots.sso.calllog.ChatONCallLogData.a:java.lang.String
        if (v0 == 0) /* goto L_000d */;
        v0 = v2.a; // com.coolots.sso.calllog.ChatONCallLogData.a:java.lang.String
        _result = v0.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0052 */;
        _result = v3.writeInt(v1); // android.os.Parcel.writeInt -> void
        v0 = v2.b; // com.coolots.sso.calllog.ChatONCallLogData.b:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.c; // com.coolots.sso.calllog.ChatONCallLogData.c:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.d; // com.coolots.sso.calllog.ChatONCallLogData.d:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.e; // com.coolots.sso.calllog.ChatONCallLogData.e:java.lang.String
        if (v0 == 0) /* goto L_002b */;
        v0 = v2.e; // com.coolots.sso.calllog.ChatONCallLogData.e:java.lang.String
        _result = v0.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0061 */;
        _result = v3.writeInt(v1); // android.os.Parcel.writeInt -> void
        v0 = v2.f; // com.coolots.sso.calllog.ChatONCallLogData.f:java.lang.String
        if (v0 == 0) /* goto L_003a */;
        v0 = v2.f; // com.coolots.sso.calllog.ChatONCallLogData.f:java.lang.String
        _result = v0.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0070 */;
        _result = v3.writeInt(v1); // android.os.Parcel.writeInt -> void
        v0 = v2.g; // com.coolots.sso.calllog.ChatONCallLogData.g:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.h; // com.coolots.sso.calllog.ChatONCallLogData.h:java.lang.String
        if (v0 == 0) /* goto L_004e */;
        v0 = v2.h; // com.coolots.sso.calllog.ChatONCallLogData.h:java.lang.String
        _result = v0.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_007f */;
        _result = v3.writeInt(v1); // android.os.Parcel.writeInt -> void
        return;
        v0 = v2.a; // com.coolots.sso.calllog.ChatONCallLogData.a:java.lang.String
        _result = v0.length(); // java.lang.String.length -> int
        v0 = _result;
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.a; // com.coolots.sso.calllog.ChatONCallLogData.a:java.lang.String
        _result = v3.writeString(v0); // android.os.Parcel.writeString -> void
        // goto L_0010
        v0 = v2.e; // com.coolots.sso.calllog.ChatONCallLogData.e:java.lang.String
        _result = v0.length(); // java.lang.String.length -> int
        v0 = _result;
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.e; // com.coolots.sso.calllog.ChatONCallLogData.e:java.lang.String
        _result = v3.writeString(v0); // android.os.Parcel.writeString -> void
        // goto L_002e
        v0 = v2.f; // com.coolots.sso.calllog.ChatONCallLogData.f:java.lang.String
        _result = v0.length(); // java.lang.String.length -> int
        v0 = _result;
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.f; // com.coolots.sso.calllog.ChatONCallLogData.f:java.lang.String
        _result = v3.writeString(v0); // android.os.Parcel.writeString -> void
        // goto L_003d
        v0 = v2.h; // com.coolots.sso.calllog.ChatONCallLogData.h:java.lang.String
        _result = v0.length(); // java.lang.String.length -> int
        v0 = _result;
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.h; // com.coolots.sso.calllog.ChatONCallLogData.h:java.lang.String
        _result = v3.writeString(v0); // android.os.Parcel.writeString -> void
        // goto L_0051
    }

}