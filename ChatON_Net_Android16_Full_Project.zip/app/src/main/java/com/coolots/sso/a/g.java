package com.coolots.sso.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/coolots/sso/a/g;
 */
class g extends android.content.BroadcastReceiver {
    final com.coolots.sso.a.a a;

    private g(com.coolots.sso.a.a p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.coolots.sso.a.a)
        v0.a = v1; // com.coolots.sso.a.g.a:com.coolots.sso.a.a
        _result = v0.<init>(); // android.content.BroadcastReceiver.<init> -> void
        return;
    }

    g(com.coolots.sso.a.a p0, com.coolots.sso.a.g p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.coolots.sso.a.a), v2 = p1 (com.coolots.sso.a.g)
        _result = v0.<init>(v1); // com.coolots.sso.a.g.<init> -> void
        return;
    }

    public void onReceive(android.content.Context p0, android.content.Intent p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.content.Context), v7 = p1 (android.content.Intent)
        if (v7 != 0) /* goto L_0003 */;
        return;
        _result = v7.getAction(); // android.content.Intent.getAction -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0002 */;
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIIUpdateReceiver() action: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIIUpdateReceiver() this: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = v5.a; // com.coolots.sso.a.g.a:com.coolots.sso.a.a
        _result = v1.e(); // com.coolots.sso.a.a.e -> com.coolots.sso.a.d
        v1 = _result;
        if (v1 == 0) /* goto L_0050 */;
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIIUpdateReceiver() mUpdateListener: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        v2 = v5.a; // com.coolots.sso.a.g.a:com.coolots.sso.a.a
        _result = v2.e(); // com.coolots.sso.a.a.e -> com.coolots.sso.a.d
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = v5.a; // com.coolots.sso.a.g.a:com.coolots.sso.a.a
        _result = v1.f(); // com.coolots.sso.a.a.f -> com.coolots.sso.a.g
        v1 = _result;
        if (v1 == 0) /* goto L_0071 */;
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIIUpdateReceiver() mUpdateReceiver: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        v2 = v5.a; // com.coolots.sso.a.g.a:com.coolots.sso.a.a
        _result = v2.f(); // com.coolots.sso.a.a.f -> com.coolots.sso.a.g
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = "com.coolots.chaton.version.UPGRADE_NEW_APK_INFO";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0002 */;
        v0 = "version_name";
        _result = v7.hasExtra(v0); // android.content.Intent.hasExtra -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0002 */;
        v0 = "version_info";
        _result = v7.hasExtra(v0); // android.content.Intent.hasExtra -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0002 */;
        v0 = "current_version_name";
        _result = v7.getStringExtra(v0); // android.content.Intent.getStringExtra -> java.lang.String
        v1 = _result;
        v0 = "version_name";
        _result = v7.getStringExtra(v0); // android.content.Intent.getStringExtra -> java.lang.String
        v0 = _result;
        if (v1 == 0) /* goto L_00a2 */;
        _result = v1.isEmpty(); // java.lang.String.isEmpty -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_00a5 */;
        v1 = "0.0";
        if (v0 == 0) /* goto L_00ad */;
        _result = v0.isEmpty(); // java.lang.String.isEmpty -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_00b0 */;
        v0 = "0.0";
        v2 = "version_info";
        v3 = 0;
        _result = v7.getIntExtra(v2, v3); // android.content.Intent.getIntExtra -> int
        v2 = _result;
        v3 = new java.lang.StringBuilder;
        v4 = "BR_UPGRADE_NEW_APK_INFO ";
        _result = v3.<init>(v4); // java.lang.StringBuilder.<init> -> void
        _result = v3.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ", ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ", ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v3.a(); // com.coolots.sso.a.a.a -> void
        v3 = v5.a; // com.coolots.sso.a.g.a:com.coolots.sso.a.a
        _result = v3.e(); // com.coolots.sso.a.a.e -> com.coolots.sso.a.d
        v3 = _result;
        if (v3 == 0) /* goto L_0002 */;
        v3 = v5.a; // com.coolots.sso.a.g.a:com.coolots.sso.a.a
        _result = v3.e(); // com.coolots.sso.a.a.e -> com.coolots.sso.a.d
        v3 = _result;
        _result = com.coolots.sso.a.d.a(v3, v1, v0, v2); // -> void
        // goto L_0002
    }

}