package com.coolots.sso.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/coolots/sso/a/e;
 */
class e extends android.content.BroadcastReceiver {
    final com.coolots.sso.a.a a;

    private e(com.coolots.sso.a.a p0) {
        // Registers (2 total): v0 = this, v1 = p0 (com.coolots.sso.a.a)
        v0.a = v1; // com.coolots.sso.a.e.a:com.coolots.sso.a.a
        _result = v0.<init>(); // android.content.BroadcastReceiver.<init> -> void
        return;
    }

    e(com.coolots.sso.a.a p0, com.coolots.sso.a.e p1) {
        // Registers (3 total): v0 = this, v1 = p0 (com.coolots.sso.a.a), v2 = p1 (com.coolots.sso.a.e)
        _result = v0.<init>(v1); // com.coolots.sso.a.e.<init> -> void
        return;
    }

    public void onReceive(android.content.Context p0, android.content.Intent p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.content.Intent)
        if (v5 != 0) /* goto L_0003 */;
        return;
        _result = v5.getAction(); // android.content.Intent.getAction -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0002 */;
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIICallReceiver() action: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIICallReceiver() this: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = v3.a; // com.coolots.sso.a.e.a:com.coolots.sso.a.a
        _result = v1.c(); // com.coolots.sso.a.a.c -> com.coolots.sso.a.b
        v1 = _result;
        if (v1 == 0) /* goto L_0050 */;
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIICallReceiver() mCallListener: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        v2 = v3.a; // com.coolots.sso.a.e.a:com.coolots.sso.a.a
        _result = v2.c(); // com.coolots.sso.a.a.c -> com.coolots.sso.a.b
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = v3.a; // com.coolots.sso.a.e.a:com.coolots.sso.a.a
        _result = v1.d(); // com.coolots.sso.a.a.d -> com.coolots.sso.a.e
        v1 = _result;
        if (v1 == 0) /* goto L_0071 */;
        v1 = new java.lang.StringBuilder;
        v2 = "ChatONVAPIICallReceiver() mCallReceiver: ";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        v2 = v3.a; // com.coolots.sso.a.e.a:com.coolots.sso.a.a
        _result = v2.d(); // com.coolots.sso.a.a.d -> com.coolots.sso.a.e
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = "com.coolots.chaton.account.CALL_STATE_CHANGE_INFO";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_00bc */;
        v0 = "result";
        _result = v5.hasExtra(v0); // android.content.Intent.hasExtra -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0002 */;
        v0 = "result";
        v1 = 3;
        _result = v5.getIntExtra(v0, v1); // android.content.Intent.getIntExtra -> int
        v0 = _result;
        v1 = new java.lang.StringBuilder;
        v2 = "BR_CALL_STATE_CHANGE_INFO state(";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        _result = v0.a(); // com.coolots.sso.a.a.a -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ")";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.a(); // com.coolots.sso.a.a.a -> void
        v1 = v3.a; // com.coolots.sso.a.e.a:com.coolots.sso.a.a
        _result = v1.c(); // com.coolots.sso.a.a.c -> com.coolots.sso.a.b
        v1 = _result;
        if (v1 == 0) /* goto L_0002 */;
        v1 = v3.a; // com.coolots.sso.a.e.a:com.coolots.sso.a.a
        _result = v1.c(); // com.coolots.sso.a.a.c -> com.coolots.sso.a.b
        v1 = _result;
        _result = com.coolots.sso.a.b.a(v1, v0); // -> void
        // goto L_0002
        v1 = "com.coolots.chaton.version.CONFERENCE_MEMBER_CHANGED";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0002 */;
        v0 = "BR_CONFERENCE_MEMBER_CHANGED";
        _result = v0.a(); // com.coolots.sso.a.a.a -> void
        v0 = v3.a; // com.coolots.sso.a.e.a:com.coolots.sso.a.a
        _result = v0.c(); // com.coolots.sso.a.a.c -> com.coolots.sso.a.b
        v0 = _result;
        if (v0 == 0) /* goto L_0002 */;
        v0 = v3.a; // com.coolots.sso.a.e.a:com.coolots.sso.a.a
        _result = v0.c(); // com.coolots.sso.a.a.c -> com.coolots.sso.a.b
        v0 = _result;
        _result = com.coolots.sso.a.b.a(v0); // -> void
        // goto L_0002
    }

}