package com.coolots.sso.calllog;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/coolots/sso/calllog/a;
 */
class a implements android.os.Parcelable$Creator {
    a() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public com.coolots.sso.calllog.ChatONCallLogData a(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        v0 = new com.coolots.sso.calllog.ChatONCallLogData;
        _result = v0.<init>(v2); // com.coolots.sso.calllog.ChatONCallLogData.<init> -> void
        return v0;
    }

    public java.lang.Object createFromParcel(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        _result = v1.a(v2); // com.coolots.sso.calllog.a.a -> com.coolots.sso.calllog.ChatONCallLogData
        v0 = _result;
        return v0;
    }

    public java.lang.Object[] newArray(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = new com.coolots.sso.calllog.ChatONCallLogData[][size=v2];
        return v0;
    }

}