package com.coolots.sso.a;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lcom/coolots/sso/a/b;
 */
public interface b {
    public abstract void a();
    public abstract void a(int p0);
}