package com.facebook.a;

/**
 * Original SourceFile: DialogError.java
 * Descriptor: Lcom/facebook/a/a;
 */
public class a extends java.lang.Throwable {
    private int a;
    private java.lang.String b;

    public a(java.lang.String p0, int p1, java.lang.String p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int), v3 = p2 (java.lang.String)
        _result = v0.<init>(v1); // java.lang.Throwable.<init> -> void
        v0.a = v2; // com.facebook.a.a.a:int
        v0.b = v3; // com.facebook.a.a.b:java.lang.String
        return;
    }

}