package com.facebook.a;

/**
 * Original SourceFile: Facebook.java
 * Descriptor: Lcom/facebook/a/b;
 */
public class b {
}