package android.os;

/**
 * Original SourceFile: ServiceManagerNative.java
 * Descriptor: Landroid/os/ServiceManagerNative;
 */
public abstract class ServiceManagerNative extends android.os.Binder implements android.os.IServiceManager {
    public ServiceManagerNative() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // android.os.Binder.<init> -> void
        v0 = "android.os.IServiceManager";
        _result = v1.attachInterface(v1, v0); // android.os.ServiceManagerNative.attachInterface -> void
        return;
    }

    public static android.os.IServiceManager asInterface(android.os.IBinder p0) {
        // Registers (2 total): v1 = p0 (android.os.IBinder)
        if (v1 != 0) /* goto L_0004 */;
        v0 = 0;
        return v0;
        v0 = "android.os.IServiceManager";
        _result = android.os.IBinder.queryLocalInterface(v1, v0); // -> android.os.IInterface
        v0 = _result;
        v0 = (android.os.IServiceManager) v0;
        if (v0 != 0) /* goto L_0003 */;
        v0 = new android.os.ServiceManagerProxy;
        _result = v0.<init>(v1); // android.os.ServiceManagerProxy.<init> -> void
        // goto L_0003
    }

    public android.os.IBinder asBinder() {
        // Registers (1 total): v0 = this
        return v0;
    }

    public boolean onTransact(int p0, android.os.Parcel p1, android.os.Parcel p2, int p3) {
        // Registers (8 total): v3 = this, v4 = p0 (int), v5 = p1 (android.os.Parcel), v6 = p2 (android.os.Parcel), v7 = p3 (int)
        v0 = 1;
        // switch(v4)
        v0 = 0;
        return v0;
        v1 = "android.os.IServiceManager";
        _result = v5.enforceInterface(v1); // android.os.Parcel.enforceInterface -> void
        _result = v5.readString(); // android.os.Parcel.readString -> java.lang.String
        v1 = _result;
        _result = v3.getService(v1); // android.os.ServiceManagerNative.getService -> android.os.IBinder
        v1 = _result;
        _result = v6.writeStrongBinder(v1); // android.os.Parcel.writeStrongBinder -> void
        // goto L_0005
        v0 = _exception;
        // goto L_0004
        v1 = "android.os.IServiceManager";
        _result = v5.enforceInterface(v1); // android.os.Parcel.enforceInterface -> void
        _result = v5.readString(); // android.os.Parcel.readString -> java.lang.String
        v1 = _result;
        _result = v3.checkService(v1); // android.os.ServiceManagerNative.checkService -> android.os.IBinder
        v1 = _result;
        _result = v6.writeStrongBinder(v1); // android.os.Parcel.writeStrongBinder -> void
        // goto L_0005
        v1 = "android.os.IServiceManager";
        _result = v5.enforceInterface(v1); // android.os.Parcel.enforceInterface -> void
        _result = v5.readString(); // android.os.Parcel.readString -> java.lang.String
        v1 = _result;
        _result = v5.readStrongBinder(); // android.os.Parcel.readStrongBinder -> android.os.IBinder
        v2 = _result;
        _result = v3.addService(v1, v2); // android.os.ServiceManagerNative.addService -> void
        // goto L_0005
        v1 = "android.os.IServiceManager";
        _result = v5.enforceInterface(v1); // android.os.Parcel.enforceInterface -> void
        _result = v3.listServices(); // android.os.ServiceManagerNative.listServices -> java.lang.String[]
        v1 = _result;
        _result = v6.writeStringArray(v1); // android.os.Parcel.writeStringArray -> void
        // goto L_0005
        v1 = "android.os.IServiceManager";
        _result = v5.enforceInterface(v1); // android.os.Parcel.enforceInterface -> void
        _result = v5.readStrongBinder(); // android.os.Parcel.readStrongBinder -> android.os.IBinder
        v1 = _result;
        _result = v1.asInterface(); // android.os.IPermissionController$Stub.asInterface -> android.os.IPermissionController
        v1 = _result;
        _result = v3.setPermissionController(v1); // android.os.ServiceManagerNative.setPermissionController -> void
        // goto L_0005
    }

}