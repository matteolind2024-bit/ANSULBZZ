package android.os;

/**
 * Original SourceFile: IVoIPCallbackInterface.java
 * Descriptor: Landroid/os/IVoIPCallbackInterface$Stub;
 */
public abstract class IVoIPCallbackInterface$Stub extends android.os.Binder implements android.os.IVoIPCallbackInterface {
    private static final java.lang.String DESCRIPTOR;
    static final int TRANSACTION_answerVoIPCall;
    static final int TRANSACTION_hangupVoIPCall;
    static final int TRANSACTION_holdVoIPCall;
    static final int TRANSACTION_moveVoIPToTop;
    static final int TRANSACTION_resumeVoIPCall;

    public IVoIPCallbackInterface$Stub() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // android.os.Binder.<init> -> void
        v0 = "android.os.IVoIPCallbackInterface";
        _result = v1.attachInterface(v1, v0); // android.os.IVoIPCallbackInterface$Stub.attachInterface -> void
        return;
    }

    public static android.os.IVoIPCallbackInterface asInterface(android.os.IBinder p0) {
        // Registers (3 total): v2 = p0 (android.os.IBinder)
        if (v2 != 0) /* goto L_0004 */;
        v0 = 0;
        return v0;
        v0 = "android.os.IVoIPCallbackInterface";
        _result = android.os.IBinder.queryLocalInterface(v2, v0); // -> android.os.IInterface
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        v1 = (v0 instanceof android.os.IVoIPCallbackInterface);
        if (v1 == 0) /* goto L_0014 */;
        v0 = (android.os.IVoIPCallbackInterface) v0;
        // goto L_0003
        v0 = new android.os.IVoIPCallbackInterface$Stub$Proxy;
        _result = v0.<init>(v2); // android.os.IVoIPCallbackInterface$Stub$Proxy.<init> -> void
        // goto L_0003
    }

    public android.os.IBinder asBinder() {
        // Registers (1 total): v0 = this
        return v0;
    }

    public boolean onTransact(int p0, android.os.Parcel p1, android.os.Parcel p2, int p3) {
        // Registers (8 total): v3 = this, v4 = p0 (int), v5 = p1 (android.os.Parcel), v6 = p2 (android.os.Parcel), v7 = p3 (int)
        v0 = 0;
        v1 = 1;
        // switch(v4)
        _result = v3.onTransact(v4, v5, v6, v7); // android.os.Binder.onTransact -> boolean
        v1 = _result;
        return v1;
        v0 = "android.os.IVoIPCallbackInterface";
        _result = v6.writeString(v0); // android.os.Parcel.writeString -> void
        // goto L_0009
        v2 = "android.os.IVoIPCallbackInterface";
        _result = v5.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v3.answerVoIPCall(); // android.os.IVoIPCallbackInterface$Stub.answerVoIPCall -> boolean
        v2 = _result;
        _result = v6.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0021 */;
        v0 = v1;
        _result = v6.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPCallbackInterface";
        _result = v5.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v3.hangupVoIPCall(); // android.os.IVoIPCallbackInterface$Stub.hangupVoIPCall -> boolean
        v2 = _result;
        _result = v6.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0035 */;
        v0 = v1;
        _result = v6.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPCallbackInterface";
        _result = v5.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v3.moveVoIPToTop(); // android.os.IVoIPCallbackInterface$Stub.moveVoIPToTop -> boolean
        v2 = _result;
        _result = v6.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0049 */;
        v0 = v1;
        _result = v6.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPCallbackInterface";
        _result = v5.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v3.holdVoIPCall(); // android.os.IVoIPCallbackInterface$Stub.holdVoIPCall -> boolean
        v2 = _result;
        _result = v6.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_005d */;
        v0 = v1;
        _result = v6.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPCallbackInterface";
        _result = v5.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v3.resumeVoIPCall(); // android.os.IVoIPCallbackInterface$Stub.resumeVoIPCall -> boolean
        v2 = _result;
        _result = v6.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0071 */;
        v0 = v1;
        _result = v6.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
    }

}