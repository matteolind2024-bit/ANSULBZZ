package android.os;

/**
 * Original SourceFile: IVoIPInterface.java
 * Descriptor: Landroid/os/IVoIPInterface$Stub;
 */
public abstract class IVoIPInterface$Stub extends android.os.Binder implements android.os.IVoIPInterface {
    private static final java.lang.String DESCRIPTOR;
    static final int TRANSACTION_answerVoIPCall;
    static final int TRANSACTION_callInVoIP;
    static final int TRANSACTION_canUseBTInVoIP;
    static final int TRANSACTION_createCallSession;
    static final int TRANSACTION_destroyCallSession;
    static final int TRANSACTION_dumpCallSessionInfoDB;
    static final int TRANSACTION_getCurrentVoIPNumber;
    static final int TRANSACTION_getSessionCount;
    static final int TRANSACTION_getVoIPCallCount;
    static final int TRANSACTION_hangupVoIPCall;
    static final int TRANSACTION_holdVoIPCall;
    static final int TRANSACTION_isVoIPActivated;
    static final int TRANSACTION_isVoIPDialing;
    static final int TRANSACTION_isVoIPIdle;
    static final int TRANSACTION_isVoIPRingOrDialing;
    static final int TRANSACTION_isVoIPRinging;
    static final int TRANSACTION_moveVoIPToTop;
    static final int TRANSACTION_resumeVoIPCall;
    static final int TRANSACTION_setBTUserWantsAudioOn;
    static final int TRANSACTION_setEngMode;
    static final int TRANSACTION_setUseBTInVoIP;
    static final int TRANSACTION_setVoIPActive;
    static final int TRANSACTION_setVoIPCallCount;
    static final int TRANSACTION_setVoIPDialing;
    static final int TRANSACTION_setVoIPDisconnected;
    static final int TRANSACTION_setVoIPDisconnecting;
    static final int TRANSACTION_setVoIPHolding;
    static final int TRANSACTION_setVoIPIdle;
    static final int TRANSACTION_setVoIPRinging;

    public IVoIPInterface$Stub() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // android.os.Binder.<init> -> void
        v0 = "android.os.IVoIPInterface";
        _result = v1.attachInterface(v1, v0); // android.os.IVoIPInterface$Stub.attachInterface -> void
        return;
    }

    public static android.os.IVoIPInterface asInterface(android.os.IBinder p0) {
        // Registers (3 total): v2 = p0 (android.os.IBinder)
        if (v2 != 0) /* goto L_0004 */;
        v0 = 0;
        return v0;
        v0 = "android.os.IVoIPInterface";
        _result = android.os.IBinder.queryLocalInterface(v2, v0); // -> android.os.IInterface
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        v1 = (v0 instanceof android.os.IVoIPInterface);
        if (v1 == 0) /* goto L_0014 */;
        v0 = (android.os.IVoIPInterface) v0;
        // goto L_0003
        v0 = new android.os.IVoIPInterface$Stub$Proxy;
        _result = v0.<init>(v2); // android.os.IVoIPInterface$Stub$Proxy.<init> -> void
        // goto L_0003
    }

    public android.os.IBinder asBinder() {
        // Registers (1 total): v0 = this
        return v0;
    }

    public boolean onTransact(int p0, android.os.Parcel p1, android.os.Parcel p2, int p3) {
        // Registers (11 total): v6 = this, v7 = p0 (int), v8 = p1 (android.os.Parcel), v9 = p2 (android.os.Parcel), v10 = p3 (int)
        v0 = 0;
        v1 = 1;
        // switch(v7)
        _result = v6.onTransact(v7, v8, v9, v10); // android.os.Binder.onTransact -> boolean
        v1 = _result;
        return v1;
        v0 = "android.os.IVoIPInterface";
        _result = v9.writeString(v0); // android.os.Parcel.writeString -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v3 = _result;
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v4 = _result;
        _result = v8.readStrongBinder(); // android.os.Parcel.readStrongBinder -> android.os.IBinder
        v5 = _result;
        _result = v5.asInterface(); // android.os.IVoIPCallbackInterface$Stub.asInterface -> android.os.IVoIPCallbackInterface
        v5 = _result;
        _result = v6.createCallSession(v2, v3, v4, v5); // android.os.IVoIPInterface$Stub.createCallSession -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0035 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v6.destroyCallSession(v2); // android.os.IVoIPInterface$Stub.destroyCallSession -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_004d */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v6.moveVoIPToTop(); // android.os.IVoIPInterface$Stub.moveVoIPToTop -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0061 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v6.answerVoIPCall(); // android.os.IVoIPInterface$Stub.answerVoIPCall -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0075 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v6.hangupVoIPCall(); // android.os.IVoIPInterface$Stub.hangupVoIPCall -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0089 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v6.holdVoIPCall(); // android.os.IVoIPInterface$Stub.holdVoIPCall -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_009e */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v6.resumeVoIPCall(); // android.os.IVoIPInterface$Stub.resumeVoIPCall -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_00b3 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v8.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        _result = v6.setVoIPCallCount(v2, v3); // android.os.IVoIPInterface$Stub.setVoIPCallCount -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_00d0 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v0 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v0); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        _result = v6.getVoIPCallCount(v0); // android.os.IVoIPInterface$Stub.getVoIPCallCount -> int
        v0 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v6.setVoIPIdle(v2); // android.os.IVoIPInterface$Stub.setVoIPIdle -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_00ff */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v6.setVoIPRinging(v2); // android.os.IVoIPInterface$Stub.setVoIPRinging -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0118 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v6.setVoIPDialing(v2); // android.os.IVoIPInterface$Stub.setVoIPDialing -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0131 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v6.setVoIPActive(v2); // android.os.IVoIPInterface$Stub.setVoIPActive -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_014a */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v6.setVoIPHolding(v2); // android.os.IVoIPInterface$Stub.setVoIPHolding -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0163 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v6.setVoIPDisconnecting(v2); // android.os.IVoIPInterface$Stub.setVoIPDisconnecting -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_017c */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v6.setVoIPDisconnected(v2); // android.os.IVoIPInterface$Stub.setVoIPDisconnected -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0195 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v3 = _result;
        _result = v8.readInt(); // android.os.Parcel.readInt -> int
        v2 = _result;
        if (v2 == 0) /* goto L_01ba */;
        v2 = v1;
        _result = v6.setUseBTInVoIP(v3, v2); // android.os.IVoIPInterface$Stub.setUseBTInVoIP -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_01b5 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = v0;
        // goto L_01ab
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v2 = _result;
        _result = v6.canUseBTInVoIP(v2); // android.os.IVoIPInterface$Stub.canUseBTInVoIP -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_01d0 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v8.readInt(); // android.os.Parcel.readInt -> int
        v2 = _result;
        if (v2 == 0) /* goto L_01f1 */;
        v2 = v1;
        _result = v6.setBTUserWantsAudioOn(v2); // android.os.IVoIPInterface$Stub.setBTUserWantsAudioOn -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_01ec */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = v0;
        // goto L_01e2
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v6.isVoIPIdle(); // android.os.IVoIPInterface$Stub.isVoIPIdle -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0203 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v6.isVoIPRingOrDialing(); // android.os.IVoIPInterface$Stub.isVoIPRingOrDialing -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0218 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v6.isVoIPRinging(); // android.os.IVoIPInterface$Stub.isVoIPRinging -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_022d */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v6.isVoIPDialing(); // android.os.IVoIPInterface$Stub.isVoIPDialing -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0242 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v2 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v2); // android.os.Parcel.enforceInterface -> void
        _result = v6.isVoIPActivated(); // android.os.IVoIPInterface$Stub.isVoIPActivated -> boolean
        v2 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        if (v2 == 0) /* goto L_0257 */;
        v0 = v1;
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v0 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v0); // android.os.Parcel.enforceInterface -> void
        _result = v6.getCurrentVoIPNumber(); // android.os.IVoIPInterface$Stub.getCurrentVoIPNumber -> java.lang.String
        v0 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        _result = v9.writeString(v0); // android.os.Parcel.writeString -> void
        // goto L_0009
        v0 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v0); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        _result = v6.callInVoIP(v0); // android.os.IVoIPInterface$Stub.callInVoIP -> void
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        // goto L_0009
        v0 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v0); // android.os.Parcel.enforceInterface -> void
        _result = v6.getSessionCount(); // android.os.IVoIPInterface$Stub.getSessionCount -> int
        v0 = _result;
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        _result = v9.writeInt(v0); // android.os.Parcel.writeInt -> void
        // goto L_0009
        v0 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v0); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        _result = v6.dumpCallSessionInfoDB(v0); // android.os.IVoIPInterface$Stub.dumpCallSessionInfoDB -> void
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        // goto L_0009
        v0 = "android.os.IVoIPInterface";
        _result = v8.enforceInterface(v0); // android.os.Parcel.enforceInterface -> void
        _result = v8.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        _result = v8.readInt(); // android.os.Parcel.readInt -> int
        v2 = _result;
        _result = v6.setEngMode(v0, v2); // android.os.IVoIPInterface$Stub.setEngMode -> void
        _result = v9.writeNoException(); // android.os.Parcel.writeNoException -> void
        // goto L_0009
    }

}