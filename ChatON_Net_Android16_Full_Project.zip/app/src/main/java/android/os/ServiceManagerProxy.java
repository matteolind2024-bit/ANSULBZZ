package android.os;

/**
 * Original SourceFile: ServiceManagerNative.java
 * Descriptor: Landroid/os/ServiceManagerProxy;
 */
class ServiceManagerProxy implements android.os.IServiceManager {
    private android.os.IBinder mRemote;

    public ServiceManagerProxy(android.os.IBinder p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.IBinder)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.mRemote = v1; // android.os.ServiceManagerProxy.mRemote:android.os.IBinder
        return;
    }

    public void addService(java.lang.String p0, android.os.IBinder p1) {
        // Registers (8 total): v5 = this, v6 = p0 (java.lang.String), v7 = p1 (android.os.IBinder)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v0 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        v2 = "android.os.IServiceManager";
        _result = v0.writeInterfaceToken(v2); // android.os.Parcel.writeInterfaceToken -> void
        _result = v0.writeString(v6); // android.os.Parcel.writeString -> void
        _result = v0.writeStrongBinder(v7); // android.os.Parcel.writeStrongBinder -> void
        v2 = v5.mRemote; // android.os.ServiceManagerProxy.mRemote:android.os.IBinder
        v3 = 3;
        v4 = 0;
        _result = android.os.IBinder.transact(v2, v3, v0, v1, v4); // -> boolean
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        _result = v0.recycle(); // android.os.Parcel.recycle -> void
        return;
    }

    public android.os.IBinder asBinder() {
        // Registers (2 total): v1 = this
        v0 = v1.mRemote; // android.os.ServiceManagerProxy.mRemote:android.os.IBinder
        return v0;
    }

    public android.os.IBinder checkService(java.lang.String p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.String)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v0 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        v2 = "android.os.IServiceManager";
        _result = v0.writeInterfaceToken(v2); // android.os.Parcel.writeInterfaceToken -> void
        _result = v0.writeString(v6); // android.os.Parcel.writeString -> void
        v2 = v5.mRemote; // android.os.ServiceManagerProxy.mRemote:android.os.IBinder
        v3 = 2;
        v4 = 0;
        _result = android.os.IBinder.transact(v2, v3, v0, v1, v4); // -> boolean
        _result = v1.readStrongBinder(); // android.os.Parcel.readStrongBinder -> android.os.IBinder
        v2 = _result;
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        _result = v0.recycle(); // android.os.Parcel.recycle -> void
        return v2;
    }

    public android.os.IBinder getService(java.lang.String p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.String)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v0 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        v2 = "android.os.IServiceManager";
        _result = v0.writeInterfaceToken(v2); // android.os.Parcel.writeInterfaceToken -> void
        _result = v0.writeString(v6); // android.os.Parcel.writeString -> void
        v2 = v5.mRemote; // android.os.ServiceManagerProxy.mRemote:android.os.IBinder
        v3 = 1;
        v4 = 0;
        _result = android.os.IBinder.transact(v2, v3, v0, v1, v4); // -> boolean
        _result = v1.readStrongBinder(); // android.os.Parcel.readStrongBinder -> android.os.IBinder
        v2 = _result;
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        _result = v0.recycle(); // android.os.Parcel.recycle -> void
        return v2;
    }

    public java.lang.String[] listServices() {
        // Registers (6 total): v5 = this
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v0 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        v2 = "android.os.IServiceManager";
        _result = v0.writeInterfaceToken(v2); // android.os.Parcel.writeInterfaceToken -> void
        v2 = v5.mRemote; // android.os.ServiceManagerProxy.mRemote:android.os.IBinder
        v3 = 4;
        v4 = 0;
        _result = android.os.IBinder.transact(v2, v3, v0, v1, v4); // -> boolean
        _result = v1.readStringArray(); // android.os.Parcel.readStringArray -> java.lang.String[]
        v2 = _result;
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        _result = v0.recycle(); // android.os.Parcel.recycle -> void
        return v2;
    }

    public void setPermissionController(android.os.IPermissionController p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.os.IPermissionController)
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v0 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        v2 = "android.os.IServiceManager";
        _result = v0.writeInterfaceToken(v2); // android.os.Parcel.writeInterfaceToken -> void
        _result = android.os.IPermissionController.asBinder(v6); // -> android.os.IBinder
        v2 = _result;
        _result = v0.writeStrongBinder(v2); // android.os.Parcel.writeStrongBinder -> void
        v2 = v5.mRemote; // android.os.ServiceManagerProxy.mRemote:android.os.IBinder
        v3 = 6;
        v4 = 0;
        _result = android.os.IBinder.transact(v2, v3, v0, v1, v4); // -> boolean
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        _result = v0.recycle(); // android.os.Parcel.recycle -> void
        return;
    }

}