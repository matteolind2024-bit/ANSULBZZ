package android.os;

/**
 * Original SourceFile: IVoIPCallbackInterface.java
 * Descriptor: Landroid/os/IVoIPCallbackInterface;
 */
public interface IVoIPCallbackInterface extends android.os.IInterface {
    public abstract boolean answerVoIPCall();
    public abstract boolean hangupVoIPCall();
    public abstract boolean holdVoIPCall();
    public abstract boolean moveVoIPToTop();
    public abstract boolean resumeVoIPCall();
}