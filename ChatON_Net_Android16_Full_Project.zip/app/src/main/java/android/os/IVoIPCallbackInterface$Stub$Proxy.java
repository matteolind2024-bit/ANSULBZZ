package android.os;

/**
 * Original SourceFile: IVoIPCallbackInterface.java
 * Descriptor: Landroid/os/IVoIPCallbackInterface$Stub$Proxy;
 */
class IVoIPCallbackInterface$Stub$Proxy implements android.os.IVoIPCallbackInterface {
    private android.os.IBinder mRemote;

    IVoIPCallbackInterface$Stub$Proxy(android.os.IBinder p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.IBinder)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.mRemote = v1; // android.os.IVoIPCallbackInterface$Stub$Proxy.mRemote:android.os.IBinder
        return;
    }

    public boolean answerVoIPCall() {
        // Registers (8 total): v7 = this
        v0 = 1;
        v1 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v3 = _result;
        v4 = "android.os.IVoIPCallbackInterface";
        _result = v2.writeInterfaceToken(v4); // android.os.Parcel.writeInterfaceToken -> void
        v4 = v7.mRemote; // android.os.IVoIPCallbackInterface$Stub$Proxy.mRemote:android.os.IBinder
        v5 = 1;
        v6 = 0;
        _result = android.os.IBinder.transact(v4, v5, v2, v3, v6); // -> boolean
        _result = v3.readException(); // android.os.Parcel.readException -> void
        _result = v3.readInt(); // android.os.Parcel.readInt -> int
        v4 = _result;
        if (v4 == 0) /* goto L_0027 */;
        _result = v3.recycle(); // android.os.Parcel.recycle -> void
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = v1;
        // goto L_0020
        v0 = _exception;
        _result = v3.recycle(); // android.os.Parcel.recycle -> void
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public android.os.IBinder asBinder() {
        // Registers (2 total): v1 = this
        v0 = v1.mRemote; // android.os.IVoIPCallbackInterface$Stub$Proxy.mRemote:android.os.IBinder
        return v0;
    }

    public java.lang.String getInterfaceDescriptor() {
        // Registers (2 total): v1 = this
        v0 = "android.os.IVoIPCallbackInterface";
        return v0;
    }

    public boolean hangupVoIPCall() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPCallbackInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPCallbackInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 2;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0020 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean holdVoIPCall() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPCallbackInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPCallbackInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 4;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0020 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean moveVoIPToTop() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPCallbackInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPCallbackInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 3;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0020 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

    public boolean resumeVoIPCall() {
        // Registers (7 total): v6 = this
        v0 = 0;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v1 = _result;
        _result = this.obtain(); // android.os.Parcel.obtain -> android.os.Parcel
        v2 = _result;
        v3 = "android.os.IVoIPCallbackInterface";
        _result = v1.writeInterfaceToken(v3); // android.os.Parcel.writeInterfaceToken -> void
        v3 = v6.mRemote; // android.os.IVoIPCallbackInterface$Stub$Proxy.mRemote:android.os.IBinder
        v4 = 5;
        v5 = 0;
        _result = android.os.IBinder.transact(v3, v4, v1, v2, v5); // -> boolean
        _result = v2.readException(); // android.os.Parcel.readException -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0020 */;
        v0 = 1;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        return v0;
        v0 = _exception;
        _result = v2.recycle(); // android.os.Parcel.recycle -> void
        _result = v1.recycle(); // android.os.Parcel.recycle -> void
        throw v0;
    }

}