package android.os;

/**
 * Original SourceFile: IVoIPInterface.java
 * Descriptor: Landroid/os/IVoIPInterface;
 */
public interface IVoIPInterface extends android.os.IInterface {
    public abstract boolean answerVoIPCall();
    public abstract void callInVoIP(java.lang.String p0);
    public abstract boolean canUseBTInVoIP(java.lang.String p0);
    public abstract boolean createCallSession(java.lang.String p0, java.lang.String p1, java.lang.String p2, android.os.IVoIPCallbackInterface p3);
    public abstract boolean destroyCallSession(java.lang.String p0);
    public abstract void dumpCallSessionInfoDB(java.lang.String p0);
    public abstract java.lang.String getCurrentVoIPNumber();
    public abstract int getSessionCount();
    public abstract int getVoIPCallCount(java.lang.String p0);
    public abstract boolean hangupVoIPCall();
    public abstract boolean holdVoIPCall();
    public abstract boolean isVoIPActivated();
    public abstract boolean isVoIPDialing();
    public abstract boolean isVoIPIdle();
    public abstract boolean isVoIPRingOrDialing();
    public abstract boolean isVoIPRinging();
    public abstract boolean moveVoIPToTop();
    public abstract boolean resumeVoIPCall();
    public abstract boolean setBTUserWantsAudioOn(boolean p0);
    public abstract void setEngMode(java.lang.String p0, int p1);
    public abstract boolean setUseBTInVoIP(java.lang.String p0, boolean p1);
    public abstract boolean setVoIPActive(java.lang.String p0);
    public abstract boolean setVoIPCallCount(java.lang.String p0, int p1);
    public abstract boolean setVoIPDialing(java.lang.String p0);
    public abstract boolean setVoIPDisconnected(java.lang.String p0);
    public abstract boolean setVoIPDisconnecting(java.lang.String p0);
    public abstract boolean setVoIPHolding(java.lang.String p0);
    public abstract boolean setVoIPIdle(java.lang.String p0);
    public abstract boolean setVoIPRinging(java.lang.String p0);
}