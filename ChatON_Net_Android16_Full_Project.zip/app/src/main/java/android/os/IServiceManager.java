package android.os;

/**
 * Original SourceFile: IServiceManager.java
 * Descriptor: Landroid/os/IServiceManager;
 */
public interface IServiceManager extends android.os.IInterface {
    public static final int ADD_SERVICE_TRANSACTION;
    public static final int CHECK_SERVICES_TRANSACTION;
    public static final int CHECK_SERVICE_TRANSACTION;
    public static final int GET_SERVICE_TRANSACTION;
    public static final int LIST_SERVICES_TRANSACTION;
    public static final int SET_PERMISSION_CONTROLLER_TRANSACTION;
    public static final java.lang.String descriptor;

    public abstract void addService(java.lang.String p0, android.os.IBinder p1);
    public abstract android.os.IBinder checkService(java.lang.String p0);
    public abstract android.os.IBinder getService(java.lang.String p0);
    public abstract java.lang.String[] listServices();
    public abstract void setPermissionController(android.os.IPermissionController p0);
}