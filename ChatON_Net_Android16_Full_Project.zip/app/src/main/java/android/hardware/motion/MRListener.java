package android.hardware.motion;

/**
 * Original SourceFile: MRListener.java
 * Descriptor: Landroid/hardware/motion/MRListener;
 */
public interface MRListener {
    public abstract void onMotionListener(android.hardware.motion.MREvent p0);
}