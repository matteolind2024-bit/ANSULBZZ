package android.hardware.motion;

/**
 * Original SourceFile: MREvent.java
 * Descriptor: Landroid/hardware/motion/MREvent;
 */
public class MREvent implements android.os.Parcelable {
    public static final int BLOW;
    public static final int BOUNCE;
    public static final int BT_SHARING_RECEIVE_NOT_READY;
    public static final int BT_SHARING_RECEIVE_READY;
    public static final int BT_SHARING_SEND_PAUSE;
    public static final int BT_SHARING_SEND_START;
    public static final int BT_SHARING_SEND_STOP;
    public static final int CALLPOSE_L;
    public static final int CALLPOSE_NONE;
    public static final int CALLPOSE_R;
    public static final android.os.Parcelable$Creator CREATOR;
    public static final int DIRECT_CALL;
    public static final int DIRECT_CALL_LEFT;
    public static final int DIRECT_CALL_RIGHT;
    public static final int FLAT;
    public static final int FLIP_BOTTOM_TO_TOP;
    public static final int FLIP_TOP_TO_BOTTOM;
    public static final int LCD_UP_STEADY;
    public static final int LOCK_EXECUTE_APP;
    public static final int LOCK_EXECUTE_CAMERA_L;
    public static final int LOCK_EXECUTE_CAMERA_R;
    public static final int MAX;
    public static final int NONE;
    public static final int ONE_TAPPING_GYRO;
    public static final int ONE_TIPPING_GYRO;
    public static final int PANNING_GYRO;
    public static final int REACTIVE_ALERT;
    public static final int ROTATE_0;
    public static final int ROTATE_180;
    public static final int ROTATE_270;
    public static final int ROTATE_90;
    public static final int ROTATE_HORIZONTAL;
    public static final int ROTATE_START;
    public static final int ROTATE_STOP;
    public static final int ROTATION_AXIS_X;
    public static final int ROTATION_AXIS_Y;
    public static final int ROTATION_AXIS_Z;
    public static final int SHAKE;
    public static final int SHAKE_START;
    public static final int SHAKE_STOP;
    public static final int SHORT_SHAKE;
    public static final int SHORT_SHAKE_START;
    public static final int SHORT_SHAKE_STOP;
    public static final int SMART_ALERT_SETTING;
    public static final int SMART_SCROLL_CAMERA_OFF;
    public static final int SMART_SCROLL_CAMERA_ON;
    public static final int SMART_SCROLL_TILT_DOWN_START;
    public static final int SMART_SCROLL_TILT_DOWN_START_LAND;
    public static final int SMART_SCROLL_TILT_FACE_IN_STOP;
    public static final int SMART_SCROLL_TILT_FACE_IN_STOP_LAND;
    public static final int SMART_SCROLL_TILT_FACE_OUT_STOP;
    public static final int SMART_SCROLL_TILT_FACE_OUT_STOP_LAND;
    public static final int SMART_SCROLL_TILT_UP_START;
    public static final int SMART_SCROLL_TILT_UP_START_LAND;
    public static final int SNAP1_X_NEGATIVE;
    public static final int SNAP1_X_POSITIVE;
    public static final int SNAP1_Y_NEGATIVE;
    public static final int SNAP1_Y_POSITIVE;
    public static final int SNAP1_Z_NEGATIVE;
    public static final int SNAP1_Z_POSITIVE;
    public static final int SNAP2_X_NEGATIVE;
    public static final int SNAP2_X_POSITIVE;
    public static final int SNAP2_Y_NEGATIVE;
    public static final int SNAP2_Y_POSITIVE;
    public static final int SNAP2_Z_NEGATIVE;
    public static final int SNAP2_Z_POSITIVE;
    public static final int SNAP_LEFT;
    public static final int SNAP_RIGHT;
    public static final int SNAP_X_NEGATIVE;
    public static final int SNAP_X_POSITIVE;
    public static final int SNAP_Y_NEGATIVE;
    public static final int SNAP_Y_POSITIVE;
    public static final int SNAP_Z_NEGATIVE;
    public static final int SNAP_Z_POSITIVE;
    public static final int SPEAKER_PHONE_OFF;
    public static final int SPEAKER_PHONE_ON;
    public static final int TILT;
    public static final int TILT_BACK;
    public static final int TILT_DOWN_LEVEL_1;
    public static final int TILT_DOWN_LEVEL_1_LAND;
    public static final int TILT_DOWN_LEVEL_2;
    public static final int TILT_DOWN_LEVEL_2_LAND;
    public static final int TILT_DOWN_LEVEL_3;
    public static final int TILT_DOWN_LEVEL_3_LAND;
    public static final int TILT_FRONT;
    public static final int TILT_FRONT_BACK_END;
    public static final int TILT_LANDSCAPE_LEFT_LEVEL_1;
    public static final int TILT_LANDSCAPE_LEFT_LEVEL_2;
    public static final int TILT_LANDSCAPE_LEFT_RIGHT_STOP;
    public static final int TILT_LANDSCAPE_RIGHT_LEVEL_1;
    public static final int TILT_LANDSCAPE_RIGHT_LEVEL_2;
    public static final int TILT_LEFT;
    public static final int TILT_LEFT_RIGHT_END;
    public static final int TILT_LEVEL_FLAT;
    public static final int TILT_LEVEL_ZERO;
    public static final int TILT_LEVEL_ZERO_LAND;
    public static final int TILT_PORTRAIT_BACK;
    public static final int TILT_PORTRAIT_FRONT;
    public static final int TILT_PORTRAIT_FRONT_BACK_STOP;
    public static final int TILT_PORTRAIT_LEFT;
    public static final int TILT_PORTRAIT_LEFT_RIGHT_STOP;
    public static final int TILT_PORTRAIT_RIGHT;
    public static final int TILT_RIGHT;
    public static final int TILT_TO_UNLOCK;
    public static final int TILT_TO_UNLOCK_LAND;
    public static final int TILT_UP_LEVEL_1;
    public static final int TILT_UP_LEVEL_1_LAND;
    public static final int TILT_UP_LEVEL_2;
    public static final int TILT_UP_LEVEL_2_LAND;
    public static final int TILT_UP_LEVEL_3;
    public static final int TILT_UP_LEVEL_3_LAND;
    public static final int TWO_TAPPING;
    public static final int TWO_TAPPING_GYRO;
    public static final int TWO_TIPPING_GYRO;
    public static final int VOLUMEDOWN;
    private int motion;
    private int panningDx;
    private int panningDxImage;
    private int panningDy;
    private int panningDyImage;
    private int panningDz;
    private int panningDzImage;
    private int tilt;
    private int walkingStatus;

    static {
        v0 = new android.hardware.motion.MREvent$1;
        _result = v0.<init>(); // android.hardware.motion.MREvent$1.<init> -> void
        android.hardware.motion.MREvent.CREATOR = v0; // :android.os.Parcelable$Creator
        return;
    }

    public MREvent() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v1.motion = v0; // android.hardware.motion.MREvent.motion:int
        v1.panningDx = v0; // android.hardware.motion.MREvent.panningDx:int
        v1.panningDy = v0; // android.hardware.motion.MREvent.panningDy:int
        v1.panningDz = v0; // android.hardware.motion.MREvent.panningDz:int
        v1.panningDxImage = v0; // android.hardware.motion.MREvent.panningDxImage:int
        v1.panningDyImage = v0; // android.hardware.motion.MREvent.panningDyImage:int
        v1.panningDzImage = v0; // android.hardware.motion.MREvent.panningDzImage:int
        v1.walkingStatus = v0; // android.hardware.motion.MREvent.walkingStatus:int
        return;
    }

    public MREvent(android.os.Parcel p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.Parcel)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        _result = v0.readFromParcel(v1); // android.hardware.motion.MREvent.readFromParcel -> void
        return;
    }

    public int describeContents() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public int getMotion() {
        // Registers (2 total): v1 = this
        v0 = v1.motion; // android.hardware.motion.MREvent.motion:int
        return v0;
    }

    public int getPanningDx() {
        // Registers (2 total): v1 = this
        v0 = v1.panningDx; // android.hardware.motion.MREvent.panningDx:int
        return v0;
    }

    public int getPanningDxImage() {
        // Registers (2 total): v1 = this
        v0 = v1.panningDxImage; // android.hardware.motion.MREvent.panningDxImage:int
        return v0;
    }

    public int getPanningDy() {
        // Registers (2 total): v1 = this
        v0 = v1.panningDy; // android.hardware.motion.MREvent.panningDy:int
        return v0;
    }

    public int getPanningDyImage() {
        // Registers (2 total): v1 = this
        v0 = v1.panningDyImage; // android.hardware.motion.MREvent.panningDyImage:int
        return v0;
    }

    public int getPanningDz() {
        // Registers (2 total): v1 = this
        v0 = v1.panningDz; // android.hardware.motion.MREvent.panningDz:int
        return v0;
    }

    public int getPanningDzImage() {
        // Registers (2 total): v1 = this
        v0 = v1.panningDzImage; // android.hardware.motion.MREvent.panningDzImage:int
        return v0;
    }

    public int getSmartMotion() {
        // Registers (2 total): v1 = this
        v0 = v1.panningDz; // android.hardware.motion.MREvent.panningDz:int
        return v0;
    }

    public int getTilt() {
        // Registers (2 total): v1 = this
        v0 = v1.tilt; // android.hardware.motion.MREvent.tilt:int
        return v0;
    }

    public int getWalkingStatus() {
        // Registers (2 total): v1 = this
        v0 = v1.walkingStatus; // android.hardware.motion.MREvent.walkingStatus:int
        return v0;
    }

    public void readFromParcel(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.motion = v0; // android.hardware.motion.MREvent.motion:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.panningDx = v0; // android.hardware.motion.MREvent.panningDx:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.panningDy = v0; // android.hardware.motion.MREvent.panningDy:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.panningDz = v0; // android.hardware.motion.MREvent.panningDz:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.panningDxImage = v0; // android.hardware.motion.MREvent.panningDxImage:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.panningDyImage = v0; // android.hardware.motion.MREvent.panningDyImage:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.panningDzImage = v0; // android.hardware.motion.MREvent.panningDzImage:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.tilt = v0; // android.hardware.motion.MREvent.tilt:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.walkingStatus = v0; // android.hardware.motion.MREvent.walkingStatus:int
        return;
    }

    public void setMotion(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        v1.motion = v0; // android.hardware.motion.MREvent.motion:int
        if (v2 < 0) /* goto L_000b */;
        v0 = 113;
        if (v2 > v0) /* goto L_000b */;
        v1.motion = v2; // android.hardware.motion.MREvent.motion:int
        return;
    }

    public void setPanningDx(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.panningDx = v1; // android.hardware.motion.MREvent.panningDx:int
        return;
    }

    public void setPanningDxImage(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.panningDxImage = v1; // android.hardware.motion.MREvent.panningDxImage:int
        return;
    }

    public void setPanningDy(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.panningDy = v1; // android.hardware.motion.MREvent.panningDy:int
        return;
    }

    public void setPanningDyImage(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.panningDyImage = v1; // android.hardware.motion.MREvent.panningDyImage:int
        return;
    }

    public void setPanningDz(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.panningDz = v1; // android.hardware.motion.MREvent.panningDz:int
        return;
    }

    public void setPanningDzImage(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.panningDzImage = v1; // android.hardware.motion.MREvent.panningDzImage:int
        return;
    }

    public void setTilt(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.tilt = v1; // android.hardware.motion.MREvent.tilt:int
        return;
    }

    public void setWalkingStatus(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.walkingStatus = v1; // android.hardware.motion.MREvent.walkingStatus:int
        return;
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = v3.motion; // android.hardware.motion.MREvent.motion:int
        _result = v1.toString(); // java.lang.Integer.toString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = v3.motion; // android.hardware.motion.MREvent.motion:int
        // switch(v1)
        _result = v0.trim(); // java.lang.String.trim -> java.lang.String
        v0 = _result;
        v1 = v3.motion; // android.hardware.motion.MREvent.motion:int
        v2 = 61;
        if (v1 != v2) /* goto L_0064 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " (";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.panningDx; // android.hardware.motion.MREvent.panningDx:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.panningDy; // android.hardware.motion.MREvent.panningDy:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.panningDz; // android.hardware.motion.MREvent.panningDz:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ")";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = v3.motion; // android.hardware.motion.MREvent.motion:int
        v2 = 72;
        if (v1 != v2) /* goto L_0098 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " (";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.tilt; // android.hardware.motion.MREvent.tilt:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "), walking status (";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.walkingStatus; // android.hardware.motion.MREvent.walkingStatus:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ")";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "NONE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TWO_TAPPING";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP_X_POSITIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP_X_NEGATIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP_Y_POSITIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP_Y_NEGATIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP_Z_POSITIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP_Z_NEGATIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SPEAKER_PHONE_ON";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SPEAKER_PHONE_OFF";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "FLIP_TOP_TO_BOTTOM";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_PORTRAIT_FRONT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_PORTRAIT_BACK";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_PORTRAIT_FRONT_BACK_STOP";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_PORTRAIT_LEFT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_PORTRAIT_RIGHT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_PORTRAIT_LEFT_RIGHT_STOP";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_LANDSCAPE_LEFT_LEVEL_1";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_LANDSCAPE_LEFT_LEVEL_2";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_LANDSCAPE_RIGHT_LEVEL_1";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_LANDSCAPE_RIGHT_LEVEL_2";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_LANDSCAPE_LEFT_RIGHT_STOP";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_FRONT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_BACK";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_FRONT_BACK_END";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_LEFT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_RIGHT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_LEFT_RIGHT_END";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "ROTATE_0";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "ROTATE_90";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "ROTATE_180";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "ROTATE_270";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "ROTATE_START";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "ROTATE_STOP";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SHAKE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SHAKE_START";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SHAKE_STOP";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SHORT_SHAKE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SHORT_SHAKE_START";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SHORT_SHAKE_STOP";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "BT_SHARING_RECEIVE_READY";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "BT_SHARING_RECEIVE_NOT_READY";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "BT_SHARING_SEND_START";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "BT_SHARING_SEND_PAUSE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "BT_SHARING_SEND_STOP";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "ROTATE_HORIZONTAL";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "BOUNCE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP1_X_POSITIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP1_X_NEGATIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP1_Y_POSITIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP1_Y_NEGATIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP1_Z_POSITIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP1_Z_NEGATIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP2_X_POSITIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP2_X_NEGATIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP2_Y_POSITIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP2_Y_NEGATIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP2_Z_POSITIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP2_Z_NEGATIVE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP_LEFT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SNAP_RIGHT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "PANNING_GYRO";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "ONE_TAPPING_GYRO";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TWO_TAPPING_GYRO";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "ONE_TIPPING_GYRO";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TWO_TIPPING_GYRO";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "BLOW";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "REACTIVE_ALERT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SMART_ALERT_SETTING";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "DIRECT_CALL";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "DIRECT_CALL_LEFT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "DIRECT_CALL_RIGHT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "LOCK_EXECUTE_APP";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "VOLUMEDOWN";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "FLAT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "LOCK_EXECUTE_CAMERA_L";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "LOCK_EXECUTE_CAMERA_R";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_TO_UNLOCK";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_TO_UNLOCK_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "CALLPOSE_L";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "CALLPOSE_R";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "CALLPOSE_NONE";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_UP_LEVEL_1";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_UP_LEVEL_2";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_UP_LEVEL_3";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_DOWN_LEVEL_1";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_DOWN_LEVEL_2";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_DOWN_LEVEL_3";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_LEVEL_ZERO";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_LEVEL_FLAT";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "FLIP_BOTTOM_TO_TOP";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_UP_LEVEL_1_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_UP_LEVEL_2_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_UP_LEVEL_3_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_DOWN_LEVEL_1_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_DOWN_LEVEL_2_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_DOWN_LEVEL_3_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "TILT_LEVEL_ZERO_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "LCD_UP_STEADY";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SMART_SCROLL_TILT_UP_START";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SMART_SCROLL_TILT_DOWN_START";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SMART_SCROLL_TILT_FACE_IN_STOP";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SMART_SCROLL_TILT_FACE_OUT_STOP";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SMART_SCROLL_TILT_UP_START_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SMART_SCROLL_TILT_DOWN_START_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SMART_SCROLL_TILT_FACE_IN_STOP_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SMART_SCROLL_TILT_FACE_OUT_STOP_LAND";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SMART_SCROLL_CAMERA_OFF";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "SMART_SCROLL_CAMERA_ON";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "MAX";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_001f
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (int)
        v0 = v1.motion; // android.hardware.motion.MREvent.motion:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v1.panningDx; // android.hardware.motion.MREvent.panningDx:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v1.panningDy; // android.hardware.motion.MREvent.panningDy:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v1.panningDz; // android.hardware.motion.MREvent.panningDz:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v1.panningDxImage; // android.hardware.motion.MREvent.panningDxImage:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v1.panningDyImage; // android.hardware.motion.MREvent.panningDyImage:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v1.panningDzImage; // android.hardware.motion.MREvent.panningDzImage:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v1.tilt; // android.hardware.motion.MREvent.tilt:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v1.walkingStatus; // android.hardware.motion.MREvent.walkingStatus:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        return;
    }

}