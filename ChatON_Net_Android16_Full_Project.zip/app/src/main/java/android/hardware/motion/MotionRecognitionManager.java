package android.hardware.motion;

/**
 * Original SourceFile: MotionRecognitionManager.java
 * Descriptor: Landroid/hardware/motion/MotionRecognitionManager;
 */
public class MotionRecognitionManager {
    public static final java.lang.String ACTION_MOTION_RECOGNITION_EVENT;
    private static final int DEBUG_LEVEL_HIGH;
    private static final int DEBUG_LEVEL_LOW;
    private static final int DEBUG_LEVEL_MID;
    public static final int EVENT_ALL;
    public static final int EVENT_CALL_POSE;
    public static final int EVENT_DIRECT_CALLING;
    public static final int EVENT_DOUBLE_TAP;
    public static final int EVENT_FLAT;
    public static final int EVENT_LCD_UP_STEADY;
    public static final int EVENT_LOCK_EXECUTE_L;
    public static final int EVENT_LOCK_EXECUTE_R;
    public static final int EVENT_NUM;
    public static final int EVENT_OVER_TURN;
    public static final int EVENT_OVER_TURN_LOW_POWER;
    public static final int EVENT_PANNING_GALLERY;
    public static final int EVENT_PANNING_HOME;
    public static final int EVENT_REACTIVE_ALERT;
    public static final int EVENT_SHAKE;
    public static final int EVENT_SMART_ALERT_SETTING;
    public static final int EVENT_SMART_SCROLL;
    public static final int EVENT_TILT;
    public static final int EVENT_TILT_LEVEL_ZERO;
    public static final int EVENT_TILT_LEVEL_ZERO_LAND;
    public static final int EVENT_TILT_TO_UNLOCK;
    public static final int EVENT_VOLUME_DOWN;
    public static final int MOTION_SENSOR_NUM;
    public static final int MOTION_USE_ACC;
    public static final int MOTION_USE_ALL;
    public static final int MOTION_USE_GYRO;
    public static final int MOTION_USE_LIGHT;
    public static final int MOTION_USE_MOVEMENT;
    public static final int MOTION_USE_PROX;
    private static final java.lang.String TAG;
    private static final boolean localLOGV;
    private static final int mMotionVersion;
     android.os.Looper mMainLooper;
    private int mMovementCnt;
    private android.hardware.scontext.SContextManager mSContextManager;
    public boolean mSSPEnabled;
    private android.hardware.motion.IMotionRecognitionService motionService;
    private final android.hardware.scontext.SContextListener mySContextMotionListener;
    private final java.util.ArrayList sListenerDelegates;
    private final java.util.ArrayList sListenerwithSSP;

    public MotionRecognitionManager(android.os.Looper p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Looper)
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v3.sListenerDelegates = v0; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v3.sListenerwithSSP = v0; // android.hardware.motion.MotionRecognitionManager.sListenerwithSSP:java.util.ArrayList
        v0 = new android.hardware.motion.MotionRecognitionManager$1;
        _result = v0.<init>(v3); // android.hardware.motion.MotionRecognitionManager$1.<init> -> void
        v3.mySContextMotionListener = v0; // android.hardware.motion.MotionRecognitionManager.mySContextMotionListener:android.hardware.scontext.SContextListener
        v0 = "motion_recognition";
        _result = v0.getService(); // android.os.ServiceManager.getService -> android.os.IBinder
        v0 = _result;
        _result = v0.asInterface(); // android.hardware.motion.IMotionRecognitionService$Stub.asInterface -> android.hardware.motion.IMotionRecognitionService
        v0 = _result;
        v3.motionService = v0; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        v3.mMainLooper = v4; // android.hardware.motion.MotionRecognitionManager.mMainLooper:android.os.Looper
        v0 = new android.hardware.scontext.SContextManager;
        v1 = v3.mMainLooper; // android.hardware.motion.MotionRecognitionManager.mMainLooper:android.os.Looper
        _result = v0.<init>(v1); // android.hardware.scontext.SContextManager.<init> -> void
        v3.mSContextManager = v0; // android.hardware.motion.MotionRecognitionManager.mSContextManager:android.hardware.scontext.SContextManager
        v0 = 0;
        v3.mMovementCnt = v0; // android.hardware.motion.MotionRecognitionManager.mMovementCnt:int
        v0 = v3.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        _result = android.hardware.motion.IMotionRecognitionService.getSSPstatus(v0); // -> boolean
        v0 = _result;
        v3.mSSPEnabled = v0; // android.hardware.motion.MotionRecognitionManager.mSSPEnabled:boolean
        return;
        v0 = _exception;
        v1 = "MotionRecognitionManager";
        v2 = "RemoteException in getSSPstatus: ";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_003b
    }

    protected static java.lang.String EncodeLog(java.lang.String p0) {
        // Registers (3 total): v2 = p0 (java.lang.String)
        v0 = "ro.debug_level";
        v1 = "Unknown";
        _result = v0.get(v1); // android.os.SystemProperties.get -> java.lang.String
        v0 = _result;
        v1 = "Unknown";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0017 */;
        v2 = " ";
        return v2;
        v1 = 2;
        _result = v0.substring(v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        v1 = 16;
        _result = v0.parseInt(v1); // java.lang.Integer.parseInt -> int
        v0 = _result;
        v1 = 20300;
        if (v0 != v1) /* goto L_002f */;
        v2 = " ";
        // goto L_0016
        v0 = _exception;
        v2 = " ";
        // goto L_0016
        v1 = 18765;
        if (v0 == v1) /* goto L_0016 */;
        v1 = 18760;
        if (v0 == v1) /* goto L_0016 */;
        v2 = " ";
        // goto L_0016
    }

    static android.hardware.motion.IMotionRecognitionService access$000(android.hardware.motion.MotionRecognitionManager p0) {
        // Registers (2 total): v1 = p0 (android.hardware.motion.MotionRecognitionManager)
        v0 = v1.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        return v0;
    }

    static java.util.ArrayList access$100(android.hardware.motion.MotionRecognitionManager p0) {
        // Registers (2 total): v1 = p0 (android.hardware.motion.MotionRecognitionManager)
        v0 = v1.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        return v0;
    }

    public static int getMotionVersion() {
        v0 = 1;
        return v0;
    }

    public static boolean isValidMotionSensor(int p0) {
        // Registers (3 total): v2 = p0 (int)
        v0 = 1;
        if (v2 == v0) /* goto L_000d */;
        v1 = 2;
        if (v2 == v1) /* goto L_000d */;
        v1 = 4;
        if (v2 == v1) /* goto L_000d */;
        v1 = 8;
        if (v2 != v1) /* goto L_000e */;
        return v0;
        v0 = 0;
        // goto L_000d
    }

    public void registerListener(android.hardware.motion.MRListener p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.hardware.motion.MRListener)
        v0 = 0;
        v1 = 0;
        _result = v2.registerListener(v3, v0, v1); // android.hardware.motion.MotionRecognitionManager.registerListener -> void
        return;
    }

    public void registerListener(android.hardware.motion.MRListener p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.hardware.motion.MRListener), v3 = p1 (int)
        v0 = 0;
        _result = v1.registerListener(v2, v3, v0); // android.hardware.motion.MotionRecognitionManager.registerListener -> void
        return;
    }

    public void registerListener(android.hardware.motion.MRListener p0, int p1, android.os.Handler p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.hardware.motion.MRListener), v4 = p1 (int), v5 = p2 (android.os.Handler)
        v0 = 0;
        v1 = binOpLit8_0xdd(v4, 1);
        if (v1 == 0) /* goto L_0008 */;
        v0 = 237570; // 0x0003a002
        v1 = binOpLit8_0xdd(v4, 2);
        if (v1 == 0) /* goto L_000e */;
        v0 = binOpLit16_0xd6(v0, 20985);
        v1 = binOpLit8_0xdd(v4, 4);
        if (v1 == 0) /* goto L_0014 */;
        v0 = binOpLit16_0xd6(v0, 3072);
        _result = v2.registerListenerEvent(v3, v0, v5); // android.hardware.motion.MotionRecognitionManager.registerListenerEvent -> void
        return;
    }

    public void registerListener(android.hardware.motion.MRListener p0, android.os.Handler p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.hardware.motion.MRListener), v3 = p1 (android.os.Handler)
        v0 = 0;
        _result = v1.registerListener(v2, v0, v3); // android.hardware.motion.MotionRecognitionManager.registerListener -> void
        return;
    }

    public void registerListenerEvent(android.hardware.motion.MRListener p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.hardware.motion.MRListener), v3 = p1 (int)
        v0 = 0;
        _result = v1.registerListenerEvent(v2, v3, v0); // android.hardware.motion.MotionRecognitionManager.registerListenerEvent -> void
        return;
    }

    public void registerListenerEvent(android.hardware.motion.MRListener p0, int p1, android.os.Handler p2) {
        // Registers (10 total): v6 = this, v7 = p0 (android.hardware.motion.MRListener), v8 = p1 (int), v9 = p2 (android.os.Handler)
        v0 = 0;
        if (v7 == 0) /* goto L_0061 */;
        v2 = v6.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        // monitor-enter(v2)
        v1 = v6.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v3 = _result;
        v1 = v0;
        if (v1 >= v3) /* goto L_0066 */;
        v0 = v6.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.hardware.motion.MotionRecognitionManager$MRListenerDelegate) v0;
        _result = v0.getListener(); // android.hardware.motion.MotionRecognitionManager$MRListenerDelegate.getListener -> android.hardware.motion.MRListener
        v0 = _result;
        if (v0 != v7) /* goto L_0062 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "name :";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.EncodeLog(); // android.hardware.motion.MotionRecognitionManager.EncodeLog -> java.lang.String
        v0 = _result;
        v1 = "MotionRecognitionManager";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "  .registerListenerEvent : fail. already registered / listener count = ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = v6.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v4.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ", ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.d(v0); // android.util.Log.d -> int
        // monitor-exit(v2)
        return;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_000d
        v1 = new android.hardware.motion.MotionRecognitionManager$MRListenerDelegate;
        _result = v1.<init>(v6, v7, v8, v9); // android.hardware.motion.MotionRecognitionManager$MRListenerDelegate.<init> -> void
        v0 = v6.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xdd(v8, 4);
        if (v0 == 0) /* goto L_0143 */;
        v0 = v6.mSSPEnabled; // android.hardware.motion.MotionRecognitionManager.mSSPEnabled:boolean
        v4 = 1;
        if (v0 != v4) /* goto L_010c */;
        v0 = v6.mySContextMotionListener; // android.hardware.motion.MotionRecognitionManager.mySContextMotionListener:android.hardware.scontext.SContextListener
        if (v0 == 0) /* goto L_00f7 */;
        v0 = v6.mMovementCnt; // android.hardware.motion.MotionRecognitionManager.mMovementCnt:int
        if (v0 != 0) /* goto L_00f7 */;
        v0 = "MotionRecognitionManager";
        v1 = " [MOVEMENT_SERVICE] registerListener ";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v6.mSContextManager; // android.hardware.motion.MotionRecognitionManager.mSContextManager:android.hardware.scontext.SContextManager
        v1 = v6.mySContextMotionListener; // android.hardware.motion.MotionRecognitionManager.mySContextMotionListener:android.hardware.scontext.SContextListener
        v4 = 5;
        _result = v0.registerListener(v1, v4); // android.hardware.scontext.SContextManager.registerListener -> boolean
        v0 = v6.mMovementCnt; // android.hardware.motion.MotionRecognitionManager.mMovementCnt:int
        v0 = binOpLit8_0xd8(v0, 1);
        v6.mMovementCnt = v0; // android.hardware.motion.MotionRecognitionManager.mMovementCnt:int
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "name :";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.EncodeLog(); // android.hardware.motion.MotionRecognitionManager.EncodeLog -> java.lang.String
        v0 = _result;
        v1 = "MotionRecognitionManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "  .registerListenerEvent : success. listener count = ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = "->";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = v6.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v4.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ", motion_events=";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ", ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.v(v0); // android.util.Log.v -> int
        // monitor-exit(v2)
        // goto L_0061
        v0 = _exception;
        // monitor-exit(v2)
        throw v0;
        v0 = "MotionRecognitionManager";
        v1 = " [MOVEMENT_SERVICE] registerListener : fail. already registered ";
        _result = v0.e(v1); // android.util.Log.e -> int
        // goto L_0092
        v0 = _exception;
        v1 = "MotionRecognitionManager";
        v4 = "RemoteException in registerListenerEvent: ";
        _result = v1.e(v4, v0); // android.util.Log.e -> int
        // goto L_0098
        v0 = v6.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        _result = android.hardware.motion.IMotionRecognitionService.getSSPstatus(v0); // -> boolean
        v0 = _result;
        v6.mSSPEnabled = v0; // android.hardware.motion.MotionRecognitionManager.mSSPEnabled:boolean
        v0 = "MotionRecognitionManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "SSP disabled : ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = v6.mSSPEnabled; // android.hardware.motion.MotionRecognitionManager.mSSPEnabled:boolean
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v0.d(v4); // android.util.Log.d -> int
        v0 = v6.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        v4 = 0;
        _result = android.hardware.motion.IMotionRecognitionService.registerCallback(v0, v1, v4, v8); // -> void
        // goto L_0098
        v0 = _exception;
        v4 = "MotionRecognitionManager";
        v5 = "RemoteException in getSSPstatus: ";
        _result = v4.e(v5, v0); // android.util.Log.e -> int
        // goto L_0114
        v0 = v6.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        v4 = 0;
        _result = android.hardware.motion.IMotionRecognitionService.registerCallback(v0, v1, v4, v8); // -> void
        // goto L_0098
    }

    public int resetMotionEngine() {
        // Registers (4 total): v3 = this
        v0 = v3.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        _result = android.hardware.motion.IMotionRecognitionService.resetMotionEngine(v0); // -> int
        v0 = _result;
        return v0;
        v0 = _exception;
        v1 = "MotionRecognitionManager";
        v2 = "RemoteException in resetMotionEngine: ";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        v0 = 0;
        // goto L_0006
    }

    public void setLogPath(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        v0 = v3.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        _result = android.hardware.motion.IMotionRecognitionService.setLogPath(v0, v4); // -> void
        return;
        v0 = _exception;
        v1 = "MotionRecognitionManager";
        v2 = "RemoteException in setLogPath: ";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_0005
    }

    public void setMotionAngle(android.hardware.motion.MRListener p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.hardware.motion.MRListener), v2 = p1 (int)
        return;
    }

    public void setMotionTiltLevel(int p0, int p1, int p2, int p3, int p4, int p5) {
        // Registers (14 total): v7 = this, v8 = p0 (int), v9 = p1 (int), v10 = p2 (int), v11 = p3 (int), v12 = p4 (int), v13 = p5 (int)
        v0 = v7.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        v1 = v8;
        v2 = v9;
        v3 = v10;
        v4 = v11;
        v5 = v12;
        v6 = v13;
        _result = android.hardware.motion.IMotionRecognitionService.setMotionTiltLevel(v0..v6); // -> void
        v0 = "MotionRecognitionManager";
        v1 = "  .setMotionTiltLevel : 1";
        _result = v0.d(v1); // android.util.Log.d -> int
        return;
        v0 = _exception;
        v1 = "MotionRecognitionManager";
        v2 = "RemoteException in setMotionTiltLevel: ";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_000b
    }

    public void setSmartMotionAngle(android.hardware.motion.MRListener p0, int p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.hardware.motion.MRListener), v7 = p1 (int)
        v2 = v5.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        // monitor-enter(v2)
        v0 = v5.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v3 = _result;
        v0 = 0;
        v1 = v0;
        if (v1 >= v3) /* goto L_0034 */;
        v0 = v5.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.hardware.motion.MotionRecognitionManager$MRListenerDelegate) v0;
        _result = v0.getListener(); // android.hardware.motion.MotionRecognitionManager$MRListenerDelegate.getListener -> android.hardware.motion.MRListener
        v4 = _result;
        if (v4 != v6) /* goto L_0030 */;
        v1 = v5.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        _result = android.hardware.motion.IMotionRecognitionService.setMotionAngle(v1, v0, v7); // -> void
        // monitor-exit(v2)
        return;
        v0 = _exception;
        v1 = "MotionRecognitionManager";
        v3 = "RemoteException in setSmartMotionAngle: ";
        _result = v1.e(v3, v0); // android.util.Log.e -> int
        // goto L_0020
        v0 = _exception;
        // monitor-exit(v2)
        throw v0;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_000b
        v0 = "MotionRecognitionManager";
        v1 = "  .setSmartMotionAngle : listener has to be registered first";
        _result = v0.d(v1); // android.util.Log.d -> int
        // monitor-exit(v2)
        // goto L_0021
    }

    public void unregisterListener(android.hardware.motion.MRListener p0) {
        // Registers (10 total): v8 = this, v9 = p0 (android.hardware.motion.MRListener)
        v1 = 0;
        v3 = v8.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        // monitor-enter(v3)
        v0 = v8.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        v2 = v1;
        if (v2 >= v4) /* goto L_004d */;
        v0 = v8.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.hardware.motion.MotionRecognitionManager$MRListenerDelegate) v0;
        _result = v0.getListener(); // android.hardware.motion.MotionRecognitionManager$MRListenerDelegate.getListener -> android.hardware.motion.MRListener
        v0 = _result;
        _result = v0.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        v5 = "MotionRecognitionManager";
        v6 = new java.lang.StringBuilder;
        _result = v6.<init>(); // java.lang.StringBuilder.<init> -> void
        v7 = "@ member ";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v7 = " = ";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v0.EncodeLog(); // android.hardware.motion.MotionRecognitionManager.EncodeLog -> java.lang.String
        v0 = _result;
        _result = v6.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v5.d(v0); // android.util.Log.d -> int
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_000b
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        if (v1 >= v4) /* goto L_00a9 */;
        v0 = v8.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.hardware.motion.MotionRecognitionManager$MRListenerDelegate) v0;
        _result = v0.getListener(); // android.hardware.motion.MotionRecognitionManager$MRListenerDelegate.getListener -> android.hardware.motion.MRListener
        v2 = _result;
        if (v2 != v9) /* goto L_004a */;
        v2 = v8.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v2.remove(v1); // java.util.ArrayList.remove -> java.lang.Object
        _result = v0.getMotionEvents(); // android.hardware.motion.MotionRecognitionManager$MRListenerDelegate.getMotionEvents -> int
        v1 = _result;
        v1 = binOpLit8_0xdd(v1, 4);
        if (v1 == 0) /* goto L_013d */;
        v1 = v8.mSSPEnabled; // android.hardware.motion.MotionRecognitionManager.mSSPEnabled:boolean
        v2 = 1;
        if (v1 != v2) /* goto L_00f9 */;
        v0 = v8.mMovementCnt; // android.hardware.motion.MotionRecognitionManager.mMovementCnt:int
        v0 = binOpLit8_0xd8(v0, -1);
        v8.mMovementCnt = v0; // android.hardware.motion.MotionRecognitionManager.mMovementCnt:int
        v0 = v8.mMovementCnt; // android.hardware.motion.MotionRecognitionManager.mMovementCnt:int
        if (v0 > 0) /* goto L_008d */;
        v0 = "MotionRecognitionManager";
        v1 = " [MOVEMENT_SERVICE] unregisterListener ";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = 0;
        v8.mMovementCnt = v0; // android.hardware.motion.MotionRecognitionManager.mMovementCnt:int
        v0 = v8.mSContextManager; // android.hardware.motion.MotionRecognitionManager.mSContextManager:android.hardware.scontext.SContextManager
        v1 = v8.mySContextMotionListener; // android.hardware.motion.MotionRecognitionManager.mySContextMotionListener:android.hardware.scontext.SContextListener
        v2 = 5;
        _result = v0.unregisterListener(v1, v2); // android.hardware.scontext.SContextManager.unregisterListener -> void
        v0 = "MotionRecognitionManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "unregisterListener - mMovementCnt : ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v8.mMovementCnt; // android.hardware.motion.MotionRecognitionManager.mMovementCnt:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "name :";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.EncodeLog(); // android.hardware.motion.MotionRecognitionManager.EncodeLog -> java.lang.String
        v0 = _result;
        v1 = "MotionRecognitionManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "  .unregisterListener : / listener count = ";
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v4 = "->";
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v4 = v8.sListenerDelegates; // android.hardware.motion.MotionRecognitionManager.sListenerDelegates:java.util.ArrayList
        _result = v4.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v4 = ", ";
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.i(v0); // android.util.Log.i -> int
        // monitor-exit(v3)
        return;
        v1 = v8.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        _result = android.hardware.motion.IMotionRecognitionService.getSSPstatus(v1); // -> boolean
        v1 = _result;
        v8.mSSPEnabled = v1; // android.hardware.motion.MotionRecognitionManager.mSSPEnabled:boolean
        v1 = "MotionRecognitionManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "SSP disabled : ";
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v5 = v8.mSSPEnabled; // android.hardware.motion.MotionRecognitionManager.mSSPEnabled:boolean
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.d(v2); // android.util.Log.d -> int
        v1 = v8.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        _result = android.hardware.motion.IMotionRecognitionService.unregisterCallback(v1, v0); // -> void
        // goto L_00a9
        v0 = _exception;
        v1 = "MotionRecognitionManager";
        v2 = "RemoteException in unregisterListener: ";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_00a9
        v0 = _exception;
        // monitor-exit(v3)
        throw v0;
        v1 = _exception;
        v2 = "MotionRecognitionManager";
        v5 = "RemoteException in getSSPstatus: ";
        _result = v2.e(v5, v1); // android.util.Log.e -> int
        // goto L_0101
        v1 = v8.motionService; // android.hardware.motion.MotionRecognitionManager.motionService:android.hardware.motion.IMotionRecognitionService
        _result = android.hardware.motion.IMotionRecognitionService.unregisterCallback(v1, v0); // -> void
        // goto L_00a9
    }

    public void useMotionAlways(android.hardware.motion.MRListener p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.hardware.motion.MRListener), v2 = p1 (boolean)
        return;
    }

}