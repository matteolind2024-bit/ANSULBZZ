package android.support.v4.c;

/**
 * Original SourceFile: ArrayMap.java
 * Descriptor: Landroid/support/v4/c/b;
 */
class b extends android.support.v4.c.g {
    final android.support.v4.c.a a;

    b(android.support.v4.c.a p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.c.a)
        v0.a = v1; // android.support.v4.c.b.a:android.support.v4.c.a
        _result = v0.<init>(); // android.support.v4.c.g.<init> -> void
        return;
    }

    protected int a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.b.a:android.support.v4.c.a
        v0 = v0.h; // android.support.v4.c.a.h:int
        return v0;
    }

    protected int a(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        if (v3 != 0) /* goto L_0009 */;
        v0 = v2.a; // android.support.v4.c.b.a:android.support.v4.c.a
        _result = v0.a(); // android.support.v4.c.a.a -> int
        v0 = _result;
        return v0;
        v0 = v2.a; // android.support.v4.c.b.a:android.support.v4.c.a
        _result = v3.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        _result = v0.a(v3, v1); // android.support.v4.c.a.a -> int
        v0 = _result;
        // goto L_0008
    }

    protected java.lang.Object a(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v0 = v2.a; // android.support.v4.c.b.a:android.support.v4.c.a
        v0 = v0.g; // android.support.v4.c.a.g:java.lang.Object[]
        v1 = binOpLit8_0xe0(v3, 1);
        v1 = binOp2addr_0xb0(v1, v4);
        v0 = v0[v1];
        return v0;
    }

    protected java.lang.Object a(int p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (java.lang.Object)
        v0 = v1.a; // android.support.v4.c.b.a:android.support.v4.c.a
        _result = v0.a(v2, v3); // android.support.v4.c.a.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    protected void a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // android.support.v4.c.b.a:android.support.v4.c.a
        _result = v0.d(v2); // android.support.v4.c.a.d -> java.lang.Object
        return;
    }

    protected void a(java.lang.Object p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (java.lang.Object)
        v0 = v1.a; // android.support.v4.c.b.a:android.support.v4.c.a
        _result = v0.put(v2, v3); // android.support.v4.c.a.put -> java.lang.Object
        return;
    }

    protected int b(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = v1.a; // android.support.v4.c.b.a:android.support.v4.c.a
        _result = v0.a(v2); // android.support.v4.c.a.a -> int
        v0 = _result;
        return v0;
    }

    protected java.util.Map b() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.b.a:android.support.v4.c.a
        return v0;
    }

    protected void c() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.b.a:android.support.v4.c.a
        _result = v0.clear(); // android.support.v4.c.a.clear -> void
        return;
    }

}