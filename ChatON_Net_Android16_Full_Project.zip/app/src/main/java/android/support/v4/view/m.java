package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompatJellyBean.java
 * Descriptor: Landroid/support/v4/view/m;
 */
public interface m {
    public abstract java.lang.Object a(android.view.View p0);
    public abstract void a(android.view.View p0, int p1);
    public abstract void a(android.view.View p0, java.lang.Object p1);
    public abstract boolean a(android.view.View p0, int p1, android.os.Bundle p2);
    public abstract boolean a(android.view.View p0, android.view.accessibility.AccessibilityEvent p1);
    public abstract boolean a(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2);
    public abstract void b(android.view.View p0, android.view.accessibility.AccessibilityEvent p1);
    public abstract void c(android.view.View p0, android.view.accessibility.AccessibilityEvent p1);
    public abstract void d(android.view.View p0, android.view.accessibility.AccessibilityEvent p1);
}