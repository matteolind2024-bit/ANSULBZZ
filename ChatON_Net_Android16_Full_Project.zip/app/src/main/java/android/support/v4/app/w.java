package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/w;
 */
public abstract class w {
    public w() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public abstract android.support.v4.app.Fragment$SavedState a(android.support.v4.app.Fragment p0);
    public abstract android.support.v4.app.Fragment a(int p0);
    public abstract android.support.v4.app.Fragment a(android.os.Bundle p0, java.lang.String p1);
    public abstract android.support.v4.app.Fragment a(java.lang.String p0);
    public abstract android.support.v4.app.aj a();
    public abstract void a(int p0, int p1);
    public abstract void a(android.os.Bundle p0, java.lang.String p1, android.support.v4.app.Fragment p2);
    public abstract boolean b();
    public abstract java.util.List c();
}