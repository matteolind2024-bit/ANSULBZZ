package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/ar;
 */
public class ar {
    private static final android.support.v4.app.ax a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.app.bb;
        _result = v0.<init>(); // android.support.v4.app.bb.<init> -> void
        android.support.v4.app.ar.a = v0; // :android.support.v4.app.ax
        return;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_001c */;
        v0 = new android.support.v4.app.ba;
        _result = v0.<init>(); // android.support.v4.app.ba.<init> -> void
        android.support.v4.app.ar.a = v0; // :android.support.v4.app.ax
        // goto L_000d
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_002a */;
        v0 = new android.support.v4.app.az;
        _result = v0.<init>(); // android.support.v4.app.az.<init> -> void
        android.support.v4.app.ar.a = v0; // :android.support.v4.app.ax
        // goto L_000d
        v0 = new android.support.v4.app.ay;
        _result = v0.<init>(); // android.support.v4.app.ay.<init> -> void
        android.support.v4.app.ar.a = v0; // :android.support.v4.app.ax
        // goto L_000d
    }

    static android.support.v4.app.ax a() {
        v0 = android.support.v4.app.ar.a; // :android.support.v4.app.ax
        return v0;
    }

}