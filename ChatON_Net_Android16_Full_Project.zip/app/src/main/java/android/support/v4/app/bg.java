package android.support.v4.app;

/**
 * Original SourceFile: SuperNotCalledException.java
 * Descriptor: Landroid/support/v4/app/bg;
 */
final class bg extends android.util.AndroidRuntimeException {
    public bg(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        _result = v0.<init>(v1); // android.util.AndroidRuntimeException.<init> -> void
        return;
    }

}