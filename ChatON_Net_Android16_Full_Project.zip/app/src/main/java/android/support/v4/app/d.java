package android.support.v4.app;

/**
 * Original SourceFile: ActionBarDrawerToggle.java
 * Descriptor: Landroid/support/v4/app/d;
 */
class d implements android.support.v4.app.c {
    private d() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    d(android.support.v4.app.b p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.b)
        _result = v0.<init>(); // android.support.v4.app.d.<init> -> void
        return;
    }

    public android.graphics.drawable.Drawable a(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 0;
        return v0;
    }

    public java.lang.Object a(java.lang.Object p0, android.app.Activity p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.app.Activity), v3 = p2 (int)
        return v1;
    }

}