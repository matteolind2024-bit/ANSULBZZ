package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/u;
 */
abstract class u implements java.util.concurrent.Callable {
     java.lang.Object[] b;

    private u() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    u(android.support.v4.content.n p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.content.n)
        _result = v0.<init>(); // android.support.v4.content.u.<init> -> void
        return;
    }

}