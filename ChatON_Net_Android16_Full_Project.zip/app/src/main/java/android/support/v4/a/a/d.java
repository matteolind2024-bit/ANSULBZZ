package android.support.v4.a.a;

/**
 * Original SourceFile: DrawableCompat.java
 * Descriptor: Landroid/support/v4/a/a/d;
 */
class d extends android.support.v4.a.a.b {
    d() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.a.a.b.<init> -> void
        return;
    }

}