package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/au;
 */
class au implements android.support.v4.view.bc {
    au() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int a(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 2;
        return v0;
    }

    long a() {
        // Registers (3 total): v2 = this
        v0 = 10L;
        return v0;
    }

    public void a(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (13 total): v7 = this, v8 = p0 (android.view.View), v9 = p1 (int), v10 = p2 (int), v11 = p3 (int), v12 = p4 (int)
        _result = v7.a(); // android.support.v4.view.au.a -> long
        v1 = _result;
        v0 = v8;
        v3 = v9;
        v4 = v10;
        v5 = v11;
        v6 = v12;
        _result = v0.postInvalidateDelayed(v0..v6); // android.view.View.postInvalidateDelayed -> void
        return;
    }

    public void a(android.view.View p0, int p1, android.graphics.Paint p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int), v3 = p2 (android.graphics.Paint)
        return;
    }

    public void a(android.view.View p0, android.graphics.Paint p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.graphics.Paint)
        return;
    }

    public void a(android.view.View p0, android.support.v4.view.a p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.support.v4.view.a)
        return;
    }

    public void a(android.view.View p0, java.lang.Runnable p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (java.lang.Runnable)
        _result = v2.a(); // android.support.v4.view.au.a -> long
        v0 = _result;
        _result = v3.postDelayed(v4, v0, v1); // android.view.View.postDelayed -> boolean
        return;
    }

    public boolean a(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

    public void b(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        _result = v2.a(); // android.support.v4.view.au.a -> long
        v0 = _result;
        _result = v3.postInvalidateDelayed(v0, v1); // android.view.View.postInvalidateDelayed -> void
        return;
    }

    public void b(android.view.View p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int)
        return;
    }

    public int c(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 0;
        return v0;
    }

    public int d(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 0;
        return v0;
    }

    public int e(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 0;
        return v0;
    }

    public android.view.ViewParent f(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v0 = _result;
        return v0;
    }

    public boolean g(android.view.View p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.View)
        v0 = 0;
        _result = v4.getBackground(); // android.view.View.getBackground -> android.graphics.drawable.Drawable
        v1 = _result;
        if (v1 == 0) /* goto L_000f */;
        _result = v1.getOpacity(); // android.graphics.drawable.Drawable.getOpacity -> int
        v1 = _result;
        v2 = -1;
        if (v1 != v2) /* goto L_000f */;
        v0 = 1;
        return v0;
    }

}