package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/ab;
 */
class ab implements android.view.animation.Animation$AnimationListener {
    final android.support.v4.app.Fragment a;
    final android.support.v4.app.y b;

    ab(android.support.v4.app.y p0, android.support.v4.app.Fragment p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.app.y), v2 = p1 (android.support.v4.app.Fragment)
        v0.b = v1; // android.support.v4.app.ab.b:android.support.v4.app.y
        v0.a = v2; // android.support.v4.app.ab.a:android.support.v4.app.Fragment
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onAnimationEnd(android.view.animation.Animation p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.view.animation.Animation)
        v3 = 0;
        v0 = v6.a; // android.support.v4.app.ab.a:android.support.v4.app.Fragment
        v0 = v0.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        if (v0 == 0) /* goto L_0019 */;
        v0 = v6.a; // android.support.v4.app.ab.a:android.support.v4.app.Fragment
        v1 = 0;
        v0.mAnimatingAway = v1; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        v0 = v6.b; // android.support.v4.app.ab.b:android.support.v4.app.y
        v1 = v6.a; // android.support.v4.app.ab.a:android.support.v4.app.Fragment
        v2 = v6.a; // android.support.v4.app.ab.a:android.support.v4.app.Fragment
        v2 = v2.mStateAfterAnimating; // android.support.v4.app.Fragment.mStateAfterAnimating:int
        v4 = v3;
        v5 = v3;
        _result = v0.a(v0..v5); // android.support.v4.app.y.a -> void
        return;
    }

    public void onAnimationRepeat(android.view.animation.Animation p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.animation.Animation)
        return;
    }

    public void onAnimationStart(android.view.animation.Animation p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.animation.Animation)
        return;
    }

}