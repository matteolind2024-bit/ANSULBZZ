package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/bc;
 */
public abstract class bc {
     java.lang.CharSequence d;
     java.lang.CharSequence e;
     boolean f;

    public bc() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v1.f = v0; // android.support.v4.app.bc.f:boolean
        return;
    }

}