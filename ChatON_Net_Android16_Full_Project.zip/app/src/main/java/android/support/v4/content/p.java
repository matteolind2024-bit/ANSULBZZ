package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/p;
 */
class p extends java.util.concurrent.FutureTask {
    final android.support.v4.content.m a;

    p(android.support.v4.content.m p0, java.util.concurrent.Callable p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.content.m), v2 = p1 (java.util.concurrent.Callable)
        v0.a = v1; // android.support.v4.content.p.a:android.support.v4.content.m
        _result = v0.<init>(v2); // java.util.concurrent.FutureTask.<init> -> void
        return;
    }

    protected void done() {
        // Registers (4 total): v3 = this
        _result = v3.get(); // android.support.v4.content.p.get -> java.lang.Object
        v0 = _result;
        v1 = v3.a; // android.support.v4.content.p.a:android.support.v4.content.m
        _result = v1.b(v0); // android.support.v4.content.m.b -> void
        return;
        v0 = _exception;
        v1 = "AsyncTask";
        _result = v1.w(v0); // android.util.Log.w -> int
        // goto L_0009
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "An error occured while executing doInBackground()";
        _result = v0.getCause(); // java.util.concurrent.ExecutionException.getCause -> java.lang.Throwable
        v0 = _result;
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
        v0 = _exception;
        v0 = v3.a; // android.support.v4.content.p.a:android.support.v4.content.m
        v1 = 0;
        _result = v0.b(v1); // android.support.v4.content.m.b -> void
        // goto L_0009
        v0 = _exception;
        v1 = new java.lang.RuntimeException;
        v2 = "An error occured while executing doInBackground()";
        _result = v1.<init>(v2, v0); // java.lang.RuntimeException.<init> -> void
        throw v1;
    }

}