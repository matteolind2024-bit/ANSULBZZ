package android.support.v4.app;

/**
 * Original SourceFile: BackStackRecord.java
 * Descriptor: Landroid/support/v4/app/m;
 */
final class m {
     android.support.v4.app.m a;
     android.support.v4.app.m b;
     int c;
     android.support.v4.app.Fragment d;
     int e;
     int f;
     int g;
     int h;
     java.util.ArrayList i;

    m() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}