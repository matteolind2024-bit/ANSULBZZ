package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeProviderCompat.java
 * Descriptor: Landroid/support/v4/view/a/q;
 */
class q implements android.support.v4.view.a.l {
    q() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.lang.Object a(android.support.v4.view.a.k p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.a.k)
        v0 = 0;
        return v0;
    }

}