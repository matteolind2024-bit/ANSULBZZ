package android.support.v4.widget;

/**
 * Original SourceFile: ScrollerCompat.java
 * Descriptor: Landroid/support/v4/widget/v;
 */
class v implements android.support.v4.widget.u {
    v() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.lang.Object a(android.content.Context p0, android.view.animation.Interpolator p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.view.animation.Interpolator)
        if (v3 == 0) /* goto L_0008 */;
        v0 = new android.widget.Scroller;
        _result = v0.<init>(v2, v3); // android.widget.Scroller.<init> -> void
        return v0;
        v0 = new android.widget.Scroller;
        _result = v0.<init>(v2); // android.widget.Scroller.<init> -> void
        // goto L_0007
    }

    public void a(java.lang.Object p0, int p1, int p2, int p3, int p4, int p5) {
        // Registers (13 total): v6 = this, v7 = p0 (java.lang.Object), v8 = p1 (int), v9 = p2 (int), v10 = p3 (int), v11 = p4 (int), v12 = p5 (int)
        v0 = v7;
        v0 = (android.widget.Scroller) v0;
        v1 = v8;
        v2 = v9;
        v3 = v10;
        v4 = v11;
        v5 = v12;
        _result = v0.startScroll(v0..v5); // android.widget.Scroller.startScroll -> void
        return;
    }

    public boolean a(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v2 = (android.widget.Scroller) v2;
        _result = v2.isFinished(); // android.widget.Scroller.isFinished -> boolean
        v0 = _result;
        return v0;
    }

    public int b(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v2 = (android.widget.Scroller) v2;
        _result = v2.getCurrX(); // android.widget.Scroller.getCurrX -> int
        v0 = _result;
        return v0;
    }

    public int c(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v2 = (android.widget.Scroller) v2;
        _result = v2.getCurrY(); // android.widget.Scroller.getCurrY -> int
        v0 = _result;
        return v0;
    }

    public boolean d(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v2 = (android.widget.Scroller) v2;
        _result = v2.computeScrollOffset(); // android.widget.Scroller.computeScrollOffset -> boolean
        v0 = _result;
        return v0;
    }

    public void e(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        v1 = (android.widget.Scroller) v1;
        _result = v1.abortAnimation(); // android.widget.Scroller.abortAnimation -> void
        return;
    }

    public int f(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v2 = (android.widget.Scroller) v2;
        _result = v2.getFinalX(); // android.widget.Scroller.getFinalX -> int
        v0 = _result;
        return v0;
    }

    public int g(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v2 = (android.widget.Scroller) v2;
        _result = v2.getFinalY(); // android.widget.Scroller.getFinalY -> int
        v0 = _result;
        return v0;
    }

}