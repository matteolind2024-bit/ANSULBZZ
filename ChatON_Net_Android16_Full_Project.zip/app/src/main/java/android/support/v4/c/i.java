package android.support.v4.c;

/**
 * Original SourceFile: MapCollections.java
 * Descriptor: Landroid/support/v4/c/i;
 */
final class i implements java.util.Set {
    final android.support.v4.c.g a;

    i(android.support.v4.c.g p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.c.g)
        v0.a = v1; // android.support.v4.c.i.a:android.support.v4.c.g
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean a(java.util.Map$Entry p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.Map$Entry)
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public boolean add(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v2 = (java.util.Map$Entry) v2;
        _result = v1.a(v2); // android.support.v4.c.i.a -> boolean
        v0 = _result;
        return v0;
    }

    public boolean addAll(java.util.Collection p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.util.Collection)
        v0 = v5.a; // android.support.v4.c.i.a:android.support.v4.c.g
        _result = v0.a(); // android.support.v4.c.g.a -> int
        v1 = _result;
        _result = java.util.Collection.iterator(v6); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0024 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        v3 = v5.a; // android.support.v4.c.i.a:android.support.v4.c.g
        _result = java.util.Map$Entry.getKey(v0); // -> java.lang.Object
        v4 = _result;
        _result = java.util.Map$Entry.getValue(v0); // -> java.lang.Object
        v0 = _result;
        _result = v3.a(v4, v0); // android.support.v4.c.g.a -> void
        // goto L_000a
        v0 = v5.a; // android.support.v4.c.i.a:android.support.v4.c.g
        _result = v0.a(); // android.support.v4.c.g.a -> int
        v0 = _result;
        if (v1 == v0) /* goto L_002e */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_002d
    }

    public void clear() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.i.a:android.support.v4.c.g
        _result = v0.c(); // android.support.v4.c.g.c -> void
        return;
    }

    public boolean contains(java.lang.Object p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.Object)
        v0 = 0;
        v1 = (v4 instanceof java.util.Map$Entry);
        if (v1 != 0) /* goto L_0006 */;
        return v0;
        v4 = (java.util.Map$Entry) v4;
        v1 = v3.a; // android.support.v4.c.i.a:android.support.v4.c.g
        _result = java.util.Map$Entry.getKey(v4); // -> java.lang.Object
        v2 = _result;
        _result = v1.a(v2); // android.support.v4.c.g.a -> int
        v1 = _result;
        if (v1 < 0) /* goto L_0005 */;
        v0 = v3.a; // android.support.v4.c.i.a:android.support.v4.c.g
        v2 = 1;
        _result = v0.a(v1, v2); // android.support.v4.c.g.a -> java.lang.Object
        v0 = _result;
        _result = java.util.Map$Entry.getValue(v4); // -> java.lang.Object
        v1 = _result;
        _result = v0.a(v1); // android.support.v4.c.c.a -> boolean
        v0 = _result;
        // goto L_0005
    }

    public boolean containsAll(java.util.Collection p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.util.Collection)
        _result = java.util.Collection.iterator(v3); // -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0016 */;
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v1 = _result;
        _result = v2.contains(v1); // android.support.v4.c.i.contains -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0004 */;
        v0 = 0;
        return v0;
        v0 = 1;
        // goto L_0015
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v1.a(v2); // android.support.v4.c.g.a -> boolean
        v0 = _result;
        return v0;
    }

    public int hashCode() {
        // Registers (7 total): v6 = this
        v1 = 0;
        v0 = v6.a; // android.support.v4.c.i.a:android.support.v4.c.g
        _result = v0.a(); // android.support.v4.c.g.a -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v3 = v0;
        v4 = v1;
        if (v3 < 0) /* goto L_0033 */;
        v0 = v6.a; // android.support.v4.c.i.a:android.support.v4.c.g
        _result = v0.a(v3, v1); // android.support.v4.c.g.a -> java.lang.Object
        v0 = _result;
        v2 = v6.a; // android.support.v4.c.i.a:android.support.v4.c.g
        v5 = 1;
        _result = v2.a(v3, v5); // android.support.v4.c.g.a -> java.lang.Object
        v5 = _result;
        if (v0 != 0) /* goto L_0028 */;
        v2 = v1;
        if (v5 != 0) /* goto L_002e */;
        v0 = v1;
        v0 = binOp2addr_0xb7(v0, v2);
        v2 = binOp_0x90(v4, v0);
        v0 = binOpLit8_0xd8(v3, -1);
        v3 = v0;
        v4 = v2;
        // goto L_000b
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        v2 = v0;
        // goto L_001d
        _result = v5.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        // goto L_0020
        return v4;
    }

    public boolean isEmpty() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.i.a:android.support.v4.c.g
        _result = v0.a(); // android.support.v4.c.g.a -> int
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.util.Iterator iterator() {
        // Registers (3 total): v2 = this
        v0 = new android.support.v4.c.k;
        v1 = v2.a; // android.support.v4.c.i.a:android.support.v4.c.g
        _result = v0.<init>(v1); // android.support.v4.c.k.<init> -> void
        return v0;
    }

    public boolean remove(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public boolean removeAll(java.util.Collection p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.Collection)
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public boolean retainAll(java.util.Collection p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.Collection)
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public int size() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.i.a:android.support.v4.c.g
        _result = v0.a(); // android.support.v4.c.g.a -> int
        v0 = _result;
        return v0;
    }

    public java.lang.Object[] toArray() {
        // Registers (2 total): v1 = this
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public java.lang.Object[] toArray(java.lang.Object[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object[])
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

}