package android.support.v4.c;

/**
 * Original SourceFile: TimeUtils.java
 * Descriptor: Landroid/support/v4/c/o;
 */
public class o {
    private static final java.lang.Object a;
    private static char[] b;

    static {
        v0 = new java.lang.Object;
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        android.support.v4.c.o.a = v0; // :java.lang.Object
        v0 = 24;
        v0 = new char[][size=v0];
        android.support.v4.c.o.b = v0; // :char[]
        return;
    }

    private static int a(int p0, int p1, boolean p2, int p3) {
        // Registers (5 total): v1 = p0 (int), v2 = p1 (int), v3 = p2 (boolean), v4 = p3 (int)
        v0 = 99;
        if (v1 > v0) /* goto L_0009 */;
        if (v3 == 0) /* goto L_000c */;
        v0 = 3;
        if (v4 < v0) /* goto L_000c */;
        v0 = binOpLit8_0xd8(v2, 3);
        return v0;
        v0 = 9;
        if (v1 > v0) /* goto L_0015 */;
        if (v3 == 0) /* goto L_0018 */;
        v0 = 2;
        if (v4 < v0) /* goto L_0018 */;
        v0 = binOpLit8_0xd8(v2, 2);
        // goto L_000b
        if (v3 != 0) /* goto L_001c */;
        if (v1 <= 0) /* goto L_001f */;
        v0 = binOpLit8_0xd8(v2, 1);
        // goto L_000b
        v0 = 0;
        // goto L_000b
    }

    private static int a(long p0, int p1) {
        // Registers (21 total): v18 = p0 (long), v20 = p1 (int)
        v2 = android.support.v4.c.o.b; // :char[]
        v2 = v2.length;
        v0 = v20;
        if (v2 >= v0) /* goto L_000d */;
        v0 = v20;
        v2 = new char[][size=v0];
        android.support.v4.c.o.b = v2; // :char[]
        v2 = android.support.v4.c.o.b; // :char[]
        v3 = 0L;
        v3 = cmp(v18, v3);
        if (v3 != 0) /* goto L_0025 */;
        v3 = 0;
        v4 = binOpLit8_0xd8(v20, -1);
        if (v3 >= v4) /* goto L_001f */;
        v5 = 32;
        v2[v3] = v5;
        // goto L_0018
        v4 = 48;
        v2[v3] = v4;
        v2 = 1;
        return v2;
        v3 = 0L;
        v3 = cmp(v18, v3);
        if (v3 <= 0) /* goto L_00b1 */;
        v3 = 43;
        v4 = v3;
        v5 = 1000L;
        v5 = binOp_0x9f(v18, v5);
        v0 = unaryOp_0x84(v5);
        v16 = v0;
        v5 = 1000L;
        v5 = binOp_0x9e(v18, v5);
        v5 = unaryOp_0x86(v5);
        _result = v5.floor(v6); // java.lang.Math.floor -> double
        v5 = _result;
        v7 = unaryOp_0x8a(v5);
        v3 = 0;
        v6 = 0;
        v5 = 0;
        v8 = 86400; // 0x00015180
        if (v7 <= v8) /* goto L_0051 */;
        v3 = 86400; // 0x00015180
        v3 = binOp_0x93(v7, v3);
        v8 = 86400; // 0x00015180
        v8 = binOp2addr_0xb2(v8, v3);
        v7 = binOp2addr_0xb1(v7, v8);
        v8 = 3600;
        if (v7 <= v8) /* goto L_012a */;
        v6 = binOpLit16_0xd3(v7, 3600);
        v8 = binOpLit16_0xd2(v6, 3600);
        v7 = binOp2addr_0xb1(v7, v8);
        v15 = v6;
        v6 = v7;
        v7 = 60;
        if (v6 <= v7) /* goto L_0126 */;
        v5 = binOpLit8_0xdb(v6, 60);
        v7 = binOpLit8_0xda(v5, 60);
        v6 = binOp2addr_0xb1(v6, v7);
        v13 = v5;
        v14 = v6;
        v6 = 0;
        if (v20 == 0) /* goto L_00c3 */;
        v5 = 1;
        v7 = 0;
        v8 = 0;
        _result = v3.a(v5, v7, v8); // android.support.v4.c.o.a -> int
        v7 = _result;
        v8 = 1;
        if (v7 <= 0) /* goto L_00bb */;
        v5 = 1;
        v9 = 2;
        _result = v15.a(v8, v5, v9); // android.support.v4.c.o.a -> int
        v5 = _result;
        v7 = binOp2addr_0xb0(v7, v5);
        v8 = 1;
        if (v7 <= 0) /* goto L_00bd */;
        v5 = 1;
        v9 = 2;
        _result = v13.a(v8, v5, v9); // android.support.v4.c.o.a -> int
        v5 = _result;
        v7 = binOp2addr_0xb0(v7, v5);
        v8 = 1;
        if (v7 <= 0) /* goto L_00bf */;
        v5 = 1;
        v9 = 2;
        _result = v14.a(v8, v5, v9); // android.support.v4.c.o.a -> int
        v5 = _result;
        v7 = binOp2addr_0xb0(v7, v5);
        v8 = 2;
        v9 = 1;
        if (v7 <= 0) /* goto L_00c1 */;
        v5 = 3;
        v0 = v16;
        _result = v0.a(v8, v9, v5); // android.support.v4.c.o.a -> int
        v5 = _result;
        v5 = binOpLit8_0xd8(v5, 1);
        v5 = binOp2addr_0xb0(v5, v7);
        v17 = v5;
        v5 = v6;
        v6 = v17;
        v0 = v20;
        if (v6 >= v0) /* goto L_00c4 */;
        v7 = 32;
        v2[v5] = v7;
        v7 = binOpLit8_0xd8(v5, 1);
        v5 = binOpLit8_0xd8(v6, 1);
        v6 = v5;
        v5 = v7;
        // goto L_00a2
        v3 = 45;
        v0 = v18;
        v0 = unaryOp_0x7d(v0);
        v18 = v0;
        v4 = v3;
        // goto L_002e
        v5 = 0;
        // goto L_0075
        v5 = 0;
        // goto L_007f
        v5 = 0;
        // goto L_0089
        v5 = 0;
        // goto L_0094
        v5 = v6;
        v2[v5] = v4;
        v5 = binOpLit8_0xd8(v5, 1);
        if (v20 == 0) /* goto L_0115 */;
        v4 = 1;
        v12 = v4;
        v4 = 100;
        v6 = 0;
        v7 = 0;
        _result = v2.a(v2..v7); // android.support.v4.c.o.a -> int
        v9 = _result;
        v8 = 104;
        if (v9 == v5) /* goto L_0118 */;
        v10 = 1;
        if (v12 == 0) /* goto L_011a */;
        v11 = 2;
        v6 = v2;
        v7 = v15;
        _result = v6.a(v6..v11); // android.support.v4.c.o.a -> int
        v9 = _result;
        v8 = 109;
        if (v9 == v5) /* goto L_011c */;
        v10 = 1;
        if (v12 == 0) /* goto L_011e */;
        v11 = 2;
        v6 = v2;
        v7 = v13;
        _result = v6.a(v6..v11); // android.support.v4.c.o.a -> int
        v9 = _result;
        v8 = 115;
        if (v9 == v5) /* goto L_0120 */;
        v10 = 1;
        if (v12 == 0) /* goto L_0122 */;
        v11 = 2;
        v6 = v2;
        v7 = v14;
        _result = v6.a(v6..v11); // android.support.v4.c.o.a -> int
        v8 = _result;
        v4 = 109;
        v6 = 1;
        if (v12 == 0) /* goto L_0124 */;
        if (v8 == v5) /* goto L_0124 */;
        v7 = 3;
        v3 = v16;
        v5 = v8;
        _result = v2.a(v2..v7); // android.support.v4.c.o.a -> int
        v3 = _result;
        v4 = 115;
        v2[v3] = v4;
        v2 = binOpLit8_0xd8(v3, 1);
        // goto L_0024
        v4 = 0;
        v12 = v4;
        // goto L_00cc
        v10 = 0;
        // goto L_00d9
        v11 = 0;
        // goto L_00dc
        v10 = 0;
        // goto L_00e7
        v11 = 0;
        // goto L_00ea
        v10 = 0;
        // goto L_00f5
        v11 = 0;
        // goto L_00f8
        v7 = 0;
        // goto L_0106
        v13 = v5;
        v14 = v6;
        // goto L_0067
        v15 = v6;
        v6 = v7;
        // goto L_005c
    }

    private static int a(char[] p0, int p1, char p2, int p3, boolean p4, int p5) {
        // Registers (10 total): v4 = p0 (char[]), v5 = p1 (int), v6 = p2 (char), v7 = p3 (int), v8 = p4 (boolean), v9 = p5 (int)
        if (v8 != 0) /* goto L_0004 */;
        if (v5 <= 0) /* goto L_003c */;
        if (v8 == 0) /* goto L_0009 */;
        v0 = 3;
        if (v9 >= v0) /* goto L_000d */;
        v0 = 99;
        if (v5 <= v0) /* goto L_003d */;
        v1 = binOpLit8_0xdb(v5, 100);
        v0 = binOpLit8_0xd8(v1, 48);
        v0 = unaryOp_0x8e(v0);
        v4[v7] = v0;
        v0 = binOpLit8_0xd8(v7, 1);
        v1 = binOpLit8_0xda(v1, 100);
        v1 = binOp_0x91(v5, v1);
        if (v8 == 0) /* goto L_001f */;
        v2 = 2;
        if (v9 >= v2) /* goto L_0025 */;
        v2 = 9;
        if (v1 > v2) /* goto L_0025 */;
        if (v7 == v0) /* goto L_0031 */;
        v2 = binOpLit8_0xdb(v1, 10);
        v3 = binOpLit8_0xd8(v2, 48);
        v3 = unaryOp_0x8e(v3);
        v4[v0] = v3;
        v0 = binOpLit8_0xd8(v0, 1);
        v2 = binOpLit8_0xda(v2, 10);
        v1 = binOp2addr_0xb1(v1, v2);
        v1 = binOpLit8_0xd8(v1, 48);
        v1 = unaryOp_0x8e(v1);
        v4[v0] = v1;
        v0 = binOpLit8_0xd8(v0, 1);
        v4[v0] = v6;
        v7 = binOpLit8_0xd8(v0, 1);
        return v7;
        v0 = v7;
        v1 = v5;
        // goto L_001a
    }

    public static void a(long p0, long p1, java.io.PrintWriter p2) {
        // Registers (8 total): v3 = p0 (long), v5 = p1 (long), v7 = p2 (java.io.PrintWriter)
        v0 = 0L;
        v0 = cmp(v3, v0);
        if (v0 != 0) /* goto L_000d */;
        v0 = "--";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        return;
        v0 = binOp_0x9c(v3, v5);
        v2 = 0;
        _result = v0.a(v1, v7, v2); // android.support.v4.c.o.a -> void
        // goto L_000c
    }

    public static void a(long p0, java.io.PrintWriter p1) {
        // Registers (4 total): v1 = p0 (long), v3 = p1 (java.io.PrintWriter)
        v0 = 0;
        _result = v1.a(v2, v3, v0); // android.support.v4.c.o.a -> void
        return;
    }

    public static void a(long p0, java.io.PrintWriter p1, int p2) {
        // Registers (9 total): v5 = p0 (long), v7 = p1 (java.io.PrintWriter), v8 = p2 (int)
        v1 = android.support.v4.c.o.a; // :java.lang.Object
        // monitor-enter(v1)
        _result = v5.a(v6, v8); // android.support.v4.c.o.a -> int
        v0 = _result;
        v2 = new java.lang.String;
        v3 = android.support.v4.c.o.b; // :char[]
        v4 = 0;
        _result = v2.<init>(v3, v4, v0); // java.lang.String.<init> -> void
        _result = v7.print(v2); // java.io.PrintWriter.print -> void
        // monitor-exit(v1)
        return;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

}