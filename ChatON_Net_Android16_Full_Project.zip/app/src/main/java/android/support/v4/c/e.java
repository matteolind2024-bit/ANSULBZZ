package android.support.v4.c;

/**
 * Original SourceFile: LogWriter.java
 * Descriptor: Landroid/support/v4/c/e;
 */
public class e extends java.io.Writer {
    private final java.lang.String a;
    private java.lang.StringBuilder b;

    public e(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        _result = v2.<init>(); // java.io.Writer.<init> -> void
        v0 = new java.lang.StringBuilder;
        v1 = 128;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v2.b = v0; // android.support.v4.c.e.b:java.lang.StringBuilder
        v2.a = v3; // android.support.v4.c.e.a:java.lang.String
        return;
    }

    private void a() {
        // Registers (4 total): v3 = this
        v0 = v3.b; // android.support.v4.c.e.b:java.lang.StringBuilder
        _result = v0.length(); // java.lang.StringBuilder.length -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_001f */;
        v0 = v3.a; // android.support.v4.c.e.a:java.lang.String
        v1 = v3.b; // android.support.v4.c.e.b:java.lang.StringBuilder
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = v3.b; // android.support.v4.c.e.b:java.lang.StringBuilder
        v1 = 0;
        v2 = v3.b; // android.support.v4.c.e.b:java.lang.StringBuilder
        _result = v2.length(); // java.lang.StringBuilder.length -> int
        v2 = _result;
        _result = v0.delete(v1, v2); // java.lang.StringBuilder.delete -> java.lang.StringBuilder
        return;
    }

    public void close() {
        // Registers (1 total): v0 = this
        _result = v0.a(); // android.support.v4.c.e.a -> void
        return;
    }

    public void flush() {
        // Registers (1 total): v0 = this
        _result = v0.a(); // android.support.v4.c.e.a -> void
        return;
    }

    public void write(char[] p0, int p1, int p2) {
        // Registers (7 total): v3 = this, v4 = p0 (char[]), v5 = p1 (int), v6 = p2 (int)
        v0 = 0;
        if (v0 >= v6) /* goto L_0017 */;
        v1 = binOp_0x90(v5, v0);
        v1 = v4[v1];
        v2 = 10;
        if (v1 != v2) /* goto L_0011 */;
        _result = v3.a(); // android.support.v4.c.e.a -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0001
        v2 = v3.b; // android.support.v4.c.e.b:java.lang.StringBuilder
        _result = v2.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_000e
        return;
    }

}