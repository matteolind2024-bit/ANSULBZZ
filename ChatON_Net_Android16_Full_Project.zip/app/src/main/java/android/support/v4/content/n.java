package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/n;
 */
final class n implements java.util.concurrent.ThreadFactory {
    private final java.util.concurrent.atomic.AtomicInteger a;

    n() {
        // Registers (3 total): v2 = this
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.concurrent.atomic.AtomicInteger;
        v1 = 1;
        _result = v0.<init>(v1); // java.util.concurrent.atomic.AtomicInteger.<init> -> void
        v2.a = v0; // android.support.v4.content.n.a:java.util.concurrent.atomic.AtomicInteger
        return;
    }

    public java.lang.Thread newThread(java.lang.Runnable p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.Runnable)
        v0 = new java.lang.Thread;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "ModernAsyncTask #";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.a; // android.support.v4.content.n.a:java.util.concurrent.atomic.AtomicInteger
        _result = v2.getAndIncrement(); // java.util.concurrent.atomic.AtomicInteger.getAndIncrement -> int
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v4, v1); // java.lang.Thread.<init> -> void
        return v0;
    }

}