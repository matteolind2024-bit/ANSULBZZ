package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/at;
 */
public class at extends android.support.v4.app.bc {
     android.graphics.Bitmap a;
     android.graphics.Bitmap b;
     boolean c;

    public at() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.app.bc.<init> -> void
        return;
    }

}