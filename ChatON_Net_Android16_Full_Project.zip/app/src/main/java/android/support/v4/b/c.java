package android.support.v4.b;

/**
 * Original SourceFile: ParcelableCompatCreatorCallbacks.java
 * Descriptor: Landroid/support/v4/b/c;
 */
public interface c {
    public abstract java.lang.Object a(android.os.Parcel p0, java.lang.ClassLoader p1);
    public abstract java.lang.Object[] a(int p0);
}