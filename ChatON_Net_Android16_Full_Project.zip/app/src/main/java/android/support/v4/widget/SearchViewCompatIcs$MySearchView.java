package android.support.v4.widget;

/**
 * Original SourceFile: SearchViewCompatIcs.java
 * Descriptor: Landroid/support/v4/widget/SearchViewCompatIcs$MySearchView;
 */
public class SearchViewCompatIcs$MySearchView extends android.widget.SearchView {
    public SearchViewCompatIcs$MySearchView(android.content.Context p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.content.Context)
        _result = v0.<init>(v1); // android.widget.SearchView.<init> -> void
        return;
    }

    public void onActionViewCollapsed() {
        // Registers (3 total): v2 = this
        v0 = "";
        v1 = 0;
        _result = v2.setQuery(v0, v1); // android.support.v4.widget.SearchViewCompatIcs$MySearchView.setQuery -> void
        _result = v2.onActionViewCollapsed(); // android.widget.SearchView.onActionViewCollapsed -> void
        return;
    }

}