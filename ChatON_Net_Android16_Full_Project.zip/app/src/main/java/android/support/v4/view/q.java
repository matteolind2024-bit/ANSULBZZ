package android.support.v4.view;

/**
 * Original SourceFile: GravityCompat.java
 * Descriptor: Landroid/support/v4/view/q;
 */
class q implements android.support.v4.view.o {
    q() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int a(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        _result = v2.a(v3); // android.support.v4.view.r.a -> int
        v0 = _result;
        return v0;
    }

}