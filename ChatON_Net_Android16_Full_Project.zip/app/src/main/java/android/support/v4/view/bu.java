package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompatHC.java
 * Descriptor: Landroid/support/v4/view/bu;
 */
class bu {
    public static void a(android.view.ViewGroup p0, boolean p1) {
        // Registers (2 total): v0 = p0 (android.view.ViewGroup), v1 = p1 (boolean)
        _result = v0.setMotionEventSplittingEnabled(v1); // android.view.ViewGroup.setMotionEventSplittingEnabled -> void
        return;
    }

}