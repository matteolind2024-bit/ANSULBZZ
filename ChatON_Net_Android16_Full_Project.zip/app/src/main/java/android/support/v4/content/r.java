package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/r;
 */
class r {
    final android.support.v4.content.m a;
    final java.lang.Object[] b;

    r(android.support.v4.content.m p0, java.lang.Object[] p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.content.m), v2 = p1 (java.lang.Object[])
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // android.support.v4.content.r.a:android.support.v4.content.m
        v0.b = v2; // android.support.v4.content.r.b:java.lang.Object[]
        return;
    }

}