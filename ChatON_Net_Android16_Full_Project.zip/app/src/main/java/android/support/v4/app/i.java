package android.support.v4.app;

/**
 * Original SourceFile: ActionBarDrawerToggleHoneycomb.java
 * Descriptor: Landroid/support/v4/app/i;
 */
class i {
    private static final int[] a;

    static {
        v0 = 1;
        v0 = new int[][size=v0];
        v1 = 0;
        v2 = 16843531; // 0x0101030b
        v0[v1] = v2;
        android.support.v4.app.i.a = v0; // :int[]
        return;
    }

    public static android.graphics.drawable.Drawable a(android.app.Activity p0) {
        // Registers (3 total): v2 = p0 (android.app.Activity)
        v0 = android.support.v4.app.i.a; // :int[]
        _result = v2.obtainStyledAttributes(v0); // android.app.Activity.obtainStyledAttributes -> android.content.res.TypedArray
        v0 = _result;
        v1 = 0;
        _result = v0.getDrawable(v1); // android.content.res.TypedArray.getDrawable -> android.graphics.drawable.Drawable
        v1 = _result;
        _result = v0.recycle(); // android.content.res.TypedArray.recycle -> void
        return v1;
    }

    public static java.lang.Object a(java.lang.Object p0, android.app.Activity p1, int p2) {
        // Registers (9 total): v6 = p0 (java.lang.Object), v7 = p1 (android.app.Activity), v8 = p2 (int)
        if (v6 != 0) /* goto L_002d */;
        v1 = new android.support.v4.app.j;
        _result = v1.<init>(v7); // android.support.v4.app.j.<init> -> void
        v0 = v1;
        v0 = (android.support.v4.app.j) v0;
        v2 = v0.a; // android.support.v4.app.j.a:java.lang.reflect.Method
        if (v2 == 0) /* goto L_0021 */;
        _result = v7.getActionBar(); // android.app.Activity.getActionBar -> android.app.ActionBar
        v2 = _result;
        v0 = v0.b; // android.support.v4.app.j.b:java.lang.reflect.Method
        v3 = 1;
        v3 = new java.lang.Object[][size=v3];
        v4 = 0;
        _result = v8.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v5 = _result;
        v3[v4] = v5;
        _result = v0.invoke(v2, v3); // java.lang.reflect.Method.invoke -> java.lang.Object
        return v1;
        v0 = _exception;
        v2 = "ActionBarDrawerToggleHoneycomb";
        v3 = "Couldn't set content description via JB-MR2 API";
        _result = v2.w(v3, v0); // android.util.Log.w -> int
        // goto L_0021
        v1 = v6;
        // goto L_0007
    }

}