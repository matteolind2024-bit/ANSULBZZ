package android.support.v4.widget;

/**
 * Original SourceFile: ViewDragHelper.java
 * Descriptor: Landroid/support/v4/widget/am;
 */
public class am {
    private static final android.view.animation.Interpolator v;
    private int a;
    private int b;
    private int c;
    private float[] d;
    private float[] e;
    private float[] f;
    private float[] g;
    private int[] h;
    private int[] i;
    private int[] j;
    private int k;
    private android.view.VelocityTracker l;
    private float m;
    private float n;
    private int o;
    private int p;
    private android.support.v4.widget.t q;
    private final android.support.v4.widget.ap r;
    private android.view.View s;
    private boolean t;
    private final android.view.ViewGroup u;
    private final java.lang.Runnable w;

    static {
        v0 = new android.support.v4.widget.an;
        _result = v0.<init>(); // android.support.v4.widget.an.<init> -> void
        android.support.v4.widget.am.v = v0; // :android.view.animation.Interpolator
        return;
    }

    private am(android.content.Context p0, android.view.ViewGroup p1, android.support.v4.widget.ap p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.view.ViewGroup), v6 = p2 (android.support.v4.widget.ap)
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v0 = -1;
        v3.c = v0; // android.support.v4.widget.am.c:int
        v0 = new android.support.v4.widget.ao;
        _result = v0.<init>(v3); // android.support.v4.widget.ao.<init> -> void
        v3.w = v0; // android.support.v4.widget.am.w:java.lang.Runnable
        if (v5 != 0) /* goto L_0018 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Parent view may not be null";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        if (v6 != 0) /* goto L_0023 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Callback may not be null";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v3.u = v5; // android.support.v4.widget.am.u:android.view.ViewGroup
        v3.r = v6; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        _result = v4.get(); // android.view.ViewConfiguration.get -> android.view.ViewConfiguration
        v0 = _result;
        _result = v4.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v1 = _result;
        _result = v1.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v1 = _result;
        v1 = v1.density; // android.util.DisplayMetrics.density:float
        v2 = 0x41a00000;
        v1 = binOp2addr_0xc8(v1, v2);
        v2 = 0x3f000000;
        v1 = binOp2addr_0xc6(v1, v2);
        v1 = unaryOp_0x87(v1);
        v3.o = v1; // android.support.v4.widget.am.o:int
        _result = v0.getScaledTouchSlop(); // android.view.ViewConfiguration.getScaledTouchSlop -> int
        v1 = _result;
        v3.b = v1; // android.support.v4.widget.am.b:int
        _result = v0.getScaledMaximumFlingVelocity(); // android.view.ViewConfiguration.getScaledMaximumFlingVelocity -> int
        v1 = _result;
        v1 = unaryOp_0x82(v1);
        v3.m = v1; // android.support.v4.widget.am.m:float
        _result = v0.getScaledMinimumFlingVelocity(); // android.view.ViewConfiguration.getScaledMinimumFlingVelocity -> int
        v0 = _result;
        v0 = unaryOp_0x82(v0);
        v3.n = v0; // android.support.v4.widget.am.n:float
        v0 = android.support.v4.widget.am.v; // :android.view.animation.Interpolator
        _result = v4.a(v0); // android.support.v4.widget.t.a -> android.support.v4.widget.t
        v0 = _result;
        v3.q = v0; // android.support.v4.widget.am.q:android.support.v4.widget.t
        return;
    }

    private float a(float p0, float p1, float p2) {
        // Registers (7 total): v3 = this, v4 = p0 (float), v5 = p1 (float), v6 = p2 (float)
        v0 = 0;
        _result = v4.abs(); // java.lang.Math.abs -> float
        v1 = _result;
        v2 = cmp(v1, v5);
        if (v2 >= 0) /* goto L_000b */;
        v6 = v0;
        return v6;
        v1 = cmp(v1, v6);
        if (v1 <= 0) /* goto L_0015 */;
        v0 = cmp(v4, v0);
        if (v0 > 0) /* goto L_000a */;
        v6 = unaryOp_0x7f(v6);
        // goto L_000a
        v6 = v4;
        // goto L_000a
    }

    private int a(int p0, int p1, int p2) {
        // Registers (8 total): v4 = this, v5 = p0 (int), v6 = p1 (int), v7 = p2 (int)
        v3 = 0x3f800000;
        if (v5 != 0) /* goto L_0006 */;
        v0 = 0;
        return v0;
        v0 = v4.u; // android.support.v4.widget.am.u:android.view.ViewGroup
        _result = v0.getWidth(); // android.view.ViewGroup.getWidth -> int
        v0 = _result;
        v1 = binOpLit8_0xdb(v0, 2);
        _result = v5.abs(); // java.lang.Math.abs -> int
        v2 = _result;
        v2 = unaryOp_0x82(v2);
        v0 = unaryOp_0x82(v0);
        v0 = binOp_0xa9(v2, v0);
        _result = v3.min(v0); // java.lang.Math.min -> float
        v0 = _result;
        v2 = unaryOp_0x82(v1);
        v1 = unaryOp_0x82(v1);
        _result = v4.b(v0); // android.support.v4.widget.am.b -> float
        v0 = _result;
        v0 = binOp2addr_0xc8(v0, v1);
        v0 = binOp2addr_0xc6(v0, v2);
        _result = v6.abs(); // java.lang.Math.abs -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_003e */;
        v2 = 0x447a0000;
        v1 = unaryOp_0x82(v1);
        v0 = binOp2addr_0xc9(v0, v1);
        _result = v0.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v0 = binOp2addr_0xc8(v0, v2);
        _result = v0.round(); // java.lang.Math.round -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 4);
        v1 = 600;
        _result = v0.min(v1); // java.lang.Math.min -> int
        v0 = _result;
        // goto L_0005
        _result = v5.abs(); // java.lang.Math.abs -> int
        v0 = _result;
        v0 = unaryOp_0x82(v0);
        v1 = unaryOp_0x82(v7);
        v0 = binOp2addr_0xc9(v0, v1);
        v0 = binOp2addr_0xc6(v0, v3);
        v1 = 0x43800000;
        v0 = binOp2addr_0xc8(v0, v1);
        v0 = unaryOp_0x87(v0);
        // goto L_0037
    }

    private int a(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (14 total): v8 = this, v9 = p0 (android.view.View), v10 = p1 (int), v11 = p2 (int), v12 = p3 (int), v13 = p4 (int)
        v0 = v8.n; // android.support.v4.widget.am.n:float
        v0 = unaryOp_0x87(v0);
        v1 = v8.m; // android.support.v4.widget.am.m:float
        v1 = unaryOp_0x87(v1);
        _result = v8.b(v12, v0, v1); // android.support.v4.widget.am.b -> int
        v2 = _result;
        v0 = v8.n; // android.support.v4.widget.am.n:float
        v0 = unaryOp_0x87(v0);
        v1 = v8.m; // android.support.v4.widget.am.m:float
        v1 = unaryOp_0x87(v1);
        _result = v8.b(v13, v0, v1); // android.support.v4.widget.am.b -> int
        v3 = _result;
        _result = v10.abs(); // java.lang.Math.abs -> int
        v0 = _result;
        _result = v11.abs(); // java.lang.Math.abs -> int
        v4 = _result;
        _result = v2.abs(); // java.lang.Math.abs -> int
        v1 = _result;
        _result = v3.abs(); // java.lang.Math.abs -> int
        v5 = _result;
        v6 = binOp_0x90(v1, v5);
        v7 = binOp_0x90(v0, v4);
        if (v2 == 0) /* goto L_004e */;
        v0 = unaryOp_0x82(v1);
        v1 = unaryOp_0x82(v6);
        v0 = binOp2addr_0xc9(v0, v1);
        v1 = v0;
        if (v3 == 0) /* goto L_0053 */;
        v0 = unaryOp_0x82(v5);
        v4 = unaryOp_0x82(v6);
        v0 = binOp2addr_0xc9(v0, v4);
        v4 = v8.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        _result = v4.a(v9); // android.support.v4.widget.ap.a -> int
        v4 = _result;
        _result = v8.a(v10, v2, v4); // android.support.v4.widget.am.a -> int
        v2 = _result;
        v4 = v8.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        _result = v4.b(v9); // android.support.v4.widget.ap.b -> int
        v4 = _result;
        _result = v8.a(v11, v3, v4); // android.support.v4.widget.am.a -> int
        v3 = _result;
        v2 = unaryOp_0x82(v2);
        v1 = binOp2addr_0xc8(v1, v2);
        v2 = unaryOp_0x82(v3);
        v0 = binOp2addr_0xc8(v0, v2);
        v0 = binOp2addr_0xc6(v0, v1);
        v0 = unaryOp_0x87(v0);
        return v0;
        v0 = unaryOp_0x82(v0);
        v1 = unaryOp_0x82(v7);
        v0 = binOp2addr_0xc9(v0, v1);
        v1 = v0;
        // goto L_002e
        v0 = unaryOp_0x82(v4);
        v4 = unaryOp_0x82(v7);
        v0 = binOp2addr_0xc9(v0, v4);
        // goto L_0033
    }

    public static android.support.v4.widget.am a(android.view.ViewGroup p0, float p1, android.support.v4.widget.ap p2) {
        // Registers (6 total): v3 = p0 (android.view.ViewGroup), v4 = p1 (float), v5 = p2 (android.support.v4.widget.ap)
        _result = v3.a(v5); // android.support.v4.widget.am.a -> android.support.v4.widget.am
        v0 = _result;
        v1 = v0.b; // android.support.v4.widget.am.b:int
        v1 = unaryOp_0x82(v1);
        v2 = 0x3f800000;
        v2 = binOp2addr_0xc9(v2, v4);
        v1 = binOp2addr_0xc8(v1, v2);
        v1 = unaryOp_0x87(v1);
        v0.b = v1; // android.support.v4.widget.am.b:int
        return v0;
    }

    public static android.support.v4.widget.am a(android.view.ViewGroup p0, android.support.v4.widget.ap p1) {
        // Registers (4 total): v2 = p0 (android.view.ViewGroup), v3 = p1 (android.support.v4.widget.ap)
        v0 = new android.support.v4.widget.am;
        _result = v2.getContext(); // android.view.ViewGroup.getContext -> android.content.Context
        v1 = _result;
        _result = v0.<init>(v1, v2, v3); // android.support.v4.widget.am.<init> -> void
        return v0;
    }

    private void a(float p0, float p1) {
        // Registers (7 total): v4 = this, v5 = p0 (float), v6 = p1 (float)
        v3 = 1;
        v2 = 0;
        v4.t = v3; // android.support.v4.widget.am.t:boolean
        v0 = v4.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        v1 = v4.s; // android.support.v4.widget.am.s:android.view.View
        _result = v0.a(v1, v5, v6); // android.support.v4.widget.ap.a -> void
        v4.t = v2; // android.support.v4.widget.am.t:boolean
        v0 = v4.a; // android.support.v4.widget.am.a:int
        if (v0 != v3) /* goto L_0014 */;
        _result = v4.c(v2); // android.support.v4.widget.am.c -> void
        return;
    }

    private void a(float p0, float p1, int p2) {
        // Registers (7 total): v3 = this, v4 = p0 (float), v5 = p1 (float), v6 = p2 (int)
        _result = v3.f(v6); // android.support.v4.widget.am.f -> void
        v0 = v3.d; // android.support.v4.widget.am.d:float[]
        v1 = v3.f; // android.support.v4.widget.am.f:float[]
        v1[v6] = v4;
        v0[v6] = v4;
        v0 = v3.e; // android.support.v4.widget.am.e:float[]
        v1 = v3.g; // android.support.v4.widget.am.g:float[]
        v1[v6] = v5;
        v0[v6] = v5;
        v0 = v3.h; // android.support.v4.widget.am.h:int[]
        v1 = unaryOp_0x87(v4);
        v2 = unaryOp_0x87(v5);
        _result = v3.e(v1, v2); // android.support.v4.widget.am.e -> int
        v1 = _result;
        v0[v6] = v1;
        v0 = v3.k; // android.support.v4.widget.am.k:int
        v1 = 1;
        v1 = binOp2addr_0xb8(v1, v6);
        v0 = binOp2addr_0xb6(v0, v1);
        v3.k = v0; // android.support.v4.widget.am.k:int
        return;
    }

    private boolean a(float p0, float p1, int p2, int p3) {
        // Registers (9 total): v4 = this, v5 = p0 (float), v6 = p1 (float), v7 = p2 (int), v8 = p3 (int)
        v0 = 0;
        _result = v5.abs(); // java.lang.Math.abs -> float
        v1 = _result;
        _result = v6.abs(); // java.lang.Math.abs -> float
        v2 = _result;
        v3 = v4.h; // android.support.v4.widget.am.h:int[]
        v3 = v3[v7];
        v3 = binOp2addr_0xb5(v3, v8);
        if (v3 != v8) /* goto L_0031 */;
        v3 = v4.p; // android.support.v4.widget.am.p:int
        v3 = binOp2addr_0xb5(v3, v8);
        if (v3 == 0) /* goto L_0031 */;
        v3 = v4.j; // android.support.v4.widget.am.j:int[]
        v3 = v3[v7];
        v3 = binOp2addr_0xb5(v3, v8);
        if (v3 == v8) /* goto L_0031 */;
        v3 = v4.i; // android.support.v4.widget.am.i:int[]
        v3 = v3[v7];
        v3 = binOp2addr_0xb5(v3, v8);
        if (v3 == v8) /* goto L_0031 */;
        v3 = v4.b; // android.support.v4.widget.am.b:int
        v3 = unaryOp_0x82(v3);
        v3 = cmp(v1, v3);
        if (v3 > 0) /* goto L_0032 */;
        v3 = v4.b; // android.support.v4.widget.am.b:int
        v3 = unaryOp_0x82(v3);
        v3 = cmp(v2, v3);
        if (v3 > 0) /* goto L_0032 */;
        return v0;
        v3 = 0x3f000000;
        v2 = binOp2addr_0xc8(v2, v3);
        v2 = cmp(v1, v2);
        if (v2 >= 0) /* goto L_0049 */;
        v2 = v4.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        _result = v2.b(v8); // android.support.v4.widget.ap.b -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0049 */;
        v1 = v4.j; // android.support.v4.widget.am.j:int[]
        v2 = v1[v7];
        v2 = binOp2addr_0xb6(v2, v8);
        v1[v7] = v2;
        // goto L_0031
        v2 = v4.i; // android.support.v4.widget.am.i:int[]
        v2 = v2[v7];
        v2 = binOp2addr_0xb5(v2, v8);
        if (v2 != 0) /* goto L_0031 */;
        v2 = v4.b; // android.support.v4.widget.am.b:int
        v2 = unaryOp_0x82(v2);
        v1 = cmp(v1, v2);
        if (v1 <= 0) /* goto L_0031 */;
        v0 = 1;
        // goto L_0031
    }

    private boolean a(int p0, int p1, int p2, int p3) {
        // Registers (15 total): v10 = this, v11 = p0 (int), v12 = p1 (int), v13 = p2 (int), v14 = p3 (int)
        v0 = 0;
        v1 = v10.s; // android.support.v4.widget.am.s:android.view.View
        _result = v1.getLeft(); // android.view.View.getLeft -> int
        v7 = _result;
        v1 = v10.s; // android.support.v4.widget.am.s:android.view.View
        _result = v1.getTop(); // android.view.View.getTop -> int
        v6 = _result;
        v2 = binOp_0x91(v11, v7);
        v3 = binOp_0x91(v12, v6);
        if (v2 != 0) /* goto L_001e */;
        if (v3 != 0) /* goto L_001e */;
        v1 = v10.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v1.g(); // android.support.v4.widget.t.g -> void
        _result = v10.c(v0); // android.support.v4.widget.am.c -> void
        return v0;
        v1 = v10.s; // android.support.v4.widget.am.s:android.view.View
        v0 = v10;
        v4 = v13;
        v5 = v14;
        _result = v0.a(v0..v5); // android.support.v4.widget.am.a -> int
        v9 = _result;
        v4 = v10.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        v5 = v7;
        v7 = v2;
        v8 = v3;
        _result = v4.a(v4..v9); // android.support.v4.widget.t.a -> void
        v0 = 2;
        _result = v10.c(v0); // android.support.v4.widget.am.c -> void
        v0 = 1;
        // goto L_001d
    }

    private boolean a(android.view.View p0, float p1, float p2) {
        // Registers (9 total): v5 = this, v6 = p0 (android.view.View), v7 = p1 (float), v8 = p2 (float)
        v1 = 1;
        v2 = 0;
        if (v6 != 0) /* goto L_0006 */;
        v1 = v2;
        return v1;
        v0 = v5.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        _result = v0.a(v6); // android.support.v4.widget.ap.a -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_002d */;
        v0 = v1;
        v3 = v5.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        _result = v3.b(v6); // android.support.v4.widget.ap.b -> int
        v3 = _result;
        if (v3 <= 0) /* goto L_002f */;
        v3 = v1;
        if (v0 == 0) /* goto L_0031 */;
        if (v3 == 0) /* goto L_0031 */;
        v0 = binOp_0xa8(v7, v7);
        v3 = binOp_0xa8(v8, v8);
        v0 = binOp2addr_0xc6(v0, v3);
        v3 = v5.b; // android.support.v4.widget.am.b:int
        v4 = v5.b; // android.support.v4.widget.am.b:int
        v3 = binOp2addr_0xb2(v3, v4);
        v3 = unaryOp_0x82(v3);
        v0 = cmp(v0, v3);
        if (v0 > 0) /* goto L_0005 */;
        v1 = v2;
        // goto L_0005
        v0 = v2;
        // goto L_000f
        v3 = v2;
        // goto L_0018
        if (v0 == 0) /* goto L_0040 */;
        _result = v7.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v3 = v5.b; // android.support.v4.widget.am.b:int
        v3 = unaryOp_0x82(v3);
        v0 = cmp(v0, v3);
        if (v0 > 0) /* goto L_0005 */;
        v1 = v2;
        // goto L_0005
        if (v3 == 0) /* goto L_004f */;
        _result = v8.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v3 = v5.b; // android.support.v4.widget.am.b:int
        v3 = unaryOp_0x82(v3);
        v0 = cmp(v0, v3);
        if (v0 > 0) /* goto L_0005 */;
        v1 = v2;
        // goto L_0005
        v1 = v2;
        // goto L_0005
    }

    private float b(float p0) {
        // Registers (6 total): v4 = this, v5 = p0 (float)
        v0 = 0x3f000000;
        v0 = binOp_0xa7(v5, v0);
        v0 = unaryOp_0x89(v0);
        v2 = 0x3fde28c7460698c7L;
        v0 = binOp2addr_0xcd(v0, v2);
        v0 = unaryOp_0x8c(v0);
        v0 = unaryOp_0x89(v0);
        _result = v0.sin(v1); // java.lang.Math.sin -> double
        v0 = _result;
        v0 = unaryOp_0x8c(v0);
        return v0;
    }

    private int b(int p0, int p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (int), v4 = p2 (int)
        _result = v2.abs(); // java.lang.Math.abs -> int
        v0 = _result;
        if (v0 >= v3) /* goto L_0008 */;
        v4 = 0;
        return v4;
        if (v0 <= v4) /* goto L_000e */;
        if (v2 > 0) /* goto L_0007 */;
        v4 = unaryOp_0x7b(v4);
        // goto L_0007
        v4 = v2;
        // goto L_0007
    }

    private void b(float p0, float p1, int p2) {
        // Registers (7 total): v3 = this, v4 = p0 (float), v5 = p1 (float), v6 = p2 (int)
        v0 = 1;
        v1 = 0;
        _result = v3.a(v4, v5, v6, v0); // android.support.v4.widget.am.a -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0033 */;
        v1 = 4;
        _result = v3.a(v5, v4, v6, v1); // android.support.v4.widget.am.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0011 */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = 2;
        _result = v3.a(v4, v5, v6, v1); // android.support.v4.widget.am.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = 8;
        _result = v3.a(v5, v4, v6, v1); // android.support.v4.widget.am.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0024 */;
        v0 = binOpLit8_0xde(v0, 8);
        if (v0 == 0) /* goto L_0032 */;
        v1 = v3.i; // android.support.v4.widget.am.i:int[]
        v2 = v1[v6];
        v2 = binOp2addr_0xb6(v2, v0);
        v1[v6] = v2;
        v1 = v3.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        _result = v1.b(v0, v6); // android.support.v4.widget.ap.b -> void
        return;
        v0 = v1;
        // goto L_0008
    }

    private void b(int p0, int p1, int p2, int p3) {
        // Registers (11 total): v6 = this, v7 = p0 (int), v8 = p1 (int), v9 = p2 (int), v10 = p3 (int)
        v0 = v6.s; // android.support.v4.widget.am.s:android.view.View
        _result = v0.getLeft(); // android.view.View.getLeft -> int
        v0 = _result;
        v1 = v6.s; // android.support.v4.widget.am.s:android.view.View
        _result = v1.getTop(); // android.view.View.getTop -> int
        v1 = _result;
        if (v9 == 0) /* goto L_0040 */;
        v2 = v6.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        v3 = v6.s; // android.support.v4.widget.am.s:android.view.View
        _result = v2.a(v3, v7, v9); // android.support.v4.widget.ap.a -> int
        v2 = _result;
        v3 = v6.s; // android.support.v4.widget.am.s:android.view.View
        v4 = binOp_0x91(v2, v0);
        _result = v3.offsetLeftAndRight(v4); // android.view.View.offsetLeftAndRight -> void
        if (v10 == 0) /* goto L_003e */;
        v3 = v6.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        v4 = v6.s; // android.support.v4.widget.am.s:android.view.View
        _result = v3.b(v4, v8, v10); // android.support.v4.widget.ap.b -> int
        v3 = _result;
        v4 = v6.s; // android.support.v4.widget.am.s:android.view.View
        v5 = binOp_0x91(v3, v1);
        _result = v4.offsetTopAndBottom(v5); // android.view.View.offsetTopAndBottom -> void
        if (v9 != 0) /* goto L_0032 */;
        if (v10 == 0) /* goto L_003d */;
        v4 = binOp_0x91(v2, v0);
        v5 = binOp_0x91(v3, v1);
        v0 = v6.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        v1 = v6.s; // android.support.v4.widget.am.s:android.view.View
        _result = v0.a(v0..v5); // android.support.v4.widget.ap.a -> void
        return;
        v3 = v8;
        // goto L_002e
        v2 = v7;
        // goto L_001d
    }

    private void c(android.view.MotionEvent p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.view.MotionEvent)
        _result = v7.c(); // android.support.v4.view.z.c -> int
        v1 = _result;
        v0 = 0;
        if (v0 >= v1) /* goto L_001e */;
        _result = v7.b(v0); // android.support.v4.view.z.b -> int
        v2 = _result;
        _result = v7.c(v0); // android.support.v4.view.z.c -> float
        v3 = _result;
        _result = v7.d(v0); // android.support.v4.view.z.d -> float
        v4 = _result;
        v5 = v6.f; // android.support.v4.widget.am.f:float[]
        v5[v2] = v3;
        v3 = v6.g; // android.support.v4.widget.am.g:float[]
        v3[v2] = v4;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0005
        return;
    }

    private int e(int p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (int)
        v0 = 0;
        v1 = v3.u; // android.support.v4.widget.am.u:android.view.ViewGroup
        _result = v1.getLeft(); // android.view.ViewGroup.getLeft -> int
        v1 = _result;
        v2 = v3.o; // android.support.v4.widget.am.o:int
        v1 = binOp2addr_0xb0(v1, v2);
        if (v4 >= v1) /* goto L_000d */;
        v0 = 1;
        v1 = v3.u; // android.support.v4.widget.am.u:android.view.ViewGroup
        _result = v1.getTop(); // android.view.ViewGroup.getTop -> int
        v1 = _result;
        v2 = v3.o; // android.support.v4.widget.am.o:int
        v1 = binOp2addr_0xb0(v1, v2);
        if (v5 >= v1) /* goto L_001a */;
        v0 = binOpLit8_0xde(v0, 4);
        v1 = v3.u; // android.support.v4.widget.am.u:android.view.ViewGroup
        _result = v1.getRight(); // android.view.ViewGroup.getRight -> int
        v1 = _result;
        v2 = v3.o; // android.support.v4.widget.am.o:int
        v1 = binOp2addr_0xb1(v1, v2);
        if (v4 <= v1) /* goto L_0027 */;
        v0 = binOpLit8_0xde(v0, 2);
        v1 = v3.u; // android.support.v4.widget.am.u:android.view.ViewGroup
        _result = v1.getBottom(); // android.view.ViewGroup.getBottom -> int
        v1 = _result;
        v2 = v3.o; // android.support.v4.widget.am.o:int
        v1 = binOp2addr_0xb1(v1, v2);
        if (v5 <= v1) /* goto L_0034 */;
        v0 = binOpLit8_0xde(v0, 8);
        return v0;
    }

    private void e(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v2 = 0;
        v1 = 0;
        v0 = v3.d; // android.support.v4.widget.am.d:float[]
        if (v0 != 0) /* goto L_0007 */;
        return;
        v0 = v3.d; // android.support.v4.widget.am.d:float[]
        v0[v4] = v1;
        v0 = v3.e; // android.support.v4.widget.am.e:float[]
        v0[v4] = v1;
        v0 = v3.f; // android.support.v4.widget.am.f:float[]
        v0[v4] = v1;
        v0 = v3.g; // android.support.v4.widget.am.g:float[]
        v0[v4] = v1;
        v0 = v3.h; // android.support.v4.widget.am.h:int[]
        v0[v4] = v2;
        v0 = v3.i; // android.support.v4.widget.am.i:int[]
        v0[v4] = v2;
        v0 = v3.j; // android.support.v4.widget.am.j:int[]
        v0[v4] = v2;
        v0 = v3.k; // android.support.v4.widget.am.k:int
        v1 = 1;
        v1 = binOp2addr_0xb8(v1, v4);
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v3.k = v0; // android.support.v4.widget.am.k:int
        // goto L_0006
    }

    private void f(int p0) {
        // Registers (12 total): v10 = this, v11 = p0 (int)
        v9 = 0;
        v0 = v10.d; // android.support.v4.widget.am.d:float[]
        if (v0 == 0) /* goto L_000a */;
        v0 = v10.d; // android.support.v4.widget.am.d:float[]
        v0 = v0.length;
        if (v0 > v11) /* goto L_0070 */;
        v0 = binOpLit8_0xd8(v11, 1);
        v0 = new float[][size=v0];
        v1 = binOpLit8_0xd8(v11, 1);
        v1 = new float[][size=v1];
        v2 = binOpLit8_0xd8(v11, 1);
        v2 = new float[][size=v2];
        v3 = binOpLit8_0xd8(v11, 1);
        v3 = new float[][size=v3];
        v4 = binOpLit8_0xd8(v11, 1);
        v4 = new int[][size=v4];
        v5 = binOpLit8_0xd8(v11, 1);
        v5 = new int[][size=v5];
        v6 = binOpLit8_0xd8(v11, 1);
        v6 = new int[][size=v6];
        v7 = v10.d; // android.support.v4.widget.am.d:float[]
        if (v7 == 0) /* goto L_0062 */;
        v7 = v10.d; // android.support.v4.widget.am.d:float[]
        v8 = v10.d; // android.support.v4.widget.am.d:float[]
        v8 = v8.length;
        _result = v7.arraycopy(v9, v0, v9, v8); // java.lang.System.arraycopy -> void
        v7 = v10.e; // android.support.v4.widget.am.e:float[]
        v8 = v10.e; // android.support.v4.widget.am.e:float[]
        v8 = v8.length;
        _result = v7.arraycopy(v9, v1, v9, v8); // java.lang.System.arraycopy -> void
        v7 = v10.f; // android.support.v4.widget.am.f:float[]
        v8 = v10.f; // android.support.v4.widget.am.f:float[]
        v8 = v8.length;
        _result = v7.arraycopy(v9, v2, v9, v8); // java.lang.System.arraycopy -> void
        v7 = v10.g; // android.support.v4.widget.am.g:float[]
        v8 = v10.g; // android.support.v4.widget.am.g:float[]
        v8 = v8.length;
        _result = v7.arraycopy(v9, v3, v9, v8); // java.lang.System.arraycopy -> void
        v7 = v10.h; // android.support.v4.widget.am.h:int[]
        v8 = v10.h; // android.support.v4.widget.am.h:int[]
        v8 = v8.length;
        _result = v7.arraycopy(v9, v4, v9, v8); // java.lang.System.arraycopy -> void
        v7 = v10.i; // android.support.v4.widget.am.i:int[]
        v8 = v10.i; // android.support.v4.widget.am.i:int[]
        v8 = v8.length;
        _result = v7.arraycopy(v9, v5, v9, v8); // java.lang.System.arraycopy -> void
        v7 = v10.j; // android.support.v4.widget.am.j:int[]
        v8 = v10.j; // android.support.v4.widget.am.j:int[]
        v8 = v8.length;
        _result = v7.arraycopy(v9, v6, v9, v8); // java.lang.System.arraycopy -> void
        v10.d = v0; // android.support.v4.widget.am.d:float[]
        v10.e = v1; // android.support.v4.widget.am.e:float[]
        v10.f = v2; // android.support.v4.widget.am.f:float[]
        v10.g = v3; // android.support.v4.widget.am.g:float[]
        v10.h = v4; // android.support.v4.widget.am.h:int[]
        v10.i = v5; // android.support.v4.widget.am.i:int[]
        v10.j = v6; // android.support.v4.widget.am.j:int[]
        return;
    }

    private void g() {
        // Registers (4 total): v3 = this
        v2 = 0;
        v1 = 0;
        v0 = v3.d; // android.support.v4.widget.am.d:float[]
        if (v0 != 0) /* goto L_0007 */;
        return;
        v0 = v3.d; // android.support.v4.widget.am.d:float[]
        _result = v0.fill(v1); // java.util.Arrays.fill -> void
        v0 = v3.e; // android.support.v4.widget.am.e:float[]
        _result = v0.fill(v1); // java.util.Arrays.fill -> void
        v0 = v3.f; // android.support.v4.widget.am.f:float[]
        _result = v0.fill(v1); // java.util.Arrays.fill -> void
        v0 = v3.g; // android.support.v4.widget.am.g:float[]
        _result = v0.fill(v1); // java.util.Arrays.fill -> void
        v0 = v3.h; // android.support.v4.widget.am.h:int[]
        _result = v0.fill(v2); // java.util.Arrays.fill -> void
        v0 = v3.i; // android.support.v4.widget.am.i:int[]
        _result = v0.fill(v2); // java.util.Arrays.fill -> void
        v0 = v3.j; // android.support.v4.widget.am.j:int[]
        _result = v0.fill(v2); // java.util.Arrays.fill -> void
        v3.k = v2; // android.support.v4.widget.am.k:int
        // goto L_0006
    }

    private void h() {
        // Registers (5 total): v4 = this
        v0 = v4.l; // android.support.v4.widget.am.l:android.view.VelocityTracker
        v1 = 1000;
        v2 = v4.m; // android.support.v4.widget.am.m:float
        _result = v0.computeCurrentVelocity(v1, v2); // android.view.VelocityTracker.computeCurrentVelocity -> void
        v0 = v4.l; // android.support.v4.widget.am.l:android.view.VelocityTracker
        v1 = v4.c; // android.support.v4.widget.am.c:int
        _result = v0.a(v1); // android.support.v4.view.ao.a -> float
        v0 = _result;
        v1 = v4.n; // android.support.v4.widget.am.n:float
        v2 = v4.m; // android.support.v4.widget.am.m:float
        _result = v4.a(v0, v1, v2); // android.support.v4.widget.am.a -> float
        v0 = _result;
        v1 = v4.l; // android.support.v4.widget.am.l:android.view.VelocityTracker
        v2 = v4.c; // android.support.v4.widget.am.c:int
        _result = v1.b(v2); // android.support.v4.view.ao.b -> float
        v1 = _result;
        v2 = v4.n; // android.support.v4.widget.am.n:float
        v3 = v4.m; // android.support.v4.widget.am.m:float
        _result = v4.a(v1, v2, v3); // android.support.v4.widget.am.a -> float
        v1 = _result;
        _result = v4.a(v0, v1); // android.support.v4.widget.am.a -> void
        return;
    }

    public int a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.widget.am.a:int
        return v0;
    }

    public void a(float p0) {
        // Registers (2 total): v0 = this, v1 = p0 (float)
        v0.n = v1; // android.support.v4.widget.am.n:float
        return;
    }

    public void a(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.p = v1; // android.support.v4.widget.am.p:int
        return;
    }

    public void a(android.view.View p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.view.View), v5 = p1 (int)
        _result = v4.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v0 = _result;
        v1 = v3.u; // android.support.v4.widget.am.u:android.view.ViewGroup
        if (v0 == v1) /* goto L_002b */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.u; // android.support.v4.widget.am.u:android.view.ViewGroup
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ")";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v3.s = v4; // android.support.v4.widget.am.s:android.view.View
        v3.c = v5; // android.support.v4.widget.am.c:int
        v0 = v3.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        _result = v0.b(v4, v5); // android.support.v4.widget.ap.b -> void
        v0 = 1;
        _result = v3.c(v0); // android.support.v4.widget.am.c -> void
        return;
    }

    public boolean a(int p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (int)
        v0 = v3.t; // android.support.v4.widget.am.t:boolean
        if (v0 != 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.l; // android.support.v4.widget.am.l:android.view.VelocityTracker
        v1 = v3.c; // android.support.v4.widget.am.c:int
        _result = v0.a(v1); // android.support.v4.view.ao.a -> float
        v0 = _result;
        v0 = unaryOp_0x87(v0);
        v1 = v3.l; // android.support.v4.widget.am.l:android.view.VelocityTracker
        v2 = v3.c; // android.support.v4.widget.am.c:int
        _result = v1.b(v2); // android.support.v4.view.ao.b -> float
        v1 = _result;
        v1 = unaryOp_0x87(v1);
        _result = v3.a(v4, v5, v0, v1); // android.support.v4.widget.am.a -> boolean
        v0 = _result;
        return v0;
    }

    public boolean a(android.view.MotionEvent p0) {
        // Registers (12 total): v10 = this, v11 = p0 (android.view.MotionEvent)
        v6 = 2;
        v0 = 1;
        v1 = 0;
        _result = v11.a(); // android.support.v4.view.z.a -> int
        v2 = _result;
        _result = v11.b(); // android.support.v4.view.z.b -> int
        v3 = _result;
        if (v2 != 0) /* goto L_0010 */;
        _result = v10.e(); // android.support.v4.widget.am.e -> void
        v4 = v10.l; // android.support.v4.widget.am.l:android.view.VelocityTracker
        if (v4 != 0) /* goto L_001a */;
        _result = this.obtain(); // android.view.VelocityTracker.obtain -> android.view.VelocityTracker
        v4 = _result;
        v10.l = v4; // android.support.v4.widget.am.l:android.view.VelocityTracker
        v4 = v10.l; // android.support.v4.widget.am.l:android.view.VelocityTracker
        _result = v4.addMovement(v11); // android.view.VelocityTracker.addMovement -> void
        // switch(v2)
        v2 = v10.a; // android.support.v4.widget.am.a:int
        if (v2 != v0) /* goto L_00e0 */;
        return v0;
        _result = v11.getX(); // android.view.MotionEvent.getX -> float
        v2 = _result;
        _result = v11.getY(); // android.view.MotionEvent.getY -> float
        v3 = _result;
        _result = v11.b(v1); // android.support.v4.view.z.b -> int
        v4 = _result;
        _result = v10.a(v2, v3, v4); // android.support.v4.widget.am.a -> void
        v2 = unaryOp_0x87(v2);
        v3 = unaryOp_0x87(v3);
        _result = v10.d(v2, v3); // android.support.v4.widget.am.d -> android.view.View
        v2 = _result;
        v3 = v10.s; // android.support.v4.widget.am.s:android.view.View
        if (v2 != v3) /* goto L_0047 */;
        v3 = v10.a; // android.support.v4.widget.am.a:int
        if (v3 != v6) /* goto L_0047 */;
        _result = v10.b(v2, v4); // android.support.v4.widget.am.b -> boolean
        v2 = v10.h; // android.support.v4.widget.am.h:int[]
        v2 = v2[v4];
        v3 = v10.p; // android.support.v4.widget.am.p:int
        v3 = binOp2addr_0xb5(v3, v2);
        if (v3 == 0) /* goto L_0022 */;
        v3 = v10.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        v5 = v10.p; // android.support.v4.widget.am.p:int
        v2 = binOp2addr_0xb5(v2, v5);
        _result = v3.a(v2, v4); // android.support.v4.widget.ap.a -> void
        // goto L_0022
        _result = v11.b(v3); // android.support.v4.view.z.b -> int
        v2 = _result;
        _result = v11.c(v3); // android.support.v4.view.z.c -> float
        v4 = _result;
        _result = v11.d(v3); // android.support.v4.view.z.d -> float
        v3 = _result;
        _result = v10.a(v4, v3, v2); // android.support.v4.widget.am.a -> void
        v5 = v10.a; // android.support.v4.widget.am.a:int
        if (v5 != 0) /* goto L_007e */;
        v3 = v10.h; // android.support.v4.widget.am.h:int[]
        v3 = v3[v2];
        v4 = v10.p; // android.support.v4.widget.am.p:int
        v4 = binOp2addr_0xb5(v4, v3);
        if (v4 == 0) /* goto L_0022 */;
        v4 = v10.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        v5 = v10.p; // android.support.v4.widget.am.p:int
        v3 = binOp2addr_0xb5(v3, v5);
        _result = v4.a(v3, v2); // android.support.v4.widget.ap.a -> void
        // goto L_0022
        v5 = v10.a; // android.support.v4.widget.am.a:int
        if (v5 != v6) /* goto L_0022 */;
        v4 = unaryOp_0x87(v4);
        v3 = unaryOp_0x87(v3);
        _result = v10.d(v4, v3); // android.support.v4.widget.am.d -> android.view.View
        v3 = _result;
        v4 = v10.s; // android.support.v4.widget.am.s:android.view.View
        if (v3 != v4) /* goto L_0022 */;
        _result = v10.b(v3, v2); // android.support.v4.widget.am.b -> boolean
        // goto L_0022
        _result = v11.c(); // android.support.v4.view.z.c -> int
        v3 = _result;
        v2 = v1;
        if (v2 >= v3) /* goto L_00b6 */;
        _result = v11.b(v2); // android.support.v4.view.z.b -> int
        v4 = _result;
        _result = v11.c(v2); // android.support.v4.view.z.c -> float
        v5 = _result;
        _result = v11.d(v2); // android.support.v4.view.z.d -> float
        v6 = _result;
        v7 = v10.d; // android.support.v4.widget.am.d:float[]
        v7 = v7[v4];
        v7 = binOp_0xa7(v5, v7);
        v8 = v10.e; // android.support.v4.widget.am.e:float[]
        v8 = v8[v4];
        v8 = binOp_0xa7(v6, v8);
        _result = v10.b(v7, v8, v4); // android.support.v4.widget.am.b -> void
        v9 = v10.a; // android.support.v4.widget.am.a:int
        if (v9 != v0) /* goto L_00bb */;
        _result = v10.c(v11); // android.support.v4.widget.am.c -> void
        // goto L_0022
        v5 = unaryOp_0x87(v5);
        v6 = unaryOp_0x87(v6);
        _result = v10.d(v5, v6); // android.support.v4.widget.am.d -> android.view.View
        v5 = _result;
        if (v5 == 0) /* goto L_00cf */;
        _result = v10.a(v5, v7, v8); // android.support.v4.widget.am.a -> boolean
        v6 = _result;
        if (v6 == 0) /* goto L_00cf */;
        _result = v10.b(v5, v4); // android.support.v4.widget.am.b -> boolean
        v4 = _result;
        if (v4 != 0) /* goto L_00b6 */;
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_0095
        _result = v11.b(v3); // android.support.v4.view.z.b -> int
        v2 = _result;
        _result = v10.e(v2); // android.support.v4.widget.am.e -> void
        // goto L_0022
        _result = v10.e(); // android.support.v4.widget.am.e -> void
        // goto L_0022
        v0 = v1;
        // goto L_0026
    }

    public boolean a(android.view.View p0, int p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int), v5 = p2 (int)
        v1 = 0;
        v2.s = v3; // android.support.v4.widget.am.s:android.view.View
        v0 = -1;
        v2.c = v0; // android.support.v4.widget.am.c:int
        _result = v2.a(v4, v5, v1, v1); // android.support.v4.widget.am.a -> boolean
        v0 = _result;
        return v0;
    }

    public boolean a(boolean p0) {
        // Registers (11 total): v9 = this, v10 = p0 (boolean)
        v8 = 2;
        v6 = 0;
        v0 = v9.a; // android.support.v4.widget.am.a:int
        if (v0 != v8) /* goto L_0069 */;
        v0 = v9.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.f(); // android.support.v4.widget.t.f -> boolean
        v7 = _result;
        v0 = v9.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.b(); // android.support.v4.widget.t.b -> int
        v2 = _result;
        v0 = v9.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.c(); // android.support.v4.widget.t.c -> int
        v3 = _result;
        v0 = v9.s; // android.support.v4.widget.am.s:android.view.View
        _result = v0.getLeft(); // android.view.View.getLeft -> int
        v0 = _result;
        v4 = binOp_0x91(v2, v0);
        v0 = v9.s; // android.support.v4.widget.am.s:android.view.View
        _result = v0.getTop(); // android.view.View.getTop -> int
        v0 = _result;
        v5 = binOp_0x91(v3, v0);
        if (v4 == 0) /* goto L_002f */;
        v0 = v9.s; // android.support.v4.widget.am.s:android.view.View
        _result = v0.offsetLeftAndRight(v4); // android.view.View.offsetLeftAndRight -> void
        if (v5 == 0) /* goto L_0036 */;
        v0 = v9.s; // android.support.v4.widget.am.s:android.view.View
        _result = v0.offsetTopAndBottom(v5); // android.view.View.offsetTopAndBottom -> void
        if (v4 != 0) /* goto L_003a */;
        if (v5 == 0) /* goto L_0041 */;
        v0 = v9.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        v1 = v9.s; // android.support.v4.widget.am.s:android.view.View
        _result = v0.a(v0..v5); // android.support.v4.widget.ap.a -> void
        if (v7 == 0) /* goto L_0075 */;
        v0 = v9.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.d(); // android.support.v4.widget.t.d -> int
        v0 = _result;
        if (v2 != v0) /* goto L_0075 */;
        v0 = v9.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.e(); // android.support.v4.widget.t.e -> int
        v0 = _result;
        if (v3 != v0) /* goto L_0075 */;
        v0 = v9.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.g(); // android.support.v4.widget.t.g -> void
        v0 = v9.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.a(); // android.support.v4.widget.t.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0069 */;
        if (v10 == 0) /* goto L_006f */;
        v0 = v9.u; // android.support.v4.widget.am.u:android.view.ViewGroup
        v1 = v9.w; // android.support.v4.widget.am.w:java.lang.Runnable
        _result = v0.post(v1); // android.view.ViewGroup.post -> boolean
        v0 = v9.a; // android.support.v4.widget.am.a:int
        if (v0 != v8) /* goto L_0073 */;
        v0 = 1;
        return v0;
        _result = v9.c(v6); // android.support.v4.widget.am.c -> void
        // goto L_0069
        v0 = v6;
        // goto L_006e
        v0 = v7;
        // goto L_005e
    }

    public int b() {
        // Registers (2 total): v1 = this
        v0 = v1.o; // android.support.v4.widget.am.o:int
        return v0;
    }

    public void b(android.view.MotionEvent p0) {
        // Registers (11 total): v9 = this, v10 = p0 (android.view.MotionEvent)
        v1 = -1;
        v5 = 0;
        v0 = 0;
        v8 = 1;
        _result = v10.a(); // android.support.v4.view.z.a -> int
        v2 = _result;
        _result = v10.b(); // android.support.v4.view.z.b -> int
        v3 = _result;
        if (v2 != 0) /* goto L_0011 */;
        _result = v9.e(); // android.support.v4.widget.am.e -> void
        v4 = v9.l; // android.support.v4.widget.am.l:android.view.VelocityTracker
        if (v4 != 0) /* goto L_001b */;
        _result = this.obtain(); // android.view.VelocityTracker.obtain -> android.view.VelocityTracker
        v4 = _result;
        v9.l = v4; // android.support.v4.widget.am.l:android.view.VelocityTracker
        v4 = v9.l; // android.support.v4.widget.am.l:android.view.VelocityTracker
        _result = v4.addMovement(v10); // android.view.VelocityTracker.addMovement -> void
        // switch(v2)
        return;
        _result = v10.getX(); // android.view.MotionEvent.getX -> float
        v1 = _result;
        _result = v10.getY(); // android.view.MotionEvent.getY -> float
        v2 = _result;
        _result = v10.b(v0); // android.support.v4.view.z.b -> int
        v0 = _result;
        v3 = unaryOp_0x87(v1);
        v4 = unaryOp_0x87(v2);
        _result = v9.d(v3, v4); // android.support.v4.widget.am.d -> android.view.View
        v3 = _result;
        _result = v9.a(v1, v2, v0); // android.support.v4.widget.am.a -> void
        _result = v9.b(v3, v0); // android.support.v4.widget.am.b -> boolean
        v1 = v9.h; // android.support.v4.widget.am.h:int[]
        v1 = v1[v0];
        v2 = v9.p; // android.support.v4.widget.am.p:int
        v2 = binOp2addr_0xb5(v2, v1);
        if (v2 == 0) /* goto L_0023 */;
        v2 = v9.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        v3 = v9.p; // android.support.v4.widget.am.p:int
        v1 = binOp2addr_0xb5(v1, v3);
        _result = v2.a(v1, v0); // android.support.v4.widget.ap.a -> void
        // goto L_0023
        _result = v10.b(v3); // android.support.v4.view.z.b -> int
        v0 = _result;
        _result = v10.c(v3); // android.support.v4.view.z.c -> float
        v1 = _result;
        _result = v10.d(v3); // android.support.v4.view.z.d -> float
        v2 = _result;
        _result = v9.a(v1, v2, v0); // android.support.v4.widget.am.a -> void
        v3 = v9.a; // android.support.v4.widget.am.a:int
        if (v3 != 0) /* goto L_007c */;
        v1 = unaryOp_0x87(v1);
        v2 = unaryOp_0x87(v2);
        _result = v9.d(v1, v2); // android.support.v4.widget.am.d -> android.view.View
        v1 = _result;
        _result = v9.b(v1, v0); // android.support.v4.widget.am.b -> boolean
        v1 = v9.h; // android.support.v4.widget.am.h:int[]
        v1 = v1[v0];
        v2 = v9.p; // android.support.v4.widget.am.p:int
        v2 = binOp2addr_0xb5(v2, v1);
        if (v2 == 0) /* goto L_0023 */;
        v2 = v9.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        v3 = v9.p; // android.support.v4.widget.am.p:int
        v1 = binOp2addr_0xb5(v1, v3);
        _result = v2.a(v1, v0); // android.support.v4.widget.ap.a -> void
        // goto L_0023
        v1 = unaryOp_0x87(v1);
        v2 = unaryOp_0x87(v2);
        _result = v9.c(v1, v2); // android.support.v4.widget.am.c -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0023 */;
        v1 = v9.s; // android.support.v4.widget.am.s:android.view.View
        _result = v9.b(v1, v0); // android.support.v4.widget.am.b -> boolean
        // goto L_0023
        v1 = v9.a; // android.support.v4.widget.am.a:int
        if (v1 != v8) /* goto L_00c2 */;
        v0 = v9.c; // android.support.v4.widget.am.c:int
        _result = v10.a(v0); // android.support.v4.view.z.a -> int
        v0 = _result;
        _result = v10.c(v0); // android.support.v4.view.z.c -> float
        v1 = _result;
        _result = v10.d(v0); // android.support.v4.view.z.d -> float
        v0 = _result;
        v2 = v9.f; // android.support.v4.widget.am.f:float[]
        v3 = v9.c; // android.support.v4.widget.am.c:int
        v2 = v2[v3];
        v1 = binOp2addr_0xc7(v1, v2);
        v1 = unaryOp_0x87(v1);
        v2 = v9.g; // android.support.v4.widget.am.g:float[]
        v3 = v9.c; // android.support.v4.widget.am.c:int
        v2 = v2[v3];
        v0 = binOp2addr_0xc7(v0, v2);
        v0 = unaryOp_0x87(v0);
        v2 = v9.s; // android.support.v4.widget.am.s:android.view.View
        _result = v2.getLeft(); // android.view.View.getLeft -> int
        v2 = _result;
        v2 = binOp2addr_0xb0(v2, v1);
        v3 = v9.s; // android.support.v4.widget.am.s:android.view.View
        _result = v3.getTop(); // android.view.View.getTop -> int
        v3 = _result;
        v3 = binOp2addr_0xb0(v3, v0);
        _result = v9.b(v2, v3, v1, v0); // android.support.v4.widget.am.b -> void
        _result = v9.c(v10); // android.support.v4.widget.am.c -> void
        // goto L_0023
        _result = v10.c(); // android.support.v4.view.z.c -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_00e7 */;
        _result = v10.b(v0); // android.support.v4.view.z.b -> int
        v2 = _result;
        _result = v10.c(v0); // android.support.v4.view.z.c -> float
        v3 = _result;
        _result = v10.d(v0); // android.support.v4.view.z.d -> float
        v4 = _result;
        v5 = v9.d; // android.support.v4.widget.am.d:float[]
        v5 = v5[v2];
        v5 = binOp_0xa7(v3, v5);
        v6 = v9.e; // android.support.v4.widget.am.e:float[]
        v6 = v6[v2];
        v6 = binOp_0xa7(v4, v6);
        _result = v9.b(v5, v6, v2); // android.support.v4.widget.am.b -> void
        v7 = v9.a; // android.support.v4.widget.am.a:int
        if (v7 != v8) /* goto L_00ec */;
        _result = v9.c(v10); // android.support.v4.widget.am.c -> void
        // goto L_0023
        v3 = unaryOp_0x87(v3);
        v4 = unaryOp_0x87(v4);
        _result = v9.d(v3, v4); // android.support.v4.widget.am.d -> android.view.View
        v3 = _result;
        _result = v9.a(v3, v5, v6); // android.support.v4.widget.am.a -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_00fe */;
        _result = v9.b(v3, v2); // android.support.v4.widget.am.b -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_00e7 */;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_00c6
        _result = v10.b(v3); // android.support.v4.view.z.b -> int
        v2 = _result;
        v3 = v9.a; // android.support.v4.widget.am.a:int
        if (v3 != v8) /* goto L_013f */;
        v3 = v9.c; // android.support.v4.widget.am.c:int
        if (v2 != v3) /* goto L_013f */;
        _result = v10.c(); // android.support.v4.view.z.c -> int
        v3 = _result;
        if (v0 >= v3) /* goto L_015c */;
        _result = v10.b(v0); // android.support.v4.view.z.b -> int
        v4 = _result;
        v5 = v9.c; // android.support.v4.widget.am.c:int
        if (v4 != v5) /* goto L_011e */;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0111
        _result = v10.c(v0); // android.support.v4.view.z.c -> float
        v5 = _result;
        _result = v10.d(v0); // android.support.v4.view.z.d -> float
        v6 = _result;
        v5 = unaryOp_0x87(v5);
        v6 = unaryOp_0x87(v6);
        _result = v9.d(v5, v6); // android.support.v4.widget.am.d -> android.view.View
        v5 = _result;
        v6 = v9.s; // android.support.v4.widget.am.s:android.view.View
        if (v5 != v6) /* goto L_011b */;
        v5 = v9.s; // android.support.v4.widget.am.s:android.view.View
        _result = v9.b(v5, v4); // android.support.v4.widget.am.b -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_011b */;
        v0 = v9.c; // android.support.v4.widget.am.c:int
        if (v0 != v1) /* goto L_013f */;
        _result = v9.h(); // android.support.v4.widget.am.h -> void
        _result = v9.e(v2); // android.support.v4.widget.am.e -> void
        // goto L_0023
        v0 = v9.a; // android.support.v4.widget.am.a:int
        if (v0 != v8) /* goto L_014b */;
        _result = v9.h(); // android.support.v4.widget.am.h -> void
        _result = v9.e(); // android.support.v4.widget.am.e -> void
        // goto L_0023
        v0 = v9.a; // android.support.v4.widget.am.a:int
        if (v0 != v8) /* goto L_0157 */;
        _result = v9.a(v5, v5); // android.support.v4.widget.am.a -> void
        _result = v9.e(); // android.support.v4.widget.am.e -> void
        // goto L_0023
        v0 = v1;
        // goto L_013a
    }

    public boolean b(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = 1;
        v1 = v3.k; // android.support.v4.widget.am.k:int
        v2 = binOp_0x98(v0, v4);
        v1 = binOp2addr_0xb5(v1, v2);
        if (v1 == 0) /* goto L_0009 */;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public boolean b(int p0, int p1) {
        // Registers (10 total): v7 = this, v8 = p0 (int), v9 = p1 (int)
        v1 = 1;
        v2 = 0;
        _result = v7.b(v9); // android.support.v4.widget.am.b -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v1 = v2;
        return v1;
        v0 = binOpLit8_0xdd(v8, 1);
        if (v0 != v1) /* goto L_003c */;
        v3 = v1;
        v0 = binOpLit8_0xdd(v8, 2);
        v4 = 2;
        if (v0 != v4) /* goto L_003e */;
        v0 = v1;
        v4 = v7.f; // android.support.v4.widget.am.f:float[]
        v4 = v4[v9];
        v5 = v7.d; // android.support.v4.widget.am.d:float[]
        v5 = v5[v9];
        v4 = binOp2addr_0xc7(v4, v5);
        v5 = v7.g; // android.support.v4.widget.am.g:float[]
        v5 = v5[v9];
        v6 = v7.e; // android.support.v4.widget.am.e:float[]
        v6 = v6[v9];
        v5 = binOp2addr_0xc7(v5, v6);
        if (v3 == 0) /* goto L_0040 */;
        if (v0 == 0) /* goto L_0040 */;
        v0 = binOp_0xa8(v4, v4);
        v3 = binOp_0xa8(v5, v5);
        v0 = binOp2addr_0xc6(v0, v3);
        v3 = v7.b; // android.support.v4.widget.am.b:int
        v4 = v7.b; // android.support.v4.widget.am.b:int
        v3 = binOp2addr_0xb2(v3, v4);
        v3 = unaryOp_0x82(v3);
        v0 = cmp(v0, v3);
        if (v0 > 0) /* goto L_0009 */;
        v1 = v2;
        // goto L_0009
        v3 = v2;
        // goto L_000f
        v0 = v2;
        // goto L_0015
        if (v3 == 0) /* goto L_004f */;
        _result = v4.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v3 = v7.b; // android.support.v4.widget.am.b:int
        v3 = unaryOp_0x82(v3);
        v0 = cmp(v0, v3);
        if (v0 > 0) /* goto L_0009 */;
        v1 = v2;
        // goto L_0009
        if (v0 == 0) /* goto L_005e */;
        _result = v5.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v3 = v7.b; // android.support.v4.widget.am.b:int
        v3 = unaryOp_0x82(v3);
        v0 = cmp(v0, v3);
        if (v0 > 0) /* goto L_0009 */;
        v1 = v2;
        // goto L_0009
        v1 = v2;
        // goto L_0009
    }

    boolean b(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = 1;
        v1 = v2.s; // android.support.v4.widget.am.s:android.view.View
        if (v3 != v1) /* goto L_000a */;
        v1 = v2.c; // android.support.v4.widget.am.c:int
        if (v1 != v4) /* goto L_000a */;
        return v0;
        if (v3 == 0) /* goto L_001a */;
        v1 = v2.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        _result = v1.a(v3, v4); // android.support.v4.widget.ap.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_001a */;
        v2.c = v4; // android.support.v4.widget.am.c:int
        _result = v2.a(v3, v4); // android.support.v4.widget.am.a -> void
        // goto L_0009
        v0 = 0;
        // goto L_0009
    }

    public boolean b(android.view.View p0, int p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int), v5 = p2 (int)
        v0 = 0;
        if (v3 != 0) /* goto L_0004 */;
        return v0;
        _result = v3.getLeft(); // android.view.View.getLeft -> int
        v1 = _result;
        if (v4 < v1) /* goto L_0003 */;
        _result = v3.getRight(); // android.view.View.getRight -> int
        v1 = _result;
        if (v4 >= v1) /* goto L_0003 */;
        _result = v3.getTop(); // android.view.View.getTop -> int
        v1 = _result;
        if (v5 < v1) /* goto L_0003 */;
        _result = v3.getBottom(); // android.view.View.getBottom -> int
        v1 = _result;
        if (v5 >= v1) /* goto L_0003 */;
        v0 = 1;
        // goto L_0003
    }

    public android.view.View c() {
        // Registers (2 total): v1 = this
        v0 = v1.s; // android.support.v4.widget.am.s:android.view.View
        return v0;
    }

    void c(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // android.support.v4.widget.am.a:int
        if (v0 == v2) /* goto L_0010 */;
        v1.a = v2; // android.support.v4.widget.am.a:int
        v0 = v1.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        _result = v0.a(v2); // android.support.v4.widget.ap.a -> void
        if (v2 != 0) /* goto L_0010 */;
        v0 = 0;
        v1.s = v0; // android.support.v4.widget.am.s:android.view.View
        return;
    }

    public boolean c(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = v1.s; // android.support.v4.widget.am.s:android.view.View
        _result = v1.b(v0, v2, v3); // android.support.v4.widget.am.b -> boolean
        v0 = _result;
        return v0;
    }

    public int d() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.widget.am.b:int
        return v0;
    }

    public android.view.View d(int p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (int)
        v0 = v3.u; // android.support.v4.widget.am.u:android.view.ViewGroup
        _result = v0.getChildCount(); // android.view.ViewGroup.getChildCount -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0034 */;
        v0 = v3.u; // android.support.v4.widget.am.u:android.view.ViewGroup
        v2 = v3.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        _result = v2.c(v1); // android.support.v4.widget.ap.c -> int
        v2 = _result;
        _result = v0.getChildAt(v2); // android.view.ViewGroup.getChildAt -> android.view.View
        v0 = _result;
        _result = v0.getLeft(); // android.view.View.getLeft -> int
        v2 = _result;
        if (v4 < v2) /* goto L_0030 */;
        _result = v0.getRight(); // android.view.View.getRight -> int
        v2 = _result;
        if (v4 >= v2) /* goto L_0030 */;
        _result = v0.getTop(); // android.view.View.getTop -> int
        v2 = _result;
        if (v5 < v2) /* goto L_0030 */;
        _result = v0.getBottom(); // android.view.View.getBottom -> int
        v2 = _result;
        if (v5 >= v2) /* goto L_0030 */;
        return v0;
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0009
        v0 = 0;
        // goto L_002f
    }

    public boolean d(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        v0 = 0;
        v1 = v4.d; // android.support.v4.widget.am.d:float[]
        v2 = v1.length;
        v1 = v0;
        if (v1 >= v2) /* goto L_000e */;
        _result = v4.b(v5, v1); // android.support.v4.widget.am.b -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_000f */;
        v0 = 1;
        return v0;
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0005
    }

    public void e() {
        // Registers (2 total): v1 = this
        v0 = -1;
        v1.c = v0; // android.support.v4.widget.am.c:int
        _result = v1.g(); // android.support.v4.widget.am.g -> void
        v0 = v1.l; // android.support.v4.widget.am.l:android.view.VelocityTracker
        if (v0 == 0) /* goto L_0012 */;
        v0 = v1.l; // android.support.v4.widget.am.l:android.view.VelocityTracker
        _result = v0.recycle(); // android.view.VelocityTracker.recycle -> void
        v0 = 0;
        v1.l = v0; // android.support.v4.widget.am.l:android.view.VelocityTracker
        return;
    }

    public void f() {
        // Registers (7 total): v6 = this
        _result = v6.e(); // android.support.v4.widget.am.e -> void
        v0 = v6.a; // android.support.v4.widget.am.a:int
        v1 = 2;
        if (v0 != v1) /* goto L_0030 */;
        v0 = v6.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.b(); // android.support.v4.widget.t.b -> int
        v4 = _result;
        v0 = v6.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.c(); // android.support.v4.widget.t.c -> int
        v5 = _result;
        v0 = v6.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.g(); // android.support.v4.widget.t.g -> void
        v0 = v6.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.b(); // android.support.v4.widget.t.b -> int
        v2 = _result;
        v0 = v6.q; // android.support.v4.widget.am.q:android.support.v4.widget.t
        _result = v0.c(); // android.support.v4.widget.t.c -> int
        v3 = _result;
        v0 = v6.r; // android.support.v4.widget.am.r:android.support.v4.widget.ap
        v1 = v6.s; // android.support.v4.widget.am.s:android.view.View
        v4 = binOp_0x91(v2, v4);
        v5 = binOp_0x91(v3, v5);
        _result = v0.a(v0..v5); // android.support.v4.widget.ap.a -> void
        v0 = 0;
        _result = v6.c(v0); // android.support.v4.widget.am.c -> void
        return;
    }

}