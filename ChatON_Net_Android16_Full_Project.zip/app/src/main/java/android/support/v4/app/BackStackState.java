package android.support.v4.app;

/**
 * Original SourceFile: BackStackRecord.java
 * Descriptor: Landroid/support/v4/app/BackStackState;
 */
final class BackStackState implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
    final int mBreadCrumbShortTitleRes;
    final java.lang.CharSequence mBreadCrumbShortTitleText;
    final int mBreadCrumbTitleRes;
    final java.lang.CharSequence mBreadCrumbTitleText;
    final int mIndex;
    final java.lang.String mName;
    final int[] mOps;
    final int mTransition;
    final int mTransitionStyle;

    static {
        v0 = new android.support.v4.app.n;
        _result = v0.<init>(); // android.support.v4.app.n.<init> -> void
        android.support.v4.app.BackStackState.CREATOR = v0; // :android.os.Parcelable$Creator
        return;
    }

    public BackStackState(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        _result = v2.createIntArray(); // android.os.Parcel.createIntArray -> int[]
        v0 = _result;
        v1.mOps = v0; // android.support.v4.app.BackStackState.mOps:int[]
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.mTransition = v0; // android.support.v4.app.BackStackState.mTransition:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.mTransitionStyle = v0; // android.support.v4.app.BackStackState.mTransitionStyle:int
        _result = v2.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        v1.mName = v0; // android.support.v4.app.BackStackState.mName:java.lang.String
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.mIndex = v0; // android.support.v4.app.BackStackState.mIndex:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.mBreadCrumbTitleRes = v0; // android.support.v4.app.BackStackState.mBreadCrumbTitleRes:int
        v0 = android.text.TextUtils.CHAR_SEQUENCE_CREATOR; // :android.os.Parcelable$Creator
        _result = android.os.Parcelable$Creator.createFromParcel(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.CharSequence) v0;
        v1.mBreadCrumbTitleText = v0; // android.support.v4.app.BackStackState.mBreadCrumbTitleText:java.lang.CharSequence
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.mBreadCrumbShortTitleRes = v0; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleRes:int
        v0 = android.text.TextUtils.CHAR_SEQUENCE_CREATOR; // :android.os.Parcelable$Creator
        _result = android.os.Parcelable$Creator.createFromParcel(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.CharSequence) v0;
        v1.mBreadCrumbShortTitleText = v0; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleText:java.lang.CharSequence
        return;
    }

    public BackStackState(android.support.v4.app.y p0, android.support.v4.app.l p1) {
        // Registers (11 total): v8 = this, v9 = p0 (android.support.v4.app.y), v10 = p1 (android.support.v4.app.l)
        v3 = 0;
        _result = v8.<init>(); // java.lang.Object.<init> -> void
        v0 = v10.b; // android.support.v4.app.l.b:android.support.v4.app.m
        v1 = v0;
        v0 = v3;
        if (v1 == 0) /* goto L_0018 */;
        v2 = v1.i; // android.support.v4.app.m.i:java.util.ArrayList
        if (v2 == 0) /* goto L_0015 */;
        v2 = v1.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v1 = v1.a; // android.support.v4.app.m.a:android.support.v4.app.m
        // goto L_0008
        v1 = v10.d; // android.support.v4.app.l.d:int
        v1 = binOpLit8_0xda(v1, 7);
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = new int[][size=v0];
        v8.mOps = v0; // android.support.v4.app.BackStackState.mOps:int[]
        v0 = v10.k; // android.support.v4.app.l.k:boolean
        if (v0 != 0) /* goto L_002e */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Not on back stack";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v10.b; // android.support.v4.app.l.b:android.support.v4.app.m
        v5 = v0;
        v0 = v3;
        if (v5 == 0) /* goto L_00a0 */;
        v1 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v2 = binOpLit8_0xd8(v0, 1);
        v4 = v5.c; // android.support.v4.app.m.c:int
        v1[v0] = v4;
        v1 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v4 = binOpLit8_0xd8(v2, 1);
        v0 = v5.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0092 */;
        v0 = v5.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v0 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v1[v2] = v0;
        v0 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v1 = binOpLit8_0xd8(v4, 1);
        v2 = v5.e; // android.support.v4.app.m.e:int
        v0[v4] = v2;
        v0 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v2 = binOpLit8_0xd8(v1, 1);
        v4 = v5.f; // android.support.v4.app.m.f:int
        v0[v1] = v4;
        v0 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v1 = binOpLit8_0xd8(v2, 1);
        v4 = v5.g; // android.support.v4.app.m.g:int
        v0[v2] = v4;
        v0 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v2 = binOpLit8_0xd8(v1, 1);
        v4 = v5.h; // android.support.v4.app.m.h:int
        v0[v1] = v4;
        v0 = v5.i; // android.support.v4.app.m.i:java.util.ArrayList
        if (v0 == 0) /* goto L_0099 */;
        v0 = v5.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v6 = _result;
        v0 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v1 = binOpLit8_0xd8(v2, 1);
        v0[v2] = v6;
        v2 = v3;
        if (v2 >= v6) /* goto L_0094 */;
        v7 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v4 = binOpLit8_0xd8(v1, 1);
        v0 = v5.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v0 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v7[v1] = v0;
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        v1 = v4;
        // goto L_007b
        v0 = -1;
        // goto L_0048
        v0 = v1;
        v1 = v5.a; // android.support.v4.app.m.a:android.support.v4.app.m
        v5 = v1;
        // goto L_0032
        v1 = v8.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v0 = binOpLit8_0xd8(v2, 1);
        v1[v2] = v3;
        // goto L_0095
        v0 = v10.i; // android.support.v4.app.l.i:int
        v8.mTransition = v0; // android.support.v4.app.BackStackState.mTransition:int
        v0 = v10.j; // android.support.v4.app.l.j:int
        v8.mTransitionStyle = v0; // android.support.v4.app.BackStackState.mTransitionStyle:int
        v0 = v10.m; // android.support.v4.app.l.m:java.lang.String
        v8.mName = v0; // android.support.v4.app.BackStackState.mName:java.lang.String
        v0 = v10.o; // android.support.v4.app.l.o:int
        v8.mIndex = v0; // android.support.v4.app.BackStackState.mIndex:int
        v0 = v10.p; // android.support.v4.app.l.p:int
        v8.mBreadCrumbTitleRes = v0; // android.support.v4.app.BackStackState.mBreadCrumbTitleRes:int
        v0 = v10.q; // android.support.v4.app.l.q:java.lang.CharSequence
        v8.mBreadCrumbTitleText = v0; // android.support.v4.app.BackStackState.mBreadCrumbTitleText:java.lang.CharSequence
        v0 = v10.r; // android.support.v4.app.l.r:int
        v8.mBreadCrumbShortTitleRes = v0; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleRes:int
        v0 = v10.s; // android.support.v4.app.l.s:java.lang.CharSequence
        v8.mBreadCrumbShortTitleText = v0; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleText:java.lang.CharSequence
        return;
    }

    public android.support.v4.app.l a(android.support.v4.app.y p0) {
        // Registers (13 total): v11 = this, v12 = p0 (android.support.v4.app.y)
        v10 = 1;
        v2 = 0;
        v6 = new android.support.v4.app.l;
        _result = v6.<init>(v12); // android.support.v4.app.l.<init> -> void
        v1 = v2;
        v0 = v2;
        v3 = v11.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v3 = v3.length;
        if (v0 >= v3) /* goto L_00e9 */;
        v7 = new android.support.v4.app.m;
        _result = v7.<init>(); // android.support.v4.app.m.<init> -> void
        v3 = v11.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v4 = binOpLit8_0xd8(v0, 1);
        v0 = v3[v0];
        v7.c = v0; // android.support.v4.app.m.c:int
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0053 */;
        v0 = "FragmentManager";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "Instantiate ";
        _result = v3.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v5 = " op #";
        _result = v3.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v5 = " base fragment #";
        _result = v3.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v5 = v11.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v5 = v5[v4];
        _result = v3.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v0.v(v3); // android.util.Log.v -> int
        v0 = v11.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v3 = binOpLit8_0xd8(v4, 1);
        v0 = v0[v4];
        if (v0 < 0) /* goto L_00dc */;
        v4 = v12.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v4.get(v0); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v7.d = v0; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v0 = v11.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v4 = binOpLit8_0xd8(v3, 1);
        v0 = v0[v3];
        v7.e = v0; // android.support.v4.app.m.e:int
        v0 = v11.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v3 = binOpLit8_0xd8(v4, 1);
        v0 = v0[v4];
        v7.f = v0; // android.support.v4.app.m.f:int
        v0 = v11.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v4 = binOpLit8_0xd8(v3, 1);
        v0 = v0[v3];
        v7.g = v0; // android.support.v4.app.m.g:int
        v0 = v11.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v5 = binOpLit8_0xd8(v4, 1);
        v0 = v0[v4];
        v7.h = v0; // android.support.v4.app.m.h:int
        v0 = v11.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v3 = binOpLit8_0xd8(v5, 1);
        v8 = v0[v5];
        if (v8 <= 0) /* goto L_00e0 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(v8); // java.util.ArrayList.<init> -> void
        v7.i = v0; // android.support.v4.app.m.i:java.util.ArrayList
        v4 = v2;
        if (v4 >= v8) /* goto L_00e0 */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_00c4 */;
        v0 = "FragmentManager";
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        v9 = "Instantiate ";
        _result = v5.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v9 = " set remove fragment #";
        _result = v5.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v9 = v11.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v9 = v9[v3];
        _result = v5.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v5 = _result;
        _result = v0.v(v5); // android.util.Log.v -> int
        v0 = v12.f; // android.support.v4.app.y.f:java.util.ArrayList
        v9 = v11.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        v5 = binOpLit8_0xd8(v3, 1);
        v3 = v9[v3];
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v3 = v7.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v3.add(v0); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v4, 1);
        v4 = v0;
        v3 = v5;
        // goto L_0095
        v0 = 0;
        v7.d = v0; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        // goto L_0065
        _result = v6.a(v7); // android.support.v4.app.l.a -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        v0 = v3;
        // goto L_0009
        v0 = v11.mTransition; // android.support.v4.app.BackStackState.mTransition:int
        v6.i = v0; // android.support.v4.app.l.i:int
        v0 = v11.mTransitionStyle; // android.support.v4.app.BackStackState.mTransitionStyle:int
        v6.j = v0; // android.support.v4.app.l.j:int
        v0 = v11.mName; // android.support.v4.app.BackStackState.mName:java.lang.String
        v6.m = v0; // android.support.v4.app.l.m:java.lang.String
        v0 = v11.mIndex; // android.support.v4.app.BackStackState.mIndex:int
        v6.o = v0; // android.support.v4.app.l.o:int
        v6.k = v10; // android.support.v4.app.l.k:boolean
        v0 = v11.mBreadCrumbTitleRes; // android.support.v4.app.BackStackState.mBreadCrumbTitleRes:int
        v6.p = v0; // android.support.v4.app.l.p:int
        v0 = v11.mBreadCrumbTitleText; // android.support.v4.app.BackStackState.mBreadCrumbTitleText:java.lang.CharSequence
        v6.q = v0; // android.support.v4.app.l.q:java.lang.CharSequence
        v0 = v11.mBreadCrumbShortTitleRes; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleRes:int
        v6.r = v0; // android.support.v4.app.l.r:int
        v0 = v11.mBreadCrumbShortTitleText; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleText:java.lang.CharSequence
        v6.s = v0; // android.support.v4.app.l.s:java.lang.CharSequence
        _result = v6.a(v10); // android.support.v4.app.l.a -> void
        return v6;
    }

    public int describeContents() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.os.Parcel), v4 = p1 (int)
        v1 = 0;
        v0 = v2.mOps; // android.support.v4.app.BackStackState.mOps:int[]
        _result = v3.writeIntArray(v0); // android.os.Parcel.writeIntArray -> void
        v0 = v2.mTransition; // android.support.v4.app.BackStackState.mTransition:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.mTransitionStyle; // android.support.v4.app.BackStackState.mTransitionStyle:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.mName; // android.support.v4.app.BackStackState.mName:java.lang.String
        _result = v3.writeString(v0); // android.os.Parcel.writeString -> void
        v0 = v2.mIndex; // android.support.v4.app.BackStackState.mIndex:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.mBreadCrumbTitleRes; // android.support.v4.app.BackStackState.mBreadCrumbTitleRes:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.mBreadCrumbTitleText; // android.support.v4.app.BackStackState.mBreadCrumbTitleText:java.lang.CharSequence
        _result = v0.writeToParcel(v3, v1); // android.text.TextUtils.writeToParcel -> void
        v0 = v2.mBreadCrumbShortTitleRes; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleRes:int
        _result = v3.writeInt(v0); // android.os.Parcel.writeInt -> void
        v0 = v2.mBreadCrumbShortTitleText; // android.support.v4.app.BackStackState.mBreadCrumbShortTitleText:java.lang.CharSequence
        _result = v0.writeToParcel(v3, v1); // android.text.TextUtils.writeToParcel -> void
        return;
    }

}