package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/aa;
 */
class aa implements java.lang.Runnable {
    final int a;
    final int b;
    final android.support.v4.app.y c;

    aa(android.support.v4.app.y p0, int p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.support.v4.app.y), v2 = p1 (int), v3 = p2 (int)
        v0.c = v1; // android.support.v4.app.aa.c:android.support.v4.app.y
        v0.a = v2; // android.support.v4.app.aa.a:int
        v0.b = v3; // android.support.v4.app.aa.b:int
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (6 total): v5 = this
        v0 = v5.c; // android.support.v4.app.aa.c:android.support.v4.app.y
        v1 = v5.c; // android.support.v4.app.aa.c:android.support.v4.app.y
        v1 = v1.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v1 = v1.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        v2 = 0;
        v3 = v5.a; // android.support.v4.app.aa.a:int
        v4 = v5.b; // android.support.v4.app.aa.b:int
        _result = v0.a(v1, v2, v3, v4); // android.support.v4.app.y.a -> boolean
        return;
    }

}