package android.support.v4.widget;

/**
 * Original SourceFile: DrawerLayout.java
 * Descriptor: Landroid/support/v4/widget/m;
 */
class m implements java.lang.Runnable {
    final android.support.v4.widget.l a;

    m(android.support.v4.widget.l p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.l)
        v0.a = v1; // android.support.v4.widget.m.a:android.support.v4.widget.l
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.widget.m.a:android.support.v4.widget.l
        _result = v0.a(); // android.support.v4.widget.l.a -> void
        return;
    }

}