package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/cf;
 */
final class cf implements android.support.v4.b.c {
    cf() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.lang.Object a(android.os.Parcel p0, java.lang.ClassLoader p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (java.lang.ClassLoader)
        _result = v1.b(v2, v3); // android.support.v4.view.cf.b -> android.support.v4.view.ViewPager$SavedState
        v0 = _result;
        return v0;
    }

    public java.lang.Object[] a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.b(v2); // android.support.v4.view.cf.b -> android.support.v4.view.ViewPager$SavedState[]
        v0 = _result;
        return v0;
    }

    public android.support.v4.view.ViewPager$SavedState b(android.os.Parcel p0, java.lang.ClassLoader p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (java.lang.ClassLoader)
        v0 = new android.support.v4.view.ViewPager$SavedState;
        _result = v0.<init>(v2, v3); // android.support.v4.view.ViewPager$SavedState.<init> -> void
        return v0;
    }

    public android.support.v4.view.ViewPager$SavedState[] b(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = new android.support.v4.view.ViewPager$SavedState[][size=v2];
        return v0;
    }

}