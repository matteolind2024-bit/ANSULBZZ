package android.support.v4.view;

/**
 * Original SourceFile: PagerTitleStrip.java
 * Descriptor: Landroid/support/v4/view/ai;
 */
class ai extends android.database.DataSetObserver implements android.support.v4.view.cb, android.support.v4.view.cc {
    final android.support.v4.view.PagerTitleStrip a;
    private int b;

    private ai(android.support.v4.view.PagerTitleStrip p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.PagerTitleStrip)
        v0.a = v1; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        _result = v0.<init>(); // android.database.DataSetObserver.<init> -> void
        return;
    }

    ai(android.support.v4.view.PagerTitleStrip p0, android.support.v4.view.ah p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.view.PagerTitleStrip), v2 = p1 (android.support.v4.view.ah)
        _result = v0.<init>(v1); // android.support.v4.view.ai.<init> -> void
        return;
    }

    public void a(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        v0 = 0;
        v1 = v4.b; // android.support.v4.view.ai.b:int
        if (v1 != 0) /* goto L_0038 */;
        v1 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        v2 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        v2 = v2.a; // android.support.v4.view.PagerTitleStrip.a:android.support.v4.view.ViewPager
        _result = v2.c(); // android.support.v4.view.ViewPager.c -> int
        v2 = _result;
        v3 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        v3 = v3.a; // android.support.v4.view.PagerTitleStrip.a:android.support.v4.view.ViewPager
        _result = v3.b(); // android.support.v4.view.ViewPager.b -> android.support.v4.view.ae
        v3 = _result;
        _result = v1.a(v2, v3); // android.support.v4.view.PagerTitleStrip.a -> void
        v1 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        _result = v1.a(); // android.support.v4.view.PagerTitleStrip.a -> float
        v1 = _result;
        v1 = cmp(v1, v0);
        if (v1 < 0) /* goto L_002a */;
        v0 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        _result = v0.a(); // android.support.v4.view.PagerTitleStrip.a -> float
        v0 = _result;
        v1 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        v2 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        v2 = v2.a; // android.support.v4.view.PagerTitleStrip.a:android.support.v4.view.ViewPager
        _result = v2.c(); // android.support.v4.view.ViewPager.c -> int
        v2 = _result;
        v3 = 1;
        _result = v1.a(v2, v0, v3); // android.support.v4.view.PagerTitleStrip.a -> void
        return;
    }

    public void a(int p0, float p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (float), v5 = p2 (int)
        v0 = 0x3f000000;
        v0 = cmp(v4, v0);
        if (v0 <= 0) /* goto L_0008 */;
        v3 = binOpLit8_0xd8(v3, 1);
        v0 = v2.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        v1 = 0;
        _result = v0.a(v3, v4, v1); // android.support.v4.view.PagerTitleStrip.a -> void
        return;
    }

    public void a(android.support.v4.view.ae p0, android.support.v4.view.ae p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.support.v4.view.ae), v3 = p1 (android.support.v4.view.ae)
        v0 = v1.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        _result = v0.a(v2, v3); // android.support.v4.view.PagerTitleStrip.a -> void
        return;
    }

    public void b(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.b = v1; // android.support.v4.view.ai.b:int
        return;
    }

    public void onChanged() {
        // Registers (5 total): v4 = this
        v0 = 0;
        v1 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        v2 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        v2 = v2.a; // android.support.v4.view.PagerTitleStrip.a:android.support.v4.view.ViewPager
        _result = v2.c(); // android.support.v4.view.ViewPager.c -> int
        v2 = _result;
        v3 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        v3 = v3.a; // android.support.v4.view.PagerTitleStrip.a:android.support.v4.view.ViewPager
        _result = v3.b(); // android.support.v4.view.ViewPager.b -> android.support.v4.view.ae
        v3 = _result;
        _result = v1.a(v2, v3); // android.support.v4.view.PagerTitleStrip.a -> void
        v1 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        _result = v1.a(); // android.support.v4.view.PagerTitleStrip.a -> float
        v1 = _result;
        v1 = cmp(v1, v0);
        if (v1 < 0) /* goto L_0026 */;
        v0 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        _result = v0.a(); // android.support.v4.view.PagerTitleStrip.a -> float
        v0 = _result;
        v1 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        v2 = v4.a; // android.support.v4.view.ai.a:android.support.v4.view.PagerTitleStrip
        v2 = v2.a; // android.support.v4.view.PagerTitleStrip.a:android.support.v4.view.ViewPager
        _result = v2.c(); // android.support.v4.view.ViewPager.c -> int
        v2 = _result;
        v3 = 1;
        _result = v1.a(v2, v0, v3); // android.support.v4.view.PagerTitleStrip.a -> void
        return;
    }

}