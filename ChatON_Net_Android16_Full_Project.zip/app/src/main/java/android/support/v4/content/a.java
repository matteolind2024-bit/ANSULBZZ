package android.support.v4.content;

/**
 * Original SourceFile: AsyncTaskLoader.java
 * Descriptor: Landroid/support/v4/content/a;
 */
public abstract class a extends android.support.v4.content.f {
    volatile android.support.v4.content.b a;
    volatile android.support.v4.content.b b;
     long c;
     long d;
     android.os.Handler e;

    public a(android.content.Context p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Context)
        _result = v2.<init>(v3); // android.support.v4.content.f.<init> -> void
        v0 = -10000L;
        v2.d = v0; // android.support.v4.content.a.d:long
        return;
    }

    protected void a() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // android.support.v4.content.f.a -> void
        _result = v1.b(); // android.support.v4.content.a.b -> boolean
        v0 = new android.support.v4.content.b;
        _result = v0.<init>(v1); // android.support.v4.content.b.<init> -> void
        v1.a = v0; // android.support.v4.content.a.a:android.support.v4.content.b
        _result = v1.c(); // android.support.v4.content.a.c -> void
        return;
    }

    void a(android.support.v4.content.b p0, java.lang.Object p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.support.v4.content.b), v4 = p1 (java.lang.Object)
        _result = v2.a(v4); // android.support.v4.content.a.a -> void
        v0 = v2.b; // android.support.v4.content.a.b:android.support.v4.content.b
        if (v0 != v3) /* goto L_0016 */;
        _result = v2.w(); // android.support.v4.content.a.w -> void
        _result = this.uptimeMillis(); // android.os.SystemClock.uptimeMillis -> long
        v0 = _result;
        v2.d = v0; // android.support.v4.content.a.d:long
        v0 = 0;
        v2.b = v0; // android.support.v4.content.a.b:android.support.v4.content.b
        _result = v2.c(); // android.support.v4.content.a.c -> void
        return;
    }

    public void a(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        return;
    }

    public void a(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (9 total): v4 = this, v5 = p0 (java.lang.String), v6 = p1 (java.io.FileDescriptor), v7 = p2 (java.io.PrintWriter), v8 = p3 (java.lang.String[])
        _result = v4.a(v5, v6, v7, v8); // android.support.v4.content.f.a -> void
        v0 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        if (v0 == 0) /* goto L_0022 */;
        _result = v7.print(v5); // java.io.PrintWriter.print -> void
        v0 = "mTask=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = " waiting=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        v0 = v0.b; // android.support.v4.content.b.b:boolean
        _result = v7.println(v0); // java.io.PrintWriter.println -> void
        v0 = v4.b; // android.support.v4.content.a.b:android.support.v4.content.b
        if (v0 == 0) /* goto L_0041 */;
        _result = v7.print(v5); // java.io.PrintWriter.print -> void
        v0 = "mCancellingTask=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.b; // android.support.v4.content.a.b:android.support.v4.content.b
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = " waiting=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.b; // android.support.v4.content.a.b:android.support.v4.content.b
        v0 = v0.b; // android.support.v4.content.b.b:boolean
        _result = v7.println(v0); // java.io.PrintWriter.println -> void
        v0 = v4.c; // android.support.v4.content.a.c:long
        v2 = 0L;
        v0 = cmp(v0, v2);
        if (v0 == 0) /* goto L_0069 */;
        _result = v7.print(v5); // java.io.PrintWriter.print -> void
        v0 = "mUpdateThrottle=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.c; // android.support.v4.content.a.c:long
        _result = v0.a(v1, v7); // android.support.v4.c.o.a -> void
        v0 = " mLastLoadCompleteTime=";
        _result = v7.print(v0); // java.io.PrintWriter.print -> void
        v0 = v4.d; // android.support.v4.content.a.d:long
        _result = this.uptimeMillis(); // android.os.SystemClock.uptimeMillis -> long
        v2 = _result;
        _result = v0.a(v1, v2, v3, v7); // android.support.v4.c.o.a -> void
        _result = v7.println(); // java.io.PrintWriter.println -> void
        return;
    }

    void b(android.support.v4.content.b p0, java.lang.Object p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.support.v4.content.b), v4 = p1 (java.lang.Object)
        v0 = v2.a; // android.support.v4.content.a.a:android.support.v4.content.b
        if (v0 == v3) /* goto L_0008 */;
        _result = v2.a(v3, v4); // android.support.v4.content.a.a -> void
        return;
        _result = v2.m(); // android.support.v4.content.a.m -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0012 */;
        _result = v2.a(v4); // android.support.v4.content.a.a -> void
        // goto L_0007
        _result = v2.v(); // android.support.v4.content.a.v -> void
        _result = this.uptimeMillis(); // android.os.SystemClock.uptimeMillis -> long
        v0 = _result;
        v2.d = v0; // android.support.v4.content.a.d:long
        v0 = 0;
        v2.a = v0; // android.support.v4.content.a.a:android.support.v4.content.b
        _result = v2.b(v4); // android.support.v4.content.a.b -> void
        // goto L_0007
    }

    public boolean b() {
        // Registers (5 total): v4 = this
        v3 = 0;
        v0 = 0;
        v1 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        if (v1 == 0) /* goto L_001d */;
        v1 = v4.b; // android.support.v4.content.a.b:android.support.v4.content.b
        if (v1 == 0) /* goto L_001e */;
        v1 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        v1 = v1.b; // android.support.v4.content.b.b:boolean
        if (v1 == 0) /* goto L_001b */;
        v1 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        v1.b = v0; // android.support.v4.content.b.b:boolean
        v1 = v4.e; // android.support.v4.content.a.e:android.os.Handler
        v2 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        _result = v1.removeCallbacks(v2); // android.os.Handler.removeCallbacks -> void
        v4.a = v3; // android.support.v4.content.a.a:android.support.v4.content.b
        return v0;
        v1 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        v1 = v1.b; // android.support.v4.content.b.b:boolean
        if (v1 == 0) /* goto L_0032 */;
        v1 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        v1.b = v0; // android.support.v4.content.b.b:boolean
        v1 = v4.e; // android.support.v4.content.a.e:android.os.Handler
        v2 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        _result = v1.removeCallbacks(v2); // android.os.Handler.removeCallbacks -> void
        v4.a = v3; // android.support.v4.content.a.a:android.support.v4.content.b
        // goto L_001d
        v1 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        _result = v1.a(v0); // android.support.v4.content.b.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003e */;
        v1 = v4.a; // android.support.v4.content.a.a:android.support.v4.content.b
        v4.b = v1; // android.support.v4.content.a.b:android.support.v4.content.b
        v4.a = v3; // android.support.v4.content.a.a:android.support.v4.content.b
        // goto L_001d
    }

    void c() {
        // Registers (7 total): v6 = this
        v0 = v6.b; // android.support.v4.content.a.b:android.support.v4.content.b
        if (v0 != 0) /* goto L_0040 */;
        v0 = v6.a; // android.support.v4.content.a.a:android.support.v4.content.b
        if (v0 == 0) /* goto L_0040 */;
        v0 = v6.a; // android.support.v4.content.a.a:android.support.v4.content.b
        v0 = v0.b; // android.support.v4.content.b.b:boolean
        if (v0 == 0) /* goto L_001a */;
        v0 = v6.a; // android.support.v4.content.a.a:android.support.v4.content.b
        v1 = 0;
        v0.b = v1; // android.support.v4.content.b.b:boolean
        v0 = v6.e; // android.support.v4.content.a.e:android.os.Handler
        v1 = v6.a; // android.support.v4.content.a.a:android.support.v4.content.b
        _result = v0.removeCallbacks(v1); // android.os.Handler.removeCallbacks -> void
        v0 = v6.c; // android.support.v4.content.a.c:long
        v2 = 0L;
        v0 = cmp(v0, v2);
        if (v0 <= 0) /* goto L_0041 */;
        _result = this.uptimeMillis(); // android.os.SystemClock.uptimeMillis -> long
        v0 = _result;
        v2 = v6.d; // android.support.v4.content.a.d:long
        v4 = v6.c; // android.support.v4.content.a.c:long
        v2 = binOp2addr_0xbb(v2, v4);
        v0 = cmp(v0, v2);
        if (v0 >= 0) /* goto L_0041 */;
        v0 = v6.a; // android.support.v4.content.a.a:android.support.v4.content.b
        v1 = 1;
        v0.b = v1; // android.support.v4.content.b.b:boolean
        v0 = v6.e; // android.support.v4.content.a.e:android.os.Handler
        v1 = v6.a; // android.support.v4.content.a.a:android.support.v4.content.b
        v2 = v6.d; // android.support.v4.content.a.d:long
        v4 = v6.c; // android.support.v4.content.a.c:long
        v2 = binOp2addr_0xbb(v2, v4);
        _result = v0.postAtTime(v1, v2, v3); // android.os.Handler.postAtTime -> boolean
        return;
        v1 = v6.a; // android.support.v4.content.a.a:android.support.v4.content.b
        v2 = android.support.v4.content.m.d; // :java.util.concurrent.Executor
        v0 = 0;
        v0 = (java.lang.Void[]) v0;
        _result = v1.a(v2, v0); // android.support.v4.content.b.a -> android.support.v4.content.m
        // goto L_0040
    }

    public abstract java.lang.Object d();
    protected java.lang.Object e() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // android.support.v4.content.a.d -> java.lang.Object
        v0 = _result;
        return v0;
    }

}