package android.support.v4.c;

/**
 * Original SourceFile: MapCollections.java
 * Descriptor: Landroid/support/v4/c/h;
 */
final class h implements java.util.Iterator {
    final int a;
     int b;
     int c;
     boolean d;
    final android.support.v4.c.g e;

    h(android.support.v4.c.g p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.support.v4.c.g), v3 = p1 (int)
        v1.e = v2; // android.support.v4.c.h.e:android.support.v4.c.g
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v1.d = v0; // android.support.v4.c.h.d:boolean
        v1.a = v3; // android.support.v4.c.h.a:int
        _result = v2.a(); // android.support.v4.c.g.a -> int
        v0 = _result;
        v1.b = v0; // android.support.v4.c.h.b:int
        return;
    }

    public boolean hasNext() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // android.support.v4.c.h.c:int
        v1 = v2.b; // android.support.v4.c.h.b:int
        if (v0 >= v1) /* goto L_0008 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public java.lang.Object next() {
        // Registers (4 total): v3 = this
        v0 = v3.e; // android.support.v4.c.h.e:android.support.v4.c.g
        v1 = v3.c; // android.support.v4.c.h.c:int
        v2 = v3.a; // android.support.v4.c.h.a:int
        _result = v0.a(v1, v2); // android.support.v4.c.g.a -> java.lang.Object
        v0 = _result;
        v1 = v3.c; // android.support.v4.c.h.c:int
        v1 = binOpLit8_0xd8(v1, 1);
        v3.c = v1; // android.support.v4.c.h.c:int
        v1 = 1;
        v3.d = v1; // android.support.v4.c.h.d:boolean
        return v0;
    }

    public void remove() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // android.support.v4.c.h.d:boolean
        if (v0 != 0) /* goto L_000a */;
        v0 = new java.lang.IllegalStateException;
        _result = v0.<init>(); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v2.c; // android.support.v4.c.h.c:int
        v0 = binOpLit8_0xd8(v0, -1);
        v2.c = v0; // android.support.v4.c.h.c:int
        v0 = v2.b; // android.support.v4.c.h.b:int
        v0 = binOpLit8_0xd8(v0, -1);
        v2.b = v0; // android.support.v4.c.h.b:int
        v0 = 0;
        v2.d = v0; // android.support.v4.c.h.d:boolean
        v0 = v2.e; // android.support.v4.c.h.e:android.support.v4.c.g
        v1 = v2.c; // android.support.v4.c.h.c:int
        _result = v0.a(v1); // android.support.v4.c.g.a -> void
        return;
    }

}