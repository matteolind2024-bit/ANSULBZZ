package android.support.v4.app;

/**
 * Original SourceFile: Fragment.java
 * Descriptor: Landroid/support/v4/app/q;
 */
final class q implements android.os.Parcelable$Creator {
    q() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.support.v4.app.Fragment$SavedState a(android.os.Parcel p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Parcel)
        v0 = new android.support.v4.app.Fragment$SavedState;
        v1 = 0;
        _result = v0.<init>(v3, v1); // android.support.v4.app.Fragment$SavedState.<init> -> void
        return v0;
    }

    public android.support.v4.app.Fragment$SavedState[] a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = new android.support.v4.app.Fragment$SavedState[][size=v2];
        return v0;
    }

    public java.lang.Object createFromParcel(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        _result = v1.a(v2); // android.support.v4.app.q.a -> android.support.v4.app.Fragment$SavedState
        v0 = _result;
        return v0;
    }

    public java.lang.Object[] newArray(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.a(v2); // android.support.v4.app.q.a -> android.support.v4.app.Fragment$SavedState[]
        v0 = _result;
        return v0;
    }

}