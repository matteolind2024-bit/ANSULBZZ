package android.support.v4.app;

/**
 * Original SourceFile: ActionBarDrawerToggleHoneycomb.java
 * Descriptor: Landroid/support/v4/app/j;
 */
class j {
    public java.lang.reflect.Method a;
    public java.lang.reflect.Method b;
    public android.widget.ImageView c;

    j(android.app.Activity p0) {
        // Registers (10 total): v8 = this, v9 = p0 (android.app.Activity)
        v7 = 16908332; // 0x0102002c
        v6 = 1;
        v5 = 0;
        _result = v8.<init>(); // java.lang.Object.<init> -> void
        v0 = android.app.ActionBar.class;
        v1 = "setHomeAsUpIndicator";
        v2 = 1;
        v2 = new java.lang.Class[][size=v2];
        v3 = 0;
        v4 = android.graphics.drawable.Drawable.class;
        v2[v3] = v4;
        _result = v0.getDeclaredMethod(v1, v2); // java.lang.Class.getDeclaredMethod -> java.lang.reflect.Method
        v0 = _result;
        v8.a = v0; // android.support.v4.app.j.a:java.lang.reflect.Method
        v0 = android.app.ActionBar.class;
        v1 = "setHomeActionContentDescription";
        v2 = 1;
        v2 = new java.lang.Class[][size=v2];
        v3 = 0;
        v4 = java.lang.Integer.TYPE; // :java.lang.Class
        v2[v3] = v4;
        _result = v0.getDeclaredMethod(v1, v2); // java.lang.Class.getDeclaredMethod -> java.lang.reflect.Method
        v0 = _result;
        v8.b = v0; // android.support.v4.app.j.b:java.lang.reflect.Method
        return;
        v0 = _exception;
        _result = v9.findViewById(v7); // android.app.Activity.findViewById -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_002e */;
        _result = v0.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v0 = _result;
        v0 = (android.view.ViewGroup) v0;
        _result = v0.getChildCount(); // android.view.ViewGroup.getChildCount -> int
        v1 = _result;
        v2 = 2;
        if (v1 != v2) /* goto L_002e */;
        _result = v0.getChildAt(v5); // android.view.ViewGroup.getChildAt -> android.view.View
        v1 = _result;
        _result = v0.getChildAt(v6); // android.view.ViewGroup.getChildAt -> android.view.View
        v0 = _result;
        _result = v1.getId(); // android.view.View.getId -> int
        v2 = _result;
        if (v2 != v7) /* goto L_005a */;
        v1 = (v0 instanceof android.widget.ImageView);
        if (v1 == 0) /* goto L_002e */;
        v0 = (android.widget.ImageView) v0;
        v8.c = v0; // android.support.v4.app.j.c:android.widget.ImageView
        // goto L_002e
        v0 = v1;
        // goto L_0051
    }

}