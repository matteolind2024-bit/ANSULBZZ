package android.support.v4.widget;

/**
 * Original SourceFile: EdgeEffectCompat.java
 * Descriptor: Landroid/support/v4/widget/q;
 */
interface q {
    public abstract java.lang.Object a(android.content.Context p0);
    public abstract void a(java.lang.Object p0, int p1, int p2);
    public abstract boolean a(java.lang.Object p0);
    public abstract boolean a(java.lang.Object p0, float p1);
    public abstract boolean a(java.lang.Object p0, android.graphics.Canvas p1);
    public abstract void b(java.lang.Object p0);
    public abstract boolean c(java.lang.Object p0);
}