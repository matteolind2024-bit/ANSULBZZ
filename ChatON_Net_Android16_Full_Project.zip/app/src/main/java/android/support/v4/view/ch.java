package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ch;
 */
class ch implements java.util.Comparator {
    ch() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int a(android.view.View p0, android.view.View p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.view.View), v6 = p1 (android.view.View)
        _result = v5.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        _result = v6.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v1 = _result;
        v1 = (android.support.v4.view.ViewPager$LayoutParams) v1;
        v2 = v0.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        v3 = v1.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v2 == v3) /* goto L_001a */;
        v0 = v0.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v0 == 0) /* goto L_0018 */;
        v0 = 1;
        return v0;
        v0 = -1;
        // goto L_0017
        v0 = v0.e; // android.support.v4.view.ViewPager$LayoutParams.e:int
        v1 = v1.e; // android.support.v4.view.ViewPager$LayoutParams.e:int
        v0 = binOp2addr_0xb1(v0, v1);
        // goto L_0017
    }

    public int compare(java.lang.Object p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (java.lang.Object)
        v2 = (android.view.View) v2;
        v3 = (android.view.View) v3;
        _result = v1.a(v2, v3); // android.support.v4.view.ch.a -> int
        v0 = _result;
        return v0;
    }

}