package android.support.v4.content;

/**
 * Original SourceFile: CursorLoader.java
 * Descriptor: Landroid/support/v4/content/c;
 */
public class c extends android.support.v4.content.a {
    final android.support.v4.content.g f;
     android.net.Uri g;
     java.lang.String[] h;
     java.lang.String i;
     java.lang.String[] j;
     java.lang.String k;
     android.database.Cursor l;

    public c(android.content.Context p0, android.net.Uri p1, java.lang.String[] p2, java.lang.String p3, java.lang.String[] p4, java.lang.String p5) {
        // Registers (8 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.net.Uri), v4 = p2 (java.lang.String[]), v5 = p3 (java.lang.String), v6 = p4 (java.lang.String[]), v7 = p5 (java.lang.String)
        _result = v1.<init>(v2); // android.support.v4.content.a.<init> -> void
        v0 = new android.support.v4.content.g;
        _result = v0.<init>(v1); // android.support.v4.content.g.<init> -> void
        v1.f = v0; // android.support.v4.content.c.f:android.support.v4.content.g
        v1.g = v3; // android.support.v4.content.c.g:android.net.Uri
        v1.h = v4; // android.support.v4.content.c.h:java.lang.String[]
        v1.i = v5; // android.support.v4.content.c.i:java.lang.String
        v1.j = v6; // android.support.v4.content.c.j:java.lang.String[]
        v1.k = v7; // android.support.v4.content.c.k:java.lang.String
        return;
    }

    public void a(android.database.Cursor p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.database.Cursor)
        _result = v2.n(); // android.support.v4.content.c.n -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000c */;
        if (v3 == 0) /* goto L_000b */;
        _result = android.database.Cursor.close(v3); // -> void
        return;
        v0 = v2.l; // android.support.v4.content.c.l:android.database.Cursor
        v2.l = v3; // android.support.v4.content.c.l:android.database.Cursor
        _result = v2.l(); // android.support.v4.content.c.l -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0019 */;
        _result = v2.b(v3); // android.support.v4.content.a.b -> void
        if (v0 == 0) /* goto L_000b */;
        if (v0 == v3) /* goto L_000b */;
        _result = android.database.Cursor.isClosed(v0); // -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000b */;
        _result = android.database.Cursor.close(v0); // -> void
        // goto L_000b
    }

    public void a(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        v1 = (android.database.Cursor) v1;
        _result = v0.b(v1); // android.support.v4.content.c.b -> void
        return;
    }

    public void a(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.io.FileDescriptor), v4 = p2 (java.io.PrintWriter), v5 = p3 (java.lang.String[])
        _result = v1.a(v2, v3, v4, v5); // android.support.v4.content.a.a -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mUri=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.g; // android.support.v4.content.c.g:android.net.Uri
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mProjection=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.h; // android.support.v4.content.c.h:java.lang.String[]
        _result = v0.toString(); // java.util.Arrays.toString -> java.lang.String
        v0 = _result;
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mSelection=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.i; // android.support.v4.content.c.i:java.lang.String
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mSelectionArgs=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.j; // android.support.v4.content.c.j:java.lang.String[]
        _result = v0.toString(); // java.util.Arrays.toString -> java.lang.String
        v0 = _result;
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mSortOrder=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.k; // android.support.v4.content.c.k:java.lang.String
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mCursor=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.l; // android.support.v4.content.c.l:android.database.Cursor
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mContentChanged=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.s; // android.support.v4.content.c.s:boolean
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        return;
    }

    public void b(android.database.Cursor p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.database.Cursor)
        if (v2 == 0) /* goto L_000b */;
        _result = android.database.Cursor.isClosed(v2); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000b */;
        _result = android.database.Cursor.close(v2); // -> void
        return;
    }

    public void b(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        v1 = (android.database.Cursor) v1;
        _result = v0.a(v1); // android.support.v4.content.c.a -> void
        return;
    }

    public java.lang.Object d() {
        // Registers (2 total): v1 = this
        _result = v1.f(); // android.support.v4.content.c.f -> android.database.Cursor
        v0 = _result;
        return v0;
    }

    public android.database.Cursor f() {
        // Registers (7 total): v6 = this
        _result = v6.j(); // android.support.v4.content.c.j -> android.content.Context
        v0 = _result;
        _result = v0.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        v1 = v6.g; // android.support.v4.content.c.g:android.net.Uri
        v2 = v6.h; // android.support.v4.content.c.h:java.lang.String[]
        v3 = v6.i; // android.support.v4.content.c.i:java.lang.String
        v4 = v6.j; // android.support.v4.content.c.j:java.lang.String[]
        v5 = v6.k; // android.support.v4.content.c.k:java.lang.String
        _result = v0.query(v0..v5); // android.content.ContentResolver.query -> android.database.Cursor
        v0 = _result;
        if (v0 == 0) /* goto L_0020 */;
        _result = android.database.Cursor.getCount(v0); // -> int
        v1 = v6.f; // android.support.v4.content.c.f:android.support.v4.content.g
        _result = android.database.Cursor.registerContentObserver(v0, v1); // -> void
        return v0;
    }

    protected void g() {
        // Registers (2 total): v1 = this
        v0 = v1.l; // android.support.v4.content.c.l:android.database.Cursor
        if (v0 == 0) /* goto L_0009 */;
        v0 = v1.l; // android.support.v4.content.c.l:android.database.Cursor
        _result = v1.a(v0); // android.support.v4.content.c.a -> void
        _result = v1.u(); // android.support.v4.content.c.u -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0013 */;
        v0 = v1.l; // android.support.v4.content.c.l:android.database.Cursor
        if (v0 != 0) /* goto L_0016 */;
        _result = v1.p(); // android.support.v4.content.c.p -> void
        return;
    }

    protected void h() {
        // Registers (1 total): v0 = this
        _result = v0.b(); // android.support.v4.content.c.b -> boolean
        return;
    }

    protected void i() {
        // Registers (2 total): v1 = this
        _result = v1.i(); // android.support.v4.content.a.i -> void
        _result = v1.h(); // android.support.v4.content.c.h -> void
        v0 = v1.l; // android.support.v4.content.c.l:android.database.Cursor
        if (v0 == 0) /* goto L_0017 */;
        v0 = v1.l; // android.support.v4.content.c.l:android.database.Cursor
        _result = android.database.Cursor.isClosed(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        v0 = v1.l; // android.support.v4.content.c.l:android.database.Cursor
        _result = android.database.Cursor.close(v0); // -> void
        v0 = 0;
        v1.l = v0; // android.support.v4.content.c.l:android.database.Cursor
        return;
    }

}