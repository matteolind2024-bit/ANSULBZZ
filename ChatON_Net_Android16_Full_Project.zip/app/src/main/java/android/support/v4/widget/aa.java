package android.support.v4.widget;

/**
 * Original SourceFile: SimpleCursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/aa;
 */
public interface aa {
    public abstract java.lang.CharSequence a(android.database.Cursor p0);
}