package android.support.v4.app;

/**
 * Original SourceFile: FragmentActivity.java
 * Descriptor: Landroid/support/v4/app/FragmentActivity;
 */
public class FragmentActivity extends android.app.Activity {
    final android.os.Handler a;
    final android.support.v4.app.y b;
    final android.support.v4.app.v c;
     boolean d;
     boolean e;
     boolean f;
     boolean g;
     boolean h;
     boolean i;
     boolean j;
     boolean k;
     android.support.v4.c.m l;
     android.support.v4.app.ao m;

    public FragmentActivity() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // android.app.Activity.<init> -> void
        v0 = new android.support.v4.app.r;
        _result = v0.<init>(v1); // android.support.v4.app.r.<init> -> void
        v1.a = v0; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        v0 = new android.support.v4.app.y;
        _result = v0.<init>(); // android.support.v4.app.y.<init> -> void
        v1.b = v0; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v0 = new android.support.v4.app.s;
        _result = v0.<init>(v1); // android.support.v4.app.s.<init> -> void
        v1.c = v0; // android.support.v4.app.FragmentActivity.c:android.support.v4.app.v
        return;
    }

    private static java.lang.String a(android.view.View p0) {
        // Registers (8 total): v7 = p0 (android.view.View)
        v3 = 86;
        v1 = 70;
        v6 = 44;
        v5 = 32;
        v2 = 46;
        v4 = new java.lang.StringBuilder;
        v0 = 128;
        _result = v4.<init>(v0); // java.lang.StringBuilder.<init> -> void
        _result = v7.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getName(); // java.lang.Class.getName -> java.lang.String
        v0 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = 123;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.identityHashCode(); // java.lang.System.identityHashCode -> int
        v0 = _result;
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.getVisibility(); // android.view.View.getVisibility -> int
        v0 = _result;
        // switch(v0)
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.isFocusable(); // android.view.View.isFocusable -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0136 */;
        v0 = v1;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.isEnabled(); // android.view.View.isEnabled -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0139 */;
        v0 = 69;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.willNotDraw(); // android.view.View.willNotDraw -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_013c */;
        v0 = v2;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.isHorizontalScrollBarEnabled(); // android.view.View.isHorizontalScrollBarEnabled -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0140 */;
        v0 = 72;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.isVerticalScrollBarEnabled(); // android.view.View.isVerticalScrollBarEnabled -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0143 */;
        v0 = v3;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.isClickable(); // android.view.View.isClickable -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0146 */;
        v0 = 67;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.isLongClickable(); // android.view.View.isLongClickable -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0149 */;
        v0 = 76;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.isFocused(); // android.view.View.isFocused -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_014c */;
        _result = v4.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.isSelected(); // android.view.View.isSelected -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_014f */;
        v0 = 83;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.isPressed(); // android.view.View.isPressed -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00a2 */;
        v2 = 80;
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.getLeft(); // android.view.View.getLeft -> int
        v0 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.getTop(); // android.view.View.getTop -> int
        v0 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = 45;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.getRight(); // android.view.View.getRight -> int
        v0 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.getBottom(); // android.view.View.getBottom -> int
        v0 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.getId(); // android.view.View.getId -> int
        v1 = _result;
        v0 = -1;
        if (v1 == v0) /* goto L_0118 */;
        v0 = " #";
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v7.getResources(); // android.view.View.getResources -> android.content.res.Resources
        v2 = _result;
        if (v1 == 0) /* goto L_0118 */;
        if (v2 == 0) /* goto L_0118 */;
        v0 = 0xff000000;
        v0 = binOp2addr_0xb5(v0, v1);
        // switch(v0)
        _result = v2.getResourcePackageName(v1); // android.content.res.Resources.getResourcePackageName -> java.lang.String
        v0 = _result;
        _result = v2.getResourceTypeName(v1); // android.content.res.Resources.getResourceTypeName -> java.lang.String
        v3 = _result;
        _result = v2.getResourceEntryName(v1); // android.content.res.Resources.getResourceEntryName -> java.lang.String
        v1 = _result;
        v2 = " ";
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = ":";
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "/";
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "}";
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        _result = v4.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0039
        v0 = 73;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0039
        v0 = 71;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0039
        v0 = v2;
        // goto L_0040
        v0 = v2;
        // goto L_004b
        v0 = 68;
        // goto L_0055
        v0 = v2;
        // goto L_0060
        v0 = v2;
        // goto L_006a
        v0 = v2;
        // goto L_0075
        v0 = v2;
        // goto L_0080
        v1 = v2;
        // goto L_008c
        v0 = v2;
        // goto L_0097
        v0 = "app";
        // goto L_00f5
        v0 = "android";
        // goto L_00f5
        v0 = _exception;
        // goto L_0118
    }

    private void a(java.lang.String p0, java.io.PrintWriter p1, android.view.View p2) {
        // Registers (8 total): v4 = this, v5 = p0 (java.lang.String), v6 = p1 (java.io.PrintWriter), v7 = p2 (android.view.View)
        _result = v6.print(v5); // java.io.PrintWriter.print -> void
        if (v7 != 0) /* goto L_000c */;
        v0 = "null";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        return;
        _result = v7.a(); // android.support.v4.app.FragmentActivity.a -> java.lang.String
        v0 = _result;
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = (v7 instanceof android.view.ViewGroup);
        if (v0 == 0) /* goto L_000b */;
        v7 = (android.view.ViewGroup) v7;
        _result = v7.getChildCount(); // android.view.ViewGroup.getChildCount -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_000b */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = "  ";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        v0 = 0;
        if (v0 >= v1) /* goto L_000b */;
        _result = v7.getChildAt(v0); // android.view.ViewGroup.getChildAt -> android.view.View
        v3 = _result;
        _result = v4.a(v2, v6, v3); // android.support.v4.app.FragmentActivity.a -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0034
    }

    android.support.v4.app.ao a(java.lang.String p0, boolean p1, boolean p2) {
        // Registers (6 total): v2 = this, v3 = p0 (java.lang.String), v4 = p1 (boolean), v5 = p2 (boolean)
        v0 = v2.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        if (v0 != 0) /* goto L_000b */;
        v0 = new android.support.v4.c.m;
        _result = v0.<init>(); // android.support.v4.c.m.<init> -> void
        v2.l = v0; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        v0 = v2.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        _result = v0.get(v3); // android.support.v4.c.m.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ao) v0;
        if (v0 != 0) /* goto L_0022 */;
        if (v5 == 0) /* goto L_0021 */;
        v0 = new android.support.v4.app.ao;
        _result = v0.<init>(v3, v2, v4); // android.support.v4.app.ao.<init> -> void
        v1 = v2.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        _result = v1.put(v3, v0); // android.support.v4.c.m.put -> java.lang.Object
        return v0;
        _result = v0.a(v2); // android.support.v4.app.ao.a -> void
        // goto L_0021
    }

    public void a(android.support.v4.app.Fragment p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.Fragment)
        return;
    }

    public void a(android.support.v4.app.Fragment p0, android.content.Intent p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment), v4 = p1 (android.content.Intent), v5 = p2 (int)
        v0 = -1;
        if (v5 != v0) /* goto L_0007 */;
        _result = v2.startActivityForResult(v4, v0); // android.app.Activity.startActivityForResult -> void
        return;
        v0 = 0xffff0000;
        v0 = binOp2addr_0xb5(v0, v5);
        if (v0 == 0) /* goto L_0015 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Can only use lower 16 bits for requestCode";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v3.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v0 = binOpLit8_0xd8(v0, 1);
        v0 = binOpLit8_0xe0(v0, 16);
        v1 = 65535; // 0x0000ffff
        v1 = binOp2addr_0xb5(v1, v5);
        v0 = binOp2addr_0xb0(v0, v1);
        _result = v2.startActivityForResult(v4, v0); // android.app.Activity.startActivityForResult -> void
        // goto L_0006
    }

    void a(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = v2.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        if (v0 == 0) /* goto L_001a */;
        v0 = v2.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        _result = v0.get(v3); // android.support.v4.c.m.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ao) v0;
        if (v0 == 0) /* goto L_001a */;
        v1 = v0.g; // android.support.v4.app.ao.g:boolean
        if (v1 != 0) /* goto L_001a */;
        _result = v0.h(); // android.support.v4.app.ao.h -> void
        v0 = v2.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        _result = v0.remove(v3); // android.support.v4.c.m.remove -> java.lang.Object
        return;
    }

    void a(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v1 = 1;
        v0 = v2.g; // android.support.v4.app.FragmentActivity.g:boolean
        if (v0 != 0) /* goto L_0011 */;
        v2.g = v1; // android.support.v4.app.FragmentActivity.g:boolean
        v2.h = v3; // android.support.v4.app.FragmentActivity.h:boolean
        v0 = v2.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        _result = v0.removeMessages(v1); // android.os.Handler.removeMessages -> void
        _result = v2.d(); // android.support.v4.app.FragmentActivity.d -> void
        return;
    }

    protected boolean a(android.view.View p0, android.view.Menu p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.Menu)
        v0 = 0;
        _result = v1.onPreparePanel(v0, v2, v3); // android.app.Activity.onPreparePanel -> boolean
        v0 = _result;
        return v0;
    }

    protected void a_() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.n(); // android.support.v4.app.y.n -> void
        return;
    }

    void d() {
        // Registers (2 total): v1 = this
        v0 = v1.k; // android.support.v4.app.FragmentActivity.k:boolean
        if (v0 == 0) /* goto L_0014 */;
        v0 = 0;
        v1.k = v0; // android.support.v4.app.FragmentActivity.k:boolean
        v0 = v1.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        if (v0 == 0) /* goto L_0014 */;
        v0 = v1.h; // android.support.v4.app.FragmentActivity.h:boolean
        if (v0 != 0) /* goto L_001a */;
        v0 = v1.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        _result = v0.c(); // android.support.v4.app.ao.c -> void
        v0 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.q(); // android.support.v4.app.y.q -> void
        return;
        v0 = v1.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        _result = v0.d(); // android.support.v4.app.ao.d -> void
        // goto L_0014
    }

    public void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (8 total): v3 = this, v4 = p0 (java.lang.String), v5 = p1 (java.io.FileDescriptor), v6 = p2 (java.io.PrintWriter), v7 = p3 (java.lang.String[])
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_0006 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "Local FragmentActivity ";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        _result = v3.identityHashCode(); // java.lang.System.identityHashCode -> int
        v0 = _result;
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " State:";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "  ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v1 = "mCreated=";
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = v3.d; // android.support.v4.app.FragmentActivity.d:boolean
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = "mResumed=";
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = v3.e; // android.support.v4.app.FragmentActivity.e:boolean
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = " mStopped=";
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = v3.f; // android.support.v4.app.FragmentActivity.f:boolean
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = " mReallyStopped=";
        _result = v6.print(v1); // java.io.PrintWriter.print -> void
        v1 = v3.g; // android.support.v4.app.FragmentActivity.g:boolean
        _result = v6.println(v1); // java.io.PrintWriter.println -> void
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = "mLoadersStarted=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.k; // android.support.v4.app.FragmentActivity.k:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        if (v0 == 0) /* goto L_00aa */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "Loader Manager ";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        _result = v0.identityHashCode(); // java.lang.System.identityHashCode -> int
        v0 = _result;
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = ":";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "  ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.a(v1, v5, v6, v7); // android.support.v4.app.ao.a -> void
        v0 = v3.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.a(v4, v5, v6, v7); // android.support.v4.app.y.a -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "View Hierarchy:";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "  ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v3.getWindow(); // android.support.v4.app.FragmentActivity.getWindow -> android.view.Window
        v1 = _result;
        _result = v1.getDecorView(); // android.view.Window.getDecorView -> android.view.View
        v1 = _result;
        _result = v3.a(v0, v6, v1); // android.support.v4.app.FragmentActivity.a -> void
        return;
    }

    public android.support.v4.app.w e() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        return v0;
    }

    protected void onActivityResult(int p0, int p1, android.content.Intent p2) {
        // Registers (7 total): v3 = this, v4 = p0 (int), v5 = p1 (int), v6 = p2 (android.content.Intent)
        v0 = v3.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.j(); // android.support.v4.app.y.j -> void
        v0 = binOpLit8_0xe1(v4, 16);
        if (v0 == 0) /* goto L_006f */;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v3.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v1 = v1.f; // android.support.v4.app.y.f:java.util.ArrayList
        if (v1 == 0) /* goto L_001d */;
        if (v0 < 0) /* goto L_001d */;
        v1 = v3.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v1 = v1.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v0 < v1) /* goto L_003c */;
        v0 = "FragmentActivity";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Activity result fragment index out of range: 0x";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v4.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.w(v1); // android.util.Log.w -> int
        return;
        v1 = v3.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v1 = v1.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v1.get(v0); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 != 0) /* goto L_0067 */;
        v0 = "FragmentActivity";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Activity result no fragment exists for index: 0x";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v4.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.w(v1); // android.util.Log.w -> int
        // goto L_003b
        v1 = 65535; // 0x0000ffff
        v1 = binOp2addr_0xb5(v1, v4);
        _result = v0.onActivityResult(v1, v5, v6); // android.support.v4.app.Fragment.onActivityResult -> void
        // goto L_003b
        _result = v3.onActivityResult(v4, v5, v6); // android.app.Activity.onActivityResult -> void
        // goto L_003b
    }

    public void onBackPressed() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.d(); // android.support.v4.app.y.d -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000b */;
        _result = v1.finish(); // android.support.v4.app.FragmentActivity.finish -> void
        return;
    }

    public void onConfigurationChanged(android.content.res.Configuration p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.res.Configuration)
        _result = v1.onConfigurationChanged(v2); // android.app.Activity.onConfigurationChanged -> void
        v0 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.a(v2); // android.support.v4.app.y.a -> void
        return;
    }

    protected void onCreate(android.os.Bundle p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.os.Bundle)
        v1 = 0;
        v0 = v4.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v2 = v4.c; // android.support.v4.app.FragmentActivity.c:android.support.v4.app.v
        _result = v0.a(v4, v2, v1); // android.support.v4.app.y.a -> void
        _result = v4.getLayoutInflater(); // android.support.v4.app.FragmentActivity.getLayoutInflater -> android.view.LayoutInflater
        v0 = _result;
        _result = v0.getFactory(); // android.view.LayoutInflater.getFactory -> android.view.LayoutInflater$Factory
        v0 = _result;
        if (v0 != 0) /* goto L_0019 */;
        _result = v4.getLayoutInflater(); // android.support.v4.app.FragmentActivity.getLayoutInflater -> android.view.LayoutInflater
        v0 = _result;
        _result = v0.setFactory(v4); // android.view.LayoutInflater.setFactory -> void
        _result = v4.onCreate(v5); // android.app.Activity.onCreate -> void
        _result = v4.getLastNonConfigurationInstance(); // android.support.v4.app.FragmentActivity.getLastNonConfigurationInstance -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.u) v0;
        if (v0 == 0) /* goto L_0028 */;
        v2 = v0.e; // android.support.v4.app.u.e:android.support.v4.c.m
        v4.l = v2; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        if (v5 == 0) /* goto L_003a */;
        v2 = "android:support:fragments";
        _result = v5.getParcelable(v2); // android.os.Bundle.getParcelable -> android.os.Parcelable
        v2 = _result;
        v3 = v4.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        if (v0 == 0) /* goto L_0040 */;
        v0 = v0.d; // android.support.v4.app.u.d:java.util.ArrayList
        _result = v3.a(v2, v0); // android.support.v4.app.y.a -> void
        v0 = v4.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.k(); // android.support.v4.app.y.k -> void
        return;
        v0 = v1;
        // goto L_0037
    }

    public boolean onCreatePanelMenu(int p0, android.view.Menu p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (android.view.Menu)
        if (v4 != 0) /* goto L_001a */;
        _result = v3.onCreatePanelMenu(v4, v5); // android.app.Activity.onCreatePanelMenu -> boolean
        v0 = _result;
        v1 = v3.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v3.getMenuInflater(); // android.support.v4.app.FragmentActivity.getMenuInflater -> android.view.MenuInflater
        v2 = _result;
        _result = v1.a(v5, v2); // android.support.v4.app.y.a -> boolean
        v1 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        v1 = android.os.Build$VERSION.SDK_INT; // :int
        v2 = 11;
        if (v1 < v2) /* goto L_0018 */;
        return v0;
        v0 = 1;
        // goto L_0017
        _result = v3.onCreatePanelMenu(v4, v5); // android.app.Activity.onCreatePanelMenu -> boolean
        v0 = _result;
        // goto L_0017
    }

    public android.view.View onCreateView(java.lang.String p0, android.content.Context p1, android.util.AttributeSet p2) {
        // Registers (13 total): v9 = this, v10 = p0 (java.lang.String), v11 = p1 (android.content.Context), v12 = p2 (android.util.AttributeSet)
        v3 = 0;
        v1 = 0;
        v8 = 1;
        v6 = -1;
        v0 = "fragment";
        _result = v0.equals(v10); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0012 */;
        _result = v9.onCreateView(v10, v11, v12); // android.app.Activity.onCreateView -> android.view.View
        v0 = _result;
        return v0;
        v0 = "class";
        _result = android.util.AttributeSet.getAttributeValue(v12, v1, v0); // -> java.lang.String
        v0 = _result;
        v2 = android.support.v4.app.t.a; // :int[]
        _result = v11.obtainStyledAttributes(v12, v2); // android.content.Context.obtainStyledAttributes -> android.content.res.TypedArray
        v4 = _result;
        if (v0 != 0) /* goto L_0025 */;
        _result = v4.getString(v3); // android.content.res.TypedArray.getString -> java.lang.String
        v0 = _result;
        _result = v4.getResourceId(v8, v6); // android.content.res.TypedArray.getResourceId -> int
        v2 = _result;
        v5 = 2;
        _result = v4.getString(v5); // android.content.res.TypedArray.getString -> java.lang.String
        v5 = _result;
        _result = v4.recycle(); // android.content.res.TypedArray.recycle -> void
        _result = v9.isSupportFragmentClass(v0); // android.support.v4.app.Fragment.isSupportFragmentClass -> boolean
        v4 = _result;
        if (v4 != 0) /* goto L_003c */;
        _result = v9.onCreateView(v10, v11, v12); // android.app.Activity.onCreateView -> android.view.View
        v0 = _result;
        // goto L_0011
        if (v1 == 0) /* goto L_0042 */;
        _result = v1.getId(); // android.view.View.getId -> int
        v3 = _result;
        if (v3 != v6) /* goto L_006a */;
        if (v2 != v6) /* goto L_006a */;
        if (v5 != 0) /* goto L_006a */;
        v1 = new java.lang.IllegalArgumentException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = android.util.AttributeSet.getPositionDescription(v12); // -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": Must specify unique android:id, android:tag, or have a parent with an id for ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v1;
        if (v2 == v6) /* goto L_0072 */;
        v1 = v9.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v1.a(v2); // android.support.v4.app.y.a -> android.support.v4.app.Fragment
        v1 = _result;
        if (v1 != 0) /* goto L_007c */;
        if (v5 == 0) /* goto L_007c */;
        v1 = v9.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v1.a(v5); // android.support.v4.app.y.a -> android.support.v4.app.Fragment
        v1 = _result;
        if (v1 != 0) /* goto L_0086 */;
        if (v3 == v6) /* goto L_0086 */;
        v1 = v9.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v1.a(v3); // android.support.v4.app.y.a -> android.support.v4.app.Fragment
        v1 = _result;
        v4 = android.support.v4.app.y.a; // :boolean
        if (v4 == 0) /* goto L_00be */;
        v4 = "FragmentActivity";
        v6 = new java.lang.StringBuilder;
        _result = v6.<init>(); // java.lang.StringBuilder.<init> -> void
        v7 = "onCreateView: id=0x";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v2.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v7 = _result;
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v7 = " fname=";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v7 = " existing=";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v6 = _result;
        _result = v4.v(v6); // android.util.Log.v -> int
        if (v1 != 0) /* goto L_0107 */;
        _result = v9.instantiate(v0); // android.support.v4.app.Fragment.instantiate -> android.support.v4.app.Fragment
        v4 = _result;
        v4.mFromLayout = v8; // android.support.v4.app.Fragment.mFromLayout:boolean
        if (v2 == 0) /* goto L_0105 */;
        v1 = v2;
        v4.mFragmentId = v1; // android.support.v4.app.Fragment.mFragmentId:int
        v4.mContainerId = v3; // android.support.v4.app.Fragment.mContainerId:int
        v4.mTag = v5; // android.support.v4.app.Fragment.mTag:java.lang.String
        v4.mInLayout = v8; // android.support.v4.app.Fragment.mInLayout:boolean
        v1 = v9.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v4.mFragmentManager = v1; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.y
        v1 = v4.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v4.onInflate(v9, v12, v1); // android.support.v4.app.Fragment.onInflate -> void
        v1 = v9.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v1.a(v4, v8); // android.support.v4.app.y.a -> void
        v1 = v4;
        v3 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v3 != 0) /* goto L_0168 */;
        v1 = new java.lang.IllegalStateException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Fragment ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = " did not create a view.";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.IllegalStateException.<init> -> void
        throw v1;
        v1 = v3;
        // goto L_00c9
        v4 = v1.mInLayout; // android.support.v4.app.Fragment.mInLayout:boolean
        if (v4 == 0) /* goto L_0156 */;
        v1 = new java.lang.IllegalArgumentException;
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = android.util.AttributeSet.getPositionDescription(v12); // -> java.lang.String
        v6 = _result;
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v6 = ": Duplicate id 0x";
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v2.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v2 = _result;
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v4 = ", tag ";
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v4 = ", or parent id 0x";
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v3.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " with another fragment for ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v1;
        v1.mInLayout = v8; // android.support.v4.app.Fragment.mInLayout:boolean
        v3 = v1.mRetaining; // android.support.v4.app.Fragment.mRetaining:boolean
        if (v3 != 0) /* goto L_0161 */;
        v3 = v1.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v1.onInflate(v9, v12, v3); // android.support.v4.app.Fragment.onInflate -> void
        v3 = v9.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v3.c(v1); // android.support.v4.app.y.c -> void
        // goto L_00e0
        if (v2 == 0) /* goto L_016f */;
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.setId(v2); // android.view.View.setId -> void
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.getTag(); // android.view.View.getTag -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_017c */;
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.setTag(v5); // android.view.View.setTag -> void
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        // goto L_0011
    }

    protected void onDestroy() {
        // Registers (2 total): v1 = this
        _result = v1.onDestroy(); // android.app.Activity.onDestroy -> void
        v0 = 0;
        _result = v1.a(v0); // android.support.v4.app.FragmentActivity.a -> void
        v0 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.s(); // android.support.v4.app.y.s -> void
        v0 = v1.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        if (v0 == 0) /* goto L_0015 */;
        v0 = v1.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        _result = v0.h(); // android.support.v4.app.ao.h -> void
        return;
    }

    public boolean onKeyDown(int p0, android.view.KeyEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (android.view.KeyEvent)
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 5;
        if (v0 >= v1) /* goto L_0013 */;
        v0 = 4;
        if (v3 != v0) /* goto L_0013 */;
        _result = v4.getRepeatCount(); // android.view.KeyEvent.getRepeatCount -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0013 */;
        _result = v2.onBackPressed(); // android.support.v4.app.FragmentActivity.onBackPressed -> void
        v0 = 1;
        return v0;
        _result = v2.onKeyDown(v3, v4); // android.app.Activity.onKeyDown -> boolean
        v0 = _result;
        // goto L_0012
    }

    public void onLowMemory() {
        // Registers (2 total): v1 = this
        _result = v1.onLowMemory(); // android.app.Activity.onLowMemory -> void
        v0 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.t(); // android.support.v4.app.y.t -> void
        return;
    }

    public boolean onMenuItemSelected(int p0, android.view.MenuItem p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (android.view.MenuItem)
        _result = v1.onMenuItemSelected(v2, v3); // android.app.Activity.onMenuItemSelected -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0008 */;
        v0 = 1;
        return v0;
        // switch(v2)
        v0 = 0;
        // goto L_0007
        v0 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.a(v3); // android.support.v4.app.y.a -> boolean
        v0 = _result;
        // goto L_0007
        v0 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.b(v3); // android.support.v4.app.y.b -> boolean
        v0 = _result;
        // goto L_0007
    }

    protected void onNewIntent(android.content.Intent p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Intent)
        _result = v1.onNewIntent(v2); // android.app.Activity.onNewIntent -> void
        v0 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.j(); // android.support.v4.app.y.j -> void
        return;
    }

    public void onPanelClosed(int p0, android.view.Menu p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (android.view.Menu)
        // switch(v2)
        _result = v1.onPanelClosed(v2, v3); // android.app.Activity.onPanelClosed -> void
        return;
        v0 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.b(v3); // android.support.v4.app.y.b -> void
        // goto L_0003
    }

    protected void onPause() {
        // Registers (3 total): v2 = this
        v1 = 2;
        _result = v2.onPause(); // android.app.Activity.onPause -> void
        v0 = 0;
        v2.e = v0; // android.support.v4.app.FragmentActivity.e:boolean
        v0 = v2.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        _result = v0.hasMessages(v1); // android.os.Handler.hasMessages -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v0 = v2.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        _result = v0.removeMessages(v1); // android.os.Handler.removeMessages -> void
        _result = v2.a_(); // android.support.v4.app.FragmentActivity.a_ -> void
        v0 = v2.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.o(); // android.support.v4.app.y.o -> void
        return;
    }

    protected void onPostResume() {
        // Registers (3 total): v2 = this
        _result = v2.onPostResume(); // android.app.Activity.onPostResume -> void
        v0 = v2.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        v1 = 2;
        _result = v0.removeMessages(v1); // android.os.Handler.removeMessages -> void
        _result = v2.a_(); // android.support.v4.app.FragmentActivity.a_ -> void
        v0 = v2.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.f(); // android.support.v4.app.y.f -> boolean
        return;
    }

    public boolean onPreparePanel(int p0, android.view.View p1, android.view.Menu p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (android.view.View), v5 = p2 (android.view.Menu)
        if (v3 != 0) /* goto L_001d */;
        if (v5 == 0) /* goto L_001d */;
        v0 = v2.i; // android.support.v4.app.FragmentActivity.i:boolean
        if (v0 == 0) /* goto L_0011 */;
        v0 = 0;
        v2.i = v0; // android.support.v4.app.FragmentActivity.i:boolean
        _result = android.view.Menu.clear(v5); // -> void
        _result = v2.onCreatePanelMenu(v3, v5); // android.support.v4.app.FragmentActivity.onCreatePanelMenu -> boolean
        _result = v2.a(v4, v5); // android.support.v4.app.FragmentActivity.a -> boolean
        v0 = _result;
        v1 = v2.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v1.a(v5); // android.support.v4.app.y.a -> boolean
        v1 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        return v0;
        _result = v2.onPreparePanel(v3, v4, v5); // android.app.Activity.onPreparePanel -> boolean
        v0 = _result;
        // goto L_001c
    }

    protected void onResume() {
        // Registers (3 total): v2 = this
        _result = v2.onResume(); // android.app.Activity.onResume -> void
        v0 = v2.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        v1 = 2;
        _result = v0.sendEmptyMessage(v1); // android.os.Handler.sendEmptyMessage -> boolean
        v0 = 1;
        v2.e = v0; // android.support.v4.app.FragmentActivity.e:boolean
        v0 = v2.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.f(); // android.support.v4.app.y.f -> boolean
        return;
    }

    public final java.lang.Object onRetainNonConfigurationInstance() {
        // Registers (11 total): v10 = this
        v1 = 1;
        v3 = 0;
        v2 = 0;
        v0 = v10.f; // android.support.v4.app.FragmentActivity.f:boolean
        if (v0 == 0) /* goto L_000a */;
        _result = v10.a(v1); // android.support.v4.app.FragmentActivity.a -> void
        _result = v10.v_(); // android.support.v4.app.FragmentActivity.v_ -> java.lang.Object
        v5 = _result;
        v0 = v10.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.h(); // android.support.v4.app.y.h -> java.util.ArrayList
        v6 = _result;
        v0 = v10.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        if (v0 == 0) /* goto L_004b */;
        v0 = v10.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        _result = v0.size(); // android.support.v4.c.m.size -> int
        v7 = _result;
        v8 = new android.support.v4.app.ao[][size=v7];
        v0 = binOpLit8_0xd8(v7, -1);
        v4 = v0;
        if (v4 < 0) /* goto L_0033 */;
        v0 = v10.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        _result = v0.c(v4); // android.support.v4.c.m.c -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ao) v0;
        v8[v4] = v0;
        v0 = binOpLit8_0xd8(v4, -1);
        v4 = v0;
        // goto L_0023
        v0 = v3;
        if (v3 >= v7) /* goto L_004c */;
        v4 = v8[v3];
        v9 = v4.g; // android.support.v4.app.ao.g:boolean
        if (v9 == 0) /* goto L_0040 */;
        v0 = v1;
        v3 = binOpLit8_0xd8(v3, 1);
        // goto L_0034
        _result = v4.h(); // android.support.v4.app.ao.h -> void
        v9 = v10.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        v4 = v4.d; // android.support.v4.app.ao.d:java.lang.String
        _result = v9.remove(v4); // android.support.v4.c.m.remove -> java.lang.Object
        // goto L_003d
        v0 = v3;
        if (v6 != 0) /* goto L_0054 */;
        if (v0 != 0) /* goto L_0054 */;
        if (v5 != 0) /* goto L_0054 */;
        v0 = v2;
        return v0;
        v0 = new android.support.v4.app.u;
        _result = v0.<init>(); // android.support.v4.app.u.<init> -> void
        v0.a = v2; // android.support.v4.app.u.a:java.lang.Object
        v0.b = v5; // android.support.v4.app.u.b:java.lang.Object
        v0.c = v2; // android.support.v4.app.u.c:android.support.v4.c.m
        v0.d = v6; // android.support.v4.app.u.d:java.util.ArrayList
        v1 = v10.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        v0.e = v1; // android.support.v4.app.u.e:android.support.v4.c.m
        // goto L_0053
    }

    protected void onSaveInstanceState(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onSaveInstanceState(v3); // android.app.Activity.onSaveInstanceState -> void
        v0 = v2.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.i(); // android.support.v4.app.y.i -> android.os.Parcelable
        v0 = _result;
        if (v0 == 0) /* goto L_0011 */;
        v1 = "android:support:fragments";
        _result = v3.putParcelable(v1, v0); // android.os.Bundle.putParcelable -> void
        return;
    }

    protected void onStart() {
        // Registers (6 total): v5 = this
        v3 = 1;
        v1 = 0;
        _result = v5.onStart(); // android.app.Activity.onStart -> void
        v5.f = v1; // android.support.v4.app.FragmentActivity.f:boolean
        v5.g = v1; // android.support.v4.app.FragmentActivity.g:boolean
        v0 = v5.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        _result = v0.removeMessages(v3); // android.os.Handler.removeMessages -> void
        v0 = v5.d; // android.support.v4.app.FragmentActivity.d:boolean
        if (v0 != 0) /* goto L_0019 */;
        v5.d = v3; // android.support.v4.app.FragmentActivity.d:boolean
        v0 = v5.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.l(); // android.support.v4.app.y.l -> void
        v0 = v5.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.j(); // android.support.v4.app.y.j -> void
        v0 = v5.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.f(); // android.support.v4.app.y.f -> boolean
        v0 = v5.k; // android.support.v4.app.FragmentActivity.k:boolean
        if (v0 != 0) /* goto L_0034 */;
        v5.k = v3; // android.support.v4.app.FragmentActivity.k:boolean
        v0 = v5.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        if (v0 == 0) /* goto L_0058 */;
        v0 = v5.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        _result = v0.b(); // android.support.v4.app.ao.b -> void
        v5.j = v3; // android.support.v4.app.FragmentActivity.j:boolean
        v0 = v5.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.m(); // android.support.v4.app.y.m -> void
        v0 = v5.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        if (v0 == 0) /* goto L_0085 */;
        v0 = v5.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        _result = v0.size(); // android.support.v4.c.m.size -> int
        v3 = _result;
        v4 = new android.support.v4.app.ao[][size=v3];
        v0 = binOpLit8_0xd8(v3, -1);
        v2 = v0;
        if (v2 < 0) /* goto L_0077 */;
        v0 = v5.l; // android.support.v4.app.FragmentActivity.l:android.support.v4.c.m
        _result = v0.c(v2); // android.support.v4.c.m.c -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ao) v0;
        v4[v2] = v0;
        v0 = binOpLit8_0xd8(v2, -1);
        v2 = v0;
        // goto L_0048
        v0 = v5.j; // android.support.v4.app.FragmentActivity.j:boolean
        if (v0 != 0) /* goto L_0032 */;
        v0 = "(root)";
        v2 = v5.k; // android.support.v4.app.FragmentActivity.k:boolean
        _result = v5.a(v0, v2, v1); // android.support.v4.app.FragmentActivity.a -> android.support.v4.app.ao
        v0 = _result;
        v5.m = v0; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        v0 = v5.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        if (v0 == 0) /* goto L_0032 */;
        v0 = v5.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        v0 = v0.f; // android.support.v4.app.ao.f:boolean
        if (v0 != 0) /* goto L_0032 */;
        v0 = v5.m; // android.support.v4.app.FragmentActivity.m:android.support.v4.app.ao
        _result = v0.b(); // android.support.v4.app.ao.b -> void
        // goto L_0032
        v0 = v1;
        if (v0 >= v3) /* goto L_0085 */;
        v1 = v4[v0];
        _result = v1.e(); // android.support.v4.app.ao.e -> void
        _result = v1.g(); // android.support.v4.app.ao.g -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0078
        return;
    }

    protected void onStop() {
        // Registers (3 total): v2 = this
        v1 = 1;
        _result = v2.onStop(); // android.app.Activity.onStop -> void
        v2.f = v1; // android.support.v4.app.FragmentActivity.f:boolean
        v0 = v2.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        _result = v0.sendEmptyMessage(v1); // android.os.Handler.sendEmptyMessage -> boolean
        v0 = v2.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.p(); // android.support.v4.app.y.p -> void
        return;
    }

    public void startActivityForResult(android.content.Intent p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.content.Intent), v4 = p1 (int)
        v0 = -1;
        if (v4 == v0) /* goto L_0011 */;
        v0 = 0xffff0000;
        v0 = binOp2addr_0xb5(v0, v4);
        if (v0 == 0) /* goto L_0011 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Can only use lower 16 bits for requestCode";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = v2.startActivityForResult(v3, v4); // android.app.Activity.startActivityForResult -> void
        return;
    }

    public void u_() {
        // Registers (3 total): v2 = this
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000a */;
        _result = v2.a(); // android.support.v4.app.k.a -> void
        return;
        v0 = 1;
        v2.i = v0; // android.support.v4.app.FragmentActivity.i:boolean
        // goto L_0009
    }

    public java.lang.Object v_() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

}