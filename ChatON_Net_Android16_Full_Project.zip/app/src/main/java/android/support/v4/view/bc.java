package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/bc;
 */
interface bc {
    public abstract int a(android.view.View p0);
    public abstract void a(android.view.View p0, int p1, int p2, int p3, int p4);
    public abstract void a(android.view.View p0, int p1, android.graphics.Paint p2);
    public abstract void a(android.view.View p0, android.graphics.Paint p1);
    public abstract void a(android.view.View p0, android.support.v4.view.a p1);
    public abstract void a(android.view.View p0, java.lang.Runnable p1);
    public abstract boolean a(android.view.View p0, int p1);
    public abstract void b(android.view.View p0);
    public abstract void b(android.view.View p0, int p1);
    public abstract int c(android.view.View p0);
    public abstract int d(android.view.View p0);
    public abstract int e(android.view.View p0);
    public abstract android.view.ViewParent f(android.view.View p0);
    public abstract boolean g(android.view.View p0);
}