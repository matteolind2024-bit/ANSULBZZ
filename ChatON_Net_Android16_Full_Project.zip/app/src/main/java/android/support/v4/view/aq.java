package android.support.v4.view;

/**
 * Original SourceFile: VelocityTrackerCompat.java
 * Descriptor: Landroid/support/v4/view/aq;
 */
class aq implements android.support.v4.view.ar {
    aq() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public float a(android.view.VelocityTracker p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.VelocityTracker), v3 = p1 (int)
        _result = v2.a(v3); // android.support.v4.view.as.a -> float
        v0 = _result;
        return v0;
    }

    public float b(android.view.VelocityTracker p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.VelocityTracker), v3 = p1 (int)
        _result = v2.b(v3); // android.support.v4.view.as.b -> float
        v0 = _result;
        return v0;
    }

}