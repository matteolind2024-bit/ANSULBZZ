package android.support.v4.widget;

/**
 * Original SourceFile: DrawerLayout.java
 * Descriptor: Landroid/support/v4/widget/DrawerLayout;
 */
public class DrawerLayout extends android.view.ViewGroup {
    private static final int[] a;
    private int b;
    private int c;
    private float d;
    private android.graphics.Paint e;
    private final android.support.v4.widget.am f;
    private final android.support.v4.widget.am g;
    private final android.support.v4.widget.l h;
    private final android.support.v4.widget.l i;
    private int j;
    private boolean k;
    private boolean l;
    private int m;
    private int n;
    private boolean o;
    private boolean p;
    private android.support.v4.widget.j q;
    private float r;
    private float s;
    private android.graphics.drawable.Drawable t;
    private android.graphics.drawable.Drawable u;

    static {
        v0 = 1;
        v0 = new int[][size=v0];
        v1 = 0;
        v2 = 16842931; // 0x010100b3
        v0[v1] = v2;
        android.support.v4.widget.DrawerLayout.a = v0; // :int[]
        return;
    }

    public DrawerLayout(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        v0 = 0;
        _result = v1.<init>(v2, v0); // android.support.v4.widget.DrawerLayout.<init> -> void
        return;
    }

    public DrawerLayout(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.util.AttributeSet)
        v0 = 0;
        _result = v1.<init>(v2, v3, v0); // android.support.v4.widget.DrawerLayout.<init> -> void
        return;
    }

    public DrawerLayout(android.content.Context p0, android.util.AttributeSet p1, int p2) {
        // Registers (9 total): v5 = this, v6 = p0 (android.content.Context), v7 = p1 (android.util.AttributeSet), v8 = p2 (int)
        v4 = 0x3f800000;
        v3 = 1;
        _result = v5.<init>(v6, v7, v8); // android.view.ViewGroup.<init> -> void
        v0 = 0x99000000;
        v5.c = v0; // android.support.v4.widget.DrawerLayout.c:int
        v0 = new android.graphics.Paint;
        _result = v0.<init>(); // android.graphics.Paint.<init> -> void
        v5.e = v0; // android.support.v4.widget.DrawerLayout.e:android.graphics.Paint
        v5.l = v3; // android.support.v4.widget.DrawerLayout.l:boolean
        _result = v5.getResources(); // android.support.v4.widget.DrawerLayout.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v0 = _result;
        v0 = v0.density; // android.util.DisplayMetrics.density:float
        v1 = 0x42800000;
        v1 = binOp2addr_0xc8(v1, v0);
        v2 = 0x3f000000;
        v1 = binOp2addr_0xc6(v1, v2);
        v1 = unaryOp_0x87(v1);
        v5.b = v1; // android.support.v4.widget.DrawerLayout.b:int
        v1 = 0x43c80000;
        v0 = binOp2addr_0xc8(v0, v1);
        v1 = new android.support.v4.widget.l;
        v2 = 3;
        _result = v1.<init>(v5, v2); // android.support.v4.widget.l.<init> -> void
        v5.h = v1; // android.support.v4.widget.DrawerLayout.h:android.support.v4.widget.l
        v1 = new android.support.v4.widget.l;
        v2 = 5;
        _result = v1.<init>(v5, v2); // android.support.v4.widget.l.<init> -> void
        v5.i = v1; // android.support.v4.widget.DrawerLayout.i:android.support.v4.widget.l
        v1 = v5.h; // android.support.v4.widget.DrawerLayout.h:android.support.v4.widget.l
        _result = v5.a(v4, v1); // android.support.v4.widget.am.a -> android.support.v4.widget.am
        v1 = _result;
        v5.f = v1; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        v1 = v5.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        _result = v1.a(v3); // android.support.v4.widget.am.a -> void
        v1 = v5.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        _result = v1.a(v0); // android.support.v4.widget.am.a -> void
        v1 = v5.h; // android.support.v4.widget.DrawerLayout.h:android.support.v4.widget.l
        v2 = v5.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        _result = v1.a(v2); // android.support.v4.widget.l.a -> void
        v1 = v5.i; // android.support.v4.widget.DrawerLayout.i:android.support.v4.widget.l
        _result = v5.a(v4, v1); // android.support.v4.widget.am.a -> android.support.v4.widget.am
        v1 = _result;
        v5.g = v1; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        v1 = v5.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        v2 = 2;
        _result = v1.a(v2); // android.support.v4.widget.am.a -> void
        v1 = v5.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        _result = v1.a(v0); // android.support.v4.widget.am.a -> void
        v0 = v5.i; // android.support.v4.widget.DrawerLayout.i:android.support.v4.widget.l
        v1 = v5.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        _result = v0.a(v1); // android.support.v4.widget.l.a -> void
        _result = v5.setFocusableInTouchMode(v3); // android.support.v4.widget.DrawerLayout.setFocusableInTouchMode -> void
        v0 = new android.support.v4.widget.i;
        _result = v0.<init>(v5); // android.support.v4.widget.i.<init> -> void
        _result = v5.a(v0); // android.support.v4.view.at.a -> void
        v0 = 0;
        _result = v5.a(v0); // android.support.v4.view.bo.a -> void
        return;
    }

    static java.lang.String b(int p0) {
        // Registers (3 total): v2 = p0 (int)
        v0 = binOpLit8_0xdd(v2, 3);
        v1 = 3;
        if (v0 != v1) /* goto L_0009 */;
        v0 = "LEFT";
        return v0;
        v0 = binOpLit8_0xdd(v2, 5);
        v1 = 5;
        if (v0 != v1) /* goto L_0012 */;
        v0 = "RIGHT";
        // goto L_0008
        _result = v2.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        // goto L_0008
    }

    static int[] d() {
        v0 = android.support.v4.widget.DrawerLayout.a; // :int[]
        return v0;
    }

    private boolean e() {
        // Registers (5 total): v4 = this
        v1 = 0;
        _result = v4.getChildCount(); // android.support.v4.widget.DrawerLayout.getChildCount -> int
        v3 = _result;
        v2 = v1;
        if (v2 >= v3) /* goto L_001c */;
        _result = v4.getChildAt(v2); // android.support.v4.widget.DrawerLayout.getChildAt -> android.view.View
        v0 = _result;
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v0 = v0.c; // android.support.v4.widget.DrawerLayout$LayoutParams.c:boolean
        if (v0 == 0) /* goto L_0018 */;
        v0 = 1;
        return v0;
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0006
        v0 = v1;
        // goto L_0017
    }

    private boolean f() {
        // Registers (2 total): v1 = this
        _result = v1.g(); // android.support.v4.widget.DrawerLayout.g -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0008 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    private android.view.View g() {
        // Registers (5 total): v4 = this
        _result = v4.getChildCount(); // android.support.v4.widget.DrawerLayout.getChildCount -> int
        v2 = _result;
        v0 = 0;
        v1 = v0;
        if (v1 >= v2) /* goto L_001d */;
        _result = v4.getChildAt(v1); // android.support.v4.widget.DrawerLayout.getChildAt -> android.view.View
        v0 = _result;
        _result = v4.g(v0); // android.support.v4.widget.DrawerLayout.g -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0019 */;
        _result = v4.k(v0); // android.support.v4.widget.DrawerLayout.k -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0019 */;
        return v0;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
        v0 = 0;
        // goto L_0018
    }

    private static boolean l(android.view.View p0) {
        // Registers (4 total): v3 = p0 (android.view.View)
        v0 = 0;
        _result = v3.getBackground(); // android.view.View.getBackground -> android.graphics.drawable.Drawable
        v1 = _result;
        if (v1 == 0) /* goto L_000f */;
        _result = v1.getOpacity(); // android.graphics.drawable.Drawable.getOpacity -> int
        v1 = _result;
        v2 = -1;
        if (v1 != v2) /* goto L_000f */;
        v0 = 1;
        return v0;
    }

    public int a(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        _result = v2.e(v3); // android.support.v4.widget.DrawerLayout.e -> int
        v0 = _result;
        v1 = 3;
        if (v0 != v1) /* goto L_000a */;
        v0 = v2.m; // android.support.v4.widget.DrawerLayout.m:int
        return v0;
        v1 = 5;
        if (v0 != v1) /* goto L_0010 */;
        v0 = v2.n; // android.support.v4.widget.DrawerLayout.n:int
        // goto L_0009
        v0 = 0;
        // goto L_0009
    }

    android.view.View a() {
        // Registers (5 total): v4 = this
        _result = v4.getChildCount(); // android.support.v4.widget.DrawerLayout.getChildCount -> int
        v3 = _result;
        v0 = 0;
        v2 = v0;
        if (v2 >= v3) /* goto L_001c */;
        _result = v4.getChildAt(v2); // android.support.v4.widget.DrawerLayout.getChildAt -> android.view.View
        v1 = _result;
        _result = v1.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v0 = v0.d; // android.support.v4.widget.DrawerLayout$LayoutParams.d:boolean
        if (v0 == 0) /* goto L_0018 */;
        v0 = v1;
        return v0;
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0006
        v0 = 0;
        // goto L_0017
    }

    android.view.View a(int p0) {
        // Registers (7 total): v5 = this, v6 = p0 (int)
        _result = v5.e(); // android.support.v4.view.at.e -> int
        v0 = _result;
        _result = v6.a(v0); // android.support.v4.view.n.a -> int
        v0 = _result;
        v2 = binOpLit8_0xdd(v0, 7);
        _result = v5.getChildCount(); // android.support.v4.widget.DrawerLayout.getChildCount -> int
        v3 = _result;
        v0 = 0;
        v1 = v0;
        if (v1 >= v3) /* goto L_0023 */;
        _result = v5.getChildAt(v1); // android.support.v4.widget.DrawerLayout.getChildAt -> android.view.View
        v0 = _result;
        _result = v5.e(v0); // android.support.v4.widget.DrawerLayout.e -> int
        v4 = _result;
        v4 = binOpLit8_0xdd(v4, 7);
        if (v4 != v2) /* goto L_001f */;
        return v0;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0010
        v0 = 0;
        // goto L_001e
    }

    void a(int p0, int p1, android.view.View p2) {
        // Registers (8 total): v4 = this, v5 = p0 (int), v6 = p1 (int), v7 = p2 (android.view.View)
        v0 = 2;
        v1 = 1;
        v2 = v4.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        _result = v2.a(); // android.support.v4.widget.am.a -> int
        v2 = _result;
        v3 = v4.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        _result = v3.a(); // android.support.v4.widget.am.a -> int
        v3 = _result;
        if (v2 == v1) /* goto L_0012 */;
        if (v3 != v1) /* goto L_0036 */;
        if (v7 == 0) /* goto L_0026 */;
        if (v6 != 0) /* goto L_0026 */;
        _result = v7.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v2 = v0.b; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        v3 = 0;
        v2 = cmp(v2, v3);
        if (v2 != 0) /* goto L_003f */;
        _result = v4.b(v7); // android.support.v4.widget.DrawerLayout.b -> void
        v0 = v4.j; // android.support.v4.widget.DrawerLayout.j:int
        if (v1 == v0) /* goto L_0035 */;
        v4.j = v1; // android.support.v4.widget.DrawerLayout.j:int
        v0 = v4.q; // android.support.v4.widget.DrawerLayout.q:android.support.v4.widget.j
        if (v0 == 0) /* goto L_0035 */;
        v0 = v4.q; // android.support.v4.widget.DrawerLayout.q:android.support.v4.widget.j
        _result = android.support.v4.widget.j.a(v0, v1); // -> void
        return;
        if (v2 == v0) /* goto L_003a */;
        if (v3 != v0) /* goto L_003c */;
        v1 = v0;
        // goto L_0012
        v0 = 0;
        v1 = v0;
        // goto L_0012
        v0 = v0.b; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        v2 = 0x3f800000;
        v0 = cmp(v0, v2);
        if (v0 != 0) /* goto L_0026 */;
        _result = v4.c(v7); // android.support.v4.widget.DrawerLayout.c -> void
        // goto L_0026
    }

    void a(android.view.View p0, float p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (float)
        v0 = v1.q; // android.support.v4.widget.DrawerLayout.q:android.support.v4.widget.j
        if (v0 == 0) /* goto L_0009 */;
        v0 = v1.q; // android.support.v4.widget.DrawerLayout.q:android.support.v4.widget.j
        _result = android.support.v4.widget.j.a(v0, v2, v3); // -> void
        return;
    }

    void a(boolean p0) {
        // Registers (11 total): v9 = this, v10 = p0 (boolean)
        v3 = 0;
        _result = v9.getChildCount(); // android.support.v4.widget.DrawerLayout.getChildCount -> int
        v4 = _result;
        v2 = v3;
        v1 = v3;
        if (v2 >= v4) /* goto L_004d */;
        _result = v9.getChildAt(v2); // android.support.v4.widget.DrawerLayout.getChildAt -> android.view.View
        v5 = _result;
        _result = v5.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        _result = v9.g(v5); // android.support.v4.widget.DrawerLayout.g -> boolean
        v6 = _result;
        if (v6 == 0) /* goto L_001f */;
        if (v10 == 0) /* goto L_0023 */;
        v6 = v0.c; // android.support.v4.widget.DrawerLayout$LayoutParams.c:boolean
        if (v6 != 0) /* goto L_0023 */;
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0007
        _result = v5.getWidth(); // android.view.View.getWidth -> int
        v6 = _result;
        v7 = 3;
        _result = v9.a(v5, v7); // android.support.v4.widget.DrawerLayout.a -> boolean
        v7 = _result;
        if (v7 == 0) /* goto L_003d */;
        v7 = v9.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        v6 = unaryOp_0x7b(v6);
        _result = v5.getTop(); // android.view.View.getTop -> int
        v8 = _result;
        _result = v7.a(v5, v6, v8); // android.support.v4.widget.am.a -> boolean
        v5 = _result;
        v1 = binOp2addr_0xb6(v1, v5);
        v0.c = v3; // android.support.v4.widget.DrawerLayout$LayoutParams.c:boolean
        // goto L_001f
        v6 = v9.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        _result = v9.getWidth(); // android.support.v4.widget.DrawerLayout.getWidth -> int
        v7 = _result;
        _result = v5.getTop(); // android.view.View.getTop -> int
        v8 = _result;
        _result = v6.a(v5, v7, v8); // android.support.v4.widget.am.a -> boolean
        v5 = _result;
        v1 = binOp2addr_0xb6(v1, v5);
        // goto L_003a
        v0 = v9.h; // android.support.v4.widget.DrawerLayout.h:android.support.v4.widget.l
        _result = v0.a(); // android.support.v4.widget.l.a -> void
        v0 = v9.i; // android.support.v4.widget.DrawerLayout.i:android.support.v4.widget.l
        _result = v0.a(); // android.support.v4.widget.l.a -> void
        if (v1 == 0) /* goto L_005c */;
        _result = v9.invalidate(); // android.support.v4.widget.DrawerLayout.invalidate -> void
        return;
    }

    boolean a(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        _result = v1.e(v2); // android.support.v4.widget.DrawerLayout.e -> int
        v0 = _result;
        v0 = binOp2addr_0xb5(v0, v3);
        if (v0 != v3) /* goto L_0009 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0008
    }

    public void b() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.a(v0); // android.support.v4.widget.DrawerLayout.a -> void
        return;
    }

    void b(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        _result = v3.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v1 = v0.d; // android.support.v4.widget.DrawerLayout$LayoutParams.d:boolean
        if (v1 == 0) /* goto L_001b */;
        v1 = 0;
        v0.d = v1; // android.support.v4.widget.DrawerLayout$LayoutParams.d:boolean
        v0 = v2.q; // android.support.v4.widget.DrawerLayout.q:android.support.v4.widget.j
        if (v0 == 0) /* goto L_0016 */;
        v0 = v2.q; // android.support.v4.widget.DrawerLayout.q:android.support.v4.widget.j
        _result = android.support.v4.widget.j.b(v0, v3); // -> void
        v0 = 32;
        _result = v2.sendAccessibilityEvent(v0); // android.support.v4.widget.DrawerLayout.sendAccessibilityEvent -> void
        return;
    }

    void b(android.view.View p0, float p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (float)
        _result = v3.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v1 = v0.b; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        v1 = cmp(v4, v1);
        if (v1 != 0) /* goto L_000d */;
        return;
        v0.b = v4; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        _result = v2.a(v3, v4); // android.support.v4.widget.DrawerLayout.a -> void
        // goto L_000c
    }

    void c() {
        // Registers (9 total): v8 = this
        v7 = 0;
        v5 = 0;
        v0 = v8.p; // android.support.v4.widget.DrawerLayout.p:boolean
        if (v0 != 0) /* goto L_0027 */;
        _result = this.uptimeMillis(); // android.os.SystemClock.uptimeMillis -> long
        v0 = _result;
        v4 = 3;
        v2 = v0;
        v6 = v5;
        _result = v0.obtain(v0..v7); // android.view.MotionEvent.obtain -> android.view.MotionEvent
        v0 = _result;
        _result = v8.getChildCount(); // android.support.v4.widget.DrawerLayout.getChildCount -> int
        v1 = _result;
        if (v7 >= v1) /* goto L_0021 */;
        _result = v8.getChildAt(v7); // android.support.v4.widget.DrawerLayout.getChildAt -> android.view.View
        v2 = _result;
        _result = v2.dispatchTouchEvent(v0); // android.view.View.dispatchTouchEvent -> boolean
        v7 = binOpLit8_0xd8(v7, 1);
        // goto L_0015
        _result = v0.recycle(); // android.view.MotionEvent.recycle -> void
        v0 = 1;
        v8.p = v0; // android.support.v4.widget.DrawerLayout.p:boolean
        return;
    }

    void c(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        _result = v3.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v1 = v0.d; // android.support.v4.widget.DrawerLayout$LayoutParams.d:boolean
        if (v1 != 0) /* goto L_001b */;
        v1 = 1;
        v0.d = v1; // android.support.v4.widget.DrawerLayout$LayoutParams.d:boolean
        v0 = v2.q; // android.support.v4.widget.DrawerLayout.q:android.support.v4.widget.j
        if (v0 == 0) /* goto L_0016 */;
        v0 = v2.q; // android.support.v4.widget.DrawerLayout.q:android.support.v4.widget.j
        _result = android.support.v4.widget.j.a(v0, v3); // -> void
        v0 = 32;
        _result = v3.sendAccessibilityEvent(v0); // android.view.View.sendAccessibilityEvent -> void
        return;
    }

    protected boolean checkLayoutParams(android.view.ViewGroup$LayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$LayoutParams)
        v0 = (v2 instanceof android.support.v4.widget.DrawerLayout$LayoutParams);
        if (v0 == 0) /* goto L_000c */;
        _result = v1.checkLayoutParams(v2); // android.view.ViewGroup.checkLayoutParams -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000b
    }

    public void computeScroll() {
        // Registers (6 total): v5 = this
        v4 = 1;
        _result = v5.getChildCount(); // android.support.v4.widget.DrawerLayout.getChildCount -> int
        v3 = _result;
        v1 = 0;
        v0 = 0;
        v2 = v1;
        v1 = v0;
        if (v1 >= v3) /* goto L_001f */;
        _result = v5.getChildAt(v1); // android.support.v4.widget.DrawerLayout.getChildAt -> android.view.View
        v0 = _result;
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v0 = v0.b; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        _result = v2.max(v0); // java.lang.Math.max -> float
        v2 = _result;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0009
        v5.d = v2; // android.support.v4.widget.DrawerLayout.d:float
        v0 = v5.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        _result = v0.a(v4); // android.support.v4.widget.am.a -> boolean
        v0 = _result;
        v1 = v5.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        _result = v1.a(v4); // android.support.v4.widget.am.a -> boolean
        v1 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        if (v0 == 0) /* goto L_0033 */;
        _result = v5.b(); // android.support.v4.view.at.b -> void
        return;
    }

    float d(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v0 = v0.b; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        return v0;
    }

    protected boolean drawChild(android.graphics.Canvas p0, android.view.View p1, long p2) {
        // Registers (14 total): v9 = this, v10 = p0 (android.graphics.Canvas), v11 = p1 (android.view.View), v12 = p2 (long)
        _result = v9.getHeight(); // android.support.v4.widget.DrawerLayout.getHeight -> int
        v4 = _result;
        _result = v9.f(v11); // android.support.v4.widget.DrawerLayout.f -> boolean
        v5 = _result;
        v1 = 0;
        _result = v9.getWidth(); // android.support.v4.widget.DrawerLayout.getWidth -> int
        v2 = _result;
        _result = v10.save(); // android.graphics.Canvas.save -> int
        v6 = _result;
        if (v5 == 0) /* goto L_005f */;
        _result = v9.getChildCount(); // android.support.v4.widget.DrawerLayout.getChildCount -> int
        v7 = _result;
        v0 = 0;
        v3 = v0;
        if (v3 >= v7) /* goto L_0057 */;
        _result = v9.getChildAt(v3); // android.support.v4.widget.DrawerLayout.getChildAt -> android.view.View
        v0 = _result;
        if (v0 == v11) /* goto L_0055 */;
        _result = v0.getVisibility(); // android.view.View.getVisibility -> int
        v8 = _result;
        if (v8 != 0) /* goto L_0055 */;
        _result = v0.l(); // android.support.v4.widget.DrawerLayout.l -> boolean
        v8 = _result;
        if (v8 == 0) /* goto L_0055 */;
        _result = v9.g(v0); // android.support.v4.widget.DrawerLayout.g -> boolean
        v8 = _result;
        if (v8 == 0) /* goto L_0055 */;
        _result = v0.getHeight(); // android.view.View.getHeight -> int
        v8 = _result;
        if (v8 >= v4) /* goto L_003f */;
        v0 = v2;
        v2 = binOpLit8_0xd8(v3, 1);
        v3 = v2;
        v2 = v0;
        // goto L_0019
        v8 = 3;
        _result = v9.a(v0, v8); // android.support.v4.widget.DrawerLayout.a -> boolean
        v8 = _result;
        if (v8 == 0) /* goto L_004f */;
        _result = v0.getRight(); // android.view.View.getRight -> int
        v0 = _result;
        if (v0 <= v1) /* goto L_012d */;
        v1 = v0;
        v0 = v2;
        // goto L_003a
        _result = v0.getLeft(); // android.view.View.getLeft -> int
        v0 = _result;
        if (v0 < v2) /* goto L_003a */;
        v0 = v2;
        // goto L_003a
        v0 = 0;
        _result = v9.getHeight(); // android.support.v4.widget.DrawerLayout.getHeight -> int
        v3 = _result;
        _result = v10.clipRect(v1, v0, v2, v3); // android.graphics.Canvas.clipRect -> boolean
        v0 = v2;
        _result = v9.drawChild(v10, v11, v12, v13); // android.view.ViewGroup.drawChild -> boolean
        v7 = _result;
        _result = v10.restoreToCount(v6); // android.graphics.Canvas.restoreToCount -> void
        v2 = v9.d; // android.support.v4.widget.DrawerLayout.d:float
        v3 = 0;
        v2 = cmp(v2, v3);
        if (v2 <= 0) /* goto L_0099 */;
        if (v5 == 0) /* goto L_0099 */;
        v2 = v9.c; // android.support.v4.widget.DrawerLayout.c:int
        v3 = 0xff000000;
        v2 = binOp2addr_0xb5(v2, v3);
        v2 = binOpLit8_0xe2(v2, 24);
        v2 = unaryOp_0x82(v2);
        v3 = v9.d; // android.support.v4.widget.DrawerLayout.d:float
        v2 = binOp2addr_0xc8(v2, v3);
        v2 = unaryOp_0x87(v2);
        v2 = binOpLit8_0xe0(v2, 24);
        v3 = v9.c; // android.support.v4.widget.DrawerLayout.c:int
        v4 = 16777215; // 0x00ffffff
        v3 = binOp2addr_0xb5(v3, v4);
        v2 = binOp2addr_0xb6(v2, v3);
        v3 = v9.e; // android.support.v4.widget.DrawerLayout.e:android.graphics.Paint
        _result = v3.setColor(v2); // android.graphics.Paint.setColor -> void
        v1 = unaryOp_0x82(v1);
        v2 = 0;
        v3 = unaryOp_0x82(v0);
        _result = v9.getHeight(); // android.support.v4.widget.DrawerLayout.getHeight -> int
        v0 = _result;
        v4 = unaryOp_0x82(v0);
        v5 = v9.e; // android.support.v4.widget.DrawerLayout.e:android.graphics.Paint
        v0 = v10;
        _result = v0.drawRect(v0..v5); // android.graphics.Canvas.drawRect -> void
        return v7;
        v0 = v9.t; // android.support.v4.widget.DrawerLayout.t:android.graphics.drawable.Drawable
        if (v0 == 0) /* goto L_00e0 */;
        v0 = 3;
        _result = v9.a(v11, v0); // android.support.v4.widget.DrawerLayout.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00e0 */;
        v0 = v9.t; // android.support.v4.widget.DrawerLayout.t:android.graphics.drawable.Drawable
        _result = v0.getIntrinsicWidth(); // android.graphics.drawable.Drawable.getIntrinsicWidth -> int
        v0 = _result;
        _result = v11.getRight(); // android.view.View.getRight -> int
        v1 = _result;
        v2 = v9.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        _result = v2.b(); // android.support.v4.widget.am.b -> int
        v2 = _result;
        v3 = 0;
        v4 = unaryOp_0x82(v1);
        v2 = unaryOp_0x82(v2);
        v2 = binOp_0xa9(v4, v2);
        v4 = 0x3f800000;
        _result = v2.min(v4); // java.lang.Math.min -> float
        v2 = _result;
        _result = v3.max(v2); // java.lang.Math.max -> float
        v2 = _result;
        v3 = v9.t; // android.support.v4.widget.DrawerLayout.t:android.graphics.drawable.Drawable
        _result = v11.getTop(); // android.view.View.getTop -> int
        v4 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        _result = v11.getBottom(); // android.view.View.getBottom -> int
        v5 = _result;
        _result = v3.setBounds(v1, v4, v0, v5); // android.graphics.drawable.Drawable.setBounds -> void
        v0 = v9.t; // android.support.v4.widget.DrawerLayout.t:android.graphics.drawable.Drawable
        v1 = 0x437f0000;
        v1 = binOp2addr_0xc8(v1, v2);
        v1 = unaryOp_0x87(v1);
        _result = v0.setAlpha(v1); // android.graphics.drawable.Drawable.setAlpha -> void
        v0 = v9.t; // android.support.v4.widget.DrawerLayout.t:android.graphics.drawable.Drawable
        _result = v0.draw(v10); // android.graphics.drawable.Drawable.draw -> void
        // goto L_0098
        v0 = v9.u; // android.support.v4.widget.DrawerLayout.u:android.graphics.drawable.Drawable
        if (v0 == 0) /* goto L_0098 */;
        v0 = 5;
        _result = v9.a(v11, v0); // android.support.v4.widget.DrawerLayout.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0098 */;
        v0 = v9.u; // android.support.v4.widget.DrawerLayout.u:android.graphics.drawable.Drawable
        _result = v0.getIntrinsicWidth(); // android.graphics.drawable.Drawable.getIntrinsicWidth -> int
        v0 = _result;
        _result = v11.getLeft(); // android.view.View.getLeft -> int
        v1 = _result;
        _result = v9.getWidth(); // android.support.v4.widget.DrawerLayout.getWidth -> int
        v2 = _result;
        v2 = binOp2addr_0xb1(v2, v1);
        v3 = v9.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        _result = v3.b(); // android.support.v4.widget.am.b -> int
        v3 = _result;
        v4 = 0;
        v2 = unaryOp_0x82(v2);
        v3 = unaryOp_0x82(v3);
        v2 = binOp2addr_0xc9(v2, v3);
        v3 = 0x3f800000;
        _result = v2.min(v3); // java.lang.Math.min -> float
        v2 = _result;
        _result = v4.max(v2); // java.lang.Math.max -> float
        v2 = _result;
        v3 = v9.u; // android.support.v4.widget.DrawerLayout.u:android.graphics.drawable.Drawable
        v0 = binOp_0x91(v1, v0);
        _result = v11.getTop(); // android.view.View.getTop -> int
        v4 = _result;
        _result = v11.getBottom(); // android.view.View.getBottom -> int
        v5 = _result;
        _result = v3.setBounds(v0, v4, v1, v5); // android.graphics.drawable.Drawable.setBounds -> void
        v0 = v9.u; // android.support.v4.widget.DrawerLayout.u:android.graphics.drawable.Drawable
        v1 = 0x437f0000;
        v1 = binOp2addr_0xc8(v1, v2);
        v1 = unaryOp_0x87(v1);
        _result = v0.setAlpha(v1); // android.graphics.drawable.Drawable.setAlpha -> void
        v0 = v9.u; // android.support.v4.widget.DrawerLayout.u:android.graphics.drawable.Drawable
        _result = v0.draw(v10); // android.graphics.drawable.Drawable.draw -> void
        // goto L_0098
        v0 = v1;
        // goto L_004c
    }

    int e(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        _result = v3.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v0 = v0.a; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        _result = v2.e(); // android.support.v4.view.at.e -> int
        v1 = _result;
        _result = v0.a(v1); // android.support.v4.view.n.a -> int
        v0 = _result;
        return v0;
    }

    boolean f(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v0 = v0.a; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        if (v0 != 0) /* goto L_000c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000b
    }

    boolean g(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        _result = v3.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v0 = v0.a; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        _result = v3.e(); // android.support.v4.view.at.e -> int
        v1 = _result;
        _result = v0.a(v1); // android.support.v4.view.n.a -> int
        v0 = _result;
        v0 = binOpLit8_0xdd(v0, 7);
        if (v0 == 0) /* goto L_0016 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0015
    }

    protected android.view.ViewGroup$LayoutParams generateDefaultLayoutParams() {
        // Registers (3 total): v2 = this
        v1 = -1;
        v0 = new android.support.v4.widget.DrawerLayout$LayoutParams;
        _result = v0.<init>(v1, v1); // android.support.v4.widget.DrawerLayout$LayoutParams.<init> -> void
        return v0;
    }

    public android.view.ViewGroup$LayoutParams generateLayoutParams(android.util.AttributeSet p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.util.AttributeSet)
        v0 = new android.support.v4.widget.DrawerLayout$LayoutParams;
        _result = v2.getContext(); // android.support.v4.widget.DrawerLayout.getContext -> android.content.Context
        v1 = _result;
        _result = v0.<init>(v1, v3); // android.support.v4.widget.DrawerLayout$LayoutParams.<init> -> void
        return v0;
    }

    protected android.view.ViewGroup$LayoutParams generateLayoutParams(android.view.ViewGroup$LayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$LayoutParams)
        v0 = (v2 instanceof android.support.v4.widget.DrawerLayout$LayoutParams);
        if (v0 == 0) /* goto L_000c */;
        v0 = new android.support.v4.widget.DrawerLayout$LayoutParams;
        v2 = (android.support.v4.widget.DrawerLayout$LayoutParams) v2;
        _result = v0.<init>(v2); // android.support.v4.widget.DrawerLayout$LayoutParams.<init> -> void
        return v0;
        v0 = (v2 instanceof android.view.ViewGroup$MarginLayoutParams);
        if (v0 == 0) /* goto L_0018 */;
        v0 = new android.support.v4.widget.DrawerLayout$LayoutParams;
        v2 = (android.view.ViewGroup$MarginLayoutParams) v2;
        _result = v0.<init>(v2); // android.support.v4.widget.DrawerLayout$LayoutParams.<init> -> void
        // goto L_000b
        v0 = new android.support.v4.widget.DrawerLayout$LayoutParams;
        _result = v0.<init>(v2); // android.support.v4.widget.DrawerLayout$LayoutParams.<init> -> void
        // goto L_000b
    }

    public void h(android.view.View p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.View)
        _result = v3.g(v4); // android.support.v4.widget.DrawerLayout.g -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0027 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "View ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " is not a sliding drawer";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v3.l; // android.support.v4.widget.DrawerLayout.l:boolean
        if (v0 == 0) /* goto L_003c */;
        _result = v4.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v1 = 0x3f800000;
        v0.b = v1; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        v1 = 1;
        v0.d = v1; // android.support.v4.widget.DrawerLayout$LayoutParams.d:boolean
        _result = v3.invalidate(); // android.support.v4.widget.DrawerLayout.invalidate -> void
        return;
        v0 = 3;
        _result = v3.a(v4, v0); // android.support.v4.widget.DrawerLayout.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_004e */;
        v0 = v3.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        v1 = 0;
        _result = v4.getTop(); // android.view.View.getTop -> int
        v2 = _result;
        _result = v0.a(v4, v1, v2); // android.support.v4.widget.am.a -> boolean
        // goto L_0038
        v0 = v3.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        _result = v3.getWidth(); // android.support.v4.widget.DrawerLayout.getWidth -> int
        v1 = _result;
        _result = v4.getWidth(); // android.view.View.getWidth -> int
        v2 = _result;
        v1 = binOp2addr_0xb1(v1, v2);
        _result = v4.getTop(); // android.view.View.getTop -> int
        v2 = _result;
        _result = v0.a(v4, v1, v2); // android.support.v4.widget.am.a -> boolean
        // goto L_0038
    }

    public void i(android.view.View p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.View)
        _result = v3.g(v4); // android.support.v4.widget.DrawerLayout.g -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0027 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "View ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " is not a sliding drawer";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v3.l; // android.support.v4.widget.DrawerLayout.l:boolean
        if (v0 == 0) /* goto L_003b */;
        _result = v4.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v1 = 0;
        v0.b = v1; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        v1 = 0;
        v0.d = v1; // android.support.v4.widget.DrawerLayout$LayoutParams.d:boolean
        _result = v3.invalidate(); // android.support.v4.widget.DrawerLayout.invalidate -> void
        return;
        v0 = 3;
        _result = v3.a(v4, v0); // android.support.v4.widget.DrawerLayout.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0051 */;
        v0 = v3.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        _result = v4.getWidth(); // android.view.View.getWidth -> int
        v1 = _result;
        v1 = unaryOp_0x7b(v1);
        _result = v4.getTop(); // android.view.View.getTop -> int
        v2 = _result;
        _result = v0.a(v4, v1, v2); // android.support.v4.widget.am.a -> boolean
        // goto L_0037
        v0 = v3.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        _result = v3.getWidth(); // android.support.v4.widget.DrawerLayout.getWidth -> int
        v1 = _result;
        _result = v4.getTop(); // android.view.View.getTop -> int
        v2 = _result;
        _result = v0.a(v4, v1, v2); // android.support.v4.widget.am.a -> boolean
        // goto L_0037
    }

    public boolean j(android.view.View p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.View)
        _result = v3.g(v4); // android.support.v4.widget.DrawerLayout.g -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0027 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "View ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " is not a drawer";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = v4.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v0 = v0.d; // android.support.v4.widget.DrawerLayout$LayoutParams.d:boolean
        return v0;
    }

    public boolean k(android.view.View p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.View)
        _result = v3.g(v4); // android.support.v4.widget.DrawerLayout.g -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0027 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "View ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " is not a drawer";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = v4.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v0 = v0.b; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        v1 = 0;
        v0 = cmp(v0, v1);
        if (v0 <= 0) /* goto L_0036 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0035
    }

    protected void onAttachedToWindow() {
        // Registers (2 total): v1 = this
        _result = v1.onAttachedToWindow(); // android.view.ViewGroup.onAttachedToWindow -> void
        v0 = 1;
        v1.l = v0; // android.support.v4.widget.DrawerLayout.l:boolean
        return;
    }

    protected void onDetachedFromWindow() {
        // Registers (2 total): v1 = this
        _result = v1.onDetachedFromWindow(); // android.view.ViewGroup.onDetachedFromWindow -> void
        v0 = 1;
        v1.l = v0; // android.support.v4.widget.DrawerLayout.l:boolean
        return;
    }

    public boolean onInterceptTouchEvent(android.view.MotionEvent p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.view.MotionEvent)
        v1 = 1;
        v2 = 0;
        _result = v8.a(); // android.support.v4.view.z.a -> int
        v0 = _result;
        v3 = v7.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        _result = v3.a(v8); // android.support.v4.widget.am.a -> boolean
        v3 = _result;
        v4 = v7.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        _result = v4.a(v8); // android.support.v4.widget.am.a -> boolean
        v4 = _result;
        v3 = binOp2addr_0xb6(v3, v4);
        // switch(v0)
        v0 = v2;
        if (v3 != 0) /* goto L_0025 */;
        if (v0 != 0) /* goto L_0025 */;
        _result = v7.e(); // android.support.v4.widget.DrawerLayout.e -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0025 */;
        v0 = v7.p; // android.support.v4.widget.DrawerLayout.p:boolean
        if (v0 == 0) /* goto L_0026 */;
        v2 = v1;
        return v2;
        _result = v8.getX(); // android.view.MotionEvent.getX -> float
        v0 = _result;
        _result = v8.getY(); // android.view.MotionEvent.getY -> float
        v4 = _result;
        v7.r = v0; // android.support.v4.widget.DrawerLayout.r:float
        v7.s = v4; // android.support.v4.widget.DrawerLayout.s:float
        v5 = v7.d; // android.support.v4.widget.DrawerLayout.d:float
        v6 = 0;
        v5 = cmp(v5, v6);
        if (v5 <= 0) /* goto L_006b */;
        v5 = v7.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        v0 = unaryOp_0x87(v0);
        v4 = unaryOp_0x87(v4);
        _result = v5.d(v0, v4); // android.support.v4.widget.am.d -> android.view.View
        v0 = _result;
        _result = v7.f(v0); // android.support.v4.widget.DrawerLayout.f -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_006b */;
        v0 = v1;
        v7.o = v2; // android.support.v4.widget.DrawerLayout.o:boolean
        v7.p = v2; // android.support.v4.widget.DrawerLayout.p:boolean
        // goto L_0017
        v0 = v7.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        v4 = 3;
        _result = v0.d(v4); // android.support.v4.widget.am.d -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0016 */;
        v0 = v7.h; // android.support.v4.widget.DrawerLayout.h:android.support.v4.widget.l
        _result = v0.a(); // android.support.v4.widget.l.a -> void
        v0 = v7.i; // android.support.v4.widget.DrawerLayout.i:android.support.v4.widget.l
        _result = v0.a(); // android.support.v4.widget.l.a -> void
        v0 = v2;
        // goto L_0017
        _result = v7.a(v1); // android.support.v4.widget.DrawerLayout.a -> void
        v7.o = v2; // android.support.v4.widget.DrawerLayout.o:boolean
        v7.p = v2; // android.support.v4.widget.DrawerLayout.p:boolean
        // goto L_0016
        v0 = v2;
        // goto L_0049
    }

    public boolean onKeyDown(int p0, android.view.KeyEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (android.view.KeyEvent)
        v0 = 4;
        if (v2 != v0) /* goto L_000e */;
        _result = v1.f(); // android.support.v4.widget.DrawerLayout.f -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000e */;
        _result = v3.b(); // android.support.v4.view.s.b -> void
        v0 = 1;
        return v0;
        _result = v1.onKeyDown(v2, v3); // android.view.ViewGroup.onKeyDown -> boolean
        v0 = _result;
        // goto L_000d
    }

    public boolean onKeyUp(int p0, android.view.KeyEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (android.view.KeyEvent)
        v0 = 4;
        if (v3 != v0) /* goto L_0018 */;
        _result = v2.g(); // android.support.v4.widget.DrawerLayout.g -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0012 */;
        _result = v2.a(v0); // android.support.v4.widget.DrawerLayout.a -> int
        v1 = _result;
        if (v1 != 0) /* goto L_0012 */;
        _result = v2.b(); // android.support.v4.widget.DrawerLayout.b -> void
        if (v0 == 0) /* goto L_0016 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0015
        _result = v2.onKeyUp(v3, v4); // android.view.ViewGroup.onKeyUp -> boolean
        v0 = _result;
        // goto L_0015
    }

    protected void onLayout(boolean p0, int p1, int p2, int p3, int p4) {
        // Registers (20 total): v14 = this, v15 = p0 (boolean), v16 = p1 (int), v17 = p2 (int), v18 = p3 (int), v19 = p4 (int)
        v0 = 1;
        v14.k = v0; // android.support.v4.widget.DrawerLayout.k:boolean
        v6 = binOp_0x91(v18, v16);
        _result = v14.getChildCount(); // android.support.v4.widget.DrawerLayout.getChildCount -> int
        v7 = _result;
        v0 = 0;
        v5 = v0;
        if (v5 >= v7) /* goto L_00cc */;
        _result = v14.getChildAt(v5); // android.support.v4.widget.DrawerLayout.getChildAt -> android.view.View
        v8 = _result;
        _result = v8.getVisibility(); // android.view.View.getVisibility -> int
        v0 = _result;
        v1 = 8;
        if (v0 != v1) /* goto L_001d */;
        v0 = binOpLit8_0xd8(v5, 1);
        v5 = v0;
        // goto L_000b
        _result = v8.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        _result = v14.f(v8); // android.support.v4.widget.DrawerLayout.f -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_003f */;
        v1 = v0.leftMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.leftMargin:int
        v2 = v0.topMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.topMargin:int
        v3 = v0.leftMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.leftMargin:int
        _result = v8.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v4 = _result;
        v3 = binOp2addr_0xb0(v3, v4);
        v0 = v0.topMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.topMargin:int
        _result = v8.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v4 = _result;
        v0 = binOp2addr_0xb0(v0, v4);
        _result = v8.layout(v1, v2, v3, v0); // android.view.View.layout -> void
        // goto L_0019
        _result = v8.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v9 = _result;
        _result = v8.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v10 = _result;
        v1 = 3;
        _result = v14.a(v8, v1); // android.support.v4.widget.DrawerLayout.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0088 */;
        v1 = unaryOp_0x7b(v9);
        v2 = unaryOp_0x82(v9);
        v3 = v0.b; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        v2 = binOp2addr_0xc8(v2, v3);
        v2 = unaryOp_0x87(v2);
        v2 = binOp2addr_0xb0(v2, v1);
        v1 = binOp_0x90(v9, v2);
        v1 = unaryOp_0x82(v1);
        v3 = unaryOp_0x82(v9);
        v1 = binOp2addr_0xc9(v1, v3);
        v3 = v0.b; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        v3 = cmp(v1, v3);
        if (v3 == 0) /* goto L_0095 */;
        v3 = 1;
        v4 = v0.a; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        v4 = binOpLit8_0xdd(v4, 112);
        // switch(v4)
        v4 = v0.topMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.topMargin:int
        v9 = binOp2addr_0xb0(v9, v2);
        v11 = v0.topMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.topMargin:int
        v10 = binOp2addr_0xb0(v10, v11);
        _result = v8.layout(v2, v4, v9, v10); // android.view.View.layout -> void
        if (v3 == 0) /* goto L_0076 */;
        _result = v14.b(v8, v1); // android.support.v4.widget.DrawerLayout.b -> void
        v0 = v0.b; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        v1 = 0;
        v0 = cmp(v0, v1);
        if (v0 <= 0) /* goto L_00ca */;
        v0 = 0;
        _result = v8.getVisibility(); // android.view.View.getVisibility -> int
        v1 = _result;
        if (v1 == v0) /* goto L_0019 */;
        _result = v8.setVisibility(v0); // android.view.View.setVisibility -> void
        // goto L_0019
        v1 = unaryOp_0x82(v9);
        v2 = v0.b; // android.support.v4.widget.DrawerLayout$LayoutParams.b:float
        v1 = binOp2addr_0xc8(v1, v2);
        v1 = unaryOp_0x87(v1);
        v2 = binOp_0x91(v6, v1);
        v1 = binOp_0x91(v6, v2);
        v1 = unaryOp_0x82(v1);
        v3 = unaryOp_0x82(v9);
        v1 = binOp2addr_0xc9(v1, v3);
        // goto L_005a
        v3 = 0;
        // goto L_0061
        v4 = binOp_0x91(v19, v17);
        v10 = v0.bottomMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.bottomMargin:int
        v10 = binOp_0x91(v4, v10);
        _result = v8.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v11 = _result;
        v10 = binOp2addr_0xb1(v10, v11);
        v9 = binOp2addr_0xb0(v9, v2);
        v11 = v0.bottomMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.bottomMargin:int
        v4 = binOp2addr_0xb1(v4, v11);
        _result = v8.layout(v2, v10, v9, v4); // android.view.View.layout -> void
        // goto L_0071
        v11 = binOp_0x91(v19, v17);
        v4 = binOp_0x91(v11, v10);
        v4 = binOpLit8_0xdb(v4, 2);
        v12 = v0.topMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.topMargin:int
        if (v4 >= v12) /* goto L_00bc */;
        v4 = v0.topMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.topMargin:int
        v9 = binOp2addr_0xb0(v9, v2);
        v10 = binOp2addr_0xb0(v10, v4);
        _result = v8.layout(v2, v4, v9, v10); // android.view.View.layout -> void
        // goto L_0071
        v12 = binOp_0x90(v4, v10);
        v13 = v0.bottomMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.bottomMargin:int
        v13 = binOp_0x91(v11, v13);
        if (v12 <= v13) /* goto L_00b6 */;
        v4 = v0.bottomMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.bottomMargin:int
        v4 = binOp_0x91(v11, v4);
        v4 = binOp2addr_0xb1(v4, v10);
        // goto L_00b6
        v0 = 4;
        // goto L_007e
        v0 = 0;
        v14.k = v0; // android.support.v4.widget.DrawerLayout.k:boolean
        v0 = 0;
        v14.l = v0; // android.support.v4.widget.DrawerLayout.l:boolean
        return;
    }

    protected void onMeasure(int p0, int p1) {
        // Registers (14 total): v11 = this, v12 = p0 (int), v13 = p1 (int)
        v1 = 300;
        v4 = 0;
        v7 = 0x80000000;
        v10 = 0x40000000;
        _result = v12.getMode(); // android.view.View$MeasureSpec.getMode -> int
        v3 = _result;
        _result = v13.getMode(); // android.view.View$MeasureSpec.getMode -> int
        v5 = _result;
        _result = v12.getSize(); // android.view.View$MeasureSpec.getSize -> int
        v2 = _result;
        _result = v13.getSize(); // android.view.View$MeasureSpec.getSize -> int
        v0 = _result;
        if (v3 != v10) /* goto L_001b */;
        if (v5 == v10) /* goto L_0046 */;
        _result = v11.isInEditMode(); // android.support.v4.widget.DrawerLayout.isInEditMode -> boolean
        v6 = _result;
        if (v6 == 0) /* goto L_0048 */;
        if (v3 != v7) /* goto L_0040 */;
        if (v5 != v7) /* goto L_0044 */;
        v1 = v0;
        _result = v11.setMeasuredDimension(v2, v1); // android.support.v4.widget.DrawerLayout.setMeasuredDimension -> void
        _result = v11.getChildCount(); // android.support.v4.widget.DrawerLayout.getChildCount -> int
        v5 = _result;
        v3 = v4;
        if (v3 >= v5) /* goto L_0113 */;
        _result = v11.getChildAt(v3); // android.support.v4.widget.DrawerLayout.getChildAt -> android.view.View
        v6 = _result;
        _result = v6.getVisibility(); // android.view.View.getVisibility -> int
        v0 = _result;
        v7 = 8;
        if (v0 != v7) /* goto L_0051 */;
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_002e
        if (v3 != 0) /* goto L_0023 */;
        v2 = v1;
        // goto L_0023
        if (v5 == 0) /* goto L_0026 */;
        v1 = v0;
        // goto L_0026
        v0 = new java.lang.IllegalArgumentException;
        v1 = "DrawerLayout must be measured with MeasureSpec.EXACTLY.";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = v6.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        _result = v11.f(v6); // android.support.v4.widget.DrawerLayout.f -> boolean
        v7 = _result;
        if (v7 == 0) /* goto L_0078 */;
        v7 = v0.leftMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.leftMargin:int
        v7 = binOp_0x91(v2, v7);
        v8 = v0.rightMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.rightMargin:int
        v7 = binOp2addr_0xb1(v7, v8);
        _result = v7.makeMeasureSpec(v10); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v7 = _result;
        v8 = v0.topMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.topMargin:int
        v8 = binOp_0x91(v1, v8);
        v0 = v0.bottomMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.bottomMargin:int
        v0 = binOp_0x91(v8, v0);
        _result = v0.makeMeasureSpec(v10); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        _result = v6.measure(v7, v0); // android.view.View.measure -> void
        // goto L_003c
        _result = v11.g(v6); // android.support.v4.widget.DrawerLayout.g -> boolean
        v7 = _result;
        if (v7 == 0) /* goto L_00e0 */;
        _result = v11.e(v6); // android.support.v4.widget.DrawerLayout.e -> int
        v7 = _result;
        v7 = binOpLit8_0xdd(v7, 7);
        v8 = binOp_0x95(v4, v7);
        if (v8 == 0) /* goto L_00c2 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Child drawer has absolute gravity ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v7.b(); // android.support.v4.widget.DrawerLayout.b -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " but this ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "DrawerLayout";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " already has a ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "drawer view along that edge";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v7 = v11.b; // android.support.v4.widget.DrawerLayout.b:int
        v8 = v0.leftMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.leftMargin:int
        v7 = binOp2addr_0xb0(v7, v8);
        v8 = v0.rightMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.rightMargin:int
        v7 = binOp2addr_0xb0(v7, v8);
        v8 = v0.width; // android.support.v4.widget.DrawerLayout$LayoutParams.width:int
        _result = v12.getChildMeasureSpec(v7, v8); // android.support.v4.widget.DrawerLayout.getChildMeasureSpec -> int
        v7 = _result;
        v8 = v0.topMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.topMargin:int
        v9 = v0.bottomMargin; // android.support.v4.widget.DrawerLayout$LayoutParams.bottomMargin:int
        v8 = binOp2addr_0xb0(v8, v9);
        v0 = v0.height; // android.support.v4.widget.DrawerLayout$LayoutParams.height:int
        _result = v13.getChildMeasureSpec(v8, v0); // android.support.v4.widget.DrawerLayout.getChildMeasureSpec -> int
        v0 = _result;
        _result = v6.measure(v7, v0); // android.view.View.measure -> void
        // goto L_003c
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Child ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " at index ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " does not have a valid layout_gravity - must be Gravity.LEFT, ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "Gravity.RIGHT or Gravity.NO_GRAVITY";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        return;
    }

    protected void onRestoreInstanceState(android.os.Parcelable p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Parcelable)
        v3 = (android.support.v4.widget.DrawerLayout$SavedState) v3;
        _result = v3.getSuperState(); // android.support.v4.widget.DrawerLayout$SavedState.getSuperState -> android.os.Parcelable
        v0 = _result;
        _result = v2.onRestoreInstanceState(v0); // android.view.ViewGroup.onRestoreInstanceState -> void
        v0 = v3.openDrawerGravity; // android.support.v4.widget.DrawerLayout$SavedState.openDrawerGravity:int
        if (v0 == 0) /* goto L_0018 */;
        v0 = v3.openDrawerGravity; // android.support.v4.widget.DrawerLayout$SavedState.openDrawerGravity:int
        _result = v2.a(v0); // android.support.v4.widget.DrawerLayout.a -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0018 */;
        _result = v2.h(v0); // android.support.v4.widget.DrawerLayout.h -> void
        v0 = v3.lockModeLeft; // android.support.v4.widget.DrawerLayout$SavedState.lockModeLeft:int
        v1 = 3;
        _result = v2.setDrawerLockMode(v0, v1); // android.support.v4.widget.DrawerLayout.setDrawerLockMode -> void
        v0 = v3.lockModeRight; // android.support.v4.widget.DrawerLayout$SavedState.lockModeRight:int
        v1 = 5;
        _result = v2.setDrawerLockMode(v0, v1); // android.support.v4.widget.DrawerLayout.setDrawerLockMode -> void
        return;
    }

    protected android.os.Parcelable onSaveInstanceState() {
        // Registers (6 total): v5 = this
        _result = v5.onSaveInstanceState(); // android.view.ViewGroup.onSaveInstanceState -> android.os.Parcelable
        v0 = _result;
        v2 = new android.support.v4.widget.DrawerLayout$SavedState;
        _result = v2.<init>(v0); // android.support.v4.widget.DrawerLayout$SavedState.<init> -> void
        _result = v5.getChildCount(); // android.support.v4.widget.DrawerLayout.getChildCount -> int
        v3 = _result;
        v0 = 0;
        v1 = v0;
        if (v1 >= v3) /* goto L_002d */;
        _result = v5.getChildAt(v1); // android.support.v4.widget.DrawerLayout.getChildAt -> android.view.View
        v0 = _result;
        _result = v5.g(v0); // android.support.v4.widget.DrawerLayout.g -> boolean
        v4 = _result;
        if (v4 != 0) /* goto L_001f */;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_000f
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v4 = v0.d; // android.support.v4.widget.DrawerLayout$LayoutParams.d:boolean
        if (v4 == 0) /* goto L_001b */;
        v0 = v0.a; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        v2.openDrawerGravity = v0; // android.support.v4.widget.DrawerLayout$SavedState.openDrawerGravity:int
        v0 = v5.m; // android.support.v4.widget.DrawerLayout.m:int
        v2.lockModeLeft = v0; // android.support.v4.widget.DrawerLayout$SavedState.lockModeLeft:int
        v0 = v5.n; // android.support.v4.widget.DrawerLayout.n:int
        v2.lockModeRight = v0; // android.support.v4.widget.DrawerLayout$SavedState.lockModeRight:int
        return v2;
    }

    public boolean onTouchEvent(android.view.MotionEvent p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.view.MotionEvent)
        v1 = 1;
        v2 = 0;
        v0 = v7.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        _result = v0.b(v8); // android.support.v4.widget.am.b -> void
        v0 = v7.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        _result = v0.b(v8); // android.support.v4.widget.am.b -> void
        _result = v8.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        v0 = binOpLit16_0xd5(v0, 255);
        // switch(v0)
        return v1;
        _result = v8.getX(); // android.view.MotionEvent.getX -> float
        v0 = _result;
        _result = v8.getY(); // android.view.MotionEvent.getY -> float
        v3 = _result;
        v7.r = v0; // android.support.v4.widget.DrawerLayout.r:float
        v7.s = v3; // android.support.v4.widget.DrawerLayout.s:float
        v7.o = v2; // android.support.v4.widget.DrawerLayout.o:boolean
        v7.p = v2; // android.support.v4.widget.DrawerLayout.p:boolean
        // goto L_0015
        _result = v8.getX(); // android.view.MotionEvent.getX -> float
        v0 = _result;
        _result = v8.getY(); // android.view.MotionEvent.getY -> float
        v3 = _result;
        v4 = v7.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        v5 = unaryOp_0x87(v0);
        v6 = unaryOp_0x87(v3);
        _result = v4.d(v5, v6); // android.support.v4.widget.am.d -> android.view.View
        v4 = _result;
        if (v4 == 0) /* goto L_0073 */;
        _result = v7.f(v4); // android.support.v4.widget.DrawerLayout.f -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_0073 */;
        v4 = v7.r; // android.support.v4.widget.DrawerLayout.r:float
        v0 = binOp2addr_0xc7(v0, v4);
        v4 = v7.s; // android.support.v4.widget.DrawerLayout.s:float
        v3 = binOp2addr_0xc7(v3, v4);
        v4 = v7.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        _result = v4.d(); // android.support.v4.widget.am.d -> int
        v4 = _result;
        v0 = binOp2addr_0xc8(v0, v0);
        v3 = binOp2addr_0xc8(v3, v3);
        v0 = binOp2addr_0xc6(v0, v3);
        v3 = binOp_0x92(v4, v4);
        v3 = unaryOp_0x82(v3);
        v0 = cmp(v0, v3);
        if (v0 >= 0) /* goto L_0073 */;
        _result = v7.a(); // android.support.v4.widget.DrawerLayout.a -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0073 */;
        _result = v7.a(v0); // android.support.v4.widget.DrawerLayout.a -> int
        v0 = _result;
        v3 = 2;
        if (v0 != v3) /* goto L_0069 */;
        v0 = v1;
        _result = v7.a(v0); // android.support.v4.widget.DrawerLayout.a -> void
        v7.o = v2; // android.support.v4.widget.DrawerLayout.o:boolean
        // goto L_0015
        v0 = v2;
        // goto L_0063
        _result = v7.a(v1); // android.support.v4.widget.DrawerLayout.a -> void
        v7.o = v2; // android.support.v4.widget.DrawerLayout.o:boolean
        v7.p = v2; // android.support.v4.widget.DrawerLayout.p:boolean
        // goto L_0015
        v0 = v1;
        // goto L_0063
    }

    public void requestDisallowInterceptTouchEvent(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        _result = v1.requestDisallowInterceptTouchEvent(v2); // android.view.ViewGroup.requestDisallowInterceptTouchEvent -> void
        v1.o = v2; // android.support.v4.widget.DrawerLayout.o:boolean
        if (v2 == 0) /* goto L_000b */;
        v0 = 1;
        _result = v1.a(v0); // android.support.v4.widget.DrawerLayout.a -> void
        return;
    }

    public void requestLayout() {
        // Registers (2 total): v1 = this
        v0 = v1.k; // android.support.v4.widget.DrawerLayout.k:boolean
        if (v0 != 0) /* goto L_0007 */;
        _result = v1.requestLayout(); // android.view.ViewGroup.requestLayout -> void
        return;
    }

    public void setDrawerListener(android.support.v4.widget.j p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.j)
        v0.q = v1; // android.support.v4.widget.DrawerLayout.q:android.support.v4.widget.j
        return;
    }

    public void setDrawerLockMode(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 3;
        _result = v1.setDrawerLockMode(v2, v0); // android.support.v4.widget.DrawerLayout.setDrawerLockMode -> void
        v0 = 5;
        _result = v1.setDrawerLockMode(v2, v0); // android.support.v4.widget.DrawerLayout.setDrawerLockMode -> void
        return;
    }

    public void setDrawerLockMode(int p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (int)
        v2 = 3;
        _result = v3.e(); // android.support.v4.view.at.e -> int
        v0 = _result;
        _result = v5.a(v0); // android.support.v4.view.n.a -> int
        v1 = _result;
        if (v1 != v2) /* goto L_001a */;
        v3.m = v4; // android.support.v4.widget.DrawerLayout.m:int
        if (v4 == 0) /* goto L_0016 */;
        if (v1 != v2) /* goto L_0020 */;
        v0 = v3.f; // android.support.v4.widget.DrawerLayout.f:android.support.v4.widget.am
        _result = v0.e(); // android.support.v4.widget.am.e -> void
        // switch(v4)
        return;
        v0 = 5;
        if (v1 != v0) /* goto L_000d */;
        v3.n = v4; // android.support.v4.widget.DrawerLayout.n:int
        // goto L_000d
        v0 = v3.g; // android.support.v4.widget.DrawerLayout.g:android.support.v4.widget.am
        // goto L_0013
        _result = v3.a(v1); // android.support.v4.widget.DrawerLayout.a -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0019 */;
        _result = v3.h(v0); // android.support.v4.widget.DrawerLayout.h -> void
        // goto L_0019
        _result = v3.a(v1); // android.support.v4.widget.DrawerLayout.a -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0019 */;
        _result = v3.i(v0); // android.support.v4.widget.DrawerLayout.i -> void
        // goto L_0019
    }

    public void setDrawerLockMode(int p0, android.view.View p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (android.view.View)
        _result = v3.g(v5); // android.support.v4.widget.DrawerLayout.g -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_002e */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "View ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " is not a ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "drawer with appropriate layout_gravity";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = v5.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v0 = v0.a; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        _result = v3.setDrawerLockMode(v4, v0); // android.support.v4.widget.DrawerLayout.setDrawerLockMode -> void
        return;
    }

    public void setDrawerShadow(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        _result = v1.getResources(); // android.support.v4.widget.DrawerLayout.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDrawable(v2); // android.content.res.Resources.getDrawable -> android.graphics.drawable.Drawable
        v0 = _result;
        _result = v1.setDrawerShadow(v0, v3); // android.support.v4.widget.DrawerLayout.setDrawerShadow -> void
        return;
    }

    public void setDrawerShadow(android.graphics.drawable.Drawable p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.graphics.drawable.Drawable), v5 = p1 (int)
        _result = v3.e(); // android.support.v4.view.at.e -> int
        v0 = _result;
        _result = v5.a(v0); // android.support.v4.view.n.a -> int
        v0 = _result;
        v1 = binOpLit8_0xdd(v0, 3);
        v2 = 3;
        if (v1 != v2) /* goto L_0012 */;
        v3.t = v4; // android.support.v4.widget.DrawerLayout.t:android.graphics.drawable.Drawable
        _result = v3.invalidate(); // android.support.v4.widget.DrawerLayout.invalidate -> void
        v0 = binOpLit8_0xdd(v0, 5);
        v1 = 5;
        if (v0 != v1) /* goto L_001c */;
        v3.u = v4; // android.support.v4.widget.DrawerLayout.u:android.graphics.drawable.Drawable
        _result = v3.invalidate(); // android.support.v4.widget.DrawerLayout.invalidate -> void
        return;
    }

    public void setScrimColor(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.c = v1; // android.support.v4.widget.DrawerLayout.c:int
        _result = v0.invalidate(); // android.support.v4.widget.DrawerLayout.invalidate -> void
        return;
    }

}