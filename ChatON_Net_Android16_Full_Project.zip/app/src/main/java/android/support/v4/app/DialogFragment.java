package android.support.v4.app;

/**
 * Original SourceFile: DialogFragment.java
 * Descriptor: Landroid/support/v4/app/DialogFragment;
 */
public class DialogFragment extends android.support.v4.app.Fragment implements android.content.DialogInterface$OnCancelListener, android.content.DialogInterface$OnDismissListener {
     int a;
     int b;
     boolean c;
     boolean d;
     int e;
     android.app.Dialog f;
     boolean g;
     boolean h;
     boolean i;

    public DialogFragment() {
        // Registers (3 total): v2 = this
        v1 = 1;
        v0 = 0;
        _result = v2.<init>(); // android.support.v4.app.Fragment.<init> -> void
        v2.a = v0; // android.support.v4.app.DialogFragment.a:int
        v2.b = v0; // android.support.v4.app.DialogFragment.b:int
        v2.c = v1; // android.support.v4.app.DialogFragment.c:boolean
        v2.d = v1; // android.support.v4.app.DialogFragment.d:boolean
        v0 = -1;
        v2.e = v0; // android.support.v4.app.DialogFragment.e:int
        return;
    }

    public int a(android.support.v4.app.aj p0, java.lang.String p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.support.v4.app.aj), v4 = p1 (java.lang.String)
        v1 = 0;
        v2.h = v1; // android.support.v4.app.DialogFragment.h:boolean
        v0 = 1;
        v2.i = v0; // android.support.v4.app.DialogFragment.i:boolean
        _result = v3.a(v2, v4); // android.support.v4.app.aj.a -> android.support.v4.app.aj
        v2.g = v1; // android.support.v4.app.DialogFragment.g:boolean
        _result = v3.b(); // android.support.v4.app.aj.b -> int
        v0 = _result;
        v2.e = v0; // android.support.v4.app.DialogFragment.e:int
        v0 = v2.e; // android.support.v4.app.DialogFragment.e:int
        return v0;
    }

    public android.app.Dialog a(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v0 = new android.app.Dialog;
        _result = v3.getActivity(); // android.support.v4.app.DialogFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v3.c(); // android.support.v4.app.DialogFragment.c -> int
        v2 = _result;
        _result = v0.<init>(v1, v2); // android.app.Dialog.<init> -> void
        return v0;
    }

    public void a() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.a(v0); // android.support.v4.app.DialogFragment.a -> void
        return;
    }

    public void a(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v2.a = v3; // android.support.v4.app.DialogFragment.a:int
        v0 = v2.a; // android.support.v4.app.DialogFragment.a:int
        v1 = 2;
        if (v0 == v1) /* goto L_000c */;
        v0 = v2.a; // android.support.v4.app.DialogFragment.a:int
        v1 = 3;
        if (v0 != v1) /* goto L_0011 */;
        v0 = 16973913; // 0x01030059
        v2.b = v0; // android.support.v4.app.DialogFragment.b:int
        if (v4 == 0) /* goto L_0015 */;
        v2.b = v4; // android.support.v4.app.DialogFragment.b:int
        return;
    }

    public void a(android.support.v4.app.w p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.support.v4.app.w), v3 = p1 (java.lang.String)
        v0 = 0;
        v1.h = v0; // android.support.v4.app.DialogFragment.h:boolean
        v0 = 1;
        v1.i = v0; // android.support.v4.app.DialogFragment.i:boolean
        _result = v2.a(); // android.support.v4.app.w.a -> android.support.v4.app.aj
        v0 = _result;
        _result = v0.a(v1, v3); // android.support.v4.app.aj.a -> android.support.v4.app.aj
        _result = v0.b(); // android.support.v4.app.aj.b -> int
        return;
    }

    void a(boolean p0) {
        // Registers (5 total): v3 = this, v4 = p0 (boolean)
        v2 = 1;
        v0 = v3.h; // android.support.v4.app.DialogFragment.h:boolean
        if (v0 == 0) /* goto L_0006 */;
        return;
        v3.h = v2; // android.support.v4.app.DialogFragment.h:boolean
        v0 = 0;
        v3.i = v0; // android.support.v4.app.DialogFragment.i:boolean
        v0 = v3.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        if (v0 == 0) /* goto L_0017 */;
        v0 = v3.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v0.dismiss(); // android.app.Dialog.dismiss -> void
        v0 = 0;
        v3.f = v0; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        v3.g = v2; // android.support.v4.app.DialogFragment.g:boolean
        v0 = v3.e; // android.support.v4.app.DialogFragment.e:int
        if (v0 < 0) /* goto L_002a */;
        _result = v3.getFragmentManager(); // android.support.v4.app.DialogFragment.getFragmentManager -> android.support.v4.app.w
        v0 = _result;
        v1 = v3.e; // android.support.v4.app.DialogFragment.e:int
        _result = v0.a(v1, v2); // android.support.v4.app.w.a -> void
        v0 = -1;
        v3.e = v0; // android.support.v4.app.DialogFragment.e:int
        // goto L_0005
        _result = v3.getFragmentManager(); // android.support.v4.app.DialogFragment.getFragmentManager -> android.support.v4.app.w
        v0 = _result;
        _result = v0.a(); // android.support.v4.app.w.a -> android.support.v4.app.aj
        v0 = _result;
        _result = v0.a(v3); // android.support.v4.app.aj.a -> android.support.v4.app.aj
        if (v4 == 0) /* goto L_003b */;
        _result = v0.c(); // android.support.v4.app.aj.c -> int
        // goto L_0005
        _result = v0.b(); // android.support.v4.app.aj.b -> int
        // goto L_0005
    }

    public android.app.Dialog b() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        return v0;
    }

    public int c() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.app.DialogFragment.b:int
        return v0;
    }

    public android.view.LayoutInflater getLayoutInflater(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        v0 = v2.d; // android.support.v4.app.DialogFragment.d:boolean
        if (v0 != 0) /* goto L_0009 */;
        _result = v2.getLayoutInflater(v3); // android.support.v4.app.Fragment.getLayoutInflater -> android.view.LayoutInflater
        v0 = _result;
        return v0;
        _result = v2.a(v3); // android.support.v4.app.DialogFragment.a -> android.app.Dialog
        v0 = _result;
        v2.f = v0; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        v0 = v2.a; // android.support.v4.app.DialogFragment.a:int
        // switch(v0)
        v0 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        if (v0 == 0) /* goto L_003a */;
        v0 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v0.getContext(); // android.app.Dialog.getContext -> android.content.Context
        v0 = _result;
        v1 = "layout_inflater";
        _result = v0.getSystemService(v1); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        // goto L_0008
        v0 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v0.getWindow(); // android.app.Dialog.getWindow -> android.view.Window
        v0 = _result;
        v1 = 24;
        _result = v0.addFlags(v1); // android.view.Window.addFlags -> void
        v0 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        v1 = 1;
        _result = v0.requestWindowFeature(v1); // android.app.Dialog.requestWindowFeature -> boolean
        // goto L_0014
        v0 = v2.mActivity; // android.support.v4.app.DialogFragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = "layout_inflater";
        _result = v0.getSystemService(v1); // android.support.v4.app.FragmentActivity.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        // goto L_0008
    }

    public void onActivityCreated(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onActivityCreated(v3); // android.support.v4.app.Fragment.onActivityCreated -> void
        v0 = v2.d; // android.support.v4.app.DialogFragment.d:boolean
        if (v0 != 0) /* goto L_0008 */;
        return;
        _result = v2.getView(); // android.support.v4.app.DialogFragment.getView -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0022 */;
        _result = v0.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v1 = _result;
        if (v1 == 0) /* goto L_001d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "DialogFragment can not be attached to a container view";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v1 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v1.setContentView(v0); // android.app.Dialog.setContentView -> void
        v0 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v2.getActivity(); // android.support.v4.app.DialogFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v0.setOwnerActivity(v1); // android.app.Dialog.setOwnerActivity -> void
        v0 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        v1 = v2.c; // android.support.v4.app.DialogFragment.c:boolean
        _result = v0.setCancelable(v1); // android.app.Dialog.setCancelable -> void
        v0 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v0.setOnCancelListener(v2); // android.app.Dialog.setOnCancelListener -> void
        v0 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v0.setOnDismissListener(v2); // android.app.Dialog.setOnDismissListener -> void
        if (v3 == 0) /* goto L_0007 */;
        v0 = "android:savedDialogState";
        _result = v3.getBundle(v0); // android.os.Bundle.getBundle -> android.os.Bundle
        v0 = _result;
        if (v0 == 0) /* goto L_0007 */;
        v1 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v1.onRestoreInstanceState(v0); // android.app.Dialog.onRestoreInstanceState -> void
        // goto L_0007
    }

    public void onAttach(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        _result = v1.onAttach(v2); // android.support.v4.app.Fragment.onAttach -> void
        v0 = v1.i; // android.support.v4.app.DialogFragment.i:boolean
        if (v0 != 0) /* goto L_000a */;
        v0 = 0;
        v1.h = v0; // android.support.v4.app.DialogFragment.h:boolean
        return;
    }

    public void onCancel(android.content.DialogInterface p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.content.DialogInterface)
        return;
    }

    public void onCreate(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v1 = 1;
        v2 = 0;
        _result = v3.onCreate(v4); // android.support.v4.app.Fragment.onCreate -> void
        v0 = v3.mContainerId; // android.support.v4.app.DialogFragment.mContainerId:int
        if (v0 != 0) /* goto L_003f */;
        v0 = v1;
        v3.d = v0; // android.support.v4.app.DialogFragment.d:boolean
        if (v4 == 0) /* goto L_003e */;
        v0 = "android:style";
        _result = v4.getInt(v0, v2); // android.os.Bundle.getInt -> int
        v0 = _result;
        v3.a = v0; // android.support.v4.app.DialogFragment.a:int
        v0 = "android:theme";
        _result = v4.getInt(v0, v2); // android.os.Bundle.getInt -> int
        v0 = _result;
        v3.b = v0; // android.support.v4.app.DialogFragment.b:int
        v0 = "android:cancelable";
        _result = v4.getBoolean(v0, v1); // android.os.Bundle.getBoolean -> boolean
        v0 = _result;
        v3.c = v0; // android.support.v4.app.DialogFragment.c:boolean
        v0 = "android:showsDialog";
        v1 = v3.d; // android.support.v4.app.DialogFragment.d:boolean
        _result = v4.getBoolean(v0, v1); // android.os.Bundle.getBoolean -> boolean
        v0 = _result;
        v3.d = v0; // android.support.v4.app.DialogFragment.d:boolean
        v0 = "android:backStackId";
        v1 = -1;
        _result = v4.getInt(v0, v1); // android.os.Bundle.getInt -> int
        v0 = _result;
        v3.e = v0; // android.support.v4.app.DialogFragment.e:int
        return;
        v0 = v2;
        // goto L_000a
    }

    public void onDestroyView() {
        // Registers (2 total): v1 = this
        _result = v1.onDestroyView(); // android.support.v4.app.Fragment.onDestroyView -> void
        v0 = v1.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        if (v0 == 0) /* goto L_0012 */;
        v0 = 1;
        v1.g = v0; // android.support.v4.app.DialogFragment.g:boolean
        v0 = v1.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v0.dismiss(); // android.app.Dialog.dismiss -> void
        v0 = 0;
        v1.f = v0; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        return;
    }

    public void onDetach() {
        // Registers (2 total): v1 = this
        _result = v1.onDetach(); // android.support.v4.app.Fragment.onDetach -> void
        v0 = v1.i; // android.support.v4.app.DialogFragment.i:boolean
        if (v0 != 0) /* goto L_000e */;
        v0 = v1.h; // android.support.v4.app.DialogFragment.h:boolean
        if (v0 != 0) /* goto L_000e */;
        v0 = 1;
        v1.h = v0; // android.support.v4.app.DialogFragment.h:boolean
        return;
    }

    public void onDismiss(android.content.DialogInterface p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.DialogInterface)
        v0 = v1.g; // android.support.v4.app.DialogFragment.g:boolean
        if (v0 != 0) /* goto L_0008 */;
        v0 = 1;
        _result = v1.a(v0); // android.support.v4.app.DialogFragment.a -> void
        return;
    }

    public void onSaveInstanceState(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onSaveInstanceState(v3); // android.support.v4.app.Fragment.onSaveInstanceState -> void
        v0 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        if (v0 == 0) /* goto L_0015 */;
        v0 = v2.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v0.onSaveInstanceState(); // android.app.Dialog.onSaveInstanceState -> android.os.Bundle
        v0 = _result;
        if (v0 == 0) /* goto L_0015 */;
        v1 = "android:savedDialogState";
        _result = v3.putBundle(v1, v0); // android.os.Bundle.putBundle -> void
        v0 = v2.a; // android.support.v4.app.DialogFragment.a:int
        if (v0 == 0) /* goto L_0021 */;
        v0 = "android:style";
        v1 = v2.a; // android.support.v4.app.DialogFragment.a:int
        _result = v3.putInt(v0, v1); // android.os.Bundle.putInt -> void
        v0 = v2.b; // android.support.v4.app.DialogFragment.b:int
        if (v0 == 0) /* goto L_002d */;
        v0 = "android:theme";
        v1 = v2.b; // android.support.v4.app.DialogFragment.b:int
        _result = v3.putInt(v0, v1); // android.os.Bundle.putInt -> void
        v0 = v2.c; // android.support.v4.app.DialogFragment.c:boolean
        if (v0 != 0) /* goto L_0039 */;
        v0 = "android:cancelable";
        v1 = v2.c; // android.support.v4.app.DialogFragment.c:boolean
        _result = v3.putBoolean(v0, v1); // android.os.Bundle.putBoolean -> void
        v0 = v2.d; // android.support.v4.app.DialogFragment.d:boolean
        if (v0 != 0) /* goto L_0045 */;
        v0 = "android:showsDialog";
        v1 = v2.d; // android.support.v4.app.DialogFragment.d:boolean
        _result = v3.putBoolean(v0, v1); // android.os.Bundle.putBoolean -> void
        v0 = v2.e; // android.support.v4.app.DialogFragment.e:int
        v1 = -1;
        if (v0 == v1) /* goto L_0052 */;
        v0 = "android:backStackId";
        v1 = v2.e; // android.support.v4.app.DialogFragment.e:int
        _result = v3.putInt(v0, v1); // android.os.Bundle.putInt -> void
        return;
    }

    public void onStart() {
        // Registers (2 total): v1 = this
        _result = v1.onStart(); // android.support.v4.app.Fragment.onStart -> void
        v0 = v1.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        if (v0 == 0) /* goto L_000f */;
        v0 = 0;
        v1.g = v0; // android.support.v4.app.DialogFragment.g:boolean
        v0 = v1.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v0.show(); // android.app.Dialog.show -> void
        return;
    }

    public void onStop() {
        // Registers (2 total): v1 = this
        _result = v1.onStop(); // android.support.v4.app.Fragment.onStop -> void
        v0 = v1.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        if (v0 == 0) /* goto L_000c */;
        v0 = v1.f; // android.support.v4.app.DialogFragment.f:android.app.Dialog
        _result = v0.hide(); // android.app.Dialog.hide -> void
        return;
    }

}