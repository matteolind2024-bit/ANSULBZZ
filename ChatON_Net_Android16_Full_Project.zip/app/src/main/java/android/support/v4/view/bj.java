package android.support.v4.view;

/**
 * Original SourceFile: ViewConfigurationCompat.java
 * Descriptor: Landroid/support/v4/view/bj;
 */
public class bj {
    static final android.support.v4.view.bm a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.bl;
        _result = v0.<init>(); // android.support.v4.view.bl.<init> -> void
        android.support.v4.view.bj.a = v0; // :android.support.v4.view.bm
        return;
        v0 = new android.support.v4.view.bk;
        _result = v0.<init>(); // android.support.v4.view.bk.<init> -> void
        android.support.v4.view.bj.a = v0; // :android.support.v4.view.bm
        // goto L_000d
    }

    public static int a(android.view.ViewConfiguration p0) {
        // Registers (2 total): v1 = p0 (android.view.ViewConfiguration)
        v0 = android.support.v4.view.bj.a; // :android.support.v4.view.bm
        _result = android.support.v4.view.bm.a(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

}