package android.support.v4.widget;

/**
 * Original SourceFile: CursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/c;
 */
public abstract class c extends android.widget.BaseAdapter implements android.support.v4.widget.h, android.widget.Filterable {
    protected boolean a;
    protected boolean b;
    protected android.database.Cursor c;
    protected android.content.Context d;
    protected int e;
    protected android.support.v4.widget.e f;
    protected android.database.DataSetObserver g;
    protected android.support.v4.widget.g h;
    protected android.widget.FilterQueryProvider i;

    public c(android.content.Context p0, android.database.Cursor p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.database.Cursor)
        _result = v1.<init>(); // android.widget.BaseAdapter.<init> -> void
        v0 = 1;
        _result = v1.a(v2, v3, v0); // android.support.v4.widget.c.a -> void
        return;
    }

    public c(android.content.Context p0, android.database.Cursor p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.content.Context), v2 = p1 (android.database.Cursor), v3 = p2 (int)
        _result = v0.<init>(); // android.widget.BaseAdapter.<init> -> void
        _result = v0.a(v1, v2, v3); // android.support.v4.widget.c.a -> void
        return;
    }

    public c(android.content.Context p0, android.database.Cursor p1, boolean p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.database.Cursor), v4 = p2 (boolean)
        _result = v1.<init>(); // android.widget.BaseAdapter.<init> -> void
        if (v4 == 0) /* goto L_000a */;
        v0 = 1;
        _result = v1.a(v2, v3, v0); // android.support.v4.widget.c.a -> void
        return;
        v0 = 2;
        // goto L_0006
    }

    public android.database.Cursor a() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // android.support.v4.widget.c.c:android.database.Cursor
        return v0;
    }

    public android.database.Cursor a(java.lang.CharSequence p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.CharSequence)
        v0 = v1.i; // android.support.v4.widget.c.i:android.widget.FilterQueryProvider
        if (v0 == 0) /* goto L_000b */;
        v0 = v1.i; // android.support.v4.widget.c.i:android.widget.FilterQueryProvider
        _result = android.widget.FilterQueryProvider.runQuery(v0, v2); // -> android.database.Cursor
        v0 = _result;
        return v0;
        v0 = v1.c; // android.support.v4.widget.c.c:android.database.Cursor
        // goto L_000a
    }

    public abstract android.view.View a(android.content.Context p0, android.database.Cursor p1, android.view.ViewGroup p2);
    void a(android.content.Context p0, android.database.Cursor p1, int p2) {
        // Registers (8 total): v4 = this, v5 = p0 (android.content.Context), v6 = p1 (android.database.Cursor), v7 = p2 (int)
        v1 = 0;
        v3 = 0;
        v0 = 1;
        v2 = binOpLit8_0xdd(v7, 1);
        if (v2 != v0) /* goto L_0046 */;
        v7 = binOpLit8_0xde(v7, 2);
        v4.b = v0; // android.support.v4.widget.c.b:boolean
        if (v6 == 0) /* goto L_0049 */;
        v4.c = v6; // android.support.v4.widget.c.c:android.database.Cursor
        v4.a = v0; // android.support.v4.widget.c.a:boolean
        v4.d = v5; // android.support.v4.widget.c.d:android.content.Context
        if (v0 == 0) /* goto L_004b */;
        v1 = "_id";
        _result = android.database.Cursor.getColumnIndexOrThrow(v6, v1); // -> int
        v1 = _result;
        v4.e = v1; // android.support.v4.widget.c.e:int
        v1 = binOpLit8_0xdd(v7, 2);
        v2 = 2;
        if (v1 != v2) /* goto L_004d */;
        v1 = new android.support.v4.widget.e;
        _result = v1.<init>(v4); // android.support.v4.widget.e.<init> -> void
        v4.f = v1; // android.support.v4.widget.c.f:android.support.v4.widget.e
        v1 = new android.support.v4.widget.f;
        _result = v1.<init>(v4, v3); // android.support.v4.widget.f.<init> -> void
        v4.g = v1; // android.support.v4.widget.c.g:android.database.DataSetObserver
        if (v0 == 0) /* goto L_0045 */;
        v0 = v4.f; // android.support.v4.widget.c.f:android.support.v4.widget.e
        if (v0 == 0) /* goto L_003c */;
        v0 = v4.f; // android.support.v4.widget.c.f:android.support.v4.widget.e
        _result = android.database.Cursor.registerContentObserver(v6, v0); // -> void
        v0 = v4.g; // android.support.v4.widget.c.g:android.database.DataSetObserver
        if (v0 == 0) /* goto L_0045 */;
        v0 = v4.g; // android.support.v4.widget.c.g:android.database.DataSetObserver
        _result = android.database.Cursor.registerDataSetObserver(v6, v0); // -> void
        return;
        v4.b = v1; // android.support.v4.widget.c.b:boolean
        // goto L_000b
        v0 = v1;
        // goto L_000d
        v1 = -1;
        // goto L_001c
        v4.f = v3; // android.support.v4.widget.c.f:android.support.v4.widget.e
        v4.g = v3; // android.support.v4.widget.c.g:android.database.DataSetObserver
        // goto L_0031
    }

    public void a(android.database.Cursor p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.database.Cursor)
        _result = v1.b(v2); // android.support.v4.widget.c.b -> android.database.Cursor
        v0 = _result;
        if (v0 == 0) /* goto L_0009 */;
        _result = android.database.Cursor.close(v0); // -> void
        return;
    }

    public abstract void a(android.view.View p0, android.content.Context p1, android.database.Cursor p2);
    public android.database.Cursor b(android.database.Cursor p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.database.Cursor)
        v0 = v2.c; // android.support.v4.widget.c.c:android.database.Cursor
        if (v3 != v0) /* goto L_0006 */;
        v0 = 0;
        return v0;
        v0 = v2.c; // android.support.v4.widget.c.c:android.database.Cursor
        if (v0 == 0) /* goto L_001c */;
        v1 = v2.f; // android.support.v4.widget.c.f:android.support.v4.widget.e
        if (v1 == 0) /* goto L_0013 */;
        v1 = v2.f; // android.support.v4.widget.c.f:android.support.v4.widget.e
        _result = android.database.Cursor.unregisterContentObserver(v0, v1); // -> void
        v1 = v2.g; // android.support.v4.widget.c.g:android.database.DataSetObserver
        if (v1 == 0) /* goto L_001c */;
        v1 = v2.g; // android.support.v4.widget.c.g:android.database.DataSetObserver
        _result = android.database.Cursor.unregisterDataSetObserver(v0, v1); // -> void
        v2.c = v3; // android.support.v4.widget.c.c:android.database.Cursor
        if (v3 == 0) /* goto L_0042 */;
        v1 = v2.f; // android.support.v4.widget.c.f:android.support.v4.widget.e
        if (v1 == 0) /* goto L_0029 */;
        v1 = v2.f; // android.support.v4.widget.c.f:android.support.v4.widget.e
        _result = android.database.Cursor.registerContentObserver(v3, v1); // -> void
        v1 = v2.g; // android.support.v4.widget.c.g:android.database.DataSetObserver
        if (v1 == 0) /* goto L_0032 */;
        v1 = v2.g; // android.support.v4.widget.c.g:android.database.DataSetObserver
        _result = android.database.Cursor.registerDataSetObserver(v3, v1); // -> void
        v1 = "_id";
        _result = android.database.Cursor.getColumnIndexOrThrow(v3, v1); // -> int
        v1 = _result;
        v2.e = v1; // android.support.v4.widget.c.e:int
        v1 = 1;
        v2.a = v1; // android.support.v4.widget.c.a:boolean
        _result = v2.notifyDataSetChanged(); // android.support.v4.widget.c.notifyDataSetChanged -> void
        // goto L_0005
        v1 = -1;
        v2.e = v1; // android.support.v4.widget.c.e:int
        v1 = 0;
        v2.a = v1; // android.support.v4.widget.c.a:boolean
        _result = v2.notifyDataSetInvalidated(); // android.support.v4.widget.c.notifyDataSetInvalidated -> void
        // goto L_0005
    }

    public android.view.View b(android.content.Context p0, android.database.Cursor p1, android.view.ViewGroup p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.database.Cursor), v4 = p2 (android.view.ViewGroup)
        _result = v1.a(v2, v3, v4); // android.support.v4.widget.c.a -> android.view.View
        v0 = _result;
        return v0;
    }

    protected void b() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.widget.c.b:boolean
        if (v0 == 0) /* goto L_0018 */;
        v0 = v1.c; // android.support.v4.widget.c.c:android.database.Cursor
        if (v0 == 0) /* goto L_0018 */;
        v0 = v1.c; // android.support.v4.widget.c.c:android.database.Cursor
        _result = android.database.Cursor.isClosed(v0); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0018 */;
        v0 = v1.c; // android.support.v4.widget.c.c:android.database.Cursor
        _result = android.database.Cursor.requery(v0); // -> boolean
        v0 = _result;
        v1.a = v0; // android.support.v4.widget.c.a:boolean
        return;
    }

    public java.lang.CharSequence c(android.database.Cursor p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.database.Cursor)
        if (v2 != 0) /* goto L_0006 */;
        v0 = "";
        return v0;
        _result = v2.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        // goto L_0005
    }

    public int getCount() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.widget.c.a:boolean
        if (v0 == 0) /* goto L_000f */;
        v0 = v1.c; // android.support.v4.widget.c.c:android.database.Cursor
        if (v0 == 0) /* goto L_000f */;
        v0 = v1.c; // android.support.v4.widget.c.c:android.database.Cursor
        _result = android.database.Cursor.getCount(v0); // -> int
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_000e
    }

    public android.view.View getDropDownView(int p0, android.view.View p1, android.view.ViewGroup p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (android.view.View), v5 = p2 (android.view.ViewGroup)
        v0 = v2.a; // android.support.v4.widget.c.a:boolean
        if (v0 == 0) /* goto L_001b */;
        v0 = v2.c; // android.support.v4.widget.c.c:android.database.Cursor
        _result = android.database.Cursor.moveToPosition(v0, v3); // -> boolean
        if (v4 != 0) /* goto L_0013 */;
        v0 = v2.d; // android.support.v4.widget.c.d:android.content.Context
        v1 = v2.c; // android.support.v4.widget.c.c:android.database.Cursor
        _result = v2.b(v0, v1, v5); // android.support.v4.widget.c.b -> android.view.View
        v4 = _result;
        v0 = v2.d; // android.support.v4.widget.c.d:android.content.Context
        v1 = v2.c; // android.support.v4.widget.c.c:android.database.Cursor
        _result = v2.a(v4, v0, v1); // android.support.v4.widget.c.a -> void
        return v4;
        v4 = 0;
        // goto L_001a
    }

    public android.widget.Filter getFilter() {
        // Registers (2 total): v1 = this
        v0 = v1.h; // android.support.v4.widget.c.h:android.support.v4.widget.g
        if (v0 != 0) /* goto L_000b */;
        v0 = new android.support.v4.widget.g;
        _result = v0.<init>(v1); // android.support.v4.widget.g.<init> -> void
        v1.h = v0; // android.support.v4.widget.c.h:android.support.v4.widget.g
        v0 = v1.h; // android.support.v4.widget.c.h:android.support.v4.widget.g
        return v0;
    }

    public java.lang.Object getItem(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // android.support.v4.widget.c.a:boolean
        if (v0 == 0) /* goto L_0010 */;
        v0 = v1.c; // android.support.v4.widget.c.c:android.database.Cursor
        if (v0 == 0) /* goto L_0010 */;
        v0 = v1.c; // android.support.v4.widget.c.c:android.database.Cursor
        _result = android.database.Cursor.moveToPosition(v0, v2); // -> boolean
        v0 = v1.c; // android.support.v4.widget.c.c:android.database.Cursor
        return v0;
        v0 = 0;
        // goto L_000f
    }

    public long getItemId(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = 0L;
        v2 = v3.a; // android.support.v4.widget.c.a:boolean
        if (v2 == 0) /* goto L_001a */;
        v2 = v3.c; // android.support.v4.widget.c.c:android.database.Cursor
        if (v2 == 0) /* goto L_001a */;
        v2 = v3.c; // android.support.v4.widget.c.c:android.database.Cursor
        _result = android.database.Cursor.moveToPosition(v2, v4); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_001a */;
        v0 = v3.c; // android.support.v4.widget.c.c:android.database.Cursor
        v1 = v3.e; // android.support.v4.widget.c.e:int
        _result = android.database.Cursor.getLong(v0, v1); // -> long
        v0 = _result;
        return v0;
    }

    public android.view.View getView(int p0, android.view.View p1, android.view.ViewGroup p2) {
        // Registers (7 total): v3 = this, v4 = p0 (int), v5 = p1 (android.view.View), v6 = p2 (android.view.ViewGroup)
        v0 = v3.a; // android.support.v4.widget.c.a:boolean
        if (v0 != 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "this should only be called when the cursor is valid";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.c; // android.support.v4.widget.c.c:android.database.Cursor
        _result = android.database.Cursor.moveToPosition(v0, v4); // -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_002f */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "couldn't move cursor to position ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        if (v5 != 0) /* goto L_0039 */;
        v0 = v3.d; // android.support.v4.widget.c.d:android.content.Context
        v1 = v3.c; // android.support.v4.widget.c.c:android.database.Cursor
        _result = v3.a(v0, v1, v6); // android.support.v4.widget.c.a -> android.view.View
        v5 = _result;
        v0 = v3.d; // android.support.v4.widget.c.d:android.content.Context
        v1 = v3.c; // android.support.v4.widget.c.c:android.database.Cursor
        _result = v3.a(v5, v0, v1); // android.support.v4.widget.c.a -> void
        return v5;
    }

    public boolean hasStableIds() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

}