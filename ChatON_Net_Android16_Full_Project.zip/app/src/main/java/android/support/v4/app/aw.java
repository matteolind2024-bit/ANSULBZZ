package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/aw;
 */
public class aw extends android.support.v4.app.bc {
     java.util.ArrayList a;

    public aw() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // android.support.v4.app.bc.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.a = v0; // android.support.v4.app.aw.a:java.util.ArrayList
        return;
    }

}