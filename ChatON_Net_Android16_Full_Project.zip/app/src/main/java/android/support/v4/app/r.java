package android.support.v4.app;

/**
 * Original SourceFile: FragmentActivity.java
 * Descriptor: Landroid/support/v4/app/r;
 */
class r extends android.os.Handler {
    final android.support.v4.app.FragmentActivity a;

    r(android.support.v4.app.FragmentActivity p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.FragmentActivity)
        v0.a = v1; // android.support.v4.app.r.a:android.support.v4.app.FragmentActivity
        _result = v0.<init>(); // android.os.Handler.<init> -> void
        return;
    }

    public void handleMessage(android.os.Message p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Message)
        v0 = v3.what; // android.os.Message.what:int
        // switch(v0)
        _result = v2.handleMessage(v3); // android.os.Handler.handleMessage -> void
        return;
        v0 = v2.a; // android.support.v4.app.r.a:android.support.v4.app.FragmentActivity
        v0 = v0.f; // android.support.v4.app.FragmentActivity.f:boolean
        if (v0 == 0) /* goto L_0008 */;
        v0 = v2.a; // android.support.v4.app.r.a:android.support.v4.app.FragmentActivity
        v1 = 0;
        _result = v0.a(v1); // android.support.v4.app.FragmentActivity.a -> void
        // goto L_0008
        v0 = v2.a; // android.support.v4.app.r.a:android.support.v4.app.FragmentActivity
        _result = v0.a_(); // android.support.v4.app.FragmentActivity.a_ -> void
        v0 = v2.a; // android.support.v4.app.r.a:android.support.v4.app.FragmentActivity
        v0 = v0.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.f(); // android.support.v4.app.y.f -> boolean
        // goto L_0008
    }

}