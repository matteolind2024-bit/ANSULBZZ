package android.support.v4.b;

/**
 * Original SourceFile: ParcelableCompatHoneycombMR2.java
 * Descriptor: Landroid/support/v4/b/e;
 */
class e {
    static android.os.Parcelable$Creator a(android.support.v4.b.c p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.b.c)
        v0 = new android.support.v4.b.d;
        _result = v0.<init>(v1); // android.support.v4.b.d.<init> -> void
        return v0;
    }

}