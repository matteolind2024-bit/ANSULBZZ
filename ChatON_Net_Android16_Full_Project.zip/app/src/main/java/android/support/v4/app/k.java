package android.support.v4.app;

/**
 * Original SourceFile: ActivityCompatHoneycomb.java
 * Descriptor: Landroid/support/v4/app/k;
 */
class k {
    static void a(android.app.Activity p0) {
        // Registers (1 total): v0 = p0 (android.app.Activity)
        _result = v0.invalidateOptionsMenu(); // android.app.Activity.invalidateOptionsMenu -> void
        return;
    }

}