package android.support.v4.widget;

/**
 * Original SourceFile: SlidingPaneLayout.java
 * Descriptor: Landroid/support/v4/widget/SlidingPaneLayout$SavedState;
 */
class SlidingPaneLayout$SavedState extends android.view.View$BaseSavedState {
    public static final android.os.Parcelable$Creator CREATOR;
     boolean isOpen;

    static {
        v0 = new android.support.v4.widget.ah;
        _result = v0.<init>(); // android.support.v4.widget.ah.<init> -> void
        android.support.v4.widget.SlidingPaneLayout$SavedState.CREATOR = v0; // :android.os.Parcelable$Creator
        return;
    }

    private SlidingPaneLayout$SavedState(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        _result = v1.<init>(v2); // android.view.View$BaseSavedState.<init> -> void
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        if (v0 == 0) /* goto L_000d */;
        v0 = 1;
        v1.isOpen = v0; // android.support.v4.widget.SlidingPaneLayout$SavedState.isOpen:boolean
        return;
        v0 = 0;
        // goto L_000a
    }

    SlidingPaneLayout$SavedState(android.os.Parcel p0, android.support.v4.widget.ac p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.os.Parcel), v2 = p1 (android.support.v4.widget.ac)
        _result = v0.<init>(v1); // android.support.v4.widget.SlidingPaneLayout$SavedState.<init> -> void
        return;
    }

    SlidingPaneLayout$SavedState(android.os.Parcelable p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.Parcelable)
        _result = v0.<init>(v1); // android.view.View$BaseSavedState.<init> -> void
        return;
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (int)
        _result = v1.writeToParcel(v2, v3); // android.view.View$BaseSavedState.writeToParcel -> void
        v0 = v1.isOpen; // android.support.v4.widget.SlidingPaneLayout$SavedState.isOpen:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = 1;
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        return;
        v0 = 0;
        // goto L_0008
    }

}