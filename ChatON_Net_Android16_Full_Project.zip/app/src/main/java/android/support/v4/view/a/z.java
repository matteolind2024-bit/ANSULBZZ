package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityRecordCompat.java
 * Descriptor: Landroid/support/v4/view/a/z;
 */
class z extends android.support.v4.view.a.y {
    z() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.a.y.<init> -> void
        return;
    }

}