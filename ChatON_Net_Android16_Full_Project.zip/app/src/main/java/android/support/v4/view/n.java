package android.support.v4.view;

/**
 * Original SourceFile: GravityCompat.java
 * Descriptor: Landroid/support/v4/view/n;
 */
public class n {
    static final android.support.v4.view.o a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 17;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.q;
        _result = v0.<init>(); // android.support.v4.view.q.<init> -> void
        android.support.v4.view.n.a = v0; // :android.support.v4.view.o
        return;
        v0 = new android.support.v4.view.p;
        _result = v0.<init>(); // android.support.v4.view.p.<init> -> void
        android.support.v4.view.n.a = v0; // :android.support.v4.view.o
        // goto L_000d
    }

    public static int a(int p0, int p1) {
        // Registers (3 total): v1 = p0 (int), v2 = p1 (int)
        v0 = android.support.v4.view.n.a; // :android.support.v4.view.o
        _result = android.support.v4.view.o.a(v0, v1, v2); // -> int
        v0 = _result;
        return v0;
    }

}