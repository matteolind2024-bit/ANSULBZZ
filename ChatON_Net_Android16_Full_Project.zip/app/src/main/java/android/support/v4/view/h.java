package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompatIcs.java
 * Descriptor: Landroid/support/v4/view/h;
 */
class h {
    public static java.lang.Object a() {
        v0 = new android.view.View$AccessibilityDelegate;
        _result = v0.<init>(); // android.view.View$AccessibilityDelegate.<init> -> void
        return v0;
    }

    public static java.lang.Object a(android.support.v4.view.j p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.view.j)
        v0 = new android.support.v4.view.i;
        _result = v0.<init>(v1); // android.support.v4.view.i.<init> -> void
        return v0;
    }

    public static void a(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (int)
        v0 = (android.view.View$AccessibilityDelegate) v0;
        _result = v0.sendAccessibilityEvent(v1, v2); // android.view.View$AccessibilityDelegate.sendAccessibilityEvent -> void
        return;
    }

    public static void a(java.lang.Object p0, android.view.View p1, java.lang.Object p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (java.lang.Object)
        v0 = (android.view.View$AccessibilityDelegate) v0;
        v2 = (android.view.accessibility.AccessibilityNodeInfo) v2;
        _result = v0.onInitializeAccessibilityNodeInfo(v1, v2); // android.view.View$AccessibilityDelegate.onInitializeAccessibilityNodeInfo -> void
        return;
    }

    public static boolean a(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        v1 = (android.view.View$AccessibilityDelegate) v1;
        _result = v1.dispatchPopulateAccessibilityEvent(v2, v3); // android.view.View$AccessibilityDelegate.dispatchPopulateAccessibilityEvent -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean a(java.lang.Object p0, android.view.ViewGroup p1, android.view.View p2, android.view.accessibility.AccessibilityEvent p3) {
        // Registers (5 total): v1 = p0 (java.lang.Object), v2 = p1 (android.view.ViewGroup), v3 = p2 (android.view.View), v4 = p3 (android.view.accessibility.AccessibilityEvent)
        v1 = (android.view.View$AccessibilityDelegate) v1;
        _result = v1.onRequestSendAccessibilityEvent(v2, v3, v4); // android.view.View$AccessibilityDelegate.onRequestSendAccessibilityEvent -> boolean
        v0 = _result;
        return v0;
    }

    public static void b(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = (android.view.View$AccessibilityDelegate) v0;
        _result = v0.onInitializeAccessibilityEvent(v1, v2); // android.view.View$AccessibilityDelegate.onInitializeAccessibilityEvent -> void
        return;
    }

    public static void c(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = (android.view.View$AccessibilityDelegate) v0;
        _result = v0.onPopulateAccessibilityEvent(v1, v2); // android.view.View$AccessibilityDelegate.onPopulateAccessibilityEvent -> void
        return;
    }

    public static void d(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View), v2 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = (android.view.View$AccessibilityDelegate) v0;
        _result = v0.sendAccessibilityEventUnchecked(v1, v2); // android.view.View$AccessibilityDelegate.sendAccessibilityEventUnchecked -> void
        return;
    }

}