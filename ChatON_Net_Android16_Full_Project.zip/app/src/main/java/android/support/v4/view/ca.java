package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ca;
 */
class ca extends android.support.v4.view.a {
    final android.support.v4.view.ViewPager b;

    ca(android.support.v4.view.ViewPager p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.ViewPager)
        v0.b = v1; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        _result = v0.<init>(); // android.support.v4.view.a.<init> -> void
        return;
    }

    private boolean b() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        _result = v1.a(); // android.support.v4.view.ViewPager.a -> android.support.v4.view.ae
        v1 = _result;
        if (v1 == 0) /* goto L_0016 */;
        v1 = v2.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        _result = v1.a(); // android.support.v4.view.ViewPager.a -> android.support.v4.view.ae
        v1 = _result;
        _result = v1.b(); // android.support.v4.view.ae.b -> int
        v1 = _result;
        if (v1 <= v0) /* goto L_0016 */;
        return v0;
        v0 = 0;
        // goto L_0015
    }

    public void a(android.view.View p0, android.support.v4.view.a.a p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.support.v4.view.a.a)
        _result = v2.a(v3, v4); // android.support.v4.view.a.a -> void
        v0 = android.support.v4.view.ViewPager.class;
        _result = v0.getName(); // java.lang.Class.getName -> java.lang.String
        v0 = _result;
        _result = v4.b(v0); // android.support.v4.view.a.a.b -> void
        _result = v2.b(); // android.support.v4.view.ca.b -> boolean
        v0 = _result;
        _result = v4.i(v0); // android.support.v4.view.a.a.i -> void
        v0 = v2.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        v1 = 1;
        _result = v0.canScrollHorizontally(v1); // android.support.v4.view.ViewPager.canScrollHorizontally -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        v0 = 4096;
        _result = v4.a(v0); // android.support.v4.view.a.a.a -> void
        v0 = v2.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        v1 = -1;
        _result = v0.canScrollHorizontally(v1); // android.support.v4.view.ViewPager.canScrollHorizontally -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002f */;
        v0 = 8192;
        _result = v4.a(v0); // android.support.v4.view.a.a.a -> void
        return;
    }

    public boolean a(android.view.View p0, int p1, android.os.Bundle p2) {
        // Registers (8 total): v4 = this, v5 = p0 (android.view.View), v6 = p1 (int), v7 = p2 (android.os.Bundle)
        v1 = 0;
        v0 = 1;
        _result = v4.a(v5, v6, v7); // android.support.v4.view.a.a -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0009 */;
        return v0;
        // switch(v6)
        v0 = v1;
        // goto L_0008
        v2 = v4.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        _result = v2.canScrollHorizontally(v0); // android.support.v4.view.ViewPager.canScrollHorizontally -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0024 */;
        v1 = v4.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        v2 = v4.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        _result = v2.b(); // android.support.v4.view.ViewPager.b -> int
        v2 = _result;
        v2 = binOpLit8_0xd8(v2, 1);
        _result = v1.setCurrentItem(v2); // android.support.v4.view.ViewPager.setCurrentItem -> void
        // goto L_0008
        v0 = v1;
        // goto L_0008
        v2 = v4.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        v3 = -1;
        _result = v2.canScrollHorizontally(v3); // android.support.v4.view.ViewPager.canScrollHorizontally -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_003d */;
        v1 = v4.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        v2 = v4.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        _result = v2.b(); // android.support.v4.view.ViewPager.b -> int
        v2 = _result;
        v2 = binOpLit8_0xd8(v2, -1);
        _result = v1.setCurrentItem(v2); // android.support.v4.view.ViewPager.setCurrentItem -> void
        // goto L_0008
        v0 = v1;
        // goto L_0008
    }

    public void d(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.view.View), v5 = p1 (android.view.accessibility.AccessibilityEvent)
        _result = v3.d(v4, v5); // android.support.v4.view.a.d -> void
        v0 = android.support.v4.view.ViewPager.class;
        _result = v0.getName(); // java.lang.Class.getName -> java.lang.String
        v0 = _result;
        _result = v5.setClassName(v0); // android.view.accessibility.AccessibilityEvent.setClassName -> void
        _result = this.a(); // android.support.v4.view.a.x.a -> android.support.v4.view.a.x
        v0 = _result;
        _result = v3.b(); // android.support.v4.view.ca.b -> boolean
        v1 = _result;
        _result = v0.a(v1); // android.support.v4.view.a.x.a -> void
        _result = v5.getEventType(); // android.view.accessibility.AccessibilityEvent.getEventType -> int
        v1 = _result;
        v2 = 4096;
        if (v1 != v2) /* goto L_0046 */;
        v1 = v3.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        _result = v1.a(); // android.support.v4.view.ViewPager.a -> android.support.v4.view.ae
        v1 = _result;
        if (v1 == 0) /* goto L_0046 */;
        v1 = v3.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        _result = v1.a(); // android.support.v4.view.ViewPager.a -> android.support.v4.view.ae
        v1 = _result;
        _result = v1.b(); // android.support.v4.view.ae.b -> int
        v1 = _result;
        _result = v0.a(v1); // android.support.v4.view.a.x.a -> void
        v1 = v3.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        _result = v1.b(); // android.support.v4.view.ViewPager.b -> int
        v1 = _result;
        _result = v0.b(v1); // android.support.v4.view.a.x.b -> void
        v1 = v3.b; // android.support.v4.view.ca.b:android.support.v4.view.ViewPager
        _result = v1.b(); // android.support.v4.view.ViewPager.b -> int
        v1 = _result;
        _result = v0.c(v1); // android.support.v4.view.a.x.c -> void
        return;
    }

}