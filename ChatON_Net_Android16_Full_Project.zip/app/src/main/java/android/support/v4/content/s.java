package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/s;
 */
class s extends android.os.Handler {
    private s() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.os.Handler.<init> -> void
        return;
    }

    s(android.support.v4.content.n p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.content.n)
        _result = v0.<init>(); // android.support.v4.content.s.<init> -> void
        return;
    }

    public void handleMessage(android.os.Message p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Message)
        v0 = v4.obj; // android.os.Message.obj:java.lang.Object
        v0 = (android.support.v4.content.r) v0;
        v1 = v4.what; // android.os.Message.what:int
        // switch(v1)
        return;
        v1 = v0.a; // android.support.v4.content.r.a:android.support.v4.content.m
        v0 = v0.b; // android.support.v4.content.r.b:java.lang.Object[]
        v2 = 0;
        v0 = v0[v2];
        _result = v1.c(v0); // android.support.v4.content.m.c -> void
        // goto L_0009
        v1 = v0.a; // android.support.v4.content.r.a:android.support.v4.content.m
        v0 = v0.b; // android.support.v4.content.r.b:java.lang.Object[]
        _result = v1.b(v0); // android.support.v4.content.m.b -> void
        // goto L_0009
    }

}