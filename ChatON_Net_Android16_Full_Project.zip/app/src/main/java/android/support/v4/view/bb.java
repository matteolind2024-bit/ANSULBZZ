package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/bb;
 */
class bb extends android.support.v4.view.ba {
    bb() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.ba.<init> -> void
        return;
    }

}