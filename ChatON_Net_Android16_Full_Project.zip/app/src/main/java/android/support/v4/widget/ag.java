package android.support.v4.widget;

/**
 * Original SourceFile: SlidingPaneLayout.java
 * Descriptor: Landroid/support/v4/widget/ag;
 */
public interface ag {
    public abstract void a(android.view.View p0);
    public abstract void a(android.view.View p0, float p1);
    public abstract void b(android.view.View p0);
}