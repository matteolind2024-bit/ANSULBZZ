package android.support.v4.view;

/**
 * Original SourceFile: VelocityTrackerCompat.java
 * Descriptor: Landroid/support/v4/view/ar;
 */
interface ar {
    public abstract float a(android.view.VelocityTracker p0, int p1);
    public abstract float b(android.view.VelocityTracker p0, int p1);
}