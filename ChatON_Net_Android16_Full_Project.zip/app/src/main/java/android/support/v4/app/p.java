package android.support.v4.app;

/**
 * Original SourceFile: Fragment.java
 * Descriptor: Landroid/support/v4/app/p;
 */
public class p extends java.lang.RuntimeException {
    public p(java.lang.String p0, java.lang.Exception p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (java.lang.Exception)
        _result = v0.<init>(v1, v2); // java.lang.RuntimeException.<init> -> void
        return;
    }

}