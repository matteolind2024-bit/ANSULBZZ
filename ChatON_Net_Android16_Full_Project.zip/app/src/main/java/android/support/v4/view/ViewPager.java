package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager;
 */
public class ViewPager extends android.view.ViewGroup {
    private static final int[] a;
    private static final android.support.v4.view.ch af;
    private static final java.util.Comparator c;
    private static final android.view.animation.Interpolator d;
    private boolean A;
    private boolean B;
    private int C;
    private int D;
    private int E;
    private float F;
    private float G;
    private float H;
    private float I;
    private int J;
    private android.view.VelocityTracker K;
    private int L;
    private int M;
    private int N;
    private int O;
    private boolean P;
    private android.support.v4.widget.n Q;
    private android.support.v4.widget.n R;
    private boolean S;
    private boolean T;
    private boolean U;
    private int V;
    private android.support.v4.view.cc W;
    private android.support.v4.view.cc Z;
    private android.support.v4.view.cb aa;
    private android.support.v4.view.cd ab;
    private java.lang.reflect.Method ac;
    private int ad;
    private java.util.ArrayList ae;
    private final java.lang.Runnable ag;
    private int ah;
    private int b;
    private final java.util.ArrayList e;
    private final android.support.v4.view.bz f;
    private final android.graphics.Rect g;
    private android.support.v4.view.ae h;
    private int i;
    private int j;
    private android.os.Parcelable k;
    private java.lang.ClassLoader l;
    private android.widget.Scroller m;
    private android.support.v4.view.ce n;
    private int o;
    private android.graphics.drawable.Drawable p;
    private int q;
    private int r;
    private float s;
    private float t;
    private int u;
    private int v;
    private boolean w;
    private boolean x;
    private boolean y;
    private int z;

    static {
        v0 = 1;
        v0 = new int[][size=v0];
        v1 = 0;
        v2 = 16842931; // 0x010100b3
        v0[v1] = v2;
        android.support.v4.view.ViewPager.a = v0; // :int[]
        v0 = new android.support.v4.view.bv;
        _result = v0.<init>(); // android.support.v4.view.bv.<init> -> void
        android.support.v4.view.ViewPager.c = v0; // :java.util.Comparator
        v0 = new android.support.v4.view.bw;
        _result = v0.<init>(); // android.support.v4.view.bw.<init> -> void
        android.support.v4.view.ViewPager.d = v0; // :android.view.animation.Interpolator
        v0 = new android.support.v4.view.ch;
        _result = v0.<init>(); // android.support.v4.view.ch.<init> -> void
        android.support.v4.view.ViewPager.af = v0; // :android.support.v4.view.ch
        return;
    }

    public ViewPager(android.content.Context p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.content.Context)
        v4 = 0;
        v3 = 1;
        v2 = 0;
        v1 = -1;
        _result = v5.<init>(v6); // android.view.ViewGroup.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v5.e = v0; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        v0 = new android.support.v4.view.bz;
        _result = v0.<init>(); // android.support.v4.view.bz.<init> -> void
        v5.f = v0; // android.support.v4.view.ViewPager.f:android.support.v4.view.bz
        v0 = new android.graphics.Rect;
        _result = v0.<init>(); // android.graphics.Rect.<init> -> void
        v5.g = v0; // android.support.v4.view.ViewPager.g:android.graphics.Rect
        v5.j = v1; // android.support.v4.view.ViewPager.j:int
        v5.k = v4; // android.support.v4.view.ViewPager.k:android.os.Parcelable
        v5.l = v4; // android.support.v4.view.ViewPager.l:java.lang.ClassLoader
        v0 = -8388609; // 0xff7fffff
        v5.s = v0; // android.support.v4.view.ViewPager.s:float
        v0 = 2139095039; // 0x7f7fffff
        v5.t = v0; // android.support.v4.view.ViewPager.t:float
        v5.z = v3; // android.support.v4.view.ViewPager.z:int
        v5.J = v1; // android.support.v4.view.ViewPager.J:int
        v5.S = v3; // android.support.v4.view.ViewPager.S:boolean
        v5.T = v2; // android.support.v4.view.ViewPager.T:boolean
        v0 = new android.support.v4.view.bx;
        _result = v0.<init>(v5); // android.support.v4.view.bx.<init> -> void
        v5.ag = v0; // android.support.v4.view.ViewPager.ag:java.lang.Runnable
        v5.ah = v2; // android.support.v4.view.ViewPager.ah:int
        _result = v5.a(); // android.support.v4.view.ViewPager.a -> void
        return;
    }

    public ViewPager(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.content.Context), v7 = p1 (android.util.AttributeSet)
        v4 = 0;
        v3 = 1;
        v2 = 0;
        v1 = -1;
        _result = v5.<init>(v6, v7); // android.view.ViewGroup.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v5.e = v0; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        v0 = new android.support.v4.view.bz;
        _result = v0.<init>(); // android.support.v4.view.bz.<init> -> void
        v5.f = v0; // android.support.v4.view.ViewPager.f:android.support.v4.view.bz
        v0 = new android.graphics.Rect;
        _result = v0.<init>(); // android.graphics.Rect.<init> -> void
        v5.g = v0; // android.support.v4.view.ViewPager.g:android.graphics.Rect
        v5.j = v1; // android.support.v4.view.ViewPager.j:int
        v5.k = v4; // android.support.v4.view.ViewPager.k:android.os.Parcelable
        v5.l = v4; // android.support.v4.view.ViewPager.l:java.lang.ClassLoader
        v0 = -8388609; // 0xff7fffff
        v5.s = v0; // android.support.v4.view.ViewPager.s:float
        v0 = 2139095039; // 0x7f7fffff
        v5.t = v0; // android.support.v4.view.ViewPager.t:float
        v5.z = v3; // android.support.v4.view.ViewPager.z:int
        v5.J = v1; // android.support.v4.view.ViewPager.J:int
        v5.S = v3; // android.support.v4.view.ViewPager.S:boolean
        v5.T = v2; // android.support.v4.view.ViewPager.T:boolean
        v0 = new android.support.v4.view.bx;
        _result = v0.<init>(v5); // android.support.v4.view.bx.<init> -> void
        v5.ag = v0; // android.support.v4.view.ViewPager.ag:java.lang.Runnable
        v5.ah = v2; // android.support.v4.view.ViewPager.ah:int
        _result = v5.a(); // android.support.v4.view.ViewPager.a -> void
        return;
    }

    private int a(int p0, float p1, int p2, int p3) {
        // Registers (8 total): v3 = this, v4 = p0 (int), v5 = p1 (float), v6 = p2 (int), v7 = p3 (int)
        _result = v7.abs(); // java.lang.Math.abs -> int
        v0 = _result;
        v1 = v3.N; // android.support.v4.view.ViewPager.N:int
        if (v0 <= v1) /* goto L_0043 */;
        _result = v6.abs(); // java.lang.Math.abs -> int
        v0 = _result;
        v1 = v3.L; // android.support.v4.view.ViewPager.L:int
        if (v0 <= v1) /* goto L_0043 */;
        if (v6 <= 0) /* goto L_0040 */;
        v0 = v3.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_003f */;
        v0 = v3.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        v1 = 0;
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v1 = v3.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        v2 = v3.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        v2 = binOpLit8_0xd8(v2, -1);
        _result = v1.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.view.bz) v1;
        v0 = v0.b; // android.support.v4.view.bz.b:int
        v1 = v1.b; // android.support.v4.view.bz.b:int
        _result = v4.min(v1); // java.lang.Math.min -> int
        v1 = _result;
        _result = v0.max(v1); // java.lang.Math.max -> int
        v4 = _result;
        return v4;
        v4 = binOpLit8_0xd8(v4, 1);
        // goto L_0012
        v0 = v3.i; // android.support.v4.view.ViewPager.i:int
        if (v4 < v0) /* goto L_004f */;
        v0 = 1053609165; // 0x3ecccccd
        v1 = unaryOp_0x82(v4);
        v1 = binOp2addr_0xc6(v1, v5);
        v0 = binOp2addr_0xc6(v0, v1);
        v4 = unaryOp_0x87(v0);
        // goto L_0012
        v0 = 1058642330; // 0x3f19999a
        // goto L_004a
    }

    private android.graphics.Rect a(android.graphics.Rect p0, android.view.View p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.graphics.Rect), v6 = p1 (android.view.View)
        v0 = 0;
        if (v5 != 0) /* goto L_005e */;
        v1 = new android.graphics.Rect;
        _result = v1.<init>(); // android.graphics.Rect.<init> -> void
        if (v6 != 0) /* goto L_000f */;
        _result = v1.set(v0, v0, v0, v0); // android.graphics.Rect.set -> void
        v0 = v1;
        return v0;
        _result = v6.getLeft(); // android.view.View.getLeft -> int
        v0 = _result;
        v1.left = v0; // android.graphics.Rect.left:int
        _result = v6.getRight(); // android.view.View.getRight -> int
        v0 = _result;
        v1.right = v0; // android.graphics.Rect.right:int
        _result = v6.getTop(); // android.view.View.getTop -> int
        v0 = _result;
        v1.top = v0; // android.graphics.Rect.top:int
        _result = v6.getBottom(); // android.view.View.getBottom -> int
        v0 = _result;
        v1.bottom = v0; // android.graphics.Rect.bottom:int
        _result = v6.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v0 = _result;
        v2 = (v0 instanceof android.view.ViewGroup);
        if (v2 == 0) /* goto L_005c */;
        if (v0 == v4) /* goto L_005c */;
        v0 = (android.view.ViewGroup) v0;
        v2 = v1.left; // android.graphics.Rect.left:int
        _result = v0.getLeft(); // android.view.ViewGroup.getLeft -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v1.left = v2; // android.graphics.Rect.left:int
        v2 = v1.right; // android.graphics.Rect.right:int
        _result = v0.getRight(); // android.view.ViewGroup.getRight -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v1.right = v2; // android.graphics.Rect.right:int
        v2 = v1.top; // android.graphics.Rect.top:int
        _result = v0.getTop(); // android.view.ViewGroup.getTop -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v1.top = v2; // android.graphics.Rect.top:int
        v2 = v1.bottom; // android.graphics.Rect.bottom:int
        _result = v0.getBottom(); // android.view.ViewGroup.getBottom -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v1.bottom = v2; // android.graphics.Rect.bottom:int
        _result = v0.getParent(); // android.view.ViewGroup.getParent -> android.view.ViewParent
        v0 = _result;
        // goto L_002b
        v0 = v1;
        // goto L_000e
        v1 = v5;
        // goto L_0008
    }

    static android.support.v4.view.ae a(android.support.v4.view.ViewPager p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.view.ViewPager)
        v0 = v1.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        return v0;
    }

    private void a(int p0, int p1, int p2, int p3) {
        // Registers (11 total): v6 = this, v7 = p0 (int), v8 = p1 (int), v9 = p2 (int), v10 = p3 (int)
        v2 = 0;
        if (v8 <= 0) /* goto L_005d */;
        v0 = v6.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.isEmpty(); // java.util.ArrayList.isEmpty -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_005d */;
        _result = v6.getPaddingLeft(); // android.support.v4.view.ViewPager.getPaddingLeft -> int
        v0 = _result;
        v0 = binOp_0x91(v7, v0);
        _result = v6.getPaddingRight(); // android.support.v4.view.ViewPager.getPaddingRight -> int
        v1 = _result;
        v0 = binOp2addr_0xb1(v0, v1);
        v0 = binOp2addr_0xb0(v0, v9);
        _result = v6.getPaddingLeft(); // android.support.v4.view.ViewPager.getPaddingLeft -> int
        v1 = _result;
        v1 = binOp_0x91(v8, v1);
        _result = v6.getPaddingRight(); // android.support.v4.view.ViewPager.getPaddingRight -> int
        v3 = _result;
        v1 = binOp2addr_0xb1(v1, v3);
        v1 = binOp2addr_0xb0(v1, v10);
        _result = v6.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v3 = _result;
        v3 = unaryOp_0x82(v3);
        v1 = unaryOp_0x82(v1);
        v1 = binOp_0xa9(v3, v1);
        v0 = unaryOp_0x82(v0);
        v0 = binOp2addr_0xc8(v0, v1);
        v1 = unaryOp_0x87(v0);
        _result = v6.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v0 = _result;
        _result = v6.scrollTo(v1, v0); // android.support.v4.view.ViewPager.scrollTo -> void
        v0 = v6.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v0.isFinished(); // android.widget.Scroller.isFinished -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_005c */;
        v0 = v6.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v0.getDuration(); // android.widget.Scroller.getDuration -> int
        v0 = _result;
        v3 = v6.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v3.timePassed(); // android.widget.Scroller.timePassed -> int
        v3 = _result;
        v5 = binOp_0x91(v0, v3);
        v0 = v6.i; // android.support.v4.view.ViewPager.i:int
        _result = v6.b(v0); // android.support.v4.view.ViewPager.b -> android.support.v4.view.bz
        v3 = _result;
        v0 = v6.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        v3 = v3.e; // android.support.v4.view.bz.e:float
        v4 = unaryOp_0x82(v7);
        v3 = binOp2addr_0xc8(v3, v4);
        v3 = unaryOp_0x87(v3);
        v4 = v2;
        _result = v0.startScroll(v0..v5); // android.widget.Scroller.startScroll -> void
        return;
        v0 = v6.i; // android.support.v4.view.ViewPager.i:int
        _result = v6.b(v0); // android.support.v4.view.ViewPager.b -> android.support.v4.view.bz
        v0 = _result;
        if (v0 == 0) /* goto L_008c */;
        v0 = v0.e; // android.support.v4.view.bz.e:float
        v1 = v6.t; // android.support.v4.view.ViewPager.t:float
        _result = v0.min(v1); // java.lang.Math.min -> float
        v0 = _result;
        _result = v6.getPaddingLeft(); // android.support.v4.view.ViewPager.getPaddingLeft -> int
        v1 = _result;
        v1 = binOp_0x91(v7, v1);
        _result = v6.getPaddingRight(); // android.support.v4.view.ViewPager.getPaddingRight -> int
        v3 = _result;
        v1 = binOp2addr_0xb1(v1, v3);
        v1 = unaryOp_0x82(v1);
        v0 = binOp2addr_0xc8(v0, v1);
        v0 = unaryOp_0x87(v0);
        _result = v6.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v1 = _result;
        if (v0 == v1) /* goto L_005c */;
        _result = v6.b(v2); // android.support.v4.view.ViewPager.b -> void
        _result = v6.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v1 = _result;
        _result = v6.scrollTo(v0, v1); // android.support.v4.view.ViewPager.scrollTo -> void
        // goto L_005c
        v0 = 0;
        // goto L_006d
    }

    private void a(int p0, boolean p1, int p2, boolean p3) {
        // Registers (10 total): v5 = this, v6 = p0 (int), v7 = p1 (boolean), v8 = p2 (int), v9 = p3 (boolean)
        v1 = 0;
        _result = v5.b(v6); // android.support.v4.view.ViewPager.b -> android.support.v4.view.bz
        v0 = _result;
        if (v0 == 0) /* goto L_0058 */;
        _result = v5.j(); // android.support.v4.view.ViewPager.j -> int
        v2 = _result;
        v2 = unaryOp_0x82(v2);
        v3 = v5.s; // android.support.v4.view.ViewPager.s:float
        v0 = v0.e; // android.support.v4.view.bz.e:float
        v4 = v5.t; // android.support.v4.view.ViewPager.t:float
        _result = v0.min(v4); // java.lang.Math.min -> float
        v0 = _result;
        _result = v3.max(v0); // java.lang.Math.max -> float
        v0 = _result;
        v0 = binOp2addr_0xc8(v0, v2);
        v0 = unaryOp_0x87(v0);
        if (v7 == 0) /* goto L_0038 */;
        _result = v5.a(v0, v1, v8); // android.support.v4.view.ViewPager.a -> void
        if (v9 == 0) /* goto L_002c */;
        v0 = v5.W; // android.support.v4.view.ViewPager.W:android.support.v4.view.cc
        if (v0 == 0) /* goto L_002c */;
        v0 = v5.W; // android.support.v4.view.ViewPager.W:android.support.v4.view.cc
        _result = android.support.v4.view.cc.a(v0, v6); // -> void
        if (v9 == 0) /* goto L_0037 */;
        v0 = v5.Z; // android.support.v4.view.ViewPager.Z:android.support.v4.view.cc
        if (v0 == 0) /* goto L_0037 */;
        v0 = v5.Z; // android.support.v4.view.ViewPager.Z:android.support.v4.view.cc
        _result = android.support.v4.view.cc.a(v0, v6); // -> void
        return;
        if (v9 == 0) /* goto L_0043 */;
        v2 = v5.W; // android.support.v4.view.ViewPager.W:android.support.v4.view.cc
        if (v2 == 0) /* goto L_0043 */;
        v2 = v5.W; // android.support.v4.view.ViewPager.W:android.support.v4.view.cc
        _result = android.support.v4.view.cc.a(v2, v6); // -> void
        if (v9 == 0) /* goto L_004e */;
        v2 = v5.Z; // android.support.v4.view.ViewPager.Z:android.support.v4.view.cc
        if (v2 == 0) /* goto L_004e */;
        v2 = v5.Z; // android.support.v4.view.ViewPager.Z:android.support.v4.view.cc
        _result = android.support.v4.view.cc.a(v2, v6); // -> void
        _result = v5.b(v1); // android.support.v4.view.ViewPager.b -> void
        _result = v5.scrollTo(v0, v1); // android.support.v4.view.ViewPager.scrollTo -> void
        _result = v5.e(v0); // android.support.v4.view.ViewPager.e -> boolean
        // goto L_0037
        v0 = v1;
        // goto L_001c
    }

    static void a(android.support.v4.view.ViewPager p0, int p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.view.ViewPager), v1 = p1 (int)
        _result = v0.d(v1); // android.support.v4.view.ViewPager.d -> void
        return;
    }

    private void a(android.support.v4.view.bz p0, int p1, android.support.v4.view.bz p2) {
        // Registers (15 total): v11 = this, v12 = p0 (android.support.v4.view.bz), v13 = p1 (int), v14 = p2 (android.support.v4.view.bz)
        v4 = 0;
        v10 = 0x3f800000;
        v0 = v11.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v0.b(); // android.support.v4.view.ae.b -> int
        v7 = _result;
        _result = v11.j(); // android.support.v4.view.ViewPager.j -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0055 */;
        v1 = v11.o; // android.support.v4.view.ViewPager.o:int
        v1 = unaryOp_0x82(v1);
        v0 = unaryOp_0x82(v0);
        v0 = binOp_0xa9(v1, v0);
        v6 = v0;
        if (v14 == 0) /* goto L_00b7 */;
        v0 = v14.b; // android.support.v4.view.bz.b:int
        v1 = v12.b; // android.support.v4.view.bz.b:int
        if (v0 >= v1) /* goto L_0070 */;
        v1 = v14.e; // android.support.v4.view.bz.e:float
        v2 = v14.d; // android.support.v4.view.bz.d:float
        v1 = binOp2addr_0xc6(v1, v2);
        v3 = binOp_0xa6(v1, v6);
        v2 = binOpLit8_0xd8(v0, 1);
        v1 = v4;
        v0 = v12.b; // android.support.v4.view.bz.b:int
        if (v2 > v0) /* goto L_00b7 */;
        v0 = v11.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_00b7 */;
        v0 = v11.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v5 = v0.b; // android.support.v4.view.bz.b:int
        if (v2 <= v5) /* goto L_0058 */;
        v5 = v11.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v5.size(); // java.util.ArrayList.size -> int
        v5 = _result;
        v5 = binOpLit8_0xd8(v5, -1);
        if (v1 >= v5) /* goto L_0058 */;
        v1 = binOpLit8_0xd8(v1, 1);
        v0 = v11.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        // goto L_003c
        v0 = 0;
        v6 = v0;
        // goto L_0016
        v5 = v0.b; // android.support.v4.view.bz.b:int
        if (v2 >= v5) /* goto L_0067 */;
        v5 = v11.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v5.d(v2); // android.support.v4.view.ae.d -> float
        v5 = _result;
        v5 = binOp2addr_0xc6(v5, v6);
        v3 = binOp2addr_0xc6(v3, v5);
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_0058
        v0.e = v3; // android.support.v4.view.bz.e:float
        v0 = v0.d; // android.support.v4.view.bz.d:float
        v0 = binOp2addr_0xc6(v0, v6);
        v3 = binOp2addr_0xc6(v3, v0);
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_0028
        v1 = v12.b; // android.support.v4.view.bz.b:int
        if (v0 <= v1) /* goto L_00b7 */;
        v1 = v11.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        v3 = v14.e; // android.support.v4.view.bz.e:float
        v2 = binOpLit8_0xd8(v0, -1);
        v0 = v12.b; // android.support.v4.view.bz.b:int
        if (v2 < v0) /* goto L_00b7 */;
        if (v1 < 0) /* goto L_00b7 */;
        v0 = v11.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v5 = v0.b; // android.support.v4.view.bz.b:int
        if (v2 >= v5) /* goto L_009f */;
        if (v1 <= 0) /* goto L_009f */;
        v1 = binOpLit8_0xd8(v1, -1);
        v0 = v11.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        // goto L_008e
        v5 = v0.b; // android.support.v4.view.bz.b:int
        if (v2 <= v5) /* goto L_00ae */;
        v5 = v11.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v5.d(v2); // android.support.v4.view.ae.d -> float
        v5 = _result;
        v5 = binOp2addr_0xc6(v5, v6);
        v3 = binOp2addr_0xc7(v3, v5);
        v2 = binOpLit8_0xd8(v2, -1);
        // goto L_009f
        v5 = v0.d; // android.support.v4.view.bz.d:float
        v5 = binOp2addr_0xc6(v5, v6);
        v3 = binOp2addr_0xc7(v3, v5);
        v0.e = v3; // android.support.v4.view.bz.e:float
        v2 = binOpLit8_0xd8(v2, -1);
        // goto L_0080
        v0 = v11.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v8 = _result;
        v2 = v12.e; // android.support.v4.view.bz.e:float
        v0 = v12.b; // android.support.v4.view.bz.b:int
        v1 = binOpLit8_0xd8(v0, -1);
        v0 = v12.b; // android.support.v4.view.bz.b:int
        if (v0 != 0) /* goto L_00f9 */;
        v0 = v12.e; // android.support.v4.view.bz.e:float
        v11.s = v0; // android.support.v4.view.ViewPager.s:float
        v0 = v12.b; // android.support.v4.view.bz.b:int
        v3 = binOpLit8_0xd8(v7, -1);
        if (v0 != v3) /* goto L_00fd */;
        v0 = v12.e; // android.support.v4.view.bz.e:float
        v3 = v12.d; // android.support.v4.view.bz.d:float
        v0 = binOp2addr_0xc6(v0, v3);
        v0 = binOp2addr_0xc7(v0, v10);
        v11.t = v0; // android.support.v4.view.ViewPager.t:float
        v0 = binOpLit8_0xd8(v13, -1);
        v5 = v0;
        if (v5 < 0) /* goto L_0114 */;
        v0 = v11.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v3 = v2;
        v2 = v0.b; // android.support.v4.view.bz.b:int
        if (v1 <= v2) /* goto L_0101 */;
        v9 = v11.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v2 = binOpLit8_0xd8(v1, -1);
        _result = v9.d(v1); // android.support.v4.view.ae.d -> float
        v1 = _result;
        v1 = binOp2addr_0xc6(v1, v6);
        v1 = binOp_0xa7(v3, v1);
        v3 = v1;
        v1 = v2;
        // goto L_00e7
        v0 = -8388609; // 0xff7fffff
        // goto L_00c9
        v0 = 2139095039; // 0x7f7fffff
        // goto L_00d7
        v2 = v0.d; // android.support.v4.view.bz.d:float
        v2 = binOp2addr_0xc6(v2, v6);
        v2 = binOp_0xa7(v3, v2);
        v0.e = v2; // android.support.v4.view.bz.e:float
        v0 = v0.b; // android.support.v4.view.bz.b:int
        if (v0 != 0) /* goto L_010e */;
        v11.s = v2; // android.support.v4.view.ViewPager.s:float
        v0 = binOpLit8_0xd8(v5, -1);
        v1 = binOpLit8_0xd8(v1, -1);
        v5 = v0;
        // goto L_00dc
        v0 = v12.e; // android.support.v4.view.bz.e:float
        v1 = v12.d; // android.support.v4.view.bz.d:float
        v0 = binOp2addr_0xc6(v0, v1);
        v2 = binOp_0xa6(v0, v6);
        v0 = v12.b; // android.support.v4.view.bz.b:int
        v1 = binOpLit8_0xd8(v0, 1);
        v0 = binOpLit8_0xd8(v13, 1);
        v5 = v0;
        if (v5 >= v8) /* goto L_0157 */;
        v0 = v11.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v3 = v2;
        v2 = v0.b; // android.support.v4.view.bz.b:int
        if (v1 >= v2) /* goto L_013e */;
        v9 = v11.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v2 = binOpLit8_0xd8(v1, 1);
        _result = v9.d(v1); // android.support.v4.view.ae.d -> float
        v1 = _result;
        v1 = binOp2addr_0xc6(v1, v6);
        v1 = binOp2addr_0xc6(v1, v3);
        v3 = v1;
        v1 = v2;
        // goto L_012d
        v2 = v0.b; // android.support.v4.view.bz.b:int
        v9 = binOpLit8_0xd8(v7, -1);
        if (v2 != v9) /* goto L_014a */;
        v2 = v0.d; // android.support.v4.view.bz.d:float
        v2 = binOp2addr_0xc6(v2, v3);
        v2 = binOp2addr_0xc7(v2, v10);
        v11.t = v2; // android.support.v4.view.ViewPager.t:float
        v0.e = v3; // android.support.v4.view.bz.e:float
        v0 = v0.d; // android.support.v4.view.bz.d:float
        v0 = binOp2addr_0xc6(v0, v6);
        v2 = binOp_0xa6(v3, v0);
        v0 = binOpLit8_0xd8(v5, 1);
        v1 = binOpLit8_0xd8(v1, 1);
        v5 = v0;
        // goto L_0122
        v11.T = v4; // android.support.v4.view.ViewPager.T:boolean
        return;
    }

    private void a(android.view.MotionEvent p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.MotionEvent)
        _result = v4.b(); // android.support.v4.view.z.b -> int
        v0 = _result;
        _result = v4.b(v0); // android.support.v4.view.z.b -> int
        v1 = _result;
        v2 = v3.J; // android.support.v4.view.ViewPager.J:int
        if (v1 != v2) /* goto L_0024 */;
        if (v0 != 0) /* goto L_0025 */;
        v0 = 1;
        _result = v4.c(v0); // android.support.v4.view.z.c -> float
        v1 = _result;
        v3.F = v1; // android.support.v4.view.ViewPager.F:float
        _result = v4.b(v0); // android.support.v4.view.z.b -> int
        v0 = _result;
        v3.J = v0; // android.support.v4.view.ViewPager.J:int
        v0 = v3.K; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        if (v0 == 0) /* goto L_0024 */;
        v0 = v3.K; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        _result = v0.clear(); // android.view.VelocityTracker.clear -> void
        return;
        v0 = 0;
        // goto L_000f
    }

    private boolean a(float p0, float p1) {
        // Registers (6 total): v3 = this, v4 = p0 (float), v5 = p1 (float)
        v2 = 0;
        v0 = v3.D; // android.support.v4.view.ViewPager.D:int
        v0 = unaryOp_0x82(v0);
        v0 = cmp(v4, v0);
        if (v0 >= 0) /* goto L_000c */;
        v0 = cmp(v5, v2);
        if (v0 > 0) /* goto L_001c */;
        _result = v3.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v0 = _result;
        v1 = v3.D; // android.support.v4.view.ViewPager.D:int
        v0 = binOp2addr_0xb1(v0, v1);
        v0 = unaryOp_0x82(v0);
        v0 = cmp(v4, v0);
        if (v0 <= 0) /* goto L_001e */;
        v0 = cmp(v5, v2);
        if (v0 >= 0) /* goto L_001e */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_001d
    }

    static int b(android.support.v4.view.ViewPager p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.view.ViewPager)
        v0 = v1.i; // android.support.v4.view.ViewPager.i:int
        return v0;
    }

    private void b(boolean p0) {
        // Registers (9 total): v7 = this, v8 = p0 (boolean)
        v4 = 1;
        v2 = 0;
        v0 = v7.ah; // android.support.v4.view.ViewPager.ah:int
        v1 = 2;
        if (v0 != v1) /* goto L_004c */;
        v0 = v4;
        if (v0 == 0) /* goto L_002d */;
        _result = v7.e(v2); // android.support.v4.view.ViewPager.e -> void
        v1 = v7.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v1.abortAnimation(); // android.widget.Scroller.abortAnimation -> void
        _result = v7.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v1 = _result;
        _result = v7.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v3 = _result;
        v5 = v7.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v5.getCurrX(); // android.widget.Scroller.getCurrX -> int
        v5 = _result;
        v6 = v7.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v6.getCurrY(); // android.widget.Scroller.getCurrY -> int
        v6 = _result;
        if (v1 != v5) /* goto L_002a */;
        if (v3 == v6) /* goto L_002d */;
        _result = v7.scrollTo(v5, v6); // android.support.v4.view.ViewPager.scrollTo -> void
        v7.y = v2; // android.support.v4.view.ViewPager.y:boolean
        v1 = v2;
        v3 = v0;
        v0 = v7.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_004e */;
        v0 = v7.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v5 = v0.c; // android.support.v4.view.bz.c:boolean
        if (v5 == 0) /* goto L_0048 */;
        v0.c = v2; // android.support.v4.view.bz.c:boolean
        v3 = v4;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0031
        v0 = v2;
        // goto L_0008
        if (v3 == 0) /* goto L_0057 */;
        if (v8 == 0) /* goto L_0058 */;
        v0 = v7.ag; // android.support.v4.view.ViewPager.ag:java.lang.Runnable
        _result = v7.a(v0); // android.support.v4.view.at.a -> void
        return;
        v0 = v7.ag; // android.support.v4.view.ViewPager.ag:java.lang.Runnable
        _result = java.lang.Runnable.run(v0); // -> void
        // goto L_0057
    }

    private boolean b(float p0) {
        // Registers (12 total): v10 = this, v11 = p0 (float)
        v3 = 1;
        v2 = 0;
        v0 = v10.F; // android.support.v4.view.ViewPager.F:float
        v0 = binOp2addr_0xc7(v0, v11);
        v10.F = v11; // android.support.v4.view.ViewPager.F:float
        _result = v10.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v1 = _result;
        v1 = unaryOp_0x82(v1);
        v5 = binOp_0xa6(v1, v0);
        _result = v10.j(); // android.support.v4.view.ViewPager.j -> int
        v7 = _result;
        v0 = unaryOp_0x82(v7);
        v1 = v10.s; // android.support.v4.view.ViewPager.s:float
        v4 = binOp_0xa8(v0, v1);
        v0 = unaryOp_0x82(v7);
        v1 = v10.t; // android.support.v4.view.ViewPager.t:float
        v6 = binOp_0xa8(v0, v1);
        v0 = v10.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v1 = v10.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        v8 = v10.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v8.size(); // java.util.ArrayList.size -> int
        v8 = _result;
        v8 = binOpLit8_0xd8(v8, -1);
        _result = v1.get(v8); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.view.bz) v1;
        v8 = v0.b; // android.support.v4.view.bz.b:int
        if (v8 == 0) /* goto L_0093 */;
        v0 = v0.e; // android.support.v4.view.bz.e:float
        v4 = unaryOp_0x82(v7);
        v0 = binOp2addr_0xc8(v0, v4);
        v4 = v0;
        v0 = v2;
        v8 = v1.b; // android.support.v4.view.bz.b:int
        v9 = v10.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v9.b(); // android.support.v4.view.ae.b -> int
        v9 = _result;
        v9 = binOpLit8_0xd8(v9, -1);
        if (v8 == v9) /* goto L_0091 */;
        v1 = v1.e; // android.support.v4.view.bz.e:float
        v3 = unaryOp_0x82(v7);
        v1 = binOp2addr_0xc8(v1, v3);
        v3 = v2;
        v6 = cmp(v5, v4);
        if (v6 >= 0) /* goto L_0079 */;
        if (v0 == 0) /* goto L_0063 */;
        v0 = binOp_0xa7(v4, v5);
        v1 = v10.Q; // android.support.v4.view.ViewPager.Q:android.support.v4.widget.n
        _result = v0.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v2 = unaryOp_0x82(v7);
        v0 = binOp2addr_0xc9(v0, v2);
        _result = v1.a(v0); // android.support.v4.widget.n.a -> boolean
        v2 = _result;
        v0 = v10.F; // android.support.v4.view.ViewPager.F:float
        v1 = unaryOp_0x87(v4);
        v1 = unaryOp_0x82(v1);
        v1 = binOp_0xa7(v4, v1);
        v0 = binOp2addr_0xc6(v0, v1);
        v10.F = v0; // android.support.v4.view.ViewPager.F:float
        v0 = unaryOp_0x87(v4);
        _result = v10.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v1 = _result;
        _result = v10.scrollTo(v0, v1); // android.support.v4.view.ViewPager.scrollTo -> void
        v0 = unaryOp_0x87(v4);
        _result = v10.e(v0); // android.support.v4.view.ViewPager.e -> boolean
        return v2;
        v0 = cmp(v5, v1);
        if (v0 <= 0) /* goto L_008f */;
        if (v3 == 0) /* goto L_008d */;
        v0 = binOp_0xa7(v5, v1);
        v2 = v10.R; // android.support.v4.view.ViewPager.R:android.support.v4.widget.n
        _result = v0.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v3 = unaryOp_0x82(v7);
        v0 = binOp2addr_0xc9(v0, v3);
        _result = v2.a(v0); // android.support.v4.widget.n.a -> boolean
        v2 = _result;
        v4 = v1;
        // goto L_0063
        v4 = v5;
        // goto L_0063
        v1 = v6;
        // goto L_004f
        v0 = v3;
        // goto L_003e
    }

    private void c(boolean p0) {
        // Registers (8 total): v6 = this, v7 = p0 (boolean)
        v1 = 0;
        _result = v6.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v3 = _result;
        v2 = v1;
        if (v2 >= v3) /* goto L_0019 */;
        if (v7 == 0) /* goto L_0017 */;
        v0 = 2;
        _result = v6.getChildAt(v2); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v4 = _result;
        v5 = 0;
        _result = v4.a(v0, v5); // android.support.v4.view.at.a -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0006
        v0 = v1;
        // goto L_000b
        return;
    }

    private void d(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.ah; // android.support.v4.view.ViewPager.ah:int
        if (v0 != v2) /* goto L_0005 */;
        return;
        v1.ah = v2; // android.support.v4.view.ViewPager.ah:int
        v0 = v1.ab; // android.support.v4.view.ViewPager.ab:android.support.v4.view.cd
        if (v0 == 0) /* goto L_0011 */;
        if (v2 == 0) /* goto L_001b */;
        v0 = 1;
        _result = v1.c(v0); // android.support.v4.view.ViewPager.c -> void
        v0 = v1.W; // android.support.v4.view.ViewPager.W:android.support.v4.view.cc
        if (v0 == 0) /* goto L_0004 */;
        v0 = v1.W; // android.support.v4.view.ViewPager.W:android.support.v4.view.cc
        _result = android.support.v4.view.cc.b(v0, v2); // -> void
        // goto L_0004
        v0 = 0;
        // goto L_000e
    }

    private void d(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        _result = v1.getParent(); // android.support.v4.view.ViewPager.getParent -> android.view.ViewParent
        v0 = _result;
        if (v0 == 0) /* goto L_0009 */;
        _result = android.view.ViewParent.requestDisallowInterceptTouchEvent(v0, v2); // -> void
        return;
    }

    private void e(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.x; // android.support.v4.view.ViewPager.x:boolean
        if (v0 == v2) /* goto L_0006 */;
        v1.x = v2; // android.support.v4.view.ViewPager.x:boolean
        return;
    }

    private boolean e(int p0) {
        // Registers (9 total): v7 = this, v8 = p0 (int)
        v0 = 0;
        v1 = v7.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v1 != 0) /* goto L_001c */;
        v7.U = v0; // android.support.v4.view.ViewPager.U:boolean
        v1 = 0;
        _result = v7.a(v0, v1, v0); // android.support.v4.view.ViewPager.a -> void
        v1 = v7.U; // android.support.v4.view.ViewPager.U:boolean
        if (v1 != 0) /* goto L_0050 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "onPageScrolled did not call superclass implementation";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        _result = v7.l(); // android.support.v4.view.ViewPager.l -> android.support.v4.view.bz
        v1 = _result;
        _result = v7.j(); // android.support.v4.view.ViewPager.j -> int
        v2 = _result;
        v3 = v7.o; // android.support.v4.view.ViewPager.o:int
        v3 = binOp2addr_0xb0(v3, v2);
        v4 = v7.o; // android.support.v4.view.ViewPager.o:int
        v4 = unaryOp_0x82(v4);
        v5 = unaryOp_0x82(v2);
        v4 = binOp2addr_0xc9(v4, v5);
        v5 = v1.b; // android.support.v4.view.bz.b:int
        v6 = unaryOp_0x82(v8);
        v2 = unaryOp_0x82(v2);
        v2 = binOp_0xa9(v6, v2);
        v6 = v1.e; // android.support.v4.view.bz.e:float
        v2 = binOp2addr_0xc7(v2, v6);
        v1 = v1.d; // android.support.v4.view.bz.d:float
        v1 = binOp2addr_0xc6(v1, v4);
        v1 = binOp_0xa9(v2, v1);
        v2 = unaryOp_0x82(v3);
        v2 = binOp2addr_0xc8(v2, v1);
        v2 = unaryOp_0x87(v2);
        v7.U = v0; // android.support.v4.view.ViewPager.U:boolean
        _result = v7.a(v5, v1, v2); // android.support.v4.view.ViewPager.a -> void
        v0 = v7.U; // android.support.v4.view.ViewPager.U:boolean
        if (v0 != 0) /* goto L_004f */;
        v0 = new java.lang.IllegalStateException;
        v1 = "onPageScrolled did not call superclass implementation";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = 1;
        return v0;
    }

    static int[] h() {
        v0 = android.support.v4.view.ViewPager.a; // :int[]
        return v0;
    }

    private void i() {
        // Registers (3 total): v2 = this
        v0 = 0;
        v1 = v0;
        _result = v2.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001f */;
        _result = v2.getChildAt(v1); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v0 = _result;
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        v0 = v0.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v0 != 0) /* goto L_001b */;
        _result = v2.removeViewAt(v1); // android.support.v4.view.ViewPager.removeViewAt -> void
        v1 = binOpLit8_0xd8(v1, -1);
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0002
        return;
    }

    private int j() {
        // Registers (3 total): v2 = this
        _result = v2.getMeasuredWidth(); // android.support.v4.view.ViewPager.getMeasuredWidth -> int
        v0 = _result;
        _result = v2.getPaddingLeft(); // android.support.v4.view.ViewPager.getPaddingLeft -> int
        v1 = _result;
        v0 = binOp2addr_0xb1(v0, v1);
        _result = v2.getPaddingRight(); // android.support.v4.view.ViewPager.getPaddingRight -> int
        v1 = _result;
        v0 = binOp2addr_0xb1(v0, v1);
        return v0;
    }

    private void k() {
        // Registers (5 total): v4 = this
        v0 = v4.ad; // android.support.v4.view.ViewPager.ad:int
        if (v0 == 0) /* goto L_002f */;
        v0 = v4.ae; // android.support.v4.view.ViewPager.ae:java.util.ArrayList
        if (v0 != 0) /* goto L_0022 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v4.ae = v0; // android.support.v4.view.ViewPager.ae:java.util.ArrayList
        _result = v4.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v1 = _result;
        v0 = 0;
        if (v0 >= v1) /* goto L_0028 */;
        _result = v4.getChildAt(v0); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v2 = _result;
        v3 = v4.ae; // android.support.v4.view.ViewPager.ae:java.util.ArrayList
        _result = v3.add(v2); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0014
        v0 = v4.ae; // android.support.v4.view.ViewPager.ae:java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        // goto L_000f
        v0 = v4.ae; // android.support.v4.view.ViewPager.ae:java.util.ArrayList
        v1 = android.support.v4.view.ViewPager.af; // :android.support.v4.view.ch
        _result = v0.sort(v1); // java.util.Collections.sort -> void
        return;
    }

    private android.support.v4.view.bz l() {
        // Registers (14 total): v13 = this
        v3 = 0;
        v2 = 0;
        _result = v13.j(); // android.support.v4.view.ViewPager.j -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_006e */;
        _result = v13.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v0 = _result;
        v0 = unaryOp_0x82(v0);
        v4 = unaryOp_0x82(v1);
        v0 = binOp2addr_0xc9(v0, v4);
        v9 = v0;
        if (v1 <= 0) /* goto L_0070 */;
        v0 = v13.o; // android.support.v4.view.ViewPager.o:int
        v0 = unaryOp_0x82(v0);
        v1 = unaryOp_0x82(v1);
        v0 = binOp2addr_0xc9(v0, v1);
        v1 = v0;
        v5 = -1;
        v4 = 1;
        v0 = 0;
        v6 = v2;
        v7 = v2;
        v8 = v5;
        v2 = v3;
        v5 = v4;
        v4 = v0;
        v0 = v13.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v2 >= v0) /* goto L_006d */;
        v0 = v13.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        if (v5 != 0) /* goto L_007f */;
        v10 = v0.b; // android.support.v4.view.bz.b:int
        v11 = binOpLit8_0xd8(v8, 1);
        if (v10 == v11) /* goto L_007f */;
        v0 = v13.f; // android.support.v4.view.ViewPager.f:android.support.v4.view.bz
        v6 = binOp2addr_0xc6(v6, v7);
        v6 = binOp2addr_0xc6(v6, v1);
        v0.e = v6; // android.support.v4.view.bz.e:float
        v6 = binOpLit8_0xd8(v8, 1);
        v0.b = v6; // android.support.v4.view.bz.b:int
        v6 = v13.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v7 = v0.b; // android.support.v4.view.bz.b:int
        _result = v6.d(v7); // android.support.v4.view.ae.d -> float
        v6 = _result;
        v0.d = v6; // android.support.v4.view.bz.d:float
        v2 = binOpLit8_0xd8(v2, -1);
        v12 = v0;
        v0 = v2;
        v2 = v12;
        v6 = v2.e; // android.support.v4.view.bz.e:float
        v7 = v2.d; // android.support.v4.view.bz.d:float
        v7 = binOp2addr_0xc6(v7, v6);
        v7 = binOp2addr_0xc6(v7, v1);
        if (v5 != 0) /* goto L_005e */;
        v5 = cmp(v9, v6);
        if (v5 < 0) /* goto L_006d */;
        v4 = cmp(v9, v7);
        if (v4 < 0) /* goto L_006c */;
        v4 = v13.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v4.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        v4 = binOpLit8_0xd8(v4, -1);
        if (v0 != v4) /* goto L_0072 */;
        v4 = v2;
        return v4;
        v9 = v2;
        // goto L_0010
        v1 = v2;
        // goto L_0018
        v5 = v2.b; // android.support.v4.view.bz.b:int
        v4 = v2.d; // android.support.v4.view.bz.d:float
        v0 = binOpLit8_0xd8(v0, 1);
        v7 = v6;
        v8 = v5;
        v5 = v3;
        v6 = v4;
        v4 = v2;
        v2 = v0;
        // goto L_0021
        v12 = v0;
        v0 = v2;
        v2 = v12;
        // goto L_0052
    }

    private void m() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.A = v0; // android.support.v4.view.ViewPager.A:boolean
        v1.B = v0; // android.support.v4.view.ViewPager.B:boolean
        v0 = v1.K; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        if (v0 == 0) /* goto L_0011 */;
        v0 = v1.K; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        _result = v0.recycle(); // android.view.VelocityTracker.recycle -> void
        v0 = 0;
        v1.K = v0; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        return;
    }

    float a(float p0) {
        // Registers (6 total): v4 = this, v5 = p0 (float)
        v0 = 0x3f000000;
        v0 = binOp_0xa7(v5, v0);
        v0 = unaryOp_0x89(v0);
        v2 = 0x3fde28c7460698c7L;
        v0 = binOp2addr_0xcd(v0, v2);
        v0 = unaryOp_0x8c(v0);
        v0 = unaryOp_0x89(v0);
        _result = v0.sin(v1); // java.lang.Math.sin -> double
        v0 = _result;
        v0 = unaryOp_0x8c(v0);
        return v0;
    }

    android.support.v4.view.bz a(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v0 = new android.support.v4.view.bz;
        _result = v0.<init>(); // android.support.v4.view.bz.<init> -> void
        v0.b = v3; // android.support.v4.view.bz.b:int
        v1 = v2.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v1.a(v2, v3); // android.support.v4.view.ae.a -> java.lang.Object
        v1 = _result;
        v0.a = v1; // android.support.v4.view.bz.a:java.lang.Object
        v1 = v2.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v1.d(v3); // android.support.v4.view.ae.d -> float
        v1 = _result;
        v0.d = v1; // android.support.v4.view.bz.d:float
        if (v4 < 0) /* goto L_0021 */;
        v1 = v2.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v4 < v1) /* goto L_0027 */;
        v1 = v2.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v1.add(v0); // java.util.ArrayList.add -> boolean
        return v0;
        v1 = v2.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v1.add(v4, v0); // java.util.ArrayList.add -> void
        // goto L_0026
    }

    android.support.v4.view.bz a(android.view.View p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.view.View)
        v0 = 0;
        v1 = v0;
        v0 = v4.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0021 */;
        v0 = v4.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v2 = v4.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v3 = v0.a; // android.support.v4.view.bz.a:java.lang.Object
        _result = v2.a(v5, v3); // android.support.v4.view.ae.a -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_001d */;
        return v0;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0002
        v0 = 0;
        // goto L_001c
    }

    android.support.v4.view.cc a(android.support.v4.view.cc p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.cc)
        v0 = v1.Z; // android.support.v4.view.ViewPager.Z:android.support.v4.view.cc
        v1.Z = v2; // android.support.v4.view.ViewPager.Z:android.support.v4.view.cc
        return v0;
    }

    void a() {
        // Registers (6 total): v5 = this
        v4 = 1;
        v0 = 0;
        _result = v5.setWillNotDraw(v0); // android.support.v4.view.ViewPager.setWillNotDraw -> void
        v0 = 0x00040000;
        _result = v5.setDescendantFocusability(v0); // android.support.v4.view.ViewPager.setDescendantFocusability -> void
        _result = v5.setFocusable(v4); // android.support.v4.view.ViewPager.setFocusable -> void
        _result = v5.getContext(); // android.support.v4.view.ViewPager.getContext -> android.content.Context
        v0 = _result;
        v1 = new android.widget.Scroller;
        v2 = android.support.v4.view.ViewPager.d; // :android.view.animation.Interpolator
        _result = v1.<init>(v0, v2); // android.widget.Scroller.<init> -> void
        v5.m = v1; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v0.get(); // android.view.ViewConfiguration.get -> android.view.ViewConfiguration
        v1 = _result;
        _result = v0.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v2 = _result;
        _result = v2.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v2 = _result;
        v2 = v2.density; // android.util.DisplayMetrics.density:float
        _result = v1.a(); // android.support.v4.view.bj.a -> int
        v3 = _result;
        v5.E = v3; // android.support.v4.view.ViewPager.E:int
        v3 = 0x43c80000;
        v3 = binOp2addr_0xc8(v3, v2);
        v3 = unaryOp_0x87(v3);
        v5.L = v3; // android.support.v4.view.ViewPager.L:int
        _result = v1.getScaledMaximumFlingVelocity(); // android.view.ViewConfiguration.getScaledMaximumFlingVelocity -> int
        v1 = _result;
        v5.M = v1; // android.support.v4.view.ViewPager.M:int
        v1 = new android.support.v4.widget.n;
        _result = v1.<init>(v0); // android.support.v4.widget.n.<init> -> void
        v5.Q = v1; // android.support.v4.view.ViewPager.Q:android.support.v4.widget.n
        v1 = new android.support.v4.widget.n;
        _result = v1.<init>(v0); // android.support.v4.widget.n.<init> -> void
        v5.R = v1; // android.support.v4.view.ViewPager.R:android.support.v4.widget.n
        v0 = 0x41c80000;
        v0 = binOp2addr_0xc8(v0, v2);
        v0 = unaryOp_0x87(v0);
        v5.N = v0; // android.support.v4.view.ViewPager.N:int
        v0 = 0x40000000;
        v0 = binOp2addr_0xc8(v0, v2);
        v0 = unaryOp_0x87(v0);
        v5.O = v0; // android.support.v4.view.ViewPager.O:int
        v0 = 0x41800000;
        v0 = binOp2addr_0xc8(v0, v2);
        v0 = unaryOp_0x87(v0);
        v5.C = v0; // android.support.v4.view.ViewPager.C:int
        v0 = new android.support.v4.view.ca;
        _result = v0.<init>(v5); // android.support.v4.view.ca.<init> -> void
        _result = v5.a(v0); // android.support.v4.view.at.a -> void
        _result = v5.c(); // android.support.v4.view.at.c -> int
        v0 = _result;
        if (v0 != 0) /* goto L_006b */;
        _result = v5.b(v4); // android.support.v4.view.at.b -> void
        return;
    }

    void a(int p0) {
        // Registers (20 total): v18 = this, v19 = p0 (int)
        v3 = 0;
        v2 = 2;
        v0 = v18;
        v4 = v0.i; // android.support.v4.view.ViewPager.i:int
        v0 = v19;
        if (v4 == v0) /* goto L_0344 */;
        v0 = v18;
        v2 = v0.i; // android.support.v4.view.ViewPager.i:int
        v0 = v19;
        if (v2 >= v0) /* goto L_0030 */;
        v2 = 66;
        v0 = v18;
        v3 = v0.i; // android.support.v4.view.ViewPager.i:int
        v0 = v18;
        _result = v0.b(v3); // android.support.v4.view.ViewPager.b -> android.support.v4.view.bz
        v3 = _result;
        v0 = v19;
        v1 = v18;
        v1.i = v0; // android.support.v4.view.ViewPager.i:int
        v4 = v3;
        v3 = v2;
        v0 = v18;
        v2 = v0.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        if (v2 != 0) /* goto L_0033 */;
        _result = v18.k(v18..v18); // android.support.v4.view.ViewPager.k -> void
        return;
        v2 = 17;
        // goto L_0014
        v0 = v18;
        v2 = v0.y; // android.support.v4.view.ViewPager.y:boolean
        if (v2 == 0) /* goto L_003d */;
        _result = v18.k(v18..v18); // android.support.v4.view.ViewPager.k -> void
        // goto L_002f
        _result = v18.getWindowToken(v18..v18); // android.support.v4.view.ViewPager.getWindowToken -> android.os.IBinder
        v2 = _result;
        if (v2 == 0) /* goto L_002f */;
        v0 = v18;
        v2 = v0.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v0 = v18;
        _result = v2.a(v0); // android.support.v4.view.ae.a -> void
        v0 = v18;
        v2 = v0.z; // android.support.v4.view.ViewPager.z:int
        v5 = 0;
        v0 = v18;
        v6 = v0.i; // android.support.v4.view.ViewPager.i:int
        v6 = binOp2addr_0xb1(v6, v2);
        _result = v5.max(v6); // java.lang.Math.max -> int
        v11 = _result;
        v0 = v18;
        v5 = v0.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v5.b(); // android.support.v4.view.ae.b -> int
        v12 = _result;
        v5 = binOpLit8_0xd8(v12, -1);
        v0 = v18;
        v6 = v0.i; // android.support.v4.view.ViewPager.i:int
        v2 = binOp2addr_0xb0(v2, v6);
        _result = v5.min(v2); // java.lang.Math.min -> int
        v13 = _result;
        v0 = v18;
        v2 = v0.b; // android.support.v4.view.ViewPager.b:int
        if (v12 == v2) /* goto L_00df */;
        _result = v18.getResources(v18..v18); // android.support.v4.view.ViewPager.getResources -> android.content.res.Resources
        v2 = _result;
        _result = v18.getId(v18..v18); // android.support.v4.view.ViewPager.getId -> int
        v3 = _result;
        _result = v2.getResourceName(v3); // android.content.res.Resources.getResourceName -> java.lang.String
        v2 = _result;
        v3 = new java.lang.IllegalStateException;
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v0 = v18;
        v5 = v0.b; // android.support.v4.view.ViewPager.b:int
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = ", found: ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v12); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = " Pager id: ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v4 = " Pager class: ";
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v18.getClass(v18..v18); // java.lang.Object.getClass -> java.lang.Class
        v4 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v4 = " Problematic adapter: ";
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v0 = v18;
        v4 = v0.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v4 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v3.<init>(v2); // java.lang.IllegalStateException.<init> -> void
        throw v3;
        v2 = _exception;
        _result = v18.getId(v18..v18); // android.support.v4.view.ViewPager.getId -> int
        v2 = _result;
        _result = v2.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v2 = _result;
        // goto L_007f
        v6 = 0;
        v2 = 0;
        v5 = v2;
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        if (v5 >= v2) /* goto L_0341 */;
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.view.bz) v2;
        v7 = v2.b; // android.support.v4.view.bz.b:int
        v0 = v18;
        v8 = v0.i; // android.support.v4.view.ViewPager.i:int
        if (v7 < v8) /* goto L_01d4 */;
        v7 = v2.b; // android.support.v4.view.bz.b:int
        v0 = v18;
        v8 = v0.i; // android.support.v4.view.ViewPager.i:int
        if (v7 != v8) /* goto L_0341 */;
        if (v2 != 0) /* goto L_033e */;
        if (v12 <= 0) /* goto L_033e */;
        v0 = v18;
        v2 = v0.i; // android.support.v4.view.ViewPager.i:int
        v0 = v18;
        _result = v0.a(v2, v5); // android.support.v4.view.ViewPager.a -> android.support.v4.view.bz
        v2 = _result;
        v10 = v2;
        if (v10 == 0) /* goto L_0185 */;
        v9 = 0;
        v8 = binOpLit8_0xd8(v5, -1);
        if (v8 < 0) /* goto L_01d9 */;
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.get(v8); // java.util.ArrayList.get -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.view.bz) v2;
        _result = v18.j(v18..v18); // android.support.v4.view.ViewPager.j -> int
        v14 = _result;
        if (v14 > 0) /* goto L_01dc */;
        v6 = 0;
        v0 = v18;
        v7 = v0.i; // android.support.v4.view.ViewPager.i:int
        v7 = binOpLit8_0xd8(v7, -1);
        v16 = v7;
        v7 = v9;
        v9 = v16;
        v17 = v8;
        v8 = v5;
        v5 = v17;
        if (v9 < 0) /* goto L_0147 */;
        v15 = cmp(v7, v6);
        if (v15 < 0) /* goto L_021b */;
        if (v9 >= v11) /* goto L_021b */;
        if (v2 != 0) /* goto L_01eb */;
        v6 = v10.d; // android.support.v4.view.bz.d:float
        v9 = binOpLit8_0xd8(v8, 1);
        v2 = 0x40000000;
        v2 = cmp(v6, v2);
        if (v2 >= 0) /* goto L_0180 */;
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        if (v9 >= v2) /* goto L_0251 */;
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.get(v9); // java.util.ArrayList.get -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.view.bz) v2;
        v7 = v2;
        if (v14 > 0) /* goto L_0254 */;
        v2 = 0;
        v5 = v2;
        v0 = v18;
        v2 = v0.i; // android.support.v4.view.ViewPager.i:int
        v2 = binOpLit8_0xd8(v2, 1);
        v16 = v2;
        v2 = v7;
        v7 = v9;
        v9 = v16;
        if (v9 >= v12) /* goto L_0180 */;
        v11 = cmp(v6, v5);
        if (v11 < 0) /* goto L_029f */;
        if (v9 <= v13) /* goto L_029f */;
        if (v2 != 0) /* goto L_0261 */;
        v0 = v18;
        _result = v0.a(v10, v8, v4); // android.support.v4.view.ViewPager.a -> void
        v0 = v18;
        v4 = v0.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v0 = v18;
        v5 = v0.i; // android.support.v4.view.ViewPager.i:int
        if (v10 == 0) /* goto L_02ed */;
        v2 = v10.a; // android.support.v4.view.bz.a:java.lang.Object
        v0 = v18;
        _result = v4.b(v0, v5, v2); // android.support.v4.view.ae.b -> void
        v0 = v18;
        v2 = v0.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v0 = v18;
        _result = v2.b(v0); // android.support.v4.view.ae.b -> void
        _result = v18.getChildCount(v18..v18); // android.support.v4.view.ViewPager.getChildCount -> int
        v5 = _result;
        v2 = 0;
        v4 = v2;
        if (v4 >= v5) /* goto L_02f0 */;
        v0 = v18;
        _result = v0.getChildAt(v4); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v6 = _result;
        _result = v6.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v2 = _result;
        v2 = (android.support.v4.view.ViewPager$LayoutParams) v2;
        v2.f = v4; // android.support.v4.view.ViewPager$LayoutParams.f:int
        v7 = v2.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v7 != 0) /* goto L_01d0 */;
        v7 = v2.c; // android.support.v4.view.ViewPager$LayoutParams.c:float
        v8 = 0;
        v7 = cmp(v7, v8);
        if (v7 != 0) /* goto L_01d0 */;
        v0 = v18;
        _result = v0.a(v6); // android.support.v4.view.ViewPager.a -> android.support.v4.view.bz
        v6 = _result;
        if (v6 == 0) /* goto L_01d0 */;
        v7 = v6.d; // android.support.v4.view.bz.d:float
        v2.c = v7; // android.support.v4.view.ViewPager$LayoutParams.c:float
        v6 = v6.b; // android.support.v4.view.bz.b:int
        v2.e = v6; // android.support.v4.view.ViewPager$LayoutParams.e:int
        v2 = binOpLit8_0xd8(v4, 1);
        v4 = v2;
        // goto L_01a5
        v2 = binOpLit8_0xd8(v5, 1);
        v5 = v2;
        // goto L_00e2
        v2 = 0;
        // goto L_0126
        v6 = 0x40000000;
        v7 = v10.d; // android.support.v4.view.bz.d:float
        v6 = binOp2addr_0xc7(v6, v7);
        _result = v18.getPaddingLeft(v18..v18); // android.support.v4.view.ViewPager.getPaddingLeft -> int
        v7 = _result;
        v7 = unaryOp_0x82(v7);
        v15 = unaryOp_0x82(v14);
        v7 = binOp2addr_0xc9(v7, v15);
        v6 = binOp2addr_0xc6(v6, v7);
        // goto L_012d
        v15 = v2.b; // android.support.v4.view.bz.b:int
        if (v9 != v15) /* goto L_0215 */;
        v15 = v2.c; // android.support.v4.view.bz.c:boolean
        if (v15 != 0) /* goto L_0215 */;
        v0 = v18;
        v15 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v15.remove(v5); // java.util.ArrayList.remove -> java.lang.Object
        v0 = v18;
        v15 = v0.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v2 = v2.a; // android.support.v4.view.bz.a:java.lang.Object
        v0 = v18;
        _result = v15.a(v0, v9, v2); // android.support.v4.view.ae.a -> void
        v5 = binOpLit8_0xd8(v5, -1);
        v8 = binOpLit8_0xd8(v8, -1);
        if (v5 < 0) /* goto L_0219 */;
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.view.bz) v2;
        v9 = binOpLit8_0xd8(v9, -1);
        // goto L_013d
        v2 = 0;
        // goto L_0215
        if (v2 == 0) /* goto L_0235 */;
        v15 = v2.b; // android.support.v4.view.bz.b:int
        if (v9 != v15) /* goto L_0235 */;
        v2 = v2.d; // android.support.v4.view.bz.d:float
        v7 = binOp2addr_0xc6(v7, v2);
        v5 = binOpLit8_0xd8(v5, -1);
        if (v5 < 0) /* goto L_0233 */;
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.view.bz) v2;
        // goto L_0215
        v2 = 0;
        // goto L_0215
        v2 = binOpLit8_0xd8(v5, 1);
        v0 = v18;
        _result = v0.a(v9, v2); // android.support.v4.view.ViewPager.a -> android.support.v4.view.bz
        v2 = _result;
        v2 = v2.d; // android.support.v4.view.bz.d:float
        v7 = binOp2addr_0xc6(v7, v2);
        v8 = binOpLit8_0xd8(v8, 1);
        if (v5 < 0) /* goto L_024f */;
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.view.bz) v2;
        // goto L_0215
        v2 = 0;
        // goto L_0215
        v7 = 0;
        // goto L_0166
        _result = v18.getPaddingRight(v18..v18); // android.support.v4.view.ViewPager.getPaddingRight -> int
        v2 = _result;
        v2 = unaryOp_0x82(v2);
        v5 = unaryOp_0x82(v14);
        v2 = binOp2addr_0xc9(v2, v5);
        v5 = 0x40000000;
        v2 = binOp2addr_0xc6(v2, v5);
        v5 = v2;
        // goto L_016a
        v11 = v2.b; // android.support.v4.view.bz.b:int
        if (v9 != v11) /* goto L_0337 */;
        v11 = v2.c; // android.support.v4.view.bz.c:boolean
        if (v11 != 0) /* goto L_0337 */;
        v0 = v18;
        v11 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v11.remove(v7); // java.util.ArrayList.remove -> java.lang.Object
        v0 = v18;
        v11 = v0.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v2 = v2.a; // android.support.v4.view.bz.a:java.lang.Object
        v0 = v18;
        _result = v11.a(v0, v9, v2); // android.support.v4.view.ae.a -> void
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        if (v7 >= v2) /* goto L_029d */;
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.get(v7); // java.util.ArrayList.get -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.view.bz) v2;
        v16 = v6;
        v6 = v2;
        v2 = v16;
        v9 = binOpLit8_0xd8(v9, 1);
        v16 = v2;
        v2 = v6;
        v6 = v16;
        // goto L_0176
        v2 = 0;
        // goto L_028f
        if (v2 == 0) /* goto L_02c6 */;
        v11 = v2.b; // android.support.v4.view.bz.b:int
        if (v9 != v11) /* goto L_02c6 */;
        v2 = v2.d; // android.support.v4.view.bz.d:float
        v6 = binOp2addr_0xc6(v6, v2);
        v7 = binOpLit8_0xd8(v7, 1);
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        if (v7 >= v2) /* goto L_02c4 */;
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.get(v7); // java.util.ArrayList.get -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.view.bz) v2;
        v16 = v6;
        v6 = v2;
        v2 = v16;
        // goto L_0294
        v2 = 0;
        // goto L_02be
        v0 = v18;
        _result = v0.a(v9, v7); // android.support.v4.view.ViewPager.a -> android.support.v4.view.bz
        v2 = _result;
        v7 = binOpLit8_0xd8(v7, 1);
        v2 = v2.d; // android.support.v4.view.bz.d:float
        v6 = binOp2addr_0xc6(v6, v2);
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        if (v7 >= v2) /* goto L_02eb */;
        v0 = v18;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.get(v7); // java.util.ArrayList.get -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.view.bz) v2;
        v16 = v6;
        v6 = v2;
        v2 = v16;
        // goto L_0294
        v2 = 0;
        // goto L_02e5
        v2 = 0;
        // goto L_0191
        _result = v18.k(v18..v18); // android.support.v4.view.ViewPager.k -> void
        _result = v18.hasFocus(v18..v18); // android.support.v4.view.ViewPager.hasFocus -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_002f */;
        _result = v18.findFocus(v18..v18); // android.support.v4.view.ViewPager.findFocus -> android.view.View
        v2 = _result;
        if (v2 == 0) /* goto L_0335 */;
        v0 = v18;
        _result = v0.b(v2); // android.support.v4.view.ViewPager.b -> android.support.v4.view.bz
        v2 = _result;
        if (v2 == 0) /* goto L_030f */;
        v2 = v2.b; // android.support.v4.view.bz.b:int
        v0 = v18;
        v4 = v0.i; // android.support.v4.view.ViewPager.i:int
        if (v2 == v4) /* goto L_002f */;
        v2 = 0;
        _result = v18.getChildCount(v18..v18); // android.support.v4.view.ViewPager.getChildCount -> int
        v4 = _result;
        if (v2 >= v4) /* goto L_002f */;
        v0 = v18;
        _result = v0.getChildAt(v2); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v4 = _result;
        v0 = v18;
        _result = v0.a(v4); // android.support.v4.view.ViewPager.a -> android.support.v4.view.bz
        v5 = _result;
        if (v5 == 0) /* goto L_0332 */;
        v5 = v5.b; // android.support.v4.view.bz.b:int
        v0 = v18;
        v6 = v0.i; // android.support.v4.view.ViewPager.i:int
        if (v5 != v6) /* goto L_0332 */;
        _result = v4.requestFocus(v3); // android.view.View.requestFocus -> boolean
        v4 = _result;
        if (v4 != 0) /* goto L_002f */;
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_0310
        v2 = 0;
        // goto L_0305
        v16 = v6;
        v6 = v2;
        v2 = v16;
        // goto L_0294
        v10 = v2;
        // goto L_0115
        v2 = v6;
        // goto L_0106
        v4 = v3;
        v3 = v2;
        // goto L_0026
    }

    protected void a(int p0, float p1, int p2) {
        // Registers (15 total): v11 = this, v12 = p0 (int), v13 = p1 (float), v14 = p2 (int)
        v3 = 0;
        v0 = v11.V; // android.support.v4.view.ViewPager.V:int
        if (v0 <= 0) /* goto L_0075 */;
        _result = v11.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v5 = _result;
        _result = v11.getPaddingLeft(); // android.support.v4.view.ViewPager.getPaddingLeft -> int
        v1 = _result;
        _result = v11.getPaddingRight(); // android.support.v4.view.ViewPager.getPaddingRight -> int
        v2 = _result;
        _result = v11.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v6 = _result;
        _result = v11.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v7 = _result;
        v4 = v3;
        if (v4 >= v7) /* goto L_0075 */;
        _result = v11.getChildAt(v4); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v8 = _result;
        _result = v8.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        v9 = v0.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v9 != 0) /* goto L_0034 */;
        v10 = v2;
        v2 = v1;
        v1 = v10;
        v0 = binOpLit8_0xd8(v4, 1);
        v4 = v0;
        v10 = v1;
        v1 = v2;
        v2 = v10;
        // goto L_001a
        v0 = v0.b; // android.support.v4.view.ViewPager$LayoutParams.b:int
        v0 = binOpLit8_0xdd(v0, 7);
        // switch(v0)
        v0 = v1;
        v10 = v2;
        v2 = v1;
        v1 = v10;
        v0 = binOp2addr_0xb0(v0, v5);
        _result = v8.getLeft(); // android.view.View.getLeft -> int
        v9 = _result;
        v0 = binOp2addr_0xb1(v0, v9);
        if (v0 == 0) /* goto L_002d */;
        _result = v8.offsetLeftAndRight(v0); // android.view.View.offsetLeftAndRight -> void
        // goto L_002d
        _result = v8.getWidth(); // android.view.View.getWidth -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v10 = v1;
        v1 = v2;
        v2 = v0;
        v0 = v10;
        // goto L_003f
        _result = v8.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v0 = _result;
        v0 = binOp_0x91(v6, v0);
        v0 = binOpLit8_0xdb(v0, 2);
        _result = v0.max(v1); // java.lang.Math.max -> int
        v0 = _result;
        v10 = v2;
        v2 = v1;
        v1 = v10;
        // goto L_003f
        v0 = binOp_0x91(v6, v2);
        _result = v8.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v9 = _result;
        v0 = binOp2addr_0xb1(v0, v9);
        _result = v8.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v9 = _result;
        v2 = binOp2addr_0xb0(v2, v9);
        v10 = v2;
        v2 = v1;
        v1 = v10;
        // goto L_003f
        v0 = v11.W; // android.support.v4.view.ViewPager.W:android.support.v4.view.cc
        if (v0 == 0) /* goto L_007e */;
        v0 = v11.W; // android.support.v4.view.ViewPager.W:android.support.v4.view.cc
        _result = android.support.v4.view.cc.a(v0, v12, v13, v14); // -> void
        v0 = v11.Z; // android.support.v4.view.ViewPager.Z:android.support.v4.view.cc
        if (v0 == 0) /* goto L_0087 */;
        v0 = v11.Z; // android.support.v4.view.ViewPager.Z:android.support.v4.view.cc
        _result = android.support.v4.view.cc.a(v0, v12, v13, v14); // -> void
        v0 = v11.ab; // android.support.v4.view.ViewPager.ab:android.support.v4.view.cd
        if (v0 == 0) /* goto L_00ba */;
        _result = v11.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v2 = _result;
        _result = v11.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v4 = _result;
        v1 = v3;
        if (v1 >= v4) /* goto L_00ba */;
        _result = v11.getChildAt(v1); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v3 = _result;
        _result = v3.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        v0 = v0.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v0 == 0) /* goto L_00a8 */;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0094
        _result = v3.getLeft(); // android.view.View.getLeft -> int
        v0 = _result;
        v0 = binOp2addr_0xb1(v0, v2);
        v0 = unaryOp_0x82(v0);
        _result = v11.j(); // android.support.v4.view.ViewPager.j -> int
        v5 = _result;
        v5 = unaryOp_0x82(v5);
        v0 = binOp2addr_0xc9(v0, v5);
        v5 = v11.ab; // android.support.v4.view.ViewPager.ab:android.support.v4.view.cd
        _result = android.support.v4.view.cd.a(v5, v3, v0); // -> void
        // goto L_00a4
        v0 = 1;
        v11.U = v0; // android.support.v4.view.ViewPager.U:boolean
        return;
    }

    void a(int p0, int p1, int p2) {
        // Registers (13 total): v9 = this, v10 = p0 (int), v11 = p1 (int), v12 = p2 (int)
        v5 = 0;
        v8 = 0x3f800000;
        _result = v9.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v0 = _result;
        if (v0 != 0) /* goto L_000d */;
        _result = v9.e(v5); // android.support.v4.view.ViewPager.e -> void
        return;
        _result = v9.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v1 = _result;
        _result = v9.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v2 = _result;
        v3 = binOp_0x91(v10, v1);
        v4 = binOp_0x91(v11, v2);
        if (v3 != 0) /* goto L_0027 */;
        if (v4 != 0) /* goto L_0027 */;
        _result = v9.b(v5); // android.support.v4.view.ViewPager.b -> void
        _result = v9.e(); // android.support.v4.view.ViewPager.e -> void
        _result = v9.d(v5); // android.support.v4.view.ViewPager.d -> void
        // goto L_000c
        v0 = 1;
        _result = v9.e(v0); // android.support.v4.view.ViewPager.e -> void
        v0 = 2;
        _result = v9.d(v0); // android.support.v4.view.ViewPager.d -> void
        _result = v9.j(); // android.support.v4.view.ViewPager.j -> int
        v0 = _result;
        v5 = binOpLit8_0xdb(v0, 2);
        _result = v3.abs(); // java.lang.Math.abs -> int
        v6 = _result;
        v6 = unaryOp_0x82(v6);
        v6 = binOp2addr_0xc8(v6, v8);
        v7 = unaryOp_0x82(v0);
        v6 = binOp2addr_0xc9(v6, v7);
        _result = v8.min(v6); // java.lang.Math.min -> float
        v6 = _result;
        v7 = unaryOp_0x82(v5);
        v5 = unaryOp_0x82(v5);
        _result = v9.a(v6); // android.support.v4.view.ViewPager.a -> float
        v6 = _result;
        v5 = binOp2addr_0xc8(v5, v6);
        v5 = binOp2addr_0xc6(v5, v7);
        _result = v12.abs(); // java.lang.Math.abs -> int
        v6 = _result;
        if (v6 <= 0) /* goto L_006d */;
        v0 = 0x447a0000;
        v6 = unaryOp_0x82(v6);
        v5 = binOp2addr_0xc9(v5, v6);
        _result = v5.abs(); // java.lang.Math.abs -> float
        v5 = _result;
        v0 = binOp2addr_0xc8(v0, v5);
        _result = v0.round(); // java.lang.Math.round -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 4);
        v5 = 600;
        _result = v0.min(v5); // java.lang.Math.min -> int
        v5 = _result;
        v0 = v9.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v0.startScroll(v0..v5); // android.widget.Scroller.startScroll -> void
        _result = v9.b(); // android.support.v4.view.at.b -> void
        // goto L_000c
        v0 = unaryOp_0x82(v0);
        v5 = v9.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v6 = v9.i; // android.support.v4.view.ViewPager.i:int
        _result = v5.d(v6); // android.support.v4.view.ae.d -> float
        v5 = _result;
        v0 = binOp2addr_0xc8(v0, v5);
        _result = v3.abs(); // java.lang.Math.abs -> int
        v5 = _result;
        v5 = unaryOp_0x82(v5);
        v6 = v9.o; // android.support.v4.view.ViewPager.o:int
        v6 = unaryOp_0x82(v6);
        v0 = binOp2addr_0xc6(v0, v6);
        v0 = binOp_0xa9(v5, v0);
        v0 = binOp2addr_0xc6(v0, v8);
        v5 = 0x42c80000;
        v0 = binOp2addr_0xc8(v0, v5);
        v0 = unaryOp_0x87(v0);
        // goto L_005e
    }

    void a(int p0, boolean p1, boolean p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (boolean), v4 = p2 (boolean)
        v0 = 0;
        _result = v1.a(v2, v3, v4, v0); // android.support.v4.view.ViewPager.a -> void
        return;
    }

    void a(int p0, boolean p1, boolean p2, int p3) {
        // Registers (9 total): v4 = this, v5 = p0 (int), v6 = p1 (boolean), v7 = p2 (boolean), v8 = p3 (int)
        v3 = 1;
        v1 = 0;
        v0 = v4.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        if (v0 == 0) /* goto L_000e */;
        v0 = v4.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v0.b(); // android.support.v4.view.ae.b -> int
        v0 = _result;
        if (v0 > 0) /* goto L_0012 */;
        _result = v4.e(v1); // android.support.v4.view.ViewPager.e -> void
        return;
        if (v7 != 0) /* goto L_0024 */;
        v0 = v4.i; // android.support.v4.view.ViewPager.i:int
        if (v0 != v5) /* goto L_0024 */;
        v0 = v4.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0024 */;
        _result = v4.e(v1); // android.support.v4.view.ViewPager.e -> void
        // goto L_0011
        if (v5 >= 0) /* goto L_004b */;
        v5 = v1;
        v0 = v4.z; // android.support.v4.view.ViewPager.z:int
        v2 = v4.i; // android.support.v4.view.ViewPager.i:int
        v2 = binOp2addr_0xb0(v2, v0);
        if (v5 > v2) /* goto L_0034 */;
        v2 = v4.i; // android.support.v4.view.ViewPager.i:int
        v0 = binOp_0x91(v2, v0);
        if (v5 >= v0) /* goto L_005c */;
        v2 = v1;
        v0 = v4.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v2 >= v0) /* goto L_005c */;
        v0 = v4.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v0.c = v3; // android.support.v4.view.bz.c:boolean
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0035
        v0 = v4.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v0.b(); // android.support.v4.view.ae.b -> int
        v0 = _result;
        if (v5 < v0) /* goto L_0027 */;
        v0 = v4.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v0.b(); // android.support.v4.view.ae.b -> int
        v0 = _result;
        v5 = binOpLit8_0xd8(v0, -1);
        // goto L_0027
        v0 = v4.i; // android.support.v4.view.ViewPager.i:int
        if (v0 == v5) /* goto L_0061 */;
        v1 = v3;
        v0 = v4.S; // android.support.v4.view.ViewPager.S:boolean
        if (v0 == 0) /* goto L_0081 */;
        v4.i = v5; // android.support.v4.view.ViewPager.i:int
        if (v1 == 0) /* goto L_0072 */;
        v0 = v4.W; // android.support.v4.view.ViewPager.W:android.support.v4.view.cc
        if (v0 == 0) /* goto L_0072 */;
        v0 = v4.W; // android.support.v4.view.ViewPager.W:android.support.v4.view.cc
        _result = android.support.v4.view.cc.a(v0, v5); // -> void
        if (v1 == 0) /* goto L_007d */;
        v0 = v4.Z; // android.support.v4.view.ViewPager.Z:android.support.v4.view.cc
        if (v0 == 0) /* goto L_007d */;
        v0 = v4.Z; // android.support.v4.view.ViewPager.Z:android.support.v4.view.cc
        _result = android.support.v4.view.cc.a(v0, v5); // -> void
        _result = v4.requestLayout(); // android.support.v4.view.ViewPager.requestLayout -> void
        // goto L_0011
        _result = v4.a(v5); // android.support.v4.view.ViewPager.a -> void
        _result = v4.a(v5, v6, v8, v1); // android.support.v4.view.ViewPager.a -> void
        // goto L_0011
    }

    void a(android.support.v4.view.cb p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.cb)
        v0.aa = v1; // android.support.v4.view.ViewPager.aa:android.support.v4.view.cb
        return;
    }

    void a(boolean p0) {
        // Registers (7 total): v5 = this, v6 = p0 (boolean)
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 7;
        if (v0 < v1) /* goto L_002b */;
        v0 = v5.ac; // android.support.v4.view.ViewPager.ac:java.lang.reflect.Method
        if (v0 != 0) /* goto L_001c */;
        v0 = android.view.ViewGroup.class;
        v1 = "setChildrenDrawingOrderEnabled";
        v2 = 1;
        v2 = new java.lang.Class[][size=v2];
        v3 = 0;
        v4 = java.lang.Boolean.TYPE; // :java.lang.Class
        v2[v3] = v4;
        _result = v0.getDeclaredMethod(v1, v2); // java.lang.Class.getDeclaredMethod -> java.lang.reflect.Method
        v0 = _result;
        v5.ac = v0; // android.support.v4.view.ViewPager.ac:java.lang.reflect.Method
        v0 = v5.ac; // android.support.v4.view.ViewPager.ac:java.lang.reflect.Method
        v1 = 1;
        v1 = new java.lang.Object[][size=v1];
        v2 = 0;
        _result = v6.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v3 = _result;
        v1[v2] = v3;
        _result = v0.invoke(v5, v1); // java.lang.reflect.Method.invoke -> java.lang.Object
        return;
        v0 = _exception;
        v1 = "ViewPager";
        v2 = "Can't find setChildrenDrawingOrderEnabled";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_001c
        v0 = _exception;
        v1 = "ViewPager";
        v2 = "Error changing children drawing order";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_002b
    }

    public boolean a(android.view.KeyEvent p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.view.KeyEvent)
        v3 = 1;
        v0 = 0;
        _result = v5.getAction(); // android.view.KeyEvent.getAction -> int
        v1 = _result;
        if (v1 != 0) /* goto L_000f */;
        _result = v5.getKeyCode(); // android.view.KeyEvent.getKeyCode -> int
        v1 = _result;
        // switch(v1)
        return v0;
        v0 = 17;
        _result = v4.c(v0); // android.support.v4.view.ViewPager.c -> boolean
        v0 = _result;
        // goto L_000f
        v0 = 66;
        _result = v4.c(v0); // android.support.v4.view.ViewPager.c -> boolean
        v0 = _result;
        // goto L_000f
        v1 = android.os.Build$VERSION.SDK_INT; // :int
        v2 = 11;
        if (v1 < v2) /* goto L_000f */;
        _result = v5.a(); // android.support.v4.view.s.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0030 */;
        v0 = 2;
        _result = v4.c(v0); // android.support.v4.view.ViewPager.c -> boolean
        v0 = _result;
        // goto L_000f
        _result = v5.a(v3); // android.support.v4.view.s.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_000f */;
        _result = v4.c(v3); // android.support.v4.view.ViewPager.c -> boolean
        v0 = _result;
        // goto L_000f
    }

    protected boolean a(android.view.View p0, boolean p1, int p2, int p3, int p4) {
        // Registers (16 total): v10 = this, v11 = p0 (android.view.View), v12 = p1 (boolean), v13 = p2 (int), v14 = p3 (int), v15 = p4 (int)
        v2 = 1;
        v0 = (v11 instanceof android.view.ViewGroup);
        if (v0 == 0) /* goto L_005a */;
        v6 = v11;
        v6 = (android.view.ViewGroup) v6;
        _result = v11.getScrollX(); // android.view.View.getScrollX -> int
        v8 = _result;
        _result = v11.getScrollY(); // android.view.View.getScrollY -> int
        v9 = _result;
        _result = v6.getChildCount(); // android.view.ViewGroup.getChildCount -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v7 = v0;
        if (v7 < 0) /* goto L_005a */;
        _result = v6.getChildAt(v7); // android.view.ViewGroup.getChildAt -> android.view.View
        v1 = _result;
        v0 = binOp_0x90(v14, v8);
        _result = v1.getLeft(); // android.view.View.getLeft -> int
        v3 = _result;
        if (v0 < v3) /* goto L_0056 */;
        v0 = binOp_0x90(v14, v8);
        _result = v1.getRight(); // android.view.View.getRight -> int
        v3 = _result;
        if (v0 >= v3) /* goto L_0056 */;
        v0 = binOp_0x90(v15, v9);
        _result = v1.getTop(); // android.view.View.getTop -> int
        v3 = _result;
        if (v0 < v3) /* goto L_0056 */;
        v0 = binOp_0x90(v15, v9);
        _result = v1.getBottom(); // android.view.View.getBottom -> int
        v3 = _result;
        if (v0 >= v3) /* goto L_0056 */;
        v0 = binOp_0x90(v14, v8);
        _result = v1.getLeft(); // android.view.View.getLeft -> int
        v3 = _result;
        v4 = binOp_0x91(v0, v3);
        v0 = binOp_0x90(v15, v9);
        _result = v1.getTop(); // android.view.View.getTop -> int
        v3 = _result;
        v5 = binOp_0x91(v0, v3);
        v0 = v10;
        v3 = v13;
        _result = v0.a(v0..v5); // android.support.v4.view.ViewPager.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0056 */;
        return v2;
        v0 = binOpLit8_0xd8(v7, -1);
        v7 = v0;
        // goto L_0017
        if (v12 == 0) /* goto L_0063 */;
        v0 = unaryOp_0x7b(v13);
        _result = v11.a(v0); // android.support.v4.view.at.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0055 */;
        v2 = 0;
        // goto L_0055
    }

    public void addFocusables(java.util.ArrayList p0, int p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (java.util.ArrayList), v8 = p1 (int), v9 = p2 (int)
        _result = v7.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        _result = v6.getDescendantFocusability(); // android.support.v4.view.ViewPager.getDescendantFocusability -> int
        v2 = _result;
        v0 = 0x00060000;
        if (v2 == v0) /* goto L_002f */;
        v0 = 0;
        _result = v6.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v3 = _result;
        if (v0 >= v3) /* goto L_002f */;
        _result = v6.getChildAt(v0); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v3 = _result;
        _result = v3.getVisibility(); // android.view.View.getVisibility -> int
        v4 = _result;
        if (v4 != 0) /* goto L_002c */;
        _result = v6.a(v3); // android.support.v4.view.ViewPager.a -> android.support.v4.view.bz
        v4 = _result;
        if (v4 == 0) /* goto L_002c */;
        v4 = v4.b; // android.support.v4.view.bz.b:int
        v5 = v6.i; // android.support.v4.view.ViewPager.i:int
        if (v4 != v5) /* goto L_002c */;
        _result = v3.addFocusables(v7, v8, v9); // android.view.View.addFocusables -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_000d
        v0 = 0x00040000;
        if (v2 != v0) /* goto L_0039 */;
        _result = v7.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 != v0) /* goto L_003f */;
        _result = v6.isFocusable(); // android.support.v4.view.ViewPager.isFocusable -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0040 */;
        return;
        v0 = binOpLit8_0xdd(v9, 1);
        v1 = 1;
        if (v0 != v1) /* goto L_0051 */;
        _result = v6.isInTouchMode(); // android.support.v4.view.ViewPager.isInTouchMode -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0051 */;
        _result = v6.isFocusableInTouchMode(); // android.support.v4.view.ViewPager.isFocusableInTouchMode -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003f */;
        if (v7 == 0) /* goto L_003f */;
        _result = v7.add(v6); // java.util.ArrayList.add -> boolean
        // goto L_003f
    }

    public void addTouchables(java.util.ArrayList p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.util.ArrayList)
        v0 = 0;
        _result = v4.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v1 = _result;
        if (v0 >= v1) /* goto L_0023 */;
        _result = v4.getChildAt(v0); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v1 = _result;
        _result = v1.getVisibility(); // android.view.View.getVisibility -> int
        v2 = _result;
        if (v2 != 0) /* goto L_0020 */;
        _result = v4.a(v1); // android.support.v4.view.ViewPager.a -> android.support.v4.view.bz
        v2 = _result;
        if (v2 == 0) /* goto L_0020 */;
        v2 = v2.b; // android.support.v4.view.bz.b:int
        v3 = v4.i; // android.support.v4.view.ViewPager.i:int
        if (v2 != v3) /* goto L_0020 */;
        _result = v1.addTouchables(v5); // android.view.View.addTouchables -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0001
        return;
    }

    public void addView(android.view.View p0, int p1, android.view.ViewGroup$LayoutParams p2) {
        // Registers (8 total): v4 = this, v5 = p0 (android.view.View), v6 = p1 (int), v7 = p2 (android.view.ViewGroup$LayoutParams)
        _result = v4.checkLayoutParams(v7); // android.support.v4.view.ViewPager.checkLayoutParams -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0032 */;
        _result = v4.generateLayoutParams(v7); // android.support.v4.view.ViewPager.generateLayoutParams -> android.view.ViewGroup$LayoutParams
        v1 = _result;
        v0 = v1;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        v2 = v0.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        v3 = (v5 instanceof android.support.v4.view.by);
        v2 = binOp2addr_0xb6(v2, v3);
        v0.a = v2; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        v2 = v4.w; // android.support.v4.view.ViewPager.w:boolean
        if (v2 == 0) /* goto L_002e */;
        if (v0 == 0) /* goto L_0027 */;
        v2 = v0.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v2 == 0) /* goto L_0027 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Cannot add pager decor view during layout";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v2 = 1;
        v0.d = v2; // android.support.v4.view.ViewPager$LayoutParams.d:boolean
        _result = v4.addViewInLayout(v5, v6, v1); // android.support.v4.view.ViewPager.addViewInLayout -> boolean
        return;
        _result = v4.addView(v5, v6, v1); // android.view.ViewGroup.addView -> void
        // goto L_002d
        v1 = v7;
        // goto L_000a
    }

    public android.support.v4.view.ae b() {
        // Registers (2 total): v1 = this
        v0 = v1.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        return v0;
    }

    android.support.v4.view.bz b(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = 0;
        v1 = v0;
        v0 = v3.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001b */;
        v0 = v3.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v2 = v0.b; // android.support.v4.view.bz.b:int
        if (v2 != v4) /* goto L_0017 */;
        return v0;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0002
        v0 = 0;
        // goto L_0016
    }

    android.support.v4.view.bz b(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        _result = v3.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v0 = _result;
        if (v0 == v2) /* goto L_0012 */;
        if (v0 == 0) /* goto L_000c */;
        v1 = (v0 instanceof android.view.View);
        if (v1 != 0) /* goto L_000e */;
        v0 = 0;
        return v0;
        v0 = (android.view.View) v0;
        v3 = v0;
        // goto L_0000
        _result = v2.a(v3); // android.support.v4.view.ViewPager.a -> android.support.v4.view.bz
        v0 = _result;
        // goto L_000d
    }

    public int c() {
        // Registers (2 total): v1 = this
        v0 = v1.i; // android.support.v4.view.ViewPager.i:int
        return v0;
    }

    public boolean c(int p0) {
        // Registers (11 total): v9 = this, v10 = p0 (int)
        v1 = 0;
        v8 = 66;
        v7 = 17;
        v4 = 1;
        v3 = 0;
        _result = v9.findFocus(); // android.support.v4.view.ViewPager.findFocus -> android.view.View
        v2 = _result;
        if (v2 != v9) /* goto L_003e */;
        v0 = v1;
        _result = this.getInstance(); // android.view.FocusFinder.getInstance -> android.view.FocusFinder
        v1 = _result;
        _result = v1.findNextFocus(v9, v0, v10); // android.view.FocusFinder.findNextFocus -> android.view.View
        v1 = _result;
        if (v1 == 0) /* goto L_00c9 */;
        if (v1 == v0) /* goto L_00c9 */;
        if (v10 != v7) /* goto L_00a7 */;
        v2 = v9.g; // android.support.v4.view.ViewPager.g:android.graphics.Rect
        _result = v9.a(v2, v1); // android.support.v4.view.ViewPager.a -> android.graphics.Rect
        v2 = _result;
        v2 = v2.left; // android.graphics.Rect.left:int
        v3 = v9.g; // android.support.v4.view.ViewPager.g:android.graphics.Rect
        _result = v9.a(v3, v0); // android.support.v4.view.ViewPager.a -> android.graphics.Rect
        v3 = _result;
        v3 = v3.left; // android.graphics.Rect.left:int
        if (v0 == 0) /* goto L_00a2 */;
        if (v2 < v3) /* goto L_00a2 */;
        _result = v9.f(); // android.support.v4.view.ViewPager.f -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003d */;
        _result = v10.getContantForFocusDirection(); // android.view.SoundEffectConstants.getContantForFocusDirection -> int
        v1 = _result;
        _result = v9.playSoundEffect(v1); // android.support.v4.view.ViewPager.playSoundEffect -> void
        return v0;
        if (v2 == 0) /* goto L_00e1 */;
        _result = v2.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v0 = _result;
        v5 = (v0 instanceof android.view.ViewGroup);
        if (v5 == 0) /* goto L_00e4 */;
        if (v0 != v9) /* goto L_007c */;
        v0 = v4;
        if (v0 != 0) /* goto L_00e1 */;
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v0 = _result;
        _result = v5.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v2.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v0 = _result;
        v2 = (v0 instanceof android.view.ViewGroup);
        if (v2 == 0) /* goto L_0081 */;
        v2 = " => ";
        _result = v5.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v0.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v6 = _result;
        _result = v6.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v6 = _result;
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = android.view.ViewParent.getParent(v0); // -> android.view.ViewParent
        v0 = _result;
        // goto L_0061
        _result = android.view.ViewParent.getParent(v0); // -> android.view.ViewParent
        v0 = _result;
        // goto L_0044
        v0 = "ViewPager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "arrowScroll tried to find focus based on non-child current focused view ";
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v5.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v5 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v0.e(v2); // android.util.Log.e -> int
        v0 = v1;
        // goto L_000e
        _result = v1.requestFocus(); // android.view.View.requestFocus -> boolean
        v0 = _result;
        // goto L_0034
        if (v10 != v8) /* goto L_00de */;
        v2 = v9.g; // android.support.v4.view.ViewPager.g:android.graphics.Rect
        _result = v9.a(v2, v1); // android.support.v4.view.ViewPager.a -> android.graphics.Rect
        v2 = _result;
        v2 = v2.left; // android.graphics.Rect.left:int
        v3 = v9.g; // android.support.v4.view.ViewPager.g:android.graphics.Rect
        _result = v9.a(v3, v0); // android.support.v4.view.ViewPager.a -> android.graphics.Rect
        v3 = _result;
        v3 = v3.left; // android.graphics.Rect.left:int
        if (v0 == 0) /* goto L_00c3 */;
        if (v2 > v3) /* goto L_00c3 */;
        _result = v9.g(); // android.support.v4.view.ViewPager.g -> boolean
        v0 = _result;
        // goto L_0034
        _result = v1.requestFocus(); // android.view.View.requestFocus -> boolean
        v0 = _result;
        // goto L_0034
        if (v10 == v7) /* goto L_00cd */;
        if (v10 != v4) /* goto L_00d3 */;
        _result = v9.f(); // android.support.v4.view.ViewPager.f -> boolean
        v0 = _result;
        // goto L_0034
        if (v10 == v8) /* goto L_00d8 */;
        v0 = 2;
        if (v10 != v0) /* goto L_00de */;
        _result = v9.g(); // android.support.v4.view.ViewPager.g -> boolean
        v0 = _result;
        // goto L_0034
        v0 = v3;
        // goto L_0034
        v0 = v2;
        // goto L_000e
        v0 = v3;
        // goto L_004b
    }

    public boolean canScrollHorizontally(int p0) {
        // Registers (7 total): v5 = this, v6 = p0 (int)
        v0 = 1;
        v1 = 0;
        v2 = v5.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        if (v2 != 0) /* goto L_0007 */;
        return v1;
        _result = v5.j(); // android.support.v4.view.ViewPager.j -> int
        v2 = _result;
        _result = v5.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v3 = _result;
        if (v6 >= 0) /* goto L_001c */;
        v2 = unaryOp_0x82(v2);
        v4 = v5.s; // android.support.v4.view.ViewPager.s:float
        v2 = binOp2addr_0xc8(v2, v4);
        v2 = unaryOp_0x87(v2);
        if (v3 <= v2) /* goto L_001a */;
        v1 = v0;
        // goto L_0006
        v0 = v1;
        // goto L_0018
        if (v6 <= 0) /* goto L_0006 */;
        v2 = unaryOp_0x82(v2);
        v4 = v5.t; // android.support.v4.view.ViewPager.t:float
        v2 = binOp2addr_0xc8(v2, v4);
        v2 = unaryOp_0x87(v2);
        if (v3 >= v2) /* goto L_0027 */;
        v1 = v0;
        // goto L_0006
        v0 = v1;
        // goto L_0025
    }

    protected boolean checkLayoutParams(android.view.ViewGroup$LayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$LayoutParams)
        v0 = (v2 instanceof android.support.v4.view.ViewPager$LayoutParams);
        if (v0 == 0) /* goto L_000c */;
        _result = v1.checkLayoutParams(v2); // android.view.ViewGroup.checkLayoutParams -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000b
    }

    public void computeScroll() {
        // Registers (5 total): v4 = this
        v0 = v4.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v0.isFinished(); // android.widget.Scroller.isFinished -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_003e */;
        v0 = v4.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v0.computeScrollOffset(); // android.widget.Scroller.computeScrollOffset -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003e */;
        _result = v4.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v0 = _result;
        _result = v4.getScrollY(); // android.support.v4.view.ViewPager.getScrollY -> int
        v1 = _result;
        v2 = v4.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v2.getCurrX(); // android.widget.Scroller.getCurrX -> int
        v2 = _result;
        v3 = v4.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v3.getCurrY(); // android.widget.Scroller.getCurrY -> int
        v3 = _result;
        if (v0 != v2) /* goto L_0028 */;
        if (v1 == v3) /* goto L_003a */;
        _result = v4.scrollTo(v2, v3); // android.support.v4.view.ViewPager.scrollTo -> void
        _result = v4.e(v2); // android.support.v4.view.ViewPager.e -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_003a */;
        v0 = v4.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v0.abortAnimation(); // android.widget.Scroller.abortAnimation -> void
        v0 = 0;
        _result = v4.scrollTo(v0, v3); // android.support.v4.view.ViewPager.scrollTo -> void
        _result = v4.b(); // android.support.v4.view.at.b -> void
        return;
        v0 = 1;
        _result = v4.b(v0); // android.support.v4.view.ViewPager.b -> void
        // goto L_003d
    }

    void d() {
        // Registers (11 total): v10 = this
        v1 = 1;
        v2 = 0;
        v0 = v10.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v0.b(); // android.support.v4.view.ae.b -> int
        v8 = _result;
        v10.b = v8; // android.support.v4.view.ViewPager.b:int
        v0 = v10.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v3 = v10.z; // android.support.v4.view.ViewPager.z:int
        v3 = binOpLit8_0xda(v3, 2);
        v3 = binOpLit8_0xd8(v3, 1);
        if (v0 >= v3) /* goto L_004d */;
        v0 = v10.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 >= v8) /* goto L_004d */;
        v0 = v1;
        v3 = v10.i; // android.support.v4.view.ViewPager.i:int
        v4 = v2;
        v5 = v3;
        v6 = v0;
        v3 = v2;
        v0 = v10.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_0093 */;
        v0 = v10.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v7 = v10.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v9 = v0.a; // android.support.v4.view.bz.a:java.lang.Object
        _result = v7.a(v9); // android.support.v4.view.ae.a -> int
        v7 = _result;
        v9 = -1;
        if (v7 != v9) /* goto L_004f */;
        v0 = v3;
        v3 = v4;
        v4 = v5;
        v5 = v6;
        v0 = binOpLit8_0xd8(v0, 1);
        v6 = v5;
        v5 = v4;
        v4 = v3;
        v3 = v0;
        // goto L_0027
        v0 = v2;
        // goto L_0021
        v9 = -2;
        if (v7 != v9) /* goto L_0081 */;
        v6 = v10.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v6.remove(v3); // java.util.ArrayList.remove -> java.lang.Object
        v3 = binOpLit8_0xd8(v3, -1);
        if (v4 != 0) /* goto L_0061 */;
        v4 = v10.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v4.a(v10); // android.support.v4.view.ae.a -> void
        v4 = v1;
        v6 = v10.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v7 = v0.b; // android.support.v4.view.bz.b:int
        v9 = v0.a; // android.support.v4.view.bz.a:java.lang.Object
        _result = v6.a(v10, v7, v9); // android.support.v4.view.ae.a -> void
        v6 = v10.i; // android.support.v4.view.ViewPager.i:int
        v0 = v0.b; // android.support.v4.view.bz.b:int
        if (v6 != v0) /* goto L_00cc */;
        v0 = v10.i; // android.support.v4.view.ViewPager.i:int
        v5 = binOpLit8_0xd8(v8, -1);
        _result = v0.min(v5); // java.lang.Math.min -> int
        v0 = _result;
        _result = v2.max(v0); // java.lang.Math.max -> int
        v5 = _result;
        v0 = v3;
        v3 = v4;
        v4 = v5;
        v5 = v1;
        // goto L_0046
        v9 = v0.b; // android.support.v4.view.bz.b:int
        if (v9 == v7) /* goto L_00c6 */;
        v6 = v0.b; // android.support.v4.view.bz.b:int
        v9 = v10.i; // android.support.v4.view.ViewPager.i:int
        if (v6 != v9) /* goto L_008c */;
        v5 = v7;
        v0.b = v7; // android.support.v4.view.bz.b:int
        v0 = v3;
        v3 = v4;
        v4 = v5;
        v5 = v1;
        // goto L_0046
        if (v4 == 0) /* goto L_009a */;
        v0 = v10.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v0.b(v10); // android.support.v4.view.ae.b -> void
        v0 = v10.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        v3 = android.support.v4.view.ViewPager.c; // :java.util.Comparator
        _result = v0.sort(v3); // java.util.Collections.sort -> void
        if (v6 == 0) /* goto L_00c5 */;
        _result = v10.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v4 = _result;
        v3 = v2;
        if (v3 >= v4) /* goto L_00bf */;
        _result = v10.getChildAt(v3); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v0 = _result;
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        v6 = v0.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v6 != 0) /* goto L_00bb */;
        v6 = 0;
        v0.c = v6; // android.support.v4.view.ViewPager$LayoutParams.c:float
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_00a8
        _result = v10.a(v5, v2, v1); // android.support.v4.view.ViewPager.a -> void
        _result = v10.requestLayout(); // android.support.v4.view.ViewPager.requestLayout -> void
        return;
        v0 = v3;
        v3 = v4;
        v4 = v5;
        v5 = v6;
        // goto L_0046
        v0 = v3;
        v3 = v4;
        v4 = v5;
        v5 = v1;
        // goto L_0046
    }

    public boolean dispatchKeyEvent(android.view.KeyEvent p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.KeyEvent)
        _result = v1.dispatchKeyEvent(v2); // android.view.ViewGroup.dispatchKeyEvent -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000c */;
        _result = v1.a(v2); // android.support.v4.view.ViewPager.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000e */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000d
    }

    public boolean dispatchPopulateAccessibilityEvent(android.view.accessibility.AccessibilityEvent p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.view.accessibility.AccessibilityEvent)
        v0 = 0;
        _result = v7.getEventType(); // android.view.accessibility.AccessibilityEvent.getEventType -> int
        v1 = _result;
        v2 = 4096;
        if (v1 != v2) /* goto L_000e */;
        _result = v6.dispatchPopulateAccessibilityEvent(v7); // android.view.ViewGroup.dispatchPopulateAccessibilityEvent -> boolean
        v0 = _result;
        return v0;
        _result = v6.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v2 = _result;
        v1 = v0;
        if (v1 >= v2) /* goto L_000d */;
        _result = v6.getChildAt(v1); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v3 = _result;
        _result = v3.getVisibility(); // android.view.View.getVisibility -> int
        v4 = _result;
        if (v4 != 0) /* goto L_0033 */;
        _result = v6.a(v3); // android.support.v4.view.ViewPager.a -> android.support.v4.view.bz
        v4 = _result;
        if (v4 == 0) /* goto L_0033 */;
        v4 = v4.b; // android.support.v4.view.bz.b:int
        v5 = v6.i; // android.support.v4.view.ViewPager.i:int
        if (v4 != v5) /* goto L_0033 */;
        _result = v3.dispatchPopulateAccessibilityEvent(v7); // android.view.View.dispatchPopulateAccessibilityEvent -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0033 */;
        v0 = 1;
        // goto L_000d
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0013
    }

    public void draw(android.graphics.Canvas p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.graphics.Canvas)
        v2 = 1;
        _result = v7.draw(v8); // android.view.ViewGroup.draw -> void
        v0 = 0;
        _result = v7.a(); // android.support.v4.view.at.a -> int
        v1 = _result;
        if (v1 == 0) /* goto L_0019 */;
        if (v1 != v2) /* goto L_00a2 */;
        v1 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        if (v1 == 0) /* goto L_00a2 */;
        v1 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v1.b(); // android.support.v4.view.ae.b -> int
        v1 = _result;
        if (v1 <= v2) /* goto L_00a2 */;
        v1 = v7.Q; // android.support.v4.view.ViewPager.Q:android.support.v4.widget.n
        _result = v1.a(); // android.support.v4.widget.n.a -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0059 */;
        _result = v8.save(); // android.graphics.Canvas.save -> int
        v1 = _result;
        _result = v7.getHeight(); // android.support.v4.view.ViewPager.getHeight -> int
        v2 = _result;
        _result = v7.getPaddingTop(); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v3 = _result;
        v2 = binOp2addr_0xb1(v2, v3);
        _result = v7.getPaddingBottom(); // android.support.v4.view.ViewPager.getPaddingBottom -> int
        v3 = _result;
        v2 = binOp2addr_0xb1(v2, v3);
        _result = v7.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v3 = _result;
        v4 = 0x43870000;
        _result = v8.rotate(v4); // android.graphics.Canvas.rotate -> void
        v4 = unaryOp_0x7b(v2);
        _result = v7.getPaddingTop(); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v5 = _result;
        v4 = binOp2addr_0xb0(v4, v5);
        v4 = unaryOp_0x82(v4);
        v5 = v7.s; // android.support.v4.view.ViewPager.s:float
        v6 = unaryOp_0x82(v3);
        v5 = binOp2addr_0xc8(v5, v6);
        _result = v8.translate(v4, v5); // android.graphics.Canvas.translate -> void
        v4 = v7.Q; // android.support.v4.view.ViewPager.Q:android.support.v4.widget.n
        _result = v4.a(v2, v3); // android.support.v4.widget.n.a -> void
        v2 = v7.Q; // android.support.v4.view.ViewPager.Q:android.support.v4.widget.n
        _result = v2.a(v8); // android.support.v4.widget.n.a -> boolean
        v2 = _result;
        v0 = binOp2addr_0xb6(v0, v2);
        _result = v8.restoreToCount(v1); // android.graphics.Canvas.restoreToCount -> void
        v1 = v7.R; // android.support.v4.view.ViewPager.R:android.support.v4.widget.n
        _result = v1.a(); // android.support.v4.widget.n.a -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_009c */;
        _result = v8.save(); // android.graphics.Canvas.save -> int
        v1 = _result;
        _result = v7.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v2 = _result;
        _result = v7.getHeight(); // android.support.v4.view.ViewPager.getHeight -> int
        v3 = _result;
        _result = v7.getPaddingTop(); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v4 = _result;
        v3 = binOp2addr_0xb1(v3, v4);
        _result = v7.getPaddingBottom(); // android.support.v4.view.ViewPager.getPaddingBottom -> int
        v4 = _result;
        v3 = binOp2addr_0xb1(v3, v4);
        v4 = 0x42b40000;
        _result = v8.rotate(v4); // android.graphics.Canvas.rotate -> void
        _result = v7.getPaddingTop(); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v4 = _result;
        v4 = unaryOp_0x7b(v4);
        v4 = unaryOp_0x82(v4);
        v5 = v7.t; // android.support.v4.view.ViewPager.t:float
        v6 = 0x3f800000;
        v5 = binOp2addr_0xc6(v5, v6);
        v5 = unaryOp_0x7f(v5);
        v6 = unaryOp_0x82(v2);
        v5 = binOp2addr_0xc8(v5, v6);
        _result = v8.translate(v4, v5); // android.graphics.Canvas.translate -> void
        v4 = v7.R; // android.support.v4.view.ViewPager.R:android.support.v4.widget.n
        _result = v4.a(v3, v2); // android.support.v4.widget.n.a -> void
        v2 = v7.R; // android.support.v4.view.ViewPager.R:android.support.v4.widget.n
        _result = v2.a(v8); // android.support.v4.widget.n.a -> boolean
        v2 = _result;
        v0 = binOp2addr_0xb6(v0, v2);
        _result = v8.restoreToCount(v1); // android.graphics.Canvas.restoreToCount -> void
        if (v0 == 0) /* goto L_00a1 */;
        _result = v7.b(); // android.support.v4.view.at.b -> void
        return;
        v1 = v7.Q; // android.support.v4.view.ViewPager.Q:android.support.v4.widget.n
        _result = v1.b(); // android.support.v4.widget.n.b -> void
        v1 = v7.R; // android.support.v4.view.ViewPager.R:android.support.v4.widget.n
        _result = v1.b(); // android.support.v4.widget.n.b -> void
        // goto L_009c
    }

    protected void drawableStateChanged() {
        // Registers (3 total): v2 = this
        _result = v2.drawableStateChanged(); // android.view.ViewGroup.drawableStateChanged -> void
        v0 = v2.p; // android.support.v4.view.ViewPager.p:android.graphics.drawable.Drawable
        if (v0 == 0) /* goto L_0014 */;
        _result = v0.isStateful(); // android.graphics.drawable.Drawable.isStateful -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0014 */;
        _result = v2.getDrawableState(); // android.support.v4.view.ViewPager.getDrawableState -> int[]
        v1 = _result;
        _result = v0.setState(v1); // android.graphics.drawable.Drawable.setState -> boolean
        return;
    }

    void e() {
        // Registers (2 total): v1 = this
        v0 = v1.i; // android.support.v4.view.ViewPager.i:int
        _result = v1.a(v0); // android.support.v4.view.ViewPager.a -> void
        return;
    }

    boolean f() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = v2.i; // android.support.v4.view.ViewPager.i:int
        if (v1 <= 0) /* goto L_000d */;
        v1 = v2.i; // android.support.v4.view.ViewPager.i:int
        v1 = binOpLit8_0xd8(v1, -1);
        _result = v2.setCurrentItem(v1, v0); // android.support.v4.view.ViewPager.setCurrentItem -> void
        return v0;
        v0 = 0;
        // goto L_000c
    }

    boolean g() {
        // Registers (4 total): v3 = this
        v0 = 1;
        v1 = v3.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        if (v1 == 0) /* goto L_0019 */;
        v1 = v3.i; // android.support.v4.view.ViewPager.i:int
        v2 = v3.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v2.b(); // android.support.v4.view.ae.b -> int
        v2 = _result;
        v2 = binOpLit8_0xd8(v2, -1);
        if (v1 >= v2) /* goto L_0019 */;
        v1 = v3.i; // android.support.v4.view.ViewPager.i:int
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v3.setCurrentItem(v1, v0); // android.support.v4.view.ViewPager.setCurrentItem -> void
        return v0;
        v0 = 0;
        // goto L_0018
    }

    protected android.view.ViewGroup$LayoutParams generateDefaultLayoutParams() {
        // Registers (2 total): v1 = this
        v0 = new android.support.v4.view.ViewPager$LayoutParams;
        _result = v0.<init>(); // android.support.v4.view.ViewPager$LayoutParams.<init> -> void
        return v0;
    }

    public android.view.ViewGroup$LayoutParams generateLayoutParams(android.util.AttributeSet p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.util.AttributeSet)
        v0 = new android.support.v4.view.ViewPager$LayoutParams;
        _result = v2.getContext(); // android.support.v4.view.ViewPager.getContext -> android.content.Context
        v1 = _result;
        _result = v0.<init>(v1, v3); // android.support.v4.view.ViewPager$LayoutParams.<init> -> void
        return v0;
    }

    protected android.view.ViewGroup$LayoutParams generateLayoutParams(android.view.ViewGroup$LayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$LayoutParams)
        _result = v1.generateDefaultLayoutParams(); // android.support.v4.view.ViewPager.generateDefaultLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        return v0;
    }

    protected int getChildDrawingOrder(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v0 = v2.ad; // android.support.v4.view.ViewPager.ad:int
        v1 = 2;
        if (v0 != v1) /* goto L_0009 */;
        v0 = binOpLit8_0xd8(v3, -1);
        v4 = binOp_0x91(v0, v4);
        v0 = v2.ae; // android.support.v4.view.ViewPager.ae:java.util.ArrayList
        _result = v0.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.view.View) v0;
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        v0 = v0.f; // android.support.v4.view.ViewPager$LayoutParams.f:int
        return v0;
    }

    protected void onAttachedToWindow() {
        // Registers (2 total): v1 = this
        _result = v1.onAttachedToWindow(); // android.view.ViewGroup.onAttachedToWindow -> void
        v0 = 1;
        v1.S = v0; // android.support.v4.view.ViewPager.S:boolean
        return;
    }

    protected void onDetachedFromWindow() {
        // Registers (2 total): v1 = this
        v0 = v1.ag; // android.support.v4.view.ViewPager.ag:java.lang.Runnable
        _result = v1.removeCallbacks(v0); // android.support.v4.view.ViewPager.removeCallbacks -> boolean
        _result = v1.onDetachedFromWindow(); // android.view.ViewGroup.onDetachedFromWindow -> void
        return;
    }

    protected void onDraw(android.graphics.Canvas p0) {
        // Registers (18 total): v16 = this, v17 = p0 (android.graphics.Canvas)
        _result = v16.onDraw(v16..v17); // android.view.ViewGroup.onDraw -> void
        v0 = v16;
        v1 = v0.o; // android.support.v4.view.ViewPager.o:int
        if (v1 <= 0) /* goto L_00b2 */;
        v0 = v16;
        v1 = v0.p; // android.support.v4.view.ViewPager.p:android.graphics.drawable.Drawable
        if (v1 == 0) /* goto L_00b2 */;
        v0 = v16;
        v1 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_00b2 */;
        v0 = v16;
        v1 = v0.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        if (v1 == 0) /* goto L_00b2 */;
        _result = v16.getScrollX(v16..v16); // android.support.v4.view.ViewPager.getScrollX -> int
        v6 = _result;
        _result = v16.getWidth(v16..v16); // android.support.v4.view.ViewPager.getWidth -> int
        v7 = _result;
        v0 = v16;
        v1 = v0.o; // android.support.v4.view.ViewPager.o:int
        v1 = unaryOp_0x82(v1);
        v2 = unaryOp_0x82(v7);
        v8 = binOp_0xa9(v1, v2);
        v5 = 0;
        v0 = v16;
        v1 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        v2 = 0;
        _result = v1.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.view.bz) v1;
        v4 = v1.e; // android.support.v4.view.bz.e:float
        v0 = v16;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v2.size(); // java.util.ArrayList.size -> int
        v9 = _result;
        v3 = v1.b; // android.support.v4.view.bz.b:int
        v0 = v16;
        v2 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        v10 = binOpLit8_0xd8(v9, -1);
        _result = v2.get(v10); // java.util.ArrayList.get -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.view.bz) v2;
        v10 = v2.b; // android.support.v4.view.bz.b:int
        v2 = v5;
        v5 = v3;
        if (v5 >= v10) /* goto L_00b2 */;
        v3 = v1.b; // android.support.v4.view.bz.b:int
        if (v5 <= v3) /* goto L_006c */;
        if (v2 >= v9) /* goto L_006c */;
        v0 = v16;
        v1 = v0.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        v2 = binOpLit8_0xd8(v2, 1);
        _result = v1.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.view.bz) v1;
        // goto L_0059
        v3 = v1.b; // android.support.v4.view.bz.b:int
        if (v5 != v3) /* goto L_00b3 */;
        v3 = v1.e; // android.support.v4.view.bz.e:float
        v4 = v1.d; // android.support.v4.view.bz.d:float
        v3 = binOp2addr_0xc6(v3, v4);
        v4 = unaryOp_0x82(v7);
        v3 = binOp2addr_0xc8(v3, v4);
        v4 = v1.e; // android.support.v4.view.bz.e:float
        v11 = v1.d; // android.support.v4.view.bz.d:float
        v4 = binOp2addr_0xc6(v4, v11);
        v4 = binOp2addr_0xc6(v4, v8);
        v0 = v16;
        v11 = v0.o; // android.support.v4.view.ViewPager.o:int
        v11 = unaryOp_0x82(v11);
        v11 = binOp2addr_0xc6(v11, v3);
        v12 = unaryOp_0x82(v6);
        v11 = cmp(v11, v12);
        if (v11 <= 0) /* goto L_00ab */;
        v0 = v16;
        v11 = v0.p; // android.support.v4.view.ViewPager.p:android.graphics.drawable.Drawable
        v12 = unaryOp_0x87(v3);
        v0 = v16;
        v13 = v0.q; // android.support.v4.view.ViewPager.q:int
        v0 = v16;
        v14 = v0.o; // android.support.v4.view.ViewPager.o:int
        v14 = unaryOp_0x82(v14);
        v14 = binOp2addr_0xc6(v14, v3);
        v15 = 0x3f000000;
        v14 = binOp2addr_0xc6(v14, v15);
        v14 = unaryOp_0x87(v14);
        v0 = v16;
        v15 = v0.r; // android.support.v4.view.ViewPager.r:int
        _result = v11.setBounds(v12, v13, v14, v15); // android.graphics.drawable.Drawable.setBounds -> void
        v0 = v16;
        v11 = v0.p; // android.support.v4.view.ViewPager.p:android.graphics.drawable.Drawable
        v0 = v17;
        _result = v11.draw(v0); // android.graphics.drawable.Drawable.draw -> void
        v11 = binOp_0x90(v6, v7);
        v11 = unaryOp_0x82(v11);
        v3 = cmp(v3, v11);
        if (v3 <= 0) /* goto L_00c2 */;
        return;
        v0 = v16;
        v3 = v0.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v3.d(v5); // android.support.v4.view.ae.d -> float
        v11 = _result;
        v3 = binOp_0xa6(v4, v11);
        v12 = unaryOp_0x82(v7);
        v3 = binOp2addr_0xc8(v3, v12);
        v11 = binOp2addr_0xc6(v11, v8);
        v4 = binOp2addr_0xc6(v4, v11);
        // goto L_007d
        v3 = binOpLit8_0xd8(v5, 1);
        v5 = v3;
        // goto L_0057
    }

    public boolean onInterceptTouchEvent(android.view.MotionEvent p0) {
        // Registers (15 total): v13 = this, v14 = p0 (android.view.MotionEvent)
        v3 = -1;
        v12 = 0;
        v6 = 1;
        v2 = 0;
        _result = v14.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        v0 = binOpLit16_0xd5(v0, 255);
        v1 = 3;
        if (v0 == v1) /* goto L_000f */;
        if (v0 != v6) /* goto L_0022 */;
        v13.A = v2; // android.support.v4.view.ViewPager.A:boolean
        v13.B = v2; // android.support.v4.view.ViewPager.B:boolean
        v13.J = v3; // android.support.v4.view.ViewPager.J:int
        v0 = v13.K; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        if (v0 == 0) /* goto L_0021 */;
        v0 = v13.K; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        _result = v0.recycle(); // android.view.VelocityTracker.recycle -> void
        v0 = 0;
        v13.K = v0; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        return v2;
        if (v0 == 0) /* goto L_002e */;
        v1 = v13.A; // android.support.v4.view.ViewPager.A:boolean
        if (v1 == 0) /* goto L_002a */;
        v2 = v6;
        // goto L_0021
        v1 = v13.B; // android.support.v4.view.ViewPager.B:boolean
        if (v1 != 0) /* goto L_0021 */;
        // switch(v0)
        v0 = v13.K; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        if (v0 != 0) /* goto L_003b */;
        _result = this.obtain(); // android.view.VelocityTracker.obtain -> android.view.VelocityTracker
        v0 = _result;
        v13.K = v0; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        v0 = v13.K; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        _result = v0.addMovement(v14); // android.view.VelocityTracker.addMovement -> void
        v2 = v13.A; // android.support.v4.view.ViewPager.A:boolean
        // goto L_0021
        v0 = v13.J; // android.support.v4.view.ViewPager.J:int
        if (v0 == v3) /* goto L_0031 */;
        _result = v14.a(v0); // android.support.v4.view.z.a -> int
        v0 = _result;
        _result = v14.c(v0); // android.support.v4.view.z.c -> float
        v7 = _result;
        v1 = v13.F; // android.support.v4.view.ViewPager.F:float
        v8 = binOp_0xa7(v7, v1);
        _result = v8.abs(); // java.lang.Math.abs -> float
        v9 = _result;
        _result = v14.d(v0); // android.support.v4.view.z.d -> float
        v10 = _result;
        v0 = v13.I; // android.support.v4.view.ViewPager.I:float
        v0 = binOp_0xa7(v10, v0);
        _result = v0.abs(); // java.lang.Math.abs -> float
        v11 = _result;
        v0 = cmp(v8, v12);
        if (v0 == 0) /* goto L_0081 */;
        v0 = v13.F; // android.support.v4.view.ViewPager.F:float
        _result = v13.a(v0, v8); // android.support.v4.view.ViewPager.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0081 */;
        v3 = unaryOp_0x87(v8);
        v4 = unaryOp_0x87(v7);
        v5 = unaryOp_0x87(v10);
        v0 = v13;
        v1 = v13;
        _result = v0.a(v0..v5); // android.support.v4.view.ViewPager.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0081 */;
        v13.F = v7; // android.support.v4.view.ViewPager.F:float
        v13.G = v10; // android.support.v4.view.ViewPager.G:float
        v13.B = v6; // android.support.v4.view.ViewPager.B:boolean
        // goto L_0021
        v0 = v13.E; // android.support.v4.view.ViewPager.E:int
        v0 = unaryOp_0x82(v0);
        v0 = cmp(v9, v0);
        if (v0 <= 0) /* goto L_00be */;
        v0 = 0x3f000000;
        v0 = binOp2addr_0xc8(v0, v9);
        v0 = cmp(v0, v11);
        if (v0 <= 0) /* goto L_00be */;
        v13.A = v6; // android.support.v4.view.ViewPager.A:boolean
        _result = v13.d(v6); // android.support.v4.view.ViewPager.d -> void
        _result = v13.d(v6); // android.support.v4.view.ViewPager.d -> void
        v0 = cmp(v8, v12);
        if (v0 <= 0) /* goto L_00b7 */;
        v0 = v13.H; // android.support.v4.view.ViewPager.H:float
        v1 = v13.E; // android.support.v4.view.ViewPager.E:int
        v1 = unaryOp_0x82(v1);
        v0 = binOp2addr_0xc6(v0, v1);
        v13.F = v0; // android.support.v4.view.ViewPager.F:float
        v13.G = v10; // android.support.v4.view.ViewPager.G:float
        _result = v13.e(v6); // android.support.v4.view.ViewPager.e -> void
        v0 = v13.A; // android.support.v4.view.ViewPager.A:boolean
        if (v0 == 0) /* goto L_0031 */;
        _result = v13.b(v7); // android.support.v4.view.ViewPager.b -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0031 */;
        _result = v13.b(); // android.support.v4.view.at.b -> void
        // goto L_0031
        v0 = v13.H; // android.support.v4.view.ViewPager.H:float
        v1 = v13.E; // android.support.v4.view.ViewPager.E:int
        v1 = unaryOp_0x82(v1);
        v0 = binOp2addr_0xc7(v0, v1);
        // goto L_00a1
        v0 = v13.E; // android.support.v4.view.ViewPager.E:int
        v0 = unaryOp_0x82(v0);
        v0 = cmp(v11, v0);
        if (v0 <= 0) /* goto L_00a8 */;
        v13.B = v6; // android.support.v4.view.ViewPager.B:boolean
        // goto L_00a8
        _result = v14.getX(); // android.view.MotionEvent.getX -> float
        v0 = _result;
        v13.H = v0; // android.support.v4.view.ViewPager.H:float
        v13.F = v0; // android.support.v4.view.ViewPager.F:float
        _result = v14.getY(); // android.view.MotionEvent.getY -> float
        v0 = _result;
        v13.I = v0; // android.support.v4.view.ViewPager.I:float
        v13.G = v0; // android.support.v4.view.ViewPager.G:float
        _result = v14.b(v2); // android.support.v4.view.z.b -> int
        v0 = _result;
        v13.J = v0; // android.support.v4.view.ViewPager.J:int
        v13.B = v2; // android.support.v4.view.ViewPager.B:boolean
        v0 = v13.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v0.computeScrollOffset(); // android.widget.Scroller.computeScrollOffset -> boolean
        v0 = v13.ah; // android.support.v4.view.ViewPager.ah:int
        v1 = 2;
        if (v0 != v1) /* goto L_0113 */;
        v0 = v13.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v0.getFinalX(); // android.widget.Scroller.getFinalX -> int
        v0 = _result;
        v1 = v13.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v1.getCurrX(); // android.widget.Scroller.getCurrX -> int
        v1 = _result;
        v0 = binOp2addr_0xb1(v0, v1);
        _result = v0.abs(); // java.lang.Math.abs -> int
        v0 = _result;
        v1 = v13.O; // android.support.v4.view.ViewPager.O:int
        if (v0 <= v1) /* goto L_0113 */;
        v0 = v13.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v0.abortAnimation(); // android.widget.Scroller.abortAnimation -> void
        v13.y = v2; // android.support.v4.view.ViewPager.y:boolean
        _result = v13.e(); // android.support.v4.view.ViewPager.e -> void
        v13.A = v6; // android.support.v4.view.ViewPager.A:boolean
        _result = v13.d(v6); // android.support.v4.view.ViewPager.d -> void
        _result = v13.d(v6); // android.support.v4.view.ViewPager.d -> void
        // goto L_0031
        _result = v13.b(v2); // android.support.v4.view.ViewPager.b -> void
        v13.A = v2; // android.support.v4.view.ViewPager.A:boolean
        // goto L_0031
        _result = v13.a(v14); // android.support.v4.view.ViewPager.a -> void
        // goto L_0031
    }

    protected void onLayout(boolean p0, int p1, int p2, int p3, int p4) {
        // Registers (23 total): v17 = this, v18 = p0 (boolean), v19 = p1 (int), v20 = p2 (int), v21 = p3 (int), v22 = p4 (int)
        _result = v17.getChildCount(v17..v17); // android.support.v4.view.ViewPager.getChildCount -> int
        v9 = _result;
        v10 = binOp_0x91(v21, v19);
        v11 = binOp_0x91(v22, v20);
        _result = v17.getPaddingLeft(v17..v17); // android.support.v4.view.ViewPager.getPaddingLeft -> int
        v6 = _result;
        _result = v17.getPaddingTop(v17..v17); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v2 = _result;
        _result = v17.getPaddingRight(v17..v17); // android.support.v4.view.ViewPager.getPaddingRight -> int
        v5 = _result;
        _result = v17.getPaddingBottom(v17..v17); // android.support.v4.view.ViewPager.getPaddingBottom -> int
        v3 = _result;
        _result = v17.getScrollX(v17..v17); // android.support.v4.view.ViewPager.getScrollX -> int
        v12 = _result;
        v4 = 0;
        v1 = 0;
        v8 = v1;
        if (v8 >= v9) /* goto L_00be */;
        v0 = v17;
        _result = v0.getChildAt(v8); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v13 = _result;
        _result = v13.getVisibility(); // android.view.View.getVisibility -> int
        v1 = _result;
        v7 = 8;
        if (v1 == v7) /* goto L_0141 */;
        _result = v13.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v1 = _result;
        v1 = (android.support.v4.view.ViewPager$LayoutParams) v1;
        v7 = v1.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v7 == 0) /* goto L_0141 */;
        v7 = v1.b; // android.support.v4.view.ViewPager$LayoutParams.b:int
        v7 = binOpLit8_0xdd(v7, 7);
        v1 = v1.b; // android.support.v4.view.ViewPager$LayoutParams.b:int
        v14 = binOpLit8_0xdd(v1, 112);
        // switch(v7)
        v7 = v6;
        // switch(v14)
        v1 = v2;
        v16 = v3;
        v3 = v2;
        v2 = v16;
        v7 = binOp2addr_0xb0(v7, v12);
        _result = v13.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v14 = _result;
        v14 = binOp2addr_0xb0(v14, v7);
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v15 = _result;
        v15 = binOp2addr_0xb0(v15, v1);
        _result = v13.layout(v7, v1, v14, v15); // android.view.View.layout -> void
        v1 = binOpLit8_0xd8(v4, 1);
        v4 = v3;
        v3 = v2;
        v2 = v5;
        v5 = v6;
        v6 = binOpLit8_0xd8(v8, 1);
        v8 = v6;
        v6 = v5;
        v5 = v2;
        v2 = v4;
        v4 = v1;
        // goto L_001f
        _result = v13.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v1 = _result;
        v1 = binOp2addr_0xb0(v1, v6);
        v7 = v6;
        v6 = v1;
        // goto L_0045
        _result = v13.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v1 = _result;
        v1 = binOp_0x91(v10, v1);
        v1 = binOpLit8_0xdb(v1, 2);
        _result = v1.max(v6); // java.lang.Math.max -> int
        v1 = _result;
        v7 = v1;
        // goto L_0045
        v1 = binOp_0x91(v10, v5);
        _result = v13.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v7 = _result;
        v1 = binOp2addr_0xb1(v1, v7);
        _result = v13.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v7 = _result;
        v5 = binOp2addr_0xb0(v5, v7);
        v7 = v1;
        // goto L_0045
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v1 = _result;
        v1 = binOp2addr_0xb0(v1, v2);
        v16 = v2;
        v2 = v3;
        v3 = v1;
        v1 = v16;
        // goto L_004e
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v1 = _result;
        v1 = binOp_0x91(v11, v1);
        v1 = binOpLit8_0xdb(v1, 2);
        _result = v1.max(v2); // java.lang.Math.max -> int
        v1 = _result;
        v16 = v3;
        v3 = v2;
        v2 = v16;
        // goto L_004e
        v1 = binOp_0x91(v11, v3);
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v14 = _result;
        v1 = binOp2addr_0xb1(v1, v14);
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v14 = _result;
        v3 = binOp2addr_0xb0(v3, v14);
        v16 = v3;
        v3 = v2;
        v2 = v16;
        // goto L_004e
        v1 = binOp_0x91(v10, v6);
        v7 = binOp_0x91(v1, v5);
        v1 = 0;
        v5 = v1;
        if (v5 >= v9) /* goto L_011b */;
        v0 = v17;
        _result = v0.getChildAt(v5); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v8 = _result;
        _result = v8.getVisibility(); // android.view.View.getVisibility -> int
        v1 = _result;
        v10 = 8;
        if (v1 == v10) /* goto L_0117 */;
        _result = v8.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v1 = _result;
        v1 = (android.support.v4.view.ViewPager$LayoutParams) v1;
        v10 = v1.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v10 != 0) /* goto L_0117 */;
        v0 = v17;
        _result = v0.a(v8); // android.support.v4.view.ViewPager.a -> android.support.v4.view.bz
        v10 = _result;
        if (v10 == 0) /* goto L_0117 */;
        v12 = unaryOp_0x82(v7);
        v10 = v10.e; // android.support.v4.view.bz.e:float
        v10 = binOp2addr_0xc8(v10, v12);
        v10 = unaryOp_0x87(v10);
        v10 = binOp2addr_0xb0(v10, v6);
        v12 = v1.d; // android.support.v4.view.ViewPager$LayoutParams.d:boolean
        if (v12 == 0) /* goto L_010a */;
        v12 = 0;
        v1.d = v12; // android.support.v4.view.ViewPager$LayoutParams.d:boolean
        v12 = unaryOp_0x82(v7);
        v1 = v1.c; // android.support.v4.view.ViewPager$LayoutParams.c:float
        v1 = binOp2addr_0xc8(v1, v12);
        v1 = unaryOp_0x87(v1);
        v12 = 0x40000000;
        _result = v1.makeMeasureSpec(v12); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v1 = _result;
        v12 = binOp_0x91(v11, v2);
        v12 = binOp2addr_0xb1(v12, v3);
        v13 = 0x40000000;
        _result = v12.makeMeasureSpec(v13); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v12 = _result;
        _result = v8.measure(v1, v12); // android.view.View.measure -> void
        _result = v8.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v1 = _result;
        v1 = binOp2addr_0xb0(v1, v10);
        _result = v8.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v12 = _result;
        v12 = binOp2addr_0xb0(v12, v2);
        _result = v8.layout(v10, v2, v1, v12); // android.view.View.layout -> void
        v1 = binOpLit8_0xd8(v5, 1);
        v5 = v1;
        // goto L_00c4
        v0 = v17;
        v0.q = v2; // android.support.v4.view.ViewPager.q:int
        v1 = binOp_0x91(v11, v3);
        v0 = v17;
        v0.r = v1; // android.support.v4.view.ViewPager.r:int
        v0 = v17;
        v0.V = v4; // android.support.v4.view.ViewPager.V:int
        v0 = v17;
        v1 = v0.S; // android.support.v4.view.ViewPager.S:boolean
        if (v1 == 0) /* goto L_013b */;
        v0 = v17;
        v1 = v0.i; // android.support.v4.view.ViewPager.i:int
        v2 = 0;
        v3 = 0;
        v4 = 0;
        v0 = v17;
        _result = v0.a(v1, v2, v3, v4); // android.support.v4.view.ViewPager.a -> void
        v1 = 0;
        v0 = v17;
        v0.S = v1; // android.support.v4.view.ViewPager.S:boolean
        return;
        v1 = v4;
        v4 = v2;
        v2 = v5;
        v5 = v6;
        // goto L_0062
    }

    protected void onMeasure(int p0, int p1) {
        // Registers (16 total): v13 = this, v14 = p0 (int), v15 = p1 (int)
        v0 = 0;
        _result = v0.getDefaultSize(v14); // android.support.v4.view.ViewPager.getDefaultSize -> int
        v0 = _result;
        v1 = 0;
        _result = v1.getDefaultSize(v15); // android.support.v4.view.ViewPager.getDefaultSize -> int
        v1 = _result;
        _result = v13.setMeasuredDimension(v0, v1); // android.support.v4.view.ViewPager.setMeasuredDimension -> void
        _result = v13.getMeasuredWidth(); // android.support.v4.view.ViewPager.getMeasuredWidth -> int
        v0 = _result;
        v1 = binOpLit8_0xdb(v0, 10);
        v2 = v13.C; // android.support.v4.view.ViewPager.C:int
        _result = v1.min(v2); // java.lang.Math.min -> int
        v1 = _result;
        v13.D = v1; // android.support.v4.view.ViewPager.D:int
        _result = v13.getPaddingLeft(); // android.support.v4.view.ViewPager.getPaddingLeft -> int
        v1 = _result;
        v0 = binOp2addr_0xb1(v0, v1);
        _result = v13.getPaddingRight(); // android.support.v4.view.ViewPager.getPaddingRight -> int
        v1 = _result;
        v3 = binOp_0x91(v0, v1);
        _result = v13.getMeasuredHeight(); // android.support.v4.view.ViewPager.getMeasuredHeight -> int
        v0 = _result;
        _result = v13.getPaddingTop(); // android.support.v4.view.ViewPager.getPaddingTop -> int
        v1 = _result;
        v0 = binOp2addr_0xb1(v0, v1);
        _result = v13.getPaddingBottom(); // android.support.v4.view.ViewPager.getPaddingBottom -> int
        v1 = _result;
        v5 = binOp_0x91(v0, v1);
        _result = v13.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v9 = _result;
        v0 = 0;
        v8 = v0;
        if (v8 >= v9) /* goto L_00bc */;
        _result = v13.getChildAt(v8); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v10 = _result;
        _result = v10.getVisibility(); // android.view.View.getVisibility -> int
        v0 = _result;
        v1 = 8;
        if (v0 == v1) /* goto L_00a5 */;
        _result = v10.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        if (v0 == 0) /* goto L_00a5 */;
        v1 = v0.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v1 == 0) /* goto L_00a5 */;
        v1 = v0.b; // android.support.v4.view.ViewPager$LayoutParams.b:int
        v6 = binOpLit8_0xdd(v1, 7);
        v1 = v0.b; // android.support.v4.view.ViewPager$LayoutParams.b:int
        v4 = binOpLit8_0xdd(v1, 112);
        v2 = 0x80000000;
        v1 = 0x80000000;
        v7 = 48;
        if (v4 == v7) /* goto L_0069 */;
        v7 = 80;
        if (v4 != v7) /* goto L_00a9 */;
        v4 = 1;
        v7 = v4;
        v4 = 3;
        if (v6 == v4) /* goto L_0071 */;
        v4 = 5;
        if (v6 != v4) /* goto L_00ac */;
        v4 = 1;
        v6 = v4;
        if (v7 == 0) /* goto L_00af */;
        v2 = 0x40000000;
        v4 = v0.width; // android.support.v4.view.ViewPager$LayoutParams.width:int
        v11 = -2;
        if (v4 == v11) /* goto L_010f */;
        v4 = 0x40000000;
        v2 = v0.width; // android.support.v4.view.ViewPager$LayoutParams.width:int
        v11 = -1;
        if (v2 == v11) /* goto L_010c */;
        v2 = v0.width; // android.support.v4.view.ViewPager$LayoutParams.width:int
        v11 = v0.height; // android.support.v4.view.ViewPager$LayoutParams.height:int
        v12 = -2;
        if (v11 == v12) /* goto L_010a */;
        v1 = 0x40000000;
        v11 = v0.height; // android.support.v4.view.ViewPager$LayoutParams.height:int
        v12 = -1;
        if (v11 == v12) /* goto L_010a */;
        v0 = v0.height; // android.support.v4.view.ViewPager$LayoutParams.height:int
        _result = v2.makeMeasureSpec(v4); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v2 = _result;
        _result = v0.makeMeasureSpec(v1); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        _result = v10.measure(v2, v0); // android.view.View.measure -> void
        if (v7 == 0) /* goto L_00b4 */;
        _result = v10.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v0 = _result;
        v5 = binOp2addr_0xb1(v5, v0);
        v0 = binOpLit8_0xd8(v8, 1);
        v8 = v0;
        // goto L_003b
        v4 = 0;
        v7 = v4;
        // goto L_006b
        v4 = 0;
        v6 = v4;
        // goto L_0073
        if (v6 == 0) /* goto L_0077 */;
        v1 = 0x40000000;
        // goto L_0077
        if (v6 == 0) /* goto L_00a5 */;
        _result = v10.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v0 = _result;
        v3 = binOp2addr_0xb1(v3, v0);
        // goto L_00a5
        v0 = 0x40000000;
        _result = v3.makeMeasureSpec(v0); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        v13.u = v0; // android.support.v4.view.ViewPager.u:int
        v0 = 0x40000000;
        _result = v5.makeMeasureSpec(v0); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        v13.v = v0; // android.support.v4.view.ViewPager.v:int
        v0 = 1;
        v13.w = v0; // android.support.v4.view.ViewPager.w:boolean
        _result = v13.e(); // android.support.v4.view.ViewPager.e -> void
        v0 = 0;
        v13.w = v0; // android.support.v4.view.ViewPager.w:boolean
        _result = v13.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v2 = _result;
        v0 = 0;
        v1 = v0;
        if (v1 >= v2) /* goto L_0109 */;
        _result = v13.getChildAt(v1); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v4 = _result;
        _result = v4.getVisibility(); // android.view.View.getVisibility -> int
        v0 = _result;
        v5 = 8;
        if (v0 == v5) /* goto L_0105 */;
        _result = v4.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.view.ViewPager$LayoutParams) v0;
        if (v0 == 0) /* goto L_00f5 */;
        v5 = v0.a; // android.support.v4.view.ViewPager$LayoutParams.a:boolean
        if (v5 != 0) /* goto L_0105 */;
        v5 = unaryOp_0x82(v3);
        v0 = v0.c; // android.support.v4.view.ViewPager$LayoutParams.c:float
        v0 = binOp2addr_0xc8(v0, v5);
        v0 = unaryOp_0x87(v0);
        v5 = 0x40000000;
        _result = v0.makeMeasureSpec(v5); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        v5 = v13.v; // android.support.v4.view.ViewPager.v:int
        _result = v4.measure(v0, v5); // android.view.View.measure -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_00db
        return;
        v0 = v5;
        // goto L_0093
        v2 = v3;
        // goto L_0085
        v4 = v2;
        v2 = v3;
        // goto L_0085
    }

    protected boolean onRequestFocusInDescendants(int p0, android.graphics.Rect p1) {
        // Registers (11 total): v8 = this, v9 = p0 (int), v10 = p1 (android.graphics.Rect)
        v2 = 1;
        v4 = 0;
        v1 = -1;
        _result = v8.getChildCount(); // android.support.v4.view.ViewPager.getChildCount -> int
        v0 = _result;
        v3 = binOpLit8_0xdd(v9, 2);
        if (v3 == 0) /* goto L_002c */;
        v1 = v2;
        v3 = v4;
        if (v3 == v0) /* goto L_0033 */;
        _result = v8.getChildAt(v3); // android.support.v4.view.ViewPager.getChildAt -> android.view.View
        v5 = _result;
        _result = v5.getVisibility(); // android.view.View.getVisibility -> int
        v6 = _result;
        if (v6 != 0) /* goto L_0031 */;
        _result = v8.a(v5); // android.support.v4.view.ViewPager.a -> android.support.v4.view.bz
        v6 = _result;
        if (v6 == 0) /* goto L_0031 */;
        v6 = v6.b; // android.support.v4.view.bz.b:int
        v7 = v8.i; // android.support.v4.view.ViewPager.i:int
        if (v6 != v7) /* goto L_0031 */;
        _result = v5.requestFocus(v9, v10); // android.view.View.requestFocus -> boolean
        v5 = _result;
        if (v5 == 0) /* goto L_0031 */;
        return v2;
        v0 = binOpLit8_0xd8(v0, -1);
        v3 = v0;
        v0 = v1;
        // goto L_000d
        v3 = binOp2addr_0xb0(v3, v1);
        // goto L_000d
        v2 = v4;
        // goto L_002b
    }

    public void onRestoreInstanceState(android.os.Parcelable p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Parcelable)
        v0 = (v4 instanceof android.support.v4.view.ViewPager$SavedState);
        if (v0 != 0) /* goto L_0008 */;
        _result = v3.onRestoreInstanceState(v4); // android.view.ViewGroup.onRestoreInstanceState -> void
        return;
        v4 = (android.support.v4.view.ViewPager$SavedState) v4;
        _result = v4.getSuperState(); // android.support.v4.view.ViewPager$SavedState.getSuperState -> android.os.Parcelable
        v0 = _result;
        _result = v3.onRestoreInstanceState(v0); // android.view.ViewGroup.onRestoreInstanceState -> void
        v0 = v3.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        if (v0 == 0) /* goto L_0026 */;
        v0 = v3.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v1 = v4.adapterState; // android.support.v4.view.ViewPager$SavedState.adapterState:android.os.Parcelable
        v2 = v4.loader; // android.support.v4.view.ViewPager$SavedState.loader:java.lang.ClassLoader
        _result = v0.a(v1, v2); // android.support.v4.view.ae.a -> void
        v0 = v4.position; // android.support.v4.view.ViewPager$SavedState.position:int
        v1 = 0;
        v2 = 1;
        _result = v3.a(v0, v1, v2); // android.support.v4.view.ViewPager.a -> void
        // goto L_0007
        v0 = v4.position; // android.support.v4.view.ViewPager$SavedState.position:int
        v3.j = v0; // android.support.v4.view.ViewPager.j:int
        v0 = v4.adapterState; // android.support.v4.view.ViewPager$SavedState.adapterState:android.os.Parcelable
        v3.k = v0; // android.support.v4.view.ViewPager.k:android.os.Parcelable
        v0 = v4.loader; // android.support.v4.view.ViewPager$SavedState.loader:java.lang.ClassLoader
        v3.l = v0; // android.support.v4.view.ViewPager.l:java.lang.ClassLoader
        // goto L_0007
    }

    public android.os.Parcelable onSaveInstanceState() {
        // Registers (3 total): v2 = this
        _result = v2.onSaveInstanceState(); // android.view.ViewGroup.onSaveInstanceState -> android.os.Parcelable
        v0 = _result;
        v1 = new android.support.v4.view.ViewPager$SavedState;
        _result = v1.<init>(v0); // android.support.v4.view.ViewPager$SavedState.<init> -> void
        v0 = v2.i; // android.support.v4.view.ViewPager.i:int
        v1.position = v0; // android.support.v4.view.ViewPager$SavedState.position:int
        v0 = v2.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        if (v0 == 0) /* goto L_0019 */;
        v0 = v2.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v0.a(); // android.support.v4.view.ae.a -> android.os.Parcelable
        v0 = _result;
        v1.adapterState = v0; // android.support.v4.view.ViewPager$SavedState.adapterState:android.os.Parcelable
        return v1;
    }

    protected void onSizeChanged(int p0, int p1, int p2, int p3) {
        // Registers (7 total): v2 = this, v3 = p0 (int), v4 = p1 (int), v5 = p2 (int), v6 = p3 (int)
        _result = v2.onSizeChanged(v3, v4, v5, v6); // android.view.ViewGroup.onSizeChanged -> void
        if (v3 == v5) /* goto L_000c */;
        v0 = v2.o; // android.support.v4.view.ViewPager.o:int
        v1 = v2.o; // android.support.v4.view.ViewPager.o:int
        _result = v2.a(v3, v5, v0, v1); // android.support.v4.view.ViewPager.a -> void
        return;
    }

    public boolean onTouchEvent(android.view.MotionEvent p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.view.MotionEvent)
        v6 = -1;
        v2 = 0;
        v1 = 1;
        v0 = v7.P; // android.support.v4.view.ViewPager.P:boolean
        if (v0 == 0) /* goto L_0009 */;
        v0 = v1;
        return v0;
        _result = v8.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        _result = v8.getEdgeFlags(); // android.view.MotionEvent.getEdgeFlags -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        v0 = v2;
        // goto L_0008
        v0 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        if (v0 == 0) /* goto L_0023 */;
        v0 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v0.b(); // android.support.v4.view.ae.b -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0025 */;
        v0 = v2;
        // goto L_0008
        v0 = v7.K; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        if (v0 != 0) /* goto L_002f */;
        _result = this.obtain(); // android.view.VelocityTracker.obtain -> android.view.VelocityTracker
        v0 = _result;
        v7.K = v0; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        v0 = v7.K; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        _result = v0.addMovement(v8); // android.view.VelocityTracker.addMovement -> void
        _result = v8.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        v0 = binOpLit16_0xd5(v0, 255);
        // switch(v0)
        if (v2 == 0) /* goto L_0042 */;
        _result = v7.b(); // android.support.v4.view.at.b -> void
        v0 = v1;
        // goto L_0008
        v0 = v7.m; // android.support.v4.view.ViewPager.m:android.widget.Scroller
        _result = v0.abortAnimation(); // android.widget.Scroller.abortAnimation -> void
        v7.y = v2; // android.support.v4.view.ViewPager.y:boolean
        _result = v7.e(); // android.support.v4.view.ViewPager.e -> void
        _result = v8.getX(); // android.view.MotionEvent.getX -> float
        v0 = _result;
        v7.H = v0; // android.support.v4.view.ViewPager.H:float
        v7.F = v0; // android.support.v4.view.ViewPager.F:float
        _result = v8.getY(); // android.view.MotionEvent.getY -> float
        v0 = _result;
        v7.I = v0; // android.support.v4.view.ViewPager.I:float
        v7.G = v0; // android.support.v4.view.ViewPager.G:float
        _result = v8.b(v2); // android.support.v4.view.z.b -> int
        v0 = _result;
        v7.J = v0; // android.support.v4.view.ViewPager.J:int
        // goto L_003d
        v0 = v7.A; // android.support.v4.view.ViewPager.A:boolean
        if (v0 != 0) /* goto L_00b9 */;
        v0 = v7.J; // android.support.v4.view.ViewPager.J:int
        _result = v8.a(v0); // android.support.v4.view.z.a -> int
        v0 = _result;
        _result = v8.c(v0); // android.support.v4.view.z.c -> float
        v3 = _result;
        v4 = v7.F; // android.support.v4.view.ViewPager.F:float
        v4 = binOp_0xa7(v3, v4);
        _result = v4.abs(); // java.lang.Math.abs -> float
        v4 = _result;
        _result = v8.d(v0); // android.support.v4.view.z.d -> float
        v5 = _result;
        v0 = v7.G; // android.support.v4.view.ViewPager.G:float
        v0 = binOp_0xa7(v5, v0);
        _result = v0.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v6 = v7.E; // android.support.v4.view.ViewPager.E:int
        v6 = unaryOp_0x82(v6);
        v6 = cmp(v4, v6);
        if (v6 <= 0) /* goto L_00b9 */;
        v0 = cmp(v4, v0);
        if (v0 <= 0) /* goto L_00b9 */;
        v7.A = v1; // android.support.v4.view.ViewPager.A:boolean
        _result = v7.d(v1); // android.support.v4.view.ViewPager.d -> void
        v0 = v7.H; // android.support.v4.view.ViewPager.H:float
        v0 = binOp_0xa7(v3, v0);
        v3 = 0;
        v0 = cmp(v0, v3);
        if (v0 <= 0) /* goto L_00ce */;
        v0 = v7.H; // android.support.v4.view.ViewPager.H:float
        v3 = v7.E; // android.support.v4.view.ViewPager.E:int
        v3 = unaryOp_0x82(v3);
        v0 = binOp2addr_0xc6(v0, v3);
        v7.F = v0; // android.support.v4.view.ViewPager.F:float
        v7.G = v5; // android.support.v4.view.ViewPager.G:float
        _result = v7.d(v1); // android.support.v4.view.ViewPager.d -> void
        _result = v7.e(v1); // android.support.v4.view.ViewPager.e -> void
        _result = v7.getParent(); // android.support.v4.view.ViewPager.getParent -> android.view.ViewParent
        v0 = _result;
        if (v0 == 0) /* goto L_00b9 */;
        _result = android.view.ViewParent.requestDisallowInterceptTouchEvent(v0, v1); // -> void
        v0 = v7.A; // android.support.v4.view.ViewPager.A:boolean
        if (v0 == 0) /* goto L_003d */;
        v0 = v7.J; // android.support.v4.view.ViewPager.J:int
        _result = v8.a(v0); // android.support.v4.view.z.a -> int
        v0 = _result;
        _result = v8.c(v0); // android.support.v4.view.z.c -> float
        v0 = _result;
        _result = v7.b(v0); // android.support.v4.view.ViewPager.b -> boolean
        v0 = _result;
        v2 = binOp2addr_0xb6(v2, v0);
        // goto L_003d
        v0 = v7.H; // android.support.v4.view.ViewPager.H:float
        v3 = v7.E; // android.support.v4.view.ViewPager.E:int
        v3 = unaryOp_0x82(v3);
        v0 = binOp2addr_0xc7(v0, v3);
        // goto L_00a6
        v0 = v7.A; // android.support.v4.view.ViewPager.A:boolean
        if (v0 == 0) /* goto L_003d */;
        v0 = v7.K; // android.support.v4.view.ViewPager.K:android.view.VelocityTracker
        v2 = 1000;
        v3 = v7.M; // android.support.v4.view.ViewPager.M:int
        v3 = unaryOp_0x82(v3);
        _result = v0.computeCurrentVelocity(v2, v3); // android.view.VelocityTracker.computeCurrentVelocity -> void
        v2 = v7.J; // android.support.v4.view.ViewPager.J:int
        _result = v0.a(v2); // android.support.v4.view.ao.a -> float
        v0 = _result;
        v0 = unaryOp_0x87(v0);
        v7.y = v1; // android.support.v4.view.ViewPager.y:boolean
        _result = v7.j(); // android.support.v4.view.ViewPager.j -> int
        v2 = _result;
        _result = v7.getScrollX(); // android.support.v4.view.ViewPager.getScrollX -> int
        v3 = _result;
        _result = v7.l(); // android.support.v4.view.ViewPager.l -> android.support.v4.view.bz
        v4 = _result;
        v5 = v4.b; // android.support.v4.view.bz.b:int
        v3 = unaryOp_0x82(v3);
        v2 = unaryOp_0x82(v2);
        v2 = binOp_0xa9(v3, v2);
        v3 = v4.e; // android.support.v4.view.bz.e:float
        v2 = binOp2addr_0xc7(v2, v3);
        v3 = v4.d; // android.support.v4.view.bz.d:float
        v2 = binOp2addr_0xc9(v2, v3);
        v3 = v7.J; // android.support.v4.view.ViewPager.J:int
        _result = v8.a(v3); // android.support.v4.view.z.a -> int
        v3 = _result;
        _result = v8.c(v3); // android.support.v4.view.z.c -> float
        v3 = _result;
        v4 = v7.H; // android.support.v4.view.ViewPager.H:float
        v3 = binOp2addr_0xc7(v3, v4);
        v3 = unaryOp_0x87(v3);
        _result = v7.a(v5, v2, v0, v3); // android.support.v4.view.ViewPager.a -> int
        v2 = _result;
        _result = v7.a(v2, v1, v1, v0); // android.support.v4.view.ViewPager.a -> void
        v7.J = v6; // android.support.v4.view.ViewPager.J:int
        _result = v7.m(); // android.support.v4.view.ViewPager.m -> void
        v0 = v7.Q; // android.support.v4.view.ViewPager.Q:android.support.v4.widget.n
        _result = v0.c(); // android.support.v4.widget.n.c -> boolean
        v0 = _result;
        v2 = v7.R; // android.support.v4.view.ViewPager.R:android.support.v4.widget.n
        _result = v2.c(); // android.support.v4.widget.n.c -> boolean
        v2 = _result;
        v2 = binOp2addr_0xb6(v2, v0);
        // goto L_003d
        v0 = v7.A; // android.support.v4.view.ViewPager.A:boolean
        if (v0 == 0) /* goto L_003d */;
        v0 = v7.i; // android.support.v4.view.ViewPager.i:int
        _result = v7.a(v0, v1, v2, v2); // android.support.v4.view.ViewPager.a -> void
        v7.J = v6; // android.support.v4.view.ViewPager.J:int
        _result = v7.m(); // android.support.v4.view.ViewPager.m -> void
        v0 = v7.Q; // android.support.v4.view.ViewPager.Q:android.support.v4.widget.n
        _result = v0.c(); // android.support.v4.widget.n.c -> boolean
        v0 = _result;
        v2 = v7.R; // android.support.v4.view.ViewPager.R:android.support.v4.widget.n
        _result = v2.c(); // android.support.v4.widget.n.c -> boolean
        v2 = _result;
        v2 = binOp2addr_0xb6(v2, v0);
        // goto L_003d
        _result = v8.b(); // android.support.v4.view.z.b -> int
        v0 = _result;
        _result = v8.c(v0); // android.support.v4.view.z.c -> float
        v3 = _result;
        v7.F = v3; // android.support.v4.view.ViewPager.F:float
        _result = v8.b(v0); // android.support.v4.view.z.b -> int
        v0 = _result;
        v7.J = v0; // android.support.v4.view.ViewPager.J:int
        // goto L_003d
        _result = v7.a(v8); // android.support.v4.view.ViewPager.a -> void
        v0 = v7.J; // android.support.v4.view.ViewPager.J:int
        _result = v8.a(v0); // android.support.v4.view.z.a -> int
        v0 = _result;
        _result = v8.c(v0); // android.support.v4.view.z.c -> float
        v0 = _result;
        v7.F = v0; // android.support.v4.view.ViewPager.F:float
        // goto L_003d
    }

    public void removeView(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = v1.w; // android.support.v4.view.ViewPager.w:boolean
        if (v0 == 0) /* goto L_0008 */;
        _result = v1.removeViewInLayout(v2); // android.support.v4.view.ViewPager.removeViewInLayout -> void
        return;
        _result = v1.removeView(v2); // android.view.ViewGroup.removeView -> void
        // goto L_0007
    }

    public void setAdapter(android.support.v4.view.ae p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.support.v4.view.ae)
        v6 = 1;
        v5 = 0;
        v2 = 0;
        v0 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        if (v0 == 0) /* goto L_0043 */;
        v0 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v1 = v7.n; // android.support.v4.view.ViewPager.n:android.support.v4.view.ce
        _result = v0.b(v1); // android.support.v4.view.ae.b -> void
        v0 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v0.a(v7); // android.support.v4.view.ae.a -> void
        v1 = v2;
        v0 = v7.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0031 */;
        v0 = v7.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.bz) v0;
        v3 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v4 = v0.b; // android.support.v4.view.bz.b:int
        v0 = v0.a; // android.support.v4.view.bz.a:java.lang.Object
        _result = v3.a(v7, v4, v0); // android.support.v4.view.ae.a -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0014
        v0 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v0.b(v7); // android.support.v4.view.ae.b -> void
        v0 = v7.e; // android.support.v4.view.ViewPager.e:java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        _result = v7.i(); // android.support.v4.view.ViewPager.i -> void
        v7.i = v2; // android.support.v4.view.ViewPager.i:int
        _result = v7.scrollTo(v2, v2); // android.support.v4.view.ViewPager.scrollTo -> void
        v0 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v7.h = v8; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v7.b = v2; // android.support.v4.view.ViewPager.b:int
        v1 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        if (v1 == 0) /* goto L_0086 */;
        v1 = v7.n; // android.support.v4.view.ViewPager.n:android.support.v4.view.ce
        if (v1 != 0) /* goto L_0058 */;
        v1 = new android.support.v4.view.ce;
        _result = v1.<init>(v7, v5); // android.support.v4.view.ce.<init> -> void
        v7.n = v1; // android.support.v4.view.ViewPager.n:android.support.v4.view.ce
        v1 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v3 = v7.n; // android.support.v4.view.ViewPager.n:android.support.v4.view.ce
        _result = v1.a(v3); // android.support.v4.view.ae.a -> void
        v7.y = v2; // android.support.v4.view.ViewPager.y:boolean
        v1 = v7.S; // android.support.v4.view.ViewPager.S:boolean
        v7.S = v6; // android.support.v4.view.ViewPager.S:boolean
        v3 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        _result = v3.b(); // android.support.v4.view.ae.b -> int
        v3 = _result;
        v7.b = v3; // android.support.v4.view.ViewPager.b:int
        v3 = v7.j; // android.support.v4.view.ViewPager.j:int
        if (v3 < 0) /* goto L_0092 */;
        v1 = v7.h; // android.support.v4.view.ViewPager.h:android.support.v4.view.ae
        v3 = v7.k; // android.support.v4.view.ViewPager.k:android.os.Parcelable
        v4 = v7.l; // android.support.v4.view.ViewPager.l:java.lang.ClassLoader
        _result = v1.a(v3, v4); // android.support.v4.view.ae.a -> void
        v1 = v7.j; // android.support.v4.view.ViewPager.j:int
        _result = v7.a(v1, v2, v6); // android.support.v4.view.ViewPager.a -> void
        v1 = -1;
        v7.j = v1; // android.support.v4.view.ViewPager.j:int
        v7.k = v5; // android.support.v4.view.ViewPager.k:android.os.Parcelable
        v7.l = v5; // android.support.v4.view.ViewPager.l:java.lang.ClassLoader
        v1 = v7.aa; // android.support.v4.view.ViewPager.aa:android.support.v4.view.cb
        if (v1 == 0) /* goto L_0091 */;
        if (v0 == v8) /* goto L_0091 */;
        v1 = v7.aa; // android.support.v4.view.ViewPager.aa:android.support.v4.view.cb
        _result = android.support.v4.view.cb.a(v1, v0, v8); // -> void
        return;
        if (v1 != 0) /* goto L_0098 */;
        _result = v7.e(); // android.support.v4.view.ViewPager.e -> void
        // goto L_0086
        _result = v7.requestLayout(); // android.support.v4.view.ViewPager.requestLayout -> void
        // goto L_0086
    }

    public void setCurrentItem(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v1 = 0;
        v2.y = v1; // android.support.v4.view.ViewPager.y:boolean
        v0 = v2.S; // android.support.v4.view.ViewPager.S:boolean
        if (v0 != 0) /* goto L_000c */;
        v0 = 1;
        _result = v2.a(v3, v0, v1); // android.support.v4.view.ViewPager.a -> void
        return;
        v0 = v1;
        // goto L_0008
    }

    public void setCurrentItem(int p0, boolean p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (boolean)
        v0 = 0;
        v1.y = v0; // android.support.v4.view.ViewPager.y:boolean
        _result = v1.a(v2, v3, v0); // android.support.v4.view.ViewPager.a -> void
        return;
    }

    public void setOffscreenPageLimit(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        v0 = 1;
        if (v5 >= v0) /* goto L_0029 */;
        v1 = "ViewPager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Requested offscreen page limit ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " too small; defaulting to ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.w(v2); // android.util.Log.w -> int
        v5 = v0;
        v0 = v4.z; // android.support.v4.view.ViewPager.z:int
        if (v5 == v0) /* goto L_0032 */;
        v4.z = v5; // android.support.v4.view.ViewPager.z:int
        _result = v4.e(); // android.support.v4.view.ViewPager.e -> void
        return;
    }

    public void setOnPageChangeListener(android.support.v4.view.cc p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.cc)
        v0.W = v1; // android.support.v4.view.ViewPager.W:android.support.v4.view.cc
        return;
    }

    public void setPageMargin(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.o; // android.support.v4.view.ViewPager.o:int
        v2.o = v3; // android.support.v4.view.ViewPager.o:int
        _result = v2.getWidth(); // android.support.v4.view.ViewPager.getWidth -> int
        v1 = _result;
        _result = v2.a(v1, v1, v3, v0); // android.support.v4.view.ViewPager.a -> void
        _result = v2.requestLayout(); // android.support.v4.view.ViewPager.requestLayout -> void
        return;
    }

    public void setPageMarginDrawable(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.getContext(); // android.support.v4.view.ViewPager.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDrawable(v2); // android.content.res.Resources.getDrawable -> android.graphics.drawable.Drawable
        v0 = _result;
        _result = v1.setPageMarginDrawable(v0); // android.support.v4.view.ViewPager.setPageMarginDrawable -> void
        return;
    }

    public void setPageMarginDrawable(android.graphics.drawable.Drawable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.graphics.drawable.Drawable)
        v1.p = v2; // android.support.v4.view.ViewPager.p:android.graphics.drawable.Drawable
        if (v2 == 0) /* goto L_0007 */;
        _result = v1.refreshDrawableState(); // android.support.v4.view.ViewPager.refreshDrawableState -> void
        if (v2 != 0) /* goto L_0011 */;
        v0 = 1;
        _result = v1.setWillNotDraw(v0); // android.support.v4.view.ViewPager.setWillNotDraw -> void
        _result = v1.invalidate(); // android.support.v4.view.ViewPager.invalidate -> void
        return;
        v0 = 0;
        // goto L_000a
    }

    public void setPageTransformer(boolean p0, android.support.v4.view.cd p1) {
        // Registers (7 total): v4 = this, v5 = p0 (boolean), v6 = p1 (android.support.v4.view.cd)
        v1 = 1;
        v2 = 0;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v3 = 11;
        if (v0 < v3) /* goto L_0024 */;
        if (v6 == 0) /* goto L_0025 */;
        v0 = v1;
        v3 = v4.ab; // android.support.v4.view.ViewPager.ab:android.support.v4.view.cd
        if (v3 == 0) /* goto L_0027 */;
        v3 = v1;
        if (v0 == v3) /* goto L_0029 */;
        v3 = v1;
        v4.ab = v6; // android.support.v4.view.ViewPager.ab:android.support.v4.view.cd
        _result = v4.a(v0); // android.support.v4.view.ViewPager.a -> void
        if (v0 == 0) /* goto L_002b */;
        if (v5 == 0) /* goto L_001d */;
        v1 = 2;
        v4.ad = v1; // android.support.v4.view.ViewPager.ad:int
        if (v3 == 0) /* goto L_0024 */;
        _result = v4.e(); // android.support.v4.view.ViewPager.e -> void
        return;
        v0 = v2;
        // goto L_000b
        v3 = v2;
        // goto L_0010
        v3 = v2;
        // goto L_0013
        v4.ad = v2; // android.support.v4.view.ViewPager.ad:int
        // goto L_001f
    }

    protected boolean verifyDrawable(android.graphics.drawable.Drawable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.graphics.drawable.Drawable)
        _result = v1.verifyDrawable(v2); // android.view.ViewGroup.verifyDrawable -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v0 = v1.p; // android.support.v4.view.ViewPager.p:android.graphics.drawable.Drawable
        if (v2 != v0) /* goto L_000c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000b
    }

}