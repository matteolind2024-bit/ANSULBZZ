package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompat.java
 * Descriptor: Landroid/support/v4/view/br;
 */
interface br {
    public abstract void a(android.view.ViewGroup p0, boolean p1);
}