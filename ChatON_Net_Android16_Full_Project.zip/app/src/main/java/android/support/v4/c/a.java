package android.support.v4.c;

/**
 * Original SourceFile: ArrayMap.java
 * Descriptor: Landroid/support/v4/c/a;
 */
public class a extends android.support.v4.c.m implements java.util.Map {
     android.support.v4.c.g a;

    public a() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.c.m.<init> -> void
        return;
    }

    private android.support.v4.c.g b() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.a.a:android.support.v4.c.g
        if (v0 != 0) /* goto L_000b */;
        v0 = new android.support.v4.c.b;
        _result = v0.<init>(v1); // android.support.v4.c.b.<init> -> void
        v1.a = v0; // android.support.v4.c.a.a:android.support.v4.c.g
        v0 = v1.a; // android.support.v4.c.a.a:android.support.v4.c.g
        return v0;
    }

    public java.util.Set entrySet() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // android.support.v4.c.a.b -> android.support.v4.c.g
        v0 = _result;
        _result = v0.d(); // android.support.v4.c.g.d -> java.util.Set
        v0 = _result;
        return v0;
    }

    public java.util.Set keySet() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // android.support.v4.c.a.b -> android.support.v4.c.g
        v0 = _result;
        _result = v0.e(); // android.support.v4.c.g.e -> java.util.Set
        v0 = _result;
        return v0;
    }

    public void putAll(java.util.Map p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.util.Map)
        v0 = v3.h; // android.support.v4.c.a.h:int
        _result = java.util.Map.size(v4); // -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        _result = v3.a(v0); // android.support.v4.c.a.a -> void
        _result = java.util.Map.entrySet(v4); // -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002a */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = java.util.Map$Entry.getKey(v0); // -> java.lang.Object
        v2 = _result;
        _result = java.util.Map$Entry.getValue(v0); // -> java.lang.Object
        v0 = _result;
        _result = v3.put(v2, v0); // android.support.v4.c.a.put -> java.lang.Object
        // goto L_0012
        return;
    }

    public java.util.Collection values() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // android.support.v4.c.a.b -> android.support.v4.c.g
        v0 = _result;
        _result = v0.f(); // android.support.v4.c.g.f -> java.util.Collection
        v0 = _result;
        return v0;
    }

}