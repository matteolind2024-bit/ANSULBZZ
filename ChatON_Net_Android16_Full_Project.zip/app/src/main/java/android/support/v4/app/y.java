package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/y;
 */
final class y extends android.support.v4.app.w {
    static final android.view.animation.Interpolator A;
    static final android.view.animation.Interpolator B;
    static final android.view.animation.Interpolator C;
    static boolean a;
    static final boolean b;
    static final android.view.animation.Interpolator z;
     java.util.ArrayList c;
     java.lang.Runnable[] d;
     boolean e;
     java.util.ArrayList f;
     java.util.ArrayList g;
     java.util.ArrayList h;
     java.util.ArrayList i;
     java.util.ArrayList j;
     java.util.ArrayList k;
     java.util.ArrayList l;
     java.util.ArrayList m;
     int n;
     android.support.v4.app.FragmentActivity o;
     android.support.v4.app.v p;
     android.support.v4.app.Fragment q;
     boolean r;
     boolean s;
     boolean t;
     java.lang.String u;
     boolean v;
     android.os.Bundle w;
     android.util.SparseArray x;
     java.lang.Runnable y;

    static {
        v0 = 0;
        v4 = 0x40200000;
        v3 = 0x3fc00000;
        android.support.v4.app.y.a = v0; // :boolean
        v1 = android.os.Build$VERSION.SDK_INT; // :int
        v2 = 11;
        if (v1 < v2) /* goto L_000e */;
        v0 = 1;
        android.support.v4.app.y.b = v0; // :boolean
        v0 = new android.view.animation.DecelerateInterpolator;
        _result = v0.<init>(v4); // android.view.animation.DecelerateInterpolator.<init> -> void
        android.support.v4.app.y.z = v0; // :android.view.animation.Interpolator
        v0 = new android.view.animation.DecelerateInterpolator;
        _result = v0.<init>(v3); // android.view.animation.DecelerateInterpolator.<init> -> void
        android.support.v4.app.y.A = v0; // :android.view.animation.Interpolator
        v0 = new android.view.animation.AccelerateInterpolator;
        _result = v0.<init>(v4); // android.view.animation.AccelerateInterpolator.<init> -> void
        android.support.v4.app.y.B = v0; // :android.view.animation.Interpolator
        v0 = new android.view.animation.AccelerateInterpolator;
        _result = v0.<init>(v3); // android.view.animation.AccelerateInterpolator.<init> -> void
        android.support.v4.app.y.C = v0; // :android.view.animation.Interpolator
        return;
    }

    y() {
        // Registers (3 total): v2 = this
        v1 = 0;
        _result = v2.<init>(); // android.support.v4.app.w.<init> -> void
        v0 = 0;
        v2.n = v0; // android.support.v4.app.y.n:int
        v2.w = v1; // android.support.v4.app.y.w:android.os.Bundle
        v2.x = v1; // android.support.v4.app.y.x:android.util.SparseArray
        v0 = new android.support.v4.app.z;
        _result = v0.<init>(v2); // android.support.v4.app.z.<init> -> void
        v2.y = v0; // android.support.v4.app.y.y:java.lang.Runnable
        return;
    }

    static android.view.animation.Animation a(android.content.Context p0, float p1, float p2) {
        // Registers (6 total): v3 = p0 (android.content.Context), v4 = p1 (float), v5 = p2 (float)
        v0 = new android.view.animation.AlphaAnimation;
        _result = v0.<init>(v4, v5); // android.view.animation.AlphaAnimation.<init> -> void
        v1 = android.support.v4.app.y.A; // :android.view.animation.Interpolator
        _result = v0.setInterpolator(v1); // android.view.animation.AlphaAnimation.setInterpolator -> void
        v1 = 220L;
        _result = v0.setDuration(v1, v2); // android.view.animation.AlphaAnimation.setDuration -> void
        return v0;
    }

    static android.view.animation.Animation a(android.content.Context p0, float p1, float p2, float p3, float p4) {
        // Registers (15 total): v10 = p0 (android.content.Context), v11 = p1 (float), v12 = p2 (float), v13 = p3 (float), v14 = p4 (float)
        v9 = new android.view.animation.AnimationSet;
        v0 = 0;
        _result = v9.<init>(v0); // android.view.animation.AnimationSet.<init> -> void
        v0 = new android.view.animation.ScaleAnimation;
        v5 = 1;
        v6 = 0x3f000000;
        v7 = 1;
        v8 = 0x3f000000;
        v1 = v11;
        v2 = v12;
        v3 = v11;
        v4 = v12;
        _result = v0.<init>(v0..v8); // android.view.animation.ScaleAnimation.<init> -> void
        v1 = android.support.v4.app.y.z; // :android.view.animation.Interpolator
        _result = v0.setInterpolator(v1); // android.view.animation.ScaleAnimation.setInterpolator -> void
        v1 = 220L;
        _result = v0.setDuration(v1, v2); // android.view.animation.ScaleAnimation.setDuration -> void
        _result = v9.addAnimation(v0); // android.view.animation.AnimationSet.addAnimation -> void
        v0 = new android.view.animation.AlphaAnimation;
        _result = v0.<init>(v13, v14); // android.view.animation.AlphaAnimation.<init> -> void
        v1 = android.support.v4.app.y.A; // :android.view.animation.Interpolator
        _result = v0.setInterpolator(v1); // android.view.animation.AlphaAnimation.setInterpolator -> void
        v1 = 220L;
        _result = v0.setDuration(v1, v2); // android.view.animation.AlphaAnimation.setDuration -> void
        _result = v9.addAnimation(v0); // android.view.animation.AnimationSet.addAnimation -> void
        return v9;
    }

    private void a(java.lang.RuntimeException p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.RuntimeException)
        v0 = "FragmentManager";
        _result = v6.getMessage(); // java.lang.RuntimeException.getMessage -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // android.util.Log.e -> int
        v0 = "FragmentManager";
        v1 = "Activity state:";
        _result = v0.e(v1); // android.util.Log.e -> int
        v0 = new android.support.v4.c.e;
        v1 = "FragmentManager";
        _result = v0.<init>(v1); // android.support.v4.c.e.<init> -> void
        v1 = new java.io.PrintWriter;
        _result = v1.<init>(v0); // java.io.PrintWriter.<init> -> void
        v0 = v5.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_003c */;
        v0 = v5.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v2 = "  ";
        v3 = 0;
        v4 = 0;
        v4 = new java.lang.String[][size=v4];
        _result = v0.dump(v2, v3, v1, v4); // android.support.v4.app.FragmentActivity.dump -> void
        throw v6;
        v0 = _exception;
        v1 = "FragmentManager";
        v2 = "Failed dumping state";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_0030
        v0 = "  ";
        v2 = 0;
        v3 = 0;
        v3 = new java.lang.String[][size=v3];
        _result = v5.a(v0, v2, v1, v3); // android.support.v4.app.y.a -> void
        // goto L_0030
        v0 = _exception;
        v1 = "FragmentManager";
        v2 = "Failed dumping state";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_0030
    }

    public static int b(int p0, boolean p1) {
        // Registers (3 total): v1 = p0 (int), v2 = p1 (boolean)
        v0 = -1;
        // switch(v1)
        return v0;
        if (v2 == 0) /* goto L_0009 */;
        v0 = 1;
        // goto L_0004
        v0 = 2;
        // goto L_0004
        if (v2 == 0) /* goto L_000f */;
        v0 = 3;
        // goto L_0004
        v0 = 4;
        // goto L_0004
        if (v2 == 0) /* goto L_0015 */;
        v0 = 5;
        // goto L_0004
        v0 = 6;
        // goto L_0004
    }

    public static int c(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = 0;
        // switch(v1)
        return v0;
        v0 = 8194;
        // goto L_0004
        v0 = 4097;
        // goto L_0004
        v0 = 4099;
        // goto L_0004
    }

    private void u() {
        // Registers (4 total): v3 = this
        v0 = v3.s; // android.support.v4.app.y.s:boolean
        if (v0 == 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Can not perform this action after onSaveInstanceState";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.u; // android.support.v4.app.y.u:java.lang.String
        if (v0 == 0) /* goto L_002d */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Can not perform this action inside of ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.u; // android.support.v4.app.y.u:java.lang.String
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        return;
    }

    public int a(android.support.v4.app.l p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.support.v4.app.l)
        // monitor-enter(v4)
        v0 = v4.l; // android.support.v4.app.y.l:java.util.ArrayList
        if (v0 == 0) /* goto L_000d */;
        v0 = v4.l; // android.support.v4.app.y.l:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > 0) /* goto L_004e */;
        v0 = v4.k; // android.support.v4.app.y.k:java.util.ArrayList
        if (v0 != 0) /* goto L_0018 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v4.k = v0; // android.support.v4.app.y.k:java.util.ArrayList
        v0 = v4.k; // android.support.v4.app.y.k:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v1 = android.support.v4.app.y.a; // :boolean
        if (v1 == 0) /* goto L_0047 */;
        v1 = "FragmentManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Setting back stack index ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " to ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v4.k; // android.support.v4.app.y.k:java.util.ArrayList
        _result = v1.add(v5); // java.util.ArrayList.add -> boolean
        // monitor-exit(v4)
        return v0;
        v0 = v4.l; // android.support.v4.app.y.l:java.util.ArrayList
        v1 = v4.l; // android.support.v4.app.y.l:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        _result = v0.remove(v1); // java.util.ArrayList.remove -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Integer) v0;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        v1 = android.support.v4.app.y.a; // :boolean
        if (v1 == 0) /* goto L_008b */;
        v1 = "FragmentManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Adding back stack index ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " with ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v4.k; // android.support.v4.app.y.k:java.util.ArrayList
        _result = v1.set(v0, v5); // java.util.ArrayList.set -> java.lang.Object
        // monitor-exit(v4)
        // goto L_004d
        v0 = _exception;
        // monitor-exit(v4)
        throw v0;
    }

    public android.support.v4.app.Fragment$SavedState a(android.support.v4.app.Fragment p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.support.v4.app.Fragment)
        v0 = 0;
        v1 = v5.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v1 >= 0) /* goto L_0028 */;
        v1 = new java.lang.IllegalStateException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Fragment ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " is not currently in the FragmentManager";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2); // java.lang.IllegalStateException.<init> -> void
        _result = v4.a(v1); // android.support.v4.app.y.a -> void
        v1 = v5.mState; // android.support.v4.app.Fragment.mState:int
        if (v1 <= 0) /* goto L_0037 */;
        _result = v4.g(v5); // android.support.v4.app.y.g -> android.os.Bundle
        v1 = _result;
        if (v1 == 0) /* goto L_0037 */;
        v0 = new android.support.v4.app.Fragment$SavedState;
        _result = v0.<init>(v1); // android.support.v4.app.Fragment$SavedState.<init> -> void
        return v0;
    }

    public android.support.v4.app.Fragment a(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 == 0) /* goto L_0022 */;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0022 */;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_001e */;
        v2 = v0.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        if (v2 != v4) /* goto L_001e */;
        return v0;
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_000d
        v0 = v3.f; // android.support.v4.app.y.f:java.util.ArrayList
        if (v0 == 0) /* goto L_0043 */;
        v0 = v3.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0043 */;
        v0 = v3.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_003f */;
        v2 = v0.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        if (v2 == v4) /* goto L_001d */;
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_002f
        v0 = 0;
        // goto L_001d
    }

    public android.support.v4.app.Fragment a(android.os.Bundle p0, java.lang.String p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.os.Bundle), v7 = p1 (java.lang.String)
        v0 = -1;
        _result = v6.getInt(v7, v0); // android.os.Bundle.getInt -> int
        v1 = _result;
        if (v1 != v0) /* goto L_0009 */;
        v0 = 0;
        return v0;
        v0 = v5.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 < v0) /* goto L_0038 */;
        v0 = new java.lang.IllegalStateException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Fragement no longer exists for key ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": index ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v0.<init>(v2); // java.lang.IllegalStateException.<init> -> void
        _result = v5.a(v0); // android.support.v4.app.y.a -> void
        v0 = v5.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 != 0) /* goto L_0008 */;
        v2 = new java.lang.IllegalStateException;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "Fragement no longer exists for key ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ": index ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v2.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        _result = v5.a(v2); // android.support.v4.app.y.a -> void
        // goto L_0008
    }

    public android.support.v4.app.Fragment a(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 == 0) /* goto L_0028 */;
        if (v4 == 0) /* goto L_0028 */;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0028 */;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0024 */;
        v2 = v0.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v4.equals(v2); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0024 */;
        return v0;
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_000f
        v0 = v3.f; // android.support.v4.app.y.f:java.util.ArrayList
        if (v0 == 0) /* goto L_004f */;
        if (v4 == 0) /* goto L_004f */;
        v0 = v3.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_004f */;
        v0 = v3.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_004b */;
        v2 = v0.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v4.equals(v2); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0023 */;
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0037
        v0 = 0;
        // goto L_0023
    }

    public android.support.v4.app.aj a() {
        // Registers (2 total): v1 = this
        v0 = new android.support.v4.app.l;
        _result = v0.<init>(v1); // android.support.v4.app.l.<init> -> void
        return v0;
    }

    android.view.animation.Animation a(android.support.v4.app.Fragment p0, int p1, boolean p2, int p3) {
        // Registers (11 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment), v8 = p1 (int), v9 = p2 (boolean), v10 = p3 (int)
        v5 = 1064933786; // 0x3f79999a
        v1 = 0;
        v4 = 0;
        v3 = 0x3f800000;
        v0 = v7.mNextAnim; // android.support.v4.app.Fragment.mNextAnim:int
        _result = v7.onCreateAnimation(v8, v9, v0); // android.support.v4.app.Fragment.onCreateAnimation -> android.view.animation.Animation
        v0 = _result;
        if (v0 == 0) /* goto L_0010 */;
        return v0;
        v0 = v7.mNextAnim; // android.support.v4.app.Fragment.mNextAnim:int
        if (v0 == 0) /* goto L_001e */;
        v0 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v2 = v7.mNextAnim; // android.support.v4.app.Fragment.mNextAnim:int
        _result = v0.loadAnimation(v2); // android.view.animation.AnimationUtils.loadAnimation -> android.view.animation.Animation
        v0 = _result;
        if (v0 != 0) /* goto L_000f */;
        if (v8 != 0) /* goto L_0022 */;
        v0 = v1;
        // goto L_000f
        _result = v8.b(v9); // android.support.v4.app.y.b -> int
        v0 = _result;
        if (v0 >= 0) /* goto L_002a */;
        v0 = v1;
        // goto L_000f
        // switch(v0)
        if (v10 != 0) /* goto L_0043 */;
        v0 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v0.getWindow(); // android.support.v4.app.FragmentActivity.getWindow -> android.view.Window
        v0 = _result;
        if (v0 == 0) /* goto L_0043 */;
        v0 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v0.getWindow(); // android.support.v4.app.FragmentActivity.getWindow -> android.view.Window
        v0 = _result;
        _result = v0.getAttributes(); // android.view.Window.getAttributes -> android.view.WindowManager$LayoutParams
        v0 = _result;
        v10 = v0.windowAnimations; // android.view.WindowManager$LayoutParams.windowAnimations:int
        if (v10 != 0) /* goto L_0076 */;
        v0 = v1;
        // goto L_000f
        v0 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v1 = 0x3f900000;
        _result = v0.a(v1, v3, v4, v3); // android.support.v4.app.y.a -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v0.a(v3, v5, v3, v4); // android.support.v4.app.y.a -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v0.a(v5, v3, v4, v3); // android.support.v4.app.y.a -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v1 = 1065982362; // 0x3f89999a
        _result = v0.a(v3, v1, v3, v4); // android.support.v4.app.y.a -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v0.a(v4, v3); // android.support.v4.app.y.a -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v0.a(v3, v4); // android.support.v4.app.y.a -> android.view.animation.Animation
        v0 = _result;
        // goto L_000f
        v0 = v1;
        // goto L_000f
    }

    public void a(int p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (int)
        if (v4 >= 0) /* goto L_001c */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Bad id: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = new android.support.v4.app.aa;
        _result = v0.<init>(v3, v4, v5); // android.support.v4.app.aa.<init> -> void
        v1 = 0;
        _result = v3.a(v0, v1); // android.support.v4.app.y.a -> void
        return;
    }

    void a(int p0, int p1, int p2, boolean p3) {
        // Registers (13 total): v8 = this, v9 = p0 (int), v10 = p1 (int), v11 = p2 (int), v12 = p3 (boolean)
        v5 = 0;
        v0 = v8.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_0010 */;
        if (v9 == 0) /* goto L_0010 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "No activity";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        if (v12 != 0) /* goto L_0017 */;
        v0 = v8.n; // android.support.v4.app.y.n:int
        if (v0 != v9) /* goto L_0017 */;
        return;
        v8.n = v9; // android.support.v4.app.y.n:int
        v0 = v8.f; // android.support.v4.app.y.f:java.util.ArrayList
        if (v0 == 0) /* goto L_0016 */;
        v6 = v5;
        v7 = v5;
        v0 = v8.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v6 >= v0) /* goto L_0049 */;
        v0 = v8.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.get(v6); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.app.Fragment) v1;
        if (v1 == 0) /* goto L_0063 */;
        v0 = v8;
        v2 = v9;
        v3 = v10;
        v4 = v11;
        _result = v0.a(v0..v5); // android.support.v4.app.y.a -> void
        v0 = v1.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        if (v0 == 0) /* goto L_0063 */;
        v0 = v1.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        _result = v0.a(); // android.support.v4.app.ao.a -> boolean
        v0 = _result;
        v7 = binOp2addr_0xb6(v7, v0);
        v1 = v7;
        v0 = binOpLit8_0xd8(v6, 1);
        v6 = v0;
        v7 = v1;
        // goto L_001f
        if (v7 != 0) /* goto L_004e */;
        _result = v8.e(); // android.support.v4.app.y.e -> void
        v0 = v8.r; // android.support.v4.app.y.r:boolean
        if (v0 == 0) /* goto L_0016 */;
        v0 = v8.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_0016 */;
        v0 = v8.n; // android.support.v4.app.y.n:int
        v1 = 5;
        if (v0 != v1) /* goto L_0016 */;
        v0 = v8.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v0.u_(); // android.support.v4.app.FragmentActivity.u_ -> void
        v8.r = v5; // android.support.v4.app.y.r:boolean
        // goto L_0016
        v1 = v7;
        // goto L_0044
    }

    public void a(int p0, android.support.v4.app.l p1) {
        // Registers (7 total): v4 = this, v5 = p0 (int), v6 = p1 (android.support.v4.app.l)
        // monitor-enter(v4)
        v0 = v4.k; // android.support.v4.app.y.k:java.util.ArrayList
        if (v0 != 0) /* goto L_000c */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v4.k = v0; // android.support.v4.app.y.k:java.util.ArrayList
        v0 = v4.k; // android.support.v4.app.y.k:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v5 >= v0) /* goto L_0044 */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_003d */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Setting back stack index ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " to ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.k; // android.support.v4.app.y.k:java.util.ArrayList
        _result = v0.set(v5, v6); // java.util.ArrayList.set -> java.lang.Object
        // monitor-exit(v4)
        return;
        if (v0 >= v5) /* goto L_0081 */;
        v1 = v4.k; // android.support.v4.app.y.k:java.util.ArrayList
        v2 = 0;
        _result = v1.add(v2); // java.util.ArrayList.add -> boolean
        v1 = v4.l; // android.support.v4.app.y.l:java.util.ArrayList
        if (v1 != 0) /* goto L_0057 */;
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        v4.l = v1; // android.support.v4.app.y.l:java.util.ArrayList
        v1 = android.support.v4.app.y.a; // :boolean
        if (v1 == 0) /* goto L_0075 */;
        v1 = "FragmentManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Adding available back stack index ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v4.l; // android.support.v4.app.y.l:java.util.ArrayList
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v2 = _result;
        _result = v1.add(v2); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0044
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_00aa */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Adding back stack index ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " with ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.k; // android.support.v4.app.y.k:java.util.ArrayList
        _result = v0.add(v6); // java.util.ArrayList.add -> boolean
        // goto L_0042
        v0 = _exception;
        // monitor-exit(v4)
        throw v0;
    }

    void a(int p0, boolean p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (boolean)
        v0 = 0;
        _result = v1.a(v2, v0, v0, v3); // android.support.v4.app.y.a -> void
        return;
    }

    public void a(android.content.res.Configuration p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.res.Configuration)
        v0 = v2.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 == 0) /* goto L_001f */;
        v0 = 0;
        v1 = v0;
        v0 = v2.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001f */;
        v0 = v2.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_001b */;
        _result = v0.performConfigurationChanged(v3); // android.support.v4.app.Fragment.performConfigurationChanged -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
        return;
    }

    public void a(android.os.Bundle p0, java.lang.String p1, android.support.v4.app.Fragment p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.os.Bundle), v5 = p1 (java.lang.String), v6 = p2 (android.support.v4.app.Fragment)
        v0 = v6.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v0 >= 0) /* goto L_0027 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " is not currently in the FragmentManager";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        _result = v3.a(v0); // android.support.v4.app.y.a -> void
        v0 = v6.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v4.putInt(v5, v0); // android.os.Bundle.putInt -> void
        return;
    }

    void a(android.os.Parcelable p0, java.util.ArrayList p1) {
        // Registers (11 total): v8 = this, v9 = p0 (android.os.Parcelable), v10 = p1 (java.util.ArrayList)
        v7 = 0;
        v2 = 0;
        if (v9 != 0) /* goto L_0005 */;
        return;
        v9 = (android.support.v4.app.FragmentManagerState) v9;
        v0 = v9.mActive; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        if (v0 == 0) /* goto L_0004 */;
        if (v10 == 0) /* goto L_0068 */;
        v1 = v2;
        _result = v10.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0068 */;
        _result = v10.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v3 = android.support.v4.app.y.a; // :boolean
        if (v3 == 0) /* goto L_0038 */;
        v3 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "restoreAllState: re-attaching retained ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v3.v(v4); // android.util.Log.v -> int
        v3 = v9.mActive; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        v4 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v3 = v3[v4];
        v3.mInstance = v0; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v0.mSavedViewState = v7; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        v0.mBackStackNesting = v2; // android.support.v4.app.Fragment.mBackStackNesting:int
        v0.mInLayout = v2; // android.support.v4.app.Fragment.mInLayout:boolean
        v0.mAdded = v2; // android.support.v4.app.Fragment.mAdded:boolean
        v0.mTarget = v7; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v4 = v3.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        if (v4 == 0) /* goto L_0064 */;
        v4 = v3.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v5 = v8.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v5.getClassLoader(); // android.support.v4.app.FragmentActivity.getClassLoader -> java.lang.ClassLoader
        v5 = _result;
        _result = v4.setClassLoader(v5); // android.os.Bundle.setClassLoader -> void
        v3 = v3.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v4 = "android:view_state";
        _result = v3.getSparseParcelableArray(v4); // android.os.Bundle.getSparseParcelableArray -> android.util.SparseArray
        v3 = _result;
        v0.mSavedViewState = v3; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_000e
        v0 = new java.util.ArrayList;
        v1 = v9.mActive; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        v1 = v1.length;
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v8.f = v0; // android.support.v4.app.y.f:java.util.ArrayList
        v0 = v8.h; // android.support.v4.app.y.h:java.util.ArrayList
        if (v0 == 0) /* goto L_007b */;
        v0 = v8.h; // android.support.v4.app.y.h:java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        v0 = v2;
        v1 = v9.mActive; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        v1 = v1.length;
        if (v0 >= v1) /* goto L_00fa */;
        v1 = v9.mActive; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        v1 = v1[v0];
        if (v1 == 0) /* goto L_00c2 */;
        v3 = v8.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v4 = v8.q; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        _result = v1.a(v3, v4); // android.support.v4.app.FragmentState.a -> android.support.v4.app.Fragment
        v3 = _result;
        v4 = android.support.v4.app.y.a; // :boolean
        if (v4 == 0) /* goto L_00b8 */;
        v4 = "FragmentManager";
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "restoreAllState: active #";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = ": ";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v5 = _result;
        _result = v4.v(v5); // android.util.Log.v -> int
        v4 = v8.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v4.add(v3); // java.util.ArrayList.add -> boolean
        v1.mInstance = v7; // android.support.v4.app.FragmentState.mInstance:android.support.v4.app.Fragment
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_007c
        v1 = v8.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v1.add(v7); // java.util.ArrayList.add -> boolean
        v1 = v8.h; // android.support.v4.app.y.h:java.util.ArrayList
        if (v1 != 0) /* goto L_00d2 */;
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        v8.h = v1; // android.support.v4.app.y.h:java.util.ArrayList
        v1 = android.support.v4.app.y.a; // :boolean
        if (v1 == 0) /* goto L_00f0 */;
        v1 = "FragmentManager";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "restoreAllState: avail #";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v1.v(v3); // android.util.Log.v -> int
        v1 = v8.h; // android.support.v4.app.y.h:java.util.ArrayList
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v3 = _result;
        _result = v1.add(v3); // java.util.ArrayList.add -> boolean
        // goto L_00bf
        if (v10 == 0) /* goto L_0151 */;
        v3 = v2;
        _result = v10.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_0151 */;
        _result = v10.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v1 = v0.mTargetIndex; // android.support.v4.app.Fragment.mTargetIndex:int
        if (v1 < 0) /* goto L_0123 */;
        v1 = v0.mTargetIndex; // android.support.v4.app.Fragment.mTargetIndex:int
        v4 = v8.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v4.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        if (v1 >= v4) /* goto L_0127 */;
        v1 = v8.f; // android.support.v4.app.y.f:java.util.ArrayList
        v4 = v0.mTargetIndex; // android.support.v4.app.Fragment.mTargetIndex:int
        _result = v1.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.app.Fragment) v1;
        v0.mTarget = v1; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_00fd
        v1 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "Re-attaching retained fragment ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = " target no longer exists: ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = v0.mTargetIndex; // android.support.v4.app.Fragment.mTargetIndex:int
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v1.w(v4); // android.util.Log.w -> int
        v0.mTarget = v7; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        // goto L_0123
        v0 = v9.mAdded; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        if (v0 == 0) /* goto L_01d9 */;
        v0 = new java.util.ArrayList;
        v1 = v9.mAdded; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        v1 = v1.length;
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v8.g = v0; // android.support.v4.app.y.g:java.util.ArrayList
        v1 = v2;
        v0 = v9.mAdded; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        v0 = v0.length;
        if (v1 >= v0) /* goto L_01db */;
        v0 = v8.f; // android.support.v4.app.y.f:java.util.ArrayList
        v3 = v9.mAdded; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        v3 = v3[v1];
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 != 0) /* goto L_0193 */;
        v3 = new java.lang.IllegalStateException;
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "No instantiated fragment for index #";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = v9.mAdded; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        v5 = v5[v1];
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v3.<init>(v4); // java.lang.IllegalStateException.<init> -> void
        _result = v8.a(v3); // android.support.v4.app.y.a -> void
        v3 = 1;
        v0.mAdded = v3; // android.support.v4.app.Fragment.mAdded:boolean
        v3 = android.support.v4.app.y.a; // :boolean
        if (v3 == 0) /* goto L_01bf */;
        v3 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "restoreAllState: added #";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = ": ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v3.v(v4); // android.util.Log.v -> int
        v3 = v8.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v3.contains(v0); // java.util.ArrayList.contains -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_01d0 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Already added!";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v3 = v8.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v3.add(v0); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0160
        v8.g = v7; // android.support.v4.app.y.g:java.util.ArrayList
        v0 = v9.mBackStack; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        if (v0 == 0) /* goto L_0251 */;
        v0 = new java.util.ArrayList;
        v1 = v9.mBackStack; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        v1 = v1.length;
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v8.i = v0; // android.support.v4.app.y.i:java.util.ArrayList
        v0 = v2;
        v1 = v9.mBackStack; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        v1 = v1.length;
        if (v0 >= v1) /* goto L_0004 */;
        v1 = v9.mBackStack; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        v1 = v1[v0];
        _result = v1.a(v8); // android.support.v4.app.BackStackState.a -> android.support.v4.app.l
        v1 = _result;
        v3 = android.support.v4.app.y.a; // :boolean
        if (v3 == 0) /* goto L_0240 */;
        v3 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "restoreAllState: back stack #";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = " (index ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = v1.o; // android.support.v4.app.l.o:int
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = "): ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v3.v(v4); // android.util.Log.v -> int
        v3 = new android.support.v4.c.e;
        v4 = "FragmentManager";
        _result = v3.<init>(v4); // android.support.v4.c.e.<init> -> void
        v4 = new java.io.PrintWriter;
        _result = v4.<init>(v3); // java.io.PrintWriter.<init> -> void
        v3 = "  ";
        _result = v1.a(v3, v4, v2); // android.support.v4.app.l.a -> void
        v3 = v8.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v3.add(v1); // java.util.ArrayList.add -> boolean
        v3 = v1.o; // android.support.v4.app.l.o:int
        if (v3 < 0) /* goto L_024e */;
        v3 = v1.o; // android.support.v4.app.l.o:int
        _result = v8.a(v3, v1); // android.support.v4.app.y.a -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_01ea
        v8.i = v7; // android.support.v4.app.y.i:java.util.ArrayList
        // goto L_0004
    }

    public void a(android.support.v4.app.Fragment p0, int p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment), v8 = p1 (int), v9 = p2 (int)
        v1 = 1;
        v5 = 0;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_002d */;
        v0 = "FragmentManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "remove: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " nesting=";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v7.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v0.v(v2); // android.util.Log.v -> int
        _result = v7.isInBackStack(); // android.support.v4.app.Fragment.isInBackStack -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_005c */;
        v0 = v1;
        v2 = v7.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        if (v2 == 0) /* goto L_003a */;
        if (v0 == 0) /* goto L_005b */;
        v2 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v2 == 0) /* goto L_0043 */;
        v2 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v2.remove(v7); // java.util.ArrayList.remove -> boolean
        v2 = v7.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v2 == 0) /* goto L_004d */;
        v2 = v7.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v2 == 0) /* goto L_004d */;
        v6.r = v1; // android.support.v4.app.y.r:boolean
        v7.mAdded = v5; // android.support.v4.app.Fragment.mAdded:boolean
        v7.mRemoving = v1; // android.support.v4.app.Fragment.mRemoving:boolean
        if (v0 == 0) /* goto L_005e */;
        v2 = v5;
        v0 = v6;
        v1 = v7;
        v3 = v8;
        v4 = v9;
        _result = v0.a(v0..v5); // android.support.v4.app.y.a -> void
        return;
        v0 = v5;
        // goto L_0034
        v2 = v1;
        // goto L_0054
    }

    void a(android.support.v4.app.Fragment p0, int p1, int p2, int p3, boolean p4) {
        // Registers (15 total): v9 = this, v10 = p0 (android.support.v4.app.Fragment), v11 = p1 (int), v12 = p2 (int), v13 = p3 (int), v14 = p4 (boolean)
        v8 = 4;
        v6 = 3;
        v3 = 0;
        v5 = 1;
        v7 = 0;
        v0 = v10.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 == 0) /* goto L_000d */;
        v0 = v10.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        if (v0 == 0) /* goto L_0010 */;
        if (v11 <= v5) /* goto L_0010 */;
        v11 = v5;
        v0 = v10.mRemoving; // android.support.v4.app.Fragment.mRemoving:boolean
        if (v0 == 0) /* goto L_001a */;
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        if (v11 <= v0) /* goto L_001a */;
        v11 = v10.mState; // android.support.v4.app.Fragment.mState:int
        v0 = v10.mDeferStart; // android.support.v4.app.Fragment.mDeferStart:boolean
        if (v0 == 0) /* goto L_0025 */;
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        if (v0 >= v8) /* goto L_0025 */;
        if (v11 <= v6) /* goto L_0025 */;
        v11 = v6;
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        if (v0 >= v11) /* goto L_0251 */;
        v0 = v10.mFromLayout; // android.support.v4.app.Fragment.mFromLayout:boolean
        if (v0 == 0) /* goto L_0032 */;
        v0 = v10.mInLayout; // android.support.v4.app.Fragment.mInLayout:boolean
        if (v0 != 0) /* goto L_0032 */;
        return;
        v0 = v10.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        if (v0 == 0) /* goto L_0040 */;
        v10.mAnimatingAway = v7; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        v2 = v10.mStateAfterAnimating; // android.support.v4.app.Fragment.mStateAfterAnimating:int
        v0 = v9;
        v1 = v10;
        v4 = v3;
        _result = v0.a(v0..v5); // android.support.v4.app.y.a -> void
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        // switch(v0)
        v10.mState = v11; // android.support.v4.app.Fragment.mState:int
        // goto L_0031
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0066 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "moveto CREATED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        if (v0 == 0) /* goto L_00a3 */;
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v1 = "android:view_state";
        _result = v0.getSparseParcelableArray(v1); // android.os.Bundle.getSparseParcelableArray -> android.util.SparseArray
        v0 = _result;
        v10.mSavedViewState = v0; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v1 = "android:target_state";
        _result = v9.a(v0, v1); // android.support.v4.app.y.a -> android.support.v4.app.Fragment
        v0 = _result;
        v10.mTarget = v0; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v0 = v10.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_008f */;
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v1 = "android:target_req_state";
        _result = v0.getInt(v1, v3); // android.os.Bundle.getInt -> int
        v0 = _result;
        v10.mTargetRequestCode = v0; // android.support.v4.app.Fragment.mTargetRequestCode:int
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v1 = "android:user_visible_hint";
        _result = v0.getBoolean(v1, v5); // android.os.Bundle.getBoolean -> boolean
        v0 = _result;
        v10.mUserVisibleHint = v0; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        v0 = v10.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        if (v0 != 0) /* goto L_00a3 */;
        v10.mDeferStart = v5; // android.support.v4.app.Fragment.mDeferStart:boolean
        if (v11 <= v6) /* goto L_00a3 */;
        v11 = v6;
        v0 = v9.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v10.mActivity = v0; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v0 = v9.q; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        v10.mParentFragment = v0; // android.support.v4.app.Fragment.mParentFragment:android.support.v4.app.Fragment
        v0 = v9.q; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_00e1 */;
        v0 = v9.q; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        v0 = v0.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        v10.mFragmentManager = v0; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.y
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        v0 = v9.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v10.onAttach(v0); // android.support.v4.app.Fragment.onAttach -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_00e6 */;
        v0 = new android.support.v4.app.bg;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onAttach()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.bg.<init> -> void
        throw v0;
        v0 = v9.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v0 = v0.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        // goto L_00b3
        v0 = v10.mParentFragment; // android.support.v4.app.Fragment.mParentFragment:android.support.v4.app.Fragment
        if (v0 != 0) /* goto L_00ef */;
        v0 = v9.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v0.a(v10); // android.support.v4.app.FragmentActivity.a -> void
        v0 = v10.mRetaining; // android.support.v4.app.Fragment.mRetaining:boolean
        if (v0 != 0) /* goto L_00f8 */;
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.performCreate(v0); // android.support.v4.app.Fragment.performCreate -> void
        v10.mRetaining = v3; // android.support.v4.app.Fragment.mRetaining:boolean
        v0 = v10.mFromLayout; // android.support.v4.app.Fragment.mFromLayout:boolean
        if (v0 == 0) /* goto L_012e */;
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.getLayoutInflater(v0); // android.support.v4.app.Fragment.getLayoutInflater -> android.view.LayoutInflater
        v0 = _result;
        v1 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.performCreateView(v0, v7, v1); // android.support.v4.app.Fragment.performCreateView -> android.view.View
        v0 = _result;
        v10.mView = v0; // android.support.v4.app.Fragment.mView:android.view.View
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_024a */;
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v10.mInnerView = v0; // android.support.v4.app.Fragment.mInnerView:android.view.View
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.a(); // android.support.v4.app.aq.a -> android.view.ViewGroup
        v0 = _result;
        v10.mView = v0; // android.support.v4.app.Fragment.mView:android.view.View
        v0 = v10.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v0 == 0) /* goto L_0127 */;
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = 8;
        _result = v0.setVisibility(v1); // android.view.View.setVisibility -> void
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.onViewCreated(v0, v1); // android.support.v4.app.Fragment.onViewCreated -> void
        if (v11 <= v5) /* goto L_01fc */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_014e */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "moveto ACTIVITY_CREATED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v10.mFromLayout; // android.support.v4.app.Fragment.mFromLayout:boolean
        if (v0 != 0) /* goto L_01ec */;
        v0 = v10.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        if (v0 == 0) /* goto L_03b4 */;
        v0 = v9.p; // android.support.v4.app.y.p:android.support.v4.app.v
        v1 = v10.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        _result = android.support.v4.app.v.a(v0, v1); // -> android.view.View
        v0 = _result;
        v0 = (android.view.ViewGroup) v0;
        if (v0 != 0) /* goto L_01a8 */;
        v1 = v10.mRestored; // android.support.v4.app.Fragment.mRestored:boolean
        if (v1 != 0) /* goto L_01a8 */;
        v1 = new java.lang.IllegalArgumentException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "No view found for id 0x";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v10.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        _result = v3.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " (";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v10.getResources(); // android.support.v4.app.Fragment.getResources -> android.content.res.Resources
        v3 = _result;
        v4 = v10.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        _result = v3.getResourceName(v4); // android.content.res.Resources.getResourceName -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ") for fragment ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2); // java.lang.IllegalArgumentException.<init> -> void
        _result = v9.a(v1); // android.support.v4.app.y.a -> void
        v10.mContainer = v0; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        v1 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.getLayoutInflater(v1); // android.support.v4.app.Fragment.getLayoutInflater -> android.view.LayoutInflater
        v1 = _result;
        v2 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.performCreateView(v1, v0, v2); // android.support.v4.app.Fragment.performCreateView -> android.view.View
        v1 = _result;
        v10.mView = v1; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v1 == 0) /* goto L_024e */;
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v10.mInnerView = v1; // android.support.v4.app.Fragment.mInnerView:android.view.View
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v1.a(); // android.support.v4.app.aq.a -> android.view.ViewGroup
        v1 = _result;
        v10.mView = v1; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_01da */;
        _result = v9.a(v10, v12, v5, v13); // android.support.v4.app.y.a -> android.view.animation.Animation
        v1 = _result;
        if (v1 == 0) /* goto L_01d5 */;
        v2 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v2.startAnimation(v1); // android.view.View.startAnimation -> void
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.addView(v1); // android.view.ViewGroup.addView -> void
        v0 = v10.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v0 == 0) /* goto L_01e5 */;
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = 8;
        _result = v0.setVisibility(v1); // android.view.View.setVisibility -> void
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.onViewCreated(v0, v1); // android.support.v4.app.Fragment.onViewCreated -> void
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.performActivityCreated(v0); // android.support.v4.app.Fragment.performActivityCreated -> void
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_01fa */;
        v0 = v10.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v10.restoreViewState(v0); // android.support.v4.app.Fragment.restoreViewState -> void
        v10.mSavedFragmentState = v7; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        if (v11 <= v6) /* goto L_021f */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_021c */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "moveto STARTED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        _result = v10.performStart(); // android.support.v4.app.Fragment.performStart -> void
        if (v11 <= v8) /* goto L_0045 */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_023f */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "moveto RESUMED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v10.mResumed = v5; // android.support.v4.app.Fragment.mResumed:boolean
        _result = v10.performResume(); // android.support.v4.app.Fragment.performResume -> void
        v10.mSavedFragmentState = v7; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v10.mSavedViewState = v7; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        // goto L_0045
        v10.mInnerView = v7; // android.support.v4.app.Fragment.mInnerView:android.view.View
        // goto L_012e
        v10.mInnerView = v7; // android.support.v4.app.Fragment.mInnerView:android.view.View
        // goto L_01ec
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        if (v0 <= v11) /* goto L_0045 */;
        v0 = v10.mState; // android.support.v4.app.Fragment.mState:int
        // switch(v0)
        // goto L_0045
        if (v11 >= v5) /* goto L_0045 */;
        v0 = v9.t; // android.support.v4.app.y.t:boolean
        if (v0 == 0) /* goto L_026d */;
        v0 = v10.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        if (v0 == 0) /* goto L_026d */;
        v0 = v10.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        v10.mAnimatingAway = v7; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        _result = v0.clearAnimation(); // android.view.View.clearAnimation -> void
        v0 = v10.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        if (v0 == 0) /* goto L_0351 */;
        v10.mStateAfterAnimating = v11; // android.support.v4.app.Fragment.mStateAfterAnimating:int
        v11 = v5;
        // goto L_0045
        v0 = 5;
        if (v11 >= v0) /* goto L_029c */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0297 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "movefrom RESUMED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        _result = v10.performPause(); // android.support.v4.app.Fragment.performPause -> void
        v10.mResumed = v3; // android.support.v4.app.Fragment.mResumed:boolean
        if (v11 >= v8) /* goto L_02bf */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_02bc */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "movefrom STARTED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        _result = v10.performStop(); // android.support.v4.app.Fragment.performStop -> void
        if (v11 >= v6) /* goto L_02e2 */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_02df */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "movefrom STOPPED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        _result = v10.performReallyStop(); // android.support.v4.app.Fragment.performReallyStop -> void
        v0 = 2;
        if (v11 >= v0) /* goto L_025c */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0303 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "movefrom ACTIVITY_CREATED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_0316 */;
        v0 = v9.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v0.isFinishing(); // android.support.v4.app.FragmentActivity.isFinishing -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0316 */;
        v0 = v10.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        if (v0 != 0) /* goto L_0316 */;
        _result = v9.f(v10); // android.support.v4.app.y.f -> void
        _result = v10.performDestroyView(); // android.support.v4.app.Fragment.performDestroyView -> void
        v0 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_0349 */;
        v0 = v10.mContainer; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        if (v0 == 0) /* goto L_0349 */;
        v0 = v9.n; // android.support.v4.app.y.n:int
        if (v0 <= 0) /* goto L_03b1 */;
        v0 = v9.t; // android.support.v4.app.y.t:boolean
        if (v0 != 0) /* goto L_03b1 */;
        _result = v9.a(v10, v12, v3, v13); // android.support.v4.app.y.a -> android.view.animation.Animation
        v0 = _result;
        if (v0 == 0) /* goto L_0342 */;
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v10.mAnimatingAway = v1; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        v10.mStateAfterAnimating = v11; // android.support.v4.app.Fragment.mStateAfterAnimating:int
        v1 = new android.support.v4.app.ab;
        _result = v1.<init>(v9, v10); // android.support.v4.app.ab.<init> -> void
        _result = v0.setAnimationListener(v1); // android.view.animation.Animation.setAnimationListener -> void
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v1.startAnimation(v0); // android.view.View.startAnimation -> void
        v0 = v10.mContainer; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        v1 = v10.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.removeView(v1); // android.view.ViewGroup.removeView -> void
        v10.mContainer = v7; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        v10.mView = v7; // android.support.v4.app.Fragment.mView:android.view.View
        v10.mInnerView = v7; // android.support.v4.app.Fragment.mInnerView:android.view.View
        // goto L_025c
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_036f */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "movefrom CREATED: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v10.mRetaining; // android.support.v4.app.Fragment.mRetaining:boolean
        if (v0 != 0) /* goto L_0376 */;
        _result = v10.performDestroy(); // android.support.v4.app.Fragment.performDestroy -> void
        v10.mCalled = v3; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v10.onDetach(); // android.support.v4.app.Fragment.onDetach -> void
        v0 = v10.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_03a0 */;
        v0 = new android.support.v4.app.bg;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onDetach()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.bg.<init> -> void
        throw v0;
        if (v14 != 0) /* goto L_0045 */;
        v0 = v10.mRetaining; // android.support.v4.app.Fragment.mRetaining:boolean
        if (v0 != 0) /* goto L_03ab */;
        _result = v9.e(v10); // android.support.v4.app.y.e -> void
        // goto L_0045
        v10.mActivity = v7; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v10.mFragmentManager = v7; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.y
        // goto L_0045
        v0 = v7;
        // goto L_032d
        v0 = v7;
        // goto L_01a8
    }

    public void a(android.support.v4.app.Fragment p0, boolean p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.support.v4.app.Fragment), v6 = p1 (boolean)
        v3 = 1;
        v0 = v4.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 != 0) /* goto L_000c */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v4.g = v0; // android.support.v4.app.y.g:java.util.ArrayList
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_002a */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "add: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        _result = v4.d(v5); // android.support.v4.app.y.d -> void
        v0 = v5.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        if (v0 != 0) /* goto L_006c */;
        v0 = v4.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.contains(v5); // java.util.ArrayList.contains -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0053 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment already added: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v4.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.add(v5); // java.util.ArrayList.add -> boolean
        v5.mAdded = v3; // android.support.v4.app.Fragment.mAdded:boolean
        v0 = 0;
        v5.mRemoving = v0; // android.support.v4.app.Fragment.mRemoving:boolean
        v0 = v5.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_0067 */;
        v0 = v5.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == 0) /* goto L_0067 */;
        v4.r = v3; // android.support.v4.app.y.r:boolean
        if (v6 == 0) /* goto L_006c */;
        _result = v4.c(v5); // android.support.v4.app.y.c -> void
        return;
    }

    public void a(android.support.v4.app.FragmentActivity p0, android.support.v4.app.v p1, android.support.v4.app.Fragment p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.support.v4.app.FragmentActivity), v4 = p1 (android.support.v4.app.v), v5 = p2 (android.support.v4.app.Fragment)
        v0 = v2.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Already attached";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v2.o = v3; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v2.p = v4; // android.support.v4.app.y.p:android.support.v4.app.v
        v2.q = v5; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        return;
    }

    public void a(java.lang.Runnable p0, boolean p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.Runnable), v4 = p1 (boolean)
        if (v4 != 0) /* goto L_0005 */;
        _result = v2.u(); // android.support.v4.app.y.u -> void
        // monitor-enter(v2)
        v0 = v2.t; // android.support.v4.app.y.t:boolean
        if (v0 != 0) /* goto L_000e */;
        v0 = v2.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_001a */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Activity has been destroyed";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = _exception;
        // monitor-exit(v2)
        throw v0;
        v0 = v2.c; // android.support.v4.app.y.c:java.util.ArrayList
        if (v0 != 0) /* goto L_0025 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v2.c = v0; // android.support.v4.app.y.c:java.util.ArrayList
        v0 = v2.c; // android.support.v4.app.y.c:java.util.ArrayList
        _result = v0.add(v3); // java.util.ArrayList.add -> boolean
        v0 = v2.c; // android.support.v4.app.y.c:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v1 = 1;
        if (v0 != v1) /* goto L_0045 */;
        v0 = v2.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v0 = v0.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        v1 = v2.y; // android.support.v4.app.y.y:java.lang.Runnable
        _result = v0.removeCallbacks(v1); // android.os.Handler.removeCallbacks -> void
        v0 = v2.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v0 = v0.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        v1 = v2.y; // android.support.v4.app.y.y:java.lang.Runnable
        _result = v0.post(v1); // android.os.Handler.post -> boolean
        // monitor-exit(v2)
        return;
    }

    public void a(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (11 total): v6 = this, v7 = p0 (java.lang.String), v8 = p1 (java.io.FileDescriptor), v9 = p2 (java.io.PrintWriter), v10 = p3 (java.lang.String[])
        v1 = 0;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = "    ";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v0 = v6.f; // android.support.v4.app.y.f:java.util.ArrayList
        if (v0 == 0) /* goto L_0064 */;
        v0 = v6.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        if (v4 <= 0) /* goto L_0064 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Active Fragments in ";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        _result = v6.identityHashCode(); // java.lang.System.identityHashCode -> int
        v0 = _result;
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = ":";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v2 = v1;
        if (v2 >= v4) /* goto L_0064 */;
        v0 = v6.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v5 = "  #";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.print(v2); // java.io.PrintWriter.print -> void
        v5 = ": ";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        if (v0 == 0) /* goto L_0060 */;
        _result = v0.dump(v3, v8, v9, v10); // android.support.v4.app.Fragment.dump -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_003c
        v0 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 == 0) /* goto L_00a1 */;
        v0 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        if (v4 <= 0) /* goto L_00a1 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Added Fragments:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v2 = v1;
        if (v2 >= v4) /* goto L_00a1 */;
        v0 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v5 = "  #";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.print(v2); // java.io.PrintWriter.print -> void
        v5 = ": ";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v0.toString(); // android.support.v4.app.Fragment.toString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_007a
        v0 = v6.j; // android.support.v4.app.y.j:java.util.ArrayList
        if (v0 == 0) /* goto L_00de */;
        v0 = v6.j; // android.support.v4.app.y.j:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        if (v4 <= 0) /* goto L_00de */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Fragments Created Menus:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v2 = v1;
        if (v2 >= v4) /* goto L_00de */;
        v0 = v6.j; // android.support.v4.app.y.j:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v5 = "  #";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.print(v2); // java.io.PrintWriter.print -> void
        v5 = ": ";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v0.toString(); // android.support.v4.app.Fragment.toString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_00b7
        v0 = v6.i; // android.support.v4.app.y.i:java.util.ArrayList
        if (v0 == 0) /* goto L_011e */;
        v0 = v6.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v4 = _result;
        if (v4 <= 0) /* goto L_011e */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Back Stack:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v2 = v1;
        if (v2 >= v4) /* goto L_011e */;
        v0 = v6.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.l) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v5 = "  #";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.print(v2); // java.io.PrintWriter.print -> void
        v5 = ": ";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v0.toString(); // android.support.v4.app.l.toString -> java.lang.String
        v5 = _result;
        _result = v9.println(v5); // java.io.PrintWriter.println -> void
        _result = v0.a(v3, v8, v9, v10); // android.support.v4.app.l.a -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_00f4
        // monitor-enter(v6)
        v0 = v6.k; // android.support.v4.app.y.k:java.util.ArrayList
        if (v0 == 0) /* goto L_0158 */;
        v0 = v6.k; // android.support.v4.app.y.k:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v3 = _result;
        if (v3 <= 0) /* goto L_0158 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Back Stack Indices:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v2 = v1;
        if (v2 >= v3) /* goto L_0158 */;
        v0 = v6.k; // android.support.v4.app.y.k:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.l) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v4 = "  #";
        _result = v9.print(v4); // java.io.PrintWriter.print -> void
        _result = v9.print(v2); // java.io.PrintWriter.print -> void
        v4 = ": ";
        _result = v9.print(v4); // java.io.PrintWriter.print -> void
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0135
        v0 = v6.l; // android.support.v4.app.y.l:java.util.ArrayList
        if (v0 == 0) /* goto L_017a */;
        v0 = v6.l; // android.support.v4.app.y.l:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_017a */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "mAvailBackStackIndices: ";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.l; // android.support.v4.app.y.l:java.util.ArrayList
        _result = v0.toArray(); // java.util.ArrayList.toArray -> java.lang.Object[]
        v0 = _result;
        _result = v0.toString(); // java.util.Arrays.toString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        // monitor-exit(v6)
        v0 = v6.c; // android.support.v4.app.y.c:java.util.ArrayList
        if (v0 == 0) /* goto L_01b6 */;
        v0 = v6.c; // android.support.v4.app.y.c:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        if (v2 <= 0) /* goto L_01b6 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "Pending Actions:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        if (v1 >= v2) /* goto L_01b6 */;
        v0 = v6.c; // android.support.v4.app.y.c:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Runnable) v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v3 = "  #";
        _result = v9.print(v3); // java.io.PrintWriter.print -> void
        _result = v9.print(v1); // java.io.PrintWriter.print -> void
        v3 = ": ";
        _result = v9.print(v3); // java.io.PrintWriter.print -> void
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0190
        v0 = _exception;
        // monitor-exit(v6)
        throw v0;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "FragmentManager misc state:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  mActivity=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  mContainer=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.p; // android.support.v4.app.y.p:android.support.v4.app.v
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.q; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_01ed */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  mParent=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.q; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  mCurState=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.n; // android.support.v4.app.y.n:int
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mStateSaved=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.s; // android.support.v4.app.y.s:boolean
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mDestroyed=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.t; // android.support.v4.app.y.t:boolean
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.r; // android.support.v4.app.y.r:boolean
        if (v0 == 0) /* goto L_0223 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  mNeedMenuInvalidate=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.r; // android.support.v4.app.y.r:boolean
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.u; // android.support.v4.app.y.u:java.lang.String
        if (v0 == 0) /* goto L_0235 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  mNoTransactionsBecause=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.u; // android.support.v4.app.y.u:java.lang.String
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v6.h; // android.support.v4.app.y.h:java.util.ArrayList
        if (v0 == 0) /* goto L_0257 */;
        v0 = v6.h; // android.support.v4.app.y.h:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0257 */;
        _result = v9.print(v7); // java.io.PrintWriter.print -> void
        v0 = "  mAvailIndices: ";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v6.h; // android.support.v4.app.y.h:java.util.ArrayList
        _result = v0.toArray(); // java.util.ArrayList.toArray -> java.lang.Object[]
        v0 = _result;
        _result = v0.toString(); // java.util.Arrays.toString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        return;
    }

    boolean a(android.os.Handler p0, java.lang.String p1, int p2, int p3) {
        // Registers (13 total): v8 = this, v9 = p0 (android.os.Handler), v10 = p1 (java.lang.String), v11 = p2 (int), v12 = p3 (int)
        v2 = 1;
        v3 = 0;
        v0 = v8.i; // android.support.v4.app.y.i:java.util.ArrayList
        if (v0 != 0) /* goto L_0007 */;
        return v3;
        if (v10 != 0) /* goto L_0029 */;
        if (v11 >= 0) /* goto L_0029 */;
        v0 = binOpLit8_0xdd(v12, 1);
        if (v0 != 0) /* goto L_0029 */;
        v0 = v8.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        if (v0 < 0) /* goto L_0006 */;
        v1 = v8.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v1.remove(v0); // java.util.ArrayList.remove -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.l) v0;
        _result = v0.b(v2); // android.support.v4.app.l.b -> void
        _result = v8.g(); // android.support.v4.app.y.g -> void
        v3 = v2;
        // goto L_0006
        v0 = -1;
        if (v10 != 0) /* goto L_002e */;
        if (v11 < 0) /* goto L_007d */;
        v0 = v8.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v1 = binOpLit8_0xd8(v0, -1);
        if (v1 < 0) /* goto L_004c */;
        v0 = v8.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.l) v0;
        if (v10 == 0) /* goto L_0073 */;
        _result = v0.d(); // android.support.v4.app.l.d -> java.lang.String
        v4 = _result;
        _result = v10.equals(v4); // java.lang.String.equals -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_0073 */;
        if (v1 < 0) /* goto L_0006 */;
        v0 = binOpLit8_0xdd(v12, 1);
        if (v0 == 0) /* goto L_007c */;
        v1 = binOpLit8_0xd8(v1, -1);
        if (v1 < 0) /* goto L_007c */;
        v0 = v8.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.l) v0;
        if (v10 == 0) /* goto L_006a */;
        _result = v0.d(); // android.support.v4.app.l.d -> java.lang.String
        v4 = _result;
        _result = v10.equals(v4); // java.lang.String.equals -> boolean
        v4 = _result;
        if (v4 != 0) /* goto L_0070 */;
        if (v11 < 0) /* goto L_007c */;
        v0 = v0.o; // android.support.v4.app.l.o:int
        if (v11 != v0) /* goto L_007c */;
        v1 = binOpLit8_0xd8(v1, -1);
        // goto L_0054
        if (v11 < 0) /* goto L_0079 */;
        v0 = v0.o; // android.support.v4.app.l.o:int
        if (v11 == v0) /* goto L_004c */;
        v1 = binOpLit8_0xd8(v1, -1);
        // goto L_0036
        v0 = v1;
        v1 = v8.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        if (v0 == v1) /* goto L_0006 */;
        v5 = new java.util.ArrayList;
        _result = v5.<init>(); // java.util.ArrayList.<init> -> void
        v1 = v8.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        if (v1 <= v0) /* goto L_00a2 */;
        v4 = v8.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v4.remove(v1); // java.util.ArrayList.remove -> java.lang.Object
        v4 = _result;
        _result = v5.add(v4); // java.util.ArrayList.add -> boolean
        v1 = binOpLit8_0xd8(v1, -1);
        // goto L_0094
        _result = v5.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v6 = binOpLit8_0xd8(v0, -1);
        v4 = v3;
        if (v4 > v6) /* goto L_00df */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_00cd */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v7 = "Popping back stack state: ";
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v5.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v7 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        _result = v5.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.l) v0;
        if (v4 != v6) /* goto L_00dd */;
        v1 = v2;
        _result = v0.b(v1); // android.support.v4.app.l.b -> void
        v0 = binOpLit8_0xd8(v4, 1);
        v4 = v0;
        // goto L_00a9
        v1 = v3;
        // goto L_00d6
        _result = v8.g(); // android.support.v4.app.y.g -> void
        // goto L_0027
    }

    public boolean a(android.view.Menu p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.Menu)
        v0 = 0;
        v1 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v1 == 0) /* goto L_0024 */;
        v1 = v0;
        v2 = v0;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0025 */;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0020 */;
        _result = v0.performPrepareOptionsMenu(v4); // android.support.v4.app.Fragment.performPrepareOptionsMenu -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0020 */;
        v2 = 1;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0007
        v2 = v0;
        return v2;
    }

    public boolean a(android.view.Menu p0, android.view.MenuInflater p1) {
        // Registers (9 total): v6 = this, v7 = p0 (android.view.Menu), v8 = p1 (android.view.MenuInflater)
        v4 = 0;
        v1 = 0;
        v0 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 == 0) /* goto L_0031 */;
        v3 = v4;
        v2 = v4;
        v0 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_0032 */;
        v0 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_002b */;
        _result = v0.performCreateOptionsMenu(v7, v8); // android.support.v4.app.Fragment.performCreateOptionsMenu -> boolean
        v5 = _result;
        if (v5 == 0) /* goto L_002b */;
        v2 = 1;
        if (v1 != 0) /* goto L_0028 */;
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        _result = v1.add(v0); // java.util.ArrayList.add -> boolean
        v0 = v2;
        v2 = binOpLit8_0xd8(v3, 1);
        v3 = v2;
        v2 = v0;
        // goto L_0008
        v2 = v4;
        v0 = v6.j; // android.support.v4.app.y.j:java.util.ArrayList
        if (v0 == 0) /* goto L_0054 */;
        v0 = v6.j; // android.support.v4.app.y.j:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v4 >= v0) /* goto L_0054 */;
        v0 = v6.j; // android.support.v4.app.y.j:java.util.ArrayList
        _result = v0.get(v4); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v1 == 0) /* goto L_004e */;
        _result = v1.contains(v0); // java.util.ArrayList.contains -> boolean
        v3 = _result;
        if (v3 != 0) /* goto L_0051 */;
        _result = v0.onDestroyOptionsMenu(); // android.support.v4.app.Fragment.onDestroyOptionsMenu -> void
        v4 = binOpLit8_0xd8(v4, 1);
        // goto L_0036
        v6.j = v1; // android.support.v4.app.y.j:java.util.ArrayList
        return v2;
    }

    public boolean a(android.view.MenuItem p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.MenuItem)
        v2 = 0;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 == 0) /* goto L_001f */;
        v1 = v2;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001f */;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0020 */;
        _result = v0.performOptionsItemSelected(v4); // android.support.v4.app.Fragment.performOptionsItemSelected -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0020 */;
        v2 = 1;
        return v2;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
    }

    public android.support.v4.app.Fragment b(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = v2.f; // android.support.v4.app.y.f:java.util.ArrayList
        if (v0 == 0) /* goto L_0026 */;
        if (v3 == 0) /* goto L_0026 */;
        v0 = v2.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0026 */;
        v0 = v2.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0022 */;
        _result = v0.findFragmentByWho(v3); // android.support.v4.app.Fragment.findFragmentByWho -> android.support.v4.app.Fragment
        v0 = _result;
        if (v0 == 0) /* goto L_0022 */;
        return v0;
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_000f
        v0 = 0;
        // goto L_0021
    }

    public void b(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        // monitor-enter(v3)
        v0 = v3.k; // android.support.v4.app.y.k:java.util.ArrayList
        v1 = 0;
        _result = v0.set(v4, v1); // java.util.ArrayList.set -> java.lang.Object
        v0 = v3.l; // android.support.v4.app.y.l:java.util.ArrayList
        if (v0 != 0) /* goto L_0012 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v3.l = v0; // android.support.v4.app.y.l:java.util.ArrayList
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0030 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Freeing back stack index ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v3.l; // android.support.v4.app.y.l:java.util.ArrayList
        _result = v4.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        // monitor-exit(v3)
        return;
        v0 = _exception;
        // monitor-exit(v3)
        throw v0;
    }

    public void b(android.support.v4.app.Fragment p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment)
        v3 = 0;
        v0 = v7.mDeferStart; // android.support.v4.app.Fragment.mDeferStart:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = v6.e; // android.support.v4.app.y.e:boolean
        if (v0 == 0) /* goto L_000d */;
        v0 = 1;
        v6.v = v0; // android.support.v4.app.y.v:boolean
        return;
        v7.mDeferStart = v3; // android.support.v4.app.Fragment.mDeferStart:boolean
        v2 = v6.n; // android.support.v4.app.y.n:int
        v0 = v6;
        v1 = v7;
        v4 = v3;
        v5 = v3;
        _result = v0.a(v0..v5); // android.support.v4.app.y.a -> void
        // goto L_000c
    }

    public void b(android.support.v4.app.Fragment p0, int p1, int p2) {
        // Registers (8 total): v4 = this, v5 = p0 (android.support.v4.app.Fragment), v6 = p1 (int), v7 = p2 (int)
        v3 = 1;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_001f */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "hide: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v5.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v0 != 0) /* goto L_004d */;
        v5.mHidden = v3; // android.support.v4.app.Fragment.mHidden:boolean
        v0 = v5.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_003c */;
        v0 = 0;
        _result = v4.a(v5, v6, v0, v7); // android.support.v4.app.y.a -> android.view.animation.Animation
        v0 = _result;
        if (v0 == 0) /* goto L_0035 */;
        v1 = v5.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v1.startAnimation(v0); // android.view.View.startAnimation -> void
        v0 = v5.mView; // android.support.v4.app.Fragment.mView:android.view.View
        v1 = 8;
        _result = v0.setVisibility(v1); // android.view.View.setVisibility -> void
        v0 = v5.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 == 0) /* goto L_004a */;
        v0 = v5.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_004a */;
        v0 = v5.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == 0) /* goto L_004a */;
        v4.r = v3; // android.support.v4.app.y.r:boolean
        _result = v5.onHiddenChanged(v3); // android.support.v4.app.Fragment.onHiddenChanged -> void
        return;
    }

    void b(android.support.v4.app.l p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.l)
        v0 = v1.i; // android.support.v4.app.y.i:java.util.ArrayList
        if (v0 != 0) /* goto L_000b */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.i = v0; // android.support.v4.app.y.i:java.util.ArrayList
        v0 = v1.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        _result = v1.g(); // android.support.v4.app.y.g -> void
        return;
    }

    public void b(android.view.Menu p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.Menu)
        v0 = v2.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 == 0) /* goto L_001f */;
        v0 = 0;
        v1 = v0;
        v0 = v2.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001f */;
        v0 = v2.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_001b */;
        _result = v0.performOptionsMenuClosed(v3); // android.support.v4.app.Fragment.performOptionsMenuClosed -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
        return;
    }

    public boolean b() {
        // Registers (2 total): v1 = this
        _result = v1.f(); // android.support.v4.app.y.f -> boolean
        v0 = _result;
        return v0;
    }

    public boolean b(android.view.MenuItem p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.MenuItem)
        v2 = 0;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 == 0) /* goto L_001f */;
        v1 = v2;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001f */;
        v0 = v3.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0020 */;
        _result = v0.performContextItemSelected(v4); // android.support.v4.app.Fragment.performContextItemSelected -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0020 */;
        v2 = 1;
        return v2;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
    }

    public java.util.List c() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // android.support.v4.app.y.f:java.util.ArrayList
        return v0;
    }

    void c(android.support.v4.app.Fragment p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment)
        v3 = 0;
        v2 = v6.n; // android.support.v4.app.y.n:int
        v0 = v6;
        v1 = v7;
        v4 = v3;
        v5 = v3;
        _result = v0.a(v0..v5); // android.support.v4.app.y.a -> void
        return;
    }

    public void c(android.support.v4.app.Fragment p0, int p1, int p2) {
        // Registers (9 total): v5 = this, v6 = p0 (android.support.v4.app.Fragment), v7 = p1 (int), v8 = p2 (int)
        v4 = 1;
        v3 = 0;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0020 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "show: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v6.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v0 == 0) /* goto L_004b */;
        v6.mHidden = v3; // android.support.v4.app.Fragment.mHidden:boolean
        v0 = v6.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_003a */;
        _result = v5.a(v6, v7, v4, v8); // android.support.v4.app.y.a -> android.view.animation.Animation
        v0 = _result;
        if (v0 == 0) /* goto L_0035 */;
        v1 = v6.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v1.startAnimation(v0); // android.view.View.startAnimation -> void
        v0 = v6.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.setVisibility(v3); // android.view.View.setVisibility -> void
        v0 = v6.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 == 0) /* goto L_0048 */;
        v0 = v6.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_0048 */;
        v0 = v6.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == 0) /* goto L_0048 */;
        v5.r = v4; // android.support.v4.app.y.r:boolean
        _result = v6.onHiddenChanged(v3); // android.support.v4.app.Fragment.onHiddenChanged -> void
        return;
    }

    void d(android.support.v4.app.Fragment p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.support.v4.app.Fragment)
        v0 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v0 < 0) /* goto L_0005 */;
        return;
        v0 = v3.h; // android.support.v4.app.y.h:java.util.ArrayList
        if (v0 == 0) /* goto L_0011 */;
        v0 = v3.h; // android.support.v4.app.y.h:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > 0) /* goto L_004b */;
        v0 = v3.f; // android.support.v4.app.y.f:java.util.ArrayList
        if (v0 != 0) /* goto L_001c */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v3.f = v0; // android.support.v4.app.y.f:java.util.ArrayList
        v0 = v3.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v1 = v3.q; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        _result = v4.setIndex(v0, v1); // android.support.v4.app.Fragment.setIndex -> void
        v0 = v3.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.add(v4); // java.util.ArrayList.add -> boolean
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0004 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Allocated fragment index ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        // goto L_0004
        v0 = v3.h; // android.support.v4.app.y.h:java.util.ArrayList
        v1 = v3.h; // android.support.v4.app.y.h:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        _result = v0.remove(v1); // java.util.ArrayList.remove -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Integer) v0;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        v1 = v3.q; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        _result = v4.setIndex(v0, v1); // android.support.v4.app.Fragment.setIndex -> void
        v0 = v3.f; // android.support.v4.app.y.f:java.util.ArrayList
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v0.set(v1, v4); // java.util.ArrayList.set -> java.lang.Object
        // goto L_002c
    }

    public void d(android.support.v4.app.Fragment p0, int p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment), v8 = p1 (int), v9 = p2 (int)
        v5 = 0;
        v2 = 1;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0020 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "detach: ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v7.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        if (v0 != 0) /* goto L_0064 */;
        v7.mDetached = v2; // android.support.v4.app.Fragment.mDetached:boolean
        v0 = v7.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 == 0) /* goto L_0064 */;
        v0 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 == 0) /* goto L_0051 */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_004c */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "remove from detach: ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.remove(v7); // java.util.ArrayList.remove -> boolean
        v0 = v7.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_005b */;
        v0 = v7.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == 0) /* goto L_005b */;
        v6.r = v2; // android.support.v4.app.y.r:boolean
        v7.mAdded = v5; // android.support.v4.app.Fragment.mAdded:boolean
        v0 = v6;
        v1 = v7;
        v3 = v8;
        v4 = v9;
        _result = v0.a(v0..v5); // android.support.v4.app.y.a -> void
        return;
    }

    public boolean d() {
        // Registers (5 total): v4 = this
        _result = v4.u(); // android.support.v4.app.y.u -> void
        _result = v4.b(); // android.support.v4.app.y.b -> boolean
        v0 = v4.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v0 = v0.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        v1 = 0;
        v2 = -1;
        v3 = 0;
        _result = v4.a(v0, v1, v2, v3); // android.support.v4.app.y.a -> boolean
        v0 = _result;
        return v0;
    }

    void e() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // android.support.v4.app.y.f:java.util.ArrayList
        if (v0 != 0) /* goto L_0005 */;
        return;
        v0 = 0;
        v1 = v0;
        v0 = v2.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0004 */;
        v0 = v2.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_001c */;
        _result = v2.b(v0); // android.support.v4.app.y.b -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0007
    }

    void e(android.support.v4.app.Fragment p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.support.v4.app.Fragment)
        v0 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v0 >= 0) /* goto L_0005 */;
        return;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0023 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Freeing fragment index ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v3.f; // android.support.v4.app.y.f:java.util.ArrayList
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v2 = 0;
        _result = v0.set(v1, v2); // java.util.ArrayList.set -> java.lang.Object
        v0 = v3.h; // android.support.v4.app.y.h:java.util.ArrayList
        if (v0 != 0) /* goto L_0036 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v3.h = v0; // android.support.v4.app.y.h:java.util.ArrayList
        v0 = v3.h; // android.support.v4.app.y.h:java.util.ArrayList
        v1 = v4.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        v0 = v3.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v1 = v4.mWho; // android.support.v4.app.Fragment.mWho:java.lang.String
        _result = v0.a(v1); // android.support.v4.app.FragmentActivity.a -> void
        _result = v4.initState(); // android.support.v4.app.Fragment.initState -> void
        // goto L_0004
    }

    public void e(android.support.v4.app.Fragment p0, int p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (android.support.v4.app.Fragment), v8 = p1 (int), v9 = p2 (int)
        v3 = 1;
        v5 = 0;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0020 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "attach: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v7.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        if (v0 == 0) /* goto L_008f */;
        v7.mDetached = v5; // android.support.v4.app.Fragment.mDetached:boolean
        v0 = v7.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 != 0) /* goto L_008f */;
        v0 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 != 0) /* goto L_0035 */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v6.g = v0; // android.support.v4.app.y.g:java.util.ArrayList
        v0 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.contains(v7); // java.util.ArrayList.contains -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0057 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment already added: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0075 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "add from attach: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v6.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.add(v7); // java.util.ArrayList.add -> boolean
        v7.mAdded = v3; // android.support.v4.app.Fragment.mAdded:boolean
        v0 = v7.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_0086 */;
        v0 = v7.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == 0) /* goto L_0086 */;
        v6.r = v3; // android.support.v4.app.y.r:boolean
        v2 = v6.n; // android.support.v4.app.y.n:int
        v0 = v6;
        v1 = v7;
        v3 = v8;
        v4 = v9;
        _result = v0.a(v0..v5); // android.support.v4.app.y.a -> void
        return;
    }

    void f(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = v3.mInnerView; // android.support.v4.app.Fragment.mInnerView:android.view.View
        if (v0 != 0) /* goto L_0005 */;
        return;
        v0 = v2.x; // android.support.v4.app.y.x:android.util.SparseArray
        if (v0 != 0) /* goto L_0027 */;
        v0 = new android.util.SparseArray;
        _result = v0.<init>(); // android.util.SparseArray.<init> -> void
        v2.x = v0; // android.support.v4.app.y.x:android.util.SparseArray
        v0 = v3.mInnerView; // android.support.v4.app.Fragment.mInnerView:android.view.View
        v1 = v2.x; // android.support.v4.app.y.x:android.util.SparseArray
        _result = v0.saveHierarchyState(v1); // android.view.View.saveHierarchyState -> void
        v0 = v2.x; // android.support.v4.app.y.x:android.util.SparseArray
        _result = v0.size(); // android.util.SparseArray.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0004 */;
        v0 = v2.x; // android.support.v4.app.y.x:android.util.SparseArray
        v3.mSavedViewState = v0; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        v0 = 0;
        v2.x = v0; // android.support.v4.app.y.x:android.util.SparseArray
        // goto L_0004
        v0 = v2.x; // android.support.v4.app.y.x:android.util.SparseArray
        _result = v0.clear(); // android.util.SparseArray.clear -> void
        // goto L_0010
    }

    public boolean f() {
        // Registers (7 total): v6 = this
        v0 = 1;
        v2 = 0;
        v1 = v6.e; // android.support.v4.app.y.e:boolean
        if (v1 == 0) /* goto L_000f */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Recursive entry to executePendingTransactions";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        _result = this.myLooper(); // android.os.Looper.myLooper -> android.os.Looper
        v1 = _result;
        v3 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v3 = v3.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        _result = v3.getLooper(); // android.os.Handler.getLooper -> android.os.Looper
        v3 = _result;
        if (v1 == v3) /* goto L_0026 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Must be called from main thread of process";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v1 = v2;
        // monitor-enter(v6)
        v3 = v6.c; // android.support.v4.app.y.c:java.util.ArrayList
        if (v3 == 0) /* goto L_0034 */;
        v3 = v6.c; // android.support.v4.app.y.c:java.util.ArrayList
        _result = v3.size(); // java.util.ArrayList.size -> int
        v3 = _result;
        if (v3 != 0) /* goto L_005c */;
        // monitor-exit(v6)
        v0 = v6.v; // android.support.v4.app.y.v:boolean
        if (v0 == 0) /* goto L_00a7 */;
        v3 = v2;
        v4 = v2;
        v0 = v6.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_00a0 */;
        v0 = v6.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0058 */;
        v5 = v0.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        if (v5 == 0) /* goto L_0058 */;
        v0 = v0.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        _result = v0.a(); // android.support.v4.app.ao.a -> boolean
        v0 = _result;
        v4 = binOp2addr_0xb6(v4, v0);
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_003b
        v1 = v6.c; // android.support.v4.app.y.c:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v3 = _result;
        v1 = v6.d; // android.support.v4.app.y.d:java.lang.Runnable[]
        if (v1 == 0) /* goto L_006b */;
        v1 = v6.d; // android.support.v4.app.y.d:java.lang.Runnable[]
        v1 = v1.length;
        if (v1 >= v3) /* goto L_006f */;
        v1 = new java.lang.Runnable[][size=v3];
        v6.d = v1; // android.support.v4.app.y.d:java.lang.Runnable[]
        v1 = v6.c; // android.support.v4.app.y.c:java.util.ArrayList
        v4 = v6.d; // android.support.v4.app.y.d:java.lang.Runnable[]
        _result = v1.toArray(v4); // java.util.ArrayList.toArray -> java.lang.Object[]
        v1 = v6.c; // android.support.v4.app.y.c:java.util.ArrayList
        _result = v1.clear(); // java.util.ArrayList.clear -> void
        v1 = v6.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v1 = v1.a; // android.support.v4.app.FragmentActivity.a:android.os.Handler
        v4 = v6.y; // android.support.v4.app.y.y:java.lang.Runnable
        _result = v1.removeCallbacks(v4); // android.os.Handler.removeCallbacks -> void
        // monitor-exit(v6)
        v6.e = v0; // android.support.v4.app.y.e:boolean
        v1 = v2;
        if (v1 >= v3) /* goto L_009c */;
        v4 = v6.d; // android.support.v4.app.y.d:java.lang.Runnable[]
        v4 = v4[v1];
        _result = java.lang.Runnable.run(v4); // -> void
        v4 = v6.d; // android.support.v4.app.y.d:java.lang.Runnable[]
        v5 = 0;
        v4[v1] = v5;
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0088
        v0 = _exception;
        // monitor-exit(v6)
        throw v0;
        v6.e = v2; // android.support.v4.app.y.e:boolean
        v1 = v0;
        // goto L_0027
        if (v4 != 0) /* goto L_00a7 */;
        v6.v = v2; // android.support.v4.app.y.v:boolean
        _result = v6.e(); // android.support.v4.app.y.e -> void
        return v1;
    }

    android.os.Bundle g(android.support.v4.app.Fragment p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.support.v4.app.Fragment)
        v1 = 0;
        v0 = v3.w; // android.support.v4.app.y.w:android.os.Bundle
        if (v0 != 0) /* goto L_000c */;
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        v3.w = v0; // android.support.v4.app.y.w:android.os.Bundle
        v0 = v3.w; // android.support.v4.app.y.w:android.os.Bundle
        _result = v4.performSaveInstanceState(v0); // android.support.v4.app.Fragment.performSaveInstanceState -> void
        v0 = v3.w; // android.support.v4.app.y.w:android.os.Bundle
        _result = v0.isEmpty(); // android.os.Bundle.isEmpty -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_004b */;
        v0 = v3.w; // android.support.v4.app.y.w:android.os.Bundle
        v3.w = v1; // android.support.v4.app.y.w:android.os.Bundle
        v1 = v4.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v1 == 0) /* goto L_0024 */;
        _result = v3.f(v4); // android.support.v4.app.y.f -> void
        v1 = v4.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        if (v1 == 0) /* goto L_0037 */;
        if (v0 != 0) /* goto L_002f */;
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        v1 = "android:view_state";
        v2 = v4.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        _result = v0.putSparseParcelableArray(v1, v2); // android.os.Bundle.putSparseParcelableArray -> void
        v1 = v4.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        if (v1 != 0) /* goto L_004a */;
        if (v0 != 0) /* goto L_0042 */;
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        v1 = "android:user_visible_hint";
        v2 = v4.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        _result = v0.putBoolean(v1, v2); // android.os.Bundle.putBoolean -> void
        return v0;
        v0 = v1;
        // goto L_001d
    }

    void g() {
        // Registers (3 total): v2 = this
        v0 = v2.m; // android.support.v4.app.y.m:java.util.ArrayList
        if (v0 == 0) /* goto L_001d */;
        v0 = 0;
        v1 = v0;
        v0 = v2.m; // android.support.v4.app.y.m:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001d */;
        v0 = v2.m; // android.support.v4.app.y.m:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.x) v0;
        _result = android.support.v4.app.x.a(v0); // -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
        return;
    }

    java.util.ArrayList h() {
        // Registers (7 total): v6 = this
        v1 = 0;
        v0 = v6.f; // android.support.v4.app.y.f:java.util.ArrayList
        if (v0 == 0) /* goto L_0058 */;
        v0 = 0;
        v3 = v0;
        v0 = v6.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v3 >= v0) /* goto L_0058 */;
        v0 = v6.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.get(v3); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0052 */;
        v2 = v0.mRetainInstance; // android.support.v4.app.Fragment.mRetainInstance:boolean
        if (v2 == 0) /* goto L_0052 */;
        if (v1 != 0) /* goto L_0024 */;
        v1 = new java.util.ArrayList;
        _result = v1.<init>(); // java.util.ArrayList.<init> -> void
        _result = v1.add(v0); // java.util.ArrayList.add -> boolean
        v2 = 1;
        v0.mRetaining = v2; // android.support.v4.app.Fragment.mRetaining:boolean
        v2 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        if (v2 == 0) /* goto L_0056 */;
        v2 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v2 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v0.mTargetIndex = v2; // android.support.v4.app.Fragment.mTargetIndex:int
        v2 = android.support.v4.app.y.a; // :boolean
        if (v2 == 0) /* goto L_0052 */;
        v2 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "retainNonConfig: keeping retained ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v2.v(v0); // android.util.Log.v -> int
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_0007
        v2 = -1;
        // goto L_0032
        return v1;
    }

    android.os.Parcelable i() {
        // Registers (12 total): v11 = this
        v1 = 1;
        v3 = 0;
        v4 = 0;
        _result = v11.f(); // android.support.v4.app.y.f -> boolean
        v0 = android.support.v4.app.y.b; // :boolean
        if (v0 == 0) /* goto L_000c */;
        v11.s = v1; // android.support.v4.app.y.s:boolean
        v0 = v11.f; // android.support.v4.app.y.f:java.util.ArrayList
        if (v0 == 0) /* goto L_0018 */;
        v0 = v11.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > 0) /* goto L_0019 */;
        return v3;
        v0 = v11.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v6 = _result;
        v7 = new android.support.v4.app.FragmentState[][size=v6];
        v5 = v4;
        v2 = v4;
        if (v5 >= v6) /* goto L_00fe */;
        v0 = v11.f; // android.support.v4.app.y.f:java.util.ArrayList
        _result = v0.get(v5); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_01f4 */;
        v2 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v2 >= 0) /* goto L_005c */;
        v2 = new java.lang.IllegalStateException;
        v8 = new java.lang.StringBuilder;
        _result = v8.<init>(); // java.lang.StringBuilder.<init> -> void
        v9 = "Failure saving state: active ";
        _result = v8.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v8 = _result;
        _result = v8.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v8 = _result;
        v9 = " has cleared index: ";
        _result = v8.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v8 = _result;
        v9 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v8.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v8 = _result;
        _result = v8.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v8 = _result;
        _result = v2.<init>(v8); // java.lang.IllegalStateException.<init> -> void
        _result = v11.a(v2); // android.support.v4.app.y.a -> void
        v2 = new android.support.v4.app.FragmentState;
        _result = v2.<init>(v0); // android.support.v4.app.FragmentState.<init> -> void
        v7[v5] = v2;
        v8 = v0.mState; // android.support.v4.app.Fragment.mState:int
        if (v8 <= 0) /* goto L_00f9 */;
        v8 = v2.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        if (v8 != 0) /* goto L_00f9 */;
        _result = v11.g(v0); // android.support.v4.app.y.g -> android.os.Bundle
        v8 = _result;
        v2.mSavedFragmentState = v8; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v8 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        if (v8 == 0) /* goto L_00c7 */;
        v8 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v8 = v8.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v8 >= 0) /* goto L_00a4 */;
        v8 = new java.lang.IllegalStateException;
        v9 = new java.lang.StringBuilder;
        _result = v9.<init>(); // java.lang.StringBuilder.<init> -> void
        v10 = "Failure saving state: ";
        _result = v9.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        _result = v9.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        v10 = " has target not in fragment manager: ";
        _result = v9.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        v10 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        _result = v9.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        _result = v9.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v9 = _result;
        _result = v8.<init>(v9); // java.lang.IllegalStateException.<init> -> void
        _result = v11.a(v8); // android.support.v4.app.y.a -> void
        v8 = v2.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        if (v8 != 0) /* goto L_00af */;
        v8 = new android.os.Bundle;
        _result = v8.<init>(); // android.os.Bundle.<init> -> void
        v2.mSavedFragmentState = v8; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v8 = v2.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v9 = "android:target_state";
        v10 = v0.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        _result = v11.a(v8, v9, v10); // android.support.v4.app.y.a -> void
        v8 = v0.mTargetRequestCode; // android.support.v4.app.Fragment.mTargetRequestCode:int
        if (v8 == 0) /* goto L_00c7 */;
        v8 = v2.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        v9 = "android:target_req_state";
        v10 = v0.mTargetRequestCode; // android.support.v4.app.Fragment.mTargetRequestCode:int
        _result = v8.putInt(v9, v10); // android.os.Bundle.putInt -> void
        v8 = android.support.v4.app.y.a; // :boolean
        if (v8 == 0) /* goto L_00f2 */;
        v8 = "FragmentManager";
        v9 = new java.lang.StringBuilder;
        _result = v9.<init>(); // java.lang.StringBuilder.<init> -> void
        v10 = "Saved state of ";
        _result = v9.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v9 = _result;
        _result = v9.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v9 = ": ";
        _result = v0.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = v2.mSavedFragmentState; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v8.v(v0); // android.util.Log.v -> int
        v0 = v1;
        v2 = binOpLit8_0xd8(v5, 1);
        v5 = v2;
        v2 = v0;
        // goto L_0023
        v8 = v0.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        v2.mSavedFragmentState = v8; // android.support.v4.app.FragmentState.mSavedFragmentState:android.os.Bundle
        // goto L_00c7
        if (v2 != 0) /* goto L_010f */;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0018 */;
        v0 = "FragmentManager";
        v1 = "saveAllState: no fragments!";
        _result = v0.v(v1); // android.util.Log.v -> int
        // goto L_0018
        v0 = v11.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 == 0) /* goto L_0192 */;
        v0 = v11.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v5 = _result;
        if (v5 <= 0) /* goto L_0192 */;
        v1 = new int[][size=v5];
        v2 = v4;
        if (v2 >= v5) /* goto L_0193 */;
        v0 = v11.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v0 = v0.mIndex; // android.support.v4.app.Fragment.mIndex:int
        v1[v2] = v0;
        v0 = v1[v2];
        if (v0 >= 0) /* goto L_015f */;
        v0 = new java.lang.IllegalStateException;
        v6 = new java.lang.StringBuilder;
        _result = v6.<init>(); // java.lang.StringBuilder.<init> -> void
        v8 = "Failure saving state: active ";
        _result = v6.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v8 = v11.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v8.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v8 = _result;
        _result = v6.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v8 = " has cleared index: ";
        _result = v6.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v8 = v1[v2];
        _result = v6.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v6 = _result;
        _result = v0.<init>(v6); // java.lang.IllegalStateException.<init> -> void
        _result = v11.a(v0); // android.support.v4.app.y.a -> void
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_018e */;
        v0 = "FragmentManager";
        v6 = new java.lang.StringBuilder;
        _result = v6.<init>(); // java.lang.StringBuilder.<init> -> void
        v8 = "saveAllState: adding fragment #";
        _result = v6.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v8 = ": ";
        _result = v6.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v8 = v11.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v8.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v8 = _result;
        _result = v6.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v6 = _result;
        _result = v0.v(v6); // android.util.Log.v -> int
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_011e
        v1 = v3;
        v0 = v11.i; // android.support.v4.app.y.i:java.util.ArrayList
        if (v0 == 0) /* goto L_01e6 */;
        v0 = v11.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v5 = _result;
        if (v5 <= 0) /* goto L_01e6 */;
        v3 = new android.support.v4.app.BackStackState[][size=v5];
        v2 = v4;
        if (v2 >= v5) /* goto L_01e6 */;
        v4 = new android.support.v4.app.BackStackState;
        v0 = v11.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.l) v0;
        _result = v4.<init>(v11, v0); // android.support.v4.app.BackStackState.<init> -> void
        v3[v2] = v4;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_01e2 */;
        v0 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "saveAllState: adding back stack #";
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v6 = ": ";
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v6 = v11.i; // android.support.v4.app.y.i:java.util.ArrayList
        _result = v6.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v6 = _result;
        _result = v4.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v0.v(v4); // android.util.Log.v -> int
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_01a2
        v0 = new android.support.v4.app.FragmentManagerState;
        _result = v0.<init>(); // android.support.v4.app.FragmentManagerState.<init> -> void
        v0.mActive = v7; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        v0.mAdded = v1; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        v0.mBackStack = v3; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        v3 = v0;
        // goto L_0018
        v0 = v2;
        // goto L_00f3
    }

    public void j() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.s = v0; // android.support.v4.app.y.s:boolean
        return;
    }

    public void k() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v2.s = v1; // android.support.v4.app.y.s:boolean
        v0 = 1;
        _result = v2.a(v0, v1); // android.support.v4.app.y.a -> void
        return;
    }

    public void l() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v2.s = v1; // android.support.v4.app.y.s:boolean
        v0 = 2;
        _result = v2.a(v0, v1); // android.support.v4.app.y.a -> void
        return;
    }

    public void m() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v2.s = v1; // android.support.v4.app.y.s:boolean
        v0 = 4;
        _result = v2.a(v0, v1); // android.support.v4.app.y.a -> void
        return;
    }

    public void n() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v2.s = v1; // android.support.v4.app.y.s:boolean
        v0 = 5;
        _result = v2.a(v0, v1); // android.support.v4.app.y.a -> void
        return;
    }

    public void o() {
        // Registers (3 total): v2 = this
        v0 = 4;
        v1 = 0;
        _result = v2.a(v0, v1); // android.support.v4.app.y.a -> void
        return;
    }

    public void p() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v2.s = v0; // android.support.v4.app.y.s:boolean
        v0 = 3;
        v1 = 0;
        _result = v2.a(v0, v1); // android.support.v4.app.y.a -> void
        return;
    }

    public void q() {
        // Registers (3 total): v2 = this
        v0 = 2;
        v1 = 0;
        _result = v2.a(v0, v1); // android.support.v4.app.y.a -> void
        return;
    }

    public void r() {
        // Registers (3 total): v2 = this
        v0 = 1;
        v1 = 0;
        _result = v2.a(v0, v1); // android.support.v4.app.y.a -> void
        return;
    }

    public void s() {
        // Registers (4 total): v3 = this
        v2 = 0;
        v1 = 0;
        v0 = 1;
        v3.t = v0; // android.support.v4.app.y.t:boolean
        _result = v3.f(); // android.support.v4.app.y.f -> boolean
        _result = v3.a(v2, v2); // android.support.v4.app.y.a -> void
        v3.o = v1; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        v3.p = v1; // android.support.v4.app.y.p:android.support.v4.app.v
        v3.q = v1; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        return;
    }

    public void t() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v0 == 0) /* goto L_001f */;
        v0 = 0;
        v1 = v0;
        v0 = v2.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_001f */;
        v0 = v2.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_001b */;
        _result = v0.performLowMemory(); // android.support.v4.app.Fragment.performLowMemory -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
        return;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 128;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = "FragmentManager{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v2.identityHashCode(); // java.lang.System.identityHashCode -> int
        v1 = _result;
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = " in ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.q; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        if (v1 == 0) /* goto L_0032 */;
        v1 = v2.q; // android.support.v4.app.y.q:android.support.v4.app.Fragment
        _result = v1.a(v0); // android.support.v4.c.d.a -> void
        v1 = "}}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v1 = v2.o; // android.support.v4.app.y.o:android.support.v4.app.FragmentActivity
        _result = v1.a(v0); // android.support.v4.c.d.a -> void
        // goto L_0027
    }

}