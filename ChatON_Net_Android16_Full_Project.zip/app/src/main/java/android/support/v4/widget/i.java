package android.support.v4.widget;

/**
 * Original SourceFile: DrawerLayout.java
 * Descriptor: Landroid/support/v4/widget/i;
 */
class i extends android.support.v4.view.a {
    final android.support.v4.widget.DrawerLayout b;
    private final android.graphics.Rect c;

    i(android.support.v4.widget.DrawerLayout p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.widget.DrawerLayout)
        v1.b = v2; // android.support.v4.widget.i.b:android.support.v4.widget.DrawerLayout
        _result = v1.<init>(); // android.support.v4.view.a.<init> -> void
        v0 = new android.graphics.Rect;
        _result = v0.<init>(); // android.graphics.Rect.<init> -> void
        v1.c = v0; // android.support.v4.widget.i.c:android.graphics.Rect
        return;
    }

    private void a(android.support.v4.view.a.a p0, android.support.v4.view.a.a p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.support.v4.view.a.a), v3 = p1 (android.support.v4.view.a.a)
        v0 = v1.c; // android.support.v4.widget.i.c:android.graphics.Rect
        _result = v3.a(v0); // android.support.v4.view.a.a.a -> void
        _result = v2.b(v0); // android.support.v4.view.a.a.b -> void
        _result = v3.c(v0); // android.support.v4.view.a.a.c -> void
        _result = v2.d(v0); // android.support.v4.view.a.a.d -> void
        _result = v3.h(); // android.support.v4.view.a.a.h -> boolean
        v0 = _result;
        _result = v2.c(v0); // android.support.v4.view.a.a.c -> void
        _result = v3.p(); // android.support.v4.view.a.a.p -> java.lang.CharSequence
        v0 = _result;
        _result = v2.a(v0); // android.support.v4.view.a.a.a -> void
        _result = v3.q(); // android.support.v4.view.a.a.q -> java.lang.CharSequence
        v0 = _result;
        _result = v2.b(v0); // android.support.v4.view.a.a.b -> void
        _result = v3.s(); // android.support.v4.view.a.a.s -> java.lang.CharSequence
        v0 = _result;
        _result = v2.c(v0); // android.support.v4.view.a.a.c -> void
        _result = v3.m(); // android.support.v4.view.a.a.m -> boolean
        v0 = _result;
        _result = v2.h(v0); // android.support.v4.view.a.a.h -> void
        _result = v3.k(); // android.support.v4.view.a.a.k -> boolean
        v0 = _result;
        _result = v2.f(v0); // android.support.v4.view.a.a.f -> void
        _result = v3.f(); // android.support.v4.view.a.a.f -> boolean
        v0 = _result;
        _result = v2.a(v0); // android.support.v4.view.a.a.a -> void
        _result = v3.g(); // android.support.v4.view.a.a.g -> boolean
        v0 = _result;
        _result = v2.b(v0); // android.support.v4.view.a.a.b -> void
        _result = v3.i(); // android.support.v4.view.a.a.i -> boolean
        v0 = _result;
        _result = v2.d(v0); // android.support.v4.view.a.a.d -> void
        _result = v3.j(); // android.support.v4.view.a.a.j -> boolean
        v0 = _result;
        _result = v2.e(v0); // android.support.v4.view.a.a.e -> void
        _result = v3.l(); // android.support.v4.view.a.a.l -> boolean
        v0 = _result;
        _result = v2.g(v0); // android.support.v4.view.a.a.g -> void
        _result = v3.b(); // android.support.v4.view.a.a.b -> int
        v0 = _result;
        _result = v2.a(v0); // android.support.v4.view.a.a.a -> void
        return;
    }

    private void a(android.support.v4.view.a.a p0, android.view.ViewGroup p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.support.v4.view.a.a), v6 = p1 (android.view.ViewGroup)
        _result = v6.getChildCount(); // android.view.ViewGroup.getChildCount -> int
        v2 = _result;
        v0 = 0;
        v1 = v0;
        if (v1 >= v2) /* goto L_0030 */;
        _result = v6.getChildAt(v1); // android.view.ViewGroup.getChildAt -> android.view.View
        v0 = _result;
        _result = v4.b(v0); // android.support.v4.widget.i.b -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0016 */;
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0006
        _result = v0.c(); // android.support.v4.view.at.c -> int
        v3 = _result;
        // switch(v3)
        // goto L_0012
        v3 = 1;
        _result = v0.b(v3); // android.support.v4.view.at.b -> void
        _result = v5.b(v0); // android.support.v4.view.a.a.b -> void
        // goto L_0012
        v3 = (v0 instanceof android.view.ViewGroup);
        if (v3 == 0) /* goto L_0012 */;
        v0 = (android.view.ViewGroup) v0;
        _result = v4.a(v5, v0); // android.support.v4.widget.i.a -> void
        // goto L_0012
        return;
    }

    public void a(android.view.View p0, android.support.v4.view.a.a p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.view.View), v5 = p1 (android.support.v4.view.a.a)
        _result = v5.a(); // android.support.v4.view.a.a.a -> android.support.v4.view.a.a
        v1 = _result;
        _result = v3.a(v4, v1); // android.support.v4.view.a.a -> void
        _result = v5.a(v4); // android.support.v4.view.a.a.a -> void
        _result = v4.f(); // android.support.v4.view.at.f -> android.view.ViewParent
        v0 = _result;
        v2 = (v0 instanceof android.view.View);
        if (v2 == 0) /* goto L_0017 */;
        v0 = (android.view.View) v0;
        _result = v5.c(v0); // android.support.v4.view.a.a.c -> void
        _result = v3.a(v5, v1); // android.support.v4.widget.i.a -> void
        _result = v1.t(); // android.support.v4.view.a.a.t -> void
        v4 = (android.view.ViewGroup) v4;
        _result = v3.a(v5, v4); // android.support.v4.widget.i.a -> void
        return;
    }

    public boolean a(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (android.view.View), v4 = p2 (android.view.accessibility.AccessibilityEvent)
        _result = v1.b(v3); // android.support.v4.widget.i.b -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000b */;
        _result = v1.a(v2, v3, v4); // android.support.v4.view.a.a -> boolean
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_000a
    }

    public boolean b(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = v1.b; // android.support.v4.widget.i.b:android.support.v4.widget.DrawerLayout
        _result = v0.a(); // android.support.v4.widget.DrawerLayout.a -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_000c */;
        if (v0 == v2) /* goto L_000c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000b
    }

}