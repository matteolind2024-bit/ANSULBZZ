package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeInfoCompat.java
 * Descriptor: Landroid/support/v4/view/a/f;
 */
class f extends android.support.v4.view.a.e {
    f() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.a.e.<init> -> void
        return;
    }

}