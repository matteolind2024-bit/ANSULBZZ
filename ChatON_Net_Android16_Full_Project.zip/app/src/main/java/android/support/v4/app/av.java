package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/av;
 */
public class av {
     android.content.Context a;
     java.lang.CharSequence b;
     java.lang.CharSequence c;
     android.app.PendingIntent d;
     android.app.PendingIntent e;
     android.widget.RemoteViews f;
     android.graphics.Bitmap g;
     java.lang.CharSequence h;
     int i;
     int j;
     boolean k;
     android.support.v4.app.bc l;
     java.lang.CharSequence m;
     int n;
     int o;
     boolean p;
     java.util.ArrayList q;
     android.app.Notification r;

    public av(android.content.Context p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Context)
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v3.q = v0; // android.support.v4.app.av.q:java.util.ArrayList
        v0 = new android.app.Notification;
        _result = v0.<init>(); // android.app.Notification.<init> -> void
        v3.r = v0; // android.support.v4.app.av.r:android.app.Notification
        v3.a = v4; // android.support.v4.app.av.a:android.content.Context
        v0 = v3.r; // android.support.v4.app.av.r:android.app.Notification
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v1 = _result;
        v0.when = v1; // android.app.Notification.when:long
        v0 = v3.r; // android.support.v4.app.av.r:android.app.Notification
        v1 = -1;
        v0.audioStreamType = v1; // android.app.Notification.audioStreamType:int
        v0 = 0;
        v3.j = v0; // android.support.v4.app.av.j:int
        return;
    }

    private void a(int p0, boolean p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (boolean)
        if (v5 == 0) /* goto L_000a */;
        v0 = v3.r; // android.support.v4.app.av.r:android.app.Notification
        v1 = v0.flags; // android.app.Notification.flags:int
        v1 = binOp2addr_0xb6(v1, v4);
        v0.flags = v1; // android.app.Notification.flags:int
        return;
        v0 = v3.r; // android.support.v4.app.av.r:android.app.Notification
        v1 = v0.flags; // android.app.Notification.flags:int
        v2 = binOpLit8_0xdf(v4, -1);
        v1 = binOp2addr_0xb5(v1, v2);
        v0.flags = v1; // android.app.Notification.flags:int
        // goto L_0009
    }

    public android.app.Notification a() {
        // Registers (2 total): v1 = this
        _result = this.a(); // android.support.v4.app.ar.a -> android.support.v4.app.ax
        v0 = _result;
        _result = android.support.v4.app.ax.a(v0, v1); // -> android.app.Notification
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.av a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.r; // android.support.v4.app.av.r:android.app.Notification
        v0.icon = v2; // android.app.Notification.icon:int
        return v1;
    }

    public android.support.v4.app.av a(int p0, int p1, boolean p2) {
        // Registers (4 total): v0 = this, v1 = p0 (int), v2 = p1 (int), v3 = p2 (boolean)
        v0.n = v1; // android.support.v4.app.av.n:int
        v0.o = v2; // android.support.v4.app.av.o:int
        v0.p = v3; // android.support.v4.app.av.p:boolean
        return v0;
    }

    public android.support.v4.app.av a(android.app.PendingIntent p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.app.PendingIntent)
        v0.d = v1; // android.support.v4.app.av.d:android.app.PendingIntent
        return v0;
    }

    public android.support.v4.app.av a(java.lang.CharSequence p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.CharSequence)
        v0.b = v1; // android.support.v4.app.av.b:java.lang.CharSequence
        return v0;
    }

    public android.support.v4.app.av a(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = 16;
        _result = v1.a(v0, v2); // android.support.v4.app.av.a -> void
        return v1;
    }

    public android.support.v4.app.av b(java.lang.CharSequence p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.CharSequence)
        v0.c = v1; // android.support.v4.app.av.c:java.lang.CharSequence
        return v0;
    }

    public android.support.v4.app.av c(java.lang.CharSequence p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.CharSequence)
        v0 = v1.r; // android.support.v4.app.av.r:android.app.Notification
        v0.tickerText = v2; // android.app.Notification.tickerText:java.lang.CharSequence
        return v1;
    }

}