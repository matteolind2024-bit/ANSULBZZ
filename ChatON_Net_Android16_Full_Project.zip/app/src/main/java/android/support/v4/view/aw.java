package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/aw;
 */
class aw extends android.support.v4.view.av {
    aw() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.av.<init> -> void
        return;
    }

    public int a(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.a(); // android.support.v4.view.be.a -> int
        v0 = _result;
        return v0;
    }

}