package android.support.v4.app;

/**
 * Original SourceFile: ActionBarDrawerToggle.java
 * Descriptor: Landroid/support/v4/app/f;
 */
public interface f {
    public abstract android.graphics.drawable.Drawable a();
    public abstract void a(int p0);
}