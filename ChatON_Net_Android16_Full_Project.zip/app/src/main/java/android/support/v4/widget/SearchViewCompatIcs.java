package android.support.v4.widget;

/**
 * Original SourceFile: SearchViewCompatIcs.java
 * Descriptor: Landroid/support/v4/widget/SearchViewCompatIcs;
 */
class SearchViewCompatIcs {
}