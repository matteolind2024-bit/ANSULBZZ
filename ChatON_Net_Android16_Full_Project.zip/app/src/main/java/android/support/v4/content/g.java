package android.support.v4.content;

/**
 * Original SourceFile: Loader.java
 * Descriptor: Landroid/support/v4/content/g;
 */
public final class g extends android.database.ContentObserver {
    final android.support.v4.content.f a;

    public g(android.support.v4.content.f p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.content.f)
        v1.a = v2; // android.support.v4.content.g.a:android.support.v4.content.f
        v0 = new android.os.Handler;
        _result = v0.<init>(); // android.os.Handler.<init> -> void
        _result = v1.<init>(v0); // android.database.ContentObserver.<init> -> void
        return;
    }

    public boolean deliverSelfNotifications() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public void onChange(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.a; // android.support.v4.content.g.a:android.support.v4.content.f
        _result = v0.x(); // android.support.v4.content.f.x -> void
        return;
    }

}