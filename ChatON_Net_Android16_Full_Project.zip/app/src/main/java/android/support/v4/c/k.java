package android.support.v4.c;

/**
 * Original SourceFile: MapCollections.java
 * Descriptor: Landroid/support/v4/c/k;
 */
final class k implements java.util.Iterator, java.util.Map$Entry {
     int a;
     int b;
     boolean c;
    final android.support.v4.c.g d;

    k(android.support.v4.c.g p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.c.g)
        v1.d = v2; // android.support.v4.c.k.d:android.support.v4.c.g
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v1.c = v0; // android.support.v4.c.k.c:boolean
        _result = v2.a(); // android.support.v4.c.g.a -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1.a = v0; // android.support.v4.c.k.a:int
        v0 = -1;
        v1.b = v0; // android.support.v4.c.k.b:int
        return;
    }

    public java.util.Map$Entry a() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.c.k.b:int
        v0 = binOpLit8_0xd8(v0, 1);
        v1.b = v0; // android.support.v4.c.k.b:int
        v0 = 1;
        v1.c = v0; // android.support.v4.c.k.c:boolean
        return v1;
    }

    public final boolean equals(java.lang.Object p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        v2 = v5.c; // android.support.v4.c.k.c:boolean
        if (v2 != 0) /* goto L_000f */;
        v0 = new java.lang.IllegalStateException;
        v1 = "This container does not support retaining Map.Entry objects";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v2 = (v6 instanceof java.util.Map$Entry);
        if (v2 != 0) /* goto L_0014 */;
        return v1;
        v6 = (java.util.Map$Entry) v6;
        _result = java.util.Map$Entry.getKey(v6); // -> java.lang.Object
        v2 = _result;
        v3 = v5.d; // android.support.v4.c.k.d:android.support.v4.c.g
        v4 = v5.b; // android.support.v4.c.k.b:int
        _result = v3.a(v4, v1); // android.support.v4.c.g.a -> java.lang.Object
        v3 = _result;
        _result = v2.a(v3); // android.support.v4.c.c.a -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_003c */;
        _result = java.util.Map$Entry.getValue(v6); // -> java.lang.Object
        v2 = _result;
        v3 = v5.d; // android.support.v4.c.k.d:android.support.v4.c.g
        v4 = v5.b; // android.support.v4.c.k.b:int
        _result = v3.a(v4, v0); // android.support.v4.c.g.a -> java.lang.Object
        v3 = _result;
        _result = v2.a(v3); // android.support.v4.c.c.a -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_003c */;
        v1 = v0;
        // goto L_0013
        v0 = v1;
        // goto L_003a
    }

    public java.lang.Object getKey() {
        // Registers (4 total): v3 = this
        v0 = v3.c; // android.support.v4.c.k.c:boolean
        if (v0 != 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "This container does not support retaining Map.Entry objects";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.d; // android.support.v4.c.k.d:android.support.v4.c.g
        v1 = v3.b; // android.support.v4.c.k.b:int
        v2 = 0;
        _result = v0.a(v1, v2); // android.support.v4.c.g.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object getValue() {
        // Registers (4 total): v3 = this
        v0 = v3.c; // android.support.v4.c.k.c:boolean
        if (v0 != 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "This container does not support retaining Map.Entry objects";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.d; // android.support.v4.c.k.d:android.support.v4.c.g
        v1 = v3.b; // android.support.v4.c.k.b:int
        v2 = 1;
        _result = v0.a(v1, v2); // android.support.v4.c.g.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public boolean hasNext() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // android.support.v4.c.k.b:int
        v1 = v2.a; // android.support.v4.c.k.a:int
        if (v0 >= v1) /* goto L_0008 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public final int hashCode() {
        // Registers (6 total): v5 = this
        v0 = 0;
        v1 = v5.c; // android.support.v4.c.k.c:boolean
        if (v1 != 0) /* goto L_000e */;
        v0 = new java.lang.IllegalStateException;
        v1 = "This container does not support retaining Map.Entry objects";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v1 = v5.d; // android.support.v4.c.k.d:android.support.v4.c.g
        v2 = v5.b; // android.support.v4.c.k.b:int
        _result = v1.a(v2, v0); // android.support.v4.c.g.a -> java.lang.Object
        v1 = _result;
        v2 = v5.d; // android.support.v4.c.k.d:android.support.v4.c.g
        v3 = v5.b; // android.support.v4.c.k.b:int
        v4 = 1;
        _result = v2.a(v3, v4); // android.support.v4.c.g.a -> java.lang.Object
        v2 = _result;
        if (v1 != 0) /* goto L_0026 */;
        v1 = v0;
        if (v2 != 0) /* goto L_002b */;
        v0 = binOp2addr_0xb7(v0, v1);
        return v0;
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        // goto L_0022
        _result = v2.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        // goto L_0024
    }

    public java.lang.Object next() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // android.support.v4.c.k.a -> java.util.Map$Entry
        v0 = _result;
        return v0;
    }

    public void remove() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // android.support.v4.c.k.c:boolean
        if (v0 != 0) /* goto L_000a */;
        v0 = new java.lang.IllegalStateException;
        _result = v0.<init>(); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v2.b; // android.support.v4.c.k.b:int
        v0 = binOpLit8_0xd8(v0, -1);
        v2.b = v0; // android.support.v4.c.k.b:int
        v0 = v2.a; // android.support.v4.c.k.a:int
        v0 = binOpLit8_0xd8(v0, -1);
        v2.a = v0; // android.support.v4.c.k.a:int
        v0 = 0;
        v2.c = v0; // android.support.v4.c.k.c:boolean
        v0 = v2.d; // android.support.v4.c.k.d:android.support.v4.c.g
        v1 = v2.b; // android.support.v4.c.k.b:int
        _result = v0.a(v1); // android.support.v4.c.g.a -> void
        return;
    }

    public java.lang.Object setValue(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v0 = v2.c; // android.support.v4.c.k.c:boolean
        if (v0 != 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "This container does not support retaining Map.Entry objects";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v2.d; // android.support.v4.c.k.d:android.support.v4.c.g
        v1 = v2.b; // android.support.v4.c.k.b:int
        _result = v0.a(v1, v3); // android.support.v4.c.g.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public final java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v2.getKey(); // android.support.v4.c.k.getKey -> java.lang.Object
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.getValue(); // android.support.v4.c.k.getValue -> java.lang.Object
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}