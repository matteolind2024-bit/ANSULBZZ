package android.support.v4.a.a;

/**
 * Original SourceFile: DrawableCompat.java
 * Descriptor: Landroid/support/v4/a/a/a;
 */
public class a {
    static final android.support.v4.a.a.c a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 19;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.a.a.e;
        _result = v0.<init>(); // android.support.v4.a.a.e.<init> -> void
        android.support.v4.a.a.a.a = v0; // :android.support.v4.a.a.c
        return;
        v1 = 11;
        if (v0 < v1) /* goto L_001a */;
        v0 = new android.support.v4.a.a.d;
        _result = v0.<init>(); // android.support.v4.a.a.d.<init> -> void
        android.support.v4.a.a.a.a = v0; // :android.support.v4.a.a.c
        // goto L_000d
        v0 = new android.support.v4.a.a.b;
        _result = v0.<init>(); // android.support.v4.a.a.b.<init> -> void
        android.support.v4.a.a.a.a = v0; // :android.support.v4.a.a.c
        // goto L_000d
    }

    public static void a(android.graphics.drawable.Drawable p0, boolean p1) {
        // Registers (3 total): v1 = p0 (android.graphics.drawable.Drawable), v2 = p1 (boolean)
        v0 = android.support.v4.a.a.a.a; // :android.support.v4.a.a.c
        _result = android.support.v4.a.a.c.a(v0, v1, v2); // -> void
        return;
    }

    public static boolean a(android.graphics.drawable.Drawable p0) {
        // Registers (2 total): v1 = p0 (android.graphics.drawable.Drawable)
        v0 = android.support.v4.a.a.a.a; // :android.support.v4.a.a.c
        _result = android.support.v4.a.a.c.a(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

}