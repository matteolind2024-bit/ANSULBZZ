package android.support.v4.view;

/**
 * Original SourceFile: KeyEventCompatHoneycomb.java
 * Descriptor: Landroid/support/v4/view/y;
 */
class y {
    public static int a(int p0) {
        // Registers (2 total): v1 = p0 (int)
        _result = v1.normalizeMetaState(); // android.view.KeyEvent.normalizeMetaState -> int
        v0 = _result;
        return v0;
    }

    public static boolean a(int p0, int p1) {
        // Registers (3 total): v1 = p0 (int), v2 = p1 (int)
        _result = v1.metaStateHasModifiers(v2); // android.view.KeyEvent.metaStateHasModifiers -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean b(int p0) {
        // Registers (2 total): v1 = p0 (int)
        _result = v1.metaStateHasNoModifiers(); // android.view.KeyEvent.metaStateHasNoModifiers -> boolean
        v0 = _result;
        return v0;
    }

}