package android.support.v4.b;

/**
 * Original SourceFile: ParcelableCompat.java
 * Descriptor: Landroid/support/v4/b/a;
 */
public class a {
    public static android.os.Parcelable$Creator a(android.support.v4.b.c p0) {
        // Registers (3 total): v2 = p0 (android.support.v4.b.c)
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 13;
        if (v0 < v1) /* goto L_0009 */;
        _result = v2.a(); // android.support.v4.b.e.a -> android.os.Parcelable$Creator
        v0 = new android.support.v4.b.b;
        _result = v0.<init>(v2); // android.support.v4.b.b.<init> -> void
        return v0;
    }

}