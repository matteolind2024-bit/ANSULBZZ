package android.support.v4.app;

/**
 * Original SourceFile: LoaderManager.java
 * Descriptor: Landroid/support/v4/app/an;
 */
public interface an {
    public abstract android.support.v4.content.f a(int p0, android.os.Bundle p1);
    public abstract void a(android.support.v4.content.f p0);
    public abstract void a(android.support.v4.content.f p0, java.lang.Object p1);
}