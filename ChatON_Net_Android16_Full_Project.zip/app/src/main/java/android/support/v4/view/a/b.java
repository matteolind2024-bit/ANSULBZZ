package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeInfoCompat.java
 * Descriptor: Landroid/support/v4/view/a/b;
 */
class b extends android.support.v4.view.a.g {
    b() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.a.g.<init> -> void
        return;
    }

    public java.lang.Object a(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.a(); // android.support.v4.view.a.h.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void a(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.a(v2); // android.support.v4.view.a.h.a -> void
        return;
    }

    public void a(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.graphics.Rect)
        _result = v1.a(v2); // android.support.v4.view.a.h.a -> void
        return;
    }

    public void a(java.lang.Object p0, android.view.View p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View)
        _result = v1.a(v2); // android.support.v4.view.a.h.a -> void
        return;
    }

    public void a(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        _result = v1.a(v2); // android.support.v4.view.a.h.a -> void
        return;
    }

    public void a(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.a(v2); // android.support.v4.view.a.h.a -> void
        return;
    }

    public int b(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.b(); // android.support.v4.view.a.h.b -> int
        v0 = _result;
        return v0;
    }

    public void b(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.graphics.Rect)
        _result = v1.b(v2); // android.support.v4.view.a.h.b -> void
        return;
    }

    public void b(java.lang.Object p0, android.view.View p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View)
        _result = v1.b(v2); // android.support.v4.view.a.h.b -> void
        return;
    }

    public void b(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        _result = v1.b(v2); // android.support.v4.view.a.h.b -> void
        return;
    }

    public void b(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.b(v2); // android.support.v4.view.a.h.b -> void
        return;
    }

    public java.lang.CharSequence c(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.c(); // android.support.v4.view.a.h.c -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public void c(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.graphics.Rect)
        _result = v1.c(v2); // android.support.v4.view.a.h.c -> void
        return;
    }

    public void c(java.lang.Object p0, android.view.View p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View)
        _result = v1.c(v2); // android.support.v4.view.a.h.c -> void
        return;
    }

    public void c(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (java.lang.CharSequence)
        _result = v1.c(v2); // android.support.v4.view.a.h.c -> void
        return;
    }

    public void c(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.c(v2); // android.support.v4.view.a.h.c -> void
        return;
    }

    public java.lang.CharSequence d(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.d(); // android.support.v4.view.a.h.d -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public void d(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.graphics.Rect)
        _result = v1.d(v2); // android.support.v4.view.a.h.d -> void
        return;
    }

    public void d(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.d(v2); // android.support.v4.view.a.h.d -> void
        return;
    }

    public java.lang.CharSequence e(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.e(); // android.support.v4.view.a.h.e -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public void e(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.e(v2); // android.support.v4.view.a.h.e -> void
        return;
    }

    public java.lang.CharSequence f(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.f(); // android.support.v4.view.a.h.f -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public void f(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.f(v2); // android.support.v4.view.a.h.f -> void
        return;
    }

    public void g(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.g(v2); // android.support.v4.view.a.h.g -> void
        return;
    }

    public boolean g(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.g(); // android.support.v4.view.a.h.g -> boolean
        v0 = _result;
        return v0;
    }

    public boolean h(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.h(); // android.support.v4.view.a.h.h -> boolean
        v0 = _result;
        return v0;
    }

    public boolean i(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.i(); // android.support.v4.view.a.h.i -> boolean
        v0 = _result;
        return v0;
    }

    public boolean j(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.j(); // android.support.v4.view.a.h.j -> boolean
        v0 = _result;
        return v0;
    }

    public boolean k(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.k(); // android.support.v4.view.a.h.k -> boolean
        v0 = _result;
        return v0;
    }

    public boolean l(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.l(); // android.support.v4.view.a.h.l -> boolean
        v0 = _result;
        return v0;
    }

    public boolean m(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.m(); // android.support.v4.view.a.h.m -> boolean
        v0 = _result;
        return v0;
    }

    public boolean n(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.n(); // android.support.v4.view.a.h.n -> boolean
        v0 = _result;
        return v0;
    }

    public boolean o(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.o(); // android.support.v4.view.a.h.o -> boolean
        v0 = _result;
        return v0;
    }

    public boolean p(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.p(); // android.support.v4.view.a.h.p -> boolean
        v0 = _result;
        return v0;
    }

    public void q(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v1.q(); // android.support.v4.view.a.h.q -> void
        return;
    }

}