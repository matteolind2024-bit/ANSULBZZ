package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityRecordCompat.java
 * Descriptor: Landroid/support/v4/view/a/ac;
 */
class ac implements android.support.v4.view.a.aa {
    ac() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.lang.Object a() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public void a(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

    public void a(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        return;
    }

    public void b(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

    public void c(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        return;
    }

}