package android.support.v4.widget;

/**
 * Original SourceFile: ContentLoadingProgressBar.java
 * Descriptor: Landroid/support/v4/widget/b;
 */
class b implements java.lang.Runnable {
    final android.support.v4.widget.ContentLoadingProgressBar a;

    b(android.support.v4.widget.ContentLoadingProgressBar p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.ContentLoadingProgressBar)
        v0.a = v1; // android.support.v4.widget.b.a:android.support.v4.widget.ContentLoadingProgressBar
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (5 total): v4 = this
        v3 = 0;
        v0 = v4.a; // android.support.v4.widget.b.a:android.support.v4.widget.ContentLoadingProgressBar
        _result = v0.b(v3); // android.support.v4.widget.ContentLoadingProgressBar.b -> boolean
        v0 = v4.a; // android.support.v4.widget.b.a:android.support.v4.widget.ContentLoadingProgressBar
        _result = v0.a(); // android.support.v4.widget.ContentLoadingProgressBar.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_001c */;
        v0 = v4.a; // android.support.v4.widget.b.a:android.support.v4.widget.ContentLoadingProgressBar
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v1 = _result;
        _result = v0.a(v1, v2); // android.support.v4.widget.ContentLoadingProgressBar.a -> long
        v0 = v4.a; // android.support.v4.widget.b.a:android.support.v4.widget.ContentLoadingProgressBar
        _result = v0.setVisibility(v3); // android.support.v4.widget.ContentLoadingProgressBar.setVisibility -> void
        return;
    }

}