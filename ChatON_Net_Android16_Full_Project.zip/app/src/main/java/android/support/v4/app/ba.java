package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/ba;
 */
class ba implements android.support.v4.app.ax {
    ba() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.app.Notification a(android.support.v4.app.av p0) {
        // Registers (15 total): v13 = this, v14 = p0 (android.support.v4.app.av)
        v0 = v14.a; // android.support.v4.app.av.a:android.content.Context
        v1 = v14.r; // android.support.v4.app.av.r:android.app.Notification
        v2 = v14.b; // android.support.v4.app.av.b:java.lang.CharSequence
        v3 = v14.c; // android.support.v4.app.av.c:java.lang.CharSequence
        v4 = v14.h; // android.support.v4.app.av.h:java.lang.CharSequence
        v5 = v14.f; // android.support.v4.app.av.f:android.widget.RemoteViews
        v6 = v14.i; // android.support.v4.app.av.i:int
        v7 = v14.d; // android.support.v4.app.av.d:android.app.PendingIntent
        v8 = v14.e; // android.support.v4.app.av.e:android.app.PendingIntent
        v9 = v14.g; // android.support.v4.app.av.g:android.graphics.Bitmap
        v10 = v14.n; // android.support.v4.app.av.n:int
        v11 = v14.o; // android.support.v4.app.av.o:int
        v12 = v14.p; // android.support.v4.app.av.p:boolean
        _result = v0.a(v0..v12); // android.support.v4.app.be.a -> android.app.Notification
        v0 = _result;
        return v0;
    }

}