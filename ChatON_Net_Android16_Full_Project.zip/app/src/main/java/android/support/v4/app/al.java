package android.support.v4.app;

/**
 * Original SourceFile: ListFragment.java
 * Descriptor: Landroid/support/v4/app/al;
 */
class al implements android.widget.AdapterView$OnItemClickListener {
    final android.support.v4.app.ListFragment a;

    al(android.support.v4.app.ListFragment p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.ListFragment)
        v0.a = v1; // android.support.v4.app.al.a:android.support.v4.app.ListFragment
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void onItemClick(android.widget.AdapterView p0, android.view.View p1, int p2, long p3) {
        // Registers (12 total): v6 = this, v7 = p0 (android.widget.AdapterView), v8 = p1 (android.view.View), v9 = p2 (int), v10 = p3 (long)
        v0 = v6.a; // android.support.v4.app.al.a:android.support.v4.app.ListFragment
        v1 = v7;
        v1 = (android.widget.ListView) v1;
        v2 = v8;
        v3 = v9;
        v4 = v10;
        _result = v0.a(v0..v5); // android.support.v4.app.ListFragment.a -> void
        return;
    }

}