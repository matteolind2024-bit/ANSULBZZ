package android.support.v4.view;

/**
 * Original SourceFile: GravityCompat.java
 * Descriptor: Landroid/support/v4/view/o;
 */
interface o {
    public abstract int a(int p0, int p1);
}