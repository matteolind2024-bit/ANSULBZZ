package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/az;
 */
class az implements android.support.v4.app.ax {
    az() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.app.Notification a(android.support.v4.app.av p0) {
        // Registers (12 total): v10 = this, v11 = p0 (android.support.v4.app.av)
        v0 = v11.a; // android.support.v4.app.av.a:android.content.Context
        v1 = v11.r; // android.support.v4.app.av.r:android.app.Notification
        v2 = v11.b; // android.support.v4.app.av.b:java.lang.CharSequence
        v3 = v11.c; // android.support.v4.app.av.c:java.lang.CharSequence
        v4 = v11.h; // android.support.v4.app.av.h:java.lang.CharSequence
        v5 = v11.f; // android.support.v4.app.av.f:android.widget.RemoteViews
        v6 = v11.i; // android.support.v4.app.av.i:int
        v7 = v11.d; // android.support.v4.app.av.d:android.app.PendingIntent
        v8 = v11.e; // android.support.v4.app.av.e:android.app.PendingIntent
        v9 = v11.g; // android.support.v4.app.av.g:android.graphics.Bitmap
        _result = v0.a(v0..v9); // android.support.v4.app.bd.a -> android.app.Notification
        v0 = _result;
        return v0;
    }

}