package android.support.v4.view;

/**
 * Original SourceFile: ViewCompatGingerbread.java
 * Descriptor: Landroid/support/v4/view/be;
 */
class be {
    public static int a(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        _result = v1.getOverScrollMode(); // android.view.View.getOverScrollMode -> int
        v0 = _result;
        return v0;
    }

}