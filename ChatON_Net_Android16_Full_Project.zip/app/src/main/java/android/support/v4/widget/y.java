package android.support.v4.widget;

/**
 * Original SourceFile: ScrollerCompatGingerbread.java
 * Descriptor: Landroid/support/v4/widget/y;
 */
class y {
    public static java.lang.Object a(android.content.Context p0, android.view.animation.Interpolator p1) {
        // Registers (3 total): v1 = p0 (android.content.Context), v2 = p1 (android.view.animation.Interpolator)
        if (v2 == 0) /* goto L_0008 */;
        v0 = new android.widget.OverScroller;
        _result = v0.<init>(v1, v2); // android.widget.OverScroller.<init> -> void
        return v0;
        v0 = new android.widget.OverScroller;
        _result = v0.<init>(v1); // android.widget.OverScroller.<init> -> void
        // goto L_0007
    }

    public static void a(java.lang.Object p0, int p1, int p2, int p3, int p4, int p5) {
        // Registers (12 total): v6 = p0 (java.lang.Object), v7 = p1 (int), v8 = p2 (int), v9 = p3 (int), v10 = p4 (int), v11 = p5 (int)
        v0 = v6;
        v0 = (android.widget.OverScroller) v0;
        v1 = v7;
        v2 = v8;
        v3 = v9;
        v4 = v10;
        v5 = v11;
        _result = v0.startScroll(v0..v5); // android.widget.OverScroller.startScroll -> void
        return;
    }

    public static boolean a(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.widget.OverScroller) v1;
        _result = v1.isFinished(); // android.widget.OverScroller.isFinished -> boolean
        v0 = _result;
        return v0;
    }

    public static int b(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.widget.OverScroller) v1;
        _result = v1.getCurrX(); // android.widget.OverScroller.getCurrX -> int
        v0 = _result;
        return v0;
    }

    public static int c(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.widget.OverScroller) v1;
        _result = v1.getCurrY(); // android.widget.OverScroller.getCurrY -> int
        v0 = _result;
        return v0;
    }

    public static boolean d(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.widget.OverScroller) v1;
        _result = v1.computeScrollOffset(); // android.widget.OverScroller.computeScrollOffset -> boolean
        v0 = _result;
        return v0;
    }

    public static void e(java.lang.Object p0) {
        // Registers (1 total): v0 = p0 (java.lang.Object)
        v0 = (android.widget.OverScroller) v0;
        _result = v0.abortAnimation(); // android.widget.OverScroller.abortAnimation -> void
        return;
    }

    public static int f(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.widget.OverScroller) v1;
        _result = v1.getFinalX(); // android.widget.OverScroller.getFinalX -> int
        v0 = _result;
        return v0;
    }

    public static int g(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.widget.OverScroller) v1;
        _result = v1.getFinalY(); // android.widget.OverScroller.getFinalY -> int
        v0 = _result;
        return v0;
    }

}