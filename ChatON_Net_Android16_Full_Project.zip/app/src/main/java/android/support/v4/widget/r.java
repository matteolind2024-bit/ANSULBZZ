package android.support.v4.widget;

/**
 * Original SourceFile: EdgeEffectCompatIcs.java
 * Descriptor: Landroid/support/v4/widget/r;
 */
class r {
    public static java.lang.Object a(android.content.Context p0) {
        // Registers (2 total): v1 = p0 (android.content.Context)
        v0 = new android.widget.EdgeEffect;
        _result = v0.<init>(v1); // android.widget.EdgeEffect.<init> -> void
        return v0;
    }

    public static void a(java.lang.Object p0, int p1, int p2) {
        // Registers (3 total): v0 = p0 (java.lang.Object), v1 = p1 (int), v2 = p2 (int)
        v0 = (android.widget.EdgeEffect) v0;
        _result = v0.setSize(v1, v2); // android.widget.EdgeEffect.setSize -> void
        return;
    }

    public static boolean a(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.widget.EdgeEffect) v1;
        _result = v1.isFinished(); // android.widget.EdgeEffect.isFinished -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean a(java.lang.Object p0, float p1) {
        // Registers (3 total): v1 = p0 (java.lang.Object), v2 = p1 (float)
        v1 = (android.widget.EdgeEffect) v1;
        _result = v1.onPull(v2); // android.widget.EdgeEffect.onPull -> void
        v0 = 1;
        return v0;
    }

    public static boolean a(java.lang.Object p0, android.graphics.Canvas p1) {
        // Registers (3 total): v1 = p0 (java.lang.Object), v2 = p1 (android.graphics.Canvas)
        v1 = (android.widget.EdgeEffect) v1;
        _result = v1.draw(v2); // android.widget.EdgeEffect.draw -> boolean
        v0 = _result;
        return v0;
    }

    public static void b(java.lang.Object p0) {
        // Registers (1 total): v0 = p0 (java.lang.Object)
        v0 = (android.widget.EdgeEffect) v0;
        _result = v0.finish(); // android.widget.EdgeEffect.finish -> void
        return;
    }

    public static boolean c(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.widget.EdgeEffect) v1;
        _result = v1.onRelease(); // android.widget.EdgeEffect.onRelease -> void
        _result = v1.isFinished(); // android.widget.EdgeEffect.isFinished -> boolean
        v0 = _result;
        return v0;
    }

}