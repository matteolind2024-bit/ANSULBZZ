package android.support.v4.widget;

/**
 * Original SourceFile: SlidingPaneLayout.java
 * Descriptor: Landroid/support/v4/widget/ai;
 */
interface ai {
    public abstract void a(android.support.v4.widget.SlidingPaneLayout p0, android.view.View p1);
}