package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompat.java
 * Descriptor: Landroid/support/v4/view/d;
 */
interface d {
    public abstract android.support.v4.view.a.k a(java.lang.Object p0, android.view.View p1);
    public abstract java.lang.Object a();
    public abstract java.lang.Object a(android.support.v4.view.a p0);
    public abstract void a(java.lang.Object p0, android.view.View p1, int p2);
    public abstract void a(java.lang.Object p0, android.view.View p1, android.support.v4.view.a.a p2);
    public abstract boolean a(java.lang.Object p0, android.view.View p1, int p2, android.os.Bundle p3);
    public abstract boolean a(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2);
    public abstract boolean a(java.lang.Object p0, android.view.ViewGroup p1, android.view.View p2, android.view.accessibility.AccessibilityEvent p3);
    public abstract void b(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2);
    public abstract void c(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2);
    public abstract void d(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2);
}