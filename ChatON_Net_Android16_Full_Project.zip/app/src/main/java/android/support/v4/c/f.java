package android.support.v4.c;

/**
 * Original SourceFile: LruCache.java
 * Descriptor: Landroid/support/v4/c/f;
 */
public class f {
    private final java.util.LinkedHashMap a;
    private int b;
    private int c;
    private int d;
    private int e;
    private int f;
    private int g;
    private int h;

    public f(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        _result = v4.<init>(); // java.lang.Object.<init> -> void
        if (v5 > 0) /* goto L_000e */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "maxSize <= 0";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v4.c = v5; // android.support.v4.c.f.c:int
        v0 = new java.util.LinkedHashMap;
        v1 = 0;
        v2 = 0x3f400000;
        v3 = 1;
        _result = v0.<init>(v1, v2, v3); // java.util.LinkedHashMap.<init> -> void
        v4.a = v0; // android.support.v4.c.f.a:java.util.LinkedHashMap
        return;
    }

    private int c(java.lang.Object p0, java.lang.Object p1) {
        // Registers (6 total): v3 = this, v4 = p0 (java.lang.Object), v5 = p1 (java.lang.Object)
        _result = v3.b(v4, v5); // android.support.v4.c.f.b -> int
        v0 = _result;
        if (v0 >= 0) /* goto L_002b */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Negative size: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "=";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        return v0;
    }

    public final java.lang.Object a(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        if (v5 != 0) /* goto L_000b */;
        v0 = new java.lang.NullPointerException;
        v1 = "key == null";
        _result = v0.<init>(v1); // java.lang.NullPointerException.<init> -> void
        throw v0;
        // monitor-enter(v4)
        v0 = v4.a; // android.support.v4.c.f.a:java.util.LinkedHashMap
        _result = v0.get(v5); // java.util.LinkedHashMap.get -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_001c */;
        v1 = v4.g; // android.support.v4.c.f.g:int
        v1 = binOpLit8_0xd8(v1, 1);
        v4.g = v1; // android.support.v4.c.f.g:int
        // monitor-exit(v4)
        return v0;
        v0 = v4.h; // android.support.v4.c.f.h:int
        v0 = binOpLit8_0xd8(v0, 1);
        v4.h = v0; // android.support.v4.c.f.h:int
        // monitor-exit(v4)
        _result = v4.b(v5); // android.support.v4.c.f.b -> java.lang.Object
        v1 = _result;
        if (v1 != 0) /* goto L_002e */;
        v0 = 0;
        // goto L_001b
        v0 = _exception;
        // monitor-exit(v4)
        throw v0;
        // monitor-enter(v4)
        v0 = v4.e; // android.support.v4.c.f.e:int
        v0 = binOpLit8_0xd8(v0, 1);
        v4.e = v0; // android.support.v4.c.f.e:int
        v0 = v4.a; // android.support.v4.c.f.a:java.util.LinkedHashMap
        _result = v0.put(v5, v1); // java.util.LinkedHashMap.put -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_004a */;
        v2 = v4.a; // android.support.v4.c.f.a:java.util.LinkedHashMap
        _result = v2.put(v5, v0); // java.util.LinkedHashMap.put -> java.lang.Object
        // monitor-exit(v4)
        if (v0 == 0) /* goto L_0057 */;
        v2 = 0;
        _result = v4.a(v2, v5, v1, v0); // android.support.v4.c.f.a -> void
        // goto L_001b
        v2 = v4.b; // android.support.v4.c.f.b:int
        _result = v4.c(v5, v1); // android.support.v4.c.f.c -> int
        v3 = _result;
        v2 = binOp2addr_0xb0(v2, v3);
        v4.b = v2; // android.support.v4.c.f.b:int
        // goto L_0042
        v0 = _exception;
        // monitor-exit(v4)
        throw v0;
        v0 = v4.c; // android.support.v4.c.f.c:int
        _result = v4.a(v0); // android.support.v4.c.f.a -> void
        v0 = v1;
        // goto L_001b
    }

    public final java.lang.Object a(java.lang.Object p0, java.lang.Object p1) {
        // Registers (6 total): v3 = this, v4 = p0 (java.lang.Object), v5 = p1 (java.lang.Object)
        if (v4 == 0) /* goto L_0004 */;
        if (v5 != 0) /* goto L_000d */;
        v0 = new java.lang.NullPointerException;
        v1 = "key == null || value == null";
        _result = v0.<init>(v1); // java.lang.NullPointerException.<init> -> void
        throw v0;
        // monitor-enter(v3)
        v0 = v3.d; // android.support.v4.c.f.d:int
        v0 = binOpLit8_0xd8(v0, 1);
        v3.d = v0; // android.support.v4.c.f.d:int
        v0 = v3.b; // android.support.v4.c.f.b:int
        _result = v3.c(v4, v5); // android.support.v4.c.f.c -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v3.b = v0; // android.support.v4.c.f.b:int
        v0 = v3.a; // android.support.v4.c.f.a:java.util.LinkedHashMap
        _result = v0.put(v4, v5); // java.util.LinkedHashMap.put -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_002e */;
        v1 = v3.b; // android.support.v4.c.f.b:int
        _result = v3.c(v4, v0); // android.support.v4.c.f.c -> int
        v2 = _result;
        v1 = binOp2addr_0xb1(v1, v2);
        v3.b = v1; // android.support.v4.c.f.b:int
        // monitor-exit(v3)
        if (v0 == 0) /* goto L_0035 */;
        v1 = 0;
        _result = v3.a(v1, v4, v0, v5); // android.support.v4.c.f.a -> void
        v1 = v3.c; // android.support.v4.c.f.c:int
        _result = v3.a(v1); // android.support.v4.c.f.a -> void
        return v0;
        v0 = _exception;
        // monitor-exit(v3)
        throw v0;
    }

    public final void a() {
        // Registers (2 total): v1 = this
        v0 = -1;
        _result = v1.a(v0); // android.support.v4.c.f.a -> void
        return;
    }

    public void a(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        // monitor-enter(v4)
        v0 = v4.b; // android.support.v4.c.f.b:int
        if (v0 < 0) /* goto L_0011 */;
        v0 = v4.a; // android.support.v4.c.f.a:java.util.LinkedHashMap
        _result = v0.isEmpty(); // java.util.LinkedHashMap.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0036 */;
        v0 = v4.b; // android.support.v4.c.f.b:int
        if (v0 == 0) /* goto L_0036 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v2.getName(); // java.lang.Class.getName -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ".sizeOf() is reporting inconsistent results!";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = _exception;
        // monitor-exit(v4)
        throw v0;
        v0 = v4.b; // android.support.v4.c.f.b:int
        if (v0 <= v5) /* goto L_0042 */;
        v0 = v4.a; // android.support.v4.c.f.a:java.util.LinkedHashMap
        _result = v0.isEmpty(); // java.util.LinkedHashMap.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0044 */;
        // monitor-exit(v4)
        return;
        v0 = v4.a; // android.support.v4.c.f.a:java.util.LinkedHashMap
        _result = v0.entrySet(); // java.util.LinkedHashMap.entrySet -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = java.util.Map$Entry.getKey(v0); // -> java.lang.Object
        v1 = _result;
        _result = java.util.Map$Entry.getValue(v0); // -> java.lang.Object
        v0 = _result;
        v2 = v4.a; // android.support.v4.c.f.a:java.util.LinkedHashMap
        _result = v2.remove(v1); // java.util.LinkedHashMap.remove -> java.lang.Object
        v2 = v4.b; // android.support.v4.c.f.b:int
        _result = v4.c(v1, v0); // android.support.v4.c.f.c -> int
        v3 = _result;
        v2 = binOp2addr_0xb1(v2, v3);
        v4.b = v2; // android.support.v4.c.f.b:int
        v2 = v4.f; // android.support.v4.c.f.f:int
        v2 = binOpLit8_0xd8(v2, 1);
        v4.f = v2; // android.support.v4.c.f.f:int
        // monitor-exit(v4)
        v2 = 1;
        v3 = 0;
        _result = v4.a(v2, v1, v0, v3); // android.support.v4.c.f.a -> void
        // goto L_0000
    }

    protected void a(boolean p0, java.lang.Object p1, java.lang.Object p2, java.lang.Object p3) {
        // Registers (5 total): v0 = this, v1 = p0 (boolean), v2 = p1 (java.lang.Object), v3 = p2 (java.lang.Object), v4 = p3 (java.lang.Object)
        return;
    }

    protected int b(java.lang.Object p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (java.lang.Object)
        v0 = 1;
        return v0;
    }

    protected java.lang.Object b(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = 0;
        return v0;
    }

    public final java.lang.String toString() {
        // Registers (6 total): v5 = this
        v0 = 0;
        // monitor-enter(v5)
        v1 = v5.g; // android.support.v4.c.f.g:int
        v2 = v5.h; // android.support.v4.c.f.h:int
        v1 = binOp2addr_0xb0(v1, v2);
        if (v1 == 0) /* goto L_000e */;
        v0 = v5.g; // android.support.v4.c.f.g:int
        v0 = binOpLit8_0xda(v0, 100);
        v0 = binOp2addr_0xb3(v0, v1);
        v1 = "LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]";
        v2 = 4;
        v2 = new java.lang.Object[][size=v2];
        v3 = 0;
        v4 = v5.c; // android.support.v4.c.f.c:int
        _result = v4.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v4 = _result;
        v2[v3] = v4;
        v3 = 1;
        v4 = v5.g; // android.support.v4.c.f.g:int
        _result = v4.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v4 = _result;
        v2[v3] = v4;
        v3 = 2;
        v4 = v5.h; // android.support.v4.c.f.h:int
        _result = v4.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v4 = _result;
        v2[v3] = v4;
        v3 = 3;
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v0 = _result;
        v2[v3] = v0;
        _result = v1.format(v2); // java.lang.String.format -> java.lang.String
        v0 = _result;
        // monitor-exit(v5)
        return v0;
        v0 = _exception;
        // monitor-exit(v5)
        throw v0;
    }

}