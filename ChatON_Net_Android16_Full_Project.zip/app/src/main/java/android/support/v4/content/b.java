package android.support.v4.content;

/**
 * Original SourceFile: AsyncTaskLoader.java
 * Descriptor: Landroid/support/v4/content/b;
 */
final class b extends android.support.v4.content.m implements java.lang.Runnable {
     java.lang.Object a;
     boolean b;
    final android.support.v4.content.a c;
    private java.util.concurrent.CountDownLatch e;

    b(android.support.v4.content.a p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.content.a)
        v2.c = v3; // android.support.v4.content.b.c:android.support.v4.content.a
        _result = v2.<init>(); // android.support.v4.content.m.<init> -> void
        v0 = new java.util.concurrent.CountDownLatch;
        v1 = 1;
        _result = v0.<init>(v1); // java.util.concurrent.CountDownLatch.<init> -> void
        v2.e = v0; // android.support.v4.content.b.e:java.util.concurrent.CountDownLatch
        return;
    }

    protected java.lang.Object a(java.lang.Object[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object[])
        v2 = (java.lang.Void[]) v2;
        _result = v1.a(v2); // android.support.v4.content.b.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    protected java.lang.Object a(java.lang.Void[] p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Void[])
        v0 = v1.c; // android.support.v4.content.b.c:android.support.v4.content.a
        _result = v0.e(); // android.support.v4.content.a.e -> java.lang.Object
        v0 = _result;
        v1.a = v0; // android.support.v4.content.b.a:java.lang.Object
        v0 = v1.a; // android.support.v4.content.b.a:java.lang.Object
        return v0;
    }

    protected void a() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // android.support.v4.content.b.c:android.support.v4.content.a
        v1 = v2.a; // android.support.v4.content.b.a:java.lang.Object
        _result = v0.a(v2, v1); // android.support.v4.content.a.a -> void
        v0 = v2.e; // android.support.v4.content.b.e:java.util.concurrent.CountDownLatch
        _result = v0.countDown(); // java.util.concurrent.CountDownLatch.countDown -> void
        return;
        v0 = _exception;
        v1 = v2.e; // android.support.v4.content.b.e:java.util.concurrent.CountDownLatch
        _result = v1.countDown(); // java.util.concurrent.CountDownLatch.countDown -> void
        throw v0;
    }

    protected void a(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v0 = v2.c; // android.support.v4.content.b.c:android.support.v4.content.a
        _result = v0.b(v2, v3); // android.support.v4.content.a.b -> void
        v0 = v2.e; // android.support.v4.content.b.e:java.util.concurrent.CountDownLatch
        _result = v0.countDown(); // java.util.concurrent.CountDownLatch.countDown -> void
        return;
        v0 = _exception;
        v1 = v2.e; // android.support.v4.content.b.e:java.util.concurrent.CountDownLatch
        _result = v1.countDown(); // java.util.concurrent.CountDownLatch.countDown -> void
        throw v0;
    }

    public void run() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.b = v0; // android.support.v4.content.b.b:boolean
        v0 = v1.c; // android.support.v4.content.b.c:android.support.v4.content.a
        _result = v0.c(); // android.support.v4.content.a.c -> void
        return;
    }

}