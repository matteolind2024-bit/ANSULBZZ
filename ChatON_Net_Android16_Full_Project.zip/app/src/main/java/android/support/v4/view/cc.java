package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/cc;
 */
public interface cc {
    public abstract void a(int p0);
    public abstract void a(int p0, float p1, int p2);
    public abstract void b(int p0);
}