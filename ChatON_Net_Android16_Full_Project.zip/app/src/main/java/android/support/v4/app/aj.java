package android.support.v4.app;

/**
 * Original SourceFile: FragmentTransaction.java
 * Descriptor: Landroid/support/v4/app/aj;
 */
public abstract class aj {
    public aj() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public abstract android.support.v4.app.aj a();
    public abstract android.support.v4.app.aj a(int p0, android.support.v4.app.Fragment p1);
    public abstract android.support.v4.app.aj a(int p0, android.support.v4.app.Fragment p1, java.lang.String p2);
    public abstract android.support.v4.app.aj a(android.support.v4.app.Fragment p0);
    public abstract android.support.v4.app.aj a(android.support.v4.app.Fragment p0, java.lang.String p1);
    public abstract int b();
    public abstract android.support.v4.app.aj b(int p0, android.support.v4.app.Fragment p1);
    public abstract android.support.v4.app.aj b(int p0, android.support.v4.app.Fragment p1, java.lang.String p2);
    public abstract android.support.v4.app.aj b(android.support.v4.app.Fragment p0);
    public abstract int c();
    public abstract android.support.v4.app.aj c(android.support.v4.app.Fragment p0);
    public abstract android.support.v4.app.aj d(android.support.v4.app.Fragment p0);
    public abstract android.support.v4.app.aj e(android.support.v4.app.Fragment p0);
    public abstract boolean e();
}