package android.support.v4.content;

/**
 * Original SourceFile: Loader.java
 * Descriptor: Landroid/support/v4/content/f;
 */
public class f {
     int m;
     android.support.v4.content.h n;
     android.content.Context o;
     boolean p;
     boolean q;
     boolean r;
     boolean s;
     boolean t;

    public f(android.content.Context p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Context)
        v1 = 0;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.p = v1; // android.support.v4.content.f.p:boolean
        v2.q = v1; // android.support.v4.content.f.q:boolean
        v0 = 1;
        v2.r = v0; // android.support.v4.content.f.r:boolean
        v2.s = v1; // android.support.v4.content.f.s:boolean
        v2.t = v1; // android.support.v4.content.f.t:boolean
        _result = v3.getApplicationContext(); // android.content.Context.getApplicationContext -> android.content.Context
        v0 = _result;
        v2.o = v0; // android.support.v4.content.f.o:android.content.Context
        return;
    }

    protected void a() {
        // Registers (1 total): v0 = this
        return;
    }

    public void a(int p0, android.support.v4.content.h p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (android.support.v4.content.h)
        v0 = v2.n; // android.support.v4.content.f.n:android.support.v4.content.h
        if (v0 == 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "There is already a listener registered";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v2.n = v4; // android.support.v4.content.f.n:android.support.v4.content.h
        v2.m = v3; // android.support.v4.content.f.m:int
        return;
    }

    public void a(android.support.v4.content.h p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.content.h)
        v0 = v2.n; // android.support.v4.content.f.n:android.support.v4.content.h
        if (v0 != 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "No listener register";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v2.n; // android.support.v4.content.f.n:android.support.v4.content.h
        if (v0 == v3) /* goto L_001a */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Attempting to unregister the wrong listener";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = 0;
        v2.n = v0; // android.support.v4.content.f.n:android.support.v4.content.h
        return;
    }

    public void a(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.io.FileDescriptor), v4 = p2 (java.io.PrintWriter), v5 = p3 (java.lang.String[])
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mId=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.m; // android.support.v4.content.f.m:int
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mListener=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.n; // android.support.v4.content.f.n:android.support.v4.content.h
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        v0 = v1.p; // android.support.v4.content.f.p:boolean
        if (v0 != 0) /* goto L_0025 */;
        v0 = v1.s; // android.support.v4.content.f.s:boolean
        if (v0 != 0) /* goto L_0025 */;
        v0 = v1.t; // android.support.v4.content.f.t:boolean
        if (v0 == 0) /* goto L_0049 */;
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mStarted=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.p; // android.support.v4.content.f.p:boolean
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mContentChanged=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.s; // android.support.v4.content.f.s:boolean
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mProcessingChange=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.t; // android.support.v4.content.f.t:boolean
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        v0 = v1.q; // android.support.v4.content.f.q:boolean
        if (v0 != 0) /* goto L_0051 */;
        v0 = v1.r; // android.support.v4.content.f.r:boolean
        if (v0 == 0) /* goto L_006a */;
        _result = v4.print(v2); // java.io.PrintWriter.print -> void
        v0 = "mAbandoned=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.q; // android.support.v4.content.f.q:boolean
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mReset=";
        _result = v4.print(v0); // java.io.PrintWriter.print -> void
        v0 = v1.r; // android.support.v4.content.f.r:boolean
        _result = v4.println(v0); // java.io.PrintWriter.println -> void
        return;
    }

    public void b(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = v1.n; // android.support.v4.content.f.n:android.support.v4.content.h
        if (v0 == 0) /* goto L_0009 */;
        v0 = v1.n; // android.support.v4.content.f.n:android.support.v4.content.h
        _result = android.support.v4.content.h.a(v0, v1, v2); // -> void
        return;
    }

    public java.lang.String c(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v0 = new java.lang.StringBuilder;
        v1 = 64;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v3.a(v0); // android.support.v4.c.d.a -> void
        v1 = "}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    protected void g() {
        // Registers (1 total): v0 = this
        return;
    }

    protected void h() {
        // Registers (1 total): v0 = this
        return;
    }

    protected void i() {
        // Registers (1 total): v0 = this
        return;
    }

    public android.content.Context j() {
        // Registers (2 total): v1 = this
        v0 = v1.o; // android.support.v4.content.f.o:android.content.Context
        return v0;
    }

    public int k() {
        // Registers (2 total): v1 = this
        v0 = v1.m; // android.support.v4.content.f.m:int
        return v0;
    }

    public boolean l() {
        // Registers (2 total): v1 = this
        v0 = v1.p; // android.support.v4.content.f.p:boolean
        return v0;
    }

    public boolean m() {
        // Registers (2 total): v1 = this
        v0 = v1.q; // android.support.v4.content.f.q:boolean
        return v0;
    }

    public boolean n() {
        // Registers (2 total): v1 = this
        v0 = v1.r; // android.support.v4.content.f.r:boolean
        return v0;
    }

    public final void o() {
        // Registers (3 total): v2 = this
        v1 = 0;
        v0 = 1;
        v2.p = v0; // android.support.v4.content.f.p:boolean
        v2.r = v1; // android.support.v4.content.f.r:boolean
        v2.q = v1; // android.support.v4.content.f.q:boolean
        _result = v2.g(); // android.support.v4.content.f.g -> void
        return;
    }

    public void p() {
        // Registers (1 total): v0 = this
        _result = v0.a(); // android.support.v4.content.f.a -> void
        return;
    }

    public void q() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.p = v0; // android.support.v4.content.f.p:boolean
        _result = v1.h(); // android.support.v4.content.f.h -> void
        return;
    }

    public void r() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.q = v0; // android.support.v4.content.f.q:boolean
        _result = v1.s(); // android.support.v4.content.f.s -> void
        return;
    }

    protected void s() {
        // Registers (1 total): v0 = this
        return;
    }

    public void t() {
        // Registers (3 total): v2 = this
        v1 = 0;
        _result = v2.i(); // android.support.v4.content.f.i -> void
        v0 = 1;
        v2.r = v0; // android.support.v4.content.f.r:boolean
        v2.p = v1; // android.support.v4.content.f.p:boolean
        v2.q = v1; // android.support.v4.content.f.q:boolean
        v2.s = v1; // android.support.v4.content.f.s:boolean
        v2.t = v1; // android.support.v4.content.f.t:boolean
        return;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 64;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v2.a(v0); // android.support.v4.c.d.a -> void
        v1 = " id=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.m; // android.support.v4.content.f.m:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = "}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public boolean u() {
        // Registers (3 total): v2 = this
        v0 = v2.s; // android.support.v4.content.f.s:boolean
        v1 = 0;
        v2.s = v1; // android.support.v4.content.f.s:boolean
        v1 = v2.t; // android.support.v4.content.f.t:boolean
        v1 = binOp2addr_0xb6(v1, v0);
        v2.t = v1; // android.support.v4.content.f.t:boolean
        return v0;
    }

    public void v() {
        // Registers (2 total): v1 = this
        v0 = 0;
        v1.t = v0; // android.support.v4.content.f.t:boolean
        return;
    }

    public void w() {
        // Registers (2 total): v1 = this
        v0 = v1.t; // android.support.v4.content.f.t:boolean
        if (v0 == 0) /* goto L_0007 */;
        v0 = 1;
        v1.s = v0; // android.support.v4.content.f.s:boolean
        return;
    }

    public void x() {
        // Registers (2 total): v1 = this
        v0 = v1.p; // android.support.v4.content.f.p:boolean
        if (v0 == 0) /* goto L_0008 */;
        _result = v1.p(); // android.support.v4.content.f.p -> void
        return;
        v0 = 1;
        v1.s = v0; // android.support.v4.content.f.s:boolean
        // goto L_0007
    }

}