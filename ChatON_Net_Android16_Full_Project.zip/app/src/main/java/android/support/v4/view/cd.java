package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/cd;
 */
public interface cd {
    public abstract void a(android.view.View p0, float p1);
}