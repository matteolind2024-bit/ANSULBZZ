package android.support.v4.app;

/**
 * Original SourceFile: FragmentStatePagerAdapter.java
 * Descriptor: Landroid/support/v4/app/af;
 */
public abstract class af extends android.support.v4.view.ae {
    private final android.support.v4.app.w a;
    private android.support.v4.app.aj b;
    private java.util.ArrayList c;
    private java.util.ArrayList d;
    private android.support.v4.app.Fragment e;

    public af(android.support.v4.app.w p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.w)
        v1 = 0;
        _result = v2.<init>(); // android.support.v4.view.ae.<init> -> void
        v2.b = v1; // android.support.v4.app.af.b:android.support.v4.app.aj
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v2.c = v0; // android.support.v4.app.af.c:java.util.ArrayList
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v2.d = v0; // android.support.v4.app.af.d:java.util.ArrayList
        v2.e = v1; // android.support.v4.app.af.e:android.support.v4.app.Fragment
        v2.a = v3; // android.support.v4.app.af.a:android.support.v4.app.w
        return;
    }

    public android.os.Parcelable a() {
        // Registers (6 total): v5 = this
        v0 = 0;
        v1 = v5.c; // android.support.v4.app.af.c:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_0021 */;
        v0 = new android.os.Bundle;
        _result = v0.<init>(); // android.os.Bundle.<init> -> void
        v1 = v5.c; // android.support.v4.app.af.c:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v1 = _result;
        v1 = new android.support.v4.app.Fragment$SavedState[][size=v1];
        v2 = v5.c; // android.support.v4.app.af.c:java.util.ArrayList
        _result = v2.toArray(v1); // java.util.ArrayList.toArray -> java.lang.Object[]
        v2 = "states";
        _result = v0.putParcelableArray(v2, v1); // android.os.Bundle.putParcelableArray -> void
        v1 = 0;
        v2 = v0;
        v0 = v5.d; // android.support.v4.app.af.d:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0059 */;
        v0 = v5.d; // android.support.v4.app.af.d:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0055 */;
        if (v2 != 0) /* goto L_003c */;
        v2 = new android.os.Bundle;
        _result = v2.<init>(); // android.os.Bundle.<init> -> void
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "f";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v4 = v5.a; // android.support.v4.app.af.a:android.support.v4.app.w
        _result = v4.a(v2, v3, v0); // android.support.v4.app.w.a -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0023
        return v2;
    }

    public abstract android.support.v4.app.Fragment a(int p0);
    public java.lang.Object a(android.view.ViewGroup p0, int p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.view.ViewGroup), v6 = p1 (int)
        v3 = 0;
        v0 = v4.d; // android.support.v4.app.af.d:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= v6) /* goto L_0014 */;
        v0 = v4.d; // android.support.v4.app.af.d:java.util.ArrayList
        _result = v0.get(v6); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v0 == 0) /* goto L_0014 */;
        return v0;
        v0 = v4.b; // android.support.v4.app.af.b:android.support.v4.app.aj
        if (v0 != 0) /* goto L_0020 */;
        v0 = v4.a; // android.support.v4.app.af.a:android.support.v4.app.w
        _result = v0.a(); // android.support.v4.app.w.a -> android.support.v4.app.aj
        v0 = _result;
        v4.b = v0; // android.support.v4.app.af.b:android.support.v4.app.aj
        _result = v4.a(v6); // android.support.v4.app.af.a -> android.support.v4.app.Fragment
        v1 = _result;
        v0 = v4.c; // android.support.v4.app.af.c:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= v6) /* goto L_0039 */;
        v0 = v4.c; // android.support.v4.app.af.c:java.util.ArrayList
        _result = v0.get(v6); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment$SavedState) v0;
        if (v0 == 0) /* goto L_0039 */;
        _result = v1.setInitialSavedState(v0); // android.support.v4.app.Fragment.setInitialSavedState -> void
        v0 = v4.d; // android.support.v4.app.af.d:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > v6) /* goto L_0048 */;
        v0 = v4.d; // android.support.v4.app.af.d:java.util.ArrayList
        v2 = 0;
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        // goto L_0039
        _result = v1.setMenuVisibility(v3); // android.support.v4.app.Fragment.setMenuVisibility -> void
        _result = v1.setUserVisibleHint(v3); // android.support.v4.app.Fragment.setUserVisibleHint -> void
        v0 = v4.d; // android.support.v4.app.af.d:java.util.ArrayList
        _result = v0.set(v6, v1); // java.util.ArrayList.set -> java.lang.Object
        v0 = v4.b; // android.support.v4.app.af.b:android.support.v4.app.aj
        _result = v5.getId(); // android.view.ViewGroup.getId -> int
        v2 = _result;
        _result = v0.a(v2, v1); // android.support.v4.app.aj.a -> android.support.v4.app.aj
        v0 = v1;
        // goto L_0013
    }

    public void a(android.os.Parcelable p0, java.lang.ClassLoader p1) {
        // Registers (9 total): v6 = this, v7 = p0 (android.os.Parcelable), v8 = p1 (java.lang.ClassLoader)
        v2 = 0;
        if (v7 == 0) /* goto L_008d */;
        v7 = (android.os.Bundle) v7;
        _result = v7.setClassLoader(v8); // android.os.Bundle.setClassLoader -> void
        v0 = "states";
        _result = v7.getParcelableArray(v0); // android.os.Bundle.getParcelableArray -> android.os.Parcelable[]
        v3 = _result;
        v0 = v6.c; // android.support.v4.app.af.c:java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        v0 = v6.d; // android.support.v4.app.af.d:java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        if (v3 == 0) /* goto L_002c */;
        v1 = v2;
        v0 = v3.length;
        if (v1 >= v0) /* goto L_002c */;
        v4 = v6.c; // android.support.v4.app.af.c:java.util.ArrayList
        v0 = v3[v1];
        v0 = (android.support.v4.app.Fragment$SavedState) v0;
        _result = v4.add(v0); // java.util.ArrayList.add -> boolean
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_001c
        _result = v7.keySet(); // android.os.Bundle.keySet -> java.util.Set
        v0 = _result;
        _result = java.lang.Iterable.iterator(v0); // -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_008d */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        v3 = "f";
        _result = v0.startsWith(v3); // java.lang.String.startsWith -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0034 */;
        v3 = 1;
        _result = v0.substring(v3); // java.lang.String.substring -> java.lang.String
        v3 = _result;
        _result = v3.parseInt(); // java.lang.Integer.parseInt -> int
        v3 = _result;
        v4 = v6.a; // android.support.v4.app.af.a:android.support.v4.app.w
        _result = v4.a(v7, v0); // android.support.v4.app.w.a -> android.support.v4.app.Fragment
        v4 = _result;
        if (v4 == 0) /* goto L_0072 */;
        v0 = v6.d; // android.support.v4.app.af.d:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > v3) /* goto L_0069 */;
        v0 = v6.d; // android.support.v4.app.af.d:java.util.ArrayList
        v5 = 0;
        _result = v0.add(v5); // java.util.ArrayList.add -> boolean
        // goto L_005a
        _result = v4.setMenuVisibility(v2); // android.support.v4.app.Fragment.setMenuVisibility -> void
        v0 = v6.d; // android.support.v4.app.af.d:java.util.ArrayList
        _result = v0.set(v3, v4); // java.util.ArrayList.set -> java.lang.Object
        // goto L_0034
        v3 = "FragmentStatePagerAdapter";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "Bad fragment at key ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v3.w(v0); // android.util.Log.w -> int
        // goto L_0034
        return;
    }

    public void a(android.view.ViewGroup p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.ViewGroup)
        return;
    }

    public void a(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.view.ViewGroup), v5 = p1 (int), v6 = p2 (java.lang.Object)
        v2 = 0;
        v6 = (android.support.v4.app.Fragment) v6;
        v0 = v3.b; // android.support.v4.app.af.b:android.support.v4.app.aj
        if (v0 != 0) /* goto L_000f */;
        v0 = v3.a; // android.support.v4.app.af.a:android.support.v4.app.w
        _result = v0.a(); // android.support.v4.app.w.a -> android.support.v4.app.aj
        v0 = _result;
        v3.b = v0; // android.support.v4.app.af.b:android.support.v4.app.aj
        v0 = v3.c; // android.support.v4.app.af.c:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 > v5) /* goto L_001d */;
        v0 = v3.c; // android.support.v4.app.af.c:java.util.ArrayList
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        // goto L_000f
        v0 = v3.c; // android.support.v4.app.af.c:java.util.ArrayList
        v1 = v3.a; // android.support.v4.app.af.a:android.support.v4.app.w
        _result = v1.a(v6); // android.support.v4.app.w.a -> android.support.v4.app.Fragment$SavedState
        v1 = _result;
        _result = v0.set(v5, v1); // java.util.ArrayList.set -> java.lang.Object
        v0 = v3.d; // android.support.v4.app.af.d:java.util.ArrayList
        _result = v0.set(v5, v2); // java.util.ArrayList.set -> java.lang.Object
        v0 = v3.b; // android.support.v4.app.af.b:android.support.v4.app.aj
        _result = v0.a(v6); // android.support.v4.app.aj.a -> android.support.v4.app.aj
        return;
    }

    public boolean a(android.view.View p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (java.lang.Object)
        v3 = (android.support.v4.app.Fragment) v3;
        _result = v3.getView(); // android.support.v4.app.Fragment.getView -> android.view.View
        v0 = _result;
        if (v0 != v2) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public void b(android.view.ViewGroup p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup)
        v0 = v1.b; // android.support.v4.app.af.b:android.support.v4.app.aj
        if (v0 == 0) /* goto L_0011 */;
        v0 = v1.b; // android.support.v4.app.af.b:android.support.v4.app.aj
        _result = v0.c(); // android.support.v4.app.aj.c -> int
        v0 = 0;
        v1.b = v0; // android.support.v4.app.af.b:android.support.v4.app.aj
        v0 = v1.a; // android.support.v4.app.af.a:android.support.v4.app.w
        _result = v0.b(); // android.support.v4.app.w.b -> boolean
        return;
    }

    public void b(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.view.ViewGroup), v5 = p1 (int), v6 = p2 (java.lang.Object)
        v2 = 1;
        v1 = 0;
        v6 = (android.support.v4.app.Fragment) v6;
        v0 = v3.e; // android.support.v4.app.af.e:android.support.v4.app.Fragment
        if (v6 == v0) /* goto L_0020 */;
        v0 = v3.e; // android.support.v4.app.af.e:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0016 */;
        v0 = v3.e; // android.support.v4.app.af.e:android.support.v4.app.Fragment
        _result = v0.setMenuVisibility(v1); // android.support.v4.app.Fragment.setMenuVisibility -> void
        v0 = v3.e; // android.support.v4.app.af.e:android.support.v4.app.Fragment
        _result = v0.setUserVisibleHint(v1); // android.support.v4.app.Fragment.setUserVisibleHint -> void
        if (v6 == 0) /* goto L_001e */;
        _result = v6.setMenuVisibility(v2); // android.support.v4.app.Fragment.setMenuVisibility -> void
        _result = v6.setUserVisibleHint(v2); // android.support.v4.app.Fragment.setUserVisibleHint -> void
        v3.e = v6; // android.support.v4.app.af.e:android.support.v4.app.Fragment
        return;
    }

}