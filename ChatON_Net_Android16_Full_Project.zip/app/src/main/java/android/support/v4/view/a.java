package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompat.java
 * Descriptor: Landroid/support/v4/view/a;
 */
public class a {
    private static final android.support.v4.view.d b;
    private static final java.lang.Object c;
    final java.lang.Object a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_0016 */;
        v0 = new android.support.v4.view.e;
        _result = v0.<init>(); // android.support.v4.view.e.<init> -> void
        android.support.v4.view.a.b = v0; // :android.support.v4.view.d
        v0 = android.support.v4.view.a.b; // :android.support.v4.view.d
        _result = android.support.v4.view.d.a(v0); // -> java.lang.Object
        v0 = _result;
        android.support.v4.view.a.c = v0; // :java.lang.Object
        return;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_0024 */;
        v0 = new android.support.v4.view.b;
        _result = v0.<init>(); // android.support.v4.view.b.<init> -> void
        android.support.v4.view.a.b = v0; // :android.support.v4.view.d
        // goto L_000d
        v0 = new android.support.v4.view.g;
        _result = v0.<init>(); // android.support.v4.view.g.<init> -> void
        android.support.v4.view.a.b = v0; // :android.support.v4.view.d
        // goto L_000d
    }

    public a() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = android.support.v4.view.a.b; // :android.support.v4.view.d
        _result = android.support.v4.view.d.a(v0, v1); // -> java.lang.Object
        v0 = _result;
        v1.a = v0; // android.support.v4.view.a.a:java.lang.Object
        return;
    }

    public android.support.v4.view.a.k a(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = android.support.v4.view.a.b; // :android.support.v4.view.d
        v1 = android.support.v4.view.a.c; // :java.lang.Object
        _result = android.support.v4.view.d.a(v0, v1, v3); // -> android.support.v4.view.a.k
        v0 = _result;
        return v0;
    }

    java.lang.Object a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.view.a.a:java.lang.Object
        return v0;
    }

    public void a(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = android.support.v4.view.a.b; // :android.support.v4.view.d
        v1 = android.support.v4.view.a.c; // :java.lang.Object
        _result = android.support.v4.view.d.a(v0, v1, v3, v4); // -> void
        return;
    }

    public void a(android.view.View p0, android.support.v4.view.a.a p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.support.v4.view.a.a)
        v0 = android.support.v4.view.a.b; // :android.support.v4.view.d
        v1 = android.support.v4.view.a.c; // :java.lang.Object
        _result = android.support.v4.view.d.a(v0, v1, v3, v4); // -> void
        return;
    }

    public void a(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.a.b; // :android.support.v4.view.d
        v1 = android.support.v4.view.a.c; // :java.lang.Object
        _result = android.support.v4.view.d.d(v0, v1, v3, v4); // -> void
        return;
    }

    public boolean a(android.view.View p0, int p1, android.os.Bundle p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int), v5 = p2 (android.os.Bundle)
        v0 = android.support.v4.view.a.b; // :android.support.v4.view.d
        v1 = android.support.v4.view.a.c; // :java.lang.Object
        _result = android.support.v4.view.d.a(v0, v1, v3, v4, v5); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean a(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.ViewGroup), v4 = p1 (android.view.View), v5 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.a.b; // :android.support.v4.view.d
        v1 = android.support.v4.view.a.c; // :java.lang.Object
        _result = android.support.v4.view.d.a(v0, v1, v3, v4, v5); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean b(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.a.b; // :android.support.v4.view.d
        v1 = android.support.v4.view.a.c; // :java.lang.Object
        _result = android.support.v4.view.d.a(v0, v1, v3, v4); // -> boolean
        v0 = _result;
        return v0;
    }

    public void c(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.a.b; // :android.support.v4.view.d
        v1 = android.support.v4.view.a.c; // :java.lang.Object
        _result = android.support.v4.view.d.c(v0, v1, v3, v4); // -> void
        return;
    }

    public void d(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = android.support.v4.view.a.b; // :android.support.v4.view.d
        v1 = android.support.v4.view.a.c; // :java.lang.Object
        _result = android.support.v4.view.d.b(v0, v1, v3, v4); // -> void
        return;
    }

}