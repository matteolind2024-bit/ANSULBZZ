package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/ba;
 */
class ba extends android.support.v4.view.az {
    ba() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.az.<init> -> void
        return;
    }

    public void a(android.view.View p0, android.graphics.Paint p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.graphics.Paint)
        _result = v1.a(v2); // android.support.v4.view.bi.a -> void
        return;
    }

    public int e(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.a(); // android.support.v4.view.bi.a -> int
        v0 = _result;
        return v0;
    }

}