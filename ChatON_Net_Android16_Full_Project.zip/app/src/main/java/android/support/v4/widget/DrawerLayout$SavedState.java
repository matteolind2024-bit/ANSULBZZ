package android.support.v4.widget;

/**
 * Original SourceFile: DrawerLayout.java
 * Descriptor: Landroid/support/v4/widget/DrawerLayout$SavedState;
 */
public class DrawerLayout$SavedState extends android.view.View$BaseSavedState {
    public static final android.os.Parcelable$Creator CREATOR;
     int lockModeLeft;
     int lockModeRight;
     int openDrawerGravity;

    static {
        v0 = new android.support.v4.widget.k;
        _result = v0.<init>(); // android.support.v4.widget.k.<init> -> void
        android.support.v4.widget.DrawerLayout$SavedState.CREATOR = v0; // :android.os.Parcelable$Creator
        return;
    }

    public DrawerLayout$SavedState(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        v0 = 0;
        _result = v1.<init>(v2); // android.view.View$BaseSavedState.<init> -> void
        v1.openDrawerGravity = v0; // android.support.v4.widget.DrawerLayout$SavedState.openDrawerGravity:int
        v1.lockModeLeft = v0; // android.support.v4.widget.DrawerLayout$SavedState.lockModeLeft:int
        v1.lockModeRight = v0; // android.support.v4.widget.DrawerLayout$SavedState.lockModeRight:int
        _result = v2.readInt(); // android.os.Parcel.readInt -> int
        v0 = _result;
        v1.openDrawerGravity = v0; // android.support.v4.widget.DrawerLayout$SavedState.openDrawerGravity:int
        return;
    }

    public DrawerLayout$SavedState(android.os.Parcelable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcelable)
        v0 = 0;
        _result = v1.<init>(v2); // android.view.View$BaseSavedState.<init> -> void
        v1.openDrawerGravity = v0; // android.support.v4.widget.DrawerLayout$SavedState.openDrawerGravity:int
        v1.lockModeLeft = v0; // android.support.v4.widget.DrawerLayout$SavedState.lockModeLeft:int
        v1.lockModeRight = v0; // android.support.v4.widget.DrawerLayout$SavedState.lockModeRight:int
        return;
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (int)
        _result = v1.writeToParcel(v2, v3); // android.view.View$BaseSavedState.writeToParcel -> void
        v0 = v1.openDrawerGravity; // android.support.v4.widget.DrawerLayout$SavedState.openDrawerGravity:int
        _result = v2.writeInt(v0); // android.os.Parcel.writeInt -> void
        return;
    }

}