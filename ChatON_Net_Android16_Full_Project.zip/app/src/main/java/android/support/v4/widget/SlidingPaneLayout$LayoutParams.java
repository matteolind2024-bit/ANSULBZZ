package android.support.v4.widget;

/**
 * Original SourceFile: SlidingPaneLayout.java
 * Descriptor: Landroid/support/v4/widget/SlidingPaneLayout$LayoutParams;
 */
public class SlidingPaneLayout$LayoutParams extends android.view.ViewGroup$MarginLayoutParams {
    private static final int[] e;
    public float a;
     boolean b;
     boolean c;
     android.graphics.Paint d;

    static {
        v0 = 1;
        v0 = new int[][size=v0];
        v1 = 0;
        v2 = 16843137; // 0x01010181
        v0[v1] = v2;
        android.support.v4.widget.SlidingPaneLayout$LayoutParams.e = v0; // :int[]
        return;
    }

    public SlidingPaneLayout$LayoutParams() {
        // Registers (2 total): v1 = this
        v0 = -1;
        _result = v1.<init>(v0, v0); // android.view.ViewGroup$MarginLayoutParams.<init> -> void
        v0 = 0;
        v1.a = v0; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.a:float
        return;
    }

    public SlidingPaneLayout$LayoutParams(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.util.AttributeSet)
        v2 = 0;
        _result = v3.<init>(v4, v5); // android.view.ViewGroup$MarginLayoutParams.<init> -> void
        v3.a = v2; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.a:float
        v0 = android.support.v4.widget.SlidingPaneLayout$LayoutParams.e; // :int[]
        _result = v4.obtainStyledAttributes(v5, v0); // android.content.Context.obtainStyledAttributes -> android.content.res.TypedArray
        v0 = _result;
        v1 = 0;
        _result = v0.getFloat(v1, v2); // android.content.res.TypedArray.getFloat -> float
        v1 = _result;
        v3.a = v1; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.a:float
        _result = v0.recycle(); // android.content.res.TypedArray.recycle -> void
        return;
    }

    public SlidingPaneLayout$LayoutParams(android.view.ViewGroup$LayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$LayoutParams)
        _result = v1.<init>(v2); // android.view.ViewGroup$MarginLayoutParams.<init> -> void
        v0 = 0;
        v1.a = v0; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.a:float
        return;
    }

    public SlidingPaneLayout$LayoutParams(android.view.ViewGroup$MarginLayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$MarginLayoutParams)
        _result = v1.<init>(v2); // android.view.ViewGroup$MarginLayoutParams.<init> -> void
        v0 = 0;
        v1.a = v0; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.a:float
        return;
    }

}