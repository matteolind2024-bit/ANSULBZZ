package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompat.java
 * Descriptor: Landroid/support/v4/view/b;
 */
class b extends android.support.v4.view.g {
    b() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.g.<init> -> void
        return;
    }

    public java.lang.Object a() {
        // Registers (2 total): v1 = this
        _result = this.a(); // android.support.v4.view.h.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object a(android.support.v4.view.a p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.a)
        v0 = new android.support.v4.view.c;
        _result = v0.<init>(v1, v2); // android.support.v4.view.c.<init> -> void
        _result = v0.a(); // android.support.v4.view.h.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void a(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (int)
        _result = v1.a(v2, v3); // android.support.v4.view.h.a -> void
        return;
    }

    public void a(java.lang.Object p0, android.view.View p1, android.support.v4.view.a.a p2) {
        // Registers (5 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.view.View), v4 = p2 (android.support.v4.view.a.a)
        _result = v4.a(); // android.support.v4.view.a.a.a -> java.lang.Object
        v0 = _result;
        _result = v2.a(v3, v0); // android.support.v4.view.h.a -> void
        return;
    }

    public boolean a(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.view.View), v4 = p2 (android.view.accessibility.AccessibilityEvent)
        _result = v2.a(v3, v4); // android.support.v4.view.h.a -> boolean
        v0 = _result;
        return v0;
    }

    public boolean a(java.lang.Object p0, android.view.ViewGroup p1, android.view.View p2, android.view.accessibility.AccessibilityEvent p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.view.ViewGroup), v4 = p2 (android.view.View), v5 = p3 (android.view.accessibility.AccessibilityEvent)
        _result = v2.a(v3, v4, v5); // android.support.v4.view.h.a -> boolean
        v0 = _result;
        return v0;
    }

    public void b(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        _result = v1.b(v2, v3); // android.support.v4.view.h.b -> void
        return;
    }

    public void c(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        _result = v1.c(v2, v3); // android.support.v4.view.h.c -> void
        return;
    }

    public void d(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        _result = v1.d(v2, v3); // android.support.v4.view.h.d -> void
        return;
    }

}