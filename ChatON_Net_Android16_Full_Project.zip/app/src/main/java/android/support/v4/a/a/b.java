package android.support.v4.a.a;

/**
 * Original SourceFile: DrawableCompat.java
 * Descriptor: Landroid/support/v4/a/a/b;
 */
class b implements android.support.v4.a.a.c {
    b() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void a(android.graphics.drawable.Drawable p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.graphics.drawable.Drawable), v2 = p1 (boolean)
        return;
    }

    public boolean a(android.graphics.drawable.Drawable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.graphics.drawable.Drawable)
        v0 = 0;
        return v0;
    }

}