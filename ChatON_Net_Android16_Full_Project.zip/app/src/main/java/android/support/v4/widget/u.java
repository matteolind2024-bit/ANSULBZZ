package android.support.v4.widget;

/**
 * Original SourceFile: ScrollerCompat.java
 * Descriptor: Landroid/support/v4/widget/u;
 */
interface u {
    public abstract java.lang.Object a(android.content.Context p0, android.view.animation.Interpolator p1);
    public abstract void a(java.lang.Object p0, int p1, int p2, int p3, int p4, int p5);
    public abstract boolean a(java.lang.Object p0);
    public abstract int b(java.lang.Object p0);
    public abstract int c(java.lang.Object p0);
    public abstract boolean d(java.lang.Object p0);
    public abstract void e(java.lang.Object p0);
    public abstract int f(java.lang.Object p0);
    public abstract int g(java.lang.Object p0);
}