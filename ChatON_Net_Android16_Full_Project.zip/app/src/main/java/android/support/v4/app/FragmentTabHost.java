package android.support.v4.app;

/**
 * Original SourceFile: FragmentTabHost.java
 * Descriptor: Landroid/support/v4/app/FragmentTabHost;
 */
public class FragmentTabHost extends android.widget.TabHost implements android.widget.TabHost$OnTabChangeListener {
    private final java.util.ArrayList a;
    private android.widget.FrameLayout b;
    private android.content.Context c;
    private android.support.v4.app.w d;
    private int e;
    private android.widget.TabHost$OnTabChangeListener f;
    private android.support.v4.app.ai g;
    private boolean h;

    public FragmentTabHost(android.content.Context p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.content.Context)
        v1 = 0;
        _result = v2.<init>(v3, v1); // android.widget.TabHost.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v2.a = v0; // android.support.v4.app.FragmentTabHost.a:java.util.ArrayList
        _result = v2.a(v3, v1); // android.support.v4.app.FragmentTabHost.a -> void
        return;
    }

    public FragmentTabHost(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.util.AttributeSet)
        _result = v1.<init>(v2, v3); // android.widget.TabHost.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.a = v0; // android.support.v4.app.FragmentTabHost.a:java.util.ArrayList
        _result = v1.a(v2, v3); // android.support.v4.app.FragmentTabHost.a -> void
        return;
    }

    private android.support.v4.app.aj a(java.lang.String p0, android.support.v4.app.aj p1) {
        // Registers (7 total): v4 = this, v5 = p0 (java.lang.String), v6 = p1 (android.support.v4.app.aj)
        v1 = 0;
        v0 = 0;
        v2 = v0;
        v0 = v4.a; // android.support.v4.app.FragmentTabHost.a:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v2 >= v0) /* goto L_0022 */;
        v0 = v4.a; // android.support.v4.app.FragmentTabHost.a:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ai) v0;
        _result = v0.b(); // android.support.v4.app.ai.b -> java.lang.String
        v3 = _result;
        _result = v3.equals(v5); // java.lang.String.equals -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0094 */;
        v1 = binOpLit8_0xd8(v2, 1);
        v2 = v1;
        v1 = v0;
        // goto L_0003
        if (v1 != 0) /* goto L_003e */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "No tab known for tag ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v4.g; // android.support.v4.app.FragmentTabHost.g:android.support.v4.app.ai
        if (v0 == v1) /* goto L_008b */;
        if (v6 != 0) /* goto L_004a */;
        v0 = v4.d; // android.support.v4.app.FragmentTabHost.d:android.support.v4.app.w
        _result = v0.a(); // android.support.v4.app.w.a -> android.support.v4.app.aj
        v6 = _result;
        v0 = v4.g; // android.support.v4.app.FragmentTabHost.g:android.support.v4.app.ai
        if (v0 == 0) /* goto L_005f */;
        v0 = v4.g; // android.support.v4.app.FragmentTabHost.g:android.support.v4.app.ai
        _result = v0.a(); // android.support.v4.app.ai.a -> android.support.v4.app.Fragment
        v0 = _result;
        if (v0 == 0) /* goto L_005f */;
        v0 = v4.g; // android.support.v4.app.FragmentTabHost.g:android.support.v4.app.ai
        _result = v0.a(); // android.support.v4.app.ai.a -> android.support.v4.app.Fragment
        v0 = _result;
        _result = v6.d(v0); // android.support.v4.app.aj.d -> android.support.v4.app.aj
        if (v1 == 0) /* goto L_0089 */;
        _result = v1.a(); // android.support.v4.app.ai.a -> android.support.v4.app.Fragment
        v0 = _result;
        if (v0 != 0) /* goto L_008c */;
        v0 = v4.c; // android.support.v4.app.FragmentTabHost.c:android.content.Context
        _result = v1.c(); // android.support.v4.app.ai.c -> java.lang.Class
        v2 = _result;
        _result = v2.getName(); // java.lang.Class.getName -> java.lang.String
        v2 = _result;
        _result = v1.d(); // android.support.v4.app.ai.d -> android.os.Bundle
        v3 = _result;
        _result = v0.instantiate(v2, v3); // android.support.v4.app.Fragment.instantiate -> android.support.v4.app.Fragment
        v0 = _result;
        _result = v1.a(v0); // android.support.v4.app.ai.a -> android.support.v4.app.Fragment
        v0 = v4.e; // android.support.v4.app.FragmentTabHost.e:int
        _result = v1.a(); // android.support.v4.app.ai.a -> android.support.v4.app.Fragment
        v2 = _result;
        _result = v1.b(); // android.support.v4.app.ai.b -> java.lang.String
        v3 = _result;
        _result = v6.a(v0, v2, v3); // android.support.v4.app.aj.a -> android.support.v4.app.aj
        v4.g = v1; // android.support.v4.app.FragmentTabHost.g:android.support.v4.app.ai
        return v6;
        _result = v1.a(); // android.support.v4.app.ai.a -> android.support.v4.app.Fragment
        v0 = _result;
        _result = v6.e(v0); // android.support.v4.app.aj.e -> android.support.v4.app.aj
        // goto L_0089
        v0 = v1;
        // goto L_001d
    }

    private void a() {
        // Registers (4 total): v3 = this
        v0 = v3.b; // android.support.v4.app.FragmentTabHost.b:android.widget.FrameLayout
        if (v0 != 0) /* goto L_002e */;
        v0 = v3.e; // android.support.v4.app.FragmentTabHost.e:int
        _result = v3.findViewById(v0); // android.support.v4.app.FragmentTabHost.findViewById -> android.view.View
        v0 = _result;
        v0 = (android.widget.FrameLayout) v0;
        v3.b = v0; // android.support.v4.app.FragmentTabHost.b:android.widget.FrameLayout
        v0 = v3.b; // android.support.v4.app.FragmentTabHost.b:android.widget.FrameLayout
        if (v0 != 0) /* goto L_002e */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "No tab content FrameLayout found for id ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.e; // android.support.v4.app.FragmentTabHost.e:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        return;
    }

    private void a(android.content.Context p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.content.Context)
        v2 = 16908307; // 0x01020013
        v6 = 0;
        v5 = 0;
        v4 = -1;
        _result = v7.findViewById(v2); // android.support.v4.app.FragmentTabHost.findViewById -> android.view.View
        v0 = _result;
        if (v0 != 0) /* goto L_005c */;
        v0 = new android.widget.LinearLayout;
        _result = v0.<init>(v8); // android.widget.LinearLayout.<init> -> void
        v1 = 1;
        _result = v0.setOrientation(v1); // android.widget.LinearLayout.setOrientation -> void
        v1 = new android.widget.FrameLayout$LayoutParams;
        _result = v1.<init>(v4, v4); // android.widget.FrameLayout$LayoutParams.<init> -> void
        _result = v7.addView(v0, v1); // android.support.v4.app.FragmentTabHost.addView -> void
        v1 = new android.widget.TabWidget;
        _result = v1.<init>(v8); // android.widget.TabWidget.<init> -> void
        _result = v1.setId(v2); // android.widget.TabWidget.setId -> void
        _result = v1.setOrientation(v5); // android.widget.TabWidget.setOrientation -> void
        v2 = new android.widget.LinearLayout$LayoutParams;
        v3 = -2;
        _result = v2.<init>(v4, v3, v6); // android.widget.LinearLayout$LayoutParams.<init> -> void
        _result = v0.addView(v1, v2); // android.widget.LinearLayout.addView -> void
        v1 = new android.widget.FrameLayout;
        _result = v1.<init>(v8); // android.widget.FrameLayout.<init> -> void
        v2 = 16908305; // 0x01020011
        _result = v1.setId(v2); // android.widget.FrameLayout.setId -> void
        v2 = new android.widget.LinearLayout$LayoutParams;
        _result = v2.<init>(v5, v5, v6); // android.widget.LinearLayout$LayoutParams.<init> -> void
        _result = v0.addView(v1, v2); // android.widget.LinearLayout.addView -> void
        v1 = new android.widget.FrameLayout;
        _result = v1.<init>(v8); // android.widget.FrameLayout.<init> -> void
        v7.b = v1; // android.support.v4.app.FragmentTabHost.b:android.widget.FrameLayout
        v2 = v7.b; // android.support.v4.app.FragmentTabHost.b:android.widget.FrameLayout
        v3 = v7.e; // android.support.v4.app.FragmentTabHost.e:int
        _result = v2.setId(v3); // android.widget.FrameLayout.setId -> void
        v2 = new android.widget.LinearLayout$LayoutParams;
        v3 = 0x3f800000;
        _result = v2.<init>(v4, v5, v3); // android.widget.LinearLayout$LayoutParams.<init> -> void
        _result = v0.addView(v1, v2); // android.widget.LinearLayout.addView -> void
        return;
    }

    private void a(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.util.AttributeSet)
        v2 = 0;
        v0 = 1;
        v0 = new int[][size=v0];
        v1 = 16842995; // 0x010100f3
        v0[v2] = v1;
        _result = v4.obtainStyledAttributes(v5, v0, v2, v2); // android.content.Context.obtainStyledAttributes -> android.content.res.TypedArray
        v0 = _result;
        _result = v0.getResourceId(v2, v2); // android.content.res.TypedArray.getResourceId -> int
        v1 = _result;
        v3.e = v1; // android.support.v4.app.FragmentTabHost.e:int
        _result = v0.recycle(); // android.content.res.TypedArray.recycle -> void
        _result = v3.setOnTabChangedListener(v3); // android.widget.TabHost.setOnTabChangedListener -> void
        return;
    }

    protected void onAttachedToWindow() {
        // Registers (7 total): v6 = this
        _result = v6.onAttachedToWindow(); // android.widget.TabHost.onAttachedToWindow -> void
        _result = v6.getCurrentTabTag(); // android.support.v4.app.FragmentTabHost.getCurrentTabTag -> java.lang.String
        v3 = _result;
        v1 = 0;
        v0 = 0;
        v2 = v0;
        v0 = v6.a; // android.support.v4.app.FragmentTabHost.a:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v2 >= v0) /* goto L_0057 */;
        v0 = v6.a; // android.support.v4.app.FragmentTabHost.a:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ai) v0;
        v4 = v6.d; // android.support.v4.app.FragmentTabHost.d:android.support.v4.app.w
        _result = v0.b(); // android.support.v4.app.ai.b -> java.lang.String
        v5 = _result;
        _result = v4.a(v5); // android.support.v4.app.w.a -> android.support.v4.app.Fragment
        v4 = _result;
        _result = v0.a(v4); // android.support.v4.app.ai.a -> android.support.v4.app.Fragment
        _result = v0.a(); // android.support.v4.app.ai.a -> android.support.v4.app.Fragment
        v4 = _result;
        if (v4 == 0) /* goto L_0043 */;
        _result = v0.a(); // android.support.v4.app.ai.a -> android.support.v4.app.Fragment
        v4 = _result;
        _result = v4.isDetached(); // android.support.v4.app.Fragment.isDetached -> boolean
        v4 = _result;
        if (v4 != 0) /* goto L_0043 */;
        _result = v0.b(); // android.support.v4.app.ai.b -> java.lang.String
        v4 = _result;
        _result = v4.equals(v3); // java.lang.String.equals -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_0047 */;
        v6.g = v0; // android.support.v4.app.FragmentTabHost.g:android.support.v4.app.ai
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_000a
        if (v1 != 0) /* goto L_004f */;
        v1 = v6.d; // android.support.v4.app.FragmentTabHost.d:android.support.v4.app.w
        _result = v1.a(); // android.support.v4.app.w.a -> android.support.v4.app.aj
        v1 = _result;
        _result = v0.a(); // android.support.v4.app.ai.a -> android.support.v4.app.Fragment
        v0 = _result;
        _result = v1.d(v0); // android.support.v4.app.aj.d -> android.support.v4.app.aj
        // goto L_0043
        v0 = 1;
        v6.h = v0; // android.support.v4.app.FragmentTabHost.h:boolean
        _result = v6.a(v3, v1); // android.support.v4.app.FragmentTabHost.a -> android.support.v4.app.aj
        v0 = _result;
        if (v0 == 0) /* goto L_0068 */;
        _result = v0.b(); // android.support.v4.app.aj.b -> int
        v0 = v6.d; // android.support.v4.app.FragmentTabHost.d:android.support.v4.app.w
        _result = v0.b(); // android.support.v4.app.w.b -> boolean
        return;
    }

    protected void onDetachedFromWindow() {
        // Registers (2 total): v1 = this
        _result = v1.onDetachedFromWindow(); // android.widget.TabHost.onDetachedFromWindow -> void
        v0 = 0;
        v1.h = v0; // android.support.v4.app.FragmentTabHost.h:boolean
        return;
    }

    protected void onRestoreInstanceState(android.os.Parcelable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcelable)
        v2 = (android.support.v4.app.FragmentTabHost$SavedState) v2;
        _result = v2.getSuperState(); // android.support.v4.app.FragmentTabHost$SavedState.getSuperState -> android.os.Parcelable
        v0 = _result;
        _result = v1.onRestoreInstanceState(v0); // android.widget.TabHost.onRestoreInstanceState -> void
        v0 = v2.curTab; // android.support.v4.app.FragmentTabHost$SavedState.curTab:java.lang.String
        _result = v1.setCurrentTabByTag(v0); // android.support.v4.app.FragmentTabHost.setCurrentTabByTag -> void
        return;
    }

    protected android.os.Parcelable onSaveInstanceState() {
        // Registers (3 total): v2 = this
        _result = v2.onSaveInstanceState(); // android.widget.TabHost.onSaveInstanceState -> android.os.Parcelable
        v0 = _result;
        v1 = new android.support.v4.app.FragmentTabHost$SavedState;
        _result = v1.<init>(v0); // android.support.v4.app.FragmentTabHost$SavedState.<init> -> void
        _result = v2.getCurrentTabTag(); // android.support.v4.app.FragmentTabHost.getCurrentTabTag -> java.lang.String
        v0 = _result;
        v1.curTab = v0; // android.support.v4.app.FragmentTabHost$SavedState.curTab:java.lang.String
        return v1;
    }

    public void onTabChanged(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.h; // android.support.v4.app.FragmentTabHost.h:boolean
        if (v0 == 0) /* goto L_000e */;
        v0 = 0;
        _result = v1.a(v2, v0); // android.support.v4.app.FragmentTabHost.a -> android.support.v4.app.aj
        v0 = _result;
        if (v0 == 0) /* goto L_000e */;
        _result = v0.b(); // android.support.v4.app.aj.b -> int
        v0 = v1.f; // android.support.v4.app.FragmentTabHost.f:android.widget.TabHost$OnTabChangeListener
        if (v0 == 0) /* goto L_0017 */;
        v0 = v1.f; // android.support.v4.app.FragmentTabHost.f:android.widget.TabHost$OnTabChangeListener
        _result = android.widget.TabHost$OnTabChangeListener.onTabChanged(v0, v2); // -> void
        return;
    }

    public void setOnTabChangedListener(android.widget.TabHost$OnTabChangeListener p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.widget.TabHost$OnTabChangeListener)
        v0.f = v1; // android.support.v4.app.FragmentTabHost.f:android.widget.TabHost$OnTabChangeListener
        return;
    }

    public void setup() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.IllegalStateException;
        v1 = "Must call setup() that takes a Context and FragmentManager";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
    }

    public void setup(android.content.Context p0, android.support.v4.app.w p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.content.Context), v2 = p1 (android.support.v4.app.w)
        _result = v0.a(v1); // android.support.v4.app.FragmentTabHost.a -> void
        _result = v0.setup(); // android.widget.TabHost.setup -> void
        v0.c = v1; // android.support.v4.app.FragmentTabHost.c:android.content.Context
        v0.d = v2; // android.support.v4.app.FragmentTabHost.d:android.support.v4.app.w
        _result = v0.a(); // android.support.v4.app.FragmentTabHost.a -> void
        return;
    }

    public void setup(android.content.Context p0, android.support.v4.app.w p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.content.Context), v4 = p1 (android.support.v4.app.w), v5 = p2 (int)
        _result = v2.a(v3); // android.support.v4.app.FragmentTabHost.a -> void
        _result = v2.setup(); // android.widget.TabHost.setup -> void
        v2.c = v3; // android.support.v4.app.FragmentTabHost.c:android.content.Context
        v2.d = v4; // android.support.v4.app.FragmentTabHost.d:android.support.v4.app.w
        v2.e = v5; // android.support.v4.app.FragmentTabHost.e:int
        _result = v2.a(); // android.support.v4.app.FragmentTabHost.a -> void
        v0 = v2.b; // android.support.v4.app.FragmentTabHost.b:android.widget.FrameLayout
        _result = v0.setId(v5); // android.widget.FrameLayout.setId -> void
        _result = v2.getId(); // android.support.v4.app.FragmentTabHost.getId -> int
        v0 = _result;
        v1 = -1;
        if (v0 != v1) /* goto L_0021 */;
        v0 = 16908306; // 0x01020012
        _result = v2.setId(v0); // android.support.v4.app.FragmentTabHost.setId -> void
        return;
    }

}