package android.support.v4.widget;

/**
 * Original SourceFile: SlidingPaneLayout.java
 * Descriptor: Landroid/support/v4/widget/al;
 */
class al extends android.support.v4.widget.aj {
    al() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.widget.aj.<init> -> void
        return;
    }

    public void a(android.support.v4.widget.SlidingPaneLayout p0, android.view.View p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.support.v4.widget.SlidingPaneLayout), v3 = p1 (android.view.View)
        _result = v3.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        v0 = v0.d; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.d:android.graphics.Paint
        _result = v3.a(v0); // android.support.v4.view.at.a -> void
        return;
    }

}