package android.support.v4.widget;

/**
 * Original SourceFile: ScrollerCompat.java
 * Descriptor: Landroid/support/v4/widget/t;
 */
public class t {
    static final android.support.v4.widget.u b;
     java.lang.Object a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.widget.x;
        _result = v0.<init>(); // android.support.v4.widget.x.<init> -> void
        android.support.v4.widget.t.b = v0; // :android.support.v4.widget.u
        return;
        v1 = 9;
        if (v0 < v1) /* goto L_001a */;
        v0 = new android.support.v4.widget.w;
        _result = v0.<init>(); // android.support.v4.widget.w.<init> -> void
        android.support.v4.widget.t.b = v0; // :android.support.v4.widget.u
        // goto L_000d
        v0 = new android.support.v4.widget.v;
        _result = v0.<init>(); // android.support.v4.widget.v.<init> -> void
        android.support.v4.widget.t.b = v0; // :android.support.v4.widget.u
        // goto L_000d
    }

    t(android.content.Context p0, android.view.animation.Interpolator p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.view.animation.Interpolator)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = android.support.v4.widget.t.b; // :android.support.v4.widget.u
        _result = android.support.v4.widget.u.a(v0, v2, v3); // -> java.lang.Object
        v0 = _result;
        v1.a = v0; // android.support.v4.widget.t.a:java.lang.Object
        return;
    }

    public static android.support.v4.widget.t a(android.content.Context p0, android.view.animation.Interpolator p1) {
        // Registers (3 total): v1 = p0 (android.content.Context), v2 = p1 (android.view.animation.Interpolator)
        v0 = new android.support.v4.widget.t;
        _result = v0.<init>(v1, v2); // android.support.v4.widget.t.<init> -> void
        return v0;
    }

    public void a(int p0, int p1, int p2, int p3, int p4) {
        // Registers (13 total): v7 = this, v8 = p0 (int), v9 = p1 (int), v10 = p2 (int), v11 = p3 (int), v12 = p4 (int)
        v0 = android.support.v4.widget.t.b; // :android.support.v4.widget.u
        v1 = v7.a; // android.support.v4.widget.t.a:java.lang.Object
        v2 = v8;
        v3 = v9;
        v4 = v10;
        v5 = v11;
        v6 = v12;
        _result = android.support.v4.widget.u.a(v0..v6); // -> void
        return;
    }

    public boolean a() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.t.b; // :android.support.v4.widget.u
        v1 = v2.a; // android.support.v4.widget.t.a:java.lang.Object
        _result = android.support.v4.widget.u.a(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public int b() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.t.b; // :android.support.v4.widget.u
        v1 = v2.a; // android.support.v4.widget.t.a:java.lang.Object
        _result = android.support.v4.widget.u.b(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int c() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.t.b; // :android.support.v4.widget.u
        v1 = v2.a; // android.support.v4.widget.t.a:java.lang.Object
        _result = android.support.v4.widget.u.c(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int d() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.t.b; // :android.support.v4.widget.u
        v1 = v2.a; // android.support.v4.widget.t.a:java.lang.Object
        _result = android.support.v4.widget.u.f(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public int e() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.t.b; // :android.support.v4.widget.u
        v1 = v2.a; // android.support.v4.widget.t.a:java.lang.Object
        _result = android.support.v4.widget.u.g(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public boolean f() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.t.b; // :android.support.v4.widget.u
        v1 = v2.a; // android.support.v4.widget.t.a:java.lang.Object
        _result = android.support.v4.widget.u.d(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public void g() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.t.b; // :android.support.v4.widget.u
        v1 = v2.a; // android.support.v4.widget.t.a:java.lang.Object
        _result = android.support.v4.widget.u.e(v0, v1); // -> void
        return;
    }

}