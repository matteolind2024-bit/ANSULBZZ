package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeProviderCompat.java
 * Descriptor: Landroid/support/v4/view/a/n;
 */
class n implements android.support.v4.view.a.t {
    final android.support.v4.view.a.k a;
    final android.support.v4.view.a.m b;

    n(android.support.v4.view.a.m p0, android.support.v4.view.a.k p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.view.a.m), v2 = p1 (android.support.v4.view.a.k)
        v0.b = v1; // android.support.v4.view.a.n.b:android.support.v4.view.a.m
        v0.a = v2; // android.support.v4.view.a.n.a:android.support.v4.view.a.k
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.lang.Object a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // android.support.v4.view.a.n.a:android.support.v4.view.a.k
        _result = v0.a(v2); // android.support.v4.view.a.k.a -> android.support.v4.view.a.a
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v0 = 0;
        return v0;
        _result = v0.a(); // android.support.v4.view.a.a.a -> java.lang.Object
        v0 = _result;
        // goto L_0009
    }

    public java.util.List a(java.lang.String p0, int p1) {
        // Registers (8 total): v5 = this, v6 = p0 (java.lang.String), v7 = p1 (int)
        v0 = v5.a; // android.support.v4.view.a.n.a:android.support.v4.view.a.k
        _result = v0.a(v6, v7); // android.support.v4.view.a.k.a -> java.util.List
        v2 = _result;
        v3 = new java.util.ArrayList;
        _result = v3.<init>(); // java.util.ArrayList.<init> -> void
        _result = java.util.List.size(v2); // -> int
        v4 = _result;
        v0 = 0;
        v1 = v0;
        if (v1 >= v4) /* goto L_0024 */;
        _result = java.util.List.get(v2, v1); // -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.view.a.a) v0;
        _result = v0.a(); // android.support.v4.view.a.a.a -> java.lang.Object
        v0 = _result;
        _result = java.util.List.add(v3, v0); // -> boolean
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0011
        return v3;
    }

    public boolean a(int p0, int p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (int), v4 = p2 (android.os.Bundle)
        v0 = v1.a; // android.support.v4.view.a.n.a:android.support.v4.view.a.k
        _result = v0.a(v2, v3, v4); // android.support.v4.view.a.k.a -> boolean
        v0 = _result;
        return v0;
    }

}