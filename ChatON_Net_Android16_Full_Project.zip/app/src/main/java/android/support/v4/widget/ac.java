package android.support.v4.widget;

/**
 * Original SourceFile: SlidingPaneLayout.java
 * Descriptor: Landroid/support/v4/widget/ac;
 */
class ac {
}