package android.support.v4.c;

/**
 * Original SourceFile: MapCollections.java
 * Descriptor: Landroid/support/v4/c/l;
 */
final class l implements java.util.Collection {
    final android.support.v4.c.g a;

    l(android.support.v4.c.g p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.c.g)
        v0.a = v1; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean add(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public boolean addAll(java.util.Collection p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.Collection)
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public void clear() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v0.c(); // android.support.v4.c.g.c -> void
        return;
    }

    public boolean contains(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = v1.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v0.b(v2); // android.support.v4.c.g.b -> int
        v0 = _result;
        if (v0 < 0) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public boolean containsAll(java.util.Collection p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.util.Collection)
        _result = java.util.Collection.iterator(v3); // -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0016 */;
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v1 = _result;
        _result = v2.contains(v1); // android.support.v4.c.l.contains -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0004 */;
        v0 = 0;
        return v0;
        v0 = 1;
        // goto L_0015
    }

    public boolean isEmpty() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v0.a(); // android.support.v4.c.g.a -> int
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.util.Iterator iterator() {
        // Registers (4 total): v3 = this
        v0 = new android.support.v4.c.h;
        v1 = v3.a; // android.support.v4.c.l.a:android.support.v4.c.g
        v2 = 1;
        _result = v0.<init>(v1, v2); // android.support.v4.c.h.<init> -> void
        return v0;
    }

    public boolean remove(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v0 = v2.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v0.b(v3); // android.support.v4.c.g.b -> int
        v0 = _result;
        if (v0 < 0) /* goto L_000f */;
        v1 = v2.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v1.a(v0); // android.support.v4.c.g.a -> void
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000e
    }

    public boolean removeAll(java.util.Collection p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.util.Collection)
        v2 = 1;
        v0 = 0;
        v1 = v5.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v1.a(); // android.support.v4.c.g.a -> int
        v3 = _result;
        v1 = v0;
        if (v0 >= v3) /* goto L_0025 */;
        v4 = v5.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v4.a(v0, v2); // android.support.v4.c.g.a -> java.lang.Object
        v4 = _result;
        _result = java.util.Collection.contains(v6, v4); // -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_0022 */;
        v1 = v5.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v1.a(v0); // android.support.v4.c.g.a -> void
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = binOpLit8_0xd8(v3, -1);
        v3 = v1;
        v1 = v2;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0009
        return v1;
    }

    public boolean retainAll(java.util.Collection p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.util.Collection)
        v2 = 1;
        v0 = 0;
        v1 = v5.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v1.a(); // android.support.v4.c.g.a -> int
        v3 = _result;
        v1 = v0;
        if (v0 >= v3) /* goto L_0025 */;
        v4 = v5.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v4.a(v0, v2); // android.support.v4.c.g.a -> java.lang.Object
        v4 = _result;
        _result = java.util.Collection.contains(v6, v4); // -> boolean
        v4 = _result;
        if (v4 != 0) /* goto L_0022 */;
        v1 = v5.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v1.a(v0); // android.support.v4.c.g.a -> void
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = binOpLit8_0xd8(v3, -1);
        v3 = v1;
        v1 = v2;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0009
        return v1;
    }

    public int size() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.l.a:android.support.v4.c.g
        _result = v0.a(); // android.support.v4.c.g.a -> int
        v0 = _result;
        return v0;
    }

    public java.lang.Object[] toArray() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // android.support.v4.c.l.a:android.support.v4.c.g
        v1 = 1;
        _result = v0.b(v1); // android.support.v4.c.g.b -> java.lang.Object[]
        v0 = _result;
        return v0;
    }

    public java.lang.Object[] toArray(java.lang.Object[] p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object[])
        v0 = v2.a; // android.support.v4.c.l.a:android.support.v4.c.g
        v1 = 1;
        _result = v0.a(v3, v1); // android.support.v4.c.g.a -> java.lang.Object[]
        v0 = _result;
        return v0;
    }

}