package android.support.v4.widget;

/**
 * Original SourceFile: CursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/e;
 */
class e extends android.database.ContentObserver {
    final android.support.v4.widget.c a;

    public e(android.support.v4.widget.c p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.widget.c)
        v1.a = v2; // android.support.v4.widget.e.a:android.support.v4.widget.c
        v0 = new android.os.Handler;
        _result = v0.<init>(); // android.os.Handler.<init> -> void
        _result = v1.<init>(v0); // android.database.ContentObserver.<init> -> void
        return;
    }

    public boolean deliverSelfNotifications() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public void onChange(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.a; // android.support.v4.widget.e.a:android.support.v4.widget.c
        _result = v0.b(); // android.support.v4.widget.c.b -> void
        return;
    }

}