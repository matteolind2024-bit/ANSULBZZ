package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeInfoCompat.java
 * Descriptor: Landroid/support/v4/view/a/c;
 */
interface c {
    public abstract java.lang.Object a(java.lang.Object p0);
    public abstract void a(java.lang.Object p0, int p1);
    public abstract void a(java.lang.Object p0, android.graphics.Rect p1);
    public abstract void a(java.lang.Object p0, android.view.View p1);
    public abstract void a(java.lang.Object p0, java.lang.CharSequence p1);
    public abstract void a(java.lang.Object p0, boolean p1);
    public abstract int b(java.lang.Object p0);
    public abstract void b(java.lang.Object p0, int p1);
    public abstract void b(java.lang.Object p0, android.graphics.Rect p1);
    public abstract void b(java.lang.Object p0, android.view.View p1);
    public abstract void b(java.lang.Object p0, java.lang.CharSequence p1);
    public abstract void b(java.lang.Object p0, boolean p1);
    public abstract java.lang.CharSequence c(java.lang.Object p0);
    public abstract void c(java.lang.Object p0, android.graphics.Rect p1);
    public abstract void c(java.lang.Object p0, android.view.View p1);
    public abstract void c(java.lang.Object p0, java.lang.CharSequence p1);
    public abstract void c(java.lang.Object p0, boolean p1);
    public abstract java.lang.CharSequence d(java.lang.Object p0);
    public abstract void d(java.lang.Object p0, android.graphics.Rect p1);
    public abstract void d(java.lang.Object p0, boolean p1);
    public abstract java.lang.CharSequence e(java.lang.Object p0);
    public abstract void e(java.lang.Object p0, boolean p1);
    public abstract java.lang.CharSequence f(java.lang.Object p0);
    public abstract void f(java.lang.Object p0, boolean p1);
    public abstract void g(java.lang.Object p0, boolean p1);
    public abstract boolean g(java.lang.Object p0);
    public abstract void h(java.lang.Object p0, boolean p1);
    public abstract boolean h(java.lang.Object p0);
    public abstract void i(java.lang.Object p0, boolean p1);
    public abstract boolean i(java.lang.Object p0);
    public abstract boolean j(java.lang.Object p0);
    public abstract boolean k(java.lang.Object p0);
    public abstract boolean l(java.lang.Object p0);
    public abstract boolean m(java.lang.Object p0);
    public abstract boolean n(java.lang.Object p0);
    public abstract boolean o(java.lang.Object p0);
    public abstract boolean p(java.lang.Object p0);
    public abstract void q(java.lang.Object p0);
    public abstract int r(java.lang.Object p0);
    public abstract boolean s(java.lang.Object p0);
    public abstract boolean t(java.lang.Object p0);
    public abstract java.lang.String u(java.lang.Object p0);
}