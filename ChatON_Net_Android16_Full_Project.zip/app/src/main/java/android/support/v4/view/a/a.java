package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeInfoCompat.java
 * Descriptor: Landroid/support/v4/view/a/a;
 */
public class a {
    private static final android.support.v4.view.a.c a;
    private final java.lang.Object b;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 19;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.a.f;
        _result = v0.<init>(); // android.support.v4.view.a.f.<init> -> void
        android.support.v4.view.a.a.a = v0; // :android.support.v4.view.a.c
        return;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 18;
        if (v0 < v1) /* goto L_001c */;
        v0 = new android.support.v4.view.a.e;
        _result = v0.<init>(); // android.support.v4.view.a.e.<init> -> void
        android.support.v4.view.a.a.a = v0; // :android.support.v4.view.a.c
        // goto L_000d
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_002a */;
        v0 = new android.support.v4.view.a.d;
        _result = v0.<init>(); // android.support.v4.view.a.d.<init> -> void
        android.support.v4.view.a.a.a = v0; // :android.support.v4.view.a.c
        // goto L_000d
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_0038 */;
        v0 = new android.support.v4.view.a.b;
        _result = v0.<init>(); // android.support.v4.view.a.b.<init> -> void
        android.support.v4.view.a.a.a = v0; // :android.support.v4.view.a.c
        // goto L_000d
        v0 = new android.support.v4.view.a.g;
        _result = v0.<init>(); // android.support.v4.view.a.g.<init> -> void
        android.support.v4.view.a.a.a = v0; // :android.support.v4.view.a.c
        // goto L_000d
    }

    public a(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.b = v1; // android.support.v4.view.a.a.b:java.lang.Object
        return;
    }

    public static android.support.v4.view.a.a a(android.support.v4.view.a.a p0) {
        // Registers (3 total): v2 = p0 (android.support.v4.view.a.a)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.a(v0, v1); // -> java.lang.Object
        v0 = _result;
        _result = v0.a(); // android.support.v4.view.a.a.a -> android.support.v4.view.a.a
        v0 = _result;
        return v0;
    }

    static android.support.v4.view.a.a a(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        if (v1 == 0) /* goto L_0008 */;
        v0 = new android.support.v4.view.a.a;
        _result = v0.<init>(v1); // android.support.v4.view.a.a.<init> -> void
        return v0;
        v0 = 0;
        // goto L_0007
    }

    private static java.lang.String c(int p0) {
        // Registers (2 total): v1 = p0 (int)
        // switch(v1)
        v0 = "ACTION_UNKNOWN";
        return v0;
        v0 = "ACTION_FOCUS";
        // goto L_0006
        v0 = "ACTION_CLEAR_FOCUS";
        // goto L_0006
        v0 = "ACTION_SELECT";
        // goto L_0006
        v0 = "ACTION_CLEAR_SELECTION";
        // goto L_0006
        v0 = "ACTION_CLICK";
        // goto L_0006
        v0 = "ACTION_LONG_CLICK";
        // goto L_0006
        v0 = "ACTION_ACCESSIBILITY_FOCUS";
        // goto L_0006
        v0 = "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
        // goto L_0006
        v0 = "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
        // goto L_0006
        v0 = "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
        // goto L_0006
        v0 = "ACTION_NEXT_HTML_ELEMENT";
        // goto L_0006
        v0 = "ACTION_PREVIOUS_HTML_ELEMENT";
        // goto L_0006
        v0 = "ACTION_SCROLL_FORWARD";
        // goto L_0006
        v0 = "ACTION_SCROLL_BACKWARD";
        // goto L_0006
        v0 = "ACTION_CUT";
        // goto L_0006
        v0 = "ACTION_COPY";
        // goto L_0006
        v0 = "ACTION_PASTE";
        // goto L_0006
        v0 = "ACTION_SET_SELECTION";
        // goto L_0006
    }

    public java.lang.Object a() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.view.a.a.b:java.lang.Object
        return v0;
    }

    public void a(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.a(v0, v1, v3); // -> void
        return;
    }

    public void a(android.graphics.Rect p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Rect)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.a(v0, v1, v3); // -> void
        return;
    }

    public void a(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.c(v0, v1, v3); // -> void
        return;
    }

    public void a(java.lang.CharSequence p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.CharSequence)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.c(v0, v1, v3); // -> void
        return;
    }

    public void a(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.c(v0, v1, v3); // -> void
        return;
    }

    public int b() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.b(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public void b(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.b(v0, v1, v3); // -> void
        return;
    }

    public void b(android.graphics.Rect p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Rect)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.c(v0, v1, v3); // -> void
        return;
    }

    public void b(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.a(v0, v1, v3); // -> void
        return;
    }

    public void b(java.lang.CharSequence p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.CharSequence)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.a(v0, v1, v3); // -> void
        return;
    }

    public void b(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.d(v0, v1, v3); // -> void
        return;
    }

    public int c() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.r(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public void c(android.graphics.Rect p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Rect)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.b(v0, v1, v3); // -> void
        return;
    }

    public void c(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.b(v0, v1, v3); // -> void
        return;
    }

    public void c(java.lang.CharSequence p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.CharSequence)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.b(v0, v1, v3); // -> void
        return;
    }

    public void c(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.h(v0, v1, v3); // -> void
        return;
    }

    public void d(android.graphics.Rect p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Rect)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.d(v0, v1, v3); // -> void
        return;
    }

    public void d(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.i(v0, v1, v3); // -> void
        return;
    }

    public boolean d() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.g(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public void e(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.g(v0, v1, v3); // -> void
        return;
    }

    public boolean e() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.h(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        if (v5 != 0) /* goto L_0009 */;
        v0 = v1;
        // goto L_0004
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0015 */;
        v0 = v1;
        // goto L_0004
        v5 = (android.support.v4.view.a.a) v5;
        v2 = v4.b; // android.support.v4.view.a.a.b:java.lang.Object
        if (v2 != 0) /* goto L_0021 */;
        v2 = v5.b; // android.support.v4.view.a.a.b:java.lang.Object
        if (v2 == 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v4.b; // android.support.v4.view.a.a.b:java.lang.Object
        v3 = v5.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public void f(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.a(v0, v1, v3); // -> void
        return;
    }

    public boolean f() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.k(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public void g(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.e(v0, v1, v3); // -> void
        return;
    }

    public boolean g() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.l(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public void h(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.b(v0, v1, v3); // -> void
        return;
    }

    public boolean h() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.s(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public int hashCode() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.view.a.a.b:java.lang.Object
        if (v0 != 0) /* goto L_0006 */;
        v0 = 0;
        return v0;
        v0 = v1.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        // goto L_0005
    }

    public void i(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.f(v0, v1, v3); // -> void
        return;
    }

    public boolean i() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.t(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean j() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.p(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean k() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.i(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean l() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.m(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean m() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.j(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean n() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.n(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean o() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.o(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence p() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.e(v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence q() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.c(v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence r() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.f(v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public java.lang.CharSequence s() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.d(v0, v1); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public void t() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.q(v0, v1); // -> void
        return;
    }

    public java.lang.String toString() {
        // Registers (5 total): v4 = this
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v4.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = new android.graphics.Rect;
        _result = v0.<init>(); // android.graphics.Rect.<init> -> void
        _result = v4.a(v0); // android.support.v4.view.a.a.a -> void
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "; boundsInParent: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.c(v0); // android.support.v4.view.a.a.c -> void
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "; boundsInScreen: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; packageName: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.p(); // android.support.v4.view.a.a.p -> java.lang.CharSequence
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; className: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.q(); // android.support.v4.view.a.a.q -> java.lang.CharSequence
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; text: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.r(); // android.support.v4.view.a.a.r -> java.lang.CharSequence
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; contentDescription: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.s(); // android.support.v4.view.a.a.s -> java.lang.CharSequence
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; viewId: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.u(); // android.support.v4.view.a.a.u -> java.lang.String
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; checkable: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.d(); // android.support.v4.view.a.a.d -> boolean
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; checked: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.e(); // android.support.v4.view.a.a.e -> boolean
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; focusable: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.f(); // android.support.v4.view.a.a.f -> boolean
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; focused: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.g(); // android.support.v4.view.a.a.g -> boolean
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; selected: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.j(); // android.support.v4.view.a.a.j -> boolean
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; clickable: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.k(); // android.support.v4.view.a.a.k -> boolean
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; longClickable: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.l(); // android.support.v4.view.a.a.l -> boolean
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; enabled: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.m(); // android.support.v4.view.a.a.m -> boolean
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; password: ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.n(); // android.support.v4.view.a.a.n -> boolean
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "; scrollable: ";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.o(); // android.support.v4.view.a.a.o -> boolean
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = "; [";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.b(); // android.support.v4.view.a.a.b -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0149 */;
        v2 = 1;
        _result = v0.numberOfTrailingZeros(); // java.lang.Integer.numberOfTrailingZeros -> int
        v3 = _result;
        v2 = binOp2addr_0xb8(v2, v3);
        v3 = binOpLit8_0xdf(v2, -1);
        v0 = binOp2addr_0xb5(v0, v3);
        _result = v2.c(); // android.support.v4.view.a.a.c -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        if (v0 == 0) /* goto L_012e */;
        v2 = ", ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_012e
        v0 = "]";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String u() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.view.a.a.a; // :android.support.v4.view.a.c
        v1 = v2.b; // android.support.v4.view.a.a.b:java.lang.Object
        _result = android.support.v4.view.a.c.u(v0, v1); // -> java.lang.String
        v0 = _result;
        return v0;
    }

}