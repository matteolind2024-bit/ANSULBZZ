package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompat.java
 * Descriptor: Landroid/support/v4/view/bp;
 */
class bp extends android.support.v4.view.bt {
    bp() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.bt.<init> -> void
        return;
    }

    public void a(android.view.ViewGroup p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.ViewGroup), v2 = p1 (boolean)
        _result = v1.a(v2); // android.support.v4.view.bu.a -> void
        return;
    }

}