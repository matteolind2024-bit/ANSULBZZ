package android.support.v4.view;

/**
 * Original SourceFile: ViewCompatEclairMr1.java
 * Descriptor: Landroid/support/v4/view/bd;
 */
class bd {
    public static boolean a(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        _result = v1.isOpaque(); // android.view.View.isOpaque -> boolean
        v0 = _result;
        return v0;
    }

}