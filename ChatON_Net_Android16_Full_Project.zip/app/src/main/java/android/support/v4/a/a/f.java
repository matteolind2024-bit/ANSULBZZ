package android.support.v4.a.a;

/**
 * Original SourceFile: DrawableCompatKitKat.java
 * Descriptor: Landroid/support/v4/a/a/f;
 */
class f {
    public static void a(android.graphics.drawable.Drawable p0, boolean p1) {
        // Registers (2 total): v0 = p0 (android.graphics.drawable.Drawable), v1 = p1 (boolean)
        _result = v0.setAutoMirrored(v1); // android.graphics.drawable.Drawable.setAutoMirrored -> void
        return;
    }

    public static boolean a(android.graphics.drawable.Drawable p0) {
        // Registers (2 total): v1 = p0 (android.graphics.drawable.Drawable)
        _result = v1.isAutoMirrored(); // android.graphics.drawable.Drawable.isAutoMirrored -> boolean
        v0 = _result;
        return v0;
    }

}