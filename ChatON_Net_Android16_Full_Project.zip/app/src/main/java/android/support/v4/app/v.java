package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/v;
 */
interface v {
    public abstract android.view.View a(int p0);
}