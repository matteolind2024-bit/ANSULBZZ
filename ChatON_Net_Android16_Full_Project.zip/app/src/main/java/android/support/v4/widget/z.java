package android.support.v4.widget;

/**
 * Original SourceFile: SimpleCursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/z;
 */
public class z extends android.support.v4.widget.s {
    protected int[] j;
    protected int[] k;
     java.lang.String[] l;
    private int m;
    private android.support.v4.widget.aa n;
    private android.support.v4.widget.ab o;

    public z(android.content.Context p0, int p1, android.database.Cursor p2, java.lang.String[] p3, int[] p4) {
        // Registers (7 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (int), v4 = p2 (android.database.Cursor), v5 = p3 (java.lang.String[]), v6 = p4 (int[])
        _result = v1.<init>(v2, v3, v4); // android.support.v4.widget.s.<init> -> void
        v0 = -1;
        v1.m = v0; // android.support.v4.widget.z.m:int
        v1.k = v6; // android.support.v4.widget.z.k:int[]
        v1.l = v5; // android.support.v4.widget.z.l:java.lang.String[]
        _result = v1.a(v5); // android.support.v4.widget.z.a -> void
        return;
    }

    public z(android.content.Context p0, int p1, android.database.Cursor p2, java.lang.String[] p3, int[] p4, int p5) {
        // Registers (8 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (int), v4 = p2 (android.database.Cursor), v5 = p3 (java.lang.String[]), v6 = p4 (int[]), v7 = p5 (int)
        _result = v1.<init>(v2, v3, v4, v7); // android.support.v4.widget.s.<init> -> void
        v0 = -1;
        v1.m = v0; // android.support.v4.widget.z.m:int
        v1.k = v6; // android.support.v4.widget.z.k:int[]
        v1.l = v5; // android.support.v4.widget.z.l:java.lang.String[]
        _result = v1.a(v5); // android.support.v4.widget.z.a -> void
        return;
    }

    private void a(java.lang.String[] p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.String[])
        v0 = v5.c; // android.support.v4.widget.z.c:android.database.Cursor
        if (v0 == 0) /* goto L_0024 */;
        v1 = v6.length;
        v0 = v5.j; // android.support.v4.widget.z.j:int[]
        if (v0 == 0) /* goto L_000e */;
        v0 = v5.j; // android.support.v4.widget.z.j:int[]
        v0 = v0.length;
        if (v0 == v1) /* goto L_0012 */;
        v0 = new int[][size=v1];
        v5.j = v0; // android.support.v4.widget.z.j:int[]
        v0 = 0;
        if (v0 >= v1) /* goto L_0027 */;
        v2 = v5.j; // android.support.v4.widget.z.j:int[]
        v3 = v5.c; // android.support.v4.widget.z.c:android.database.Cursor
        v4 = v6[v0];
        _result = android.database.Cursor.getColumnIndexOrThrow(v3, v4); // -> int
        v3 = _result;
        v2[v0] = v3;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0013
        v0 = 0;
        v5.j = v0; // android.support.v4.widget.z.j:int[]
        return;
    }

    public void a(android.view.View p0, android.content.Context p1, android.database.Cursor p2) {
        // Registers (13 total): v9 = this, v10 = p0 (android.view.View), v11 = p1 (android.content.Context), v12 = p2 (android.database.Cursor)
        v2 = 0;
        v4 = v9.o; // android.support.v4.widget.z.o:android.support.v4.widget.ab
        v0 = v9.k; // android.support.v4.widget.z.k:int[]
        v5 = v0.length;
        v6 = v9.j; // android.support.v4.widget.z.j:int[]
        v7 = v9.k; // android.support.v4.widget.z.k:int[]
        v3 = v2;
        if (v3 >= v5) /* goto L_006a */;
        v0 = v7[v3];
        _result = v10.findViewById(v0); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0033 */;
        if (v4 == 0) /* goto L_006b */;
        v1 = v6[v3];
        _result = android.support.v4.widget.ab.a(v4, v0, v12, v1); // -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0033 */;
        v1 = v6[v3];
        _result = android.database.Cursor.getString(v12, v1); // -> java.lang.String
        v1 = _result;
        if (v1 != 0) /* goto L_002a */;
        v1 = "";
        v8 = (v0 instanceof android.widget.TextView);
        if (v8 == 0) /* goto L_0037 */;
        v0 = (android.widget.TextView) v0;
        _result = v9.a(v0, v1); // android.support.v4.widget.z.a -> void
        v0 = binOpLit8_0xd8(v3, 1);
        v3 = v0;
        // goto L_000b
        v8 = (v0 instanceof android.widget.ImageView);
        if (v8 == 0) /* goto L_0041 */;
        v0 = (android.widget.ImageView) v0;
        _result = v9.a(v0, v1); // android.support.v4.widget.z.a -> void
        // goto L_0033
        v1 = new java.lang.IllegalStateException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getName(); // java.lang.Class.getName -> java.lang.String
        v0 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = " is not a ";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = " view that can be bounds by this SimpleCursorAdapter";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.IllegalStateException.<init> -> void
        throw v1;
        return;
        v1 = v2;
        // goto L_001d
    }

    public void a(android.widget.ImageView p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.widget.ImageView), v3 = p1 (java.lang.String)
        _result = v3.parseInt(); // java.lang.Integer.parseInt -> int
        v0 = _result;
        _result = v2.setImageResource(v0); // android.widget.ImageView.setImageResource -> void
        return;
        v0 = _exception;
        _result = v3.parse(); // android.net.Uri.parse -> android.net.Uri
        v0 = _result;
        _result = v2.setImageURI(v0); // android.widget.ImageView.setImageURI -> void
        // goto L_0007
    }

    public void a(android.widget.TextView p0, java.lang.String p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.widget.TextView), v2 = p1 (java.lang.String)
        _result = v1.setText(v2); // android.widget.TextView.setText -> void
        return;
    }

    public android.database.Cursor b(android.database.Cursor p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.database.Cursor)
        _result = v2.b(v3); // android.support.v4.widget.s.b -> android.database.Cursor
        v0 = _result;
        v1 = v2.l; // android.support.v4.widget.z.l:java.lang.String[]
        _result = v2.a(v1); // android.support.v4.widget.z.a -> void
        return v0;
    }

    public java.lang.CharSequence c(android.database.Cursor p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.database.Cursor)
        v0 = v2.n; // android.support.v4.widget.z.n:android.support.v4.widget.aa
        if (v0 == 0) /* goto L_000b */;
        v0 = v2.n; // android.support.v4.widget.z.n:android.support.v4.widget.aa
        _result = android.support.v4.widget.aa.a(v0, v3); // -> java.lang.CharSequence
        v0 = _result;
        return v0;
        v0 = v2.m; // android.support.v4.widget.z.m:int
        v1 = -1;
        if (v0 <= v1) /* goto L_0017 */;
        v0 = v2.m; // android.support.v4.widget.z.m:int
        _result = android.database.Cursor.getString(v3, v0); // -> java.lang.String
        v0 = _result;
        // goto L_000a
        _result = v2.c(v3); // android.support.v4.widget.s.c -> java.lang.CharSequence
        v0 = _result;
        // goto L_000a
    }

}