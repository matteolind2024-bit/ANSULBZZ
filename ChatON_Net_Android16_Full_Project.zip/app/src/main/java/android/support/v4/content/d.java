package android.support.v4.content;

/**
 * Original SourceFile: FileProvider.java
 * Descriptor: Landroid/support/v4/content/d;
 */
interface d {
    public abstract android.net.Uri a(java.io.File p0);
    public abstract java.io.File a(android.net.Uri p0);
}