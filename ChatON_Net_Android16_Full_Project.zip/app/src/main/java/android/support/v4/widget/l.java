package android.support.v4.widget;

/**
 * Original SourceFile: DrawerLayout.java
 * Descriptor: Landroid/support/v4/widget/l;
 */
class l extends android.support.v4.widget.ap {
    final android.support.v4.widget.DrawerLayout a;
    private final int b;
    private android.support.v4.widget.am c;
    private final java.lang.Runnable d;

    public l(android.support.v4.widget.DrawerLayout p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.support.v4.widget.DrawerLayout), v3 = p1 (int)
        v1.a = v2; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v1.<init>(); // android.support.v4.widget.ap.<init> -> void
        v0 = new android.support.v4.widget.m;
        _result = v0.<init>(v1); // android.support.v4.widget.m.<init> -> void
        v1.d = v0; // android.support.v4.widget.l.d:java.lang.Runnable
        v1.b = v3; // android.support.v4.widget.l.b:int
        return;
    }

    static void a(android.support.v4.widget.l p0) {
        // Registers (1 total): v0 = p0 (android.support.v4.widget.l)
        _result = v0.c(); // android.support.v4.widget.l.c -> void
        return;
    }

    private void b() {
        // Registers (3 total): v2 = this
        v0 = 3;
        v1 = v2.b; // android.support.v4.widget.l.b:int
        if (v1 != v0) /* goto L_0006 */;
        v0 = 5;
        v1 = v2.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v1.a(v0); // android.support.v4.widget.DrawerLayout.a -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0013 */;
        v1 = v2.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v1.i(v0); // android.support.v4.widget.DrawerLayout.i -> void
        return;
    }

    private void c() {
        // Registers (7 total): v6 = this
        v5 = 3;
        v4 = 1;
        v0 = 0;
        v1 = v6.c; // android.support.v4.widget.l.c:android.support.v4.widget.am
        _result = v1.b(); // android.support.v4.widget.am.b -> int
        v2 = _result;
        v1 = v6.b; // android.support.v4.widget.l.b:int
        if (v1 != v5) /* goto L_0059 */;
        v3 = v4;
        if (v3 == 0) /* goto L_005b */;
        v1 = v6.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v1.a(v5); // android.support.v4.widget.DrawerLayout.a -> android.view.View
        v1 = _result;
        if (v1 == 0) /* goto L_001d */;
        _result = v1.getWidth(); // android.view.View.getWidth -> int
        v0 = _result;
        v0 = unaryOp_0x7b(v0);
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = v1;
        v1 = v0;
        if (v2 == 0) /* goto L_0058 */;
        if (v3 == 0) /* goto L_002a */;
        _result = v2.getLeft(); // android.view.View.getLeft -> int
        v0 = _result;
        if (v0 < v1) /* goto L_0032 */;
        if (v3 != 0) /* goto L_0058 */;
        _result = v2.getLeft(); // android.view.View.getLeft -> int
        v0 = _result;
        if (v0 <= v1) /* goto L_0058 */;
        v0 = v6.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v0.a(v2); // android.support.v4.widget.DrawerLayout.a -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0058 */;
        _result = v2.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v3 = v6.c; // android.support.v4.widget.l.c:android.support.v4.widget.am
        _result = v2.getTop(); // android.view.View.getTop -> int
        v5 = _result;
        _result = v3.a(v2, v1, v5); // android.support.v4.widget.am.a -> boolean
        v0.c = v4; // android.support.v4.widget.DrawerLayout$LayoutParams.c:boolean
        v0 = v6.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v0.invalidate(); // android.support.v4.widget.DrawerLayout.invalidate -> void
        _result = v6.b(); // android.support.v4.widget.l.b -> void
        v0 = v6.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v0.c(); // android.support.v4.widget.DrawerLayout.c -> void
        return;
        v3 = v0;
        // goto L_000e
        v0 = v6.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        v1 = 5;
        _result = v0.a(v1); // android.support.v4.widget.DrawerLayout.a -> android.view.View
        v1 = _result;
        v0 = v6.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v0.getWidth(); // android.support.v4.widget.DrawerLayout.getWidth -> int
        v0 = _result;
        v0 = binOp2addr_0xb1(v0, v2);
        v2 = v1;
        v1 = v0;
        // goto L_0020
    }

    public int a(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.getWidth(); // android.view.View.getWidth -> int
        v0 = _result;
        return v0;
    }

    public int a(android.view.View p0, int p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int), v5 = p2 (int)
        v0 = v2.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        v1 = 3;
        _result = v0.a(v3, v1); // android.support.v4.widget.DrawerLayout.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0018 */;
        _result = v3.getWidth(); // android.view.View.getWidth -> int
        v0 = _result;
        v0 = unaryOp_0x7b(v0);
        v1 = 0;
        _result = v4.min(v1); // java.lang.Math.min -> int
        v1 = _result;
        _result = v0.max(v1); // java.lang.Math.max -> int
        v0 = _result;
        return v0;
        v0 = v2.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v0.getWidth(); // android.support.v4.widget.DrawerLayout.getWidth -> int
        v0 = _result;
        _result = v3.getWidth(); // android.view.View.getWidth -> int
        v1 = _result;
        v1 = binOp_0x91(v0, v1);
        _result = v4.min(v0); // java.lang.Math.min -> int
        v0 = _result;
        _result = v1.max(v0); // java.lang.Math.max -> int
        v0 = _result;
        // goto L_0017
    }

    public void a() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        v1 = v2.d; // android.support.v4.widget.l.d:java.lang.Runnable
        _result = v0.removeCallbacks(v1); // android.support.v4.widget.DrawerLayout.removeCallbacks -> boolean
        return;
    }

    public void a(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        v1 = v3.b; // android.support.v4.widget.l.b:int
        v2 = v3.c; // android.support.v4.widget.l.c:android.support.v4.widget.am
        _result = v2.c(); // android.support.v4.widget.am.c -> android.view.View
        v2 = _result;
        _result = v0.a(v1, v4, v2); // android.support.v4.widget.DrawerLayout.a -> void
        return;
    }

    public void a(int p0, int p1) {
        // Registers (7 total): v4 = this, v5 = p0 (int), v6 = p1 (int)
        v0 = v4.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        v1 = v4.d; // android.support.v4.widget.l.d:java.lang.Runnable
        v2 = 160L;
        _result = v0.postDelayed(v1, v2, v3); // android.support.v4.widget.DrawerLayout.postDelayed -> boolean
        return;
    }

    public void a(android.support.v4.widget.am p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.am)
        v0.c = v1; // android.support.v4.widget.l.c:android.support.v4.widget.am
        return;
    }

    public void a(android.view.View p0, float p1, float p2) {
        // Registers (10 total): v6 = this, v7 = p0 (android.view.View), v8 = p1 (float), v9 = p2 (float)
        v5 = 0x3f000000;
        v4 = 0;
        v0 = v6.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v0.d(v7); // android.support.v4.widget.DrawerLayout.d -> float
        v1 = _result;
        _result = v7.getWidth(); // android.view.View.getWidth -> int
        v2 = _result;
        v0 = v6.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        v3 = 3;
        _result = v0.a(v7, v3); // android.support.v4.widget.DrawerLayout.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0034 */;
        v0 = cmp(v8, v4);
        if (v0 > 0) /* goto L_0022 */;
        v0 = cmp(v8, v4);
        if (v0 != 0) /* goto L_0032 */;
        v0 = cmp(v1, v5);
        if (v0 <= 0) /* goto L_0032 */;
        v0 = 0;
        v1 = v6.c; // android.support.v4.widget.l.c:android.support.v4.widget.am
        _result = v7.getTop(); // android.view.View.getTop -> int
        v2 = _result;
        _result = v1.a(v0, v2); // android.support.v4.widget.am.a -> boolean
        v0 = v6.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v0.invalidate(); // android.support.v4.widget.DrawerLayout.invalidate -> void
        return;
        v0 = unaryOp_0x7b(v2);
        // goto L_0023
        v0 = v6.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v0.getWidth(); // android.support.v4.widget.DrawerLayout.getWidth -> int
        v0 = _result;
        v3 = cmp(v8, v4);
        if (v3 < 0) /* goto L_0046 */;
        v3 = cmp(v8, v4);
        if (v3 != 0) /* goto L_0023 */;
        v1 = cmp(v1, v5);
        if (v1 <= 0) /* goto L_0023 */;
        v0 = binOp2addr_0xb1(v0, v2);
        // goto L_0023
    }

    public void a(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (9 total): v3 = this, v4 = p0 (android.view.View), v5 = p1 (int), v6 = p2 (int), v7 = p3 (int), v8 = p4 (int)
        _result = v4.getWidth(); // android.view.View.getWidth -> int
        v0 = _result;
        v1 = v3.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        v2 = 3;
        _result = v1.a(v4, v2); // android.support.v4.widget.DrawerLayout.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0027 */;
        v1 = binOp_0x90(v0, v5);
        v1 = unaryOp_0x82(v1);
        v0 = unaryOp_0x82(v0);
        v0 = binOp_0xa9(v1, v0);
        v1 = v3.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v1.b(v4, v0); // android.support.v4.widget.DrawerLayout.b -> void
        v1 = 0;
        v0 = cmp(v0, v1);
        if (v0 != 0) /* goto L_0033 */;
        v0 = 4;
        _result = v4.setVisibility(v0); // android.view.View.setVisibility -> void
        v0 = v3.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v0.invalidate(); // android.support.v4.widget.DrawerLayout.invalidate -> void
        return;
        v1 = v3.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v1.getWidth(); // android.support.v4.widget.DrawerLayout.getWidth -> int
        v1 = _result;
        v1 = binOp2addr_0xb1(v1, v5);
        v1 = unaryOp_0x82(v1);
        v0 = unaryOp_0x82(v0);
        v0 = binOp_0xa9(v1, v0);
        // goto L_0013
        v0 = 0;
        // goto L_001e
    }

    public boolean a(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = v2.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v0.g(v3); // android.support.v4.widget.DrawerLayout.g -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001c */;
        v0 = v2.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        v1 = v2.b; // android.support.v4.widget.l.b:int
        _result = v0.a(v3, v1); // android.support.v4.widget.DrawerLayout.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001c */;
        v0 = v2.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v0.a(v3); // android.support.v4.widget.DrawerLayout.a -> int
        v0 = _result;
        if (v0 != 0) /* goto L_001c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_001b
    }

    public int b(android.view.View p0, int p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int), v4 = p2 (int)
        _result = v2.getTop(); // android.view.View.getTop -> int
        v0 = _result;
        return v0;
    }

    public void b(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v0 = binOpLit8_0xdd(v3, 1);
        v1 = 1;
        if (v0 != v1) /* goto L_001c */;
        v0 = v2.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        v1 = 3;
        _result = v0.a(v1); // android.support.v4.widget.DrawerLayout.a -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_001b */;
        v1 = v2.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        _result = v1.a(v0); // android.support.v4.widget.DrawerLayout.a -> int
        v1 = _result;
        if (v1 != 0) /* goto L_001b */;
        v1 = v2.c; // android.support.v4.widget.l.c:android.support.v4.widget.am
        _result = v1.a(v0, v4); // android.support.v4.widget.am.a -> void
        return;
        v0 = v2.a; // android.support.v4.widget.l.a:android.support.v4.widget.DrawerLayout
        v1 = 5;
        _result = v0.a(v1); // android.support.v4.widget.DrawerLayout.a -> android.view.View
        v0 = _result;
        // goto L_000c
    }

    public void b(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        _result = v3.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.DrawerLayout$LayoutParams) v0;
        v1 = 0;
        v0.c = v1; // android.support.v4.widget.DrawerLayout$LayoutParams.c:boolean
        _result = v2.b(); // android.support.v4.widget.l.b -> void
        return;
    }

    public boolean b(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

}