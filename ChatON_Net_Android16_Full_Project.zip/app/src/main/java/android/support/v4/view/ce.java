package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ce;
 */
class ce extends android.database.DataSetObserver {
    final android.support.v4.view.ViewPager a;

    private ce(android.support.v4.view.ViewPager p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.ViewPager)
        v0.a = v1; // android.support.v4.view.ce.a:android.support.v4.view.ViewPager
        _result = v0.<init>(); // android.database.DataSetObserver.<init> -> void
        return;
    }

    ce(android.support.v4.view.ViewPager p0, android.support.v4.view.bv p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.view.ViewPager), v2 = p1 (android.support.v4.view.bv)
        _result = v0.<init>(v1); // android.support.v4.view.ce.<init> -> void
        return;
    }

    public void onChanged() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.view.ce.a:android.support.v4.view.ViewPager
        _result = v0.d(); // android.support.v4.view.ViewPager.d -> void
        return;
    }

    public void onInvalidated() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.view.ce.a:android.support.v4.view.ViewPager
        _result = v0.d(); // android.support.v4.view.ViewPager.d -> void
        return;
    }

}