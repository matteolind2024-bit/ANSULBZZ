package android.support.v4.app;

/**
 * Original SourceFile: ActionBarHookActivity.java
 * Descriptor: Landroid/support/v4/app/ActionBarHookActivity;
 */
public class ActionBarHookActivity extends android.support.v4.app.FragmentActivity {
    private com.sec.common.actionbar.t n;

    public ActionBarHookActivity() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.app.FragmentActivity.<init> -> void
        return;
    }

    public boolean onCreatePanelMenu(int p0, android.view.Menu p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (android.view.Menu)
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 >= v1) /* goto L_0021 */;
        if (v4 != 0) /* goto L_0021 */;
        _result = v3.onCreateOptionsMenu(v5); // android.support.v4.app.ActionBarHookActivity.onCreateOptionsMenu -> boolean
        v1 = _result;
        v0 = (v5 instanceof com.sec.common.actionbar.t);
        if (v0 == 0) /* goto L_0026 */;
        v0 = v5;
        v0 = (com.sec.common.actionbar.t) v0;
        v3.n = v0; // android.support.v4.app.ActionBarHookActivity.n:com.sec.common.actionbar.t
        v0 = v3.b; // android.support.v4.app.ActionBarHookActivity.b:android.support.v4.app.y
        _result = v3.getMenuInflater(); // android.support.v4.app.ActionBarHookActivity.getMenuInflater -> android.view.MenuInflater
        v2 = _result;
        _result = v0.a(v5, v2); // android.support.v4.app.y.a -> boolean
        v0 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        return v0;
        _result = v3.onCreatePanelMenu(v4, v5); // android.support.v4.app.FragmentActivity.onCreatePanelMenu -> boolean
        v0 = _result;
        // goto L_0020
        v0 = v1;
        // goto L_0020
    }

    public boolean onPreparePanel(int p0, android.view.View p1, android.view.Menu p2) {
        // Registers (7 total): v3 = this, v4 = p0 (int), v5 = p1 (android.view.View), v6 = p2 (android.view.Menu)
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 >= v1) /* goto L_0023 */;
        if (v4 != 0) /* goto L_0023 */;
        v0 = v3.n; // android.support.v4.app.ActionBarHookActivity.n:com.sec.common.actionbar.t
        _result = v3.onPrepareOptionsMenu(v0); // android.support.v4.app.ActionBarHookActivity.onPrepareOptionsMenu -> boolean
        v0 = _result;
        v1 = v3.b; // android.support.v4.app.ActionBarHookActivity.b:android.support.v4.app.y
        v2 = v3.n; // android.support.v4.app.ActionBarHookActivity.n:com.sec.common.actionbar.t
        _result = v1.a(v2); // android.support.v4.app.y.a -> boolean
        v1 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        if (v0 == 0) /* goto L_0021 */;
        _result = android.view.Menu.hasVisibleItems(v6); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0020
        _result = v3.onPreparePanel(v4, v5, v6); // android.support.v4.app.FragmentActivity.onPreparePanel -> boolean
        v0 = _result;
        // goto L_0020
    }

}