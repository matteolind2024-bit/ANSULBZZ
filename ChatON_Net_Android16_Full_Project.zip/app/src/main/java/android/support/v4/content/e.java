package android.support.v4.content;

/**
 * Original SourceFile: FileProvider.java
 * Descriptor: Landroid/support/v4/content/e;
 */
class e implements android.support.v4.content.d {
    private final java.lang.String a;
    private final java.util.HashMap b;

    public e(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        v1.b = v0; // android.support.v4.content.e.b:java.util.HashMap
        v1.a = v2; // android.support.v4.content.e.a:java.lang.String
        return;
    }

    public android.net.Uri a(java.io.File p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.io.File)
        _result = v7.getCanonicalPath(); // java.io.File.getCanonicalPath -> java.lang.String
        v3 = _result;
        v2 = 0;
        v0 = v6.b; // android.support.v4.content.e.b:java.util.HashMap
        _result = v0.entrySet(); // java.util.HashMap.entrySet -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v4 = _result;
        _result = java.util.Iterator.hasNext(v4); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_005e */;
        _result = java.util.Iterator.next(v4); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = java.util.Map$Entry.getValue(v0); // -> java.lang.Object
        v1 = _result;
        v1 = (java.io.File) v1;
        _result = v1.getPath(); // java.io.File.getPath -> java.lang.String
        v1 = _result;
        _result = v3.startsWith(v1); // java.lang.String.startsWith -> boolean
        v5 = _result;
        if (v5 == 0) /* goto L_00e5 */;
        if (v2 == 0) /* goto L_0041 */;
        _result = v1.length(); // java.lang.String.length -> int
        v5 = _result;
        _result = java.util.Map$Entry.getValue(v2); // -> java.lang.Object
        v1 = _result;
        v1 = (java.io.File) v1;
        _result = v1.getPath(); // java.io.File.getPath -> java.lang.String
        v1 = _result;
        _result = v1.length(); // java.lang.String.length -> int
        v1 = _result;
        if (v5 <= v1) /* goto L_00e5 */;
        v2 = v0;
        // goto L_000f
        v0 = _exception;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Failed to resolve canonical path for ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        if (v2 != 0) /* goto L_007a */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Failed to find configured root that contains ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = java.util.Map$Entry.getValue(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.io.File) v0;
        _result = v0.getPath(); // java.io.File.getPath -> java.lang.String
        v0 = _result;
        v1 = "/";
        _result = v0.endsWith(v1); // java.lang.String.endsWith -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_00d9 */;
        _result = v0.length(); // java.lang.String.length -> int
        v0 = _result;
        _result = v3.substring(v0); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        v1 = v0;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = java.util.Map$Entry.getKey(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        _result = v0.encode(); // android.net.Uri.encode -> java.lang.String
        v0 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = 47;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = "/";
        _result = v1.encode(v2); // android.net.Uri.encode -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = new android.net.Uri$Builder;
        _result = v1.<init>(); // android.net.Uri$Builder.<init> -> void
        v2 = "content";
        _result = v1.scheme(v2); // android.net.Uri$Builder.scheme -> android.net.Uri$Builder
        v1 = _result;
        v2 = v6.a; // android.support.v4.content.e.a:java.lang.String
        _result = v1.authority(v2); // android.net.Uri$Builder.authority -> android.net.Uri$Builder
        v1 = _result;
        _result = v1.encodedPath(v0); // android.net.Uri$Builder.encodedPath -> android.net.Uri$Builder
        v0 = _result;
        _result = v0.build(); // android.net.Uri$Builder.build -> android.net.Uri
        v0 = _result;
        return v0;
        _result = v0.length(); // java.lang.String.length -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, 1);
        _result = v3.substring(v0); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        v1 = v0;
        // goto L_0096
        v0 = v2;
        // goto L_0041
    }

    public java.io.File a(android.net.Uri p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.net.Uri)
        v2 = 1;
        _result = v5.getEncodedPath(); // android.net.Uri.getEncodedPath -> java.lang.String
        v0 = _result;
        v1 = 47;
        _result = v0.indexOf(v1, v2); // java.lang.String.indexOf -> int
        v1 = _result;
        _result = v0.substring(v2, v1); // java.lang.String.substring -> java.lang.String
        v2 = _result;
        _result = v2.decode(); // android.net.Uri.decode -> java.lang.String
        v2 = _result;
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v0.substring(v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        _result = v0.decode(); // android.net.Uri.decode -> java.lang.String
        v1 = _result;
        v0 = v4.b; // android.support.v4.content.e.b:java.util.HashMap
        _result = v0.get(v2); // java.util.HashMap.get -> java.lang.Object
        v0 = _result;
        v0 = (java.io.File) v0;
        if (v0 != 0) /* goto L_0041 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Unable to find configured root for ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v2 = new java.io.File;
        _result = v2.<init>(v0, v1); // java.io.File.<init> -> void
        _result = v2.getCanonicalFile(); // java.io.File.getCanonicalFile -> java.io.File
        v1 = _result;
        _result = v1.getPath(); // java.io.File.getPath -> java.lang.String
        v2 = _result;
        _result = v0.getPath(); // java.io.File.getPath -> java.lang.String
        v0 = _result;
        _result = v2.startsWith(v0); // java.lang.String.startsWith -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_007c */;
        v0 = new java.lang.SecurityException;
        v1 = "Resolved path jumped beyond configured root";
        _result = v0.<init>(v1); // java.lang.SecurityException.<init> -> void
        throw v0;
        v0 = _exception;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Failed to resolve canonical path for ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        return v1;
    }

    public void a(java.lang.String p0, java.io.File p1) {
        // Registers (7 total): v4 = this, v5 = p0 (java.lang.String), v6 = p1 (java.io.File)
        _result = v5.isEmpty(); // android.text.TextUtils.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000f */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Name must not be empty";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = v6.getCanonicalFile(); // java.io.File.getCanonicalFile -> java.io.File
        v0 = _result;
        v1 = v4.b; // android.support.v4.content.e.b:java.util.HashMap
        _result = v1.put(v5, v0); // java.util.HashMap.put -> java.lang.Object
        return;
        v0 = _exception;
        v1 = new java.lang.IllegalArgumentException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Failed to resolve canonical path for ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v1;
    }

}