package android.support.v4.app;

/**
 * Original SourceFile: Fragment.java
 * Descriptor: Landroid/support/v4/app/o;
 */
class o implements android.support.v4.app.v {
    final android.support.v4.app.Fragment a;

    o(android.support.v4.app.Fragment p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.Fragment)
        v0.a = v1; // android.support.v4.app.o.a:android.support.v4.app.Fragment
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.view.View a(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.a; // android.support.v4.app.o.a:android.support.v4.app.Fragment
        v0 = v0.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 != 0) /* goto L_000f */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Fragment does not have a view";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v2.a; // android.support.v4.app.o.a:android.support.v4.app.Fragment
        v0 = v0.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.findViewById(v3); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        return v0;
    }

}