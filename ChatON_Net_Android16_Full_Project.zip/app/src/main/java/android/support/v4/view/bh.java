package android.support.v4.view;

/**
 * Original SourceFile: ViewCompatJB.java
 * Descriptor: Landroid/support/v4/view/bh;
 */
class bh {
    public static void a(android.view.View p0) {
        // Registers (1 total): v0 = p0 (android.view.View)
        _result = v0.postInvalidateOnAnimation(); // android.view.View.postInvalidateOnAnimation -> void
        return;
    }

    public static void a(android.view.View p0, int p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (int)
        _result = v0.setImportantForAccessibility(v1); // android.view.View.setImportantForAccessibility -> void
        return;
    }

    public static void a(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (5 total): v0 = p0 (android.view.View), v1 = p1 (int), v2 = p2 (int), v3 = p3 (int), v4 = p4 (int)
        _result = v0.postInvalidate(v1, v2, v3, v4); // android.view.View.postInvalidate -> void
        return;
    }

    public static void a(android.view.View p0, java.lang.Runnable p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (java.lang.Runnable)
        _result = v0.postOnAnimation(v1); // android.view.View.postOnAnimation -> void
        return;
    }

    public static int b(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        _result = v1.getImportantForAccessibility(); // android.view.View.getImportantForAccessibility -> int
        v0 = _result;
        return v0;
    }

    public static android.view.ViewParent c(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        _result = v1.getParentForAccessibility(); // android.view.View.getParentForAccessibility -> android.view.ViewParent
        v0 = _result;
        return v0;
    }

}