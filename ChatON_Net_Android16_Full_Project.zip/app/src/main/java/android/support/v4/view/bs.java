package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompat.java
 * Descriptor: Landroid/support/v4/view/bs;
 */
class bs extends android.support.v4.view.bq {
    bs() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.bq.<init> -> void
        return;
    }

}