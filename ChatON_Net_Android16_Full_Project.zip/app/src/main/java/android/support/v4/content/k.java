package android.support.v4.content;

/**
 * Original SourceFile: LocalBroadcastManager.java
 * Descriptor: Landroid/support/v4/content/k;
 */
class k {
    final android.content.Intent a;
    final java.util.ArrayList b;

    k(android.content.Intent p0, java.util.ArrayList p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.content.Intent), v2 = p1 (java.util.ArrayList)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // android.support.v4.content.k.a:android.content.Intent
        v0.b = v2; // android.support.v4.content.k.b:java.util.ArrayList
        return;
    }

}