package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityRecordCompat.java
 * Descriptor: Landroid/support/v4/view/a/aa;
 */
interface aa {
    public abstract java.lang.Object a();
    public abstract void a(java.lang.Object p0, int p1);
    public abstract void a(java.lang.Object p0, boolean p1);
    public abstract void b(java.lang.Object p0, int p1);
    public abstract void c(java.lang.Object p0, int p1);
}