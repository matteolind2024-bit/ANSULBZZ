package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityRecordCompat.java
 * Descriptor: Landroid/support/v4/view/a/y;
 */
class y extends android.support.v4.view.a.ac {
    y() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.a.ac.<init> -> void
        return;
    }

    public java.lang.Object a() {
        // Registers (2 total): v1 = this
        _result = this.a(); // android.support.v4.view.a.ad.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void a(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.a(v2); // android.support.v4.view.a.ad.a -> void
        return;
    }

    public void a(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.a(v2); // android.support.v4.view.a.ad.a -> void
        return;
    }

    public void b(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.b(v2); // android.support.v4.view.a.ad.b -> void
        return;
    }

    public void c(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.c(v2); // android.support.v4.view.a.ad.c -> void
        return;
    }

}