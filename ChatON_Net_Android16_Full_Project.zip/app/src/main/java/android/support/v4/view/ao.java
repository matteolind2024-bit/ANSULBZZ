package android.support.v4.view;

/**
 * Original SourceFile: VelocityTrackerCompat.java
 * Descriptor: Landroid/support/v4/view/ao;
 */
public class ao {
    static final android.support.v4.view.ar a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.aq;
        _result = v0.<init>(); // android.support.v4.view.aq.<init> -> void
        android.support.v4.view.ao.a = v0; // :android.support.v4.view.ar
        return;
        v0 = new android.support.v4.view.ap;
        _result = v0.<init>(); // android.support.v4.view.ap.<init> -> void
        android.support.v4.view.ao.a = v0; // :android.support.v4.view.ar
        // goto L_000d
    }

    public static float a(android.view.VelocityTracker p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.VelocityTracker), v2 = p1 (int)
        v0 = android.support.v4.view.ao.a; // :android.support.v4.view.ar
        _result = android.support.v4.view.ar.a(v0, v1, v2); // -> float
        v0 = _result;
        return v0;
    }

    public static float b(android.view.VelocityTracker p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.VelocityTracker), v2 = p1 (int)
        v0 = android.support.v4.view.ao.a; // :android.support.v4.view.ar
        _result = android.support.v4.view.ar.b(v0, v1, v2); // -> float
        v0 = _result;
        return v0;
    }

}