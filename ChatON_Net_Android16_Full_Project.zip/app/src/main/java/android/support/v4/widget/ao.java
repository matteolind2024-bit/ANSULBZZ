package android.support.v4.widget;

/**
 * Original SourceFile: ViewDragHelper.java
 * Descriptor: Landroid/support/v4/widget/ao;
 */
class ao implements java.lang.Runnable {
    final android.support.v4.widget.am a;

    ao(android.support.v4.widget.am p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.am)
        v0.a = v1; // android.support.v4.widget.ao.a:android.support.v4.widget.am
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // android.support.v4.widget.ao.a:android.support.v4.widget.am
        v1 = 0;
        _result = v0.c(v1); // android.support.v4.widget.am.c -> void
        return;
    }

}