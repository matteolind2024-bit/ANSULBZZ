package android.support.v4.c;

/**
 * Original SourceFile: MapCollections.java
 * Descriptor: Landroid/support/v4/c/g;
 */
abstract class g {
     android.support.v4.c.i b;
     android.support.v4.c.j c;
     android.support.v4.c.l d;

    g() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static boolean a(java.util.Map p0, java.util.Collection p1) {
        // Registers (4 total): v2 = p0 (java.util.Map), v3 = p1 (java.util.Collection)
        _result = java.util.Collection.iterator(v3); // -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0016 */;
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v1 = _result;
        _result = java.util.Map.containsKey(v2, v1); // -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0004 */;
        v0 = 0;
        return v0;
        v0 = 1;
        // goto L_0015
    }

    public static boolean a(java.util.Set p0, java.lang.Object p1) {
        // Registers (6 total): v4 = p0 (java.util.Set), v5 = p1 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0006 */;
        v1 = v0;
        return v1;
        v2 = (v5 instanceof java.util.Set);
        if (v2 == 0) /* goto L_0005 */;
        v5 = (java.util.Set) v5;
        _result = java.util.Set.size(v4); // -> int
        v2 = _result;
        _result = java.util.Set.size(v5); // -> int
        v3 = _result;
        if (v2 != v3) /* goto L_001e */;
        _result = java.util.Set.containsAll(v4, v5); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_001e */;
        v1 = v0;
        // goto L_0005
        v0 = v1;
        // goto L_001c
        v0 = _exception;
        // goto L_0005
        v0 = _exception;
        // goto L_0005
    }

    public static boolean b(java.util.Map p0, java.util.Collection p1) {
        // Registers (5 total): v3 = p0 (java.util.Map), v4 = p1 (java.util.Collection)
        _result = java.util.Map.size(v3); // -> int
        v0 = _result;
        _result = java.util.Collection.iterator(v4); // -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0016 */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v2 = _result;
        _result = java.util.Map.remove(v3, v2); // -> java.lang.Object
        // goto L_0008
        _result = java.util.Map.size(v3); // -> int
        v1 = _result;
        if (v0 == v1) /* goto L_001e */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_001d
    }

    public static boolean c(java.util.Map p0, java.util.Collection p1) {
        // Registers (5 total): v3 = p0 (java.util.Map), v4 = p1 (java.util.Collection)
        _result = java.util.Map.size(v3); // -> int
        v0 = _result;
        _result = java.util.Map.keySet(v3); // -> java.util.Set
        v1 = _result;
        _result = java.util.Set.iterator(v1); // -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0020 */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v2 = _result;
        _result = java.util.Collection.contains(v4, v2); // -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_000c */;
        _result = java.util.Iterator.remove(v1); // -> void
        // goto L_000c
        _result = java.util.Map.size(v3); // -> int
        v1 = _result;
        if (v0 == v1) /* goto L_0028 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0027
    }

    protected abstract int a();
    protected abstract int a(java.lang.Object p0);
    protected abstract java.lang.Object a(int p0, int p1);
    protected abstract java.lang.Object a(int p0, java.lang.Object p1);
    protected abstract void a(int p0);
    protected abstract void a(java.lang.Object p0, java.lang.Object p1);
    public java.lang.Object[] a(java.lang.Object[] p0, int p1) {
        // Registers (7 total): v4 = this, v5 = p0 (java.lang.Object[]), v6 = p1 (int)
        _result = v4.a(); // android.support.v4.c.g.a -> int
        v2 = _result;
        v0 = v5.length;
        if (v0 >= v2) /* goto L_002a */;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getComponentType(); // java.lang.Class.getComponentType -> java.lang.Class
        v0 = _result;
        _result = v0.newInstance(v2); // java.lang.reflect.Array.newInstance -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Object[]) v0;
        v0 = (java.lang.Object[]) v0;
        v1 = 0;
        if (v1 >= v2) /* goto L_0023 */;
        _result = v4.a(v1, v6); // android.support.v4.c.g.a -> java.lang.Object
        v3 = _result;
        v0[v1] = v3;
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0018
        v1 = v0.length;
        if (v1 <= v2) /* goto L_0029 */;
        v1 = 0;
        v0[v2] = v1;
        return v0;
        v0 = v5;
        // goto L_0017
    }

    protected abstract int b(java.lang.Object p0);
    protected abstract java.util.Map b();
    public java.lang.Object[] b(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        _result = v4.a(); // android.support.v4.c.g.a -> int
        v1 = _result;
        v2 = new java.lang.Object[][size=v1];
        v0 = 0;
        if (v0 >= v1) /* goto L_0012 */;
        _result = v4.a(v0, v5); // android.support.v4.c.g.a -> java.lang.Object
        v3 = _result;
        v2[v0] = v3;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0007
        return v2;
    }

    protected abstract void c();
    public java.util.Set d() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.c.g.b:android.support.v4.c.i
        if (v0 != 0) /* goto L_000b */;
        v0 = new android.support.v4.c.i;
        _result = v0.<init>(v1); // android.support.v4.c.i.<init> -> void
        v1.b = v0; // android.support.v4.c.g.b:android.support.v4.c.i
        v0 = v1.b; // android.support.v4.c.g.b:android.support.v4.c.i
        return v0;
    }

    public java.util.Set e() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // android.support.v4.c.g.c:android.support.v4.c.j
        if (v0 != 0) /* goto L_000b */;
        v0 = new android.support.v4.c.j;
        _result = v0.<init>(v1); // android.support.v4.c.j.<init> -> void
        v1.c = v0; // android.support.v4.c.g.c:android.support.v4.c.j
        v0 = v1.c; // android.support.v4.c.g.c:android.support.v4.c.j
        return v0;
    }

    public java.util.Collection f() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // android.support.v4.c.g.d:android.support.v4.c.l
        if (v0 != 0) /* goto L_000b */;
        v0 = new android.support.v4.c.l;
        _result = v0.<init>(v1); // android.support.v4.c.l.<init> -> void
        v1.d = v0; // android.support.v4.c.g.d:android.support.v4.c.l
        v0 = v1.d; // android.support.v4.c.g.d:android.support.v4.c.l
        return v0;
    }

}