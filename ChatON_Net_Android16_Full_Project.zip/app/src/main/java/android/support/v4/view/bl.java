package android.support.v4.view;

/**
 * Original SourceFile: ViewConfigurationCompat.java
 * Descriptor: Landroid/support/v4/view/bl;
 */
class bl implements android.support.v4.view.bm {
    bl() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int a(android.view.ViewConfiguration p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewConfiguration)
        _result = v2.a(); // android.support.v4.view.bn.a -> int
        v0 = _result;
        return v0;
    }

}