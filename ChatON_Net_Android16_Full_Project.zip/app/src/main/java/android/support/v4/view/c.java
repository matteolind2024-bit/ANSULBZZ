package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompat.java
 * Descriptor: Landroid/support/v4/view/c;
 */
class c implements android.support.v4.view.j {
    final android.support.v4.view.a a;
    final android.support.v4.view.b b;

    c(android.support.v4.view.b p0, android.support.v4.view.a p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.view.b), v2 = p1 (android.support.v4.view.a)
        v0.b = v1; // android.support.v4.view.c.b:android.support.v4.view.b
        v0.a = v2; // android.support.v4.view.c.a:android.support.v4.view.a
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void a(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        v0 = v1.a; // android.support.v4.view.c.a:android.support.v4.view.a
        _result = v0.a(v2, v3); // android.support.v4.view.a.a -> void
        return;
    }

    public void a(android.view.View p0, java.lang.Object p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (java.lang.Object)
        v0 = v2.a; // android.support.v4.view.c.a:android.support.v4.view.a
        v1 = new android.support.v4.view.a.a;
        _result = v1.<init>(v4); // android.support.v4.view.a.a.<init> -> void
        _result = v0.a(v3, v1); // android.support.v4.view.a.a -> void
        return;
    }

    public boolean a(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.a; // android.support.v4.view.c.a:android.support.v4.view.a
        _result = v0.b(v2, v3); // android.support.v4.view.a.b -> boolean
        v0 = _result;
        return v0;
    }

    public boolean a(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (android.view.View), v4 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.a; // android.support.v4.view.c.a:android.support.v4.view.a
        _result = v0.a(v2, v3, v4); // android.support.v4.view.a.a -> boolean
        v0 = _result;
        return v0;
    }

    public void b(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.a; // android.support.v4.view.c.a:android.support.v4.view.a
        _result = v0.d(v2, v3); // android.support.v4.view.a.d -> void
        return;
    }

    public void c(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.a; // android.support.v4.view.c.a:android.support.v4.view.a
        _result = v0.c(v2, v3); // android.support.v4.view.a.c -> void
        return;
    }

    public void d(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.a; // android.support.v4.view.c.a:android.support.v4.view.a
        _result = v0.a(v2, v3); // android.support.v4.view.a.a -> void
        return;
    }

}