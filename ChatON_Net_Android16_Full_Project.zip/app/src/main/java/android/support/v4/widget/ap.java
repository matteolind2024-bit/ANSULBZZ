package android.support.v4.widget;

/**
 * Original SourceFile: ViewDragHelper.java
 * Descriptor: Landroid/support/v4/widget/ap;
 */
public abstract class ap {
    public ap() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int a(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 0;
        return v0;
    }

    public int a(android.view.View p0, int p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int), v4 = p2 (int)
        v0 = 0;
        return v0;
    }

    public void a(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        return;
    }

    public void a(int p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (int), v2 = p1 (int)
        return;
    }

    public void a(android.view.View p0, float p1, float p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (float), v3 = p2 (float)
        return;
    }

    public void a(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (6 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int), v3 = p2 (int), v4 = p3 (int), v5 = p4 (int)
        return;
    }

    public abstract boolean a(android.view.View p0, int p1);
    public int b(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 0;
        return v0;
    }

    public int b(android.view.View p0, int p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int), v4 = p2 (int)
        v0 = 0;
        return v0;
    }

    public void b(int p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (int), v2 = p1 (int)
        return;
    }

    public void b(android.view.View p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int)
        return;
    }

    public boolean b(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public int c(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        return v1;
    }

}