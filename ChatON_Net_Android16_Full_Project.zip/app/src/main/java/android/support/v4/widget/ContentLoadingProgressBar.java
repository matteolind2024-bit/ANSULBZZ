package android.support.v4.widget;

/**
 * Original SourceFile: ContentLoadingProgressBar.java
 * Descriptor: Landroid/support/v4/widget/ContentLoadingProgressBar;
 */
public class ContentLoadingProgressBar extends android.widget.ProgressBar {
    private long a;
    private boolean b;
    private boolean c;
    private boolean d;
    private final java.lang.Runnable e;
    private final java.lang.Runnable f;

    public ContentLoadingProgressBar(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        v0 = 0;
        _result = v1.<init>(v2, v0); // android.support.v4.widget.ContentLoadingProgressBar.<init> -> void
        return;
    }

    public ContentLoadingProgressBar(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.util.AttributeSet)
        v2 = 0;
        _result = v3.<init>(v4, v5, v2); // android.widget.ProgressBar.<init> -> void
        v0 = -1L;
        v3.a = v0; // android.support.v4.widget.ContentLoadingProgressBar.a:long
        v3.b = v2; // android.support.v4.widget.ContentLoadingProgressBar.b:boolean
        v3.c = v2; // android.support.v4.widget.ContentLoadingProgressBar.c:boolean
        v3.d = v2; // android.support.v4.widget.ContentLoadingProgressBar.d:boolean
        v0 = new android.support.v4.widget.a;
        _result = v0.<init>(v3); // android.support.v4.widget.a.<init> -> void
        v3.e = v0; // android.support.v4.widget.ContentLoadingProgressBar.e:java.lang.Runnable
        v0 = new android.support.v4.widget.b;
        _result = v0.<init>(v3); // android.support.v4.widget.b.<init> -> void
        v3.f = v0; // android.support.v4.widget.ContentLoadingProgressBar.f:java.lang.Runnable
        return;
    }

    static long a(android.support.v4.widget.ContentLoadingProgressBar p0, long p1) {
        // Registers (3 total): v0 = p0 (android.support.v4.widget.ContentLoadingProgressBar), v1 = p1 (long)
        v0.a = v1; // android.support.v4.widget.ContentLoadingProgressBar.a:long
        return v1;
    }

    private void a() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // android.support.v4.widget.ContentLoadingProgressBar.e:java.lang.Runnable
        _result = v1.removeCallbacks(v0); // android.support.v4.widget.ContentLoadingProgressBar.removeCallbacks -> boolean
        v0 = v1.f; // android.support.v4.widget.ContentLoadingProgressBar.f:java.lang.Runnable
        _result = v1.removeCallbacks(v0); // android.support.v4.widget.ContentLoadingProgressBar.removeCallbacks -> boolean
        return;
    }

    static boolean a(android.support.v4.widget.ContentLoadingProgressBar p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.widget.ContentLoadingProgressBar)
        v0 = v1.d; // android.support.v4.widget.ContentLoadingProgressBar.d:boolean
        return v0;
    }

    static boolean a(android.support.v4.widget.ContentLoadingProgressBar p0, boolean p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.widget.ContentLoadingProgressBar), v1 = p1 (boolean)
        v0.b = v1; // android.support.v4.widget.ContentLoadingProgressBar.b:boolean
        return v1;
    }

    static boolean b(android.support.v4.widget.ContentLoadingProgressBar p0, boolean p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.widget.ContentLoadingProgressBar), v1 = p1 (boolean)
        v0.c = v1; // android.support.v4.widget.ContentLoadingProgressBar.c:boolean
        return v1;
    }

    public void onAttachedToWindow() {
        // Registers (1 total): v0 = this
        _result = v0.onAttachedToWindow(); // android.widget.ProgressBar.onAttachedToWindow -> void
        _result = v0.a(); // android.support.v4.widget.ContentLoadingProgressBar.a -> void
        return;
    }

    public void onDetachedFromWindow() {
        // Registers (1 total): v0 = this
        _result = v0.onDetachedFromWindow(); // android.widget.ProgressBar.onDetachedFromWindow -> void
        _result = v0.a(); // android.support.v4.widget.ContentLoadingProgressBar.a -> void
        return;
    }

}