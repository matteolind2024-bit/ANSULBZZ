package android.support.v4.widget;

/**
 * Original SourceFile: SlidingPaneLayout.java
 * Descriptor: Landroid/support/v4/widget/af;
 */
class af extends android.support.v4.widget.ap {
    final android.support.v4.widget.SlidingPaneLayout a;

    private af(android.support.v4.widget.SlidingPaneLayout p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.SlidingPaneLayout)
        v0.a = v1; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v0.<init>(); // android.support.v4.widget.ap.<init> -> void
        return;
    }

    af(android.support.v4.widget.SlidingPaneLayout p0, android.support.v4.widget.ac p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.widget.SlidingPaneLayout), v2 = p1 (android.support.v4.widget.ac)
        _result = v0.<init>(v1); // android.support.v4.widget.af.<init> -> void
        return;
    }

    public int a(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = v1.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v0.e(); // android.support.v4.widget.SlidingPaneLayout.e -> int
        v0 = _result;
        return v0;
    }

    public int a(android.view.View p0, int p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int), v5 = p2 (int)
        v0 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v0.d(); // android.support.v4.widget.SlidingPaneLayout.d -> android.view.View
        v0 = _result;
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        v1 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v1.getPaddingLeft(); // android.support.v4.widget.SlidingPaneLayout.getPaddingLeft -> int
        v1 = _result;
        v0 = v0.leftMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.leftMargin:int
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v1.e(); // android.support.v4.widget.SlidingPaneLayout.e -> int
        v1 = _result;
        v1 = binOp2addr_0xb0(v1, v0);
        _result = v4.max(v0); // java.lang.Math.max -> int
        v0 = _result;
        _result = v0.min(v1); // java.lang.Math.min -> int
        v0 = _result;
        return v0;
    }

    public void a(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v0.b(); // android.support.v4.widget.SlidingPaneLayout.b -> android.support.v4.widget.am
        v0 = _result;
        _result = v0.a(); // android.support.v4.widget.am.a -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0033 */;
        v0 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v0.c(); // android.support.v4.widget.SlidingPaneLayout.c -> float
        v0 = _result;
        v1 = 0;
        v0 = cmp(v0, v1);
        if (v0 != 0) /* goto L_0034 */;
        v0 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        v1 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v1.d(); // android.support.v4.widget.SlidingPaneLayout.d -> android.view.View
        v1 = _result;
        _result = v0.d(v1); // android.support.v4.widget.SlidingPaneLayout.d -> void
        v0 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        v1 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v1.d(); // android.support.v4.widget.SlidingPaneLayout.d -> android.view.View
        v1 = _result;
        _result = v0.c(v1); // android.support.v4.widget.SlidingPaneLayout.c -> void
        v0 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        v1 = 0;
        _result = v0.a(v1); // android.support.v4.widget.SlidingPaneLayout.a -> boolean
        return;
        v0 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        v1 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v1.d(); // android.support.v4.widget.SlidingPaneLayout.d -> android.view.View
        v1 = _result;
        _result = v0.b(v1); // android.support.v4.widget.SlidingPaneLayout.b -> void
        v0 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        v1 = 1;
        _result = v0.a(v1); // android.support.v4.widget.SlidingPaneLayout.a -> boolean
        // goto L_0033
    }

    public void a(android.view.View p0, float p1, float p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.view.View), v5 = p1 (float), v6 = p2 (float)
        v2 = 0;
        _result = v4.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        v1 = v3.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v1.getPaddingLeft(); // android.support.v4.widget.SlidingPaneLayout.getPaddingLeft -> int
        v1 = _result;
        v0 = v0.leftMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.leftMargin:int
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = cmp(v5, v2);
        if (v1 > 0) /* goto L_0024 */;
        v1 = cmp(v5, v2);
        if (v1 != 0) /* goto L_002b */;
        v1 = v3.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v1.c(); // android.support.v4.widget.SlidingPaneLayout.c -> float
        v1 = _result;
        v2 = 0x3f000000;
        v1 = cmp(v1, v2);
        if (v1 <= 0) /* goto L_002b */;
        v1 = v3.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v1.e(); // android.support.v4.widget.SlidingPaneLayout.e -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v3.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v1.b(); // android.support.v4.widget.SlidingPaneLayout.b -> android.support.v4.widget.am
        v1 = _result;
        _result = v4.getTop(); // android.view.View.getTop -> int
        v2 = _result;
        _result = v1.a(v0, v2); // android.support.v4.widget.am.a -> boolean
        v0 = v3.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v0.invalidate(); // android.support.v4.widget.SlidingPaneLayout.invalidate -> void
        return;
    }

    public void a(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (7 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int), v4 = p2 (int), v5 = p3 (int), v6 = p4 (int)
        v0 = v1.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v0.a(v3); // android.support.v4.widget.SlidingPaneLayout.a -> void
        v0 = v1.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v0.invalidate(); // android.support.v4.widget.SlidingPaneLayout.invalidate -> void
        return;
    }

    public boolean a(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        v0 = v1.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v0.a(); // android.support.v4.widget.SlidingPaneLayout.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000a */;
        v0 = 0;
        return v0;
        _result = v2.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        v0 = v0.b; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.b:boolean
        // goto L_0009
    }

    public void b(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v0 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v0.b(); // android.support.v4.widget.SlidingPaneLayout.b -> android.support.v4.widget.am
        v0 = _result;
        v1 = v2.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v1.d(); // android.support.v4.widget.SlidingPaneLayout.d -> android.view.View
        v1 = _result;
        _result = v0.a(v1, v4); // android.support.v4.widget.am.a -> void
        return;
    }

    public void b(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        v0 = v1.a; // android.support.v4.widget.af.a:android.support.v4.widget.SlidingPaneLayout
        _result = v0.a(); // android.support.v4.widget.SlidingPaneLayout.a -> void
        return;
    }

}