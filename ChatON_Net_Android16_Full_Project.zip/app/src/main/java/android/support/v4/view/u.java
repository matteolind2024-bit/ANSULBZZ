package android.support.v4.view;

/**
 * Original SourceFile: KeyEventCompat.java
 * Descriptor: Landroid/support/v4/view/u;
 */
class u extends android.support.v4.view.t {
    u() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.t.<init> -> void
        return;
    }

    public void a(android.view.KeyEvent p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.KeyEvent)
        _result = v1.a(); // android.support.v4.view.x.a -> void
        return;
    }

}