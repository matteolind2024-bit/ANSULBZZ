package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/bv;
 */
final class bv implements java.util.Comparator {
    bv() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int a(android.support.v4.view.bz p0, android.support.v4.view.bz p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.support.v4.view.bz), v4 = p1 (android.support.v4.view.bz)
        v0 = v3.b; // android.support.v4.view.bz.b:int
        v1 = v4.b; // android.support.v4.view.bz.b:int
        v0 = binOp2addr_0xb1(v0, v1);
        return v0;
    }

    public int compare(java.lang.Object p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (java.lang.Object)
        v2 = (android.support.v4.view.bz) v2;
        v3 = (android.support.v4.view.bz) v3;
        _result = v1.a(v2, v3); // android.support.v4.view.bv.a -> int
        v0 = _result;
        return v0;
    }

}