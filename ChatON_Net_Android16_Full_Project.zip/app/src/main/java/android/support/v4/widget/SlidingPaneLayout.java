package android.support.v4.widget;

/**
 * Original SourceFile: SlidingPaneLayout.java
 * Descriptor: Landroid/support/v4/widget/SlidingPaneLayout;
 */
public class SlidingPaneLayout extends android.view.ViewGroup {
    static final android.support.v4.widget.ai a;
    private int b;
    private int c;
    private android.graphics.drawable.Drawable d;
    private final int e;
    private boolean f;
    private android.view.View g;
    private float h;
    private float i;
    private int j;
    private boolean k;
    private int l;
    private float m;
    private float n;
    private android.support.v4.widget.ag o;
    private final android.support.v4.widget.am p;
    private boolean q;
    private boolean r;
    private final android.graphics.Rect s;
    private final java.util.ArrayList t;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 17;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.widget.al;
        _result = v0.<init>(); // android.support.v4.widget.al.<init> -> void
        android.support.v4.widget.SlidingPaneLayout.a = v0; // :android.support.v4.widget.ai
        return;
        v1 = 16;
        if (v0 < v1) /* goto L_001a */;
        v0 = new android.support.v4.widget.ak;
        _result = v0.<init>(); // android.support.v4.widget.ak.<init> -> void
        android.support.v4.widget.SlidingPaneLayout.a = v0; // :android.support.v4.widget.ai
        // goto L_000d
        v0 = new android.support.v4.widget.aj;
        _result = v0.<init>(); // android.support.v4.widget.aj.<init> -> void
        android.support.v4.widget.SlidingPaneLayout.a = v0; // :android.support.v4.widget.ai
        // goto L_000d
    }

    public SlidingPaneLayout(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        v0 = 0;
        _result = v1.<init>(v2, v0); // android.support.v4.widget.SlidingPaneLayout.<init> -> void
        return;
    }

    public SlidingPaneLayout(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.util.AttributeSet)
        v0 = 0;
        _result = v1.<init>(v2, v3, v0); // android.support.v4.widget.SlidingPaneLayout.<init> -> void
        return;
    }

    public SlidingPaneLayout(android.content.Context p0, android.util.AttributeSet p1, int p2) {
        // Registers (9 total): v5 = this, v6 = p0 (android.content.Context), v7 = p1 (android.util.AttributeSet), v8 = p2 (int)
        v4 = 0x3f000000;
        v3 = 1;
        _result = v5.<init>(v6, v7, v8); // android.view.ViewGroup.<init> -> void
        v0 = -858993460; // 0xcccccccc
        v5.b = v0; // android.support.v4.widget.SlidingPaneLayout.b:int
        v5.r = v3; // android.support.v4.widget.SlidingPaneLayout.r:boolean
        v0 = new android.graphics.Rect;
        _result = v0.<init>(); // android.graphics.Rect.<init> -> void
        v5.s = v0; // android.support.v4.widget.SlidingPaneLayout.s:android.graphics.Rect
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v5.t = v0; // android.support.v4.widget.SlidingPaneLayout.t:java.util.ArrayList
        _result = v6.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v0 = _result;
        v0 = v0.density; // android.util.DisplayMetrics.density:float
        v1 = 0x42000000;
        v1 = binOp2addr_0xc8(v1, v0);
        v1 = binOp2addr_0xc6(v1, v4);
        v1 = unaryOp_0x87(v1);
        v5.e = v1; // android.support.v4.widget.SlidingPaneLayout.e:int
        _result = v6.get(); // android.view.ViewConfiguration.get -> android.view.ViewConfiguration
        v1 = 0;
        _result = v5.setWillNotDraw(v1); // android.support.v4.widget.SlidingPaneLayout.setWillNotDraw -> void
        v1 = new android.support.v4.widget.ad;
        _result = v1.<init>(v5); // android.support.v4.widget.ad.<init> -> void
        _result = v5.a(v1); // android.support.v4.view.at.a -> void
        _result = v5.b(v3); // android.support.v4.view.at.b -> void
        v1 = new android.support.v4.widget.af;
        v2 = 0;
        _result = v1.<init>(v5, v2); // android.support.v4.widget.af.<init> -> void
        _result = v5.a(v4, v1); // android.support.v4.widget.am.a -> android.support.v4.widget.am
        v1 = _result;
        v5.p = v1; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        v1 = v5.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v1.a(v3); // android.support.v4.widget.am.a -> void
        v1 = v5.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        v2 = 0x43c80000;
        v0 = binOp2addr_0xc8(v0, v2);
        _result = v1.a(v0); // android.support.v4.widget.am.a -> void
        return;
    }

    private void a(float p0) {
        // Registers (10 total): v8 = this, v9 = p0 (float)
        v1 = 0;
        v7 = 0x3f800000;
        v0 = v8.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        v2 = v0.c; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.c:boolean
        if (v2 == 0) /* goto L_0025 */;
        v0 = v0.leftMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.leftMargin:int
        if (v0 > 0) /* goto L_0025 */;
        v0 = 1;
        _result = v8.getChildCount(); // android.support.v4.widget.SlidingPaneLayout.getChildCount -> int
        v2 = _result;
        if (v1 >= v2) /* goto L_0049 */;
        _result = v8.getChildAt(v1); // android.support.v4.widget.SlidingPaneLayout.getChildAt -> android.view.View
        v3 = _result;
        v4 = v8.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        if (v3 != v4) /* goto L_0027 */;
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0018
        v0 = v1;
        // goto L_0014
        v4 = v8.i; // android.support.v4.widget.SlidingPaneLayout.i:float
        v4 = binOp_0xa7(v7, v4);
        v5 = v8.l; // android.support.v4.widget.SlidingPaneLayout.l:int
        v5 = unaryOp_0x82(v5);
        v4 = binOp2addr_0xc8(v4, v5);
        v4 = unaryOp_0x87(v4);
        v8.i = v9; // android.support.v4.widget.SlidingPaneLayout.i:float
        v5 = binOp_0xa7(v7, v9);
        v6 = v8.l; // android.support.v4.widget.SlidingPaneLayout.l:int
        v6 = unaryOp_0x82(v6);
        v5 = binOp2addr_0xc8(v5, v6);
        v5 = unaryOp_0x87(v5);
        v4 = binOp2addr_0xb1(v4, v5);
        _result = v3.offsetLeftAndRight(v4); // android.view.View.offsetLeftAndRight -> void
        if (v0 == 0) /* goto L_0022 */;
        v4 = v8.i; // android.support.v4.widget.SlidingPaneLayout.i:float
        v4 = binOp_0xa7(v7, v4);
        v5 = v8.c; // android.support.v4.widget.SlidingPaneLayout.c:int
        _result = v8.a(v3, v4, v5); // android.support.v4.widget.SlidingPaneLayout.a -> void
        // goto L_0022
        return;
    }

    private void a(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        _result = v3.getPaddingLeft(); // android.support.v4.widget.SlidingPaneLayout.getPaddingLeft -> int
        v1 = _result;
        v2 = v0.leftMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.leftMargin:int
        v1 = binOp2addr_0xb0(v1, v2);
        v1 = binOp_0x91(v4, v1);
        v1 = unaryOp_0x82(v1);
        v2 = v3.j; // android.support.v4.widget.SlidingPaneLayout.j:int
        v2 = unaryOp_0x82(v2);
        v1 = binOp2addr_0xc9(v1, v2);
        v3.h = v1; // android.support.v4.widget.SlidingPaneLayout.h:float
        v1 = v3.l; // android.support.v4.widget.SlidingPaneLayout.l:int
        if (v1 == 0) /* goto L_0021 */;
        v1 = v3.h; // android.support.v4.widget.SlidingPaneLayout.h:float
        _result = v3.a(v1); // android.support.v4.widget.SlidingPaneLayout.a -> void
        v0 = v0.c; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.c:boolean
        if (v0 == 0) /* goto L_002e */;
        v0 = v3.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        v1 = v3.h; // android.support.v4.widget.SlidingPaneLayout.h:float
        v2 = v3.b; // android.support.v4.widget.SlidingPaneLayout.b:int
        _result = v3.a(v0, v1, v2); // android.support.v4.widget.SlidingPaneLayout.a -> void
        v0 = v3.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        _result = v3.a(v0); // android.support.v4.widget.SlidingPaneLayout.a -> void
        return;
    }

    static void a(android.support.v4.widget.SlidingPaneLayout p0, int p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.widget.SlidingPaneLayout), v1 = p1 (int)
        _result = v0.a(v1); // android.support.v4.widget.SlidingPaneLayout.a -> void
        return;
    }

    static void a(android.support.v4.widget.SlidingPaneLayout p0, android.view.View p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.widget.SlidingPaneLayout), v1 = p1 (android.view.View)
        _result = v0.g(v1); // android.support.v4.widget.SlidingPaneLayout.g -> void
        return;
    }

    private void a(android.view.View p0, float p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (android.view.View), v8 = p1 (float), v9 = p2 (int)
        v5 = 2;
        _result = v7.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        v1 = 0;
        v1 = cmp(v8, v1);
        if (v1 <= 0) /* goto L_0043 */;
        if (v9 == 0) /* goto L_0043 */;
        v1 = 0xff000000;
        v1 = binOp2addr_0xb5(v1, v9);
        v1 = binOpLit8_0xe2(v1, 24);
        v1 = unaryOp_0x82(v1);
        v1 = binOp2addr_0xc8(v1, v8);
        v1 = unaryOp_0x87(v1);
        v1 = binOpLit8_0xe0(v1, 24);
        v2 = 16777215; // 0x00ffffff
        v2 = binOp2addr_0xb5(v2, v9);
        v1 = binOp2addr_0xb6(v1, v2);
        v2 = v0.d; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.d:android.graphics.Paint
        if (v2 != 0) /* goto L_0028 */;
        v2 = new android.graphics.Paint;
        _result = v2.<init>(); // android.graphics.Paint.<init> -> void
        v0.d = v2; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.d:android.graphics.Paint
        v2 = v0.d; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.d:android.graphics.Paint
        v3 = new android.graphics.PorterDuffColorFilter;
        v4 = android.graphics.PorterDuff$Mode.SRC_OVER; // :android.graphics.PorterDuff$Mode
        _result = v3.<init>(v1, v4); // android.graphics.PorterDuffColorFilter.<init> -> void
        _result = v2.setColorFilter(v3); // android.graphics.Paint.setColorFilter -> android.graphics.ColorFilter
        _result = v7.d(); // android.support.v4.view.at.d -> int
        v1 = _result;
        if (v1 == v5) /* goto L_003f */;
        v0 = v0.d; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.d:android.graphics.Paint
        _result = v7.a(v5, v0); // android.support.v4.view.at.a -> void
        _result = v6.g(v7); // android.support.v4.widget.SlidingPaneLayout.g -> void
        return;
        _result = v7.d(); // android.support.v4.view.at.d -> int
        v1 = _result;
        if (v1 == 0) /* goto L_0042 */;
        v1 = v0.d; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.d:android.graphics.Paint
        if (v1 == 0) /* goto L_0053 */;
        v0 = v0.d; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.d:android.graphics.Paint
        v1 = 0;
        _result = v0.setColorFilter(v1); // android.graphics.Paint.setColorFilter -> android.graphics.ColorFilter
        v0 = new android.support.v4.widget.ae;
        _result = v0.<init>(v6, v7); // android.support.v4.widget.ae.<init> -> void
        v1 = v6.t; // android.support.v4.widget.SlidingPaneLayout.t:java.util.ArrayList
        _result = v1.add(v0); // java.util.ArrayList.add -> boolean
        _result = v6.a(v0); // android.support.v4.view.at.a -> void
        // goto L_0042
    }

    static boolean a(android.support.v4.widget.SlidingPaneLayout p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.widget.SlidingPaneLayout)
        v0 = v1.k; // android.support.v4.widget.SlidingPaneLayout.k:boolean
        return v0;
    }

    static boolean a(android.support.v4.widget.SlidingPaneLayout p0, boolean p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.widget.SlidingPaneLayout), v1 = p1 (boolean)
        v0.q = v1; // android.support.v4.widget.SlidingPaneLayout.q:boolean
        return v1;
    }

    private boolean a(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = 0;
        v1 = v2.r; // android.support.v4.widget.SlidingPaneLayout.r:boolean
        if (v1 != 0) /* goto L_000c */;
        v1 = 0;
        _result = v2.a(v1, v4); // android.support.v4.widget.SlidingPaneLayout.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_000f */;
        v2.q = v0; // android.support.v4.widget.SlidingPaneLayout.q:boolean
        v0 = 1;
        return v0;
    }

    static android.support.v4.widget.am b(android.support.v4.widget.SlidingPaneLayout p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.widget.SlidingPaneLayout)
        v0 = v1.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        return v0;
    }

    private boolean b(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = 1;
        v1 = v2.r; // android.support.v4.widget.SlidingPaneLayout.r:boolean
        if (v1 != 0) /* goto L_000d */;
        v1 = 0x3f800000;
        _result = v2.a(v1, v4); // android.support.v4.widget.SlidingPaneLayout.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0010 */;
        v2.q = v0; // android.support.v4.widget.SlidingPaneLayout.q:boolean
        return v0;
        v0 = 0;
        // goto L_000f
    }

    static float c(android.support.v4.widget.SlidingPaneLayout p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.widget.SlidingPaneLayout)
        v0 = v1.h; // android.support.v4.widget.SlidingPaneLayout.h:float
        return v0;
    }

    static android.view.View d(android.support.v4.widget.SlidingPaneLayout p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.widget.SlidingPaneLayout)
        v0 = v1.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        return v0;
    }

    static int e(android.support.v4.widget.SlidingPaneLayout p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.widget.SlidingPaneLayout)
        v0 = v1.j; // android.support.v4.widget.SlidingPaneLayout.j:int
        return v0;
    }

    static java.util.ArrayList f(android.support.v4.widget.SlidingPaneLayout p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.widget.SlidingPaneLayout)
        v0 = v1.t; // android.support.v4.widget.SlidingPaneLayout.t:java.util.ArrayList
        return v0;
    }

    private static boolean f(android.view.View p0) {
        // Registers (5 total): v4 = p0 (android.view.View)
        v0 = 1;
        v1 = 0;
        _result = v4.g(); // android.support.v4.view.at.g -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0009 */;
        return v0;
        v2 = android.os.Build$VERSION.SDK_INT; // :int
        v3 = 18;
        if (v2 < v3) /* goto L_0011 */;
        v0 = v1;
        // goto L_0008
        _result = v4.getBackground(); // android.view.View.getBackground -> android.graphics.drawable.Drawable
        v2 = _result;
        if (v2 == 0) /* goto L_0020 */;
        _result = v2.getOpacity(); // android.graphics.drawable.Drawable.getOpacity -> int
        v2 = _result;
        v3 = -1;
        if (v2 == v3) /* goto L_0008 */;
        v0 = v1;
        // goto L_0008
        v0 = v1;
        // goto L_0008
    }

    private void g(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = android.support.v4.widget.SlidingPaneLayout.a; // :android.support.v4.widget.ai
        _result = android.support.v4.widget.ai.a(v0, v1, v2); // -> void
        return;
    }

    void a() {
        // Registers (7 total): v6 = this
        v1 = 0;
        _result = v6.getChildCount(); // android.support.v4.widget.SlidingPaneLayout.getChildCount -> int
        v2 = _result;
        v0 = v1;
        if (v0 >= v2) /* goto L_0019 */;
        _result = v6.getChildAt(v0); // android.support.v4.widget.SlidingPaneLayout.getChildAt -> android.view.View
        v3 = _result;
        _result = v3.getVisibility(); // android.view.View.getVisibility -> int
        v4 = _result;
        v5 = 4;
        if (v4 != v5) /* goto L_0016 */;
        _result = v3.setVisibility(v1); // android.view.View.setVisibility -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0006
        return;
    }

    void a(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = v2.o; // android.support.v4.widget.SlidingPaneLayout.o:android.support.v4.widget.ag
        if (v0 == 0) /* goto L_000b */;
        v0 = v2.o; // android.support.v4.widget.SlidingPaneLayout.o:android.support.v4.widget.ag
        v1 = v2.h; // android.support.v4.widget.SlidingPaneLayout.h:float
        _result = android.support.v4.widget.ag.a(v0, v3, v1); // -> void
        return;
    }

    boolean a(float p0, int p1) {
        // Registers (8 total): v5 = this, v6 = p0 (float), v7 = p1 (int)
        v1 = 0;
        v0 = v5.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v0 != 0) /* goto L_0007 */;
        v0 = v1;
        return v0;
        v0 = v5.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        _result = v5.getPaddingLeft(); // android.support.v4.widget.SlidingPaneLayout.getPaddingLeft -> int
        v2 = _result;
        v0 = v0.leftMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.leftMargin:int
        v0 = binOp2addr_0xb0(v0, v2);
        v0 = unaryOp_0x82(v0);
        v2 = v5.j; // android.support.v4.widget.SlidingPaneLayout.j:int
        v2 = unaryOp_0x82(v2);
        v2 = binOp2addr_0xc8(v2, v6);
        v0 = binOp2addr_0xc6(v0, v2);
        v0 = unaryOp_0x87(v0);
        v2 = v5.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        v3 = v5.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        v4 = v5.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        _result = v4.getTop(); // android.view.View.getTop -> int
        v4 = _result;
        _result = v2.a(v3, v0, v4); // android.support.v4.widget.am.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0035 */;
        _result = v5.a(); // android.support.v4.widget.SlidingPaneLayout.a -> void
        _result = v5.b(); // android.support.v4.view.at.b -> void
        v0 = 1;
        // goto L_0006
        v0 = v1;
        // goto L_0006
    }

    void b(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = v1.o; // android.support.v4.widget.SlidingPaneLayout.o:android.support.v4.widget.ag
        if (v0 == 0) /* goto L_0009 */;
        v0 = v1.o; // android.support.v4.widget.SlidingPaneLayout.o:android.support.v4.widget.ag
        _result = android.support.v4.widget.ag.a(v0, v2); // -> void
        v0 = 32;
        _result = v1.sendAccessibilityEvent(v0); // android.support.v4.widget.SlidingPaneLayout.sendAccessibilityEvent -> void
        return;
    }

    public boolean b() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        v1 = 0;
        _result = v2.b(v0, v1); // android.support.v4.widget.SlidingPaneLayout.b -> boolean
        v0 = _result;
        return v0;
    }

    void c(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = v1.o; // android.support.v4.widget.SlidingPaneLayout.o:android.support.v4.widget.ag
        if (v0 == 0) /* goto L_0009 */;
        v0 = v1.o; // android.support.v4.widget.SlidingPaneLayout.o:android.support.v4.widget.ag
        _result = android.support.v4.widget.ag.b(v0, v2); // -> void
        v0 = 32;
        _result = v1.sendAccessibilityEvent(v0); // android.support.v4.widget.SlidingPaneLayout.sendAccessibilityEvent -> void
        return;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        v1 = 0;
        _result = v2.a(v0, v1); // android.support.v4.widget.SlidingPaneLayout.a -> boolean
        v0 = _result;
        return v0;
    }

    protected boolean checkLayoutParams(android.view.ViewGroup$LayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$LayoutParams)
        v0 = (v2 instanceof android.support.v4.widget.SlidingPaneLayout$LayoutParams);
        if (v0 == 0) /* goto L_000c */;
        _result = v1.checkLayoutParams(v2); // android.view.ViewGroup.checkLayoutParams -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000b
    }

    public void computeScroll() {
        // Registers (3 total): v2 = this
        v0 = v2.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        v1 = 1;
        _result = v0.a(v1); // android.support.v4.widget.am.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0012 */;
        v0 = v2.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v0 != 0) /* goto L_0013 */;
        v0 = v2.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v0.f(); // android.support.v4.widget.am.f -> void
        return;
        _result = v2.b(); // android.support.v4.view.at.b -> void
        // goto L_0012
    }

    void d(android.view.View p0) {
        // Registers (18 total): v16 = this, v17 = p0 (android.view.View)
        _result = v16.getPaddingLeft(v16..v16); // android.support.v4.widget.SlidingPaneLayout.getPaddingLeft -> int
        v7 = _result;
        _result = v16.getWidth(v16..v16); // android.support.v4.widget.SlidingPaneLayout.getWidth -> int
        v1 = _result;
        _result = v16.getPaddingRight(v16..v16); // android.support.v4.widget.SlidingPaneLayout.getPaddingRight -> int
        v2 = _result;
        v8 = binOp_0x91(v1, v2);
        _result = v16.getPaddingTop(v16..v16); // android.support.v4.widget.SlidingPaneLayout.getPaddingTop -> int
        v9 = _result;
        _result = v16.getHeight(v16..v16); // android.support.v4.widget.SlidingPaneLayout.getHeight -> int
        v1 = _result;
        _result = v16.getPaddingBottom(v16..v16); // android.support.v4.widget.SlidingPaneLayout.getPaddingBottom -> int
        v2 = _result;
        v10 = binOp_0x91(v1, v2);
        if (v17 == 0) /* goto L_0047 */;
        _result = v17.f(v17..v17); // android.support.v4.widget.SlidingPaneLayout.f -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0047 */;
        _result = v17.getLeft(v17..v17); // android.view.View.getLeft -> int
        v4 = _result;
        _result = v17.getRight(v17..v17); // android.view.View.getRight -> int
        v3 = _result;
        _result = v17.getTop(v17..v17); // android.view.View.getTop -> int
        v2 = _result;
        _result = v17.getBottom(v17..v17); // android.view.View.getBottom -> int
        v1 = _result;
        v5 = 0;
        _result = v16.getChildCount(v16..v16); // android.support.v4.widget.SlidingPaneLayout.getChildCount -> int
        v11 = _result;
        v6 = v5;
        if (v6 >= v11) /* goto L_0046 */;
        v0 = v16;
        _result = v0.getChildAt(v6); // android.support.v4.widget.SlidingPaneLayout.getChildAt -> android.view.View
        v12 = _result;
        v0 = v17;
        if (v12 != v0) /* goto L_004c */;
        return;
        v1 = 0;
        v2 = v1;
        v3 = v1;
        v4 = v1;
        // goto L_0034
        _result = v12.getLeft(); // android.view.View.getLeft -> int
        v5 = _result;
        _result = v7.max(v5); // java.lang.Math.max -> int
        v5 = _result;
        _result = v12.getTop(); // android.view.View.getTop -> int
        v13 = _result;
        _result = v9.max(v13); // java.lang.Math.max -> int
        v13 = _result;
        _result = v12.getRight(); // android.view.View.getRight -> int
        v14 = _result;
        _result = v8.min(v14); // java.lang.Math.min -> int
        v14 = _result;
        _result = v12.getBottom(); // android.view.View.getBottom -> int
        v15 = _result;
        _result = v10.min(v15); // java.lang.Math.min -> int
        v15 = _result;
        if (v5 < v4) /* goto L_007c */;
        if (v13 < v2) /* goto L_007c */;
        if (v14 > v3) /* goto L_007c */;
        if (v15 > v1) /* goto L_007c */;
        v5 = 4;
        _result = v12.setVisibility(v5); // android.view.View.setVisibility -> void
        v5 = binOpLit8_0xd8(v6, 1);
        v6 = v5;
        // goto L_003a
        v5 = 0;
        // goto L_0075
    }

    public boolean d() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = v2.h; // android.support.v4.widget.SlidingPaneLayout.h:float
        v1 = 0x3f800000;
        v0 = cmp(v0, v1);
        if (v0 != 0) /* goto L_000e */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000d
    }

    public void draw(android.graphics.Canvas p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.graphics.Canvas)
        v1 = 1;
        _result = v5.draw(v6); // android.view.ViewGroup.draw -> void
        _result = v5.getChildCount(); // android.support.v4.widget.SlidingPaneLayout.getChildCount -> int
        v0 = _result;
        if (v0 <= v1) /* goto L_0015 */;
        _result = v5.getChildAt(v1); // android.support.v4.widget.SlidingPaneLayout.getChildAt -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_0014 */;
        v1 = v5.d; // android.support.v4.widget.SlidingPaneLayout.d:android.graphics.drawable.Drawable
        if (v1 != 0) /* goto L_0017 */;
        return;
        v0 = 0;
        // goto L_000e
        v1 = v5.d; // android.support.v4.widget.SlidingPaneLayout.d:android.graphics.drawable.Drawable
        _result = v1.getIntrinsicWidth(); // android.graphics.drawable.Drawable.getIntrinsicWidth -> int
        v1 = _result;
        _result = v0.getLeft(); // android.view.View.getLeft -> int
        v2 = _result;
        _result = v0.getTop(); // android.view.View.getTop -> int
        v3 = _result;
        _result = v0.getBottom(); // android.view.View.getBottom -> int
        v0 = _result;
        v1 = binOp_0x91(v2, v1);
        v4 = v5.d; // android.support.v4.widget.SlidingPaneLayout.d:android.graphics.drawable.Drawable
        _result = v4.setBounds(v1, v3, v2, v0); // android.graphics.drawable.Drawable.setBounds -> void
        v0 = v5.d; // android.support.v4.widget.SlidingPaneLayout.d:android.graphics.drawable.Drawable
        _result = v0.draw(v6); // android.graphics.drawable.Drawable.draw -> void
        // goto L_0014
    }

    protected boolean drawChild(android.graphics.Canvas p0, android.view.View p1, long p2) {
        // Registers (11 total): v6 = this, v7 = p0 (android.graphics.Canvas), v8 = p1 (android.view.View), v9 = p2 (long)
        v1 = 0;
        _result = v8.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        v2 = 2;
        _result = v7.save(v2); // android.graphics.Canvas.save -> int
        v2 = _result;
        v3 = v6.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v3 == 0) /* goto L_0034 */;
        v3 = v0.b; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.b:boolean
        if (v3 != 0) /* goto L_0034 */;
        v3 = v6.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        if (v3 == 0) /* goto L_0034 */;
        v3 = v6.s; // android.support.v4.widget.SlidingPaneLayout.s:android.graphics.Rect
        _result = v7.getClipBounds(v3); // android.graphics.Canvas.getClipBounds -> boolean
        v3 = v6.s; // android.support.v4.widget.SlidingPaneLayout.s:android.graphics.Rect
        v4 = v6.s; // android.support.v4.widget.SlidingPaneLayout.s:android.graphics.Rect
        v4 = v4.right; // android.graphics.Rect.right:int
        v5 = v6.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        _result = v5.getLeft(); // android.view.View.getLeft -> int
        v5 = _result;
        _result = v4.min(v5); // java.lang.Math.min -> int
        v4 = _result;
        v3.right = v4; // android.graphics.Rect.right:int
        v3 = v6.s; // android.support.v4.widget.SlidingPaneLayout.s:android.graphics.Rect
        _result = v7.clipRect(v3); // android.graphics.Canvas.clipRect -> boolean
        v3 = android.os.Build$VERSION.SDK_INT; // :int
        v4 = 11;
        if (v3 < v4) /* goto L_0042 */;
        _result = v6.drawChild(v7, v8, v9, v10); // android.view.ViewGroup.drawChild -> boolean
        v0 = _result;
        _result = v7.restoreToCount(v2); // android.graphics.Canvas.restoreToCount -> void
        return v0;
        v3 = v0.c; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.c:boolean
        if (v3 == 0) /* goto L_0094 */;
        v3 = v6.h; // android.support.v4.widget.SlidingPaneLayout.h:float
        v4 = 0;
        v3 = cmp(v3, v4);
        if (v3 <= 0) /* goto L_0094 */;
        _result = v8.isDrawingCacheEnabled(); // android.view.View.isDrawingCacheEnabled -> boolean
        v3 = _result;
        if (v3 != 0) /* goto L_0057 */;
        v3 = 1;
        _result = v8.setDrawingCacheEnabled(v3); // android.view.View.setDrawingCacheEnabled -> void
        _result = v8.getDrawingCache(); // android.view.View.getDrawingCache -> android.graphics.Bitmap
        v3 = _result;
        if (v3 == 0) /* goto L_006e */;
        _result = v8.getLeft(); // android.view.View.getLeft -> int
        v4 = _result;
        v4 = unaryOp_0x82(v4);
        _result = v8.getTop(); // android.view.View.getTop -> int
        v5 = _result;
        v5 = unaryOp_0x82(v5);
        v0 = v0.d; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.d:android.graphics.Paint
        _result = v7.drawBitmap(v3, v4, v5, v0); // android.graphics.Canvas.drawBitmap -> void
        v0 = v1;
        // goto L_003e
        v0 = "SlidingPaneLayout";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "drawChild: child view ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v3 = " returned null drawing cache";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // android.util.Log.e -> int
        _result = v6.drawChild(v7, v8, v9, v10); // android.view.ViewGroup.drawChild -> boolean
        v0 = _result;
        // goto L_003e
        _result = v8.isDrawingCacheEnabled(); // android.view.View.isDrawingCacheEnabled -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_009d */;
        _result = v8.setDrawingCacheEnabled(v1); // android.view.View.setDrawingCacheEnabled -> void
        _result = v6.drawChild(v7, v8, v9, v10); // android.view.ViewGroup.drawChild -> boolean
        v0 = _result;
        // goto L_003e
    }

    public boolean e() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        return v0;
    }

    boolean e(android.view.View p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.view.View)
        v1 = 0;
        if (v4 != 0) /* goto L_0004 */;
        return v1;
        _result = v4.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        v2 = v3.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v2 == 0) /* goto L_001c */;
        v0 = v0.c; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.c:boolean
        if (v0 == 0) /* goto L_001c */;
        v0 = v3.h; // android.support.v4.widget.SlidingPaneLayout.h:float
        v2 = 0;
        v0 = cmp(v0, v2);
        if (v0 <= 0) /* goto L_001c */;
        v0 = 1;
        v1 = v0;
        // goto L_0003
        v0 = v1;
        // goto L_001a
    }

    protected android.view.ViewGroup$LayoutParams generateDefaultLayoutParams() {
        // Registers (2 total): v1 = this
        v0 = new android.support.v4.widget.SlidingPaneLayout$LayoutParams;
        _result = v0.<init>(); // android.support.v4.widget.SlidingPaneLayout$LayoutParams.<init> -> void
        return v0;
    }

    public android.view.ViewGroup$LayoutParams generateLayoutParams(android.util.AttributeSet p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.util.AttributeSet)
        v0 = new android.support.v4.widget.SlidingPaneLayout$LayoutParams;
        _result = v2.getContext(); // android.support.v4.widget.SlidingPaneLayout.getContext -> android.content.Context
        v1 = _result;
        _result = v0.<init>(v1, v3); // android.support.v4.widget.SlidingPaneLayout$LayoutParams.<init> -> void
        return v0;
    }

    protected android.view.ViewGroup$LayoutParams generateLayoutParams(android.view.ViewGroup$LayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$LayoutParams)
        v0 = (v2 instanceof android.view.ViewGroup$MarginLayoutParams);
        if (v0 == 0) /* goto L_000c */;
        v0 = new android.support.v4.widget.SlidingPaneLayout$LayoutParams;
        v2 = (android.view.ViewGroup$MarginLayoutParams) v2;
        _result = v0.<init>(v2); // android.support.v4.widget.SlidingPaneLayout$LayoutParams.<init> -> void
        return v0;
        v0 = new android.support.v4.widget.SlidingPaneLayout$LayoutParams;
        _result = v0.<init>(v2); // android.support.v4.widget.SlidingPaneLayout$LayoutParams.<init> -> void
        // goto L_000b
    }

    protected void onAttachedToWindow() {
        // Registers (2 total): v1 = this
        _result = v1.onAttachedToWindow(); // android.view.ViewGroup.onAttachedToWindow -> void
        v0 = 1;
        v1.r = v0; // android.support.v4.widget.SlidingPaneLayout.r:boolean
        return;
    }

    protected void onDetachedFromWindow() {
        // Registers (4 total): v3 = this
        _result = v3.onDetachedFromWindow(); // android.view.ViewGroup.onDetachedFromWindow -> void
        v0 = 1;
        v3.r = v0; // android.support.v4.widget.SlidingPaneLayout.r:boolean
        v0 = 0;
        v1 = v3.t; // android.support.v4.widget.SlidingPaneLayout.t:java.util.ArrayList
        _result = v1.size(); // java.util.ArrayList.size -> int
        v2 = _result;
        v1 = v0;
        if (v1 >= v2) /* goto L_001f */;
        v0 = v3.t; // android.support.v4.widget.SlidingPaneLayout.t:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.widget.ae) v0;
        _result = v0.run(); // android.support.v4.widget.ae.run -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_000e
        v0 = v3.t; // android.support.v4.widget.SlidingPaneLayout.t:java.util.ArrayList
        _result = v0.clear(); // java.util.ArrayList.clear -> void
        return;
    }

    public boolean onInterceptTouchEvent(android.view.MotionEvent p0) {
        // Registers (9 total): v7 = this, v8 = p0 (android.view.MotionEvent)
        v2 = 0;
        v1 = 1;
        _result = v8.a(); // android.support.v4.view.z.a -> int
        v3 = _result;
        v0 = v7.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v0 != 0) /* goto L_002d */;
        if (v3 != 0) /* goto L_002d */;
        _result = v7.getChildCount(); // android.support.v4.widget.SlidingPaneLayout.getChildCount -> int
        v0 = _result;
        if (v0 <= v1) /* goto L_002d */;
        _result = v7.getChildAt(v1); // android.support.v4.widget.SlidingPaneLayout.getChildAt -> android.view.View
        v0 = _result;
        if (v0 == 0) /* goto L_002d */;
        v4 = v7.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v8.getX(); // android.view.MotionEvent.getX -> float
        v5 = _result;
        v5 = unaryOp_0x87(v5);
        _result = v8.getY(); // android.view.MotionEvent.getY -> float
        v6 = _result;
        v6 = unaryOp_0x87(v6);
        _result = v4.b(v0, v5, v6); // android.support.v4.widget.am.b -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0041 */;
        v0 = v1;
        v7.q = v0; // android.support.v4.widget.SlidingPaneLayout.q:boolean
        v0 = v7.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v0 == 0) /* goto L_0037 */;
        v0 = v7.k; // android.support.v4.widget.SlidingPaneLayout.k:boolean
        if (v0 == 0) /* goto L_0043 */;
        if (v3 == 0) /* goto L_0043 */;
        v0 = v7.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v0.e(); // android.support.v4.widget.am.e -> void
        _result = v7.onInterceptTouchEvent(v8); // android.view.ViewGroup.onInterceptTouchEvent -> boolean
        v2 = _result;
        return v2;
        v0 = v2;
        // goto L_002b
        v0 = 3;
        if (v3 == v0) /* goto L_0048 */;
        if (v3 != v1) /* goto L_004e */;
        v0 = v7.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v0.e(); // android.support.v4.widget.am.e -> void
        // goto L_0040
        // switch(v3)
        v0 = v2;
        v3 = v7.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v3.a(v8); // android.support.v4.widget.am.a -> boolean
        v3 = _result;
        if (v3 != 0) /* goto L_005c */;
        if (v0 == 0) /* goto L_0040 */;
        v2 = v1;
        // goto L_0040
        v7.k = v2; // android.support.v4.widget.SlidingPaneLayout.k:boolean
        _result = v8.getX(); // android.view.MotionEvent.getX -> float
        v0 = _result;
        _result = v8.getY(); // android.view.MotionEvent.getY -> float
        v3 = _result;
        v7.m = v0; // android.support.v4.widget.SlidingPaneLayout.m:float
        v7.n = v3; // android.support.v4.widget.SlidingPaneLayout.n:float
        v4 = v7.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        v5 = v7.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        v0 = unaryOp_0x87(v0);
        v3 = unaryOp_0x87(v3);
        _result = v4.b(v5, v0, v3); // android.support.v4.widget.am.b -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0051 */;
        v0 = v7.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        _result = v7.e(v0); // android.support.v4.widget.SlidingPaneLayout.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0051 */;
        v0 = v1;
        // goto L_0052
        _result = v8.getX(); // android.view.MotionEvent.getX -> float
        v0 = _result;
        _result = v8.getY(); // android.view.MotionEvent.getY -> float
        v3 = _result;
        v4 = v7.m; // android.support.v4.widget.SlidingPaneLayout.m:float
        v0 = binOp2addr_0xc7(v0, v4);
        _result = v0.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v4 = v7.n; // android.support.v4.widget.SlidingPaneLayout.n:float
        v3 = binOp2addr_0xc7(v3, v4);
        _result = v3.abs(); // java.lang.Math.abs -> float
        v3 = _result;
        v4 = v7.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v4.d(); // android.support.v4.widget.am.d -> int
        v4 = _result;
        v4 = unaryOp_0x82(v4);
        v4 = cmp(v0, v4);
        if (v4 <= 0) /* goto L_0051 */;
        v0 = cmp(v3, v0);
        if (v0 <= 0) /* goto L_0051 */;
        v0 = v7.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v0.e(); // android.support.v4.widget.am.e -> void
        v7.k = v1; // android.support.v4.widget.SlidingPaneLayout.k:boolean
        // goto L_0040
    }

    protected void onLayout(boolean p0, int p1, int p2, int p3, int p4) {
        // Registers (20 total): v14 = this, v15 = p0 (boolean), v16 = p1 (int), v17 = p2 (int), v18 = p3 (int), v19 = p4 (int)
        v6 = binOp_0x91(v18, v16);
        _result = v14.getPaddingLeft(); // android.support.v4.widget.SlidingPaneLayout.getPaddingLeft -> int
        v3 = _result;
        _result = v14.getPaddingRight(); // android.support.v4.widget.SlidingPaneLayout.getPaddingRight -> int
        v7 = _result;
        _result = v14.getPaddingTop(); // android.support.v4.widget.SlidingPaneLayout.getPaddingTop -> int
        v8 = _result;
        _result = v14.getChildCount(); // android.support.v4.widget.SlidingPaneLayout.getChildCount -> int
        v9 = _result;
        v0 = v14.r; // android.support.v4.widget.SlidingPaneLayout.r:boolean
        if (v0 == 0) /* goto L_0022 */;
        v0 = v14.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v0 == 0) /* goto L_0039 */;
        v0 = v14.q; // android.support.v4.widget.SlidingPaneLayout.q:boolean
        if (v0 == 0) /* goto L_0039 */;
        v0 = 0x3f800000;
        v14.h = v0; // android.support.v4.widget.SlidingPaneLayout.h:float
        v0 = 0;
        v5 = v0;
        v4 = v3;
        if (v5 >= v9) /* goto L_00a0 */;
        _result = v14.getChildAt(v5); // android.support.v4.widget.SlidingPaneLayout.getChildAt -> android.view.View
        v10 = _result;
        _result = v10.getVisibility(); // android.view.View.getVisibility -> int
        v0 = _result;
        v1 = 8;
        if (v0 != v1) /* goto L_003b */;
        v1 = v4;
        v0 = binOpLit8_0xd8(v5, 1);
        v5 = v0;
        v4 = v1;
        // goto L_0025
        v0 = 0;
        // goto L_0020
        _result = v10.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        _result = v10.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v11 = _result;
        v2 = 0;
        v1 = v0.b; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.b:boolean
        if (v1 == 0) /* goto L_0089 */;
        v1 = v0.leftMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.leftMargin:int
        v12 = v0.rightMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.rightMargin:int
        v1 = binOp2addr_0xb0(v1, v12);
        v12 = binOp_0x91(v6, v7);
        v13 = v14.e; // android.support.v4.widget.SlidingPaneLayout.e:int
        v12 = binOp2addr_0xb1(v12, v13);
        _result = v3.min(v12); // java.lang.Math.min -> int
        v12 = _result;
        v12 = binOp2addr_0xb1(v12, v4);
        v12 = binOp2addr_0xb1(v12, v1);
        v14.j = v12; // android.support.v4.widget.SlidingPaneLayout.j:int
        v1 = v0.leftMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.leftMargin:int
        v1 = binOp2addr_0xb0(v1, v4);
        v1 = binOp2addr_0xb0(v1, v12);
        v13 = binOpLit8_0xdb(v11, 2);
        v1 = binOp2addr_0xb0(v1, v13);
        v13 = binOp_0x91(v6, v7);
        if (v1 <= v13) /* goto L_0087 */;
        v1 = 1;
        v0.c = v1; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.c:boolean
        v1 = unaryOp_0x82(v12);
        v12 = v14.h; // android.support.v4.widget.SlidingPaneLayout.h:float
        v1 = binOp2addr_0xc8(v1, v12);
        v1 = unaryOp_0x87(v1);
        v0 = v0.leftMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.leftMargin:int
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = binOp2addr_0xb0(v0, v4);
        v1 = v0;
        v0 = v2;
        v0 = binOp_0x91(v1, v0);
        v2 = binOp_0x90(v0, v11);
        _result = v10.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v4 = _result;
        v4 = binOp2addr_0xb0(v4, v8);
        _result = v10.layout(v0, v8, v2, v4); // android.view.View.layout -> void
        _result = v10.getWidth(); // android.view.View.getWidth -> int
        v0 = _result;
        v3 = binOp2addr_0xb0(v3, v0);
        // goto L_0034
        v1 = 0;
        // goto L_0068
        v0 = v14.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v0 == 0) /* goto L_009d */;
        v0 = v14.l; // android.support.v4.widget.SlidingPaneLayout.l:int
        if (v0 == 0) /* goto L_009d */;
        v0 = 0x3f800000;
        v1 = v14.h; // android.support.v4.widget.SlidingPaneLayout.h:float
        v0 = binOp2addr_0xc7(v0, v1);
        v1 = v14.l; // android.support.v4.widget.SlidingPaneLayout.l:int
        v1 = unaryOp_0x82(v1);
        v0 = binOp2addr_0xc8(v0, v1);
        v0 = unaryOp_0x87(v0);
        v1 = v3;
        // goto L_0075
        v0 = v2;
        v1 = v3;
        // goto L_0075
        v0 = v14.r; // android.support.v4.widget.SlidingPaneLayout.r:boolean
        if (v0 == 0) /* goto L_00cb */;
        v0 = v14.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v0 == 0) /* goto L_00cf */;
        v0 = v14.l; // android.support.v4.widget.SlidingPaneLayout.l:int
        if (v0 == 0) /* goto L_00b1 */;
        v0 = v14.h; // android.support.v4.widget.SlidingPaneLayout.h:float
        _result = v14.a(v0); // android.support.v4.widget.SlidingPaneLayout.a -> void
        v0 = v14.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        _result = v0.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        v0 = v0.c; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.c:boolean
        if (v0 == 0) /* goto L_00c6 */;
        v0 = v14.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        v1 = v14.h; // android.support.v4.widget.SlidingPaneLayout.h:float
        v2 = v14.b; // android.support.v4.widget.SlidingPaneLayout.b:int
        _result = v14.a(v0, v1, v2); // android.support.v4.widget.SlidingPaneLayout.a -> void
        v0 = v14.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        _result = v14.d(v0); // android.support.v4.widget.SlidingPaneLayout.d -> void
        v0 = 0;
        v14.r = v0; // android.support.v4.widget.SlidingPaneLayout.r:boolean
        return;
        v0 = 0;
        if (v0 >= v9) /* goto L_00c6 */;
        _result = v14.getChildAt(v0); // android.support.v4.widget.SlidingPaneLayout.getChildAt -> android.view.View
        v1 = _result;
        v2 = 0;
        v3 = v14.b; // android.support.v4.widget.SlidingPaneLayout.b:int
        _result = v14.a(v1, v2, v3); // android.support.v4.widget.SlidingPaneLayout.a -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_00d0
    }

    protected void onMeasure(int p0, int p1) {
        // Registers (18 total): v15 = this, v16 = p0 (int), v17 = p1 (int)
        _result = v16.getMode(v16..v16); // android.view.View$MeasureSpec.getMode -> int
        v3 = _result;
        _result = v16.getSize(v16..v16); // android.view.View$MeasureSpec.getSize -> int
        v2 = _result;
        _result = v17.getMode(v17..v17); // android.view.View$MeasureSpec.getMode -> int
        v1 = _result;
        _result = v17.getSize(v17..v17); // android.view.View$MeasureSpec.getSize -> int
        v0 = _result;
        v4 = 0x40000000;
        if (v3 == v4) /* goto L_0082 */;
        _result = v15.isInEditMode(); // android.support.v4.widget.SlidingPaneLayout.isInEditMode -> boolean
        v4 = _result;
        if (v4 == 0) /* goto L_0079 */;
        v4 = 0x80000000;
        if (v3 != v4) /* goto L_0071 */;
        v9 = v1;
        v10 = v2;
        v2 = v0;
        v1 = 0;
        v0 = -1;
        // switch(v9)
        v14 = v0;
        v0 = v1;
        v1 = v14;
        v3 = 0;
        v6 = 0;
        _result = v15.getPaddingLeft(); // android.support.v4.widget.SlidingPaneLayout.getPaddingLeft -> int
        v2 = _result;
        v2 = binOp_0x91(v10, v2);
        _result = v15.getPaddingRight(); // android.support.v4.widget.SlidingPaneLayout.getPaddingRight -> int
        v4 = _result;
        v5 = binOp_0x91(v2, v4);
        _result = v15.getChildCount(); // android.support.v4.widget.SlidingPaneLayout.getChildCount -> int
        v11 = _result;
        v2 = 2;
        if (v11 <= v2) /* goto L_0047 */;
        v2 = "SlidingPaneLayout";
        v4 = "onMeasure: More than two child views are not supported.";
        _result = v2.e(v4); // android.util.Log.e -> int
        v2 = 0;
        v15.g = v2; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        v2 = 0;
        v8 = v2;
        v7 = v0;
        v2 = v3;
        if (v8 >= v11) /* goto L_0142 */;
        _result = v15.getChildAt(v8); // android.support.v4.widget.SlidingPaneLayout.getChildAt -> android.view.View
        v12 = _result;
        _result = v12.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        _result = v12.getVisibility(); // android.view.View.getVisibility -> int
        v3 = _result;
        v4 = 8;
        if (v3 != v4) /* goto L_00ba */;
        v3 = 0;
        v0.c = v3; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.c:boolean
        v0 = v5;
        v3 = v2;
        v4 = v7;
        v2 = v6;
        v5 = binOpLit8_0xd8(v8, 1);
        v8 = v5;
        v6 = v2;
        v7 = v4;
        v2 = v3;
        v5 = v0;
        // goto L_004e
        if (v3 != 0) /* goto L_024b */;
        v2 = 300;
        v9 = v1;
        v10 = v2;
        v2 = v0;
        // goto L_0021
        v0 = new java.lang.IllegalStateException;
        v1 = "Width must have an exact value or MATCH_PARENT";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        if (v1 != 0) /* goto L_024b */;
        _result = v15.isInEditMode(); // android.support.v4.widget.SlidingPaneLayout.isInEditMode -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0094 */;
        if (v1 != 0) /* goto L_024b */;
        v1 = 0x80000000;
        v0 = 300;
        v9 = v1;
        v10 = v2;
        v2 = v0;
        // goto L_0021
        v0 = new java.lang.IllegalStateException;
        v1 = "Height must not be UNSPECIFIED";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        _result = v15.getPaddingTop(); // android.support.v4.widget.SlidingPaneLayout.getPaddingTop -> int
        v0 = _result;
        v0 = binOp_0x91(v2, v0);
        _result = v15.getPaddingBottom(); // android.support.v4.widget.SlidingPaneLayout.getPaddingBottom -> int
        v1 = _result;
        v0 = binOp2addr_0xb1(v0, v1);
        v1 = v0;
        // goto L_0029
        _result = v15.getPaddingTop(); // android.support.v4.widget.SlidingPaneLayout.getPaddingTop -> int
        v0 = _result;
        v0 = binOp_0x91(v2, v0);
        _result = v15.getPaddingBottom(); // android.support.v4.widget.SlidingPaneLayout.getPaddingBottom -> int
        v2 = _result;
        v0 = binOp2addr_0xb1(v0, v2);
        v14 = v0;
        v0 = v1;
        v1 = v14;
        // goto L_0029
        v3 = v0.a; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.a:float
        v4 = 0;
        v3 = cmp(v3, v4);
        if (v3 <= 0) /* goto L_00cd */;
        v3 = v0.a; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.a:float
        v2 = binOp2addr_0xc6(v2, v3);
        v3 = v0.width; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.width:int
        if (v3 != 0) /* goto L_00cd */;
        v0 = v5;
        v3 = v2;
        v4 = v7;
        v2 = v6;
        // goto L_0069
        v3 = v0.leftMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.leftMargin:int
        v4 = v0.rightMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.rightMargin:int
        v3 = binOp2addr_0xb0(v3, v4);
        v4 = v0.width; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.width:int
        v13 = -2;
        if (v4 != v13) /* goto L_0114 */;
        v3 = binOp_0x91(v10, v3);
        v4 = 0x80000000;
        _result = v3.makeMeasureSpec(v4); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v3 = _result;
        v4 = v0.height; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.height:int
        v13 = -2;
        if (v4 != v13) /* goto L_012b */;
        v4 = 0x80000000;
        _result = v1.makeMeasureSpec(v4); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v4 = _result;
        _result = v12.measure(v3, v4); // android.view.View.measure -> void
        _result = v12.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v3 = _result;
        _result = v12.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v4 = _result;
        v13 = 0x80000000;
        if (v9 != v13) /* goto L_00ff */;
        if (v4 <= v7) /* goto L_00ff */;
        _result = v4.min(v1); // java.lang.Math.min -> int
        v7 = _result;
        v4 = binOp_0x91(v5, v3);
        if (v4 >= 0) /* goto L_0140 */;
        v3 = 1;
        v0.b = v3; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.b:boolean
        v3 = binOp2addr_0xb6(v3, v6);
        v0 = v0.b; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.b:boolean
        if (v0 == 0) /* goto L_010d */;
        v15.g = v12; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        v0 = v4;
        v4 = v7;
        v14 = v2;
        v2 = v3;
        v3 = v14;
        // goto L_0069
        v4 = v0.width; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.width:int
        v13 = -1;
        if (v4 != v13) /* goto L_0122 */;
        v3 = binOp_0x91(v10, v3);
        v4 = 0x40000000;
        _result = v3.makeMeasureSpec(v4); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v3 = _result;
        // goto L_00df
        v3 = v0.width; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.width:int
        v4 = 0x40000000;
        _result = v3.makeMeasureSpec(v4); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v3 = _result;
        // goto L_00df
        v4 = v0.height; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.height:int
        v13 = -1;
        if (v4 != v13) /* goto L_0137 */;
        v4 = 0x40000000;
        _result = v1.makeMeasureSpec(v4); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v4 = _result;
        // goto L_00ea
        v4 = v0.height; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.height:int
        v13 = 0x40000000;
        _result = v4.makeMeasureSpec(v13); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v4 = _result;
        // goto L_00ea
        v3 = 0;
        // goto L_0104
        if (v6 != 0) /* goto L_0149 */;
        v0 = 0;
        v0 = cmp(v2, v0);
        if (v0 <= 0) /* goto L_0236 */;
        v0 = v15.e; // android.support.v4.widget.SlidingPaneLayout.e:int
        v12 = binOp_0x91(v10, v0);
        v0 = 0;
        v9 = v0;
        if (v9 >= v11) /* goto L_0236 */;
        _result = v15.getChildAt(v9); // android.support.v4.widget.SlidingPaneLayout.getChildAt -> android.view.View
        v13 = _result;
        _result = v13.getVisibility(); // android.view.View.getVisibility -> int
        v0 = _result;
        v3 = 8;
        if (v0 != v3) /* goto L_0161 */;
        v0 = binOpLit8_0xd8(v9, 1);
        v9 = v0;
        // goto L_014f
        _result = v13.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v0 = _result;
        v0 = (android.support.v4.widget.SlidingPaneLayout$LayoutParams) v0;
        _result = v13.getVisibility(); // android.view.View.getVisibility -> int
        v3 = _result;
        v4 = 8;
        if (v3 == v4) /* goto L_015d */;
        v3 = v0.width; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.width:int
        if (v3 != 0) /* goto L_01aa */;
        v3 = v0.a; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.a:float
        v4 = 0;
        v3 = cmp(v3, v4);
        if (v3 <= 0) /* goto L_01aa */;
        v3 = 1;
        v8 = v3;
        if (v8 == 0) /* goto L_01ad */;
        v3 = 0;
        v4 = v3;
        if (v6 == 0) /* goto L_01d3 */;
        v3 = v15.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        if (v13 == v3) /* goto L_01d3 */;
        v3 = v0.width; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.width:int
        if (v3 >= 0) /* goto L_015d */;
        if (v4 > v12) /* goto L_0193 */;
        v3 = v0.a; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.a:float
        v4 = 0;
        v3 = cmp(v3, v4);
        if (v3 <= 0) /* goto L_015d */;
        if (v8 == 0) /* goto L_01c8 */;
        v3 = v0.height; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.height:int
        v4 = -2;
        if (v3 != v4) /* goto L_01b3 */;
        v0 = 0x80000000;
        _result = v1.makeMeasureSpec(v0); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        v3 = 0x40000000;
        _result = v12.makeMeasureSpec(v3); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v3 = _result;
        _result = v13.measure(v3, v0); // android.view.View.measure -> void
        // goto L_015d
        v3 = 0;
        v8 = v3;
        // goto L_017c
        _result = v13.getMeasuredWidth(); // android.view.View.getMeasuredWidth -> int
        v3 = _result;
        v4 = v3;
        // goto L_0180
        v3 = v0.height; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.height:int
        v4 = -1;
        if (v3 != v4) /* goto L_01bf */;
        v0 = 0x40000000;
        _result = v1.makeMeasureSpec(v0); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        // goto L_01a0
        v0 = v0.height; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.height:int
        v3 = 0x40000000;
        _result = v0.makeMeasureSpec(v3); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        // goto L_01a0
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v0 = _result;
        v3 = 0x40000000;
        _result = v0.makeMeasureSpec(v3); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        // goto L_01a0
        v3 = v0.a; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.a:float
        v8 = 0;
        v3 = cmp(v3, v8);
        if (v3 <= 0) /* goto L_015d */;
        v3 = v0.width; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.width:int
        if (v3 != 0) /* goto L_0214 */;
        v3 = v0.height; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.height:int
        v8 = -2;
        if (v3 != v8) /* goto L_01ff */;
        v3 = 0x80000000;
        _result = v1.makeMeasureSpec(v3); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v3 = _result;
        if (v6 == 0) /* goto L_021f */;
        v8 = v0.leftMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.leftMargin:int
        v0 = v0.rightMargin; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.rightMargin:int
        v0 = binOp2addr_0xb0(v0, v8);
        v0 = binOp_0x91(v10, v0);
        v8 = 0x40000000;
        _result = v0.makeMeasureSpec(v8); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v8 = _result;
        if (v4 == v0) /* goto L_015d */;
        _result = v13.measure(v8, v3); // android.view.View.measure -> void
        // goto L_015d
        v3 = v0.height; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.height:int
        v8 = -1;
        if (v3 != v8) /* goto L_020b */;
        v3 = 0x40000000;
        _result = v1.makeMeasureSpec(v3); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v3 = _result;
        // goto L_01e9
        v3 = v0.height; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.height:int
        v8 = 0x40000000;
        _result = v3.makeMeasureSpec(v8); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v3 = _result;
        // goto L_01e9
        _result = v13.getMeasuredHeight(); // android.view.View.getMeasuredHeight -> int
        v3 = _result;
        v8 = 0x40000000;
        _result = v3.makeMeasureSpec(v8); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v3 = _result;
        // goto L_01e9
        v8 = 0;
        _result = v8.max(v5); // java.lang.Math.max -> int
        v8 = _result;
        v0 = v0.a; // android.support.v4.widget.SlidingPaneLayout$LayoutParams.a:float
        v8 = unaryOp_0x82(v8);
        v0 = binOp2addr_0xc8(v0, v8);
        v0 = binOp2addr_0xc9(v0, v2);
        v0 = unaryOp_0x87(v0);
        v0 = binOp2addr_0xb0(v0, v4);
        v4 = 0x40000000;
        _result = v0.makeMeasureSpec(v4); // android.view.View$MeasureSpec.makeMeasureSpec -> int
        v0 = _result;
        _result = v13.measure(v0, v3); // android.view.View.measure -> void
        // goto L_015d
        _result = v15.setMeasuredDimension(v10, v7); // android.support.v4.widget.SlidingPaneLayout.setMeasuredDimension -> void
        v15.f = v6; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        v0 = v15.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v0.a(); // android.support.v4.widget.am.a -> int
        v0 = _result;
        if (v0 == 0) /* goto L_024a */;
        if (v6 != 0) /* goto L_024a */;
        v0 = v15.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v0.f(); // android.support.v4.widget.am.f -> void
        return;
        v9 = v1;
        v10 = v2;
        v2 = v0;
        // goto L_0021
    }

    protected void onRestoreInstanceState(android.os.Parcelable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcelable)
        v2 = (android.support.v4.widget.SlidingPaneLayout$SavedState) v2;
        _result = v2.getSuperState(); // android.support.v4.widget.SlidingPaneLayout$SavedState.getSuperState -> android.os.Parcelable
        v0 = _result;
        _result = v1.onRestoreInstanceState(v0); // android.view.ViewGroup.onRestoreInstanceState -> void
        v0 = v2.isOpen; // android.support.v4.widget.SlidingPaneLayout$SavedState.isOpen:boolean
        if (v0 == 0) /* goto L_0015 */;
        _result = v1.b(); // android.support.v4.widget.SlidingPaneLayout.b -> boolean
        v0 = v2.isOpen; // android.support.v4.widget.SlidingPaneLayout$SavedState.isOpen:boolean
        v1.q = v0; // android.support.v4.widget.SlidingPaneLayout.q:boolean
        return;
        _result = v1.c(); // android.support.v4.widget.SlidingPaneLayout.c -> boolean
        // goto L_0010
    }

    protected android.os.Parcelable onSaveInstanceState() {
        // Registers (3 total): v2 = this
        _result = v2.onSaveInstanceState(); // android.view.ViewGroup.onSaveInstanceState -> android.os.Parcelable
        v0 = _result;
        v1 = new android.support.v4.widget.SlidingPaneLayout$SavedState;
        _result = v1.<init>(v0); // android.support.v4.widget.SlidingPaneLayout$SavedState.<init> -> void
        _result = v2.e(); // android.support.v4.widget.SlidingPaneLayout.e -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0016 */;
        _result = v2.d(); // android.support.v4.widget.SlidingPaneLayout.d -> boolean
        v0 = _result;
        v1.isOpen = v0; // android.support.v4.widget.SlidingPaneLayout$SavedState.isOpen:boolean
        return v1;
        v0 = v2.q; // android.support.v4.widget.SlidingPaneLayout.q:boolean
        // goto L_0013
    }

    protected void onSizeChanged(int p0, int p1, int p2, int p3) {
        // Registers (6 total): v1 = this, v2 = p0 (int), v3 = p1 (int), v4 = p2 (int), v5 = p3 (int)
        _result = v1.onSizeChanged(v2, v3, v4, v5); // android.view.ViewGroup.onSizeChanged -> void
        if (v2 == v4) /* goto L_0008 */;
        v0 = 1;
        v1.r = v0; // android.support.v4.widget.SlidingPaneLayout.r:boolean
        return;
    }

    public boolean onTouchEvent(android.view.MotionEvent p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.view.MotionEvent)
        v0 = v6.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v0 != 0) /* goto L_0009 */;
        _result = v6.onTouchEvent(v7); // android.view.ViewGroup.onTouchEvent -> boolean
        v0 = _result;
        return v0;
        v0 = v6.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v0.b(v7); // android.support.v4.widget.am.b -> void
        _result = v7.getAction(); // android.view.MotionEvent.getAction -> int
        v1 = _result;
        v0 = 1;
        v1 = binOpLit16_0xd5(v1, 255);
        // switch(v1)
        // goto L_0008
        _result = v7.getX(); // android.view.MotionEvent.getX -> float
        v1 = _result;
        _result = v7.getY(); // android.view.MotionEvent.getY -> float
        v2 = _result;
        v6.m = v1; // android.support.v4.widget.SlidingPaneLayout.m:float
        v6.n = v2; // android.support.v4.widget.SlidingPaneLayout.n:float
        // goto L_0008
        v1 = v6.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        _result = v6.e(v1); // android.support.v4.widget.SlidingPaneLayout.e -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0008 */;
        _result = v7.getX(); // android.view.MotionEvent.getX -> float
        v1 = _result;
        _result = v7.getY(); // android.view.MotionEvent.getY -> float
        v2 = _result;
        v3 = v6.m; // android.support.v4.widget.SlidingPaneLayout.m:float
        v3 = binOp_0xa7(v1, v3);
        v4 = v6.n; // android.support.v4.widget.SlidingPaneLayout.n:float
        v4 = binOp_0xa7(v2, v4);
        v5 = v6.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        _result = v5.d(); // android.support.v4.widget.am.d -> int
        v5 = _result;
        v3 = binOp2addr_0xc8(v3, v3);
        v4 = binOp2addr_0xc8(v4, v4);
        v3 = binOp2addr_0xc6(v3, v4);
        v4 = binOp_0x92(v5, v5);
        v4 = unaryOp_0x82(v4);
        v3 = cmp(v3, v4);
        if (v3 >= 0) /* goto L_0008 */;
        v3 = v6.p; // android.support.v4.widget.SlidingPaneLayout.p:android.support.v4.widget.am
        v4 = v6.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        v1 = unaryOp_0x87(v1);
        v2 = unaryOp_0x87(v2);
        _result = v3.b(v4, v1, v2); // android.support.v4.widget.am.b -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0008 */;
        v1 = v6.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        v2 = 0;
        _result = v6.a(v1, v2); // android.support.v4.widget.SlidingPaneLayout.a -> boolean
        // goto L_0008
    }

    public void requestChildFocus(android.view.View p0, android.view.View p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.View)
        _result = v1.requestChildFocus(v2, v3); // android.view.ViewGroup.requestChildFocus -> void
        _result = v1.isInTouchMode(); // android.support.v4.widget.SlidingPaneLayout.isInTouchMode -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0014 */;
        v0 = v1.f; // android.support.v4.widget.SlidingPaneLayout.f:boolean
        if (v0 != 0) /* goto L_0014 */;
        v0 = v1.g; // android.support.v4.widget.SlidingPaneLayout.g:android.view.View
        if (v2 != v0) /* goto L_0015 */;
        v0 = 1;
        v1.q = v0; // android.support.v4.widget.SlidingPaneLayout.q:boolean
        return;
        v0 = 0;
        // goto L_0012
    }

    public void setCoveredFadeColor(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.c = v1; // android.support.v4.widget.SlidingPaneLayout.c:int
        return;
    }

    public void setPanelSlideListener(android.support.v4.widget.ag p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.ag)
        v0.o = v1; // android.support.v4.widget.SlidingPaneLayout.o:android.support.v4.widget.ag
        return;
    }

    public void setParallaxDistance(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.l = v1; // android.support.v4.widget.SlidingPaneLayout.l:int
        _result = v0.requestLayout(); // android.support.v4.widget.SlidingPaneLayout.requestLayout -> void
        return;
    }

    public void setShadowDrawable(android.graphics.drawable.Drawable p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.graphics.drawable.Drawable)
        v0.d = v1; // android.support.v4.widget.SlidingPaneLayout.d:android.graphics.drawable.Drawable
        return;
    }

    public void setShadowResource(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.getResources(); // android.support.v4.widget.SlidingPaneLayout.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDrawable(v2); // android.content.res.Resources.getDrawable -> android.graphics.drawable.Drawable
        v0 = _result;
        _result = v1.setShadowDrawable(v0); // android.support.v4.widget.SlidingPaneLayout.setShadowDrawable -> void
        return;
    }

    public void setSliderFadeColor(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        v0.b = v1; // android.support.v4.widget.SlidingPaneLayout.b:int
        return;
    }

}