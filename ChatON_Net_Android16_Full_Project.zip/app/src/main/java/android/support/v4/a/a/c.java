package android.support.v4.a.a;

/**
 * Original SourceFile: DrawableCompat.java
 * Descriptor: Landroid/support/v4/a/a/c;
 */
interface c {
    public abstract void a(android.graphics.drawable.Drawable p0, boolean p1);
    public abstract boolean a(android.graphics.drawable.Drawable p0);
}