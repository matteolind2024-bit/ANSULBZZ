package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/FragmentManagerState;
 */
final class FragmentManagerState implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
     android.support.v4.app.FragmentState[] mActive;
     int[] mAdded;
     android.support.v4.app.BackStackState[] mBackStack;

    static {
        v0 = new android.support.v4.app.ac;
        _result = v0.<init>(); // android.support.v4.app.ac.<init> -> void
        android.support.v4.app.FragmentManagerState.CREATOR = v0; // :android.os.Parcelable$Creator
        return;
    }

    public FragmentManagerState() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public FragmentManagerState(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = android.support.v4.app.FragmentState.CREATOR; // :android.os.Parcelable$Creator
        _result = v2.createTypedArray(v0); // android.os.Parcel.createTypedArray -> java.lang.Object[]
        v0 = _result;
        v0 = (android.support.v4.app.FragmentState[]) v0;
        v1.mActive = v0; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        _result = v2.createIntArray(); // android.os.Parcel.createIntArray -> int[]
        v0 = _result;
        v1.mAdded = v0; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        v0 = android.support.v4.app.BackStackState.CREATOR; // :android.os.Parcelable$Creator
        _result = v2.createTypedArray(v0); // android.os.Parcel.createTypedArray -> java.lang.Object[]
        v0 = _result;
        v0 = (android.support.v4.app.BackStackState[]) v0;
        v1.mBackStack = v0; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        return;
    }

    public int describeContents() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (int)
        v0 = v1.mActive; // android.support.v4.app.FragmentManagerState.mActive:android.support.v4.app.FragmentState[]
        _result = v2.writeTypedArray(v0, v3); // android.os.Parcel.writeTypedArray -> void
        v0 = v1.mAdded; // android.support.v4.app.FragmentManagerState.mAdded:int[]
        _result = v2.writeIntArray(v0); // android.os.Parcel.writeIntArray -> void
        v0 = v1.mBackStack; // android.support.v4.app.FragmentManagerState.mBackStack:android.support.v4.app.BackStackState[]
        _result = v2.writeTypedArray(v0, v3); // android.os.Parcel.writeTypedArray -> void
        return;
    }

}