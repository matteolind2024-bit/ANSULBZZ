package android.support.v4.app;

/**
 * Original SourceFile: FragmentPagerAdapter.java
 * Descriptor: Landroid/support/v4/app/ad;
 */
public abstract class ad extends android.support.v4.view.ae {
    private final android.support.v4.app.w a;
    private android.support.v4.app.aj b;
    private android.support.v4.app.Fragment c;

    public ad(android.support.v4.app.w p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.w)
        v0 = 0;
        _result = v1.<init>(); // android.support.v4.view.ae.<init> -> void
        v1.b = v0; // android.support.v4.app.ad.b:android.support.v4.app.aj
        v1.c = v0; // android.support.v4.app.ad.c:android.support.v4.app.Fragment
        v1.a = v2; // android.support.v4.app.ad.a:android.support.v4.app.w
        return;
    }

    private static java.lang.String a(int p0, long p1) {
        // Registers (5 total): v2 = p0 (int), v3 = p1 (long)
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "android:switcher:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ":";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3, v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public android.os.Parcelable a() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public abstract android.support.v4.app.Fragment a(int p0);
    public java.lang.Object a(android.view.ViewGroup p0, int p1) {
        // Registers (10 total): v7 = this, v8 = p0 (android.view.ViewGroup), v9 = p1 (int)
        v6 = 0;
        v0 = v7.b; // android.support.v4.app.ad.b:android.support.v4.app.aj
        if (v0 != 0) /* goto L_000d */;
        v0 = v7.a; // android.support.v4.app.ad.a:android.support.v4.app.w
        _result = v0.a(); // android.support.v4.app.w.a -> android.support.v4.app.aj
        v0 = _result;
        v7.b = v0; // android.support.v4.app.ad.b:android.support.v4.app.aj
        _result = v7.b(v9); // android.support.v4.app.ad.b -> long
        v1 = _result;
        _result = v8.getId(); // android.view.ViewGroup.getId -> int
        v0 = _result;
        _result = v0.a(v1, v2); // android.support.v4.app.ad.a -> java.lang.String
        v0 = _result;
        v3 = v7.a; // android.support.v4.app.ad.a:android.support.v4.app.w
        _result = v3.a(v0); // android.support.v4.app.w.a -> android.support.v4.app.Fragment
        v0 = _result;
        if (v0 == 0) /* goto L_0031 */;
        v1 = v7.b; // android.support.v4.app.ad.b:android.support.v4.app.aj
        _result = v1.e(v0); // android.support.v4.app.aj.e -> android.support.v4.app.aj
        v1 = v7.c; // android.support.v4.app.ad.c:android.support.v4.app.Fragment
        if (v0 == v1) /* goto L_0030 */;
        _result = v0.setMenuVisibility(v6); // android.support.v4.app.Fragment.setMenuVisibility -> void
        _result = v0.setUserVisibleHint(v6); // android.support.v4.app.Fragment.setUserVisibleHint -> void
        return v0;
        _result = v7.a(v9); // android.support.v4.app.ad.a -> android.support.v4.app.Fragment
        v0 = _result;
        v3 = v7.b; // android.support.v4.app.ad.b:android.support.v4.app.aj
        _result = v8.getId(); // android.view.ViewGroup.getId -> int
        v4 = _result;
        _result = v8.getId(); // android.view.ViewGroup.getId -> int
        v5 = _result;
        _result = v5.a(v1, v2); // android.support.v4.app.ad.a -> java.lang.String
        v1 = _result;
        _result = v3.a(v4, v0, v1); // android.support.v4.app.aj.a -> android.support.v4.app.aj
        // goto L_0026
    }

    public void a(android.os.Parcelable p0, java.lang.ClassLoader p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.os.Parcelable), v2 = p1 (java.lang.ClassLoader)
        return;
    }

    public void a(android.view.ViewGroup p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.ViewGroup)
        return;
    }

    public void a(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (int), v4 = p2 (java.lang.Object)
        v0 = v1.b; // android.support.v4.app.ad.b:android.support.v4.app.aj
        if (v0 != 0) /* goto L_000c */;
        v0 = v1.a; // android.support.v4.app.ad.a:android.support.v4.app.w
        _result = v0.a(); // android.support.v4.app.w.a -> android.support.v4.app.aj
        v0 = _result;
        v1.b = v0; // android.support.v4.app.ad.b:android.support.v4.app.aj
        v0 = v1.b; // android.support.v4.app.ad.b:android.support.v4.app.aj
        v4 = (android.support.v4.app.Fragment) v4;
        _result = v0.d(v4); // android.support.v4.app.aj.d -> android.support.v4.app.aj
        return;
    }

    public boolean a(android.view.View p0, java.lang.Object p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (java.lang.Object)
        v3 = (android.support.v4.app.Fragment) v3;
        _result = v3.getView(); // android.support.v4.app.Fragment.getView -> android.view.View
        v0 = _result;
        if (v0 != v2) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public long b(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = unaryOp_0x81(v3);
        return v0;
    }

    public void b(android.view.ViewGroup p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup)
        v0 = v1.b; // android.support.v4.app.ad.b:android.support.v4.app.aj
        if (v0 == 0) /* goto L_0011 */;
        v0 = v1.b; // android.support.v4.app.ad.b:android.support.v4.app.aj
        _result = v0.c(); // android.support.v4.app.aj.c -> int
        v0 = 0;
        v1.b = v0; // android.support.v4.app.ad.b:android.support.v4.app.aj
        v0 = v1.a; // android.support.v4.app.ad.a:android.support.v4.app.w
        _result = v0.b(); // android.support.v4.app.w.b -> boolean
        return;
    }

    public void b(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.view.ViewGroup), v5 = p1 (int), v6 = p2 (java.lang.Object)
        v2 = 1;
        v1 = 0;
        v6 = (android.support.v4.app.Fragment) v6;
        v0 = v3.c; // android.support.v4.app.ad.c:android.support.v4.app.Fragment
        if (v6 == v0) /* goto L_0020 */;
        v0 = v3.c; // android.support.v4.app.ad.c:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0016 */;
        v0 = v3.c; // android.support.v4.app.ad.c:android.support.v4.app.Fragment
        _result = v0.setMenuVisibility(v1); // android.support.v4.app.Fragment.setMenuVisibility -> void
        v0 = v3.c; // android.support.v4.app.ad.c:android.support.v4.app.Fragment
        _result = v0.setUserVisibleHint(v1); // android.support.v4.app.Fragment.setUserVisibleHint -> void
        if (v6 == 0) /* goto L_001e */;
        _result = v6.setMenuVisibility(v2); // android.support.v4.app.Fragment.setMenuVisibility -> void
        _result = v6.setUserVisibleHint(v2); // android.support.v4.app.Fragment.setUserVisibleHint -> void
        v3.c = v6; // android.support.v4.app.ad.c:android.support.v4.app.Fragment
        return;
    }

}