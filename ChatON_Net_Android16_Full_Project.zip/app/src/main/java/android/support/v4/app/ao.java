package android.support.v4.app;

/**
 * Original SourceFile: LoaderManager.java
 * Descriptor: Landroid/support/v4/app/ao;
 */
class ao extends android.support.v4.app.am {
    static boolean a;
    final android.support.v4.c.n b;
    final android.support.v4.c.n c;
    final java.lang.String d;
     android.support.v4.app.FragmentActivity e;
     boolean f;
     boolean g;
     boolean h;

    static {
        v0 = 0;
        android.support.v4.app.ao.a = v0; // :boolean
        return;
    }

    ao(java.lang.String p0, android.support.v4.app.FragmentActivity p1, boolean p2) {
        // Registers (5 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (android.support.v4.app.FragmentActivity), v4 = p2 (boolean)
        _result = v1.<init>(); // android.support.v4.app.am.<init> -> void
        v0 = new android.support.v4.c.n;
        _result = v0.<init>(); // android.support.v4.c.n.<init> -> void
        v1.b = v0; // android.support.v4.app.ao.b:android.support.v4.c.n
        v0 = new android.support.v4.c.n;
        _result = v0.<init>(); // android.support.v4.c.n.<init> -> void
        v1.c = v0; // android.support.v4.app.ao.c:android.support.v4.c.n
        v1.d = v2; // android.support.v4.app.ao.d:java.lang.String
        v1.e = v3; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        v1.f = v4; // android.support.v4.app.ao.f:boolean
        return;
    }

    private android.support.v4.app.ap c(int p0, android.os.Bundle p1, android.support.v4.app.an p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (android.os.Bundle), v5 = p2 (android.support.v4.app.an)
        v0 = new android.support.v4.app.ap;
        _result = v0.<init>(v2, v3, v4, v5); // android.support.v4.app.ap.<init> -> void
        _result = android.support.v4.app.an.a(v5, v3, v4); // -> android.support.v4.content.f
        v1 = _result;
        v0.d = v1; // android.support.v4.app.ap.d:android.support.v4.content.f
        return v0;
    }

    private android.support.v4.app.ap d(int p0, android.os.Bundle p1, android.support.v4.app.an p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (android.os.Bundle), v5 = p2 (android.support.v4.app.an)
        v1 = 0;
        v0 = 1;
        v2.h = v0; // android.support.v4.app.ao.h:boolean
        _result = v2.c(v3, v4, v5); // android.support.v4.app.ao.c -> android.support.v4.app.ap
        v0 = _result;
        _result = v2.a(v0); // android.support.v4.app.ao.a -> void
        v2.h = v1; // android.support.v4.app.ao.h:boolean
        return v0;
        v0 = _exception;
        v2.h = v1; // android.support.v4.app.ao.h:boolean
        throw v0;
    }

    public android.support.v4.content.f a(int p0, android.os.Bundle p1, android.support.v4.app.an p2) {
        // Registers (8 total): v4 = this, v5 = p0 (int), v6 = p1 (android.os.Bundle), v7 = p2 (android.support.v4.app.an)
        v0 = v4.h; // android.support.v4.app.ao.h:boolean
        if (v0 == 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Called while creating a loader";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v4.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.a(v5); // android.support.v4.c.n.a -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        v1 = android.support.v4.app.ao.a; // :boolean
        if (v1 == 0) /* goto L_003e */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "initLoader in ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": args=";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        if (v0 != 0) /* goto L_0074 */;
        _result = v4.d(v5, v6, v7); // android.support.v4.app.ao.d -> android.support.v4.app.ap
        v0 = _result;
        v1 = android.support.v4.app.ao.a; // :boolean
        if (v1 == 0) /* goto L_0062 */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Created new loader ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v0.e; // android.support.v4.app.ap.e:boolean
        if (v1 == 0) /* goto L_0071 */;
        v1 = v4.f; // android.support.v4.app.ao.f:boolean
        if (v1 == 0) /* goto L_0071 */;
        v1 = v0.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        v2 = v0.g; // android.support.v4.app.ap.g:java.lang.Object
        _result = v0.b(v1, v2); // android.support.v4.app.ap.b -> void
        v0 = v0.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        return v0;
        v1 = android.support.v4.app.ao.a; // :boolean
        if (v1 == 0) /* goto L_0092 */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Re-using existing loader ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v0.c = v7; // android.support.v4.app.ap.c:android.support.v4.app.an
        // goto L_0062
    }

    public void a(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.h; // android.support.v4.app.ao.h:boolean
        if (v0 == 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Called while creating a loader";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_0036 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "destroyLoader in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " of ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v3.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.g(v4); // android.support.v4.c.n.g -> int
        v1 = _result;
        if (v1 < 0) /* goto L_004e */;
        v0 = v3.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.f(v1); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        v2 = v3.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v2.d(v1); // android.support.v4.c.n.d -> void
        _result = v0.f(); // android.support.v4.app.ap.f -> void
        v0 = v3.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v0.g(v4); // android.support.v4.c.n.g -> int
        v1 = _result;
        if (v1 < 0) /* goto L_0066 */;
        v0 = v3.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v0.f(v1); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        v2 = v3.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v2.d(v1); // android.support.v4.c.n.d -> void
        _result = v0.f(); // android.support.v4.app.ap.f -> void
        v0 = v3.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_0077 */;
        _result = v3.a(); // android.support.v4.app.ao.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0077 */;
        v0 = v3.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        v0 = v0.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.e(); // android.support.v4.app.y.e -> void
        return;
    }

    void a(android.support.v4.app.FragmentActivity p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.FragmentActivity)
        v0.e = v1; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        return;
    }

    void a(android.support.v4.app.ap p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.ap)
        v0 = v2.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        v1 = v3.a; // android.support.v4.app.ap.a:int
        _result = v0.b(v1, v3); // android.support.v4.c.n.b -> void
        v0 = v2.f; // android.support.v4.app.ao.f:boolean
        if (v0 == 0) /* goto L_000e */;
        _result = v3.a(); // android.support.v4.app.ap.a -> void
        return;
    }

    public void a(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (10 total): v5 = this, v6 = p0 (java.lang.String), v7 = p1 (java.io.FileDescriptor), v8 = p2 (java.io.PrintWriter), v9 = p3 (java.lang.String[])
        v2 = 0;
        v0 = v5.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_005d */;
        _result = v8.print(v6); // java.io.PrintWriter.print -> void
        v0 = "Active Loaders:";
        _result = v8.println(v0); // java.io.PrintWriter.println -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "    ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v1 = v2;
        v0 = v5.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_005d */;
        v0 = v5.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.f(v1); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        _result = v8.print(v6); // java.io.PrintWriter.print -> void
        v4 = "  #";
        _result = v8.print(v4); // java.io.PrintWriter.print -> void
        v4 = v5.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v4.e(v1); // android.support.v4.c.n.e -> int
        v4 = _result;
        _result = v8.print(v4); // java.io.PrintWriter.print -> void
        v4 = ": ";
        _result = v8.print(v4); // java.io.PrintWriter.print -> void
        _result = v0.toString(); // android.support.v4.app.ap.toString -> java.lang.String
        v4 = _result;
        _result = v8.println(v4); // java.io.PrintWriter.println -> void
        _result = v0.a(v3, v7, v8, v9); // android.support.v4.app.ap.a -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0027
        v0 = v5.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_00b7 */;
        _result = v8.print(v6); // java.io.PrintWriter.print -> void
        v0 = "Inactive Loaders:";
        _result = v8.println(v0); // java.io.PrintWriter.println -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "    ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        v0 = v5.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        if (v2 >= v0) /* goto L_00b7 */;
        v0 = v5.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v0.f(v2); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        _result = v8.print(v6); // java.io.PrintWriter.print -> void
        v3 = "  #";
        _result = v8.print(v3); // java.io.PrintWriter.print -> void
        v3 = v5.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v3.e(v2); // android.support.v4.c.n.e -> int
        v3 = _result;
        _result = v8.print(v3); // java.io.PrintWriter.print -> void
        v3 = ": ";
        _result = v8.print(v3); // java.io.PrintWriter.print -> void
        _result = v0.toString(); // android.support.v4.app.ap.toString -> java.lang.String
        v3 = _result;
        _result = v8.println(v3); // java.io.PrintWriter.println -> void
        _result = v0.a(v1, v7, v8, v9); // android.support.v4.app.ap.a -> void
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_0082
        return;
    }

    public boolean a() {
        // Registers (7 total): v6 = this
        v1 = 0;
        v0 = v6.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v4 = _result;
        v2 = v1;
        v3 = v1;
        if (v2 >= v4) /* goto L_0023 */;
        v0 = v6.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.f(v2); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        v5 = v0.h; // android.support.v4.app.ap.h:boolean
        if (v5 == 0) /* goto L_0021 */;
        v0 = v0.f; // android.support.v4.app.ap.f:boolean
        if (v0 != 0) /* goto L_0021 */;
        v0 = 1;
        v3 = binOp2addr_0xb6(v3, v0);
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0009
        v0 = v1;
        // goto L_001c
        return v3;
    }

    public android.support.v4.content.f b(int p0, android.os.Bundle p1, android.support.v4.app.an p2) {
        // Registers (9 total): v5 = this, v6 = p0 (int), v7 = p1 (android.os.Bundle), v8 = p2 (android.support.v4.app.an)
        v4 = 0;
        v0 = v5.h; // android.support.v4.app.ao.h:boolean
        if (v0 == 0) /* goto L_000e */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Called while creating a loader";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v5.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.a(v6); // android.support.v4.c.n.a -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        v1 = android.support.v4.app.ao.a; // :boolean
        if (v1 == 0) /* goto L_003f */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "restartLoader in ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": args=";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        if (v0 == 0) /* goto L_007d */;
        v1 = v5.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v1.a(v6); // android.support.v4.c.n.a -> java.lang.Object
        v1 = _result;
        v1 = (android.support.v4.app.ap) v1;
        if (v1 == 0) /* goto L_00e1 */;
        v2 = v0.e; // android.support.v4.app.ap.e:boolean
        if (v2 == 0) /* goto L_0084 */;
        v2 = android.support.v4.app.ao.a; // :boolean
        if (v2 == 0) /* goto L_006d */;
        v2 = "LoaderManager";
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "  Removing last inactive loader: ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v2.v(v3); // android.util.Log.v -> int
        v2 = 0;
        v1.f = v2; // android.support.v4.app.ap.f:boolean
        _result = v1.f(); // android.support.v4.app.ap.f -> void
        v1 = v0.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v1.r(); // android.support.v4.content.f.r -> void
        v1 = v5.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v1.b(v6, v0); // android.support.v4.c.n.b -> void
        _result = v5.d(v6, v7, v8); // android.support.v4.app.ao.d -> android.support.v4.app.ap
        v0 = _result;
        v0 = v0.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        return v0;
        v1 = v0.h; // android.support.v4.app.ap.h:boolean
        if (v1 != 0) /* goto L_009e */;
        v1 = android.support.v4.app.ao.a; // :boolean
        if (v1 == 0) /* goto L_0095 */;
        v1 = "LoaderManager";
        v2 = "  Current loader is stopped; replacing";
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v5.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v1.b(v6, v4); // android.support.v4.c.n.b -> void
        _result = v0.f(); // android.support.v4.app.ap.f -> void
        // goto L_007d
        v1 = v0.n; // android.support.v4.app.ap.n:android.support.v4.app.ap
        if (v1 == 0) /* goto L_00c9 */;
        v1 = android.support.v4.app.ao.a; // :boolean
        if (v1 == 0) /* goto L_00c2 */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Removing pending loader: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v0.n; // android.support.v4.app.ap.n:android.support.v4.app.ap
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v0.n; // android.support.v4.app.ap.n:android.support.v4.app.ap
        _result = v1.f(); // android.support.v4.app.ap.f -> void
        v0.n = v4; // android.support.v4.app.ap.n:android.support.v4.app.ap
        v1 = android.support.v4.app.ao.a; // :boolean
        if (v1 == 0) /* goto L_00d6 */;
        v1 = "LoaderManager";
        v2 = "  Enqueuing as new pending loader";
        _result = v1.v(v2); // android.util.Log.v -> int
        _result = v5.c(v6, v7, v8); // android.support.v4.app.ao.c -> android.support.v4.app.ap
        v1 = _result;
        v0.n = v1; // android.support.v4.app.ap.n:android.support.v4.app.ap
        v0 = v0.n; // android.support.v4.app.ap.n:android.support.v4.app.ap
        v0 = v0.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        // goto L_0083
        v1 = android.support.v4.app.ao.a; // :boolean
        if (v1 == 0) /* goto L_00ff */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Making last loader inactive: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v1 = v0.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v1.r(); // android.support.v4.content.f.r -> void
        v1 = v5.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v1.b(v6, v0); // android.support.v4.c.n.b -> void
        // goto L_007d
    }

    void b() {
        // Registers (5 total): v4 = this
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_001e */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Starting in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.f; // android.support.v4.app.ao.f:boolean
        if (v0 == 0) /* goto L_0048 */;
        v0 = new java.lang.RuntimeException;
        v1 = "here";
        _result = v0.<init>(v1); // java.lang.RuntimeException.<init> -> void
        _result = v0.fillInStackTrace(); // java.lang.RuntimeException.fillInStackTrace -> java.lang.Throwable
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Called doStart when already started: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.w(v2, v0); // android.util.Log.w -> int
        return;
        v0 = 1;
        v4.f = v0; // android.support.v4.app.ao.f:boolean
        v0 = v4.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0047 */;
        v0 = v4.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.f(v1); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        _result = v0.a(); // android.support.v4.app.ap.a -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0054
    }

    void c() {
        // Registers (5 total): v4 = this
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_001e */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Stopping in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.f; // android.support.v4.app.ao.f:boolean
        if (v0 != 0) /* goto L_0048 */;
        v0 = new java.lang.RuntimeException;
        v1 = "here";
        _result = v0.<init>(v1); // java.lang.RuntimeException.<init> -> void
        _result = v0.fillInStackTrace(); // java.lang.RuntimeException.fillInStackTrace -> java.lang.Throwable
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Called doStop when not started: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.w(v2, v0); // android.util.Log.w -> int
        return;
        v0 = v4.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0062 */;
        v0 = v4.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.f(v1); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        _result = v0.e(); // android.support.v4.app.ap.e -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0051
        v0 = 0;
        v4.f = v0; // android.support.v4.app.ao.f:boolean
        // goto L_0047
    }

    void d() {
        // Registers (5 total): v4 = this
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_001e */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Retaining in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.f; // android.support.v4.app.ao.f:boolean
        if (v0 != 0) /* goto L_0048 */;
        v0 = new java.lang.RuntimeException;
        v1 = "here";
        _result = v0.<init>(v1); // java.lang.RuntimeException.<init> -> void
        _result = v0.fillInStackTrace(); // java.lang.RuntimeException.fillInStackTrace -> java.lang.Throwable
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Called doRetain when not started: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.w(v2, v0); // android.util.Log.w -> int
        return;
        v0 = 1;
        v4.g = v0; // android.support.v4.app.ao.g:boolean
        v0 = 0;
        v4.f = v0; // android.support.v4.app.ao.f:boolean
        v0 = v4.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0047 */;
        v0 = v4.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.f(v1); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        _result = v0.b(); // android.support.v4.app.ap.b -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0057
    }

    void e() {
        // Registers (4 total): v3 = this
        v0 = v3.g; // android.support.v4.app.ao.g:boolean
        if (v0 == 0) /* goto L_003f */;
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_0022 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Finished Retaining in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = 0;
        v3.g = v0; // android.support.v4.app.ao.g:boolean
        v0 = v3.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_003f */;
        v0 = v3.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.f(v1); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        _result = v0.c(); // android.support.v4.app.ap.c -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_002e
        return;
    }

    void f() {
        // Registers (4 total): v3 = this
        v0 = v3.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_001a */;
        v0 = v3.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.f(v1); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        v2 = 1;
        v0.k = v2; // android.support.v4.app.ap.k:boolean
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0009
        return;
    }

    void g() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_001a */;
        v0 = v2.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.f(v1); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        _result = v0.d(); // android.support.v4.app.ap.d -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0009
        return;
    }

    void h() {
        // Registers (4 total): v3 = this
        v0 = v3.g; // android.support.v4.app.ao.g:boolean
        if (v0 != 0) /* goto L_0041 */;
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_0022 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Destroying Active in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v3.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_003c */;
        v0 = v3.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.f(v1); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        _result = v0.f(); // android.support.v4.app.ap.f -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_002b
        v0 = v3.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        _result = v0.c(); // android.support.v4.c.n.c -> void
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_005f */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Destroying Inactive in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v3.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v0.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_0079 */;
        v0 = v3.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v0.f(v1); // android.support.v4.c.n.f -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        _result = v0.f(); // android.support.v4.app.ap.f -> void
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_0068
        v0 = v3.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        _result = v0.c(); // android.support.v4.c.n.c -> void
        return;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 128;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = "LoaderManager{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v2.identityHashCode(); // java.lang.System.identityHashCode -> int
        v1 = _result;
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = " in ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        _result = v1.a(v0); // android.support.v4.c.d.a -> void
        v1 = "}}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}