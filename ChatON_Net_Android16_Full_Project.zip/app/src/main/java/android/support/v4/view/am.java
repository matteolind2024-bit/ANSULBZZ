package android.support.v4.view;

/**
 * Original SourceFile: PagerTitleStripIcs.java
 * Descriptor: Landroid/support/v4/view/am;
 */
class am {
    public static void a(android.widget.TextView p0) {
        // Registers (3 total): v2 = p0 (android.widget.TextView)
        v0 = new android.support.v4.view.an;
        _result = v2.getContext(); // android.widget.TextView.getContext -> android.content.Context
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.view.an.<init> -> void
        _result = v2.setTransformationMethod(v0); // android.widget.TextView.setTransformationMethod -> void
        return;
    }

}