package android.support.v4.widget;

/**
 * Original SourceFile: EdgeEffectCompat.java
 * Descriptor: Landroid/support/v4/widget/n;
 */
public class n {
    private static final android.support.v4.widget.q b;
    private java.lang.Object a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.widget.p;
        _result = v0.<init>(); // android.support.v4.widget.p.<init> -> void
        android.support.v4.widget.n.b = v0; // :android.support.v4.widget.q
        return;
        v0 = new android.support.v4.widget.o;
        _result = v0.<init>(); // android.support.v4.widget.o.<init> -> void
        android.support.v4.widget.n.b = v0; // :android.support.v4.widget.q
        // goto L_000d
    }

    public n(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = android.support.v4.widget.n.b; // :android.support.v4.widget.q
        _result = android.support.v4.widget.q.a(v0, v2); // -> java.lang.Object
        v0 = _result;
        v1.a = v0; // android.support.v4.widget.n.a:java.lang.Object
        return;
    }

    public void a(int p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (int)
        v0 = android.support.v4.widget.n.b; // :android.support.v4.widget.q
        v1 = v2.a; // android.support.v4.widget.n.a:java.lang.Object
        _result = android.support.v4.widget.q.a(v0, v1, v3, v4); // -> void
        return;
    }

    public boolean a() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.n.b; // :android.support.v4.widget.q
        v1 = v2.a; // android.support.v4.widget.n.a:java.lang.Object
        _result = android.support.v4.widget.q.a(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean a(float p0) {
        // Registers (4 total): v2 = this, v3 = p0 (float)
        v0 = android.support.v4.widget.n.b; // :android.support.v4.widget.q
        v1 = v2.a; // android.support.v4.widget.n.a:java.lang.Object
        _result = android.support.v4.widget.q.a(v0, v1, v3); // -> boolean
        v0 = _result;
        return v0;
    }

    public boolean a(android.graphics.Canvas p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Canvas)
        v0 = android.support.v4.widget.n.b; // :android.support.v4.widget.q
        v1 = v2.a; // android.support.v4.widget.n.a:java.lang.Object
        _result = android.support.v4.widget.q.a(v0, v1, v3); // -> boolean
        v0 = _result;
        return v0;
    }

    public void b() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.n.b; // :android.support.v4.widget.q
        v1 = v2.a; // android.support.v4.widget.n.a:java.lang.Object
        _result = android.support.v4.widget.q.b(v0, v1); // -> void
        return;
    }

    public boolean c() {
        // Registers (3 total): v2 = this
        v0 = android.support.v4.widget.n.b; // :android.support.v4.widget.q
        v1 = v2.a; // android.support.v4.widget.n.a:java.lang.Object
        _result = android.support.v4.widget.q.c(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

}