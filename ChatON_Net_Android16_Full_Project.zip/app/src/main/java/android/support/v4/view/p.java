package android.support.v4.view;

/**
 * Original SourceFile: GravityCompat.java
 * Descriptor: Landroid/support/v4/view/p;
 */
class p implements android.support.v4.view.o {
    p() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int a(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = -8388609; // 0xff7fffff
        v0 = binOp2addr_0xb5(v0, v2);
        return v0;
    }

}