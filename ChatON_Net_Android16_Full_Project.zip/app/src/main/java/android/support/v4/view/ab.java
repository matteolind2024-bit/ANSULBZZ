package android.support.v4.view;

/**
 * Original SourceFile: MotionEventCompat.java
 * Descriptor: Landroid/support/v4/view/ab;
 */
class ab implements android.support.v4.view.ac {
    ab() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int a(android.view.MotionEvent p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.MotionEvent)
        _result = v2.a(); // android.support.v4.view.ad.a -> int
        v0 = _result;
        return v0;
    }

    public int a(android.view.MotionEvent p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MotionEvent), v3 = p1 (int)
        _result = v2.a(v3); // android.support.v4.view.ad.a -> int
        v0 = _result;
        return v0;
    }

    public int b(android.view.MotionEvent p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MotionEvent), v3 = p1 (int)
        _result = v2.b(v3); // android.support.v4.view.ad.b -> int
        v0 = _result;
        return v0;
    }

    public float c(android.view.MotionEvent p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MotionEvent), v3 = p1 (int)
        _result = v2.c(v3); // android.support.v4.view.ad.c -> float
        v0 = _result;
        return v0;
    }

    public float d(android.view.MotionEvent p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.MotionEvent), v3 = p1 (int)
        _result = v2.d(v3); // android.support.v4.view.ad.d -> float
        v0 = _result;
        return v0;
    }

}