package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeInfoCompat.java
 * Descriptor: Landroid/support/v4/view/a/e;
 */
class e extends android.support.v4.view.a.d {
    e() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.a.d.<init> -> void
        return;
    }

    public java.lang.String u(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.a(); // android.support.v4.view.a.j.a -> java.lang.String
        v0 = _result;
        return v0;
    }

}