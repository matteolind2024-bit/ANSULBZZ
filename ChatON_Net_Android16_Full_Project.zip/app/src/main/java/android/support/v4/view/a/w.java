package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeProviderCompatKitKat.java
 * Descriptor: Landroid/support/v4/view/a/w;
 */
interface w {
    public abstract java.lang.Object a(int p0);
    public abstract java.util.List a(java.lang.String p0, int p1);
    public abstract boolean a(int p0, int p1, android.os.Bundle p2);
}