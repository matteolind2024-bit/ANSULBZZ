package android.support.v4.view;

/**
 * Original SourceFile: ViewCompatHC.java
 * Descriptor: Landroid/support/v4/view/bf;
 */
class bf {
    public static int a(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        _result = v1.getLayerType(); // android.view.View.getLayerType -> int
        v0 = _result;
        return v0;
    }

    static long a() {
        _result = this.getFrameDelay(); // android.animation.ValueAnimator.getFrameDelay -> long
        v0 = _result;
        return v0;
    }

    public static void a(android.view.View p0, int p1, android.graphics.Paint p2) {
        // Registers (3 total): v0 = p0 (android.view.View), v1 = p1 (int), v2 = p2 (android.graphics.Paint)
        _result = v0.setLayerType(v1, v2); // android.view.View.setLayerType -> void
        return;
    }

}