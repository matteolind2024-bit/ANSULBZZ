package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityRecordCompat.java
 * Descriptor: Landroid/support/v4/view/a/x;
 */
public class x {
    private static final android.support.v4.view.a.aa a;
    private final java.lang.Object b;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.a.ab;
        _result = v0.<init>(); // android.support.v4.view.a.ab.<init> -> void
        android.support.v4.view.a.x.a = v0; // :android.support.v4.view.a.aa
        return;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 15;
        if (v0 < v1) /* goto L_001c */;
        v0 = new android.support.v4.view.a.z;
        _result = v0.<init>(); // android.support.v4.view.a.z.<init> -> void
        android.support.v4.view.a.x.a = v0; // :android.support.v4.view.a.aa
        // goto L_000d
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 14;
        if (v0 < v1) /* goto L_002a */;
        v0 = new android.support.v4.view.a.y;
        _result = v0.<init>(); // android.support.v4.view.a.y.<init> -> void
        android.support.v4.view.a.x.a = v0; // :android.support.v4.view.a.aa
        // goto L_000d
        v0 = new android.support.v4.view.a.ac;
        _result = v0.<init>(); // android.support.v4.view.a.ac.<init> -> void
        android.support.v4.view.a.x.a = v0; // :android.support.v4.view.a.aa
        // goto L_000d
    }

    public x(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.b = v1; // android.support.v4.view.a.x.b:java.lang.Object
        return;
    }

    public static android.support.v4.view.a.x a() {
        v0 = new android.support.v4.view.a.x;
        v1 = android.support.v4.view.a.x.a; // :android.support.v4.view.a.aa
        _result = android.support.v4.view.a.aa.a(v1); // -> java.lang.Object
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.view.a.x.<init> -> void
        return v0;
    }

    public void a(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.a.x.a; // :android.support.v4.view.a.aa
        v1 = v2.b; // android.support.v4.view.a.x.b:java.lang.Object
        _result = android.support.v4.view.a.aa.b(v0, v1, v3); // -> void
        return;
    }

    public void a(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = android.support.v4.view.a.x.a; // :android.support.v4.view.a.aa
        v1 = v2.b; // android.support.v4.view.a.x.b:java.lang.Object
        _result = android.support.v4.view.a.aa.a(v0, v1, v3); // -> void
        return;
    }

    public void b(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.a.x.a; // :android.support.v4.view.a.aa
        v1 = v2.b; // android.support.v4.view.a.x.b:java.lang.Object
        _result = android.support.v4.view.a.aa.a(v0, v1, v3); // -> void
        return;
    }

    public void c(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = android.support.v4.view.a.x.a; // :android.support.v4.view.a.aa
        v1 = v2.b; // android.support.v4.view.a.x.b:java.lang.Object
        _result = android.support.v4.view.a.aa.c(v0, v1, v3); // -> void
        return;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        if (v5 != 0) /* goto L_0009 */;
        v0 = v1;
        // goto L_0004
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0015 */;
        v0 = v1;
        // goto L_0004
        v5 = (android.support.v4.view.a.x) v5;
        v2 = v4.b; // android.support.v4.view.a.x.b:java.lang.Object
        if (v2 != 0) /* goto L_0021 */;
        v2 = v5.b; // android.support.v4.view.a.x.b:java.lang.Object
        if (v2 == 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v4.b; // android.support.v4.view.a.x.b:java.lang.Object
        v3 = v5.b; // android.support.v4.view.a.x.b:java.lang.Object
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public int hashCode() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.view.a.x.b:java.lang.Object
        if (v0 != 0) /* goto L_0006 */;
        v0 = 0;
        return v0;
        v0 = v1.b; // android.support.v4.view.a.x.b:java.lang.Object
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        // goto L_0005
    }

}