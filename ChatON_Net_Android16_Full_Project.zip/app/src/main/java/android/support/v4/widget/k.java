package android.support.v4.widget;

/**
 * Original SourceFile: DrawerLayout.java
 * Descriptor: Landroid/support/v4/widget/k;
 */
final class k implements android.os.Parcelable$Creator {
    k() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.support.v4.widget.DrawerLayout$SavedState a(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        v0 = new android.support.v4.widget.DrawerLayout$SavedState;
        _result = v0.<init>(v2); // android.support.v4.widget.DrawerLayout$SavedState.<init> -> void
        return v0;
    }

    public android.support.v4.widget.DrawerLayout$SavedState[] a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = new android.support.v4.widget.DrawerLayout$SavedState[][size=v2];
        return v0;
    }

    public java.lang.Object createFromParcel(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        _result = v1.a(v2); // android.support.v4.widget.k.a -> android.support.v4.widget.DrawerLayout$SavedState
        v0 = _result;
        return v0;
    }

    public java.lang.Object[] newArray(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.a(v2); // android.support.v4.widget.k.a -> android.support.v4.widget.DrawerLayout$SavedState[]
        v0 = _result;
        return v0;
    }

}