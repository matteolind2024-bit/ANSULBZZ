package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/az;
 */
class az extends android.support.v4.view.ay {
    az() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.ay.<init> -> void
        return;
    }

    public void a(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (6 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int), v3 = p2 (int), v4 = p3 (int), v5 = p4 (int)
        _result = v1.a(v2, v3, v4, v5); // android.support.v4.view.bh.a -> void
        return;
    }

    public void a(android.view.View p0, java.lang.Runnable p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (java.lang.Runnable)
        _result = v1.a(v2); // android.support.v4.view.bh.a -> void
        return;
    }

    public void b(android.view.View p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.View)
        _result = v1.a(); // android.support.v4.view.bh.a -> void
        return;
    }

    public void b(android.view.View p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int)
        _result = v1.a(v2); // android.support.v4.view.bh.a -> void
        return;
    }

    public int c(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.b(); // android.support.v4.view.bh.b -> int
        v0 = _result;
        return v0;
    }

    public android.view.ViewParent f(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.c(); // android.support.v4.view.bh.c -> android.view.ViewParent
        v0 = _result;
        return v0;
    }

}