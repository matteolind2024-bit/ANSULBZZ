package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/av;
 */
class av extends android.support.v4.view.au {
    av() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.au.<init> -> void
        return;
    }

    public boolean g(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.a(); // android.support.v4.view.bd.a -> boolean
        v0 = _result;
        return v0;
    }

}