package android.support.v4.app;

/**
 * Original SourceFile: FragmentTabHost.java
 * Descriptor: Landroid/support/v4/app/ag;
 */
class ag {
}