package android.support.v4.widget;

/**
 * Original SourceFile: SlidingPaneLayout.java
 * Descriptor: Landroid/support/v4/widget/ak;
 */
class ak extends android.support.v4.widget.aj {
    private java.lang.reflect.Method a;
    private java.lang.reflect.Field b;

    ak() {
        // Registers (4 total): v3 = this
        _result = v3.<init>(); // android.support.v4.widget.aj.<init> -> void
        v1 = android.view.View.class;
        v2 = "getDisplayList";
        v0 = 0;
        v0 = (java.lang.Class[]) v0;
        _result = v1.getDeclaredMethod(v2, v0); // java.lang.Class.getDeclaredMethod -> java.lang.reflect.Method
        v0 = _result;
        v3.a = v0; // android.support.v4.widget.ak.a:java.lang.reflect.Method
        v0 = android.view.View.class;
        v1 = "mRecreateDisplayList";
        _result = v0.getDeclaredField(v1); // java.lang.Class.getDeclaredField -> java.lang.reflect.Field
        v0 = _result;
        v3.b = v0; // android.support.v4.widget.ak.b:java.lang.reflect.Field
        v0 = v3.b; // android.support.v4.widget.ak.b:java.lang.reflect.Field
        v1 = 1;
        _result = v0.setAccessible(v1); // java.lang.reflect.Field.setAccessible -> void
        return;
        v0 = _exception;
        v1 = "SlidingPaneLayout";
        v2 = "Couldn't fetch getDisplayList method; dimming won't work right.";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_0011
        v0 = _exception;
        v1 = "SlidingPaneLayout";
        v2 = "Couldn't fetch mRecreateDisplayList field; dimming will be slow.";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_0022
    }

    public void a(android.support.v4.widget.SlidingPaneLayout p0, android.view.View p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.support.v4.widget.SlidingPaneLayout), v5 = p1 (android.view.View)
        v0 = v3.a; // android.support.v4.widget.ak.a:java.lang.reflect.Method
        if (v0 == 0) /* goto L_0025 */;
        v0 = v3.b; // android.support.v4.widget.ak.b:java.lang.reflect.Field
        if (v0 == 0) /* goto L_0025 */;
        v0 = v3.b; // android.support.v4.widget.ak.b:java.lang.reflect.Field
        v1 = 1;
        _result = v0.setBoolean(v5, v1); // java.lang.reflect.Field.setBoolean -> void
        v1 = v3.a; // android.support.v4.widget.ak.a:java.lang.reflect.Method
        v0 = 0;
        v0 = (java.lang.Object[]) v0;
        _result = v1.invoke(v5, v0); // java.lang.reflect.Method.invoke -> java.lang.Object
        _result = v3.a(v4, v5); // android.support.v4.widget.aj.a -> void
        return;
        v0 = _exception;
        v1 = "SlidingPaneLayout";
        v2 = "Error refreshing display list state";
        _result = v1.e(v2, v0); // android.util.Log.e -> int
        // goto L_0016
        _result = v5.invalidate(); // android.view.View.invalidate -> void
        // goto L_0019
    }

}