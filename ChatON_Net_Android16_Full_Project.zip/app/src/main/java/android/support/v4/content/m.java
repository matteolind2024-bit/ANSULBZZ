package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/m;
 */
abstract class m {
    private static final java.util.concurrent.ThreadFactory a;
    private static final java.util.concurrent.BlockingQueue b;
    private static final android.support.v4.content.s c;
    public static final java.util.concurrent.Executor d;
    private static volatile java.util.concurrent.Executor e;
    private final android.support.v4.content.u f;
    private final java.util.concurrent.FutureTask g;
    private volatile android.support.v4.content.t h;
    private final java.util.concurrent.atomic.AtomicBoolean i;

    static {
        v0 = new android.support.v4.content.n;
        _result = v0.<init>(); // android.support.v4.content.n.<init> -> void
        android.support.v4.content.m.a = v0; // :java.util.concurrent.ThreadFactory
        v0 = new java.util.concurrent.LinkedBlockingQueue;
        v1 = 10;
        _result = v0.<init>(v1); // java.util.concurrent.LinkedBlockingQueue.<init> -> void
        android.support.v4.content.m.b = v0; // :java.util.concurrent.BlockingQueue
        v0 = new java.util.concurrent.ThreadPoolExecutor;
        v1 = 5;
        v2 = 128;
        v3 = 1L;
        v5 = java.util.concurrent.TimeUnit.SECONDS; // :java.util.concurrent.TimeUnit
        v6 = android.support.v4.content.m.b; // :java.util.concurrent.BlockingQueue
        v7 = android.support.v4.content.m.a; // :java.util.concurrent.ThreadFactory
        _result = v0.<init>(v0..v7); // java.util.concurrent.ThreadPoolExecutor.<init> -> void
        android.support.v4.content.m.d = v0; // :java.util.concurrent.Executor
        v0 = new android.support.v4.content.s;
        v1 = 0;
        _result = v0.<init>(v1); // android.support.v4.content.s.<init> -> void
        android.support.v4.content.m.c = v0; // :android.support.v4.content.s
        v0 = android.support.v4.content.m.d; // :java.util.concurrent.Executor
        android.support.v4.content.m.e = v0; // :java.util.concurrent.Executor
        return;
    }

    public m() {
        // Registers (3 total): v2 = this
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v0 = android.support.v4.content.t.a; // :android.support.v4.content.t
        v2.h = v0; // android.support.v4.content.m.h:android.support.v4.content.t
        v0 = new java.util.concurrent.atomic.AtomicBoolean;
        _result = v0.<init>(); // java.util.concurrent.atomic.AtomicBoolean.<init> -> void
        v2.i = v0; // android.support.v4.content.m.i:java.util.concurrent.atomic.AtomicBoolean
        v0 = new android.support.v4.content.o;
        _result = v0.<init>(v2); // android.support.v4.content.o.<init> -> void
        v2.f = v0; // android.support.v4.content.m.f:android.support.v4.content.u
        v0 = new android.support.v4.content.p;
        v1 = v2.f; // android.support.v4.content.m.f:android.support.v4.content.u
        _result = v0.<init>(v2, v1); // android.support.v4.content.p.<init> -> void
        v2.g = v0; // android.support.v4.content.m.g:java.util.concurrent.FutureTask
        return;
    }

    static java.lang.Object a(android.support.v4.content.m p0, java.lang.Object p1) {
        // Registers (3 total): v1 = p0 (android.support.v4.content.m), v2 = p1 (java.lang.Object)
        _result = v1.d(v2); // android.support.v4.content.m.d -> java.lang.Object
        v0 = _result;
        return v0;
    }

    static java.util.concurrent.atomic.AtomicBoolean a(android.support.v4.content.m p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.content.m)
        v0 = v1.i; // android.support.v4.content.m.i:java.util.concurrent.atomic.AtomicBoolean
        return v0;
    }

    static void b(android.support.v4.content.m p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.content.m), v1 = p1 (java.lang.Object)
        _result = v0.c(v1); // android.support.v4.content.m.c -> void
        return;
    }

    static void c(android.support.v4.content.m p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.content.m), v1 = p1 (java.lang.Object)
        _result = v0.e(v1); // android.support.v4.content.m.e -> void
        return;
    }

    private void c(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = v1.i; // android.support.v4.content.m.i:java.util.concurrent.atomic.AtomicBoolean
        _result = v0.get(); // java.util.concurrent.atomic.AtomicBoolean.get -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000b */;
        _result = v1.d(v2); // android.support.v4.content.m.d -> java.lang.Object
        return;
    }

    private java.lang.Object d(java.lang.Object p0) {
        // Registers (7 total): v5 = this, v6 = p0 (java.lang.Object)
        v4 = 1;
        v0 = android.support.v4.content.m.c; // :android.support.v4.content.s
        v1 = new android.support.v4.content.r;
        v2 = new java.lang.Object[][size=v4];
        v3 = 0;
        v2[v3] = v6;
        _result = v1.<init>(v5, v2); // android.support.v4.content.r.<init> -> void
        _result = v0.obtainMessage(v4, v1); // android.support.v4.content.s.obtainMessage -> android.os.Message
        v0 = _result;
        _result = v0.sendToTarget(); // android.os.Message.sendToTarget -> void
        return v6;
    }

    private void e(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v1.c(); // android.support.v4.content.m.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000e */;
        _result = v1.b(v2); // android.support.v4.content.m.b -> void
        v0 = android.support.v4.content.t.c; // :android.support.v4.content.t
        v1.h = v0; // android.support.v4.content.m.h:android.support.v4.content.t
        return;
        _result = v1.a(v2); // android.support.v4.content.m.a -> void
        // goto L_0009
    }

    public final android.support.v4.content.m a(java.util.concurrent.Executor p0, java.lang.Object[] p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.util.concurrent.Executor), v4 = p1 (java.lang.Object[])
        v0 = v2.h; // android.support.v4.content.m.h:android.support.v4.content.t
        v1 = android.support.v4.content.t.a; // :android.support.v4.content.t
        if (v0 == v1) /* goto L_0013 */;
        v0 = android.support.v4.content.q.a; // :int[]
        v1 = v2.h; // android.support.v4.content.m.h:android.support.v4.content.t
        _result = v1.ordinal(); // android.support.v4.content.t.ordinal -> int
        v1 = _result;
        v0 = v0[v1];
        // switch(v0)
        v0 = android.support.v4.content.t.b; // :android.support.v4.content.t
        v2.h = v0; // android.support.v4.content.m.h:android.support.v4.content.t
        _result = v2.b(); // android.support.v4.content.m.b -> void
        v0 = v2.f; // android.support.v4.content.m.f:android.support.v4.content.u
        v0.b = v4; // android.support.v4.content.u.b:java.lang.Object[]
        v0 = v2.g; // android.support.v4.content.m.g:java.util.concurrent.FutureTask
        _result = java.util.concurrent.Executor.execute(v3, v0); // -> void
        return v2;
        v0 = new java.lang.IllegalStateException;
        v1 = "Cannot execute task: the task is already running.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = new java.lang.IllegalStateException;
        v1 = "Cannot execute task: the task has already been executed (a task can be executed only once)";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
    }

    protected abstract java.lang.Object a(java.lang.Object[] p0);
    protected void a() {
        // Registers (1 total): v0 = this
        return;
    }

    protected void a(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        return;
    }

    public final boolean a(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.g; // android.support.v4.content.m.g:java.util.concurrent.FutureTask
        _result = v0.cancel(v2); // java.util.concurrent.FutureTask.cancel -> boolean
        v0 = _result;
        return v0;
    }

    protected void b() {
        // Registers (1 total): v0 = this
        return;
    }

    protected void b(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v0.a(); // android.support.v4.content.m.a -> void
        return;
    }

    protected void b(java.lang.Object[] p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object[])
        return;
    }

    public final boolean c() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // android.support.v4.content.m.g:java.util.concurrent.FutureTask
        _result = v0.isCancelled(); // java.util.concurrent.FutureTask.isCancelled -> boolean
        v0 = _result;
        return v0;
    }

}