package android.support.v4.widget;

/**
 * Original SourceFile: EdgeEffectCompat.java
 * Descriptor: Landroid/support/v4/widget/p;
 */
class p implements android.support.v4.widget.q {
    p() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.lang.Object a(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        _result = v2.a(); // android.support.v4.widget.r.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void a(java.lang.Object p0, int p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int), v3 = p2 (int)
        _result = v1.a(v2, v3); // android.support.v4.widget.r.a -> void
        return;
    }

    public boolean a(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.a(); // android.support.v4.widget.r.a -> boolean
        v0 = _result;
        return v0;
    }

    public boolean a(java.lang.Object p0, float p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (float)
        _result = v2.a(v3); // android.support.v4.widget.r.a -> boolean
        v0 = _result;
        return v0;
    }

    public boolean a(java.lang.Object p0, android.graphics.Canvas p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.graphics.Canvas)
        _result = v2.a(v3); // android.support.v4.widget.r.a -> boolean
        v0 = _result;
        return v0;
    }

    public void b(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v1.b(); // android.support.v4.widget.r.b -> void
        return;
    }

    public boolean c(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.c(); // android.support.v4.widget.r.c -> boolean
        v0 = _result;
        return v0;
    }

}