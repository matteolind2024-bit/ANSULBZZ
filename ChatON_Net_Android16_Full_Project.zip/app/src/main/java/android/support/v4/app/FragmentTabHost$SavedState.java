package android.support.v4.app;

/**
 * Original SourceFile: FragmentTabHost.java
 * Descriptor: Landroid/support/v4/app/FragmentTabHost$SavedState;
 */
class FragmentTabHost$SavedState extends android.view.View$BaseSavedState {
    public static final android.os.Parcelable$Creator CREATOR;
     java.lang.String curTab;

    static {
        v0 = new android.support.v4.app.ah;
        _result = v0.<init>(); // android.support.v4.app.ah.<init> -> void
        android.support.v4.app.FragmentTabHost$SavedState.CREATOR = v0; // :android.os.Parcelable$Creator
        return;
    }

    private FragmentTabHost$SavedState(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        _result = v1.<init>(v2); // android.view.View$BaseSavedState.<init> -> void
        _result = v2.readString(); // android.os.Parcel.readString -> java.lang.String
        v0 = _result;
        v1.curTab = v0; // android.support.v4.app.FragmentTabHost$SavedState.curTab:java.lang.String
        return;
    }

    FragmentTabHost$SavedState(android.os.Parcel p0, android.support.v4.app.ag p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.os.Parcel), v2 = p1 (android.support.v4.app.ag)
        _result = v0.<init>(v1); // android.support.v4.app.FragmentTabHost$SavedState.<init> -> void
        return;
    }

    FragmentTabHost$SavedState(android.os.Parcelable p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.Parcelable)
        _result = v0.<init>(v1); // android.view.View$BaseSavedState.<init> -> void
        return;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "FragmentTabHost.SavedState{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.identityHashCode(); // java.lang.System.identityHashCode -> int
        v1 = _result;
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " curTab=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.curTab; // android.support.v4.app.FragmentTabHost$SavedState.curTab:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void writeToParcel(android.os.Parcel p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.os.Parcel), v3 = p1 (int)
        _result = v1.writeToParcel(v2, v3); // android.view.View$BaseSavedState.writeToParcel -> void
        v0 = v1.curTab; // android.support.v4.app.FragmentTabHost$SavedState.curTab:java.lang.String
        _result = v2.writeString(v0); // android.os.Parcel.writeString -> void
        return;
    }

}