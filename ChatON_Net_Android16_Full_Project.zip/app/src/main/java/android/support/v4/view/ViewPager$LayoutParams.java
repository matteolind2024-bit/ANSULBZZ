package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/ViewPager$LayoutParams;
 */
public class ViewPager$LayoutParams extends android.view.ViewGroup$LayoutParams {
    public boolean a;
    public int b;
     float c;
     boolean d;
     int e;
     int f;

    public ViewPager$LayoutParams() {
        // Registers (2 total): v1 = this
        v0 = -1;
        _result = v1.<init>(v0, v0); // android.view.ViewGroup$LayoutParams.<init> -> void
        v0 = 0;
        v1.c = v0; // android.support.v4.view.ViewPager$LayoutParams.c:float
        return;
    }

    public ViewPager$LayoutParams(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.util.AttributeSet)
        _result = v3.<init>(v4, v5); // android.view.ViewGroup$LayoutParams.<init> -> void
        v0 = 0;
        v3.c = v0; // android.support.v4.view.ViewPager$LayoutParams.c:float
        _result = this.h(); // android.support.v4.view.ViewPager.h -> int[]
        v0 = _result;
        _result = v4.obtainStyledAttributes(v5, v0); // android.content.Context.obtainStyledAttributes -> android.content.res.TypedArray
        v0 = _result;
        v1 = 0;
        v2 = 48;
        _result = v0.getInteger(v1, v2); // android.content.res.TypedArray.getInteger -> int
        v1 = _result;
        v3.b = v1; // android.support.v4.view.ViewPager$LayoutParams.b:int
        _result = v0.recycle(); // android.content.res.TypedArray.recycle -> void
        return;
    }

}