package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompat.java
 * Descriptor: Landroid/support/v4/view/bo;
 */
public class bo {
    static final android.support.v4.view.br a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 18;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.bs;
        _result = v0.<init>(); // android.support.v4.view.bs.<init> -> void
        android.support.v4.view.bo.a = v0; // :android.support.v4.view.br
        return;
        v1 = 14;
        if (v0 < v1) /* goto L_001a */;
        v0 = new android.support.v4.view.bq;
        _result = v0.<init>(); // android.support.v4.view.bq.<init> -> void
        android.support.v4.view.bo.a = v0; // :android.support.v4.view.br
        // goto L_000d
        v1 = 11;
        if (v0 < v1) /* goto L_0026 */;
        v0 = new android.support.v4.view.bp;
        _result = v0.<init>(); // android.support.v4.view.bp.<init> -> void
        android.support.v4.view.bo.a = v0; // :android.support.v4.view.br
        // goto L_000d
        v0 = new android.support.v4.view.bt;
        _result = v0.<init>(); // android.support.v4.view.bt.<init> -> void
        android.support.v4.view.bo.a = v0; // :android.support.v4.view.br
        // goto L_000d
    }

    public static void a(android.view.ViewGroup p0, boolean p1) {
        // Registers (3 total): v1 = p0 (android.view.ViewGroup), v2 = p1 (boolean)
        v0 = android.support.v4.view.bo.a; // :android.support.v4.view.br
        _result = android.support.v4.view.br.a(v0, v1, v2); // -> void
        return;
    }

}