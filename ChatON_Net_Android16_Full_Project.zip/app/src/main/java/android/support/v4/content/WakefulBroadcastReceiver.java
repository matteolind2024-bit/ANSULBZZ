package android.support.v4.content;

/**
 * Original SourceFile: WakefulBroadcastReceiver.java
 * Descriptor: Landroid/support/v4/content/WakefulBroadcastReceiver;
 */
public abstract class WakefulBroadcastReceiver extends android.content.BroadcastReceiver {
    private static final android.util.SparseArray a;
    private static int b;

    static {
        v0 = new android.util.SparseArray;
        _result = v0.<init>(); // android.util.SparseArray.<init> -> void
        android.support.v4.content.WakefulBroadcastReceiver.a = v0; // :android.util.SparseArray
        v0 = 1;
        android.support.v4.content.WakefulBroadcastReceiver.b = v0; // :int
        return;
    }

    public WakefulBroadcastReceiver() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.content.BroadcastReceiver.<init> -> void
        return;
    }

}