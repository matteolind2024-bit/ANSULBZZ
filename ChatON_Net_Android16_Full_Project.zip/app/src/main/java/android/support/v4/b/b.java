package android.support.v4.b;

/**
 * Original SourceFile: ParcelableCompat.java
 * Descriptor: Landroid/support/v4/b/b;
 */
class b implements android.os.Parcelable$Creator {
    final android.support.v4.b.c a;

    public b(android.support.v4.b.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.b.c)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // android.support.v4.b.b.a:android.support.v4.b.c
        return;
    }

    public java.lang.Object createFromParcel(android.os.Parcel p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Parcel)
        v0 = v2.a; // android.support.v4.b.b.a:android.support.v4.b.c
        v1 = 0;
        _result = android.support.v4.b.c.a(v0, v3, v1); // -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object[] newArray(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // android.support.v4.b.b.a:android.support.v4.b.c
        _result = android.support.v4.b.c.a(v0, v2); // -> java.lang.Object[]
        v0 = _result;
        return v0;
    }

}