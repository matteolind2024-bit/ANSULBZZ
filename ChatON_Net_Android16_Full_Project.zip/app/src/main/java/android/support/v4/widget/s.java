package android.support.v4.widget;

/**
 * Original SourceFile: ResourceCursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/s;
 */
public abstract class s extends android.support.v4.widget.c {
    private int j;
    private int k;
    private android.view.LayoutInflater l;

    public s(android.content.Context p0, int p1, android.database.Cursor p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (int), v4 = p2 (android.database.Cursor)
        _result = v1.<init>(v2, v4); // android.support.v4.widget.c.<init> -> void
        v1.k = v3; // android.support.v4.widget.s.k:int
        v1.j = v3; // android.support.v4.widget.s.j:int
        v0 = "layout_inflater";
        _result = v2.getSystemService(v0); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        v1.l = v0; // android.support.v4.widget.s.l:android.view.LayoutInflater
        return;
    }

    public s(android.content.Context p0, int p1, android.database.Cursor p2, int p3) {
        // Registers (6 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (int), v4 = p2 (android.database.Cursor), v5 = p3 (int)
        _result = v1.<init>(v2, v4, v5); // android.support.v4.widget.c.<init> -> void
        v1.k = v3; // android.support.v4.widget.s.k:int
        v1.j = v3; // android.support.v4.widget.s.j:int
        v0 = "layout_inflater";
        _result = v2.getSystemService(v0); // android.content.Context.getSystemService -> java.lang.Object
        v0 = _result;
        v0 = (android.view.LayoutInflater) v0;
        v1.l = v0; // android.support.v4.widget.s.l:android.view.LayoutInflater
        return;
    }

    public android.view.View a(android.content.Context p0, android.database.Cursor p1, android.view.ViewGroup p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.database.Cursor), v6 = p2 (android.view.ViewGroup)
        v0 = v3.l; // android.support.v4.widget.s.l:android.view.LayoutInflater
        v1 = v3.j; // android.support.v4.widget.s.j:int
        v2 = 0;
        _result = v0.inflate(v1, v6, v2); // android.view.LayoutInflater.inflate -> android.view.View
        v0 = _result;
        return v0;
    }

    public android.view.View b(android.content.Context p0, android.database.Cursor p1, android.view.ViewGroup p2) {
        // Registers (7 total): v3 = this, v4 = p0 (android.content.Context), v5 = p1 (android.database.Cursor), v6 = p2 (android.view.ViewGroup)
        v0 = v3.l; // android.support.v4.widget.s.l:android.view.LayoutInflater
        v1 = v3.k; // android.support.v4.widget.s.k:int
        v2 = 0;
        _result = v0.inflate(v1, v6, v2); // android.view.LayoutInflater.inflate -> android.view.View
        v0 = _result;
        return v0;
    }

}