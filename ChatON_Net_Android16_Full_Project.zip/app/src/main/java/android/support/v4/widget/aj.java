package android.support.v4.widget;

/**
 * Original SourceFile: SlidingPaneLayout.java
 * Descriptor: Landroid/support/v4/widget/aj;
 */
class aj implements android.support.v4.widget.ai {
    aj() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void a(android.support.v4.widget.SlidingPaneLayout p0, android.view.View p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.support.v4.widget.SlidingPaneLayout), v6 = p1 (android.view.View)
        _result = v6.getLeft(); // android.view.View.getLeft -> int
        v0 = _result;
        _result = v6.getTop(); // android.view.View.getTop -> int
        v1 = _result;
        _result = v6.getRight(); // android.view.View.getRight -> int
        v2 = _result;
        _result = v6.getBottom(); // android.view.View.getBottom -> int
        v3 = _result;
        _result = v5.a(v0, v1, v2, v3); // android.support.v4.view.at.a -> void
        return;
    }

}