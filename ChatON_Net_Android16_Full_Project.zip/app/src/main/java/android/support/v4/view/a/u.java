package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeProviderCompatKitKat.java
 * Descriptor: Landroid/support/v4/view/a/u;
 */
class u {
    public static java.lang.Object a(android.support.v4.view.a.w p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.view.a.w)
        v0 = new android.support.v4.view.a.v;
        _result = v0.<init>(v1); // android.support.v4.view.a.v.<init> -> void
        return v0;
    }

}