package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityRecordCompatIcs.java
 * Descriptor: Landroid/support/v4/view/a/ad;
 */
class ad {
    public static java.lang.Object a() {
        _result = this.obtain(); // android.view.accessibility.AccessibilityRecord.obtain -> android.view.accessibility.AccessibilityRecord
        v0 = _result;
        return v0;
    }

    public static void a(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setFromIndex(v1); // android.view.accessibility.AccessibilityRecord.setFromIndex -> void
        return;
    }

    public static void a(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setScrollable(v1); // android.view.accessibility.AccessibilityRecord.setScrollable -> void
        return;
    }

    public static void b(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setItemCount(v1); // android.view.accessibility.AccessibilityRecord.setItemCount -> void
        return;
    }

    public static void c(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityRecord) v0;
        _result = v0.setToIndex(v1); // android.view.accessibility.AccessibilityRecord.setToIndex -> void
        return;
    }

}