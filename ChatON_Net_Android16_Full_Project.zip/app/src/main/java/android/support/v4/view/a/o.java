package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeProviderCompat.java
 * Descriptor: Landroid/support/v4/view/a/o;
 */
class o extends android.support.v4.view.a.q {
    o() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.a.q.<init> -> void
        return;
    }

    public java.lang.Object a(android.support.v4.view.a.k p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.a.k)
        v0 = new android.support.v4.view.a.p;
        _result = v0.<init>(v1, v2); // android.support.v4.view.a.p.<init> -> void
        _result = v0.a(); // android.support.v4.view.a.u.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

}