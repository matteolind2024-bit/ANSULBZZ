package android.support.v4.view;

/**
 * Original SourceFile: KeyEventCompat.java
 * Descriptor: Landroid/support/v4/view/s;
 */
public class s {
    static final android.support.v4.view.w a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.v;
        _result = v0.<init>(); // android.support.v4.view.v.<init> -> void
        android.support.v4.view.s.a = v0; // :android.support.v4.view.w
        return;
        v0 = new android.support.v4.view.t;
        _result = v0.<init>(); // android.support.v4.view.t.<init> -> void
        android.support.v4.view.s.a = v0; // :android.support.v4.view.w
        // goto L_000d
    }

    public static boolean a(android.view.KeyEvent p0) {
        // Registers (3 total): v2 = p0 (android.view.KeyEvent)
        v0 = android.support.v4.view.s.a; // :android.support.v4.view.w
        _result = v2.getMetaState(); // android.view.KeyEvent.getMetaState -> int
        v1 = _result;
        _result = android.support.v4.view.w.b(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean a(android.view.KeyEvent p0, int p1) {
        // Registers (4 total): v2 = p0 (android.view.KeyEvent), v3 = p1 (int)
        v0 = android.support.v4.view.s.a; // :android.support.v4.view.w
        _result = v2.getMetaState(); // android.view.KeyEvent.getMetaState -> int
        v1 = _result;
        _result = android.support.v4.view.w.a(v0, v1, v3); // -> boolean
        v0 = _result;
        return v0;
    }

    public static void b(android.view.KeyEvent p0) {
        // Registers (2 total): v1 = p0 (android.view.KeyEvent)
        v0 = android.support.v4.view.s.a; // :android.support.v4.view.w
        _result = android.support.v4.view.w.a(v0, v1); // -> void
        return;
    }

}