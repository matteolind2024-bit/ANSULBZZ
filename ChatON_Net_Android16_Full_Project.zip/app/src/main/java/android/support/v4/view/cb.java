package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/cb;
 */
interface cb {
    public abstract void a(android.support.v4.view.ae p0, android.support.v4.view.ae p1);
}