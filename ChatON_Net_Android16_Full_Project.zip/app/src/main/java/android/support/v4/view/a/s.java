package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeProviderCompatJellyBean.java
 * Descriptor: Landroid/support/v4/view/a/s;
 */
final class s extends android.view.accessibility.AccessibilityNodeProvider {
    final android.support.v4.view.a.t a;

    s(android.support.v4.view.a.t p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.a.t)
        v0.a = v1; // android.support.v4.view.a.s.a:android.support.v4.view.a.t
        _result = v0.<init>(); // android.view.accessibility.AccessibilityNodeProvider.<init> -> void
        return;
    }

    public android.view.accessibility.AccessibilityNodeInfo createAccessibilityNodeInfo(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // android.support.v4.view.a.s.a:android.support.v4.view.a.t
        _result = android.support.v4.view.a.t.a(v0, v2); // -> java.lang.Object
        v0 = _result;
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        return v0;
    }

    public java.util.List findAccessibilityNodeInfosByText(java.lang.String p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (int)
        v0 = v1.a; // android.support.v4.view.a.s.a:android.support.v4.view.a.t
        _result = android.support.v4.view.a.t.a(v0, v2, v3); // -> java.util.List
        v0 = _result;
        return v0;
    }

    public boolean performAction(int p0, int p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (int), v4 = p2 (android.os.Bundle)
        v0 = v1.a; // android.support.v4.view.a.s.a:android.support.v4.view.a.t
        _result = android.support.v4.view.a.t.a(v0, v2, v3, v4); // -> boolean
        v0 = _result;
        return v0;
    }

}