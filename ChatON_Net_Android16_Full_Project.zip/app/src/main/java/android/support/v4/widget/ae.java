package android.support.v4.widget;

/**
 * Original SourceFile: SlidingPaneLayout.java
 * Descriptor: Landroid/support/v4/widget/ae;
 */
class ae implements java.lang.Runnable {
    final android.view.View a;
    final android.support.v4.widget.SlidingPaneLayout b;

    ae(android.support.v4.widget.SlidingPaneLayout p0, android.view.View p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.widget.SlidingPaneLayout), v2 = p1 (android.view.View)
        v0.b = v1; // android.support.v4.widget.ae.b:android.support.v4.widget.SlidingPaneLayout
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v2; // android.support.v4.widget.ae.a:android.view.View
        return;
    }

    public void run() {
        // Registers (4 total): v3 = this
        v0 = v3.a; // android.support.v4.widget.ae.a:android.view.View
        _result = v0.getParent(); // android.view.View.getParent -> android.view.ViewParent
        v0 = _result;
        v1 = v3.b; // android.support.v4.widget.ae.b:android.support.v4.widget.SlidingPaneLayout
        if (v0 != v1) /* goto L_0018 */;
        v0 = v3.a; // android.support.v4.widget.ae.a:android.view.View
        v1 = 0;
        v2 = 0;
        _result = v0.a(v1, v2); // android.support.v4.view.at.a -> void
        v0 = v3.b; // android.support.v4.widget.ae.b:android.support.v4.widget.SlidingPaneLayout
        v1 = v3.a; // android.support.v4.widget.ae.a:android.view.View
        _result = v0.a(v1); // android.support.v4.widget.SlidingPaneLayout.a -> void
        v0 = v3.b; // android.support.v4.widget.ae.b:android.support.v4.widget.SlidingPaneLayout
        _result = v0.f(); // android.support.v4.widget.SlidingPaneLayout.f -> java.util.ArrayList
        v0 = _result;
        _result = v0.remove(v3); // java.util.ArrayList.remove -> boolean
        return;
    }

}