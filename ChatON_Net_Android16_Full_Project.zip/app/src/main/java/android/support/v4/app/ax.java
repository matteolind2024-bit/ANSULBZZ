package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/ax;
 */
interface ax {
    public abstract android.app.Notification a(android.support.v4.app.av p0);
}