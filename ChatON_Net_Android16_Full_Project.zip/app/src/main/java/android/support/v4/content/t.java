package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/t;
 */
public final enum t {
    public static final android.support.v4.content.t a;
    public static final android.support.v4.content.t b;
    public static final android.support.v4.content.t c;
    private static final android.support.v4.content.t[] d;

    static {
        v4 = 2;
        v3 = 1;
        v2 = 0;
        v0 = new android.support.v4.content.t;
        v1 = "PENDING";
        _result = v0.<init>(v1, v2); // android.support.v4.content.t.<init> -> void
        android.support.v4.content.t.a = v0; // :android.support.v4.content.t
        v0 = new android.support.v4.content.t;
        v1 = "RUNNING";
        _result = v0.<init>(v1, v3); // android.support.v4.content.t.<init> -> void
        android.support.v4.content.t.b = v0; // :android.support.v4.content.t
        v0 = new android.support.v4.content.t;
        v1 = "FINISHED";
        _result = v0.<init>(v1, v4); // android.support.v4.content.t.<init> -> void
        android.support.v4.content.t.c = v0; // :android.support.v4.content.t
        v0 = 3;
        v0 = new android.support.v4.content.t[][size=v0];
        v1 = android.support.v4.content.t.a; // :android.support.v4.content.t
        v0[v2] = v1;
        v1 = android.support.v4.content.t.b; // :android.support.v4.content.t
        v0[v3] = v1;
        v1 = android.support.v4.content.t.c; // :android.support.v4.content.t
        v0[v4] = v1;
        android.support.v4.content.t.d = v0; // :android.support.v4.content.t[]
        return;
    }

    private t(java.lang.String p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        return;
    }

    public static android.support.v4.content.t valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = android.support.v4.content.t.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (android.support.v4.content.t) v0;
        return v0;
    }

    public static android.support.v4.content.t[] values() {
        v0 = android.support.v4.content.t.d; // :android.support.v4.content.t[]
        _result = v0.clone(); // android.support.v4.content.t[].clone -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.content.t[]) v0;
        return v0;
    }

}