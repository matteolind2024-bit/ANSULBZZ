package android.support.v4.c;

/**
 * Original SourceFile: ContainerHelpers.java
 * Descriptor: Landroid/support/v4/c/c;
 */
class c {
    static final int[] a;
    static final long[] b;
    static final java.lang.Object[] c;

    static {
        v1 = 0;
        v0 = new int[][size=v1];
        android.support.v4.c.c.a = v0; // :int[]
        v0 = new long[][size=v1];
        android.support.v4.c.c.b = v0; // :long[]
        v0 = new java.lang.Object[][size=v1];
        android.support.v4.c.c.c = v0; // :java.lang.Object[]
        return;
    }

    public static int a(int p0) {
        // Registers (2 total): v1 = p0 (int)
        v0 = binOpLit8_0xda(v1, 4);
        _result = v0.b(); // android.support.v4.c.c.b -> int
        v0 = _result;
        v0 = binOpLit8_0xdb(v0, 4);
        return v0;
    }

    static int a(int[] p0, int p1, int p2) {
        // Registers (7 total): v4 = p0 (int[]), v5 = p1 (int), v6 = p2 (int)
        v1 = 0;
        v0 = binOpLit8_0xd8(v5, -1);
        if (v1 > v0) /* goto L_0017 */;
        v2 = binOp_0x90(v1, v0);
        v2 = binOpLit8_0xe2(v2, 1);
        v3 = v4[v2];
        if (v3 >= v6) /* goto L_0010 */;
        v1 = binOpLit8_0xd8(v2, 1);
        // goto L_0003
        if (v3 <= v6) /* goto L_0015 */;
        v0 = binOpLit8_0xd8(v2, -1);
        // goto L_0003
        v0 = v2;
        return v0;
        v0 = binOpLit8_0xdf(v1, -1);
        // goto L_0016
    }

    public static boolean a(java.lang.Object p0, java.lang.Object p1) {
        // Registers (3 total): v1 = p0 (java.lang.Object), v2 = p1 (java.lang.Object)
        if (v1 == v2) /* goto L_000a */;
        if (v1 == 0) /* goto L_000c */;
        _result = v1.equals(v2); // java.lang.Object.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000c */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000b
    }

    public static int b(int p0) {
        // Registers (4 total): v3 = p0 (int)
        v2 = 1;
        v0 = 4;
        v1 = 32;
        if (v0 >= v1) /* goto L_0010 */;
        v1 = binOp_0x98(v2, v0);
        v1 = binOpLit8_0xd8(v1, -12);
        if (v3 > v1) /* goto L_0011 */;
        v0 = binOp_0x98(v2, v0);
        v3 = binOpLit8_0xd8(v0, -12);
        return v3;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0002
    }

}