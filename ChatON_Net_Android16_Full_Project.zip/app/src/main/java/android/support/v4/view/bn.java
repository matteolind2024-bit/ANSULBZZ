package android.support.v4.view;

/**
 * Original SourceFile: ViewConfigurationCompatFroyo.java
 * Descriptor: Landroid/support/v4/view/bn;
 */
class bn {
    public static int a(android.view.ViewConfiguration p0) {
        // Registers (2 total): v1 = p0 (android.view.ViewConfiguration)
        _result = v1.getScaledPagingTouchSlop(); // android.view.ViewConfiguration.getScaledPagingTouchSlop -> int
        v0 = _result;
        return v0;
    }

}