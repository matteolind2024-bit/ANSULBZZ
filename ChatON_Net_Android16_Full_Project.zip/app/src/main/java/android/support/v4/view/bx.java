package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/bx;
 */
class bx implements java.lang.Runnable {
    final android.support.v4.view.ViewPager a;

    bx(android.support.v4.view.ViewPager p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.ViewPager)
        v0.a = v1; // android.support.v4.view.bx.a:android.support.v4.view.ViewPager
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // android.support.v4.view.bx.a:android.support.v4.view.ViewPager
        v1 = 0;
        _result = v0.a(v1); // android.support.v4.view.ViewPager.a -> void
        v0 = v2.a; // android.support.v4.view.bx.a:android.support.v4.view.ViewPager
        _result = v0.e(); // android.support.v4.view.ViewPager.e -> void
        return;
    }

}