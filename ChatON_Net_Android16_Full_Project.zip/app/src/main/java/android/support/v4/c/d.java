package android.support.v4.c;

/**
 * Original SourceFile: DebugUtils.java
 * Descriptor: Landroid/support/v4/c/d;
 */
public class d {
    public static void a(java.lang.Object p0, java.lang.StringBuilder p1) {
        // Registers (4 total): v2 = p0 (java.lang.Object), v3 = p1 (java.lang.StringBuilder)
        if (v2 != 0) /* goto L_0009 */;
        v0 = "null";
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        return;
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getSimpleName(); // java.lang.Class.getSimpleName -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0019 */;
        _result = v0.length(); // java.lang.String.length -> int
        v1 = _result;
        if (v1 > 0) /* goto L_002f */;
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getName(); // java.lang.Class.getName -> java.lang.String
        v0 = _result;
        v1 = 46;
        _result = v0.lastIndexOf(v1); // java.lang.String.lastIndexOf -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_002f */;
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v0.substring(v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = 123;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v2.identityHashCode(); // java.lang.System.identityHashCode -> int
        v0 = _result;
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0008
    }

}