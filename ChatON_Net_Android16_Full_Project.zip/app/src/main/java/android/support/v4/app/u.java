package android.support.v4.app;

/**
 * Original SourceFile: FragmentActivity.java
 * Descriptor: Landroid/support/v4/app/u;
 */
final class u {
     java.lang.Object a;
     java.lang.Object b;
     android.support.v4.c.m c;
     java.util.ArrayList d;
     android.support.v4.c.m e;

    u() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}