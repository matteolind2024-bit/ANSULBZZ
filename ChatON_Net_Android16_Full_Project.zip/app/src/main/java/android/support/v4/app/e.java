package android.support.v4.app;

/**
 * Original SourceFile: ActionBarDrawerToggle.java
 * Descriptor: Landroid/support/v4/app/e;
 */
class e implements android.support.v4.app.c {
    private e() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    e(android.support.v4.app.b p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.b)
        _result = v0.<init>(); // android.support.v4.app.e.<init> -> void
        return;
    }

    public android.graphics.drawable.Drawable a(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        _result = v2.a(); // android.support.v4.app.i.a -> android.graphics.drawable.Drawable
        v0 = _result;
        return v0;
    }

    public java.lang.Object a(java.lang.Object p0, android.app.Activity p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.app.Activity), v4 = p2 (int)
        _result = v2.a(v3, v4); // android.support.v4.app.i.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

}