package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeInfoCompatJellybeanMr2.java
 * Descriptor: Landroid/support/v4/view/a/j;
 */
class j {
    public static java.lang.String a(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getViewIdResourceName(); // android.view.accessibility.AccessibilityNodeInfo.getViewIdResourceName -> java.lang.String
        v0 = _result;
        return v0;
    }

}