package android.support.v4.app;

/**
 * Original SourceFile: LoaderManager.java
 * Descriptor: Landroid/support/v4/app/am;
 */
public abstract class am {
    public am() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public abstract android.support.v4.content.f a(int p0, android.os.Bundle p1, android.support.v4.app.an p2);
    public abstract void a(int p0);
    public boolean a() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public abstract android.support.v4.content.f b(int p0, android.os.Bundle p1, android.support.v4.app.an p2);
}