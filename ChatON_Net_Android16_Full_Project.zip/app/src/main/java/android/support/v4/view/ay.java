package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/ay;
 */
class ay extends android.support.v4.view.ax {
    ay() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.ax.<init> -> void
        return;
    }

    public void a(android.view.View p0, android.support.v4.view.a p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.support.v4.view.a)
        _result = v3.a(); // android.support.v4.view.a.a -> java.lang.Object
        v0 = _result;
        _result = v2.a(v0); // android.support.v4.view.bg.a -> void
        return;
    }

    public boolean a(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        _result = v2.a(v3); // android.support.v4.view.bg.a -> boolean
        v0 = _result;
        return v0;
    }

}