package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompatIceCreamSandwich.java
 * Descriptor: Landroid/support/v4/app/be;
 */
class be {
    static android.app.Notification a(android.content.Context p0, android.app.Notification p1, java.lang.CharSequence p2, java.lang.CharSequence p3, java.lang.CharSequence p4, android.widget.RemoteViews p5, int p6, android.app.PendingIntent p7, android.app.PendingIntent p8, android.graphics.Bitmap p9, int p10, int p11, boolean p12) {
        // Registers (20 total): v7 = p0 (android.content.Context), v8 = p1 (android.app.Notification), v9 = p2 (java.lang.CharSequence), v10 = p3 (java.lang.CharSequence), v11 = p4 (java.lang.CharSequence), v12 = p5 (android.widget.RemoteViews), v13 = p6 (int), v14 = p7 (android.app.PendingIntent), v15 = p8 (android.app.PendingIntent), v16 = p9 (android.graphics.Bitmap), v17 = p10 (int), v18 = p11 (int), v19 = p12 (boolean)
        v3 = new android.app.Notification$Builder;
        _result = v3.<init>(v7); // android.app.Notification$Builder.<init> -> void
        v4 = v8.when; // android.app.Notification.when:long
        _result = v3.setWhen(v4, v5); // android.app.Notification$Builder.setWhen -> android.app.Notification$Builder
        v3 = _result;
        v4 = v8.icon; // android.app.Notification.icon:int
        v5 = v8.iconLevel; // android.app.Notification.iconLevel:int
        _result = v3.setSmallIcon(v4, v5); // android.app.Notification$Builder.setSmallIcon -> android.app.Notification$Builder
        v3 = _result;
        v4 = v8.contentView; // android.app.Notification.contentView:android.widget.RemoteViews
        _result = v3.setContent(v4); // android.app.Notification$Builder.setContent -> android.app.Notification$Builder
        v3 = _result;
        v4 = v8.tickerText; // android.app.Notification.tickerText:java.lang.CharSequence
        _result = v3.setTicker(v4, v12); // android.app.Notification$Builder.setTicker -> android.app.Notification$Builder
        v3 = _result;
        v4 = v8.sound; // android.app.Notification.sound:android.net.Uri
        v5 = v8.audioStreamType; // android.app.Notification.audioStreamType:int
        _result = v3.setSound(v4, v5); // android.app.Notification$Builder.setSound -> android.app.Notification$Builder
        v3 = _result;
        v4 = v8.vibrate; // android.app.Notification.vibrate:long[]
        _result = v3.setVibrate(v4); // android.app.Notification$Builder.setVibrate -> android.app.Notification$Builder
        v3 = _result;
        v4 = v8.ledARGB; // android.app.Notification.ledARGB:int
        v5 = v8.ledOnMS; // android.app.Notification.ledOnMS:int
        v6 = v8.ledOffMS; // android.app.Notification.ledOffMS:int
        _result = v3.setLights(v4, v5, v6); // android.app.Notification$Builder.setLights -> android.app.Notification$Builder
        v4 = _result;
        v3 = v8.flags; // android.app.Notification.flags:int
        v3 = binOpLit8_0xdd(v3, 2);
        if (v3 == 0) /* goto L_0098 */;
        v3 = 1;
        _result = v4.setOngoing(v3); // android.app.Notification$Builder.setOngoing -> android.app.Notification$Builder
        v4 = _result;
        v3 = v8.flags; // android.app.Notification.flags:int
        v3 = binOpLit8_0xdd(v3, 8);
        if (v3 == 0) /* goto L_009a */;
        v3 = 1;
        _result = v4.setOnlyAlertOnce(v3); // android.app.Notification$Builder.setOnlyAlertOnce -> android.app.Notification$Builder
        v4 = _result;
        v3 = v8.flags; // android.app.Notification.flags:int
        v3 = binOpLit8_0xdd(v3, 16);
        if (v3 == 0) /* goto L_009c */;
        v3 = 1;
        _result = v4.setAutoCancel(v3); // android.app.Notification$Builder.setAutoCancel -> android.app.Notification$Builder
        v3 = _result;
        v4 = v8.defaults; // android.app.Notification.defaults:int
        _result = v3.setDefaults(v4); // android.app.Notification$Builder.setDefaults -> android.app.Notification$Builder
        v3 = _result;
        _result = v3.setContentTitle(v9); // android.app.Notification$Builder.setContentTitle -> android.app.Notification$Builder
        v3 = _result;
        _result = v3.setContentText(v10); // android.app.Notification$Builder.setContentText -> android.app.Notification$Builder
        v3 = _result;
        _result = v3.setContentInfo(v11); // android.app.Notification$Builder.setContentInfo -> android.app.Notification$Builder
        v3 = _result;
        _result = v3.setContentIntent(v14); // android.app.Notification$Builder.setContentIntent -> android.app.Notification$Builder
        v3 = _result;
        v4 = v8.deleteIntent; // android.app.Notification.deleteIntent:android.app.PendingIntent
        _result = v3.setDeleteIntent(v4); // android.app.Notification$Builder.setDeleteIntent -> android.app.Notification$Builder
        v4 = _result;
        v3 = v8.flags; // android.app.Notification.flags:int
        v3 = binOpLit16_0xd5(v3, 128);
        if (v3 == 0) /* goto L_009e */;
        v3 = 1;
        _result = v4.setFullScreenIntent(v15, v3); // android.app.Notification$Builder.setFullScreenIntent -> android.app.Notification$Builder
        v3 = _result;
        v0 = v16;
        _result = v3.setLargeIcon(v0); // android.app.Notification$Builder.setLargeIcon -> android.app.Notification$Builder
        v3 = _result;
        _result = v3.setNumber(v13); // android.app.Notification$Builder.setNumber -> android.app.Notification$Builder
        v3 = _result;
        v0 = v17;
        v1 = v18;
        v2 = v19;
        _result = v3.setProgress(v0, v1, v2); // android.app.Notification$Builder.setProgress -> android.app.Notification$Builder
        v3 = _result;
        _result = v3.getNotification(); // android.app.Notification$Builder.getNotification -> android.app.Notification
        v3 = _result;
        return v3;
        v3 = 0;
        // goto L_003e
        v3 = 0;
        // goto L_0049
        v3 = 0;
        // goto L_0054
        v3 = 0;
        // goto L_007b
    }

}