package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeInfoCompatIcs.java
 * Descriptor: Landroid/support/v4/view/a/h;
 */
class h {
    public static java.lang.Object a(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.obtain(); // android.view.accessibility.AccessibilityNodeInfo.obtain -> android.view.accessibility.AccessibilityNodeInfo
        v0 = _result;
        return v0;
    }

    public static void a(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.addAction(v1); // android.view.accessibility.AccessibilityNodeInfo.addAction -> void
        return;
    }

    public static void a(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.graphics.Rect)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.getBoundsInParent(v1); // android.view.accessibility.AccessibilityNodeInfo.getBoundsInParent -> void
        return;
    }

    public static void a(java.lang.Object p0, android.view.View p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.addChild(v1); // android.view.accessibility.AccessibilityNodeInfo.addChild -> void
        return;
    }

    public static void a(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (java.lang.CharSequence)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setClassName(v1); // android.view.accessibility.AccessibilityNodeInfo.setClassName -> void
        return;
    }

    public static void a(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setClickable(v1); // android.view.accessibility.AccessibilityNodeInfo.setClickable -> void
        return;
    }

    public static int b(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getActions(); // android.view.accessibility.AccessibilityNodeInfo.getActions -> int
        v0 = _result;
        return v0;
    }

    public static void b(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.graphics.Rect)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.getBoundsInScreen(v1); // android.view.accessibility.AccessibilityNodeInfo.getBoundsInScreen -> void
        return;
    }

    public static void b(java.lang.Object p0, android.view.View p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setParent(v1); // android.view.accessibility.AccessibilityNodeInfo.setParent -> void
        return;
    }

    public static void b(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (java.lang.CharSequence)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setContentDescription(v1); // android.view.accessibility.AccessibilityNodeInfo.setContentDescription -> void
        return;
    }

    public static void b(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setEnabled(v1); // android.view.accessibility.AccessibilityNodeInfo.setEnabled -> void
        return;
    }

    public static java.lang.CharSequence c(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getClassName(); // android.view.accessibility.AccessibilityNodeInfo.getClassName -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public static void c(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.graphics.Rect)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setBoundsInParent(v1); // android.view.accessibility.AccessibilityNodeInfo.setBoundsInParent -> void
        return;
    }

    public static void c(java.lang.Object p0, android.view.View p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.view.View)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setSource(v1); // android.view.accessibility.AccessibilityNodeInfo.setSource -> void
        return;
    }

    public static void c(java.lang.Object p0, java.lang.CharSequence p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (java.lang.CharSequence)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setPackageName(v1); // android.view.accessibility.AccessibilityNodeInfo.setPackageName -> void
        return;
    }

    public static void c(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setFocusable(v1); // android.view.accessibility.AccessibilityNodeInfo.setFocusable -> void
        return;
    }

    public static java.lang.CharSequence d(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getContentDescription(); // android.view.accessibility.AccessibilityNodeInfo.getContentDescription -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public static void d(java.lang.Object p0, android.graphics.Rect p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (android.graphics.Rect)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setBoundsInScreen(v1); // android.view.accessibility.AccessibilityNodeInfo.setBoundsInScreen -> void
        return;
    }

    public static void d(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setFocused(v1); // android.view.accessibility.AccessibilityNodeInfo.setFocused -> void
        return;
    }

    public static java.lang.CharSequence e(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getPackageName(); // android.view.accessibility.AccessibilityNodeInfo.getPackageName -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public static void e(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setLongClickable(v1); // android.view.accessibility.AccessibilityNodeInfo.setLongClickable -> void
        return;
    }

    public static java.lang.CharSequence f(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getText(); // android.view.accessibility.AccessibilityNodeInfo.getText -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public static void f(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setScrollable(v1); // android.view.accessibility.AccessibilityNodeInfo.setScrollable -> void
        return;
    }

    public static void g(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setSelected(v1); // android.view.accessibility.AccessibilityNodeInfo.setSelected -> void
        return;
    }

    public static boolean g(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isCheckable(); // android.view.accessibility.AccessibilityNodeInfo.isCheckable -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean h(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isChecked(); // android.view.accessibility.AccessibilityNodeInfo.isChecked -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean i(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isClickable(); // android.view.accessibility.AccessibilityNodeInfo.isClickable -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean j(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isEnabled(); // android.view.accessibility.AccessibilityNodeInfo.isEnabled -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean k(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isFocusable(); // android.view.accessibility.AccessibilityNodeInfo.isFocusable -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean l(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isFocused(); // android.view.accessibility.AccessibilityNodeInfo.isFocused -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean m(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isLongClickable(); // android.view.accessibility.AccessibilityNodeInfo.isLongClickable -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean n(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isPassword(); // android.view.accessibility.AccessibilityNodeInfo.isPassword -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean o(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isScrollable(); // android.view.accessibility.AccessibilityNodeInfo.isScrollable -> boolean
        v0 = _result;
        return v0;
    }

    public static boolean p(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isSelected(); // android.view.accessibility.AccessibilityNodeInfo.isSelected -> boolean
        v0 = _result;
        return v0;
    }

    public static void q(java.lang.Object p0) {
        // Registers (1 total): v0 = p0 (java.lang.Object)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.recycle(); // android.view.accessibility.AccessibilityNodeInfo.recycle -> void
        return;
    }

}