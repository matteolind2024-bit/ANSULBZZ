package android.support.v4.widget;

/**
 * Original SourceFile: ContentLoadingProgressBar.java
 * Descriptor: Landroid/support/v4/widget/a;
 */
class a implements java.lang.Runnable {
    final android.support.v4.widget.ContentLoadingProgressBar a;

    a(android.support.v4.widget.ContentLoadingProgressBar p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.ContentLoadingProgressBar)
        v0.a = v1; // android.support.v4.widget.a.a:android.support.v4.widget.ContentLoadingProgressBar
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (4 total): v3 = this
        v0 = v3.a; // android.support.v4.widget.a.a:android.support.v4.widget.ContentLoadingProgressBar
        v1 = 0;
        _result = v0.a(v1); // android.support.v4.widget.ContentLoadingProgressBar.a -> boolean
        v0 = v3.a; // android.support.v4.widget.a.a:android.support.v4.widget.ContentLoadingProgressBar
        v1 = -1L;
        _result = v0.a(v1, v2); // android.support.v4.widget.ContentLoadingProgressBar.a -> long
        v0 = v3.a; // android.support.v4.widget.a.a:android.support.v4.widget.ContentLoadingProgressBar
        v1 = 8;
        _result = v0.setVisibility(v1); // android.support.v4.widget.ContentLoadingProgressBar.setVisibility -> void
        return;
    }

}