package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/au;
 */
public class au extends android.support.v4.app.bc {
     java.lang.CharSequence a;

    public au() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.app.bc.<init> -> void
        return;
    }

}