package android.support.v4.c;

/**
 * Original SourceFile: SimpleArrayMap.java
 * Descriptor: Landroid/support/v4/c/m;
 */
public class m {
    static java.lang.Object[] b;
    static int c;
    static java.lang.Object[] d;
    static int e;
     int[] f;
     java.lang.Object[] g;
     int h;

    public m() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = android.support.v4.c.c.a; // :int[]
        v1.f = v0; // android.support.v4.c.m.f:int[]
        v0 = android.support.v4.c.c.c; // :java.lang.Object[]
        v1.g = v0; // android.support.v4.c.m.g:java.lang.Object[]
        v0 = 0;
        v1.h = v0; // android.support.v4.c.m.h:int
        return;
    }

    private static void a(int[] p0, java.lang.Object[] p1, int p2) {
        // Registers (7 total): v4 = p0 (int[]), v5 = p1 (java.lang.Object[]), v6 = p2 (int)
        v2 = 10;
        v3 = 2;
        v0 = v4.length;
        v1 = 8;
        if (v0 != v1) /* goto L_0030 */;
        v1 = android.support.v4.c.a.class;
        // monitor-enter(v1)
        v0 = android.support.v4.c.m.e; // :int
        if (v0 >= v2) /* goto L_002b */;
        v0 = 0;
        v2 = android.support.v4.c.m.d; // :java.lang.Object[]
        v5[v0] = v2;
        v0 = 1;
        v5[v0] = v4;
        v0 = binOpLit8_0xe0(v6, 1);
        v0 = binOpLit8_0xd8(v0, -1);
        if (v0 < v3) /* goto L_0023 */;
        v2 = 0;
        v5[v0] = v2;
        v0 = binOpLit8_0xd8(v0, -1);
        // goto L_001b
        android.support.v4.c.m.d = v5; // :java.lang.Object[]
        v0 = android.support.v4.c.m.e; // :int
        v0 = binOpLit8_0xd8(v0, 1);
        android.support.v4.c.m.e = v0; // :int
        // monitor-exit(v1)
        return;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
        v0 = v4.length;
        v1 = 4;
        if (v0 != v1) /* goto L_002c */;
        v1 = android.support.v4.c.a.class;
        // monitor-enter(v1)
        v0 = android.support.v4.c.m.c; // :int
        if (v0 >= v2) /* goto L_0057 */;
        v0 = 0;
        v2 = android.support.v4.c.m.b; // :java.lang.Object[]
        v5[v0] = v2;
        v0 = 1;
        v5[v0] = v4;
        v0 = binOpLit8_0xe0(v6, 1);
        v0 = binOpLit8_0xd8(v0, -1);
        if (v0 < v3) /* goto L_004f */;
        v2 = 0;
        v5[v0] = v2;
        v0 = binOpLit8_0xd8(v0, -1);
        // goto L_0047
        android.support.v4.c.m.b = v5; // :java.lang.Object[]
        v0 = android.support.v4.c.m.c; // :int
        v0 = binOpLit8_0xd8(v0, 1);
        android.support.v4.c.m.c = v0; // :int
        // monitor-exit(v1)
        // goto L_002c
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

    private void e(int p0) {
        // Registers (7 total): v5 = this, v6 = p0 (int)
        v0 = 8;
        if (v6 != v0) /* goto L_003f */;
        v1 = android.support.v4.c.a.class;
        // monitor-enter(v1)
        v0 = android.support.v4.c.m.d; // :java.lang.Object[]
        if (v0 == 0) /* goto L_0030 */;
        v2 = android.support.v4.c.m.d; // :java.lang.Object[]
        v5.g = v2; // android.support.v4.c.m.g:java.lang.Object[]
        v0 = 0;
        v0 = v2[v0];
        v0 = (java.lang.Object[]) v0;
        v0 = (java.lang.Object[]) v0;
        android.support.v4.c.m.d = v0; // :java.lang.Object[]
        v0 = 1;
        v0 = v2[v0];
        v0 = (int[]) v0;
        v0 = (int[]) v0;
        v5.f = v0; // android.support.v4.c.m.f:int[]
        v0 = 0;
        v3 = 1;
        v4 = 0;
        v2[v3] = v4;
        v2[v0] = v4;
        v0 = android.support.v4.c.m.e; // :int
        v0 = binOpLit8_0xd8(v0, -1);
        android.support.v4.c.m.e = v0; // :int
        // monitor-exit(v1)
        return;
        // monitor-exit(v1)
        v0 = new int[][size=v6];
        v5.f = v0; // android.support.v4.c.m.f:int[]
        v0 = binOpLit8_0xe0(v6, 1);
        v0 = new java.lang.Object[][size=v0];
        v5.g = v0; // android.support.v4.c.m.g:java.lang.Object[]
        // goto L_002f
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
        v0 = 4;
        if (v6 != v0) /* goto L_0031 */;
        v1 = android.support.v4.c.a.class;
        // monitor-enter(v1)
        v0 = android.support.v4.c.m.b; // :java.lang.Object[]
        if (v0 == 0) /* goto L_0071 */;
        v2 = android.support.v4.c.m.b; // :java.lang.Object[]
        v5.g = v2; // android.support.v4.c.m.g:java.lang.Object[]
        v0 = 0;
        v0 = v2[v0];
        v0 = (java.lang.Object[]) v0;
        v0 = (java.lang.Object[]) v0;
        android.support.v4.c.m.b = v0; // :java.lang.Object[]
        v0 = 1;
        v0 = v2[v0];
        v0 = (int[]) v0;
        v0 = (int[]) v0;
        v5.f = v0; // android.support.v4.c.m.f:int[]
        v0 = 0;
        v3 = 1;
        v4 = 0;
        v2[v3] = v4;
        v2[v0] = v4;
        v0 = android.support.v4.c.m.c; // :int
        v0 = binOpLit8_0xd8(v0, -1);
        android.support.v4.c.m.c = v0; // :int
        // monitor-exit(v1)
        // goto L_002f
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
        // monitor-exit(v1)
        // goto L_0031
    }

    int a() {
        // Registers (6 total): v5 = this
        v2 = v5.h; // android.support.v4.c.m.h:int
        if (v2 != 0) /* goto L_0006 */;
        v0 = -1;
        return v0;
        v0 = v5.f; // android.support.v4.c.m.f:int[]
        v1 = 0;
        _result = v0.a(v2, v1); // android.support.v4.c.c.a -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0005 */;
        v1 = v5.g; // android.support.v4.c.m.g:java.lang.Object[]
        v3 = binOpLit8_0xe0(v0, 1);
        v1 = v1[v3];
        if (v1 == 0) /* goto L_0005 */;
        v1 = binOpLit8_0xd8(v0, 1);
        if (v1 >= v2) /* goto L_002e */;
        v3 = v5.f; // android.support.v4.c.m.f:int[]
        v3 = v3[v1];
        if (v3 != 0) /* goto L_002e */;
        v3 = v5.g; // android.support.v4.c.m.g:java.lang.Object[]
        v4 = binOpLit8_0xe0(v1, 1);
        v3 = v3[v4];
        if (v3 != 0) /* goto L_002b */;
        v0 = v1;
        // goto L_0005
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0019
        v0 = binOpLit8_0xd8(v0, -1);
        if (v0 < 0) /* goto L_0043 */;
        v2 = v5.f; // android.support.v4.c.m.f:int[]
        v2 = v2[v0];
        if (v2 != 0) /* goto L_0043 */;
        v2 = v5.g; // android.support.v4.c.m.g:java.lang.Object[]
        v3 = binOpLit8_0xe0(v0, 1);
        v2 = v2[v3];
        if (v2 == 0) /* goto L_0005 */;
        v0 = binOpLit8_0xd8(v0, -1);
        // goto L_0030
        v0 = binOpLit8_0xdf(v1, -1);
        // goto L_0005
    }

    int a(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = v4.h; // android.support.v4.c.m.h:int
        v1 = binOpLit8_0xda(v1, 2);
        v2 = v4.g; // android.support.v4.c.m.g:java.lang.Object[]
        if (v5 != 0) /* goto L_0017 */;
        if (v0 >= v1) /* goto L_0024 */;
        v3 = v2[v0];
        if (v3 != 0) /* goto L_0012 */;
        v0 = binOpLit8_0xe1(v0, 1);
        return v0;
        v0 = binOpLit8_0xd8(v0, 2);
        // goto L_0009
        v0 = binOpLit8_0xd8(v0, 2);
        if (v0 >= v1) /* goto L_0024 */;
        v3 = v2[v0];
        _result = v5.equals(v3); // java.lang.Object.equals -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0015 */;
        v0 = binOpLit8_0xe1(v0, 1);
        // goto L_0011
        v0 = -1;
        // goto L_0011
    }

    int a(java.lang.Object p0, int p1) {
        // Registers (8 total): v5 = this, v6 = p0 (java.lang.Object), v7 = p1 (int)
        v2 = v5.h; // android.support.v4.c.m.h:int
        if (v2 != 0) /* goto L_0006 */;
        v0 = -1;
        return v0;
        v0 = v5.f; // android.support.v4.c.m.f:int[]
        _result = v0.a(v2, v7); // android.support.v4.c.c.a -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0005 */;
        v1 = v5.g; // android.support.v4.c.m.g:java.lang.Object[]
        v3 = binOpLit8_0xe0(v0, 1);
        v1 = v1[v3];
        _result = v6.equals(v1); // java.lang.Object.equals -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0005 */;
        v1 = binOpLit8_0xd8(v0, 1);
        if (v1 >= v2) /* goto L_0035 */;
        v3 = v5.f; // android.support.v4.c.m.f:int[]
        v3 = v3[v1];
        if (v3 != v7) /* goto L_0035 */;
        v3 = v5.g; // android.support.v4.c.m.g:java.lang.Object[]
        v4 = binOpLit8_0xe0(v1, 1);
        v3 = v3[v4];
        _result = v6.equals(v3); // java.lang.Object.equals -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0032 */;
        v0 = v1;
        // goto L_0005
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_001c
        v0 = binOpLit8_0xd8(v0, -1);
        if (v0 < 0) /* goto L_004e */;
        v2 = v5.f; // android.support.v4.c.m.f:int[]
        v2 = v2[v0];
        if (v2 != v7) /* goto L_004e */;
        v2 = v5.g; // android.support.v4.c.m.g:java.lang.Object[]
        v3 = binOpLit8_0xe0(v0, 1);
        v2 = v2[v3];
        _result = v6.equals(v2); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0005 */;
        v0 = binOpLit8_0xd8(v0, -1);
        // goto L_0037
        v0 = binOpLit8_0xdf(v1, -1);
        // goto L_0005
    }

    public java.lang.Object a(int p0, java.lang.Object p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (java.lang.Object)
        v0 = binOpLit8_0xe0(v4, 1);
        v0 = binOpLit8_0xd8(v0, 1);
        v1 = v3.g; // android.support.v4.c.m.g:java.lang.Object[]
        v1 = v1[v0];
        v2 = v3.g; // android.support.v4.c.m.g:java.lang.Object[]
        v2[v0] = v5;
        return v1;
    }

    public void a(int p0) {
        // Registers (7 total): v5 = this, v6 = p0 (int)
        v4 = 0;
        v0 = v5.f; // android.support.v4.c.m.f:int[]
        v0 = v0.length;
        if (v0 >= v6) /* goto L_0026 */;
        v0 = v5.f; // android.support.v4.c.m.f:int[]
        v1 = v5.g; // android.support.v4.c.m.g:java.lang.Object[]
        _result = v5.e(v6); // android.support.v4.c.m.e -> void
        v2 = v5.h; // android.support.v4.c.m.h:int
        if (v2 <= 0) /* goto L_0021 */;
        v2 = v5.f; // android.support.v4.c.m.f:int[]
        v3 = v5.h; // android.support.v4.c.m.h:int
        _result = v0.arraycopy(v4, v2, v4, v3); // java.lang.System.arraycopy -> void
        v2 = v5.g; // android.support.v4.c.m.g:java.lang.Object[]
        v3 = v5.h; // android.support.v4.c.m.h:int
        v3 = binOpLit8_0xe0(v3, 1);
        _result = v1.arraycopy(v4, v2, v4, v3); // java.lang.System.arraycopy -> void
        v2 = v5.h; // android.support.v4.c.m.h:int
        _result = v0.a(v1, v2); // android.support.v4.c.m.a -> void
        return;
    }

    public java.lang.Object b(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.g; // android.support.v4.c.m.g:java.lang.Object[]
        v1 = binOpLit8_0xe0(v3, 1);
        v0 = v0[v1];
        return v0;
    }

    public java.lang.Object c(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.g; // android.support.v4.c.m.g:java.lang.Object[]
        v1 = binOpLit8_0xe0(v3, 1);
        v1 = binOpLit8_0xd8(v1, 1);
        v0 = v0[v1];
        return v0;
    }

    public void clear() {
        // Registers (4 total): v3 = this
        v0 = v3.h; // android.support.v4.c.m.h:int
        if (v0 == 0) /* goto L_0018 */;
        v0 = v3.f; // android.support.v4.c.m.f:int[]
        v1 = v3.g; // android.support.v4.c.m.g:java.lang.Object[]
        v2 = v3.h; // android.support.v4.c.m.h:int
        _result = v0.a(v1, v2); // android.support.v4.c.m.a -> void
        v0 = android.support.v4.c.c.a; // :int[]
        v3.f = v0; // android.support.v4.c.m.f:int[]
        v0 = android.support.v4.c.c.c; // :java.lang.Object[]
        v3.g = v0; // android.support.v4.c.m.g:java.lang.Object[]
        v0 = 0;
        v3.h = v0; // android.support.v4.c.m.h:int
        return;
    }

    public boolean containsKey(java.lang.Object p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != 0) /* goto L_000d */;
        _result = v3.a(); // android.support.v4.c.m.a -> int
        v2 = _result;
        if (v2 < 0) /* goto L_000b */;
        return v0;
        v0 = v1;
        // goto L_000a
        _result = v4.hashCode(); // java.lang.Object.hashCode -> int
        v2 = _result;
        _result = v3.a(v4, v2); // android.support.v4.c.m.a -> int
        v2 = _result;
        if (v2 >= 0) /* goto L_000a */;
        v0 = v1;
        // goto L_000a
    }

    public boolean containsValue(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v1.a(v2); // android.support.v4.c.m.a -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0008 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0007
    }

    public java.lang.Object d(int p0) {
        // Registers (9 total): v7 = this, v8 = p0 (int)
        v6 = 0;
        v0 = 8;
        v5 = 0;
        v1 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v2 = binOpLit8_0xe0(v8, 1);
        v2 = binOpLit8_0xd8(v2, 1);
        v1 = v1[v2];
        v2 = v7.h; // android.support.v4.c.m.h:int
        v3 = 1;
        if (v2 > v3) /* goto L_0025 */;
        v0 = v7.f; // android.support.v4.c.m.f:int[]
        v2 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v3 = v7.h; // android.support.v4.c.m.h:int
        _result = v0.a(v2, v3); // android.support.v4.c.m.a -> void
        v0 = android.support.v4.c.c.a; // :int[]
        v7.f = v0; // android.support.v4.c.m.f:int[]
        v0 = android.support.v4.c.c.c; // :java.lang.Object[]
        v7.g = v0; // android.support.v4.c.m.g:java.lang.Object[]
        v7.h = v5; // android.support.v4.c.m.h:int
        return v1;
        v2 = v7.f; // android.support.v4.c.m.f:int[]
        v2 = v2.length;
        if (v2 <= v0) /* goto L_0078 */;
        v2 = v7.h; // android.support.v4.c.m.h:int
        v3 = v7.f; // android.support.v4.c.m.f:int[]
        v3 = v3.length;
        v3 = binOpLit8_0xdb(v3, 3);
        if (v2 >= v3) /* goto L_0078 */;
        v2 = v7.h; // android.support.v4.c.m.h:int
        if (v2 <= v0) /* goto L_003e */;
        v0 = v7.h; // android.support.v4.c.m.h:int
        v2 = v7.h; // android.support.v4.c.m.h:int
        v2 = binOpLit8_0xe1(v2, 1);
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = v7.f; // android.support.v4.c.m.f:int[]
        v3 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        _result = v7.e(v0); // android.support.v4.c.m.e -> void
        v0 = v7.h; // android.support.v4.c.m.h:int
        v0 = binOpLit8_0xd8(v0, -1);
        v7.h = v0; // android.support.v4.c.m.h:int
        if (v8 <= 0) /* goto L_0059 */;
        v0 = v7.f; // android.support.v4.c.m.f:int[]
        _result = v2.arraycopy(v5, v0, v5, v8); // java.lang.System.arraycopy -> void
        v0 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v4 = binOpLit8_0xe0(v8, 1);
        _result = v3.arraycopy(v5, v0, v5, v4); // java.lang.System.arraycopy -> void
        v0 = v7.h; // android.support.v4.c.m.h:int
        if (v8 >= v0) /* goto L_0024 */;
        v0 = binOpLit8_0xd8(v8, 1);
        v4 = v7.f; // android.support.v4.c.m.f:int[]
        v5 = v7.h; // android.support.v4.c.m.h:int
        v5 = binOp2addr_0xb1(v5, v8);
        _result = v2.arraycopy(v0, v4, v8, v5); // java.lang.System.arraycopy -> void
        v0 = binOpLit8_0xd8(v8, 1);
        v0 = binOpLit8_0xe0(v0, 1);
        v2 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v4 = binOpLit8_0xe0(v8, 1);
        v5 = v7.h; // android.support.v4.c.m.h:int
        v5 = binOp2addr_0xb1(v5, v8);
        v5 = binOpLit8_0xe0(v5, 1);
        _result = v3.arraycopy(v0, v2, v4, v5); // java.lang.System.arraycopy -> void
        // goto L_0024
        v0 = v7.h; // android.support.v4.c.m.h:int
        v0 = binOpLit8_0xd8(v0, -1);
        v7.h = v0; // android.support.v4.c.m.h:int
        v0 = v7.h; // android.support.v4.c.m.h:int
        if (v8 >= v0) /* goto L_00a0 */;
        v0 = v7.f; // android.support.v4.c.m.f:int[]
        v2 = binOpLit8_0xd8(v8, 1);
        v3 = v7.f; // android.support.v4.c.m.f:int[]
        v4 = v7.h; // android.support.v4.c.m.h:int
        v4 = binOp2addr_0xb1(v4, v8);
        _result = v0.arraycopy(v2, v3, v8, v4); // java.lang.System.arraycopy -> void
        v0 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v2 = binOpLit8_0xd8(v8, 1);
        v2 = binOpLit8_0xe0(v2, 1);
        v3 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v4 = binOpLit8_0xe0(v8, 1);
        v5 = v7.h; // android.support.v4.c.m.h:int
        v5 = binOp2addr_0xb1(v5, v8);
        v5 = binOpLit8_0xe0(v5, 1);
        _result = v0.arraycopy(v2, v3, v4, v5); // java.lang.System.arraycopy -> void
        v0 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v2 = v7.h; // android.support.v4.c.m.h:int
        v2 = binOpLit8_0xe0(v2, 1);
        v0[v2] = v6;
        v0 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v2 = v7.h; // android.support.v4.c.m.h:int
        v2 = binOpLit8_0xe0(v2, 1);
        v2 = binOpLit8_0xd8(v2, 1);
        v0[v2] = v6;
        // goto L_0024
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v6 != v7) /* goto L_0005 */;
        return v0;
        v2 = (v7 instanceof java.util.Map);
        if (v2 == 0) /* goto L_0045 */;
        v7 = (java.util.Map) v7;
        _result = v6.size(); // android.support.v4.c.m.size -> int
        v2 = _result;
        _result = java.util.Map.size(v7); // -> int
        v3 = _result;
        if (v2 == v3) /* goto L_0017 */;
        v0 = v1;
        // goto L_0004
        v2 = v1;
        v3 = v6.h; // android.support.v4.c.m.h:int
        if (v2 >= v3) /* goto L_0004 */;
        _result = v6.b(v2); // android.support.v4.c.m.b -> java.lang.Object
        v3 = _result;
        _result = v6.c(v2); // android.support.v4.c.m.c -> java.lang.Object
        v4 = _result;
        _result = java.util.Map.get(v7, v3); // -> java.lang.Object
        v5 = _result;
        if (v4 != 0) /* goto L_0034 */;
        if (v5 != 0) /* goto L_0032 */;
        _result = java.util.Map.containsKey(v7, v3); // -> boolean
        v3 = _result;
        if (v3 != 0) /* goto L_003c */;
        v0 = v1;
        // goto L_0004
        _result = v4.equals(v5); // java.lang.Object.equals -> boolean
        v3 = _result;
        if (v3 != 0) /* goto L_003c */;
        v0 = v1;
        // goto L_0004
        v2 = binOpLit8_0xd8(v2, 1);
        // goto L_0018
        v0 = _exception;
        v0 = v1;
        // goto L_0004
        v0 = _exception;
        v0 = v1;
        // goto L_0004
        v0 = v1;
        // goto L_0004
    }

    public java.lang.Object get(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        if (v3 != 0) /* goto L_0011 */;
        _result = v2.a(); // android.support.v4.c.m.a -> int
        v0 = _result;
        if (v0 < 0) /* goto L_001a */;
        v1 = v2.g; // android.support.v4.c.m.g:java.lang.Object[]
        v0 = binOpLit8_0xe0(v0, 1);
        v0 = binOpLit8_0xd8(v0, 1);
        v0 = v1[v0];
        return v0;
        _result = v3.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        _result = v2.a(v3, v0); // android.support.v4.c.m.a -> int
        v0 = _result;
        // goto L_0006
        v0 = 0;
        // goto L_0010
    }

    public int hashCode() {
        // Registers (10 total): v9 = this
        v1 = 0;
        v5 = v9.f; // android.support.v4.c.m.f:int[]
        v6 = v9.g; // android.support.v4.c.m.g:java.lang.Object[]
        v0 = 1;
        v7 = v9.h; // android.support.v4.c.m.h:int
        v2 = v0;
        v3 = v1;
        v4 = v1;
        if (v3 >= v7) /* goto L_0021 */;
        v0 = v6[v2];
        v8 = v5[v3];
        if (v0 != 0) /* goto L_001c */;
        v0 = v1;
        v0 = binOp2addr_0xb7(v0, v8);
        v4 = binOp2addr_0xb0(v4, v0);
        v3 = binOpLit8_0xd8(v3, 1);
        v0 = binOpLit8_0xd8(v2, 2);
        v2 = v0;
        // goto L_000b
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        // goto L_0014
        return v4;
    }

    public boolean isEmpty() {
        // Registers (2 total): v1 = this
        v0 = v1.h; // android.support.v4.c.m.h:int
        if (v0 > 0) /* goto L_0006 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0005
    }

    public java.lang.Object put(java.lang.Object p0, java.lang.Object p1) {
        // Registers (10 total): v7 = this, v8 = p0 (java.lang.Object), v9 = p1 (java.lang.Object)
        v0 = 8;
        v1 = 4;
        v4 = 0;
        if (v8 != 0) /* goto L_001a */;
        _result = v7.a(); // android.support.v4.c.m.a -> int
        v2 = _result;
        v3 = v4;
        if (v2 < 0) /* goto L_0023 */;
        v0 = binOpLit8_0xe0(v2, 1);
        v1 = binOpLit8_0xd8(v0, 1);
        v0 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v0 = v0[v1];
        v2 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v2[v1] = v9;
        return v0;
        _result = v8.hashCode(); // java.lang.Object.hashCode -> int
        v3 = _result;
        _result = v7.a(v8, v3); // android.support.v4.c.m.a -> int
        v2 = _result;
        // goto L_000b
        v2 = binOpLit8_0xdf(v2, -1);
        v5 = v7.h; // android.support.v4.c.m.h:int
        v6 = v7.f; // android.support.v4.c.m.f:int[]
        v6 = v6.length;
        if (v5 < v6) /* goto L_0054 */;
        v5 = v7.h; // android.support.v4.c.m.h:int
        if (v5 < v0) /* goto L_0090 */;
        v0 = v7.h; // android.support.v4.c.m.h:int
        v1 = v7.h; // android.support.v4.c.m.h:int
        v1 = binOpLit8_0xe1(v1, 1);
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = v7.f; // android.support.v4.c.m.f:int[]
        v5 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        _result = v7.e(v0); // android.support.v4.c.m.e -> void
        v0 = v7.f; // android.support.v4.c.m.f:int[]
        v0 = v0.length;
        if (v0 <= 0) /* goto L_004f */;
        v0 = v7.f; // android.support.v4.c.m.f:int[]
        v6 = v1.length;
        _result = v1.arraycopy(v4, v0, v4, v6); // java.lang.System.arraycopy -> void
        v0 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v6 = v5.length;
        _result = v5.arraycopy(v4, v0, v4, v6); // java.lang.System.arraycopy -> void
        v0 = v7.h; // android.support.v4.c.m.h:int
        _result = v1.a(v5, v0); // android.support.v4.c.m.a -> void
        v0 = v7.h; // android.support.v4.c.m.h:int
        if (v2 >= v0) /* goto L_0076 */;
        v0 = v7.f; // android.support.v4.c.m.f:int[]
        v1 = v7.f; // android.support.v4.c.m.f:int[]
        v4 = binOpLit8_0xd8(v2, 1);
        v5 = v7.h; // android.support.v4.c.m.h:int
        v5 = binOp2addr_0xb1(v5, v2);
        _result = v0.arraycopy(v2, v1, v4, v5); // java.lang.System.arraycopy -> void
        v0 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v1 = binOpLit8_0xe0(v2, 1);
        v4 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v5 = binOpLit8_0xd8(v2, 1);
        v5 = binOpLit8_0xe0(v5, 1);
        v6 = v7.h; // android.support.v4.c.m.h:int
        v6 = binOp2addr_0xb1(v6, v2);
        v6 = binOpLit8_0xe0(v6, 1);
        _result = v0.arraycopy(v1, v4, v5, v6); // java.lang.System.arraycopy -> void
        v0 = v7.f; // android.support.v4.c.m.f:int[]
        v0[v2] = v3;
        v0 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v1 = binOpLit8_0xe0(v2, 1);
        v0[v1] = v8;
        v0 = v7.g; // android.support.v4.c.m.g:java.lang.Object[]
        v1 = binOpLit8_0xe0(v2, 1);
        v1 = binOpLit8_0xd8(v1, 1);
        v0[v1] = v9;
        v0 = v7.h; // android.support.v4.c.m.h:int
        v0 = binOpLit8_0xd8(v0, 1);
        v7.h = v0; // android.support.v4.c.m.h:int
        v0 = 0;
        // goto L_0019
        v5 = v7.h; // android.support.v4.c.m.h:int
        if (v5 >= v1) /* goto L_0037 */;
        v0 = v1;
        // goto L_0037
    }

    public java.lang.Object remove(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        if (v2 != 0) /* goto L_000d */;
        _result = v1.a(); // android.support.v4.c.m.a -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0016 */;
        _result = v1.d(v0); // android.support.v4.c.m.d -> java.lang.Object
        v0 = _result;
        return v0;
        _result = v2.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        _result = v1.a(v2, v0); // android.support.v4.c.m.a -> int
        v0 = _result;
        // goto L_0006
        v0 = 0;
        // goto L_000c
    }

    public int size() {
        // Registers (2 total): v1 = this
        v0 = v1.h; // android.support.v4.c.m.h:int
        return v0;
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        _result = v3.isEmpty(); // android.support.v4.c.m.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000a */;
        v0 = "{}";
        return v0;
        v1 = new java.lang.StringBuilder;
        v0 = v3.h; // android.support.v4.c.m.h:int
        v0 = binOpLit8_0xda(v0, 28);
        _result = v1.<init>(v0); // java.lang.StringBuilder.<init> -> void
        v0 = 123;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = 0;
        v2 = v3.h; // android.support.v4.c.m.h:int
        if (v0 >= v2) /* goto L_004d */;
        if (v0 <= 0) /* goto L_0025 */;
        v2 = ", ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v3.b(v0); // android.support.v4.c.m.b -> java.lang.Object
        v2 = _result;
        if (v2 == v3) /* goto L_003f */;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = 61;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v3.c(v0); // android.support.v4.c.m.c -> java.lang.Object
        v2 = _result;
        if (v2 == v3) /* goto L_0046 */;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0019
        v2 = "(this Map)";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_002e
        v2 = "(this Map)";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_003c
        v0 = 125;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0009
    }

}