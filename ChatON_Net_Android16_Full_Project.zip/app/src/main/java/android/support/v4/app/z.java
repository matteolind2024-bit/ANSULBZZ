package android.support.v4.app;

/**
 * Original SourceFile: FragmentManager.java
 * Descriptor: Landroid/support/v4/app/z;
 */
class z implements java.lang.Runnable {
    final android.support.v4.app.y a;

    z(android.support.v4.app.y p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.y)
        v0.a = v1; // android.support.v4.app.z.a:android.support.v4.app.y
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.app.z.a:android.support.v4.app.y
        _result = v0.f(); // android.support.v4.app.y.f -> boolean
        return;
    }

}