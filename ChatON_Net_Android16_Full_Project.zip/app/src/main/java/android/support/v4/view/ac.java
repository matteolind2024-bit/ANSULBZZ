package android.support.v4.view;

/**
 * Original SourceFile: MotionEventCompat.java
 * Descriptor: Landroid/support/v4/view/ac;
 */
interface ac {
    public abstract int a(android.view.MotionEvent p0);
    public abstract int a(android.view.MotionEvent p0, int p1);
    public abstract int b(android.view.MotionEvent p0, int p1);
    public abstract float c(android.view.MotionEvent p0, int p1);
    public abstract float d(android.view.MotionEvent p0, int p1);
}