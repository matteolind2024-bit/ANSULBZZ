package android.support.v4.c;

/**
 * Original SourceFile: MapCollections.java
 * Descriptor: Landroid/support/v4/c/j;
 */
final class j implements java.util.Set {
    final android.support.v4.c.g a;

    j(android.support.v4.c.g p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.c.g)
        v0.a = v1; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public boolean add(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public boolean addAll(java.util.Collection p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.Collection)
        v0 = new java.lang.UnsupportedOperationException;
        _result = v0.<init>(); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public void clear() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v0.c(); // android.support.v4.c.g.c -> void
        return;
    }

    public boolean contains(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = v1.a; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v0.a(v2); // android.support.v4.c.g.a -> int
        v0 = _result;
        if (v0 < 0) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public boolean containsAll(java.util.Collection p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.Collection)
        v0 = v1.a; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v0.b(); // android.support.v4.c.g.b -> java.util.Map
        v0 = _result;
        _result = v0.a(v2); // android.support.v4.c.g.a -> boolean
        v0 = _result;
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v1.a(v2); // android.support.v4.c.g.a -> boolean
        v0 = _result;
        return v0;
    }

    public int hashCode() {
        // Registers (5 total): v4 = this
        v1 = 0;
        v0 = v4.a; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v0.a(); // android.support.v4.c.g.a -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v2 = v0;
        v3 = v1;
        if (v2 < 0) /* goto L_0020 */;
        v0 = v4.a; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v0.a(v2, v1); // android.support.v4.c.g.a -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_001b */;
        v0 = v1;
        v3 = binOp2addr_0xb0(v3, v0);
        v0 = binOpLit8_0xd8(v2, -1);
        v2 = v0;
        // goto L_000b
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        // goto L_0016
        return v3;
    }

    public boolean isEmpty() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v0.a(); // android.support.v4.c.g.a -> int
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public java.util.Iterator iterator() {
        // Registers (4 total): v3 = this
        v0 = new android.support.v4.c.h;
        v1 = v3.a; // android.support.v4.c.j.a:android.support.v4.c.g
        v2 = 0;
        _result = v0.<init>(v1, v2); // android.support.v4.c.h.<init> -> void
        return v0;
    }

    public boolean remove(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v0 = v2.a; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v0.a(v3); // android.support.v4.c.g.a -> int
        v0 = _result;
        if (v0 < 0) /* goto L_000f */;
        v1 = v2.a; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v1.a(v0); // android.support.v4.c.g.a -> void
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000e
    }

    public boolean removeAll(java.util.Collection p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.Collection)
        v0 = v1.a; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v0.b(); // android.support.v4.c.g.b -> java.util.Map
        v0 = _result;
        _result = v0.b(v2); // android.support.v4.c.g.b -> boolean
        v0 = _result;
        return v0;
    }

    public boolean retainAll(java.util.Collection p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.Collection)
        v0 = v1.a; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v0.b(); // android.support.v4.c.g.b -> java.util.Map
        v0 = _result;
        _result = v0.c(v2); // android.support.v4.c.g.c -> boolean
        v0 = _result;
        return v0;
    }

    public int size() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.c.j.a:android.support.v4.c.g
        _result = v0.a(); // android.support.v4.c.g.a -> int
        v0 = _result;
        return v0;
    }

    public java.lang.Object[] toArray() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // android.support.v4.c.j.a:android.support.v4.c.g
        v1 = 0;
        _result = v0.b(v1); // android.support.v4.c.g.b -> java.lang.Object[]
        v0 = _result;
        return v0;
    }

    public java.lang.Object[] toArray(java.lang.Object[] p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object[])
        v0 = v2.a; // android.support.v4.c.j.a:android.support.v4.c.g
        v1 = 0;
        _result = v0.a(v3, v1); // android.support.v4.c.g.a -> java.lang.Object[]
        v0 = _result;
        return v0;
    }

}