package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/as;
 */
public class as {
    public int a;
    public java.lang.CharSequence b;
    public android.app.PendingIntent c;

}