package android.support.v4.view;

/**
 * Original SourceFile: PagerAdapter.java
 * Descriptor: Landroid/support/v4/view/ae;
 */
public abstract class ae {
    private android.database.DataSetObservable a;

    public ae() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new android.database.DataSetObservable;
        _result = v0.<init>(); // android.database.DataSetObservable.<init> -> void
        v1.a = v0; // android.support.v4.view.ae.a:android.database.DataSetObservable
        return;
    }

    public int a(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = -1;
        return v0;
    }

    public android.os.Parcelable a() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public java.lang.Object a(android.view.View p0, int p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int)
        v0 = new java.lang.UnsupportedOperationException;
        v1 = "Required method instantiateItem was not overridden";
        _result = v0.<init>(v1); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public java.lang.Object a(android.view.ViewGroup p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (int)
        _result = v1.a(v2, v3); // android.support.v4.view.ae.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void a(android.database.DataSetObserver p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.database.DataSetObserver)
        v0 = v1.a; // android.support.v4.view.ae.a:android.database.DataSetObservable
        _result = v0.registerObserver(v2); // android.database.DataSetObservable.registerObserver -> void
        return;
    }

    public void a(android.os.Parcelable p0, java.lang.ClassLoader p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.os.Parcelable), v2 = p1 (java.lang.ClassLoader)
        return;
    }

    public void a(android.view.View p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.View)
        return;
    }

    public void a(android.view.View p0, int p1, java.lang.Object p2) {
        // Registers (6 total): v2 = this, v3 = p0 (android.view.View), v4 = p1 (int), v5 = p2 (java.lang.Object)
        v0 = new java.lang.UnsupportedOperationException;
        v1 = "Required method destroyItem was not overridden";
        _result = v0.<init>(v1); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public void a(android.view.ViewGroup p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.ViewGroup)
        _result = v0.a(v1); // android.support.v4.view.ae.a -> void
        return;
    }

    public void a(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.view.ViewGroup), v2 = p1 (int), v3 = p2 (java.lang.Object)
        _result = v0.a(v1, v2, v3); // android.support.v4.view.ae.a -> void
        return;
    }

    public abstract boolean a(android.view.View p0, java.lang.Object p1);
    public abstract int b();
    public void b(android.database.DataSetObserver p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.database.DataSetObserver)
        v0 = v1.a; // android.support.v4.view.ae.a:android.database.DataSetObservable
        _result = v0.unregisterObserver(v2); // android.database.DataSetObservable.unregisterObserver -> void
        return;
    }

    public void b(android.view.View p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.View)
        return;
    }

    public void b(android.view.View p0, int p1, java.lang.Object p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int), v3 = p2 (java.lang.Object)
        return;
    }

    public void b(android.view.ViewGroup p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.ViewGroup)
        _result = v0.b(v1); // android.support.v4.view.ae.b -> void
        return;
    }

    public void b(android.view.ViewGroup p0, int p1, java.lang.Object p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.view.ViewGroup), v2 = p1 (int), v3 = p2 (java.lang.Object)
        _result = v0.b(v1, v2, v3); // android.support.v4.view.ae.b -> void
        return;
    }

    public java.lang.CharSequence c(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public void c() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.view.ae.a:android.database.DataSetObservable
        _result = v0.notifyChanged(); // android.database.DataSetObservable.notifyChanged -> void
        return;
    }

    public float d(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0x3f800000;
        return v0;
    }

}