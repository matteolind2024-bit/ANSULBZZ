package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeProviderCompatJellyBean.java
 * Descriptor: Landroid/support/v4/view/a/r;
 */
class r {
    public static java.lang.Object a(android.support.v4.view.a.t p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.view.a.t)
        v0 = new android.support.v4.view.a.s;
        _result = v0.<init>(v1); // android.support.v4.view.a.s.<init> -> void
        return v0;
    }

}