package android.support.v4.view;

/**
 * Original SourceFile: KeyEventCompat.java
 * Descriptor: Landroid/support/v4/view/v;
 */
class v extends android.support.v4.view.u {
    v() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.u.<init> -> void
        return;
    }

    public int a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v2.a(); // android.support.v4.view.y.a -> int
        v0 = _result;
        return v0;
    }

    public boolean a(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        _result = v2.a(v3); // android.support.v4.view.y.a -> boolean
        v0 = _result;
        return v0;
    }

    public boolean b(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v2.b(); // android.support.v4.view.y.b -> boolean
        v0 = _result;
        return v0;
    }

}