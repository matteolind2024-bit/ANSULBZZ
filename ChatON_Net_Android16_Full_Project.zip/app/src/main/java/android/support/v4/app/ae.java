package android.support.v4.app;

/**
 * Original SourceFile: Fragment.java
 * Descriptor: Landroid/support/v4/app/ae;
 */
final class ae implements android.os.Parcelable$Creator {
    ae() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.support.v4.app.FragmentState a(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        v0 = new android.support.v4.app.FragmentState;
        _result = v0.<init>(v2); // android.support.v4.app.FragmentState.<init> -> void
        return v0;
    }

    public android.support.v4.app.FragmentState[] a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = new android.support.v4.app.FragmentState[][size=v2];
        return v0;
    }

    public java.lang.Object createFromParcel(android.os.Parcel p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Parcel)
        _result = v1.a(v2); // android.support.v4.app.ae.a -> android.support.v4.app.FragmentState
        v0 = _result;
        return v0;
    }

    public java.lang.Object[] newArray(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.a(v2); // android.support.v4.app.ae.a -> android.support.v4.app.FragmentState[]
        v0 = _result;
        return v0;
    }

}