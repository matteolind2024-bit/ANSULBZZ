package android.support.v4.view;

/**
 * Original SourceFile: ViewCompatJellybeanMr1.java
 * Descriptor: Landroid/support/v4/view/bi;
 */
class bi {
    public static int a(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        _result = v1.getLayoutDirection(); // android.view.View.getLayoutDirection -> int
        v0 = _result;
        return v0;
    }

    public static void a(android.view.View p0, android.graphics.Paint p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (android.graphics.Paint)
        _result = v0.setLayerPaint(v1); // android.view.View.setLayerPaint -> void
        return;
    }

}