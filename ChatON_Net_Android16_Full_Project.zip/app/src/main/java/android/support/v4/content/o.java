package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/o;
 */
class o extends android.support.v4.content.u {
    final android.support.v4.content.m a;

    o(android.support.v4.content.m p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.content.m)
        v1.a = v2; // android.support.v4.content.o.a:android.support.v4.content.m
        v0 = 0;
        _result = v1.<init>(v0); // android.support.v4.content.u.<init> -> void
        return;
    }

    public java.lang.Object call() {
        // Registers (4 total): v3 = this
        v0 = v3.a; // android.support.v4.content.o.a:android.support.v4.content.m
        _result = v0.a(); // android.support.v4.content.m.a -> java.util.concurrent.atomic.AtomicBoolean
        v0 = _result;
        v1 = 1;
        _result = v0.set(v1); // java.util.concurrent.atomic.AtomicBoolean.set -> void
        v0 = 10;
        _result = v0.setThreadPriority(); // android.os.Process.setThreadPriority -> void
        v0 = v3.a; // android.support.v4.content.o.a:android.support.v4.content.m
        v1 = v3.a; // android.support.v4.content.o.a:android.support.v4.content.m
        v2 = v3.b; // android.support.v4.content.o.b:java.lang.Object[]
        _result = v1.a(v2); // android.support.v4.content.m.a -> java.lang.Object
        v1 = _result;
        _result = v0.a(v1); // android.support.v4.content.m.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

}