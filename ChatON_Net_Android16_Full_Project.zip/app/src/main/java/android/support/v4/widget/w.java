package android.support.v4.widget;

/**
 * Original SourceFile: ScrollerCompat.java
 * Descriptor: Landroid/support/v4/widget/w;
 */
class w implements android.support.v4.widget.u {
    w() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public java.lang.Object a(android.content.Context p0, android.view.animation.Interpolator p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.view.animation.Interpolator)
        _result = v2.a(v3); // android.support.v4.widget.y.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public void a(java.lang.Object p0, int p1, int p2, int p3, int p4, int p5) {
        // Registers (7 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int), v3 = p2 (int), v4 = p3 (int), v5 = p4 (int), v6 = p5 (int)
        _result = v1.a(v1..v6); // android.support.v4.widget.y.a -> void
        return;
    }

    public boolean a(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.a(); // android.support.v4.widget.y.a -> boolean
        v0 = _result;
        return v0;
    }

    public int b(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.b(); // android.support.v4.widget.y.b -> int
        v0 = _result;
        return v0;
    }

    public int c(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.c(); // android.support.v4.widget.y.c -> int
        v0 = _result;
        return v0;
    }

    public boolean d(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.d(); // android.support.v4.widget.y.d -> boolean
        v0 = _result;
        return v0;
    }

    public void e(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v1.e(); // android.support.v4.widget.y.e -> void
        return;
    }

    public int f(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.f(); // android.support.v4.widget.y.f -> int
        v0 = _result;
        return v0;
    }

    public int g(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.g(); // android.support.v4.widget.y.g -> int
        v0 = _result;
        return v0;
    }

}