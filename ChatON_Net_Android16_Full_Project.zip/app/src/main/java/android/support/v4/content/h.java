package android.support.v4.content;

/**
 * Original SourceFile: Loader.java
 * Descriptor: Landroid/support/v4/content/h;
 */
public interface h {
    public abstract void a(android.support.v4.content.f p0, java.lang.Object p1);
}