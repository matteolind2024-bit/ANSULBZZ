package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeInfoCompatJellyBean.java
 * Descriptor: Landroid/support/v4/view/a/i;
 */
class i {
    public static void a(java.lang.Object p0, int p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (int)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setMovementGranularities(v1); // android.view.accessibility.AccessibilityNodeInfo.setMovementGranularities -> void
        return;
    }

    public static void a(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setVisibleToUser(v1); // android.view.accessibility.AccessibilityNodeInfo.setVisibleToUser -> void
        return;
    }

    public static boolean a(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isVisibleToUser(); // android.view.accessibility.AccessibilityNodeInfo.isVisibleToUser -> boolean
        v0 = _result;
        return v0;
    }

    public static int b(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.getMovementGranularities(); // android.view.accessibility.AccessibilityNodeInfo.getMovementGranularities -> int
        v0 = _result;
        return v0;
    }

    public static void b(java.lang.Object p0, boolean p1) {
        // Registers (2 total): v0 = p0 (java.lang.Object), v1 = p1 (boolean)
        v0 = (android.view.accessibility.AccessibilityNodeInfo) v0;
        _result = v0.setAccessibilityFocused(v1); // android.view.accessibility.AccessibilityNodeInfo.setAccessibilityFocused -> void
        return;
    }

    public static boolean c(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        v1 = (android.view.accessibility.AccessibilityNodeInfo) v1;
        _result = v1.isAccessibilityFocused(); // android.view.accessibility.AccessibilityNodeInfo.isAccessibilityFocused -> boolean
        v0 = _result;
        return v0;
    }

}