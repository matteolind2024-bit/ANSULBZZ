package android.support.v4.view;

/**
 * Original SourceFile: KeyEventCompat.java
 * Descriptor: Landroid/support/v4/view/w;
 */
interface w {
    public abstract void a(android.view.KeyEvent p0);
    public abstract boolean a(int p0, int p1);
    public abstract boolean b(int p0);
}