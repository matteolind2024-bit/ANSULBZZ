package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/at;
 */
public class at {
    static final android.support.v4.view.bc a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 19;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.bb;
        _result = v0.<init>(); // android.support.v4.view.bb.<init> -> void
        android.support.v4.view.at.a = v0; // :android.support.v4.view.bc
        return;
        v1 = 17;
        if (v0 < v1) /* goto L_001a */;
        v0 = new android.support.v4.view.ba;
        _result = v0.<init>(); // android.support.v4.view.ba.<init> -> void
        android.support.v4.view.at.a = v0; // :android.support.v4.view.bc
        // goto L_000d
        v1 = 16;
        if (v0 < v1) /* goto L_0026 */;
        v0 = new android.support.v4.view.az;
        _result = v0.<init>(); // android.support.v4.view.az.<init> -> void
        android.support.v4.view.at.a = v0; // :android.support.v4.view.bc
        // goto L_000d
        v1 = 14;
        if (v0 < v1) /* goto L_0032 */;
        v0 = new android.support.v4.view.ay;
        _result = v0.<init>(); // android.support.v4.view.ay.<init> -> void
        android.support.v4.view.at.a = v0; // :android.support.v4.view.bc
        // goto L_000d
        v1 = 11;
        if (v0 < v1) /* goto L_003e */;
        v0 = new android.support.v4.view.ax;
        _result = v0.<init>(); // android.support.v4.view.ax.<init> -> void
        android.support.v4.view.at.a = v0; // :android.support.v4.view.bc
        // goto L_000d
        v1 = 9;
        if (v0 < v1) /* goto L_004a */;
        v0 = new android.support.v4.view.aw;
        _result = v0.<init>(); // android.support.v4.view.aw.<init> -> void
        android.support.v4.view.at.a = v0; // :android.support.v4.view.bc
        // goto L_000d
        v0 = new android.support.v4.view.au;
        _result = v0.<init>(); // android.support.v4.view.au.<init> -> void
        android.support.v4.view.at.a = v0; // :android.support.v4.view.bc
        // goto L_000d
    }

    public static int a(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.a(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public static void a(android.view.View p0, int p1, int p2, int p3, int p4) {
        // Registers (11 total): v6 = p0 (android.view.View), v7 = p1 (int), v8 = p2 (int), v9 = p3 (int), v10 = p4 (int)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        v1 = v6;
        v2 = v7;
        v3 = v8;
        v4 = v9;
        v5 = v10;
        _result = android.support.v4.view.bc.a(v0..v5); // -> void
        return;
    }

    public static void a(android.view.View p0, int p1, android.graphics.Paint p2) {
        // Registers (4 total): v1 = p0 (android.view.View), v2 = p1 (int), v3 = p2 (android.graphics.Paint)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.a(v0, v1, v2, v3); // -> void
        return;
    }

    public static void a(android.view.View p0, android.graphics.Paint p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (android.graphics.Paint)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.a(v0, v1, v2); // -> void
        return;
    }

    public static void a(android.view.View p0, android.support.v4.view.a p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (android.support.v4.view.a)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.a(v0, v1, v2); // -> void
        return;
    }

    public static void a(android.view.View p0, java.lang.Runnable p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (java.lang.Runnable)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.a(v0, v1, v2); // -> void
        return;
    }

    public static boolean a(android.view.View p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (int)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.a(v0, v1, v2); // -> boolean
        v0 = _result;
        return v0;
    }

    public static void b(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.b(v0, v1); // -> void
        return;
    }

    public static void b(android.view.View p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (int)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.b(v0, v1, v2); // -> void
        return;
    }

    public static int c(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.c(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public static int d(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.d(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public static int e(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.e(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public static android.view.ViewParent f(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.f(v0, v1); // -> android.view.ViewParent
        v0 = _result;
        return v0;
    }

    public static boolean g(android.view.View p0) {
        // Registers (2 total): v1 = p0 (android.view.View)
        v0 = android.support.v4.view.at.a; // :android.support.v4.view.bc
        _result = android.support.v4.view.bc.g(v0, v1); // -> boolean
        v0 = _result;
        return v0;
    }

}