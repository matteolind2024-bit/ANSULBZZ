package android.support.v4.widget;

/**
 * Original SourceFile: CursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/f;
 */
class f extends android.database.DataSetObserver {
    final android.support.v4.widget.c a;

    private f(android.support.v4.widget.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.widget.c)
        v0.a = v1; // android.support.v4.widget.f.a:android.support.v4.widget.c
        _result = v0.<init>(); // android.database.DataSetObserver.<init> -> void
        return;
    }

    f(android.support.v4.widget.c p0, android.support.v4.widget.d p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.widget.c), v2 = p1 (android.support.v4.widget.d)
        _result = v0.<init>(v1); // android.support.v4.widget.f.<init> -> void
        return;
    }

    public void onChanged() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // android.support.v4.widget.f.a:android.support.v4.widget.c
        v1 = 1;
        v0.a = v1; // android.support.v4.widget.c.a:boolean
        v0 = v2.a; // android.support.v4.widget.f.a:android.support.v4.widget.c
        _result = v0.notifyDataSetChanged(); // android.support.v4.widget.c.notifyDataSetChanged -> void
        return;
    }

    public void onInvalidated() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // android.support.v4.widget.f.a:android.support.v4.widget.c
        v1 = 0;
        v0.a = v1; // android.support.v4.widget.c.a:boolean
        v0 = v2.a; // android.support.v4.widget.f.a:android.support.v4.widget.c
        _result = v0.notifyDataSetInvalidated(); // android.support.v4.widget.c.notifyDataSetInvalidated -> void
        return;
    }

}