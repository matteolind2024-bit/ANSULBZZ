package android.support.v4.app;

/**
 * Original SourceFile: LoaderManager.java
 * Descriptor: Landroid/support/v4/app/ap;
 */
final class ap implements android.support.v4.content.h {
    final int a;
    final android.os.Bundle b;
     android.support.v4.app.an c;
     android.support.v4.content.f d;
     boolean e;
     boolean f;
     java.lang.Object g;
     boolean h;
     boolean i;
     boolean j;
     boolean k;
     boolean l;
     boolean m;
     android.support.v4.app.ap n;
    final android.support.v4.app.ao o;

    public ap(android.support.v4.app.ao p0, int p1, android.os.Bundle p2, android.support.v4.app.an p3) {
        // Registers (5 total): v0 = this, v1 = p0 (android.support.v4.app.ao), v2 = p1 (int), v3 = p2 (android.os.Bundle), v4 = p3 (android.support.v4.app.an)
        v0.o = v1; // android.support.v4.app.ap.o:android.support.v4.app.ao
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v2; // android.support.v4.app.ap.a:int
        v0.b = v3; // android.support.v4.app.ap.b:android.os.Bundle
        v0.c = v4; // android.support.v4.app.ap.c:android.support.v4.app.an
        return;
    }

    void a() {
        // Registers (5 total): v4 = this
        v3 = 1;
        v0 = v4.i; // android.support.v4.app.ap.i:boolean
        if (v0 == 0) /* goto L_000c */;
        v0 = v4.j; // android.support.v4.app.ap.j:boolean
        if (v0 == 0) /* goto L_000c */;
        v4.h = v3; // android.support.v4.app.ap.h:boolean
        return;
        v0 = v4.h; // android.support.v4.app.ap.h:boolean
        if (v0 != 0) /* goto L_000b */;
        v4.h = v3; // android.support.v4.app.ap.h:boolean
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_0030 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "  Starting: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v4.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        if (v0 != 0) /* goto L_0044 */;
        v0 = v4.c; // android.support.v4.app.ap.c:android.support.v4.app.an
        if (v0 == 0) /* goto L_0044 */;
        v0 = v4.c; // android.support.v4.app.ap.c:android.support.v4.app.an
        v1 = v4.a; // android.support.v4.app.ap.a:int
        v2 = v4.b; // android.support.v4.app.ap.b:android.os.Bundle
        _result = android.support.v4.app.an.a(v0, v1, v2); // -> android.support.v4.content.f
        v0 = _result;
        v4.d = v0; // android.support.v4.app.ap.d:android.support.v4.content.f
        v0 = v4.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        if (v0 == 0) /* goto L_000b */;
        v0 = v4.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v0.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.isMemberClass(); // java.lang.Class.isMemberClass -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0080 */;
        v0 = v4.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v0.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getModifiers(); // java.lang.Class.getModifiers -> int
        v0 = _result;
        _result = v0.isStatic(); // java.lang.reflect.Modifier.isStatic -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0080 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Object returned from onCreateLoader must not be a non-static inner member class: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v4.m; // android.support.v4.app.ap.m:boolean
        if (v0 != 0) /* goto L_008d */;
        v0 = v4.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        v1 = v4.a; // android.support.v4.app.ap.a:int
        _result = v0.a(v1, v4); // android.support.v4.content.f.a -> void
        v4.m = v3; // android.support.v4.app.ap.m:boolean
        v0 = v4.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v0.o(); // android.support.v4.content.f.o -> void
        // goto L_000b
    }

    public void a(android.support.v4.content.f p0, java.lang.Object p1) {
        // Registers (8 total): v5 = this, v6 = p0 (android.support.v4.content.f), v7 = p1 (java.lang.Object)
        v4 = 0;
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_001f */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "onLoadComplete: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v5.l; // android.support.v4.app.ap.l:boolean
        if (v0 == 0) /* goto L_0031 */;
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_0030 */;
        v0 = "LoaderManager";
        v1 = "  Ignoring load complete -- destroyed";
        _result = v0.v(v1); // android.util.Log.v -> int
        return;
        v0 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        v1 = v5.a; // android.support.v4.app.ap.a:int
        _result = v0.a(v1); // android.support.v4.c.n.a -> java.lang.Object
        v0 = _result;
        if (v0 == v5) /* goto L_004b */;
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_0030 */;
        v0 = "LoaderManager";
        v1 = "  Ignoring load complete -- not active";
        _result = v0.v(v1); // android.util.Log.v -> int
        // goto L_0030
        v0 = v5.n; // android.support.v4.app.ap.n:android.support.v4.app.ap
        if (v0 == 0) /* goto L_0081 */;
        v1 = android.support.v4.app.ao.a; // :boolean
        if (v1 == 0) /* goto L_006d */;
        v1 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Switching to pending loader: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.v(v2); // android.util.Log.v -> int
        v5.n = v4; // android.support.v4.app.ap.n:android.support.v4.app.ap
        v1 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v1 = v1.b; // android.support.v4.app.ao.b:android.support.v4.c.n
        v2 = v5.a; // android.support.v4.app.ap.a:int
        _result = v1.b(v2, v4); // android.support.v4.c.n.b -> void
        _result = v5.f(); // android.support.v4.app.ap.f -> void
        v1 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        _result = v1.a(v0); // android.support.v4.app.ao.a -> void
        // goto L_0030
        v0 = v5.g; // android.support.v4.app.ap.g:java.lang.Object
        if (v0 != v7) /* goto L_0089 */;
        v0 = v5.e; // android.support.v4.app.ap.e:boolean
        if (v0 != 0) /* goto L_0095 */;
        v5.g = v7; // android.support.v4.app.ap.g:java.lang.Object
        v0 = 1;
        v5.e = v0; // android.support.v4.app.ap.e:boolean
        v0 = v5.h; // android.support.v4.app.ap.h:boolean
        if (v0 == 0) /* goto L_0095 */;
        _result = v5.b(v6, v7); // android.support.v4.app.ap.b -> void
        v0 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        v1 = v5.a; // android.support.v4.app.ap.a:int
        _result = v0.a(v1); // android.support.v4.c.n.a -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.ap) v0;
        if (v0 == 0) /* goto L_00b4 */;
        if (v0 == v5) /* goto L_00b4 */;
        v1 = 0;
        v0.f = v1; // android.support.v4.app.ap.f:boolean
        _result = v0.f(); // android.support.v4.app.ap.f -> void
        v0 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.c; // android.support.v4.app.ao.c:android.support.v4.c.n
        v1 = v5.a; // android.support.v4.app.ap.a:int
        _result = v0.c(v1); // android.support.v4.c.n.c -> void
        v0 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_0030 */;
        v0 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        _result = v0.a(); // android.support.v4.app.ao.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0030 */;
        v0 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        v0 = v0.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        _result = v0.e(); // android.support.v4.app.y.e -> void
        // goto L_0030
    }

    public void a(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (8 total): v3 = this, v4 = p0 (java.lang.String), v5 = p1 (java.io.FileDescriptor), v6 = p2 (java.io.PrintWriter), v7 = p3 (java.lang.String[])
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mId=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.a; // android.support.v4.app.ap.a:int
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mArgs=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.b; // android.support.v4.app.ap.b:android.os.Bundle
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mCallbacks=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.c; // android.support.v4.app.ap.c:android.support.v4.app.an
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mLoader=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        if (v0 == 0) /* goto L_0052 */;
        v0 = v3.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "  ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.a(v1, v5, v6, v7); // android.support.v4.content.f.a -> void
        v0 = v3.e; // android.support.v4.app.ap.e:boolean
        if (v0 != 0) /* goto L_005a */;
        v0 = v3.f; // android.support.v4.app.ap.f:boolean
        if (v0 == 0) /* goto L_0081 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mHaveData=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.e; // android.support.v4.app.ap.e:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = "  mDeliveredData=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.f; // android.support.v4.app.ap.f:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mData=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.g; // android.support.v4.app.ap.g:java.lang.Object
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mStarted=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.h; // android.support.v4.app.ap.h:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mReportNextStart=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.k; // android.support.v4.app.ap.k:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mDestroyed=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.l; // android.support.v4.app.ap.l:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mRetaining=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.i; // android.support.v4.app.ap.i:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mRetainingStarted=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.j; // android.support.v4.app.ap.j:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mListenerRegistered=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.m; // android.support.v4.app.ap.m:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.n; // android.support.v4.app.ap.n:android.support.v4.app.ap
        if (v0 == 0) /* goto L_00fa */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "Pending Loader ";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.n; // android.support.v4.app.ap.n:android.support.v4.app.ap
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = ":";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.n; // android.support.v4.app.ap.n:android.support.v4.app.ap
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "  ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.a(v1, v5, v6, v7); // android.support.v4.app.ap.a -> void
        return;
    }

    void b() {
        // Registers (4 total): v3 = this
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_001e */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "  Retaining: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = 1;
        v3.i = v0; // android.support.v4.app.ap.i:boolean
        v0 = v3.h; // android.support.v4.app.ap.h:boolean
        v3.j = v0; // android.support.v4.app.ap.j:boolean
        v0 = 0;
        v3.h = v0; // android.support.v4.app.ap.h:boolean
        v0 = 0;
        v3.c = v0; // android.support.v4.app.ap.c:android.support.v4.app.an
        return;
    }

    void b(android.support.v4.content.f p0, java.lang.Object p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.support.v4.content.f), v6 = p1 (java.lang.Object)
        v0 = v4.c; // android.support.v4.app.ap.c:android.support.v4.app.an
        if (v0 == 0) /* goto L_0062 */;
        v0 = 0;
        v1 = v4.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v1 = v1.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        if (v1 == 0) /* goto L_0073 */;
        v0 = v4.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        v0 = v0.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v0 = v0.u; // android.support.v4.app.y.u:java.lang.String
        v1 = v4.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v1 = v1.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        v1 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v2 = "onLoadFinished";
        v1.u = v2; // android.support.v4.app.y.u:java.lang.String
        v1 = v0;
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_004c */;
        v0 = "LoaderManager";
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  onLoadFinished in ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v5.c(v6); // android.support.v4.content.f.c -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v0.v(v2); // android.util.Log.v -> int
        v0 = v4.c; // android.support.v4.app.ap.c:android.support.v4.app.an
        _result = android.support.v4.app.an.a(v0, v5, v6); // -> void
        v0 = v4.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_005f */;
        v0 = v4.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        v0 = v0.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v0.u = v1; // android.support.v4.app.y.u:java.lang.String
        v0 = 1;
        v4.f = v0; // android.support.v4.app.ap.f:boolean
        return;
        v0 = _exception;
        v2 = v4.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v2 = v2.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        if (v2 == 0) /* goto L_0072 */;
        v2 = v4.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v2 = v2.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        v2 = v2.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v2.u = v1; // android.support.v4.app.y.u:java.lang.String
        throw v0;
        v1 = v0;
        // goto L_001f
    }

    void c() {
        // Registers (4 total): v3 = this
        v0 = v3.i; // android.support.v4.app.ap.i:boolean
        if (v0 == 0) /* goto L_0032 */;
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_0022 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "  Finished Retaining: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = 0;
        v3.i = v0; // android.support.v4.app.ap.i:boolean
        v0 = v3.h; // android.support.v4.app.ap.h:boolean
        v1 = v3.j; // android.support.v4.app.ap.j:boolean
        if (v0 == v1) /* goto L_0032 */;
        v0 = v3.h; // android.support.v4.app.ap.h:boolean
        if (v0 != 0) /* goto L_0032 */;
        _result = v3.e(); // android.support.v4.app.ap.e -> void
        v0 = v3.h; // android.support.v4.app.ap.h:boolean
        if (v0 == 0) /* goto L_0045 */;
        v0 = v3.e; // android.support.v4.app.ap.e:boolean
        if (v0 == 0) /* goto L_0045 */;
        v0 = v3.k; // android.support.v4.app.ap.k:boolean
        if (v0 != 0) /* goto L_0045 */;
        v0 = v3.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        v1 = v3.g; // android.support.v4.app.ap.g:java.lang.Object
        _result = v3.b(v0, v1); // android.support.v4.app.ap.b -> void
        return;
    }

    void d() {
        // Registers (3 total): v2 = this
        v0 = v2.h; // android.support.v4.app.ap.h:boolean
        if (v0 == 0) /* goto L_0016 */;
        v0 = v2.k; // android.support.v4.app.ap.k:boolean
        if (v0 == 0) /* goto L_0016 */;
        v0 = 0;
        v2.k = v0; // android.support.v4.app.ap.k:boolean
        v0 = v2.e; // android.support.v4.app.ap.e:boolean
        if (v0 == 0) /* goto L_0016 */;
        v0 = v2.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        v1 = v2.g; // android.support.v4.app.ap.g:java.lang.Object
        _result = v2.b(v0, v1); // android.support.v4.app.ap.b -> void
        return;
    }

    void e() {
        // Registers (5 total): v4 = this
        v3 = 0;
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_001f */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "  Stopping: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v4.h = v3; // android.support.v4.app.ap.h:boolean
        v0 = v4.i; // android.support.v4.app.ap.i:boolean
        if (v0 != 0) /* goto L_0039 */;
        v0 = v4.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        if (v0 == 0) /* goto L_0039 */;
        v0 = v4.m; // android.support.v4.app.ap.m:boolean
        if (v0 == 0) /* goto L_0039 */;
        v4.m = v3; // android.support.v4.app.ap.m:boolean
        v0 = v4.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v0.a(v4); // android.support.v4.content.f.a -> void
        v0 = v4.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v0.q(); // android.support.v4.content.f.q -> void
        return;
    }

    void f() {
        // Registers (6 total): v5 = this
        v2 = 0;
        v4 = 0;
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_0020 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Destroying: ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = 1;
        v5.l = v0; // android.support.v4.app.ap.l:boolean
        v0 = v5.f; // android.support.v4.app.ap.f:boolean
        v5.f = v4; // android.support.v4.app.ap.f:boolean
        v1 = v5.c; // android.support.v4.app.ap.c:android.support.v4.app.an
        if (v1 == 0) /* goto L_0082 */;
        v1 = v5.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        if (v1 == 0) /* goto L_0082 */;
        v1 = v5.e; // android.support.v4.app.ap.e:boolean
        if (v1 == 0) /* goto L_0082 */;
        if (v0 == 0) /* goto L_0082 */;
        v0 = android.support.v4.app.ao.a; // :boolean
        if (v0 == 0) /* goto L_0053 */;
        v0 = "LoaderManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "  Reseting: ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_00b6 */;
        v0 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        v0 = v0.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v0 = v0.u; // android.support.v4.app.y.u:java.lang.String
        v1 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v1 = v1.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        v1 = v1.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v3 = "onLoaderReset";
        v1.u = v3; // android.support.v4.app.y.u:java.lang.String
        v1 = v0;
        v0 = v5.c; // android.support.v4.app.ap.c:android.support.v4.app.an
        v3 = v5.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = android.support.v4.app.an.a(v0, v3); // -> void
        v0 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_0082 */;
        v0 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v0 = v0.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        v0 = v0.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v0.u = v1; // android.support.v4.app.y.u:java.lang.String
        v5.c = v2; // android.support.v4.app.ap.c:android.support.v4.app.an
        v5.g = v2; // android.support.v4.app.ap.g:java.lang.Object
        v5.e = v4; // android.support.v4.app.ap.e:boolean
        v0 = v5.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        if (v0 == 0) /* goto L_009c */;
        v0 = v5.m; // android.support.v4.app.ap.m:boolean
        if (v0 == 0) /* goto L_0097 */;
        v5.m = v4; // android.support.v4.app.ap.m:boolean
        v0 = v5.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v0.a(v5); // android.support.v4.content.f.a -> void
        v0 = v5.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v0.t(); // android.support.v4.content.f.t -> void
        v0 = v5.n; // android.support.v4.app.ap.n:android.support.v4.app.ap
        if (v0 == 0) /* goto L_00a5 */;
        v0 = v5.n; // android.support.v4.app.ap.n:android.support.v4.app.ap
        _result = v0.f(); // android.support.v4.app.ap.f -> void
        return;
        v0 = _exception;
        v2 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v2 = v2.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        if (v2 == 0) /* goto L_00b5 */;
        v2 = v5.o; // android.support.v4.app.ap.o:android.support.v4.app.ao
        v2 = v2.e; // android.support.v4.app.ao.e:android.support.v4.app.FragmentActivity
        v2 = v2.b; // android.support.v4.app.FragmentActivity.b:android.support.v4.app.y
        v2.u = v1; // android.support.v4.app.y.u:java.lang.String
        throw v0;
        v1 = v2;
        // goto L_006d
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 64;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = "LoaderInfo{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v2.identityHashCode(); // java.lang.System.identityHashCode -> int
        v1 = _result;
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = " #";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.a; // android.support.v4.app.ap.a:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = " : ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.d; // android.support.v4.app.ap.d:android.support.v4.content.f
        _result = v1.a(v0); // android.support.v4.c.d.a -> void
        v1 = "}}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}