package android.support.v4.widget;

/**
 * Original SourceFile: SimpleCursorAdapter.java
 * Descriptor: Landroid/support/v4/widget/ab;
 */
public interface ab {
    public abstract boolean a(android.view.View p0, android.database.Cursor p1, int p2);
}