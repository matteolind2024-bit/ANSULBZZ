package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeProviderCompat.java
 * Descriptor: Landroid/support/v4/view/a/l;
 */
interface l {
    public abstract java.lang.Object a(android.support.v4.view.a.k p0);
}