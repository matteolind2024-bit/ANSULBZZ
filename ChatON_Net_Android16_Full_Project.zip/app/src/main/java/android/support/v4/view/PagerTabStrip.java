package android.support.v4.view;

/**
 * Original SourceFile: PagerTabStrip.java
 * Descriptor: Landroid/support/v4/view/PagerTabStrip;
 */
public class PagerTabStrip extends android.support.v4.view.PagerTitleStrip {
    private int f;
    private int g;
    private int h;
    private int i;
    private int j;
    private int k;
    private final android.graphics.Paint l;
    private final android.graphics.Rect m;
    private int n;
    private boolean o;
    private boolean p;
    private int q;
    private boolean r;
    private float s;
    private float t;
    private int u;

    public PagerTabStrip(android.content.Context p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.Context)
        v0 = 0;
        _result = v1.<init>(v2, v0); // android.support.v4.view.PagerTabStrip.<init> -> void
        return;
    }

    public PagerTabStrip(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (9 total): v6 = this, v7 = p0 (android.content.Context), v8 = p1 (android.util.AttributeSet)
        v5 = 1;
        v4 = 0;
        v2 = 0x3f000000;
        _result = v6.<init>(v7, v8); // android.support.v4.view.PagerTitleStrip.<init> -> void
        v0 = new android.graphics.Paint;
        _result = v0.<init>(); // android.graphics.Paint.<init> -> void
        v6.l = v0; // android.support.v4.view.PagerTabStrip.l:android.graphics.Paint
        v0 = new android.graphics.Rect;
        _result = v0.<init>(); // android.graphics.Rect.<init> -> void
        v6.m = v0; // android.support.v4.view.PagerTabStrip.m:android.graphics.Rect
        v0 = 255;
        v6.n = v0; // android.support.v4.view.PagerTabStrip.n:int
        v6.o = v4; // android.support.v4.view.PagerTabStrip.o:boolean
        v6.p = v4; // android.support.v4.view.PagerTabStrip.p:boolean
        v0 = v6.e; // android.support.v4.view.PagerTabStrip.e:int
        v6.f = v0; // android.support.v4.view.PagerTabStrip.f:int
        v0 = v6.l; // android.support.v4.view.PagerTabStrip.l:android.graphics.Paint
        v1 = v6.f; // android.support.v4.view.PagerTabStrip.f:int
        _result = v0.setColor(v1); // android.graphics.Paint.setColor -> void
        _result = v7.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDisplayMetrics(); // android.content.res.Resources.getDisplayMetrics -> android.util.DisplayMetrics
        v0 = _result;
        v0 = v0.density; // android.util.DisplayMetrics.density:float
        v1 = 0x40400000;
        v1 = binOp2addr_0xc8(v1, v0);
        v1 = binOp2addr_0xc6(v1, v2);
        v1 = unaryOp_0x87(v1);
        v6.g = v1; // android.support.v4.view.PagerTabStrip.g:int
        v1 = 0x40c00000;
        v1 = binOp2addr_0xc8(v1, v0);
        v1 = binOp2addr_0xc6(v1, v2);
        v1 = unaryOp_0x87(v1);
        v6.h = v1; // android.support.v4.view.PagerTabStrip.h:int
        v1 = 0x42800000;
        v1 = binOp2addr_0xc8(v1, v0);
        v1 = unaryOp_0x87(v1);
        v6.i = v1; // android.support.v4.view.PagerTabStrip.i:int
        v1 = 0x41800000;
        v1 = binOp2addr_0xc8(v1, v0);
        v1 = binOp2addr_0xc6(v1, v2);
        v1 = unaryOp_0x87(v1);
        v6.k = v1; // android.support.v4.view.PagerTabStrip.k:int
        v1 = 0x3f800000;
        v1 = binOp2addr_0xc8(v1, v0);
        v1 = binOp2addr_0xc6(v1, v2);
        v1 = unaryOp_0x87(v1);
        v6.q = v1; // android.support.v4.view.PagerTabStrip.q:int
        v1 = 0x42000000;
        v0 = binOp2addr_0xc8(v0, v1);
        v0 = binOp2addr_0xc6(v0, v2);
        v0 = unaryOp_0x87(v0);
        v6.j = v0; // android.support.v4.view.PagerTabStrip.j:int
        _result = v7.get(); // android.view.ViewConfiguration.get -> android.view.ViewConfiguration
        v0 = _result;
        _result = v0.getScaledTouchSlop(); // android.view.ViewConfiguration.getScaledTouchSlop -> int
        v0 = _result;
        v6.u = v0; // android.support.v4.view.PagerTabStrip.u:int
        _result = v6.getPaddingLeft(); // android.support.v4.view.PagerTabStrip.getPaddingLeft -> int
        v0 = _result;
        _result = v6.getPaddingTop(); // android.support.v4.view.PagerTabStrip.getPaddingTop -> int
        v1 = _result;
        _result = v6.getPaddingRight(); // android.support.v4.view.PagerTabStrip.getPaddingRight -> int
        v2 = _result;
        _result = v6.getPaddingBottom(); // android.support.v4.view.PagerTabStrip.getPaddingBottom -> int
        v3 = _result;
        _result = v6.setPadding(v0, v1, v2, v3); // android.support.v4.view.PagerTabStrip.setPadding -> void
        _result = v6.b(); // android.support.v4.view.PagerTabStrip.b -> int
        v0 = _result;
        _result = v6.setTextSpacing(v0); // android.support.v4.view.PagerTabStrip.setTextSpacing -> void
        _result = v6.setWillNotDraw(v4); // android.support.v4.view.PagerTabStrip.setWillNotDraw -> void
        v0 = v6.b; // android.support.v4.view.PagerTabStrip.b:android.widget.TextView
        _result = v0.setFocusable(v5); // android.widget.TextView.setFocusable -> void
        v0 = v6.b; // android.support.v4.view.PagerTabStrip.b:android.widget.TextView
        v1 = new android.support.v4.view.af;
        _result = v1.<init>(v6); // android.support.v4.view.af.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.TextView.setOnClickListener -> void
        v0 = v6.d; // android.support.v4.view.PagerTabStrip.d:android.widget.TextView
        _result = v0.setFocusable(v5); // android.widget.TextView.setFocusable -> void
        v0 = v6.d; // android.support.v4.view.PagerTabStrip.d:android.widget.TextView
        v1 = new android.support.v4.view.ag;
        _result = v1.<init>(v6); // android.support.v4.view.ag.<init> -> void
        _result = v0.setOnClickListener(v1); // android.widget.TextView.setOnClickListener -> void
        _result = v6.getBackground(); // android.support.v4.view.PagerTabStrip.getBackground -> android.graphics.drawable.Drawable
        v0 = _result;
        if (v0 != 0) /* goto L_00a8 */;
        v6.o = v5; // android.support.v4.view.PagerTabStrip.o:boolean
        return;
    }

    int a() {
        // Registers (3 total): v2 = this
        _result = v2.a(); // android.support.v4.view.PagerTitleStrip.a -> int
        v0 = _result;
        v1 = v2.j; // android.support.v4.view.PagerTabStrip.j:int
        _result = v0.max(v1); // java.lang.Math.max -> int
        v0 = _result;
        return v0;
    }

    void a(int p0, float p1, boolean p2) {
        // Registers (10 total): v6 = this, v7 = p0 (int), v8 = p1 (float), v9 = p2 (boolean)
        v0 = v6.m; // android.support.v4.view.PagerTabStrip.m:android.graphics.Rect
        _result = v6.getHeight(); // android.support.v4.view.PagerTabStrip.getHeight -> int
        v1 = _result;
        v2 = v6.c; // android.support.v4.view.PagerTabStrip.c:android.widget.TextView
        _result = v2.getLeft(); // android.widget.TextView.getLeft -> int
        v2 = _result;
        v3 = v6.k; // android.support.v4.view.PagerTabStrip.k:int
        v2 = binOp2addr_0xb1(v2, v3);
        v3 = v6.c; // android.support.v4.view.PagerTabStrip.c:android.widget.TextView
        _result = v3.getRight(); // android.widget.TextView.getRight -> int
        v3 = _result;
        v4 = v6.k; // android.support.v4.view.PagerTabStrip.k:int
        v3 = binOp2addr_0xb0(v3, v4);
        v4 = v6.g; // android.support.v4.view.PagerTabStrip.g:int
        v4 = binOp_0x91(v1, v4);
        _result = v0.set(v2, v4, v3, v1); // android.graphics.Rect.set -> void
        _result = v6.a(v7, v8, v9); // android.support.v4.view.PagerTitleStrip.a -> void
        v2 = 0x3f000000;
        v2 = binOp_0xa7(v8, v2);
        _result = v2.abs(); // java.lang.Math.abs -> float
        v2 = _result;
        v3 = 0x40000000;
        v2 = binOp2addr_0xc8(v2, v3);
        v3 = 0x437f0000;
        v2 = binOp2addr_0xc8(v2, v3);
        v2 = unaryOp_0x87(v2);
        v6.n = v2; // android.support.v4.view.PagerTabStrip.n:int
        v2 = v6.c; // android.support.v4.view.PagerTabStrip.c:android.widget.TextView
        _result = v2.getLeft(); // android.widget.TextView.getLeft -> int
        v2 = _result;
        v3 = v6.k; // android.support.v4.view.PagerTabStrip.k:int
        v2 = binOp2addr_0xb1(v2, v3);
        v3 = v6.c; // android.support.v4.view.PagerTabStrip.c:android.widget.TextView
        _result = v3.getRight(); // android.widget.TextView.getRight -> int
        v3 = _result;
        v5 = v6.k; // android.support.v4.view.PagerTabStrip.k:int
        v3 = binOp2addr_0xb0(v3, v5);
        _result = v0.union(v2, v4, v3, v1); // android.graphics.Rect.union -> void
        _result = v6.invalidate(v0); // android.support.v4.view.PagerTabStrip.invalidate -> void
        return;
    }

    protected void onDraw(android.graphics.Canvas p0) {
        // Registers (10 total): v8 = this, v9 = p0 (android.graphics.Canvas)
        v7 = 16777215; // 0x00ffffff
        _result = v8.onDraw(v9); // android.support.v4.view.PagerTitleStrip.onDraw -> void
        _result = v8.getHeight(); // android.support.v4.view.PagerTabStrip.getHeight -> int
        v6 = _result;
        v0 = v8.c; // android.support.v4.view.PagerTabStrip.c:android.widget.TextView
        _result = v0.getLeft(); // android.widget.TextView.getLeft -> int
        v0 = _result;
        v1 = v8.k; // android.support.v4.view.PagerTabStrip.k:int
        v0 = binOp2addr_0xb1(v0, v1);
        v1 = v8.c; // android.support.v4.view.PagerTabStrip.c:android.widget.TextView
        _result = v1.getRight(); // android.widget.TextView.getRight -> int
        v1 = _result;
        v2 = v8.k; // android.support.v4.view.PagerTabStrip.k:int
        v3 = binOp_0x90(v1, v2);
        v1 = v8.g; // android.support.v4.view.PagerTabStrip.g:int
        v2 = binOp_0x91(v6, v1);
        v1 = v8.l; // android.support.v4.view.PagerTabStrip.l:android.graphics.Paint
        v4 = v8.n; // android.support.v4.view.PagerTabStrip.n:int
        v4 = binOpLit8_0xe0(v4, 24);
        v5 = v8.f; // android.support.v4.view.PagerTabStrip.f:int
        v5 = binOp2addr_0xb5(v5, v7);
        v4 = binOp2addr_0xb6(v4, v5);
        _result = v1.setColor(v4); // android.graphics.Paint.setColor -> void
        v1 = unaryOp_0x82(v0);
        v2 = unaryOp_0x82(v2);
        v3 = unaryOp_0x82(v3);
        v4 = unaryOp_0x82(v6);
        v5 = v8.l; // android.support.v4.view.PagerTabStrip.l:android.graphics.Paint
        v0 = v9;
        _result = v0.drawRect(v0..v5); // android.graphics.Canvas.drawRect -> void
        v0 = v8.o; // android.support.v4.view.PagerTabStrip.o:boolean
        if (v0 == 0) /* goto L_0062 */;
        v0 = v8.l; // android.support.v4.view.PagerTabStrip.l:android.graphics.Paint
        v1 = 0xff000000;
        v2 = v8.f; // android.support.v4.view.PagerTabStrip.f:int
        v2 = binOp2addr_0xb5(v2, v7);
        v1 = binOp2addr_0xb6(v1, v2);
        _result = v0.setColor(v1); // android.graphics.Paint.setColor -> void
        _result = v8.getPaddingLeft(); // android.support.v4.view.PagerTabStrip.getPaddingLeft -> int
        v0 = _result;
        v1 = unaryOp_0x82(v0);
        v0 = v8.q; // android.support.v4.view.PagerTabStrip.q:int
        v0 = binOp_0x91(v6, v0);
        v2 = unaryOp_0x82(v0);
        _result = v8.getWidth(); // android.support.v4.view.PagerTabStrip.getWidth -> int
        v0 = _result;
        _result = v8.getPaddingRight(); // android.support.v4.view.PagerTabStrip.getPaddingRight -> int
        v3 = _result;
        v0 = binOp2addr_0xb1(v0, v3);
        v3 = unaryOp_0x82(v0);
        v4 = unaryOp_0x82(v6);
        v5 = v8.l; // android.support.v4.view.PagerTabStrip.l:android.graphics.Paint
        v0 = v9;
        _result = v0.drawRect(v0..v5); // android.graphics.Canvas.drawRect -> void
        return;
    }

    public boolean onTouchEvent(android.view.MotionEvent p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.view.MotionEvent)
        v1 = 1;
        v0 = 0;
        _result = v6.getAction(); // android.view.MotionEvent.getAction -> int
        v2 = _result;
        if (v2 == 0) /* goto L_000d */;
        v3 = v5.r; // android.support.v4.view.PagerTabStrip.r:boolean
        if (v3 == 0) /* goto L_000d */;
        return v0;
        _result = v6.getX(); // android.view.MotionEvent.getX -> float
        v3 = _result;
        _result = v6.getY(); // android.view.MotionEvent.getY -> float
        v4 = _result;
        // switch(v2)
        v0 = v1;
        // goto L_000c
        v5.s = v3; // android.support.v4.view.PagerTabStrip.s:float
        v5.t = v4; // android.support.v4.view.PagerTabStrip.t:float
        v5.r = v0; // android.support.v4.view.PagerTabStrip.r:boolean
        // goto L_0018
        v0 = v5.s; // android.support.v4.view.PagerTabStrip.s:float
        v0 = binOp_0xa7(v3, v0);
        _result = v0.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v2 = v5.u; // android.support.v4.view.PagerTabStrip.u:int
        v2 = unaryOp_0x82(v2);
        v0 = cmp(v0, v2);
        if (v0 > 0) /* goto L_003f */;
        v0 = v5.t; // android.support.v4.view.PagerTabStrip.t:float
        v0 = binOp_0xa7(v4, v0);
        _result = v0.abs(); // java.lang.Math.abs -> float
        v0 = _result;
        v2 = v5.u; // android.support.v4.view.PagerTabStrip.u:int
        v2 = unaryOp_0x82(v2);
        v0 = cmp(v0, v2);
        if (v0 <= 0) /* goto L_0018 */;
        v5.r = v1; // android.support.v4.view.PagerTabStrip.r:boolean
        // goto L_0018
        v0 = v5.c; // android.support.v4.view.PagerTabStrip.c:android.widget.TextView
        _result = v0.getLeft(); // android.widget.TextView.getLeft -> int
        v0 = _result;
        v2 = v5.k; // android.support.v4.view.PagerTabStrip.k:int
        v0 = binOp2addr_0xb1(v0, v2);
        v0 = unaryOp_0x82(v0);
        v0 = cmp(v3, v0);
        if (v0 >= 0) /* goto L_005e */;
        v0 = v5.a; // android.support.v4.view.PagerTabStrip.a:android.support.v4.view.ViewPager
        v2 = v5.a; // android.support.v4.view.PagerTabStrip.a:android.support.v4.view.ViewPager
        _result = v2.c(); // android.support.v4.view.ViewPager.c -> int
        v2 = _result;
        v2 = binOpLit8_0xd8(v2, -1);
        _result = v0.setCurrentItem(v2); // android.support.v4.view.ViewPager.setCurrentItem -> void
        // goto L_0018
        v0 = v5.c; // android.support.v4.view.PagerTabStrip.c:android.widget.TextView
        _result = v0.getRight(); // android.widget.TextView.getRight -> int
        v0 = _result;
        v2 = v5.k; // android.support.v4.view.PagerTabStrip.k:int
        v0 = binOp2addr_0xb0(v0, v2);
        v0 = unaryOp_0x82(v0);
        v0 = cmp(v3, v0);
        if (v0 <= 0) /* goto L_0018 */;
        v0 = v5.a; // android.support.v4.view.PagerTabStrip.a:android.support.v4.view.ViewPager
        v2 = v5.a; // android.support.v4.view.PagerTabStrip.a:android.support.v4.view.ViewPager
        _result = v2.c(); // android.support.v4.view.ViewPager.c -> int
        v2 = _result;
        v2 = binOpLit8_0xd8(v2, 1);
        _result = v0.setCurrentItem(v2); // android.support.v4.view.ViewPager.setCurrentItem -> void
        // goto L_0018
    }

    public void setBackgroundColor(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.setBackgroundColor(v2); // android.support.v4.view.PagerTitleStrip.setBackgroundColor -> void
        v0 = v1.p; // android.support.v4.view.PagerTabStrip.p:boolean
        if (v0 != 0) /* goto L_000f */;
        v0 = 0xff000000;
        v0 = binOp2addr_0xb5(v0, v2);
        if (v0 != 0) /* goto L_0010 */;
        v0 = 1;
        v1.o = v0; // android.support.v4.view.PagerTabStrip.o:boolean
        return;
        v0 = 0;
        // goto L_000d
    }

    public void setBackgroundDrawable(android.graphics.drawable.Drawable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.graphics.drawable.Drawable)
        _result = v1.setBackgroundDrawable(v2); // android.support.v4.view.PagerTitleStrip.setBackgroundDrawable -> void
        v0 = v1.p; // android.support.v4.view.PagerTabStrip.p:boolean
        if (v0 != 0) /* goto L_000c */;
        if (v2 != 0) /* goto L_000d */;
        v0 = 1;
        v1.o = v0; // android.support.v4.view.PagerTabStrip.o:boolean
        return;
        v0 = 0;
        // goto L_000a
    }

    public void setBackgroundResource(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.setBackgroundResource(v2); // android.support.v4.view.PagerTitleStrip.setBackgroundResource -> void
        v0 = v1.p; // android.support.v4.view.PagerTabStrip.p:boolean
        if (v0 != 0) /* goto L_000c */;
        if (v2 != 0) /* goto L_000d */;
        v0 = 1;
        v1.o = v0; // android.support.v4.view.PagerTabStrip.o:boolean
        return;
        v0 = 0;
        // goto L_000a
    }

    public void setDrawFullUnderline(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v1.o = v2; // android.support.v4.view.PagerTabStrip.o:boolean
        v0 = 1;
        v1.p = v0; // android.support.v4.view.PagerTabStrip.p:boolean
        _result = v1.invalidate(); // android.support.v4.view.PagerTabStrip.invalidate -> void
        return;
    }

    public void setPadding(int p0, int p1, int p2, int p3) {
        // Registers (6 total): v1 = this, v2 = p0 (int), v3 = p1 (int), v4 = p2 (int), v5 = p3 (int)
        v0 = v1.h; // android.support.v4.view.PagerTabStrip.h:int
        if (v5 >= v0) /* goto L_0006 */;
        v5 = v1.h; // android.support.v4.view.PagerTabStrip.h:int
        _result = v1.setPadding(v2, v3, v4, v5); // android.support.v4.view.PagerTitleStrip.setPadding -> void
        return;
    }

    public void setTabIndicatorColor(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v2.f = v3; // android.support.v4.view.PagerTabStrip.f:int
        v0 = v2.l; // android.support.v4.view.PagerTabStrip.l:android.graphics.Paint
        v1 = v2.f; // android.support.v4.view.PagerTabStrip.f:int
        _result = v0.setColor(v1); // android.graphics.Paint.setColor -> void
        _result = v2.invalidate(); // android.support.v4.view.PagerTabStrip.invalidate -> void
        return;
    }

    public void setTabIndicatorColorResource(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.getContext(); // android.support.v4.view.PagerTabStrip.getContext -> android.content.Context
        v0 = _result;
        _result = v0.getResources(); // android.content.Context.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getColor(v2); // android.content.res.Resources.getColor -> int
        v0 = _result;
        _result = v1.setTabIndicatorColor(v0); // android.support.v4.view.PagerTabStrip.setTabIndicatorColor -> void
        return;
    }

    public void setTextSpacing(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.i; // android.support.v4.view.PagerTabStrip.i:int
        if (v2 >= v0) /* goto L_0006 */;
        v2 = v1.i; // android.support.v4.view.PagerTabStrip.i:int
        _result = v1.setTextSpacing(v2); // android.support.v4.view.PagerTitleStrip.setTextSpacing -> void
        return;
    }

}