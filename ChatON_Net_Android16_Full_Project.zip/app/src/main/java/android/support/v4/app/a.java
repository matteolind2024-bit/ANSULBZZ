package android.support.v4.app;

/**
 * Original SourceFile: ActionBarDrawerToggle.java
 * Descriptor: Landroid/support/v4/app/a;
 */
public class a implements android.support.v4.widget.j {
    private static final android.support.v4.app.c a;
    private final android.app.Activity b;
    private final android.support.v4.app.f c;
    private final android.support.v4.widget.DrawerLayout d;
    private boolean e;
    private android.graphics.drawable.Drawable f;
    private android.graphics.drawable.Drawable g;
    private android.support.v4.app.h h;
    private final int i;
    private final int j;
    private final int k;
    private java.lang.Object l;

    static {
        v2 = 0;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 11;
        if (v0 < v1) /* goto L_000f */;
        v0 = new android.support.v4.app.e;
        _result = v0.<init>(v2); // android.support.v4.app.e.<init> -> void
        android.support.v4.app.a.a = v0; // :android.support.v4.app.c
        return;
        v0 = new android.support.v4.app.d;
        _result = v0.<init>(v2); // android.support.v4.app.d.<init> -> void
        android.support.v4.app.a.a = v0; // :android.support.v4.app.c
        // goto L_000e
    }

    public a(android.app.Activity p0, android.support.v4.widget.DrawerLayout p1, int p2, int p3, int p4) {
        // Registers (9 total): v3 = this, v4 = p0 (android.app.Activity), v5 = p1 (android.support.v4.widget.DrawerLayout), v6 = p2 (int), v7 = p3 (int), v8 = p4 (int)
        v2 = 0;
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v0 = 1;
        v3.e = v0; // android.support.v4.app.a.e:boolean
        v3.b = v4; // android.support.v4.app.a.b:android.app.Activity
        v0 = (v4 instanceof android.support.v4.app.g);
        if (v0 == 0) /* goto L_0040 */;
        v0 = v4;
        v0 = (android.support.v4.app.g) v0;
        _result = android.support.v4.app.g.a(v0); // -> android.support.v4.app.f
        v0 = _result;
        v3.c = v0; // android.support.v4.app.a.c:android.support.v4.app.f
        v3.d = v5; // android.support.v4.app.a.d:android.support.v4.widget.DrawerLayout
        v3.i = v6; // android.support.v4.app.a.i:int
        v3.j = v7; // android.support.v4.app.a.j:int
        v3.k = v8; // android.support.v4.app.a.k:int
        _result = v3.a(); // android.support.v4.app.a.a -> android.graphics.drawable.Drawable
        v0 = _result;
        v3.f = v0; // android.support.v4.app.a.f:android.graphics.drawable.Drawable
        _result = v4.getResources(); // android.app.Activity.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getDrawable(v6); // android.content.res.Resources.getDrawable -> android.graphics.drawable.Drawable
        v0 = _result;
        v3.g = v0; // android.support.v4.app.a.g:android.graphics.drawable.Drawable
        v0 = new android.support.v4.app.h;
        v1 = v3.g; // android.support.v4.app.a.g:android.graphics.drawable.Drawable
        _result = v0.<init>(v3, v1, v2); // android.support.v4.app.h.<init> -> void
        v3.h = v0; // android.support.v4.app.a.h:android.support.v4.app.h
        v0 = v3.h; // android.support.v4.app.a.h:android.support.v4.app.h
        v1 = 1051372203; // 0x3eaaaaab
        _result = v0.b(v1); // android.support.v4.app.h.b -> void
        return;
        v3.c = v2; // android.support.v4.app.a.c:android.support.v4.app.f
        // goto L_0016
    }

    static android.app.Activity a(android.support.v4.app.a p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.app.a)
        v0 = v1.b; // android.support.v4.app.a.b:android.app.Activity
        return v0;
    }

    android.graphics.drawable.Drawable a() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // android.support.v4.app.a.c:android.support.v4.app.f
        if (v0 == 0) /* goto L_000b */;
        v0 = v2.c; // android.support.v4.app.a.c:android.support.v4.app.f
        _result = android.support.v4.app.f.a(v0); // -> android.graphics.drawable.Drawable
        v0 = _result;
        return v0;
        v0 = android.support.v4.app.a.a; // :android.support.v4.app.c
        v1 = v2.b; // android.support.v4.app.a.b:android.app.Activity
        _result = android.support.v4.app.c.a(v0, v1); // -> android.graphics.drawable.Drawable
        v0 = _result;
        // goto L_000a
    }

    public void a(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        return;
    }

    public void a(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = v2.h; // android.support.v4.app.a.h:android.support.v4.app.h
        v1 = 0x3f800000;
        _result = v0.a(v1); // android.support.v4.app.h.a -> void
        v0 = v2.e; // android.support.v4.app.a.e:boolean
        if (v0 == 0) /* goto L_0010 */;
        v0 = v2.k; // android.support.v4.app.a.k:int
        _result = v2.b(v0); // android.support.v4.app.a.b -> void
        return;
    }

    public void a(android.view.View p0, float p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.view.View), v6 = p1 (float)
        v3 = 0x40000000;
        v2 = 0x3f000000;
        v0 = v4.h; // android.support.v4.app.a.h:android.support.v4.app.h
        _result = v0.a(); // android.support.v4.app.h.a -> float
        v0 = _result;
        v1 = cmp(v6, v2);
        if (v1 <= 0) /* goto L_0020 */;
        v1 = 0;
        v2 = binOp_0xa7(v6, v2);
        _result = v1.max(v2); // java.lang.Math.max -> float
        v1 = _result;
        v1 = binOp2addr_0xc8(v1, v3);
        _result = v0.max(v1); // java.lang.Math.max -> float
        v0 = _result;
        v1 = v4.h; // android.support.v4.app.a.h:android.support.v4.app.h
        _result = v1.a(v0); // android.support.v4.app.h.a -> void
        return;
        v1 = binOp_0xa8(v6, v3);
        _result = v0.min(v1); // java.lang.Math.min -> float
        v0 = _result;
        // goto L_001a
    }

    void b(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.c; // android.support.v4.app.a.c:android.support.v4.app.f
        if (v0 == 0) /* goto L_000a */;
        v0 = v3.c; // android.support.v4.app.a.c:android.support.v4.app.f
        _result = android.support.v4.app.f.a(v0, v4); // -> void
        return;
        v0 = android.support.v4.app.a.a; // :android.support.v4.app.c
        v1 = v3.l; // android.support.v4.app.a.l:java.lang.Object
        v2 = v3.b; // android.support.v4.app.a.b:android.app.Activity
        _result = android.support.v4.app.c.a(v0, v1, v2, v4); // -> java.lang.Object
        v0 = _result;
        v3.l = v0; // android.support.v4.app.a.l:java.lang.Object
        // goto L_0009
    }

    public void b(android.view.View p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.View)
        v0 = v2.h; // android.support.v4.app.a.h:android.support.v4.app.h
        v1 = 0;
        _result = v0.a(v1); // android.support.v4.app.h.a -> void
        v0 = v2.e; // android.support.v4.app.a.e:boolean
        if (v0 == 0) /* goto L_000f */;
        v0 = v2.j; // android.support.v4.app.a.j:int
        _result = v2.b(v0); // android.support.v4.app.a.b -> void
        return;
    }

}