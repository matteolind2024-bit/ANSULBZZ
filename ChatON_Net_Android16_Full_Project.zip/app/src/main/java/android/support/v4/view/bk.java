package android.support.v4.view;

/**
 * Original SourceFile: ViewConfigurationCompat.java
 * Descriptor: Landroid/support/v4/view/bk;
 */
class bk implements android.support.v4.view.bm {
    bk() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public int a(android.view.ViewConfiguration p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewConfiguration)
        _result = v2.getScaledTouchSlop(); // android.view.ViewConfiguration.getScaledTouchSlop -> int
        v0 = _result;
        return v0;
    }

}