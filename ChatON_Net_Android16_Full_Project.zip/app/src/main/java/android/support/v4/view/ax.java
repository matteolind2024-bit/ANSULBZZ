package android.support.v4.view;

/**
 * Original SourceFile: ViewCompat.java
 * Descriptor: Landroid/support/v4/view/ax;
 */
class ax extends android.support.v4.view.aw {
    ax() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.aw.<init> -> void
        return;
    }

    long a() {
        // Registers (3 total): v2 = this
        _result = this.a(); // android.support.v4.view.bf.a -> long
        v0 = _result;
        return v0;
    }

    public void a(android.view.View p0, int p1, android.graphics.Paint p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (int), v3 = p2 (android.graphics.Paint)
        _result = v1.a(v2, v3); // android.support.v4.view.bf.a -> void
        return;
    }

    public void a(android.view.View p0, android.graphics.Paint p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.graphics.Paint)
        _result = v1.d(v2); // android.support.v4.view.ax.d -> int
        v0 = _result;
        _result = v1.a(v2, v0, v3); // android.support.v4.view.ax.a -> void
        _result = v2.invalidate(); // android.view.View.invalidate -> void
        return;
    }

    public int d(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        _result = v2.a(); // android.support.v4.view.bf.a -> int
        v0 = _result;
        return v0;
    }

}