package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompatJellybean.java
 * Descriptor: Landroid/support/v4/app/bf;
 */
class bf {
    private android.app.Notification$Builder a;

    public bf(android.content.Context p0, android.app.Notification p1, java.lang.CharSequence p2, java.lang.CharSequence p3, java.lang.CharSequence p4, android.widget.RemoteViews p5, int p6, android.app.PendingIntent p7, android.app.PendingIntent p8, android.graphics.Bitmap p9, int p10, int p11, boolean p12, boolean p13, int p14, java.lang.CharSequence p15) {
        // Registers (24 total): v7 = this, v8 = p0 (android.content.Context), v9 = p1 (android.app.Notification), v10 = p2 (java.lang.CharSequence), v11 = p3 (java.lang.CharSequence), v12 = p4 (java.lang.CharSequence), v13 = p5 (android.widget.RemoteViews), v14 = p6 (int), v15 = p7 (android.app.PendingIntent), v16 = p8 (android.app.PendingIntent), v17 = p9 (android.graphics.Bitmap), v18 = p10 (int), v19 = p11 (int), v20 = p12 (boolean), v21 = p13 (boolean), v22 = p14 (int), v23 = p15 (java.lang.CharSequence)
        _result = v7.<init>(); // java.lang.Object.<init> -> void
        v3 = new android.app.Notification$Builder;
        _result = v3.<init>(v8); // android.app.Notification$Builder.<init> -> void
        v4 = v9.when; // android.app.Notification.when:long
        _result = v3.setWhen(v4, v5); // android.app.Notification$Builder.setWhen -> android.app.Notification$Builder
        v3 = _result;
        v4 = v9.icon; // android.app.Notification.icon:int
        v5 = v9.iconLevel; // android.app.Notification.iconLevel:int
        _result = v3.setSmallIcon(v4, v5); // android.app.Notification$Builder.setSmallIcon -> android.app.Notification$Builder
        v3 = _result;
        v4 = v9.contentView; // android.app.Notification.contentView:android.widget.RemoteViews
        _result = v3.setContent(v4); // android.app.Notification$Builder.setContent -> android.app.Notification$Builder
        v3 = _result;
        v4 = v9.tickerText; // android.app.Notification.tickerText:java.lang.CharSequence
        _result = v3.setTicker(v4, v13); // android.app.Notification$Builder.setTicker -> android.app.Notification$Builder
        v3 = _result;
        v4 = v9.sound; // android.app.Notification.sound:android.net.Uri
        v5 = v9.audioStreamType; // android.app.Notification.audioStreamType:int
        _result = v3.setSound(v4, v5); // android.app.Notification$Builder.setSound -> android.app.Notification$Builder
        v3 = _result;
        v4 = v9.vibrate; // android.app.Notification.vibrate:long[]
        _result = v3.setVibrate(v4); // android.app.Notification$Builder.setVibrate -> android.app.Notification$Builder
        v3 = _result;
        v4 = v9.ledARGB; // android.app.Notification.ledARGB:int
        v5 = v9.ledOnMS; // android.app.Notification.ledOnMS:int
        v6 = v9.ledOffMS; // android.app.Notification.ledOffMS:int
        _result = v3.setLights(v4, v5, v6); // android.app.Notification$Builder.setLights -> android.app.Notification$Builder
        v4 = _result;
        v3 = v9.flags; // android.app.Notification.flags:int
        v3 = binOpLit8_0xdd(v3, 2);
        if (v3 == 0) /* goto L_00ad */;
        v3 = 1;
        _result = v4.setOngoing(v3); // android.app.Notification$Builder.setOngoing -> android.app.Notification$Builder
        v4 = _result;
        v3 = v9.flags; // android.app.Notification.flags:int
        v3 = binOpLit8_0xdd(v3, 8);
        if (v3 == 0) /* goto L_00af */;
        v3 = 1;
        _result = v4.setOnlyAlertOnce(v3); // android.app.Notification$Builder.setOnlyAlertOnce -> android.app.Notification$Builder
        v4 = _result;
        v3 = v9.flags; // android.app.Notification.flags:int
        v3 = binOpLit8_0xdd(v3, 16);
        if (v3 == 0) /* goto L_00b1 */;
        v3 = 1;
        _result = v4.setAutoCancel(v3); // android.app.Notification$Builder.setAutoCancel -> android.app.Notification$Builder
        v3 = _result;
        v4 = v9.defaults; // android.app.Notification.defaults:int
        _result = v3.setDefaults(v4); // android.app.Notification$Builder.setDefaults -> android.app.Notification$Builder
        v3 = _result;
        _result = v3.setContentTitle(v10); // android.app.Notification$Builder.setContentTitle -> android.app.Notification$Builder
        v3 = _result;
        _result = v3.setContentText(v11); // android.app.Notification$Builder.setContentText -> android.app.Notification$Builder
        v3 = _result;
        v0 = v23;
        _result = v3.setSubText(v0); // android.app.Notification$Builder.setSubText -> android.app.Notification$Builder
        v3 = _result;
        _result = v3.setContentInfo(v12); // android.app.Notification$Builder.setContentInfo -> android.app.Notification$Builder
        v3 = _result;
        _result = v3.setContentIntent(v15); // android.app.Notification$Builder.setContentIntent -> android.app.Notification$Builder
        v3 = _result;
        v4 = v9.deleteIntent; // android.app.Notification.deleteIntent:android.app.PendingIntent
        _result = v3.setDeleteIntent(v4); // android.app.Notification$Builder.setDeleteIntent -> android.app.Notification$Builder
        v4 = _result;
        v3 = v9.flags; // android.app.Notification.flags:int
        v3 = binOpLit16_0xd5(v3, 128);
        if (v3 == 0) /* goto L_00b3 */;
        v3 = 1;
        v0 = v16;
        _result = v4.setFullScreenIntent(v0, v3); // android.app.Notification$Builder.setFullScreenIntent -> android.app.Notification$Builder
        v3 = _result;
        v0 = v17;
        _result = v3.setLargeIcon(v0); // android.app.Notification$Builder.setLargeIcon -> android.app.Notification$Builder
        v3 = _result;
        _result = v3.setNumber(v14); // android.app.Notification$Builder.setNumber -> android.app.Notification$Builder
        v3 = _result;
        v0 = v21;
        _result = v3.setUsesChronometer(v0); // android.app.Notification$Builder.setUsesChronometer -> android.app.Notification$Builder
        v3 = _result;
        v0 = v22;
        _result = v3.setPriority(v0); // android.app.Notification$Builder.setPriority -> android.app.Notification$Builder
        v3 = _result;
        v0 = v18;
        v1 = v19;
        v2 = v20;
        _result = v3.setProgress(v0, v1, v2); // android.app.Notification$Builder.setProgress -> android.app.Notification$Builder
        v3 = _result;
        v7.a = v3; // android.support.v4.app.bf.a:android.app.Notification$Builder
        return;
        v3 = 0;
        // goto L_0041
        v3 = 0;
        // goto L_004c
        v3 = 0;
        // goto L_0057
        v3 = 0;
        // goto L_0084
    }

    public android.app.Notification a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.app.bf.a:android.app.Notification$Builder
        _result = v0.build(); // android.app.Notification$Builder.build -> android.app.Notification
        v0 = _result;
        return v0;
    }

    public void a(int p0, java.lang.CharSequence p1, android.app.PendingIntent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (java.lang.CharSequence), v4 = p2 (android.app.PendingIntent)
        v0 = v1.a; // android.support.v4.app.bf.a:android.app.Notification$Builder
        _result = v0.addAction(v2, v3, v4); // android.app.Notification$Builder.addAction -> android.app.Notification$Builder
        return;
    }

    public void a(java.lang.CharSequence p0, boolean p1, java.lang.CharSequence p2, android.graphics.Bitmap p3, android.graphics.Bitmap p4, boolean p5) {
        // Registers (9 total): v2 = this, v3 = p0 (java.lang.CharSequence), v4 = p1 (boolean), v5 = p2 (java.lang.CharSequence), v6 = p3 (android.graphics.Bitmap), v7 = p4 (android.graphics.Bitmap), v8 = p5 (boolean)
        v0 = new android.app.Notification$BigPictureStyle;
        v1 = v2.a; // android.support.v4.app.bf.a:android.app.Notification$Builder
        _result = v0.<init>(v1); // android.app.Notification$BigPictureStyle.<init> -> void
        _result = v0.setBigContentTitle(v3); // android.app.Notification$BigPictureStyle.setBigContentTitle -> android.app.Notification$BigPictureStyle
        v0 = _result;
        _result = v0.bigPicture(v6); // android.app.Notification$BigPictureStyle.bigPicture -> android.app.Notification$BigPictureStyle
        v0 = _result;
        if (v8 == 0) /* goto L_0014 */;
        _result = v0.bigLargeIcon(v7); // android.app.Notification$BigPictureStyle.bigLargeIcon -> android.app.Notification$BigPictureStyle
        if (v4 == 0) /* goto L_0019 */;
        _result = v0.setSummaryText(v5); // android.app.Notification$BigPictureStyle.setSummaryText -> android.app.Notification$BigPictureStyle
        return;
    }

    public void a(java.lang.CharSequence p0, boolean p1, java.lang.CharSequence p2, java.lang.CharSequence p3) {
        // Registers (7 total): v2 = this, v3 = p0 (java.lang.CharSequence), v4 = p1 (boolean), v5 = p2 (java.lang.CharSequence), v6 = p3 (java.lang.CharSequence)
        v0 = new android.app.Notification$BigTextStyle;
        v1 = v2.a; // android.support.v4.app.bf.a:android.app.Notification$Builder
        _result = v0.<init>(v1); // android.app.Notification$BigTextStyle.<init> -> void
        _result = v0.setBigContentTitle(v3); // android.app.Notification$BigTextStyle.setBigContentTitle -> android.app.Notification$BigTextStyle
        v0 = _result;
        _result = v0.bigText(v6); // android.app.Notification$BigTextStyle.bigText -> android.app.Notification$BigTextStyle
        v0 = _result;
        if (v4 == 0) /* goto L_0014 */;
        _result = v0.setSummaryText(v5); // android.app.Notification$BigTextStyle.setSummaryText -> android.app.Notification$BigTextStyle
        return;
    }

    public void a(java.lang.CharSequence p0, boolean p1, java.lang.CharSequence p2, java.util.ArrayList p3) {
        // Registers (8 total): v3 = this, v4 = p0 (java.lang.CharSequence), v5 = p1 (boolean), v6 = p2 (java.lang.CharSequence), v7 = p3 (java.util.ArrayList)
        v0 = new android.app.Notification$InboxStyle;
        v1 = v3.a; // android.support.v4.app.bf.a:android.app.Notification$Builder
        _result = v0.<init>(v1); // android.app.Notification$InboxStyle.<init> -> void
        _result = v0.setBigContentTitle(v4); // android.app.Notification$InboxStyle.setBigContentTitle -> android.app.Notification$InboxStyle
        v1 = _result;
        if (v5 == 0) /* goto L_0010 */;
        _result = v1.setSummaryText(v6); // android.app.Notification$InboxStyle.setSummaryText -> android.app.Notification$InboxStyle
        _result = v7.iterator(); // java.util.ArrayList.iterator -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0024 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.CharSequence) v0;
        _result = v1.addLine(v0); // android.app.Notification$InboxStyle.addLine -> android.app.Notification$InboxStyle
        // goto L_0014
        return;
    }

}