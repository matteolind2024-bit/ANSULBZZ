package android.support.v4.app;

/**
 * Original SourceFile: Fragment.java
 * Descriptor: Landroid/support/v4/app/Fragment;
 */
public class Fragment implements android.content.ComponentCallbacks, android.view.View$OnCreateContextMenuListener {
    static final int ACTIVITY_CREATED;
    static final int CREATED;
    static final int INITIALIZING;
    static final int RESUMED;
    static final int STARTED;
    static final int STOPPED;
    private static final android.support.v4.c.m sClassMap;
     android.support.v4.app.FragmentActivity mActivity;
     boolean mAdded;
     android.view.View mAnimatingAway;
     android.os.Bundle mArguments;
     int mBackStackNesting;
     boolean mCalled;
     boolean mCheckedForLoaderManager;
     android.support.v4.app.y mChildFragmentManager;
     android.view.ViewGroup mContainer;
     int mContainerId;
     boolean mDeferStart;
     boolean mDetached;
     int mFragmentId;
     android.support.v4.app.y mFragmentManager;
     boolean mFromLayout;
     boolean mHasMenu;
     boolean mHidden;
     boolean mInLayout;
     int mIndex;
     android.view.View mInnerView;
     android.support.v4.app.ao mLoaderManager;
     boolean mLoadersStarted;
     boolean mMenuVisible;
     int mNextAnim;
     android.support.v4.app.Fragment mParentFragment;
     boolean mRemoving;
     boolean mRestored;
     boolean mResumed;
     boolean mRetainInstance;
     boolean mRetaining;
     android.os.Bundle mSavedFragmentState;
     android.util.SparseArray mSavedViewState;
     int mState;
     int mStateAfterAnimating;
     java.lang.String mTag;
     android.support.v4.app.Fragment mTarget;
     int mTargetIndex;
     int mTargetRequestCode;
     boolean mUserVisibleHint;
     android.view.View mView;
     java.lang.String mWho;

    static {
        v0 = new android.support.v4.c.m;
        _result = v0.<init>(); // android.support.v4.c.m.<init> -> void
        android.support.v4.app.Fragment.sClassMap = v0; // :android.support.v4.c.m
        return;
    }

    public Fragment() {
        // Registers (4 total): v3 = this
        v2 = 1;
        v1 = -1;
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v3.mState = v0; // android.support.v4.app.Fragment.mState:int
        v3.mIndex = v1; // android.support.v4.app.Fragment.mIndex:int
        v3.mTargetIndex = v1; // android.support.v4.app.Fragment.mTargetIndex:int
        v3.mMenuVisible = v2; // android.support.v4.app.Fragment.mMenuVisible:boolean
        v3.mUserVisibleHint = v2; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        return;
    }

    public static android.support.v4.app.Fragment instantiate(android.content.Context p0, java.lang.String p1) {
        // Registers (3 total): v1 = p0 (android.content.Context), v2 = p1 (java.lang.String)
        v0 = 0;
        _result = v1.instantiate(v2, v0); // android.support.v4.app.Fragment.instantiate -> android.support.v4.app.Fragment
        v0 = _result;
        return v0;
    }

    public static android.support.v4.app.Fragment instantiate(android.content.Context p0, java.lang.String p1, android.os.Bundle p2) {
        // Registers (7 total): v4 = p0 (android.content.Context), v5 = p1 (java.lang.String), v6 = p2 (android.os.Bundle)
        v0 = android.support.v4.app.Fragment.sClassMap; // :android.support.v4.c.m
        _result = v0.get(v5); // android.support.v4.c.m.get -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Class) v0;
        if (v0 != 0) /* goto L_0017 */;
        _result = v4.getClassLoader(); // android.content.Context.getClassLoader -> java.lang.ClassLoader
        v0 = _result;
        _result = v0.loadClass(v5); // java.lang.ClassLoader.loadClass -> java.lang.Class
        v0 = _result;
        v1 = android.support.v4.app.Fragment.sClassMap; // :android.support.v4.c.m
        _result = v1.put(v5, v0); // android.support.v4.c.m.put -> java.lang.Object
        _result = v0.newInstance(); // java.lang.Class.newInstance -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        if (v6 == 0) /* goto L_002c */;
        _result = v0.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getClassLoader(); // java.lang.Class.getClassLoader -> java.lang.ClassLoader
        v1 = _result;
        _result = v6.setClassLoader(v1); // android.os.Bundle.setClassLoader -> void
        v0.mArguments = v6; // android.support.v4.app.Fragment.mArguments:android.os.Bundle
        return v0;
        v0 = _exception;
        v1 = new android.support.v4.app.p;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Unable to instantiate fragment ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": make sure class name exists, is public, and has an";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " empty constructor that is public";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // android.support.v4.app.p.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new android.support.v4.app.p;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Unable to instantiate fragment ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": make sure class name exists, is public, and has an";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " empty constructor that is public";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // android.support.v4.app.p.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new android.support.v4.app.p;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Unable to instantiate fragment ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ": make sure class name exists, is public, and has an";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = " empty constructor that is public";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // android.support.v4.app.p.<init> -> void
        throw v1;
    }

    static boolean isSupportFragmentClass(android.content.Context p0, java.lang.String p1) {
        // Registers (4 total): v2 = p0 (android.content.Context), v3 = p1 (java.lang.String)
        v0 = android.support.v4.app.Fragment.sClassMap; // :android.support.v4.c.m
        _result = v0.get(v3); // android.support.v4.c.m.get -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Class) v0;
        if (v0 != 0) /* goto L_0017 */;
        _result = v2.getClassLoader(); // android.content.Context.getClassLoader -> java.lang.ClassLoader
        v0 = _result;
        _result = v0.loadClass(v3); // java.lang.ClassLoader.loadClass -> java.lang.Class
        v0 = _result;
        v1 = android.support.v4.app.Fragment.sClassMap; // :android.support.v4.c.m
        _result = v1.put(v3, v0); // android.support.v4.c.m.put -> java.lang.Object
        v1 = android.support.v4.app.Fragment.class;
        _result = v1.isAssignableFrom(v0); // java.lang.Class.isAssignableFrom -> boolean
        v0 = _result;
        return v0;
        v0 = _exception;
        v0 = 0;
        // goto L_001d
    }

    public void dump(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (8 total): v3 = this, v4 = p0 (java.lang.String), v5 = p1 (java.io.FileDescriptor), v6 = p2 (java.io.PrintWriter), v7 = p3 (java.lang.String[])
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mFragmentId=#";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mContainerId=#";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mTag=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mState=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mState; // android.support.v4.app.Fragment.mState:int
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mIndex=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mWho=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mWho; // android.support.v4.app.Fragment.mWho:java.lang.String
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mBackStackNesting=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mAdded=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mRemoving=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mRemoving; // android.support.v4.app.Fragment.mRemoving:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mResumed=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mResumed; // android.support.v4.app.Fragment.mResumed:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mFromLayout=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mFromLayout; // android.support.v4.app.Fragment.mFromLayout:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mInLayout=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mInLayout; // android.support.v4.app.Fragment.mInLayout:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mHidden=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mDetached=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mMenuVisible=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mHasMenu=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mRetainInstance=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mRetainInstance; // android.support.v4.app.Fragment.mRetainInstance:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mRetaining=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mRetaining; // android.support.v4.app.Fragment.mRetaining:boolean
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mUserVisibleHint=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mFragmentManager; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_00fa */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mFragmentManager=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mFragmentManager; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.y
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_010c */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mActivity=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mParentFragment; // android.support.v4.app.Fragment.mParentFragment:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_011e */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mParentFragment=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mParentFragment; // android.support.v4.app.Fragment.mParentFragment:android.support.v4.app.Fragment
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mArguments; // android.support.v4.app.Fragment.mArguments:android.os.Bundle
        if (v0 == 0) /* goto L_0130 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mArguments=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mArguments; // android.support.v4.app.Fragment.mArguments:android.os.Bundle
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        if (v0 == 0) /* goto L_0142 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mSavedFragmentState=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mSavedFragmentState; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        if (v0 == 0) /* goto L_0154 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mSavedViewState=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0171 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mTarget=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mTargetRequestCode=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mTargetRequestCode; // android.support.v4.app.Fragment.mTargetRequestCode:int
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mNextAnim; // android.support.v4.app.Fragment.mNextAnim:int
        if (v0 == 0) /* goto L_0183 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mNextAnim=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mNextAnim; // android.support.v4.app.Fragment.mNextAnim:int
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mContainer; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        if (v0 == 0) /* goto L_0195 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mContainer=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mContainer; // android.support.v4.app.Fragment.mContainer:android.view.ViewGroup
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_01a7 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mView=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mInnerView; // android.support.v4.app.Fragment.mInnerView:android.view.View
        if (v0 == 0) /* goto L_01b9 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mInnerView=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        if (v0 == 0) /* goto L_01d9 */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mAnimatingAway=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mAnimatingAway; // android.support.v4.app.Fragment.mAnimatingAway:android.view.View
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "mStateAfterAnimating=";
        _result = v6.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.mStateAfterAnimating; // android.support.v4.app.Fragment.mStateAfterAnimating:int
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        if (v0 == 0) /* goto L_01ff */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = "Loader Manager:";
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "  ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.a(v1, v5, v6, v7); // android.support.v4.app.ao.a -> void
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_023f */;
        _result = v6.print(v4); // java.io.PrintWriter.print -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "Child ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ":";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v6.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "  ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.a(v1, v5, v6, v7); // android.support.v4.app.y.a -> void
        return;
    }

    public final boolean equals(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v1.equals(v2); // java.lang.Object.equals -> boolean
        v0 = _result;
        return v0;
    }

    android.support.v4.app.Fragment findFragmentByWho(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.mWho; // android.support.v4.app.Fragment.mWho:java.lang.String
        _result = v2.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0009 */;
        return v1;
        v0 = v1.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0014 */;
        v0 = v1.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.b(v2); // android.support.v4.app.y.b -> android.support.v4.app.Fragment
        v1 = _result;
        // goto L_0008
        v1 = 0;
        // goto L_0008
    }

    public final android.support.v4.app.FragmentActivity getActivity() {
        // Registers (2 total): v1 = this
        v0 = v1.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        return v0;
    }

    public final android.os.Bundle getArguments() {
        // Registers (2 total): v1 = this
        v0 = v1.mArguments; // android.support.v4.app.Fragment.mArguments:android.os.Bundle
        return v0;
    }

    public final android.support.v4.app.w getChildFragmentManager() {
        // Registers (3 total): v2 = this
        v0 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 != 0) /* goto L_0011 */;
        _result = v2.instantiateChildFragmentManager(); // android.support.v4.app.Fragment.instantiateChildFragmentManager -> void
        v0 = v2.mState; // android.support.v4.app.Fragment.mState:int
        v1 = 5;
        if (v0 < v1) /* goto L_0014 */;
        v0 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.n(); // android.support.v4.app.y.n -> void
        v0 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        return v0;
        v0 = v2.mState; // android.support.v4.app.Fragment.mState:int
        v1 = 4;
        if (v0 < v1) /* goto L_001f */;
        v0 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.m(); // android.support.v4.app.y.m -> void
        // goto L_0011
        v0 = v2.mState; // android.support.v4.app.Fragment.mState:int
        v1 = 2;
        if (v0 < v1) /* goto L_002a */;
        v0 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.l(); // android.support.v4.app.y.l -> void
        // goto L_0011
        v0 = v2.mState; // android.support.v4.app.Fragment.mState:int
        v1 = 1;
        if (v0 < v1) /* goto L_0011 */;
        v0 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.k(); // android.support.v4.app.y.k -> void
        // goto L_0011
    }

    public final android.support.v4.app.w getFragmentManager() {
        // Registers (2 total): v1 = this
        v0 = v1.mFragmentManager; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.y
        return v0;
    }

    public final int getId() {
        // Registers (2 total): v1 = this
        v0 = v1.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        return v0;
    }

    public android.view.LayoutInflater getLayoutInflater(android.os.Bundle p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Bundle)
        v0 = v1.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.getLayoutInflater(); // android.support.v4.app.FragmentActivity.getLayoutInflater -> android.view.LayoutInflater
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.am getLoaderManager() {
        // Registers (5 total): v4 = this
        v3 = 1;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        if (v0 == 0) /* goto L_0008 */;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        return v0;
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_002d */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " not attached to Activity";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v4.mCheckedForLoaderManager = v3; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = v4.mWho; // android.support.v4.app.Fragment.mWho:java.lang.String
        v2 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        _result = v0.a(v1, v2, v3); // android.support.v4.app.FragmentActivity.a -> android.support.v4.app.ao
        v0 = _result;
        v4.mLoaderManager = v0; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        // goto L_0007
    }

    public final android.support.v4.app.Fragment getParentFragment() {
        // Registers (2 total): v1 = this
        v0 = v1.mParentFragment; // android.support.v4.app.Fragment.mParentFragment:android.support.v4.app.Fragment
        return v0;
    }

    public final android.content.res.Resources getResources() {
        // Registers (4 total): v3 = this
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_0025 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " not attached to Activity";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.getResources(); // android.support.v4.app.FragmentActivity.getResources -> android.content.res.Resources
        v0 = _result;
        return v0;
    }

    public final boolean getRetainInstance() {
        // Registers (2 total): v1 = this
        v0 = v1.mRetainInstance; // android.support.v4.app.Fragment.mRetainInstance:boolean
        return v0;
    }

    public final java.lang.String getString(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.getResources(); // android.support.v4.app.Fragment.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getString(v2); // android.content.res.Resources.getString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public final java.lang.String getString(int p0, java.lang.Object[] p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (java.lang.Object[])
        _result = v1.getResources(); // android.support.v4.app.Fragment.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getString(v2, v3); // android.content.res.Resources.getString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public final java.lang.String getTag() {
        // Registers (2 total): v1 = this
        v0 = v1.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        return v0;
    }

    public final android.support.v4.app.Fragment getTargetFragment() {
        // Registers (2 total): v1 = this
        v0 = v1.mTarget; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        return v0;
    }

    public final int getTargetRequestCode() {
        // Registers (2 total): v1 = this
        v0 = v1.mTargetRequestCode; // android.support.v4.app.Fragment.mTargetRequestCode:int
        return v0;
    }

    public final java.lang.CharSequence getText(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        _result = v1.getResources(); // android.support.v4.app.Fragment.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getText(v2); // android.content.res.Resources.getText -> java.lang.CharSequence
        v0 = _result;
        return v0;
    }

    public boolean getUserVisibleHint() {
        // Registers (2 total): v1 = this
        v0 = v1.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        return v0;
    }

    public android.view.View getView() {
        // Registers (2 total): v1 = this
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        return v0;
    }

    public final boolean hasOptionsMenu() {
        // Registers (2 total): v1 = this
        v0 = v1.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        return v0;
    }

    public final int hashCode() {
        // Registers (2 total): v1 = this
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        return v0;
    }

    void initState() {
        // Registers (4 total): v3 = this
        v2 = 0;
        v1 = 0;
        v0 = -1;
        v3.mIndex = v0; // android.support.v4.app.Fragment.mIndex:int
        v3.mWho = v2; // android.support.v4.app.Fragment.mWho:java.lang.String
        v3.mAdded = v1; // android.support.v4.app.Fragment.mAdded:boolean
        v3.mRemoving = v1; // android.support.v4.app.Fragment.mRemoving:boolean
        v3.mResumed = v1; // android.support.v4.app.Fragment.mResumed:boolean
        v3.mFromLayout = v1; // android.support.v4.app.Fragment.mFromLayout:boolean
        v3.mInLayout = v1; // android.support.v4.app.Fragment.mInLayout:boolean
        v3.mRestored = v1; // android.support.v4.app.Fragment.mRestored:boolean
        v3.mBackStackNesting = v1; // android.support.v4.app.Fragment.mBackStackNesting:int
        v3.mFragmentManager = v2; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.y
        v3.mActivity = v2; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v3.mFragmentId = v1; // android.support.v4.app.Fragment.mFragmentId:int
        v3.mContainerId = v1; // android.support.v4.app.Fragment.mContainerId:int
        v3.mTag = v2; // android.support.v4.app.Fragment.mTag:java.lang.String
        v3.mHidden = v1; // android.support.v4.app.Fragment.mHidden:boolean
        v3.mDetached = v1; // android.support.v4.app.Fragment.mDetached:boolean
        v3.mRetaining = v1; // android.support.v4.app.Fragment.mRetaining:boolean
        v3.mLoaderManager = v2; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        v3.mLoadersStarted = v1; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        v3.mCheckedForLoaderManager = v1; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        return;
    }

    void instantiateChildFragmentManager() {
        // Registers (4 total): v3 = this
        v0 = new android.support.v4.app.y;
        _result = v0.<init>(); // android.support.v4.app.y.<init> -> void
        v3.mChildFragmentManager = v0; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        v1 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v2 = new android.support.v4.app.o;
        _result = v2.<init>(v3); // android.support.v4.app.o.<init> -> void
        _result = v0.a(v1, v2, v3); // android.support.v4.app.y.a -> void
        return;
    }

    public final boolean isAdded() {
        // Registers (2 total): v1 = this
        v0 = v1.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 == 0) /* goto L_000a */;
        v0 = v1.mAdded; // android.support.v4.app.Fragment.mAdded:boolean
        if (v0 == 0) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public final boolean isDetached() {
        // Registers (2 total): v1 = this
        v0 = v1.mDetached; // android.support.v4.app.Fragment.mDetached:boolean
        return v0;
    }

    public final boolean isHidden() {
        // Registers (2 total): v1 = this
        v0 = v1.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        return v0;
    }

    final boolean isInBackStack() {
        // Registers (2 total): v1 = this
        v0 = v1.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        if (v0 <= 0) /* goto L_0006 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0005
    }

    public final boolean isInLayout() {
        // Registers (2 total): v1 = this
        v0 = v1.mInLayout; // android.support.v4.app.Fragment.mInLayout:boolean
        return v0;
    }

    public final boolean isMenuVisible() {
        // Registers (2 total): v1 = this
        v0 = v1.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        return v0;
    }

    public final boolean isRemoving() {
        // Registers (2 total): v1 = this
        v0 = v1.mRemoving; // android.support.v4.app.Fragment.mRemoving:boolean
        return v0;
    }

    public final boolean isResumed() {
        // Registers (2 total): v1 = this
        v0 = v1.mResumed; // android.support.v4.app.Fragment.mResumed:boolean
        return v0;
    }

    public final boolean isVisible() {
        // Registers (2 total): v1 = this
        _result = v1.isAdded(); // android.support.v4.app.Fragment.isAdded -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0022 */;
        _result = v1.isHidden(); // android.support.v4.app.Fragment.isHidden -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0022 */;
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        if (v0 == 0) /* goto L_0022 */;
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.getWindowToken(); // android.view.View.getWindowToken -> android.os.IBinder
        v0 = _result;
        if (v0 == 0) /* goto L_0022 */;
        v0 = v1.mView; // android.support.v4.app.Fragment.mView:android.view.View
        _result = v0.getVisibility(); // android.view.View.getVisibility -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0022 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0021
    }

    public void onActivityCreated(android.os.Bundle p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Bundle)
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onActivityResult(int p0, int p1, android.content.Intent p2) {
        // Registers (4 total): v0 = this, v1 = p0 (int), v2 = p1 (int), v3 = p2 (android.content.Intent)
        return;
    }

    public void onAttach(android.app.Activity p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.app.Activity)
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onConfigurationChanged(android.content.res.Configuration p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.res.Configuration)
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public boolean onContextItemSelected(android.view.MenuItem p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.MenuItem)
        v0 = 0;
        return v0;
    }

    public void onCreate(android.os.Bundle p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Bundle)
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public android.view.animation.Animation onCreateAnimation(int p0, boolean p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (boolean), v4 = p2 (int)
        v0 = 0;
        return v0;
    }

    public void onCreateContextMenu(android.view.ContextMenu p0, android.view.View p1, android.view.ContextMenu$ContextMenuInfo p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ContextMenu), v3 = p1 (android.view.View), v4 = p2 (android.view.ContextMenu$ContextMenuInfo)
        _result = v1.getActivity(); // android.support.v4.app.Fragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        _result = v0.onCreateContextMenu(v2, v3, v4); // android.support.v4.app.FragmentActivity.onCreateContextMenu -> void
        return;
    }

    public void onCreateOptionsMenu(android.view.Menu p0, android.view.MenuInflater p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.Menu), v2 = p1 (android.view.MenuInflater)
        return;
    }

    public android.view.View onCreateView(android.view.LayoutInflater p0, android.view.ViewGroup p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.LayoutInflater), v3 = p1 (android.view.ViewGroup), v4 = p2 (android.os.Bundle)
        v0 = 0;
        return v0;
    }

    public void onDestroy() {
        // Registers (5 total): v4 = this
        v1 = 1;
        v4.mCalled = v1; // android.support.v4.app.Fragment.mCalled:boolean
        v0 = v4.mCheckedForLoaderManager; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        if (v0 != 0) /* goto L_0016 */;
        v4.mCheckedForLoaderManager = v1; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = v4.mWho; // android.support.v4.app.Fragment.mWho:java.lang.String
        v2 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        v3 = 0;
        _result = v0.a(v1, v2, v3); // android.support.v4.app.FragmentActivity.a -> android.support.v4.app.ao
        v0 = _result;
        v4.mLoaderManager = v0; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        if (v0 == 0) /* goto L_001f */;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        _result = v0.h(); // android.support.v4.app.ao.h -> void
        return;
    }

    public void onDestroyOptionsMenu() {
        // Registers (1 total): v0 = this
        return;
    }

    public void onDestroyView() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onDetach() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onHiddenChanged(boolean p0) {
        // Registers (2 total): v0 = this, v1 = p0 (boolean)
        return;
    }

    public void onInflate(android.app.Activity p0, android.util.AttributeSet p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.app.Activity), v3 = p1 (android.util.AttributeSet), v4 = p2 (android.os.Bundle)
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onLowMemory() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public boolean onOptionsItemSelected(android.view.MenuItem p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.MenuItem)
        v0 = 0;
        return v0;
    }

    public void onOptionsMenuClosed(android.view.Menu p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.Menu)
        return;
    }

    public void onPause() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onPrepareOptionsMenu(android.view.Menu p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.Menu)
        return;
    }

    public void onResume() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onSaveInstanceState(android.os.Bundle p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.os.Bundle)
        return;
    }

    public void onStart() {
        // Registers (5 total): v4 = this
        v1 = 1;
        v4.mCalled = v1; // android.support.v4.app.Fragment.mCalled:boolean
        v0 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        if (v0 != 0) /* goto L_0025 */;
        v4.mLoadersStarted = v1; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        v0 = v4.mCheckedForLoaderManager; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        if (v0 != 0) /* goto L_001c */;
        v4.mCheckedForLoaderManager = v1; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = v4.mWho; // android.support.v4.app.Fragment.mWho:java.lang.String
        v2 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        v3 = 0;
        _result = v0.a(v1, v2, v3); // android.support.v4.app.FragmentActivity.a -> android.support.v4.app.ao
        v0 = _result;
        v4.mLoaderManager = v0; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        if (v0 == 0) /* goto L_0025 */;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        _result = v0.b(); // android.support.v4.app.ao.b -> void
        return;
    }

    public void onStop() {
        // Registers (2 total): v1 = this
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    public void onViewCreated(android.view.View p0, android.os.Bundle p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.os.Bundle)
        return;
    }

    public void onViewStateRestored(android.os.Bundle p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.os.Bundle)
        v0 = 1;
        v1.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        return;
    }

    void performActivityCreated(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0009 */;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.j(); // android.support.v4.app.y.j -> void
        v0 = 0;
        v3.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v3.onActivityCreated(v4); // android.support.v4.app.Fragment.onActivityCreated -> void
        v0 = v3.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0034 */;
        v0 = new android.support.v4.app.bg;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onActivityCreated()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.bg.<init> -> void
        throw v0;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_003d */;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.l(); // android.support.v4.app.y.l -> void
        return;
    }

    void performConfigurationChanged(android.content.res.Configuration p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.res.Configuration)
        _result = v1.onConfigurationChanged(v2); // android.support.v4.app.Fragment.onConfigurationChanged -> void
        v0 = v1.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_000c */;
        v0 = v1.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.a(v2); // android.support.v4.app.y.a -> void
        return;
    }

    boolean performContextItemSelected(android.view.MenuItem p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.MenuItem)
        v0 = 1;
        v1 = v2.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v1 != 0) /* goto L_0018 */;
        _result = v2.onContextItemSelected(v3); // android.support.v4.app.Fragment.onContextItemSelected -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_000c */;
        return v0;
        v1 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v1 == 0) /* goto L_0018 */;
        v1 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v1.b(v3); // android.support.v4.app.y.b -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000b */;
        v0 = 0;
        // goto L_000b
    }

    void performCreate(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0009 */;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.j(); // android.support.v4.app.y.j -> void
        v0 = 0;
        v3.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v3.onCreate(v4); // android.support.v4.app.Fragment.onCreate -> void
        v0 = v3.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0034 */;
        v0 = new android.support.v4.app.bg;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onCreate()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.bg.<init> -> void
        throw v0;
        if (v4 == 0) /* goto L_0051 */;
        v0 = "android:support:fragments";
        _result = v4.getParcelable(v0); // android.os.Bundle.getParcelable -> android.os.Parcelable
        v0 = _result;
        if (v0 == 0) /* goto L_0051 */;
        v1 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v1 != 0) /* goto L_0046 */;
        _result = v3.instantiateChildFragmentManager(); // android.support.v4.app.Fragment.instantiateChildFragmentManager -> void
        v1 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        v2 = 0;
        _result = v1.a(v0, v2); // android.support.v4.app.y.a -> void
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.k(); // android.support.v4.app.y.k -> void
        return;
    }

    boolean performCreateOptionsMenu(android.view.Menu p0, android.view.MenuInflater p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.view.Menu), v4 = p1 (android.view.MenuInflater)
        v0 = 0;
        v1 = v2.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v1 != 0) /* goto L_001c */;
        v1 = v2.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v1 == 0) /* goto L_0011 */;
        v1 = v2.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v1 == 0) /* goto L_0011 */;
        v0 = 1;
        _result = v2.onCreateOptionsMenu(v3, v4); // android.support.v4.app.Fragment.onCreateOptionsMenu -> void
        v1 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v1 == 0) /* goto L_001c */;
        v1 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v1.a(v3, v4); // android.support.v4.app.y.a -> boolean
        v1 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        return v0;
    }

    android.view.View performCreateView(android.view.LayoutInflater p0, android.view.ViewGroup p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.LayoutInflater), v3 = p1 (android.view.ViewGroup), v4 = p2 (android.os.Bundle)
        v0 = v1.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0009 */;
        v0 = v1.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.j(); // android.support.v4.app.y.j -> void
        _result = v1.onCreateView(v2, v3, v4); // android.support.v4.app.Fragment.onCreateView -> android.view.View
        v0 = _result;
        return v0;
    }

    void performDestroy() {
        // Registers (4 total): v3 = this
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0009 */;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.s(); // android.support.v4.app.y.s -> void
        v0 = 0;
        v3.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v3.onDestroy(); // android.support.v4.app.Fragment.onDestroy -> void
        v0 = v3.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0034 */;
        v0 = new android.support.v4.app.bg;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onDestroy()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.bg.<init> -> void
        throw v0;
        return;
    }

    void performDestroyView() {
        // Registers (4 total): v3 = this
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0009 */;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.r(); // android.support.v4.app.y.r -> void
        v0 = 0;
        v3.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v3.onDestroyView(); // android.support.v4.app.Fragment.onDestroyView -> void
        v0 = v3.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0034 */;
        v0 = new android.support.v4.app.bg;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onDestroyView()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.bg.<init> -> void
        throw v0;
        v0 = v3.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        if (v0 == 0) /* goto L_003d */;
        v0 = v3.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        _result = v0.f(); // android.support.v4.app.ao.f -> void
        return;
    }

    void performLowMemory() {
        // Registers (2 total): v1 = this
        _result = v1.onLowMemory(); // android.support.v4.app.Fragment.onLowMemory -> void
        v0 = v1.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_000c */;
        v0 = v1.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.t(); // android.support.v4.app.y.t -> void
        return;
    }

    boolean performOptionsItemSelected(android.view.MenuItem p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.MenuItem)
        v0 = 1;
        v1 = v2.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v1 != 0) /* goto L_0020 */;
        v1 = v2.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v1 == 0) /* goto L_0014 */;
        v1 = v2.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v1 == 0) /* goto L_0014 */;
        _result = v2.onOptionsItemSelected(v3); // android.support.v4.app.Fragment.onOptionsItemSelected -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0014 */;
        return v0;
        v1 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v1 == 0) /* goto L_0020 */;
        v1 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v1.a(v3); // android.support.v4.app.y.a -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0013 */;
        v0 = 0;
        // goto L_0013
    }

    void performOptionsMenuClosed(android.view.Menu p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.Menu)
        v0 = v1.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v0 != 0) /* goto L_0018 */;
        v0 = v1.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_000f */;
        v0 = v1.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == 0) /* goto L_000f */;
        _result = v1.onOptionsMenuClosed(v2); // android.support.v4.app.Fragment.onOptionsMenuClosed -> void
        v0 = v1.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0018 */;
        v0 = v1.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.b(v2); // android.support.v4.app.y.b -> void
        return;
    }

    void performPause() {
        // Registers (4 total): v3 = this
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0009 */;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.o(); // android.support.v4.app.y.o -> void
        v0 = 0;
        v3.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v3.onPause(); // android.support.v4.app.Fragment.onPause -> void
        v0 = v3.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0034 */;
        v0 = new android.support.v4.app.bg;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onPause()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.bg.<init> -> void
        throw v0;
        return;
    }

    boolean performPrepareOptionsMenu(android.view.Menu p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.view.Menu)
        v0 = 0;
        v1 = v2.mHidden; // android.support.v4.app.Fragment.mHidden:boolean
        if (v1 != 0) /* goto L_001c */;
        v1 = v2.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v1 == 0) /* goto L_0011 */;
        v1 = v2.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v1 == 0) /* goto L_0011 */;
        v0 = 1;
        _result = v2.onPrepareOptionsMenu(v3); // android.support.v4.app.Fragment.onPrepareOptionsMenu -> void
        v1 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v1 == 0) /* goto L_001c */;
        v1 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v1.a(v3); // android.support.v4.app.y.a -> boolean
        v1 = _result;
        v0 = binOp2addr_0xb6(v0, v1);
        return v0;
    }

    void performReallyStop() {
        // Registers (5 total): v4 = this
        v3 = 0;
        v0 = v4.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_000a */;
        v0 = v4.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.q(); // android.support.v4.app.y.q -> void
        v0 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        if (v0 == 0) /* goto L_0032 */;
        v4.mLoadersStarted = v3; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        v0 = v4.mCheckedForLoaderManager; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        if (v0 != 0) /* goto L_0023 */;
        v0 = 1;
        v4.mCheckedForLoaderManager = v0; // android.support.v4.app.Fragment.mCheckedForLoaderManager:boolean
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = v4.mWho; // android.support.v4.app.Fragment.mWho:java.lang.String
        v2 = v4.mLoadersStarted; // android.support.v4.app.Fragment.mLoadersStarted:boolean
        _result = v0.a(v1, v2, v3); // android.support.v4.app.FragmentActivity.a -> android.support.v4.app.ao
        v0 = _result;
        v4.mLoaderManager = v0; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        if (v0 == 0) /* goto L_0032 */;
        v0 = v4.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v0 = v0.h; // android.support.v4.app.FragmentActivity.h:boolean
        if (v0 != 0) /* goto L_0033 */;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        _result = v0.c(); // android.support.v4.app.ao.c -> void
        return;
        v0 = v4.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        _result = v0.d(); // android.support.v4.app.ao.d -> void
        // goto L_0032
    }

    void performResume() {
        // Registers (4 total): v3 = this
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_000e */;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.j(); // android.support.v4.app.y.j -> void
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.f(); // android.support.v4.app.y.f -> boolean
        v0 = 0;
        v3.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v3.onResume(); // android.support.v4.app.Fragment.onResume -> void
        v0 = v3.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0039 */;
        v0 = new android.support.v4.app.bg;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onResume()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.bg.<init> -> void
        throw v0;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0047 */;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.n(); // android.support.v4.app.y.n -> void
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.f(); // android.support.v4.app.y.f -> boolean
        return;
    }

    void performSaveInstanceState(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        _result = v2.onSaveInstanceState(v3); // android.support.v4.app.Fragment.onSaveInstanceState -> void
        v0 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0015 */;
        v0 = v2.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.i(); // android.support.v4.app.y.i -> android.os.Parcelable
        v0 = _result;
        if (v0 == 0) /* goto L_0015 */;
        v1 = "android:support:fragments";
        _result = v3.putParcelable(v1, v0); // android.os.Bundle.putParcelable -> void
        return;
    }

    void performStart() {
        // Registers (4 total): v3 = this
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_000e */;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.j(); // android.support.v4.app.y.j -> void
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.f(); // android.support.v4.app.y.f -> boolean
        v0 = 0;
        v3.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v3.onStart(); // android.support.v4.app.Fragment.onStart -> void
        v0 = v3.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0039 */;
        v0 = new android.support.v4.app.bg;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onStart()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.bg.<init> -> void
        throw v0;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0042 */;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.m(); // android.support.v4.app.y.m -> void
        v0 = v3.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        if (v0 == 0) /* goto L_004b */;
        v0 = v3.mLoaderManager; // android.support.v4.app.Fragment.mLoaderManager:android.support.v4.app.ao
        _result = v0.g(); // android.support.v4.app.ao.g -> void
        return;
    }

    void performStop() {
        // Registers (4 total): v3 = this
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        if (v0 == 0) /* goto L_0009 */;
        v0 = v3.mChildFragmentManager; // android.support.v4.app.Fragment.mChildFragmentManager:android.support.v4.app.y
        _result = v0.p(); // android.support.v4.app.y.p -> void
        v0 = 0;
        v3.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v3.onStop(); // android.support.v4.app.Fragment.onStop -> void
        v0 = v3.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0034 */;
        v0 = new android.support.v4.app.bg;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onStop()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.bg.<init> -> void
        throw v0;
        return;
    }

    public void registerForContextMenu(android.view.View p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.view.View)
        _result = v1.setOnCreateContextMenuListener(v0); // android.view.View.setOnCreateContextMenuListener -> void
        return;
    }

    final void restoreViewState(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v0 = v3.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        if (v0 == 0) /* goto L_000e */;
        v0 = v3.mInnerView; // android.support.v4.app.Fragment.mInnerView:android.view.View
        v1 = v3.mSavedViewState; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        _result = v0.restoreHierarchyState(v1); // android.view.View.restoreHierarchyState -> void
        v0 = 0;
        v3.mSavedViewState = v0; // android.support.v4.app.Fragment.mSavedViewState:android.util.SparseArray
        v0 = 0;
        v3.mCalled = v0; // android.support.v4.app.Fragment.mCalled:boolean
        _result = v3.onViewStateRestored(v4); // android.support.v4.app.Fragment.onViewStateRestored -> void
        v0 = v3.mCalled; // android.support.v4.app.Fragment.mCalled:boolean
        if (v0 != 0) /* goto L_0039 */;
        v0 = new android.support.v4.app.bg;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " did not call through to super.onViewStateRestored()";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.bg.<init> -> void
        throw v0;
        return;
    }

    public void setArguments(android.os.Bundle p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.os.Bundle)
        v0 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v0 < 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Fragment already active";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v2.mArguments = v3; // android.support.v4.app.Fragment.mArguments:android.os.Bundle
        return;
    }

    public void setHasOptionsMenu(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == v2) /* goto L_0017 */;
        v1.mHasMenu = v2; // android.support.v4.app.Fragment.mHasMenu:boolean
        _result = v1.isAdded(); // android.support.v4.app.Fragment.isAdded -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0017 */;
        _result = v1.isHidden(); // android.support.v4.app.Fragment.isHidden -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        v0 = v1.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.u_(); // android.support.v4.app.FragmentActivity.u_ -> void
        return;
    }

    final void setIndex(int p0, android.support.v4.app.Fragment p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (android.support.v4.app.Fragment)
        v2.mIndex = v3; // android.support.v4.app.Fragment.mIndex:int
        if (v4 == 0) /* goto L_0023 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = v4.mWho; // android.support.v4.app.Fragment.mWho:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ":";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v2.mWho = v0; // android.support.v4.app.Fragment.mWho:java.lang.String
        return;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "android:fragment:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v2.mWho = v0; // android.support.v4.app.Fragment.mWho:java.lang.String
        // goto L_0022
    }

    public void setInitialSavedState(android.support.v4.app.Fragment$SavedState p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment$SavedState)
        v0 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v0 < 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Fragment already active";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        if (v3 == 0) /* goto L_0018 */;
        v0 = v3.mState; // android.support.v4.app.Fragment$SavedState.mState:android.os.Bundle
        if (v0 == 0) /* goto L_0018 */;
        v0 = v3.mState; // android.support.v4.app.Fragment$SavedState.mState:android.os.Bundle
        v2.mSavedFragmentState = v0; // android.support.v4.app.Fragment.mSavedFragmentState:android.os.Bundle
        return;
        v0 = 0;
        // goto L_0015
    }

    public void setMenuVisibility(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = v1.mMenuVisible; // android.support.v4.app.Fragment.mMenuVisible:boolean
        if (v0 == v2) /* goto L_001b */;
        v1.mMenuVisible = v2; // android.support.v4.app.Fragment.mMenuVisible:boolean
        v0 = v1.mHasMenu; // android.support.v4.app.Fragment.mHasMenu:boolean
        if (v0 == 0) /* goto L_001b */;
        _result = v1.isAdded(); // android.support.v4.app.Fragment.isAdded -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001b */;
        _result = v1.isHidden(); // android.support.v4.app.Fragment.isHidden -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_001b */;
        v0 = v1.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.u_(); // android.support.v4.app.FragmentActivity.u_ -> void
        return;
    }

    public void setRetainInstance(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        if (v3 == 0) /* goto L_000f */;
        v0 = v2.mParentFragment; // android.support.v4.app.Fragment.mParentFragment:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_000f */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Can't retain fragements that are nested in other fragments";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v2.mRetainInstance = v3; // android.support.v4.app.Fragment.mRetainInstance:boolean
        return;
    }

    public void setTargetFragment(android.support.v4.app.Fragment p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.support.v4.app.Fragment), v2 = p1 (int)
        v0.mTarget = v1; // android.support.v4.app.Fragment.mTarget:android.support.v4.app.Fragment
        v0.mTargetRequestCode = v2; // android.support.v4.app.Fragment.mTargetRequestCode:int
        return;
    }

    public void setUserVisibleHint(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = v2.mUserVisibleHint; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        if (v0 != 0) /* goto L_0010 */;
        if (v3 == 0) /* goto L_0010 */;
        v0 = v2.mState; // android.support.v4.app.Fragment.mState:int
        v1 = 4;
        if (v0 >= v1) /* goto L_0010 */;
        v0 = v2.mFragmentManager; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.y
        _result = v0.b(v2); // android.support.v4.app.y.b -> void
        v2.mUserVisibleHint = v3; // android.support.v4.app.Fragment.mUserVisibleHint:boolean
        if (v3 != 0) /* goto L_0018 */;
        v0 = 1;
        v2.mDeferStart = v0; // android.support.v4.app.Fragment.mDeferStart:boolean
        return;
        v0 = 0;
        // goto L_0015
    }

    public void startActivity(android.content.Intent p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.content.Intent)
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_0025 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " not attached to Activity";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        v1 = -1;
        _result = v0.a(v3, v4, v1); // android.support.v4.app.FragmentActivity.a -> void
        return;
    }

    public void startActivityForResult(android.content.Intent p0, int p1) {
        // Registers (6 total): v3 = this, v4 = p0 (android.content.Intent), v5 = p1 (int)
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        if (v0 != 0) /* goto L_0025 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " not attached to Activity";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.mActivity; // android.support.v4.app.Fragment.mActivity:android.support.v4.app.FragmentActivity
        _result = v0.a(v3, v4, v5); // android.support.v4.app.FragmentActivity.a -> void
        return;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 128;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v2.a(v0); // android.support.v4.c.d.a -> void
        v1 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        if (v1 < 0) /* goto L_0019 */;
        v1 = " #";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mIndex; // android.support.v4.app.Fragment.mIndex:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        if (v1 == 0) /* goto L_002c */;
        v1 = " id=0x";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        if (v1 == 0) /* goto L_003b */;
        v1 = " ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void unregisterForContextMenu(android.view.View p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.View)
        v0 = 0;
        _result = v2.setOnCreateContextMenuListener(v0); // android.view.View.setOnCreateContextMenuListener -> void
        return;
    }

}