package android.support.v4.view;

/**
 * Original SourceFile: ViewConfigurationCompat.java
 * Descriptor: Landroid/support/v4/view/bm;
 */
interface bm {
    public abstract int a(android.view.ViewConfiguration p0);
}