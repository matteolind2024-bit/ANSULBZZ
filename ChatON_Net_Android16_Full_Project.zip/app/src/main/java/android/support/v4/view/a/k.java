package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeProviderCompat.java
 * Descriptor: Landroid/support/v4/view/a/k;
 */
public class k {
    private static final android.support.v4.view.a.l a;
    private final java.lang.Object b;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 19;
        if (v0 < v1) /* goto L_000e */;
        v0 = new android.support.v4.view.a.o;
        _result = v0.<init>(); // android.support.v4.view.a.o.<init> -> void
        android.support.v4.view.a.k.a = v0; // :android.support.v4.view.a.l
        return;
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 16;
        if (v0 < v1) /* goto L_001c */;
        v0 = new android.support.v4.view.a.m;
        _result = v0.<init>(); // android.support.v4.view.a.m.<init> -> void
        android.support.v4.view.a.k.a = v0; // :android.support.v4.view.a.l
        // goto L_000d
        v0 = new android.support.v4.view.a.q;
        _result = v0.<init>(); // android.support.v4.view.a.q.<init> -> void
        android.support.v4.view.a.k.a = v0; // :android.support.v4.view.a.l
        // goto L_000d
    }

    public k() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = android.support.v4.view.a.k.a; // :android.support.v4.view.a.l
        _result = android.support.v4.view.a.l.a(v0, v1); // -> java.lang.Object
        v0 = _result;
        v1.b = v0; // android.support.v4.view.a.k.b:java.lang.Object
        return;
    }

    public k(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.b = v1; // android.support.v4.view.a.k.b:java.lang.Object
        return;
    }

    public android.support.v4.view.a.a a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public java.lang.Object a() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.view.a.k.b:java.lang.Object
        return v0;
    }

    public java.util.List a(java.lang.String p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

    public boolean a(int p0, int p1, android.os.Bundle p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (int), v4 = p2 (android.os.Bundle)
        v0 = 0;
        return v0;
    }

}