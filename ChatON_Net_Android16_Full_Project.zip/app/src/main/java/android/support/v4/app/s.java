package android.support.v4.app;

/**
 * Original SourceFile: FragmentActivity.java
 * Descriptor: Landroid/support/v4/app/s;
 */
class s implements android.support.v4.app.v {
    final android.support.v4.app.FragmentActivity a;

    s(android.support.v4.app.FragmentActivity p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.FragmentActivity)
        v0.a = v1; // android.support.v4.app.s.a:android.support.v4.app.FragmentActivity
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.view.View a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.a; // android.support.v4.app.s.a:android.support.v4.app.FragmentActivity
        _result = v0.findViewById(v2); // android.support.v4.app.FragmentActivity.findViewById -> android.view.View
        v0 = _result;
        return v0;
    }

}