package android.support.v4.app;

/**
 * Original SourceFile: ActionBarDrawerToggle.java
 * Descriptor: Landroid/support/v4/app/g;
 */
public interface g {
    public abstract android.support.v4.app.f a();
}