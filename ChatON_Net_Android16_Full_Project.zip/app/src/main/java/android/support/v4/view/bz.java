package android.support.v4.view;

/**
 * Original SourceFile: ViewPager.java
 * Descriptor: Landroid/support/v4/view/bz;
 */
class bz {
     java.lang.Object a;
     int b;
     boolean c;
     float d;
     float e;

    bz() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}