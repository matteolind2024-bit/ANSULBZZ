package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompatIcs.java
 * Descriptor: Landroid/support/v4/view/i;
 */
final class i extends android.view.View$AccessibilityDelegate {
    final android.support.v4.view.j a;

    i(android.support.v4.view.j p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.view.j)
        v0.a = v1; // android.support.v4.view.i.a:android.support.v4.view.j
        _result = v0.<init>(); // android.view.View$AccessibilityDelegate.<init> -> void
        return;
    }

    public boolean dispatchPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.a; // android.support.v4.view.i.a:android.support.v4.view.j
        _result = android.support.v4.view.j.a(v0, v2, v3); // -> boolean
        v0 = _result;
        return v0;
    }

    public void onInitializeAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.a; // android.support.v4.view.i.a:android.support.v4.view.j
        _result = android.support.v4.view.j.b(v0, v2, v3); // -> void
        return;
    }

    public void onInitializeAccessibilityNodeInfo(android.view.View p0, android.view.accessibility.AccessibilityNodeInfo p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityNodeInfo)
        v0 = v1.a; // android.support.v4.view.i.a:android.support.v4.view.j
        _result = android.support.v4.view.j.a(v0, v2, v3); // -> void
        return;
    }

    public void onPopulateAccessibilityEvent(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.a; // android.support.v4.view.i.a:android.support.v4.view.j
        _result = android.support.v4.view.j.c(v0, v2, v3); // -> void
        return;
    }

    public boolean onRequestSendAccessibilityEvent(android.view.ViewGroup p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.view.ViewGroup), v3 = p1 (android.view.View), v4 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.a; // android.support.v4.view.i.a:android.support.v4.view.j
        _result = android.support.v4.view.j.a(v0, v2, v3, v4); // -> boolean
        v0 = _result;
        return v0;
    }

    public void sendAccessibilityEvent(android.view.View p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (int)
        v0 = v1.a; // android.support.v4.view.i.a:android.support.v4.view.j
        _result = android.support.v4.view.j.a(v0, v2, v3); // -> void
        return;
    }

    public void sendAccessibilityEventUnchecked(android.view.View p0, android.view.accessibility.AccessibilityEvent p1) {
        // Registers (4 total): v1 = this, v2 = p0 (android.view.View), v3 = p1 (android.view.accessibility.AccessibilityEvent)
        v0 = v1.a; // android.support.v4.view.i.a:android.support.v4.view.j
        _result = android.support.v4.view.j.d(v0, v2, v3); // -> void
        return;
    }

}