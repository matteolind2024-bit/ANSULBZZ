package android.support.v4.view;

/**
 * Original SourceFile: PagerTitleStrip.java
 * Descriptor: Landroid/support/v4/view/ah;
 */
class ah {
}