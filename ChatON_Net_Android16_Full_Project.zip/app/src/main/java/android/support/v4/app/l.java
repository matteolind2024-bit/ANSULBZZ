package android.support.v4.app;

/**
 * Original SourceFile: BackStackRecord.java
 * Descriptor: Landroid/support/v4/app/l;
 */
final class l extends android.support.v4.app.aj implements java.lang.Runnable {
    final android.support.v4.app.y a;
     android.support.v4.app.m b;
     android.support.v4.app.m c;
     int d;
     int e;
     int f;
     int g;
     int h;
     int i;
     int j;
     boolean k;
     boolean l;
     java.lang.String m;
     boolean n;
     int o;
     int p;
     java.lang.CharSequence q;
     int r;
     java.lang.CharSequence s;

    public l(android.support.v4.app.y p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.y)
        _result = v1.<init>(); // android.support.v4.app.aj.<init> -> void
        v0 = 1;
        v1.l = v0; // android.support.v4.app.l.l:boolean
        v0 = -1;
        v1.o = v0; // android.support.v4.app.l.o:int
        v1.a = v2; // android.support.v4.app.l.a:android.support.v4.app.y
        return;
    }

    private void a(int p0, android.support.v4.app.Fragment p1, java.lang.String p2, int p3) {
        // Registers (8 total): v3 = this, v4 = p0 (int), v5 = p1 (android.support.v4.app.Fragment), v6 = p2 (java.lang.String), v7 = p3 (int)
        v0 = v3.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v5.mFragmentManager = v0; // android.support.v4.app.Fragment.mFragmentManager:android.support.v4.app.y
        if (v6 == 0) /* goto L_0046 */;
        v0 = v5.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        if (v0 == 0) /* goto L_0044 */;
        v0 = v5.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v6.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0044 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Can't change tag of fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ": was ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v5.mTag; // android.support.v4.app.Fragment.mTag:java.lang.String
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " now ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v5.mTag = v6; // android.support.v4.app.Fragment.mTag:java.lang.String
        if (v4 == 0) /* goto L_0086 */;
        v0 = v5.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        if (v0 == 0) /* goto L_0082 */;
        v0 = v5.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        if (v0 == v4) /* goto L_0082 */;
        v0 = new java.lang.IllegalStateException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Can't change container ID of fragment ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ": was ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v5.mFragmentId; // android.support.v4.app.Fragment.mFragmentId:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " now ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v5.mFragmentId = v4; // android.support.v4.app.Fragment.mFragmentId:int
        v5.mContainerId = v4; // android.support.v4.app.Fragment.mContainerId:int
        v0 = new android.support.v4.app.m;
        _result = v0.<init>(); // android.support.v4.app.m.<init> -> void
        v0.c = v7; // android.support.v4.app.m.c:int
        v0.d = v5; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        _result = v3.a(v0); // android.support.v4.app.l.a -> void
        return;
    }

    int a(boolean p0) {
        // Registers (6 total): v4 = this, v5 = p0 (boolean)
        v3 = 0;
        v0 = v4.n; // android.support.v4.app.l.n:boolean
        if (v0 == 0) /* goto L_000e */;
        v0 = new java.lang.IllegalStateException;
        v1 = "commit already called";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_003f */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Commit: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = new android.support.v4.c.e;
        v1 = "FragmentManager";
        _result = v0.<init>(v1); // android.support.v4.c.e.<init> -> void
        v1 = new java.io.PrintWriter;
        _result = v1.<init>(v0); // java.io.PrintWriter.<init> -> void
        v0 = "  ";
        _result = v4.a(v0, v3, v1, v3); // android.support.v4.app.l.a -> void
        v0 = 1;
        v4.n = v0; // android.support.v4.app.l.n:boolean
        v0 = v4.k; // android.support.v4.app.l.k:boolean
        if (v0 == 0) /* goto L_0056 */;
        v0 = v4.a; // android.support.v4.app.l.a:android.support.v4.app.y
        _result = v0.a(v4); // android.support.v4.app.y.a -> int
        v0 = _result;
        v4.o = v0; // android.support.v4.app.l.o:int
        v0 = v4.a; // android.support.v4.app.l.a:android.support.v4.app.y
        _result = v0.a(v4, v5); // android.support.v4.app.y.a -> void
        v0 = v4.o; // android.support.v4.app.l.o:int
        return v0;
        v0 = -1;
        v4.o = v0; // android.support.v4.app.l.o:int
        // goto L_004e
    }

    public android.support.v4.app.aj a() {
        // Registers (3 total): v2 = this
        v0 = v2.k; // android.support.v4.app.l.k:boolean
        if (v0 == 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "This transaction is already being added to the back stack";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = 0;
        v2.l = v0; // android.support.v4.app.l.l:boolean
        return v2;
    }

    public android.support.v4.app.aj a(int p0, android.support.v4.app.Fragment p1) {
        // Registers (5 total): v2 = this, v3 = p0 (int), v4 = p1 (android.support.v4.app.Fragment)
        v0 = 0;
        v1 = 1;
        _result = v2.a(v3, v4, v0, v1); // android.support.v4.app.l.a -> void
        return v2;
    }

    public android.support.v4.app.aj a(int p0, android.support.v4.app.Fragment p1, java.lang.String p2) {
        // Registers (5 total): v1 = this, v2 = p0 (int), v3 = p1 (android.support.v4.app.Fragment), v4 = p2 (java.lang.String)
        v0 = 1;
        _result = v1.a(v2, v3, v4, v0); // android.support.v4.app.l.a -> void
        return v1;
    }

    public android.support.v4.app.aj a(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = new android.support.v4.app.m;
        _result = v0.<init>(); // android.support.v4.app.m.<init> -> void
        v1 = 3;
        v0.c = v1; // android.support.v4.app.m.c:int
        v0.d = v3; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        _result = v2.a(v0); // android.support.v4.app.l.a -> void
        return v2;
    }

    public android.support.v4.app.aj a(android.support.v4.app.Fragment p0, java.lang.String p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment), v4 = p1 (java.lang.String)
        v0 = 0;
        v1 = 1;
        _result = v2.a(v0, v3, v4, v1); // android.support.v4.app.l.a -> void
        return v2;
    }

    void a(int p0) {
        // Registers (8 total): v6 = this, v7 = p0 (int)
        v0 = v6.k; // android.support.v4.app.l.k:boolean
        if (v0 != 0) /* goto L_0005 */;
        return;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_002e */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Bump nesting in ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " by ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v6.b; // android.support.v4.app.l.b:android.support.v4.app.m
        v2 = v0;
        if (v2 == 0) /* goto L_0004 */;
        v0 = v2.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_006d */;
        v0 = v2.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v0.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        v1 = binOp2addr_0xb0(v1, v7);
        v0.mBackStackNesting = v1; // android.support.v4.app.Fragment.mBackStackNesting:int
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_006d */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Bump nesting of ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v3 = v2.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v3 = " to ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v3 = v2.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v3 = v3.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v2.i; // android.support.v4.app.m.i:java.util.ArrayList
        if (v0 == 0) /* goto L_00b8 */;
        v0 = v2.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        v0 = binOpLit8_0xd8(v0, -1);
        v1 = v0;
        if (v1 < 0) /* goto L_00b8 */;
        v0 = v2.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v3 = v0.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        v3 = binOp2addr_0xb0(v3, v7);
        v0.mBackStackNesting = v3; // android.support.v4.app.Fragment.mBackStackNesting:int
        v3 = android.support.v4.app.y.a; // :boolean
        if (v3 == 0) /* goto L_00b4 */;
        v3 = "FragmentManager";
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "Bump nesting of ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = " to ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v0 = v0.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        _result = v4.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v3.v(v0); // android.util.Log.v -> int
        v0 = binOpLit8_0xd8(v1, -1);
        v1 = v0;
        // goto L_007a
        v0 = v2.a; // android.support.v4.app.m.a:android.support.v4.app.m
        v2 = v0;
        // goto L_0031
    }

    void a(android.support.v4.app.m p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.app.m)
        v0 = v1.b; // android.support.v4.app.l.b:android.support.v4.app.m
        if (v0 != 0) /* goto L_001f */;
        v1.c = v2; // android.support.v4.app.l.c:android.support.v4.app.m
        v1.b = v2; // android.support.v4.app.l.b:android.support.v4.app.m
        v0 = v1.e; // android.support.v4.app.l.e:int
        v2.e = v0; // android.support.v4.app.m.e:int
        v0 = v1.f; // android.support.v4.app.l.f:int
        v2.f = v0; // android.support.v4.app.m.f:int
        v0 = v1.g; // android.support.v4.app.l.g:int
        v2.g = v0; // android.support.v4.app.m.g:int
        v0 = v1.h; // android.support.v4.app.l.h:int
        v2.h = v0; // android.support.v4.app.m.h:int
        v0 = v1.d; // android.support.v4.app.l.d:int
        v0 = binOpLit8_0xd8(v0, 1);
        v1.d = v0; // android.support.v4.app.l.d:int
        return;
        v0 = v1.c; // android.support.v4.app.l.c:android.support.v4.app.m
        v2.b = v0; // android.support.v4.app.m.b:android.support.v4.app.m
        v0 = v1.c; // android.support.v4.app.l.c:android.support.v4.app.m
        v0.a = v2; // android.support.v4.app.m.a:android.support.v4.app.m
        v1.c = v2; // android.support.v4.app.l.c:android.support.v4.app.m
        // goto L_0008
    }

    public void a(java.lang.String p0, java.io.FileDescriptor p1, java.io.PrintWriter p2, java.lang.String[] p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.io.FileDescriptor), v4 = p2 (java.io.PrintWriter), v5 = p3 (java.lang.String[])
        v0 = 1;
        _result = v1.a(v2, v4, v0); // android.support.v4.app.l.a -> void
        return;
    }

    public void a(java.lang.String p0, java.io.PrintWriter p1, boolean p2) {
        // Registers (11 total): v7 = this, v8 = p0 (java.lang.String), v9 = p1 (java.io.PrintWriter), v10 = p2 (boolean)
        v1 = 0;
        if (v10 == 0) /* goto L_00e8 */;
        _result = v9.print(v8); // java.io.PrintWriter.print -> void
        v0 = "mName=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.m; // android.support.v4.app.l.m:java.lang.String
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mIndex=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.o; // android.support.v4.app.l.o:int
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mCommitted=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.n; // android.support.v4.app.l.n:boolean
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v7.i; // android.support.v4.app.l.i:int
        if (v0 == 0) /* goto L_004c */;
        _result = v9.print(v8); // java.io.PrintWriter.print -> void
        v0 = "mTransition=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.i; // android.support.v4.app.l.i:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mTransitionStyle=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.j; // android.support.v4.app.l.j:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v7.e; // android.support.v4.app.l.e:int
        if (v0 != 0) /* goto L_0054 */;
        v0 = v7.f; // android.support.v4.app.l.f:int
        if (v0 == 0) /* goto L_0075 */;
        _result = v9.print(v8); // java.io.PrintWriter.print -> void
        v0 = "mEnterAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.e; // android.support.v4.app.l.e:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mExitAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.f; // android.support.v4.app.l.f:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v7.g; // android.support.v4.app.l.g:int
        if (v0 != 0) /* goto L_007d */;
        v0 = v7.h; // android.support.v4.app.l.h:int
        if (v0 == 0) /* goto L_009e */;
        _result = v9.print(v8); // java.io.PrintWriter.print -> void
        v0 = "mPopEnterAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.g; // android.support.v4.app.l.g:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mPopExitAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.h; // android.support.v4.app.l.h:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v7.p; // android.support.v4.app.l.p:int
        if (v0 != 0) /* goto L_00a6 */;
        v0 = v7.q; // android.support.v4.app.l.q:java.lang.CharSequence
        if (v0 == 0) /* goto L_00c3 */;
        _result = v9.print(v8); // java.io.PrintWriter.print -> void
        v0 = "mBreadCrumbTitleRes=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.p; // android.support.v4.app.l.p:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mBreadCrumbTitleText=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.q; // android.support.v4.app.l.q:java.lang.CharSequence
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v7.r; // android.support.v4.app.l.r:int
        if (v0 != 0) /* goto L_00cb */;
        v0 = v7.s; // android.support.v4.app.l.s:java.lang.CharSequence
        if (v0 == 0) /* goto L_00e8 */;
        _result = v9.print(v8); // java.io.PrintWriter.print -> void
        v0 = "mBreadCrumbShortTitleRes=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.r; // android.support.v4.app.l.r:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " mBreadCrumbShortTitleText=";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v7.s; // android.support.v4.app.l.s:java.lang.CharSequence
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v7.b; // android.support.v4.app.l.b:android.support.v4.app.m
        if (v0 == 0) /* goto L_021b */;
        _result = v9.print(v8); // java.io.PrintWriter.print -> void
        v0 = "Operations:";
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = "    ";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        v0 = v7.b; // android.support.v4.app.l.b:android.support.v4.app.m
        v2 = v1;
        v3 = v0;
        if (v3 == 0) /* goto L_021b */;
        v0 = v3.c; // android.support.v4.app.m.c:int
        // switch(v0)
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "cmd=";
        _result = v0.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v5 = v3.c; // android.support.v4.app.m.c:int
        _result = v0.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v9.print(v8); // java.io.PrintWriter.print -> void
        v5 = "  Op #";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.print(v2); // java.io.PrintWriter.print -> void
        v5 = ": ";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " ";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        if (v10 == 0) /* goto L_019e */;
        v0 = v3.e; // android.support.v4.app.m.e:int
        if (v0 != 0) /* goto L_0154 */;
        v0 = v3.f; // android.support.v4.app.m.f:int
        if (v0 == 0) /* goto L_0175 */;
        _result = v9.print(v8); // java.io.PrintWriter.print -> void
        v0 = "enterAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.e; // android.support.v4.app.m.e:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " exitAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.f; // android.support.v4.app.m.f:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.g; // android.support.v4.app.m.g:int
        if (v0 != 0) /* goto L_017d */;
        v0 = v3.h; // android.support.v4.app.m.h:int
        if (v0 == 0) /* goto L_019e */;
        _result = v9.print(v8); // java.io.PrintWriter.print -> void
        v0 = "popEnterAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.g; // android.support.v4.app.m.g:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = " popExitAnim=#";
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v0 = v3.h; // android.support.v4.app.m.h:int
        _result = v0.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v0 = _result;
        _result = v9.println(v0); // java.io.PrintWriter.println -> void
        v0 = v3.i; // android.support.v4.app.m.i:java.util.ArrayList
        if (v0 == 0) /* goto L_0214 */;
        v0 = v3.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v0 <= 0) /* goto L_0214 */;
        v0 = v1;
        v5 = v3.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v5.size(); // java.util.ArrayList.size -> int
        v5 = _result;
        if (v0 >= v5) /* goto L_0214 */;
        _result = v9.print(v4); // java.io.PrintWriter.print -> void
        v5 = v3.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v5.size(); // java.util.ArrayList.size -> int
        v5 = _result;
        v6 = 1;
        if (v5 != v6) /* goto L_01f9 */;
        v5 = "Removed: ";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        v5 = v3.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v5.get(v0); // java.util.ArrayList.get -> java.lang.Object
        v5 = _result;
        _result = v9.println(v5); // java.io.PrintWriter.println -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_01ab
        v0 = "NULL";
        // goto L_012a
        v0 = "ADD";
        // goto L_012a
        v0 = "REPLACE";
        // goto L_012a
        v0 = "REMOVE";
        // goto L_012a
        v0 = "HIDE";
        // goto L_012a
        v0 = "SHOW";
        // goto L_012a
        v0 = "DETACH";
        // goto L_012a
        v0 = "ATTACH";
        // goto L_012a
        if (v0 != 0) /* goto L_0201 */;
        v5 = "Removed:";
        _result = v9.println(v5); // java.io.PrintWriter.println -> void
        _result = v9.print(v4); // java.io.PrintWriter.print -> void
        v5 = "  #";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        _result = v9.print(v0); // java.io.PrintWriter.print -> void
        v5 = ": ";
        _result = v9.print(v5); // java.io.PrintWriter.print -> void
        // goto L_01c5
        v3 = v3.a; // android.support.v4.app.m.a:android.support.v4.app.m
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_010d
        return;
    }

    public int b() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.a(v0); // android.support.v4.app.l.a -> int
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.aj b(int p0, android.support.v4.app.Fragment p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (android.support.v4.app.Fragment)
        v0 = 0;
        _result = v1.b(v2, v3, v0); // android.support.v4.app.l.b -> android.support.v4.app.aj
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.aj b(int p0, android.support.v4.app.Fragment p1, java.lang.String p2) {
        // Registers (6 total): v2 = this, v3 = p0 (int), v4 = p1 (android.support.v4.app.Fragment), v5 = p2 (java.lang.String)
        if (v3 != 0) /* goto L_000b */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Must use non-zero containerViewId";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = 2;
        _result = v2.a(v3, v4, v5, v0); // android.support.v4.app.l.a -> void
        return v2;
    }

    public android.support.v4.app.aj b(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = new android.support.v4.app.m;
        _result = v0.<init>(); // android.support.v4.app.m.<init> -> void
        v1 = 4;
        v0.c = v1; // android.support.v4.app.m.c:int
        v0.d = v3; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        _result = v2.a(v0); // android.support.v4.app.l.a -> void
        return v2;
    }

    public void b(boolean p0) {
        // Registers (9 total): v7 = this, v8 = p0 (boolean)
        v4 = 0;
        v6 = -1;
        v2 = 0;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0034 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "popFromBackStack: ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = new android.support.v4.c.e;
        v1 = "FragmentManager";
        _result = v0.<init>(v1); // android.support.v4.c.e.<init> -> void
        v1 = new java.io.PrintWriter;
        _result = v1.<init>(v0); // java.io.PrintWriter.<init> -> void
        v0 = "  ";
        _result = v7.a(v0, v4, v1, v4); // android.support.v4.app.l.a -> void
        _result = v7.a(v6); // android.support.v4.app.l.a -> void
        v0 = v7.c; // android.support.v4.app.l.c:android.support.v4.app.m
        v3 = v0;
        if (v3 == 0) /* goto L_0109 */;
        v0 = v3.c; // android.support.v4.app.m.c:int
        // switch(v0)
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Unknown cmd: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.c; // android.support.v4.app.m.c:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v3.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v3.h; // android.support.v4.app.m.h:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v4 = v7.i; // android.support.v4.app.l.i:int
        _result = v4.c(); // android.support.v4.app.y.c -> int
        v4 = _result;
        v5 = v7.j; // android.support.v4.app.l.j:int
        _result = v1.a(v0, v4, v5); // android.support.v4.app.y.a -> void
        v0 = v3.b; // android.support.v4.app.m.b:android.support.v4.app.m
        v3 = v0;
        // goto L_003a
        v0 = v3.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        if (v0 == 0) /* goto L_0089 */;
        v1 = v3.h; // android.support.v4.app.m.h:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v4 = v7.i; // android.support.v4.app.l.i:int
        _result = v4.c(); // android.support.v4.app.y.c -> int
        v4 = _result;
        v5 = v7.j; // android.support.v4.app.l.j:int
        _result = v1.a(v0, v4, v5); // android.support.v4.app.y.a -> void
        v0 = v3.i; // android.support.v4.app.m.i:java.util.ArrayList
        if (v0 == 0) /* goto L_0070 */;
        v1 = v2;
        v0 = v3.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0070 */;
        v0 = v3.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v4 = v3.g; // android.support.v4.app.m.g:int
        v0.mNextAnim = v4; // android.support.v4.app.Fragment.mNextAnim:int
        v4 = v7.a; // android.support.v4.app.l.a:android.support.v4.app.y
        _result = v4.a(v0, v2); // android.support.v4.app.y.a -> void
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_008e
        v0 = v3.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v3.g; // android.support.v4.app.m.g:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.a; // android.support.v4.app.l.a:android.support.v4.app.y
        _result = v1.a(v0, v2); // android.support.v4.app.y.a -> void
        // goto L_0070
        v0 = v3.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v3.g; // android.support.v4.app.m.g:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v4 = v7.i; // android.support.v4.app.l.i:int
        _result = v4.c(); // android.support.v4.app.y.c -> int
        v4 = _result;
        v5 = v7.j; // android.support.v4.app.l.j:int
        _result = v1.c(v0, v4, v5); // android.support.v4.app.y.c -> void
        // goto L_0070
        v0 = v3.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v3.h; // android.support.v4.app.m.h:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v4 = v7.i; // android.support.v4.app.l.i:int
        _result = v4.c(); // android.support.v4.app.y.c -> int
        v4 = _result;
        v5 = v7.j; // android.support.v4.app.l.j:int
        _result = v1.b(v0, v4, v5); // android.support.v4.app.y.b -> void
        // goto L_0070
        v0 = v3.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v3.g; // android.support.v4.app.m.g:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v4 = v7.i; // android.support.v4.app.l.i:int
        _result = v4.c(); // android.support.v4.app.y.c -> int
        v4 = _result;
        v5 = v7.j; // android.support.v4.app.l.j:int
        _result = v1.e(v0, v4, v5); // android.support.v4.app.y.e -> void
        // goto L_0070
        v0 = v3.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v3.g; // android.support.v4.app.m.g:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v7.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v4 = v7.i; // android.support.v4.app.l.i:int
        _result = v4.c(); // android.support.v4.app.y.c -> int
        v4 = _result;
        v5 = v7.j; // android.support.v4.app.l.j:int
        _result = v1.d(v0, v4, v5); // android.support.v4.app.y.d -> void
        // goto L_0070
        if (v8 == 0) /* goto L_011d */;
        v0 = v7.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v1 = v7.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v1 = v1.n; // android.support.v4.app.y.n:int
        v2 = v7.i; // android.support.v4.app.l.i:int
        _result = v2.c(); // android.support.v4.app.y.c -> int
        v2 = _result;
        v3 = v7.j; // android.support.v4.app.l.j:int
        v4 = 1;
        _result = v0.a(v1, v2, v3, v4); // android.support.v4.app.y.a -> void
        v0 = v7.o; // android.support.v4.app.l.o:int
        if (v0 < 0) /* goto L_012a */;
        v0 = v7.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v1 = v7.o; // android.support.v4.app.l.o:int
        _result = v0.b(v1); // android.support.v4.app.y.b -> void
        v7.o = v6; // android.support.v4.app.l.o:int
        return;
    }

    public int c() {
        // Registers (2 total): v1 = this
        v0 = 1;
        _result = v1.a(v0); // android.support.v4.app.l.a -> int
        v0 = _result;
        return v0;
    }

    public android.support.v4.app.aj c(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = new android.support.v4.app.m;
        _result = v0.<init>(); // android.support.v4.app.m.<init> -> void
        v1 = 5;
        v0.c = v1; // android.support.v4.app.m.c:int
        v0.d = v3; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        _result = v2.a(v0); // android.support.v4.app.l.a -> void
        return v2;
    }

    public android.support.v4.app.aj d(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = new android.support.v4.app.m;
        _result = v0.<init>(); // android.support.v4.app.m.<init> -> void
        v1 = 6;
        v0.c = v1; // android.support.v4.app.m.c:int
        v0.d = v3; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        _result = v2.a(v0); // android.support.v4.app.l.a -> void
        return v2;
    }

    public java.lang.String d() {
        // Registers (2 total): v1 = this
        v0 = v1.m; // android.support.v4.app.l.m:java.lang.String
        return v0;
    }

    public android.support.v4.app.aj e(android.support.v4.app.Fragment p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.support.v4.app.Fragment)
        v0 = new android.support.v4.app.m;
        _result = v0.<init>(); // android.support.v4.app.m.<init> -> void
        v1 = 7;
        v0.c = v1; // android.support.v4.app.m.c:int
        v0.d = v3; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        _result = v2.a(v0); // android.support.v4.app.l.a -> void
        return v2;
    }

    public boolean e() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // android.support.v4.app.l.d:int
        if (v0 != 0) /* goto L_0006 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0005
    }

    public void run() {
        // Registers (10 total): v9 = this
        v8 = 1;
        v2 = 0;
        v0 = android.support.v4.app.y.a; // :boolean
        if (v0 == 0) /* goto L_0020 */;
        v0 = "FragmentManager";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Run: ";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v9); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.v(v1); // android.util.Log.v -> int
        v0 = v9.k; // android.support.v4.app.l.k:boolean
        if (v0 == 0) /* goto L_0031 */;
        v0 = v9.o; // android.support.v4.app.l.o:int
        if (v0 >= 0) /* goto L_0031 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "addToBackStack() called after commit()";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        _result = v9.a(v8); // android.support.v4.app.l.a -> void
        v0 = v9.b; // android.support.v4.app.l.b:android.support.v4.app.m
        v4 = v0;
        if (v4 == 0) /* goto L_0177 */;
        v0 = v4.c; // android.support.v4.app.m.c:int
        // switch(v0)
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Unknown cmd: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.c; // android.support.v4.app.m.c:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        v0 = v4.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v4.e; // android.support.v4.app.m.e:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        _result = v1.a(v0, v2); // android.support.v4.app.y.a -> void
        v0 = v4.a; // android.support.v4.app.m.a:android.support.v4.app.m
        v4 = v0;
        // goto L_0037
        v0 = v4.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v1 = v1.g; // android.support.v4.app.y.g:java.util.ArrayList
        if (v1 == 0) /* goto L_0114 */;
        v1 = v2;
        v3 = v0;
        v0 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v0 = v0.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        if (v1 >= v0) /* goto L_0115 */;
        v0 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v0 = v0.g; // android.support.v4.app.y.g:java.util.ArrayList
        _result = v0.get(v1); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.app.Fragment) v0;
        v5 = android.support.v4.app.y.a; // :boolean
        if (v5 == 0) /* goto L_00b0 */;
        v5 = "FragmentManager";
        v6 = new java.lang.StringBuilder;
        _result = v6.<init>(); // java.lang.StringBuilder.<init> -> void
        v7 = "OP_REPLACE: adding=";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v7 = " old=";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v6 = _result;
        _result = v5.v(v6); // android.util.Log.v -> int
        if (v3 == 0) /* goto L_00b8 */;
        v5 = v0.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        v6 = v3.mContainerId; // android.support.v4.app.Fragment.mContainerId:int
        if (v5 != v6) /* goto L_00bd */;
        if (v0 != v3) /* goto L_00c1 */;
        v3 = 0;
        v4.d = v3; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v0 = binOpLit8_0xd8(v1, 1);
        v1 = v0;
        // goto L_0073
        v5 = v4.i; // android.support.v4.app.m.i:java.util.ArrayList
        if (v5 != 0) /* goto L_00cc */;
        v5 = new java.util.ArrayList;
        _result = v5.<init>(); // java.util.ArrayList.<init> -> void
        v4.i = v5; // android.support.v4.app.m.i:java.util.ArrayList
        v5 = v4.i; // android.support.v4.app.m.i:java.util.ArrayList
        _result = v5.add(v0); // java.util.ArrayList.add -> boolean
        v5 = v4.f; // android.support.v4.app.m.f:int
        v0.mNextAnim = v5; // android.support.v4.app.Fragment.mNextAnim:int
        v5 = v9.k; // android.support.v4.app.l.k:boolean
        if (v5 == 0) /* goto L_010a */;
        v5 = v0.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        v5 = binOpLit8_0xd8(v5, 1);
        v0.mBackStackNesting = v5; // android.support.v4.app.Fragment.mBackStackNesting:int
        v5 = android.support.v4.app.y.a; // :boolean
        if (v5 == 0) /* goto L_010a */;
        v5 = "FragmentManager";
        v6 = new java.lang.StringBuilder;
        _result = v6.<init>(); // java.lang.StringBuilder.<init> -> void
        v7 = "Bump nesting of ";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v7 = " to ";
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        v7 = v0.mBackStackNesting; // android.support.v4.app.Fragment.mBackStackNesting:int
        _result = v6.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v6 = _result;
        _result = v6.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v6 = _result;
        _result = v5.v(v6); // android.util.Log.v -> int
        v5 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v6 = v9.i; // android.support.v4.app.l.i:int
        v7 = v9.j; // android.support.v4.app.l.j:int
        _result = v5.a(v0, v6, v7); // android.support.v4.app.y.a -> void
        // goto L_00bd
        v3 = v0;
        if (v3 == 0) /* goto L_0065 */;
        v0 = v4.e; // android.support.v4.app.m.e:int
        v3.mNextAnim = v0; // android.support.v4.app.Fragment.mNextAnim:int
        v0 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        _result = v0.a(v3, v2); // android.support.v4.app.y.a -> void
        // goto L_0065
        v0 = v4.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v4.f; // android.support.v4.app.m.f:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v3 = v9.i; // android.support.v4.app.l.i:int
        v5 = v9.j; // android.support.v4.app.l.j:int
        _result = v1.a(v0, v3, v5); // android.support.v4.app.y.a -> void
        // goto L_0065
        v0 = v4.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v4.f; // android.support.v4.app.m.f:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v3 = v9.i; // android.support.v4.app.l.i:int
        v5 = v9.j; // android.support.v4.app.l.j:int
        _result = v1.b(v0, v3, v5); // android.support.v4.app.y.b -> void
        // goto L_0065
        v0 = v4.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v4.e; // android.support.v4.app.m.e:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v3 = v9.i; // android.support.v4.app.l.i:int
        v5 = v9.j; // android.support.v4.app.l.j:int
        _result = v1.c(v0, v3, v5); // android.support.v4.app.y.c -> void
        // goto L_0065
        v0 = v4.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v4.f; // android.support.v4.app.m.f:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v3 = v9.i; // android.support.v4.app.l.i:int
        v5 = v9.j; // android.support.v4.app.l.j:int
        _result = v1.d(v0, v3, v5); // android.support.v4.app.y.d -> void
        // goto L_0065
        v0 = v4.d; // android.support.v4.app.m.d:android.support.v4.app.Fragment
        v1 = v4.e; // android.support.v4.app.m.e:int
        v0.mNextAnim = v1; // android.support.v4.app.Fragment.mNextAnim:int
        v1 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v3 = v9.i; // android.support.v4.app.l.i:int
        v5 = v9.j; // android.support.v4.app.l.j:int
        _result = v1.e(v0, v3, v5); // android.support.v4.app.y.e -> void
        // goto L_0065
        v0 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v1 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        v1 = v1.n; // android.support.v4.app.y.n:int
        v2 = v9.i; // android.support.v4.app.l.i:int
        v3 = v9.j; // android.support.v4.app.l.j:int
        _result = v0.a(v1, v2, v3, v8); // android.support.v4.app.y.a -> void
        v0 = v9.k; // android.support.v4.app.l.k:boolean
        if (v0 == 0) /* goto L_018d */;
        v0 = v9.a; // android.support.v4.app.l.a:android.support.v4.app.y
        _result = v0.b(v9); // android.support.v4.app.y.b -> void
        return;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        v1 = 128;
        _result = v0.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = "BackStackEntry{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v2.identityHashCode(); // java.lang.System.identityHashCode -> int
        v1 = _result;
        _result = v1.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.o; // android.support.v4.app.l.o:int
        if (v1 < 0) /* goto L_0027 */;
        v1 = " #";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.o; // android.support.v4.app.l.o:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.m; // android.support.v4.app.l.m:java.lang.String
        if (v1 == 0) /* goto L_0036 */;
        v1 = " ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v2.m; // android.support.v4.app.l.m:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = "}";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}