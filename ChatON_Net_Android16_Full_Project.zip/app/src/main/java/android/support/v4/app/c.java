package android.support.v4.app;

/**
 * Original SourceFile: ActionBarDrawerToggle.java
 * Descriptor: Landroid/support/v4/app/c;
 */
interface c {
    public abstract android.graphics.drawable.Drawable a(android.app.Activity p0);
    public abstract java.lang.Object a(java.lang.Object p0, android.app.Activity p1, int p2);
}