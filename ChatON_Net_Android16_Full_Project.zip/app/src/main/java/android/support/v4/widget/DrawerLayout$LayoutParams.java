package android.support.v4.widget;

/**
 * Original SourceFile: DrawerLayout.java
 * Descriptor: Landroid/support/v4/widget/DrawerLayout$LayoutParams;
 */
public class DrawerLayout$LayoutParams extends android.view.ViewGroup$MarginLayoutParams {
    public int a;
     float b;
     boolean c;
     boolean d;

    public DrawerLayout$LayoutParams(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        _result = v1.<init>(v2, v3); // android.view.ViewGroup$MarginLayoutParams.<init> -> void
        v0 = 0;
        v1.a = v0; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        return;
    }

    public DrawerLayout$LayoutParams(android.content.Context p0, android.util.AttributeSet p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.content.Context), v4 = p1 (android.util.AttributeSet)
        v1 = 0;
        _result = v2.<init>(v3, v4); // android.view.ViewGroup$MarginLayoutParams.<init> -> void
        v2.a = v1; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        _result = this.d(); // android.support.v4.widget.DrawerLayout.d -> int[]
        v0 = _result;
        _result = v3.obtainStyledAttributes(v4, v0); // android.content.Context.obtainStyledAttributes -> android.content.res.TypedArray
        v0 = _result;
        _result = v0.getInt(v1, v1); // android.content.res.TypedArray.getInt -> int
        v1 = _result;
        v2.a = v1; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        _result = v0.recycle(); // android.content.res.TypedArray.recycle -> void
        return;
    }

    public DrawerLayout$LayoutParams(android.support.v4.widget.DrawerLayout$LayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.widget.DrawerLayout$LayoutParams)
        _result = v1.<init>(v2); // android.view.ViewGroup$MarginLayoutParams.<init> -> void
        v0 = 0;
        v1.a = v0; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        v0 = v2.a; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        v1.a = v0; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        return;
    }

    public DrawerLayout$LayoutParams(android.view.ViewGroup$LayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$LayoutParams)
        _result = v1.<init>(v2); // android.view.ViewGroup$MarginLayoutParams.<init> -> void
        v0 = 0;
        v1.a = v0; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        return;
    }

    public DrawerLayout$LayoutParams(android.view.ViewGroup$MarginLayoutParams p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.view.ViewGroup$MarginLayoutParams)
        _result = v1.<init>(v2); // android.view.ViewGroup$MarginLayoutParams.<init> -> void
        v0 = 0;
        v1.a = v0; // android.support.v4.widget.DrawerLayout$LayoutParams.a:int
        return;
    }

}