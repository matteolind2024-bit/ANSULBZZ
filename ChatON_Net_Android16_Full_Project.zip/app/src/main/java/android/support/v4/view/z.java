package android.support.v4.view;

/**
 * Original SourceFile: MotionEventCompat.java
 * Descriptor: Landroid/support/v4/view/z;
 */
public class z {
    static final android.support.v4.view.ac a;

    static {
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v1 = 5;
        if (v0 < v1) /* goto L_000d */;
        v0 = new android.support.v4.view.ab;
        _result = v0.<init>(); // android.support.v4.view.ab.<init> -> void
        android.support.v4.view.z.a = v0; // :android.support.v4.view.ac
        return;
        v0 = new android.support.v4.view.aa;
        _result = v0.<init>(); // android.support.v4.view.aa.<init> -> void
        android.support.v4.view.z.a = v0; // :android.support.v4.view.ac
        // goto L_000c
    }

    public static int a(android.view.MotionEvent p0) {
        // Registers (2 total): v1 = p0 (android.view.MotionEvent)
        _result = v1.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        v0 = binOpLit16_0xd5(v0, 255);
        return v0;
    }

    public static int a(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        v0 = android.support.v4.view.z.a; // :android.support.v4.view.ac
        _result = android.support.v4.view.ac.a(v0, v1, v2); // -> int
        v0 = _result;
        return v0;
    }

    public static int b(android.view.MotionEvent p0) {
        // Registers (3 total): v2 = p0 (android.view.MotionEvent)
        _result = v2.getAction(); // android.view.MotionEvent.getAction -> int
        v0 = _result;
        v1 = 65280; // 0x0000ff00
        v0 = binOp2addr_0xb5(v0, v1);
        v0 = binOpLit8_0xe1(v0, 8);
        return v0;
    }

    public static int b(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        v0 = android.support.v4.view.z.a; // :android.support.v4.view.ac
        _result = android.support.v4.view.ac.b(v0, v1, v2); // -> int
        v0 = _result;
        return v0;
    }

    public static float c(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        v0 = android.support.v4.view.z.a; // :android.support.v4.view.ac
        _result = android.support.v4.view.ac.c(v0, v1, v2); // -> float
        v0 = _result;
        return v0;
    }

    public static int c(android.view.MotionEvent p0) {
        // Registers (2 total): v1 = p0 (android.view.MotionEvent)
        v0 = android.support.v4.view.z.a; // :android.support.v4.view.ac
        _result = android.support.v4.view.ac.a(v0, v1); // -> int
        v0 = _result;
        return v0;
    }

    public static float d(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        v0 = android.support.v4.view.z.a; // :android.support.v4.view.ac
        _result = android.support.v4.view.ac.d(v0, v1, v2); // -> float
        v0 = _result;
        return v0;
    }

}