package android.support.v4.widget;

/**
 * Original SourceFile: DrawerLayout.java
 * Descriptor: Landroid/support/v4/widget/j;
 */
public interface j {
    public abstract void a(int p0);
    public abstract void a(android.view.View p0);
    public abstract void a(android.view.View p0, float p1);
    public abstract void b(android.view.View p0);
}