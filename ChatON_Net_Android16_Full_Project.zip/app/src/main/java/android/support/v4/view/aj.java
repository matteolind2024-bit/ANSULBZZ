package android.support.v4.view;

/**
 * Original SourceFile: PagerTitleStrip.java
 * Descriptor: Landroid/support/v4/view/aj;
 */
interface aj {
    public abstract void a(android.widget.TextView p0);
}