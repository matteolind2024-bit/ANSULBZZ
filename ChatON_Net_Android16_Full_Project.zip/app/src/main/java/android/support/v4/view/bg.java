package android.support.v4.view;

/**
 * Original SourceFile: ViewCompatICS.java
 * Descriptor: Landroid/support/v4/view/bg;
 */
class bg {
    public static void a(android.view.View p0, java.lang.Object p1) {
        // Registers (2 total): v0 = p0 (android.view.View), v1 = p1 (java.lang.Object)
        v1 = (android.view.View$AccessibilityDelegate) v1;
        _result = v0.setAccessibilityDelegate(v1); // android.view.View.setAccessibilityDelegate -> void
        return;
    }

    public static boolean a(android.view.View p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.View), v2 = p1 (int)
        _result = v1.canScrollHorizontally(v2); // android.view.View.canScrollHorizontally -> boolean
        v0 = _result;
        return v0;
    }

}