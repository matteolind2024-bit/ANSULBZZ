package android.support.v4.app;

/**
 * Original SourceFile: NoSaveStateFrameLayout.java
 * Descriptor: Landroid/support/v4/app/aq;
 */
class aq extends android.widget.FrameLayout {
    public aq(android.content.Context p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.content.Context)
        _result = v0.<init>(v1); // android.widget.FrameLayout.<init> -> void
        return;
    }

    static android.view.ViewGroup a(android.view.View p0) {
        // Registers (4 total): v3 = p0 (android.view.View)
        v2 = -1;
        v0 = new android.support.v4.app.aq;
        _result = v3.getContext(); // android.view.View.getContext -> android.content.Context
        v1 = _result;
        _result = v0.<init>(v1); // android.support.v4.app.aq.<init> -> void
        _result = v3.getLayoutParams(); // android.view.View.getLayoutParams -> android.view.ViewGroup$LayoutParams
        v1 = _result;
        if (v1 == 0) /* goto L_0013 */;
        _result = v0.setLayoutParams(v1); // android.support.v4.app.aq.setLayoutParams -> void
        v1 = new android.widget.FrameLayout$LayoutParams;
        _result = v1.<init>(v2, v2); // android.widget.FrameLayout$LayoutParams.<init> -> void
        _result = v3.setLayoutParams(v1); // android.view.View.setLayoutParams -> void
        _result = v0.addView(v3); // android.support.v4.app.aq.addView -> void
        return v0;
    }

    protected void dispatchRestoreInstanceState(android.util.SparseArray p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.util.SparseArray)
        _result = v0.dispatchThawSelfOnly(v1); // android.support.v4.app.aq.dispatchThawSelfOnly -> void
        return;
    }

    protected void dispatchSaveInstanceState(android.util.SparseArray p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.util.SparseArray)
        _result = v0.dispatchFreezeSelfOnly(v1); // android.support.v4.app.aq.dispatchFreezeSelfOnly -> void
        return;
    }

}