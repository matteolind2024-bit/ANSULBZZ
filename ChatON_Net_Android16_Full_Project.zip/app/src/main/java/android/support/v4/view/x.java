package android.support.v4.view;

/**
 * Original SourceFile: KeyEventCompatEclair.java
 * Descriptor: Landroid/support/v4/view/x;
 */
class x {
    public static void a(android.view.KeyEvent p0) {
        // Registers (1 total): v0 = p0 (android.view.KeyEvent)
        _result = v0.startTracking(); // android.view.KeyEvent.startTracking -> void
        return;
    }

}