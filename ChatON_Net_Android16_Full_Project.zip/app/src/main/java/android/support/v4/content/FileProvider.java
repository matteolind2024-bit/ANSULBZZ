package android.support.v4.content;

/**
 * Original SourceFile: FileProvider.java
 * Descriptor: Landroid/support/v4/content/FileProvider;
 */
public class FileProvider extends android.content.ContentProvider {
    private static final java.lang.String[] a;
    private static final java.io.File b;
    private static java.util.HashMap c;
    private android.support.v4.content.d d;

    static {
        v0 = 2;
        v0 = new java.lang.String[][size=v0];
        v1 = 0;
        v2 = "_display_name";
        v0[v1] = v2;
        v1 = 1;
        v2 = "_size";
        v0[v1] = v2;
        android.support.v4.content.FileProvider.a = v0; // :java.lang.String[]
        v0 = new java.io.File;
        v1 = "/";
        _result = v0.<init>(v1); // java.io.File.<init> -> void
        android.support.v4.content.FileProvider.b = v0; // :java.io.File
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        android.support.v4.content.FileProvider.c = v0; // :java.util.HashMap
        return;
    }

    public FileProvider() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.content.ContentProvider.<init> -> void
        return;
    }

    private static int a(java.lang.String p0) {
        // Registers (4 total): v3 = p0 (java.lang.String)
        v0 = "r";
        _result = v0.equals(v3); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000c */;
        v0 = 0x10000000;
        return v0;
        v0 = "w";
        _result = v0.equals(v3); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_001e */;
        v0 = "wt";
        _result = v0.equals(v3); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0021 */;
        v0 = 0x2c000000;
        // goto L_000b
        v0 = "wa";
        _result = v0.equals(v3); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002d */;
        v0 = 0x2a000000;
        // goto L_000b
        v0 = "rw";
        _result = v0.equals(v3); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0039 */;
        v0 = 0x38000000;
        // goto L_000b
        v0 = "rwt";
        _result = v0.equals(v3); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0045 */;
        v0 = 0x3c000000;
        // goto L_000b
        v0 = new java.lang.IllegalArgumentException;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Invalid mode: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
    }

    public static android.net.Uri a(android.content.Context p0, java.lang.String p1, java.io.File p2) {
        // Registers (4 total): v1 = p0 (android.content.Context), v2 = p1 (java.lang.String), v3 = p2 (java.io.File)
        _result = v1.a(v2); // android.support.v4.content.FileProvider.a -> android.support.v4.content.d
        v0 = _result;
        _result = android.support.v4.content.d.a(v0, v3); // -> android.net.Uri
        v0 = _result;
        return v0;
    }

    private static android.support.v4.content.d a(android.content.Context p0, java.lang.String p1) {
        // Registers (6 total): v4 = p0 (android.content.Context), v5 = p1 (java.lang.String)
        v1 = android.support.v4.content.FileProvider.c; // :java.util.HashMap
        // monitor-enter(v1)
        v0 = android.support.v4.content.FileProvider.c; // :java.util.HashMap
        _result = v0.get(v5); // java.util.HashMap.get -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.content.d) v0;
        if (v0 != 0) /* goto L_0016 */;
        _result = v4.b(v5); // android.support.v4.content.FileProvider.b -> android.support.v4.content.d
        v0 = _result;
        v2 = android.support.v4.content.FileProvider.c; // :java.util.HashMap
        _result = v2.put(v5, v0); // java.util.HashMap.put -> java.lang.Object
        // monitor-exit(v1)
        return v0;
        v0 = _exception;
        v2 = new java.lang.IllegalArgumentException;
        v3 = "Failed to parse android.support.FILE_PROVIDER_PATHS meta-data";
        _result = v2.<init>(v3, v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v2;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
        v0 = _exception;
        v2 = new java.lang.IllegalArgumentException;
        v3 = "Failed to parse android.support.FILE_PROVIDER_PATHS meta-data";
        _result = v2.<init>(v3, v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v2;
    }

    private static java.io.File a(java.io.File p0, java.lang.String[] p1) {
        // Registers (7 total): v5 = p0 (java.io.File), v6 = p1 (java.lang.String[])
        v3 = v6.length;
        v0 = 0;
        v2 = v0;
        v1 = v5;
        if (v2 >= v3) /* goto L_0014 */;
        v4 = v6[v2];
        if (v4 == 0) /* goto L_0015 */;
        v0 = new java.io.File;
        _result = v0.<init>(v1, v4); // java.io.File.<init> -> void
        v1 = binOpLit8_0xd8(v2, 1);
        v2 = v1;
        v1 = v0;
        // goto L_0004
        return v1;
        v0 = v1;
        // goto L_000f
    }

    private static java.lang.Object[] a(java.lang.Object[] p0, int p1) {
        // Registers (4 total): v2 = p0 (java.lang.Object[]), v3 = p1 (int)
        v1 = 0;
        v0 = new java.lang.Object[][size=v3];
        _result = v2.arraycopy(v1, v0, v1, v3); // java.lang.System.arraycopy -> void
        return v0;
    }

    private static java.lang.String[] a(java.lang.String[] p0, int p1) {
        // Registers (4 total): v2 = p0 (java.lang.String[]), v3 = p1 (int)
        v1 = 0;
        v0 = new java.lang.String[][size=v3];
        _result = v2.arraycopy(v1, v0, v1, v3); // java.lang.System.arraycopy -> void
        return v0;
    }

    private static android.support.v4.content.d b(android.content.Context p0, java.lang.String p1) {
        // Registers (11 total): v9 = p0 (android.content.Context), v10 = p1 (java.lang.String)
        v1 = 0;
        v8 = 0;
        v7 = 1;
        v2 = new android.support.v4.content.e;
        _result = v2.<init>(v10); // android.support.v4.content.e.<init> -> void
        _result = v9.getPackageManager(); // android.content.Context.getPackageManager -> android.content.pm.PackageManager
        v0 = _result;
        v3 = 128;
        _result = v0.resolveContentProvider(v10, v3); // android.content.pm.PackageManager.resolveContentProvider -> android.content.pm.ProviderInfo
        v0 = _result;
        _result = v9.getPackageManager(); // android.content.Context.getPackageManager -> android.content.pm.PackageManager
        v3 = _result;
        v4 = "android.support.FILE_PROVIDER_PATHS";
        _result = v0.loadXmlMetaData(v3, v4); // android.content.pm.ProviderInfo.loadXmlMetaData -> android.content.res.XmlResourceParser
        v3 = _result;
        if (v3 != 0) /* goto L_0028 */;
        v0 = new java.lang.IllegalArgumentException;
        v1 = "Missing android.support.FILE_PROVIDER_PATHS meta-data";
        _result = v0.<init>(v1); // java.lang.IllegalArgumentException.<init> -> void
        throw v0;
        _result = android.content.res.XmlResourceParser.next(v3); // -> int
        v0 = _result;
        if (v0 == v7) /* goto L_009e */;
        v4 = 2;
        if (v0 != v4) /* goto L_0028 */;
        _result = android.content.res.XmlResourceParser.getName(v3); // -> java.lang.String
        v0 = _result;
        v4 = "name";
        _result = android.content.res.XmlResourceParser.getAttributeValue(v3, v1, v4); // -> java.lang.String
        v4 = _result;
        v5 = "path";
        _result = android.content.res.XmlResourceParser.getAttributeValue(v3, v1, v5); // -> java.lang.String
        v5 = _result;
        v6 = "root-path";
        _result = v6.equals(v0); // java.lang.String.equals -> boolean
        v6 = _result;
        if (v6 == 0) /* goto L_005c */;
        v0 = android.support.v4.content.FileProvider.b; // :java.io.File
        v6 = new java.lang.String[][size=v7];
        v6[v8] = v5;
        _result = v0.a(v6); // android.support.v4.content.FileProvider.a -> java.io.File
        v0 = _result;
        if (v0 == 0) /* goto L_0028 */;
        _result = v2.a(v4, v0); // android.support.v4.content.e.a -> void
        // goto L_0028
        v6 = "files-path";
        _result = v6.equals(v0); // java.lang.String.equals -> boolean
        v6 = _result;
        if (v6 == 0) /* goto L_0072 */;
        _result = v9.getFilesDir(); // android.content.Context.getFilesDir -> java.io.File
        v0 = _result;
        v6 = new java.lang.String[][size=v7];
        v6[v8] = v5;
        _result = v0.a(v6); // android.support.v4.content.FileProvider.a -> java.io.File
        v0 = _result;
        // goto L_0056
        v6 = "cache-path";
        _result = v6.equals(v0); // java.lang.String.equals -> boolean
        v6 = _result;
        if (v6 == 0) /* goto L_0088 */;
        _result = v9.getCacheDir(); // android.content.Context.getCacheDir -> java.io.File
        v0 = _result;
        v6 = new java.lang.String[][size=v7];
        v6[v8] = v5;
        _result = v0.a(v6); // android.support.v4.content.FileProvider.a -> java.io.File
        v0 = _result;
        // goto L_0056
        v6 = "external-path";
        _result = v6.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_009f */;
        _result = this.getExternalStorageDirectory(); // android.os.Environment.getExternalStorageDirectory -> java.io.File
        v0 = _result;
        v6 = new java.lang.String[][size=v7];
        v6[v8] = v5;
        _result = v0.a(v6); // android.support.v4.content.FileProvider.a -> java.io.File
        v0 = _result;
        // goto L_0056
        return v2;
        v0 = v1;
        // goto L_0056
    }

    public void attachInfo(android.content.Context p0, android.content.pm.ProviderInfo p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.content.Context), v4 = p1 (android.content.pm.ProviderInfo)
        _result = v2.attachInfo(v3, v4); // android.content.ContentProvider.attachInfo -> void
        v0 = v4.exported; // android.content.pm.ProviderInfo.exported:boolean
        if (v0 == 0) /* goto L_0010 */;
        v0 = new java.lang.SecurityException;
        v1 = "Provider must not be exported";
        _result = v0.<init>(v1); // java.lang.SecurityException.<init> -> void
        throw v0;
        v0 = v4.grantUriPermissions; // android.content.pm.ProviderInfo.grantUriPermissions:boolean
        if (v0 != 0) /* goto L_001d */;
        v0 = new java.lang.SecurityException;
        v1 = "Provider must grant uri permissions";
        _result = v0.<init>(v1); // java.lang.SecurityException.<init> -> void
        throw v0;
        v0 = v4.authority; // android.content.pm.ProviderInfo.authority:java.lang.String
        _result = v3.a(v0); // android.support.v4.content.FileProvider.a -> android.support.v4.content.d
        v0 = _result;
        v2.d = v0; // android.support.v4.content.FileProvider.d:android.support.v4.content.d
        return;
    }

    public int delete(android.net.Uri p0, java.lang.String p1, java.lang.String[] p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.net.Uri), v3 = p1 (java.lang.String), v4 = p2 (java.lang.String[])
        v0 = v1.d; // android.support.v4.content.FileProvider.d:android.support.v4.content.d
        _result = android.support.v4.content.d.a(v0, v2); // -> java.io.File
        v0 = _result;
        _result = v0.delete(); // java.io.File.delete -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000e */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000d
    }

    public java.lang.String getType(android.net.Uri p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.net.Uri)
        v0 = v3.d; // android.support.v4.content.FileProvider.d:android.support.v4.content.d
        _result = android.support.v4.content.d.a(v0, v4); // -> java.io.File
        v0 = _result;
        _result = v0.getName(); // java.io.File.getName -> java.lang.String
        v1 = _result;
        v2 = 46;
        _result = v1.lastIndexOf(v2); // java.lang.String.lastIndexOf -> int
        v1 = _result;
        if (v1 < 0) /* goto L_0027 */;
        _result = v0.getName(); // java.io.File.getName -> java.lang.String
        v0 = _result;
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v0.substring(v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        _result = this.getSingleton(); // android.webkit.MimeTypeMap.getSingleton -> android.webkit.MimeTypeMap
        v1 = _result;
        _result = v1.getMimeTypeFromExtension(v0); // android.webkit.MimeTypeMap.getMimeTypeFromExtension -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0027 */;
        return v0;
        v0 = "application/octet-stream";
        // goto L_0026
    }

    public android.net.Uri insert(android.net.Uri p0, android.content.ContentValues p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.net.Uri), v4 = p1 (android.content.ContentValues)
        v0 = new java.lang.UnsupportedOperationException;
        v1 = "No external inserts";
        _result = v0.<init>(v1); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

    public boolean onCreate() {
        // Registers (2 total): v1 = this
        v0 = 1;
        return v0;
    }

    public android.os.ParcelFileDescriptor openFile(android.net.Uri p0, java.lang.String p1) {
        // Registers (5 total): v2 = this, v3 = p0 (android.net.Uri), v4 = p1 (java.lang.String)
        v0 = v2.d; // android.support.v4.content.FileProvider.d:android.support.v4.content.d
        _result = android.support.v4.content.d.a(v0, v3); // -> java.io.File
        v0 = _result;
        _result = v4.a(); // android.support.v4.content.FileProvider.a -> int
        v1 = _result;
        _result = v0.open(v1); // android.os.ParcelFileDescriptor.open -> android.os.ParcelFileDescriptor
        v0 = _result;
        return v0;
    }

    public android.database.Cursor query(android.net.Uri p0, java.lang.String[] p1, java.lang.String p2, java.lang.String[] p3, java.lang.String p4) {
        // Registers (15 total): v9 = this, v10 = p0 (android.net.Uri), v11 = p1 (java.lang.String[]), v12 = p2 (java.lang.String), v13 = p3 (java.lang.String[]), v14 = p4 (java.lang.String)
        v0 = 0;
        v1 = v9.d; // android.support.v4.content.FileProvider.d:android.support.v4.content.d
        _result = android.support.v4.content.d.a(v1, v10); // -> java.io.File
        v3 = _result;
        if (v11 != 0) /* goto L_000b */;
        v11 = android.support.v4.content.FileProvider.a; // :java.lang.String[]
        v1 = v11.length;
        v4 = new java.lang.String[][size=v1];
        v1 = v11.length;
        v5 = new java.lang.Object[][size=v1];
        v6 = v11.length;
        v2 = v0;
        v1 = v0;
        if (v2 >= v6) /* goto L_004e */;
        v0 = v11[v2];
        v7 = "_display_name";
        _result = v7.equals(v0); // java.lang.String.equals -> boolean
        v7 = _result;
        if (v7 == 0) /* goto L_0033 */;
        v0 = "_display_name";
        v4[v1] = v0;
        v0 = binOpLit8_0xd8(v1, 1);
        _result = v3.getName(); // java.io.File.getName -> java.lang.String
        v7 = _result;
        v5[v1] = v7;
        v1 = binOpLit8_0xd8(v2, 1);
        v2 = v1;
        v1 = v0;
        // goto L_0014
        v7 = "_size";
        _result = v7.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0060 */;
        v0 = "_size";
        v4[v1] = v0;
        v0 = binOpLit8_0xd8(v1, 1);
        _result = v3.length(); // java.io.File.length -> long
        v7 = _result;
        _result = v7.valueOf(v8); // java.lang.Long.valueOf -> java.lang.Long
        v7 = _result;
        v5[v1] = v7;
        // goto L_002e
        _result = v4.a(v1); // android.support.v4.content.FileProvider.a -> java.lang.String[]
        v0 = _result;
        _result = v5.a(v1); // android.support.v4.content.FileProvider.a -> java.lang.Object[]
        v1 = _result;
        v2 = new android.database.MatrixCursor;
        v3 = 1;
        _result = v2.<init>(v0, v3); // android.database.MatrixCursor.<init> -> void
        _result = v2.addRow(v1); // android.database.MatrixCursor.addRow -> void
        return v2;
        v0 = v1;
        // goto L_002e
    }

    public int update(android.net.Uri p0, android.content.ContentValues p1, java.lang.String p2, java.lang.String[] p3) {
        // Registers (7 total): v2 = this, v3 = p0 (android.net.Uri), v4 = p1 (android.content.ContentValues), v5 = p2 (java.lang.String), v6 = p3 (java.lang.String[])
        v0 = new java.lang.UnsupportedOperationException;
        v1 = "No external updates";
        _result = v0.<init>(v1); // java.lang.UnsupportedOperationException.<init> -> void
        throw v0;
    }

}