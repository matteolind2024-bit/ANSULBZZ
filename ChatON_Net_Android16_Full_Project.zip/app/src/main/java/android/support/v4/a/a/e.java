package android.support.v4.a.a;

/**
 * Original SourceFile: DrawableCompat.java
 * Descriptor: Landroid/support/v4/a/a/e;
 */
class e extends android.support.v4.a.a.d {
    e() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.a.a.d.<init> -> void
        return;
    }

    public void a(android.graphics.drawable.Drawable p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.graphics.drawable.Drawable), v2 = p1 (boolean)
        _result = v1.a(v2); // android.support.v4.a.a.f.a -> void
        return;
    }

    public boolean a(android.graphics.drawable.Drawable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.graphics.drawable.Drawable)
        _result = v2.a(); // android.support.v4.a.a.f.a -> boolean
        v0 = _result;
        return v0;
    }

}