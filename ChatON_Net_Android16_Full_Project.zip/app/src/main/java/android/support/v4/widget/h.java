package android.support.v4.widget;

/**
 * Original SourceFile: CursorFilter.java
 * Descriptor: Landroid/support/v4/widget/h;
 */
interface h {
    public abstract android.database.Cursor a();
    public abstract android.database.Cursor a(java.lang.CharSequence p0);
    public abstract void a(android.database.Cursor p0);
    public abstract java.lang.CharSequence c(android.database.Cursor p0);
}