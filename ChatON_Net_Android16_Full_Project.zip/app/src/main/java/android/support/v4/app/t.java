package android.support.v4.app;

/**
 * Original SourceFile: FragmentActivity.java
 * Descriptor: Landroid/support/v4/app/t;
 */
class t {
    public static final int[] a;

    static {
        v0 = 3;
        v0 = new int[][size=v0];
        android.support.v4.app.t.a = v0; // :int[]
        return;
    }

}