package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/bb;
 */
class bb implements android.support.v4.app.ax {
    bb() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.app.Notification a(android.support.v4.app.av p0) {
        // Registers (20 total): v18 = this, v19 = p0 (android.support.v4.app.av)
        v1 = new android.support.v4.app.bf;
        v0 = v19;
        v2 = v0.a; // android.support.v4.app.av.a:android.content.Context
        v0 = v19;
        v3 = v0.r; // android.support.v4.app.av.r:android.app.Notification
        v0 = v19;
        v4 = v0.b; // android.support.v4.app.av.b:java.lang.CharSequence
        v0 = v19;
        v5 = v0.c; // android.support.v4.app.av.c:java.lang.CharSequence
        v0 = v19;
        v6 = v0.h; // android.support.v4.app.av.h:java.lang.CharSequence
        v0 = v19;
        v7 = v0.f; // android.support.v4.app.av.f:android.widget.RemoteViews
        v0 = v19;
        v8 = v0.i; // android.support.v4.app.av.i:int
        v0 = v19;
        v9 = v0.d; // android.support.v4.app.av.d:android.app.PendingIntent
        v0 = v19;
        v10 = v0.e; // android.support.v4.app.av.e:android.app.PendingIntent
        v0 = v19;
        v11 = v0.g; // android.support.v4.app.av.g:android.graphics.Bitmap
        v0 = v19;
        v12 = v0.n; // android.support.v4.app.av.n:int
        v0 = v19;
        v13 = v0.o; // android.support.v4.app.av.o:int
        v0 = v19;
        v14 = v0.p; // android.support.v4.app.av.p:boolean
        v0 = v19;
        v15 = v0.k; // android.support.v4.app.av.k:boolean
        v0 = v19;
        v0 = v0.j; // android.support.v4.app.av.j:int
        v16 = v0;
        v0 = v19;
        v0 = v0.m; // android.support.v4.app.av.m:java.lang.CharSequence
        v17 = v0;
        _result = v1.<init>(v1..v17); // android.support.v4.app.bf.<init> -> void
        v0 = v19;
        v2 = v0.q; // android.support.v4.app.av.q:java.util.ArrayList
        _result = v2.iterator(); // java.util.ArrayList.iterator -> java.util.Iterator
        v3 = _result;
        _result = java.util.Iterator.hasNext(v3); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0067 */;
        _result = java.util.Iterator.next(v3); // -> java.lang.Object
        v2 = _result;
        v2 = (android.support.v4.app.as) v2;
        v4 = v2.a; // android.support.v4.app.as.a:int
        v5 = v2.b; // android.support.v4.app.as.b:java.lang.CharSequence
        v2 = v2.c; // android.support.v4.app.as.c:android.app.PendingIntent
        _result = v1.a(v4, v5, v2); // android.support.v4.app.bf.a -> void
        // goto L_0051
        v0 = v19;
        v2 = v0.l; // android.support.v4.app.av.l:android.support.v4.app.bc
        if (v2 == 0) /* goto L_0086 */;
        v0 = v19;
        v2 = v0.l; // android.support.v4.app.av.l:android.support.v4.app.bc
        v2 = (v2 instanceof android.support.v4.app.au);
        if (v2 == 0) /* goto L_008b */;
        v0 = v19;
        v2 = v0.l; // android.support.v4.app.av.l:android.support.v4.app.bc
        v2 = (android.support.v4.app.au) v2;
        v3 = v2.d; // android.support.v4.app.au.d:java.lang.CharSequence
        v4 = v2.f; // android.support.v4.app.au.f:boolean
        v5 = v2.e; // android.support.v4.app.au.e:java.lang.CharSequence
        v2 = v2.a; // android.support.v4.app.au.a:java.lang.CharSequence
        _result = v1.a(v3, v4, v5, v2); // android.support.v4.app.bf.a -> void
        _result = v1.a(); // android.support.v4.app.bf.a -> android.app.Notification
        v1 = _result;
        return v1;
        v0 = v19;
        v2 = v0.l; // android.support.v4.app.av.l:android.support.v4.app.bc
        v2 = (v2 instanceof android.support.v4.app.aw);
        if (v2 == 0) /* goto L_00a5 */;
        v0 = v19;
        v2 = v0.l; // android.support.v4.app.av.l:android.support.v4.app.bc
        v2 = (android.support.v4.app.aw) v2;
        v3 = v2.d; // android.support.v4.app.aw.d:java.lang.CharSequence
        v4 = v2.f; // android.support.v4.app.aw.f:boolean
        v5 = v2.e; // android.support.v4.app.aw.e:java.lang.CharSequence
        v2 = v2.a; // android.support.v4.app.aw.a:java.util.ArrayList
        _result = v1.a(v3, v4, v5, v2); // android.support.v4.app.bf.a -> void
        // goto L_0086
        v0 = v19;
        v2 = v0.l; // android.support.v4.app.av.l:android.support.v4.app.bc
        v2 = (v2 instanceof android.support.v4.app.at);
        if (v2 == 0) /* goto L_0086 */;
        v0 = v19;
        v2 = v0.l; // android.support.v4.app.av.l:android.support.v4.app.bc
        v7 = v2;
        v7 = (android.support.v4.app.at) v7;
        v2 = v7.d; // android.support.v4.app.at.d:java.lang.CharSequence
        v3 = v7.f; // android.support.v4.app.at.f:boolean
        v4 = v7.e; // android.support.v4.app.at.e:java.lang.CharSequence
        v5 = v7.a; // android.support.v4.app.at.a:android.graphics.Bitmap
        v6 = v7.b; // android.support.v4.app.at.b:android.graphics.Bitmap
        v7 = v7.c; // android.support.v4.app.at.c:boolean
        _result = v1.a(v1..v7); // android.support.v4.app.bf.a -> void
        // goto L_0086
    }

}