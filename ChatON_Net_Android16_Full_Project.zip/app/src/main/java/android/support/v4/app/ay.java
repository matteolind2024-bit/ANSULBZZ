package android.support.v4.app;

/**
 * Original SourceFile: NotificationCompat.java
 * Descriptor: Landroid/support/v4/app/ay;
 */
class ay implements android.support.v4.app.ax {
    ay() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.app.Notification a(android.support.v4.app.av p0) {
        // Registers (7 total): v5 = this, v6 = p0 (android.support.v4.app.av)
        v0 = v6.r; // android.support.v4.app.av.r:android.app.Notification
        v1 = v6.a; // android.support.v4.app.av.a:android.content.Context
        v2 = v6.b; // android.support.v4.app.av.b:java.lang.CharSequence
        v3 = v6.c; // android.support.v4.app.av.c:java.lang.CharSequence
        v4 = v6.d; // android.support.v4.app.av.d:android.app.PendingIntent
        _result = v0.setLatestEventInfo(v1, v2, v3, v4); // android.app.Notification.setLatestEventInfo -> void
        v1 = v6.j; // android.support.v4.app.av.j:int
        if (v1 <= 0) /* goto L_0017 */;
        v1 = v0.flags; // android.app.Notification.flags:int
        v1 = binOpLit16_0xd6(v1, 128);
        v0.flags = v1; // android.app.Notification.flags:int
        return v0;
    }

}