package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityNodeInfoCompat.java
 * Descriptor: Landroid/support/v4/view/a/d;
 */
class d extends android.support.v4.view.a.b {
    d() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.a.b.<init> -> void
        return;
    }

    public void b(java.lang.Object p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (int)
        _result = v1.a(v2); // android.support.v4.view.a.i.a -> void
        return;
    }

    public void h(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.a(v2); // android.support.v4.view.a.i.a -> void
        return;
    }

    public void i(java.lang.Object p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (boolean)
        _result = v1.b(v2); // android.support.v4.view.a.i.b -> void
        return;
    }

    public int r(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.b(); // android.support.v4.view.a.i.b -> int
        v0 = _result;
        return v0;
    }

    public boolean s(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.a(); // android.support.v4.view.a.i.a -> boolean
        v0 = _result;
        return v0;
    }

    public boolean t(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v2.c(); // android.support.v4.view.a.i.c -> boolean
        v0 = _result;
        return v0;
    }

}