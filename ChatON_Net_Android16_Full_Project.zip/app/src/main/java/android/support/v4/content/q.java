package android.support.v4.content;

/**
 * Original SourceFile: ModernAsyncTask.java
 * Descriptor: Landroid/support/v4/content/q;
 */
class q {
    static final int[] a;

    static {
        _result = this.values(); // android.support.v4.content.t.values -> android.support.v4.content.t[]
        v0 = _result;
        v0 = v0.length;
        v0 = new int[][size=v0];
        android.support.v4.content.q.a = v0; // :int[]
        v0 = android.support.v4.content.q.a; // :int[]
        v1 = android.support.v4.content.t.b; // :android.support.v4.content.t
        _result = v1.ordinal(); // android.support.v4.content.t.ordinal -> int
        v1 = _result;
        v2 = 1;
        v0[v1] = v2;
        v0 = android.support.v4.content.q.a; // :int[]
        v1 = android.support.v4.content.t.c; // :android.support.v4.content.t
        _result = v1.ordinal(); // android.support.v4.content.t.ordinal -> int
        v1 = _result;
        v2 = 2;
        v0[v1] = v2;
        return;
        v0 = _exception;
        // goto L_001f
        v0 = _exception;
        // goto L_0014
    }

}