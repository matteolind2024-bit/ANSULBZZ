package android.support.v4.c;

/**
 * Original SourceFile: SparseArrayCompat.java
 * Descriptor: Landroid/support/v4/c/n;
 */
public class n implements java.lang.Cloneable {
    private static final java.lang.Object a;
    private boolean b;
    private int[] c;
    private java.lang.Object[] d;
    private int e;

    static {
        v0 = new java.lang.Object;
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        android.support.v4.c.n.a = v0; // :java.lang.Object
        return;
    }

    public n() {
        // Registers (2 total): v1 = this
        v0 = 10;
        _result = v1.<init>(v0); // android.support.v4.c.n.<init> -> void
        return;
    }

    public n(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v2 = 0;
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v3.b = v2; // android.support.v4.c.n.b:boolean
        if (v4 != 0) /* goto L_0013 */;
        v0 = android.support.v4.c.c.a; // :int[]
        v3.c = v0; // android.support.v4.c.n.c:int[]
        v0 = android.support.v4.c.c.c; // :java.lang.Object[]
        v3.d = v0; // android.support.v4.c.n.d:java.lang.Object[]
        v3.e = v2; // android.support.v4.c.n.e:int
        return;
        _result = v4.a(); // android.support.v4.c.c.a -> int
        v0 = _result;
        v1 = new int[][size=v0];
        v3.c = v1; // android.support.v4.c.n.c:int[]
        v0 = new java.lang.Object[][size=v0];
        v3.d = v0; // android.support.v4.c.n.d:java.lang.Object[]
        // goto L_0010
    }

    private void d() {
        // Registers (9 total): v8 = this
        v2 = 0;
        v3 = v8.e; // android.support.v4.c.n.e:int
        v4 = v8.c; // android.support.v4.c.n.c:int[]
        v5 = v8.d; // android.support.v4.c.n.d:java.lang.Object[]
        v1 = v2;
        v0 = v2;
        if (v1 >= v3) /* goto L_0021 */;
        v6 = v5[v1];
        v7 = android.support.v4.c.n.a; // :java.lang.Object
        if (v6 == v7) /* goto L_001e */;
        if (v1 == v0) /* goto L_001c */;
        v7 = v4[v1];
        v4[v0] = v7;
        v5[v0] = v6;
        v6 = 0;
        v5[v1] = v6;
        v0 = binOpLit8_0xd8(v0, 1);
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0009
        v8.b = v2; // android.support.v4.c.n.b:boolean
        v8.e = v0; // android.support.v4.c.n.e:int
        return;
    }

    public android.support.v4.c.n a() {
        // Registers (3 total): v2 = this
        v1 = 0;
        _result = v2.clone(); // java.lang.Object.clone -> java.lang.Object
        v0 = _result;
        v0 = (android.support.v4.c.n) v0;
        v1 = v2.c; // android.support.v4.c.n.c:int[]
        _result = v1.clone(); // int[].clone -> java.lang.Object
        v1 = _result;
        v1 = (int[]) v1;
        v0.c = v1; // android.support.v4.c.n.c:int[]
        v1 = v2.d; // android.support.v4.c.n.d:java.lang.Object[]
        _result = v1.clone(); // java.lang.Object[].clone -> java.lang.Object
        v1 = _result;
        v1 = (java.lang.Object[]) v1;
        v0.d = v1; // android.support.v4.c.n.d:java.lang.Object[]
        return v0;
        v0 = _exception;
        v0 = v1;
        // goto L_001b
        v1 = _exception;
        // goto L_001b
    }

    public java.lang.Object a(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        _result = v1.a(v2, v0); // android.support.v4.c.n.a -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.Object a(int p0, java.lang.Object p1) {
        // Registers (6 total): v3 = this, v4 = p0 (int), v5 = p1 (java.lang.Object)
        v0 = v3.c; // android.support.v4.c.n.c:int[]
        v1 = v3.e; // android.support.v4.c.n.e:int
        _result = v0.a(v1, v4); // android.support.v4.c.c.a -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0012 */;
        v1 = v3.d; // android.support.v4.c.n.d:java.lang.Object[]
        v1 = v1[v0];
        v2 = android.support.v4.c.n.a; // :java.lang.Object
        if (v1 != v2) /* goto L_0013 */;
        return v5;
        v1 = v3.d; // android.support.v4.c.n.d:java.lang.Object[]
        v5 = v1[v0];
        // goto L_0012
    }

    public int b() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // android.support.v4.c.n.b:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v1.d(); // android.support.v4.c.n.d -> void
        v0 = v1.e; // android.support.v4.c.n.e:int
        return v0;
    }

    public void b(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = v3.c; // android.support.v4.c.n.c:int[]
        v1 = v3.e; // android.support.v4.c.n.e:int
        _result = v0.a(v1, v4); // android.support.v4.c.c.a -> int
        v0 = _result;
        if (v0 < 0) /* goto L_001b */;
        v1 = v3.d; // android.support.v4.c.n.d:java.lang.Object[]
        v1 = v1[v0];
        v2 = android.support.v4.c.n.a; // :java.lang.Object
        if (v1 == v2) /* goto L_001b */;
        v1 = v3.d; // android.support.v4.c.n.d:java.lang.Object[]
        v2 = android.support.v4.c.n.a; // :java.lang.Object
        v1[v0] = v2;
        v0 = 1;
        v3.b = v0; // android.support.v4.c.n.b:boolean
        return;
    }

    public void b(int p0, java.lang.Object p1) {
        // Registers (9 total): v6 = this, v7 = p0 (int), v8 = p1 (java.lang.Object)
        v5 = 0;
        v0 = v6.c; // android.support.v4.c.n.c:int[]
        v1 = v6.e; // android.support.v4.c.n.e:int
        _result = v0.a(v1, v7); // android.support.v4.c.c.a -> int
        v0 = _result;
        if (v0 < 0) /* goto L_0010 */;
        v1 = v6.d; // android.support.v4.c.n.d:java.lang.Object[]
        v1[v0] = v8;
        return;
        v0 = binOpLit8_0xdf(v0, -1);
        v1 = v6.e; // android.support.v4.c.n.e:int
        if (v0 >= v1) /* goto L_0027 */;
        v1 = v6.d; // android.support.v4.c.n.d:java.lang.Object[]
        v1 = v1[v0];
        v2 = android.support.v4.c.n.a; // :java.lang.Object
        if (v1 != v2) /* goto L_0027 */;
        v1 = v6.c; // android.support.v4.c.n.c:int[]
        v1[v0] = v7;
        v1 = v6.d; // android.support.v4.c.n.d:java.lang.Object[]
        v1[v0] = v8;
        // goto L_000f
        v1 = v6.b; // android.support.v4.c.n.b:boolean
        if (v1 == 0) /* goto L_003f */;
        v1 = v6.e; // android.support.v4.c.n.e:int
        v2 = v6.c; // android.support.v4.c.n.c:int[]
        v2 = v2.length;
        if (v1 < v2) /* goto L_003f */;
        _result = v6.d(); // android.support.v4.c.n.d -> void
        v0 = v6.c; // android.support.v4.c.n.c:int[]
        v1 = v6.e; // android.support.v4.c.n.e:int
        _result = v0.a(v1, v7); // android.support.v4.c.c.a -> int
        v0 = _result;
        v0 = binOpLit8_0xdf(v0, -1);
        v1 = v6.e; // android.support.v4.c.n.e:int
        v2 = v6.c; // android.support.v4.c.n.c:int[]
        v2 = v2.length;
        if (v1 < v2) /* goto L_0066 */;
        v1 = v6.e; // android.support.v4.c.n.e:int
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v1.a(); // android.support.v4.c.c.a -> int
        v1 = _result;
        v2 = new int[][size=v1];
        v1 = new java.lang.Object[][size=v1];
        v3 = v6.c; // android.support.v4.c.n.c:int[]
        v4 = v6.c; // android.support.v4.c.n.c:int[]
        v4 = v4.length;
        _result = v3.arraycopy(v5, v2, v5, v4); // java.lang.System.arraycopy -> void
        v3 = v6.d; // android.support.v4.c.n.d:java.lang.Object[]
        v4 = v6.d; // android.support.v4.c.n.d:java.lang.Object[]
        v4 = v4.length;
        _result = v3.arraycopy(v5, v1, v5, v4); // java.lang.System.arraycopy -> void
        v6.c = v2; // android.support.v4.c.n.c:int[]
        v6.d = v1; // android.support.v4.c.n.d:java.lang.Object[]
        v1 = v6.e; // android.support.v4.c.n.e:int
        v1 = binOp2addr_0xb1(v1, v0);
        if (v1 == 0) /* goto L_0083 */;
        v1 = v6.c; // android.support.v4.c.n.c:int[]
        v2 = v6.c; // android.support.v4.c.n.c:int[]
        v3 = binOpLit8_0xd8(v0, 1);
        v4 = v6.e; // android.support.v4.c.n.e:int
        v4 = binOp2addr_0xb1(v4, v0);
        _result = v1.arraycopy(v0, v2, v3, v4); // java.lang.System.arraycopy -> void
        v1 = v6.d; // android.support.v4.c.n.d:java.lang.Object[]
        v2 = v6.d; // android.support.v4.c.n.d:java.lang.Object[]
        v3 = binOpLit8_0xd8(v0, 1);
        v4 = v6.e; // android.support.v4.c.n.e:int
        v4 = binOp2addr_0xb1(v4, v0);
        _result = v1.arraycopy(v0, v2, v3, v4); // java.lang.System.arraycopy -> void
        v1 = v6.c; // android.support.v4.c.n.c:int[]
        v1[v0] = v7;
        v1 = v6.d; // android.support.v4.c.n.d:java.lang.Object[]
        v1[v0] = v8;
        v0 = v6.e; // android.support.v4.c.n.e:int
        v0 = binOpLit8_0xd8(v0, 1);
        v6.e = v0; // android.support.v4.c.n.e:int
        // goto L_000f
    }

    public void c() {
        // Registers (6 total): v5 = this
        v1 = 0;
        v2 = v5.e; // android.support.v4.c.n.e:int
        v3 = v5.d; // android.support.v4.c.n.d:java.lang.Object[]
        v0 = v1;
        if (v0 >= v2) /* goto L_000e */;
        v4 = 0;
        v3[v0] = v4;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0006
        v5.e = v1; // android.support.v4.c.n.e:int
        v5.b = v1; // android.support.v4.c.n.b:boolean
        return;
    }

    public void c(int p0) {
        // Registers (2 total): v0 = this, v1 = p0 (int)
        _result = v0.b(v1); // android.support.v4.c.n.b -> void
        return;
    }

    public java.lang.Object clone() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // android.support.v4.c.n.a -> android.support.v4.c.n
        v0 = _result;
        return v0;
    }

    public void d(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.d; // android.support.v4.c.n.d:java.lang.Object[]
        v0 = v0[v3];
        v1 = android.support.v4.c.n.a; // :java.lang.Object
        if (v0 == v1) /* goto L_0011 */;
        v0 = v2.d; // android.support.v4.c.n.d:java.lang.Object[]
        v1 = android.support.v4.c.n.a; // :java.lang.Object
        v0[v3] = v1;
        v0 = 1;
        v2.b = v0; // android.support.v4.c.n.b:boolean
        return;
    }

    public int e(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.b; // android.support.v4.c.n.b:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v1.d(); // android.support.v4.c.n.d -> void
        v0 = v1.c; // android.support.v4.c.n.c:int[]
        v0 = v0[v2];
        return v0;
    }

    public java.lang.Object f(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.b; // android.support.v4.c.n.b:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v1.d(); // android.support.v4.c.n.d -> void
        v0 = v1.d; // android.support.v4.c.n.d:java.lang.Object[]
        v0 = v0[v2];
        return v0;
    }

    public int g(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        v0 = v2.b; // android.support.v4.c.n.b:boolean
        if (v0 == 0) /* goto L_0007 */;
        _result = v2.d(); // android.support.v4.c.n.d -> void
        v0 = v2.c; // android.support.v4.c.n.c:int[]
        v1 = v2.e; // android.support.v4.c.n.e:int
        _result = v0.a(v1, v3); // android.support.v4.c.c.a -> int
        v0 = _result;
        return v0;
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        _result = v3.b(); // android.support.v4.c.n.b -> int
        v0 = _result;
        if (v0 > 0) /* goto L_000a */;
        v0 = "{}";
        return v0;
        v1 = new java.lang.StringBuilder;
        v0 = v3.e; // android.support.v4.c.n.e:int
        v0 = binOpLit8_0xda(v0, 28);
        _result = v1.<init>(v0); // java.lang.StringBuilder.<init> -> void
        v0 = 123;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = 0;
        v2 = v3.e; // android.support.v4.c.n.e:int
        if (v0 >= v2) /* goto L_0044 */;
        if (v0 <= 0) /* goto L_0025 */;
        v2 = ", ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v3.e(v0); // android.support.v4.c.n.e -> int
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = 61;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v3.f(v0); // android.support.v4.c.n.f -> java.lang.Object
        v2 = _result;
        if (v2 == v3) /* goto L_003d */;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0019
        v2 = "(this Map)";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_003a
        v0 = 125;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0009
    }

}