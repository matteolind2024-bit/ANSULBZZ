package android.support.v4.view.a;

/**
 * Original SourceFile: AccessibilityRecordCompat.java
 * Descriptor: Landroid/support/v4/view/a/ab;
 */
class ab extends android.support.v4.view.a.z {
    ab() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.a.z.<init> -> void
        return;
    }

}