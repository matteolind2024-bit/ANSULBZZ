package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompat.java
 * Descriptor: Landroid/support/v4/view/bt;
 */
class bt implements android.support.v4.view.br {
    bt() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void a(android.view.ViewGroup p0, boolean p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.ViewGroup), v2 = p1 (boolean)
        return;
    }

}