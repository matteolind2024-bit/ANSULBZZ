package android.support.v4.view;

/**
 * Original SourceFile: ViewGroupCompat.java
 * Descriptor: Landroid/support/v4/view/bq;
 */
class bq extends android.support.v4.view.bp {
    bq() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.view.bp.<init> -> void
        return;
    }

}