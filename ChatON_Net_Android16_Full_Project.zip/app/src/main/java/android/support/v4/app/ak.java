package android.support.v4.app;

/**
 * Original SourceFile: ListFragment.java
 * Descriptor: Landroid/support/v4/app/ak;
 */
class ak implements java.lang.Runnable {
    final android.support.v4.app.ListFragment a;

    ak(android.support.v4.app.ListFragment p0) {
        // Registers (2 total): v0 = this, v1 = p0 (android.support.v4.app.ListFragment)
        v0.a = v1; // android.support.v4.app.ak.a:android.support.v4.app.ListFragment
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public void run() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // android.support.v4.app.ak.a:android.support.v4.app.ListFragment
        v0 = v0.b; // android.support.v4.app.ListFragment.b:android.widget.ListView
        v1 = v2.a; // android.support.v4.app.ak.a:android.support.v4.app.ListFragment
        v1 = v1.b; // android.support.v4.app.ListFragment.b:android.widget.ListView
        _result = v0.focusableViewAvailable(v1); // android.widget.ListView.focusableViewAvailable -> void
        return;
    }

}