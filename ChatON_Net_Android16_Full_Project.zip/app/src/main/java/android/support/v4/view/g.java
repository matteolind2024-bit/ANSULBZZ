package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompat.java
 * Descriptor: Landroid/support/v4/view/g;
 */
class g implements android.support.v4.view.d {
    g() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public android.support.v4.view.a.k a(java.lang.Object p0, android.view.View p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.view.View)
        v0 = 0;
        return v0;
    }

    public java.lang.Object a() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public java.lang.Object a(android.support.v4.view.a p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.support.v4.view.a)
        v0 = 0;
        return v0;
    }

    public void a(java.lang.Object p0, android.view.View p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (int)
        return;
    }

    public void a(java.lang.Object p0, android.view.View p1, android.support.v4.view.a.a p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.support.v4.view.a.a)
        return;
    }

    public boolean a(java.lang.Object p0, android.view.View p1, int p2, android.os.Bundle p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.view.View), v4 = p2 (int), v5 = p3 (android.os.Bundle)
        v0 = 0;
        return v0;
    }

    public boolean a(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.view.View), v4 = p2 (android.view.accessibility.AccessibilityEvent)
        v0 = 0;
        return v0;
    }

    public boolean a(java.lang.Object p0, android.view.ViewGroup p1, android.view.View p2, android.view.accessibility.AccessibilityEvent p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.Object), v3 = p1 (android.view.ViewGroup), v4 = p2 (android.view.View), v5 = p3 (android.view.accessibility.AccessibilityEvent)
        v0 = 1;
        return v0;
    }

    public void b(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        return;
    }

    public void c(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        return;
    }

    public void d(java.lang.Object p0, android.view.View p1, android.view.accessibility.AccessibilityEvent p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (android.view.accessibility.AccessibilityEvent)
        return;
    }

}