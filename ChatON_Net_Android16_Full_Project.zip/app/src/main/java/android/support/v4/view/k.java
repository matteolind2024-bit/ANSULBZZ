package android.support.v4.view;

/**
 * Original SourceFile: AccessibilityDelegateCompatJellyBean.java
 * Descriptor: Landroid/support/v4/view/k;
 */
class k {
    public static java.lang.Object a(android.support.v4.view.m p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.view.m)
        v0 = new android.support.v4.view.l;
        _result = v0.<init>(v1); // android.support.v4.view.l.<init> -> void
        return v0;
    }

    public static java.lang.Object a(java.lang.Object p0, android.view.View p1) {
        // Registers (3 total): v1 = p0 (java.lang.Object), v2 = p1 (android.view.View)
        v1 = (android.view.View$AccessibilityDelegate) v1;
        _result = v1.getAccessibilityNodeProvider(v2); // android.view.View$AccessibilityDelegate.getAccessibilityNodeProvider -> android.view.accessibility.AccessibilityNodeProvider
        v0 = _result;
        return v0;
    }

    public static boolean a(java.lang.Object p0, android.view.View p1, int p2, android.os.Bundle p3) {
        // Registers (5 total): v1 = p0 (java.lang.Object), v2 = p1 (android.view.View), v3 = p2 (int), v4 = p3 (android.os.Bundle)
        v1 = (android.view.View$AccessibilityDelegate) v1;
        _result = v1.performAccessibilityAction(v2, v3, v4); // android.view.View$AccessibilityDelegate.performAccessibilityAction -> boolean
        v0 = _result;
        return v0;
    }

}