package android.support.v4.view;

/**
 * Original SourceFile: MotionEventCompatEclair.java
 * Descriptor: Landroid/support/v4/view/ad;
 */
class ad {
    public static int a(android.view.MotionEvent p0) {
        // Registers (2 total): v1 = p0 (android.view.MotionEvent)
        _result = v1.getPointerCount(); // android.view.MotionEvent.getPointerCount -> int
        v0 = _result;
        return v0;
    }

    public static int a(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        _result = v1.findPointerIndex(v2); // android.view.MotionEvent.findPointerIndex -> int
        v0 = _result;
        return v0;
    }

    public static int b(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        _result = v1.getPointerId(v2); // android.view.MotionEvent.getPointerId -> int
        v0 = _result;
        return v0;
    }

    public static float c(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        _result = v1.getX(v2); // android.view.MotionEvent.getX -> float
        v0 = _result;
        return v0;
    }

    public static float d(android.view.MotionEvent p0, int p1) {
        // Registers (3 total): v1 = p0 (android.view.MotionEvent), v2 = p1 (int)
        _result = v1.getY(v2); // android.view.MotionEvent.getY -> float
        v0 = _result;
        return v0;
    }

}