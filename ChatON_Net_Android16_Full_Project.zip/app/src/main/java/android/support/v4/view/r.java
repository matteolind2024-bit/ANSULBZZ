package android.support.v4.view;

/**
 * Original SourceFile: GravityCompatJellybeanMr1.java
 * Descriptor: Landroid/support/v4/view/r;
 */
class r {
    public static int a(int p0, int p1) {
        // Registers (3 total): v1 = p0 (int), v2 = p1 (int)
        _result = v1.getAbsoluteGravity(v2); // android.view.Gravity.getAbsoluteGravity -> int
        v0 = _result;
        return v0;
    }

}