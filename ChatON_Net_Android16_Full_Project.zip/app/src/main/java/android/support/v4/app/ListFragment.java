package android.support.v4.app;

/**
 * Original SourceFile: ListFragment.java
 * Descriptor: Landroid/support/v4/app/ListFragment;
 */
public class ListFragment extends android.support.v4.app.Fragment {
     android.widget.ListAdapter a;
     android.widget.ListView b;
     android.view.View c;
     android.widget.TextView d;
     android.view.View e;
     android.view.View f;
     java.lang.CharSequence g;
     boolean h;
    private final android.os.Handler i;
    private final java.lang.Runnable j;
    private final android.widget.AdapterView$OnItemClickListener k;

    public ListFragment() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // android.support.v4.app.Fragment.<init> -> void
        v0 = new android.os.Handler;
        _result = v0.<init>(); // android.os.Handler.<init> -> void
        v1.i = v0; // android.support.v4.app.ListFragment.i:android.os.Handler
        v0 = new android.support.v4.app.ak;
        _result = v0.<init>(v1); // android.support.v4.app.ak.<init> -> void
        v1.j = v0; // android.support.v4.app.ListFragment.j:java.lang.Runnable
        v0 = new android.support.v4.app.al;
        _result = v0.<init>(v1); // android.support.v4.app.al.<init> -> void
        v1.k = v0; // android.support.v4.app.ListFragment.k:android.widget.AdapterView$OnItemClickListener
        return;
    }

    private void a(boolean p0, boolean p1) {
        // Registers (9 total): v6 = this, v7 = p0 (boolean), v8 = p1 (boolean)
        v5 = 17432577; // 0x010a0001
        v4 = 0x010a0000;
        v3 = 8;
        v2 = 0;
        _result = v6.c(); // android.support.v4.app.ListFragment.c -> void
        v0 = v6.e; // android.support.v4.app.ListFragment.e:android.view.View
        if (v0 != 0) /* goto L_0018 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Can't be used with a custom content view";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v6.h; // android.support.v4.app.ListFragment.h:boolean
        if (v0 != v7) /* goto L_001d */;
        return;
        v6.h = v7; // android.support.v4.app.ListFragment.h:boolean
        if (v7 == 0) /* goto L_0053 */;
        if (v8 == 0) /* goto L_0048 */;
        v0 = v6.e; // android.support.v4.app.ListFragment.e:android.view.View
        _result = v6.getActivity(); // android.support.v4.app.ListFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v1.loadAnimation(v5); // android.view.animation.AnimationUtils.loadAnimation -> android.view.animation.Animation
        v1 = _result;
        _result = v0.startAnimation(v1); // android.view.View.startAnimation -> void
        v0 = v6.f; // android.support.v4.app.ListFragment.f:android.view.View
        _result = v6.getActivity(); // android.support.v4.app.ListFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v1.loadAnimation(v4); // android.view.animation.AnimationUtils.loadAnimation -> android.view.animation.Animation
        v1 = _result;
        _result = v0.startAnimation(v1); // android.view.View.startAnimation -> void
        v0 = v6.e; // android.support.v4.app.ListFragment.e:android.view.View
        _result = v0.setVisibility(v3); // android.view.View.setVisibility -> void
        v0 = v6.f; // android.support.v4.app.ListFragment.f:android.view.View
        _result = v0.setVisibility(v2); // android.view.View.setVisibility -> void
        // goto L_001c
        v0 = v6.e; // android.support.v4.app.ListFragment.e:android.view.View
        _result = v0.clearAnimation(); // android.view.View.clearAnimation -> void
        v0 = v6.f; // android.support.v4.app.ListFragment.f:android.view.View
        _result = v0.clearAnimation(); // android.view.View.clearAnimation -> void
        // goto L_003d
        if (v8 == 0) /* goto L_007a */;
        v0 = v6.e; // android.support.v4.app.ListFragment.e:android.view.View
        _result = v6.getActivity(); // android.support.v4.app.ListFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v1.loadAnimation(v4); // android.view.animation.AnimationUtils.loadAnimation -> android.view.animation.Animation
        v1 = _result;
        _result = v0.startAnimation(v1); // android.view.View.startAnimation -> void
        v0 = v6.f; // android.support.v4.app.ListFragment.f:android.view.View
        _result = v6.getActivity(); // android.support.v4.app.ListFragment.getActivity -> android.support.v4.app.FragmentActivity
        v1 = _result;
        _result = v1.loadAnimation(v5); // android.view.animation.AnimationUtils.loadAnimation -> android.view.animation.Animation
        v1 = _result;
        _result = v0.startAnimation(v1); // android.view.View.startAnimation -> void
        v0 = v6.e; // android.support.v4.app.ListFragment.e:android.view.View
        _result = v0.setVisibility(v2); // android.view.View.setVisibility -> void
        v0 = v6.f; // android.support.v4.app.ListFragment.f:android.view.View
        _result = v0.setVisibility(v3); // android.view.View.setVisibility -> void
        // goto L_001c
        v0 = v6.e; // android.support.v4.app.ListFragment.e:android.view.View
        _result = v0.clearAnimation(); // android.view.View.clearAnimation -> void
        v0 = v6.f; // android.support.v4.app.ListFragment.f:android.view.View
        _result = v0.clearAnimation(); // android.view.View.clearAnimation -> void
        // goto L_006f
    }

    private void c() {
        // Registers (5 total): v4 = this
        v3 = 0;
        v0 = v4.b; // android.support.v4.app.ListFragment.b:android.widget.ListView
        if (v0 == 0) /* goto L_0006 */;
        return;
        _result = v4.getView(); // android.support.v4.app.ListFragment.getView -> android.view.View
        v0 = _result;
        if (v0 != 0) /* goto L_0015 */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Content view not yet created";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v1 = (v0 instanceof android.widget.ListView);
        if (v1 == 0) /* goto L_003b */;
        v0 = (android.widget.ListView) v0;
        v4.b = v0; // android.support.v4.app.ListFragment.b:android.widget.ListView
        v0 = 1;
        v4.h = v0; // android.support.v4.app.ListFragment.h:boolean
        v0 = v4.b; // android.support.v4.app.ListFragment.b:android.widget.ListView
        v1 = v4.k; // android.support.v4.app.ListFragment.k:android.widget.AdapterView$OnItemClickListener
        _result = v0.setOnItemClickListener(v1); // android.widget.ListView.setOnItemClickListener -> void
        v0 = v4.a; // android.support.v4.app.ListFragment.a:android.widget.ListAdapter
        if (v0 == 0) /* goto L_00b0 */;
        v0 = v4.a; // android.support.v4.app.ListFragment.a:android.widget.ListAdapter
        v1 = 0;
        v4.a = v1; // android.support.v4.app.ListFragment.a:android.widget.ListAdapter
        _result = v4.a(v0); // android.support.v4.app.ListFragment.a -> void
        v0 = v4.i; // android.support.v4.app.ListFragment.i:android.os.Handler
        v1 = v4.j; // android.support.v4.app.ListFragment.j:java.lang.Runnable
        _result = v0.post(v1); // android.os.Handler.post -> boolean
        // goto L_0005
        v1 = 16711681; // 0x00ff0001
        _result = v0.findViewById(v1); // android.view.View.findViewById -> android.view.View
        v1 = _result;
        v1 = (android.widget.TextView) v1;
        v4.d = v1; // android.support.v4.app.ListFragment.d:android.widget.TextView
        v1 = v4.d; // android.support.v4.app.ListFragment.d:android.widget.TextView
        if (v1 != 0) /* goto L_007b */;
        v1 = 16908292; // 0x01020004
        _result = v0.findViewById(v1); // android.view.View.findViewById -> android.view.View
        v1 = _result;
        v4.c = v1; // android.support.v4.app.ListFragment.c:android.view.View
        v1 = 16711682; // 0x00ff0002
        _result = v0.findViewById(v1); // android.view.View.findViewById -> android.view.View
        v1 = _result;
        v4.e = v1; // android.support.v4.app.ListFragment.e:android.view.View
        v1 = 16711683; // 0x00ff0003
        _result = v0.findViewById(v1); // android.view.View.findViewById -> android.view.View
        v1 = _result;
        v4.f = v1; // android.support.v4.app.ListFragment.f:android.view.View
        v1 = 16908298; // 0x0102000a
        _result = v0.findViewById(v1); // android.view.View.findViewById -> android.view.View
        v0 = _result;
        v1 = (v0 instanceof android.widget.ListView);
        if (v1 != 0) /* goto L_008c */;
        if (v0 != 0) /* goto L_0083 */;
        v0 = new java.lang.RuntimeException;
        v1 = "Your content must have a ListView whose id attribute is 'android.R.id.list'";
        _result = v0.<init>(v1); // java.lang.RuntimeException.<init> -> void
        throw v0;
        v1 = v4.d; // android.support.v4.app.ListFragment.d:android.widget.TextView
        v2 = 8;
        _result = v1.setVisibility(v2); // android.widget.TextView.setVisibility -> void
        // goto L_0053
        v0 = new java.lang.RuntimeException;
        v1 = "Content has view with id attribute 'android.R.id.list' that is not a ListView class";
        _result = v0.<init>(v1); // java.lang.RuntimeException.<init> -> void
        throw v0;
        v0 = (android.widget.ListView) v0;
        v4.b = v0; // android.support.v4.app.ListFragment.b:android.widget.ListView
        v0 = v4.c; // android.support.v4.app.ListFragment.c:android.view.View
        if (v0 == 0) /* goto L_009c */;
        v0 = v4.b; // android.support.v4.app.ListFragment.b:android.widget.ListView
        v1 = v4.c; // android.support.v4.app.ListFragment.c:android.view.View
        _result = v0.setEmptyView(v1); // android.widget.ListView.setEmptyView -> void
        // goto L_001d
        v0 = v4.g; // android.support.v4.app.ListFragment.g:java.lang.CharSequence
        if (v0 == 0) /* goto L_001d */;
        v0 = v4.d; // android.support.v4.app.ListFragment.d:android.widget.TextView
        v1 = v4.g; // android.support.v4.app.ListFragment.g:java.lang.CharSequence
        _result = v0.setText(v1); // android.widget.TextView.setText -> void
        v0 = v4.b; // android.support.v4.app.ListFragment.b:android.widget.ListView
        v1 = v4.d; // android.support.v4.app.ListFragment.d:android.widget.TextView
        _result = v0.setEmptyView(v1); // android.widget.ListView.setEmptyView -> void
        // goto L_001d
        v0 = v4.e; // android.support.v4.app.ListFragment.e:android.view.View
        if (v0 == 0) /* goto L_0033 */;
        _result = v4.a(v3, v3); // android.support.v4.app.ListFragment.a -> void
        // goto L_0033
    }

    public android.widget.ListView a() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // android.support.v4.app.ListFragment.c -> void
        v0 = v1.b; // android.support.v4.app.ListFragment.b:android.widget.ListView
        return v0;
    }

    public void a(android.widget.ListAdapter p0) {
        // Registers (6 total): v4 = this, v5 = p0 (android.widget.ListAdapter)
        v2 = 0;
        v1 = 1;
        v0 = v4.a; // android.support.v4.app.ListFragment.a:android.widget.ListAdapter
        if (v0 == 0) /* goto L_0027 */;
        v0 = v1;
        v4.a = v5; // android.support.v4.app.ListFragment.a:android.widget.ListAdapter
        v3 = v4.b; // android.support.v4.app.ListFragment.b:android.widget.ListView
        if (v3 == 0) /* goto L_0026 */;
        v3 = v4.b; // android.support.v4.app.ListFragment.b:android.widget.ListView
        _result = v3.setAdapter(v5); // android.widget.ListView.setAdapter -> void
        v3 = v4.h; // android.support.v4.app.ListFragment.h:boolean
        if (v3 != 0) /* goto L_0026 */;
        if (v0 != 0) /* goto L_0026 */;
        _result = v4.getView(); // android.support.v4.app.ListFragment.getView -> android.view.View
        v0 = _result;
        _result = v0.getWindowToken(); // android.view.View.getWindowToken -> android.os.IBinder
        v0 = _result;
        if (v0 == 0) /* goto L_0023 */;
        v2 = v1;
        _result = v4.a(v1, v2); // android.support.v4.app.ListFragment.a -> void
        return;
        v0 = v2;
        // goto L_0007
    }

    public void a(android.widget.ListView p0, android.view.View p1, int p2, long p3) {
        // Registers (6 total): v0 = this, v1 = p0 (android.widget.ListView), v2 = p1 (android.view.View), v3 = p2 (int), v4 = p3 (long)
        return;
    }

    public android.widget.ListAdapter b() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // android.support.v4.app.ListFragment.a:android.widget.ListAdapter
        return v0;
    }

    public android.view.View onCreateView(android.view.LayoutInflater p0, android.view.ViewGroup p1, android.os.Bundle p2) {
        // Registers (13 total): v9 = this, v10 = p0 (android.view.LayoutInflater), v11 = p1 (android.view.ViewGroup), v12 = p2 (android.os.Bundle)
        v8 = 17;
        v7 = -2;
        v6 = -1;
        _result = v9.getActivity(); // android.support.v4.app.ListFragment.getActivity -> android.support.v4.app.FragmentActivity
        v0 = _result;
        v1 = new android.widget.FrameLayout;
        _result = v1.<init>(v0); // android.widget.FrameLayout.<init> -> void
        v2 = new android.widget.LinearLayout;
        _result = v2.<init>(v0); // android.widget.LinearLayout.<init> -> void
        v3 = 16711682; // 0x00ff0002
        _result = v2.setId(v3); // android.widget.LinearLayout.setId -> void
        v3 = 1;
        _result = v2.setOrientation(v3); // android.widget.LinearLayout.setOrientation -> void
        v3 = 8;
        _result = v2.setVisibility(v3); // android.widget.LinearLayout.setVisibility -> void
        _result = v2.setGravity(v8); // android.widget.LinearLayout.setGravity -> void
        v3 = new android.widget.ProgressBar;
        v4 = 0;
        v5 = 16842874; // 0x0101007a
        _result = v3.<init>(v0, v4, v5); // android.widget.ProgressBar.<init> -> void
        v4 = new android.widget.FrameLayout$LayoutParams;
        _result = v4.<init>(v7, v7); // android.widget.FrameLayout$LayoutParams.<init> -> void
        _result = v2.addView(v3, v4); // android.widget.LinearLayout.addView -> void
        v3 = new android.widget.FrameLayout$LayoutParams;
        _result = v3.<init>(v6, v6); // android.widget.FrameLayout$LayoutParams.<init> -> void
        _result = v1.addView(v2, v3); // android.widget.FrameLayout.addView -> void
        v2 = new android.widget.FrameLayout;
        _result = v2.<init>(v0); // android.widget.FrameLayout.<init> -> void
        v0 = 16711683; // 0x00ff0003
        _result = v2.setId(v0); // android.widget.FrameLayout.setId -> void
        v0 = new android.widget.TextView;
        _result = v9.getActivity(); // android.support.v4.app.ListFragment.getActivity -> android.support.v4.app.FragmentActivity
        v3 = _result;
        _result = v0.<init>(v3); // android.widget.TextView.<init> -> void
        v3 = 16711681; // 0x00ff0001
        _result = v0.setId(v3); // android.widget.TextView.setId -> void
        _result = v0.setGravity(v8); // android.widget.TextView.setGravity -> void
        v3 = new android.widget.FrameLayout$LayoutParams;
        _result = v3.<init>(v6, v6); // android.widget.FrameLayout$LayoutParams.<init> -> void
        _result = v2.addView(v0, v3); // android.widget.FrameLayout.addView -> void
        v0 = new android.widget.ListView;
        _result = v9.getActivity(); // android.support.v4.app.ListFragment.getActivity -> android.support.v4.app.FragmentActivity
        v3 = _result;
        _result = v0.<init>(v3); // android.widget.ListView.<init> -> void
        v3 = 16908298; // 0x0102000a
        _result = v0.setId(v3); // android.widget.ListView.setId -> void
        v3 = 0;
        _result = v0.setDrawSelectorOnTop(v3); // android.widget.ListView.setDrawSelectorOnTop -> void
        v3 = new android.widget.FrameLayout$LayoutParams;
        _result = v3.<init>(v6, v6); // android.widget.FrameLayout$LayoutParams.<init> -> void
        _result = v2.addView(v0, v3); // android.widget.FrameLayout.addView -> void
        v0 = new android.widget.FrameLayout$LayoutParams;
        _result = v0.<init>(v6, v6); // android.widget.FrameLayout$LayoutParams.<init> -> void
        _result = v1.addView(v2, v0); // android.widget.FrameLayout.addView -> void
        v0 = new android.widget.FrameLayout$LayoutParams;
        _result = v0.<init>(v6, v6); // android.widget.FrameLayout$LayoutParams.<init> -> void
        _result = v1.setLayoutParams(v0); // android.widget.FrameLayout.setLayoutParams -> void
        return v1;
    }

    public void onDestroyView() {
        // Registers (4 total): v3 = this
        v2 = 0;
        v0 = v3.i; // android.support.v4.app.ListFragment.i:android.os.Handler
        v1 = v3.j; // android.support.v4.app.ListFragment.j:java.lang.Runnable
        _result = v0.removeCallbacks(v1); // android.os.Handler.removeCallbacks -> void
        v3.b = v2; // android.support.v4.app.ListFragment.b:android.widget.ListView
        v0 = 0;
        v3.h = v0; // android.support.v4.app.ListFragment.h:boolean
        v3.f = v2; // android.support.v4.app.ListFragment.f:android.view.View
        v3.e = v2; // android.support.v4.app.ListFragment.e:android.view.View
        v3.c = v2; // android.support.v4.app.ListFragment.c:android.view.View
        v3.d = v2; // android.support.v4.app.ListFragment.d:android.widget.TextView
        _result = v3.onDestroyView(); // android.support.v4.app.Fragment.onDestroyView -> void
        return;
    }

    public void onViewCreated(android.view.View p0, android.os.Bundle p1) {
        // Registers (3 total): v0 = this, v1 = p0 (android.view.View), v2 = p1 (android.os.Bundle)
        _result = v0.onViewCreated(v1, v2); // android.support.v4.app.Fragment.onViewCreated -> void
        _result = v0.c(); // android.support.v4.app.ListFragment.c -> void
        return;
    }

}