package android.support.v4.app;

/**
 * Original SourceFile: ActionBarDrawerToggle.java
 * Descriptor: Landroid/support/v4/app/h;
 */
class h extends android.graphics.drawable.LevelListDrawable implements android.graphics.drawable.Drawable$Callback {
    final android.support.v4.app.a a;
    private final boolean b;
    private final android.graphics.Rect c;
    private float d;
    private float e;

    private h(android.support.v4.app.a p0, android.graphics.drawable.Drawable p1) {
        // Registers (7 total): v4 = this, v5 = p0 (android.support.v4.app.a), v6 = p1 (android.graphics.drawable.Drawable)
        v1 = 1;
        v2 = 0;
        v4.a = v5; // android.support.v4.app.h.a:android.support.v4.app.a
        _result = v4.<init>(); // android.graphics.drawable.LevelListDrawable.<init> -> void
        v0 = android.os.Build$VERSION.SDK_INT; // :int
        v3 = 18;
        if (v0 <= v3) /* goto L_0024 */;
        v0 = v1;
        v4.b = v0; // android.support.v4.app.h.b:boolean
        v0 = new android.graphics.Rect;
        _result = v0.<init>(); // android.graphics.Rect.<init> -> void
        v4.c = v0; // android.support.v4.app.h.c:android.graphics.Rect
        _result = v6.a(); // android.support.v4.a.a.a.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0020 */;
        _result = v4.a(v1); // android.support.v4.a.a.a.a -> void
        _result = v4.addLevel(v2, v2, v6); // android.support.v4.app.h.addLevel -> void
        return;
        v0 = v2;
        // goto L_000e
    }

    h(android.support.v4.app.a p0, android.graphics.drawable.Drawable p1, android.support.v4.app.b p2) {
        // Registers (4 total): v0 = this, v1 = p0 (android.support.v4.app.a), v2 = p1 (android.graphics.drawable.Drawable), v3 = p2 (android.support.v4.app.b)
        _result = v0.<init>(v1, v2); // android.support.v4.app.h.<init> -> void
        return;
    }

    public float a() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // android.support.v4.app.h.d:float
        return v0;
    }

    public void a(float p0) {
        // Registers (2 total): v0 = this, v1 = p0 (float)
        v0.d = v1; // android.support.v4.app.h.d:float
        _result = v0.invalidateSelf(); // android.support.v4.app.h.invalidateSelf -> void
        return;
    }

    public void b(float p0) {
        // Registers (2 total): v0 = this, v1 = p0 (float)
        v0.e = v1; // android.support.v4.app.h.e:float
        _result = v0.invalidateSelf(); // android.support.v4.app.h.invalidateSelf -> void
        return;
    }

    public void draw(android.graphics.Canvas p0) {
        // Registers (8 total): v6 = this, v7 = p0 (android.graphics.Canvas)
        v5 = 0;
        v0 = 1;
        v1 = v6.c; // android.support.v4.app.h.c:android.graphics.Rect
        _result = v6.copyBounds(v1); // android.support.v4.app.h.copyBounds -> void
        _result = v7.save(); // android.graphics.Canvas.save -> int
        v1 = v6.a; // android.support.v4.app.h.a:android.support.v4.app.a
        _result = v1.a(); // android.support.v4.app.a.a -> android.app.Activity
        v1 = _result;
        _result = v1.getWindow(); // android.app.Activity.getWindow -> android.view.Window
        v1 = _result;
        _result = v1.getDecorView(); // android.view.Window.getDecorView -> android.view.View
        v1 = _result;
        _result = v1.e(); // android.support.v4.view.at.e -> int
        v1 = _result;
        if (v1 != v0) /* goto L_004d */;
        v1 = v0;
        if (v1 == 0) /* goto L_0022 */;
        v0 = -1;
        v2 = v6.c; // android.support.v4.app.h.c:android.graphics.Rect
        _result = v2.width(); // android.graphics.Rect.width -> int
        v2 = _result;
        v3 = v6.e; // android.support.v4.app.h.e:float
        v3 = unaryOp_0x7f(v3);
        v4 = unaryOp_0x82(v2);
        v3 = binOp2addr_0xc8(v3, v4);
        v4 = v6.d; // android.support.v4.app.h.d:float
        v3 = binOp2addr_0xc8(v3, v4);
        v0 = unaryOp_0x82(v0);
        v0 = binOp2addr_0xc8(v0, v3);
        _result = v7.translate(v0, v5); // android.graphics.Canvas.translate -> void
        if (v1 == 0) /* goto L_0046 */;
        v0 = v6.b; // android.support.v4.app.h.b:boolean
        if (v0 != 0) /* goto L_0046 */;
        v0 = unaryOp_0x82(v2);
        _result = v7.translate(v0, v5); // android.graphics.Canvas.translate -> void
        v0 = 0xbf800000;
        v1 = 0x3f800000;
        _result = v7.scale(v0, v1); // android.graphics.Canvas.scale -> void
        _result = v6.draw(v7); // android.graphics.drawable.LevelListDrawable.draw -> void
        _result = v7.restore(); // android.graphics.Canvas.restore -> void
        return;
        v1 = 0;
        // goto L_001f
    }

}