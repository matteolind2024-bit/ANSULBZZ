package android.support.v4.app;

/**
 * Original SourceFile: FragmentTabHost.java
 * Descriptor: Landroid/support/v4/app/ai;
 */
final class ai {
    private final java.lang.String a;
    private final java.lang.Class b;
    private final android.os.Bundle c;
    private android.support.v4.app.Fragment d;

    static android.support.v4.app.Fragment a(android.support.v4.app.ai p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.app.ai)
        v0 = v1.d; // android.support.v4.app.ai.d:android.support.v4.app.Fragment
        return v0;
    }

    static android.support.v4.app.Fragment a(android.support.v4.app.ai p0, android.support.v4.app.Fragment p1) {
        // Registers (2 total): v0 = p0 (android.support.v4.app.ai), v1 = p1 (android.support.v4.app.Fragment)
        v0.d = v1; // android.support.v4.app.ai.d:android.support.v4.app.Fragment
        return v1;
    }

    static java.lang.String b(android.support.v4.app.ai p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.app.ai)
        v0 = v1.a; // android.support.v4.app.ai.a:java.lang.String
        return v0;
    }

    static java.lang.Class c(android.support.v4.app.ai p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.app.ai)
        v0 = v1.b; // android.support.v4.app.ai.b:java.lang.Class
        return v0;
    }

    static android.os.Bundle d(android.support.v4.app.ai p0) {
        // Registers (2 total): v1 = p0 (android.support.v4.app.ai)
        v0 = v1.c; // android.support.v4.app.ai.c:android.os.Bundle
        return v0;
    }

}