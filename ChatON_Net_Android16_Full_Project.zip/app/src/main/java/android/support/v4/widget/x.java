package android.support.v4.widget;

/**
 * Original SourceFile: ScrollerCompat.java
 * Descriptor: Landroid/support/v4/widget/x;
 */
class x extends android.support.v4.widget.w {
    x() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // android.support.v4.widget.w.<init> -> void
        return;
    }

}