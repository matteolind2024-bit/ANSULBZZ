package android.sec.multiwindow;

/**
 * Original SourceFile: Constants.java
 * Descriptor: Landroid/sec/multiwindow/Constants$WindowManagerPolicy;
 */
public class Constants$WindowManagerPolicy {
    static java.lang.String[] FIELD_NAMES;
    public static int WINDOW_INFO_NOTHING_CHANGED;
    public static int WINDOW_INFO_SIZE_CHANGED;
    public static int WINDOW_MODE_FREESTYLE;
    public static int WINDOW_MODE_MASK;
    public static int WINDOW_MODE_NORMAL;
    public static int WINDOW_MODE_OPTION_COMMON_FIXED_RATIO;
    public static int WINDOW_MODE_OPTION_COMMON_FIXED_SIZE;
    public static int WINDOW_MODE_OPTION_COMMON_HIDDEN;
    public static int WINDOW_MODE_OPTION_COMMON_INHERIT;
    public static int WINDOW_MODE_OPTION_COMMON_MINIMIZED;
    public static int WINDOW_MODE_OPTION_COMMON_NO_CONTROLBAR;
    public static int WINDOW_MODE_OPTION_COMMON_NO_DECORATION;
    public static int WINDOW_MODE_OPTION_COMMON_PINUP;
    public static int WINDOW_MODE_OPTION_COMMON_RESIZE;
    public static int WINDOW_MODE_OPTION_SPLIT_ZONE_A;
    public static int WINDOW_MODE_OPTION_SPLIT_ZONE_B;
    public static int WINDOW_MODE_OPTION_SPLIT_ZONE_C;
    public static int WINDOW_MODE_OPTION_SPLIT_ZONE_D;
    public static int WINDOW_MODE_OPTION_SPLIT_ZONE_E;
    public static int WINDOW_MODE_OPTION_SPLIT_ZONE_F;
    public static int WINDOW_MODE_OPTION_SPLIT_ZONE_FULL;
    public static int WINDOW_MODE_OPTION_SPLIT_ZONE_MASK;
    public static int WINDOW_MODE_OPTION_SPLIT_ZONE_UNKNOWN;

    static {
        v0 = 0;
        v1 = 23;
        v1 = new java.lang.String[][size=v1];
        v2 = "WINDOW_MODE_MASK";
        v1[v0] = v2;
        v2 = 1;
        v3 = "WINDOW_MODE_NORMAL";
        v1[v2] = v3;
        v2 = 2;
        v3 = "WINDOW_MODE_FREESTYLE";
        v1[v2] = v3;
        v2 = 3;
        v3 = "WINDOW_MODE_OPTION_COMMON_PINUP";
        v1[v2] = v3;
        v2 = 4;
        v3 = "WINDOW_MODE_OPTION_COMMON_INHERIT";
        v1[v2] = v3;
        v2 = 5;
        v3 = "WINDOW_MODE_OPTION_COMMON_RESIZE";
        v1[v2] = v3;
        v2 = 6;
        v3 = "WINDOW_MODE_OPTION_COMMON_MINIMIZED";
        v1[v2] = v3;
        v2 = 7;
        v3 = "WINDOW_MODE_OPTION_COMMON_HIDDEN";
        v1[v2] = v3;
        v2 = 8;
        v3 = "WINDOW_MODE_OPTION_COMMON_FIXED_SIZE";
        v1[v2] = v3;
        v2 = 9;
        v3 = "WINDOW_MODE_OPTION_COMMON_FIXED_RATIO";
        v1[v2] = v3;
        v2 = 10;
        v3 = "WINDOW_INFO_NOTHING_CHANGED";
        v1[v2] = v3;
        v2 = 11;
        v3 = "WINDOW_INFO_SIZE_CHANGED";
        v1[v2] = v3;
        v2 = 12;
        v3 = "WINDOW_MODE_OPTION_COMMON_NO_DECORATION";
        v1[v2] = v3;
        v2 = 13;
        v3 = "WINDOW_MODE_OPTION_SPLIT_ZONE_MASK";
        v1[v2] = v3;
        v2 = 14;
        v3 = "WINDOW_MODE_OPTION_SPLIT_ZONE_F";
        v1[v2] = v3;
        v2 = 15;
        v3 = "WINDOW_MODE_OPTION_SPLIT_ZONE_E";
        v1[v2] = v3;
        v2 = 16;
        v3 = "WINDOW_MODE_OPTION_SPLIT_ZONE_D";
        v1[v2] = v3;
        v2 = 17;
        v3 = "WINDOW_MODE_OPTION_SPLIT_ZONE_C";
        v1[v2] = v3;
        v2 = 18;
        v3 = "WINDOW_MODE_OPTION_SPLIT_ZONE_UNKNOWN";
        v1[v2] = v3;
        v2 = 19;
        v3 = "WINDOW_MODE_OPTION_SPLIT_ZONE_B";
        v1[v2] = v3;
        v2 = 20;
        v3 = "WINDOW_MODE_OPTION_SPLIT_ZONE_A";
        v1[v2] = v3;
        v2 = 21;
        v3 = "WINDOW_MODE_OPTION_SPLIT_ZONE_FULL";
        v1[v2] = v3;
        v2 = 22;
        v3 = "WINDOW_MODE_OPTION_COMMON_NO_CONTROLBAR";
        v1[v2] = v3;
        android.sec.multiwindow.Constants$WindowManagerPolicy.FIELD_NAMES = v1; // :java.lang.String[]
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.FIELD_NAMES; // :java.lang.String[]
        v1 = v1.length;
        if (v0 >= v1) /* goto L_00c2 */;
        v2 = android.view.WindowManagerPolicy.class;
        v3 = android.sec.multiwindow.Constants$WindowManagerPolicy.FIELD_NAMES; // :java.lang.String[]
        v3 = v3[v0];
        _result = v2.getDeclaredField(v3); // java.lang.Class.getDeclaredField -> java.lang.reflect.Field
        v2 = _result;
        v3 = android.sec.multiwindow.Constants$WindowManagerPolicy.class;
        v4 = android.sec.multiwindow.Constants$WindowManagerPolicy.FIELD_NAMES; // :java.lang.String[]
        v4 = v4[v0];
        _result = v3.getField(v4); // java.lang.Class.getField -> java.lang.reflect.Field
        v3 = _result;
        _result = v2.getInt(v2); // java.lang.reflect.Field.getInt -> int
        v2 = _result;
        _result = v3.setInt(v3, v2); // java.lang.reflect.Field.setInt -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_00a2
        return;
        v2 = _exception;
        // goto L_00bf
        v2 = _exception;
        // goto L_00bf
        v2 = _exception;
        // goto L_00bf
    }

    public Constants$WindowManagerPolicy() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}