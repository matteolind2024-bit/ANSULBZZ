package android.sec.multiwindow;

/**
 * Original SourceFile: MultiWindow.java
 * Descriptor: Landroid/sec/multiwindow/MultiWindow;
 */
public class MultiWindow extends android.sec.multiwindow.MultiWindowImpl implements android.sec.multiwindow.IMultiWindow {
    protected static final java.lang.String TAG;
    private android.app.Activity mActivity;
    private boolean mArrangeable;
    private android.graphics.Rect mDefaultSize;
    private android.graphics.Rect mMaximumSize;
    private android.graphics.Rect mMinimumSize;
    private int mWindowMode;

    private MultiWindow(android.app.Activity p0) {
        // Registers (10 total): v8 = this, v9 = p0 (android.app.Activity)
        v1 = 0;
        v7 = 1;
        v6 = 0;
        _result = v8.<init>(v9); // android.sec.multiwindow.MultiWindowImpl.<init> -> void
        v8.mArrangeable = v7; // android.sec.multiwindow.MultiWindow.mArrangeable:boolean
        v8.mActivity = v9; // android.sec.multiwindow.MultiWindow.mActivity:android.app.Activity
        v0 = v8.mActivity; // android.sec.multiwindow.MultiWindow.mActivity:android.app.Activity
        _result = v0.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        v3 = v8.mActivity; // android.sec.multiwindow.MultiWindow.mActivity:android.app.Activity
        v4 = "getWindowMode";
        v0 = v1;
        v0 = (java.lang.Class[]) v0;
        _result = v8.putMethod(v2, v3, v4, v0); // android.sec.multiwindow.MultiWindow.putMethod -> void
        v0 = v8.mActivity; // android.sec.multiwindow.MultiWindow.mActivity:android.app.Activity
        v3 = "setWindowMode";
        v4 = 2;
        v4 = new java.lang.Class[][size=v4];
        v5 = java.lang.Integer.TYPE; // :java.lang.Class
        v4[v6] = v5;
        v5 = java.lang.Boolean.TYPE; // :java.lang.Class
        v4[v7] = v5;
        _result = v8.putMethod(v2, v0, v3, v4); // android.sec.multiwindow.MultiWindow.putMethod -> void
        v0 = v8.mActivity; // android.sec.multiwindow.MultiWindow.mActivity:android.app.Activity
        v3 = "getWindowInfo";
        v1 = (java.lang.Class[]) v1;
        _result = v8.putMethod(v2, v0, v3, v1); // android.sec.multiwindow.MultiWindow.putMethod -> void
        v0 = v8.mActivity; // android.sec.multiwindow.MultiWindow.mActivity:android.app.Activity
        v1 = "setWindowInfo";
        v3 = new java.lang.Class[][size=v7];
        v4 = android.os.Bundle.class;
        v3[v6] = v4;
        _result = v8.putMethod(v2, v0, v1, v3); // android.sec.multiwindow.MultiWindow.putMethod -> void
        _result = v8.getWindowInfo(); // android.sec.multiwindow.MultiWindow.getWindowInfo -> android.os.Bundle
        v1 = _result;
        v0 = android.sec.multiwindow.Constants$Intent.EXTRA_WINDOW_DEFAULT_SIZE; // :java.lang.String
        _result = v1.getParcelable(v0); // android.os.Bundle.getParcelable -> android.os.Parcelable
        v0 = _result;
        v0 = (android.graphics.Rect) v0;
        v8.mDefaultSize = v0; // android.sec.multiwindow.MultiWindow.mDefaultSize:android.graphics.Rect
        v0 = android.sec.multiwindow.Constants$Intent.EXTRA_WINDOW_MINIMUM_SIZE; // :java.lang.String
        _result = v1.getParcelable(v0); // android.os.Bundle.getParcelable -> android.os.Parcelable
        v0 = _result;
        v0 = (android.graphics.Rect) v0;
        v8.mMinimumSize = v0; // android.sec.multiwindow.MultiWindow.mMinimumSize:android.graphics.Rect
        v0 = new android.graphics.Point;
        _result = v0.<init>(); // android.graphics.Point.<init> -> void
        v1 = v8.mActivity; // android.sec.multiwindow.MultiWindow.mActivity:android.app.Activity
        _result = v1.getWindowManager(); // android.app.Activity.getWindowManager -> android.view.WindowManager
        v1 = _result;
        _result = android.view.WindowManager.getDefaultDisplay(v1); // -> android.view.Display
        v1 = _result;
        _result = v1.getSize(v0); // android.view.Display.getSize -> void
        v1 = new android.graphics.Rect;
        v2 = v0.x; // android.graphics.Point.x:int
        v0 = v0.y; // android.graphics.Point.y:int
        _result = v1.<init>(v6, v6, v2, v0); // android.graphics.Rect.<init> -> void
        v8.mMaximumSize = v1; // android.sec.multiwindow.MultiWindow.mMaximumSize:android.graphics.Rect
        return;
    }

    public MultiWindow(android.content.Context p0, android.sec.multiwindow.IMultiWindowService p1, android.content.ComponentName p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.sec.multiwindow.IMultiWindowService), v4 = p2 (android.content.ComponentName)
        _result = v1.<init>(v2); // android.sec.multiwindow.MultiWindowImpl.<init> -> void
        v0 = 1;
        v1.mArrangeable = v0; // android.sec.multiwindow.MultiWindow.mArrangeable:boolean
        return;
    }

    public MultiWindow(android.content.Context p0, android.sec.multiwindow.IMultiWindowService p1, android.content.Intent p2) {
        // Registers (5 total): v1 = this, v2 = p0 (android.content.Context), v3 = p1 (android.sec.multiwindow.IMultiWindowService), v4 = p2 (android.content.Intent)
        _result = v1.<init>(v2); // android.sec.multiwindow.MultiWindowImpl.<init> -> void
        v0 = 1;
        v1.mArrangeable = v0; // android.sec.multiwindow.MultiWindow.mArrangeable:boolean
        return;
    }

    private boolean checkMode(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        _result = v1.mode(v0); // android.sec.multiwindow.MultiWindow.mode -> int
        v0 = _result;
        if (v0 != v2) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    private boolean checkOption(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = v1.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        _result = v1.option(v0); // android.sec.multiwindow.MultiWindow.option -> int
        v0 = _result;
        v0 = binOp2addr_0xb5(v0, v2);
        if (v0 == 0) /* goto L_000b */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_000a
    }

    public static android.sec.multiwindow.MultiWindow createInstance(android.app.Activity p0) {
        // Registers (4 total): v3 = p0 (android.app.Activity)
        v0 = 0;
        if (v3 != 0) /* goto L_0004 */;
        return v0;
        _result = v3.getPackageManager(); // android.app.Activity.getPackageManager -> android.content.pm.PackageManager
        v1 = _result;
        v2 = android.sec.multiwindow.Constants$PackageManager.FEATURE_MULTIWINDOW; // :java.lang.String
        _result = v1.hasSystemFeature(v2); // android.content.pm.PackageManager.hasSystemFeature -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0003 */;
        v0 = new android.sec.multiwindow.MultiWindow;
        _result = v0.<init>(v3); // android.sec.multiwindow.MultiWindow.<init> -> void
        // goto L_0003
    }

    private android.graphics.Rect getLastSize() {
        // Registers (3 total): v2 = this
        _result = v2.getWindowInfo(); // android.sec.multiwindow.MultiWindow.getWindowInfo -> android.os.Bundle
        v0 = _result;
        v1 = android.sec.multiwindow.Constants$Intent.EXTRA_WINDOW_LAST_SIZE; // :java.lang.String
        _result = v0.getParcelable(v1); // android.os.Bundle.getParcelable -> android.os.Parcelable
        v0 = _result;
        v0 = (android.graphics.Rect) v0;
        if (v0 == 0) /* goto L_000f */;
        return v0;
        v0 = v2.mDefaultSize; // android.sec.multiwindow.MultiWindow.mDefaultSize:android.graphics.Rect
        // goto L_000e
    }

    private android.os.Bundle getWindowInfo() {
        // Registers (3 total): v2 = this
        v1 = "getWindowInfo";
        v0 = 0;
        v0 = (java.lang.Object[]) v0;
        _result = v2.invoke(v1, v0); // android.sec.multiwindow.MultiWindow.invoke -> java.lang.Object
        v0 = _result;
        v0 = (android.os.Bundle) v0;
        return v0;
    }

    protected static boolean isEnabledComponentName(android.content.Context p0, android.content.ComponentName p1) {
        // Registers (3 total): v1 = p0 (android.content.Context), v2 = p1 (android.content.ComponentName)
        v0 = 1;
        return v0;
    }

    private void setLastSize(android.graphics.Rect p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Rect)
        _result = v2.getWindowInfo(); // android.sec.multiwindow.MultiWindow.getWindowInfo -> android.os.Bundle
        v0 = _result;
        v1 = android.sec.multiwindow.Constants$Intent.EXTRA_WINDOW_LAST_SIZE; // :java.lang.String
        _result = v0.putParcelable(v1, v3); // android.os.Bundle.putParcelable -> void
        _result = v2.setWindowInfo(v0); // android.sec.multiwindow.MultiWindow.setWindowInfo -> void
        return;
    }

    private void setWindowInfo(android.os.Bundle p0) {
        // Registers (5 total): v3 = this, v4 = p0 (android.os.Bundle)
        v0 = "setWindowInfo";
        v1 = 1;
        v1 = new java.lang.Object[][size=v1];
        v2 = 0;
        v1[v2] = v4;
        _result = v3.invoke(v0, v1); // android.sec.multiwindow.MultiWindow.invoke -> java.lang.Object
        return;
    }

    private void setWindowMode(int p0) {
        // Registers (7 total): v5 = this, v6 = p0 (int)
        v4 = 1;
        v0 = "setWindowMode";
        v1 = 2;
        v1 = new java.lang.Object[][size=v1];
        v2 = 0;
        _result = v6.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v3 = _result;
        v1[v2] = v3;
        _result = v4.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v2 = _result;
        v1[v4] = v2;
        _result = v5.invoke(v0, v1); // android.sec.multiwindow.MultiWindow.invoke -> java.lang.Object
        return;
    }

    private void setWindowParams() {
        // Registers (6 total): v5 = this
        v4 = -1;
        v3 = 0;
        v0 = v5.mActivity; // android.sec.multiwindow.MultiWindow.mActivity:android.app.Activity
        _result = v0.getWindow(); // android.app.Activity.getWindow -> android.view.Window
        v0 = _result;
        _result = v0.getAttributes(); // android.view.Window.getAttributes -> android.view.WindowManager$LayoutParams
        v0 = _result;
        v1 = v5.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        _result = v5.mode(v1); // android.sec.multiwindow.MultiWindow.mode -> int
        v1 = _result;
        v2 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_FREESTYLE; // :int
        if (v1 != v2) /* goto L_003c */;
        _result = v5.getLastSize(); // android.sec.multiwindow.MultiWindow.getLastSize -> android.graphics.Rect
        v1 = _result;
        v2 = v1.left; // android.graphics.Rect.left:int
        v0.x = v2; // android.view.WindowManager$LayoutParams.x:int
        v2 = v1.top; // android.graphics.Rect.top:int
        v0.y = v2; // android.view.WindowManager$LayoutParams.y:int
        _result = v1.width(); // android.graphics.Rect.width -> int
        v2 = _result;
        v0.width = v2; // android.view.WindowManager$LayoutParams.width:int
        _result = v1.height(); // android.graphics.Rect.height -> int
        v1 = _result;
        v0.height = v1; // android.view.WindowManager$LayoutParams.height:int
        v1 = 51;
        v0.gravity = v1; // android.view.WindowManager$LayoutParams.gravity:int
        v1 = v5.mActivity; // android.sec.multiwindow.MultiWindow.mActivity:android.app.Activity
        _result = v1.getWindow(); // android.app.Activity.getWindow -> android.view.Window
        v1 = _result;
        _result = v1.setAttributes(v0); // android.view.Window.setAttributes -> void
        return;
        v0.x = v3; // android.view.WindowManager$LayoutParams.x:int
        v0.y = v3; // android.view.WindowManager$LayoutParams.y:int
        v0.width = v4; // android.view.WindowManager$LayoutParams.width:int
        v0.height = v4; // android.view.WindowManager$LayoutParams.height:int
        v0.gravity = v3; // android.view.WindowManager$LayoutParams.gravity:int
        // goto L_0032
    }

    private void updateWindowMode() {
        // Registers (3 total): v2 = this
        v1 = "getWindowMode";
        v0 = 0;
        v0 = (java.lang.Object[]) v0;
        _result = v2.invoke(v1, v0); // android.sec.multiwindow.MultiWindow.invoke -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.Integer) v0;
        _result = v0.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        return;
    }

    public boolean finish() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public boolean finish(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public boolean fitToHalf(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public boolean getArrangeable() {
        // Registers (2 total): v1 = this
        v0 = v1.mArrangeable; // android.sec.multiwindow.MultiWindow.mArrangeable:boolean
        return v0;
    }

    public int getHeight() {
        // Registers (2 total): v1 = this
        v0 = -1;
        return v0;
    }

    public android.graphics.Point getMinimumSize() {
        // Registers (3 total): v2 = this
        v1 = -1;
        v0 = new android.graphics.Point;
        _result = v0.<init>(v1, v1); // android.graphics.Point.<init> -> void
        return v0;
    }

    public boolean getMultiWindowEnabled() {
        // Registers (2 total): v1 = this
        _result = v1.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_RESIZE; // :int
        _result = v1.checkOption(v0); // android.sec.multiwindow.MultiWindow.checkOption -> boolean
        v0 = _result;
        return v0;
    }

    public android.graphics.Rect getRect() {
        // Registers (2 total): v1 = this
        _result = v1.isMultiWindow(); // android.sec.multiwindow.MultiWindow.isMultiWindow -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000e */;
        _result = v1.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        _result = v1.getLastSize(); // android.sec.multiwindow.MultiWindow.getLastSize -> android.graphics.Rect
        v0 = _result;
        return v0;
        v0 = v1.mMaximumSize; // android.sec.multiwindow.MultiWindow.mMaximumSize:android.graphics.Rect
        // goto L_000d
    }

    public android.graphics.Rect getRect(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = new android.graphics.Rect;
        _result = v0.<init>(); // android.graphics.Rect.<init> -> void
        return v0;
    }

    public int getWidth() {
        // Registers (2 total): v1 = this
        v0 = -1;
        return v0;
    }

    public int getZone() {
        // Registers (3 total): v2 = this
        _result = v2.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_SPLIT_ZONE_MASK; // :int
        v0 = binOp2addr_0xb5(v0, v1);
        return v0;
    }

    public boolean isMaximized() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public boolean isMaximized(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public boolean isMinimized() {
        // Registers (2 total): v1 = this
        _result = v1.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_FREESTYLE; // :int
        _result = v1.checkMode(v0); // android.sec.multiwindow.MultiWindow.checkMode -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0015 */;
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_MINIMIZED; // :int
        _result = v1.checkOption(v0); // android.sec.multiwindow.MultiWindow.checkOption -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0015 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0014
    }

    public boolean isMultiWindow() {
        // Registers (2 total): v1 = this
        _result = v1.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_FREESTYLE; // :int
        _result = v1.checkMode(v0); // android.sec.multiwindow.MultiWindow.checkMode -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isNormalWindow() {
        // Registers (2 total): v1 = this
        _result = v1.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_NORMAL; // :int
        _result = v1.checkMode(v0); // android.sec.multiwindow.MultiWindow.checkMode -> boolean
        v0 = _result;
        return v0;
    }

    public boolean isPinup() {
        // Registers (2 total): v1 = this
        _result = v1.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_FREESTYLE; // :int
        _result = v1.checkMode(v0); // android.sec.multiwindow.MultiWindow.checkMode -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0015 */;
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_PINUP; // :int
        _result = v1.checkOption(v0); // android.sec.multiwindow.MultiWindow.checkOption -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0015 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0014
    }

    public boolean isStartedAsPinup() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public boolean isStartingSplitScreen(android.content.ComponentName p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.content.ComponentName)
        v0 = 0;
        return v0;
    }

    public boolean maximize() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public boolean minimize() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public boolean minimize(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 0;
        return v0;
    }

    public boolean minimize(boolean p0) {
        // Registers (5 total): v3 = this, v4 = p0 (boolean)
        v1 = 1;
        v0 = 0;
        _result = v3.isMultiWindow(); // android.sec.multiwindow.MultiWindow.isMultiWindow -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0009 */;
        return v0;
        _result = v3.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        _result = v3.getMultiWindowEnabled(); // android.sec.multiwindow.MultiWindow.getMultiWindowEnabled -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0008 */;
        _result = v3.isMinimized(); // android.sec.multiwindow.MultiWindow.isMinimized -> boolean
        v0 = _result;
        if (v4 != v0) /* goto L_001a */;
        v0 = v1;
        // goto L_0008
        if (v4 == 0) /* goto L_0034 */;
        v0 = v3.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v2 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_MINIMIZED; // :int
        v0 = binOp2addr_0xb6(v0, v2);
        v3.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v3.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v2 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_PINUP; // :int
        v0 = binOp2addr_0xb6(v0, v2);
        v3.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v3.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        _result = v3.setWindowMode(v0); // android.sec.multiwindow.MultiWindow.setWindowMode -> void
        _result = v3.setWindowParams(); // android.sec.multiwindow.MultiWindow.setWindowParams -> void
        v0 = v1;
        // goto L_0008
        v0 = v3.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v2 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_MINIMIZED; // :int
        v2 = binOpLit8_0xdf(v2, -1);
        v0 = binOp2addr_0xb5(v0, v2);
        v3.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        // goto L_002a
    }

    public boolean multiWindow() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.multiWindow(v0, v0); // android.sec.multiwindow.MultiWindow.multiWindow -> boolean
        v0 = _result;
        return v0;
    }

    public boolean multiWindow(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = 0;
        _result = v1.multiWindow(v2, v0); // android.sec.multiwindow.MultiWindow.multiWindow -> boolean
        v0 = _result;
        return v0;
    }

    public boolean multiWindow(boolean p0, boolean p1) {
        // Registers (4 total): v1 = this, v2 = p0 (boolean), v3 = p1 (boolean)
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_SPLIT_ZONE_UNKNOWN; // :int
        _result = v1.multiWindow(v2, v3, v0); // android.sec.multiwindow.MultiWindow.multiWindow -> boolean
        v0 = _result;
        return v0;
    }

    public boolean multiWindow(boolean p0, boolean p1, int p2) {
        // Registers (6 total): v2 = this, v3 = p0 (boolean), v4 = p1 (boolean), v5 = p2 (int)
        v0 = 0;
        _result = v2.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        _result = v2.getMultiWindowEnabled(); // android.sec.multiwindow.MultiWindow.getMultiWindowEnabled -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000b */;
        return v0;
        _result = v2.isMultiWindow(); // android.sec.multiwindow.MultiWindow.isMultiWindow -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_000a */;
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_MASK; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_FREESTYLE; // :int
        v0 = binOp2addr_0xb6(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        if (v3 == 0) /* goto L_0063 */;
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_PINUP; // :int
        v0 = binOp2addr_0xb6(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        if (v4 == 0) /* goto L_006d */;
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_MINIMIZED; // :int
        v0 = binOp2addr_0xb6(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_SPLIT_ZONE_UNKNOWN; // :int
        if (v5 != v0) /* goto L_0077 */;
        v0 = v2.mActivity; // android.sec.multiwindow.MultiWindow.mActivity:android.app.Activity
        _result = v0.getResources(); // android.app.Activity.getResources -> android.content.res.Resources
        v0 = _result;
        _result = v0.getConfiguration(); // android.content.res.Resources.getConfiguration -> android.content.res.Configuration
        v0 = _result;
        _result = v2.getArrange(v0); // android.sec.multiwindow.MultiWindow.getArrange -> int
        v0 = _result;
        v1 = android.sec.multiwindow.Constants$Configuration.ARRANGE_SPLITED; // :int
        if (v0 != v1) /* goto L_0059 */;
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_SPLIT_ZONE_MASK; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_SPLIT_ZONE_A; // :int
        v0 = binOp2addr_0xb6(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        _result = v2.setWindowParams(); // android.sec.multiwindow.MultiWindow.setWindowParams -> void
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        _result = v2.setWindowMode(v0); // android.sec.multiwindow.MultiWindow.setWindowMode -> void
        v0 = 1;
        // goto L_000a
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_PINUP; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        // goto L_002a
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_MINIMIZED; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        // goto L_0033
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_SPLIT_ZONE_MASK; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = binOp2addr_0xb6(v0, v5);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        // goto L_0059
    }

    public boolean normalWindow() {
        // Registers (3 total): v2 = this
        _result = v2.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_MASK; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_NORMAL; // :int
        v0 = binOp2addr_0xb6(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_PINUP; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_MINIMIZED; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        _result = v2.setWindowMode(v0); // android.sec.multiwindow.MultiWindow.setWindowMode -> void
        _result = v2.setWindowParams(); // android.sec.multiwindow.MultiWindow.setWindowParams -> void
        v0 = 1;
        return v0;
    }

    public boolean pinUp(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v0 = 0;
        return v0;
    }

    public boolean pinUp(boolean p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (boolean), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

    public boolean pinup(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        v0 = 0;
        _result = v2.isMultiWindow(); // android.sec.multiwindow.MultiWindow.isMultiWindow -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0008 */;
        return v0;
        _result = v2.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        _result = v2.getMultiWindowEnabled(); // android.sec.multiwindow.MultiWindow.getMultiWindowEnabled -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0007 */;
        if (v3 == 0) /* goto L_0024 */;
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_PINUP; // :int
        v0 = binOp2addr_0xb6(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        _result = v2.setWindowMode(v0); // android.sec.multiwindow.MultiWindow.setWindowMode -> void
        _result = v2.setWindowParams(); // android.sec.multiwindow.MultiWindow.setWindowParams -> void
        v0 = 1;
        // goto L_0007
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_PINUP; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        // goto L_001a
    }

    public boolean relayout(android.graphics.Rect p0) {
        // Registers (3 total): v1 = this, v2 = p0 (android.graphics.Rect)
        v0 = 0;
        return v0;
    }

    public boolean restore() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

    public boolean restore(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        v0 = 1;
        return v0;
    }

    public boolean setArrangeable(boolean p0) {
        // Registers (3 total): v1 = this, v2 = p0 (boolean)
        v1.mArrangeable = v2; // android.sec.multiwindow.MultiWindow.mArrangeable:boolean
        v0 = 1;
        return v0;
    }

    public boolean setMinimumSize(int p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (int), v3 = p1 (int)
        v0 = 0;
        return v0;
    }

    public boolean setMultiWindowEnabled(boolean p0) {
        // Registers (4 total): v2 = this, v3 = p0 (boolean)
        _result = v2.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        if (v3 == 0) /* goto L_0016 */;
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_RESIZE; // :int
        v0 = binOp2addr_0xb6(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        _result = v2.setWindowMode(v0); // android.sec.multiwindow.MultiWindow.setWindowMode -> void
        _result = v2.setWindowParams(); // android.sec.multiwindow.MultiWindow.setWindowParams -> void
        v0 = 1;
        return v0;
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_MASK; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_NORMAL; // :int
        v0 = binOp2addr_0xb6(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_PINUP; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_MINIMIZED; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_COMMON_RESIZE; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        // goto L_000c
    }

    public boolean setRect(android.graphics.Rect p0) {
        // Registers (4 total): v2 = this, v3 = p0 (android.graphics.Rect)
        if (v3 == 0) /* goto L_003d */;
        _result = v3.height(); // android.graphics.Rect.height -> int
        v0 = _result;
        v1 = v2.mMinimumSize; // android.sec.multiwindow.MultiWindow.mMinimumSize:android.graphics.Rect
        _result = v1.height(); // android.graphics.Rect.height -> int
        v1 = _result;
        if (v0 < v1) /* goto L_003d */;
        _result = v3.width(); // android.graphics.Rect.width -> int
        v0 = _result;
        v1 = v2.mMinimumSize; // android.sec.multiwindow.MultiWindow.mMinimumSize:android.graphics.Rect
        _result = v1.width(); // android.graphics.Rect.width -> int
        v1 = _result;
        if (v0 < v1) /* goto L_003d */;
        _result = v3.height(); // android.graphics.Rect.height -> int
        v0 = _result;
        v1 = v2.mMaximumSize; // android.sec.multiwindow.MultiWindow.mMaximumSize:android.graphics.Rect
        _result = v1.height(); // android.graphics.Rect.height -> int
        v1 = _result;
        if (v0 > v1) /* goto L_003d */;
        _result = v3.width(); // android.graphics.Rect.width -> int
        v0 = _result;
        v1 = v2.mMaximumSize; // android.sec.multiwindow.MultiWindow.mMaximumSize:android.graphics.Rect
        _result = v1.width(); // android.graphics.Rect.width -> int
        v1 = _result;
        if (v0 > v1) /* goto L_003d */;
        _result = v2.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        _result = v2.setLastSize(v3); // android.sec.multiwindow.MultiWindow.setLastSize -> void
        _result = v2.setWindowParams(); // android.sec.multiwindow.MultiWindow.setWindowParams -> void
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_003c
    }

    public void setZone(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        _result = v2.updateWindowMode(); // android.sec.multiwindow.MultiWindow.updateWindowMode -> void
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_SPLIT_ZONE_MASK; // :int
        v1 = binOpLit8_0xdf(v1, -1);
        v0 = binOp2addr_0xb5(v0, v1);
        v2.mWindowMode = v0; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v0 = v2.mWindowMode; // android.sec.multiwindow.MultiWindow.mWindowMode:int
        v1 = android.sec.multiwindow.Constants$WindowManagerPolicy.WINDOW_MODE_OPTION_SPLIT_ZONE_MASK; // :int
        v1 = binOp2addr_0xb5(v1, v3);
        v0 = binOp2addr_0xb6(v0, v1);
        _result = v2.setWindowMode(v0); // android.sec.multiwindow.MultiWindow.setWindowMode -> void
        return;
    }

    public boolean start() {
        // Registers (2 total): v1 = this
        v0 = 0;
        return v0;
    }

}