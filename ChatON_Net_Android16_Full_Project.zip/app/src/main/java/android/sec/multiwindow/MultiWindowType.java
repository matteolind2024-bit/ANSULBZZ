package android.sec.multiwindow;

/**
 * Original SourceFile: MultiWindowType.java
 * Descriptor: Landroid/sec/multiwindow/MultiWindowType;
 */
public final enum MultiWindowType {
    private static final android.sec.multiwindow.MultiWindowType[] $VALUES;

    static {
        v0 = 0;
        v0 = new android.sec.multiwindow.MultiWindowType[][size=v0];
        android.sec.multiwindow.MultiWindowType.$VALUES = v0; // :android.sec.multiwindow.MultiWindowType[]
        return;
    }

    private MultiWindowType(java.lang.String p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        return;
    }

    public static android.sec.multiwindow.MultiWindowType valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = android.sec.multiwindow.MultiWindowType.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (android.sec.multiwindow.MultiWindowType) v0;
        return v0;
    }

    public static android.sec.multiwindow.MultiWindowType[] values() {
        v0 = android.sec.multiwindow.MultiWindowType.$VALUES; // :android.sec.multiwindow.MultiWindowType[]
        _result = v0.clone(); // android.sec.multiwindow.MultiWindowType[].clone -> java.lang.Object
        v0 = _result;
        v0 = (android.sec.multiwindow.MultiWindowType[]) v0;
        return v0;
    }

}