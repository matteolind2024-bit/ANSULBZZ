package android.sec.multiwindow;

/**
 * Original SourceFile: MultiWindowUtil.java
 * Descriptor: Landroid/sec/multiwindow/MultiWindowUtil;
 */
public final class MultiWindowUtil {
    public MultiWindowUtil() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static final boolean containsLauncher(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = 0;
        return v0;
    }

    public static final boolean isLauncher(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = 0;
        return v0;
    }

    public static final boolean isVisibleActivity(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = 0;
        return v0;
    }

}