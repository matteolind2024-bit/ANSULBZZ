package android.sec.multiwindow;

/**
 * Original SourceFile: IMultiWindowManager.java
 * Descriptor: Landroid/sec/multiwindow/IMultiWindowManager;
 */
public interface IMultiWindowManager {
    public static final int LEFT;
    public static final int RIGHT;
    public static final java.lang.String SERVICE_NAME;

    public abstract boolean arrangeWindows(int p0);
    public abstract android.graphics.Bitmap capture(android.content.ComponentName p0);
    public abstract boolean exchangeSplitScreens();
    public abstract boolean finishAllWindow();
    public abstract boolean finishAppPid(int p0);
    public abstract boolean getMultiLayout();
    public abstract java.util.List getMultiWindowList();
    public abstract java.util.List getMultiWindowList(android.content.ComponentName p0);
    public abstract android.sec.multiwindow.MultiWindowType getMultiWindowMode();
    public abstract android.content.ComponentName getPinupWindow();
    public abstract java.util.List getPinupWindowList();
    public abstract android.content.ComponentName getResumedWindow();
    public abstract java.util.List getRunningWindowList();
    public abstract java.util.List getSplitList();
    public abstract java.util.List getVisibleWindowList();
    public abstract android.sec.multiwindow.IMultiWindow getWindowInstance(android.content.ComponentName p0);
    public abstract android.sec.multiwindow.IMultiWindow getWindowInstance(android.content.Intent p0);
    public abstract boolean isMultiWindow(android.content.ComponentName p0);
    public abstract boolean isPermissionOff();
    public abstract boolean isPinup(android.content.ComponentName p0);
    public abstract boolean isPinup(android.content.ComponentName p0, int p1);
    public abstract boolean isRunning(android.content.ComponentName p0);
    public abstract boolean isVisible(android.content.ComponentName p0);
    public abstract boolean notifyFinished(android.app.Activity p0);
    public abstract boolean notifyForceFinished(android.content.ComponentName p0);
    public abstract boolean notifySIP(int p0);
    public abstract boolean notifyStarted(android.app.Activity p0);
    public abstract boolean orientationChangeRestore(android.content.ComponentName p0, int p1);
    public abstract boolean postResume(android.app.Activity p0);
    public abstract android.sec.multiwindow.IMultiWindow registerMultiWindow(android.content.ComponentName p0);
    public abstract android.sec.multiwindow.IMultiWindow registerMultiWindow(android.content.ComponentName p0, int p1, int p2);
    public abstract android.sec.multiwindow.IMultiWindow registerMultiWindow(android.content.ComponentName p0, int p1, int p2, boolean p3);
    public abstract android.sec.multiwindow.IMultiWindow registerMultiWindow(android.content.ComponentName p0, java.util.List p1);
    public abstract boolean registerMultiWindowPair(android.content.ComponentName p0, android.content.ComponentName p1);
    public abstract boolean removeMultiWindow(android.content.ComponentName p0);
    public abstract boolean removeMultiWindowPair(android.content.ComponentName p0, android.content.ComponentName p1);
    public abstract android.graphics.Bitmap screenShot(android.content.ComponentName p0);
    public abstract boolean sendCreateAction(android.app.Activity p0);
    public abstract boolean sendDestroyAction(android.app.Activity p0);
    public abstract boolean sendFinishAction(android.app.Activity p0);
    public abstract boolean sendPauseAction(android.app.Activity p0);
    public abstract boolean sendResumeAction(android.app.Activity p0);
    public abstract boolean sendStartAction(android.app.Activity p0);
    public abstract boolean setMultiLayout(boolean p0);
    public abstract boolean setMultiWindowMode(android.sec.multiwindow.MultiWindowType p0);
    public abstract void setPreferenceValue(boolean p0);
    public abstract void showSwitchWindowGuideDialog(android.content.Context p0);
    public abstract boolean startLauncher();
    public abstract boolean startLauncher(android.content.ComponentName p0);
    public abstract boolean startLauncher(android.content.Context p0);
    public abstract boolean startLauncher(android.content.Context p0, android.content.ComponentName p1);
    public abstract boolean startSplitScreens(android.content.ComponentName p0, android.content.ComponentName p1);
    public abstract boolean startSplitScreens(android.content.ComponentName p0, android.content.Intent p1);
    public abstract boolean startSplitScreens(android.content.Intent p0, android.content.ComponentName p1);
    public abstract boolean startSplitScreensForLauncher(android.content.ComponentName p0, android.content.ComponentName p1);
    public abstract boolean unRegisterMultiWindow(android.content.ComponentName p0);
}