package android.sec.multiwindow;

/**
 * Original SourceFile: Constants.java
 * Descriptor: Landroid/sec/multiwindow/Constants;
 */
public class Constants {
    public Constants() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}