package android.sec.multiwindow;

/**
 * Original SourceFile: IMultiWindowService.java
 * Descriptor: Landroid/sec/multiwindow/IMultiWindowService;
 */
interface IMultiWindowService {
    public abstract boolean getOptionMap(int p0);
    public abstract void setOptionMap(int p0, boolean p1);
}