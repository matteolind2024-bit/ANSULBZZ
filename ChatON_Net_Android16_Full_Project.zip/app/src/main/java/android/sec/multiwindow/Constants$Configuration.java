package android.sec.multiwindow;

/**
 * Original SourceFile: Constants.java
 * Descriptor: Landroid/sec/multiwindow/Constants$Configuration;
 */
public class Constants$Configuration {
    public static int ARRANGE_CASCADE;
    public static int ARRANGE_MINIMIZED_ALL;
    public static int ARRANGE_RESTORED_ALL;
    public static int ARRANGE_SPLITED;
    public static int ARRANGE_TILED;
    public static int ARRANGE_TOGGLE_MASK;
    public static int ARRANGE_UNDEFINED;
    static java.lang.String[] FIELD_NAMES;

    static {
        v0 = 0;
        v1 = 7;
        v1 = new java.lang.String[][size=v1];
        v2 = "ARRANGE_UNDEFINED";
        v1[v0] = v2;
        v2 = 1;
        v3 = "ARRANGE_TILED";
        v1[v2] = v3;
        v2 = 2;
        v3 = "ARRANGE_CASCADE";
        v1[v2] = v3;
        v2 = 3;
        v3 = "ARRANGE_SPLITED";
        v1[v2] = v3;
        v2 = 4;
        v3 = "ARRANGE_MINIMIZED_ALL";
        v1[v2] = v3;
        v2 = 5;
        v3 = "ARRANGE_RESTORED_ALL";
        v1[v2] = v3;
        v2 = 6;
        v3 = "ARRANGE_TOGGLE_MASK";
        v1[v2] = v3;
        android.sec.multiwindow.Constants$Configuration.FIELD_NAMES = v1; // :java.lang.String[]
        v1 = android.sec.multiwindow.Constants$Configuration.FIELD_NAMES; // :java.lang.String[]
        v1 = v1.length;
        if (v0 >= v1) /* goto L_0052 */;
        v2 = android.content.res.Configuration.class;
        v3 = android.sec.multiwindow.Constants$Configuration.FIELD_NAMES; // :java.lang.String[]
        v3 = v3[v0];
        _result = v2.getDeclaredField(v3); // java.lang.Class.getDeclaredField -> java.lang.reflect.Field
        v2 = _result;
        v3 = android.sec.multiwindow.Constants$Configuration.class;
        v4 = android.sec.multiwindow.Constants$Configuration.FIELD_NAMES; // :java.lang.String[]
        v4 = v4[v0];
        _result = v3.getField(v4); // java.lang.Class.getField -> java.lang.reflect.Field
        v3 = _result;
        _result = v2.getInt(v2); // java.lang.reflect.Field.getInt -> int
        v2 = _result;
        _result = v3.setInt(v3, v2); // java.lang.reflect.Field.setInt -> void
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0032
        return;
        v2 = _exception;
        // goto L_004f
        v2 = _exception;
        // goto L_004f
        v2 = _exception;
        // goto L_004f
    }

    public Constants$Configuration() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

}