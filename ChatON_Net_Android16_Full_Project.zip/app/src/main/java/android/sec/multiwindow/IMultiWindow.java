package android.sec.multiwindow;

/**
 * Original SourceFile: IMultiWindow.java
 * Descriptor: Landroid/sec/multiwindow/IMultiWindow;
 */
public interface IMultiWindow {
    public abstract boolean finish();
    public abstract boolean finish(int p0);
    public abstract boolean fitToHalf(int p0);
    public abstract int getHeight();
    public abstract android.graphics.Point getMinimumSize();
    public abstract android.graphics.Rect getRect();
    public abstract android.graphics.Rect getRect(int p0);
    public abstract int getWidth();
    public abstract boolean isMaximized();
    public abstract boolean isMaximized(int p0);
    public abstract boolean isStartingSplitScreen(android.content.ComponentName p0);
    public abstract boolean maximize();
    public abstract boolean minimize();
    public abstract boolean minimize(int p0);
    public abstract boolean pinUp(boolean p0);
    public abstract boolean pinUp(boolean p0, int p1);
    public abstract boolean relayout(android.graphics.Rect p0);
    public abstract boolean restore();
    public abstract boolean restore(int p0);
    public abstract boolean setMinimumSize(int p0, int p1);
    public abstract boolean start();
}