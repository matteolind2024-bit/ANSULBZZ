package b;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lb/i;
 */
public interface i extends java.io.Serializable {
}