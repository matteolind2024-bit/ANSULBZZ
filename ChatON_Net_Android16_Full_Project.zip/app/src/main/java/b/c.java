package b;

/**
 * Original SourceFile: RateLimitStatus.java
 * Descriptor: Lb/c;
 */
public interface c extends java.io.Serializable {
    public abstract int a();
}