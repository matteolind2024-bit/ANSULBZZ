package b;

/**
 * Original SourceFile: TwitterFactory.java
 * Descriptor: Lb/h;
 */
public final class h implements java.io.Serializable {
    static final b.b.b a;
    private static final java.lang.reflect.Constructor b;
    private static final b.f c;
    private final b.c.a d;

    static {
        _result = this.a(); // b.c.b.a -> b.c.a
        v0 = _result;
        _result = v0.a(); // b.b.c.a -> b.b.b
        v0 = _result;
        b.h.a = v0; // :b.b.b
        v0 = 0;
        _result = this.a(); // b.c.b.a -> b.c.a
        v1 = _result;
        _result = b.c.a.b(v1); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0021 */;
        v1 = "twitter4j.AppEngineTwitterImpl";
        v1 = "twitter4j.AppEngineTwitterImpl";
        _result = v1.forName(); // java.lang.Class.forName -> java.lang.Class
        v0 = "twitter4j.AppEngineTwitterImpl";
        if (v0 != 0) /* goto L_0026 */;
        v0 = "twitter4j.TwitterImpl";
        _result = v0.forName(); // java.lang.Class.forName -> java.lang.Class
        v0 = _result;
        v1 = 2;
        v1 = new java.lang.Class[][size=v1];
        v2 = 0;
        v3 = b.c.a.class;
        v1[v2] = v3;
        v2 = 1;
        v3 = b.b.b.class;
        v1[v2] = v3;
        _result = v0.getDeclaredConstructor(v1); // java.lang.Class.getDeclaredConstructor -> java.lang.reflect.Constructor
        v0 = _result;
        b.h.b = v0; // :java.lang.reflect.Constructor
        v0 = b.h.b; // :java.lang.reflect.Constructor
        v1 = 2;
        v1 = new java.lang.Object[][size=v1];
        v2 = 0;
        _result = this.a(); // b.c.b.a -> b.c.a
        v3 = _result;
        v1[v2] = v3;
        v2 = 1;
        v3 = b.h.a; // :b.b.b
        v1[v2] = v3;
        _result = v0.newInstance(v1); // java.lang.reflect.Constructor.newInstance -> java.lang.Object
        v0 = _result;
        v0 = (b.f) v0;
        b.h.c = v0; // :b.f
        return;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v1 = _exception;
        // goto L_0021
    }

    public h() {
        // Registers (2 total): v1 = this
        _result = this.a(); // b.c.b.a -> b.c.a
        v0 = _result;
        _result = v1.<init>(v0); // b.h.<init> -> void
        return;
    }

    public h(b.c.a p0) {
        // Registers (4 total): v2 = this, v3 = p0 (b.c.a)
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        if (v3 != 0) /* goto L_000e */;
        v0 = new java.lang.NullPointerException;
        v1 = "configuration cannot be null";
        _result = v0.<init>(v1); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v2.d = v3; // b.h.d:b.c.a
        return;
    }

    public b.f a() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // b.h.d:b.c.a
        _result = v0.a(); // b.b.c.a -> b.b.b
        v0 = _result;
        _result = v1.a(v0); // b.h.a -> b.f
        v0 = _result;
        return v0;
    }

    public b.f a(b.b.b p0) {
        // Registers (6 total): v4 = this, v5 = p0 (b.b.b)
        v0 = b.h.b; // :java.lang.reflect.Constructor
        v1 = 2;
        v1 = new java.lang.Object[][size=v1];
        v2 = 0;
        v3 = v4.d; // b.h.d:b.c.a
        v1[v2] = v3;
        v2 = 1;
        v1[v2] = v5;
        _result = v0.newInstance(v1); // java.lang.reflect.Constructor.newInstance -> java.lang.Object
        v0 = _result;
        v0 = (b.f) v0;
        return v0;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
    }

}