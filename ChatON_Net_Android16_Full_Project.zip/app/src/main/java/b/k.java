package b;

/**
 * Original SourceFile: Version.java
 * Descriptor: Lb/k;
 */
public final class k {
    public static java.lang.String a() {
        v0 = "3.0.3";
        return v0;
    }

}