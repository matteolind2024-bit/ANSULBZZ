package b;

/**
 * Original SourceFile: ExceptionDiagnosis.java
 * Descriptor: Lb/a;
 */
final class a implements java.io.Serializable {
     int a;
     int b;
     java.lang.String c;
     java.lang.Throwable d;

    a(java.lang.Throwable p0, java.lang.String[] p1) {
        // Registers (11 total): v8 = this, v9 = p0 (java.lang.Throwable), v10 = p1 (java.lang.String[])
        v1 = 0;
        _result = v8.<init>(); // java.lang.Object.<init> -> void
        v0 = "";
        v8.c = v0; // b.a.c:java.lang.String
        v8.d = v9; // b.a.d:java.lang.Throwable
        _result = v9.getStackTrace(); // java.lang.Throwable.getStackTrace -> java.lang.StackTraceElement[]
        v3 = _result;
        v8.a = v1; // b.a.a:int
        v8.b = v1; // b.a.b:int
        v0 = v3.length;
        v0 = binOpLit8_0xd8(v0, -1);
        v2 = v0;
        if (v2 < 0) /* goto L_0055 */;
        v4 = v3[v2];
        v5 = v10.length;
        v0 = v1;
        if (v0 >= v5) /* goto L_004e */;
        v6 = v10[v0];
        _result = v4.getClassName(); // java.lang.StackTraceElement.getClassName -> java.lang.String
        v7 = _result;
        _result = v7.startsWith(v6); // java.lang.String.startsWith -> boolean
        v6 = _result;
        if (v6 == 0) /* goto L_0052 */;
        _result = v4.getClassName(); // java.lang.StackTraceElement.getClassName -> java.lang.String
        v0 = _result;
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        _result = v4.getMethodName(); // java.lang.StackTraceElement.getMethodName -> java.lang.String
        v5 = _result;
        _result = v5.hashCode(); // java.lang.String.hashCode -> int
        v5 = _result;
        v0 = binOp2addr_0xb0(v0, v5);
        v5 = v8.a; // b.a.a:int
        v5 = binOpLit8_0xda(v5, 31);
        v0 = binOp2addr_0xb0(v0, v5);
        v8.a = v0; // b.a.a:int
        v0 = v8.b; // b.a.b:int
        v0 = binOpLit8_0xda(v0, 31);
        _result = v4.getLineNumber(); // java.lang.StackTraceElement.getLineNumber -> int
        v4 = _result;
        v0 = binOp2addr_0xb0(v0, v4);
        v8.b = v0; // b.a.b:int
        v0 = binOpLit8_0xd8(v2, -1);
        v2 = v0;
        // goto L_0017
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_001d
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = v8.c; // b.a.c:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v8.a; // b.a.a:int
        _result = v8.a(v1); // b.a.a -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "-";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v8.b; // b.a.b:int
        _result = v8.a(v1); // b.a.a -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v8.c = v0; // b.a.c:java.lang.String
        _result = v9.getCause(); // java.lang.Throwable.getCause -> java.lang.Throwable
        v0 = _result;
        if (v0 == 0) /* goto L_00b0 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = v8.c; // b.a.c:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = new b.a;
        _result = v9.getCause(); // java.lang.Throwable.getCause -> java.lang.Throwable
        v2 = _result;
        _result = v1.<init>(v2, v10); // b.a.<init> -> void
        _result = v1.c(); // b.a.c -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v8.c = v0; // b.a.c:java.lang.String
        return;
    }

    private java.lang.String a(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "0000000";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.length(); // java.lang.String.length -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -8);
        _result = v0.length(); // java.lang.String.length -> int
        v2 = _result;
        _result = v0.substring(v1, v2); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        return v0;
    }

    java.lang.String a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // b.a.a:int
        _result = v1.a(v0); // b.a.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    java.lang.String b() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // b.a.b:int
        _result = v1.a(v0); // b.a.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    java.lang.String c() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // b.a.c:java.lang.String
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        if (v5 == 0) /* goto L_0011 */;
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0013 */;
        v0 = v1;
        // goto L_0004
        v5 = (b.a) v5;
        v2 = v4.b; // b.a.b:int
        v3 = v5.b; // b.a.b:int
        if (v2 == v3) /* goto L_001d */;
        v0 = v1;
        // goto L_0004
        v2 = v4.a; // b.a.a:int
        v3 = v5.a; // b.a.a:int
        if (v2 == v3) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public int hashCode() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // b.a.a:int
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.b; // b.a.b:int
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "ExceptionDiagnosis{stackLineHash=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.a; // b.a.a:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", lineNumberHash=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.b; // b.a.b:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}