package b;

/**
 * Original SourceFile: TwitterException.java
 * Descriptor: Lb/g;
 */
public class g extends java.lang.Exception implements b.i {
    private static final java.lang.String[] g;
     boolean a;
    private int b;
    private int c;
    private b.a d;
    private b.d.a.l e;
    private java.lang.String f;

    static {
        v0 = 1;
        v0 = new java.lang.String[][size=v0];
        v1 = 0;
        v2 = "twitter4j";
        v0[v1] = v2;
        b.g.g = v0; // :java.lang.String[]
        return;
    }

    public g(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = 0;
        v0 = (java.lang.Throwable) v0;
        _result = v1.<init>(v2, v0); // b.g.<init> -> void
        return;
    }

    public g(java.lang.String p0, b.d.a.l p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (b.d.a.l)
        _result = v1.<init>(v2); // b.g.<init> -> void
        v1.e = v3; // b.g.e:b.d.a.l
        _result = v3.a(); // b.d.a.l.a -> int
        v0 = _result;
        v1.b = v0; // b.g.b:int
        return;
    }

    public g(java.lang.String p0, java.lang.Exception p1, int p2) {
        // Registers (4 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (java.lang.Exception), v3 = p2 (int)
        _result = v0.<init>(v1, v2); // b.g.<init> -> void
        v0.b = v3; // b.g.b:int
        return;
    }

    public g(java.lang.String p0, java.lang.Throwable p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.String), v4 = p1 (java.lang.Throwable)
        v1 = 0;
        v0 = -1;
        _result = v2.<init>(v3, v4); // java.lang.Exception.<init> -> void
        v2.b = v0; // b.g.b:int
        v2.c = v0; // b.g.c:int
        v2.d = v1; // b.g.d:b.a
        v2.f = v1; // b.g.f:java.lang.String
        v0 = 0;
        v2.a = v0; // b.g.a:boolean
        _result = v2.a(v3); // b.g.a -> void
        return;
    }

    private static java.lang.String a(int p0) {
        // Registers (4 total): v3 = p0 (int)
        // switch(v3)
        v0 = "";
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ":";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v0 = "There was no new data to return.";
        // goto L_0006
        v0 = "The request was invalid. An accompanying error message will explain why. This is the status code will be returned during version 1.0 rate limiting(https://dev.twitter.com/pages/rate-limiting). In API v1.1, a request without authentication is considered invalid and you will get this response.";
        // goto L_0006
        v0 = "Authentication credentials (https://dev.twitter.com/pages/auth) were missing or incorrect. Ensure that you have set valid consumer key/secret, access token/secret, and the system clock is in sync.";
        // goto L_0006
        v0 = "The request is understood, but it has been refused. An accompanying error message will explain why. This code is used when requests are being denied due to update limits (https://support.twitter.com/articles/15364-about-twitter-limits-update-api-dm-and-following).";
        // goto L_0006
        v0 = "The URI requested is invalid or the resource requested, such as a user, does not exists. Also returned when the requested format is not supported by the requested method.";
        // goto L_0006
        v0 = "Returned by the Search API when an invalid format is specified in the request.\nReturned by the Streaming API when one or more of the parameters are not suitable for the resource. The track parameter, for example, would throw this error if:\n The track keyword is too long or too short.\n The bounding box specified is invalid.\n No predicates defined for filtered resource, for example, neither track nor follow parameter defined.\n Follow userid cannot be read.";
        // goto L_0006
        v0 = "Returned by the Search and Trends API when you are being rate limited (https://dev.twitter.com/docs/rate-limiting).\nReturned by the Streaming API:\n Too many login attempts in a short period of time.\n Running too many copies of the same application authenticating with the same account name.";
        // goto L_0006
        v0 = "Returned when an image uploaded to POST account/update_profile_banner(https://dev.twitter.com/docs/api/1/post/account/update_profile_banner) is unable to be processed.";
        // goto L_0006
        v0 = "Returned in API v1.1 when a request cannot be served due to the application's rate limit having been exhausted for the resource. See Rate Limiting in API v1.1.(https://dev.twitter.com/docs/rate-limiting/1.1)";
        // goto L_0006
        v0 = "Something is broken. Please post to the group (https://dev.twitter.com/docs/support) so the Twitter team can investigate.";
        // goto L_0006
        v0 = "Twitter is down or being upgraded.";
        // goto L_0006
        v0 = "The Twitter servers are up, but overloaded with requests. Try again later.";
        // goto L_0006
        v0 = "The Twitter servers are up, but the request couldn't be serviced due to some failure within our stack. Try again later.";
        // goto L_0006
    }

    private void a(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        if (v3 == 0) /* goto L_0037 */;
        v0 = "{";
        _result = v3.startsWith(v0); // java.lang.String.startsWith -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0037 */;
        v0 = new b.d.d.a.c;
        _result = v0.<init>(v3); // b.d.d.a.c.<init> -> void
        v1 = "errors";
        _result = v0.d(v1); // b.d.d.a.c.d -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0037 */;
        v1 = "errors";
        _result = v0.b(v1); // b.d.d.a.c.b -> b.d.d.a.a
        v0 = _result;
        v1 = 0;
        _result = v0.b(v1); // b.d.d.a.a.b -> b.d.d.a.c
        v0 = _result;
        v1 = "message";
        _result = v0.c(v1); // b.d.d.a.c.c -> java.lang.String
        v1 = _result;
        v2.f = v1; // b.g.f:java.lang.String
        v1 = "code";
        _result = v1.b(v0); // b.d.b.d.b -> int
        v0 = _result;
        v2.c = v0; // b.g.c:int
        return;
        v0 = _exception;
        // goto L_0037
    }

    private b.a e() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // b.g.d:b.a
        if (v0 != 0) /* goto L_000d */;
        v0 = new b.a;
        v1 = b.g.g; // :java.lang.String[]
        _result = v0.<init>(v2, v1); // b.a.<init> -> void
        v2.d = v0; // b.g.d:b.a
        v0 = v2.d; // b.g.d:b.a
        return v0;
    }

    public b.c a() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // b.g.e:b.d.a.l
        if (v0 != 0) /* goto L_0006 */;
        v0 = 0;
        return v0;
        v0 = v1.e; // b.g.e:b.d.a.l
        _result = v0.a(); // b.d.b.c.a -> b.c
        v0 = _result;
        // goto L_0005
    }

    public int b() {
        // Registers (4 total): v3 = this
        v0 = -1;
        v1 = v3.b; // b.g.b:int
        v2 = 400;
        if (v1 != v2) /* goto L_0012 */;
        _result = v3.a(); // b.g.a -> b.c
        v1 = _result;
        if (v1 == 0) /* goto L_0011 */;
        _result = b.c.a(v1); // -> int
        v0 = _result;
        return v0;
        v1 = v3.b; // b.g.b:int
        v2 = 420;
        if (v1 != v2) /* goto L_0011 */;
        v1 = v3.e; // b.g.e:b.d.a.l
        v2 = "Retry-After";
        _result = v1.a(v2); // b.d.a.l.a -> java.lang.String
        v1 = _result;
        if (v1 == 0) /* goto L_0011 */;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v1.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        // goto L_0011
        v1 = _exception;
        // goto L_0011
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        _result = v1.e(); // b.g.e -> b.a
        v0 = _result;
        _result = v0.c(); // b.a.c -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String d() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // b.g.f:java.lang.String
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        if (v5 == 0) /* goto L_0011 */;
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0013 */;
        v0 = v1;
        // goto L_0004
        v5 = (b.g) v5;
        v2 = v4.c; // b.g.c:int
        v3 = v5.c; // b.g.c:int
        if (v2 == v3) /* goto L_001d */;
        v0 = v1;
        // goto L_0004
        v2 = v4.a; // b.g.a:boolean
        v3 = v5.a; // b.g.a:boolean
        if (v2 == v3) /* goto L_0025 */;
        v0 = v1;
        // goto L_0004
        v2 = v4.b; // b.g.b:int
        v3 = v5.b; // b.g.b:int
        if (v2 == v3) /* goto L_002d */;
        v0 = v1;
        // goto L_0004
        v2 = v4.f; // b.g.f:java.lang.String
        if (v2 == 0) /* goto L_003d */;
        v2 = v4.f; // b.g.f:java.lang.String
        v3 = v5.f; // b.g.f:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0041 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.f; // b.g.f:java.lang.String
        if (v2 != 0) /* goto L_003b */;
        v2 = v4.d; // b.g.d:b.a
        if (v2 == 0) /* goto L_0051 */;
        v2 = v4.d; // b.g.d:b.a
        v3 = v5.d; // b.g.d:b.a
        _result = v2.equals(v3); // b.a.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0055 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.d; // b.g.d:b.a
        if (v2 != 0) /* goto L_004f */;
        v2 = v4.e; // b.g.e:b.d.a.l
        if (v2 == 0) /* goto L_0065 */;
        v2 = v4.e; // b.g.e:b.d.a.l
        v3 = v5.e; // b.g.e:b.d.a.l
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.e; // b.g.e:b.d.a.l
        if (v2 == 0) /* goto L_0004 */;
        // goto L_0063
    }

    public java.lang.String getMessage() {
        // Registers (5 total): v4 = this
        v3 = -1;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = v4.f; // b.g.f:java.lang.String
        if (v1 == 0) /* goto L_005b */;
        v1 = v4.c; // b.g.c:int
        if (v1 == v3) /* goto L_005b */;
        v1 = "message - ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.f; // b.g.f:java.lang.String
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "\n";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = "code - ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.c; // b.g.c:int
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "\n";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v4.b; // b.g.b:int
        if (v1 == v3) /* goto L_0063 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = v4.b; // b.g.b:int
        _result = v2.a(); // b.g.a -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "\n";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        _result = v4.getMessage(); // java.lang.Exception.getMessage -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0034
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_005a
    }

    public int hashCode() {
        // Registers (4 total): v3 = this
        v1 = 0;
        v0 = v3.b; // b.g.b:int
        v0 = binOpLit8_0xda(v0, 31);
        v2 = v3.c; // b.g.c:int
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = binOpLit8_0xda(v0, 31);
        v0 = v3.d; // b.g.d:b.a
        if (v0 == 0) /* goto L_0038 */;
        v0 = v3.d; // b.g.d:b.a
        _result = v0.hashCode(); // b.a.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = binOpLit8_0xda(v0, 31);
        v0 = v3.e; // b.g.e:b.d.a.l
        if (v0 == 0) /* goto L_003a */;
        v0 = v3.e; // b.g.e:b.d.a.l
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = binOpLit8_0xda(v0, 31);
        v0 = v3.f; // b.g.f:java.lang.String
        if (v0 == 0) /* goto L_003c */;
        v0 = v3.f; // b.g.f:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v0 = binOpLit8_0xda(v0, 31);
        v2 = v3.a; // b.g.a:boolean
        if (v2 == 0) /* goto L_0036 */;
        v1 = 1;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v0 = v1;
        // goto L_0014
        v0 = v1;
        // goto L_0021
        v0 = v1;
        // goto L_002e
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v3.getMessage(); // b.g.getMessage -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v0 = v3.a; // b.g.a:boolean
        if (v0 == 0) /* goto L_0089 */;
        v0 = "";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "\nTwitterException{";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v0 = v3.a; // b.g.a:boolean
        if (v0 == 0) /* goto L_00ba */;
        v0 = "";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "statusCode=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.b; // b.g.b:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", message=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.f; // b.g.f:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", code=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.c; // b.g.c:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", retryAfter=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.b(); // b.g.b -> int
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", rateLimitStatus=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.a(); // b.g.a -> b.c
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", version=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = this.a(); // b.k.a -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "\nRelevant discussions can be found on the Internet at:\n	http://www.google.co.jp/search?q=";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.e(); // b.g.e -> b.a
        v2 = _result;
        _result = v2.a(); // b.a.a -> java.lang.String
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = " or\n	http://www.google.co.jp/search?q=";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.e(); // b.g.e -> b.a
        v2 = _result;
        _result = v2.b(); // b.a.b -> java.lang.String
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0014
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "exceptionCode=[";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v3.c(); // b.g.c -> java.lang.String
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = "], ";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0026
    }

}