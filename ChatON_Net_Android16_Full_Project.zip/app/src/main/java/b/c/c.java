package b.c;

/**
 * Original SourceFile: ConfigurationFactory.java
 * Descriptor: Lb/c/c;
 */
public interface c {
    public abstract b.c.a a();
}