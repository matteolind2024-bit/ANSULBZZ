package b.c;

/**
 * Original SourceFile: ConfigurationContext.java
 * Descriptor: Lb/c/b;
 */
public final class b {
    private static final b.c.c a;

    static {
        v0 = "twitter4j.configurationFactory";
        v1 = "twitter4j.conf.PropertyConfigurationFactory";
        _result = v0.getProperty(v1); // java.lang.System.getProperty -> java.lang.String
        v0 = _result;
        _result = v0.forName(); // java.lang.Class.forName -> java.lang.Class
        v0 = _result;
        _result = v0.newInstance(); // java.lang.Class.newInstance -> java.lang.Object
        v0 = _result;
        v0 = (b.c.c) v0;
        b.c.b.a = v0; // :b.c.c
        return;
        v0 = _exception;
        v0 = "twitter4j.conf.PropertyConfigurationFactory";
        // goto L_000a
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
    }

    public static b.c.a a() {
        v0 = b.c.b.a; // :b.c.c
        _result = b.c.c.a(v0); // -> b.c.a
        v0 = _result;
        return v0;
    }

}