package b.c;

/**
 * Original SourceFile: Configuration.java
 * Descriptor: Lb/c/a;
 */
public interface a extends b.d.a.d, b.d.a.i, java.io.Serializable {
    public abstract boolean a();
    public abstract boolean b();
    public abstract boolean c();
    public abstract java.lang.String d();
    public abstract java.lang.String e();
    public abstract java.lang.String f();
    public abstract java.lang.String g();
    public abstract java.lang.String h();
    public abstract java.lang.String i();
    public abstract java.lang.String j();
    public abstract java.lang.String k();
    public abstract java.lang.String l();
}