package b;

/**
 * Original SourceFile: ResponseList.java
 * Descriptor: Lb/d;
 */
public interface d extends b.i, java.util.List {
}