package b.a;

/**
 * Original SourceFile: FriendsFollowersResources.java
 * Descriptor: Lb/a/a;
 */
public interface a {
    public abstract b.b a(long p0);
}