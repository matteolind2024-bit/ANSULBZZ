package b.a;

/**
 * Original SourceFile: UsersResources.java
 * Descriptor: Lb/a/c;
 */
public interface c {
    public abstract b.d a(long[] p0);
    public abstract b.j a_(long p0);
}