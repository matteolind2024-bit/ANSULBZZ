package b.a;

/**
 * Original SourceFile: TweetsResources.java
 * Descriptor: Lb/a/b;
 */
public interface b {
    public abstract b.e b_(java.lang.String p0);
}