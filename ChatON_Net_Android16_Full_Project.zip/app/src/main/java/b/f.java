package b;

/**
 * Original SourceFile: Twitter.java
 * Descriptor: Lb/f;
 */
public interface f extends b.a.a, b.a.b, b.a.c, b.b.g, java.io.Serializable {
}