package b;

/**
 * Original SourceFile: Status.java
 * Descriptor: Lb/e;
 */
public interface e extends b.i, java.io.Serializable, java.lang.Comparable {
}