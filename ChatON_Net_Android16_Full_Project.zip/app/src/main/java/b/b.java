package b;

/**
 * Original SourceFile: IDs.java
 * Descriptor: Lb/b;
 */
public interface b extends b.i, java.io.Serializable {
    public abstract long[] a();
    public abstract long b();
}