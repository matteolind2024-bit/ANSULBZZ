package b;

/**
 * Original SourceFile: User.java
 * Descriptor: Lb/j;
 */
public interface j extends b.i, java.io.Serializable, java.lang.Comparable {
    public abstract long a();
    public abstract java.lang.String b();
    public abstract java.lang.String c();
    public abstract java.lang.String d();
}