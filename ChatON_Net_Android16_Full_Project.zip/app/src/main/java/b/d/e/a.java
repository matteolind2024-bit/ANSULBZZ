package b.d.e;

/**
 * Original SourceFile: z_T4JInternalStringUtil.java
 * Descriptor: Lb/d/e/a;
 */
public class a {
    public static java.lang.String a(java.lang.String p0) {
        // Registers (4 total): v3 = p0 (java.lang.String)
        v1 = new java.lang.StringBuilder;
        _result = v3.length(); // java.lang.String.length -> int
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.StringBuilder.<init> -> void
        v0 = 0;
        _result = v3.length(); // java.lang.String.length -> int
        v2 = _result;
        if (v0 >= v2) /* goto L_0019 */;
        v2 = "*";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_000a
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String[] a(java.lang.String p0, java.lang.String p1) {
        // Registers (7 total): v5 = p0 (java.lang.String), v6 = p1 (java.lang.String)
        v1 = 0;
        v3 = -1;
        _result = v5.indexOf(v6); // java.lang.String.indexOf -> int
        v0 = _result;
        if (v0 != v3) /* goto L_000e */;
        v0 = 1;
        v0 = new java.lang.String[][size=v0];
        v0[v1] = v5;
        return v0;
        v2 = new java.util.ArrayList;
        _result = v2.<init>(); // java.util.ArrayList.<init> -> void
        v4 = v1;
        v1 = v0;
        v0 = v4;
        if (v1 == v3) /* goto L_0029 */;
        _result = v5.substring(v0, v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        _result = java.util.List.add(v2, v0); // -> boolean
        _result = v6.length(); // java.lang.String.length -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        _result = v5.indexOf(v6, v0); // java.lang.String.indexOf -> int
        v1 = _result;
        // goto L_0016
        _result = v5.length(); // java.lang.String.length -> int
        v1 = _result;
        if (v0 == v1) /* goto L_0036 */;
        _result = v5.substring(v0); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        _result = java.util.List.add(v2, v0); // -> boolean
        _result = java.util.List.size(v2); // -> int
        v0 = _result;
        v0 = new java.lang.String[][size=v0];
        _result = java.util.List.toArray(v2, v0); // -> java.lang.Object[]
        v0 = _result;
        v0 = (java.lang.String[]) v0;
        // goto L_000d
    }

}