package b.d.c;

/**
 * Original SourceFile: Logger.java
 * Descriptor: Lb/d/c/a;
 */
public abstract class a {
    private static final b.d.c.b a;

    static {
        v0 = 0;
        v1 = "twitter4j.loggerFactory";
        _result = v1.getProperty(); // java.lang.System.getProperty -> java.lang.String
        v1 = _result;
        if (v1 == 0) /* goto L_000e */;
        _result = v1.b(v1); // b.d.c.a.b -> b.d.c.b
        v0 = _result;
        _result = this.a(); // b.c.b.a -> b.c.a
        v1 = _result;
        _result = b.c.a.l(v1); // -> java.lang.String
        v2 = _result;
        if (v2 == 0) /* goto L_001c */;
        _result = v2.b(v2); // b.d.c.a.b -> b.d.c.b
        v0 = _result;
        if (v0 != 0) /* goto L_0028 */;
        v0 = "org.slf4j.impl.StaticLoggerBinder";
        v2 = "twitter4j.internal.logging.SLF4JLoggerFactory";
        _result = v0.b(v2); // b.d.c.a.b -> b.d.c.b
        v0 = _result;
        if (v0 != 0) /* goto L_0034 */;
        v0 = "org.apache.commons.logging.Log";
        v2 = "twitter4j.internal.logging.CommonsLoggingLoggerFactory";
        _result = v0.b(v2); // b.d.c.a.b -> b.d.c.b
        v0 = _result;
        if (v0 != 0) /* goto L_0040 */;
        v0 = "org.apache.log4j.Logger";
        v2 = "twitter4j.internal.logging.Log4JLoggerFactory";
        _result = v0.b(v2); // b.d.c.a.b -> b.d.c.b
        v0 = _result;
        if (v0 != 0) /* goto L_004c */;
        v0 = "com.google.appengine.api.urlfetch.URLFetchService";
        v2 = "twitter4j.internal.logging.JULLoggerFactory";
        _result = v0.b(v2); // b.d.c.a.b -> b.d.c.b
        v0 = _result;
        if (v0 != 0) /* goto L_0053 */;
        v0 = new b.d.c.d;
        _result = v0.<init>(); // b.d.c.d.<init> -> void
        b.d.c.a.a = v0; // :b.d.c.b
        _result = v1.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        v2 = "dumpConfiguration";
        v3 = 0;
        v3 = new java.lang.Class[][size=v3];
        _result = v0.getMethod(v2, v3); // java.lang.Class.getMethod -> java.lang.reflect.Method
        v0 = _result;
        v2 = 1;
        _result = v0.setAccessible(v2); // java.lang.reflect.Method.setAccessible -> void
        v2 = 0;
        v2 = new java.lang.Object[][size=v2];
        _result = v0.invoke(v1, v2); // java.lang.reflect.Method.invoke -> java.lang.Object
        return;
        v0 = _exception;
        // goto L_006d
        v0 = _exception;
        // goto L_006d
        v0 = _exception;
        // goto L_006d
    }

    public a() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static b.d.c.a a(java.lang.Class p0) {
        // Registers (2 total): v1 = p0 (java.lang.Class)
        v0 = b.d.c.a.a; // :b.d.c.b
        _result = v0.a(v1); // b.d.c.b.a -> b.d.c.a
        v0 = _result;
        return v0;
    }

    private static b.d.c.b b(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        _result = v2.forName(); // java.lang.Class.forName -> java.lang.Class
        _result = v3.forName(); // java.lang.Class.forName -> java.lang.Class
        v0 = _result;
        _result = v0.newInstance(); // java.lang.Class.newInstance -> java.lang.Object
        v0 = _result;
        v0 = (b.d.c.b) v0;
        return v0;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v0 = 0;
        // goto L_000d
        v0 = _exception;
        // goto L_001d
    }

    public abstract void a(java.lang.String p0);
    public abstract void a(java.lang.String p0, java.lang.String p1);
    public abstract void a(java.lang.String p0, java.lang.Throwable p1);
    public abstract boolean a();
}