package b.d.c;

/**
 * Original SourceFile: StdOutLogger.java
 * Descriptor: Lb/d/c/c;
 */
final class c extends b.d.c.a {
    private static final boolean a;

    static {
        _result = this.a(); // b.c.b.a -> b.c.a
        v0 = _result;
        _result = b.c.a.c(v0); // -> boolean
        v0 = _result;
        b.d.c.c.a = v0; // :boolean
        return;
    }

    c() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // b.d.c.a.<init> -> void
        return;
    }

    public void a(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        v0 = b.d.c.c.a; // :boolean
        if (v0 == 0) /* goto L_002d */;
        v0 = java.lang.System.out; // :java.io.PrintStream
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = new java.util.Date;
        _result = v2.<init>(); // java.util.Date.<init> -> void
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "]";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.println(v1); // java.io.PrintStream.println -> void
        return;
    }

    public void a(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        v0 = b.d.c.c.a; // :boolean
        if (v0 == 0) /* goto L_0018 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.a(v0); // b.d.c.c.a -> void
        return;
    }

    public void a(java.lang.String p0, java.lang.Throwable p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.Throwable)
        v0 = java.lang.System.out; // :java.io.PrintStream
        _result = v0.println(v2); // java.io.PrintStream.println -> void
        v0 = java.lang.System.err; // :java.io.PrintStream
        _result = v3.printStackTrace(v0); // java.lang.Throwable.printStackTrace -> void
        return;
    }

    public boolean a() {
        // Registers (2 total): v1 = this
        v0 = b.d.c.c.a; // :boolean
        return v0;
    }

}