package b.d.c;

/**
 * Original SourceFile: StdOutLoggerFactory.java
 * Descriptor: Lb/d/c/d;
 */
final class d extends b.d.c.b {
    private static final b.d.c.a a;

    static {
        v0 = new b.d.c.c;
        _result = v0.<init>(); // b.d.c.c.<init> -> void
        b.d.c.d.a = v0; // :b.d.c.a
        return;
    }

    d() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // b.d.c.b.<init> -> void
        return;
    }

    public b.d.c.a a(java.lang.Class p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Class)
        v0 = b.d.c.d.a; // :b.d.c.a
        return v0;
    }

}