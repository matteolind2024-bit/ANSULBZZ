package b.d.c;

/**
 * Original SourceFile: LoggerFactory.java
 * Descriptor: Lb/d/c/b;
 */
public abstract class b {
    public b() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public abstract b.d.c.a a(java.lang.Class p0);
}