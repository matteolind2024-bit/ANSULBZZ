package b.d.d.a;

/**
 * Original SourceFile: JSONObject.java
 * Descriptor: Lb/d/d/a/e;
 */
final class e {
    private e() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    e(b.d.d.a.d p0) {
        // Registers (2 total): v0 = this, v1 = p0 (b.d.d.a.d)
        _result = v0.<init>(); // b.d.d.a.e.<init> -> void
        return;
    }

    protected final java.lang.Object clone() {
        // Registers (1 total): v0 = this
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        if (v2 == 0) /* goto L_0004 */;
        if (v2 != v1) /* goto L_0006 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0005
    }

    public java.lang.String toString() {
        // Registers (2 total): v1 = this
        v0 = "null";
        return v0;
    }

}