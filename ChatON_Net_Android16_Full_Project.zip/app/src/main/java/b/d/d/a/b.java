package b.d.d.a;

/**
 * Original SourceFile: JSONException.java
 * Descriptor: Lb/d/d/a/b;
 */
public class b extends java.lang.Exception {
    private java.lang.Throwable a;

    public b(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        _result = v0.<init>(v1); // java.lang.Exception.<init> -> void
        return;
    }

    public b(java.lang.Throwable p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Throwable)
        _result = v2.getMessage(); // java.lang.Throwable.getMessage -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.Exception.<init> -> void
        v1.a = v2; // b.d.d.a.b.a:java.lang.Throwable
        return;
    }

    public java.lang.Throwable getCause() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // b.d.d.a.b.a:java.lang.Throwable
        return v0;
    }

}