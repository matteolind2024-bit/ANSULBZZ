package b.d.d.a;

/**
 * Original SourceFile: JSONTokener.java
 * Descriptor: Lb/d/d/a/f;
 */
public class f {
    private int a;
    private boolean b;
    private int c;
    private int d;
    private char e;
    private java.io.Reader f;
    private boolean g;

    public f(java.io.Reader p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.io.Reader)
        v2 = 1;
        v1 = 0;
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        _result = v4.markSupported(); // java.io.Reader.markSupported -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001a */;
        v3.f = v4; // b.d.d.a.f.f:java.io.Reader
        v3.b = v1; // b.d.d.a.f.b:boolean
        v3.g = v1; // b.d.d.a.f.g:boolean
        v3.e = v1; // b.d.d.a.f.e:char
        v3.c = v1; // b.d.d.a.f.c:int
        v3.a = v2; // b.d.d.a.f.a:int
        v3.d = v2; // b.d.d.a.f.d:int
        return;
        v0 = new java.io.BufferedReader;
        _result = v0.<init>(v4); // java.io.BufferedReader.<init> -> void
        v4 = v0;
        // goto L_000b
    }

    public f(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = new java.io.StringReader;
        _result = v0.<init>(v2); // java.io.StringReader.<init> -> void
        _result = v1.<init>(v0); // b.d.d.a.f.<init> -> void
        return;
    }

    public b.d.d.a.b a(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        v0 = new b.d.d.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v3.toString(); // b.d.d.a.f.toString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        return v0;
    }

    public java.lang.String a(char p0) {
        // Registers (5 total): v3 = this, v4 = p0 (char)
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v3.c(); // b.d.d.a.f.c -> char
        v1 = _result;
        // switch(v1)
        if (v1 != v4) /* goto L_005c */;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v0 = "Unterminated string";
        _result = v3.a(v0); // b.d.d.a.f.a -> b.d.d.a.b
        v0 = _result;
        throw v0;
        _result = v3.c(); // b.d.d.a.f.c -> char
        v1 = _result;
        // switch(v1)
        v0 = "Illegal escape.";
        _result = v3.a(v0); // b.d.d.a.f.a -> b.d.d.a.b
        v0 = _result;
        throw v0;
        v1 = 8;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0005
        v1 = 9;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0005
        v1 = 10;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0005
        v1 = 12;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0005
        v1 = 13;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0005
        v1 = 4;
        _result = v3.a(v1); // b.d.d.a.f.a -> java.lang.String
        v1 = _result;
        v2 = 16;
        _result = v1.parseInt(v2); // java.lang.Integer.parseInt -> int
        v1 = _result;
        v1 = unaryOp_0x8e(v1);
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0005
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0005
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0005
    }

    public java.lang.String a(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        if (v4 != 0) /* goto L_0006 */;
        v0 = "";
        return v0;
        v1 = new char[][size=v4];
        v0 = 0;
        if (v0 >= v4) /* goto L_0022 */;
        _result = v3.c(); // b.d.d.a.f.c -> char
        v2 = _result;
        v1[v0] = v2;
        _result = v3.b(); // b.d.d.a.f.b -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_001f */;
        v0 = "Substring bounds error";
        _result = v3.a(v0); // b.d.d.a.f.a -> b.d.d.a.b
        v0 = _result;
        throw v0;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0009
        v0 = new java.lang.String;
        _result = v0.<init>(v1); // java.lang.String.<init> -> void
        // goto L_0005
    }

    public void a() {
        // Registers (3 total): v2 = this
        v0 = v2.g; // b.d.d.a.f.g:boolean
        if (v0 != 0) /* goto L_0008 */;
        v0 = v2.c; // b.d.d.a.f.c:int
        if (v0 > 0) /* goto L_0011 */;
        v0 = new b.d.d.a.b;
        v1 = "Stepping back two steps is not supported";
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
        v0 = v2.c; // b.d.d.a.f.c:int
        v0 = binOpLit8_0xd8(v0, -1);
        v2.c = v0; // b.d.d.a.f.c:int
        v0 = v2.a; // b.d.d.a.f.a:int
        v0 = binOpLit8_0xd8(v0, -1);
        v2.a = v0; // b.d.d.a.f.a:int
        v0 = 1;
        v2.g = v0; // b.d.d.a.f.g:boolean
        v0 = 0;
        v2.b = v0; // b.d.d.a.f.b:boolean
        return;
    }

    public boolean b() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // b.d.d.a.f.b:boolean
        if (v0 == 0) /* goto L_000a */;
        v0 = v1.g; // b.d.d.a.f.g:boolean
        if (v0 != 0) /* goto L_000a */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0009
    }

    public char c() {
        // Registers (7 total): v6 = this
        v5 = 10;
        v2 = 1;
        v1 = 0;
        v0 = v6.g; // b.d.d.a.f.g:boolean
        if (v0 == 0) /* goto L_0028 */;
        v6.g = v1; // b.d.d.a.f.g:boolean
        v0 = v6.e; // b.d.d.a.f.e:char
        v3 = v6.c; // b.d.d.a.f.c:int
        v3 = binOpLit8_0xd8(v3, 1);
        v6.c = v3; // b.d.d.a.f.c:int
        v3 = v6.e; // b.d.d.a.f.e:char
        v4 = 13;
        if (v3 != v4) /* goto L_003d */;
        v3 = v6.d; // b.d.d.a.f.d:int
        v3 = binOpLit8_0xd8(v3, 1);
        v6.d = v3; // b.d.d.a.f.d:int
        if (v0 != v5) /* goto L_003b */;
        v6.a = v1; // b.d.d.a.f.a:int
        v0 = unaryOp_0x8e(v0);
        v6.e = v0; // b.d.d.a.f.e:char
        v0 = v6.e; // b.d.d.a.f.e:char
        return v0;
        v0 = v6.f; // b.d.d.a.f.f:java.io.Reader
        _result = v0.read(); // java.io.Reader.read -> int
        v0 = _result;
        if (v0 > 0) /* goto L_000c */;
        v6.b = v2; // b.d.d.a.f.b:boolean
        v0 = v1;
        // goto L_000c
        v0 = _exception;
        v1 = new b.d.d.a.b;
        _result = v1.<init>(v0); // b.d.d.a.b.<init> -> void
        throw v1;
        v1 = v2;
        // goto L_0020
        if (v0 != v5) /* goto L_0048 */;
        v2 = v6.d; // b.d.d.a.f.d:int
        v2 = binOpLit8_0xd8(v2, 1);
        v6.d = v2; // b.d.d.a.f.d:int
        v6.a = v1; // b.d.d.a.f.a:int
        // goto L_0022
        v1 = v6.a; // b.d.d.a.f.a:int
        v1 = binOpLit8_0xd8(v1, 1);
        v6.a = v1; // b.d.d.a.f.a:int
        // goto L_0022
    }

    public char d() {
        // Registers (3 total): v2 = this
        _result = v2.c(); // b.d.d.a.f.c -> char
        v0 = _result;
        if (v0 == 0) /* goto L_000a */;
        v1 = 32;
        if (v0 <= v1) /* goto L_0000 */;
        return v0;
    }

    public java.lang.Object e() {
        // Registers (4 total): v3 = this
        _result = v3.d(); // b.d.d.a.f.d -> char
        v0 = _result;
        // switch(v0)
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = 32;
        if (v0 < v2) /* goto L_0038 */;
        v2 = ",:]}/\\\"[{;=#";
        _result = v2.indexOf(v0); // java.lang.String.indexOf -> int
        v2 = _result;
        if (v2 >= 0) /* goto L_0038 */;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v3.c(); // b.d.d.a.f.c -> char
        v0 = _result;
        // goto L_000c
        _result = v3.a(v0); // b.d.d.a.f.a -> java.lang.String
        v0 = _result;
        return v0;
        _result = v3.a(); // b.d.d.a.f.a -> void
        v0 = new b.d.d.a.c;
        _result = v0.<init>(v3); // b.d.d.a.c.<init> -> void
        // goto L_0025
        _result = v3.a(); // b.d.d.a.f.a -> void
        v0 = new b.d.d.a.a;
        _result = v0.<init>(v3); // b.d.d.a.a.<init> -> void
        // goto L_0025
        _result = v3.a(); // b.d.d.a.f.a -> void
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.trim(); // java.lang.String.trim -> java.lang.String
        v0 = _result;
        v1 = "";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0054 */;
        v0 = "Missing value";
        _result = v3.a(v0); // b.d.d.a.f.a -> b.d.d.a.b
        v0 = _result;
        throw v0;
        _result = v0.h(); // b.d.d.a.c.h -> java.lang.Object
        v0 = _result;
        // goto L_0025
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = " at ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.c; // b.d.d.a.f.c:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " [character ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.a; // b.d.d.a.f.a:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = " line ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.d; // b.d.d.a.f.d:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "]";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}