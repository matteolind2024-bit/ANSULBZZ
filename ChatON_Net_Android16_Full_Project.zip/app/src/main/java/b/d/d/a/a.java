package b.d.d.a;

/**
 * Original SourceFile: JSONArray.java
 * Descriptor: Lb/d/d/a/a;
 */
public class a {
    private java.util.ArrayList a;

    public a() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.a = v0; // b.d.d.a.a.a:java.util.ArrayList
        return;
    }

    public a(b.d.d.a.f p0) {
        // Registers (5 total): v3 = this, v4 = p0 (b.d.d.a.f)
        v2 = 93;
        _result = v3.<init>(); // b.d.d.a.a.<init> -> void
        _result = v4.d(); // b.d.d.a.f.d -> char
        v0 = _result;
        v1 = 91;
        if (v0 == v1) /* goto L_0015 */;
        v0 = "A JSONArray text must start with '['";
        _result = v4.a(v0); // b.d.d.a.f.a -> b.d.d.a.b
        v0 = _result;
        throw v0;
        _result = v4.d(); // b.d.d.a.f.d -> char
        v0 = _result;
        if (v0 == v2) /* goto L_0052 */;
        _result = v4.a(); // b.d.d.a.f.a -> void
        _result = v4.d(); // b.d.d.a.f.d -> char
        v0 = _result;
        v1 = 44;
        if (v0 != v1) /* goto L_003f */;
        _result = v4.a(); // b.d.d.a.f.a -> void
        v0 = v3.a; // b.d.d.a.a.a:java.util.ArrayList
        v1 = b.d.d.a.c.a; // :java.lang.Object
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        _result = v4.d(); // b.d.d.a.f.d -> char
        v0 = _result;
        // switch(v0)
        v0 = "Expected a ',' or ']'";
        _result = v4.a(v0); // b.d.d.a.f.a -> b.d.d.a.b
        v0 = _result;
        throw v0;
        _result = v4.a(); // b.d.d.a.f.a -> void
        v0 = v3.a; // b.d.d.a.a.a:java.util.ArrayList
        _result = v4.e(); // b.d.d.a.f.e -> java.lang.Object
        v1 = _result;
        _result = v0.add(v1); // java.util.ArrayList.add -> boolean
        // goto L_0030
        _result = v4.d(); // b.d.d.a.f.d -> char
        v0 = _result;
        if (v0 != v2) /* goto L_0053 */;
        return;
        _result = v4.a(); // b.d.d.a.f.a -> void
        // goto L_001e
    }

    public a(java.lang.Object p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.Object)
        _result = v3.<init>(); // b.d.d.a.a.<init> -> void
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.isArray(); // java.lang.Class.isArray -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0022 */;
        _result = v4.getLength(); // java.lang.reflect.Array.getLength -> int
        v1 = _result;
        v0 = 0;
        if (v0 >= v1) /* goto L_002b */;
        _result = v4.get(v0); // java.lang.reflect.Array.get -> java.lang.Object
        v2 = _result;
        _result = v2.c(); // b.d.d.a.c.c -> java.lang.Object
        v2 = _result;
        _result = v3.a(v2); // b.d.d.a.a.a -> b.d.d.a.a
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0012
        v0 = new b.d.d.a.b;
        v1 = "JSONArray initial value should be a string or collection or array.";
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
        return;
    }

    public a(java.util.Collection p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.util.Collection)
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v3.a = v0; // b.d.d.a.a.a:java.util.ArrayList
        if (v4 == 0) /* goto L_0024 */;
        _result = java.util.Collection.iterator(v4); // -> java.util.Iterator
        v0 = _result;
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0024 */;
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v1 = _result;
        v2 = v3.a; // b.d.d.a.a.a:java.util.ArrayList
        _result = v1.c(); // b.d.d.a.c.c -> java.lang.Object
        v1 = _result;
        _result = v2.add(v1); // java.util.ArrayList.add -> boolean
        // goto L_0010
        return;
    }

    public int a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // b.d.d.a.a.a:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        return v0;
    }

    public b.d.d.a.a a(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = v1.a; // b.d.d.a.a.a:java.util.ArrayList
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        return v1;
    }

    public java.lang.Object a(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        _result = v3.c(v4); // b.d.d.a.a.c -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_0027 */;
        v0 = new b.d.d.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "JSONArray[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "] not found.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
        return v0;
    }

    public java.lang.String a(java.lang.String p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.String)
        _result = v4.a(); // b.d.d.a.a.a -> int
        v1 = _result;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v0 = 0;
        if (v0 >= v1) /* goto L_0021 */;
        if (v0 <= 0) /* goto L_0011 */;
        _result = v2.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = v4.a; // b.d.d.a.a.a:java.util.ArrayList
        _result = v3.get(v0); // java.util.ArrayList.get -> java.lang.Object
        v3 = _result;
        _result = v3.b(); // b.d.d.a.c.b -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_000a
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public b.d.d.a.c b(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        _result = v3.a(v4); // b.d.d.a.a.a -> java.lang.Object
        v0 = _result;
        v1 = (v0 instanceof b.d.d.a.c);
        if (v1 == 0) /* goto L_000b */;
        v0 = (b.d.d.a.c) v0;
        return v0;
        v0 = new b.d.d.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "JSONArray[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "] is not a JSONObject.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
    }

    public java.lang.Object c(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        if (v2 < 0) /* goto L_0008 */;
        _result = v1.a(); // b.d.d.a.a.a -> int
        v0 = _result;
        if (v2 < v0) /* goto L_000a */;
        v0 = 0;
        return v0;
        v0 = v1.a; // b.d.d.a.a.a:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        // goto L_0009
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = 91;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ",";
        _result = v2.a(v1); // b.d.d.a.a.a -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 93;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v0 = _exception;
        v0 = 0;
        // goto L_0020
    }

}