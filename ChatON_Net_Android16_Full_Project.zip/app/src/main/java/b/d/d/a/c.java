package b.d.d.a;

/**
 * Original SourceFile: JSONObject.java
 * Descriptor: Lb/d/d/a/c;
 */
public class c {
    public static final java.lang.Object a;
    private java.util.Map b;

    static {
        v0 = new b.d.d.a.e;
        v1 = 0;
        _result = v0.<init>(v1); // b.d.d.a.e.<init> -> void
        b.d.d.a.c.a = v0; // :java.lang.Object
        return;
    }

    public c() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        v1.b = v0; // b.d.d.a.c.b:java.util.Map
        return;
    }

    public c(b.d.d.a.f p0) {
        // Registers (5 total): v3 = this, v4 = p0 (b.d.d.a.f)
        _result = v3.<init>(); // b.d.d.a.c.<init> -> void
        _result = v4.d(); // b.d.d.a.f.d -> char
        v0 = _result;
        v1 = 123;
        if (v0 == v1) /* goto L_002b */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "A JSONObject text must begin with '{' found:";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.d(); // b.d.d.a.f.d -> char
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v4.a(v0); // b.d.d.a.f.a -> b.d.d.a.b
        v0 = _result;
        throw v0;
        _result = v4.a(); // b.d.d.a.f.a -> void
        _result = v4.d(); // b.d.d.a.f.d -> char
        v0 = _result;
        // switch(v0)
        _result = v4.a(); // b.d.d.a.f.a -> void
        _result = v4.e(); // b.d.d.a.f.e -> java.lang.Object
        v0 = _result;
        _result = v0.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        _result = v4.d(); // b.d.d.a.f.d -> char
        v1 = _result;
        v2 = 61;
        if (v1 != v2) /* goto L_006e */;
        _result = v4.c(); // b.d.d.a.f.c -> char
        v1 = _result;
        v2 = 62;
        if (v1 == v2) /* goto L_0050 */;
        _result = v4.a(); // b.d.d.a.f.a -> void
        _result = v4.e(); // b.d.d.a.f.e -> java.lang.Object
        v1 = _result;
        _result = v3.b(v0, v1); // b.d.d.a.c.b -> b.d.d.a.c
        _result = v4.d(); // b.d.d.a.f.d -> char
        v0 = _result;
        // switch(v0)
        v0 = "Expected a ',' or '}'";
        _result = v4.a(v0); // b.d.d.a.f.a -> b.d.d.a.b
        v0 = _result;
        throw v0;
        v0 = "A JSONObject text must end with '}'";
        _result = v4.a(v0); // b.d.d.a.f.a -> b.d.d.a.b
        v0 = _result;
        throw v0;
        v2 = 58;
        if (v1 == v2) /* goto L_0050 */;
        v0 = "Expected a ':' after a key";
        _result = v4.a(v0); // b.d.d.a.f.a -> b.d.d.a.b
        v0 = _result;
        throw v0;
        _result = v4.d(); // b.d.d.a.f.d -> char
        v0 = _result;
        v1 = 125;
        if (v0 != v1) /* goto L_0028 */;
        return;
    }

    public c(java.lang.Object p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.Object)
        _result = v0.<init>(); // b.d.d.a.c.<init> -> void
        _result = v0.d(v1); // b.d.d.a.c.d -> void
        return;
    }

    public c(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = new b.d.d.a.f;
        _result = v0.<init>(v2); // b.d.d.a.f.<init> -> void
        _result = v1.<init>(v0); // b.d.d.a.c.<init> -> void
        return;
    }

    public c(java.util.Map p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.util.Map)
        _result = v4.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        v4.b = v0; // b.d.d.a.c.b:java.util.Map
        if (v5 == 0) /* goto L_0034 */;
        _result = java.util.Map.entrySet(v5); // -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v1 = _result;
        _result = java.util.Iterator.hasNext(v1); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0034 */;
        _result = java.util.Iterator.next(v1); // -> java.lang.Object
        v0 = _result;
        v0 = (java.util.Map$Entry) v0;
        _result = java.util.Map$Entry.getValue(v0); // -> java.lang.Object
        v2 = _result;
        if (v2 == 0) /* goto L_0014 */;
        v3 = v4.b; // b.d.d.a.c.b:java.util.Map
        _result = java.util.Map$Entry.getKey(v0); // -> java.lang.Object
        v0 = _result;
        _result = v2.c(); // b.d.d.a.c.c -> java.lang.Object
        v2 = _result;
        _result = java.util.Map.put(v3, v0, v2); // -> java.lang.Object
        // goto L_0014
        return;
    }

    public static java.lang.String a(java.lang.Number p0) {
        // Registers (4 total): v3 = p0 (java.lang.Number)
        v2 = 0;
        if (v3 != 0) /* goto L_000c */;
        v0 = new b.d.d.a.b;
        v1 = "Null pointer";
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
        _result = v3.a(); // b.d.d.a.c.a -> void
        _result = v3.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        v1 = 46;
        _result = v0.indexOf(v1); // java.lang.String.indexOf -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_0052 */;
        v1 = 101;
        _result = v0.indexOf(v1); // java.lang.String.indexOf -> int
        v1 = _result;
        if (v1 >= 0) /* goto L_0052 */;
        v1 = 69;
        _result = v0.indexOf(v1); // java.lang.String.indexOf -> int
        v1 = _result;
        if (v1 >= 0) /* goto L_0052 */;
        v1 = "0";
        _result = v0.endsWith(v1); // java.lang.String.endsWith -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_003f */;
        _result = v0.length(); // java.lang.String.length -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        _result = v0.substring(v2, v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        // goto L_002b
        v1 = ".";
        _result = v0.endsWith(v1); // java.lang.String.endsWith -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0052 */;
        _result = v0.length(); // java.lang.String.length -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        _result = v0.substring(v2, v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static void a(java.lang.Object p0) {
        // Registers (3 total): v2 = p0 (java.lang.Object)
        if (v2 == 0) /* goto L_003e */;
        v0 = (v2 instanceof java.lang.Double);
        if (v0 == 0) /* goto L_0020 */;
        v0 = v2;
        v0 = (java.lang.Double) v0;
        _result = v0.isInfinite(); // java.lang.Double.isInfinite -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        v2 = (java.lang.Double) v2;
        _result = v2.isNaN(); // java.lang.Double.isNaN -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003e */;
        v0 = new b.d.d.a.b;
        v1 = "JSON does not allow non-finite numbers.";
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
        v0 = (v2 instanceof java.lang.Float);
        if (v0 == 0) /* goto L_003e */;
        v0 = v2;
        v0 = (java.lang.Float) v0;
        _result = v0.isInfinite(); // java.lang.Float.isInfinite -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0035 */;
        v2 = (java.lang.Float) v2;
        _result = v2.isNaN(); // java.lang.Float.isNaN -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003e */;
        v0 = new b.d.d.a.b;
        v1 = "JSON does not allow non-finite numbers.";
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
        return;
    }

    public static java.lang.String b(java.lang.Object p0) {
        // Registers (2 total): v1 = p0 (java.lang.Object)
        if (v1 == 0) /* goto L_0009 */;
        v0 = 0;
        _result = v1.equals(v0); // java.lang.Object.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000d */;
        v0 = "null";
        return v0;
        v0 = (v1 instanceof java.lang.Number);
        if (v0 == 0) /* goto L_0018 */;
        v1 = (java.lang.Number) v1;
        _result = v1.a(); // b.d.d.a.c.a -> java.lang.String
        v0 = _result;
        // goto L_000c
        v0 = (v1 instanceof java.lang.Boolean);
        if (v0 != 0) /* goto L_0024 */;
        v0 = (v1 instanceof b.d.d.a.c);
        if (v0 != 0) /* goto L_0024 */;
        v0 = (v1 instanceof b.d.d.a.a);
        if (v0 == 0) /* goto L_0029 */;
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        // goto L_000c
        v0 = (v1 instanceof java.util.Map);
        if (v0 == 0) /* goto L_0039 */;
        v0 = new b.d.d.a.c;
        v1 = (java.util.Map) v1;
        _result = v0.<init>(v1); // b.d.d.a.c.<init> -> void
        _result = v0.toString(); // b.d.d.a.c.toString -> java.lang.String
        v0 = _result;
        // goto L_000c
        v0 = (v1 instanceof java.util.Collection);
        if (v0 == 0) /* goto L_0049 */;
        v0 = new b.d.d.a.a;
        v1 = (java.util.Collection) v1;
        _result = v0.<init>(v1); // b.d.d.a.a.<init> -> void
        _result = v0.toString(); // b.d.d.a.a.toString -> java.lang.String
        v0 = _result;
        // goto L_000c
        _result = v1.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.isArray(); // java.lang.Class.isArray -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_005d */;
        v0 = new b.d.d.a.a;
        _result = v0.<init>(v1); // b.d.d.a.a.<init> -> void
        _result = v0.toString(); // b.d.d.a.a.toString -> java.lang.String
        v0 = _result;
        // goto L_000c
        _result = v1.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        _result = v0.f(); // b.d.d.a.c.f -> java.lang.String
        v0 = _result;
        // goto L_000c
    }

    public static java.lang.Object c(java.lang.Object p0) {
        // Registers (3 total): v2 = p0 (java.lang.Object)
        if (v2 != 0) /* goto L_0005 */;
        v2 = b.d.d.a.c.a; // :java.lang.Object
        return v2;
        v0 = (v2 instanceof b.d.d.a.c);
        if (v0 != 0) /* goto L_0004 */;
        v0 = (v2 instanceof b.d.d.a.a);
        if (v0 != 0) /* goto L_0004 */;
        v0 = b.d.d.a.c.a; // :java.lang.Object
        _result = v0.equals(v2); // java.lang.Object.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0004 */;
        v0 = (v2 instanceof java.lang.Byte);
        if (v0 != 0) /* goto L_0004 */;
        v0 = (v2 instanceof java.lang.Character);
        if (v0 != 0) /* goto L_0004 */;
        v0 = (v2 instanceof java.lang.Short);
        if (v0 != 0) /* goto L_0004 */;
        v0 = (v2 instanceof java.lang.Integer);
        if (v0 != 0) /* goto L_0004 */;
        v0 = (v2 instanceof java.lang.Long);
        if (v0 != 0) /* goto L_0004 */;
        v0 = (v2 instanceof java.lang.Boolean);
        if (v0 != 0) /* goto L_0004 */;
        v0 = (v2 instanceof java.lang.Float);
        if (v0 != 0) /* goto L_0004 */;
        v0 = (v2 instanceof java.lang.Double);
        if (v0 != 0) /* goto L_0004 */;
        v0 = (v2 instanceof java.lang.String);
        if (v0 != 0) /* goto L_0004 */;
        v0 = (v2 instanceof java.util.Collection);
        if (v0 == 0) /* goto L_0046 */;
        v0 = new b.d.d.a.a;
        v2 = (java.util.Collection) v2;
        _result = v0.<init>(v2); // b.d.d.a.a.<init> -> void
        v2 = v0;
        // goto L_0004
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.isArray(); // java.lang.Class.isArray -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0057 */;
        v0 = new b.d.d.a.a;
        _result = v0.<init>(v2); // b.d.d.a.a.<init> -> void
        v2 = v0;
        // goto L_0004
        v0 = (v2 instanceof java.util.Map);
        if (v0 == 0) /* goto L_0064 */;
        v0 = new b.d.d.a.c;
        v2 = (java.util.Map) v2;
        _result = v0.<init>(v2); // b.d.d.a.c.<init> -> void
        v2 = v0;
        // goto L_0004
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getPackage(); // java.lang.Class.getPackage -> java.lang.Package
        v0 = _result;
        if (v0 == 0) /* goto L_0094 */;
        _result = v0.getName(); // java.lang.Package.getName -> java.lang.String
        v0 = _result;
        v1 = "java.";
        _result = v0.startsWith(v1); // java.lang.String.startsWith -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_008e */;
        v1 = "javax.";
        _result = v0.startsWith(v1); // java.lang.String.startsWith -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_008e */;
        _result = v2.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.getClassLoader(); // java.lang.Class.getClassLoader -> java.lang.ClassLoader
        v0 = _result;
        if (v0 != 0) /* goto L_0098 */;
        _result = v2.toString(); // java.lang.Object.toString -> java.lang.String
        v2 = _result;
        // goto L_0004
        v0 = "";
        // goto L_0072
        v0 = new b.d.d.a.c;
        _result = v0.<init>(v2); // b.d.d.a.c.<init> -> void
        v2 = v0;
        // goto L_0004
        v0 = _exception;
        v2 = 0;
        // goto L_0004
    }

    private void d(java.lang.Object p0) {
        // Registers (10 total): v8 = this, v9 = p0 (java.lang.Object)
        v2 = 0;
        v4 = 1;
        _result = v9.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v1.getClassLoader(); // java.lang.Class.getClassLoader -> java.lang.ClassLoader
        v0 = _result;
        if (v0 == 0) /* goto L_0081 */;
        v0 = v4;
        if (v0 == 0) /* goto L_0083 */;
        _result = v1.getMethods(); // java.lang.Class.getMethods -> java.lang.reflect.Method[]
        v0 = _result;
        v1 = v0;
        v0 = v1.length;
        if (v2 >= v0) /* goto L_00cb */;
        v5 = v1[v2];
        _result = v5.getModifiers(); // java.lang.reflect.Method.getModifiers -> int
        v0 = _result;
        _result = v0.isPublic(); // java.lang.reflect.Modifier.isPublic -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_007d */;
        _result = v5.getName(); // java.lang.reflect.Method.getName -> java.lang.String
        v3 = _result;
        v0 = "";
        v6 = "get";
        _result = v3.startsWith(v6); // java.lang.String.startsWith -> boolean
        v6 = _result;
        if (v6 == 0) /* goto L_008f */;
        v0 = "getClass";
        _result = v3.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0045 */;
        v0 = "getDeclaringClass";
        _result = v3.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0089 */;
        v0 = "";
        _result = v0.length(); // java.lang.String.length -> int
        v3 = _result;
        if (v3 <= 0) /* goto L_007d */;
        v3 = 0;
        _result = v0.charAt(v3); // java.lang.String.charAt -> char
        v3 = _result;
        _result = v3.isUpperCase(); // java.lang.Character.isUpperCase -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_007d */;
        _result = v5.getParameterTypes(); // java.lang.reflect.Method.getParameterTypes -> java.lang.Class[]
        v3 = _result;
        v3 = v3.length;
        if (v3 != 0) /* goto L_007d */;
        _result = v0.length(); // java.lang.String.length -> int
        v3 = _result;
        if (v3 != v4) /* goto L_009e */;
        _result = v0.toLowerCase(); // java.lang.String.toLowerCase -> java.lang.String
        v0 = _result;
        v3 = v0;
        v0 = 0;
        v0 = (java.lang.Object[]) v0;
        _result = v5.invoke(v9, v0); // java.lang.reflect.Method.invoke -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_007d */;
        v5 = v8.b; // b.d.d.a.c.b:java.util.Map
        _result = v0.c(); // b.d.d.a.c.c -> java.lang.Object
        v0 = _result;
        _result = java.util.Map.put(v5, v3, v0); // -> java.lang.Object
        v0 = binOpLit8_0xd8(v2, 1);
        v2 = v0;
        // goto L_0014
        v0 = v2;
        // goto L_000d
        _result = v1.getDeclaredMethods(); // java.lang.Class.getDeclaredMethods -> java.lang.reflect.Method[]
        v0 = _result;
        v1 = v0;
        // goto L_0014
        v0 = 3;
        _result = v3.substring(v0); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        // goto L_0048
        v6 = "is";
        _result = v3.startsWith(v6); // java.lang.String.startsWith -> boolean
        v6 = _result;
        if (v6 == 0) /* goto L_0048 */;
        v0 = 2;
        _result = v3.substring(v0); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        // goto L_0048
        v3 = 1;
        _result = v0.charAt(v3); // java.lang.String.charAt -> char
        v3 = _result;
        _result = v3.isUpperCase(); // java.lang.Character.isUpperCase -> boolean
        v3 = _result;
        if (v3 != 0) /* goto L_00ce */;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = 0;
        v7 = 1;
        _result = v0.substring(v6, v7); // java.lang.String.substring -> java.lang.String
        v6 = _result;
        _result = v6.toLowerCase(); // java.lang.String.toLowerCase -> java.lang.String
        v6 = _result;
        _result = v3.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v6 = 1;
        _result = v0.substring(v6); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v3 = v0;
        // goto L_006b
        return;
        v0 = _exception;
        // goto L_007d
        v3 = v0;
        // goto L_006b
    }

    public static java.lang.String f(java.lang.String p0) {
        // Registers (10 total): v9 = p0 (java.lang.String)
        v8 = 92;
        v7 = 34;
        v0 = 0;
        if (v9 == 0) /* goto L_000d */;
        _result = v9.length(); // java.lang.String.length -> int
        v1 = _result;
        if (v1 != 0) /* goto L_0011 */;
        v0 = "\"\"";
        return v0;
        _result = v9.length(); // java.lang.String.length -> int
        v3 = _result;
        v4 = new java.lang.StringBuilder;
        v1 = binOpLit8_0xd8(v3, 4);
        _result = v4.<init>(v1); // java.lang.StringBuilder.<init> -> void
        _result = v4.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = v0;
        if (v0 >= v3) /* goto L_00a6 */;
        _result = v9.charAt(v0); // java.lang.String.charAt -> char
        v2 = _result;
        // switch(v2)
        v1 = 32;
        if (v2 < v1) /* goto L_003d */;
        v1 = 128;
        if (v2 < v1) /* goto L_0035 */;
        v1 = 160;
        if (v2 < v1) /* goto L_003d */;
        v1 = 8192;
        if (v2 < v1) /* goto L_00a2 */;
        v1 = 8448;
        if (v2 >= v1) /* goto L_00a2 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "000";
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v2.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v5 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        v5 = "\\u";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v1.length(); // java.lang.String.length -> int
        v6 = _result;
        v6 = binOpLit8_0xd8(v6, -4);
        _result = v1.substring(v6); // java.lang.String.substring -> java.lang.String
        v1 = _result;
        _result = v5.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = binOpLit8_0xd8(v0, 1);
        v1 = v2;
        // goto L_0020
        _result = v4.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0069
        v5 = 60;
        if (v1 != v5) /* goto L_007b */;
        _result = v4.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0069
        v1 = "\\b";
        _result = v4.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0069
        v1 = "\\t";
        _result = v4.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0069
        v1 = "\\n";
        _result = v4.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0069
        v1 = "\\f";
        _result = v4.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0069
        v1 = "\\r";
        _result = v4.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0069
        _result = v4.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0069
        _result = v4.append(v7); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0010
    }

    public static java.lang.Object h(java.lang.String p0) {
        // Registers (8 total): v7 = p0 (java.lang.String)
        v6 = 48;
        v5 = 46;
        v4 = 2;
        v3 = 1;
        v2 = -1;
        v0 = "";
        _result = v7.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0011 */;
        return v7;
        v0 = "true";
        _result = v7.equalsIgnoreCase(v0); // java.lang.String.equalsIgnoreCase -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001d */;
        v7 = java.lang.Boolean.TRUE; // :java.lang.Boolean
        // goto L_0010
        v0 = "false";
        _result = v7.equalsIgnoreCase(v0); // java.lang.String.equalsIgnoreCase -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0029 */;
        v7 = java.lang.Boolean.FALSE; // :java.lang.Boolean
        // goto L_0010
        v0 = "null";
        _result = v7.equalsIgnoreCase(v0); // java.lang.String.equalsIgnoreCase -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0035 */;
        v7 = b.d.d.a.c.a; // :java.lang.Object
        // goto L_0010
        v0 = 0;
        _result = v7.charAt(v0); // java.lang.String.charAt -> char
        v0 = _result;
        if (v0 < v6) /* goto L_0040 */;
        v1 = 57;
        if (v0 <= v1) /* goto L_004a */;
        if (v0 == v5) /* goto L_004a */;
        v1 = 45;
        if (v0 == v1) /* goto L_004a */;
        v1 = 43;
        if (v0 != v1) /* goto L_0010 */;
        if (v0 != v6) /* goto L_0073 */;
        _result = v7.length(); // java.lang.String.length -> int
        v0 = _result;
        if (v0 <= v4) /* goto L_0073 */;
        _result = v7.charAt(v3); // java.lang.String.charAt -> char
        v0 = _result;
        v1 = 120;
        if (v0 == v1) /* goto L_0062 */;
        _result = v7.charAt(v3); // java.lang.String.charAt -> char
        v0 = _result;
        v1 = 88;
        if (v0 != v1) /* goto L_0073 */;
        v0 = 2;
        _result = v7.substring(v0); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        v1 = 16;
        _result = v0.parseInt(v1); // java.lang.Integer.parseInt -> int
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v7 = _result;
        // goto L_0010
        v0 = _exception;
        v0 = 46;
        _result = v7.indexOf(v0); // java.lang.String.indexOf -> int
        v0 = _result;
        if (v0 > v2) /* goto L_008b */;
        v0 = 101;
        _result = v7.indexOf(v0); // java.lang.String.indexOf -> int
        v0 = _result;
        if (v0 > v2) /* goto L_008b */;
        v0 = 69;
        _result = v7.indexOf(v0); // java.lang.String.indexOf -> int
        v0 = _result;
        if (v0 <= v2) /* goto L_0090 */;
        _result = v7.valueOf(); // java.lang.Double.valueOf -> java.lang.Double
        v7 = _result;
        // goto L_0010
        v0 = new java.lang.Long;
        _result = v0.<init>(v7); // java.lang.Long.<init> -> void
        _result = v0.longValue(); // java.lang.Long.longValue -> long
        v1 = _result;
        _result = v0.intValue(); // java.lang.Long.intValue -> int
        v3 = _result;
        v3 = unaryOp_0x81(v3);
        v1 = cmp(v1, v3);
        if (v1 != 0) /* goto L_00ac */;
        _result = v0.intValue(); // java.lang.Long.intValue -> int
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v7 = _result;
        // goto L_0010
        v7 = v0;
        // goto L_0010
        v0 = _exception;
        // goto L_0010
    }

    public b.d.d.a.c a(java.lang.String p0, java.lang.Object p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.String), v4 = p1 (java.lang.Object)
        if (v3 != 0) /* goto L_000b */;
        v0 = new b.d.d.a.b;
        v1 = "Null key.";
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
        if (v4 == 0) /* goto L_0016 */;
        _result = v4.a(); // b.d.d.a.c.a -> void
        v0 = v2.b; // b.d.d.a.c.b:java.util.Map
        _result = java.util.Map.put(v0, v3, v4); // -> java.lang.Object
        return v2;
        _result = v2.g(v3); // b.d.d.a.c.g -> java.lang.Object
        // goto L_0015
    }

    public java.lang.Object a(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        if (v4 != 0) /* goto L_000b */;
        v0 = new b.d.d.a.b;
        v1 = "Null key.";
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
        _result = v3.e(v4); // b.d.d.a.c.e -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_0036 */;
        v0 = new b.d.d.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "JSONObject[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v4.f(); // b.d.d.a.c.f -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "] not found.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
        return v0;
    }

    public java.util.Iterator a() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // b.d.d.a.c.b:java.util.Map
        _result = java.util.Map.keySet(v0); // -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v0 = _result;
        return v0;
    }

    public b.d.d.a.a b(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        _result = v3.a(v4); // b.d.d.a.c.a -> java.lang.Object
        v0 = _result;
        v1 = (v0 instanceof b.d.d.a.a);
        if (v1 == 0) /* goto L_000b */;
        v0 = (b.d.d.a.a) v0;
        return v0;
        v0 = new b.d.d.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "JSONObject[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v4.f(); // b.d.d.a.c.f -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "] is not a JSONArray.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
    }

    public b.d.d.a.c b(java.lang.String p0, java.lang.Object p1) {
        // Registers (6 total): v3 = this, v4 = p0 (java.lang.String), v5 = p1 (java.lang.Object)
        if (v4 == 0) /* goto L_002e */;
        if (v5 == 0) /* goto L_002e */;
        _result = v3.e(v4); // b.d.d.a.c.e -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_002b */;
        v0 = new b.d.d.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Duplicate key \"";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "\"";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // b.d.d.a.b.<init> -> void
        throw v0;
        _result = v3.a(v4, v5); // b.d.d.a.c.a -> b.d.d.a.c
        return v3;
    }

    public java.lang.String c(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        _result = v2.a(v3); // b.d.d.a.c.a -> java.lang.Object
        v0 = _result;
        v1 = b.d.d.a.c.a; // :java.lang.Object
        if (v0 != v1) /* goto L_000a */;
        v0 = 0;
        return v0;
        _result = v0.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        // goto L_0009
    }

    public boolean d(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = b.d.d.a.c.a; // :java.lang.Object
        _result = v2.e(v3); // b.d.d.a.c.e -> java.lang.Object
        v1 = _result;
        _result = v0.equals(v1); // java.lang.Object.equals -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.Object e(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0004 */;
        v0 = 0;
        return v0;
        v0 = v1.b; // b.d.d.a.c.b:java.util.Map
        _result = java.util.Map.get(v0, v2); // -> java.lang.Object
        v0 = _result;
        // goto L_0003
    }

    public java.lang.Object g(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.b; // b.d.d.a.c.b:java.util.Map
        _result = java.util.Map.remove(v0, v2); // -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.String toString() {
        // Registers (5 total): v4 = this
        _result = v4.a(); // b.d.d.a.c.a -> java.util.Iterator
        v0 = _result;
        v1 = new java.lang.StringBuilder;
        v2 = "{";
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0043 */;
        _result = v1.length(); // java.lang.StringBuilder.length -> int
        v2 = _result;
        v3 = 1;
        if (v2 <= v3) /* goto L_001e */;
        v2 = 44;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v2 = _result;
        _result = v2.toString(); // java.lang.Object.toString -> java.lang.String
        v3 = _result;
        _result = v3.f(); // b.d.d.a.c.f -> java.lang.String
        v3 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = 58;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = v4.b; // b.d.d.a.c.b:java.util.Map
        _result = java.util.Map.get(v3, v2); // -> java.lang.Object
        v2 = _result;
        _result = v2.b(); // b.d.d.a.c.b -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_000c
        v0 = _exception;
        v0 = 0;
        return v0;
        v0 = 125;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0042
    }

}