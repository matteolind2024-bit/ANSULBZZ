package b.d.d.a;

/**
 * Original SourceFile: JSONObject.java
 * Descriptor: Lb/d/d/a/d;
 */
class d {
}