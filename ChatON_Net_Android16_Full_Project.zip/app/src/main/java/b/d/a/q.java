package b.d.a;

/**
 * Original SourceFile: StreamingGZIPInputStream.java
 * Descriptor: Lb/d/a/q;
 */
final class q extends java.util.zip.GZIPInputStream {
    private final java.io.InputStream a;

    public q(java.io.InputStream p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.io.InputStream)
        _result = v0.<init>(v1); // java.util.zip.GZIPInputStream.<init> -> void
        v0.a = v1; // b.d.a.q.a:java.io.InputStream
        return;
    }

    public int available() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // b.d.a.q.a:java.io.InputStream
        _result = v0.available(); // java.io.InputStream.available -> int
        v0 = _result;
        return v0;
    }

}