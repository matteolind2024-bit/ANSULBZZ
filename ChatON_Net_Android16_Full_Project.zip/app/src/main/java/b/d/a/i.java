package b.d.a;

/**
 * Original SourceFile: HttpClientWrapperConfiguration.java
 * Descriptor: Lb/d/a/i;
 */
public interface i extends b.d.a.d {
    public abstract java.util.Map u();
}