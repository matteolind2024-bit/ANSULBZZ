package b.d.a;

/**
 * Original SourceFile: HttpClientFactory.java
 * Descriptor: Lb/d/a/e;
 */
public final class e {
    private static final java.lang.reflect.Constructor a;

    static {
        v0 = 0;
        v1 = "twitter4j.http.httpClient";
        _result = v1.getProperty(); // java.lang.System.getProperty -> java.lang.String
        v1 = _result;
        if (v1 == 0) /* goto L_000e */;
        _result = v1.forName(); // java.lang.Class.forName -> java.lang.Class
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        v1 = "twitter4j.internal.http.alternative.HttpClientImpl";
        _result = v1.forName(); // java.lang.Class.forName -> java.lang.Class
        v0 = _result;
        if (v0 != 0) /* goto L_0020 */;
        v0 = "b.d.a.f";
        _result = v0.forName(); // java.lang.Class.forName -> java.lang.Class
        v0 = _result;
        v1 = 1;
        v1 = new java.lang.Class[][size=v1];
        v2 = 0;
        v3 = b.d.a.d.class;
        v1[v2] = v3;
        _result = v0.getConstructor(v1); // java.lang.Class.getConstructor -> java.lang.reflect.Constructor
        v0 = _result;
        b.d.a.e.a = v0; // :java.lang.reflect.Constructor
        return;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v1 = _exception;
        // goto L_000e
        v1 = _exception;
        // goto L_0017
    }

    public static b.d.a.b a(b.d.a.d p0) {
        // Registers (4 total): v3 = p0 (b.d.a.d)
        v0 = b.d.a.e.a; // :java.lang.reflect.Constructor
        v1 = 1;
        v1 = new java.lang.Object[][size=v1];
        v2 = 0;
        v1[v2] = v3;
        _result = v0.newInstance(v1); // java.lang.reflect.Constructor.newInstance -> java.lang.Object
        v0 = _result;
        v0 = (b.d.a.b) v0;
        return v0;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
    }

}