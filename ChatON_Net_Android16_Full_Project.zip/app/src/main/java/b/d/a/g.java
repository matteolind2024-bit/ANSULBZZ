package b.d.a;

/**
 * Original SourceFile: HttpClientImpl.java
 * Descriptor: Lb/d/a/g;
 */
class g extends java.net.Authenticator {
    final b.d.a.f a;

    g(b.d.a.f p0) {
        // Registers (2 total): v0 = this, v1 = p0 (b.d.a.f)
        v0.a = v1; // b.d.a.g.a:b.d.a.f
        _result = v0.<init>(); // java.net.Authenticator.<init> -> void
        return;
    }

    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        // Registers (4 total): v3 = this
        _result = v3.getRequestorType(); // b.d.a.g.getRequestorType -> java.net.Authenticator$RequestorType
        v0 = _result;
        v1 = java.net.Authenticator$RequestorType.PROXY; // :java.net.Authenticator$RequestorType
        _result = v0.equals(v1); // java.net.Authenticator$RequestorType.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0026 */;
        v0 = new java.net.PasswordAuthentication;
        v1 = v3.a; // b.d.a.g.a:b.d.a.f
        v1 = v1.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.o(v1); // -> java.lang.String
        v1 = _result;
        v2 = v3.a; // b.d.a.g.a:b.d.a.f
        v2 = v2.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.p(v2); // -> java.lang.String
        v2 = _result;
        _result = v2.toCharArray(); // java.lang.String.toCharArray -> char[]
        v2 = _result;
        _result = v0.<init>(v1, v2); // java.net.PasswordAuthentication.<init> -> void
        return v0;
        v0 = 0;
        // goto L_0025
    }

}