package b.d.a;

/**
 * Original SourceFile: RequestMethod.java
 * Descriptor: Lb/d/a/p;
 */
public final enum p {
    public static final b.d.a.p a;
    public static final b.d.a.p b;
    public static final b.d.a.p c;
    public static final b.d.a.p d;
    public static final b.d.a.p e;
    private static final b.d.a.p[] f;

    static {
        v6 = 4;
        v5 = 3;
        v4 = 2;
        v3 = 1;
        v2 = 0;
        v0 = new b.d.a.p;
        v1 = "GET";
        _result = v0.<init>(v1, v2); // b.d.a.p.<init> -> void
        b.d.a.p.a = v0; // :b.d.a.p
        v0 = new b.d.a.p;
        v1 = "POST";
        _result = v0.<init>(v1, v3); // b.d.a.p.<init> -> void
        b.d.a.p.b = v0; // :b.d.a.p
        v0 = new b.d.a.p;
        v1 = "DELETE";
        _result = v0.<init>(v1, v4); // b.d.a.p.<init> -> void
        b.d.a.p.c = v0; // :b.d.a.p
        v0 = new b.d.a.p;
        v1 = "HEAD";
        _result = v0.<init>(v1, v5); // b.d.a.p.<init> -> void
        b.d.a.p.d = v0; // :b.d.a.p
        v0 = new b.d.a.p;
        v1 = "PUT";
        _result = v0.<init>(v1, v6); // b.d.a.p.<init> -> void
        b.d.a.p.e = v0; // :b.d.a.p
        v0 = 5;
        v0 = new b.d.a.p[][size=v0];
        v1 = b.d.a.p.a; // :b.d.a.p
        v0[v2] = v1;
        v1 = b.d.a.p.b; // :b.d.a.p
        v0[v3] = v1;
        v1 = b.d.a.p.c; // :b.d.a.p
        v0[v4] = v1;
        v1 = b.d.a.p.d; // :b.d.a.p
        v0[v5] = v1;
        v1 = b.d.a.p.e; // :b.d.a.p
        v0[v6] = v1;
        b.d.a.p.f = v0; // :b.d.a.p[]
        return;
    }

    private p(java.lang.String p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        return;
    }

    public static b.d.a.p valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = b.d.a.p.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (b.d.a.p) v0;
        return v0;
    }

    public static b.d.a.p[] values() {
        v0 = b.d.a.p.f; // :b.d.a.p[]
        _result = v0.clone(); // b.d.a.p[].clone -> java.lang.Object
        v0 = _result;
        v0 = (b.d.a.p[]) v0;
        return v0;
    }

}