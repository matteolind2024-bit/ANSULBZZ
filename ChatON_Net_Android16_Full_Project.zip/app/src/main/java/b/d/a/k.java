package b.d.a;

/**
 * Original SourceFile: HttpRequest.java
 * Descriptor: Lb/d/a/k;
 */
public final class k implements java.io.Serializable {
    private static final b.d.a.j[] f;
    private final b.d.a.p a;
    private final java.lang.String b;
    private final b.d.a.j[] c;
    private final b.b.b d;
    private java.util.Map e;

    static {
        v0 = 0;
        v0 = new b.d.a.j[][size=v0];
        b.d.a.k.f = v0; // :b.d.a.j[]
        return;
    }

    public k(b.d.a.p p0, java.lang.String p1, b.d.a.j[] p2, b.b.b p3, java.util.Map p4) {
        // Registers (8 total): v2 = this, v3 = p0 (b.d.a.p), v4 = p1 (java.lang.String), v5 = p2 (b.d.a.j[]), v6 = p3 (b.b.b), v7 = p4 (java.util.Map)
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.a = v3; // b.d.a.k.a:b.d.a.p
        v0 = b.d.a.p.b; // :b.d.a.p
        if (v3 == v0) /* goto L_0035 */;
        if (v5 == 0) /* goto L_0035 */;
        v0 = v5.length;
        if (v0 == 0) /* goto L_0035 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "?";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v5.b(); // b.d.a.j.b -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v2.b = v0; // b.d.a.k.b:java.lang.String
        v0 = b.d.a.k.f; // :b.d.a.j[]
        v2.c = v0; // b.d.a.k.c:b.d.a.j[]
        v2.d = v6; // b.d.a.k.d:b.b.b
        v2.e = v7; // b.d.a.k.e:java.util.Map
        return;
        v2.b = v4; // b.d.a.k.b:java.lang.String
        v2.c = v5; // b.d.a.k.c:b.d.a.j[]
        // goto L_0030
    }

    public b.d.a.p a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // b.d.a.k.a:b.d.a.p
        return v0;
    }

    public b.d.a.j[] b() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // b.d.a.k.c:b.d.a.j[]
        return v0;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // b.d.a.k.b:java.lang.String
        return v0;
    }

    public b.b.b d() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // b.d.a.k.d:b.b.b
        return v0;
    }

    public java.util.Map e() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // b.d.a.k.e:java.util.Map
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        if (v5 == 0) /* goto L_0011 */;
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0013 */;
        v0 = v1;
        // goto L_0004
        v5 = (b.d.a.k) v5;
        v2 = v4.d; // b.d.a.k.d:b.b.b
        if (v2 == 0) /* goto L_0025 */;
        v2 = v4.d; // b.d.a.k.d:b.b.b
        v3 = v5.d; // b.d.a.k.d:b.b.b
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0029 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.d; // b.d.a.k.d:b.b.b
        if (v2 != 0) /* goto L_0023 */;
        v2 = v4.c; // b.d.a.k.c:b.d.a.j[]
        v3 = v5.c; // b.d.a.k.c:b.d.a.j[]
        _result = v2.equals(v3); // java.util.Arrays.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0035 */;
        v0 = v1;
        // goto L_0004
        v2 = v4.e; // b.d.a.k.e:java.util.Map
        if (v2 == 0) /* goto L_0045 */;
        v2 = v4.e; // b.d.a.k.e:java.util.Map
        v3 = v5.e; // b.d.a.k.e:java.util.Map
        _result = java.util.Map.equals(v2, v3); // -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0049 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.e; // b.d.a.k.e:java.util.Map
        if (v2 != 0) /* goto L_0043 */;
        v2 = v4.a; // b.d.a.k.a:b.d.a.p
        if (v2 == 0) /* goto L_0059 */;
        v2 = v4.a; // b.d.a.k.a:b.d.a.p
        v3 = v5.a; // b.d.a.k.a:b.d.a.p
        _result = v2.equals(v3); // b.d.a.p.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_005d */;
        v0 = v1;
        // goto L_0004
        v2 = v5.a; // b.d.a.k.a:b.d.a.p
        if (v2 != 0) /* goto L_0057 */;
        v2 = v4.b; // b.d.a.k.b:java.lang.String
        if (v2 == 0) /* goto L_006d */;
        v2 = v4.b; // b.d.a.k.b:java.lang.String
        v3 = v5.b; // b.d.a.k.b:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.b; // b.d.a.k.b:java.lang.String
        if (v2 == 0) /* goto L_0004 */;
        // goto L_006b
    }

    public int hashCode() {
        // Registers (4 total): v3 = this
        v1 = 0;
        v0 = v3.a; // b.d.a.k.a:b.d.a.p
        if (v0 == 0) /* goto L_0040 */;
        v0 = v3.a; // b.d.a.k.a:b.d.a.p
        _result = v0.hashCode(); // b.d.a.p.hashCode -> int
        v0 = _result;
        v2 = binOpLit8_0xda(v0, 31);
        v0 = v3.b; // b.d.a.k.b:java.lang.String
        if (v0 == 0) /* goto L_0042 */;
        v0 = v3.b; // b.d.a.k.b:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = binOpLit8_0xda(v0, 31);
        v0 = v3.c; // b.d.a.k.c:b.d.a.j[]
        if (v0 == 0) /* goto L_0044 */;
        v0 = v3.c; // b.d.a.k.c:b.d.a.j[]
        _result = v0.hashCode(); // java.util.Arrays.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = binOpLit8_0xda(v0, 31);
        v0 = v3.d; // b.d.a.k.d:b.b.b
        if (v0 == 0) /* goto L_0046 */;
        v0 = v3.d; // b.d.a.k.d:b.b.b
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v0 = binOpLit8_0xda(v0, 31);
        v2 = v3.e; // b.d.a.k.e:java.util.Map
        if (v2 == 0) /* goto L_003e */;
        v1 = v3.e; // b.d.a.k.e:java.util.Map
        _result = java.util.Map.hashCode(v1); // -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v0 = v1;
        // goto L_000b
        v0 = v1;
        // goto L_0017
        v0 = v1;
        // goto L_0024
        v0 = v1;
        // goto L_0031
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "HttpRequest{requestMethod=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.a; // b.d.a.k.a:b.d.a.p
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", url='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.b; // b.d.a.k.b:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 39;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", postParams=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v0 = v2.c; // b.d.a.k.c:b.d.a.j[]
        if (v0 != 0) /* goto L_005a */;
        v0 = 0;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", authentication=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.d; // b.d.a.k.d:b.b.b
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", requestHeaders=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.e; // b.d.a.k.e:java.util.Map
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v0 = v2.c; // b.d.a.k.c:b.d.a.j[]
        _result = v0.asList(); // java.util.Arrays.asList -> java.util.List
        v0 = _result;
        // goto L_0031
    }

}