package b.d.a;

/**
 * Original SourceFile: HttpResponseImpl.java
 * Descriptor: Lb/d/a/n;
 */
public class n extends b.d.a.l {
    private java.net.HttpURLConnection e;

    n(java.net.HttpURLConnection p0, b.d.a.d p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.net.HttpURLConnection), v4 = p1 (b.d.a.d)
        _result = v2.<init>(v4); // b.d.a.l.<init> -> void
        v2.e = v3; // b.d.a.n.e:java.net.HttpURLConnection
        _result = v3.getResponseCode(); // java.net.HttpURLConnection.getResponseCode -> int
        v0 = _result;
        v2.b = v0; // b.d.a.n.b:int
        _result = v3.getErrorStream(); // java.net.HttpURLConnection.getErrorStream -> java.io.InputStream
        v0 = _result;
        v2.d = v0; // b.d.a.n.d:java.io.InputStream
        if (v0 != 0) /* goto L_0019 */;
        _result = v3.getInputStream(); // java.net.HttpURLConnection.getInputStream -> java.io.InputStream
        v0 = _result;
        v2.d = v0; // b.d.a.n.d:java.io.InputStream
        v0 = v2.d; // b.d.a.n.d:java.io.InputStream
        if (v0 == 0) /* goto L_0033 */;
        v0 = "gzip";
        _result = v3.getContentEncoding(); // java.net.HttpURLConnection.getContentEncoding -> java.lang.String
        v1 = _result;
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0033 */;
        v0 = new b.d.a.q;
        v1 = v2.d; // b.d.a.n.d:java.io.InputStream
        _result = v0.<init>(v1); // b.d.a.q.<init> -> void
        v2.d = v0; // b.d.a.n.d:java.io.InputStream
        return;
    }

    public java.lang.String a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.e; // b.d.a.n.e:java.net.HttpURLConnection
        _result = v0.getHeaderField(v2); // java.net.HttpURLConnection.getHeaderField -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void d() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // b.d.a.n.e:java.net.HttpURLConnection
        _result = v0.disconnect(); // java.net.HttpURLConnection.disconnect -> void
        return;
    }

}