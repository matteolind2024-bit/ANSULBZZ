package b.d.a;

/**
 * Original SourceFile: HttpResponseEvent.java
 * Descriptor: Lb/d/a/m;
 */
public final class m {
    private b.d.a.k a;
    private b.d.a.l b;
    private b.g c;

    m(b.d.a.k p0, b.d.a.l p1, b.g p2) {
        // Registers (4 total): v0 = this, v1 = p0 (b.d.a.k), v2 = p1 (b.d.a.l), v3 = p2 (b.g)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // b.d.a.m.a:b.d.a.k
        v0.b = v2; // b.d.a.m.b:b.d.a.l
        v0.c = v3; // b.d.a.m.c:b.g
        return;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        if (v5 == 0) /* goto L_0011 */;
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0013 */;
        v0 = v1;
        // goto L_0004
        v5 = (b.d.a.m) v5;
        v2 = v4.a; // b.d.a.m.a:b.d.a.k
        if (v2 == 0) /* goto L_0025 */;
        v2 = v4.a; // b.d.a.m.a:b.d.a.k
        v3 = v5.a; // b.d.a.m.a:b.d.a.k
        _result = v2.equals(v3); // b.d.a.k.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0029 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.a; // b.d.a.m.a:b.d.a.k
        if (v2 != 0) /* goto L_0023 */;
        v2 = v4.b; // b.d.a.m.b:b.d.a.l
        if (v2 == 0) /* goto L_0039 */;
        v2 = v4.b; // b.d.a.m.b:b.d.a.l
        v3 = v5.b; // b.d.a.m.b:b.d.a.l
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.b; // b.d.a.m.b:b.d.a.l
        if (v2 == 0) /* goto L_0004 */;
        // goto L_0037
    }

    public int hashCode() {
        // Registers (4 total): v3 = this
        v1 = 0;
        v0 = v3.a; // b.d.a.m.a:b.d.a.k
        if (v0 == 0) /* goto L_0019 */;
        v0 = v3.a; // b.d.a.m.a:b.d.a.k
        _result = v0.hashCode(); // b.d.a.k.hashCode -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 31);
        v2 = v3.b; // b.d.a.m.b:b.d.a.l
        if (v2 == 0) /* goto L_0017 */;
        v1 = v3.b; // b.d.a.m.b:b.d.a.l
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v0 = v1;
        // goto L_000b
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "HttpResponseEvent{request=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.a; // b.d.a.m.a:b.d.a.k
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", response=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.b; // b.d.a.m.b:b.d.a.l
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}