package b.d.a;

/**
 * Original SourceFile: BASE64Encoder.java
 * Descriptor: Lb/d/a/a;
 */
public final class a {
    private static final char a;
    private static final char b;
    private static final char c;
    private static final char d;
    private static final char e;
    private static final char f;
    private static final char[] g;

    static {
        v1 = 2;
        v0 = "00000011";
        _result = v0.parseInt(v1); // java.lang.Integer.parseInt -> int
        v0 = _result;
        v0 = unaryOp_0x8e(v0);
        b.d.a.a.a = v0; // :char
        v0 = "00001111";
        _result = v0.parseInt(v1); // java.lang.Integer.parseInt -> int
        v0 = _result;
        v0 = unaryOp_0x8e(v0);
        b.d.a.a.b = v0; // :char
        v0 = "00111111";
        _result = v0.parseInt(v1); // java.lang.Integer.parseInt -> int
        v0 = _result;
        v0 = unaryOp_0x8e(v0);
        b.d.a.a.c = v0; // :char
        v0 = "11111100";
        _result = v0.parseInt(v1); // java.lang.Integer.parseInt -> int
        v0 = _result;
        v0 = unaryOp_0x8e(v0);
        b.d.a.a.d = v0; // :char
        v0 = "11110000";
        _result = v0.parseInt(v1); // java.lang.Integer.parseInt -> int
        v0 = _result;
        v0 = unaryOp_0x8e(v0);
        b.d.a.a.e = v0; // :char
        v0 = "11000000";
        _result = v0.parseInt(v1); // java.lang.Integer.parseInt -> int
        v0 = _result;
        v0 = unaryOp_0x8e(v0);
        b.d.a.a.f = v0; // :char
        v0 = 64;
        v0 = new char[][size=v0];
        b.d.a.a.g = v0; // :char[]
        return;
    }

    public static java.lang.String a(byte[] p0) {
        // Registers (7 total): v6 = p0 (byte[])
        v0 = 0;
        v3 = new java.lang.StringBuilder;
        v1 = v6.length;
        v1 = unaryOp_0x83(v1);
        v4 = 0x3ff570a3d70a3d71L;
        v1 = binOp2addr_0xcd(v1, v4);
        v1 = unaryOp_0x8a(v1);
        v1 = binOpLit8_0xd8(v1, 3);
        _result = v3.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = v0;
        v2 = v0;
        v4 = v6.length;
        if (v0 >= v4) /* goto L_0071 */;
        v2 = binOpLit8_0xdc(v2, 8);
        v4 = 8;
        if (v2 >= v4) /* goto L_006e */;
        // switch(v2)
        v4 = b.d.a.a.g; // :char[]
        v4 = v4[v1];
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = binOpLit8_0xd8(v2, 6);
        // goto L_0018
        v1 = v6[v0];
        v4 = b.d.a.a.d; // :char
        v1 = binOp2addr_0xb5(v1, v4);
        v1 = unaryOp_0x8e(v1);
        v1 = binOpLit8_0xe2(v1, 2);
        v1 = unaryOp_0x8e(v1);
        // goto L_001f
        v1 = v6[v0];
        v4 = b.d.a.a.c; // :char
        v1 = binOp2addr_0xb5(v1, v4);
        v1 = unaryOp_0x8e(v1);
        // goto L_001f
        v1 = v6[v0];
        v4 = b.d.a.a.b; // :char
        v1 = binOp2addr_0xb5(v1, v4);
        v1 = unaryOp_0x8e(v1);
        v1 = binOpLit8_0xe0(v1, 2);
        v1 = unaryOp_0x8e(v1);
        v4 = binOpLit8_0xd8(v0, 1);
        v5 = v6.length;
        if (v4 >= v5) /* goto L_001f */;
        v4 = binOpLit8_0xd8(v0, 1);
        v4 = v6[v4];
        v5 = b.d.a.a.f; // :char
        v4 = binOp2addr_0xb5(v4, v5);
        v4 = binOpLit8_0xe2(v4, 6);
        v1 = binOp2addr_0xb6(v1, v4);
        v1 = unaryOp_0x8e(v1);
        // goto L_001f
        v1 = v6[v0];
        v4 = b.d.a.a.a; // :char
        v1 = binOp2addr_0xb5(v1, v4);
        v1 = unaryOp_0x8e(v1);
        v1 = binOpLit8_0xe0(v1, 4);
        v1 = unaryOp_0x8e(v1);
        v4 = binOpLit8_0xd8(v0, 1);
        v5 = v6.length;
        if (v4 >= v5) /* goto L_001f */;
        v4 = binOpLit8_0xd8(v0, 1);
        v4 = v6[v4];
        v5 = b.d.a.a.e; // :char
        v4 = binOp2addr_0xb5(v4, v5);
        v4 = binOpLit8_0xe2(v4, 4);
        v1 = binOp2addr_0xb6(v1, v4);
        v1 = unaryOp_0x8e(v1);
        // goto L_001f
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0013
        _result = v3.length(); // java.lang.StringBuilder.length -> int
        v0 = _result;
        v0 = binOpLit8_0xdc(v0, 4);
        if (v0 == 0) /* goto L_008c */;
        _result = v3.length(); // java.lang.StringBuilder.length -> int
        v0 = _result;
        v0 = binOpLit8_0xdc(v0, 4);
        v0 = binOpLit8_0xd9(v0, 4);
        if (v0 <= 0) /* goto L_008c */;
        v1 = "=";
        _result = v3.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = binOpLit8_0xd8(v0, -1);
        // goto L_0081
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}