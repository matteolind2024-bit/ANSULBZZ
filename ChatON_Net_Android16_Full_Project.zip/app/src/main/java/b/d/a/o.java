package b.d.a;

/**
 * Original SourceFile: HttpResponseListener.java
 * Descriptor: Lb/d/a/o;
 */
public interface o {
    public abstract void a(b.d.a.m p0);
}