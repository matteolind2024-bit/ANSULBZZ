package b.d.a;

/**
 * Original SourceFile: HttpResponse.java
 * Descriptor: Lb/d/a/l;
 */
public abstract class l {
    private static final b.d.c.a e;
    protected final b.d.a.d a;
    protected int b;
    protected java.lang.String c;
    protected java.io.InputStream d;
    private boolean f;
    private b.d.d.a.c g;
    private b.d.d.a.a h;

    static {
        v0 = b.d.a.n.class;
        _result = v0.a(); // b.d.c.a.a -> b.d.c.a
        v0 = _result;
        b.d.a.l.e = v0; // :b.d.c.a
        return;
    }

    public l(b.d.a.d p0) {
        // Registers (4 total): v2 = this, v3 = p0 (b.d.a.d)
        v1 = 0;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.c = v1; // b.d.a.l.c:java.lang.String
        v0 = 0;
        v2.f = v0; // b.d.a.l.f:boolean
        v2.g = v1; // b.d.a.l.g:b.d.d.a.c
        v2.h = v1; // b.d.a.l.h:b.d.d.a.a
        v2.a = v3; // b.d.a.l.a:b.d.a.d
        return;
    }

    private void e() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // b.d.a.l.d -> void
        return;
        v0 = _exception;
        // goto L_0003
    }

    public int a() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // b.d.a.l.b:int
        return v0;
    }

    public abstract java.lang.String a(java.lang.String p0);
    public java.io.InputStream b() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // b.d.a.l.f:boolean
        if (v0 == 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Stream has already been consumed.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v2.d; // b.d.a.l.d:java.io.InputStream
        return v0;
    }

    public java.lang.String c() {
        // Registers (7 total): v6 = this
        v0 = 0;
        v1 = v6.c; // b.d.a.l.c:java.lang.String
        if (v1 != 0) /* goto L_007d */;
        v1 = 0;
        _result = v6.b(); // b.d.a.l.b -> java.io.InputStream
        v2 = _result;
        if (v2 != 0) /* goto L_001a */;
        if (v2 == 0) /* goto L_0011 */;
        _result = v2.close(); // java.io.InputStream.close -> void
        if (v0 == 0) /* goto L_0016 */;
        _result = v1.close(); // java.io.BufferedReader.close -> void
        _result = v6.e(); // b.d.a.l.e -> void
        return v0;
        v1 = new java.io.BufferedReader;
        v3 = new java.io.InputStreamReader;
        v4 = "UTF-8";
        _result = v3.<init>(v2, v4); // java.io.InputStreamReader.<init> -> void
        _result = v1.<init>(v3); // java.io.BufferedReader.<init> -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.readLine(); // java.io.BufferedReader.readLine -> java.lang.String
        v3 = _result;
        if (v3 == 0) /* goto L_005d */;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = "\n";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_002c
        v0 = _exception;
        v5 = v2;
        v2 = v1;
        v1 = v5;
        v3 = new b.g;
        _result = v0.getMessage(); // java.io.IOException.getMessage -> java.lang.String
        v4 = _result;
        _result = v3.<init>(v4, v0); // b.g.<init> -> void
        throw v3;
        v0 = _exception;
        v5 = v1;
        v1 = v2;
        v2 = v5;
        if (v2 == 0) /* goto L_0054 */;
        _result = v2.close(); // java.io.InputStream.close -> void
        if (v1 == 0) /* goto L_0059 */;
        _result = v1.close(); // java.io.BufferedReader.close -> void
        _result = v6.e(); // b.d.a.l.e -> void
        throw v0;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v6.c = v0; // b.d.a.l.c:java.lang.String
        v0 = b.d.a.l.e; // :b.d.c.a
        v3 = v6.c; // b.d.a.l.c:java.lang.String
        _result = v0.a(v3); // b.d.c.a.a -> void
        _result = v2.close(); // java.io.InputStream.close -> void
        v0 = 1;
        v6.f = v0; // b.d.a.l.f:boolean
        if (v2 == 0) /* goto L_0075 */;
        _result = v2.close(); // java.io.InputStream.close -> void
        if (v1 == 0) /* goto L_007a */;
        _result = v1.close(); // java.io.BufferedReader.close -> void
        _result = v6.e(); // b.d.a.l.e -> void
        v0 = v6.c; // b.d.a.l.c:java.lang.String
        // goto L_0019
        v2 = _exception;
        // goto L_0011
        v1 = _exception;
        // goto L_0016
        v0 = _exception;
        // goto L_0075
        v0 = _exception;
        // goto L_007a
        v2 = _exception;
        // goto L_0054
        v1 = _exception;
        // goto L_0059
        v1 = _exception;
        v2 = v0;
        v5 = v1;
        v1 = v0;
        v0 = v5;
        // goto L_004f
        v1 = _exception;
        v5 = v1;
        v1 = v0;
        v0 = v5;
        // goto L_004f
        v0 = _exception;
        // goto L_004f
        v1 = _exception;
        v2 = v0;
        v5 = v0;
        v0 = v1;
        v1 = v5;
        // goto L_0041
        v1 = _exception;
        v5 = v1;
        v1 = v2;
        v2 = v0;
        v0 = v5;
        // goto L_0041
    }

    public abstract void d();
    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "HttpResponse{statusCode=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.b; // b.d.a.l.b:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", responseAsString='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.c; // b.d.a.l.c:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 39;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", is=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.d; // b.d.a.l.d:java.io.InputStream
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", streamConsumed=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.f; // b.d.a.l.f:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}