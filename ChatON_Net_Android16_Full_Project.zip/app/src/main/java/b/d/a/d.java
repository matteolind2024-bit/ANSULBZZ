package b.d.a;

/**
 * Original SourceFile: HttpClientConfiguration.java
 * Descriptor: Lb/d/a/d;
 */
public interface d {
    public abstract java.lang.String m();
    public abstract int n();
    public abstract java.lang.String o();
    public abstract java.lang.String p();
    public abstract int q();
    public abstract int r();
    public abstract int s();
    public abstract int t();
}