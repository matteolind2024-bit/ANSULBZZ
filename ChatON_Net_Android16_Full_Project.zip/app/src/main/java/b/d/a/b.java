package b.d.a;

/**
 * Original SourceFile: HttpClient.java
 * Descriptor: Lb/d/a/b;
 */
public interface b {
    public abstract b.d.a.l a(b.d.a.k p0);
}