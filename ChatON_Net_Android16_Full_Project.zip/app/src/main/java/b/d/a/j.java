package b.d.a;

/**
 * Original SourceFile: HttpParameter.java
 * Descriptor: Lb/d/a/j;
 */
public final class j implements java.io.Serializable, java.lang.Comparable {
    private java.lang.String a;
    private java.lang.String b;
    private java.io.File c;
    private java.io.InputStream d;

    public j(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        v0 = 0;
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v1.a = v0; // b.d.a.j.a:java.lang.String
        v1.b = v0; // b.d.a.j.b:java.lang.String
        v1.c = v0; // b.d.a.j.c:java.io.File
        v1.d = v0; // b.d.a.j.d:java.io.InputStream
        v1.a = v2; // b.d.a.j.a:java.lang.String
        v1.b = v3; // b.d.a.j.b:java.lang.String
        return;
    }

    public static java.lang.String a(java.lang.String p0) {
        // Registers (7 total): v6 = p0 (java.lang.String)
        v0 = 0;
        v1 = "UTF-8";
        _result = v6.encode(v1); // java.net.URLEncoder.encode -> java.lang.String
        v0 = _result;
        v2 = new java.lang.StringBuilder;
        _result = v0.length(); // java.lang.String.length -> int
        v1 = _result;
        _result = v2.<init>(v1); // java.lang.StringBuilder.<init> -> void
        v1 = 0;
        _result = v0.length(); // java.lang.String.length -> int
        v3 = _result;
        if (v1 >= v3) /* goto L_0060 */;
        _result = v0.charAt(v1); // java.lang.String.charAt -> char
        v3 = _result;
        v4 = 42;
        if (v3 != v4) /* goto L_0029 */;
        v3 = "%2A";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0012
        v4 = 43;
        if (v3 != v4) /* goto L_0034 */;
        v3 = "%20";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0026
        v4 = 37;
        if (v3 != v4) /* goto L_005c */;
        v4 = binOpLit8_0xd8(v1, 1);
        _result = v0.length(); // java.lang.String.length -> int
        v5 = _result;
        if (v4 >= v5) /* goto L_005c */;
        v4 = binOpLit8_0xd8(v1, 1);
        _result = v0.charAt(v4); // java.lang.String.charAt -> char
        v4 = _result;
        v5 = 55;
        if (v4 != v5) /* goto L_005c */;
        v4 = binOpLit8_0xd8(v1, 2);
        _result = v0.charAt(v4); // java.lang.String.charAt -> char
        v4 = _result;
        v5 = 69;
        if (v4 != v5) /* goto L_005c */;
        v3 = 126;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = binOpLit8_0xd8(v1, 2);
        // goto L_0026
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0026
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v1 = _exception;
        // goto L_0008
    }

    public static boolean a(b.d.a.j[] p0) {
        // Registers (5 total): v4 = p0 (b.d.a.j[])
        v0 = 0;
        if (v4 != 0) /* goto L_0004 */;
        return v0;
        v2 = v4.length;
        v1 = v0;
        if (v1 >= v2) /* goto L_0003 */;
        v3 = v4[v1];
        _result = v3.e(); // b.d.a.j.e -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0012 */;
        v0 = 1;
        // goto L_0003
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0006
    }

    public static java.lang.String b(b.d.a.j[] p0) {
        // Registers (5 total): v4 = p0 (b.d.a.j[])
        if (v4 != 0) /* goto L_0006 */;
        v0 = "";
        return v0;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v0 = 0;
        v2 = v4.length;
        if (v0 >= v2) /* goto L_0065 */;
        v2 = v4[v0];
        _result = v2.e(); // b.d.a.j.e -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_003c */;
        v1 = new java.lang.IllegalArgumentException;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "parameter [";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v0 = v4[v0];
        v0 = v0.a; // b.d.a.j.a:java.lang.String
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = "]should be text";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // java.lang.IllegalArgumentException.<init> -> void
        throw v1;
        if (v0 == 0) /* goto L_0044 */;
        v2 = "&";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = v4[v0];
        v2 = v2.a; // b.d.a.j.a:java.lang.String
        _result = v2.a(); // b.d.a.j.a -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = "=";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v4[v0];
        v3 = v3.b; // b.d.a.j.b:java.lang.String
        _result = v3.a(); // b.d.a.j.a -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_000c
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0005
    }

    public java.lang.String a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // b.d.a.j.a:java.lang.String
        return v0;
    }

    public java.lang.String b() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // b.d.a.j.b:java.lang.String
        return v0;
    }

    public java.io.File c() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // b.d.a.j.c:java.io.File
        return v0;
    }

    public int compareTo(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v3 = (b.d.a.j) v3;
        v0 = v2.a; // b.d.a.j.a:java.lang.String
        v1 = v3.a; // b.d.a.j.a:java.lang.String
        _result = v0.compareTo(v1); // java.lang.String.compareTo -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0014 */;
        v0 = v2.b; // b.d.a.j.b:java.lang.String
        v1 = v3.b; // b.d.a.j.b:java.lang.String
        _result = v0.compareTo(v1); // java.lang.String.compareTo -> int
        v0 = _result;
        return v0;
    }

    public java.io.InputStream d() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // b.d.a.j.d:java.io.InputStream
        return v0;
    }

    public boolean e() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // b.d.a.j.c:java.io.File
        if (v0 == 0) /* goto L_0006 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0005
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        v2 = (v5 instanceof b.d.a.j);
        if (v2 != 0) /* goto L_000b */;
        v0 = v1;
        // goto L_0004
        v5 = (b.d.a.j) v5;
        v2 = v4.c; // b.d.a.j.c:java.io.File
        if (v2 == 0) /* goto L_001d */;
        v2 = v4.c; // b.d.a.j.c:java.io.File
        v3 = v5.c; // b.d.a.j.c:java.io.File
        _result = v2.equals(v3); // java.io.File.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0021 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.c; // b.d.a.j.c:java.io.File
        if (v2 != 0) /* goto L_001b */;
        v2 = v4.d; // b.d.a.j.d:java.io.InputStream
        if (v2 == 0) /* goto L_0031 */;
        v2 = v4.d; // b.d.a.j.d:java.io.InputStream
        v3 = v5.d; // b.d.a.j.d:java.io.InputStream
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0035 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.d; // b.d.a.j.d:java.io.InputStream
        if (v2 != 0) /* goto L_002f */;
        v2 = v4.a; // b.d.a.j.a:java.lang.String
        v3 = v5.a; // b.d.a.j.a:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0041 */;
        v0 = v1;
        // goto L_0004
        v2 = v4.b; // b.d.a.j.b:java.lang.String
        if (v2 == 0) /* goto L_0051 */;
        v2 = v4.b; // b.d.a.j.b:java.lang.String
        v3 = v5.b; // b.d.a.j.b:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.b; // b.d.a.j.b:java.lang.String
        if (v2 == 0) /* goto L_0004 */;
        // goto L_004f
    }

    public boolean f() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // b.d.a.j.d:java.io.InputStream
        if (v0 == 0) /* goto L_0006 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0005
    }

    public java.lang.String g() {
        // Registers (4 total): v3 = this
        _result = v3.e(); // b.d.a.j.e -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_000f */;
        v0 = new java.lang.IllegalStateException;
        v1 = "not a file";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v3.c; // b.d.a.j.c:java.io.File
        _result = v0.getName(); // java.io.File.getName -> java.lang.String
        v0 = _result;
        v1 = ".";
        _result = v0.lastIndexOf(v1); // java.lang.String.lastIndexOf -> int
        v1 = _result;
        v2 = -1;
        if (v2 != v1) /* goto L_0023 */;
        v0 = "application/octet-stream";
        return v0;
        v1 = ".";
        _result = v0.lastIndexOf(v1); // java.lang.String.lastIndexOf -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v0.substring(v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        _result = v0.toLowerCase(); // java.lang.String.toLowerCase -> java.lang.String
        v0 = _result;
        _result = v0.length(); // java.lang.String.length -> int
        v1 = _result;
        v2 = 3;
        if (v1 != v2) /* goto L_0066 */;
        v1 = "gif";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0048 */;
        v0 = "image/gif";
        // goto L_0022
        v1 = "png";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0055 */;
        v0 = "image/png";
        // goto L_0022
        v1 = "jpg";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0062 */;
        v0 = "image/jpeg";
        // goto L_0022
        v0 = "application/octet-stream";
        // goto L_0022
        _result = v0.length(); // java.lang.String.length -> int
        v1 = _result;
        v2 = 4;
        if (v1 != v2) /* goto L_007e */;
        v1 = "jpeg";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_007a */;
        v0 = "image/jpeg";
        // goto L_0022
        v0 = "application/octet-stream";
        // goto L_0022
        v0 = "application/octet-stream";
        // goto L_0022
    }

    public int hashCode() {
        // Registers (4 total): v3 = this
        v1 = 0;
        v0 = v3.a; // b.d.a.j.a:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        v2 = binOpLit8_0xda(v0, 31);
        v0 = v3.b; // b.d.a.j.b:java.lang.String
        if (v0 == 0) /* goto L_002f */;
        v0 = v3.b; // b.d.a.j.b:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v2 = binOpLit8_0xda(v0, 31);
        v0 = v3.c; // b.d.a.j.c:java.io.File
        if (v0 == 0) /* goto L_0031 */;
        v0 = v3.c; // b.d.a.j.c:java.io.File
        _result = v0.hashCode(); // java.io.File.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v0 = binOpLit8_0xda(v0, 31);
        v2 = v3.d; // b.d.a.j.d:java.io.InputStream
        if (v2 == 0) /* goto L_002d */;
        v1 = v3.d; // b.d.a.j.d:java.io.InputStream
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v0 = v1;
        // goto L_0013
        v0 = v1;
        // goto L_0020
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        v2 = 39;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "PostParameter{name='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.a; // b.d.a.j.a:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", value='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.b; // b.d.a.j.b:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", file=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.c; // b.d.a.j.c:java.io.File
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", fileBody=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.d; // b.d.a.j.d:java.io.InputStream
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}