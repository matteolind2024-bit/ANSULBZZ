package b.d.a;

/**
 * Original SourceFile: HttpClientBase.java
 * Descriptor: Lb/d/a/c;
 */
public abstract class c implements b.d.a.b, java.io.Serializable {
    private static final b.d.c.a b;
    protected final b.d.a.d a;

    static {
        v0 = b.d.a.c.class;
        _result = v0.a(); // b.d.c.a.a -> b.d.c.a
        v0 = _result;
        b.d.a.c.b = v0; // :b.d.c.a
        return;
    }

    public c(b.d.a.d p0) {
        // Registers (2 total): v0 = this, v1 = p0 (b.d.a.d)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // b.d.a.c.a:b.d.a.d
        return;
    }

    public void a(java.io.DataOutputStream p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.io.DataOutputStream), v3 = p1 (java.lang.String)
        _result = v2.writeBytes(v3); // java.io.DataOutputStream.writeBytes -> void
        v0 = b.d.a.c.b; // :b.d.c.a
        _result = v0.a(v3); // b.d.c.a.a -> void
        return;
    }

    protected boolean a() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // b.d.a.c.a:b.d.a.d
        _result = b.d.a.d.m(v0); // -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0019 */;
        v0 = v2.a; // b.d.a.c.a:b.d.a.d
        _result = b.d.a.d.m(v0); // -> java.lang.String
        v0 = _result;
        v1 = "";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0019 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0018
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        v2 = (v5 instanceof b.d.a.c);
        if (v2 != 0) /* goto L_000b */;
        v0 = v1;
        // goto L_0004
        v5 = (b.d.a.c) v5;
        v2 = v4.a; // b.d.a.c.a:b.d.a.d
        v3 = v5.a; // b.d.a.c.a:b.d.a.d
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public int hashCode() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // b.d.a.c.a:b.d.a.d
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        return v0;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "HttpClientBase{CONF=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.a; // b.d.a.c.a:b.d.a.d
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}