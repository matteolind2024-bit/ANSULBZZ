package b.d.a;

/**
 * Original SourceFile: HttpClientWrapper.java
 * Descriptor: Lb/d/a/h;
 */
public final class h implements java.io.Serializable {
    private final b.d.a.i a;
    private b.d.a.b b;
    private final java.util.Map c;
    private b.d.a.o d;

    public h() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        _result = this.a(); // b.c.b.a -> b.c.a
        v0 = _result;
        v1.a = v0; // b.d.a.h.a:b.d.a.i
        v0 = v1.a; // b.d.a.h.a:b.d.a.i
        _result = b.d.a.i.u(v0); // -> java.util.Map
        v0 = _result;
        v1.c = v0; // b.d.a.h.c:java.util.Map
        v0 = v1.a; // b.d.a.h.a:b.d.a.i
        _result = v0.a(); // b.d.a.e.a -> b.d.a.b
        v0 = _result;
        v1.b = v0; // b.d.a.h.b:b.d.a.b
        return;
    }

    public h(b.d.a.i p0) {
        // Registers (3 total): v1 = this, v2 = p0 (b.d.a.i)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v1.a = v2; // b.d.a.h.a:b.d.a.i
        _result = b.d.a.i.u(v2); // -> java.util.Map
        v0 = _result;
        v1.c = v0; // b.d.a.h.c:java.util.Map
        _result = v2.a(); // b.d.a.e.a -> b.d.a.b
        v0 = _result;
        v1.b = v0; // b.d.a.h.b:b.d.a.b
        return;
    }

    private b.d.a.l a(b.d.a.k p0) {
        // Registers (7 total): v5 = this, v6 = p0 (b.d.a.k)
        v4 = 0;
        v0 = v5.b; // b.d.a.h.b:b.d.a.b
        _result = b.d.a.b.a(v0, v6); // -> b.d.a.l
        v0 = _result;
        v1 = v5.d; // b.d.a.h.d:b.d.a.o
        if (v1 == 0) /* goto L_0016 */;
        v1 = v5.d; // b.d.a.h.d:b.d.a.o
        v2 = new b.d.a.m;
        v3 = 0;
        _result = v2.<init>(v6, v0, v3); // b.d.a.m.<init> -> void
        _result = b.d.a.o.a(v1, v2); // -> void
        return v0;
        v0 = _exception;
        v1 = v5.d; // b.d.a.h.d:b.d.a.o
        if (v1 == 0) /* goto L_0026 */;
        v1 = v5.d; // b.d.a.h.d:b.d.a.o
        v2 = new b.d.a.m;
        _result = v2.<init>(v6, v4, v0); // b.d.a.m.<init> -> void
        _result = b.d.a.o.a(v1, v2); // -> void
        throw v0;
    }

    public b.d.a.l a(java.lang.String p0, b.d.a.j[] p1, b.b.b p2) {
        // Registers (10 total): v6 = this, v7 = p0 (java.lang.String), v8 = p1 (b.d.a.j[]), v9 = p2 (b.b.b)
        v0 = new b.d.a.k;
        v1 = b.d.a.p.b; // :b.d.a.p
        v5 = v6.c; // b.d.a.h.c:java.util.Map
        v2 = v7;
        v3 = v8;
        v4 = v9;
        _result = v0.<init>(v0..v5); // b.d.a.k.<init> -> void
        _result = v6.a(v0); // b.d.a.h.a -> b.d.a.l
        v0 = _result;
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        if (v5 == 0) /* goto L_0011 */;
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0013 */;
        v0 = v1;
        // goto L_0004
        v5 = (b.d.a.h) v5;
        v2 = v4.b; // b.d.a.h.b:b.d.a.b
        v3 = v5.b; // b.d.a.h.b:b.d.a.b
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0021 */;
        v0 = v1;
        // goto L_0004
        v2 = v4.c; // b.d.a.h.c:java.util.Map
        v3 = v5.c; // b.d.a.h.c:java.util.Map
        _result = java.util.Map.equals(v2, v3); // -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_002d */;
        v0 = v1;
        // goto L_0004
        v2 = v4.a; // b.d.a.h.a:b.d.a.i
        v3 = v5.a; // b.d.a.h.a:b.d.a.i
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public int hashCode() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // b.d.a.h.a:b.d.a.i
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.b; // b.d.a.h.b:b.d.a.b
        _result = v1.hashCode(); // java.lang.Object.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.c; // b.d.a.h.c:java.util.Map
        _result = java.util.Map.hashCode(v1); // -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "HttpClientWrapper{wrapperConf=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.a; // b.d.a.h.a:b.d.a.i
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", http=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.b; // b.d.a.h.b:b.d.a.b
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", requestHeaders=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.c; // b.d.a.h.c:java.util.Map
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", httpResponseListener=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.d; // b.d.a.h.d:b.d.a.o
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}