package b.d.a;

/**
 * Original SourceFile: HttpClientImpl.java
 * Descriptor: Lb/d/a/f;
 */
public class f extends b.d.a.c implements java.io.Serializable {
    private static final b.d.c.a b;
    private static boolean c;
    private static final java.util.Map d;

    static {
        v1 = 1;
        v0 = 0;
        v2 = b.d.a.f.class;
        _result = v2.a(); // b.d.c.a.a -> b.d.c.a
        v2 = _result;
        b.d.a.f.b = v2; // :b.d.c.a
        b.d.a.f.c = v0; // :boolean
        v2 = "java.specification.version";
        _result = v2.getProperty(); // java.lang.System.getProperty -> java.lang.String
        v2 = _result;
        if (v2 == 0) /* goto L_0022 */;
        v3 = 0x3ff8000000000000L;
        _result = v2.parseDouble(); // java.lang.Double.parseDouble -> double
        v5 = _result;
        v2 = cmp(v3, v5);
        if (v2 <= 0) /* goto L_0020 */;
        v0 = v1;
        b.d.a.f.c = v0; // :boolean
        _result = this.a(); // b.c.b.a -> b.c.a
        v0 = _result;
        _result = b.c.a.a(v0); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0038 */;
        v0 = 0;
        b.d.a.f.c = v0; // :boolean
        v0 = "http.keepAlive";
        v2 = "false";
        _result = v0.setProperty(v2); // java.lang.System.setProperty -> java.lang.String
        v0 = new java.util.HashMap;
        _result = v0.<init>(v1); // java.util.HashMap.<init> -> void
        b.d.a.f.d = v0; // :java.util.Map
        return;
        v0 = _exception;
        b.d.a.f.c = v1; // :boolean
        // goto L_0038
    }

    public f() {
        // Registers (2 total): v1 = this
        _result = this.a(); // b.c.b.a -> b.c.a
        v0 = _result;
        _result = v1.<init>(v0); // b.d.a.c.<init> -> void
        return;
    }

    private void a(b.d.a.k p0, java.net.HttpURLConnection p1) {
        // Registers (8 total): v5 = this, v6 = p0 (b.d.a.k), v7 = p1 (java.net.HttpURLConnection)
        v0 = b.d.a.f.b; // :b.d.c.a
        _result = v0.a(); // b.d.c.a.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0035 */;
        v0 = b.d.a.f.b; // :b.d.c.a
        v1 = "Request: ";
        _result = v0.a(v1); // b.d.c.a.a -> void
        v0 = b.d.a.f.b; // :b.d.c.a
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v6.a(); // b.d.a.k.a -> b.d.a.p
        v2 = _result;
        _result = v2.name(); // b.d.a.p.name -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = " ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v6.c(); // b.d.a.k.c -> java.lang.String
        v2 = _result;
        _result = v0.a(v1, v2); // b.d.c.a.a -> void
        _result = v6.d(); // b.d.a.k.d -> b.b.b
        v0 = _result;
        if (v0 == 0) /* goto L_005f */;
        _result = v6.d(); // b.d.a.k.d -> b.b.b
        v0 = _result;
        _result = b.b.b.a(v0, v6); // -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_005f */;
        v1 = b.d.a.f.b; // :b.d.c.a
        _result = v1.a(); // b.d.c.a.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0059 */;
        v1 = b.d.a.f.b; // :b.d.c.a
        v2 = "Authorization: ";
        _result = v0.a(); // b.d.e.a.a -> java.lang.String
        v3 = _result;
        _result = v1.a(v2, v3); // b.d.c.a.a -> void
        v1 = "Authorization";
        _result = v7.addRequestProperty(v1, v0); // java.net.HttpURLConnection.addRequestProperty -> void
        _result = v6.e(); // b.d.a.k.e -> java.util.Map
        v0 = _result;
        if (v0 == 0) /* goto L_00b2 */;
        _result = v6.e(); // b.d.a.k.e -> java.util.Map
        v0 = _result;
        _result = java.util.Map.keySet(v0); // -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_00b2 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        _result = v6.e(); // b.d.a.k.e -> java.util.Map
        v1 = _result;
        _result = java.util.Map.get(v1, v0); // -> java.lang.Object
        v1 = _result;
        v1 = (java.lang.String) v1;
        _result = v7.addRequestProperty(v0, v1); // java.net.HttpURLConnection.addRequestProperty -> void
        v1 = b.d.a.f.b; // :b.d.c.a
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ": ";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v6.e(); // b.d.a.k.e -> java.util.Map
        v4 = _result;
        _result = java.util.Map.get(v4, v0); // -> java.lang.Object
        v0 = _result;
        v0 = (java.lang.String) v0;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.a(v0); // b.d.c.a.a -> void
        // goto L_0071
        return;
    }

    public b.d.a.l a(b.d.a.k p0) {
        // Registers (20 total): v18 = this, v19 = p0 (b.d.a.k)
        v0 = v18;
        v2 = v0.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.s(v2); // -> int
        v2 = _result;
        v8 = binOpLit8_0xd8(v2, 1);
        v2 = 0;
        v3 = 0;
        v7 = v3;
        if (v7 >= v8) /* goto L_02e6 */;
        v6 = -1;
        v4 = 0;
        _result = v19.c(v19..v19); // b.d.a.k.c -> java.lang.String
        v3 = _result;
        v0 = v18;
        _result = v0.a(v3); // b.d.a.f.a -> java.net.HttpURLConnection
        v9 = _result;
        v3 = 1;
        _result = v9.setDoInput(v3); // java.net.HttpURLConnection.setDoInput -> void
        v0 = v18;
        v1 = v19;
        _result = v0.a(v1, v9); // b.d.a.f.a -> void
        _result = v19.a(v19..v19); // b.d.a.k.a -> b.d.a.p
        v3 = _result;
        _result = v3.name(); // b.d.a.p.name -> java.lang.String
        v3 = _result;
        _result = v9.setRequestMethod(v3); // java.net.HttpURLConnection.setRequestMethod -> void
        _result = v19.a(v19..v19); // b.d.a.k.a -> b.d.a.p
        v3 = _result;
        v5 = b.d.a.p.b; // :b.d.a.p
        if (v3 != v5) /* goto L_0350 */;
        _result = v19.b(v19..v19); // b.d.a.k.b -> b.d.a.j[]
        v3 = _result;
        _result = v3.a(); // b.d.a.j.a -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0278 */;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "----Twitter4J-upload";
        _result = v3.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v10 = _result;
        _result = v3.append(v10, v11); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v5 = "Content-Type";
        v10 = new java.lang.StringBuilder;
        _result = v10.<init>(); // java.lang.StringBuilder.<init> -> void
        v11 = "multipart/form-data; boundary=";
        _result = v10.append(v11); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v10 = _result;
        _result = v10.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v10 = _result;
        _result = v10.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v10 = _result;
        _result = v9.setRequestProperty(v5, v10); // java.net.HttpURLConnection.setRequestProperty -> void
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        v10 = "--";
        _result = v5.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v10 = _result;
        v3 = 1;
        _result = v9.setDoOutput(v3); // java.net.HttpURLConnection.setDoOutput -> void
        _result = v9.getOutputStream(); // java.net.HttpURLConnection.getOutputStream -> java.io.OutputStream
        v4 = _result;
        v11 = new java.io.DataOutputStream;
        _result = v11.<init>(v4); // java.io.DataOutputStream.<init> -> void
        _result = v19.b(v19..v19); // b.d.a.k.b -> b.d.a.j[]
        v12 = _result;
        v13 = v12.length;
        v3 = 0;
        v5 = v3;
        if (v5 >= v13) /* goto L_01df */;
        v14 = v12[v5];
        _result = v14.e(); // b.d.a.j.e -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_017a */;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v3.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v15 = "\r\n";
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v0 = v18;
        _result = v0.a(v11, v3); // b.d.a.f.a -> void
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v15 = "Content-Disposition: form-data; name=\"";
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v14.a(); // b.d.a.j.a -> java.lang.String
        v15 = _result;
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v15 = "\"; filename=\"";
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v14.c(); // b.d.a.j.c -> java.io.File
        v15 = _result;
        _result = v15.getName(); // java.io.File.getName -> java.lang.String
        v15 = _result;
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v15 = "\"\r\n";
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v0 = v18;
        _result = v0.a(v11, v3); // b.d.a.f.a -> void
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v15 = "Content-Type: ";
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v14.g(); // b.d.a.j.g -> java.lang.String
        v15 = _result;
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v15 = "\r\n\r\n";
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v0 = v18;
        _result = v0.a(v11, v3); // b.d.a.f.a -> void
        v15 = new java.io.BufferedInputStream;
        _result = v14.f(); // b.d.a.j.f -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0160 */;
        _result = v14.d(); // b.d.a.j.d -> java.io.InputStream
        v3 = _result;
        _result = v15.<init>(v3); // java.io.BufferedInputStream.<init> -> void
        v3 = 1024;
        v3 = new byte[][size=v3];
        _result = v15.read(v3); // java.io.BufferedInputStream.read -> int
        v14 = _result;
        v16 = -1;
        v0 = v16;
        if (v14 == v0) /* goto L_016a */;
        v16 = 0;
        v0 = v16;
        _result = v11.write(v3, v0, v14); // java.io.DataOutputStream.write -> void
        // goto L_012e
        v3 = _exception;
        v5 = v2;
        v2 = v3;
        v3 = v4;
        v4 = v6;
        _result = v3.close(); // java.io.OutputStream.close -> void
        throw v2;
        v2 = _exception;
        v6 = v4;
        v4 = v5;
        v0 = v18;
        v3 = v0.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.s(v3); // -> int
        v3 = _result;
        if (v7 != v3) /* goto L_0353 */;
        v3 = new b.g;
        _result = v2.getMessage(); // java.io.IOException.getMessage -> java.lang.String
        v4 = _result;
        _result = v3.<init>(v4, v2, v6); // b.g.<init> -> void
        throw v3;
        v3 = new java.io.FileInputStream;
        _result = v14.c(); // b.d.a.j.c -> java.io.File
        v14 = _result;
        _result = v3.<init>(v14); // java.io.FileInputStream.<init> -> void
        // goto L_0127
        v3 = "\r\n";
        v0 = v18;
        _result = v0.a(v11, v3); // b.d.a.f.a -> void
        _result = v15.close(); // java.io.BufferedInputStream.close -> void
        v3 = binOpLit8_0xd8(v5, 1);
        v5 = v3;
        // goto L_009d
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v3.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v15 = "\r\n";
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v0 = v18;
        _result = v0.a(v11, v3); // b.d.a.f.a -> void
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v15 = "Content-Disposition: form-data; name=\"";
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v14.a(); // b.d.a.j.a -> java.lang.String
        v15 = _result;
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v15 = "\"\r\n";
        _result = v3.append(v15); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v0 = v18;
        _result = v0.a(v11, v3); // b.d.a.f.a -> void
        v3 = "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
        v0 = v18;
        _result = v0.a(v11, v3); // b.d.a.f.a -> void
        v3 = b.d.a.f.b; // :b.d.c.a
        _result = v14.b(); // b.d.a.j.b -> java.lang.String
        v15 = _result;
        _result = v3.a(v15); // b.d.c.a.a -> void
        _result = v14.b(); // b.d.a.j.b -> java.lang.String
        v3 = _result;
        v14 = "UTF-8";
        _result = v3.getBytes(v14); // java.lang.String.getBytes -> byte[]
        v3 = _result;
        _result = v11.write(v3); // java.io.DataOutputStream.write -> void
        v3 = "\r\n";
        v0 = v18;
        _result = v0.a(v11, v3); // b.d.a.f.a -> void
        // goto L_0175
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v3.append(v10); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v5 = "--\r\n";
        _result = v3.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v0 = v18;
        _result = v0.a(v11, v3); // b.d.a.f.a -> void
        v3 = "\r\n";
        v0 = v18;
        _result = v0.a(v11, v3); // b.d.a.f.a -> void
        _result = v4.flush(); // java.io.OutputStream.flush -> void
        _result = v4.close(); // java.io.OutputStream.close -> void
        v5 = v4;
        v4 = new b.d.a.n;
        v0 = v18;
        v3 = v0.a; // b.d.a.f.a:b.d.a.d
        _result = v4.<init>(v9, v3); // b.d.a.n.<init> -> void
        _result = v9.getResponseCode(); // java.net.HttpURLConnection.getResponseCode -> int
        v6 = _result;
        v2 = b.d.a.f.b; // :b.d.c.a
        _result = v2.a(); // b.d.c.a.a -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_02b6 */;
        v2 = b.d.a.f.b; // :b.d.c.a
        v3 = "Response: ";
        _result = v2.a(v3); // b.d.c.a.a -> void
        _result = v9.getHeaderFields(); // java.net.HttpURLConnection.getHeaderFields -> java.util.Map
        v9 = _result;
        _result = java.util.Map.keySet(v9); // -> java.util.Set
        v2 = _result;
        _result = java.util.Set.iterator(v2); // -> java.util.Iterator
        v10 = _result;
        _result = java.util.Iterator.hasNext(v10); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_02b6 */;
        _result = java.util.Iterator.next(v10); // -> java.lang.Object
        v2 = _result;
        v2 = (java.lang.String) v2;
        _result = java.util.Map.get(v9, v2); // -> java.lang.Object
        v3 = _result;
        v3 = (java.util.List) v3;
        _result = java.util.List.iterator(v3); // -> java.util.Iterator
        v11 = _result;
        _result = java.util.Iterator.hasNext(v11); // -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0230 */;
        _result = java.util.Iterator.next(v11); // -> java.lang.Object
        v3 = _result;
        v3 = (java.lang.String) v3;
        if (v2 == 0) /* goto L_02b0 */;
        v12 = b.d.a.f.b; // :b.d.c.a
        v13 = new java.lang.StringBuilder;
        _result = v13.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v13.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v13 = _result;
        v14 = ": ";
        _result = v13.append(v14); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v13 = _result;
        _result = v13.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v12.a(v3); // b.d.c.a.a -> void
        // goto L_0246
        v2 = _exception;
        v3 = v5;
        v5 = v4;
        v4 = v6;
        // goto L_0145
        v3 = "Content-Type";
        v5 = "application/x-www-form-urlencoded";
        _result = v9.setRequestProperty(v3, v5); // java.net.HttpURLConnection.setRequestProperty -> void
        _result = v19.b(v19..v19); // b.d.a.k.b -> b.d.a.j[]
        v3 = _result;
        _result = v3.b(); // b.d.a.j.b -> java.lang.String
        v3 = _result;
        v5 = b.d.a.f.b; // :b.d.c.a
        v10 = "Post Params: ";
        _result = v5.a(v10, v3); // b.d.c.a.a -> void
        v5 = "UTF-8";
        _result = v3.getBytes(v5); // java.lang.String.getBytes -> byte[]
        v3 = _result;
        v5 = "Content-Length";
        v10 = v3.length;
        _result = v10.toString(); // java.lang.Integer.toString -> java.lang.String
        v10 = _result;
        _result = v9.setRequestProperty(v5, v10); // java.net.HttpURLConnection.setRequestProperty -> void
        v5 = 1;
        _result = v9.setDoOutput(v5); // java.net.HttpURLConnection.setDoOutput -> void
        _result = v9.getOutputStream(); // java.net.HttpURLConnection.getOutputStream -> java.io.OutputStream
        v4 = _result;
        _result = v4.write(v3); // java.io.OutputStream.write -> void
        // goto L_0200
        v12 = b.d.a.f.b; // :b.d.c.a
        _result = v12.a(v3); // b.d.c.a.a -> void
        // goto L_0246
        v2 = 200;
        if (v6 < v2) /* goto L_02c2 */;
        v2 = 302;
        if (v6 == v2) /* goto L_02e2 */;
        v2 = 300;
        if (v2 > v6) /* goto L_02e2 */;
        v2 = 420;
        if (v6 == v2) /* goto L_02d8 */;
        v2 = 400;
        if (v6 == v2) /* goto L_02d8 */;
        v2 = 500;
        if (v6 < v2) /* goto L_02d8 */;
        v0 = v18;
        v2 = v0.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.s(v2); // -> int
        v2 = _result;
        if (v7 != v2) /* goto L_02e7 */;
        v2 = new b.g;
        _result = v4.c(); // b.d.a.l.c -> java.lang.String
        v3 = _result;
        _result = v2.<init>(v3, v4); // b.g.<init> -> void
        throw v2;
        _result = v5.close(); // java.io.OutputStream.close -> void
        v2 = v4;
        return v2;
        _result = v5.close(); // java.io.OutputStream.close -> void
        v2 = v4;
        v3 = b.d.a.f.b; // :b.d.c.a
        _result = v3.a(); // b.d.c.a.a -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_02f8 */;
        if (v2 == 0) /* goto L_02f8 */;
        _result = v2.c(); // b.d.a.l.c -> java.lang.String
        v3 = b.d.a.f.b; // :b.d.c.a
        v4 = new java.lang.StringBuilder;
        _result = v4.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "Sleeping ";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v0 = v18;
        v5 = v0.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.t(v5); // -> int
        v5 = _result;
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        v5 = " seconds until the next retry.";
        _result = v4.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v4 = _result;
        _result = v4.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v4 = _result;
        _result = v3.a(v4); // b.d.c.a.a -> void
        v0 = v18;
        v3 = v0.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.t(v3); // -> int
        v3 = _result;
        v3 = binOpLit16_0xd2(v3, 1000);
        v3 = unaryOp_0x81(v3);
        _result = v3.sleep(v4); // java.lang.Thread.sleep -> void
        v3 = binOpLit8_0xd8(v7, 1);
        v7 = v3;
        // goto L_000d
        v2 = _exception;
        // goto L_02e5
        v2 = _exception;
        // goto L_02ea
        v3 = _exception;
        // goto L_0148
        v3 = _exception;
        // goto L_032e
        v2 = _exception;
        // goto L_014c
        v3 = _exception;
        v5 = v2;
        v2 = v3;
        v3 = v4;
        v4 = v6;
        // goto L_0145
        v3 = _exception;
        v4 = v6;
        v17 = v5;
        v5 = v2;
        v2 = v3;
        v3 = v17;
        // goto L_0145
        v5 = v4;
        // goto L_0207
        v2 = v4;
        // goto L_02eb
    }

    protected java.net.HttpURLConnection a(java.lang.String p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.String)
        _result = v4.a(); // b.d.a.f.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0103 */;
        v0 = b.d.a.f.c; // :boolean
        if (v0 != 0) /* goto L_0103 */;
        v0 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.o(v0); // -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0073 */;
        v0 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.o(v0); // -> java.lang.String
        v0 = _result;
        v1 = "";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0073 */;
        v0 = b.d.a.f.b; // :b.d.c.a
        _result = v0.a(); // b.d.c.a.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_006b */;
        v0 = b.d.a.f.b; // :b.d.c.a
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Proxy AuthUser: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.o(v2); // -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.a(v1); // b.d.c.a.a -> void
        v0 = b.d.a.f.b; // :b.d.c.a
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Proxy AuthPassword: ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.p(v2); // -> java.lang.String
        v2 = _result;
        _result = v2.a(); // b.d.e.a.a -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.a(v1); // b.d.c.a.a -> void
        v0 = new b.d.a.g;
        _result = v0.<init>(v4); // b.d.a.g.<init> -> void
        _result = v0.setDefault(); // java.net.Authenticator.setDefault -> void
        v0 = new java.net.Proxy;
        v1 = java.net.Proxy$Type.HTTP; // :java.net.Proxy$Type
        v2 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.m(v2); // -> java.lang.String
        v2 = _result;
        v3 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.n(v3); // -> int
        v3 = _result;
        _result = v2.createUnresolved(v3); // java.net.InetSocketAddress.createUnresolved -> java.net.InetSocketAddress
        v2 = _result;
        _result = v0.<init>(v1, v2); // java.net.Proxy.<init> -> void
        v1 = b.d.a.f.b; // :b.d.c.a
        _result = v1.a(); // b.d.c.a.a -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_00c9 */;
        v1 = b.d.a.f.b; // :b.d.c.a
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Opening proxied connection(";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.m(v3); // -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ":";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.n(v3); // -> int
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ")";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.a(v2); // b.d.c.a.a -> void
        v1 = new java.net.URL;
        _result = v1.<init>(v5); // java.net.URL.<init> -> void
        _result = v1.openConnection(v0); // java.net.URL.openConnection -> java.net.URLConnection
        v0 = _result;
        v0 = (java.net.HttpURLConnection) v0;
        v1 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.q(v1); // -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_00e9 */;
        v1 = b.d.a.f.c; // :boolean
        if (v1 != 0) /* goto L_00e9 */;
        v1 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.q(v1); // -> int
        v1 = _result;
        _result = v0.setConnectTimeout(v1); // java.net.HttpURLConnection.setConnectTimeout -> void
        v1 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.r(v1); // -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_00fe */;
        v1 = b.d.a.f.c; // :boolean
        if (v1 != 0) /* goto L_00fe */;
        v1 = v4.a; // b.d.a.f.a:b.d.a.d
        _result = b.d.a.d.r(v1); // -> int
        v1 = _result;
        _result = v0.setReadTimeout(v1); // java.net.HttpURLConnection.setReadTimeout -> void
        v1 = 0;
        _result = v0.setInstanceFollowRedirects(v1); // java.net.HttpURLConnection.setInstanceFollowRedirects -> void
        return v0;
        v0 = new java.net.URL;
        _result = v0.<init>(v5); // java.net.URL.<init> -> void
        _result = v0.openConnection(); // java.net.URL.openConnection -> java.net.URLConnection
        v0 = _result;
        v0 = (java.net.HttpURLConnection) v0;
        // goto L_00d4
    }

}