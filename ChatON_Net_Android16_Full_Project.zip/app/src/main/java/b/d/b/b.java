package b.d.b;

/**
 * Original SourceFile: Unknown
 * Descriptor: Lb/d/b/b;
 */
public interface b extends java.io.Serializable {
}