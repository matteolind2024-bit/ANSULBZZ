package b.d.b;

/**
 * Original SourceFile: z_T4JInternalParseUtil.java
 * Descriptor: Lb/d/b/d;
 */
public final class d {
    private static final java.util.Map a;

    static {
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        b.d.b.d.a = v0; // :java.util.Map
        return;
    }

    public static int a(java.lang.String p0) {
        // Registers (3 total): v2 = p0 (java.lang.String)
        v0 = -1;
        if (v2 == 0) /* goto L_0015 */;
        v1 = "";
        _result = v1.equals(v2); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0015 */;
        v1 = "null";
        _result = v1.equals(v2); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0016 */;
        return v0;
        _result = v2.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v1.intValue(); // java.lang.Integer.intValue -> int
        v0 = _result;
        // goto L_0015
        v1 = _exception;
        // goto L_0015
    }

    public static java.lang.String a(java.lang.String p0, b.d.d.a.c p1) {
        // Registers (4 total): v2 = p0 (java.lang.String), v3 = p1 (b.d.d.a.c)
        v0 = 0;
        _result = v3.d(v2); // b.d.d.a.c.d -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0008 */;
        return v0;
        _result = v3.c(v2); // b.d.d.a.c.c -> java.lang.String
        v0 = _result;
        // goto L_0007
        v1 = _exception;
        // goto L_0007
    }

    public static int b(java.lang.String p0, b.d.d.a.c p1) {
        // Registers (3 total): v1 = p0 (java.lang.String), v2 = p1 (b.d.d.a.c)
        _result = v1.a(v2); // b.d.b.d.a -> java.lang.String
        v0 = _result;
        _result = v0.a(); // b.d.b.d.a -> int
        v0 = _result;
        return v0;
    }

}