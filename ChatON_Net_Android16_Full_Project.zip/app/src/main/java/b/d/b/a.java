package b.d.b;

/**
 * Original SourceFile: RateLimitStatusJSONImpl.java
 * Descriptor: Lb/d/b/a;
 */
final class a implements b.c, java.io.Serializable {
    private int a;
    private int b;
    private int c;
    private int d;

    private a(int p0, int p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (int), v8 = p1 (int), v9 = p2 (int)
        v4 = 1000L;
        _result = v6.<init>(); // java.lang.Object.<init> -> void
        v6.b = v7; // b.d.b.a.b:int
        v6.a = v8; // b.d.b.a.a:int
        v6.c = v9; // b.d.b.a.c:int
        v0 = unaryOp_0x81(v9);
        v0 = binOp2addr_0xbd(v0, v4);
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v2 = _result;
        v0 = binOp2addr_0xbc(v0, v2);
        v0 = binOp2addr_0xbe(v0, v4);
        v0 = unaryOp_0x84(v0);
        v6.d = v0; // b.d.b.a.d:int
        return;
    }

    static b.c a(b.d.a.l p0) {
        // Registers (6 total): v5 = p0 (b.d.a.l)
        v0 = 0;
        if (v5 != 0) /* goto L_0004 */;
        return v0;
        v1 = "X-Rate-Limit-Limit";
        _result = v5.a(v1); // b.d.a.l.a -> java.lang.String
        v1 = _result;
        if (v1 == 0) /* goto L_0003 */;
        _result = v1.parseInt(); // java.lang.Integer.parseInt -> int
        v1 = _result;
        v2 = "X-Rate-Limit-Remaining";
        _result = v5.a(v2); // b.d.a.l.a -> java.lang.String
        v2 = _result;
        if (v2 == 0) /* goto L_0003 */;
        _result = v2.parseInt(); // java.lang.Integer.parseInt -> int
        v2 = _result;
        v3 = "X-Rate-Limit-Reset";
        _result = v5.a(v3); // b.d.a.l.a -> java.lang.String
        v3 = _result;
        if (v3 == 0) /* goto L_0003 */;
        _result = v3.parseLong(); // java.lang.Long.parseLong -> long
        v3 = _result;
        v3 = unaryOp_0x84(v3);
        v0 = new b.d.b.a;
        _result = v0.<init>(v1, v2, v3); // b.d.b.a.<init> -> void
        // goto L_0003
    }

    public int a() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // b.d.b.a.d:int
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        if (v5 == 0) /* goto L_0011 */;
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0013 */;
        v0 = v1;
        // goto L_0004
        v5 = (b.d.b.a) v5;
        v2 = v4.b; // b.d.b.a.b:int
        v3 = v5.b; // b.d.b.a.b:int
        if (v2 == v3) /* goto L_001d */;
        v0 = v1;
        // goto L_0004
        v2 = v4.a; // b.d.b.a.a:int
        v3 = v5.a; // b.d.b.a.a:int
        if (v2 == v3) /* goto L_0025 */;
        v0 = v1;
        // goto L_0004
        v2 = v4.c; // b.d.b.a.c:int
        v3 = v5.c; // b.d.b.a.c:int
        if (v2 == v3) /* goto L_002d */;
        v0 = v1;
        // goto L_0004
        v2 = v4.d; // b.d.b.a.d:int
        v3 = v5.d; // b.d.b.a.d:int
        if (v2 == v3) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public int hashCode() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // b.d.b.a.a:int
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.b; // b.d.b.a.b:int
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.c; // b.d.b.a.c:int
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.d; // b.d.b.a.d:int
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "RateLimitStatusJSONImpl{remaining=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.a; // b.d.b.a.a:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", limit=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.b; // b.d.b.a.b:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", resetTimeInSeconds=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.c; // b.d.b.a.c:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", secondsUntilReset=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.d; // b.d.b.a.d:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}