package b.d.b;

/**
 * Original SourceFile: z_T4JInternalJSONImplFactory.java
 * Descriptor: Lb/d/b/c;
 */
public class c implements b.d.b.b {
    private b.c.a a;

    public static b.c a(b.d.a.l p0) {
        // Registers (2 total): v1 = p0 (b.d.a.l)
        _result = v1.a(); // b.d.b.a.a -> b.c
        v0 = _result;
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        v2 = (v5 instanceof b.d.b.c);
        if (v2 != 0) /* goto L_000b */;
        v0 = v1;
        // goto L_0004
        v5 = (b.d.b.c) v5;
        v2 = v4.a; // b.d.b.c.a:b.c.a
        if (v2 == 0) /* goto L_001d */;
        v2 = v4.a; // b.d.b.c.a:b.c.a
        v3 = v5.a; // b.d.b.c.a:b.c.a
        _result = v2.equals(v3); // java.lang.Object.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.a; // b.d.b.c.a:b.c.a
        if (v2 == 0) /* goto L_0004 */;
        // goto L_001b
    }

    public int hashCode() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // b.d.b.c.a:b.c.a
        if (v0 == 0) /* goto L_000b */;
        v0 = v1.a; // b.d.b.c.a:b.c.a
        _result = v0.hashCode(); // java.lang.Object.hashCode -> int
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_000a
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "JSONImplFactory{conf=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.a; // b.d.b.c.a:b.c.a
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}