package b.b;

/**
 * Original SourceFile: NullAuthorization.java
 * Descriptor: Lb/b/e;
 */
public class e implements b.b.b, java.io.Serializable {
    private static b.b.e a;

    static {
        v0 = new b.b.e;
        _result = v0.<init>(); // b.b.e.<init> -> void
        b.b.e.a = v0; // :b.b.e
        return;
    }

    private e() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static b.b.e a() {
        v0 = b.b.e.a; // :b.b.e
        return v0;
    }

    public java.lang.String a(b.d.a.k p0) {
        // Registers (3 total): v1 = this, v2 = p0 (b.d.a.k)
        v0 = 0;
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = b.b.e.a; // :b.b.e
        if (v0 != v2) /* goto L_0006 */;
        v0 = 1;
        return v0;
        v0 = 0;
        // goto L_0005
    }

    public java.lang.String toString() {
        // Registers (2 total): v1 = this
        v0 = "NullAuthentication{SINGLETON}";
        return v0;
    }

}