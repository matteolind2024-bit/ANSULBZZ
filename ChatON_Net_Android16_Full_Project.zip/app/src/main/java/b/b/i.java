package b.b;

/**
 * Original SourceFile: RequestToken.java
 * Descriptor: Lb/b/i;
 */
public final class i extends b.b.h implements java.io.Serializable {
    private final b.c.a b;
    private b.b.g c;

    i(b.d.a.l p0, b.b.g p1) {
        // Registers (4 total): v1 = this, v2 = p0 (b.d.a.l), v3 = p1 (b.b.g)
        _result = v1.<init>(v2); // b.b.h.<init> -> void
        _result = this.a(); // b.c.b.a -> b.c.a
        v0 = _result;
        v1.b = v0; // b.b.i.b:b.c.a
        v1.c = v3; // b.b.i.c:b.b.g
        return;
    }

    public java.lang.String a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        _result = v1.a(v2); // b.b.h.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String b() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // b.b.h.b -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // b.b.h.c -> java.lang.String
        v0 = _result;
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v1.equals(v2); // b.b.h.equals -> boolean
        v0 = _result;
        return v0;
    }

    public int hashCode() {
        // Registers (2 total): v1 = this
        _result = v1.hashCode(); // b.b.h.hashCode -> int
        v0 = _result;
        return v0;
    }

    public java.lang.String toString() {
        // Registers (2 total): v1 = this
        _result = v1.toString(); // b.b.h.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}