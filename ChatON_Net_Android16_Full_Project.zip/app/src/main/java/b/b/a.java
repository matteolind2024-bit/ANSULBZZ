package b.b;

/**
 * Original SourceFile: AccessToken.java
 * Descriptor: Lb/b/a;
 */
public class a extends b.b.h implements java.io.Serializable {
    private java.lang.String b;
    private long c;

    a(b.d.a.l p0) {
        // Registers (3 total): v1 = this, v2 = p0 (b.d.a.l)
        _result = v2.c(); // b.d.a.l.c -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // b.b.a.<init> -> void
        return;
    }

    a(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        _result = v2.<init>(v3); // b.b.h.<init> -> void
        v0 = -1L;
        v2.c = v0; // b.b.a.c:long
        v0 = "screen_name";
        _result = v2.a(v0); // b.b.a.a -> java.lang.String
        v0 = _result;
        v2.b = v0; // b.b.a.b:java.lang.String
        v0 = "user_id";
        _result = v2.a(v0); // b.b.a.a -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_001f */;
        _result = v0.parseLong(); // java.lang.Long.parseLong -> long
        v0 = _result;
        v2.c = v0; // b.b.a.c:long
        return;
    }

    public a(java.lang.String p0, java.lang.String p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.String), v4 = p1 (java.lang.String)
        _result = v2.<init>(v3, v4); // b.b.h.<init> -> void
        v0 = -1L;
        v2.c = v0; // b.b.a.c:long
        v0 = "-";
        _result = v3.indexOf(v0); // java.lang.String.indexOf -> int
        v0 = _result;
        v1 = -1;
        if (v0 == v1) /* goto L_001c */;
        v1 = 0;
        _result = v3.substring(v1, v0); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        _result = v0.parseLong(); // java.lang.Long.parseLong -> long
        v0 = _result;
        v2.c = v0; // b.b.a.c:long
        return;
        v0 = _exception;
        // goto L_001c
    }

    public long a() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // b.b.a.c:long
        return v0;
    }

    public java.lang.String a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        _result = v1.a(v2); // b.b.h.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String b() {
        // Registers (2 total): v1 = this
        _result = v1.b(); // b.b.h.b -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // b.b.h.c -> java.lang.String
        v0 = _result;
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v6 != v7) /* goto L_0005 */;
        return v0;
        if (v7 == 0) /* goto L_0011 */;
        _result = v6.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v7.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0013 */;
        v0 = v1;
        // goto L_0004
        _result = v6.equals(v7); // b.b.h.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_001b */;
        v0 = v1;
        // goto L_0004
        v7 = (b.b.a) v7;
        v2 = v6.c; // b.b.a.c:long
        v4 = v7.c; // b.b.a.c:long
        v2 = cmp(v2, v4);
        if (v2 == 0) /* goto L_0027 */;
        v0 = v1;
        // goto L_0004
        v2 = v6.b; // b.b.a.b:java.lang.String
        if (v2 == 0) /* goto L_0037 */;
        v2 = v6.b; // b.b.a.b:java.lang.String
        v3 = v7.b; // b.b.a.b:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v7.b; // b.b.a.b:java.lang.String
        if (v2 == 0) /* goto L_0004 */;
        // goto L_0035
    }

    public int hashCode() {
        // Registers (7 total): v6 = this
        _result = v6.hashCode(); // b.b.h.hashCode -> int
        v0 = _result;
        v1 = binOpLit8_0xda(v0, 31);
        v0 = v6.b; // b.b.a.b:java.lang.String
        if (v0 == 0) /* goto L_001e */;
        v0 = v6.b; // b.b.a.b:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v6.c; // b.b.a.c:long
        v3 = v6.c; // b.b.a.c:long
        v5 = 32;
        v3 = binOp2addr_0xc5(v3, v5);
        v1 = binOp2addr_0xc2(v1, v3);
        v1 = unaryOp_0x84(v1);
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v0 = 0;
        // goto L_0010
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "AccessToken{screenName='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.b; // b.b.a.b:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 39;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", userId=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.c; // b.b.a.c:long
        _result = v0.append(v1, v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}