package b.b;

/**
 * Original SourceFile: OAuthAuthorization.java
 * Descriptor: Lb/b/f;
 */
public class f implements b.b.b, b.b.g, java.io.Serializable {
    private static transient b.d.a.h b;
    private static final b.d.a.j c;
    private static final b.d.c.a d;
    private static java.util.Random i;
    private final b.c.a a;
    private java.lang.String e;
    private java.lang.String f;
    private java.lang.String g;
    private b.b.h h;

    static {
        v0 = new b.d.a.j;
        v1 = "oauth_signature_method";
        v2 = "HMAC-SHA1";
        _result = v0.<init>(v1, v2); // b.d.a.j.<init> -> void
        b.b.f.c = v0; // :b.d.a.j
        v0 = b.b.f.class;
        _result = v0.a(); // b.d.c.a.a -> b.d.c.a
        v0 = _result;
        b.b.f.d = v0; // :b.d.c.a
        v0 = new java.util.Random;
        _result = v0.<init>(); // java.util.Random.<init> -> void
        b.b.f.i = v0; // :java.util.Random
        return;
    }

    public f(b.c.a p0) {
        // Registers (5 total): v3 = this, v4 = p0 (b.c.a)
        v1 = 0;
        _result = v3.<init>(); // java.lang.Object.<init> -> void
        v0 = "";
        v3.e = v0; // b.b.f.e:java.lang.String
        v3.g = v1; // b.b.f.g:java.lang.String
        v3.h = v1; // b.b.f.h:b.b.h
        v3.a = v4; // b.b.f.a:b.c.a
        v0 = new b.d.a.h;
        _result = v0.<init>(v4); // b.d.a.h.<init> -> void
        b.b.f.b = v0; // :b.d.a.h
        _result = b.c.a.f(v4); // -> java.lang.String
        v0 = _result;
        _result = b.c.a.g(v4); // -> java.lang.String
        v1 = _result;
        _result = v3.b(v0, v1); // b.b.f.b -> void
        _result = b.c.a.h(v4); // -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_003d */;
        _result = b.c.a.i(v4); // -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_003d */;
        v0 = new b.b.a;
        _result = b.c.a.h(v4); // -> java.lang.String
        v1 = _result;
        _result = b.c.a.i(v4); // -> java.lang.String
        v2 = _result;
        _result = v0.<init>(v1, v2); // b.b.a.<init> -> void
        _result = v3.a(v0); // b.b.f.a -> void
        return;
    }

    static java.lang.String a(java.util.List p0) {
        // Registers (2 total): v1 = p0 (java.util.List)
        _result = v1.sort(); // java.util.Collections.sort -> void
        _result = v1.b(); // b.b.f.b -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String a(java.util.List p0, java.lang.String p1, boolean p2) {
        // Registers (8 total): v5 = p0 (java.util.List), v6 = p1 (java.lang.String), v7 = p2 (boolean)
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = java.util.List.iterator(v5); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0052 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (b.d.a.j) v0;
        _result = v0.e(); // b.d.a.j.e -> boolean
        v3 = _result;
        if (v3 != 0) /* goto L_0009 */;
        _result = v1.length(); // java.lang.StringBuilder.length -> int
        v3 = _result;
        if (v3 == 0) /* goto L_002c */;
        if (v7 == 0) /* goto L_0029 */;
        v3 = "\"";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v1.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.a(); // b.d.a.j.a -> java.lang.String
        v3 = _result;
        _result = v3.a(); // b.d.a.j.a -> java.lang.String
        v3 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = "=";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        if (v7 == 0) /* goto L_0046 */;
        v3 = "\"";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v0.b(); // b.d.a.j.b -> java.lang.String
        v0 = _result;
        _result = v0.a(); // b.d.a.j.a -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        // goto L_0009
        _result = v1.length(); // java.lang.StringBuilder.length -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0060 */;
        if (v7 == 0) /* goto L_0060 */;
        v0 = "\"";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    static java.util.List a(b.d.a.j[] p0) {
        // Registers (3 total): v2 = p0 (b.d.a.j[])
        v0 = new java.util.ArrayList;
        v1 = v2.length;
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        _result = v2.asList(); // java.util.Arrays.asList -> java.util.List
        v1 = _result;
        _result = java.util.List.addAll(v0, v1); // -> boolean
        return v0;
    }

    private void a(java.lang.String p0, java.util.List p1) {
        // Registers (10 total): v7 = this, v8 = p0 (java.lang.String), v9 = p1 (java.util.List)
        v0 = 0;
        v1 = "?";
        _result = v8.indexOf(v1); // java.lang.String.indexOf -> int
        v1 = _result;
        v2 = -1;
        if (v2 == v1) /* goto L_005e */;
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v8.substring(v1); // java.lang.String.substring -> java.lang.String
        v1 = _result;
        v2 = "&";
        _result = v1.a(v2); // b.d.e.a.a -> java.lang.String[]
        v1 = _result;
        v2 = v1.length;
        if (v0 >= v2) /* goto L_005e */;
        v3 = v1[v0];
        v4 = "=";
        _result = v3.a(v4); // b.d.e.a.a -> java.lang.String[]
        v3 = _result;
        v4 = v3.length;
        v5 = 2;
        if (v4 != v5) /* goto L_0047 */;
        v4 = new b.d.a.j;
        v5 = 0;
        v5 = v3[v5];
        v6 = "UTF-8";
        _result = v5.decode(v6); // java.net.URLDecoder.decode -> java.lang.String
        v5 = _result;
        v6 = 1;
        v3 = v3[v6];
        v6 = "UTF-8";
        _result = v3.decode(v6); // java.net.URLDecoder.decode -> java.lang.String
        v3 = _result;
        _result = v4.<init>(v5, v3); // b.d.a.j.<init> -> void
        _result = java.util.List.add(v9, v4); // -> boolean
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0019
        v4 = new b.d.a.j;
        v5 = 0;
        v3 = v3[v5];
        v5 = "UTF-8";
        _result = v3.decode(v5); // java.net.URLDecoder.decode -> java.lang.String
        v3 = _result;
        v5 = "";
        _result = v4.<init>(v3, v5); // b.d.a.j.<init> -> void
        _result = java.util.List.add(v9, v4); // -> boolean
        // goto L_0044
        v0 = _exception;
        return;
    }

    static java.lang.String b(java.lang.String p0) {
        // Registers (7 total): v6 = p0 (java.lang.String)
        v5 = 8;
        v3 = -1;
        v4 = 0;
        v0 = "?";
        _result = v6.indexOf(v0); // java.lang.String.indexOf -> int
        v0 = _result;
        if (v3 == v0) /* goto L_0011 */;
        _result = v6.substring(v4, v0); // java.lang.String.substring -> java.lang.String
        v6 = _result;
        v0 = "/";
        _result = v6.indexOf(v0, v5); // java.lang.String.indexOf -> int
        v1 = _result;
        _result = v6.substring(v4, v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        _result = v0.toLowerCase(); // java.lang.String.toLowerCase -> java.lang.String
        v0 = _result;
        v2 = ":";
        _result = v0.indexOf(v2, v5); // java.lang.String.indexOf -> int
        v2 = _result;
        if (v3 == v2) /* goto L_003f */;
        v3 = "http://";
        _result = v0.startsWith(v3); // java.lang.String.startsWith -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0055 */;
        v3 = ":80";
        _result = v0.endsWith(v3); // java.lang.String.endsWith -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0055 */;
        _result = v0.substring(v4, v2); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v6.substring(v1); // java.lang.String.substring -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v3 = "https://";
        _result = v0.startsWith(v3); // java.lang.String.startsWith -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_003f */;
        v3 = ":443";
        _result = v0.endsWith(v3); // java.lang.String.endsWith -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_003f */;
        _result = v0.substring(v4, v2); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        // goto L_003f
    }

    public static java.lang.String b(java.util.List p0) {
        // Registers (3 total): v2 = p0 (java.util.List)
        v0 = "&";
        v1 = 0;
        _result = v2.a(v0, v1); // b.b.f.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    private void b() {
        // Registers (3 total): v2 = this
        v0 = v2.h; // b.b.f.h:b.b.h
        if (v0 != 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "No Token available.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        return;
    }

    public b.b.a a(java.lang.String p0) {
        // Registers (9 total): v7 = this, v8 = p0 (java.lang.String)
        _result = v7.b(); // b.b.f.b -> void
        v0 = new b.b.a;
        v1 = b.b.f.b; // :b.d.a.h
        v2 = v7.a; // b.b.f.a:b.c.a
        _result = b.c.a.k(v2); // -> java.lang.String
        v2 = _result;
        v3 = 1;
        v3 = new b.d.a.j[][size=v3];
        v4 = 0;
        v5 = new b.d.a.j;
        v6 = "oauth_verifier";
        _result = v5.<init>(v6, v8); // b.d.a.j.<init> -> void
        v3[v4] = v5;
        _result = v1.a(v2, v3, v7); // b.d.a.h.a -> b.d.a.l
        v1 = _result;
        _result = v0.<init>(v1); // b.b.a.<init> -> void
        v7.h = v0; // b.b.f.h:b.b.h
        v0 = v7.h; // b.b.f.h:b.b.h
        v0 = (b.b.a) v0;
        return v0;
    }

    public b.b.i a() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.a(v0, v0); // b.b.f.a -> b.b.i
        v0 = _result;
        return v0;
    }

    public b.b.i a(java.lang.String p0, java.lang.String p1) {
        // Registers (8 total): v5 = this, v6 = p0 (java.lang.String), v7 = p1 (java.lang.String)
        v0 = v5.h; // b.b.f.h:b.b.h
        v0 = (v0 instanceof b.b.a);
        if (v0 == 0) /* goto L_000f */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Access token already available.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        if (v6 == 0) /* goto L_0021 */;
        v1 = new b.d.a.j;
        v2 = "oauth_callback";
        _result = v1.<init>(v2, v6); // b.d.a.j.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        if (v7 == 0) /* goto L_002e */;
        v1 = new b.d.a.j;
        v2 = "x_auth_access_type";
        _result = v1.<init>(v2, v7); // b.d.a.j.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = new b.b.i;
        v2 = b.b.f.b; // :b.d.a.h
        v3 = v5.a; // b.b.f.a:b.c.a
        _result = b.c.a.j(v3); // -> java.lang.String
        v3 = _result;
        _result = java.util.List.size(v0); // -> int
        v4 = _result;
        v4 = new b.d.a.j[][size=v4];
        _result = java.util.List.toArray(v0, v4); // -> java.lang.Object[]
        v0 = _result;
        v0 = (b.d.a.j[]) v0;
        _result = v2.a(v3, v0, v5); // b.d.a.h.a -> b.d.a.l
        v0 = _result;
        _result = v1.<init>(v0, v5); // b.b.i.<init> -> void
        v5.h = v1; // b.b.f.h:b.b.h
        v0 = v5.h; // b.b.f.h:b.b.h
        v0 = (b.b.i) v0;
        return v0;
    }

    public java.lang.String a(b.d.a.k p0) {
        // Registers (6 total): v4 = this, v5 = p0 (b.d.a.k)
        _result = v5.a(); // b.d.a.k.a -> b.d.a.p
        v0 = _result;
        _result = v0.name(); // b.d.a.p.name -> java.lang.String
        v0 = _result;
        _result = v5.c(); // b.d.a.k.c -> java.lang.String
        v1 = _result;
        _result = v5.b(); // b.d.a.k.b -> b.d.a.j[]
        v2 = _result;
        v3 = v4.h; // b.b.f.h:b.b.h
        _result = v4.a(v0, v1, v2, v3); // b.b.f.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    java.lang.String a(java.lang.String p0, b.b.h p1) {
        // Registers (7 total): v4 = this, v5 = p0 (java.lang.String), v6 = p1 (b.b.h)
        v0 = "HmacSHA1";
        _result = v0.getInstance(); // javax.crypto.Mac.getInstance -> javax.crypto.Mac
        v1 = _result;
        if (v6 != 0) /* goto L_003f */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = v4.f; // b.b.f.f:java.lang.String
        _result = v2.a(); // b.d.a.j.a -> java.lang.String
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = "&";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        v0 = new javax.crypto.spec.SecretKeySpec;
        _result = v2.getBytes(); // java.lang.String.getBytes -> byte[]
        v2 = _result;
        v3 = "HmacSHA1";
        _result = v0.<init>(v2, v3); // javax.crypto.spec.SecretKeySpec.<init> -> void
        _result = v1.init(v0); // javax.crypto.Mac.init -> void
        _result = v5.getBytes(); // java.lang.String.getBytes -> byte[]
        v0 = _result;
        _result = v1.doFinal(v0); // javax.crypto.Mac.doFinal -> byte[]
        v0 = _result;
        _result = v0.a(); // b.d.a.a.a -> java.lang.String
        v0 = _result;
        return v0;
        _result = v6.d(); // b.b.h.d -> javax.crypto.spec.SecretKeySpec
        v0 = _result;
        if (v0 != 0) /* goto L_002f */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = v4.f; // b.b.f.f:java.lang.String
        _result = v2.a(); // b.d.a.j.a -> java.lang.String
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v2 = "&";
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v6.b(); // b.b.h.b -> java.lang.String
        v2 = _result;
        _result = v2.a(); // b.d.a.j.a -> java.lang.String
        v2 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        v0 = new javax.crypto.spec.SecretKeySpec;
        _result = v2.getBytes(); // java.lang.String.getBytes -> byte[]
        v2 = _result;
        v3 = "HmacSHA1";
        _result = v0.<init>(v2, v3); // javax.crypto.spec.SecretKeySpec.<init> -> void
        _result = v6.a(v0); // b.b.h.a -> void
        // goto L_002f
        v0 = _exception;
        v1 = b.b.f.d; // :b.d.c.a
        v2 = "Failed initialize \"Message Authentication Code\" (MAC)";
        _result = v1.a(v2, v0); // b.d.c.a.a -> void
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
        v0 = _exception;
        v1 = b.b.f.d; // :b.d.c.a
        v2 = "Failed to get HmacSHA1 \"Message Authentication Code\" (MAC)";
        _result = v1.a(v2, v0); // b.d.c.a.a -> void
        v1 = new java.lang.AssertionError;
        _result = v1.<init>(v0); // java.lang.AssertionError.<init> -> void
        throw v1;
    }

    java.lang.String a(java.lang.String p0, java.lang.String p1, b.d.a.j[] p2, b.b.h p3) {
        // Registers (12 total): v7 = this, v8 = p0 (java.lang.String), v9 = p1 (java.lang.String), v10 = p2 (b.d.a.j[]), v11 = p3 (b.b.h)
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v0 = _result;
        v2 = 1000L;
        v0 = binOp2addr_0xbe(v0, v2);
        v2 = b.b.f.i; // :java.util.Random
        _result = v2.nextInt(); // java.util.Random.nextInt -> int
        v2 = _result;
        v2 = unaryOp_0x81(v2);
        v2 = binOp2addr_0xbb(v2, v0);
        _result = v2.valueOf(v3); // java.lang.String.valueOf -> java.lang.String
        v4 = _result;
        _result = v0.valueOf(v1); // java.lang.String.valueOf -> java.lang.String
        v5 = _result;
        v0 = v7;
        v1 = v8;
        v2 = v9;
        v3 = v10;
        v6 = v11;
        _result = v0.a(v0..v6); // b.b.f.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    java.lang.String a(java.lang.String p0, java.lang.String p1, b.d.a.j[] p2, java.lang.String p3, java.lang.String p4, b.b.h p5) {
        // Registers (11 total): v4 = this, v5 = p0 (java.lang.String), v6 = p1 (java.lang.String), v7 = p2 (b.d.a.j[]), v8 = p3 (java.lang.String), v9 = p4 (java.lang.String), v10 = p5 (b.b.h)
        if (v7 != 0) /* goto L_0005 */;
        v0 = 0;
        v7 = new b.d.a.j[][size=v0];
        v0 = new java.util.ArrayList;
        v1 = 5;
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v1 = new b.d.a.j;
        v2 = "oauth_consumer_key";
        v3 = v4.e; // b.b.f.e:java.lang.String
        _result = v1.<init>(v2, v3); // b.d.a.j.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = b.b.f.c; // :b.d.a.j
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = new b.d.a.j;
        v2 = "oauth_timestamp";
        _result = v1.<init>(v2, v9); // b.d.a.j.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = new b.d.a.j;
        v2 = "oauth_nonce";
        _result = v1.<init>(v2, v8); // b.d.a.j.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = new b.d.a.j;
        v2 = "oauth_version";
        v3 = "1.0";
        _result = v1.<init>(v2, v3); // b.d.a.j.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        if (v10 == 0) /* goto L_0052 */;
        v1 = new b.d.a.j;
        v2 = "oauth_token";
        _result = v10.c(); // b.b.h.c -> java.lang.String
        v3 = _result;
        _result = v1.<init>(v2, v3); // b.d.a.j.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = new java.util.ArrayList;
        _result = java.util.List.size(v0); // -> int
        v2 = _result;
        v3 = v7.length;
        v2 = binOp2addr_0xb0(v2, v3);
        _result = v1.<init>(v2); // java.util.ArrayList.<init> -> void
        _result = java.util.List.addAll(v1, v0); // -> boolean
        _result = v7.a(); // b.d.a.j.a -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_006d */;
        _result = v7.a(); // b.b.f.a -> java.util.List
        v2 = _result;
        _result = java.util.List.addAll(v1, v2); // -> boolean
        _result = v4.a(v6, v1); // b.b.f.a -> void
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(v5); // java.lang.StringBuilder.<init> -> void
        v3 = "&";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v6.b(); // b.b.f.b -> java.lang.String
        v3 = _result;
        _result = v3.a(); // b.d.a.j.a -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = "&";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v1.a(); // b.b.f.a -> java.lang.String
        v1 = _result;
        _result = v1.a(); // b.d.a.j.a -> java.lang.String
        v1 = _result;
        _result = v2.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        v2 = b.b.f.d; // :b.d.c.a
        v3 = "OAuth base string: ";
        _result = v2.a(v3, v1); // b.d.c.a.a -> void
        _result = v4.a(v1, v10); // b.b.f.a -> java.lang.String
        v1 = _result;
        v2 = b.b.f.d; // :b.d.c.a
        v3 = "OAuth signature: ";
        _result = v2.a(v3, v1); // b.d.c.a.a -> void
        v2 = new b.d.a.j;
        v3 = "oauth_signature";
        _result = v2.<init>(v3, v1); // b.d.a.j.<init> -> void
        _result = java.util.List.add(v0, v2); // -> boolean
        v1 = v4.g; // b.b.f.g:java.lang.String
        if (v1 == 0) /* goto L_00ce */;
        v1 = new b.d.a.j;
        v2 = "realm";
        v3 = v4.g; // b.b.f.g:java.lang.String
        _result = v1.<init>(v2, v3); // b.d.a.j.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "OAuth ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        v3 = 1;
        _result = v0.a(v2, v3); // b.b.f.a -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void a(b.b.a p0) {
        // Registers (2 total): v0 = this, v1 = p0 (b.b.a)
        v0.h = v1; // b.b.f.h:b.b.h
        return;
    }

    public void b(java.lang.String p0, java.lang.String p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (java.lang.String)
        if (v1 == 0) /* goto L_0009 */;
        v0.e = v1; // b.b.f.e:java.lang.String
        if (v2 == 0) /* goto L_000d */;
        v0.f = v2; // b.b.f.f:java.lang.String
        return;
        v1 = "";
        // goto L_0002
        v2 = "";
        // goto L_0006
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        v2 = (v5 instanceof b.b.g);
        if (v2 != 0) /* goto L_000b */;
        v0 = v1;
        // goto L_0004
        v5 = (b.b.f) v5;
        v2 = v4.e; // b.b.f.e:java.lang.String
        if (v2 == 0) /* goto L_001d */;
        v2 = v4.e; // b.b.f.e:java.lang.String
        v3 = v5.e; // b.b.f.e:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0021 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.e; // b.b.f.e:java.lang.String
        if (v2 != 0) /* goto L_001b */;
        v2 = v4.f; // b.b.f.f:java.lang.String
        if (v2 == 0) /* goto L_0031 */;
        v2 = v4.f; // b.b.f.f:java.lang.String
        v3 = v5.f; // b.b.f.f:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0035 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.f; // b.b.f.f:java.lang.String
        if (v2 != 0) /* goto L_002f */;
        v2 = v4.h; // b.b.f.h:b.b.h
        if (v2 == 0) /* goto L_0045 */;
        v2 = v4.h; // b.b.f.h:b.b.h
        v3 = v5.h; // b.b.f.h:b.b.h
        _result = v2.equals(v3); // b.b.h.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.h; // b.b.f.h:b.b.h
        if (v2 == 0) /* goto L_0004 */;
        // goto L_0043
    }

    public int hashCode() {
        // Registers (4 total): v3 = this
        v1 = 0;
        v0 = v3.e; // b.b.f.e:java.lang.String
        if (v0 == 0) /* goto L_0026 */;
        v0 = v3.e; // b.b.f.e:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        v2 = binOpLit8_0xda(v0, 31);
        v0 = v3.f; // b.b.f.f:java.lang.String
        if (v0 == 0) /* goto L_0028 */;
        v0 = v3.f; // b.b.f.f:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v2);
        v0 = binOpLit8_0xda(v0, 31);
        v2 = v3.h; // b.b.f.h:b.b.h
        if (v2 == 0) /* goto L_0024 */;
        v1 = v3.h; // b.b.f.h:b.b.h
        _result = v1.hashCode(); // b.b.h.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v0 = v1;
        // goto L_000b
        v0 = v1;
        // goto L_0017
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "OAuthAuthorization{consumerKey='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.e; // b.b.f.e:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 39;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", consumerSecret='******************************************'";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", oauthToken=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.h; // b.b.f.h:b.b.h
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}