package b.b;

/**
 * Original SourceFile: AuthorizationFactory.java
 * Descriptor: Lb/b/c;
 */
public final class c {
    public static b.b.b a(b.c.a p0) {
        // Registers (5 total): v4 = p0 (b.c.a)
        v0 = 0;
        _result = b.c.a.f(v4); // -> java.lang.String
        v1 = _result;
        _result = b.c.a.g(v4); // -> java.lang.String
        v2 = _result;
        if (v1 == 0) /* goto L_002d */;
        if (v2 == 0) /* goto L_002d */;
        v0 = new b.b.f;
        _result = v0.<init>(v4); // b.b.f.<init> -> void
        _result = b.c.a.h(v4); // -> java.lang.String
        v1 = _result;
        _result = b.c.a.i(v4); // -> java.lang.String
        v2 = _result;
        if (v1 == 0) /* goto L_0026 */;
        if (v2 == 0) /* goto L_0026 */;
        v3 = new b.b.a;
        _result = v3.<init>(v1, v2); // b.b.a.<init> -> void
        _result = v0.a(v3); // b.b.f.a -> void
        if (v0 != 0) /* goto L_002c */;
        _result = this.a(); // b.b.e.a -> b.b.e
        v0 = _result;
        return v0;
        _result = b.c.a.d(v4); // -> java.lang.String
        v1 = _result;
        _result = b.c.a.e(v4); // -> java.lang.String
        v2 = _result;
        if (v1 == 0) /* goto L_0026 */;
        if (v2 == 0) /* goto L_0026 */;
        v0 = new b.b.d;
        _result = v0.<init>(v1, v2); // b.b.d.<init> -> void
        // goto L_0026
    }

}