package b.b;

/**
 * Original SourceFile: Authorization.java
 * Descriptor: Lb/b/b;
 */
public interface b extends java.io.Serializable {
    public abstract java.lang.String a(b.d.a.k p0);
}