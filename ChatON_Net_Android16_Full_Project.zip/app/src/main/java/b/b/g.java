package b.b;

/**
 * Original SourceFile: OAuthSupport.java
 * Descriptor: Lb/b/g;
 */
public interface g {
    public abstract b.b.a a(java.lang.String p0);
    public abstract b.b.i a();
    public abstract void a(b.b.a p0);
    public abstract void b(java.lang.String p0, java.lang.String p1);
}