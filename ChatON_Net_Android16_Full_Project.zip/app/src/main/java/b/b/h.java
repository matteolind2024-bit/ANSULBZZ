package b.b;

/**
 * Original SourceFile: OAuthToken.java
 * Descriptor: Lb/b/h;
 */
abstract class h implements java.io.Serializable {
     java.lang.String[] a;
    private java.lang.String b;
    private java.lang.String c;
    private transient javax.crypto.spec.SecretKeySpec d;

    h(b.d.a.l p0) {
        // Registers (3 total): v1 = this, v2 = p0 (b.d.a.l)
        _result = v2.c(); // b.d.a.l.c -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // b.b.h.<init> -> void
        return;
    }

    h(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v1.a = v0; // b.b.h.a:java.lang.String[]
        v0 = "&";
        _result = v2.a(v0); // b.d.e.a.a -> java.lang.String[]
        v0 = _result;
        v1.a = v0; // b.b.h.a:java.lang.String[]
        v0 = "oauth_token_secret";
        _result = v1.a(v0); // b.b.h.a -> java.lang.String
        v0 = _result;
        v1.c = v0; // b.b.h.c:java.lang.String
        v0 = "oauth_token";
        _result = v1.a(v0); // b.b.h.a -> java.lang.String
        v0 = _result;
        v1.b = v0; // b.b.h.b:java.lang.String
        return;
    }

    public h(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v1.a = v0; // b.b.h.a:java.lang.String[]
        v1.b = v2; // b.b.h.b:java.lang.String
        v1.c = v3; // b.b.h.c:java.lang.String
        return;
    }

    public java.lang.String a(java.lang.String p0) {
        // Registers (9 total): v7 = this, v8 = p0 (java.lang.String)
        v0 = 0;
        v2 = v7.a; // b.b.h.a:java.lang.String[]
        v3 = v2.length;
        v1 = 0;
        if (v1 >= v3) /* goto L_0030 */;
        v4 = v2[v1];
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v5.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = 61;
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v5 = _result;
        _result = v4.startsWith(v5); // java.lang.String.startsWith -> boolean
        v5 = _result;
        if (v5 == 0) /* goto L_0031 */;
        v0 = "=";
        _result = v4.a(v0); // b.d.e.a.a -> java.lang.String[]
        v0 = _result;
        v1 = 1;
        v0 = v0[v1];
        _result = v0.trim(); // java.lang.String.trim -> java.lang.String
        v0 = _result;
        return v0;
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0005
    }

    void a(javax.crypto.spec.SecretKeySpec p0) {
        // Registers (2 total): v0 = this, v1 = p0 (javax.crypto.spec.SecretKeySpec)
        v0.d = v1; // b.b.h.d:javax.crypto.spec.SecretKeySpec
        return;
    }

    public java.lang.String b() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // b.b.h.c:java.lang.String
        return v0;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // b.b.h.b:java.lang.String
        return v0;
    }

    javax.crypto.spec.SecretKeySpec d() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // b.b.h.d:javax.crypto.spec.SecretKeySpec
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        v2 = (v5 instanceof b.b.h);
        if (v2 != 0) /* goto L_000b */;
        v0 = v1;
        // goto L_0004
        v5 = (b.b.h) v5;
        v2 = v4.b; // b.b.h.b:java.lang.String
        v3 = v5.b; // b.b.h.b:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0019 */;
        v0 = v1;
        // goto L_0004
        v2 = v4.c; // b.b.h.c:java.lang.String
        v3 = v5.c; // b.b.h.c:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public int hashCode() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // b.b.h.b:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.c; // b.b.h.c:java.lang.String
        _result = v1.hashCode(); // java.lang.String.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        v2 = 39;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "OAuthToken{token='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.b; // b.b.h.b:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", tokenSecret='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.c; // b.b.h.c:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", secretKeySpec=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.d; // b.b.h.d:javax.crypto.spec.SecretKeySpec
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}