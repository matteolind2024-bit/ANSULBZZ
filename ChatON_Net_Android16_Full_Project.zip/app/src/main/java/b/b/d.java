package b.b;

/**
 * Original SourceFile: BasicAuthorization.java
 * Descriptor: Lb/b/d;
 */
public class d implements b.b.b, java.io.Serializable {
    private java.lang.String a;
    private java.lang.String b;
    private java.lang.String c;

    public d(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v1.a = v2; // b.b.d.a:java.lang.String
        v1.b = v3; // b.b.d.b:java.lang.String
        _result = v1.a(); // b.b.d.a -> java.lang.String
        v0 = _result;
        v1.c = v0; // b.b.d.c:java.lang.String
        return;
    }

    private java.lang.String a() {
        // Registers (4 total): v3 = this
        v0 = v3.a; // b.b.d.a:java.lang.String
        if (v0 == 0) /* goto L_0041 */;
        v0 = v3.b; // b.b.d.b:java.lang.String
        if (v0 == 0) /* goto L_0041 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "Basic ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = v3.a; // b.b.d.a:java.lang.String
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ":";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = v3.b; // b.b.d.b:java.lang.String
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v1.getBytes(); // java.lang.String.getBytes -> byte[]
        v1 = _result;
        _result = v1.a(); // b.d.a.a.a -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_0040
    }

    public java.lang.String a(b.d.a.k p0) {
        // Registers (3 total): v1 = this, v2 = p0 (b.d.a.k)
        v0 = v1.c; // b.b.d.c:java.lang.String
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        if (v2 != v3) /* goto L_0004 */;
        v0 = 1;
        return v0;
        v0 = (v3 instanceof b.b.d);
        if (v0 != 0) /* goto L_000a */;
        v0 = 0;
        // goto L_0003
        v3 = (b.b.d) v3;
        v0 = v2.c; // b.b.d.c:java.lang.String
        v1 = v3.c; // b.b.d.c:java.lang.String
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        // goto L_0003
    }

    public int hashCode() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // b.b.d.c:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        return v0;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "BasicAuthorization{userId='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.a; // b.b.d.a:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 39;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", password='**********''";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}