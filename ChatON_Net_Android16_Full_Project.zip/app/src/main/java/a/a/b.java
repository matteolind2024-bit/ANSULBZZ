package a.a;

/**
 * Original SourceFile: SStreamContentManager.java
 * Descriptor: La/a/b;
 */
public class b {
    private static boolean a;
    private static boolean b;

    static {
        v0 = 0;
        a.a.b.a = v0; // :boolean
        v0 = 1;
        a.a.b.b = v0; // :boolean
        return;
    }

    private static android.content.ContentValues a(a.a.b.d p0) {
        // Registers (10 total): v9 = p0 (a.a.b.d)
        _result = v9.b(); // a.a.b.b -> void
        v2 = new android.content.ContentValues;
        _result = v2.<init>(); // android.content.ContentValues.<init> -> void
        _result = v9.f(); // a.a.b.d.f -> long
        v0 = _result;
        v3 = unaryOp_0x86(v0);
        v5 = 0x4024000000000000L;
        v7 = 0x4028000000000000L;
        _result = v5.pow(v6, v7, v8); // java.lang.Math.pow -> double
        v5 = _result;
        v3 = cmp(v3, v5);
        if (v3 < 0) /* goto L_001c */;
        v3 = 1000L;
        v0 = binOp2addr_0xbe(v0, v3);
        v3 = "id";
        _result = v9.c(); // a.a.b.d.c -> java.lang.String
        v4 = _result;
        _result = v2.put(v3, v4); // android.content.ContentValues.put -> void
        v3 = "stream_id";
        _result = v9.h(); // a.a.b.d.h -> java.lang.String
        v4 = _result;
        _result = v2.put(v3, v4); // android.content.ContentValues.put -> void
        v3 = "category";
        _result = v9.a(); // a.a.b.d.a -> java.lang.String
        v4 = _result;
        _result = v2.put(v3, v4); // android.content.ContentValues.put -> void
        v3 = "application_name";
        _result = v9.i(); // a.a.b.d.i -> java.lang.String
        v4 = _result;
        _result = v2.put(v3, v4); // android.content.ContentValues.put -> void
        v3 = "title";
        _result = v9.b(); // a.a.b.d.b -> java.lang.String
        v4 = _result;
        _result = v2.put(v3, v4); // android.content.ContentValues.put -> void
        v3 = "body";
        _result = v9.e(); // a.a.b.d.e -> java.lang.String
        v4 = _result;
        _result = v2.put(v3, v4); // android.content.ContentValues.put -> void
        v3 = "type";
        _result = v9.j(); // a.a.b.d.j -> a.a.b.e
        v4 = _result;
        _result = v4.toString(); // a.a.b.e.toString -> java.lang.String
        v4 = _result;
        _result = v2.put(v3, v4); // android.content.ContentValues.put -> void
        v3 = "author_name";
        _result = v9.d(); // a.a.b.d.d -> a.a.b.a
        v4 = _result;
        _result = v4.a(); // a.a.b.a.a -> java.lang.String
        v4 = _result;
        _result = v2.put(v3, v4); // android.content.ContentValues.put -> void
        v3 = "time_stamp";
        _result = v0.valueOf(v1); // java.lang.Long.valueOf -> java.lang.Long
        v0 = _result;
        _result = v2.put(v3, v0); // android.content.ContentValues.put -> void
        v0 = "more";
        _result = v9.k(); // a.a.b.d.k -> int
        v1 = _result;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v2.put(v0, v1); // android.content.ContentValues.put -> void
        v0 = "source";
        _result = v9.l(); // a.a.b.d.l -> java.lang.String
        v1 = _result;
        _result = v2.put(v0, v1); // android.content.ContentValues.put -> void
        _result = v9.g(); // a.a.b.d.g -> a.a.b.b
        v0 = _result;
        if (v0 == 0) /* goto L_00dc */;
        v0 = "image_url";
        _result = v9.g(); // a.a.b.d.g -> a.a.b.b
        v1 = _result;
        _result = v1.a(); // a.a.b.b.a -> java.lang.String
        v1 = _result;
        _result = v2.put(v0, v1); // android.content.ContentValues.put -> void
        v0 = "image_hints";
        _result = v9.g(); // a.a.b.d.g -> a.a.b.b
        v1 = _result;
        _result = v1.d(); // a.a.b.b.d -> java.lang.String
        v1 = _result;
        _result = v2.put(v0, v1); // android.content.ContentValues.put -> void
        v0 = "image_height";
        _result = v9.g(); // a.a.b.d.g -> a.a.b.b
        v1 = _result;
        _result = v1.c(); // a.a.b.b.c -> int
        v1 = _result;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v2.put(v0, v1); // android.content.ContentValues.put -> void
        v0 = "image_width";
        _result = v9.g(); // a.a.b.d.g -> a.a.b.b
        v1 = _result;
        _result = v1.b(); // a.a.b.b.b -> int
        v1 = _result;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v2.put(v0, v1); // android.content.ContentValues.put -> void
        _result = v9.d(); // a.a.b.d.d -> a.a.b.a
        v0 = _result;
        _result = v0.b(); // a.a.b.a.b -> a.a.b.b
        v0 = _result;
        if (v0 == 0) /* goto L_0124 */;
        v0 = "author_image_url";
        _result = v9.d(); // a.a.b.d.d -> a.a.b.a
        v1 = _result;
        _result = v1.b(); // a.a.b.a.b -> a.a.b.b
        v1 = _result;
        _result = v1.a(); // a.a.b.b.a -> java.lang.String
        v1 = _result;
        _result = v2.put(v0, v1); // android.content.ContentValues.put -> void
        v0 = "author_image_height";
        _result = v9.d(); // a.a.b.d.d -> a.a.b.a
        v1 = _result;
        _result = v1.b(); // a.a.b.a.b -> a.a.b.b
        v1 = _result;
        _result = v1.c(); // a.a.b.b.c -> int
        v1 = _result;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v2.put(v0, v1); // android.content.ContentValues.put -> void
        v0 = "author_image_width";
        _result = v9.d(); // a.a.b.d.d -> a.a.b.a
        v1 = _result;
        _result = v1.b(); // a.a.b.a.b -> a.a.b.b
        v1 = _result;
        _result = v1.b(); // a.a.b.b.b -> int
        v1 = _result;
        _result = v1.valueOf(); // java.lang.Integer.valueOf -> java.lang.Integer
        v1 = _result;
        _result = v2.put(v0, v1); // android.content.ContentValues.put -> void
        return v2;
    }

    public static java.lang.String a(android.content.Intent p0) {
        // Registers (5 total): v4 = p0 (android.content.Intent)
        v0 = 0;
        if (v4 != 0) /* goto L_0004 */;
        return v0;
        _result = v4.getData(); // android.content.Intent.getData -> android.net.Uri
        v1 = _result;
        if (v1 == 0) /* goto L_0003 */;
        _result = v1.getScheme(); // android.net.Uri.getScheme -> java.lang.String
        v2 = _result;
        if (v2 == 0) /* goto L_0003 */;
        _result = v1.getScheme(); // android.net.Uri.getScheme -> java.lang.String
        v2 = _result;
        v3 = "sstream";
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0003 */;
        _result = v1.getHost(); // android.net.Uri.getHost -> java.lang.String
        v2 = _result;
        if (v2 == 0) /* goto L_0003 */;
        _result = v1.getHost(); // android.net.Uri.getHost -> java.lang.String
        v2 = _result;
        v3 = "storyitem";
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0003 */;
        _result = v1.getLastPathSegment(); // android.net.Uri.getLastPathSegment -> java.lang.String
        v0 = _result;
        v1 = java.lang.System.out; // :java.io.PrintStream
        v2 = new java.lang.StringBuilder;
        v3 = "StoryItem ";
        _result = v2.<init>(v3); // java.lang.StringBuilder.<init> -> void
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.println(v2); // java.io.PrintStream.println -> void
        // goto L_0003
    }

    public static void a(android.content.Context p0, a.a.b.d p1) {
        // Registers (5 total): v3 = p0 (android.content.Context), v4 = p1 (a.a.b.d)
        _result = v3.a(); // a.a.b.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0007 */;
        return;
        _result = v3.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v0 = _result;
        v1 = a.a.a.a.b; // :android.net.Uri
        _result = v4.a(); // a.a.b.a -> android.content.ContentValues
        v2 = _result;
        _result = v0.insert(v1, v2); // android.content.ContentResolver.insert -> android.net.Uri
        // goto L_0006
    }

    public static void a(android.content.Context p0, java.lang.String p1, java.lang.String p2) {
        // Registers (7 total): v4 = p0 (android.content.Context), v5 = p1 (java.lang.String), v6 = p2 (java.lang.String)
        _result = v4.a(); // a.a.b.a -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0007 */;
        return;
        if (v6 != 0) /* goto L_0012 */;
        v0 = new java.lang.NullPointerException;
        v1 = "streamId is missing";
        _result = v0.<init>(v1); // java.lang.NullPointerException.<init> -> void
        throw v0;
        v0 = "application_name=? AND stream_id=?";
        v1 = 3;
        v1 = new java.lang.String[][size=v1];
        v2 = 0;
        v3 = "";
        v1[v2] = v3;
        v2 = 1;
        v1[v2] = v5;
        v2 = 2;
        v1[v2] = v6;
        _result = v4.getContentResolver(); // android.content.Context.getContentResolver -> android.content.ContentResolver
        v2 = _result;
        v3 = a.a.a.a.d; // :android.net.Uri
        _result = v2.delete(v3, v0, v1); // android.content.ContentResolver.delete -> int
        // goto L_0006
    }

    private static boolean a(android.content.Context p0) {
        // Registers (4 total): v3 = p0 (android.content.Context)
        v1 = 1;
        v2 = 0;
        v0 = a.a.b.a; // :boolean
        if (v0 != 0) /* goto L_0019 */;
        a.a.b.a = v1; // :boolean
        _result = v3.getPackageManager(); // android.content.Context.getPackageManager -> android.content.pm.PackageManager
        v0 = _result;
        v1 = "sstream.app";
        _result = v0.getApplicationEnabledSetting(v1); // android.content.pm.PackageManager.getApplicationEnabledSetting -> int
        v0 = _result;
        // switch(v0)
        v0 = 0;
        a.a.b.b = v0; // :boolean
        v0 = a.a.b.b; // :boolean
        if (v0 != 0) /* goto L_0026 */;
        v0 = "SStreamContentManager";
        v1 = "SStream is disabled  or not installed";
        _result = v0.d(v1); // android.util.Log.d -> int
        v0 = a.a.b.b; // :boolean
        return v0;
        v0 = 1;
        a.a.b.b = v0; // :boolean
        // goto L_0019
        v0 = _exception;
        a.a.b.b = v2; // :boolean
        // goto L_0019
    }

    private static void b(a.a.b.d p0) {
        // Registers (6 total): v5 = p0 (a.a.b.d)
        if (v5 != 0) /* goto L_000b */;
        v0 = new a.a.a;
        v1 = "StoryItem is null";
        _result = v0.<init>(v1); // a.a.a.<init> -> void
        throw v0;
        v0 = "";
        _result = v5.c(); // a.a.b.d.c -> java.lang.String
        v1 = _result;
        if (v1 != 0) /* goto L_0017 */;
        v0 = "id";
        _result = v5.h(); // a.a.b.d.h -> java.lang.String
        v1 = _result;
        if (v1 != 0) /* goto L_0037 */;
        v1 = new java.lang.StringBuilder;
        _result = v0.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        _result = v0.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0070 */;
        v0 = "streamId";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v5.i(); // a.a.b.d.i -> java.lang.String
        v1 = _result;
        if (v1 != 0) /* goto L_0057 */;
        v1 = new java.lang.StringBuilder;
        _result = v0.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2); // java.lang.StringBuilder.<init> -> void
        _result = v0.isEmpty(); // java.lang.String.isEmpty -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0074 */;
        v0 = "appPackage";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.isEmpty(); // java.lang.String.isEmpty -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0078 */;
        v1 = new a.a.a;
        v2 = "StoryItem is incomplete. The following properties are missing: %s";
        v3 = 1;
        v3 = new java.lang.Object[][size=v3];
        v4 = 0;
        v3[v4] = v0;
        _result = v2.format(v3); // java.lang.String.format -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // a.a.a.<init> -> void
        throw v1;
        v0 = ", streamId";
        // goto L_002f
        v0 = ", appPackage";
        // goto L_004f
        return;
    }

    public static boolean b(android.content.Intent p0) {
        // Registers (5 total): v4 = p0 (android.content.Intent)
        v0 = 0;
        if (v4 != 0) /* goto L_0004 */;
        return v0;
        _result = v4.getData(); // android.content.Intent.getData -> android.net.Uri
        v1 = _result;
        if (v1 == 0) /* goto L_0003 */;
        _result = v1.getScheme(); // android.net.Uri.getScheme -> java.lang.String
        v2 = _result;
        if (v2 == 0) /* goto L_0003 */;
        _result = v1.getScheme(); // android.net.Uri.getScheme -> java.lang.String
        v2 = _result;
        v3 = "sstream";
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0003 */;
        _result = v1.getHost(); // android.net.Uri.getHost -> java.lang.String
        v2 = _result;
        if (v2 == 0) /* goto L_0003 */;
        _result = v1.getHost(); // android.net.Uri.getHost -> java.lang.String
        v2 = _result;
        v3 = "storyitem";
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0003 */;
        v2 = "more";
        _result = v1.getQueryParameter(v2); // android.net.Uri.getQueryParameter -> java.lang.String
        v2 = _result;
        if (v2 == 0) /* goto L_004a */;
        v2 = "more";
        _result = v1.getQueryParameter(v2); // android.net.Uri.getQueryParameter -> java.lang.String
        v1 = _result;
        v2 = "true";
        _result = v1.equals(v2); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_004a */;
        v0 = 1;
        v1 = java.lang.System.out; // :java.io.PrintStream
        v2 = new java.lang.StringBuilder;
        v3 = "isMore ";
        _result = v2.<init>(v3); // java.lang.StringBuilder.<init> -> void
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.println(v2); // java.io.PrintStream.println -> void
        // goto L_0003
    }

}