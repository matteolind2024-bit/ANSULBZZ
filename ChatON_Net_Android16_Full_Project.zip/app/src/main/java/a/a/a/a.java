package a.a.a;

/**
 * Original SourceFile: StreamProviderConstants.java
 * Descriptor: La/a/a/a;
 */
public class a {
    public static final android.net.Uri a;
    public static final android.net.Uri b;
    public static final android.net.Uri c;
    public static final android.net.Uri d;
    public static final java.lang.String[] e;

    static {
        v0 = "content://sstream.app.provider.StoryProvider";
        _result = v0.parse(); // android.net.Uri.parse -> android.net.Uri
        v0 = _result;
        a.a.a.a.a = v0; // :android.net.Uri
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = a.a.a.a.a; // :android.net.Uri
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "/";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "story";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.parse(); // android.net.Uri.parse -> android.net.Uri
        v0 = _result;
        a.a.a.a.b = v0; // :android.net.Uri
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = a.a.a.a.b; // :android.net.Uri
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "/";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "delete";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.parse(); // android.net.Uri.parse -> android.net.Uri
        v0 = _result;
        a.a.a.a.c = v0; // :android.net.Uri
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = a.a.a.a.b; // :android.net.Uri
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "/";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "delete_bulk";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.parse(); // android.net.Uri.parse -> android.net.Uri
        v0 = _result;
        a.a.a.a.d = v0; // :android.net.Uri
        v0 = 18;
        v0 = new java.lang.String[][size=v0];
        v1 = 0;
        v2 = "id";
        v0[v1] = v2;
        v1 = 1;
        v2 = "stream_id";
        v0[v1] = v2;
        v1 = 2;
        v2 = "application_name";
        v0[v1] = v2;
        v1 = 3;
        v2 = "category";
        v0[v1] = v2;
        v1 = 4;
        v2 = "type";
        v0[v1] = v2;
        v1 = 5;
        v2 = "title";
        v0[v1] = v2;
        v1 = 6;
        v2 = "body";
        v0[v1] = v2;
        v1 = 7;
        v2 = "image_url";
        v0[v1] = v2;
        v1 = 8;
        v2 = "image_hints";
        v0[v1] = v2;
        v1 = 9;
        v2 = "image_height";
        v0[v1] = v2;
        v1 = 10;
        v2 = "image_width";
        v0[v1] = v2;
        v1 = 11;
        v2 = "author_name";
        v0[v1] = v2;
        v1 = 12;
        v2 = "author_image_url";
        v0[v1] = v2;
        v1 = 13;
        v2 = "author_image_height";
        v0[v1] = v2;
        v1 = 14;
        v2 = "author_image_width";
        v0[v1] = v2;
        v1 = 15;
        v2 = "time_stamp";
        v0[v1] = v2;
        v1 = 16;
        v2 = "more";
        v0[v1] = v2;
        v1 = 17;
        v2 = "source";
        v0[v1] = v2;
        a.a.a.a.e = v0; // :java.lang.String[]
        return;
    }

}