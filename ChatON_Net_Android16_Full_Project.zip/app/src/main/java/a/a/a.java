package a.a;

/**
 * Original SourceFile: InvalidStoryItemException.java
 * Descriptor: La/a/a;
 */
public class a extends java.lang.Exception {
    public a(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        _result = v0.<init>(v1); // java.lang.Exception.<init> -> void
        return;
    }

}