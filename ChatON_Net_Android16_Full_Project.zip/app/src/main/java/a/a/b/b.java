package a.a.b;

/**
 * Original SourceFile: Image.java
 * Descriptor: La/a/b/b;
 */
public class b {
    private java.lang.String a;
    private int b;
    private int c;
    private java.lang.String d;

    public b(java.lang.String p0, int p1, int p2, java.lang.String p3) {
        // Registers (6 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (int), v4 = p2 (int), v5 = p3 (java.lang.String)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v1.a = v2; // a.a.b.b.a:java.lang.String
        if (v2 == 0) /* goto L_000f */;
        if (v3 == 0) /* goto L_000b */;
        if (v4 != 0) /* goto L_000f */;
        v3 = 480;
        v4 = 320;
        v1.b = v3; // a.a.b.b.b:int
        v1.c = v4; // a.a.b.b.c:int
        if (v5 == 0) /* goto L_002a */;
        v0 = a.a.b.c.a; // :a.a.b.c
        _result = v0.toString(); // a.a.b.c.toString -> java.lang.String
        v0 = _result;
        _result = v5.equalsIgnoreCase(v0); // java.lang.String.equalsIgnoreCase -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_002a */;
        v0 = a.a.b.c.a; // :a.a.b.c
        _result = v0.toString(); // a.a.b.c.toString -> java.lang.String
        v0 = _result;
        v1.d = v0; // a.a.b.b.d:java.lang.String
        return;
        v0 = a.a.b.c.b; // :a.a.b.c
        _result = v0.toString(); // a.a.b.c.toString -> java.lang.String
        v0 = _result;
        // goto L_0027
    }

    public java.lang.String a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // a.a.b.b.a:java.lang.String
        return v0;
    }

    public int b() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // a.a.b.b.b:int
        return v0;
    }

    public int c() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // a.a.b.b.c:int
        return v0;
    }

    public java.lang.String d() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // a.a.b.b.d:java.lang.String
        _result = v0.toString(); // java.lang.String.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}