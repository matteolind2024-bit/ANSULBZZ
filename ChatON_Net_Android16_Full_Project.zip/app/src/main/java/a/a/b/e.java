package a.a.b;

/**
 * Original SourceFile: StoryItem.java
 * Descriptor: La/a/b/e;
 */
public final enum e {
    public static final a.a.b.e a;
    public static final a.a.b.e b;
    public static final a.a.b.e c;
    public static final a.a.b.e d;
    private static final a.a.b.e[] e;

    static {
        v5 = 3;
        v4 = 2;
        v3 = 1;
        v2 = 0;
        v0 = new a.a.b.e;
        v1 = "CALL";
        _result = v0.<init>(v1, v2); // a.a.b.e.<init> -> void
        a.a.b.e.a = v0; // :a.a.b.e
        v0 = new a.a.b.e;
        v1 = "MESSAGE";
        _result = v0.<init>(v1, v3); // a.a.b.e.<init> -> void
        a.a.b.e.b = v0; // :a.a.b.e
        v0 = new a.a.b.e;
        v1 = "CALENDAR";
        _result = v0.<init>(v1, v4); // a.a.b.e.<init> -> void
        a.a.b.e.c = v0; // :a.a.b.e
        v0 = new a.a.b.e;
        v1 = "ARTICLE";
        _result = v0.<init>(v1, v5); // a.a.b.e.<init> -> void
        a.a.b.e.d = v0; // :a.a.b.e
        v0 = 4;
        v0 = new a.a.b.e[][size=v0];
        v1 = a.a.b.e.a; // :a.a.b.e
        v0[v2] = v1;
        v1 = a.a.b.e.b; // :a.a.b.e
        v0[v3] = v1;
        v1 = a.a.b.e.c; // :a.a.b.e
        v0[v4] = v1;
        v1 = a.a.b.e.d; // :a.a.b.e
        v0[v5] = v1;
        a.a.b.e.e = v0; // :a.a.b.e[]
        return;
    }

    private e(java.lang.String p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        return;
    }

    public static a.a.b.e valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = a.a.b.e.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (a.a.b.e) v0;
        return v0;
    }

    public static a.a.b.e[] values() {
        v3 = 0;
        v0 = a.a.b.e.e; // :a.a.b.e[]
        v1 = v0.length;
        v2 = new a.a.b.e[][size=v1];
        _result = v0.arraycopy(v3, v2, v3, v1); // java.lang.System.arraycopy -> void
        return v2;
    }

}