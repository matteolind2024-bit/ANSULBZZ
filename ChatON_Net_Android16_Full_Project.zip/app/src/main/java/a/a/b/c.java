package a.a.b;

/**
 * Original SourceFile: Image.java
 * Descriptor: La/a/b/c;
 */
public final enum c {
    public static final a.a.b.c a;
    public static final a.a.b.c b;
    private static final a.a.b.c[] c;

    static {
        v3 = 1;
        v2 = 0;
        v0 = new a.a.b.c;
        v1 = "NO_OVERLAY_NO_CROP";
        _result = v0.<init>(v1, v2); // a.a.b.c.<init> -> void
        a.a.b.c.a = v0; // :a.a.b.c
        v0 = new a.a.b.c;
        v1 = "NORMAL";
        _result = v0.<init>(v1, v3); // a.a.b.c.<init> -> void
        a.a.b.c.b = v0; // :a.a.b.c
        v0 = 2;
        v0 = new a.a.b.c[][size=v0];
        v1 = a.a.b.c.a; // :a.a.b.c
        v0[v2] = v1;
        v1 = a.a.b.c.b; // :a.a.b.c
        v0[v3] = v1;
        a.a.b.c.c = v0; // :a.a.b.c[]
        return;
    }

    private c(java.lang.String p0, int p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (int)
        _result = v0.<init>(v1, v2); // java.lang.Enum.<init> -> void
        return;
    }

    public static a.a.b.c valueOf(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = a.a.b.c.class;
        _result = v0.valueOf(v1); // java.lang.Enum.valueOf -> java.lang.Enum
        v0 = _result;
        v0 = (a.a.b.c) v0;
        return v0;
    }

    public static a.a.b.c[] values() {
        v3 = 0;
        v0 = a.a.b.c.c; // :a.a.b.c[]
        v1 = v0.length;
        v2 = new a.a.b.c[][size=v1];
        _result = v0.arraycopy(v3, v2, v3, v1); // java.lang.System.arraycopy -> void
        return v2;
    }

}