package a.a.b;

/**
 * Original SourceFile: StoryItem.java
 * Descriptor: La/a/b/d;
 */
public class d {
    private java.lang.String a;
    private java.lang.String b;
    private java.lang.String c;
    private java.lang.String d;
    private a.a.b.e e;
    private a.a.b.a f;
    private java.lang.String g;
    private java.lang.String h;
    private long i;
    private a.a.b.b j;
    private int k;
    private java.lang.String l;

    public d(java.lang.String p0, java.lang.String p1, java.lang.String p2, java.lang.String p3, java.lang.String p4, a.a.b.e p5, a.a.b.a p6, a.a.b.b p7, long p8, int p9, java.lang.String p10) {
        // Registers (27 total): v14 = this, v15 = p0 (java.lang.String), v16 = p1 (java.lang.String), v17 = p2 (java.lang.String), v18 = p3 (java.lang.String), v19 = p4 (java.lang.String), v20 = p5 (a.a.b.e), v21 = p6 (a.a.b.a), v22 = p7 (a.a.b.b), v23 = p8 (long), v25 = p9 (int), v26 = p10 (java.lang.String)
        v0 = v14;
        v1 = v15;
        v2 = v16;
        v3 = v17;
        v4 = v17;
        v5 = v18;
        v6 = v19;
        v7 = v20;
        v8 = v21;
        v9 = v22;
        v10 = v23;
        v12 = v25;
        v13 = v26;
        _result = v0.<init>(v0..v13); // a.a.b.d.<init> -> void
        return;
    }

    public d(java.lang.String p0, java.lang.String p1, java.lang.String p2, java.lang.String p3, java.lang.String p4, java.lang.String p5, a.a.b.e p6, a.a.b.a p7, a.a.b.b p8, long p9, int p10, java.lang.String p11) {
        // Registers (18 total): v4 = this, v5 = p0 (java.lang.String), v6 = p1 (java.lang.String), v7 = p2 (java.lang.String), v8 = p3 (java.lang.String), v9 = p4 (java.lang.String), v10 = p5 (java.lang.String), v11 = p6 (a.a.b.e), v12 = p7 (a.a.b.a), v13 = p8 (a.a.b.b), v14 = p9 (long), v16 = p10 (int), v17 = p11 (java.lang.String)
        _result = v4.<init>(); // java.lang.Object.<init> -> void
        if (v5 == 0) /* goto L_0009 */;
        if (v6 == 0) /* goto L_0009 */;
        if (v8 != 0) /* goto L_000f */;
        v1 = new java.lang.NullPointerException;
        _result = v1.<init>(); // java.lang.NullPointerException.<init> -> void
        throw v1;
        v1 = "samsung.media";
        _result = v6.equalsIgnoreCase(v1); // java.lang.String.equalsIgnoreCase -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0052 */;
        v1 = "samsung.personal";
        _result = v6.equalsIgnoreCase(v1); // java.lang.String.equalsIgnoreCase -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0052 */;
        v1 = "samsung.here.and.now";
        _result = v6.equalsIgnoreCase(v1); // java.lang.String.equalsIgnoreCase -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0052 */;
        v1 = "flipboard.temporary.will.change.later.news";
        _result = v6.equalsIgnoreCase(v1); // java.lang.String.equalsIgnoreCase -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0052 */;
        v1 = "flipboard.temporary.will.change.later.social";
        _result = v6.equalsIgnoreCase(v1); // java.lang.String.equalsIgnoreCase -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0052 */;
        v1 = new java.lang.IllegalArgumentException;
        v2 = new java.lang.StringBuilder;
        v3 = "Not a valid streamId: ";
        _result = v2.<init>(v3); // java.lang.StringBuilder.<init> -> void
        _result = v2.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2); // java.lang.IllegalArgumentException.<init> -> void
        throw v1;
        v4.a = v5; // a.a.b.d.a:java.lang.String
        v4.b = v6; // a.a.b.d.b:java.lang.String
        v4.d = v7; // a.a.b.d.d:java.lang.String
        v4.c = v8; // a.a.b.d.c:java.lang.String
        v4.f = v12; // a.a.b.d.f:a.a.b.a
        v4.g = v9; // a.a.b.d.g:java.lang.String
        v4.h = v10; // a.a.b.d.h:java.lang.String
        if (v11 != 0) /* goto L_0064 */;
        v11 = a.a.b.e.d; // :a.a.b.e
        v4.e = v11; // a.a.b.d.e:a.a.b.e
        v4.i = v14; // a.a.b.d.i:long
        v4.j = v13; // a.a.b.d.j:a.a.b.b
        v0 = v16;
        v4.k = v0; // a.a.b.d.k:int
        v0 = v17;
        v4.l = v0; // a.a.b.d.l:java.lang.String
        return;
    }

    public java.lang.String a() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // a.a.b.d.d:java.lang.String
        return v0;
    }

    public java.lang.String b() {
        // Registers (2 total): v1 = this
        v0 = v1.g; // a.a.b.d.g:java.lang.String
        return v0;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // a.a.b.d.a:java.lang.String
        return v0;
    }

    public a.a.b.a d() {
        // Registers (2 total): v1 = this
        v0 = v1.f; // a.a.b.d.f:a.a.b.a
        return v0;
    }

    public java.lang.String e() {
        // Registers (2 total): v1 = this
        v0 = v1.h; // a.a.b.d.h:java.lang.String
        if (v0 == 0) /* goto L_000b */;
        v0 = v1.h; // a.a.b.d.h:java.lang.String
        _result = v0.trim(); // java.lang.String.trim -> java.lang.String
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_000a
    }

    public long f() {
        // Registers (3 total): v2 = this
        v0 = v2.i; // a.a.b.d.i:long
        return v0;
    }

    public a.a.b.b g() {
        // Registers (2 total): v1 = this
        v0 = v1.j; // a.a.b.d.j:a.a.b.b
        return v0;
    }

    public java.lang.String h() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // a.a.b.d.b:java.lang.String
        return v0;
    }

    public java.lang.String i() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // a.a.b.d.c:java.lang.String
        return v0;
    }

    public a.a.b.e j() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // a.a.b.d.e:a.a.b.e
        return v0;
    }

    public int k() {
        // Registers (2 total): v1 = this
        v0 = v1.k; // a.a.b.d.k:int
        return v0;
    }

    public java.lang.String l() {
        // Registers (2 total): v1 = this
        v0 = v1.l; // a.a.b.d.l:java.lang.String
        return v0;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v0 = v2.g; // a.a.b.d.g:java.lang.String
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = " - ";
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = v2.j; // a.a.b.d.j:a.a.b.b
        if (v0 == 0) /* goto L_0022 */;
        v0 = v2.j; // a.a.b.d.j:a.a.b.b
        _result = v0.a(); // a.a.b.b.a -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_001a
    }

}