package a.a.b;

/**
 * Original SourceFile: Author.java
 * Descriptor: La/a/b/a;
 */
public class a {
    private java.lang.String a;
    private a.a.b.b b;

    public a(java.lang.String p0, a.a.b.b p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (a.a.b.b)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // a.a.b.a.a:java.lang.String
        v0.b = v2; // a.a.b.a.b:a.a.b.b
        return;
    }

    public java.lang.String a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // a.a.b.a.a:java.lang.String
        return v0;
    }

    public a.a.b.b b() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // a.a.b.a.b:a.a.b.b
        return v0;
    }

}