package c;

/**
 * Original SourceFile: IDs.java
 * Descriptor: Lc/b;
 */
public class b extends c.k {
    private static java.lang.String[] d;
    private long[] a;
    private long b;
    private long c;

    static {
        v0 = 2;
        v0 = new java.lang.String[][size=v0];
        v1 = 0;
        v2 = "id_list";
        v0[v1] = v2;
        v1 = 1;
        v2 = "ids";
        v0[v1] = v2;
        c.b.d = v0; // :java.lang.String[]
        return;
    }

    b(c.a.i p0, c.h p1) {
        // Registers (9 total): v6 = this, v7 = p0 (c.a.i), v8 = p1 (c.h)
        v3 = 0L;
        v0 = 0;
        _result = v6.<init>(v7); // c.k.<init> -> void
        v1 = "[]\n";
        _result = v7.b(); // c.a.i.b -> java.lang.String
        v2 = _result;
        _result = v1.equals(v2); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_001c */;
        v6.b = v3; // c.b.b:long
        v6.c = v3; // c.b.c:long
        v0 = new long[][size=v0];
        v6.a = v0; // c.b.a:long[]
        return;
        _result = v7.c(); // c.a.i.c -> c.b.a.c
        v1 = _result;
        v2 = "previous_cursor";
        _result = v1.g(v2); // c.b.a.c.g -> long
        v2 = _result;
        v6.b = v2; // c.b.b:long
        v2 = "next_cursor";
        _result = v1.g(v2); // c.b.a.c.g -> long
        v2 = _result;
        v6.c = v2; // c.b.c:long
        v2 = "ids";
        _result = v1.i(v2); // c.b.a.c.i -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_001b */;
        v2 = "ids";
        _result = v1.e(v2); // c.b.a.c.e -> c.b.a.a
        v1 = _result;
        _result = v1.a(); // c.b.a.a.a -> int
        v2 = _result;
        v3 = new long[][size=v2];
        v6.a = v3; // c.b.a:long[]
        if (v0 >= v2) /* goto L_001b */;
        v3 = v6.a; // c.b.a:long[]
        _result = v1.d(v0); // c.b.a.a.d -> long
        v4 = _result;
        v3[v0] = v4;
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_004a
        v0 = _exception;
        v1 = new c.j;
        _result = v1.<init>(v0); // c.j.<init> -> void
        throw v1;
    }

    public long[] a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // c.b.a:long[]
        return v0;
    }

    public long b() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // c.b.c:long
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        if (v2 != v3) /* goto L_0004 */;
        v0 = 1;
        return v0;
        v0 = (v3 instanceof c.b);
        if (v0 != 0) /* goto L_000a */;
        v0 = 0;
        // goto L_0003
        v3 = (c.b) v3;
        v0 = v2.a; // c.b.a:long[]
        v1 = v3.a; // c.b.a:long[]
        _result = v0.equals(v1); // java.util.Arrays.equals -> boolean
        v0 = _result;
        // goto L_0003
    }

    public int hashCode() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // c.b.a:long[]
        if (v0 == 0) /* goto L_000b */;
        v0 = v1.a; // c.b.a:long[]
        _result = v0.hashCode(); // java.util.Arrays.hashCode -> int
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_000a
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "IDs{ids=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.a; // c.b.a:long[]
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", previousCursor=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.b; // c.b.b:long
        _result = v0.append(v1, v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", nextCursor=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.c; // c.b.c:long
        _result = v0.append(v1, v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}