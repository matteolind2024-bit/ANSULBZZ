package c;

/**
 * Original SourceFile: Version.java
 * Descriptor: Lc/g;
 */
public class g {
    public static java.lang.String a() {
        v0 = "2.0.10";
        return v0;
    }

}