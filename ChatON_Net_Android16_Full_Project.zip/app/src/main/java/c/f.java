package c;

/**
 * Original SourceFile: UserWapper.java
 * Descriptor: Lc/f;
 */
public class f implements java.io.Serializable {
    private java.util.List a;
    private long b;
    private long c;

    public f(java.util.List p0, long p1, long p2) {
        // Registers (6 total): v0 = this, v1 = p0 (java.util.List), v2 = p1 (long), v4 = p2 (long)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // c.f.a:java.util.List
        v0.b = v2; // c.f.b:long
        v0.c = v4; // c.f.c:long
        return;
    }

    public java.util.List a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // c.f.a:java.util.List
        return v0;
    }

    public long b() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // c.f.c:long
        return v0;
    }

}