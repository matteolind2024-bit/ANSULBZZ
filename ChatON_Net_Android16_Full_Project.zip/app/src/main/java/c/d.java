package c;

/**
 * Original SourceFile: Status.java
 * Descriptor: Lc/d;
 */
public class d extends c.k implements java.io.Serializable {
    private java.util.Date a;
    private long b;
    private java.lang.String c;
    private java.lang.String d;
    private boolean e;
    private long f;
    private int g;
    private boolean h;
    private java.lang.String i;
    private double j;
    private double k;
    private java.lang.String l;
    private java.lang.String m;
    private java.lang.String n;
    private c.c o;
    private c.e p;

    d(c.a.i p0) {
        // Registers (7 total): v5 = this, v6 = p0 (c.a.i)
        v0 = 0xbff0000000000000L;
        _result = v5.<init>(v6); // c.k.<init> -> void
        v5.j = v0; // c.d.j:double
        v5.k = v0; // c.d.k:double
        v0 = 0;
        v5.p = v0; // c.d.p:c.e
        _result = v6.c(); // c.a.i.c -> c.b.a.c
        v1 = _result;
        v0 = "id";
        _result = v1.g(v0); // c.b.a.c.g -> long
        v2 = _result;
        v5.b = v2; // c.d.b:long
        v0 = "text";
        _result = v1.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v5.c = v0; // c.d.c:java.lang.String
        v0 = "source";
        _result = v1.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v5.d = v0; // c.d.d:java.lang.String
        v0 = "created_at";
        _result = v1.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v2 = "EEE MMM dd HH:mm:ss z yyyy";
        _result = v0.a(v2); // c.d.a -> java.util.Date
        v0 = _result;
        v5.a = v0; // c.d.a:java.util.Date
        v0 = "in_reply_to_status_id";
        _result = v0.b(v1); // c.d.b -> long
        v2 = _result;
        v5.f = v2; // c.d.f:long
        v0 = "in_reply_to_user_id";
        _result = v0.a(v1); // c.d.a -> int
        v0 = _result;
        v5.g = v0; // c.d.g:int
        v0 = "favorited";
        _result = v0.c(v1); // c.d.c -> boolean
        v0 = _result;
        v5.h = v0; // c.d.h:boolean
        v0 = "thumbnail_pic";
        _result = v1.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v5.l = v0; // c.d.l:java.lang.String
        v0 = "bmiddle_pic";
        _result = v1.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v5.m = v0; // c.d.m:java.lang.String
        v0 = "original_pic";
        _result = v1.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v5.n = v0; // c.d.n:java.lang.String
        v0 = "user";
        _result = v1.i(v0); // c.b.a.c.i -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0088 */;
        v0 = new c.e;
        v2 = "user";
        _result = v1.f(v2); // c.b.a.c.f -> c.b.a.c
        v2 = _result;
        _result = v0.<init>(v2); // c.e.<init> -> void
        v5.p = v0; // c.d.p:c.e
        v0 = "inReplyToScreenName";
        _result = v1.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v5.i = v0; // c.d.i:java.lang.String
        v0 = "retweeted_status";
        _result = v1.i(v0); // c.b.a.c.i -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_00a8 */;
        v0 = new c.c;
        v2 = "retweeted_status";
        _result = v1.f(v2); // c.b.a.c.f -> c.b.a.c
        v2 = _result;
        _result = v0.<init>(v2); // c.c.<init> -> void
        v5.o = v0; // c.d.o:c.c
        return;
        v0 = _exception;
        v2 = new c.j;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.getMessage(); // c.b.a.b.getMessage -> java.lang.String
        v4 = _result;
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        v4 = ":";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v1.toString(); // c.b.a.c.toString -> java.lang.String
        v1 = _result;
        _result = v3.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v2.<init>(v1, v0); // c.j.<init> -> void
        throw v2;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v7 != 0) /* goto L_0006 */;
        v0 = v1;
        return v0;
        if (v6 == v7) /* goto L_0005 */;
        v2 = (v7 instanceof c.d);
        if (v2 == 0) /* goto L_0016 */;
        v7 = (c.d) v7;
        v2 = v7.b; // c.d.b:long
        v4 = v6.b; // c.d.b:long
        v2 = cmp(v2, v4);
        if (v2 == 0) /* goto L_0005 */;
        v0 = v1;
        // goto L_0005
    }

    public int hashCode() {
        // Registers (3 total): v2 = this
        v0 = v2.b; // c.d.b:long
        v0 = unaryOp_0x84(v0);
        return v0;
    }

    public java.lang.String toString() {
        // Registers (5 total): v4 = this
        v3 = 39;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "Status{createdAt=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.a; // c.d.a:java.util.Date
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", id=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.b; // c.d.b:long
        _result = v0.append(v1, v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", text='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.c; // c.d.c:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", source='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.d; // c.d.d:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", isTruncated=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.e; // c.d.e:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", inReplyToStatusId=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.f; // c.d.f:long
        _result = v0.append(v1, v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", inReplyToUserId=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.g; // c.d.g:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", isFavorited=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.h; // c.d.h:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", thumbnail_pic=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.l; // c.d.l:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", bmiddle_pic=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.m; // c.d.m:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", original_pic=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.n; // c.d.n:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", inReplyToScreenName='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.i; // c.d.i:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", latitude=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.j; // c.d.j:double
        _result = v0.append(v1, v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", longitude=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.k; // c.d.k:double
        _result = v0.append(v1, v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", retweetDetails=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.o; // c.d.o:c.c
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", user=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.p; // c.d.p:c.e
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}