package c;

/**
 * Original SourceFile: Weibo.java
 * Descriptor: Lc/i;
 */
class i {
    final java.lang.String a;

    public i(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        v0.a = v1; // c.i.a:java.lang.String
        return;
    }

}