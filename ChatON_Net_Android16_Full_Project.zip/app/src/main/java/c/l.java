package c;

/**
 * Original SourceFile: WeiboSupport.java
 * Descriptor: Lc/l;
 */
class l {
    protected c.a.c f;
    protected java.lang.String g;
    protected final boolean h;

    l() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.<init>(v0, v0); // c.l.<init> -> void
        return;
    }

    l(java.lang.String p0, java.lang.String p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.String), v4 = p1 (java.lang.String)
        v1 = 0;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v0 = new c.a.c;
        _result = v0.<init>(); // c.a.c.<init> -> void
        v2.f = v0; // c.l.f:c.a.c
        _result = this.e(); // c.a.e -> java.lang.String
        v0 = _result;
        v2.g = v0; // c.l.g:java.lang.String
        _result = this.c(); // c.a.c -> boolean
        v0 = _result;
        v2.h = v0; // c.l.h:boolean
        _result = v2.h(v1); // c.l.h -> void
        _result = v2.g(v1); // c.l.g -> void
        _result = v2.f(v3); // c.l.f -> void
        _result = v2.e(v4); // c.l.e -> void
        return;
    }

    public void b(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        v0 = v1.f; // c.l.f:c.a.c
        _result = v0.b(v2, v3); // c.a.c.b -> void
        return;
    }

    public void e(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        // monitor-enter(v2)
        v0 = v2.f; // c.l.f:c.a.c
        _result = v3.d(); // c.a.d -> java.lang.String
        v1 = _result;
        _result = v0.b(v1); // c.a.c.b -> void
        // monitor-exit(v2)
        return;
        v0 = _exception;
        // monitor-exit(v2)
        throw v0;
    }

    public void f(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        // monitor-enter(v2)
        v0 = v2.f; // c.l.f:c.a.c
        _result = v3.c(); // c.a.c -> java.lang.String
        v1 = _result;
        _result = v0.a(v1); // c.a.c.a -> void
        // monitor-exit(v2)
        return;
        v0 = _exception;
        // monitor-exit(v2)
        throw v0;
    }

    public void g(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = "X-Weibo-Client-URL";
        _result = v3.b(); // c.a.b -> java.lang.String
        v1 = _result;
        _result = v2.b(v0, v1); // c.l.b -> void
        return;
    }

    public void h(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = "X-Weibo-Client-Version";
        _result = v3.a(); // c.a.a -> java.lang.String
        v1 = _result;
        _result = v2.b(v0, v1); // c.l.b -> void
        return;
    }

}