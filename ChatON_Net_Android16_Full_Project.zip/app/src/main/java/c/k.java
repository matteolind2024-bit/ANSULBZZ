package c;

/**
 * Original SourceFile: WeiboResponse.java
 * Descriptor: Lc/k;
 */
public class k implements java.io.Serializable {
    private static java.util.Map a;
    private static final boolean e;
    private transient int b;
    private transient int c;
    private transient long d;

    static {
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        c.k.a = v0; // :java.util.Map
        _result = this.b(); // c.a.b -> boolean
        v0 = _result;
        c.k.e = v0; // :boolean
        return;
    }

    public k() {
        // Registers (3 total): v2 = this
        v0 = -1;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.b = v0; // c.k.b:int
        v2.c = v0; // c.k.c:int
        v0 = -1L;
        v2.d = v0; // c.k.d:long
        return;
    }

    public k(c.a.i p0) {
        // Registers (4 total): v2 = this, v3 = p0 (c.a.i)
        v0 = -1;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.b = v0; // c.k.b:int
        v2.c = v0; // c.k.c:int
        v0 = -1L;
        v2.d = v0; // c.k.d:long
        v0 = "X-RateLimit-Limit";
        _result = v3.a(v0); // c.a.i.a -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_001b */;
        _result = v0.parseInt(); // java.lang.Integer.parseInt -> int
        v0 = _result;
        v2.b = v0; // c.k.b:int
        v0 = "X-RateLimit-Remaining";
        _result = v3.a(v0); // c.a.i.a -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_002a */;
        _result = v0.parseInt(); // java.lang.Integer.parseInt -> int
        v0 = _result;
        v2.c = v0; // c.k.c:int
        v0 = "X-RateLimit-Reset";
        _result = v3.a(v0); // c.a.i.a -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0039 */;
        _result = v0.parseLong(); // java.lang.Long.parseLong -> long
        v0 = _result;
        v2.d = v0; // c.k.d:long
        return;
    }

    protected static int a(java.lang.String p0, c.b.a.c p1) {
        // Registers (4 total): v2 = p0 (java.lang.String), v3 = p1 (c.b.a.c)
        _result = v3.h(v2); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0018 */;
        v1 = "";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0018 */;
        v1 = "null";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_001a */;
        v0 = -1;
        return v0;
        _result = v0.parseInt(); // java.lang.Integer.parseInt -> int
        v0 = _result;
        // goto L_0019
    }

    protected static java.util.Date a(java.lang.String p0, java.lang.String p1) {
        // Registers (5 total): v3 = p0 (java.lang.String), v4 = p1 (java.lang.String)
        if (v3 == 0) /* goto L_000b */;
        v0 = "";
        _result = v0.equals(v3); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000d */;
        v0 = 0;
        return v0;
        v0 = c.k.a; // :java.util.Map
        _result = java.util.Map.get(v0, v4); // -> java.lang.Object
        v0 = _result;
        v0 = (java.text.SimpleDateFormat) v0;
        if (v0 != 0) /* goto L_005a */;
        v0 = new java.text.SimpleDateFormat;
        v1 = java.util.Locale.ENGLISH; // :java.util.Locale
        _result = v0.<init>(v4, v1); // java.text.SimpleDateFormat.<init> -> void
        v1 = "GMT";
        _result = v1.getTimeZone(); // java.util.TimeZone.getTimeZone -> java.util.TimeZone
        v1 = _result;
        _result = v0.setTimeZone(v1); // java.text.SimpleDateFormat.setTimeZone -> void
        v1 = c.k.a; // :java.util.Map
        _result = java.util.Map.put(v1, v4, v0); // -> java.lang.Object
        v1 = v0;
        // monitor-enter(v1)
        _result = v1.parse(v3); // java.text.SimpleDateFormat.parse -> java.util.Date
        v0 = _result;
        // monitor-exit(v1)
        // goto L_000c
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
        v0 = _exception;
        v0 = new c.j;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Unexpected format(";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ") returned from sina.com.cn";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // c.j.<init> -> void
        throw v0;
        v1 = v0;
        // goto L_002e
    }

    protected static long b(java.lang.String p0, c.b.a.c p1) {
        // Registers (4 total): v2 = p0 (java.lang.String), v3 = p1 (c.b.a.c)
        _result = v3.h(v2); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0018 */;
        v1 = "";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0018 */;
        v1 = "null";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_001b */;
        v0 = -1L;
        return v0;
        _result = v0.parseLong(); // java.lang.Long.parseLong -> long
        v0 = _result;
        // goto L_001a
    }

    protected static boolean c(java.lang.String p0, c.b.a.c p1) {
        // Registers (4 total): v2 = p0 (java.lang.String), v3 = p1 (c.b.a.c)
        _result = v3.h(v2); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_0018 */;
        v1 = "";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0018 */;
        v1 = "null";
        _result = v1.equals(v0); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_001a */;
        v0 = 0;
        return v0;
        _result = v0.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v0 = _result;
        _result = v0.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        // goto L_0019
    }

}