package c;

/**
 * Original SourceFile: Weibo.java
 * Descriptor: Lc/h;
 */
public class h extends c.l implements java.io.Serializable {
    public static java.lang.String a;
    public static java.lang.String b;
    public static final c.i c;
    public static final c.i d;
    public static final c.i e;
    private java.lang.String i;
    private java.lang.String j;
    private java.lang.String k;
    private java.text.SimpleDateFormat l;

    static {
        v0 = "1552112022";
        c.h.a = v0; // :java.lang.String
        v0 = "bd9e3b147ece106f9cee159758a28ec1";
        c.h.b = v0; // :java.lang.String
        v0 = new c.i;
        v1 = "im";
        _result = v0.<init>(v1); // c.i.<init> -> void
        c.h.c = v0; // :c.i
        v0 = new c.i;
        v1 = "sms";
        _result = v0.<init>(v1); // c.i.<init> -> void
        c.h.d = v0; // :c.i
        v0 = new c.i;
        v1 = "none";
        _result = v0.<init>(v1); // c.i.<init> -> void
        c.h.e = v0; // :c.i
        return;
    }

    public h() {
        // Registers (4 total): v3 = this
        _result = v3.<init>(); // c.l.<init> -> void
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = this.d(); // c.a.d -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "api.t.sina.com.cn/";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v3.i = v0; // c.h.i:java.lang.String
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = this.d(); // c.a.d -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "api.t.sina.com.cn/";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v3.j = v0; // c.h.j:java.lang.String
        v0 = "https://api.weibo.com/oauth2/";
        v3.k = v0; // c.h.k:java.lang.String
        v0 = new java.text.SimpleDateFormat;
        v1 = "EEE, d MMM yyyy HH:mm:ss z";
        v2 = java.util.Locale.ENGLISH; // :java.util.Locale
        _result = v0.<init>(v1, v2); // java.text.SimpleDateFormat.<init> -> void
        v3.l = v0; // c.h.l:java.text.SimpleDateFormat
        v0 = v3.l; // c.h.l:java.text.SimpleDateFormat
        v1 = "GMT";
        _result = v1.getTimeZone(); // java.util.TimeZone.getTimeZone -> java.util.TimeZone
        v1 = _result;
        _result = v0.setTimeZone(v1); // java.text.SimpleDateFormat.setTimeZone -> void
        v0 = v3.f; // c.h.f:c.a.c
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = this.d(); // c.a.d -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "api.t.sina.com.cn/oauth/request_token";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.d(v1); // c.a.c.d -> void
        v0 = v3.f; // c.h.f:c.a.c
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = this.d(); // c.a.d -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "api.t.sina.com.cn/oauth/authorize";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.e(v1); // c.a.c.e -> void
        v0 = v3.f; // c.h.f:c.a.c
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = this.d(); // c.a.d -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "api.t.sina.com.cn/oauth/access_token";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.f(v1); // c.a.c.f -> void
        return;
    }

    public c.a.a a() {
        // Registers (2 total): v1 = this
        // monitor-enter(v1)
        v0 = v1.f; // c.h.f:c.a.c
        _result = v0.b(); // c.a.c.b -> c.a.a
        v0 = _result;
        // monitor-exit(v1)
        return v0;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

    protected c.a.i a(java.lang.String p0, c.a.g[] p1, boolean p2) {
        // Registers (6 total): v2 = this, v3 = p0 (java.lang.String), v4 = p1 (c.a.g[]), v5 = p2 (boolean)
        v1 = -1;
        v0 = "?";
        _result = v3.indexOf(v0); // java.lang.String.indexOf -> int
        v0 = _result;
        if (v0 != v1) /* goto L_004c */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "?source=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = c.h.a; // :java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        if (v4 == 0) /* goto L_0045 */;
        v1 = v4.length;
        if (v1 <= 0) /* goto L_0045 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "&";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v4.a(); // c.a.c.a -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = v2.f; // c.h.f:c.a.c
        _result = v1.a(v0, v5); // c.a.c.a -> c.a.i
        v0 = _result;
        return v0;
        v0 = "source";
        _result = v3.indexOf(v0); // java.lang.String.indexOf -> int
        v0 = _result;
        if (v0 != v1) /* goto L_0070 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "&source=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = c.h.a; // :java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0024
        v0 = v3;
        // goto L_0024
    }

    public c.e a(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v0 = new c.e;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v6.b(); // c.h.b -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "users/show.json";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        v2 = 1;
        v2 = new c.a.g[][size=v2];
        v3 = 0;
        v4 = new c.a.g;
        v5 = "user_id";
        _result = v4.<init>(v5, v7); // c.a.g.<init> -> void
        v2[v3] = v4;
        v3 = v6.f; // c.h.f:c.a.c
        _result = v3.a(); // c.a.c.a -> boolean
        v3 = _result;
        _result = v6.a(v1, v2, v3); // c.h.a -> c.a.i
        v1 = _result;
        _result = v1.c(); // c.a.i.c -> c.b.a.c
        v1 = _result;
        _result = v0.<init>(v1); // c.e.<init> -> void
        return v0;
    }

    public c.f a(java.lang.String p0, int p1, int p2) {
        // Registers (10 total): v6 = this, v7 = p0 (java.lang.String), v8 = p1 (int), v9 = p2 (int)
        v5 = 1;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v6.b(); // c.h.b -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "statuses/friends.json";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        v1 = 3;
        v1 = new c.a.g[][size=v1];
        v2 = 0;
        v3 = new c.a.g;
        v4 = "uid";
        _result = v3.<init>(v4, v7); // c.a.g.<init> -> void
        v1[v2] = v3;
        v2 = new c.a.g;
        v3 = "cursor";
        _result = v2.<init>(v3, v8); // c.a.g.<init> -> void
        v1[v5] = v2;
        v2 = 2;
        v3 = new c.a.g;
        v4 = "count";
        _result = v3.<init>(v4, v9); // c.a.g.<init> -> void
        v1[v2] = v3;
        _result = v6.a(v0, v1, v5); // c.h.a -> c.a.i
        v0 = _result;
        _result = v0.a(); // c.e.a -> c.f
        v0 = _result;
        return v0;
    }

    public void a(c.a.a p0) {
        // Registers (3 total): v1 = this, v2 = p0 (c.a.a)
        v0 = v1.f; // c.h.f:c.a.c
        _result = v0.a(v2); // c.a.c.a -> void
        return;
    }

    public void a(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        // monitor-enter(v1)
        v0 = v1.f; // c.h.f:c.a.c
        _result = v0.a(v2, v3); // c.a.c.a -> void
        // monitor-exit(v1)
        return;
        v0 = _exception;
        // monitor-exit(v1)
        throw v0;
    }

    public c.b b(java.lang.String p0, int p1, int p2) {
        // Registers (11 total): v7 = this, v8 = p0 (java.lang.String), v9 = p1 (int), v10 = p2 (int)
        v6 = 1;
        v0 = new c.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v7.b(); // c.h.b -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "friends/ids.json";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        v2 = 3;
        v2 = new c.a.g[][size=v2];
        v3 = 0;
        v4 = new c.a.g;
        v5 = "uid";
        _result = v4.<init>(v5, v8); // c.a.g.<init> -> void
        v2[v3] = v4;
        v3 = new c.a.g;
        v4 = "cursor";
        _result = v3.<init>(v4, v9); // c.a.g.<init> -> void
        v2[v6] = v3;
        v3 = 2;
        v4 = new c.a.g;
        v5 = "count";
        _result = v4.<init>(v5, v10); // c.a.g.<init> -> void
        v2[v3] = v4;
        _result = v7.a(v1, v2, v6); // c.h.a -> c.a.i
        v1 = _result;
        _result = v0.<init>(v1, v7); // c.b.<init> -> void
        return v0;
    }

    public c.d b(java.lang.String p0) {
        // Registers (10 total): v8 = this, v9 = p0 (java.lang.String)
        v7 = 1;
        v0 = new c.d;
        v1 = v8.f; // c.h.f:c.a.c
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v8.b(); // c.h.b -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = "statuses/update.json";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        v3 = new c.a.g[][size=v7];
        v4 = 0;
        v5 = new c.a.g;
        v6 = "status";
        _result = v5.<init>(v6, v9); // c.a.g.<init> -> void
        v3[v4] = v5;
        _result = v1.a(v2, v3, v7); // c.a.c.a -> c.a.i
        v1 = _result;
        _result = v0.<init>(v1); // c.d.<init> -> void
        return v0;
    }

    public java.lang.String b() {
        // Registers (2 total): v1 = this
        v0 = v1.i; // c.h.i:java.lang.String
        return v0;
    }

    public void b(java.lang.String p0, java.lang.String p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (java.lang.String)
        _result = v0.b(v1, v2); // c.l.b -> void
        return;
    }

    public c.a.h c(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.f; // c.h.f:c.a.c
        _result = v0.c(v2); // c.a.c.c -> c.a.h
        v0 = _result;
        return v0;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        v0 = v1.k; // c.h.k:java.lang.String
        return v0;
    }

    public boolean d(java.lang.String p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.String)
        v5 = 0;
        v0 = v6.f; // c.h.f:c.a.c
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v6.c(); // c.h.c -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "revokeoauth2";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        v2 = 1;
        v2 = new c.a.g[][size=v2];
        v3 = new c.a.g;
        v4 = "access_token";
        _result = v3.<init>(v4, v7); // c.a.g.<init> -> void
        v2[v5] = v3;
        _result = v0.a(v1, v2, v5); // c.a.c.a -> c.a.i
        v0 = _result;
        _result = v0.c(); // c.a.i.c -> c.b.a.c
        v0 = _result;
        v1 = "Result";
        _result = v0.b(v1); // c.b.a.c.b -> boolean
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v0 = _result;
        _result = v0.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        return v0;
        v0 = _exception;
        v1 = new c.j;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.getMessage(); // c.b.a.b.getMessage -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ":";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // c.j.<init> -> void
        throw v1;
    }

    public void e(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        _result = v0.e(v1); // c.l.e -> void
        return;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.Object)
        v0 = 0;
        if (v3 != v4) /* goto L_0005 */;
        v0 = 1;
        return v0;
        if (v4 == 0) /* goto L_0004 */;
        _result = v3.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v1 = _result;
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        if (v1 != v2) /* goto L_0004 */;
        v4 = (c.h) v4;
        v1 = v3.i; // c.h.i:java.lang.String
        v2 = v4.i; // c.h.i:java.lang.String
        _result = v1.equals(v2); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0004 */;
        v1 = v3.l; // c.h.l:java.text.SimpleDateFormat
        v2 = v4.l; // c.h.l:java.text.SimpleDateFormat
        _result = v1.equals(v2); // java.text.SimpleDateFormat.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0004 */;
        v1 = v3.f; // c.h.f:c.a.c
        v2 = v4.f; // c.h.f:c.a.c
        _result = v1.equals(v2); // c.a.c.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0004 */;
        v1 = v3.j; // c.h.j:java.lang.String
        v2 = v4.j; // c.h.j:java.lang.String
        _result = v1.equals(v2); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0004 */;
        v0 = v3.g; // c.h.g:java.lang.String
        v1 = v4.g; // c.h.g:java.lang.String
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        // goto L_0004
    }

    public void f(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        _result = v0.f(v1); // c.l.f -> void
        return;
    }

    public void g(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        _result = v0.g(v1); // c.l.g -> void
        return;
    }

    public void h(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        _result = v0.h(v1); // c.l.h -> void
        return;
    }

    public int hashCode() {
        // Registers (3 total): v2 = this
        v0 = v2.f; // c.h.f:c.a.c
        _result = v0.hashCode(); // c.a.c.hashCode -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.i; // c.h.i:java.lang.String
        _result = v1.hashCode(); // java.lang.String.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.j; // c.h.j:java.lang.String
        _result = v1.hashCode(); // java.lang.String.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.g; // c.h.g:java.lang.String
        _result = v1.hashCode(); // java.lang.String.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.l; // c.h.l:java.text.SimpleDateFormat
        _result = v1.hashCode(); // java.text.SimpleDateFormat.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        v2 = 39;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "Weibo{http=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.f; // c.h.f:c.a.c
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", baseURL='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.i; // c.h.i:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", searchBaseURL='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.j; // c.h.j:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", source='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.g; // c.h.g:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", format=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.l; // c.h.l:java.text.SimpleDateFormat
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}