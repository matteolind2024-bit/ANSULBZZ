package c.a;

/**
 * Original SourceFile: HttpClient.java
 * Descriptor: Lc/a/d;
 */
class d extends java.net.Authenticator {
    final c.a.c a;

    d(c.a.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (c.a.c)
        v0.a = v1; // c.a.d.a:c.a.c
        _result = v0.<init>(); // java.net.Authenticator.<init> -> void
        return;
    }

    protected java.net.PasswordAuthentication getPasswordAuthentication() {
        // Registers (4 total): v3 = this
        _result = v3.getRequestorType(); // c.a.d.getRequestorType -> java.net.Authenticator$RequestorType
        v0 = _result;
        v1 = java.net.Authenticator$RequestorType.PROXY; // :java.net.Authenticator$RequestorType
        _result = v0.equals(v1); // java.net.Authenticator$RequestorType.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0022 */;
        v0 = new java.net.PasswordAuthentication;
        v1 = v3.a; // c.a.d.a:c.a.c
        _result = v1.a(); // c.a.c.a -> java.lang.String
        v1 = _result;
        v2 = v3.a; // c.a.d.a:c.a.c
        _result = v2.b(); // c.a.c.b -> java.lang.String
        v2 = _result;
        _result = v2.toCharArray(); // java.lang.String.toCharArray -> char[]
        v2 = _result;
        _result = v0.<init>(v1, v2); // java.net.PasswordAuthentication.<init> -> void
        return v0;
        v0 = 0;
        // goto L_0021
    }

}