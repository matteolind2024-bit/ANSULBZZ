package c.a;

/**
 * Original SourceFile: OAuth.java
 * Descriptor: Lc/a/e;
 */
public class e implements java.io.Serializable {
    private static final c.a.g a;
    private static final boolean b;
    private static java.util.Random e;
    private java.lang.String c;
    private java.lang.String d;

    static {
        v0 = new c.a.g;
        v1 = "oauth_signature_method";
        v2 = "HMAC-SHA1";
        _result = v0.<init>(v1, v2); // c.a.g.<init> -> void
        c.a.e.a = v0; // :c.a.g
        _result = this.p(); // c.a.p -> boolean
        v0 = _result;
        c.a.e.b = v0; // :boolean
        v0 = new java.util.Random;
        _result = v0.<init>(); // java.util.Random.<init> -> void
        c.a.e.e = v0; // :java.util.Random
        return;
    }

    public e(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = "";
        v1.c = v0; // c.a.e.c:java.lang.String
        _result = v1.c(v2); // c.a.e.c -> void
        _result = v1.d(v3); // c.a.e.d -> void
        return;
    }

    public static java.lang.String a(java.lang.String p0) {
        // Registers (7 total): v6 = p0 (java.lang.String)
        v0 = 0;
        v1 = "UTF-8";
        _result = v6.encode(v1); // java.net.URLEncoder.encode -> java.lang.String
        v0 = _result;
        v2 = new java.lang.StringBuffer;
        _result = v0.length(); // java.lang.String.length -> int
        v1 = _result;
        _result = v2.<init>(v1); // java.lang.StringBuffer.<init> -> void
        v1 = 0;
        _result = v0.length(); // java.lang.String.length -> int
        v3 = _result;
        if (v1 >= v3) /* goto L_0060 */;
        _result = v0.charAt(v1); // java.lang.String.charAt -> char
        v3 = _result;
        v4 = 42;
        if (v3 != v4) /* goto L_0029 */;
        v3 = "%2A";
        _result = v2.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0012
        v4 = 43;
        if (v3 != v4) /* goto L_0034 */;
        v3 = "%20";
        _result = v2.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0026
        v4 = 37;
        if (v3 != v4) /* goto L_005c */;
        v4 = binOpLit8_0xd8(v1, 1);
        _result = v0.length(); // java.lang.String.length -> int
        v5 = _result;
        if (v4 >= v5) /* goto L_005c */;
        v4 = binOpLit8_0xd8(v1, 1);
        _result = v0.charAt(v4); // java.lang.String.charAt -> char
        v4 = _result;
        v5 = 55;
        if (v4 != v5) /* goto L_005c */;
        v4 = binOpLit8_0xd8(v1, 2);
        _result = v0.charAt(v4); // java.lang.String.charAt -> char
        v4 = _result;
        v5 = 69;
        if (v4 != v5) /* goto L_005c */;
        v3 = 126;
        _result = v2.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v1 = binOpLit8_0xd8(v1, 2);
        // goto L_0026
        _result = v2.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0026
        _result = v2.toString(); // java.lang.StringBuffer.toString -> java.lang.String
        v0 = _result;
        return v0;
        v1 = _exception;
        // goto L_0008
    }

    public static java.lang.String a(java.util.List p0) {
        // Registers (2 total): v1 = p0 (java.util.List)
        _result = v1.sort(); // java.util.Collections.sort -> void
        _result = v1.b(); // c.a.e.b -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String a(java.util.List p0, java.lang.String p1, boolean p2) {
        // Registers (8 total): v5 = p0 (java.util.List), v6 = p1 (java.lang.String), v7 = p2 (boolean)
        v1 = new java.lang.StringBuffer;
        _result = v1.<init>(); // java.lang.StringBuffer.<init> -> void
        _result = java.util.List.iterator(v5); // -> java.util.Iterator
        v2 = _result;
        _result = java.util.Iterator.hasNext(v2); // -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0048 */;
        _result = java.util.Iterator.next(v2); // -> java.lang.Object
        v0 = _result;
        v0 = (c.a.g) v0;
        _result = v1.length(); // java.lang.StringBuffer.length -> int
        v3 = _result;
        if (v3 == 0) /* goto L_0026 */;
        if (v7 == 0) /* goto L_0023 */;
        v3 = "\"";
        _result = v1.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        _result = v1.append(v6); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v3 = v0.a; // c.a.g.a:java.lang.String
        _result = v3.a(); // c.a.e.a -> java.lang.String
        v3 = _result;
        _result = v1.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v3 = _result;
        v4 = "=";
        _result = v3.append(v4); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        if (v7 == 0) /* goto L_003e */;
        v3 = "\"";
        _result = v1.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v0 = v0.b; // c.a.g.b:java.lang.String
        _result = v0.a(); // c.a.e.a -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0009
        _result = v1.length(); // java.lang.StringBuffer.length -> int
        v0 = _result;
        if (v0 == 0) /* goto L_0056 */;
        if (v7 == 0) /* goto L_0056 */;
        v0 = "\"";
        _result = v1.append(v0); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        _result = v1.toString(); // java.lang.StringBuffer.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.util.List a(c.a.g[] p0) {
        // Registers (3 total): v2 = p0 (c.a.g[])
        v0 = new java.util.ArrayList;
        v1 = v2.length;
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        _result = v2.asList(); // java.util.Arrays.asList -> java.util.List
        v1 = _result;
        _result = java.util.List.addAll(v0, v1); // -> boolean
        return v0;
    }

    private void a(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        v0 = c.a.e.b; // :boolean
        if (v0 == 0) /* goto L_0018 */;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.e(v0); // c.a.e.e -> void
        return;
    }

    private void a(java.lang.String p0, java.util.List p1) {
        // Registers (10 total): v7 = this, v8 = p0 (java.lang.String), v9 = p1 (java.util.List)
        v0 = 0;
        v1 = "?";
        _result = v8.indexOf(v1); // java.lang.String.indexOf -> int
        v1 = _result;
        v2 = -1;
        if (v2 == v1) /* goto L_005e */;
        v1 = binOpLit8_0xd8(v1, 1);
        _result = v8.substring(v1); // java.lang.String.substring -> java.lang.String
        v1 = _result;
        v2 = "&";
        _result = v1.split(v2); // java.lang.String.split -> java.lang.String[]
        v1 = _result;
        v2 = v1.length;
        if (v0 >= v2) /* goto L_005e */;
        v3 = v1[v0];
        v4 = "=";
        _result = v3.split(v4); // java.lang.String.split -> java.lang.String[]
        v3 = _result;
        v4 = v3.length;
        v5 = 2;
        if (v4 != v5) /* goto L_0047 */;
        v4 = new c.a.g;
        v5 = 0;
        v5 = v3[v5];
        v6 = "UTF-8";
        _result = v5.decode(v6); // java.net.URLDecoder.decode -> java.lang.String
        v5 = _result;
        v6 = 1;
        v3 = v3[v6];
        v6 = "UTF-8";
        _result = v3.decode(v6); // java.net.URLDecoder.decode -> java.lang.String
        v3 = _result;
        _result = v4.<init>(v5, v3); // c.a.g.<init> -> void
        _result = java.util.List.add(v9, v4); // -> boolean
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0019
        v4 = new c.a.g;
        v5 = 0;
        v3 = v3[v5];
        v5 = "UTF-8";
        _result = v3.decode(v5); // java.net.URLDecoder.decode -> java.lang.String
        v3 = _result;
        v5 = "";
        _result = v4.<init>(v3, v5); // c.a.g.<init> -> void
        _result = java.util.List.add(v9, v4); // -> boolean
        // goto L_0044
        v0 = _exception;
        return;
    }

    public static java.lang.String b(java.lang.String p0) {
        // Registers (7 total): v6 = p0 (java.lang.String)
        v5 = 8;
        v3 = -1;
        v4 = 0;
        v0 = "?";
        _result = v6.indexOf(v0); // java.lang.String.indexOf -> int
        v0 = _result;
        if (v3 == v0) /* goto L_0011 */;
        _result = v6.substring(v4, v0); // java.lang.String.substring -> java.lang.String
        v6 = _result;
        v0 = "/";
        _result = v6.indexOf(v0, v5); // java.lang.String.indexOf -> int
        v1 = _result;
        _result = v6.substring(v4, v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        _result = v0.toLowerCase(); // java.lang.String.toLowerCase -> java.lang.String
        v0 = _result;
        v2 = ":";
        _result = v0.indexOf(v2, v5); // java.lang.String.indexOf -> int
        v2 = _result;
        if (v3 == v2) /* goto L_003f */;
        v3 = "http://";
        _result = v0.startsWith(v3); // java.lang.String.startsWith -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0055 */;
        v3 = ":80";
        _result = v0.endsWith(v3); // java.lang.String.endsWith -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_0055 */;
        _result = v0.substring(v4, v2); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v6.substring(v1); // java.lang.String.substring -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v3 = "https://";
        _result = v0.startsWith(v3); // java.lang.String.startsWith -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_003f */;
        v3 = ":443";
        _result = v0.endsWith(v3); // java.lang.String.endsWith -> boolean
        v3 = _result;
        if (v3 == 0) /* goto L_003f */;
        _result = v0.substring(v4, v2); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        // goto L_003f
    }

    public static java.lang.String b(java.util.List p0) {
        // Registers (3 total): v2 = p0 (java.util.List)
        v0 = "&";
        v1 = 0;
        _result = v2.a(v0, v1); // c.a.e.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    private void e(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        v0 = c.a.e.b; // :boolean
        if (v0 == 0) /* goto L_002d */;
        v0 = java.lang.System.out; // :java.io.PrintStream
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = new java.util.Date;
        _result = v2.<init>(); // java.util.Date.<init> -> void
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "]";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.println(v1); // java.io.PrintStream.println -> void
        return;
    }

    java.lang.String a(java.lang.String p0, c.a.f p1) {
        // Registers (8 total): v5 = this, v6 = p0 (java.lang.String), v7 = p1 (c.a.f)
        v0 = 0;
        v1 = "HmacSHA1";
        _result = v1.getInstance(); // javax.crypto.Mac.getInstance -> javax.crypto.Mac
        v2 = _result;
        if (v7 != 0) /* goto L_0045 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = v5.d; // c.a.e.d:java.lang.String
        _result = v3.a(); // c.a.e.a -> java.lang.String
        v3 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v3 = "&";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        v1 = new javax.crypto.spec.SecretKeySpec;
        _result = v3.getBytes(); // java.lang.String.getBytes -> byte[]
        v3 = _result;
        v4 = "HmacSHA1";
        _result = v1.<init>(v3, v4); // javax.crypto.spec.SecretKeySpec.<init> -> void
        _result = v2.init(v1); // javax.crypto.Mac.init -> void
        _result = v6.getBytes(); // java.lang.String.getBytes -> byte[]
        v1 = _result;
        _result = v2.doFinal(v1); // javax.crypto.Mac.doFinal -> byte[]
        v0 = _result;
        v1 = new c.a.b;
        _result = v1.<init>(); // c.a.b.<init> -> void
        _result = v1.a(v0); // c.a.b.a -> java.lang.String
        v0 = _result;
        return v0;
        _result = v7.e(); // c.a.f.e -> javax.crypto.spec.SecretKeySpec
        v1 = _result;
        if (v1 != 0) /* goto L_0080 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = v5.d; // c.a.e.d:java.lang.String
        _result = v3.a(); // c.a.e.a -> java.lang.String
        v3 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v3 = "&";
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v7.c(); // c.a.f.c -> java.lang.String
        v3 = _result;
        _result = v3.a(); // c.a.e.a -> java.lang.String
        v3 = _result;
        _result = v1.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        v3 = new javax.crypto.spec.SecretKeySpec;
        _result = v1.getBytes(); // java.lang.String.getBytes -> byte[]
        v1 = _result;
        v4 = "HmacSHA1";
        _result = v3.<init>(v1, v4); // javax.crypto.spec.SecretKeySpec.<init> -> void
        _result = v7.a(v3); // c.a.f.a -> void
        _result = v7.e(); // c.a.f.e -> javax.crypto.spec.SecretKeySpec
        v1 = _result;
        // goto L_0030
        v1 = _exception;
        _result = v1.printStackTrace(); // java.security.InvalidKeyException.printStackTrace -> void
        // goto L_003b
        v1 = _exception;
        // goto L_003b
    }

    java.lang.String a(java.lang.String p0, java.lang.String p1, c.a.g[] p2, c.a.f p3) {
        // Registers (12 total): v7 = this, v8 = p0 (java.lang.String), v9 = p1 (java.lang.String), v10 = p2 (c.a.g[]), v11 = p3 (c.a.f)
        _result = this.currentTimeMillis(); // java.lang.System.currentTimeMillis -> long
        v0 = _result;
        v2 = 1000L;
        v0 = binOp2addr_0xbe(v0, v2);
        v2 = c.a.e.e; // :java.util.Random
        _result = v2.nextInt(); // java.util.Random.nextInt -> int
        v2 = _result;
        v2 = unaryOp_0x81(v2);
        v2 = binOp2addr_0xbb(v2, v0);
        _result = v2.valueOf(v3); // java.lang.String.valueOf -> java.lang.String
        v4 = _result;
        _result = v0.valueOf(v1); // java.lang.String.valueOf -> java.lang.String
        v5 = _result;
        v0 = v7;
        v1 = v8;
        v2 = v9;
        v3 = v10;
        v6 = v11;
        _result = v0.a(v0..v6); // c.a.e.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    java.lang.String a(java.lang.String p0, java.lang.String p1, c.a.g[] p2, java.lang.String p3, java.lang.String p4, c.a.f p5) {
        // Registers (11 total): v4 = this, v5 = p0 (java.lang.String), v6 = p1 (java.lang.String), v7 = p2 (c.a.g[]), v8 = p3 (java.lang.String), v9 = p4 (java.lang.String), v10 = p5 (c.a.f)
        if (v7 != 0) /* goto L_0005 */;
        v0 = 0;
        v7 = new c.a.g[][size=v0];
        v0 = new java.util.ArrayList;
        v1 = 5;
        _result = v0.<init>(v1); // java.util.ArrayList.<init> -> void
        v1 = new c.a.g;
        v2 = "oauth_consumer_key";
        v3 = v4.c; // c.a.e.c:java.lang.String
        _result = v1.<init>(v2, v3); // c.a.g.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = c.a.e.a; // :c.a.g
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = new c.a.g;
        v2 = "oauth_timestamp";
        _result = v1.<init>(v2, v9); // c.a.g.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = new c.a.g;
        v2 = "oauth_nonce";
        _result = v1.<init>(v2, v8); // c.a.g.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = new c.a.g;
        v2 = "oauth_version";
        v3 = "1.0";
        _result = v1.<init>(v2, v3); // c.a.g.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        if (v10 == 0) /* goto L_0052 */;
        v1 = new c.a.g;
        v2 = "oauth_token";
        _result = v10.d(); // c.a.f.d -> java.lang.String
        v3 = _result;
        _result = v1.<init>(v2, v3); // c.a.g.<init> -> void
        _result = java.util.List.add(v0, v1); // -> boolean
        v1 = new java.util.ArrayList;
        _result = java.util.List.size(v0); // -> int
        v2 = _result;
        v3 = v7.length;
        v2 = binOp2addr_0xb0(v2, v3);
        _result = v1.<init>(v2); // java.util.ArrayList.<init> -> void
        _result = java.util.List.addAll(v1, v0); // -> boolean
        _result = v7.a(); // c.a.e.a -> java.util.List
        v2 = _result;
        _result = java.util.List.addAll(v1, v2); // -> boolean
        _result = v4.a(v6, v1); // c.a.e.a -> void
        v2 = new java.lang.StringBuffer;
        _result = v2.<init>(v5); // java.lang.StringBuffer.<init> -> void
        v3 = "&";
        _result = v2.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v2 = _result;
        _result = v6.b(); // c.a.e.b -> java.lang.String
        v3 = _result;
        _result = v3.a(); // c.a.e.a -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v2 = _result;
        v3 = "&";
        _result = v2.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v2 = _result;
        _result = v1.a(); // c.a.e.a -> java.lang.String
        v1 = _result;
        _result = v1.a(); // c.a.e.a -> java.lang.String
        v1 = _result;
        _result = v2.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        _result = v2.toString(); // java.lang.StringBuffer.toString -> java.lang.String
        v1 = _result;
        v2 = "OAuth base string:";
        _result = v4.a(v2, v1); // c.a.e.a -> void
        _result = v4.a(v1, v10); // c.a.e.a -> java.lang.String
        v1 = _result;
        v2 = "OAuth signature:";
        _result = v4.a(v2, v1); // c.a.e.a -> void
        v2 = new c.a.g;
        v3 = "oauth_signature";
        _result = v2.<init>(v3, v1); // c.a.g.<init> -> void
        _result = java.util.List.add(v0, v2); // -> boolean
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "OAuth ";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = ",";
        v3 = 1;
        _result = v0.a(v2, v3); // c.a.e.a -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public void c(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        if (v1 == 0) /* goto L_0005 */;
        v0.c = v1; // c.a.e.c:java.lang.String
        return;
        v1 = "";
        // goto L_0002
    }

    public void d(java.lang.String p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.lang.String)
        if (v1 == 0) /* goto L_0005 */;
        v0.d = v1; // c.a.e.d:java.lang.String
        return;
        v1 = "";
        // goto L_0002
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        v2 = (v5 instanceof c.a.e);
        if (v2 != 0) /* goto L_000b */;
        v0 = v1;
        // goto L_0004
        v5 = (c.a.e) v5;
        v2 = v4.c; // c.a.e.c:java.lang.String
        if (v2 == 0) /* goto L_001d */;
        v2 = v4.c; // c.a.e.c:java.lang.String
        v3 = v5.c; // c.a.e.c:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0021 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.c; // c.a.e.c:java.lang.String
        if (v2 != 0) /* goto L_001b */;
        v2 = v4.d; // c.a.e.d:java.lang.String
        if (v2 == 0) /* goto L_0031 */;
        v2 = v4.d; // c.a.e.d:java.lang.String
        v3 = v5.d; // c.a.e.d:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.d; // c.a.e.d:java.lang.String
        if (v2 == 0) /* goto L_0004 */;
        // goto L_002f
    }

    public int hashCode() {
        // Registers (4 total): v3 = this
        v1 = 0;
        v0 = v3.c; // c.a.e.c:java.lang.String
        if (v0 == 0) /* goto L_0019 */;
        v0 = v3.c; // c.a.e.c:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 31);
        v2 = v3.d; // c.a.e.d:java.lang.String
        if (v2 == 0) /* goto L_0017 */;
        v1 = v3.d; // c.a.e.d:java.lang.String
        _result = v1.hashCode(); // java.lang.String.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v0 = v1;
        // goto L_000b
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        v2 = 39;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "OAuth{consumerKey='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.c; // c.a.e.c:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", consumerSecret='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.d; // c.a.e.d:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}