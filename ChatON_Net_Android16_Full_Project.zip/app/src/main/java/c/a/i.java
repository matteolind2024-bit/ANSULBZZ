package c.a;

/**
 * Original SourceFile: Response.java
 * Descriptor: Lc/a/i;
 */
public class i {
    private static final boolean a;
    private static java.lang.ThreadLocal b;
    private static java.util.regex.Pattern i;
    private int c;
    private org.w3c.dom.Document d;
    private java.lang.String e;
    private java.io.InputStream f;
    private java.net.HttpURLConnection g;
    private boolean h;

    static {
        _result = this.p(); // c.a.p -> boolean
        v0 = _result;
        c.a.i.a = v0; // :boolean
        v0 = new c.a.j;
        _result = v0.<init>(); // c.a.j.<init> -> void
        c.a.i.b = v0; // :java.lang.ThreadLocal
        v0 = "&#([0-9]{3,5});";
        _result = v0.compile(); // java.util.regex.Pattern.compile -> java.util.regex.Pattern
        v0 = _result;
        c.a.i.i = v0; // :java.util.regex.Pattern
        return;
    }

    public i() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v1.d = v0; // c.a.i.d:org.w3c.dom.Document
        v1.e = v0; // c.a.i.e:java.lang.String
        v0 = 0;
        v1.h = v0; // c.a.i.h:boolean
        return;
    }

    public i(java.net.HttpURLConnection p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.net.HttpURLConnection)
        v0 = 0;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        v2.d = v0; // c.a.i.d:org.w3c.dom.Document
        v2.e = v0; // c.a.i.e:java.lang.String
        v0 = 0;
        v2.h = v0; // c.a.i.h:boolean
        v2.g = v3; // c.a.i.g:java.net.HttpURLConnection
        _result = v3.getResponseCode(); // java.net.HttpURLConnection.getResponseCode -> int
        v0 = _result;
        v2.c = v0; // c.a.i.c:int
        _result = v3.getErrorStream(); // java.net.HttpURLConnection.getErrorStream -> java.io.InputStream
        v0 = _result;
        v2.f = v0; // c.a.i.f:java.io.InputStream
        if (v0 != 0) /* goto L_0021 */;
        _result = v3.getInputStream(); // java.net.HttpURLConnection.getInputStream -> java.io.InputStream
        v0 = _result;
        v2.f = v0; // c.a.i.f:java.io.InputStream
        v0 = v2.f; // c.a.i.f:java.io.InputStream
        if (v0 == 0) /* goto L_003b */;
        v0 = "gzip";
        _result = v3.getContentEncoding(); // java.net.HttpURLConnection.getContentEncoding -> java.lang.String
        v1 = _result;
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003b */;
        v0 = new java.util.zip.GZIPInputStream;
        v1 = v2.f; // c.a.i.f:java.io.InputStream
        _result = v0.<init>(v1); // java.util.zip.GZIPInputStream.<init> -> void
        v2.f = v0; // c.a.i.f:java.io.InputStream
        return;
    }

    public static java.lang.String b(java.lang.String p0) {
        // Registers (5 total): v4 = p0 (java.lang.String)
        v0 = c.a.i.i; // :java.util.regex.Pattern
        _result = v0.matcher(v4); // java.util.regex.Pattern.matcher -> java.util.regex.Matcher
        v0 = _result;
        v1 = new java.lang.StringBuffer;
        _result = v1.<init>(); // java.lang.StringBuffer.<init> -> void
        _result = v0.find(); // java.util.regex.Matcher.find -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0025 */;
        v2 = 1;
        _result = v0.group(v2); // java.util.regex.Matcher.group -> java.lang.String
        v2 = _result;
        v3 = 10;
        _result = v2.parseInt(v3); // java.lang.Integer.parseInt -> int
        v2 = _result;
        v2 = unaryOp_0x8e(v2);
        _result = v2.toString(); // java.lang.Character.toString -> java.lang.String
        v2 = _result;
        _result = v0.appendReplacement(v1, v2); // java.util.regex.Matcher.appendReplacement -> java.util.regex.Matcher
        // goto L_000b
        _result = v0.appendTail(v1); // java.util.regex.Matcher.appendTail -> java.lang.StringBuffer
        _result = v1.toString(); // java.lang.StringBuffer.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    private void c(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        v0 = c.a.i.a; // :boolean
        if (v0 == 0) /* goto L_002d */;
        v0 = java.lang.System.out; // :java.io.PrintStream
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = new java.util.Date;
        _result = v2.<init>(); // java.util.Date.<init> -> void
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "]";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.println(v1); // java.io.PrintStream.println -> void
        return;
    }

    public java.io.InputStream a() {
        // Registers (3 total): v2 = this
        v0 = v2.h; // c.a.i.h:boolean
        if (v0 == 0) /* goto L_000d */;
        v0 = new java.lang.IllegalStateException;
        v1 = "Stream has already been consumed.";
        _result = v0.<init>(v1); // java.lang.IllegalStateException.<init> -> void
        throw v0;
        v0 = v2.f; // c.a.i.f:java.io.InputStream
        return v0;
    }

    public java.lang.String a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.g; // c.a.i.g:java.net.HttpURLConnection
        if (v0 == 0) /* goto L_000b */;
        v0 = v1.g; // c.a.i.g:java.net.HttpURLConnection
        _result = v0.getHeaderField(v2); // java.net.HttpURLConnection.getHeaderField -> java.lang.String
        v0 = _result;
        return v0;
        v0 = 0;
        // goto L_000a
    }

    public java.lang.String b() {
        // Registers (6 total): v5 = this
        v0 = v5.e; // c.a.i.e:java.lang.String
        if (v0 != 0) /* goto L_005e */;
        _result = v5.a(); // c.a.i.a -> java.io.InputStream
        v0 = _result;
        if (v0 != 0) /* goto L_000c */;
        v0 = 0;
        return v0;
        v1 = new java.io.BufferedReader;
        v2 = new java.io.InputStreamReader;
        v3 = "UTF-8";
        _result = v2.<init>(v0, v3); // java.io.InputStreamReader.<init> -> void
        _result = v1.<init>(v2); // java.io.BufferedReader.<init> -> void
        v2 = new java.lang.StringBuffer;
        _result = v2.<init>(); // java.lang.StringBuffer.<init> -> void
        _result = v1.readLine(); // java.io.BufferedReader.readLine -> java.lang.String
        v3 = _result;
        if (v3 == 0) /* goto L_003a */;
        _result = v2.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v3 = _result;
        v4 = "\n";
        _result = v3.append(v4); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_001e
        v0 = _exception;
        v1 = new c.j;
        _result = v0.getMessage(); // java.lang.NullPointerException.getMessage -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // c.j.<init> -> void
        throw v1;
        _result = v2.toString(); // java.lang.StringBuffer.toString -> java.lang.String
        v1 = _result;
        v5.e = v1; // c.a.i.e:java.lang.String
        _result = this.b(); // c.a.b -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_004e */;
        v1 = v5.e; // c.a.i.e:java.lang.String
        _result = v1.b(); // c.a.i.b -> java.lang.String
        v1 = _result;
        v5.e = v1; // c.a.i.e:java.lang.String
        v1 = v5.e; // c.a.i.e:java.lang.String
        _result = v5.c(v1); // c.a.i.c -> void
        _result = v0.close(); // java.io.InputStream.close -> void
        v0 = v5.g; // c.a.i.g:java.net.HttpURLConnection
        _result = v0.disconnect(); // java.net.HttpURLConnection.disconnect -> void
        v0 = 1;
        v5.h = v0; // c.a.i.h:boolean
        v0 = v5.e; // c.a.i.e:java.lang.String
        // goto L_000b
        v0 = _exception;
        v1 = new c.j;
        _result = v0.getMessage(); // java.io.IOException.getMessage -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // c.j.<init> -> void
        throw v1;
    }

    public c.b.a.c c() {
        // Registers (5 total): v4 = this
        v0 = new c.b.a.c;
        _result = v4.b(); // c.a.i.b -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // c.b.a.c.<init> -> void
        return v0;
        v0 = _exception;
        v1 = new c.j;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.getMessage(); // c.b.a.b.getMessage -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ":";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = v4.e; // c.a.i.e:java.lang.String
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // c.j.<init> -> void
        throw v1;
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = v2.e; // c.a.i.e:java.lang.String
        if (v0 == 0) /* goto L_0007 */;
        v0 = v2.e; // c.a.i.e:java.lang.String
        return v0;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "Response{statusCode=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.c; // c.a.i.c:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", response=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.d; // c.a.i.d:org.w3c.dom.Document
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", responseString='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.e; // c.a.i.e:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 39;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", is=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.f; // c.a.i.f:java.io.InputStream
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", con=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.g; // c.a.i.g:java.net.HttpURLConnection
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        // goto L_0006
    }

}