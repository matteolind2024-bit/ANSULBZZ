package c.a;

/**
 * Original SourceFile: Response.java
 * Descriptor: Lc/a/j;
 */
final class j extends java.lang.ThreadLocal {
    j() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.ThreadLocal.<init> -> void
        return;
    }

    protected javax.xml.parsers.DocumentBuilder a() {
        // Registers (3 total): v2 = this
        _result = this.newInstance(); // javax.xml.parsers.DocumentBuilderFactory.newInstance -> javax.xml.parsers.DocumentBuilderFactory
        v0 = _result;
        _result = v0.newDocumentBuilder(); // javax.xml.parsers.DocumentBuilderFactory.newDocumentBuilder -> javax.xml.parsers.DocumentBuilder
        v0 = _result;
        return v0;
        v0 = _exception;
        v1 = new java.lang.ExceptionInInitializerError;
        _result = v1.<init>(v0); // java.lang.ExceptionInInitializerError.<init> -> void
        throw v1;
    }

    protected java.lang.Object initialValue() {
        // Registers (2 total): v1 = this
        _result = v1.a(); // c.a.j.a -> javax.xml.parsers.DocumentBuilder
        v0 = _result;
        return v0;
    }

}