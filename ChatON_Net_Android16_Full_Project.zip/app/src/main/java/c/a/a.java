package c.a;

/**
 * Original SourceFile: AccessToken.java
 * Descriptor: Lc/a/a;
 */
public class a extends c.a.f {
    private java.lang.String c;
    private long d;
    private java.lang.String e;

    a(c.a.i p0) {
        // Registers (3 total): v1 = this, v2 = p0 (c.a.i)
        _result = v2.b(); // c.a.i.b -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // c.a.a.<init> -> void
        return;
    }

    a(c.b.a.c p0) {
        // Registers (6 total): v4 = this, v5 = p0 (c.b.a.c)
        _result = v4.<init>(); // c.a.f.<init> -> void
        v0 = "access_token";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.e = v0; // c.a.a.e:java.lang.String
        return;
        v0 = _exception;
        v1 = new c.j;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.getMessage(); // c.b.a.b.getMessage -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ":";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // c.j.<init> -> void
        throw v1;
    }

    a(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        _result = v2.<init>(v3); // c.a.f.<init> -> void
        v0 = "screen_name";
        _result = v2.a(v0); // c.a.a.a -> java.lang.String
        v0 = _result;
        v2.c = v0; // c.a.a.c:java.lang.String
        v0 = "user_id";
        _result = v2.a(v0); // c.a.a.a -> java.lang.String
        v0 = _result;
        if (v0 == 0) /* goto L_001b */;
        _result = v0.parseLong(); // java.lang.Long.parseLong -> long
        v0 = _result;
        v2.d = v0; // c.a.a.d:long
        return;
    }

    public a(java.lang.String p0, java.lang.String p1) {
        // Registers (3 total): v0 = this, v1 = p0 (java.lang.String), v2 = p1 (java.lang.String)
        _result = v0.<init>(v1, v2); // c.a.f.<init> -> void
        return;
    }

    public long a() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // c.a.a.d:long
        return v0;
    }

    public java.lang.String a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        _result = v1.a(v2); // c.a.f.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String b() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // c.a.a.e:java.lang.String
        return v0;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // c.a.f.c -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String d() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // c.a.f.d -> java.lang.String
        v0 = _result;
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        _result = v1.equals(v2); // c.a.f.equals -> boolean
        v0 = _result;
        return v0;
    }

    public int hashCode() {
        // Registers (2 total): v1 = this
        _result = v1.hashCode(); // c.a.f.hashCode -> int
        v0 = _result;
        return v0;
    }

    public java.lang.String toString() {
        // Registers (2 total): v1 = this
        _result = v1.toString(); // c.a.f.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}