package c.a;

/**
 * Original SourceFile: RequestToken.java
 * Descriptor: Lc/a/h;
 */
public class h extends c.a.f {
    private c.a.c c;

    h(c.a.i p0, c.a.c p1) {
        // Registers (3 total): v0 = this, v1 = p0 (c.a.i), v2 = p1 (c.a.c)
        _result = v0.<init>(v1); // c.a.f.<init> -> void
        v0.c = v2; // c.a.h.c:c.a.c
        return;
    }

    public java.lang.String a() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = v2.c; // c.a.h.c:c.a.c
        _result = v1.c(); // c.a.c.c -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "?oauth_token=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v2.d(); // c.a.h.d -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        _result = v1.a(v2); // c.a.f.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public c.a.a b(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.c; // c.a.h.c:c.a.c
        _result = v0.a(v1, v2); // c.a.c.a -> c.a.a
        v0 = _result;
        return v0;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        _result = v1.c(); // c.a.f.c -> java.lang.String
        v0 = _result;
        return v0;
    }

    public java.lang.String d() {
        // Registers (2 total): v1 = this
        _result = v1.d(); // c.a.f.d -> java.lang.String
        v0 = _result;
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        if (v5 == 0) /* goto L_0011 */;
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v2 = _result;
        _result = v5.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v3 = _result;
        if (v2 == v3) /* goto L_0013 */;
        v0 = v1;
        // goto L_0004
        _result = v4.equals(v5); // c.a.f.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_001b */;
        v0 = v1;
        // goto L_0004
        v5 = (c.a.h) v5;
        v2 = v4.c; // c.a.h.c:c.a.c
        if (v2 == 0) /* goto L_002d */;
        v2 = v4.c; // c.a.h.c:c.a.c
        v3 = v5.c; // c.a.h.c:c.a.c
        _result = v2.equals(v3); // c.a.c.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.c; // c.a.h.c:c.a.c
        if (v2 == 0) /* goto L_0004 */;
        // goto L_002b
    }

    public int hashCode() {
        // Registers (3 total): v2 = this
        _result = v2.hashCode(); // c.a.f.hashCode -> int
        v0 = _result;
        v1 = binOpLit8_0xda(v0, 31);
        v0 = v2.c; // c.a.h.c:c.a.c
        if (v0 == 0) /* goto L_0012 */;
        v0 = v2.c; // c.a.h.c:c.a.c
        _result = v0.hashCode(); // c.a.c.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v0 = 0;
        // goto L_0010
    }

    public java.lang.String toString() {
        // Registers (2 total): v1 = this
        _result = v1.toString(); // c.a.f.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}