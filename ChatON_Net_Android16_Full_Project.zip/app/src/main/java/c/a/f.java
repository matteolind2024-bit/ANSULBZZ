package c.a;

/**
 * Original SourceFile: OAuthToken.java
 * Descriptor: Lc/a/f;
 */
abstract class f implements java.io.Serializable {
     java.lang.String[] a;
     c.b.a.c b;
    private java.lang.String c;
    private java.lang.String d;
    private transient javax.crypto.spec.SecretKeySpec e;

    f() {
        // Registers (2 total): v1 = this
        v0 = 0;
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v1.a = v0; // c.a.f.a:java.lang.String[]
        v1.b = v0; // c.a.f.b:c.b.a.c
        return;
    }

    f(c.a.i p0) {
        // Registers (3 total): v1 = this, v2 = p0 (c.a.i)
        _result = v2.b(); // c.a.i.b -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // c.a.f.<init> -> void
        return;
    }

    f(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = 0;
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v1.a = v0; // c.a.f.a:java.lang.String[]
        v1.b = v0; // c.a.f.b:c.b.a.c
        v0 = "&";
        _result = v2.split(v0); // java.lang.String.split -> java.lang.String[]
        v0 = _result;
        v1.a = v0; // c.a.f.a:java.lang.String[]
        v0 = "oauth_token_secret";
        _result = v1.a(v0); // c.a.f.a -> java.lang.String
        v0 = _result;
        v1.d = v0; // c.a.f.d:java.lang.String
        v0 = "oauth_token";
        _result = v1.a(v0); // c.a.f.a -> java.lang.String
        v0 = _result;
        v1.c = v0; // c.a.f.c:java.lang.String
        return;
    }

    public f(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        v0 = 0;
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v1.a = v0; // c.a.f.a:java.lang.String[]
        v1.b = v0; // c.a.f.b:c.b.a.c
        v1.c = v2; // c.a.f.c:java.lang.String
        v1.d = v3; // c.a.f.d:java.lang.String
        return;
    }

    public java.lang.String a(java.lang.String p0) {
        // Registers (9 total): v7 = this, v8 = p0 (java.lang.String)
        v0 = 0;
        v2 = v7.a; // c.a.f.a:java.lang.String[]
        v3 = v2.length;
        v1 = 0;
        if (v1 >= v3) /* goto L_0030 */;
        v4 = v2[v1];
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v5.append(v8); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        v6 = 61;
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v5.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v5 = _result;
        _result = v4.startsWith(v5); // java.lang.String.startsWith -> boolean
        v5 = _result;
        if (v5 == 0) /* goto L_0031 */;
        v0 = "=";
        _result = v4.split(v0); // java.lang.String.split -> java.lang.String[]
        v0 = _result;
        v1 = 1;
        v0 = v0[v1];
        _result = v0.trim(); // java.lang.String.trim -> java.lang.String
        v0 = _result;
        return v0;
        v1 = binOpLit8_0xd8(v1, 1);
        // goto L_0005
    }

    void a(javax.crypto.spec.SecretKeySpec p0) {
        // Registers (2 total): v0 = this, v1 = p0 (javax.crypto.spec.SecretKeySpec)
        v0.e = v1; // c.a.f.e:javax.crypto.spec.SecretKeySpec
        return;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // c.a.f.d:java.lang.String
        return v0;
    }

    public java.lang.String d() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // c.a.f.c:java.lang.String
        return v0;
    }

    javax.crypto.spec.SecretKeySpec e() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // c.a.f.e:javax.crypto.spec.SecretKeySpec
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v4 != v5) /* goto L_0005 */;
        return v0;
        v2 = (v5 instanceof c.a.f);
        if (v2 != 0) /* goto L_000b */;
        v0 = v1;
        // goto L_0004
        v5 = (c.a.f) v5;
        v2 = v4.e; // c.a.f.e:javax.crypto.spec.SecretKeySpec
        if (v2 == 0) /* goto L_001d */;
        v2 = v4.e; // c.a.f.e:javax.crypto.spec.SecretKeySpec
        v3 = v5.e; // c.a.f.e:javax.crypto.spec.SecretKeySpec
        _result = v2.equals(v3); // javax.crypto.spec.SecretKeySpec.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0021 */;
        v0 = v1;
        // goto L_0004
        v2 = v5.e; // c.a.f.e:javax.crypto.spec.SecretKeySpec
        if (v2 != 0) /* goto L_001b */;
        v2 = v4.c; // c.a.f.c:java.lang.String
        v3 = v5.c; // c.a.f.c:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_002d */;
        v0 = v1;
        // goto L_0004
        v2 = v4.d; // c.a.f.d:java.lang.String
        v3 = v5.d; // c.a.f.d:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 != 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public int hashCode() {
        // Registers (3 total): v2 = this
        v0 = v2.c; // c.a.f.c:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.d; // c.a.f.d:java.lang.String
        _result = v1.hashCode(); // java.lang.String.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = binOpLit8_0xda(v0, 31);
        v0 = v2.e; // c.a.f.e:javax.crypto.spec.SecretKeySpec
        if (v0 == 0) /* goto L_001d */;
        v0 = v2.e; // c.a.f.e:javax.crypto.spec.SecretKeySpec
        _result = v0.hashCode(); // javax.crypto.spec.SecretKeySpec.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v0 = 0;
        // goto L_001b
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        v2 = 39;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "OAuthToken{token='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.c; // c.a.f.c:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", tokenSecret='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.d; // c.a.f.d:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", secretKeySpec=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.e; // c.a.f.e:javax.crypto.spec.SecretKeySpec
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}