package c.a;

/**
 * Original SourceFile: PostParameter.java
 * Descriptor: Lc/a/g;
 */
public class g implements java.io.Serializable, java.lang.Comparable {
     java.lang.String a;
     java.lang.String b;
    private java.io.File c;

    public g(java.lang.String p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (int)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v1.c = v0; // c.a.g.c:java.io.File
        v1.a = v2; // c.a.g.a:java.lang.String
        _result = v3.valueOf(); // java.lang.String.valueOf -> java.lang.String
        v0 = _result;
        v1.b = v0; // c.a.g.b:java.lang.String
        return;
    }

    public g(java.lang.String p0, java.lang.String p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.String)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = 0;
        v1.c = v0; // c.a.g.c:java.io.File
        v1.a = v2; // c.a.g.a:java.lang.String
        v1.b = v3; // c.a.g.b:java.lang.String
        return;
    }

    public int compareTo(java.lang.Object p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.Object)
        v3 = (c.a.g) v3;
        v0 = v2.a; // c.a.g.a:java.lang.String
        v1 = v3.a; // c.a.g.a:java.lang.String
        _result = v0.compareTo(v1); // java.lang.String.compareTo -> int
        v0 = _result;
        if (v0 != 0) /* goto L_0014 */;
        v0 = v2.b; // c.a.g.b:java.lang.String
        v1 = v3.b; // c.a.g.b:java.lang.String
        _result = v0.compareTo(v1); // java.lang.String.compareTo -> int
        v0 = _result;
        return v0;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v5 != 0) /* goto L_0005 */;
        return v1;
        if (v4 != v5) /* goto L_0009 */;
        v1 = v0;
        // goto L_0004
        v2 = (v5 instanceof c.a.g);
        if (v2 == 0) /* goto L_0004 */;
        v5 = (c.a.g) v5;
        v2 = v4.c; // c.a.g.c:java.io.File
        if (v2 == 0) /* goto L_0033 */;
        v2 = v4.c; // c.a.g.c:java.io.File
        v3 = v5.c; // c.a.g.c:java.io.File
        _result = v2.equals(v3); // java.io.File.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0004 */;
        v2 = v4.a; // c.a.g.a:java.lang.String
        v3 = v5.a; // c.a.g.a:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0038 */;
        v2 = v4.b; // c.a.g.b:java.lang.String
        v3 = v5.b; // c.a.g.b:java.lang.String
        _result = v2.equals(v3); // java.lang.String.equals -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0038 */;
        v1 = v0;
        // goto L_0004
        v2 = v5.c; // c.a.g.c:java.io.File
        if (v2 == 0) /* goto L_001d */;
        // goto L_0004
        v0 = v1;
        // goto L_0031
    }

    public int hashCode() {
        // Registers (3 total): v2 = this
        v0 = v2.a; // c.a.g.a:java.lang.String
        _result = v0.hashCode(); // java.lang.String.hashCode -> int
        v0 = _result;
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v2.b; // c.a.g.b:java.lang.String
        _result = v1.hashCode(); // java.lang.String.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v1 = binOpLit8_0xda(v0, 31);
        v0 = v2.c; // c.a.g.c:java.io.File
        if (v0 == 0) /* goto L_001d */;
        v0 = v2.c; // c.a.g.c:java.io.File
        _result = v0.hashCode(); // java.io.File.hashCode -> int
        v0 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
        v0 = 0;
        // goto L_001b
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        v2 = 39;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "PostParameter{name='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.a; // c.a.g.a:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", value='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.b; // c.a.g.b:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", file=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.c; // c.a.g.c:java.io.File
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}