package c.b.a;

/**
 * Original SourceFile: JSONTokener.java
 * Descriptor: Lc/b/a/g;
 */
public class g {
    private int a;
    private java.io.Reader b;
    private char c;
    private boolean d;

    public g(java.io.Reader p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.io.Reader)
        v1 = 0;
        _result = v2.<init>(); // java.lang.Object.<init> -> void
        _result = v3.markSupported(); // java.io.Reader.markSupported -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0011 */;
        v2.b = v3; // c.b.a.g.b:java.io.Reader
        v2.d = v1; // c.b.a.g.d:boolean
        v2.a = v1; // c.b.a.g.a:int
        return;
        v0 = new java.io.BufferedReader;
        _result = v0.<init>(v3); // java.io.BufferedReader.<init> -> void
        v3 = v0;
        // goto L_000a
    }

    public g(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = new java.io.StringReader;
        _result = v0.<init>(v2); // java.io.StringReader.<init> -> void
        _result = v1.<init>(v0); // c.b.a.g.<init> -> void
        return;
    }

    public c.b.a.b a(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        v0 = new c.b.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v3.toString(); // c.b.a.g.toString -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        return v0;
    }

    public java.lang.String a(char p0) {
        // Registers (5 total): v3 = this, v4 = p0 (char)
        v2 = 16;
        v0 = new java.lang.StringBuffer;
        _result = v0.<init>(); // java.lang.StringBuffer.<init> -> void
        _result = v3.b(); // c.b.a.g.b -> char
        v1 = _result;
        // switch(v1)
        if (v1 != v4) /* goto L_0062 */;
        _result = v0.toString(); // java.lang.StringBuffer.toString -> java.lang.String
        v0 = _result;
        return v0;
        v0 = "Unterminated string";
        _result = v3.a(v0); // c.b.a.g.a -> c.b.a.b
        v0 = _result;
        throw v0;
        _result = v3.b(); // c.b.a.g.b -> char
        v1 = _result;
        // switch(v1)
        _result = v0.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0007
        v1 = 8;
        _result = v0.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0007
        v1 = 9;
        _result = v0.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0007
        v1 = 10;
        _result = v0.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0007
        v1 = 12;
        _result = v0.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0007
        v1 = 13;
        _result = v0.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0007
        v1 = 4;
        _result = v3.a(v1); // c.b.a.g.a -> java.lang.String
        v1 = _result;
        _result = v1.parseInt(v2); // java.lang.Integer.parseInt -> int
        v1 = _result;
        v1 = unaryOp_0x8e(v1);
        _result = v0.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0007
        v1 = 2;
        _result = v3.a(v1); // c.b.a.g.a -> java.lang.String
        v1 = _result;
        _result = v1.parseInt(v2); // java.lang.Integer.parseInt -> int
        v1 = _result;
        v1 = unaryOp_0x8e(v1);
        _result = v0.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0007
        _result = v0.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0007
    }

    public java.lang.String a(int p0) {
        // Registers (6 total): v4 = this, v5 = p0 (int)
        v0 = 0;
        if (v5 != 0) /* goto L_0007 */;
        v0 = "";
        return v0;
        v1 = new char[][size=v5];
        v2 = v4.d; // c.b.a.g.d:boolean
        if (v2 == 0) /* goto L_0014 */;
        v4.d = v0; // c.b.a.g.d:boolean
        v2 = v4.c; // c.b.a.g.c:char
        v1[v0] = v2;
        v0 = 1;
        if (v0 >= v5) /* goto L_002a */;
        v2 = v4.b; // c.b.a.g.b:java.io.Reader
        v3 = binOp_0x91(v5, v0);
        _result = v2.read(v1, v0, v3); // java.io.Reader.read -> int
        v2 = _result;
        v3 = -1;
        if (v2 == v3) /* goto L_002a */;
        v0 = binOp2addr_0xb0(v0, v2);
        // goto L_0014
        v0 = _exception;
        v1 = new c.b.a.b;
        _result = v1.<init>(v0); // c.b.a.b.<init> -> void
        throw v1;
        v2 = v4.a; // c.b.a.g.a:int
        v2 = binOp2addr_0xb0(v2, v0);
        v4.a = v2; // c.b.a.g.a:int
        if (v0 >= v5) /* goto L_0039 */;
        v0 = "Substring bounds error";
        _result = v4.a(v0); // c.b.a.g.a -> c.b.a.b
        v0 = _result;
        throw v0;
        v0 = binOpLit8_0xd8(v5, -1);
        v0 = v1[v0];
        v4.c = v0; // c.b.a.g.c:char
        v0 = new java.lang.String;
        _result = v0.<init>(v1); // java.lang.String.<init> -> void
        // goto L_0006
    }

    public void a() {
        // Registers (3 total): v2 = this
        v0 = v2.d; // c.b.a.g.d:boolean
        if (v0 != 0) /* goto L_0008 */;
        v0 = v2.a; // c.b.a.g.a:int
        if (v0 > 0) /* goto L_0011 */;
        v0 = new c.b.a.b;
        v1 = "Stepping back two steps is not supported";
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
        v0 = v2.a; // c.b.a.g.a:int
        v0 = binOpLit8_0xd8(v0, -1);
        v2.a = v0; // c.b.a.g.a:int
        v0 = 1;
        v2.d = v0; // c.b.a.g.d:boolean
        return;
    }

    public char b() {
        // Registers (3 total): v2 = this
        v0 = 0;
        v1 = v2.d; // c.b.a.g.d:boolean
        if (v1 == 0) /* goto L_0014 */;
        v2.d = v0; // c.b.a.g.d:boolean
        v0 = v2.c; // c.b.a.g.c:char
        if (v0 == 0) /* goto L_0011 */;
        v0 = v2.a; // c.b.a.g.a:int
        v0 = binOpLit8_0xd8(v0, 1);
        v2.a = v0; // c.b.a.g.a:int
        v0 = v2.c; // c.b.a.g.c:char
        return v0;
        v1 = v2.b; // c.b.a.g.b:java.io.Reader
        _result = v1.read(); // java.io.Reader.read -> int
        v1 = _result;
        if (v1 > 0) /* goto L_0026 */;
        v2.c = v0; // c.b.a.g.c:char
        // goto L_0013
        v0 = _exception;
        v1 = new c.b.a.b;
        _result = v1.<init>(v0); // c.b.a.b.<init> -> void
        throw v1;
        v0 = v2.a; // c.b.a.g.a:int
        v0 = binOpLit8_0xd8(v0, 1);
        v2.a = v0; // c.b.a.g.a:int
        v0 = unaryOp_0x8e(v1);
        v2.c = v0; // c.b.a.g.c:char
        v0 = v2.c; // c.b.a.g.c:char
        // goto L_0013
    }

    public char c() {
        // Registers (3 total): v2 = this
        _result = v2.b(); // c.b.a.g.b -> char
        v0 = _result;
        if (v0 == 0) /* goto L_000a */;
        v1 = 32;
        if (v0 <= v1) /* goto L_0000 */;
        return v0;
    }

    public java.lang.Object d() {
        // Registers (4 total): v3 = this
        _result = v3.c(); // c.b.a.g.c -> char
        v0 = _result;
        // switch(v0)
        v1 = new java.lang.StringBuffer;
        _result = v1.<init>(); // java.lang.StringBuffer.<init> -> void
        v2 = 32;
        if (v0 < v2) /* goto L_0038 */;
        v2 = ",:]}/\\\"[{;=#";
        _result = v2.indexOf(v0); // java.lang.String.indexOf -> int
        v2 = _result;
        if (v2 >= 0) /* goto L_0038 */;
        _result = v1.append(v0); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        _result = v3.b(); // c.b.a.g.b -> char
        v0 = _result;
        // goto L_000c
        _result = v3.a(v0); // c.b.a.g.a -> java.lang.String
        v0 = _result;
        return v0;
        _result = v3.a(); // c.b.a.g.a -> void
        v0 = new c.b.a.c;
        _result = v0.<init>(v3); // c.b.a.c.<init> -> void
        // goto L_0025
        _result = v3.a(); // c.b.a.g.a -> void
        v0 = new c.b.a.a;
        _result = v0.<init>(v3); // c.b.a.a.<init> -> void
        // goto L_0025
        _result = v3.a(); // c.b.a.g.a -> void
        _result = v1.toString(); // java.lang.StringBuffer.toString -> java.lang.String
        v0 = _result;
        _result = v0.trim(); // java.lang.String.trim -> java.lang.String
        v0 = _result;
        v1 = "";
        _result = v0.equals(v1); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0054 */;
        v0 = "Missing value";
        _result = v3.a(v0); // c.b.a.g.a -> c.b.a.b
        v0 = _result;
        throw v0;
        _result = v0.m(); // c.b.a.c.m -> java.lang.Object
        v0 = _result;
        // goto L_0025
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = " at character ";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v2.a; // c.b.a.g.a:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}