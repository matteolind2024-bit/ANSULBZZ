package c.b.a;

/**
 * Original SourceFile: JSONString.java
 * Descriptor: Lc/b/a/f;
 */
public interface f {
    public abstract java.lang.String a();
}