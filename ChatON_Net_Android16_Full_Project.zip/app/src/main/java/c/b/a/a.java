package c.b.a;

/**
 * Original SourceFile: JSONArray.java
 * Descriptor: Lc/b/a/a;
 */
public class a {
    private java.util.ArrayList a;

    public a() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.a = v0; // c.b.a.a.a:java.util.ArrayList
        return;
    }

    public a(c.b.a.g p0) {
        // Registers (6 total): v4 = this, v5 = p0 (c.b.a.g)
        v1 = 93;
        _result = v4.<init>(); // c.b.a.a.<init> -> void
        _result = v5.c(); // c.b.a.g.c -> char
        v0 = _result;
        v2 = 91;
        if (v0 != v2) /* goto L_0015 */;
        v0 = v1;
        _result = v5.c(); // c.b.a.g.c -> char
        v2 = _result;
        if (v2 != v1) /* goto L_0024 */;
        return;
        v2 = 40;
        if (v0 != v2) /* goto L_001c */;
        v0 = 41;
        // goto L_000e
        v0 = "A JSONArray text must start with '['";
        _result = v5.a(v0); // c.b.a.g.a -> c.b.a.b
        v0 = _result;
        throw v0;
        _result = v5.a(); // c.b.a.g.a -> void
        _result = v5.c(); // c.b.a.g.c -> char
        v2 = _result;
        v3 = 44;
        if (v2 != v3) /* goto L_0047 */;
        _result = v5.a(); // c.b.a.g.a -> void
        v2 = v4.a; // c.b.a.a.a:java.util.ArrayList
        v3 = 0;
        _result = v2.add(v3); // java.util.ArrayList.add -> boolean
        _result = v5.c(); // c.b.a.g.c -> char
        v2 = _result;
        // switch(v2)
        v0 = "Expected a ',' or ']'";
        _result = v5.a(v0); // c.b.a.g.a -> c.b.a.b
        v0 = _result;
        throw v0;
        _result = v5.a(); // c.b.a.g.a -> void
        v2 = v4.a; // c.b.a.a.a:java.util.ArrayList
        _result = v5.d(); // c.b.a.g.d -> java.lang.Object
        v3 = _result;
        _result = v2.add(v3); // java.util.ArrayList.add -> boolean
        // goto L_0038
        _result = v5.c(); // c.b.a.g.c -> char
        v2 = _result;
        if (v2 == v1) /* goto L_0014 */;
        _result = v5.a(); // c.b.a.g.a -> void
        // goto L_0027
        if (v0 == v2) /* goto L_0014 */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Expected a '";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = new java.lang.Character;
        _result = v2.<init>(v0); // java.lang.Character.<init> -> void
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = "'";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v5.a(v0); // c.b.a.g.a -> c.b.a.b
        v0 = _result;
        throw v0;
    }

    public a(java.lang.Object p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.Object)
        _result = v3.<init>(); // c.b.a.a.<init> -> void
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.isArray(); // java.lang.Class.isArray -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001e */;
        _result = v4.getLength(); // java.lang.reflect.Array.getLength -> int
        v1 = _result;
        v0 = 0;
        if (v0 >= v1) /* goto L_0027 */;
        _result = v4.get(v0); // java.lang.reflect.Array.get -> java.lang.Object
        v2 = _result;
        _result = v3.a(v2); // c.b.a.a.a -> c.b.a.a
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0012
        v0 = new c.b.a.b;
        v1 = "JSONArray initial value should be a string or collection or array.";
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
        return;
    }

    public a(java.util.Collection p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.util.Collection)
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        if (v2 != 0) /* goto L_000d */;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(); // java.util.ArrayList.<init> -> void
        v1.a = v0; // c.b.a.a.a:java.util.ArrayList
        return;
        v0 = new java.util.ArrayList;
        _result = v0.<init>(v2); // java.util.ArrayList.<init> -> void
        // goto L_000a
    }

    public int a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // c.b.a.a.a:java.util.ArrayList
        _result = v0.size(); // java.util.ArrayList.size -> int
        v0 = _result;
        return v0;
    }

    public c.b.a.a a(java.lang.Object p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Object)
        v0 = v1.a; // c.b.a.a.a:java.util.ArrayList
        _result = v0.add(v2); // java.util.ArrayList.add -> boolean
        return v1;
    }

    public java.lang.Object a(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        _result = v3.e(v4); // c.b.a.a.e -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_0027 */;
        v0 = new c.b.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "JSONArray[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "] not found.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
        return v0;
    }

    public java.lang.String a(java.lang.String p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.String)
        _result = v4.a(); // c.b.a.a.a -> int
        v1 = _result;
        v2 = new java.lang.StringBuffer;
        _result = v2.<init>(); // java.lang.StringBuffer.<init> -> void
        v0 = 0;
        if (v0 >= v1) /* goto L_0021 */;
        if (v0 <= 0) /* goto L_0011 */;
        _result = v2.append(v5); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v3 = v4.a; // c.b.a.a.a:java.util.ArrayList
        _result = v3.get(v0); // java.util.ArrayList.get -> java.lang.Object
        v3 = _result;
        _result = v3.b(); // c.b.a.c.b -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_000a
        _result = v2.toString(); // java.lang.StringBuffer.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

    public double b(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        _result = v3.a(v4); // c.b.a.a.a -> java.lang.Object
        v0 = _result;
        v1 = (v0 instanceof java.lang.Number);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.Number) v0;
        _result = v0.doubleValue(); // java.lang.Number.doubleValue -> double
        v0 = _result;
        return v0;
        v0 = (java.lang.String) v0;
        _result = v0.valueOf(); // java.lang.Double.valueOf -> java.lang.Double
        v0 = _result;
        _result = v0.doubleValue(); // java.lang.Double.doubleValue -> double
        v0 = _result;
        // goto L_000e
        v0 = _exception;
        v0 = new c.b.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "JSONArray[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "] is not a number.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
    }

    public c.b.a.c c(int p0) {
        // Registers (5 total): v3 = this, v4 = p0 (int)
        _result = v3.a(v4); // c.b.a.a.a -> java.lang.Object
        v0 = _result;
        v1 = (v0 instanceof c.b.a.c);
        if (v1 == 0) /* goto L_000b */;
        v0 = (c.b.a.c) v0;
        return v0;
        v0 = new c.b.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "JSONArray[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "] is not a JSONObject.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
    }

    public long d(int p0) {
        // Registers (4 total): v2 = this, v3 = p0 (int)
        _result = v2.a(v3); // c.b.a.a.a -> java.lang.Object
        v0 = _result;
        v1 = (v0 instanceof java.lang.Number);
        if (v1 == 0) /* goto L_000f */;
        v0 = (java.lang.Number) v0;
        _result = v0.longValue(); // java.lang.Number.longValue -> long
        v0 = _result;
        return v0;
        _result = v2.b(v3); // c.b.a.a.b -> double
        v0 = _result;
        v0 = unaryOp_0x8b(v0);
        // goto L_000e
    }

    public java.lang.Object e(int p0) {
        // Registers (3 total): v1 = this, v2 = p0 (int)
        if (v2 < 0) /* goto L_0008 */;
        _result = v1.a(); // c.b.a.a.a -> int
        v0 = _result;
        if (v2 < v0) /* goto L_000a */;
        v0 = 0;
        return v0;
        v0 = v1.a; // c.b.a.a.a:java.util.ArrayList
        _result = v0.get(v2); // java.util.ArrayList.get -> java.lang.Object
        v0 = _result;
        // goto L_0009
    }

    public java.lang.String toString() {
        // Registers (3 total): v2 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = 91;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ",";
        _result = v2.a(v1); // c.b.a.a.a -> java.lang.String
        v1 = _result;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 93;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
        v0 = _exception;
        v0 = 0;
        // goto L_0020
    }

}