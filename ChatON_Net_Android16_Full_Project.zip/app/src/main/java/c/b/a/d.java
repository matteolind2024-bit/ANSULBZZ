package c.b.a;

/**
 * Original SourceFile: JSONObject.java
 * Descriptor: Lc/b/a/d;
 */
class d {
}