package c.b.a;

/**
 * Original SourceFile: JSONObject.java
 * Descriptor: Lc/b/a/c;
 */
public class c {
    public static final java.lang.Object a;
    private java.util.Map b;

    static {
        v0 = new c.b.a.e;
        v1 = 0;
        _result = v0.<init>(v1); // c.b.a.e.<init> -> void
        c.b.a.c.a = v0; // :java.lang.Object
        return;
    }

    public c() {
        // Registers (2 total): v1 = this
        _result = v1.<init>(); // java.lang.Object.<init> -> void
        v0 = new java.util.HashMap;
        _result = v0.<init>(); // java.util.HashMap.<init> -> void
        v1.b = v0; // c.b.a.c.b:java.util.Map
        return;
    }

    public c(c.b.a.g p0) {
        // Registers (5 total): v3 = this, v4 = p0 (c.b.a.g)
        _result = v3.<init>(); // c.b.a.c.<init> -> void
        _result = v4.c(); // c.b.a.g.c -> char
        v0 = _result;
        v1 = 123;
        if (v0 == v1) /* goto L_0016 */;
        v0 = "A JSONObject text must begin with '{'";
        _result = v4.a(v0); // c.b.a.g.a -> c.b.a.b
        v0 = _result;
        throw v0;
        _result = v4.a(); // c.b.a.g.a -> void
        _result = v4.c(); // c.b.a.g.c -> char
        v0 = _result;
        // switch(v0)
        _result = v4.a(); // c.b.a.g.a -> void
        _result = v4.d(); // c.b.a.g.d -> java.lang.Object
        v0 = _result;
        _result = v0.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        _result = v4.c(); // c.b.a.g.c -> char
        v1 = _result;
        v2 = 61;
        if (v1 != v2) /* goto L_0059 */;
        _result = v4.b(); // c.b.a.g.b -> char
        v1 = _result;
        v2 = 62;
        if (v1 == v2) /* goto L_003b */;
        _result = v4.a(); // c.b.a.g.a -> void
        _result = v4.d(); // c.b.a.g.d -> java.lang.Object
        v1 = _result;
        _result = v3.b(v0, v1); // c.b.a.c.b -> c.b.a.c
        _result = v4.c(); // c.b.a.g.c -> char
        v0 = _result;
        // switch(v0)
        v0 = "Expected a ',' or '}'";
        _result = v4.a(v0); // c.b.a.g.a -> c.b.a.b
        v0 = _result;
        throw v0;
        v0 = "A JSONObject text must end with '}'";
        _result = v4.a(v0); // c.b.a.g.a -> c.b.a.b
        v0 = _result;
        throw v0;
        v2 = 58;
        if (v1 == v2) /* goto L_003b */;
        v0 = "Expected a ':' after a key";
        _result = v4.a(v0); // c.b.a.g.a -> c.b.a.b
        v0 = _result;
        throw v0;
        _result = v4.c(); // c.b.a.g.c -> char
        v0 = _result;
        v1 = 125;
        if (v0 != v1) /* goto L_0013 */;
        return;
    }

    public c(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = new c.b.a.g;
        _result = v0.<init>(v2); // c.b.a.g.<init> -> void
        _result = v1.<init>(v0); // c.b.a.c.<init> -> void
        return;
    }

    public c(java.util.Map p0) {
        // Registers (2 total): v0 = this, v1 = p0 (java.util.Map)
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        if (v1 != 0) /* goto L_000a */;
        v1 = new java.util.HashMap;
        _result = v1.<init>(); // java.util.HashMap.<init> -> void
        v0.b = v1; // c.b.a.c.b:java.util.Map
        return;
    }

    public static java.lang.String a(java.lang.Number p0) {
        // Registers (4 total): v3 = p0 (java.lang.Number)
        v2 = 0;
        if (v3 != 0) /* goto L_000c */;
        v0 = new c.b.a.b;
        v1 = "Null pointer";
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
        _result = v3.a(); // c.b.a.c.a -> void
        _result = v3.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        v1 = 46;
        _result = v0.indexOf(v1); // java.lang.String.indexOf -> int
        v1 = _result;
        if (v1 <= 0) /* goto L_0052 */;
        v1 = 101;
        _result = v0.indexOf(v1); // java.lang.String.indexOf -> int
        v1 = _result;
        if (v1 >= 0) /* goto L_0052 */;
        v1 = 69;
        _result = v0.indexOf(v1); // java.lang.String.indexOf -> int
        v1 = _result;
        if (v1 >= 0) /* goto L_0052 */;
        v1 = "0";
        _result = v0.endsWith(v1); // java.lang.String.endsWith -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_003f */;
        _result = v0.length(); // java.lang.String.length -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        _result = v0.substring(v2, v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        // goto L_002b
        v1 = ".";
        _result = v0.endsWith(v1); // java.lang.String.endsWith -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_0052 */;
        _result = v0.length(); // java.lang.String.length -> int
        v1 = _result;
        v1 = binOpLit8_0xd8(v1, -1);
        _result = v0.substring(v2, v1); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        return v0;
    }

    static void a(java.lang.Object p0) {
        // Registers (3 total): v2 = p0 (java.lang.Object)
        if (v2 == 0) /* goto L_003e */;
        v0 = (v2 instanceof java.lang.Double);
        if (v0 == 0) /* goto L_0020 */;
        v0 = v2;
        v0 = (java.lang.Double) v0;
        _result = v0.isInfinite(); // java.lang.Double.isInfinite -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0017 */;
        v2 = (java.lang.Double) v2;
        _result = v2.isNaN(); // java.lang.Double.isNaN -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003e */;
        v0 = new c.b.a.b;
        v1 = "JSON does not allow non-finite numbers.";
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
        v0 = (v2 instanceof java.lang.Float);
        if (v0 == 0) /* goto L_003e */;
        v0 = v2;
        v0 = (java.lang.Float) v0;
        _result = v0.isInfinite(); // java.lang.Float.isInfinite -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0035 */;
        v2 = (java.lang.Float) v2;
        _result = v2.isNaN(); // java.lang.Float.isNaN -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003e */;
        v0 = new c.b.a.b;
        v1 = "JSON does not allow non-finite numbers.";
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
        return;
    }

    static java.lang.String b(java.lang.Object p0) {
        // Registers (5 total): v4 = p0 (java.lang.Object)
        if (v4 == 0) /* goto L_0009 */;
        v0 = 0;
        _result = v4.equals(v0); // java.lang.Object.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000d */;
        v0 = "null";
        return v0;
        v0 = (v4 instanceof c.b.a.f);
        if (v0 == 0) /* goto L_003f */;
        v4 = (c.b.a.f) v4;
        _result = c.b.a.f.a(v4); // -> java.lang.String
        v0 = _result;
        v1 = (v0 instanceof java.lang.String);
        if (v1 == 0) /* goto L_0025 */;
        v0 = (java.lang.String) v0;
        // goto L_000c
        v0 = _exception;
        v1 = new c.b.a.b;
        _result = v1.<init>(v0); // c.b.a.b.<init> -> void
        throw v1;
        v1 = new c.b.a.b;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = "Bad value from toJSONString: ";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v1.<init>(v0); // c.b.a.b.<init> -> void
        throw v1;
        v0 = (v4 instanceof java.lang.Number);
        if (v0 == 0) /* goto L_004a */;
        v4 = (java.lang.Number) v4;
        _result = v4.a(); // c.b.a.c.a -> java.lang.String
        v0 = _result;
        // goto L_000c
        v0 = (v4 instanceof java.lang.Boolean);
        if (v0 != 0) /* goto L_0056 */;
        v0 = (v4 instanceof c.b.a.c);
        if (v0 != 0) /* goto L_0056 */;
        v0 = (v4 instanceof c.b.a.a);
        if (v0 == 0) /* goto L_005b */;
        _result = v4.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        // goto L_000c
        v0 = (v4 instanceof java.util.Map);
        if (v0 == 0) /* goto L_006b */;
        v0 = new c.b.a.c;
        v4 = (java.util.Map) v4;
        _result = v0.<init>(v4); // c.b.a.c.<init> -> void
        _result = v0.toString(); // c.b.a.c.toString -> java.lang.String
        v0 = _result;
        // goto L_000c
        v0 = (v4 instanceof java.util.Collection);
        if (v0 == 0) /* goto L_007b */;
        v0 = new c.b.a.a;
        v4 = (java.util.Collection) v4;
        _result = v0.<init>(v4); // c.b.a.a.<init> -> void
        _result = v0.toString(); // c.b.a.a.toString -> java.lang.String
        v0 = _result;
        // goto L_000c
        _result = v4.getClass(); // java.lang.Object.getClass -> java.lang.Class
        v0 = _result;
        _result = v0.isArray(); // java.lang.Class.isArray -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0090 */;
        v0 = new c.b.a.a;
        _result = v0.<init>(v4); // c.b.a.a.<init> -> void
        _result = v0.toString(); // c.b.a.a.toString -> java.lang.String
        v0 = _result;
        // goto L_000c
        _result = v4.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        _result = v0.k(); // c.b.a.c.k -> java.lang.String
        v0 = _result;
        // goto L_000c
    }

    public static java.lang.String k(java.lang.String p0) {
        // Registers (10 total): v9 = p0 (java.lang.String)
        v8 = 92;
        v7 = 34;
        v0 = 0;
        if (v9 == 0) /* goto L_000d */;
        _result = v9.length(); // java.lang.String.length -> int
        v1 = _result;
        if (v1 != 0) /* goto L_0011 */;
        v0 = "\"\"";
        return v0;
        _result = v9.length(); // java.lang.String.length -> int
        v3 = _result;
        v4 = new java.lang.StringBuffer;
        v1 = binOpLit8_0xd8(v3, 4);
        _result = v4.<init>(v1); // java.lang.StringBuffer.<init> -> void
        _result = v4.append(v7); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v1 = v0;
        if (v0 >= v3) /* goto L_00b3 */;
        _result = v9.charAt(v0); // java.lang.String.charAt -> char
        v2 = _result;
        // switch(v2)
        v1 = 32;
        if (v2 < v1) /* goto L_003d */;
        v1 = 128;
        if (v2 < v1) /* goto L_0035 */;
        v1 = 160;
        if (v2 < v1) /* goto L_003d */;
        v1 = 8192;
        if (v2 < v1) /* goto L_00af */;
        v1 = 8448;
        if (v2 >= v1) /* goto L_00af */;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v5 = "000";
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v2.toHexString(); // java.lang.Integer.toHexString -> java.lang.String
        v5 = _result;
        _result = v1.append(v5); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        v5 = new java.lang.StringBuilder;
        _result = v5.<init>(); // java.lang.StringBuilder.<init> -> void
        v6 = "\\u";
        _result = v5.append(v6); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v5 = _result;
        _result = v1.length(); // java.lang.String.length -> int
        v6 = _result;
        v6 = binOpLit8_0xd8(v6, -4);
        _result = v1.substring(v6); // java.lang.String.substring -> java.lang.String
        v1 = _result;
        _result = v5.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v4.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v0 = binOpLit8_0xd8(v0, 1);
        v1 = v2;
        // goto L_0020
        _result = v4.append(v8); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        _result = v4.append(v2); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0076
        v5 = 60;
        if (v1 != v5) /* goto L_0088 */;
        _result = v4.append(v8); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        _result = v4.append(v2); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0076
        v1 = "\\b";
        _result = v4.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0076
        v1 = "\\t";
        _result = v4.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0076
        v1 = "\\n";
        _result = v4.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0076
        v1 = "\\f";
        _result = v4.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0076
        v1 = "\\r";
        _result = v4.append(v1); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0076
        _result = v4.append(v2); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_0076
        _result = v4.append(v7); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        _result = v4.toString(); // java.lang.StringBuffer.toString -> java.lang.String
        v0 = _result;
        // goto L_0010
    }

    public static java.lang.Object m(java.lang.String p0) {
        // Registers (6 total): v5 = p0 (java.lang.String)
        v4 = 48;
        v3 = 2;
        v2 = 1;
        v0 = "";
        _result = v5.equals(v0); // java.lang.String.equals -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000e */;
        return v5;
        v0 = "true";
        _result = v5.equalsIgnoreCase(v0); // java.lang.String.equalsIgnoreCase -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_001a */;
        v5 = java.lang.Boolean.TRUE; // :java.lang.Boolean
        // goto L_000d
        v0 = "false";
        _result = v5.equalsIgnoreCase(v0); // java.lang.String.equalsIgnoreCase -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0026 */;
        v5 = java.lang.Boolean.FALSE; // :java.lang.Boolean
        // goto L_000d
        v0 = "null";
        _result = v5.equalsIgnoreCase(v0); // java.lang.String.equalsIgnoreCase -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0032 */;
        v5 = c.b.a.c.a; // :java.lang.Object
        // goto L_000d
        v0 = 0;
        _result = v5.charAt(v0); // java.lang.String.charAt -> char
        v0 = _result;
        if (v0 < v4) /* goto L_003d */;
        v1 = 57;
        if (v0 <= v1) /* goto L_0049 */;
        v1 = 46;
        if (v0 == v1) /* goto L_0049 */;
        v1 = 45;
        if (v0 == v1) /* goto L_0049 */;
        v1 = 43;
        if (v0 != v1) /* goto L_000d */;
        if (v0 != v4) /* goto L_0081 */;
        _result = v5.length(); // java.lang.String.length -> int
        v0 = _result;
        if (v0 <= v3) /* goto L_0073 */;
        _result = v5.charAt(v2); // java.lang.String.charAt -> char
        v0 = _result;
        v1 = 120;
        if (v0 == v1) /* goto L_0061 */;
        _result = v5.charAt(v2); // java.lang.String.charAt -> char
        v0 = _result;
        v1 = 88;
        if (v0 != v1) /* goto L_0073 */;
        v0 = new java.lang.Integer;
        v1 = 2;
        _result = v5.substring(v1); // java.lang.String.substring -> java.lang.String
        v1 = _result;
        v2 = 16;
        _result = v1.parseInt(v2); // java.lang.Integer.parseInt -> int
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.Integer.<init> -> void
        v5 = v0;
        // goto L_000d
        v0 = new java.lang.Integer;
        v1 = 8;
        _result = v5.parseInt(v1); // java.lang.Integer.parseInt -> int
        v1 = _result;
        _result = v0.<init>(v1); // java.lang.Integer.<init> -> void
        v5 = v0;
        // goto L_000d
        v0 = _exception;
        v0 = new java.lang.Integer;
        _result = v0.<init>(v5); // java.lang.Integer.<init> -> void
        v5 = v0;
        // goto L_000d
        v0 = _exception;
        v0 = new java.lang.Long;
        _result = v0.<init>(v5); // java.lang.Long.<init> -> void
        v5 = v0;
        // goto L_000d
        v0 = _exception;
        v0 = new java.lang.Double;
        _result = v0.<init>(v5); // java.lang.Double.<init> -> void
        v5 = v0;
        // goto L_000d
        v0 = _exception;
        // goto L_000d
        v0 = _exception;
        // goto L_0081
    }

    public c.b.a.c a(java.lang.String p0, java.lang.Object p1) {
        // Registers (5 total): v2 = this, v3 = p0 (java.lang.String), v4 = p1 (java.lang.Object)
        if (v3 != 0) /* goto L_000b */;
        v0 = new c.b.a.b;
        v1 = "Null key.";
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
        if (v4 == 0) /* goto L_0016 */;
        _result = v4.a(); // c.b.a.c.a -> void
        v0 = v2.b; // c.b.a.c.b:java.util.Map
        _result = java.util.Map.put(v0, v3, v4); // -> java.lang.Object
        return v2;
        _result = v2.l(v3); // c.b.a.c.l -> java.lang.Object
        // goto L_0015
    }

    public java.lang.Object a(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        _result = v1.j(v2); // c.b.a.c.j -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.util.Iterator a() {
        // Registers (2 total): v1 = this
        v0 = v1.b; // c.b.a.c.b:java.util.Map
        _result = java.util.Map.keySet(v0); // -> java.util.Set
        v0 = _result;
        _result = java.util.Set.iterator(v0); // -> java.util.Iterator
        v0 = _result;
        return v0;
    }

    public c.b.a.c b(java.lang.String p0, java.lang.Object p1) {
        // Registers (6 total): v3 = this, v4 = p0 (java.lang.String), v5 = p1 (java.lang.Object)
        if (v4 == 0) /* goto L_002e */;
        if (v5 == 0) /* goto L_002e */;
        _result = v3.j(v4); // c.b.a.c.j -> java.lang.Object
        v0 = _result;
        if (v0 == 0) /* goto L_002b */;
        v0 = new c.b.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "Duplicate key \"";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "\"";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
        _result = v3.a(v4, v5); // c.b.a.c.a -> c.b.a.c
        return v3;
    }

    public boolean b(java.lang.String p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.String)
        v2 = 0;
        _result = v4.a(v5); // c.b.a.c.a -> java.lang.Object
        v1 = _result;
        if (v1 != 0) /* goto L_0009 */;
        v0 = v2;
        return v0;
        v0 = java.lang.Boolean.FALSE; // :java.lang.Boolean
        _result = v1.equals(v0); // java.lang.Object.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0021 */;
        v0 = (v1 instanceof java.lang.String);
        if (v0 == 0) /* goto L_0023 */;
        v0 = v1;
        v0 = (java.lang.String) v0;
        v3 = "false";
        _result = v0.equalsIgnoreCase(v3); // java.lang.String.equalsIgnoreCase -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0023 */;
        v0 = v2;
        // goto L_0008
        v0 = java.lang.Boolean.TRUE; // :java.lang.Boolean
        _result = v1.equals(v0); // java.lang.Object.equals -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_003a */;
        v0 = (v1 instanceof java.lang.String);
        if (v0 == 0) /* goto L_003c */;
        v1 = (java.lang.String) v1;
        v0 = "true";
        _result = v1.equalsIgnoreCase(v0); // java.lang.String.equalsIgnoreCase -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_003c */;
        v0 = 1;
        // goto L_0008
        v0 = new c.b.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "JSONObject[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v5.k(); // c.b.a.c.k -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "] is not a Boolean.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
    }

    public double c(java.lang.String p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.String)
        v1 = 0L;
        _result = v4.a(v5); // c.b.a.c.a -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v0 = v1;
        return v0;
        v3 = (v0 instanceof java.lang.Number);
        if (v3 == 0) /* goto L_0015 */;
        v0 = (java.lang.Number) v0;
        _result = v0.doubleValue(); // java.lang.Number.doubleValue -> double
        v0 = _result;
        // goto L_0009
        _result = v0.toString(); // java.lang.Object.toString -> java.lang.String
        v3 = _result;
        _result = v3.length(); // java.lang.String.length -> int
        v3 = _result;
        if (v3 <= 0) /* goto L_002c */;
        _result = v0.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Double.valueOf -> java.lang.Double
        v0 = _result;
        _result = v0.doubleValue(); // java.lang.Double.doubleValue -> double
        v0 = _result;
        // goto L_0009
        v0 = v1;
        // goto L_0009
        v0 = _exception;
        v0 = new c.b.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "JSONObject[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v5.k(); // c.b.a.c.k -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "] is not a number.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
    }

    public int d(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        _result = v2.a(v3); // c.b.a.c.a -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_0008 */;
        v0 = 0;
        return v0;
        v1 = (v0 instanceof java.lang.Number);
        if (v1 == 0) /* goto L_0013 */;
        v0 = (java.lang.Number) v0;
        _result = v0.intValue(); // java.lang.Number.intValue -> int
        v0 = _result;
        // goto L_0007
        _result = v2.c(v3); // c.b.a.c.c -> double
        v0 = _result;
        v0 = unaryOp_0x8a(v0);
        // goto L_0007
    }

    public c.b.a.a e(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        _result = v3.a(v4); // c.b.a.c.a -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_0008 */;
        v0 = 0;
        return v0;
        v1 = (v0 instanceof c.b.a.a);
        if (v1 == 0) /* goto L_000f */;
        v0 = (c.b.a.a) v0;
        // goto L_0007
        v0 = new c.b.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "JSONObject[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v4.k(); // c.b.a.c.k -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "] is not a JSONArray.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
    }

    public c.b.a.c f(java.lang.String p0) {
        // Registers (5 total): v3 = this, v4 = p0 (java.lang.String)
        _result = v3.a(v4); // c.b.a.c.a -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_0008 */;
        v0 = 0;
        return v0;
        v1 = (v0 instanceof c.b.a.c);
        if (v1 == 0) /* goto L_000f */;
        v0 = (c.b.a.c) v0;
        // goto L_0007
        v0 = new c.b.a.b;
        v1 = new java.lang.StringBuilder;
        _result = v1.<init>(); // java.lang.StringBuilder.<init> -> void
        v2 = "JSONObject[";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v4.k(); // c.b.a.c.k -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v2 = "] is not a JSONObject.";
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v1.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v1 = _result;
        _result = v0.<init>(v1); // c.b.a.b.<init> -> void
        throw v0;
    }

    public long g(java.lang.String p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.String)
        v1 = 0L;
        _result = v4.a(v5); // c.b.a.c.a -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v0 = v1;
        return v0;
        v3 = (v0 instanceof java.lang.String);
        if (v3 == 0) /* goto L_0027 */;
        _result = v0.toString(); // java.lang.Object.toString -> java.lang.String
        v3 = _result;
        _result = v3.length(); // java.lang.String.length -> int
        v3 = _result;
        if (v3 <= 0) /* goto L_0025 */;
        _result = v0.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Long.valueOf -> java.lang.Long
        v0 = _result;
        _result = v0.longValue(); // java.lang.Long.longValue -> long
        v0 = _result;
        // goto L_0009
        v0 = v1;
        // goto L_0009
        v1 = (v0 instanceof java.lang.Number);
        if (v1 == 0) /* goto L_0032 */;
        v0 = (java.lang.Number) v0;
        _result = v0.longValue(); // java.lang.Number.longValue -> long
        v0 = _result;
        // goto L_0009
        _result = v4.c(v5); // c.b.a.c.c -> double
        v0 = _result;
        v0 = unaryOp_0x8b(v0);
        // goto L_0009
    }

    public java.lang.String h(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        _result = v1.a(v2); // c.b.a.c.a -> java.lang.Object
        v0 = _result;
        if (v0 != 0) /* goto L_000a */;
        v0 = "";
        return v0;
        _result = v0.toString(); // java.lang.Object.toString -> java.lang.String
        v0 = _result;
        // goto L_0009
    }

    public boolean i(java.lang.String p0) {
        // Registers (4 total): v2 = this, v3 = p0 (java.lang.String)
        v0 = c.b.a.c.a; // :java.lang.Object
        _result = v2.j(v3); // c.b.a.c.j -> java.lang.Object
        v1 = _result;
        _result = v0.equals(v1); // java.lang.Object.equals -> boolean
        v0 = _result;
        return v0;
    }

    public java.lang.Object j(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        if (v2 != 0) /* goto L_0004 */;
        v0 = 0;
        return v0;
        v0 = v1.b; // c.b.a.c.b:java.util.Map
        _result = java.util.Map.get(v0, v2); // -> java.lang.Object
        v0 = _result;
        // goto L_0003
    }

    public java.lang.Object l(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        v0 = v1.b; // c.b.a.c.b:java.util.Map
        _result = java.util.Map.remove(v0, v2); // -> java.lang.Object
        v0 = _result;
        return v0;
    }

    public java.lang.String toString() {
        // Registers (5 total): v4 = this
        _result = v4.a(); // c.b.a.c.a -> java.util.Iterator
        v0 = _result;
        v1 = new java.lang.StringBuffer;
        v2 = "{";
        _result = v1.<init>(v2); // java.lang.StringBuffer.<init> -> void
        _result = java.util.Iterator.hasNext(v0); // -> boolean
        v2 = _result;
        if (v2 == 0) /* goto L_0043 */;
        _result = v1.length(); // java.lang.StringBuffer.length -> int
        v2 = _result;
        v3 = 1;
        if (v2 <= v3) /* goto L_001e */;
        v2 = 44;
        _result = v1.append(v2); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        _result = java.util.Iterator.next(v0); // -> java.lang.Object
        v2 = _result;
        _result = v2.toString(); // java.lang.Object.toString -> java.lang.String
        v3 = _result;
        _result = v3.k(); // c.b.a.c.k -> java.lang.String
        v3 = _result;
        _result = v1.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v3 = 58;
        _result = v1.append(v3); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        v3 = v4.b; // c.b.a.c.b:java.util.Map
        _result = java.util.Map.get(v3, v2); // -> java.lang.Object
        v2 = _result;
        _result = v2.b(); // c.b.a.c.b -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        // goto L_000c
        v0 = _exception;
        v0 = 0;
        return v0;
        v0 = 125;
        _result = v1.append(v0); // java.lang.StringBuffer.append -> java.lang.StringBuffer
        _result = v1.toString(); // java.lang.StringBuffer.toString -> java.lang.String
        v0 = _result;
        // goto L_0042
    }

}