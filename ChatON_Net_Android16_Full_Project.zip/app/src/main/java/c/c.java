package c;

/**
 * Original SourceFile: RetweetDetails.java
 * Descriptor: Lc/c;
 */
public class c extends c.k implements java.io.Serializable {
    private long a;
    private java.util.Date b;
    private c.e c;

    c(c.b.a.c p0) {
        // Registers (2 total): v0 = this, v1 = p0 (c.b.a.c)
        _result = v0.<init>(); // c.k.<init> -> void
        _result = v0.a(v1); // c.c.a -> void
        return;
    }

    private void a(c.b.a.c p0) {
        // Registers (6 total): v4 = this, v5 = p0 (c.b.a.c)
        v0 = "retweetId";
        _result = v5.d(v0); // c.b.a.c.d -> int
        v0 = _result;
        v0 = unaryOp_0x81(v0);
        v4.a = v0; // c.c.a:long
        v0 = "retweetedAt";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v1 = "EEE MMM dd HH:mm:ss z yyyy";
        _result = v0.a(v1); // c.c.a -> java.util.Date
        v0 = _result;
        v4.b = v0; // c.c.b:java.util.Date
        v0 = new c.e;
        v1 = "retweetingUser";
        _result = v5.f(v1); // c.b.a.c.f -> c.b.a.c
        v1 = _result;
        _result = v0.<init>(v1); // c.e.<init> -> void
        v4.c = v0; // c.c.c:c.e
        return;
        v0 = _exception;
        v1 = new c.j;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.getMessage(); // c.b.a.b.getMessage -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ":";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v5.toString(); // c.b.a.c.toString -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // c.j.<init> -> void
        throw v1;
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (8 total): v6 = this, v7 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v6 != v7) /* goto L_0005 */;
        return v0;
        v2 = (v7 instanceof c.c);
        if (v2 != 0) /* goto L_000b */;
        v0 = v1;
        // goto L_0004
        v7 = (c.c) v7;
        v2 = v6.a; // c.c.a:long
        v4 = v7.a; // c.c.a:long
        v2 = cmp(v2, v4);
        if (v2 == 0) /* goto L_0004 */;
        v0 = v1;
        // goto L_0004
    }

    public int hashCode() {
        // Registers (6 total): v5 = this
        v0 = v5.a; // c.c.a:long
        v2 = v5.a; // c.c.a:long
        v4 = 32;
        v2 = binOp2addr_0xc5(v2, v4);
        v0 = binOp2addr_0xc2(v0, v2);
        v0 = unaryOp_0x84(v0);
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v5.b; // c.c.b:java.util.Date
        _result = v1.hashCode(); // java.util.Date.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        v0 = binOpLit8_0xda(v0, 31);
        v1 = v5.c; // c.c.c:c.e
        _result = v1.hashCode(); // c.e.hashCode -> int
        v1 = _result;
        v0 = binOp2addr_0xb0(v0, v1);
        return v0;
    }

    public java.lang.String toString() {
        // Registers (4 total): v3 = this
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "RetweetDetails{retweetId=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.a; // c.c.a:long
        _result = v0.append(v1, v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", retweetedAt=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.b; // c.c.b:java.util.Date
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", retweetingUser=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v3.c; // c.c.c:c.e
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}