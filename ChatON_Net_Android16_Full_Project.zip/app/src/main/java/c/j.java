package c;

/**
 * Original SourceFile: WeiboException.java
 * Descriptor: Lc/j;
 */
public class j extends java.lang.Exception {
    private int a;

    public j(java.lang.Exception p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.Exception)
        _result = v1.<init>(v2); // java.lang.Exception.<init> -> void
        v0 = -1;
        v1.a = v0; // c.j.a:int
        return;
    }

    public j(java.lang.String p0) {
        // Registers (3 total): v1 = this, v2 = p0 (java.lang.String)
        _result = v1.<init>(v2); // java.lang.Exception.<init> -> void
        v0 = -1;
        v1.a = v0; // c.j.a:int
        return;
    }

    public j(java.lang.String p0, int p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (int)
        _result = v1.<init>(v2); // java.lang.Exception.<init> -> void
        v0 = -1;
        v1.a = v0; // c.j.a:int
        v1.a = v3; // c.j.a:int
        return;
    }

    public j(java.lang.String p0, java.lang.Exception p1) {
        // Registers (4 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.Exception)
        _result = v1.<init>(v2, v3); // java.lang.Exception.<init> -> void
        v0 = -1;
        v1.a = v0; // c.j.a:int
        return;
    }

    public j(java.lang.String p0, java.lang.Exception p1, int p2) {
        // Registers (5 total): v1 = this, v2 = p0 (java.lang.String), v3 = p1 (java.lang.Exception), v4 = p2 (int)
        _result = v1.<init>(v2, v3); // java.lang.Exception.<init> -> void
        v0 = -1;
        v1.a = v0; // c.j.a:int
        v1.a = v4; // c.j.a:int
        return;
    }

    public int a() {
        // Registers (2 total): v1 = this
        v0 = v1.a; // c.j.a:int
        return v0;
    }

}