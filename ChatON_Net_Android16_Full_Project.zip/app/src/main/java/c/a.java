package c;

/**
 * Original SourceFile: Configuration.java
 * Descriptor: Lc/a;
 */
public class a {
    private static java.util.Properties a;
    private static boolean b;

    static {
        _result = this.a(); // c.a.a -> void
        return;
    }

    public a() {
        // Registers (1 total): v0 = this
        _result = v0.<init>(); // java.lang.Object.<init> -> void
        return;
    }

    public static java.lang.String a(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = "weibo4j.clientVersion";
        _result = v0.a(v1); // c.a.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String a(java.lang.String p0, java.lang.String p1) {
        // Registers (6 total): v4 = p0 (java.lang.String), v5 = p1 (java.lang.String)
        _result = v4.getProperty(v5); // java.lang.System.getProperty -> java.lang.String
        v0 = _result;
        if (v0 != 0) /* goto L_000c */;
        v0 = c.a.a; // :java.util.Properties
        _result = v0.getProperty(v4); // java.util.Properties.getProperty -> java.lang.String
        v0 = _result;
        if (v0 != 0) /* goto L_002e */;
        v1 = c.a.a; // :java.util.Properties
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v2.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ".fallback";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.getProperty(v2); // java.util.Properties.getProperty -> java.lang.String
        v1 = _result;
        if (v1 == 0) /* goto L_002e */;
        _result = v1.getProperty(); // java.lang.System.getProperty -> java.lang.String
        v0 = _result;
        _result = v0.k(); // c.a.k -> java.lang.String
        v0 = _result;
        return v0;
        v0 = _exception;
        v0 = v5;
        // goto L_002e
    }

    static void a() {
        v0 = new java.util.Properties;
        _result = v0.<init>(); // java.util.Properties.<init> -> void
        c.a.a = v0; // :java.util.Properties
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.debug";
        v2 = "true";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.source";
        v2 = c.h.a; // :java.lang.String
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.clientURL";
        v2 = "http://open.t.sina.com.cn/-{weibo4j.clientVersion}.xml";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.http.userAgent";
        v2 = "weibo4j http://open.t.sina.com.cn/ /{weibo4j.clientVersion}";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.http.useSSL";
        v2 = "false";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.http.proxyHost.fallback";
        v2 = "http.proxyHost";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.http.proxyPort.fallback";
        v2 = "http.proxyPort";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.http.connectionTimeout";
        v2 = "20000";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.http.readTimeout";
        v2 = "120000";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.http.retryCount";
        v2 = "3";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.http.retryIntervalSecs";
        v2 = "10";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.async.numThreads";
        v2 = "1";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.clientVersion";
        _result = this.a(); // c.g.a -> java.lang.String
        v2 = _result;
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = "dalvik.system.VMRuntime";
        _result = v0.forName(); // java.lang.Class.forName -> java.lang.Class
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.dalvik";
        v2 = "true";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        v0 = "weibo4j.dalvik";
        _result = v0.h(); // c.a.h -> boolean
        v0 = _result;
        c.a.b = v0; // :boolean
        v0 = "weibo4j.properties";
        v1 = c.a.a; // :java.util.Properties
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        v3 = ".";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = java.io.File.separatorChar; // :char
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.a(v2); // c.a.a -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0119 */;
        v1 = c.a.a; // :java.util.Properties
        v2 = c.a.class;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "/WEB-INF/";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v3 = _result;
        _result = v2.getResourceAsStream(v3); // java.lang.Class.getResourceAsStream -> java.io.InputStream
        v2 = _result;
        _result = v1.a(v2); // c.a.a -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0119 */;
        v1 = c.a.a; // :java.util.Properties
        v2 = c.a.class;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        v4 = "/";
        _result = v3.append(v4); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v3 = _result;
        _result = v3.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v2.getResourceAsStream(v0); // java.lang.Class.getResourceAsStream -> java.io.InputStream
        v0 = _result;
        _result = v1.a(v0); // c.a.a -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_0119 */;
        return;
        v0 = _exception;
        v0 = c.a.a; // :java.util.Properties
        v1 = "weibo4j.dalvik";
        v2 = "false";
        _result = v0.setProperty(v1, v2); // java.util.Properties.setProperty -> java.lang.Object
        // goto L_00a7
    }

    private static boolean a(java.util.Properties p0, java.io.InputStream p1) {
        // Registers (3 total): v1 = p0 (java.util.Properties), v2 = p1 (java.io.InputStream)
        _result = v1.load(v2); // java.util.Properties.load -> void
        v0 = 1;
        return v0;
        v0 = _exception;
        v0 = 0;
        // goto L_0004
    }

    private static boolean a(java.util.Properties p0, java.lang.String p1) {
        // Registers (4 total): v2 = p0 (java.util.Properties), v3 = p1 (java.lang.String)
        v0 = new java.io.File;
        _result = v0.<init>(v3); // java.io.File.<init> -> void
        _result = v0.exists(); // java.io.File.exists -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_001c */;
        _result = v0.isFile(); // java.io.File.isFile -> boolean
        v1 = _result;
        if (v1 == 0) /* goto L_001c */;
        v1 = new java.io.FileInputStream;
        _result = v1.<init>(v0); // java.io.FileInputStream.<init> -> void
        _result = v2.load(v1); // java.util.Properties.load -> void
        v0 = 1;
        return v0;
        v0 = _exception;
        v0 = 0;
        // goto L_001a
    }

    public static java.lang.String b(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = "weibo4j.clientURL";
        _result = v0.a(v1); // c.a.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static boolean b() {
        v0 = c.a.b; // :boolean
        return v0;
    }

    public static java.lang.String c(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = "weibo4j.user";
        _result = v0.a(v1); // c.a.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static boolean c() {
        v0 = "weibo4j.http.useSSL";
        _result = v0.h(); // c.a.h -> boolean
        v0 = _result;
        return v0;
    }

    public static java.lang.String d() {
        _result = this.c(); // c.a.c -> boolean
        v0 = _result;
        if (v0 == 0) /* goto L_000a */;
        v0 = "https://";
        return v0;
        v0 = "http://";
        // goto L_0009
    }

    public static java.lang.String d(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = "weibo4j.password";
        _result = v0.a(v1); // c.a.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String e() {
        v0 = "weibo4j.source";
        _result = v0.j(); // c.a.j -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String e(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = "weibo4j.http.userAgent";
        _result = v0.a(v1); // c.a.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String f() {
        v0 = "weibo4j.http.proxyHost";
        _result = v0.j(); // c.a.j -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String f(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = "weibo4j.oauth.consumerKey";
        _result = v0.a(v1); // c.a.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String g() {
        v0 = "weibo4j.http.proxyUser";
        _result = v0.j(); // c.a.j -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String g(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = "weibo4j.oauth.consumerSecret";
        _result = v0.a(v1); // c.a.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String h() {
        v0 = "weibo4j.http.proxyPassword";
        _result = v0.j(); // c.a.j -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static boolean h(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        _result = v1.j(); // c.a.j -> java.lang.String
        v0 = _result;
        _result = v0.valueOf(); // java.lang.Boolean.valueOf -> java.lang.Boolean
        v0 = _result;
        _result = v0.booleanValue(); // java.lang.Boolean.booleanValue -> boolean
        v0 = _result;
        return v0;
    }

    public static int i() {
        v0 = "weibo4j.http.proxyPort";
        _result = v0.i(); // c.a.i -> int
        v0 = _result;
        return v0;
    }

    public static int i(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        _result = v1.j(); // c.a.j -> java.lang.String
        v0 = _result;
        _result = v0.parseInt(); // java.lang.Integer.parseInt -> int
        v0 = _result;
        return v0;
        v0 = _exception;
        v0 = -1;
        // goto L_0008
    }

    public static int j() {
        v0 = "weibo4j.http.connectionTimeout";
        _result = v0.i(); // c.a.i -> int
        v0 = _result;
        return v0;
    }

    public static java.lang.String j(java.lang.String p0) {
        // Registers (2 total): v1 = p0 (java.lang.String)
        v0 = 0;
        _result = v1.a(v0); // c.a.a -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static int k() {
        v0 = "weibo4j.http.readTimeout";
        _result = v0.i(); // c.a.i -> int
        v0 = _result;
        return v0;
    }

    private static java.lang.String k(java.lang.String p0) {
        // Registers (6 total): v5 = p0 (java.lang.String)
        v4 = 0;
        if (v5 != 0) /* goto L_0004 */;
        return v5;
        v0 = -1;
        v1 = "{";
        _result = v5.indexOf(v1, v4); // java.lang.String.indexOf -> int
        v1 = _result;
        if (v0 == v1) /* goto L_0053 */;
        v0 = "}";
        _result = v5.indexOf(v0, v1); // java.lang.String.indexOf -> int
        v0 = _result;
        v2 = binOpLit8_0xd8(v1, 1);
        if (v0 <= v2) /* goto L_0053 */;
        v2 = binOpLit8_0xd8(v1, 1);
        _result = v5.substring(v2, v0); // java.lang.String.substring -> java.lang.String
        v2 = _result;
        _result = v2.length(); // java.lang.String.length -> int
        v3 = _result;
        if (v3 <= 0) /* goto L_0053 */;
        v3 = new java.lang.StringBuilder;
        _result = v3.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v5.substring(v4, v1); // java.lang.String.substring -> java.lang.String
        v1 = _result;
        _result = v3.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        _result = v2.j(); // c.a.j -> java.lang.String
        v2 = _result;
        _result = v1.append(v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v1 = _result;
        v0 = binOpLit8_0xd8(v0, 1);
        _result = v5.substring(v0); // java.lang.String.substring -> java.lang.String
        v0 = _result;
        _result = v1.append(v0); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        _result = v0.equals(v5); // java.lang.String.equals -> boolean
        v1 = _result;
        if (v1 != 0) /* goto L_0003 */;
        _result = v0.k(); // c.a.k -> java.lang.String
        v5 = _result;
        // goto L_0003
        v0 = v5;
        // goto L_0048
    }

    public static int l() {
        v0 = "weibo4j.http.retryCount";
        _result = v0.i(); // c.a.i -> int
        v0 = _result;
        return v0;
    }

    public static int m() {
        v0 = "weibo4j.http.retryIntervalSecs";
        _result = v0.i(); // c.a.i -> int
        v0 = _result;
        return v0;
    }

    public static java.lang.String n() {
        v0 = "weibo4j.user";
        _result = v0.j(); // c.a.j -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static java.lang.String o() {
        v0 = "weibo4j.password";
        _result = v0.j(); // c.a.j -> java.lang.String
        v0 = _result;
        return v0;
    }

    public static boolean p() {
        v0 = "weibo4j.debug";
        _result = v0.h(); // c.a.h -> boolean
        v0 = _result;
        return v0;
    }

}