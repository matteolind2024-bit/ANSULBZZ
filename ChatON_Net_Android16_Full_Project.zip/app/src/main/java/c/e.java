package c;

/**
 * Original SourceFile: User.java
 * Descriptor: Lc/e;
 */
public class e extends c.k implements java.io.Serializable {
    static final java.lang.String[] a;
    private java.util.Date A;
    private int B;
    private int C;
    private java.lang.String D;
    private java.lang.String E;
    private java.lang.String F;
    private boolean G;
    private boolean H;
    private int I;
    private boolean J;
    private boolean K;
    private c.h b;
    private int c;
    private java.lang.String d;
    private java.lang.String e;
    private java.lang.String f;
    private java.lang.String g;
    private java.lang.String h;
    private java.lang.String i;
    private boolean j;
    private int k;
    private java.util.Date l;
    private long m;
    private java.lang.String n;
    private java.lang.String o;
    private boolean p;
    private long q;
    private int r;
    private boolean s;
    private java.lang.String t;
    private java.lang.String u;
    private java.lang.String v;
    private java.lang.String w;
    private java.lang.String x;
    private java.lang.String y;
    private int z;

    static {
        v0 = 4;
        v0 = new java.lang.String[][size=v0];
        v1 = 0;
        v2 = "user";
        v0[v1] = v2;
        v1 = 1;
        v2 = "sender";
        v0[v1] = v2;
        v1 = 2;
        v2 = "recipient";
        v0[v1] = v2;
        v1 = 3;
        v2 = "retweeting_user";
        v0[v1] = v2;
        c.e.a = v0; // :java.lang.String[]
        return;
    }

    e(c.b.a.c p0) {
        // Registers (7 total): v5 = this, v6 = p0 (c.b.a.c)
        v3 = -1L;
        v2 = 0;
        v1 = 0;
        _result = v5.<init>(); // c.k.<init> -> void
        v5.m = v3; // c.e.m:long
        v5.n = v1; // c.e.n:java.lang.String
        v5.o = v1; // c.e.o:java.lang.String
        v5.p = v2; // c.e.p:boolean
        v5.q = v3; // c.e.q:long
        v0 = -1;
        v5.r = v0; // c.e.r:int
        v5.s = v2; // c.e.s:boolean
        v5.t = v1; // c.e.t:java.lang.String
        _result = v5.a(v6); // c.e.a -> void
        return;
    }

    public static c.f a(c.a.i p0) {
        // Registers (10 total): v9 = p0 (c.a.i)
        _result = v9.c(); // c.a.i.c -> c.b.a.c
        v6 = _result;
        v0 = "users";
        _result = v6.e(v0); // c.b.a.c.e -> c.b.a.a
        v2 = _result;
        _result = v2.a(); // c.b.a.a.a -> int
        v3 = _result;
        v1 = new java.util.ArrayList;
        _result = v1.<init>(v3); // java.util.ArrayList.<init> -> void
        v0 = 0;
        if (v0 >= v3) /* goto L_0026 */;
        v4 = new c.e;
        _result = v2.c(v0); // c.b.a.a.c -> c.b.a.c
        v5 = _result;
        _result = v4.<init>(v5); // c.e.<init> -> void
        _result = java.util.List.add(v1, v4); // -> boolean
        v0 = binOpLit8_0xd8(v0, 1);
        // goto L_0015
        v0 = "previous_curosr";
        _result = v6.g(v0); // c.b.a.c.g -> long
        v2 = _result;
        v0 = "next_cursor";
        _result = v6.g(v0); // c.b.a.c.g -> long
        v4 = _result;
        v7 = -1L;
        v0 = cmp(v4, v7);
        if (v0 != 0) /* goto L_0041 */;
        v0 = "nextCursor";
        _result = v6.g(v0); // c.b.a.c.g -> long
        v4 = _result;
        v0 = new c.f;
        _result = v0.<init>(v0..v5); // c.f.<init> -> void
        return v0;
        v0 = _exception;
        v1 = new c.j;
        _result = v1.<init>(v0); // c.j.<init> -> void
        throw v1;
    }

    private void a(c.b.a.c p0) {
        // Registers (6 total): v4 = this, v5 = p0 (c.b.a.c)
        if (v5 == 0) /* goto L_0149 */;
        v0 = "id";
        _result = v5.d(v0); // c.b.a.c.d -> int
        v0 = _result;
        v4.c = v0; // c.e.c:int
        v0 = "name";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.d = v0; // c.e.d:java.lang.String
        v0 = "screen_name";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.e = v0; // c.e.e:java.lang.String
        v0 = "location";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.f = v0; // c.e.f:java.lang.String
        v0 = "description";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.g = v0; // c.e.g:java.lang.String
        v0 = "profile_image_url";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.h = v0; // c.e.h:java.lang.String
        v0 = "url";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.i = v0; // c.e.i:java.lang.String
        v0 = "protected";
        _result = v5.b(v0); // c.b.a.c.b -> boolean
        v0 = _result;
        v4.j = v0; // c.e.j:boolean
        v0 = "followers_count";
        _result = v5.d(v0); // c.b.a.c.d -> int
        v0 = _result;
        v4.k = v0; // c.e.k:int
        v0 = "profile_background_color";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.u = v0; // c.e.u:java.lang.String
        v0 = "profile_text_color";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.v = v0; // c.e.v:java.lang.String
        v0 = "profile_link_color";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.w = v0; // c.e.w:java.lang.String
        v0 = "profile_sidebar_fill_color";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.x = v0; // c.e.x:java.lang.String
        v0 = "profile_sidebar_border_color";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.y = v0; // c.e.y:java.lang.String
        v0 = "friends_count";
        _result = v5.d(v0); // c.b.a.c.d -> int
        v0 = _result;
        v4.z = v0; // c.e.z:int
        v0 = "created_at";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v1 = "EEE MMM dd HH:mm:ss z yyyy";
        _result = v0.a(v1); // c.e.a -> java.util.Date
        v0 = _result;
        v4.A = v0; // c.e.A:java.util.Date
        v0 = "favourites_count";
        _result = v5.d(v0); // c.b.a.c.d -> int
        v0 = _result;
        v4.B = v0; // c.e.B:int
        v0 = "utc_offset";
        _result = v0.a(v5); // c.e.a -> int
        v0 = _result;
        v4.C = v0; // c.e.C:int
        v0 = "time_zone";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.D = v0; // c.e.D:java.lang.String
        v0 = "profile_background_image_url";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.E = v0; // c.e.E:java.lang.String
        v0 = "profile_background_tile";
        _result = v5.h(v0); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.F = v0; // c.e.F:java.lang.String
        v0 = "following";
        _result = v0.c(v5); // c.e.c -> boolean
        v0 = _result;
        v4.G = v0; // c.e.G:boolean
        v0 = "notifications";
        _result = v0.c(v5); // c.e.c -> boolean
        v0 = _result;
        v4.H = v0; // c.e.H:boolean
        v0 = "statuses_count";
        _result = v5.d(v0); // c.b.a.c.d -> int
        v0 = _result;
        v4.I = v0; // c.e.I:int
        v0 = "status";
        _result = v5.i(v0); // c.b.a.c.i -> boolean
        v0 = _result;
        if (v0 != 0) /* goto L_0149 */;
        v0 = "status";
        _result = v5.f(v0); // c.b.a.c.f -> c.b.a.c
        v0 = _result;
        v1 = "created_at";
        _result = v0.h(v1); // c.b.a.c.h -> java.lang.String
        v1 = _result;
        v2 = "EEE MMM dd HH:mm:ss z yyyy";
        _result = v1.a(v2); // c.e.a -> java.util.Date
        v1 = _result;
        v4.l = v1; // c.e.l:java.util.Date
        v1 = "id";
        _result = v0.g(v1); // c.b.a.c.g -> long
        v1 = _result;
        v4.m = v1; // c.e.m:long
        v1 = "text";
        _result = v0.h(v1); // c.b.a.c.h -> java.lang.String
        v1 = _result;
        v4.n = v1; // c.e.n:java.lang.String
        v1 = "source";
        _result = v0.h(v1); // c.b.a.c.h -> java.lang.String
        v1 = _result;
        v4.o = v1; // c.e.o:java.lang.String
        v1 = "truncated";
        _result = v0.b(v1); // c.b.a.c.b -> boolean
        v1 = _result;
        v4.p = v1; // c.e.p:boolean
        v1 = "in_reply_to_status_id";
        _result = v0.g(v1); // c.b.a.c.g -> long
        v1 = _result;
        v4.q = v1; // c.e.q:long
        v1 = "in_reply_to_user_id";
        _result = v0.d(v1); // c.b.a.c.d -> int
        v1 = _result;
        v4.r = v1; // c.e.r:int
        v1 = "favorited";
        _result = v0.b(v1); // c.b.a.c.b -> boolean
        v1 = _result;
        v4.s = v1; // c.e.s:boolean
        v1 = "in_reply_to_screen_name";
        _result = v0.h(v1); // c.b.a.c.h -> java.lang.String
        v0 = _result;
        v4.t = v0; // c.e.t:java.lang.String
        return;
        v0 = _exception;
        v1 = new c.j;
        v2 = new java.lang.StringBuilder;
        _result = v2.<init>(); // java.lang.StringBuilder.<init> -> void
        _result = v0.getMessage(); // c.b.a.b.getMessage -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        v3 = ":";
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v5.toString(); // c.b.a.c.toString -> java.lang.String
        v3 = _result;
        _result = v2.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v2 = _result;
        _result = v2.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v2 = _result;
        _result = v1.<init>(v2, v0); // c.j.<init> -> void
        throw v1;
    }

    public int a() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // c.e.c:int
        return v0;
    }

    public java.lang.String b() {
        // Registers (2 total): v1 = this
        v0 = v1.d; // c.e.d:java.lang.String
        return v0;
    }

    public java.lang.String c() {
        // Registers (2 total): v1 = this
        v0 = v1.e; // c.e.e:java.lang.String
        return v0;
    }

    public java.net.URL d() {
        // Registers (3 total): v2 = this
        v0 = new java.net.URL;
        v1 = v2.h; // c.e.h:java.lang.String
        _result = v0.<init>(v1); // java.net.URL.<init> -> void
        return v0;
        v0 = _exception;
        v0 = 0;
        // goto L_0007
    }

    public boolean equals(java.lang.Object p0) {
        // Registers (6 total): v4 = this, v5 = p0 (java.lang.Object)
        v0 = 1;
        v1 = 0;
        if (v5 != 0) /* goto L_0006 */;
        v0 = v1;
        return v0;
        if (v4 == v5) /* goto L_0005 */;
        v2 = (v5 instanceof c.e);
        if (v2 == 0) /* goto L_0014 */;
        v5 = (c.e) v5;
        v2 = v5.c; // c.e.c:int
        v3 = v4.c; // c.e.c:int
        if (v2 == v3) /* goto L_0005 */;
        v0 = v1;
        // goto L_0005
    }

    public int hashCode() {
        // Registers (2 total): v1 = this
        v0 = v1.c; // c.e.c:int
        return v0;
    }

    public java.lang.String toString() {
        // Registers (5 total): v4 = this
        v3 = 39;
        v0 = new java.lang.StringBuilder;
        _result = v0.<init>(); // java.lang.StringBuilder.<init> -> void
        v1 = "User{weibo=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.b; // c.e.b:c.h
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", id=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.c; // c.e.c:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", name='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.d; // c.e.d:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", screenName='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.e; // c.e.e:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", location='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.f; // c.e.f:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", description='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.g; // c.e.g:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", profileImageUrl='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.h; // c.e.h:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", url='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.i; // c.e.i:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", isProtected=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.j; // c.e.j:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", followersCount=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.k; // c.e.k:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", statusCreatedAt=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.l; // c.e.l:java.util.Date
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", statusId=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.m; // c.e.m:long
        _result = v0.append(v1, v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", statusText='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.n; // c.e.n:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", statusSource='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.o; // c.e.o:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", statusTruncated=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.p; // c.e.p:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", statusInReplyToStatusId=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.q; // c.e.q:long
        _result = v0.append(v1, v2); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", statusInReplyToUserId=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.r; // c.e.r:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", statusFavorited=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.s; // c.e.s:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", statusInReplyToScreenName='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.t; // c.e.t:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", profileBackgroundColor='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.u; // c.e.u:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", profileTextColor='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.v; // c.e.v:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", profileLinkColor='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.w; // c.e.w:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", profileSidebarFillColor='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.x; // c.e.x:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", profileSidebarBorderColor='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.y; // c.e.y:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", friendsCount=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.z; // c.e.z:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", createdAt=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.A; // c.e.A:java.util.Date
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", favouritesCount=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.B; // c.e.B:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", utcOffset=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.C; // c.e.C:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", timeZone='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.D; // c.e.D:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", profileBackgroundImageUrl='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.E; // c.e.E:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", profileBackgroundTile='";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.F; // c.e.F:java.lang.String
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.append(v3); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", following=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.G; // c.e.G:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", notificationEnabled=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.H; // c.e.H:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", statusesCount=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.I; // c.e.I:int
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", geoEnabled=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.J; // c.e.J:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = ", verified=";
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = v4.K; // c.e.K:boolean
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        v1 = 125;
        _result = v0.append(v1); // java.lang.StringBuilder.append -> java.lang.StringBuilder
        v0 = _result;
        _result = v0.toString(); // java.lang.StringBuilder.toString -> java.lang.String
        v0 = _result;
        return v0;
    }

}